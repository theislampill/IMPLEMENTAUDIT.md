#!/usr/bin/env bash
set -euo pipefail

resolve_package_version() {
  local skill_dir="${1:-}"
  if [ -z "$skill_dir" ]; then
    skill_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
  elif [ -d "$skill_dir" ]; then
    skill_dir="$(cd "$skill_dir" && pwd -P)"
  else
    printf 'detect-env: skill directory does not exist: %s\n' "$skill_dir" >&2
    return 1
  fi

  local -a py_cmd=()
  if command -v python >/dev/null 2>&1; then
    py_cmd=(python)
  elif command -v python3 >/dev/null 2>&1; then
    py_cmd=(python3)
  elif command -v py >/dev/null 2>&1; then
    py_cmd=(py -3)
  else
    printf 'unknown\n'
    return 0
  fi

  "${py_cmd[@]}" - \
    "$skill_dir/IMPLEMENTAUDIT_PACKAGE.json" \
    "$skill_dir/../../IMPLEMENTAUDIT_PACKAGE.json" \
    "$skill_dir/../../package/implementaudit-package.json" <<'PY'
import json
import re
import sys
from pathlib import Path

observed = []
for raw_path in sys.argv[1:]:
    path = Path(raw_path).resolve()
    if not path.is_file():
        continue
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise SystemExit(f"detect-env: invalid package identity {path}: {exc}")
    version = value.get("runtime_version") if isinstance(value, dict) else None
    if not isinstance(version, str) or not re.fullmatch(r"[0-9]+(?:\.[0-9]+)*", version):
        raise SystemExit(f"detect-env: invalid package runtime_version in {path}")
    observed.append((path, version))

if not observed:
    print("unknown")
elif len({version for _, version in observed}) != 1:
    detail = ", ".join(f"{path}={version}" for path, version in observed)
    raise SystemExit(f"detect-env: package version contradiction: {detail}")
else:
    print(observed[0][1])
PY
}

if [ "${1:-}" = "--package-version" ]; then
  [ "$#" -le 2 ] || {
    printf 'detect-env: --package-version accepts at most one skill directory\n' >&2
    exit 1
  }
  resolve_package_version "${2:-}"
  exit $?
fi
[ "$#" -eq 0 ] || {
  printf 'detect-env: unknown argument: %s\n' "$1" >&2
  exit 1
}

printf 'implementaudit.detect-env\n'
printf 'pwd=%s\n' "$(pwd)"
printf 'os=%s\n' "$(uname -s 2>/dev/null || printf unknown)"
printf 'shell=%s\n' "${SHELL:-unknown}"
host_signature="${OS:-}:$(uname -s 2>/dev/null || printf unknown):${SHELL:-}"
case "$host_signature" in
  *Windows_NT*|*MINGW*|*MSYS*|*CYGWIN*|*pwsh*|*powershell*|*cmd.exe*)
    printf '%s\n' 'warn=stream_reencoding_host: capture native output whole; record {command, exit_code, started, finished}; CLIXML=diagnostics-only'
    ;;
esac
printf 'side_effects=none\n'

if command -v git >/dev/null 2>&1; then
  printf 'git=%s\n' "$(git --version)"
  if git rev-parse --show-toplevel >/dev/null 2>&1; then
    git_root="$(git rev-parse --show-toplevel)"
    printf 'git_root=%s\n' "$git_root"
    git_common_dir="$(git rev-parse --path-format=absolute --git-common-dir 2>/dev/null || true)"
    if [ -z "$git_common_dir" ]; then
      git_common_dir="$(git rev-parse --git-common-dir)"
      case "$git_common_dir" in
        /*|[A-Za-z]:/*|[A-Za-z]:\\*) ;;
        *) git_common_dir="$(cd "$git_root" && cd "$(dirname "$git_common_dir")" && printf '%s/%s' "$(pwd -P)" "$(basename "$git_common_dir")")" ;;
      esac
    fi
    shared_repo_root="$(cd "$(dirname "$git_common_dir")" && pwd -P)"
    host_notes_path="$shared_repo_root/.IMPLEMENTAUDIT/host-notes.md"
    host_notes_count=0
    if [ -f "$host_notes_path" ]; then
      host_notes_count="$(awk -F'|' '
        /^[[:space:]]*#/ || /^[[:space:]]*$/ { next }
        NF >= 4 { count++ }
        END { print count + 0 }
      ' "$host_notes_path")"
    fi
    printf 'host_notes_path=%s\n' "$host_notes_path"
    printf 'host_notes_count=%s\n' "$host_notes_count"
    # Evidence-version anchor (#4): name the exact state evidence will be
    # gathered at, and surface LOCAL tracking-ref divergence. Read-only —
    # no fetch; a local tracking ref never implies remote freshness.
    head_sha="$(git rev-parse --short HEAD 2>/dev/null || printf none)"
    head_date="$(git log -1 --format=%cI 2>/dev/null || printf unknown)"
    printf 'head=%s (%s)\n' "$head_sha" "$head_date"
    upstream="$(git rev-parse --abbrev-ref --symbolic-full-name '@{u}' \
      2>/dev/null || true)"
    if [ -n "$upstream" ]; then
      counts="$(git rev-list --left-right --count "@{u}...HEAD" \
        2>/dev/null || printf 'unknown unknown')"
      behind="${counts%%[[:space:]]*}"
      ahead="${counts##*[[:space:]]}"
      printf 'upstream=%s behind_ahead=%s/%s\n' "$upstream" "$behind" "$ahead"
    else
      printf 'upstream=none\n'
    fi
    printf 'remote_freshness=not_checked\n'
    git status --short --branch
  else
    printf 'git_root=none\n'
  fi
else
  printf 'git=absent\n'
fi

for cmd in python python3 node npm pnpm yarn uv bash grep rg gh zip unzip; do
  if command -v "$cmd" >/dev/null 2>&1; then
    printf '%s=%s\n' "$cmd" "$(command -v "$cmd")"
  else
    printf '%s=absent\n' "$cmd"
  fi
done

printf '\nhost-session:\n'
printf 'codex_home=%s\n' "${CODEX_HOME:-unset}"
printf 'claude_config_dir=%s\n' "${CLAUDE_CONFIG_DIR:-unset}"
printf 'implementaudit_base=%s\n' "${IMPLEMENTAUDIT_BASE:-.IMPLEMENTAUDIT/runs}"
printf 'implementaudit_skill_dir=%s\n' "${IMPLEMENTAUDIT_SKILL_DIR:-skills/implementaudit (default; set to the installed skill directory)}"
printf 'implementaudit_package_version=%s\n' "$(resolve_package_version "${IMPLEMENTAUDIT_SKILL_DIR:-}")"
printf 'implementaudit_run_root=%s\n' "${IMPLEMENTAUDIT_RUN_ROOT:-unset}"
printf 'implementaudit_baseline_ref=%s\n' "${IMPLEMENTAUDIT_BASELINE_REF:-unset}"
if command -v bash >/dev/null 2>&1; then
  printf 'helper_layer=available (bash present)\n'
else
  printf 'helper_layer=unavailable (no bash; use documented weaker-evidence fallbacks)\n'
fi

printf '\noptional-docs-and-web:\n'
for cmd in gh curl wget; do
  if command -v "$cmd" >/dev/null 2>&1; then
    printf '%s=%s\n' "$cmd" "$(command -v "$cmd")"
  else
    printf '%s=absent\n' "$cmd"
  fi
done
printf 'web_lookup_authorization=unknown_owner_decision\n'
printf 'current_docs_lookup_authorization=unknown_owner_decision\n'

printf '\nmemory-continuity:\n'
for cand in \
  "${CODEX_HOME:-$HOME/.codex}/memories" \
  "$HOME/.codex/memories" \
  "$HOME/.claude/memory" \
  "$PWD/.claude/memory" \
  "${IMPLEMENTAUDIT_RUN_ROOT:-.IMPLEMENTAUDIT/runs/unclaimed}/memory"
do
  if [ -d "$cand" ]; then
    printf 'present: %s\n' "$cand"
  else
    printf 'absent: %s\n' "$cand"
  fi
done

printf '\nrun-roots:\n'
if [ -d .IMPLEMENTAUDIT/runs ]; then
  find .IMPLEMENTAUDIT/runs -mindepth 1 -maxdepth 1 -type d 2>/dev/null | sort | sed -n '1,40p'
else
  printf 'none\n'
fi
if [ -f .IMPLEMENTAUDIT/STATE.md ] || [ -f .IMPLEMENTAUDIT/ROADMAP.md ]; then
  printf 'legacy_flat_state=present\n'
else
  printf 'legacy_flat_state=absent\n'
fi

for cmd in graphify activegraph; do
  if command -v "$cmd" >/dev/null 2>&1; then
    printf '%s=%s\n' "$cmd" "$(command -v "$cmd")"
  else
    printf '%s=absent_optional\n' "$cmd"
  fi
done

printf '\nsidecar-authorization:\n'
printf 'graphify_indexing=not_authorized_by_default\n'
printf 'activegraph_event_writing=not_authorized_by_default\n'
