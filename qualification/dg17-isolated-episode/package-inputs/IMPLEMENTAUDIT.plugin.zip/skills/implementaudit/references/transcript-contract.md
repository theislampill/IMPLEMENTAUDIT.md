# Transcript Contract

Use this reference when a host, wrapper, or `/goal` evaluator needs to inspect
ImplementAudit transcript state without reading the full skill.

## Native integration support reference

The transcript contract supports native audit-object integration by making
read-only audit-object closure boundaries, repo-content-as-data security handling, branch/diff scope,
execute/review decisions, and reconciliation visible to host evaluators. The
primary integration contracts live in `audit-category-matrix.md` and
`plan-lifecycle.md`; transcript markers prove those contracts reached terminal
audit-object state.

The transcript contract is an execution boundary. It is not a release,
publication, provenance, install, Graphify indexing, or ActiveGraph export
claim.

The transcript records audit object lifecycle state. The `tdqyq-audit-object`
is the evidence-bearing record for the run: input, ledger, phase artifacts,
owner/source decisions, checks, Andons, handoffs, and terminal verification
state. `ydqyq-audit-action` operations may happen repeatedly, but the run closes
only when marker state proves the audit object reached terminal verified
closure.

For release-affecting, multi-phase, package-boundary, provenance, or public-claim
work, the transcript must preserve the double-audit sequence:

```text
AUDIT_START          -> creates or normalizes the tdqyq-audit-object
ydqyq-audit-action   -> acts against that object before mutation or handoff
AUDIT_VERIFY         -> checks object state against evidence
AUDIT_COMPLETE       -> terminal verified closure of the object
```

## RC self-dogfood evidence contract

Only exact RC/self-release `SELF_DOGFOOD_TRIGGER` loads this;
`ORDINARY_IMPLEMENTAUDIT_CONTROL` loads no dogfood owner/broker/schema. Runner
creates a temporary `CODEX_HOME`, binds candidate commit, candidate tree, package SHA-256, and installed runtime SHA-256, and isolates context/journal/key from model roots; an event cannot qualify itself. Repo-only broker is the runner-owned action boundary, never installed/ordinary I/O.

`implementaudit.dogfood-event.v1` records session, monotonically increasing sequence, unique sequence/correlation/event identity, previous event identity, actor/action/role/phase/result, target/content identity, and an HMAC produced with runner custody unavailable to the audited model. Validation fails closed on a missing event/action, duplicate/reorder, broken chain, invalid HMAC/schema, blocked/ambiguous result, pre-baseline/real-home read, or identity mismatch. Order: trigger -> contract/broker/schema -> successful machine-readable clean status/HEAD/HEAD^{tree} -> temp activation -> targeted read/search; independent corroboration reruns those fixed Git observations against the runner-bound source root.

Typed runner events are the primary semantic evidence, not sole authority; transcript remains independently parsed adversarial corroboration. Require bijective correlations and equal action facts; mismatch is `Andon: typed dogfood evidence contradicts independent observation`.

Host activation is not readback. Read only owners; prove package/checksum/install parity. Real-home installed skill readback is non-evidence; later temp proof cannot cure it. Policy rejection blocks; never bypass policy, use real home/broad globs, or weaken proof.

## Planner markers

Planner markers appear before a user starts a generated `/goal` handoff.
They are emitted by Stage 6 and Stage 6.ii of the native IMPLEMENTAUDIT planner.

```text
Self-critique:
PREFLIGHT_GREEN
PREFLIGHT_RED
```

- `Self-critique:` records the Stage 6 plan-review result.
- `PREFLIGHT_GREEN` means the deduplicated mandatory checks passed before
  dispatching a generated handoff.
- `PREFLIGHT_RED` means the pre-flight check failed or needs owner review.
- `PREFLIGHT_RED` is not a bypass. It must classify the failed baseline as
  target, unrelated, or unclear before any handoff or mutation continues.

## Stage handoff boundary

When Stage 7 prints a ready-to-paste `/goal`, the handoff is valid only if it
names the runtime protocol, sequential phase execution, final audit before
completion, and the handoff/failure exclusion rules. If the current session is
already inside `/goal using /implementaudit ...`, no second `/goal` should be
printed.

## Phase markers

Phase-loop markers appear in this order for each executed phase:

```text
IMPLEMENTAUDIT_PHASE_START
IMPLEMENTAUDIT_PHASE_VERIFY
AGENTS_UPDATE_DECISION
IMPLEMENTAUDIT_PHASE_DONE
```

- `IMPLEMENTAUDIT_PHASE_START` opens the phase and names the owner/source.
- `IMPLEMENTAUDIT_PHASE_VERIFY` records criteria, checks, evidence type, and
  cleanliness readback.
- `AGENTS_UPDATE_DECISION` states whether a durable repo-local rule was added,
  not warranted, or requires owner decision.
- `CONTINUITY_DECISION`, when printed, states whether a non-obvious learning
  warrants a bounded repo-local rule, memory note, deferral, or no writeback.
  It does not replace `AGENTS_UPDATE_DECISION`.
- `IMPLEMENTAUDIT_PHASE_DONE` closes the phase.

## Andon escalation markers

```text
ANDON_PROBE
ANDON_ESCALATE
ANDON_HANDOFF
```

Andon escalation implements Jidoka: abnormality -> stop -> understand why ->
countermeasure -> rerun evidence. The sequence is ordered: ANDON_PROBE →
ANDON_ESCALATE → ANDON_HANDOFF. Skipping to ANDON_HANDOFF on the first
abnormality is invalid. Escalation is driven by repeated same-class failure
and blocked closure, not by a try counter. There is no arbitrary three-try or
three-round cap.

Every Andon event is recorded as one classed row in the run-root STATE.md
`## Andon log` (`# | Occ | Phase | Class | Abnormality | Countermeasure |
Rerun evidence | Outcome`). One class per row; one or more linked rows per
occurrence: an occurrence carrying several independent defects records one
row per class sharing the same `Occ` id, so co-occurring defects stay
linked while per-class recurrence citation is unchanged. Legacy run roots
using the previous table shape (no `Occ` column) remain valid and resume
safely. `Class` is exactly one official abnormality class:

```text
failed-criterion
regression
hung-command
substituted-command
owner-unclear
generated-artifact-mismatch
stale-sidecar
policy-conflict
impossible-criterion
evidence-mismatch
transport-infrastructure
misplacement
false-closure
```

Definitions and boundaries for the three environment/accounting classes:

- `transport-infrastructure` — environment-level failure: network outage
  windows, process-initialization exit codes (e.g. 0xC0000142), host
  resource loss, or simultaneous failures across independent lanes.
  Boundary vs `hung-command`: `hung-command` is a single command failing to
  return/progress on an otherwise healthy, responsive host; discriminating
  evidence for infra is cross-lane simultaneity, OS-level init/exit
  signatures, or a known outage window. A failure of the REVIEW/ADVISORY
  CHANNEL itself (e.g. a platform-side filter blocking an authorized
  reviewer before any verdict) is `transport-infrastructure`, never
  evidence about the reviewed tree: preserve the non-verdict, reissue to
  the SAME authorized reviewer identity with a narrowed prompt, and never
  treat a blocked review as an accept or a reject.
- Resource exhaustion is `Class: transport-infrastructure | Blocker:
  resource-exhausted`. Label `reported_reset` `ADVISORY`; set `next_probe_at =
  min(reported_reset, backoff_probe_at)` and run a cheap capacity probe then.
  Success resumes early; only a recorded failed probe supports `blocked`.
- Supervision overrun is `Class: hung-command | Blocker:
  supervision-overrun (poll_budget N exceeded)`. Neither discriminator is a
  new class token.
- `misplacement` — right layer, wrong INSTANCE: a correct finding or fix
  attached to the wrong copy, version, file, component, or occurrence.
  Boundary vs `generated-artifact-mismatch`: that class is the wrong LAYER
  of a generator relationship (patching generated output instead of the
  source owner, or attributing generated state to source).
- `false-closure` — the closure-state ACCOUNTING is wrong: a completion
  claim collapses unresolved / unvalidated / deferred / transferred /
  risk-accepted items into "fully resolved", even when every individually
  cited piece of evidence is genuine. Boundary vs `evidence-mismatch`:
  that class is one specific claim whose cited evidence does not support
  it.

Boundary fixtures (expected classification + rationale):

| Fixture | Expected class | Rationale |
| --- | --- | --- |
| Adapter exits 0xC0000142 during a known network outage; sibling lane fails in the same window | `transport-infrastructure` | environment-level signature + cross-lane simultaneity, not a single stalled command |
| One `grep` never returns on a responsive host; siblings unaffected | `hung-command` | process-level stall in a healthy environment |
| Fix applied to the deployed copy while the source copy still carries the defect | `misplacement` | right layer (source-owned pair), wrong instance/copy |
| Patch written into a generated bundle instead of its source owner | `generated-artifact-mismatch` | wrong layer of a generator relationship |
| Run declared "fully resolved" while two ledger rows are risk-accepted and one is transferred | `false-closure` | closure accounting collapsed non-resolved states |
| A claim cites a passing test that does not cover the claimed behavior | `evidence-mismatch` | one claim, unsupporting evidence |
| Authorized reviewer returns no verdict (transient channel failure: rate limit, 5xx, or interruption) | `transport-infrastructure` | review-channel failure; preserve non-verdict and reissue to the same reviewer identity |
| Authorized reviewer returns no verdict (content-deterministic refusal: provider policy or schema rejection caused by packet text) | `transport-infrastructure` | review-channel failure; preserve non-verdict, record the origin, and do not reissue an unaltered packet — alter scope or wording first |

Same-class recurrence — not a try count — is what drives escalation. The log
has no row limit.

These markers and classes apply to any governed run, phased or not. When no
run root exists (direct in-session governance), the Markdown findings ledger
serves as the Andon log substrate: record the abnormality class on the ledger
row and cite prior same-class rows on escalation. The source-repo checker
applies the recurrence rule to that substrate with
`validate-run-root.sh --ledger <markdown-ledger>`.

- **ANDON_PROBE**: emitted on the first abnormality of any class above. It
  must record: the abnormality and its class; the failing criterion, command,
  or artifact; owner/source; containment decision; a 5 Whys root-cause drill
  proportional to the issue; Hansei (gap, cause, countermeasure, follow-up
  evidence); the countermeasure selected; and the rerun evidence required.
  The classed `## Andon log` row is appended and STATE.md is updated. A fix
  may not be attempted merely because a symptom is visible; the fix must
  follow from the probe. If the countermeasure passes its rerun evidence, the
  phase resumes; no new marker is needed.

- **ANDON_ESCALATE**: emitted when the first countermeasure fails, the
  same-class abnormality recurs, the root cause remains unclear, the fix would
  expand scope, or the owner/source is disputed. A same-class recurrence claim
  must cite the prior same-class `## Andon log` rows by `#`; a recurrence
  claim without a cited same-class row is invalid. It must record: the prior
  ANDON_PROBE history; why the first countermeasure failed; a revised or
  deeper 5 Whys; `New evidence:` and/or `Changed approach:` — if neither can
  be truthfully filled, evaluate the ANDON_HANDOFF conditions instead of
  escalating; the chosen path — split, reframe, rollback, owner decision,
  or a bounded fix-spec (`phase-N.fix.md` targeting only the failing
  criterion, no scope expansion, ending with the original VERIFY gate); and
  rerun evidence. On success, the phase resumes from
  IMPLEMENTAUDIT_PHASE_VERIFY. Escalation may repeat with new evidence;
  repeating it without new evidence or progress routes to the ANDON_HANDOFF
  conditions. When three distinct linked occurrences share one class and the
  last two repairs name the same `owner/source=<path>` in their Countermeasure
  cells, append a `Mechanism-replacement decision:` after the last triggering
  row and before closure. The accepted decisions are `replace-mechanism
  (<what>)`, `continue (<justification>)`, and
  `escalate-to-convergence-mode (<shared invariant>)`; none stops another
  bounded repair.

- **ANDON_HANDOFF**: emitted only when closure is blocked by an owner
  decision, unsafe scope, missing authorization, an external dependency,
  irreproducibility, a missing required tool or access, or when no bounded
  countermeasure remains. It is not "third try failed." Includes the full
  probe and escalation history, the remaining blocker, and the smallest next
  concrete action for a human owner. STATE.md set to BLOCKED. Phase done with
  `Status: blocked`. Phases that depend on the blocked surface do not execute;
  independent in-scope phases may continue when safe, and the run ends in an
  audited handoff rather than completion.

`ANDON_HANDOFF` is terminal for the blocked surface. A transcript containing
`ANDON_HANDOFF` must not also contain `IMPLEMENTAUDIT_RUN_COMPLETE`.
STATE.md `Status: BLOCKED` must be set before the run stops or hands off.
Legacy transcripts may contain the older FAILURE-prefixed marker spellings;
hosts must apply the same exclusivity rule to them, but new runs emit only the
ANDON-prefixed markers.

## Interruption and continuity markers

```text
IMPLEMENTAUDIT_PAUSE
IMPLEMENTAUDIT_CONTINUITY_SAVED
```

- `IMPLEMENTAUDIT_PAUSE` is emitted when a user message interrupts a phase in
  progress (after IMPLEMENTAUDIT_PHASE_START, before IMPLEMENTAUDIT_PHASE_DONE).
  It records: phase number, paused-at-boundary or paused-mid-step, last
  completed step, and whether STATE.md was updated. A transcript containing
  IMPLEMENTAUDIT_PAUSE must contain a preceding IMPLEMENTAUDIT_PHASE_START.
  Resume follows the run-root PROTOCOL.md resume contract: re-read state and
  spec from disk, re-validate the phase spec, and continue from the paused
  step without re-printing IMPLEMENTAUDIT_PHASE_START.
- `IMPLEMENTAUDIT_CONTINUITY_SAVED` is emitted only when a bounded continuity
  writeback is actually performed (plan-lifecycle.md Stage 0; PROTOCOL.md continuity
  steps). It must carry all six fields: Target, Reason, Evidence, Boundary,
  Authorization, Not saved. Saved continuity never overrides live files,
  AGENTS.md, Smoke A/B evidence, or the final audit.

Neither marker is a completion or handoff signal; both may appear in
transcripts that later reach AUDIT_COMPLETE or an audited handoff.

Context-epoch continuity (#35) deliberately introduces NO new marker: a
continuity boundary is recorded as a new epoch row in STATE.md `## Context
epochs and instruction applicability` (provenance exactly one of
`host-reported-compaction` / `new-session` / `handoff-resume` /
`manual-resume` / `inferred-context-gap`, plus the distinct claim-owned
`canonical-state-rotation`), and post-boundary reconciliation
precedes any repository mutation (PROTOCOL.md §Continuity boundaries;
`references/continuity.md`). A transcript that mutates the repository
after a host-reported compaction without a reconciliation record, or that
re-executes a one-shot instruction whose status is `satisfied`, violates
this contract even though every marker is well-ordered.

The first substantive post-boundary assistant message must be the verified
continuity receipt/current-frontier report. Waiting on or terminating an
already-running pre-boundary process is containment, not permission to start a
new command. Ordinary task narration, a new check, an audit-artifact write, a
package build or a commit before fresh invalidation, receipt verification and
currentness is a continuity violation. A remembered standing constraint remains
binding but does not become the active frontier without live-state evidence.
After migration, token-bound `--read-resume-state` reads preserve the required
STATE-then-ROADMAP order under `PRE_RESUME_EVIDENCE`. They do not replace fresh
native receipt verification or confer currentness; see `continuity.md`.


## Evidential-support contract

Use the read-only stdlib owner
`../scripts/validate-audit-implement-return.py`. Existing
mechanical owners establish facts first; this consumer only validates supplied
values. Its `VALUE_VALIDATION` output does not authenticate host currentness,
authority, evidence, semantic sufficiency or native admission.

```bash
python3 scripts/validate-audit-implement-return.py --envelope envelope.json
python3 scripts/validate-audit-implement-return.py --envelope envelope.json --result result.json --current-envelope current.json
```

Paths above are relative to the executing governor directory. The first form
checks pre-load values. The second requires freshly supplied current facts,
validates the current envelope, and demands complete equality with the original
before reading the result. Any subject, configuration, evidence, consumer,
decision-time, candidate or executing-package drift returns to the governor;
no stale result is consumed. Fresh values alone do not prove host freshness.

The exact envelope keys are `contract_version`, `child`, `routing_owner`,
`entry`, `subject_class`, `semantic_need`, `subject`, `package`, `evidence_set`,
`claims`, `assumptions`, `limitations`, `defeaters`, `unresolved_obligations`,
`mechanical`, `currentness`, `release_currentness`, `maintainer_scope`; only the
release branch also requires `candidate`. The unchanged package maintainer-only
admission applies to both branches; a non-release subject grants no wider caller
authority.

| Field | Exact value or nested keys |
|---|---|
| `contract_version` | `implementaudit.evidential-support.v2` |
| `child`, `routing_owner`, `entry` | `audit-implement`, `/implementaudit`, `GOVERNOR` |
| `semantic_need` | `REQUIRED`, `MECHANICALLY_SETTLED`, or `ORDINARY_REVERSIBLE`; the latter two return `BYPASS` and cannot consume a child result |
| `subject` | `identity`, `configuration`, `proposition`, `boundary`, `consumer`, `consequence`, `decision_time` (ISO date-time with timezone) |
| `package` | Executing package `identity`, `sha256` |
| `evidence_set` | `identity`, `sha256`, `manifest`; checksum is over the canonical manifest JSON |
| Each manifest item | `evidence_id`, `sha256`, `scope`, `common_source`, `independence`; retain common-source/correlation limits, including an explicit statement when independence is unestablished |
| Each envelope claim | `claim_id`, `subject_class`, `proposition`, `boundary`, `evidence_ids`; unique IDs, declared class matches the envelope, evidence references belong to the manifest |
| `mechanical` | `identity`, `hashes`, `parity`, `package`, `reachability`, `version`, `authority`, `custody` are `VERIFIED`; `writer_conflict`, `known_invalidators` are `CLEAR`; `required_tests` is `SATISFIED` |
| `currentness` | `subject`, `configuration`, `evidence_set`, `consumer`, `decision_time` are all `VERIFIED` |
| `release_currentness` | Release: `VERIFIED`; non-release: `NOT_APPLICABLE` |
| `candidate` (release only) | `source`, `commit`, `tree`, `artifact_sha256`, `package_sha256`, `install`, `host`; commit/tree are 40 lowercase hexadecimal characters |
| `maintainer_scope` (both branches) | `VERIFIED`; unchanged package admission ceiling |

Assumptions, limitations, defeaters and unresolved obligations are explicit
string lists, possibly empty. SHA-256 values are 64 lowercase hexadecimal
characters. Canonical JSON uses sorted keys, UTF-8, unescaped Unicode and no
separator whitespace. Each regular input file is at most 131072 bytes, each
list at most 128 items, and each nonempty string at most 4096 characters.
Duplicate JSON keys, nonstandard constants, symlinks, unknown keys, wrong
types/versions/states and authority fields outside the schema refuse. Evidence
hashes identify supplied evidence; this consumer does not open or authenticate
evidence objects or determine whether prose has been deceptively classified.

### Bounded return and legacy compatibility

Every result has exactly `contract_version`, `subject_class`, `envelope_sha256`,
`authority` (`NONE`), `rationale`, `limitations`, `gaps`, and `progression_advice`.
The digest binds the complete original canonical envelope. Advice is
non-authoritative and gives no permission. Semantic results also contain
`support_state` and `claims`. Each returned claim has exactly `claim_id`,
`support_state`, `rationale`, `limitations`, `gaps`, `conditions`, `defeaters`;
the claim-ID set equals the original envelope's set. Rationale and advice are
nonempty strings; all limitations/gaps/conditions/defeaters are string lists.

`CONDITIONAL` names exact outstanding conditions; other states cannot hide
conditions. `UNRESOLVED` names the evidence gaps rather than manufacturing a
contradiction. Apply the specific transport rule before that general gap rule:
local evidence offered for a broader deployment claim stays `CONDITIONAL` or
`NOT_SUPPORTED` until evidence closes the transport bridge. Use `CONDITIONAL`
with the exact outstanding transport qualifications, or `NOT_SUPPORTED` with
the reason the evidence cannot support the requested boundary. This boundary
judgement does not assert that the system has failed; absence of transport
evidence is not a factual counterexample. Do not use `UNRESOLVED` to bypass
this specific state bound, or silently narrow the requested deployment claim.
A separately stated narrower proposition can still be `SUPPORTED` within its
demonstrated scope. Other missing-evidence judgements retain `UNRESOLVED` and
their exact gaps. For multiple claims the conservative summary is `NOT_SUPPORTED`
if any claim has that state, otherwise `UNRESOLVED`, otherwise `CONDITIONAL`,
otherwise `SUPPORTED`. This consistency rule does not prove the judgement.

The release result additionally preserves the exact `legacy_disposition`:

| `legacy_disposition` | `support_state` and required meaning |
|---|---|
| `established` | `SUPPORTED`; preserve exact established scope |
| `contradicted` | `NOT_SUPPORTED`; preserve named defeaters |
| `insufficient` | `UNRESOLVED`; absence of evidence is not contradiction |
| `qualification gap` | `CONDITIONAL`; name the missing qualification |
| `unresolved` | `UNRESOLVED`; preserve unresolved obligations |
| `boundary not supportable` | `NOT_SUPPORTED`; rationale names the scope/boundary reason |
| `stale` / `identity mismatch` | Deterministic precondition refusal; `support_state` and `claims` are absent, never null or a semantic state |

Non-release results have no `legacy_disposition`. Old release consumers keep
the exact v1 token set until their versioned migration is qualified. Validator
exit 0 means value-valid or pre-load `BYPASS`; exit 1 with `REFUSED` preserves a
legacy deterministic refusal; exit 2 means invalid input, failed supplied
preconditions or drift. None of these exits authorizes a consequential action.


## Child-skill routing observability

A governed child route is user-visible only after the exact package gate,
resolver selection, and actual child load have occurred. The route narration
uses both lines:

```text
CHILD_SKILL_ROUTE=<selected-child>
I'm using <selected-child> to <bounded reason for this route>.
```

The selected child is exactly one of `audit-state`, `audit-assess`,
`audit-implement`, or `audit-andon`, and the announced identity must equal the
resolved and loaded child. Child files merely being packaged or discoverable,
or governor reasoning producing similar words or conclusions, is not a route.
Those governor-only cases emit no child announcement. An actual child load
without the announcement, an announcement without a load, a mismatched child,
duplicate child announcements, or a retroactive announcement is a routing
observability failure; none creates authority or closure.

For the ordinary real-boundary recovery route, the verified receipt precedes
the `audit-state` load. Its route line appears in the first narration permitted
after that receipt; it never displaces or precedes the receipt/currentness
gate. The other children follow the same actual-load/visible-route bijection
when their own governor gates genuinely select them.

A separately proved completed-compaction/resume obligation follows continuity's
required bounded route even when currentness is unresolved or its measured epoch
is absent. The actual-load announcement states that limit and preserves original
occurrence/source/scope identity; it claims no verified receipt or ordinary
execution permission. This exception does not turn dispatch, reservation, failed
return or matching output into accepted occurrence consumption. Native routing,
observation and accepted JOIN remain continuity-owned.

Preserve the existing owners' distinct evidence states; a transcript label is
not a transition receipt:

| State | Evidence boundary |
|---|---|
| Observation | Original physical occurrence, selected/prior/retry identity, source offsets/hash and scope/cutoff are identified; no child has run. |
| Reservation / OPEN | A scope is reserved or a route transaction opened; failed dispatch leaves its obligation pending. |
| LOAD | The exact selected child source was actually delivered and loaded; an attempted invocation or resolver lookup is insufficient. |
| RETURNED | That invocation produced its actual first original result; a later corrected copy is a distinct supported retry. |
| ACCEPTED | The existing governor/continuity owner checked identity, currentness, ceiling and covered scope; a success-shaped return is insufficient. |
| JOINED | The existing R0035 receiving owner completed the required result JOIN; acceptance alone cannot substitute for it. |
| Consumed | The continuity owner discharged only the accepted and joined covered scope/version. Uncovered successors remain pending, including equal H0/session labels. |

Missing currentness/epoch constrains the required bounded recovery result, not
its existence. Recover interrupted subordinate work locally from its retained
scope and actual result/absence; never mark a reservation or incomplete JOIN
consumed to make the governor appear converged. A route unavailable on a host
remains a typed capability gap with the original obligation retained.

Disclose only the selected capability and necessary evidence. Procedural skills
supply methods within an owner, never a fifth child, independence, admission or
authority. A subordinate lacking capability returns its typed gap, affected
scope and retained evidence to the governor. Local recovery keeps that owner
and actual effect ceiling. Authority-NONE prose is not host enforcement;
delegation or child chaining cannot evade the ceiling.

Verification inside a child may report an already-known cheap deterministic failure;
after return, the governor may handle that result without another model child.
If verification establishes that a new constraint defeats the selected countermeasure
and materially changes the warranted response, the active child returns to the
governor, the governor re-derives current state, and only then may it select and load a
fresh `audit-andon` route. If that diagnosis warrants another bounded repair,
`audit-andon` returns to the governor; execution/repair remains governor-owned
through its progressive reference. A later `audit-implement` route requires a
separately warranted exact claim and the applicable branch-specific admission/currentness gates.
A direct child-to-child transition is a routing failure.

## Final audit markers

```text
AUDIT_START
AUDIT_VERIFY
AUDIT_GAPS
AUDIT_WARNING
AUDIT_COMPLETE
AUDIT_HANDOFF
IMPLEMENTAUDIT_RUN_COMPLETE
```

Rules:

- Emit `AUDIT_START`, `AUDIT_VERIFY`, and applicable `AUDIT_GAPS`/`AUDIT_WARNING`
  per final-audit round. Emit `AUDIT_COMPLETE`, `AUDIT_HANDOFF` and
  `IMPLEMENTAUDIT_RUN_COMPLETE` once per run. Phase-local `ANDON_HANDOFF`
  follows its own phase contract.
  Do not replay a completion marker in a later summary or final response. Once
  emitted at its transition, later prose may describe the state but must not
  print that marker again.
- `AUDIT_START` carries `Skill version:` — the package identity version of the
  payload that produced the run, resolved by
  `scripts/detect-env.sh --package-version` across canonical-plugin,
  standalone-compatibility, or source layouts. Contradictory/malformed package
  identities stop the gate; `unknown` is reserved for an unresolvable identity
  or unavailable JSON-capable interpreter and is never guessed. This keeps the
  transcript attributable without making a host manifest the semantic owner.
- `AUDIT_COMPLETE` must precede `IMPLEMENTAUDIT_RUN_COMPLETE`.
- `AUDIT_COMPLETE` means the audit object reached terminal verified closure; it
  does not merely mean the runtime performed an audit operation.
- `AUDIT_HANDOFF` appears only when gaps, blockers, or handoff-required caveats
  remain.
- `AUDIT_HANDOFF` must not appear with `IMPLEMENTAUDIT_RUN_COMPLETE`.
- `AUDIT_WARNING` names a confidence caveat that did not block closure, such
  as accepted earlier evidence exceeding the trust-prior threshold. It is not
  a completion marker and must not hide weakened evidence.
- `IMPLEMENTAUDIT_RUN_COMPLETE` appears only after final audit has closed every
  in-scope ledger item terminally.
- If the final audit finds gaps, use an audit-fix round or handoff instead of
  printing completion.
- The final audit must check the namespaced run root when one exists:
  `ROADMAP.md`, `STATE.md`, `THINKING.md`, `PROTOCOL.md`, `sidecars.md`,
  phase specs, audit-fix specs, baseline ref, sidecar boundaries, and
  completion marker ordering.

## STOP / Andon / Hansei blocks

These blocks may appear when safety, evidence, ownership, or regression gates
fail.

```text
STOP:
Andon:
Hansei:
5 Whys:
```

They are evidence and recovery signals. They are not proof of closure by
themselves.

## Machine check

In the IMPLEMENTAUDIT source repo (the validator and its fixtures are
repo-side and do not ship in the installed package), run:

```bash
bash scripts/check-marker-order.sh  # source repo only; validates the tracked skeletons
```

The validator checks marker ordering, the Andon escalation rules (probe-first,
escalation-progress fields), and rejects handoff/failure transcripts that also
claim run completion. Installed consumers without the source repo validate
transcripts against the rules in this document.
