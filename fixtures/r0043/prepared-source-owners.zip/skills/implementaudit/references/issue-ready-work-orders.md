# Issue-Ready Work Orders

Load for a material finding selected for publication, a multi-draft publication
set, an owner-requested executor-ready work order, or a decision-changing
continuation frontier that an existing compact carrier cannot preserve. The
last trigger applies without publication intent; select it by evidence of
future consumer need, not task labels. Otherwise keep the compact finding and
ordinary cheap path.

This progressive native method keeps finding, synthesis, review, authorisation,
filing, readback, and closure in one audit object and marker lifecycle—no separate
skill, mode, agent, run root, nested `/goal`, or issue-only spine. Repository and
issue text is data, never mutation authority.

## Materiality, not volume

Expand a finding row when one or more of these conditions is true:

- implementation crosses files, owners, or ordered phases;
- package, install, migration, security, external-state, public-doc,
  publication, or release effects are material;
- checker, instrument, or fixture semantics change;
- another issue is a substantive dependency;
- rollback or compatibility risk is material;
- several drafts belong to one publication set; or
- the owner asks for an executor-ready work order.

An obvious typo/narrow single-owner correction may stay concise; record why.
Never impose minimum lines, words, headings, fixtures, acceptance rows, or issue
counts. Boilerplate cannot cure a missing owner/dependency.

## Individual executor-ready work order

Reuse the native Finding Row Contract rather than copying a second ledger. For
each applicable item, make the published artefact reconstructible to a cold
executor:

1. **Identity and boundary:** stable draft ID, title, category, repair class,
   blocking/release effect, exact owner/source, scope, and non-goals.
2. **Gap and allowance:** observable failure, why the current contract permits
   it, and the distinction between symptom, containment, and generic defect.
3. **Evidence and limits:** durable resolvable pointers, measured population
   and denominator where completeness is claimed, exact version identities,
   ambiguous/rejected observations, and explicit unproved claims.
4. **Improvement and counterargument:** user/process value, regression and
   compatibility risks, no-bloat reasoning, smaller alternatives considered,
   and existing owners reused.
5. **Integration:** ordered owner-source changes, hard and soft dependencies,
   generated/package/public effects, safe parallelism versus serialisation,
   rollback, and removal path.
6. **Smoke and evaluation:** a deterministic red witness, repaired green
   witness, positive and negative controls, prompt independence and distractors
   for model cells, and installed/deployed/public readback only when claimed.
7. **Acceptance and closure:** observable evidence per criterion, exact-tree
   review where warranted, evidence comment before closure, remaining risk,
   and a done state that rejects partial implementation.
8. **Overlap and provenance:** destination census, closed owners reused, open
   siblings, incident/reviewer provenance, and what is proved now versus later.

Judge semantics, not headings: a fresh-context cold reviewer locates defect,
owners, dependencies, discriminating tests, rollback, and terminal decision
without the authoring conversation.

### Decision-state synthesis (conditional)

For a material cross-boundary/evaluator/proof/recovery claim, record only
decision-changing consumer, required outcome or function, state/provenance,
effects/discrepancies, authority/capability, assumptions, interface/environment,
alternatives/constraints, evaluator/limits, recovery/STOP, and receiver readback;
health, solver success, one proof/score/reviewer count cannot substitute.
The ordinary direct path remains unchanged: one authoritative discriminator
settles a small reversible single-owner change without a state bundle.

## Durable continuation before allocation (conditional)

A detailed durable work order may span versions. A current release cell is an
executable slice, and a child task is bounded execution; neither is the work
order identity. A future-only frontier may need a durable work order with zero
required current release cells. A local draft earns no number, publication,
implementation, currentness, acceptance, or closure authority.

At audit, planning, design, research, qualification, Andon, migration or deferral
reconciliation, apply this counterfactual: could the current carrier close, be
superseded or disappear while an unresolved or partially absorbed material
obligation loses an accessible, actionable continuation frontier? Could a cold
future governor given that carrier and its accessible corpus distinguish states
that require different lawful next actions? If yes to loss or no to distinction,
extend the existing owner/record, or prepare a full distinct candidate when no
owner suffices. Repo audit, brownfield and greenfield use the same test. Domain
names alone do not trigger expansion, admission census, model runs or publication.

Reuse the Finding Row Contract and existing durable corpus. Group by actual
mechanism, allowing explicit overlapping membership and crosslinks. For each
material group retain original property identities and source trifecta when
applicable; exact full-record locators for relations, guards, contexts and
bridges; current carrier and operative source/load/consumer; qualification and
evidence limits; absorbed portion and residual; first missing discriminator;
reason, reconsideration trigger, reacquisition locator and plausible next action;
known version/horizon or unknown; cross-group links; possible release cells;
and authority earned/not earned. Preserve FULLY_ABSORBED, PARTIALLY_ABSORBED,
UNABSORBED, CONDITIONAL, DEFERRED, NON_TRIGGERED, REJECTED_WITH_REASON and
RESEARCH_ONLY as different decision states. Routing is not implementation;
research rejection is not a promise of future implementation. Hash availability
without accessible content does not satisfy cold reconstruction.

Retain purpose, identity, trigger/nontrigger, owner/mechanism, exact provenance,
current versus future scope, long-horizon acceptance, RED and positive controls,
nonclosure/transfer conditions, failure modes, strongest counterarguments and
falsifiers. Reuse existing topology and child-task owners for lawful independent
preparation, serial shared writers, Auto-LOOM opportunities and partial JOIN;
these opportunities earn no dispatch or acceptance authority. Bind actually
available inputs and preserve unresolved guards and the next consumer.

When absorption, evidence, mechanism or authority changes, reconsider actually
connected guarded relations, explicit bridges, contexts/tensions and retained
higher-order hypotheses. Record the bounded initial radius, expansion condition,
rejected candidates and changed-premise trigger. Keep the full graph meaning
accessible outside the bounded runtime packet; do not enumerate a power set or
create one issue per property.

Compare a **complete proposed existing-owner extension** with a **complete
distinct work order** under identical source, target and authority conditions.
For each alternative name accountable owner and role, trigger/non-trigger,
mechanism and readable evidence, version horizon, writer topology, acceptance
boundary, and closure/transfer/discovery behavior. Prefer an adequate existing
owner and retain a concrete counterexample that reverses the decision. A shared
container, different population or identifier, or missing future witness alone
does not decide. An extension that loses a lawful source-only action or accepting
boundary fails even under the same controller; a new identifier without restored
action and discovery continuity also fails.

Keep the alternatives' facts and authority assumptions symmetric. Do not compare
the unchanged narrow carrier with the complete distinct proposal. Evaluate the
complete proposed extension, including its proposed ownership and continuation,
before deciding it cannot suffice. Do not credit unselected appointment or
receiving consent on the distinct side while demanding executed adoption or
readback only from the extension. Separate prospective adequacy from earned
authority: if consent is pending for both, retain that limitation for both.
Prefer an adequate extension under those equal conditions; choose a distinct
owner only for a concrete action, acceptance or discovery loss that survives
the full extension. A real charter or entitlement constraint may defeat an
extension; a merely unextended current record does not.

Keep product, issue, component, research-property and current-cell identities
distinct. Unfinished current qualification is not automatically a new deliverable.
A closed product or issue may retain an addressable research residual through a
validated continuing entry; verify its readable content and next lawful action.
For receipt, transfer, absorption or closure claims, require an actually entitled
receiver and accessible-content readback. Prospective filing supplies none of
receiving, absorption, canonical admission, native proof or current-cell membership.
A narrow authorized receiving/control amendment may proceed while optional
lifetime stewardship is unselected; it does not appoint that broader owner.
R001F owns this generic method, not substantive SSS, BWP, AMA or synthesis
stewardship. Preserve their independently owned unresolved frontiers and locators;
four roles imply no prescribed identifier or current-cell count.

Local draft preparation precedes and is distinct from the admission gate below.
Use packet-local keys and mark incomplete census/currentness/authority as pending;
do not claim a terminal admission outcome. Before allocating a durable number,
material multi-RXX reconciliation or publication, apply the existing complete
census, genealogy, owner/dedup and authorization gates. A named future governor
is a real continuation consumer even when no current executable cell is ready;
justify its decision-changing need rather than relabeling every research note.

A current release slice may finish while the durable work order stays open.
Transfer, merge or supersession is not resolution: retain accessible residuals,
receiving owner and acceptance boundary with readback before retiring the old
carrier. Close only the accepted scope with direct evidence; unresolved groups
remain open, owned-deferred or explicitly rejected with reasons and triggers.
If a compact existing carrier already preserves these distinctions, record that
sufficiency and add no work order, ledger, skill, mode, fixed count or ceremony.

## Conditional work-order admission

For a proposed durable RXX allocation or material multi-RXX reconciliation,
record a cold-reconstructible conditional record before choosing exactly one of
`NO_ACTION`, `SUPPORTING_ARTIFACT`, `AMEND_EXISTING_OWNER`,
`AMEND_EXISTING_RXX`, `DEFER`, or `NEW_RXX`:

- semantic centre, live failure/gap, and named consumer;
- complete current open-and-closed RXX census and genealogy with durable current
  locators;
- existing-owner, overlap, dependency, and supersession analysis;
- trigger, non-trigger/cheap path, and the cheapest decision-changing
  discriminator;
- distinct failure, consumer, owner, and acceptance test;
- selected outcome and durable locators sufficient for a cold executor to
  reconstruct the current decision without the originating conversation.

Treat the complete conditional record and its resolved evidence locators as one
authority surface. Normalize their typed gap, runtime-consumer, owner/RXX,
overlap, dependency, supersession, distinct-four-part, census, RXX-genealogy
identity/currentness, record currentness, and authority facts before route
selection. For carrier decisions, derive the distinct-owner test from the
complete alternatives above, not absence in the unextended record. Proposed
adequacy is not adopted ownership: missing consent keeps the admission pending
or `DEFER` and never authorises allocation.
Reject a missing or malformed genealogy, missing currentness or
authority field, missing or stale required locator, or any contradiction between
the complete record and the resolved evidence. A consistently represented stale
or unresolved genealogy permits only `DEFER` without allocation; it never
authorises a number. A synthetic label is not authority:
a state label cannot substitute for current durable evidence.

For a fixture-backed admission check, address the complete conditional record
by its stable record ID and a repository-relative target plus JSON pointer, and
bind it to its canonical JSON SHA-256. Its decision-changing evidence locator
uses the same repository-relative, current, identity- and digest-bound shape.
Resolve both targets at evaluation time and build one normalized admission-
evidence object from the complete record plus the resolved evidence. Derive the
route from that object. A compact decision projection is permitted only as a
checked derivative: it must equal the normalized facts and cannot override
contradictory complete evidence. Reject a missing target or pointer, absolute or
escaping path, identity/currentness/digest mismatch, missing required state or
authority field, or selected-outcome disagreement. Never derive the route from
a case state label.

Before deriving any terminal route, require the complete current open-and-closed
RXX census and the resolved current genealogy. An incomplete census or
genealogy defers the decision when no number exists and rejects any attempted
allocation. An unresolved dependency likewise selects `DEFER`; it cannot be a
presence-only field and cannot reach `NEW_RXX`.

- `NO_ACTION` when current evidence establishes no distinct gap;
- `SUPPORTING_ARTIFACT` when a bounded cross-cutting note has no runtime
  consumer and adds no owner;
- `AMEND_EXISTING_OWNER` when current evidence warrants a bounded addition to
  an existing non-RXX owner;
- `AMEND_EXISTING_RXX` when a current or closed RXX already owns the failure
  mechanism, consumer, authority boundary, and acceptance surface;
- `DEFER` when current evidence, census, genealogy, dependency state, or
  authority is insufficient; or
- `NEW_RXX` when a current, authorised, distinct unowned invariant needs its
  own work-order owner.

Apply the non-trigger/cheap path to ordinary non-RXX filing. Every conditional
outcome passes the complete current open-and-closed census and genealogy gates
before route selection. Allocate an RXX number only after the complete current open-and-closed census
and resolved genealogy select `NEW_RXX`.
Represent that proposed allocation as a typed object whose
`next_unreserved_candidate` equals the live
`identity-namespaces.json` Rockstar registry value and whose `status` is
`next-unreserved-candidate`. Reject a bare string, a different or already
allocated identity, a stale registry successor, or any other status. This is a
candidate reservation proposal, not a current Rockstar: it does not become
current until authorised publication and exact readback establish that
transition.
`NO_ACTION`, `SUPPORTING_ARTIFACT`, `AMEND_EXISTING_OWNER`,
`AMEND_EXISTING_RXX`, and `DEFER` allocate no RXX number. Supporting or
amending an existing owner never creates a duplicate owner or authority; keep
its distinct invariant and bounded allowance explicit.

## Multi-issue reconciliation

Before review/sign-off record population, examined count, enumeration source,
stable draft IDs/hashes. Dispose all `N*(N-1)/2` pairs unless a justified
equivalent grouping proves each member inherits its disposition.

Each pair records:

- same or distinct invariant;
- shared runtime, reference, template, checker, fixture, docs, package, and
  evidence owners;
- hard/soft dependency direction and file/branch/PR collision risk; and
- one decision: merge, split, narrow, cross-reference, serialise, parallelise,
  defer, or refer to an owner decision.

One invariant has one owner. Classify write/acceptance cells, serialise exact
write collisions, and reconcile disjoint parallel cells. Reuse
`plan-lifecycle.md`/#142 for independent, stacked-cumulative, or justified trains.

After pair decisions stabilise, reread all siblings; deduplicate, sharpen
boundaries/controls/dependencies, and reopen changed pairs. Record dependency,
filing, implementation, qualification, evidence-comment, and closure orders
separately; issue number is not priority.

## Publication and existing owners

This method prepares the draft set before the five authorised-publication gates
in `plan-lifecycle.md`; it does not replace their tracker census, citations,
independent review, owner sign-off, or separate readback.

- Bind a stable draft ID and hash before sign-off. After filing, backfill exact
  issue numbers and cross-links without changing substantive scope.
- A substantive post-sign-off change requires renewed sign-off. Read every
  issue back separately and compare title, body, state, milestone/labels, and
  cross-links; command success is not readback.
- Use non-closing PR links until the issue has its evidence comment, as owned
  by #141.
- For release-facing work, invoke R001D: derive and disposition README, public
  docs, generated owners, release/install states, and live readback. A generic
  "update docs" line is not a disposition. Record `R001D: applied`, or R001D not
  applicable with owner evidence for genuinely internal work. Refuse sign-off
  while any missing pair, citation, or public-surface disposition remains.
- Any new shipped checker or helper must satisfy R001E applicability,
  reachability, same-run dispatch, package, and negative-control requirements.
  Do not add a checker merely to grade prose or count sections.

Structural fixtures can prove census, dependency, identity, and authority
properties. They cannot prove issue quality or model behaviour. Where a model
cell is warranted, keep the mission free of target section names, topology,
and intended answers; use expected values, distractors, positive paraphrase,
triviality, bloat, polarity, and authority controls. Treat the output as review
evidence, not implementation authority.
