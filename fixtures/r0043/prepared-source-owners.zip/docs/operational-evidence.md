# Operational Evidence Carrier

This is a repository-only tool. Set `IMPLEMENTAUDIT_REPO_ROOT` to the exact checkout root. The compiler and byte-pinned companion live in root `scripts/`; the schema and this reference live in root `docs/`. These four files are not included in the plugin or standalone skill. Native interfaces resolve only from `skills/implementaudit/scripts/` in that same checkout and retain their source/currentness requirements; absent interfaces refuse. Repository-only distribution does not limit the original six-family contract to repository scanning or authenticate captured observations.

This reference owns the strict carrier boundary for R0038. The C02 collector itself is limited to read-only repository, Git, file, package-declaration and registry-file facts plus positive Python-AST relations. It does not collect later-cell native run/evidence/release owners, query, export, publish, schedule, mutate, refresh, watch, serve a UI, call a model, or establish authority. Native repository, Git, planning, controller, execution, evidence, failure, package, install, host, CI, release, external and public owners remain authoritative.

## Portable repository observation

An explicit source-only reader is available before native acquisition. `scan` reads one exact Git worktree and emits a deterministic repository-only snapshot to stdout. `inspect` reads that frozen file. Neither selects a controller/run, creates a native receipt, writes a snapshot directory/CURRENT pointer, or calls the native publisher. There is no automatic or default invocation. The existing native `status`, `query`, `why`, and `export` routes still derive their owner internally and accept no repository, run, epoch, receipt, or snapshot override.

```bash
python -B "$IMPLEMENTAUDIT_REPO_ROOT/scripts/operational-evidence.py" scan "$REPOSITORY" > "$TASK_OUTPUT/repository.json"
python -B "$IMPLEMENTAUDIT_REPO_ROOT/scripts/operational-evidence.py" inspect "$TASK_OUTPUT/repository.json"
python -B "$IMPLEMENTAUDIT_REPO_ROOT/scripts/operational-evidence.py" inspect "$TASK_OUTPUT/repository.json" --family CODE --max-rows 100 --max-bytes 262144
python -B "$IMPLEMENTAUDIT_REPO_ROOT/scripts/operational-evidence.py" inspect "$TASK_OUTPUT/repository.json" --format graph --max-rows 100 --max-bytes 262144
```

The caller chooses an existing isolated `TASK_OUTPUT` directory; shell redirection is caller-owned output, not atomic native publication. For canonical JSON use `inspect <file> --format json`; for retained dependency explanation use `inspect <file> --why <record-id>`. `diff <before> <after>` accepts two snapshots of the same acquisition scope. Frozen inspect/diff/render are offline and run no subprocess, target code, or model. Graph and table formats are inert JSON. Bounded views include an omitted-state census and cannot claim a complete decision when truncated.

`implementaudit-repository-snapshot-v1` and its `iarepo-v1-` identity are distinct from native `iasnap-v1-` snapshots. The input manifest binds the exact repository collection, schema bytes, compiler bytes, checked query-policy bytes and reading profile through canonical SHA-256. Checkout spelling, timestamps, duration, process identity and cache state do not enter the payload. The aggregate is always `DEGRADED`; OWNERSHIP, EXECUTION, EVIDENCE, FAILURE and RELEASE retain an explicit `UNVERIFIED` acquisition census. A matching hash authenticates no native event or source owner. Inspection reports `REPOSITORY_ONLY_UNAUTHENTICATED_FILE`; changing the scope, aggregate, population, producer grammar or hash is a typed refusal. This route cannot satisfy native C03/C06, actual receiving/JOIN, installation, release or whole-issue acceptance.

### Repository input profile

The initial profile is bounded by 4,096 tracked paths, 16 MiB per file, 128 MiB total retained input and 1 MiB per Python parser input. These refusal ceilings were selected for the observed base population (1,164 tracked paths, 68,199,991 bytes total, 13,075,398-byte largest member); they are not universal repository budgets. A whole-population/total limit refuses collection. An unreadable or oversized individual file remains a named non-current observation. A Python input beyond its parser ceiling retains exact file facts and an explicit unsupported parser observation. Supported parsing only extracts positive local AST edges and never imports or executes target configuration. Registry entry, dynamic import, unsupported language and unqualified optional-analyser claims remain bounded by the original capability contracts below.

Secret/administrative names and Git-ignored tracked files are excluded before content reads, with a visible path/reason census. Untracked files are not content inputs. Case/Unicode collisions refuse the population; nonportable path spellings, device names and alternate-stream forms are excluded. POSIX reads hold non-following directory/file descriptors, refuse hard-linked regular files, and retain only an inert leaf-symlink target observation. Parent symlinks, special files, replacement races and input drift cannot yield an outside-root CURRENT file. Windows fixed-local-drive reads acquire each child relative to its held parent handle with reparse processing disabled, hold share-read-only handles for every directory and the file, refuse reparse points (including leaf links), hard links, alternate streams and device/alias spellings, and verify the opened identity and bounded bytes. Every opened component must match its handle-derived normalized long path before content is read; actual Windows short-name aliases refuse, including aliases of excluded files or directories. Parent metadata is rechecked before return; sharing flags alone do not protect reparse metadata. UNC/device namespaces remain unsupported. Unsupported secure-handle platforms refuse direct input reads and produce PARTIAL repository capabilities. Existing Windows export tests remain platform-scoped. No POSIX result implies Windows qualification.

Git reads clear ambient Git selectors/trace configuration and use an isolated read view with bounded, nonfollowing copies of HEAD, index and refs, fixed configuration, and the source object store. Target configuration and hooks are never loaded, including configuration introduced during a command. Optional locks, replacement objects, lazy fetching, external transports, hooks and fsmonitor are disabled. Exact commit/tree/index/status and file population are re-observed through the three existing collection fences. Native artifact and frozen snapshot reads use the same bounded platform reader. Git status never recurses into submodules; a gitlink is a non-current unsupported input boundary until a separately qualified submodule collector exists. Computed Python imports retain line and column anchors, including multiple calls on one line. Frozen repository facts use the same closed scalar grammar as native snapshots; recomputing an envelope digest cannot admit invalid file facts.

### Query policy and source transition

The primary carrier loads `operational_query_policy.py` from an exact sibling, checks its byte count and SHA-256, and executes only that captured buffer. Missing, symlink/reparse/parent-alias, hard-link and changed-byte sources refuse. The successor changes the pinned pair to repair a producer/consumer mismatch: real C02 and C03 data previously passed snapshot validation while being omitted from C07 queries and C08 diffs. One shared projection now retains repository facts, capabilities and diagnostics, native frontier/route/instruction data and owner-derived hold maps. Original observations remain attached; projections create no new owner fact, relationship to a work DAG, currentness or authority. Partial record-shaped values cannot silently disappear. Empty families retain an explicit unverified census; status cannot leave an empty population COMPLETE.

The same source transition repairs the required precedence `INVALID > CONTRADICTORY > PARSER_ERROR > STALE > UNVERIFIED > UNKNOWN > UNSUPPORTED > CURRENT`. Failed external refresh preserves stronger prior invalidators and expiry state. A selected native snapshot must match the newly observed pointer, portable native owner/route/hot-source tuple, compiler/schema bytes, all four collector inputs and the complete final read fence; an internally valid old pointer is insufficient. The selected reader reuses the publisher's pure material derivation without writing output. Its additional work is measured separately from offline frozen-file inspection. A legitimate repository import cycle retains its edge in `code_cycle_relations` and terminates traversal; malformed evidence/lineage cycles still refuse. Repository topology establishes no work-DAG cycle or lifecycle fact.

### Portable validation and remaining integration

The source repo command `bash tests/operational-evidence-contract.test.sh --portable-core-only` runs the existing C01/C02/C04/C05, receiver and C08 controls. Its default scope retains all native/publication/history tests. `--query-only` additionally needs the exact R0039 owner/companion/cursor fixture. `--native-readonly-only` and the full scope need the pinned R0033/R0035/R0011/R0039 dependency closure; a disposable source fixture is not real native acquisition. The separate source repo command `bash tests/operational-evidence-portable.test.sh` holds the donor/successor regression discriminators, CLI, isolated-root, offline, boundary and pin cases.

The three changed C08 projection census expectations include the 14 CODE/native rows previously omitted; their frozen fixture now has 16 rows (12 CURRENT, one STALE, three UNSUPPORTED). The existing mid-read race hook now intercepts the secure reader after byte capture. Its mutation timing and typed refusal oracle are unchanged. The donor test source and original failures remain in the executor handoff; no expected authority/currentness answer was relaxed.

The source repo fixture `fixtures/operational-evidence/portable-consumers.json` names the six current-repo consumer questions and their repository-only scope. Public title/body membership, all-comment membership, proposed/admitted registry membership, original-property membership, implementation and qualification populations remain separate. Historical issue counts are not admission constants. Host sensors, pending authentication and actual receiving still require their authenticating owners. The explicit captured-file consumer below can preserve pending boundaries without an epoch, physical occurrence pins, member coverage and lifecycle distinctions using the established source formats. Its availability does not depend on whole sibling-issue closure. Current-only native collection never substitutes a constructed profile for missing owner authentication.

This source slice adds no UI, annotation, index, hook broker or public skill. Both the default and portable test commands are registered once in the canonical verifier, after the preserved source-pack registration. The recorded hosted attempt stopped earlier at durable-identity validation; registration does not establish that either bank ran there. Helper applicability, package capacity, installed invocation and the remaining original acceptance gates retain their separate qualification requirements.

## Captured owner-file observation

`capture <kind> <input>` reads one explicitly named UTF-8 JSON file and emits `implementaudit-captured-owner-snapshot-v1`. Its `iacapture-v1-` identity binds the exact input bytes, input kind, reading profile, compiler, companion and schema. The input text remains intact, including fields outside the projected vocabulary. `inspect` labels this scope `CAPTURED_OWNER_UNAUTHENTICATED_FILE`. A captured producer's `CURRENT`, `VERIFIED`, `SATISFIED`, accepted or authenticated labels remain observations inside the source payload. Every projected row has currentness `UNVERIFIED`, invalidator `CAPTURE_AUTHENTICATION_NOT_ESTABLISHED` and `establishes: []`. No field in a supplied file can remove this floor.

```bash
python -B "$IMPLEMENTAUDIT_REPO_ROOT/scripts/operational-evidence.py" capture pending "$TASK_INPUT/pending.json" > "$TASK_OUTPUT/pending-snapshot.json"
python -B "$IMPLEMENTAUDIT_REPO_ROOT/scripts/operational-evidence.py" inspect "$TASK_OUTPUT/pending-snapshot.json" --family EXECUTION --max-rows 100 --max-bytes 262144
python -B "$IMPLEMENTAUDIT_REPO_ROOT/scripts/operational-evidence.py" inspect "$TASK_OUTPUT/pending-snapshot.json" --format graph --max-rows 100 --max-bytes 262144
```

The same frozen query, why, diff, table and graph paths serve this scope. Record identities use kind plus stable source keys; changed source content remains visible to diff. Projected source identities retain the input SHA-256, field anchor and exact format-owner source pins. All six families remain in the snapshot; uncaptured families and incomplete source semantics have explicit omission rows. `--current-only` returns no captured rows. Bounded review status describes whether the selected output was truncated; it does not authenticate the input or satisfy an obligation. Native selected snapshots remain outside `inspect`, and `status`, `query`, `why` and `export` keep their native selection contracts.

### Available source contracts

The decoder source map pins established owner files at `fa14948894f583cc0b4e3be80e9283839c9992b5`. These pins describe the grammar implemented by the consumer. They do not adopt that donor as current main, import its executable owners, or authenticate a supplied record. Unknown schemas and structurally contradictory records refuse with a typed capture error.

| Input kind | Established input and preserved distinctions |
|---|---|
| `pending` | `implementaudit.compaction-audit-pending.v1`: full observations, versions, consumed versions, source/cutoff, assignments, reservation, return, logical JOIN and admission history. Pending means `version > consumed_version`; an absent epoch or currentness receipt does not erase the record. A second uncovered boundary remains pending after a narrower assignment or counterfactual logical JOIN. |
| `pending-decision` | `implementaudit.compaction-audit-decision.v1`: complete pending, available and assigned scope, active-child census, source problem and authority ceiling. No session binding absent from this record is invented. |
| `route` | Ordinary and recovery R0033 decision records: exact identities, scope/action/package/source, obligations, input/evidence census, lifecycle bytes, child return, governor decision, invalidators and recovery abandonment. Record self-hashes are checked as structure. |
| `route-result` | Actual R0033 result/refusal variants: route state, record identity, child delivery/return bytes, lifecycle projection and post-return currentness stay separate. A returned child or a captured SATISFIED label cannot confer JOIN or receiving authority. |
| `host-binding` | H0 binding record/state/result and host-holon-stage receipt: session/generation/activation/tombstone identities, stages and recorded refusal. No host store is queried or selected. |
| `result-occurrence` | R003A acquisition C, the existing schema-less episode value, reconciliation result and acceptance: exact original bound exchange, result/member closure, source cutoff, parent/child/obligation/scope bindings, physical path/device/inode/offset/length/hash/ordinal and optional physical-line labels. Reused call IDs or equal bytes do not replace physical identity. Correlated labels for one occurrence are retained without independent corroboration. |
| `member-coverage` | R0039 work-graph core and established auto-loom facts/projection: full cells, dependency DAG, serialization groups, preparation/predecessor bindings, supplied product declarations, ancestors, all four directions, sibling/outward/future obligations, gates, views, history and return/accepted-JOIN distinctions. The coverage input may be the actual facts object or an explicit `{facts, projection}` packing of the two existing inputs. |
| `child-visibility` | Established child-return, governor decision, execution evidence, host stage receipts and lifecycle projection: OPEN, LOAD, USE, RETURN, DISPOSE and RECONCILE remain distinct. A procedure or `ini` text is retained data and cannot become a governed role or lifecycle receipt. |
| `public-census` | R0038's explicit normalized tracker adapter: full declared issue title/body and paged comments with IDs, URLs and content hashes. Tracker membership/state, authoritative admission, original-property membership, implementation, qualification and private crosswalks remain separate. |

The public input has schema `implementaudit.public-census-input.v1`, repository `owner/repo`, `declared_members` entries `{id, number}`, normalized `issues`, and `comments` entries `{issue_number, pages}`. Each issue retains exactly `id`, `number`, `title`, `state`, `state_reason`, `body`, `comments`, `created_at`, `updated_at` and `url`. Each comment retains the REST comment object with its ID, body, timestamps, issue URL, HTML URL and API URL. Pages have at most 100 comments; all nonfinal pages are full and the final page is short. Missing pages, missing declared issues or count mismatches stay explicit while retained valid contracts remain queryable. Duplicate identities and mismatched repository/issue URLs refuse. Declared IDs are supplied inputs, never inferred from a public count.

Pending return and JOIN records check the available selected observation, scope, cutoff, return identity, acceptance and prepared-obligation bindings. Canonical digests are checked for R identities, A envelopes, fixed policies and assignment identities where their owner defines that serialization. Candidate/Q/E acquisition variants reuse the exact supplied episode value for physical and O/U/exchange/ USE/R/A checks. They never synthesize C-only environment or authentication fields. A file pin hashes exact file bytes; serializing its accompanying JSON object cannot substitute for those bytes. Missing prepared records or raw-byte custody remain explicit omissions after available local checks. Admission history and counterfactual projected pending never replace the actual pending population.

Full route lifecycles bind the exact action-to-child map and packet target. Logical task names cannot alias a governed role, host session, transaction or opaque identity. Standalone route results preserve their own available scope. Native refusal diagnostics retain bounded raw UTF-8 text, including newlines; the stricter identity-text rule does not apply to diagnostic payloads.

Work preparation checks its complete declaration, rank, record, READY group and active holders or BLOCKED unmet dependencies, complete predecessor population, observed predecessor states and local product identities, assumptions, allowed and forbidden work, invalidators and activation-revalidation fields. Supplied product declarations also receive local source-pin, classification, owner, identity, disposition, composition and future-consumer checks. These observations do not grant preparation activation or product qualification. The separate exact `product_authority_bytes` and their authenticating receipt are still required by the product owner; a graph's source pin alone does not supply them.

### Consumer limits and exact remaining boundaries

The named input ceiling is 8 MiB and the projected population ceiling is 16,384 records; the existing frozen-file inspection ceiling remains 16 MiB. The result, coverage and child decoder additionally bounds its canonical input to 2 MiB and 48 levels. Route records retain their source-specific member/embedded-byte ceilings. Result/member/O artifact pins retain the owner's 1 MiB individual bound; candidate/Q/E custody pins retain the separate 2 MiB bound. Captured result members must stay lexically under the result directory using their POSIX, Windows-drive or UNC path flavor. Those path checks perform no filesystem resolution. Inputs use the existing secure non-aliased reader; symlinks, hard links, replacement races, malformed Unicode, duplicate JSON keys and unsupported scalar types refuse. Supplied paths, refs, URLs, source strings and embedded child bytes are inert. Capture performs no native acquisition, owner-helper import, model call, target execution, network fetch, controller selection or hidden refresh. Frozen query/diff/render performs no input reads. Secure reader availability and staged export retain the documented platform limits above and below.

The available C record does not export a complete prior/retry occurrence classification. The consumer preserves its exact selected occurrence and records that omitted classification; it does not reconstruct unseen history. Supplied work preparation and product bindings are checked as described above; unknown optional product fields remain retained and unqualified. Affected-node-to-route-obligation mapping requires an established cross-owner field/identity contract not present in these pinned records. The other requested host sensor envelopes likewise need their producer format where it is absent; known pending signals and host binding/refusal records remain consumable now.

One exact shared-owner incompatibility is preserved: H0 hashes a standalone host stage receipt with ASCII-escaped canonical JSON, while R0033's resolved route receipt validator uses UTF-8 canonical JSON. Non-ASCII receipt data can therefore have different required identities. Standalone and nested receipts each follow their actual owner rule; the consumer records the mismatch and never rewrites a receipt to manufacture agreement. The shared owners must settle that boundary.

Positive constructed controls demonstrate decoding, retention, invalidation, omission and read-only query behavior. They supply no native producer authentication, canonical epoch, physical acquisition, independent observation, actual receiving/JOIN, installation, release or certification. Missing private crosswalk identities remain explicit input requests.

## Canonical record

`operational-evidence-schema.json` defines `implementaudit-operational-evidence-v1`. Every record preserves exactly one of the frozen `CODE`, `OWNERSHIP`, `EXECUTION`, `EVIDENCE`, `FAILURE`, or `RELEASE` families and binds a native owner, source identity, source layer, evidence layer, and primary currentness state. The loader rejects a source/evidence layer mismatch; a relation may connect entities from different native layers, but its own evidence leg cannot silently borrow another layer's authority.

The primary fact states are `CURRENT`, `UNKNOWN`, `UNSUPPORTED`, `STALE`, `UNVERIFIED`, `CONTRADICTORY`, `PARSER_ERROR`, and `INVALID`. A `CURRENT` record cannot retain an invalidator. A `STALE` record must name at least one invalidator. `COMPLETE` requires one required `CURRENT` entity in every frozen family. Non-complete aggregates name their affected families explicitly, so unsupported, missing, or invalid input never degrades to a silent empty result.

## Byte contracts

`canonical_json_v1` is UTF-8 without BOM, recursively sorted object keys, declared array order, no insignificant whitespace, strict JSON scalars, and no implicit Unicode or line-ending rewrite inside ordinary strings.

For immutable event identity shared with R0039, strict JSON scalars exclude floats and limit integers to signed 64-bit values. The carrier therefore emits the same no-terminal-LF `canonical_json_v1` bytes for an admissible value; only the typed source-locator path contract applies NFC normalization.

Source text payloads have one separate, explicit normalization before canonical JSON serialization:

1. replace CRLF with LF;
2. replace remaining CR with LF;
3. remove every trailing LF;
4. perform no other whitespace or Unicode normalization;
5. encode as UTF-8 without BOM and verify `payload_sha256` over those bytes.

This is the trailing-LF-removed convention used by the R0038 live-object re-anchor. A one-trailing-LF digest is not a competing content fact and is not accepted as the canonical payload digest.

The repository-only carrier is `scripts/operational-evidence.py`. `validate` returns a typed validation receipt and `canonicalize` returns the canonical record bytes. Unsupported schema versions and invalid inputs return one machine-readable `implementaudit-operational-evidence-error-v1` object on standard error with a stable error code; they never return an empty model. C01 does not register this carrier as a shipped helper or public route. That later admission remains C11's owner boundary.

## Explicit invocation and receiving boundary

`scripts/operational-evidence.py` is a **standalone-diagnostic** entrypoint under this reference's R0038 owner. It has no automatic or default invocation: the governor or operator selects a concrete evidence question, binds the verified interpreter, helper/schema bytes and input scope, then chooses an existing mode below. Merely loading this reference executes nothing. The R001E full executable-member census remains the package-wide classification owner; a reference link or a source fixture is not its installed-runtime proof.

| Existing mode | Trigger and receiver | Evidence and effect boundary |
|---|---|---|
| `validate INPUT` | Explicit request to inspect one existing canonical record | Read that file and the helper's schema; return the typed structural-validation receipt |
| `canonicalize INPUT` | Explicit request for canonical bytes of that same record | Read input/schema; return bytes on stdout; no implicit destination or native discovery |
| `diff BEFORE AFTER` | Compare two explicitly selected immutable snapshot payloads | Read both payloads; preserve additions, removals and changed facts; no `CURRENT` selection |
| `status` | Inspect an already selected snapshot in an admitted native repository context | Reacquire native currentness and `CURRENT`; missing/stale custody refuses rather than rebuilding |
| `query --family FAMILY --max-rows N --max-bytes N [--current-only]` | Answer a bounded family question about that selected snapshot | Same native receiver; preserve incomplete/nondecision state and explicit row/byte bounds |
| `why RECORD_ID` | Inspect retained explanation for a named record in that snapshot | Same native receiver; reported lineage is not a new causal conclusion |
| `export --destination DEST --owned-root OWNED [--format FORMAT] [--max-rows N --max-bytes N]` | Explicit request for a new export at a declared task-owned destination | Same native receiver plus separately scoped file effect; no overwrite, fallback, authority change or implicit refresh |

The export formats are `json`, `table` and `graph`; the existing export rules below define their bounds. For the two record modes, bind `IMPLEMENTAUDIT_REPO_ROOT` to the selected repository checkout and `RECORD` to the chosen input file. `python` below denotes the verified interpreter, not a fallback selected after a failed prerequisite.

<!-- operational-evidence-explicit-record-commands:start -->
```bash
python -B "$IMPLEMENTAUDIT_REPO_ROOT/scripts/operational-evidence.py" validate "$RECORD"
python -B "$IMPLEMENTAUDIT_REPO_ROOT/scripts/operational-evidence.py" canonicalize "$RECORD"
```
<!-- operational-evidence-explicit-record-commands:end -->

Structural validation is not currentness, truth, admission, readiness, acceptance, release or closure. An optional diagnostic that was not requested creates no missing automatic-enforcement claim. An unsupported native context does not fall back to another repository, run or installed home.

There is no `build` or `refresh` CLI command. The existing internal `publish_current_snapshot()` producer is the separate C06 output writer: its selected owner and effect authority must be bound before a library call. The producer calls `_collect_snapshot_inputs_v1()`, which invokes the existing repository, evidence/failure and release collectors, while the producer calls `collect_native_current()` and the current snapshot reader holds its source-owned native observation through materialization. These library relationships do not automatically run from a reference load or a record validation. `query_history_v1()` and `run_external_readonly()` also remain their documented library interfaces; a CLI name, hidden refresh or new external authority must not be inferred for either. Native-context, snapshot publication, installed invocation and full R001E census qualification retain their own receiving gates.

## Bounded repository and static collection

`collect_repository` uses fixed, read-only local Git commands to bind the exact commit, tree, worktree state and tracked input-file-set digest. Every call disables system/global configuration, environment-supplied helpers, repository fsmonitor, hooks, credential/SSH helpers, external diff and ext transports; it never executes target-configured Git helpers. It hashes working-tree bytes without following tracked symlinks. An exact pre/post fence compares commit, tree, tracked-path population, status bytes, file type/length and every file or symlink-target hash; any mid-scan change is a typed refusal and no mixed `CURRENT` snapshot is returned. The same exact fence runs again after bounded AST/package processing, immediately before facts can be returned, so a change after the second file read is also refused. The complete result is sorted, canonicalized and decoded into its return object before a third and truly final physical fence. After that bound observation the prebuilt object is returned directly: no later sorting, digest, parsing, filesystem, Git or callback-capable work occurs. `CURRENT` is stable at that observation boundary; a later physical change is an explicit invalidator, not a continuous-state guarantee. Every readable tracked file stays an exact file fact; an unreadable or missing tracked path produces a non-empty `STALE` observation and degrades the file capability to `PARTIAL`. Known package JSON contributes only present, positively declared shared roots. The shell validation registry remains an exact file/hash fact; C02 does not parse shell or infer registry entries.

Python collection uses the standard-library AST only. It never imports a target module. A resolved local static import may produce a positive import and reverse-dependent fact bound to the Python implementation/version, stdlib AST module digest, fixed invocation/output schema, parser, input path and input digest. Computed imports stay `UNKNOWN`; syntax/UTF-8 failures remain non-empty `PARSER_ERROR` observations; imports outside the declared local module map stay typed `UNSUPPORTED` observations rather than missing edges; unsupported languages remain file facts. Source edges and cycles never become work dependencies, work-DAG cycles, `READY`, `JOIN`, deletion or obligation-omission decisions.

`normalize_static_receipt` accepts only the versioned, data-only, offline `implementaudit-static-receipt-v1` envelope. It binds collector/version/package, invocation/output schema, parser/config/trust, target commit/tree/worktree, input-set, scope completeness, diagnostics, polarity and currentness into every normalized fact together with the native repository owner and a fixed read-only structural-fact authority ceiling. No target-code execution, auto-install or network mode is admitted; no such effects are performed. Absence facts require a complete supported scope; physical changes or named invalidators invalidate `CURRENT`, and `STALE` must name its invalidator. Unsupported, missing-tool, crash/timeout and parser-error outcomes synthesize typed non-empty observations. C02 has no independent/native qualification owner or trust anchor. Therefore an external receipt can never obtain `CURRENT` from a caller-issued qualification, even when its caller-generated digest and positive/negative/unsupported/ parser-error/repeatability results are internally consistent. Every requested external `CURRENT` is refused as `OE_STATIC_QUALIFICATION_REQUIRED` until a separately governed later owner exists. Non-current external receipts require qualification absence; a caller-supplied qualification is untrusted data, not authority, and cannot be promoted by C02. A non-current envelope also demotes any caller-declared `CURRENT` fact to the envelope's non-current state. `normalize_static_receipts` requires one exact target snapshot, retains overlapping provenance separately and marks opposing edge/absence claims `CONTRADICTORY` instead of merging them.

C02 refuses every caller-supplied work-node mapping and never creates one. Governed mapping envelopes and their native-owner joins belong to their later owner; no current C02 output may be consumed directly by R0035. The normalizer never invokes R0035. The APIs are C02 substrate, not CLI commands, default preflight, helper registration, package admission, or a public route; those remain in their assigned downstream cells.

## Native-current controller facts

`collect_native_current()` is the C03 no-argument, read-only boundary. It derives the repository, bound run root, sole controller, claim and fixed `STATE.md`, `ROADMAP.md` and `WORK_GRAPH.json` paths from native Git/controller custody. It accepts no caller controller, claim, run, epoch, receipt, route, graph, source root, snapshot root or alternate path. The returned `implementaudit-native-current-facts-v1` record has the `READ_ONLY_NATIVE_CURRENT_FACT` ceiling and an empty `establishes` population.

The reader requires one exact canonical current generation pointer/receipt v3 join plus the permanent migration marker's immutable genesis join. It binds both joins to the same controller/claim/run, validates the marker's original generation pointer and receipt independently, and binds the current source epoch, pointer and manifest identities, hot STATE/ROADMAP digests, `WORK_GRAPH.json` path/digest, next action and predecessor receipt. It invokes the canonical read-only R0011 currentness validator from exact captured bytes. Qualified readonly helper pairs use bounded, literal-quoted stdin transport; other sources retain the private byte-bound materialization. The child loads both already-read `claim-run.sh` and `validate-run-root.sh` payloads, verifies their exact SHA-256 identities, and executes only those loaded bytes; the completed child reports the same exact identity pair. Its inherited environment is an exact platform/Git allowlist, with Python safe-path/user-site hardening and no inherited Python loader or module override. The mutable source paths are never invoked after observation, and both source identities stay in the final file fence. The stdin route creates no materialized helper files. The file route removes only its two exact materialized members and directory; cleanup refusal names the exact residue and requires manual reconciliation, never blind deletion. R0011 validates every typed field of the immediate v2/v3 predecessor and its exact `G(n-1)` relation, and checks the bounded structural `G(n-2)@OID` token without reading older history. The current R0033 route ref must contain exact canonical record bytes and agree with the owner-native pure R0033 predicate over native controller, claim, run, continuity, retained host-dependency identity, boundary, next-action, scope, action, evidence, observed current inputs, package, child-source, expiry, classification, history and lifecycle facts. The pure predicate independently reacquires current controller/continuity custody and finally fences the exact controller-ref/route-ref identity pair. It performs no live R003A store lookup, attributes no current host event or effect, and emits no host/session identity; a tombstoned authoring session therefore does not invalidate an otherwise current read-only route fact. A self-hash alone does not make a route record current. Missing, duplicate, malformed, unknown, contradictory, stale or foreign facts are typed refusals; a legacy v1/v2 receipt is not promoted to the C03 fact record.

ACTIVE, READY, blocked summaries and declared writer/resource holds come only
from the canonical HC-H4 `compile_frontier_projection` implementation. The
reader executes the already-read compiler bytes, reports their digest and
fences the same path after execution and again before return; path re-import
cannot substitute different projection bytes. Adjacent STATE narrative cannot
override that projection. STATE contributes only its bounded current epoch,
explicit open-Andon population, active instruction rows and exact next action;
the pointer and receipt must bind the same hot bytes and values. The physical
file/ref fence includes the predecessor and route refs plus the compiler and
both R0011/R0033 validator-source identities. After that fence, the reader runs
the complete canonical R0033 semantic predicate again as its final target-
sensitive observation and requires the same route identity. That owner recheck,
not a locally enumerated subset, re-observes request inputs, executing-package
sources, audit-state child source, the whole-worktree population and relevant
Git metadata, reacquires current controller custody and ends with the exact
route/controller ref-pair fence before the prebuilt deterministic fact object
is returned. It
does not invoke lifecycle helpers, mint or change refs, repair state, set
READY/JOIN, create a snapshot or output root, query history, use network, or
inspect an ActiveGraph mirror. C06 remains the sole later snapshot
compiler/publication owner.

## Native route and affected-node projection

The no-override native collector emits `implementaudit-native-current-facts-v3`,
retaining the v2 route projection and adding the selected accepted episode.
It retains the exact canonical WORK_GRAPH text and obtains the current obligation,
transaction and scope through R0033's `read_current_route_scope_v1`. The selected
R0035 peer derives the complete node population, direct scope, dependent and
ancestor sets, independent nodes and uncovered scopes. R0038 validates that
relation against the canonical graph and current controller/claim/receipt tuple;
it does not author a route fact or infer satisfaction from a caller's graph field.
The R0033 semantic predicate and the complete relation are reacquired at the
final native fence. Dynamic route identities remain a derivative of the current
graph; they are not written into the currentness receipt's source preimage.

Queries distinguish the persisted `DeclaredWorkGraphFrontier` from
`GovernedWorkNode` and `RouteAffectedNodes` observations. Dependency, parent,
route-obligation and uncovered-scope edges remain explicit. A changed satisfaction
affects the owner's scoped nodes while an independent node keeps its own input
identity. Each uncovered scope remains an `UNVERIFIED` capability and omission;
one satisfied scope cannot clear another boundary.

The selected peers live under source repo `source-peers/route-graph/`, outside
the normal plugin and standalone payloads. Native execution requires an exact
source-checkout composition at the canonical same-checkout owner paths. Merely
copying these sources establishes no native source/profile admission. Historical
peers lacking both new interfaces retain an explicit
`NATIVE_ROUTE_NODE_MAPPING_UNAVAILABLE` omission; a partially supplied pair
refuses. Legacy native-facts v1 bytes remain unchanged and receive that omission
at query time. Frozen v2 readers execute only the fixed, byte-bound pure R0035
validator against retained canonical bytes; they perform no subprocess, network,
model, native acquisition or publication.

Read-only native observation keeps one actual current-controller acquisition
at each end of the enclosing R0033 owner scope, with complete route semantics
derived again before closing. The standalone pure validator keeps its own pair.
For the exact pinned R0011 helper pair, R0035 avoids the second verification
only after the immutable returned receipt proves the LF-exact 18-field v3
domain shared by `require` and `verify`. Legacy TSV-pointer receipts, malformed
or unavailable receipt bytes, and unknown helper bytes retain both calls.
This is source equivalence, not cached currentness or a caller-supplied token.

The repository-only R0011 peer also exposes `--observe-current-continuity`.
It selects the same unique controller and executes the existing full `require`
branch, emitting its controller/repository/run/claim tuple and receipt only on
success. R0035 uses that one actual owner call only for the exact qualified
helper pair, at both ends of the observation. Other sources retain the two-call
route, and non-equivalent receipt domains still require separate verification.
The original helper commands and their output domains remain available.

The selected snapshot reader keeps materialization inside that live native
scope and returns no payload until the owner closes successfully. An invocation-
local, single-worker C02 read may overlap C03 after the actual repository/claim
custody is bound. Its root cannot change, all work is joined on success or
refusal, and no result or proof is cached across invocations. It then
rechecks compiler/schema bytes, fresh repository and external inputs, and
CURRENT. Publication retains its separate full native fences. Windows C02 uses
a bounded transaction-local directory-handle pool; names are retained only
through strongly held ancestry. Weaker access retains fresh canonical-name
checks. Every leaf and parent reparse check remains fresh; all three physical
repository fences and deterministic handle cleanup remain required.

Windows leaf buffers are bounded by the observed file size plus one growth
sentinel byte, within the existing ceiling; size, identity, EOF and parent
checks still close each read. Snapshot input reobservation reads optional
collectors before one final fresh repository fence, including when RELEASE is
unavailable. It retains C02's three internal fences and an immutable baseline;
standalone RELEASE collection keeps its own original fence.

The source-reporting native observation additionally exposes the exact claim
and validation helper digests used by its two loaded-byte R0011 checks. C03 can
reuse those actual checks only when both match its own captured helper bytes
and the observation closes unchanged. Its receipt/marker/predecessor, route,
input and final file/ref checks remain. Historical or separate owners keep
C03's original direct check. These source observations do not authenticate
native actor records, create caller credentials or replace receiving/JOIN.

The repository composition retains the complete R0035 compiler adopted at
`87a7ea09`, including its product-authority refusals, with the existing R0038
hardened input readers. Continuity uses host-only primitives without loading
the optional route producer. A scoped route still requires that producer's
exact source and policy; a no-scope run retains the original optional behavior.
The secure readers require this same checkout's pinned root operational reader,
query policy and continuity-helper closure. General installed R0035 support is
not established by this repository-only composition. A native observation must
come from identical compiler bytes at the canonical and frozen-peer paths;
captures from another compiler version remain subject to exact source refusal.

Declared and recursively selected graph inputs pass the repository owner's
secret/administrative-name policy before content reads. A Git-backed input root
also checks each selected path against its isolated Git ignore policy, including
ignored tracked files. A denied member refuses the scope rather than silently
removing an input. Frozen route validation binds the declared run beneath the
exact claimed relative run to the graph's platform-specific input-root digest.
Explanations keep dependency and containment edges typed: a mixed traversal
revisit is retained in `context_cycle_relations`; dependency-only, containment-only
and ordinary causal-lineage cycles still refuse.

## Immutable current snapshot publication

The v3 native fact record obtains an accepted nonprotected episode only from
the existing pending owner's no-argument `acquire_selected_episode_export_v1`.
Both runtime producer and pure observation validator must exactly match the
fixed public source-peer bytes. The owner selects its private policy and
canonical route/H0/pending pointers; a caller cannot choose an authentication
profile or supply an accepted flag. A missing capability or unbound/unaccepted
episode is an explicit UNVERIFIED observation. Bound malformed or stale evidence
refuses. The episode's current route, host, controller, claim, run, continuity,
obligation, transaction and source pins must agree with the other native owners.

The frozen record preserves original C/Q/E, physical source ranges, member
locators and selected original/prior/retry classifications. Query/why/diff use
only the source-bound pure validator; no private selection lookup, native RPC,
subprocess, model or source refresh occurs. Results, separate acceptance,
consumed JOIN, source terminal release and H0 stage receipts remain separate
records. Missing H0 receipts remain UNVERIFIED even when an accepted episode is
available. Unproved pending boundaries retain their noncurrent state. Historical
v1/v2 native facts gain a query-time missing-episode census without rewriting
their frozen bytes. Captured-owner inputs keep their existing UNVERIFIED floor.

`publish_current_snapshot()` is the C06 no-argument producer. It accepts no repository, run root, output root, controller, claim, branch, pointer, receipt, epoch, snapshot ID, manifest, locator or digest. The carrier derives the sole controller and bound run from `collect_native_current()`, then derives the only effect root as `<bound-run-root>/operational-evidence/snapshots`. Its receipt is an R0038 output-root observation with an empty `establishes` population; it creates no controller, route, currentness, lifecycle, release or closure authority.

One writer lock in the carrier's native Git common custody is held before the first native-current observation and remains held through final `CURRENT` and immutable-member readback. While holding it, C06 calls the accepted C02-C05 collectors. C02 repository collection is required. A typed absent C04 or C05 owner artifact becomes an explicit `UNKNOWN` collector row and a `DEGRADED` missing/omitted-state entry rather than a fabricated empty or current fact. Malformed, stale-custody or contradictory owner input remains invalid and refuses publication rather than being laundered through that absence path. Repository diagnostics and every C05 candidate invalidator are also retained in that census. An invalid required native/repository input refuses publication before an output directory is created; `INVALID` never advances `CURRENT`.

The compiler binds exact compiler and schema bytes, the portable native-current semantic record, controller/claim/run/source epoch/current pointer, hot STATE, ROADMAP and WORK_GRAPH digests, canonical R0033 route identity and every collector result/digest in `implementaudit-operational-snapshot-input.v1`. Absolute checkout, Git-common, run-root, temporary-directory, clock and process spellings are excluded from semantic bytes; their native custody is preserved by the bound controller, claim, run and current tuple. Immediately before any output effect the carrier rereads compiler/schema, reacquires the complete C03 result, reruns every collector and requires exact equality. It separately requires the old `CURRENT` bytes to remain unchanged through that fence.

Native payload v2 carries the exact input manifest and the original eight-field `IA-OPERATIONAL-SNAPSHOT-v1` identity record. The ID is `iasnap-v1-<sha256(canonical identity-record bytes)>`; the record binds semantic payload, canonical input manifest, schema, compiler contract and compiler bytes. The frozen reader recomputes all bindings from the validated collection population. Older v1 payloads retain their historical identities but are refused by this stronger reader; only recompilation from entitled inputs produces v2. This content binding grants no native authentication. A snapshot directory contains canonical no-terminal-LF `input-manifest.json`, `snapshot.json` and `manifest.json`. The first two carry the deterministic input and full complete-or-degraded projection. The R39-frozen owner manifest has exactly:

```text
schema_version controller_id claim_id run_id source_epoch
source_pointer_oid source_evidence_entries
```

Each unique source entry is `iasrc-v1-r0038-snapshot-<snapshot-digest>[-label]`, binds the exact `snapshot.json` digest and uses the fixed run-root-relative locator beneath the same immutable snapshot directory. An existing same-identity directory is reused only after exact population and byte readback; it is never overwritten. A create-once temporary directory is verified before rename. Private temporary cleanup removes only the three exact task-owned members and refuses unknown or link/reparse residue.

`CURRENT` is canonical no-terminal-LF JSON with exactly `schema_version`, `snapshot_id`, `manifest_sha256` and `source_pointer_oid`. Before replacement, C06 rechecks the prior selection. It writes a durable temporary sibling and uses atomic replacement last. Post-selection readback verifies `CURRENT`, its manifest, the complete source-entry population and every selected source digest. A failure before replacement leaves the old complete selection or no selection; an interruption after replacement is reported as `OE_SNAPSHOT_PUBLICATION_UNKNOWN_EFFECT`, and the new selection must still be independently read back before retry. An unselected immutable directory is residue, not discovery authority: readers follow only valid canonical `CURRENT`. Stored snapshot identities remain immutable and can be reread after a later selection without creating new R0039 archives.

## Ordinary accepted result and receiving projection

The separate `implementaudit.ordinary-episode-export.v1` contract covers a genuinely required ordinary `audit-assess` route. Its selected native acquisition uses Windows host and held-file custody; the pure frozen contract remains portable. Its source owner selects the canonical R0033 OPEN, RETURNED and SATISFIED lineage, the actual fresh child and its complete result members, the distinct governor decision and the consuming receiver/JOIN. It does not synthesize a compaction, pending assignment or covered-boundary population. Existing compaction acquisition and export retain their own contracts.

Metadata-header acquisition maps at most the existing bounded prefix and copies/parses only its first LF-terminated line. Empty, oversized and malformed headers still refuse; parsing remains inside the held-file lifetime and every closing custody check remains. The exact known child resolver may run its own byte-bound checks in process with module-local output capture. It rereads its source and every layout; unknown versions retain their original subprocess path. Neither change supplies authentication or qualification by itself.

Ordinary acquisition requires a prospectively frozen, explicitly selected source policy. It fences exact provider, configuration, interpreter and owner-source bytes, derives the current executing host instance through its ancestry, and authenticates selected public records through bounded native reads. The public source keeps `ORDINARY_SELECTION_PIN` unbound; copying source is not admission. A changed configuration or missing/contradictory source refuses instead of adopting current bytes implicitly.

The selection fixes the other helper and skill hashes before their import. The mission also binds the resulting complete policy, including the active source owner's identity, before public-record acquisition or receiver execution. Result members and later evidence slots use held-file custody and bounded reads; preliminary pathname reads cannot precede those guards.

The source owner's explicit `--ordinary-execute` operation delegates to R0033's `execute_current_ordinary_receiver_v2`. That owner first snapshots the policy as bounded canonical JSON; digest validation and subsequent bootstrap/effect reads use the same private value, independent of later caller mutation. It holds one namespace lease across the existing-receipt check, fixed held-interpreter `--ordinary-receiver` execution, capture, input fences and expected-absence publication. It loads the exact prospective policy's owner code from immutable Git blobs and held matching worktree files. The v2 receipt binds the observed process outcome to the accepted route, opening, policy, result and acceptance. The retired caller-supplied execution-result API refuses; v1 process receipts cannot receive current credit. Existing v2 receipts remain unchanged without replay. Raw tool-output JSON and a model final answer cannot supply the process exit. The ordinary export reader remains read-only; its frozen validator performs no native acquisition, network or effect.

The producer publishes an immutable attempt marker immediately before invoking the fixed receiver. A missing completed receipt after that marker requires effect reconciliation and cannot trigger another run. A failed process result is retained as a result, not promoted to success; interruption or changed inputs preserves the attempt without a successful receipt. Receipt absence proves no accepted execution evidence, not that no effect occurred.

R0035 can select this one receiver when R0033 supplies its current fixed-executor binding. The binding carries the exact accepted canonical record and prospective policy, with the two bootstrap sources pinned by that record's inputs. Source acquisition checks immutable Git bytes and held matching files; it neither runs the receiver nor publishes a receipt. The selected task must name the policy's receiver, the receipt writer resource and its distinct JOIN, and must belong to the affected route scope. Authorization, dependencies, currentness, capacity and other conflict checks still apply. Other mutation and external tasks retain `EFFECT_EXECUTOR_UNAVAILABLE`. A frozen binding supports consistency checks only; it grants no execution, native lifecycle, receiving or acceptance authority.

Typed ordinary public JSON permits the native commentary carrier's single terminal LF after the closing fence. Parsing preserves the original body, native body hash and physical locator bytes. Additional trailing whitespace, extra blank lines, prose outside the fence and duplicate JSON keys remain refusals.

R0038 projects result, acceptance, receiving, physical custody and occurrences separately, and requires the acceptance digest to match the canonical satisfied-route receipt. Formal H0 LOAD/USE/DISPOSE remain UNVERIFIED in ordinary v1. The query census retains that limitation; ordinary receiving grants no pending-compaction consumption, parent completion, campaign authority or issue closure.

The C03 read can hold the fixed R0035 owner observation open through its own
read-only consumption. R0035 retains its source, input, continuity and R0033
semantic checks on both sides; C03 corroborates the exact current identity and
rechecks its own refs and bytes after owner closure. Historical peers retain the
full separate reads. No serialized capture supplies this live observation.
For a canonical route selecting an unrelated role, the ordinary source adapter
may return only an unavailable observation with null canonical facts; it does
not prove currentness or absence of a route obligation. Applicable ordinary
reviews retain the full current reader.

When the accepted fixed ordinary receiver is present, the source owners may
observe its authenticated episode inside that same live graph/route read.
Only the fixed owners derive the canonical opening, execution receipt and
current graph; the public entry accepts no supplied episode or trusted view.
The provider remains held through use. Exit rereads the native catalog,
parent/child metadata and all four selected public records in one bounded
read-only API process, then checks physical records, H0, policy, receiving
artifacts and member custody. The enclosing graph and route owners close their
fresh input/currentness fences afterward. Unavailable and historical paths
retain their full separate acquisitions. The route view refuses new reads
after closure; returned bytes are accepted only after every exit check passes.
Frozen inspection still performs no acquisition.

The combined read also shares R0035's actual fixed-byte R0011 acquisitions
with its fixed R0033 producer. The original receipt parser still derives the
complete current tuple; after route semantics are rechecked, the fixed closing
continuation reacquires actual continuity before final refs, execution receipts
and source checks. No public entry accepts a currentness result or callback.
Standalone owners retain their own reads. Opening public records share one
bounded native API process while each record keeps its exact body, retained
identity, physical-source and post-read checks.

For a composed read of a completed ordinary episode, the fixed owner reads the receiving locator
from its bound document before batching all four O/R/A/J public reads. The JOIN
body gains no credit until execution, graph/result, artifact and final source
checks succeed. Header parsing stays inside one held leaf/ancestor lifetime;
its closing guard still precedes delivery. Each C03 ref fence obtains the exact
named refs in one fresh Git read, retaining both fence locations and all missing,
changed or malformed-ref refusals. No ancestry check or byte pin is omitted.
The standalone episode path retains its separate JOIN read after graph validation.

Within one repository publication/read transaction, a private live capture may
reuse bounded AST and repository semantics only after fresh physical bytes,
Git state, exclusion census and collector/runtime provenance agree. Each
original C02 collection retains its three terminal fences. Caller-provided
collections still require independent live derivation; no cross-transaction
cache or caller trust flag is admitted. These source mechanisms do not by
themselves establish the native publication or currentness budgets.

## Deterministic read-only status, query and why

`status`, `query` and `why` are C07 readers. They accept no repository, run root, snapshot root, controller, claim, pointer, manifest locator or other caller-supplied authority path. The CLI derives the bound run through the C03 native-current reader, follows only the validated snapshot `CURRENT`, and returns canonical JSON under the `READ_ONLY_OBSERVATION` authority ceiling with an empty `establishes` population. These commands do not publish a snapshot, change `CURRENT`, mint route/currentness/lifecycle authority, inspect an ActiveGraph mirror, use network or invoke a model.

`evaluate_currentness()` reports a separate state census for each of the six frozen families and retains the snapshot's explicit missing-or-omitted-state population. `query_family()` orders records by stable logical identity, retains native owner/source identity and exact invalidators, and may filter to `CURRENT` only when it also reports the omitted-state census. Non-current facts are observations, never normalized to success. `explain_history_why_v1()` follows only retained relation endpoints in deterministic order, retains declared contrary evidence, reports a missing identity as `UNKNOWN`, and refuses a reachable cycle rather than inventing a cause.

`query_history_v1()` accepts at least one non-empty normalized filter plus finite positive row and byte bounds. Its history authority is only the verified current R0027 generation manifest and that manifest's digest-linked predecessor chain. Manifest metadata is used to avoid hydrating unrelated immutable segments; every referenced segment is checked against its digest, canonical event identity, generation, controller and run before it is returned. The exact HC-H2B `implementaudit.history-query-request.v1` form is accepted only for one canonical `iaevt-v1-<64-lowercase-hex>` identity and is normalized to an exact event-ID filter. Executing that read does not satisfy, clear or promote the R0033 route obligation.

Rows use canonical sequence/event order. Results state the requested position, observed coverage, row and byte bounds, truncation and next cursor. Cursor payloads bind query contract, current generation, current manifest, normalized filter digest and exact requested position. Their SHA-256 suffix is an integrity checksum, not authentication. A cursor-selected page is always nondecision; only an untruncated first page from filter start is decision-usable. Any row- or byte-bound overflow returns `OE_QUERY_REQUIRES_BOUNDED_REVIEW` and cannot support a negative, absence, closure or route-satisfaction conclusion. Validation registration, helper reachability and package admission remain C11 work.

## Canonical snapshot diff and explicit export

`diff_snapshots()` compares two already materialized immutable payloads without selecting or changing `CURRENT`. It validates the exact payload schema, snapshot identity, six-family population, input-manifest digest, state vocabulary and unique record identities before comparison. Records are compared by stable `record:<id>` identity, never source-array order. Additions, removals and before/after changes are separate canonical arrays; aggregate, family, missing-or-omitted-state and input-manifest changes remain explicit. The receipt names both snapshot and manifest identities and has the `READ_ONLY_OBSERVATION` authority ceiling with an empty `establishes` array.

`export_snapshot()` writes only a new file beneath a caller-explicit absolute owned root outside repository and run authority. The owned root and every destination parent must already be regular, non-link directories; cwd-relative, outside-root, reparse/alias and existing destinations refuse before mutation. Creation uses exclusive/no-follow semantics and verifies the new regular file. No fallback, overwrite, newest-run discovery or derived destination exists.

On supported fixed Windows volumes, export holds the complete parent chain and creates the stage relative to its held parent with reparse processing disabled. On volumes supporting hard links, a protected owner-only descriptor is applied at creation and independently read back from the live object. It denies ordinary attribute, permission and owner changes, including native hard-link creation; the original creation handle retains the write and cleanup rights needed for the transaction. Publication uses a basename-only native sibling rename with replacement forbidden. Bytes, size, one-link identity, parent custody and publication security are checked before and after publication. The resulting export is immutable to ordinary in-place writes; its owner can read and delete it. This does not change any existing file or directory permissions. Unsupported capabilities, including the POSIX staged-export path, remain explicit refusals. Source/fixture controls of this transaction do not establish native input authentication or receiving acceptance.

Canonical JSON export is exactly `canonical_json_v1(snapshot)` and cannot be truncated. `table` and `graph` are inert canonical-JSON projections rather than executable markup or graph directives. They require finite positive row and byte bounds, order non-current facts before `CURRENT`, and always expose the complete state census, included/omitted counts, omitted-state census and missing-or-omitted-state population. A truncated projection reports `OE_EXPORT_REQUIRES_BOUNDED_REVIEW` and is nondecision. Diff/export uses only the Python standard library; it invokes no target content, subprocess, network, model, plugin, sidecar, database, index or ActiveGraph surface.

## Canonical evidence and failure collection

`collect_evidence_failure` is the C04 read-only boundary. It accepts one fixed, regular, bounded canonical run artifact named `operational-evidence.json`; it does not scan or interpret STATE, ROADMAP, transcripts, reports, logs or nearby prose. The strict `implementaudit-run-evidence-v1` input binds the run/artifact identity and exact artifact SHA-256, then retains separate Claim, Criterion, Evidence, Check and Review records across `ATTEMPT`, `RECEIPT`, `EFFECT`, `RECOVERY` and `CLOSURE` legs. Receipt is distinct from attempt; either may be a proxy, but neither can become effect, recovery or closure. Producer/check success, a green proxy and a nonverdict review remain observations in their declared legs; none establishes effect, recovery, PASS or closure.

The same canonical artifact retains Andon, Residual, Containment, Countermeasure, Rerun and Recovery records as immutable FAILURE lineage. When a non-proxy RED exists, the collector validates and preserves the earliest RED and a declared non-proxy RED weakest leg. A population with no RED uses JSON `null` for `first_red_id` and returns `first_red_state: NOT_APPLICABLE`; it does not fabricate a RED and may retain a non-proxy green weakest observation. Contrary evidence, open residual identities, cause confidence and direct recovery evidence remain exact. Any FAILURE row that declares `recovery_state: OBSERVED`, regardless of its record type, requires current, non-proxy GREEN `RECOVERY` evidence. Recovery does not erase the Andon, first RED, contrary evidence or residual. An unknown cause remains `UNKNOWN`; C04 does not guess it or create finite retry, strike-count or stopping semantics.

Every collected row has the `READ_ONLY_NATIVE_ARTIFACT_FACT` authority ceiling, and the collection's `establishes` population is always empty. The collector never edits evidence, infers closure, invokes a model, executes target content, uses network or reads a noncanonical fallback. It builds canonical output before checking the final path type and performing a byte-for-byte source reread as the last target-sensitive operation. It directly returns the prebuilt object when the bytes remain exact; a changed artifact is refused rather than returned as mixed evidence. Later snapshot compilation/query/publication and native closure decisions remain in their assigned downstream owners.

## Local and frozen external RELEASE collection

`collect_release` is the C05 read-only RELEASE boundary. It reuses the hardened local repository collector for exact commit, tree and worktree observations, then reads only two fixed tracked owner artifacts: `release-local.json` and `external-capture.json`. The local manifest binds generated artifact, package, install and host records to exact working-tree paths and SHA-256 bytes. The frozen capture retains separate PullRequest, Check, Merge, Tag, Release, Asset and PublicSurface records with stable IDs, commit identity, update time, ETag, payload digest, native owner and currentness. Every emitted node remains a `READ_ONLY_NATIVE_OBSERVATION`; the collection's `establishes` population is empty.

Authentication absence, rate exhaustion, incomplete pagination, object drift and capture expiry remain explicit invalidators. They conservatively demote the external population to `UNVERIFIED`, `UNKNOWN` or `STALE`; they never become an empty or successful external layer. Calendar-valid timestamps must satisfy `captured_at < expires_at` and `evaluated_at >= captured_at`; equality at the expiry boundary is stale. Native object currentness and capture-boundary currentness are retained separately and composed without deleting either set of invalidators. Missing required RELEASE types are represented as typed `UNKNOWN` omissions and `MISSING_RELEASE_LAYER:<type>` candidate invalidators, including missing Asset or Install facts. A public predecessor whose commit differs from local HEAD keeps the candidate `UNVERIFIED`. Even an exact match requires later native candidate qualification and cannot establish merge, release, publication, PASS or closure in C05. Local/frozen artifacts are fingerprinted through the repository collector before and after compilation; changed local bytes or a mixed scan are refused rather than normalized away.

The explicit GET capture preserves the consumed `X-RateLimit-Reset` header as `response.rate_reset_at`, a UTC timestamp, so a receiving C05 artifact can bind the observed reset time. A missing header produces JSON null; the receiver must retain that missing input instead of inventing a time. Duplicate, malformed, negative or out-of-calendar-range reset values refuse. This field does not refresh the capture or grant any additional authority.

`run_external_readonly` is the explicit refresh boundary, not a frozen query. It accepts one exact data-only request with no method field, maps a small fixed operation/path allowlist to one GitHub API `GET`, supplies fixed accept/version headers and uses its internal concrete GET-only client. It exposes no POST, PUT, PATCH, DELETE, GraphQL, shell, credential-discovery, pagination loop, retry or file-write verb. Native authentication derives from an explicit `authorization_token` supplied only to the fixed transport; caller `auth_state` does not establish authentication. The token never enters the capture and cannot be passed to an injected transport. Redirects refuse, response bodies are bounded, and operation-specific repository/object identity is checked before a response may be CURRENT. Missing credentials, rejected authentication and wrong objects remain explicit noncurrent results. A caller-injected transport is explicitly untrusted: it can exercise response parsing but cannot substantiate GET/no-write or `CURRENT`. Case-insensitive collisions among consumed ETag, rate and pagination headers, and negative rate-remaining values, are refused. Unconsumed native HTTP metadata supplies no identity or currentness fact. The returned in-memory capture records status, ETag, response digest, rate, pagination, auth declaration, drift, expiry and semantic digest under the `READ_ONLY_EXTERNAL_CAPTURE` ceiling and an empty `establishes` population. The frozen collector never invokes this runner, a model or network. Query, status and explanation apply present-time expiry to copied result rows, retaining observed currentness and the immutable payload and identity. Expired external rows remain visible as STALE in ordinary queries and are excluded from current-only queries; no query refreshes or extends capture validity. Refresh scheduling, cache publication, query, package admission, registry/helper routing and public release actions remain with C06-C14 owners.
