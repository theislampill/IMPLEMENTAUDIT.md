# Next independently executable DG17 case

Prepare P10's missing same-case actor judgment. Root received the actual recurrence, single prevention and34/34 finished-payload follow-up atb834300c6f031f148da3cb10739394c43083f65c on2e72a912136607e464e953c71fc8e2b44d047d92. The lost private actor input is not recreated. This fresh neutral prompt exposes retained observations and exact source; the earlier answer-bearing lesson and Root decision remain evaluator-only.

Ten direct source bodies match accepted2e72 and current540 byte-for-byte. This permits bounded dependency applicability, not a new540 archive/host/whole-program award. The historical follow-up remains on its exact subject and archive.

Four separate fresh contexts cover factual main, positive paraphrase with context/authority distractors, combined trivial/no-payoff/bloat, and evidence polarity. All missions and oracle freeze before dispatch. Root must independently receive/select this packet, appoint actors and evaluator, then decide acceptance. No original award is supplied here.

Self-critique: historical raw stdout is not newly acquired, so accepted source records are the factual basis; shared filesystem instructions do not prove physical isolation; hidden model revision/config and unavailable traces remain unknown. These limits must survive receiving.

No actor/provider/native operation, grant, commit, push, test replay, issue write or source mutation was performed. P08 stays accepted at its existing scope. NativeT12/T13 remain distinct from ordinary hosted checks.
