### Model-facing controls

If any case uses model cognition, its mission must be independent of the target
headings, loop labels, topology answer and expected disposition. The fixture
must declare expected values, plausible distractors, forbidden mission phrases,
positive paraphrase, triviality, bloat, polarity, authority and context/no-
payoff controls. Exact prompts, model/version/configuration, evaluator identity,
input/output digests, retries/non-verdicts and common dependencies must be
recorded. A model result is review evidence, never source/currentness/mutation/
PASS/closure authority.
