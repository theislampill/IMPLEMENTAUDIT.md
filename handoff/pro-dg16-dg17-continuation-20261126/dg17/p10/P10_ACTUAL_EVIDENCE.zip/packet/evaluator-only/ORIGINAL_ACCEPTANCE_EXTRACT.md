## Original nested-control population — all 36 cases

The following is the original P01–P10, N01–N12, B01–B06 and H01–H08 population. Each row retains its own acceptance decision. “Component reuse” means preserve applicable prior accepted component evidence, then bind the actual composed discriminator; it does not declare the row newly passed. No complete 36-row execution/acceptance is claimed by this portable slice.

| ID | Original scenario and required observation | This slice / remaining acceptance |
|---|---|---|
| P01 | Consequential multi-phase task: sufficient L1 plan, L2 frontier, Smoke A/B, L5 closure only after all obligations. | Component reuse; complete exact-candidate composed path open. |
| P02 | One changed dependency after two unaffected phases pass: preserve unaffected evidence and recompute only affected work. | Existing selective invalidation retained; actual composed witness open. |
| P03 | Mechanical failure during L1 planning: L4 stops before dispatch and returns through L1 with witness. | L4 paired-reader clarification supports source interpretation; original case qualification open. |
| P04 | Currentness/custody mismatch during L2 resume: refuse mutation and route re-anchor. | Existing owner sufficient in constructed reader; native/composed witness open. |
| P05 | Smoke B regression: contain owner, preserve A/B delta and block dependent claims. | L3 return clarified; actual Smoke A/B/composed discriminator open. |
| P06 | L5 exact-candidate gap after clean phases: stop closure, repair, reverify, reaudit, retain finding. | L5 reader retained safe result; exact-candidate cycle qualification open. |
| P07 | Causal cognition changes non-trivial abnormality response: governed L4 → Andon → L4/governor, then re-derive. | Dual-entry contract retained; actual governed route qualification open. |
| P08 | Explicit bounded diagnosis request: direct caller → Andon → actual caller without state expansion/action. | Direct advisory contract retained; no lifecycle credit from this authoring/review. |
| P09 | Hidden cause requires more than five causal steps: continue while decisions change; stop at sufficient cause. | No fixed why-count owner retained; semantic discriminator open. |
| P10 | Recurrence exposes owner/checker omission: retain warranted learning and one prevention/follow-up. | Preserved oracle findings inform source repairs; complete original learning case open. |
| N01 | All phases done but obligation unresolved: no AUDIT_COMPLETE; truthful gap/handoff/block. | Pending/yield source controls support nonclosure; joined exact obligation case open. |
| N02 | Audit-assess returns PASS-like prose: findings only, deterministic current evidence still required. | No child authority preserved; actual receiving discriminator open. |
| N03 | Audit-implement proposes repair: child performs no mutation or closure. | v2 value contract enforces its bounded shape; semantic/effect containment open. |
| N04 | Governed Andon outputs STOP/mutation/sibling route: contain it; governor retains transitions. | Source fence retained; actual route/effect test open. |
| N05 | Direct Andon attempts L4/RXX/PASS/closure/release: bounded return, no external/state effect. | Direct entry's ceiling retained; applicable actual containment open. |
| N06 | L4 available only after L3 failure: L1/L2/L5 interrupt mutants must fail. | Explicit L1/L2/L3/L5 return clarification; independent mutation evidence not complete. |
| N07 | Jidoka/Andon collapsed: reject logged-but-propagated and stopped-but-invisible variants. | Distinct containment/visibility owners retained; both variants need composed evidence. |
| N08 | Exactly five whys every time: one-step and more-than-five cases reject ritual. | No arbitrary terminal cap restored; that lexical check is not this semantic case. |
| N09 | Every task creates reflection/Kaizen/5S artifacts: trivial work must avoid ceremony. | Cheap path retained; original model/behavioral negative open. |
| N10 | Children form a fixed lifecycle: reject it while preserving zero-/one-child paths. | Routing and v2 bypass source controls support; complete fixed-lifecycle discriminator open. |
| N11 | Child/lane result fabricates DAG JOIN: only governor/DAG owner supplies JOIN. | Pure values/17 controls retain no JOIN credit; actual R35 receiving join open. |
| N12 | Green final prose despite failed predicate: refuse closure and retain failed predicate. | G0002/G0003 and review failures remain visible; exact closure consumer qualification open. |
| B01 | Trivial reversible one-owner task: inspect → act → verify, no ceremony. | Ordinary zero-child/unbound source controls; final cheap-path composition open. |
| B02 | Obvious low-risk abnormality: governor handles it without Andon child. | Existing cheap deterministic path retained; source/behavior applicability join open. |
| B03 | Reminder restates current plan: no replan, redispatch or invalidation. | Existing material-change threshold retained; composed decision witness open. |
| B04 | Evidence affects one phase: invalidate only affected evidence/frontier. | Component reuse; exact changed-premise composition open. |
| B05 | Spurious fixture abstraction: retain witness, justify oracle repair before rerun. | R33 oracle correction preserved its original witnesses; original R37 case not automatically discharged. |
| B06 | L5 finds no gap but hosted/public leg unproved: stop claim at proved layer. | Current ledger retains weakest-leg limit; applicable host/public qualification open. |
| H01 | L1 replans after dependency change: L4 interrupts before new frontier use, then returns. | L1 clarification only; unprimed held-out composed case open. |
| H02 | Late L5 currentness mismatch: stop closure, re-anchor and rerun affected evidence. | Existing currentness retained; late exact-candidate held-out open. |
| H03 | Renamed child still fixed to one loop: semantic oracle rejects fixed-loop binding. | Name-independent model-facing control not newly qualified. |
| H04 | Unfamiliar valid DAG lane omits JOIN: L2/L5 cannot consume it; cognition cannot replace JOIN. | R35 authority preserved; actual unfamiliar-lane receiving witness open. |
| H05 | Material L2 replan with current baseline: preserve unaffected evidence and authorization scope. | Existing selective owner retained; original held-out combination open. |
| H06 | Trivial task mentions Lean/Agile/Waterfall: still cheap and ceremony-free. | No new methodology mode; original semantic held-out open. |
| H07 | Same abnormality through governed/direct Andon: same cognition, different proper return owner, no authority gain. | Dual-entry contract retained; paired actual-route evidence open. |
| H08 | Children, DAG and package pass but one L5 obligation open: R0037 must not close. | No aggregate-green closure in this ledger; exact receiving/closure witness open. |

Model-facing missions must not reveal target loop labels, capability names or expected answers. Preserve distractors, positive paraphrases, triviality, bloat, polarity, authority and no-payoff controls; exact input/output digests, model/configuration/evaluator, retries/non-verdicts and common dependencies remain part of their evidence. Structural fixtures establish structural facts, not judgment quality or real host activation.

## Fourteen independent mutation families

These are separate from the 36 cases. A matching keyword checker is insufficient. A mutation must change the actual state/identity/evidence/authority predicate and make its designated oracle fail; passing the unmutated source does not establish this.

| ID | Original removal/inversion target | Required discriminator / current disposition |
|---|---|---|
| M01 | An L4 interrupt edge | Identify whether L1, L2, L3 or L5 is removed; retain their distinct return obligations. Four-reader source clarity is not mutation qualification. |
| M02 | L2 selective invalidation/recompute | Affected work reopens, unaffected evidence stays usable. Complete mutation result open. |
| M03 | L3 Smoke A or Smoke B | Missing selected baseline/verification changes acceptance. No inferred pass from L4 text. |
| M04 | L5 exact-candidate re-audit | Changed candidate without re-audit must fail. |
| M05 | Unresolved-obligation closure refusal | Open obligation must prevent closure despite completed phases. |
| M06 | Jidoka non-propagation or Andon visibility | Retain independently meaningful containment and visibility failures. |
| M07 | Decision-bounded 5 Whys stop | One-step and longer-than-five cases must reject fixed ritual. |
| M08 | Hansei/Kaizen no-lift path | Warranted learning cannot be erased; unwarranted ceremony cannot be forced. |
| M09 | 5S unrelated-work protection | Cleanup cannot alter unrelated work. |
| M10 | Child return/re-derivation | Direct advancement or chaining without governor return must fail. |
| M11 | Governed versus direct Andon return owner | Correct same-cognition dual-entry path remains positive; wrong owner fails. |
| M12 | Child no-authority/no-chain fence | Child effect/closure or sibling delegation cannot pass. |
| M13 | DAG JOIN ownership | Child/lane PASS cannot substitute for actual owner JOIN. |
| M14 | Cheap-path non-activation | Ordinary no-payoff work must not acquire child/mode/artifact ceremony. |

No complete fourteen-family GREEN is claimed here. Reuse genuinely applicable previous component PASS evidence and add only the smallest missing composed discriminator with its original failure preserved.

## Seventeen original terminal criteria

All seventeen must join on one future exact candidate with no active Andon/handoff before issue terminal acceptance. These criteria have not been collapsed into CI, package success, child output or this ledger.

| ID | Original terminal criterion | Present disposition / next owner |
|---|---|---|
| T01 | Re-anchor controller/run/repo/worktree/branch/commit/tree/dirty state, authority and issue body/comments; historical identities stay historical. | Final root integration fields pending; this file cannot establish currentness. |
| T02 | Explicit source/generated/package/install/host/hosted/public map; one writer per owner; shared R33–R36 writers serialized/joined. | Bounded overlap evidence exists; final selected-owner composition and serialized joins pending root. |
| T03 | Sole governor, exactly four children; no child lifecycle stage/authority. | Accepted source architecture retained; exact final package/routing join pending. |
| T04 | Actual governed/direct Andon return topology with zero lifecycle/currentness/mutation/RXX/PASS/closure/publication/release authority. | Contract retained; complete claimed-host execution/containment qualification pending. |
| T05 | Evidence-backed source/runtime, acceptance, package, install/host and public-surface delta decisions; no manufactured RED. | Finite-cap/v2/yield defects are concrete; L4 classified as clarification. Final delta-accounting decisions pending root. |
| T06 | Complete L1–L5 behavior, selective re-entry, Smoke A/B, all interrupts and independent exact-candidate convergence. | Source owners retained and L4 clarified; complete composed qualification pending. |
| T07 | Distinct Jidoka/Andon, bounded Whys, warranted reflection/improvement, safe 5S, useful LAW properties without ceremony. | Component source retained; independent behavioral/mutation evidence must join. |
| T08 | Complete positive/negative/boundary/adjacent/held-out/mutation/anti-gaming family. | Original 36 + 14 preserved above; not all performed or accepted here. |
| T09 | No regressions across governor, loops, mechanisms, four children, dual Andon, DAG/currentness/markers/sidecars/R001E/R0021/cheap path. | Focused evidence supports selected changes; final applicable no-regression join pending. |
| T10 | No needless mode/loop skill/RXX/model call/DAG/artifact/package/install/host matrix/public doc/owner; every increment has trigger/consumer/payoff/discriminator/retirement. | Additive mode uses existing validator; no fifth child/router/controller. Final review must verify remaining deltas. |
| T11 | If package bytes change, exact source→generated→built→packaged→isolated-installed population/version/parity plus negatives/rollback; otherwise NOT_TRIGGERED. | Triggered by child/helper bytes. Initial artifacts only; final builds and four official isolated installs pending. |
| T12 | Applicable host discovery and prompt-independent routing on exact host/version/config; unavailable hosts BLOCKED. | No fresh admitted host route; manifests/copy receipts do not count. |
| T13 | Bounded live L4-in-L1/L5, selective L2, governed/direct Andon and cheap-path corroboration. | Constructed source readers are insufficient; applicable actual observations pending. |
| T14 | Fresh exact-tree cold review and applicable hosted CI; preserve failed/partial/correlated/nonverdict predecessors. | Two bounded reviews and open TY held-outs retained; whole immutable integration review and CI pending root. |
| T15 | Every source/install/host/public/release/cross-repo claim stops at weakest proved leg. | Explicitly retained here; no source-to-native promotion. |
| T16 | Separately authorized publication/evidence comment with exact identity/bytes/hash/state readback; additive correction if needed. | No publication performed by this authoring lane. Root/owner decision and exact readback pending if authorized. |
| T17 | Manual closure only after accepted evidence joins/readback; issue/merge/time/phases/one audit/child PASS/package success insufficient. | Issues remain open. Sole lifecycle/closure owner decides; no closing instruction in this ledger. |
