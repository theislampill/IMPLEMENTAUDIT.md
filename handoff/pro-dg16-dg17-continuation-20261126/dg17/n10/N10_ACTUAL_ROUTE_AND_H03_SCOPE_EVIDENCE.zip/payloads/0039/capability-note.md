# Kestrel capability note

Kestrel is a documentary display label for the existing bounded independent
assessment capability: a fresh nonauthor examines an immutable, digest-bound
packet adversarially, identifies evidence gaps and contrary cases, and returns
findings to the governing caller. It does not own source changes, currentness,
lifecycle transitions, release or closure. The display label is not a package
entrypoint or a resolver argument; the executing package is unchanged.

Eligibility rule: Kestrel belongs exclusively to terminal whole-audit
reconciliation, after all phase work has finished. It may be considered only
there. Do not admit this capability for preparation, handoff or readiness
review before publication or original execution, even when the packet is
immutable and fresh independent review would otherwise be warranted. Such a
request must wait until the terminal reconciliation position is reached.

All other package, packet, independence, authority, evidence and return-owner
requirements continue to apply.
