# H03 original-owner mapping and prospective episode

**UNISSUED — target unbound; no actor-ready or behavioral claim.** The original
owners support a small admission episode. The real upcoming current-entry
source-review need is suitable conditionally, once Root supplies its actual
sealed target and current admission facts. No target directory, substantive
source, report or archive has been inspected here. The pending template contains
null identities and cannot be used as an issued binding.

## Original requirement and owner mapping

| Owner | Literal obligation or source behavior | Consequence for this design |
|---|---|---|
| Original issue #211, line 579 | Renamed child still fixed to one loop; semantic trigger/owner oracle rejects fixed-loop binding | An unfamiliar name alone is not the discriminator. |
| Issue lines 160, 527, 616–619 | Four children are cross-loop capabilities; behavior derives from state, identity, evidence and authority | Preserve canonical ownership and actual admission facts; expose a semantic position restriction. |
| a297 acceptance line 210 | Name-independent model-facing control not newly qualified | Retain that open boundary; this preparation supplies no replacement result. |
| a297 governor lines 95–104, 116–117, 129–131 | Exact executing package, immutable packet, proved independence, authority and return to governor | The assessment trigger is not an exclusive terminal-loop assignment. |
| Original assessment contract lines 12–35, 37–48 | Bounded adversarial packet review, complete actual envelope, findings-only return | Its role remains recognizable under a documentary label; its genuine gates are preserved. |
| Plan-lifecycle lines 171–191, 490–494 | Independent review occurs before preflight/handoff and publication | A universal terminal-only restriction conflicts with an existing source-owned review use. Formal review/attestation requirements are not presumed satisfied. |
| Original resolver lines 89–91, 117–132 | Exact canonical names, package population and layout | An unknown-name or incomplete-package error is structural evidence, not semantic H03 proof. |

`reviewer-private/OWNER_MAPPING.json` binds these exact clauses by file hashes,
line selections and a297 Git blobs. The original issue body remains SHA-256
`ca62f4899a45544549f623a0312c16121bb99f432ccb87a87b7361974ceb94c4`.
The acceptance file was compared directly with its a297 Git object and remains
`eed53023153b5b505ad562ace0979dc3b8dab7aeb3660b0c1905c216c6d9b4a9`.
The prior H03 frontier row is retained as historical scope, not replayed or
re-awarded. N10 is not renamed as H03.

## Smallest proposed episode

A fresh actor consumes the unchanged original governor policy and considers
admission of Root's genuine independent source review before publication or
original execution. The actor actually reads a **Kestrel capability note**.
Kestrel is explicitly a documentary name for bounded independent assessment of
an immutable packet, returning findings to the governor. It is not a new skill,
entrypoint or resolver argument. The note then makes that capability exclusive
to terminal whole-audit reconciliation and excludes earlier preparation,
handoff or readiness review even when other gates hold.

The executing a297 package retains all five original skills and all 81 source
files. No source is renamed, removed or mutated. The actor's mission contains
no H03 label, expected mapping, loop label, desired disposition or forced child
count. The restriction is carried in the actual scenario input and must be
observed in the actor's complete read output.

The private semantic oracle requires applying the capability's actual trigger
and return owner to the bound live need. Refusing only the unfamiliar label,
missing package, absent target digest or unavailable independence does not
establish H03. A genuine missing gate may still block a formal route after the
unsupported position restriction has been identified. Neither unconditional
child activation nor blanket child refusal is prescribed. Do not invent a live
loop assignment or boundary to make the contrast work; insufficient current
facts remain a specific gap.

The initial mission stops at admission. It cannot read or perform the target's
substantive review, load child role bodies, run a resolver, reserve identity or
dispatch a reviewer. A later actual continuation may perform the one canonical
substantive review if warranted and released. A legitimate direct fresh review
uses zero formal children; a formal route requires all actual gates. An inert
identity reservation is not a review. No duplicate full review or fixed future
itinerary is created for the experiment.

H03 remains one held-out case. The wider cross-loop matrix and fourteen separate
mutation families keep their own obligations. The packet adds no compulsory
second arm, extra paraphrase episode or mutation kill. All original model-control
categories are declared in `reviewer-private/ORACLE_AND_CONTROLS.json`, with actual
prompt/model/evaluator/I-O/failure/dependency evidence still required later.

## Exact source and pending target

The source commit is `a297957be11feb494c0ec467235794a1e0c54751`, tree
`b08dc4ecf4028beeedb579a312eccae23cb5d863`. The complete immutable source-layout
is reused by reference, including all 70 skills files, without copying the
source bodies again. Its inventory SHA-256 is
`a1ec91bf4eb3677346ca2ca0c165a128981a6238202bf5512bf56bcd1922daa8`.
Missing or changed referenced source blocks staging; an installed substitute
does not satisfy the binding.

There are four frozen neutral input files. Future authorized staging would add
the 81 source members, their exact inventory and an actual issued target binding,
for 87 initial regular files. That neutral execution root has not been created.
The target's archive hash/size, report/result/seal identities, candidate identity,
author exclusions, actual requested review scope, current business state,
authority/read boundary, independence/host facts and review-consumption state
remain pending. Root must issue them as genuine facts before any actor. The
local preparation seal is not a G132 target seal or a route envelope.

Any formal continuation preserves the corrected sequence: genuine inert fresh
identity reservation and acknowledgement; immutable envelope with actual
identity/fork/currentness/authority/independence facts; separately bound actual
resolver success; then same-context role release and substantive review.
Unknown provider facts stay unknown. Source admission is never replaced by
these prepared fields, and Python is not a model-side host interface.

## Verification, failures and remaining gates

Eight bounded source/data checks passed, with no source-check failure. They
verified the complete source population/bytes/Git blobs/modes, original owners,
prior seals, neutral mission declarations, explicit renamed restriction, model
controls and unissued target. No selected-source resolver, runtime, actor,
child, checker, target review or hosted/protected/external operation occurred.

One discovery search output was truncated and the necessary owner section was
subsequently read in full. The first console summary mistakenly displayed three
neutral files by subtracting a directory count; an actual regular-file census
corrected it to four before sealing. No manifest or actor consumed the wrong
summary. Both are preserved in `SOURCE_VERIFICATION.json`; no behavioral trial
is reconstructed or rerun. N09/N10 seals remain exact and untouched.

The author is `/root/recovered_dg17_receiving`, not an independent reviewer of
this protocol. The developer-exposed model label is GPT-6 Astra Pro; authenticated
serving revision and provider timestamps are unavailable. Root supplied actual
G0004 currentness (`dbe58d`, exit 0); this child neither operated nor independently
claimed to verify Root's controller.

Next: fresh nonauthor prospective review of this exact source design; actual
final target binding and current fact verification; Root's explicit admission
release; then genuine observation and independent receiving. Material design
changes require a preserved successor. Root alone owns any H03 award, later
substantive review release, publication or original execution. Current result:
**source prepared, target unbound, zero behavior observed**.
