# Next independently executable original case: N10's valid child route

**Select a genuine, still-unconsumed independent review need and use the original exact-source governor route if its gates select that route.** N10 has a concrete, native-independent missing limb. Do not repeat its accepted itinerary rejection or zero-child correction, do not replay H03, and do not append a retrospective marker to the old review. Root selects the business need, actor, operation and separate receiving; this document is preparation only.

## Why the original predicate fits this environment

Original issue211 line568 requires: **“Children encoded as fixed lifecycle | Hidden lifecycle fails; zero-child and one-child paths remain valid | Cross-loop neutrality.”** The original N10 oracle's declared layer is exact-source governor decisions and genuine ordinary host effects. Its `not_claimed` list expressly excludes **native installed activation** and **native Stop/session**. Its actual one-child requirement is a fresh nonauthor dispatch, bounded result and return to the governor, under all original gates. It expressly allows a legitimate direct review, leaving the one-child observation unproved rather than forcing another review.

The original receiving explicitly says an honest retention of actual submitted messages and exposed results, with unavailable fields marked unavailable, is sufficient at this local evidence layer; it demands no provider-authenticated full-context export. The model-control file similarly permits unavailable revision/seed/timestamps to remain explicit. These are original episode declarations, not a newly relaxed successor standard.

Exact originals are at commit `40c4aeb3ac25923c0f9ce63123c2a25f0abafa0e`:

- `handoff/pro-executor-results-20261115/continuing-execution-20261118-09/dg17-n10-prospective-v2.tar.gz.part001`–`part003`; concatenated archive SHA-256 `61334e07430020d1d434e35df22f6b3d9ced58dc2a1187cf8f66a41bf3dbb504`.
- Within it, `ordinary-work-prospective-v2/reviewer-private/ORACLE.json` and `MODEL_CONTROLS.json`. Exact local copies are in `retained/n10/`.
- Checkpoint11 `DG17_N10_ACTUAL_RECEIVING.tar.gz`, report `dg17-n10-actual-receiving/REPORT.md`.
- Checkpoint11 `root-checkpoint11-G0006-G0007.zip`, member `root/ROOT_N10_ORIGINAL_ADJUDICATION_G0006.json`; local copy `retained/root/ROOT_N10_ORIGINAL_ADJUDICATION_G0006.json`, SHA-256 `7e49b716449ecbe49fa82478b1d28f942a2d62a9a3f76823eb1babc113db77f4`.

## Preserve the actual old outcome

Root G0006 received the task-specific rejection of the fixed four-role itinerary, useful zero-child notice repair, one genuine bounded assessment, and governor return/re-derivation. The late exact visible-message retrieval resolved N10-R01 at its stated layer. N10-R02 remained a **supported omission**: the actual post-load announcement lacked `CHILD_SKILL_ROUTE=audit-assess`. Root left the complete valid one-child conjunction and original whole N10 unawarded. It did not find that the fixed itinerary was followed.

The missing line is an authentic product requirement, not an invented native prerequisite. Source540 `references/transcript-contract.md`388–406 requires both the literal route marker and human announcement **after** the exact package gate, resolver and actual child load. Source words, a reserved actor, a proposed load or an after-the-fact marker do not satisfy it.

## Available real review subject

The newly prepared `ADJUDICATION_NOTE.md` plus its exact retained evidence is an available, unconsumed independent review subject: Root has a live decision about what the original H03 contract actually requires and whether the historical broader capture qualification should affect present original-row accounting. That is a source/evidence interpretation review, not another H03 admission experiment. The author's recommendation is data to challenge, never an expected finding.

Its immutable evidence manifest is `RETAINED_MANIFEST.json`, SHA-256 `9642a6625eded49a2002a30714a4f2461284b436a557f52ac57baf47446ebdc4`; note SHA-256 `4e4362da4aba66de090ace9dbd721b85ba60d08bbb5f543d4e05a8212942ab24`. Author context `/root/dg17_actual_preparation` must be excluded. Root may instead select a different genuinely pending immutable review, such as a newly prepared operator, if the H03 decision/review need is consumed. **Do not manufacture a second review simply to obtain this route.** No selected target, actor identity or release is issued by this proposal.

## Smallest concrete successor sequence

1. **Root selects the live need and scope.** Freeze its exact bytes, claims, read boundary, dispositions, authors/context exclusions, authority ceiling and return owner. Record actual source/config/tool limits. Preserve the old N10 disposition as historical; identify this as a new business review supporting only the currently missing limb. If the need is already consumed, stop this proposal without another review.
2. **Root applies the original route gates.** Bind the exact operating source and complete package, precedence, audit object, currentness where applicable, and fresh nonauthor independence. Use the known full source540 snapshot or an equivalently verified exact source layout. The installed remote skill bodies are different bytes and cannot silently stand in for source540. Root controller continuity is caller custody, not native product acceptance.
3. **Allocate one fresh review context if the route is actually selected.** If its identity is needed before envelope issuance, reserve it inertly and record that reservation separately from load. Do not expose the N10 oracle, accepted/desired route, author context, or other reviewer output. A functional review request may state its actual bounded operating role after admission; that is not a mandatory population itinerary. A legitimate direct alternative stays legitimate and yields no one-child claim.
4. **Verify and execute the exact source resolver.** From the selected complete layout, the candidate command is `python /workspace/scratch/cca101c63aff/v03-current-cold-review/exact-source-540/skills/implementaudit/scripts/resolve-internal-skill.py --governor /workspace/scratch/cca101c63aff/v03-current-cold-review/exact-source-540/skills/implementaudit/SKILL.md --child audit-assess`. Record the actual arguments, result and returned path. This proposal has not run the resolver or granted load authority.
5. **Release the bounded review only after all gates.** The fresh actor reads the exact resolved role bytes. After that actual load, before substantive review, preserve both required visible lines. Preserve actual messages/results at each stage; do not rely on a long-lived in-memory recorder. Exposed backend/model fields remain honest, including UNKNOWN where necessary.
6. **Receive actual bounded findings in the same governor.** Root verifies the exact return and independently re-derives live target/source/authority facts before any next transition. PASS-shaped prose grants no readiness, mutation, acceptance or closure. Preserve adverse findings, transport failures and incomplete evidence; no outcome-driven replay.
7. **Separate independent receiving.** A nonauthor receiver checks actual gates, load timing, both announcement lines, fresh-context facts, immutable inputs/return, effect scope and actual governor re-derivation. It compares the new limb with the already accepted historical components and identifies subject/parity limits. Root decides whether that union satisfies original N10. No automatic whole N10/T4/T12/T13 award follows.

This is a bounded route proposal, not an issued operation. Final exact actor messages, actual identity-bound envelope, Root's preflight/grant and independent receiving assignment remain prerequisites. No new actor was launched by this preparation.

## Source data already verified

`N10_SOURCE_DATA_READBACK.json` (SHA-256 `98e0fb77dec2e6683a6970b7069ded8fcd692126792a41933f87d3b52e946398`) compares all 70 skills-subtree files and the package contract in the full540 snapshot against immutable Git blobs: 71/71 byte matches, exact five skill names, no mismatched member. This is data preparation, not an actual package-admission/resolver/load receipt or lock against future mutation. Root must recheck the executing selection at use time.

The old semantic owner bodies for audit-assess, plan-lifecycle, child-agents and transcript-contract remain byte-identical from a297 to540. The inspected governor diff leaves the relevant routing clauses unchanged. Any join of old accepted components with the new current review must disclose the distinct episodes and subjects, not pretend the missing old announcement happened.

## P03 alternative

P03's literal predicate is a failed mechanical check during planning, interruption before dispatch, preserved witness and return through planning. It is also not inherently Windows/native. However, later unissued Op M notes refer to seven private variants and authenticated provider provenance; those are not surviving executable inputs here and are not a universal original requirement. A future P03 operation must bind a real planning input/check and its working polarity control, actually observe the failed check and governed return, and use a separately frozen neutral evaluator. A pure helper printing an interrupt label, a retrospective label for an unrelated failure, or a mission that forbids dispatch in both arms is insufficient. N10's genuine next review is the more concrete available gap; no P03 actor or replacement private fixture is prepared here.
