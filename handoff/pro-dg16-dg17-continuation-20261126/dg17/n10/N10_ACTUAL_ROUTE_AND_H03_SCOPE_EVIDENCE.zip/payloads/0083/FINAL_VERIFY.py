from pathlib import Path
import json,hashlib,datetime
root=Path('/workspace/scratch/ac0b432d8253/dg17-n10-live-review-01')
out=root/'reviewer'
def sha(data): return hashlib.sha256(data).hexdigest()
checks=[]
def check(name,ok,detail=None):
 checks.append({'name':name,'ok':bool(ok),'detail':detail})
 if not ok: raise RuntimeError(name+': '+str(detail))
env_bytes=(root/'ENVELOPE.json').read_bytes();env=json.loads(env_bytes)
in_bytes=(root/'INPUTS.json').read_bytes();inputs=json.loads(in_bytes)
check('final_envelope_digest',sha(env_bytes)=='ef7df29c554925e3f6042e03d49fada8794195ea893357b65ce7b670c6fc3d36')
check('final_inputs_digest',sha(in_bytes)=='84c20475e15161dd1bfce7b5ebb3308b18e7afded8b6e7434b193a2876f78427')
for entry in inputs['files']:
 p=Path(entry['path']);data=p.read_bytes();check('unchanged_input:'+str(p),len(data)==entry['bytes'] and sha(data)==entry['sha256'] and str(p) in env['allowed_reads'])
refs=json.loads((out/'EVIDENCE_REFERENCES.json').read_text())
for ref in refs['references']:
 check('reference_digest:'+ref['id'],str(ref['path']) in env['allowed_reads'] and sha(Path(ref['path']).read_bytes())==ref['sha256'])
result=json.loads((out/'RESULT.json').read_text());att=json.loads((out/'REVIEWER_ATTESTATION.json').read_text());report=(out/'REPORT.md').read_text();archives=json.loads((out/'ARCHIVE_VERIFICATION.json').read_text())
check('result_final_bounded_pass',result['report_state']=='FINAL' and result['disposition']=='PASS' and result['authority']=='NONE' and result['original_case_award'] is None)
check('all_three_claims_present',len(result['claims'])==3 and all(c['disposition']=='PASS' and c['citations'] and c['reasoning'] for c in result['claims']))
check('historical_nonaward_preserved',result['historical_statuses_preserved']['whole_original_H03_awarded'] is False and result['historical_statuses_preserved']['complete_historical_evidence_qualification']=='NONVERDICT' and result['historical_statuses_preserved']['C09']=='ADVERSE')
check('fresh_nonauthor_attestation',att['authoring_context_reuse'] is False and att['packet_author'] is False and att['prior_authoring_conversation_inherited'] is False and att['other_current_reviewer_outputs_inspected'] is False)
check('unknown_identity_preserved',att['actual_model']=='UNKNOWN' and att['model_pair_equality_established'] is False and att['stage_6_i_readiness_attestation_established'] is False)
check('report_final_and_terminal', 'Report state: FINAL' in report and report.rstrip().endswith('\nPASS'))
check('independent_archive_data_checks',archives['all_selected_archive_counterparts_equal'] and archives['all_source_parity_hashes_match'])
check('historical_source_semantics_bound',all(e['full_bytes_equal'] for e in archives['source_comparisons'][1:]) and archives['source_comparisons'][0]['governor_routing_section_equal'])
check('note_and_prompt_bytes',archives['cross_bindings']['projected_note_exact'] and archives['cross_bindings']['assignment_is_prompt_plus_two_lf'])
summary={'schema':'h03.scope-review.final-verification.v1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_checks_pass':True,'checks':checks,'count':len(checks),'record_scope':'Fresh local byte/structure verification, not native/provider attestation or historical behavior replay.'}
(out/'FINAL_VERIFICATION.json').write_text(json.dumps(summary,indent=2)+'\n')
with (out/'action-record.jsonl').open('a') as f:
 f.write(json.dumps({'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'action':'Final byte and report-scope verification before manifest sealing','actual_command':['python3',str(out/'FINAL_VERIFY.py')],'script_sha256':sha((out/'FINAL_VERIFY.py').read_bytes()),'result':{'all_checks_pass':True,'check_count':len(checks),'verification_file':'FINAL_VERIFICATION.json'},'record_scope':'Record stops before its own manifest sealing/readback. Exact outer harness envelopes and final returned tool output are not asserted to be a complete local trace. Prior inline Python command fields denote effective operations, not exact outer shell wrapper bytes.'})+'\n')
files=['REPORT.md','RESULT.json','REVIEWER_ATTESTATION.json','ADMISSION_CHECK.json','EVIDENCE_REFERENCES.json','INPUT_VERIFICATION.json','ARCHIVE_VERIFICATION.json','FINAL_VERIFICATION.json','FINAL_VERIFY.py','action-record.jsonl']
manifest={'schema':'h03.scope-review.output-manifest.v1','report_state':'FINAL','created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/h03_scope_review','envelope_sha256':sha(env_bytes),'packet_sha256':sha(in_bytes),'authority':'NONE','self_exclusion':'MANIFEST.json excludes its own bytes to avoid recursive hashing. Final manifest/readback tool result is returned separately.','files':[]}
for name in files:
 p=out/name;data=p.read_bytes();manifest['files'].append({'path':str(p),'bytes':len(data),'sha256':sha(data)})
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
readback=json.loads((out/'MANIFEST.json').read_text())
for entry in readback['files']:
 data=Path(entry['path']).read_bytes()
 if len(data)!=entry['bytes'] or sha(data)!=entry['sha256']:raise RuntimeError('Manifest readback mismatch: '+entry['path'])
print(json.dumps({'status':'FINAL_VERIFIED','check_count':len(checks),'manifest_entries':len(readback['files']),'manifest_sha256':sha((out/'MANIFEST.json').read_bytes()),'report_sha256':sha((out/'REPORT.md').read_bytes()),'result_sha256':sha((out/'RESULT.json').read_bytes()),'disposition':'PASS','original_case_award':None,'authority':'NONE'},indent=2))
