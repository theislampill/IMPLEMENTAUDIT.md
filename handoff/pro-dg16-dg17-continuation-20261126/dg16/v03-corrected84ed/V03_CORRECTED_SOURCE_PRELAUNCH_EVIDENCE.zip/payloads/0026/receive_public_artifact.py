#!/usr/bin/env python3
"""Receive V03 public evidence without issuing review, consumption, or acceptance.

All ZIP data remains in memory. Only a new evidence receipt in this lane is
written. Current source's actual codec, manifest, pair-summary and public-proof
consumers are used. Private raw captures are neither fetched nor inferred.
"""
import argparse
import hashlib
import sys
sys.dont_write_bytecode = True
import bind_final as bound
import json
import re
import stat
import time
import zipfile
from pathlib import Path

sys.dont_write_bytecode = True
OWN = Path(__file__).resolve().parent.parent
OPERATOR = bound.OPERATOR
SOURCE = '84ed2972d370f6c34100d48657f0c96a570e0b49'
SOURCE_TREE = '53ad93aa1a94c324340f2de7ee2ba272c74fc57e'
TREE = None  # Set only after exact final-object binding verification.
BRANCH = 'engineering/pro-dg16-v03-current84ed-20261126-02'
REPOSITORY = 'theislampill/IMPLEMENTAUDIT.md'
POLICY = '8563d116a17ffeb526c5a8fe107e738bca6ec167c8649f7b2f6f7ff281f38b20'
ADOPTION = None  # Derived from actual final Git decision bytes, never a draft.
INPUTS = 'ce71206318a76872cb27f118e219445d56c7e60a995747fa7ff654caacf37ca7'
FULL = '74814dce70f28830db620c34b7932dbfb55412e1fceb74e240c523aa75f5502b'
PUBLIC = ('RESULT.json', 'HOST.json', 'SOURCE.json', 'PROBE.json', 'CLEANUP.json', 'FAILURE.json', 'ARTIFACT_MANIFEST.json')
NO_AWARDS = ('G1', 'G3', 'C5', 'full_G2', 'full_T14', 'original_acceptance', 'audit_closure', 'independent_assessment')
STEP_REVIEW = 'Prepare the exact actual full correspondence proof for live independent review'
STEP_EMIT = 'Validate all nine public review files before upload'
STEP_UPLOAD = 'Upload the actual bounded live review packet'
STEP_HOLD = 'Await actual independent review and separate root consumption within the fixed hold'
STEP_CLOSE = 'Re-read original private custody and currentness after actual review before teardown'


class Refusal(ValueError):
    pass


def need(ok, code):
    if not ok:
        raise Refusal(code)


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode('ascii')


def desc(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def digest(value):
    return type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None


def strict(raw):
    def pairs(rows):
        value = {}
        for key, item in rows:
            need(key not in value, 'DUPLICATE_JSON_KEY')
            value[key] = item
        return value
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(Refusal('NONFINITE_JSON')))


def read_json(path):
    raw = Path(path).read_bytes()
    need(0 < len(raw) <= 1024**2, 'PROVIDER_METADATA_BOUND')
    return strict(raw)


def module(name, sha):
    need(desc(bound.checked(OPERATOR / name, 2 * 1024**2))['sha256'] == sha, 'REVIEWED_CONSUMER_DIGEST')
    return bound.consumer(name)


def consumers():
    utility = module('host_utility.py', '02a15dc96ecce23e14a3a84bca880aa536d79fffc4f6d6160835cb4ba97a19b5')
    run = module('run.py', '09a7210bff5e39f9f4937f42b9554c0d912c53e0e09b92aec1b3feba84e91d54')
    full = module('full_relation.py', FULL)
    return utility, run, full


def archive(path, review, utility):
    raw = Path(path).read_bytes()
    need(0 < len(raw) <= 1024**2, 'COMPRESSED_TRANSPORT_BOUND')
    expected = {'REQUEST.json', 'PROOF.json', *('public/' + name for name in PUBLIC)} if review else set(PUBLIC)
    with zipfile.ZipFile(path) as zipped:
        info = zipped.infolist()
        need(len(info) == len(expected) and len(set(zipped.namelist())) == len(expected) and
             set(zipped.namelist()) == expected, 'EXACT_ARCHIVE_POPULATION')
        files = {}
        for item in info:
            limit = 4096 if item.filename == 'REQUEST.json' else 16384 if item.filename == 'PROOF.json' else 65536
            kind = stat.S_IFMT(item.external_attr >> 16)
            need(not item.is_dir() and not item.flag_bits & 1 and kind in (0, stat.S_IFREG) and
                 0 < item.file_size <= limit, 'ARCHIVE_MEMBER_BOUND_OR_KIND')
            value = zipped.read(item)
            need(len(value) == item.file_size, 'ARCHIVE_MEMBER_SIZE')
            files[item.filename] = value
    need(sum(map(len, files.values())) <= 262144, 'PUBLIC_TOTAL_BYTES')
    public = {name: files[('public/' if review else '') + name] for name in PUBLIC}
    utility.transport_lines(public)
    docs = {name: utility.public_codec(name, value, True) for name, value in public.items()}
    semantic = sum(len((json.dumps(doc, sort_keys=True, separators=(',', ':'), ensure_ascii=True,
                                   allow_nan=False) + '\n').encode('ascii')) for doc in docs.values())
    if review:
        semantic += len(files['REQUEST.json']) + len(files['PROOF.json'])
    need(semantic <= 262144, 'PUBLIC_SEMANTIC_TOTAL_BYTES')
    return {'zip': desc(raw), 'files': files, 'documents': docs, 'semantic_bytes': semantic}


def provider(args, zip_descriptor):
    run = read_json(args.run_json)
    jobs = read_json(args.jobs_json)
    listing = read_json(args.artifacts_json)
    need(run['id'] == args.run_id and run['run_attempt'] == 1 and run['event'] == 'push' and
         run['head_sha'] == args.workflow_commit and run['head_branch'] == BRANCH and
         run['path'] == '.github/workflows/dg16-r5-full-g2.yml' and
         run['repository']['full_name'] == REPOSITORY and run['head_commit']['tree_id'] == TREE,
         'EXACT_PROVIDER_RUN_BINDING')
    need(jobs['total_count'] == len(jobs['jobs']) == 1, 'EXACT_SINGLE_JOB_POPULATION')
    job = jobs['jobs'][0]
    need(job['run_id'] == args.run_id and job['head_sha'] == args.workflow_commit and
         job.get('run_attempt', 1) == 1, 'EXACT_PROVIDER_JOB_BINDING')
    need(type(listing['total_count']) is int and listing['total_count'] == len(listing['artifacts']),
         'ARTIFACT_LISTING_NOT_COMPLETE')
    allowed_names = {'dg16-full-correspondence-review-' + str(args.run_id) + '-1',
                     'dg16-full-registry-' + str(args.run_id) + '-1'}
    names = [row['name'] for row in listing['artifacts']]
    need(len(names) == len(set(names)) and set(names) <= allowed_names, 'CLOSED_RUN_ARTIFACT_POPULATION')
    selected = [row for row in listing['artifacts'] if row['id'] == args.artifact_id]
    need(len(selected) == 1, 'EXACT_ARTIFACT_ID_REQUIRED')
    artifact = selected[0]
    prefix = 'dg16-full-correspondence-review-' if args.phase == 'review' else 'dg16-full-registry-'
    need(artifact['name'] == prefix + str(args.run_id) + '-1' and artifact['expired'] is False and
         artifact['workflow_run']['id'] == args.run_id and
         artifact['workflow_run']['head_sha'] == args.workflow_commit and
         artifact['workflow_run']['head_branch'] == BRANCH and
         artifact['size_in_bytes'] == zip_descriptor['bytes'] and
         artifact['digest'] == 'sha256:' + zip_descriptor['sha256'], 'EXACT_PROVIDER_ARTIFACT_BINDING')
    names = [row['name'] for row in job['steps']]
    need(len(names) == len(set(names)), 'DUPLICATE_PROVIDER_STEP')
    return run, job, {row['name']: row for row in job['steps']}, listing


def proof(value, full):
    return full.validate_public_proof(value, policy_sha=POLICY, inputs_sha=INPUTS,
                                     source_commit=SOURCE, source_tree=SOURCE_TREE)


def request(files, args, full, live):
    raw = files['REQUEST.json']
    value = strict(raw)
    proof_raw = files['PROOF.json']
    actual_proof = proof(strict(proof_raw), full)
    need(raw == encode(value) and proof_raw == full.encode(actual_proof), 'REVIEW_CANONICAL_BYTES')
    fixed = {'schema': 'dg16.full-correspondence-live-review-request.v1', 'authority': 'NONE',
             'repository': REPOSITORY, 'branch': BRANCH, 'run_id': str(args.run_id), 'run_attempt': 1,
             'workflow_commit': args.workflow_commit, 'source_commit': SOURCE, 'source_tree': SOURCE_TREE,
             'policy_sha256': POLICY, 'policy_adoption_sha256': ADOPTION, 'receiver_inputs_sha256': INPUTS,
             'full_receiver_sha256': FULL, 'proof': desc(proof_raw),
             'private_observations': actual_proof['private_observations'], 'hold_seconds': 3600,
             'control_branch': BRANCH + '-control',
             'control_path': 'qualification/dg16-full-g2-control/' + str(args.run_id) + '-1',
             'private_inputs_retained_while_live': True, 'same_job_closing_readback_required': True,
             'all_declared_relations_equal': True, 'original_acceptance': False, 'automatic_full_G2_award': False}
    varying = {'same_job_currentness_sha256', 'created_utc_epoch', 'expires_utc_epoch'}
    need(type(value) is dict and set(value) == set(fixed) | varying and
         all(type(value[key]) is type(item) and value[key] == item for key, item in fixed.items()),
         'EXACT_REVIEW_REQUEST_BINDING')
    need(digest(value['same_job_currentness_sha256']) and type(value['created_utc_epoch']) is int and
         type(value['expires_utc_epoch']) is int and
         value['expires_utc_epoch'] == value['created_utc_epoch'] + 3600, 'FIXED_REVIEW_DEADLINE')
    need(actual_proof['all_declared_relations_equal'] is True, 'FULL_RELATIONS_NOT_ALL_EQUAL')
    if live:
        need(value['created_utc_epoch'] <= time.time() < value['expires_utc_epoch'], 'REVIEW_NOT_CURRENTLY_LIVE')
    return value, actual_proof


def verify(args):
    global TREE, ADOPTION
    binding = bound.load_binding(args.binding, require_live_reviewer=False)
    need(args.workflow_commit == binding['workflow_commit'], 'EXACT_FINAL_BINDING_COMMIT')
    need(type(args.receiver) is str and re.fullmatch(r'/root(?:/[a-z0-9_]+)?', args.receiver), 'ACTUAL_RECEIVER_IDENTITY_REQUIRED')
    if args.phase == 'review':
        need(binding['independent_live_reviewer'] is not None, 'LIVE_REVIEWER_APPOINTMENT_PENDING')
        need(args.receiver == binding['independent_live_reviewer'], 'APPOINTED_INDEPENDENT_LIVE_REVIEWER_REQUIRED')
    TREE = binding['workflow_tree']
    ADOPTION = binding['Root_policy_adoption']['sha256']
    need(re.fullmatch('[0-9a-f]{40}', args.workflow_commit), 'WORKFLOW_COMMIT_SHAPE')
    utility, run_consumer, full = consumers()
    received = archive(args.zip, args.phase == 'review', utility)
    api_run, job, steps, artifact_listing = provider(args, received['zip'])
    docs = received['documents']
    result, probe, cleanup, source, failure = (docs[name] for name in
        ('RESULT.json', 'PROBE.json', 'CLEANUP.json', 'SOURCE.json', 'FAILURE.json'))
    need(result['workflow_commit'] == args.workflow_commit and result['run_id'] == str(args.run_id) and
         result['run_attempt'] == 1 and result['branch'] == BRANCH and result['repository'] == REPOSITORY and
         all(result[key] is False for key in NO_AWARDS), 'RESULT_BINDING_OR_UNSUPPORTED_AWARD')
    need(source['commit'] == SOURCE and source['tree'] == SOURCE_TREE and source['tracked_source_mutations'] is False,
         'SOURCE_BINDING')
    operation = probe.get('result')
    actual_proof = None
    if operation is not None:
        run_consumer.validate_pair_summary(operation)
        if operation.get('full_correspondence') is not None:
            actual_proof = proof(operation['full_correspondence'], full)
    report = {'schema': 'dg16.v03-provider-bound-public-receiving.v1', 'authority': 'NONE',
              'receiver': args.receiver, 'phase': args.phase, 'run_id': args.run_id,
              'run_attempt': 1, 'job_id': job['id'], 'artifact_id': args.artifact_id,
              'workflow_commit': args.workflow_commit, 'workflow_tree': TREE,
              'final_binding': desc(bound.checked(args.binding, 65536)), 'candidate_seal_sha256': bound.SEAL_SHA,
              'source_commit': SOURCE, 'source_tree': SOURCE_TREE, 'artifact': received['zip'],
              'archive_members': {name: desc(raw) for name, raw in sorted(received['files'].items())},
              'public_payload_bytes': sum(map(len, received['files'].values())),
              'public_semantic_bytes': received['semantic_bytes'], 'provider_digest_verified': True,
              'actual_codec_manifest_and_pair_consumers_used': True,
              'actual_public_proof_consumer_used': actual_proof is not None,
              'private_payload_received': False, 'private_currentness_inferred_from_hashes': False,
              'decisions_issued': [], 'original_acceptance': False,
              'observed_utc_epoch': time.time()}
    if args.phase == 'final' and (api_run['conclusion'] != 'success' or
                                 result['status'] != 'FULL_CORRESPONDENCE_REVIEWED_AND_ROOT_CONSUMED_NO_AUTOMATIC_ACCEPTANCE'):
        need(api_run['status'] == 'completed' and job['status'] == 'completed', 'FINAL_RUN_NOT_TERMINAL')
        need(api_run['conclusion'] in ('failure', 'success', 'cancelled', 'timed_out', 'neutral', 'skipped',
                                      'action_required', 'startup_failure', 'stale') and
             result['status'] in ('UNQUALIFIED', 'UNQUALIFIED_OR_INCOMPLETE',
                                  'FULL_CORRESPONDENCE_REVIEWED_AND_ROOT_CONSUMED_NO_AUTOMATIC_ACCEPTANCE'),
             'CLOSED_TERMINAL_STATUS')
        failure_codes = [row['code'] for row in failure['failures']]
        need(all(type(code) is str and re.fullmatch('[A-Z0-9_]{1,90}', code) for code in failure_codes),
             'CLOSED_FAILURE_CODES')
        report.update(status='ACTUAL_FAILED_OR_INCOMPLETE_OCCURRENCE_RECEIVED',
                      provider_conclusion=api_run['conclusion'], terminal_result_status=result['status'],
                      failure_codes=failure_codes,
                      full_relations_equal=actual_proof['all_declared_relations_equal'] if actual_proof else None,
                      stdout_location=actual_proof.get('stdout_location') if actual_proof else None)
        return report, 3
    need(actual_proof is not None and actual_proof['all_declared_relations_equal'] is True and
         operation['receiving_status'] == 'RECEIVED_COMPLETE_RAW_PAIR' and
         probe['receiving']['status'] == 'RECEIVED_COMPLETE_RAW_PAIR' and
         cleanup['all_step_children_reaped'] is True and cleanup['private_outputs_uploaded'] is False and
         failure['present'] is False, 'COMPLETE_RECEIVING_PREREQUISITES')
    if args.phase == 'review':
        need(api_run['status'] == job['status'] == 'in_progress' and api_run['conclusion'] is None and
             job['conclusion'] is None, 'ACTUAL_SAME_JOB_NOT_LIVE')
        need(all(steps[name]['conclusion'] == 'success' for name in (STEP_REVIEW, STEP_EMIT, STEP_UPLOAD)) and
             steps[STEP_HOLD]['status'] == 'in_progress' and steps[STEP_HOLD]['conclusion'] is None,
             'ACTUAL_REVIEW_HOLD_NOT_OBSERVED')
        req, from_file = request(received['files'], args, full, True)
        need(from_file == actual_proof, 'PUBLIC_PREVIEW_PROOF_CHANGED')
        report.update(status='ACTUAL_REVIEW_PACKET_STRUCTURALLY_VALID_WHILE_JOB_LIVE',
                      request=desc(received['files']['REQUEST.json']), proof=desc(received['files']['PROOF.json']),
                      private_observations=actual_proof['private_observations'],
                      created_utc_epoch=req['created_utc_epoch'], expires_utc_epoch=req['expires_utc_epoch'],
                      seconds_remaining_at_readback=req['expires_utc_epoch'] - time.time(),
                      independent_review_still_required=True, root_consumption_still_required=True,
                      closing_readback_still_required=True)
    else:
        need(api_run['status'] == job['status'] == 'completed' and api_run['conclusion'] == job['conclusion'] == 'success',
             'PROVIDER_SUCCESS_NOT_OBSERVED')
        need(args.review_zip is not None, 'ACTUAL_REVIEW_ARCHIVE_REQUIRED_FOR_CLOSING_BINDING')
        review = archive(args.review_zip, True, utility)
        review_rows = [row for row in artifact_listing['artifacts']
                       if row['name'] == 'dg16-full-correspondence-review-' + str(args.run_id) + '-1']
        need(len(review_rows) == 1 and review_rows[0]['workflow_run']['id'] == args.run_id and
             review_rows[0]['workflow_run']['head_sha'] == args.workflow_commit and
             review_rows[0]['size_in_bytes'] == review['zip']['bytes'] and
             review_rows[0]['digest'] == 'sha256:' + review['zip']['sha256'], 'REVIEW_ARCHIVE_PROVIDER_DIGEST')
        req, from_file = request(review['files'], args, full, False)
        need(from_file == actual_proof, 'CLOSING_PROOF_CHANGED')
        expected = {'schema': 'dg16.full-correspondence-closing-readback.v1', 'authority': 'NONE',
                    'proof': desc(review['files']['PROOF.json']), 'private_observations': actual_proof['private_observations'],
                    'same_private_censuses': True, 'same_source_and_runtime': True,
                    'new_acceptance_or_currentness_authority': False}
        live = probe['live_review']
        need(binding['independent_live_reviewer'] is not None and live['independent_reviewer'] == binding['independent_live_reviewer'], 'APPOINTED_LIVE_REVIEWER_MISMATCH')
        need(live['status'] == 'ACTUAL_INDEPENDENT_REVIEW_AND_ROOT_CONSUMPTION_RECEIVED' and
             live['request_sha256'] == desc(review['files']['REQUEST.json'])['sha256'] and
             live['closing_readback_pending'] is False and live['verified_before_teardown'] is True and
             live['closing_readback'] == expected and digest(live['closing_currentness_sha256']) and
             live['authority'] == 'NONE' and live['automatic_full_G2_award'] is False and
             probe['receiving']['verified_before_teardown'] is True, 'SAME_JOB_CLOSING_READBACK_MISSING')
        need(source['before'] == source['after'] and source['after']['all_members_match'] is True and
             source['after']['file_count'] == 1989 and source['after']['total_bytes'] == 175634600 and
             cleanup['source_unchanged'] is True and cleanup['runtime_unchanged_after_initialization'] is True,
             'SOURCE_RUNTIME_CLOSING_BOOKENDS')
        need(steps[STEP_HOLD]['conclusion'] == steps[STEP_CLOSE]['conclusion'] == 'success', 'PROVIDER_CLOSING_STEPS')
        cumulative = sum(map(len, received['files'].values())) + sum(map(len, review['files'].values()))
        semantic = received['semantic_bytes'] + review['semantic_bytes']
        need(cumulative <= 262144 and semantic <= 262144, 'CUMULATIVE_PUBLIC_EXPORT_BOUND')
        report.update(status='ACTUAL_REVIEWED_AND_ROOT_CONSUMED_CLOSING_EVIDENCE_RECEIVED_NO_ACCEPTANCE_AWARD',
                      request=desc(review['files']['REQUEST.json']), proof=desc(review['files']['PROOF.json']),
                      private_observations=actual_proof['private_observations'],
                      closing_readback=expected, accepted_control_commit=live['control_commit'],
                      independent_reviewer=live['independent_reviewer'], review_record=live['review'],
                      root_consumption_record=live['root_consumption'],
                      cumulative_public_bytes=cumulative, cumulative_semantic_bytes=semantic,
                      separate_root_original_criterion_determination_required=True)
    return report, 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=('review', 'final'), required=True)
    parser.add_argument('--binding', required=True)
    parser.add_argument('--receiver', required=True, help='Actual receiver identity; review phase requires the appointed independent reviewer.')
    parser.add_argument('--workflow-commit', required=True)
    parser.add_argument('--run-id', type=int, required=True)
    parser.add_argument('--artifact-id', type=int, required=True)
    parser.add_argument('--run-json', required=True)
    parser.add_argument('--jobs-json', required=True)
    parser.add_argument('--artifacts-json', required=True)
    parser.add_argument('--zip', required=True)
    parser.add_argument('--review-zip')
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    try:
        report, code = verify(args)
    except Exception as exc:
        code = 1
        message = str(exc)
        reason = message if re.fullmatch('[A-Z0-9_]{1,90}', message) else type(exc).__name__.upper()
        report = {'schema': 'dg16.v03-provider-bound-public-receiving.v1', 'authority': 'NONE',
                  'receiver': args.receiver, 'status': 'REFUSED', 'code': reason,
                  'decisions_issued': [], 'original_acceptance': False}
    output = Path(args.out).absolute()
    need(output.parent == bound.RUNTIME and not output.is_symlink(), 'OWNED_RUNTIME_OUTPUT_DIRECTORY_REQUIRED')
    bound.write_evidence(output, report)
    print(json.dumps({'status': report['status'], 'receipt': desc(encode(report)),
                      'authority': 'NONE', 'decisions_issued': []}))
    return code


if __name__ == '__main__':
    raise SystemExit(main())
