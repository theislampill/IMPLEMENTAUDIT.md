# Corrected-source V03 receiving preparation

Report state: FINAL

Author: `/root/recover_v03`. Authority: `NONE`.

The exact final object and actual policy records are verified. The independent
live reviewer is **pending**. This author is excluded by both actual validators.
Root owns appointment, launch preflight, the one-use grant and every external
effect. This preparation performs no provider, protected native/model, pair,
controller, publication or decision operation.

## Exact binding

| Item | Value |
| --- | --- |
| Product / sole parent | `84ed2972d370f6c34100d48657f0c96a570e0b49` |
| Product tree | `53ad93aa1a94c324340f2de7ee2ba272c74fc57e` |
| Reviewed pre-decision tree | `e118a03deeca1991bed708917a451365b20fa5bf` |
| Final workflow commit | `07c56d666919e3b741da512c23886546388aac1e` |
| Final workflow tree | `48c67b0ba7ccb2bbbfd3a8515a8c314c081d8cac` |
| Candidate seal SHA256 | `f113bae864a61c4ab1a381f876306e36f874555a740fc5da164cf496d8cf2031` |
| Actual Root adoption SHA256 | `27128a0008b6725e06938c183faa66705d83f9ea5cfd2a2aea28fee5b7907065` |
| Actual code review SHA256 | `932813f46798437585a3b3eb654030f3973b589fd48366c509b978f01b89854b` |
| Trigger branch | `engineering/pro-dg16-v03-current84ed-20261126-02` |
| Control branch | `engineering/pro-dg16-v03-current84ed-20261126-02-control` |

`FINAL_BINDING_PENDING_REVIEWER.json` is a non-authorizing receiving record. Its
2,727 bytes have SHA256
`de14da1793c35bca61f5897222745bf90585c1ad0945e66220e4896c86fb0805`.
Its `independent_live_reviewer` is explicitly `null`.

The binder checked the actual fetched Git object: sole parent, exact tree, all
22 sealed blobs, modes and SHA256 values, exactly 24 additions, and the two actual
decision records through the unchanged `policy_control.validate` consumer.
No source copy was made and no candidate file was changed.

## Remaining runtime fields

Before launch, Root must appoint the actual independent live reviewer. Create a
new binding using that real identity; retain the pending record unchanged. The
binder checks the actual exclusion list, but does not create an appointment or
grant. Root's launch preflight and one-use authorization remain separate.

After launch, acquisition must supply the actual run ID, job ID, review/final
artifact IDs, complete provider metadata and exact downloaded bytes. Request
creation/expiration, proof/private-observation descriptors, currentness descriptor
and eventual control commit come only from those actual observations. None is
filled from the predecessor or from an expectation.

The scripts are frozen under `receiver/`. Their output directory is the separate
`runtime/` sibling, which was **not created during preparation**. The scripts do
not write output beneath their frozen source directory.

## Scripts

### 1. Bind the final commit and actual appointment

After Root has appointed the actual reviewer, set `appointed_reviewer` to that
exact identity and run:

```bash
python3 -B /workspace/scratch/ac0b432d8253/v03-84ed-receiving-preparation/receiver/bind_final.py \
  --workflow-commit 07c56d666919e3b741da512c23886546388aac1e \
  --live-reviewer "${appointed_reviewer:?Root must appoint the actual reviewer}" \
  --out /workspace/scratch/ac0b432d8253/v03-84ed-receiving-preparation/runtime/FINAL_BINDING.json
```

This rechecks the same final object and actual adoption before writing a new
write-once evidence record. It performs only local Git reads; missing objects
refuse without lazy fetch. It does not create or update refs or decisions.

### 2. Receive actual public evidence

Use `receiver/receive_public_artifact.py`. It retains the historical receiver's
exact archive, provider, proof and request predicates. The identity rebind and
final-binding gate are described in `REBIND_SCOPE.json` and
`RECEIVER_DIFF.patch`. It invokes the actual bound `public_codec`,
`transport_lines`, `validate_pair_summary` and `validate_public_proof` functions.

After receiving actual provider JSON and the actual review ZIP, the appointed
reviewer supplies `actual_run_id` and `actual_review_artifact_id`:

```bash
python3 -B /workspace/scratch/ac0b432d8253/v03-84ed-receiving-preparation/receiver/receive_public_artifact.py \
  --phase review \
  --binding /workspace/scratch/ac0b432d8253/v03-84ed-receiving-preparation/runtime/FINAL_BINDING.json \
  --receiver "${appointed_reviewer:?Actual appointed reviewer required}" \
  --workflow-commit 07c56d666919e3b741da512c23886546388aac1e \
  --run-id "${actual_run_id:?Actual provider run required}" \
  --artifact-id "${actual_review_artifact_id:?Actual provider artifact required}" \
  --run-json /workspace/scratch/ac0b432d8253/v03-84ed-receiving-preparation/runtime/run-review.json \
  --jobs-json /workspace/scratch/ac0b432d8253/v03-84ed-receiving-preparation/runtime/jobs-review.json \
  --artifacts-json /workspace/scratch/ac0b432d8253/v03-84ed-receiving-preparation/runtime/artifacts-review.json \
  --zip /workspace/scratch/ac0b432d8253/v03-84ed-receiving-preparation/runtime/review.zip \
  --out /workspace/scratch/ac0b432d8253/v03-84ed-receiving-preparation/runtime/ACTUAL_REVIEW_RECEIVING.json
```

The review archive has exactly `REQUEST.json`, `PROOF.json` and the seven
`public/` members named below. The receiver requires an actual in-progress job,
successful review emission/upload, the active hold, exact provider artifact
size/digest and a currently unexpired request. It writes evidence only; an honest
independent review and separate Root consumption remain necessary.

For terminal receiving, use the same command with `--phase final`, actual final
metadata, the final artifact ID/ZIP and a distinct output receipt. Successful
closing additionally requires `--review-zip` naming the actual earlier ZIP. The
receiver verifies that archive against provider metadata, matches the exact
request/proof, and checks the same-private-census/source/runtime closing readback,
verified-before-teardown flags, appointed reviewer and cumulative public bounds.

Exit `0` is bounded receiving evidence. Exit `3` records an actual failed or
incomplete terminal occurrence. Exit `1` is a receiving refusal. None grants
original acceptance. A failure before artifact creation is retained from actual
provider metadata/log evidence; no missing ZIP or public record is manufactured.

### 3. Check genuinely issued control records

`receiver/check_issued_control.py` accepts `--binding`, `--run-id`,
`--review-zip`, `--live-receipt`, `--issued-records`, and `--out`.

The input directory must contain the actual issued `CONTROL.json`,
`INDEPENDENT_REVIEW.json` and `ROOT_CONSUMPTION.json`, or only the actual Root STOP
record. The helper checks the actual review receipt/archive and then invokes the
unchanged `live_control.validate` with **real current UTC time**. It only writes a
bounded data-readback receipt in `runtime/`. It generates no review, Root record,
control commit or publication. Root separately refreshes actual provider hold
status immediately before publication.

`CONTROL_SCHEMA_REFERENCE.json` records the exact schema and is explicitly
**non-issuable**. It leaves the run ID, control path and reviewer pending. Each
actual control file is at most 4,096 bytes and mode `100644`. The control commit
must have sole parent `07c56d666919e3b741da512c23886546388aac1e` and only the three
exact additions under `qualification/dg16-full-g2-control/<actual-run-id>-1/`, or
the single STOP addition. Unknown/duplicate fields refuse.

## Provider acquisition and download route

Current tool metadata advertises these existing connected capabilities:

- `mcp__codex_apps__github_fetch` for approved GitHub REST JSON GETs.
- `mcp__codex_apps__github_download_workflow_artifact` for ZIP bytes through its
  returned reusable file reference.
- `mcp__codex_apps__github_fetch_workflow_job_logs` for decoded job logs when
  diagnostic evidence is needed.

No provider call was made in this preparation. The same download route previously
received actual artifact `15086029588`, 12,159 bytes, SHA256
`5db8f8d752b530013cccf590b7f7e5990d7dda0141d3cb21c2965c655def6370`.
That supports historical transport readiness only. The current consumer refuses
that old pair as source `84ed2972`.

Discover the exact new run using the branch-filtered Actions run listing and
match final SHA, push event and attempt 1. The concrete URL patterns are in
`TRANSPORT_READINESS.json`. Read the run, all jobs and complete artifact listing
at reasonable 30–60 second intervals. Preserve complete JSON from the actual
`structuredContent.content`; collect all pages when necessary. Use the push run
listing, not the PR-filtered commit-workflow helper. No branch recreation, rerun,
cancellation or automatic retry follows from missing/asynchronous data.

Download only an observed artifact ID using the dedicated download tool and
`repo_full_name: "theislampill/IMPLEMENTAUDIT.md"`. Materialize the returned
`structuredContent.file_uri.download_url` into a new runtime file with the
original 1 MiB compressed bound, and verify its exact size and SHA256 against the
provider row. Never print or persist the temporary signed URL. Generic GitHub
`fetch` does not handle binary downloads. Do not substitute reconstructed or
diagnostic output for artifact bytes.

Expected review name: `dg16-full-correspondence-review-<actual-run-id>-1`.
Expected terminal name: `dg16-full-registry-<actual-run-id>-1`.

The seven public names are `RESULT.json`, `HOST.json`, `SOURCE.json`,
`PROBE.json`, `CLEANUP.json`, `FAILURE.json` and `ARTIFACT_MANIFEST.json`.
The terminal archive places them at its root. ZIP extraction is unnecessary.

## Fixed limits and custody

| Predicate | Preserved value |
| --- | ---: |
| Request / individual control record | 4,096 bytes |
| Public proof | 16,384 bytes |
| Individual public file | 65,536 bytes |
| Cumulative exported review + final payload and semantic bytes | 262,144 bytes |
| Live review hold | 3,600 seconds from actual request creation |
| Closing reserve | 180 seconds |
| Orchestration / pair / receiving | 19,800 / 14,400 / 300 seconds |

The request deadline is exclusive and is not reset at download or receipt. The
job rechecks both clocks, control head and exclusive reservation at consumption.
Closing revalidates the original retained inputs and fresh currentness before
teardown. Hashes do not give this public receiver private custody or native
currentness authority. The 128-byte private raw/normalized diagnostic windows
remain private. No normalization, original full comparison, scope or resource
predicate is changed.

## Verification and freeze

`VERIFICATION.json` records compilation, exact final-object/policy readback,
actual bound consumer loading, historical codec/manifest transport checking and
actual refusals for: pending reviewer, this author as reviewer, the spent workflow
commit, and the historical source pair. No positive proof, independent PASS or
Root record was synthesized.

The frozen operator and receiver directories have no generated bytecode. The
runtime directory, monitor and source copies remain absent. `MANIFEST.json`
enumerates the frozen preparation; future runtime evidence is a separate resource.

Disposition: `FINAL_OBJECT_BOUND_RECEIVER_PREPARED_LIVE_REVIEWER_APPOINTMENT_PENDING`.
