#!/usr/bin/env python3
"""Bounded independent source/rebind/consumer checks; no operator main or effects."""
import ast
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import types

ROOT = Path(__file__).resolve().parent
PACKET = Path('/workspace/scratch/ac0b432d8253/v03-corrected-source-preparation')
C = PACKET / 'candidate'
Q = C / 'qualification/dg16-r5-full-g2'
SOURCE = '84ed2972d370f6c34100d48657f0c96a570e0b49'
PRIOR_SOURCE = '540a12c1385fabc3170745103dd0ccb5ba8c9063'
PRIOR_OPERATOR = 'fdcc7c1cce85350036db9d4674e27491b0ba5d3d'
AUTHOR = '/root/recover_v03'
REVIEWER = '/root/v03_84ed_cold_review'
BRANCH = 'engineering/pro-dg16-v03-current84ed-20261126-02'
PREFIX = 'qualification/dg16-r5-full-g2/'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False)+'\n').encode()

def desc(raw):
    return {'bytes':len(raw), 'sha256':sha(raw)}

def git(*args):
    return subprocess.check_output(['git','--no-optional-locks','-C',str(C),*args])

def old(name):
    return git('show', PRIOR_OPERATOR+':'+PREFIX+name)

def module(path):
    raw = path.read_bytes()
    mod = types.ModuleType('independent_84ed_'+path.stem)
    mod.__file__ = str(path)
    exec(compile(raw,str(path),'exec'),mod.__dict__)
    return mod

def constants(raw):
    out = {}
    for node in ast.parse(raw).body:
        if isinstance(node, ast.Assign):
            try:
                val = ast.literal_eval(node.value)
            except (ValueError,TypeError):
                continue
            for target in node.targets:
                if isinstance(target,ast.Name): out[target.id]=val
    return out

def mask(raw,names):
    lines=raw.decode().splitlines(keepends=True)
    seen=set()
    for node in ast.parse(raw).body:
        if isinstance(node,ast.Assign) and len(node.targets)==1:
            target=node.targets[0]
            if isinstance(target,ast.Name) and target.id in names:
                assert target.id not in seen and node.lineno==node.end_lineno
                seen.add(target.id)
                lines[node.lineno-1]=target.id+' = REVIEWED_IDENTITY_CONSTANT\n'
    assert seen==names,(seen,names)
    return ''.join(lines).encode()

def functions(raw):
    source=raw.decode()
    return [(node.name,ast.get_source_segment(source,node)) for node in ast.parse(source).body
            if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))]

envelope_path=Path('/workspace/scratch/ac0b432d8253/v03-84ed-review-route/ENVELOPE.json')
assert sha(envelope_path.read_bytes())=='5e99c8103eca62eca5fa2cce8ad8d0e02af7903dda00dc1ec892d785085494bc'
envelope=json.loads(envelope_path.read_bytes())
assert envelope['reviewer']==REVIEWER and envelope['authority_ceiling'].startswith('Review findings only')
for row in envelope['executing_package']['members']:
    assert desc((Path(envelope['executing_package']['root'])/row['path']).read_bytes())=={k:row[k] for k in ('bytes','sha256')}
manifest=json.loads((PACKET/'MANIFEST.json').read_bytes())
for row in manifest['files']:
    assert desc((PACKET/row['path']).read_bytes())=={k:row[k] for k in ('bytes','sha256')}
seal=json.loads((PACKET/'SEAL.json').read_bytes())
assert sha((PACKET/'SEAL.json').read_bytes())==envelope['packet_sha256']
source=json.loads((Q/'SOURCE_MANIFEST.json').read_bytes())
source_rows={row['path']:row for row in source['members']}
old_source=json.loads(old('SOURCE_MANIFEST.json'))
old_rows={row['path']:row for row in old_source['members']}
assert set(source_rows)==set(old_rows)
source_delta=[name for name in source_rows if source_rows[name]!=old_rows[name]]
assert source_delta==['fixtures/semantic-preservation/cases.json']
cases=json.loads((C/source_delta[0]).read_bytes())
prior_cases=json.loads(git('show',PRIOR_SOURCE+':'+source_delta[0]))
expected_cases=json.loads(json.dumps(prior_cases))
builder='scripts/package-contract.py'
assert cases['package_evidence']['builder_path']==builder
expected_cases['package_evidence']['builder_sha256']=sha((C/builder).read_bytes())
assert cases==expected_cases
assert (C/'fixtures/semantic-preservation/evaluate.py').read_bytes()==git('show',PRIOR_SOURCE+':fixtures/semantic-preservation/evaluate.py')

allowed={
 'run.py':{'SOURCE_COMMIT','SOURCE_TREE','BRANCH','MANIFEST_SHA','PAIR_DRIVER_SHA','FULL_RELATION_SHA','RELATION_INPUTS_SHA','POLICY_SHA','POLICY_CONTROL_SHA','LIVE_CONTROL_SHA','CHECKOUT_PREPARE_SHA','CAPTURE_EVIDENCE_SHA'},
 'pair_driver.py':{'SOURCE_COMMIT','SOURCE_TREE','FULL_RELATION_SHA','RELATION_INPUTS_SHA','POLICY_SHA','POLICY_CONTROL_SHA','CHECKOUT_PREPARE_SHA','CAPTURE_EVIDENCE_SHA'},
 'full_relation.py':{'REPORT_PROFILE_SHA','REPORT_PROFILE_BYTES','ROLE_PROFILE_SHA'},
 'capture_evidence.py':{'SOURCE_COMMIT','SOURCE_TREE','CATALOG_SHA'},
 'checkout_prepare.py':{'SOURCE_COMMIT'},
 'policy_control.py':{'AUTHOR','ADAPTER_AUTHOR','CURRENT_AUTHORS'},
 'live_control.py':{'AUTHOR','ADAPTER_AUTHOR','CURRENT_AUTHORS','CONTROL_BRANCH'},
}
code_preservation={}
files={p.name:p.read_bytes() for p in Q.iterdir() if p.is_file()}
for name,raw in files.items():
    if not name.endswith('.py'): continue
    prior=old(name)
    compile(raw,str(Q/name),'exec',dont_inherit=True)
    assert functions(raw)==functions(prior),name
    assert mask(raw,allowed.get(name,set()))==mask(prior,allowed.get(name,set())),name
    code_preservation[name]={'function_class_count':len(functions(raw)), 'all_function_class_bytes_equal':True,
       'other_bytes_equal_after_only_enumerated_constant_mask':True,'allowed_constants':sorted(allowed.get(name,set())),
       'whole_file_equal':raw==prior,'sha256':sha(raw)}
assert len(code_preservation)==15
assert sum(row['whole_file_equal'] for row in code_preservation.values())==8

compiler=module(C/'skills/implementaudit/scripts/compile-work-graph.py')
registry=(C/'scripts/verify-package.sh').read_bytes()
physical=sorted(name for name in source_rows if re.fullmatch(r'tests/[^/]+\.test\.sh',name))
registered=compiler.verifier_registered_tests_v1(registry)
assert physical==registered
mapping=compiler.compile_verifier_graph_v1(registry,physical,{'qualification':'STATIC_SOURCE_DERIVATION_NOT_EXECUTION'})
commands=compiler.verifier_command_stream_v1(mapping,registry)
assert b''.join(row['source'].encode() for row in mapping['nodes'])==registry
assert encode(mapping)==(PACKET/'derivation/STATIC_MAPPING.json').read_bytes()
assert commands==(PACKET/'derivation/commands.bin').read_bytes()
assert (len(mapping['nodes']),len(registered),len(commands),sha(commands))==(119,91,49666,'de2ef1f15fd8e115cc61523feafd87e42a353ce277861ab2d08d0c033b8b950d')

slots=json.loads(files['REPORT_SLOTS.json']); prior_slots=json.loads(old('REPORT_SLOTS.json'))
assert slots['source_commit']==SOURCE and slots['source_tree']==source['tree']
assert slots['slots']==prior_slots['slots']
assert set(slots['source_closure'])==set(prior_slots['source_closure'])
slot_checks=[]
node_ids={n['id'] for n in mapping['nodes']}
assert [row['ordinal'] for row in slots['slots']]==list(range(112))
for row in slots['slots']:
    for member in ('program','wrapper'):
        name=row[member]
        assert source_rows[name]==old_rows[name]
    assert (C/row['wrapper']).read_text().splitlines()[row['line']-1].strip()==row['invocation']
    assert row['registry_node'] in node_ids
    assert row['test_count']==len(row['tests'])==len({test['id'] for test in row['tests']})
    assert all(test['printed_identity']==test['id'].split('.')[-1]+' ('+test['id']+')' for test in row['tests'])
    for group in row.get('source_class_groups',[]):
        guard=group['skip_guard']
        if guard is not None:
            assert source_rows[guard['source_path']]==old_rows[guard['source_path']]
            assert guard['source']==desc((C/guard['source_path']).read_bytes())
    for spec in row.get('source_inline_stderr',[]):
        assert source_rows[spec['source_path']]==old_rows[spec['source_path']]
        assert spec['source']==desc((C/spec['source_path']).read_bytes())
    slot_checks.append({'ordinal':row['ordinal'],'test_count':row['test_count'],'program':row['program'],'wrapper':row['wrapper'],'line':row['line'],'registry_node':row['registry_node']})
assert sum(row['test_count'] for row in slot_checks)==2115
roles=json.loads(files['OUTPUT_ROLES.json']); prior_roles=json.loads(old('OUTPUT_ROLES.json'))
assert {k:v for k,v in roles.items() if k not in ('source_commit','source_tree')}=={k:v for k,v in prior_roles.items() if k not in ('source_commit','source_tree')}
for profile,field in ((slots,'source_closure'),(roles,'source_files')):
    for name,row in profile[field].items():
        assert row=={k:source_rows[name][k] for k in ('bytes','sha256','mode')}
for name,digest in roles['pending_source_pins'].items():
    assert source_rows[name]['sha256']==digest
history=json.loads((C/'test-support/work-graph-registry/original117-manifest.json').read_bytes())
for name,size,digest,mode in roles['historical_composition_sources']:
    record=history['files']['skills/implementaudit/scripts/'+name]
    raw=(C/'test-support/work-graph-registry'/record['specimen']).read_bytes()
    assert (len(raw),sha(raw),int(record['mode'],8) if isinstance(record['mode'],str) else record['mode'])==(size,digest,mode)

catalog=json.loads(files['CAPTURE_DIAGNOSTIC_CATALOG.json']); prior_catalog=json.loads(old('CAPTURE_DIAGNOSTIC_CATALOG.json'))
assert catalog['source_commit']==SOURCE and catalog['source_tree']==source['tree']
assert catalog['report_slots_sha256']==sha(files['REPORT_SLOTS.json'])
owner_raw=(C/'scripts/qualify-work-graph-verifier.py').read_bytes()
assert catalog['owner_sha256']==sha(owner_raw)
for row in catalog['files']:
    assert source_rows[row['path']]==old_rows[row['path']]
    raw=(C/row['path']).read_bytes()
    assert all(row[k]==desc(raw)[k] for k in ('bytes','sha256'))
    assert row['lines']==len(raw.splitlines())
refs=collections.defaultdict(list)
for slot in slots['slots']:
    for i,test in enumerate(slot['tests']):
        raw=test['printed_identity'].encode()
        refs[(len(raw),sha(raw))].append([slot['ordinal'],i])
expected_tests=[dict(id=f'T{i:06d}',bytes=k[0],sha256=k[1],references=v) for i,(k,v) in enumerate(sorted(refs.items(),key=lambda kv:kv[0][1]))]
assert catalog['tests']==expected_tests==prior_catalog['tests']
owner_ast=ast.parse(owner_raw)
owner_functions={n.name:n for n in owner_ast.body if isinstance(n,ast.FunctionDef)}
for cls in (n for n in owner_ast.body if isinstance(n,ast.ClassDef)):
    owner_functions.update({cls.name+'.'+n.name:n for n in cls.body if isinstance(n,ast.FunctionDef)})
for row in catalog['owner_frames']+catalog['observation_calls']:
    node=owner_functions[row['name']]
    assert row['first']==min([node.lineno]+[n.lineno for n in node.decorator_list]) and row['last']==node.end_lineno
assert catalog['literals']==prior_catalog['literals'] and catalog['prefixes']==prior_catalog['prefixes']
catalog_binding_fields={'source_commit','source_tree','owner_sha256','report_slots_sha256','current_source_catalog_rebinding'}
assert {k:v for k,v in catalog.items() if k not in catalog_binding_fields}=={k:v for k,v in prior_catalog.items() if k not in catalog_binding_fields}

run=module(Q/'run.py'); pair=module(Q/'pair_driver.py'); full=module(Q/'full_relation.py')
policy_gate=module(Q/'policy_control.py'); live=module(Q/'live_control.py')
utility=run.load_utility()
inputs=json.loads(files['RELATION_INPUTS.json']); policy=json.loads(files['POLICY.json']); prior_policy=json.loads(old('POLICY.json'))
assert full.encode(inputs)==files['RELATION_INPUTS.json'] and full.encode(policy)==files['POLICY.json']
relation=full.load(Q,inputs,pair.adapter_module,pair.bounded_json)
assert run.read_manifest(utility)==source_rows
assert relation['source']==source and relation['slots']==slots and relation['roles']==roles
assert full.REPORT_PROFILE_BYTES==len(files['REPORT_SLOTS.json'])<=full.REPORT_PROFILE_CEILING
fixed={'UTILITY_SHA':'host_utility.py','PAIR_DRIVER_SHA':'pair_driver.py','DIAGNOSTICS_SHA':'pair_diagnostics.py',
 'FULL_RELATION_SHA':'full_relation.py','RELATION_INPUTS_SHA':'RELATION_INPUTS.json','POLICY_SHA':'POLICY.json',
 'POLICY_CONTROL_SHA':'policy_control.py','LIVE_CONTROL_SHA':'live_control.py','CHECKOUT_PREPARE_SHA':'checkout_prepare.py',
 'CAPTURE_EVIDENCE_SHA':'capture_evidence.py','MANIFEST_SHA':'SOURCE_MANIFEST.json','CATALOG_SHA':'CAPTURE_DIAGNOSTIC_CATALOG.json',
 'REPORT_PROFILE_SHA':'REPORT_SLOTS.json','ROLE_PROFILE_SHA':'OUTPUT_ROLES.json','STDOUT_OBSERVER_SHA':'stdout_location.py'}
pins=[]
for name,raw in files.items():
    if not name.endswith('.py'): continue
    for field,value in constants(raw).items():
        if field in fixed:
            target=fixed[field]; assert value==sha(files[target]),(name,field,target)
            pins.append({'host':name,'field':field,'target':target,'sha256':value})
for name,row in inputs['files'].items():
    assert row==desc(files[name])
    pins.append({'host':'RELATION_INPUTS.json','field':name,'target':name,**row})
assert pair.OWNER_SHA256==sha(owner_raw)
for name in ('capture_evidence.py','checkout_prepare.py'):
    assert constants(files[name])['OWNER_SHA']==sha(owner_raw)
assert constants(files['checkout_prepare.py'])['COMPILER_SHA']==source_rows['skills/implementaudit/scripts/compile-work-graph.py']['sha256']
assert {name:source_rows['scripts/'+name]['sha256'] for name in full.SUCCESSOR_OWNER_PINS}==full.SUCCESSOR_OWNER_PINS
assert (run.SOURCE_COMMIT,pair.SOURCE_COMMIT,run.SOURCE_TREE,pair.SOURCE_TREE)==(SOURCE,SOURCE,source['tree'],source['tree'])
assert run.BRANCH==BRANCH and live.CONTROL_BRANCH==BRANCH+'-control'
assert (policy['source_commit'],policy['source_tree'],policy['author'])==(SOURCE,source['tree'],AUTHOR)
assert policy['receiver_inputs_sha256']==sha(files['RELATION_INPUTS.json']) and policy['full_receiver_sha256']==sha(files['full_relation.py'])
allowed_policy={'author','source_commit','source_tree','status','receiver_inputs_sha256','full_receiver_sha256','successor_rebinding'}
assert {k:v for k,v in policy.items() if k not in allowed_policy}=={k:v for k,v in prior_policy.items() if k not in allowed_policy}
assert policy['successor_rebinding']['historical_rebinding']==prior_policy['successor_rebinding']
assert policy['successor_rebinding']['derivation_sha256']==sha((PACKET/'derivation/DERIVATION.json').read_bytes())
assert policy['successor_rebinding']['predecessor_policy_sha256']==sha(old('POLICY.json'))
previous_authors=constants(old('policy_control.py'))['CURRENT_AUTHORS']
assert policy_gate.CURRENT_AUTHORS==live.CURRENT_AUTHORS==previous_authors+(AUTHOR,)
assert policy_gate.AUTHOR==policy_gate.ADAPTER_AUTHOR==live.AUTHOR==live.ADAPTER_AUTHOR==AUTHOR
assert not any(policy_gate.independent(identity) for identity in (*policy_gate.CURRENT_AUTHORS,'/root'))
assert policy_gate.independent(REVIEWER)
assert not (Q.parent/'dg16-r5-full-g2-decisions').exists()
refusals=[]
for name,fn in (('run.actual_policy_adoption',lambda:run.actual_policy_adoption(utility)),('pair.relation_context',pair.relation_context)):
    try:fn()
    except FileNotFoundError as error:
        assert error.filename==str(Q.parent/'dg16-r5-full-g2-decisions/INDEPENDENT_COLD_REVIEW.json')
        refusals.append({'consumer':name,'exception':'FileNotFoundError','absent_member':'INDEPENDENT_COLD_REVIEW.json'})
    else:raise AssertionError(name+' accepted absent decisions')

workflow=(C/'.github/workflows/dg16-r5-full-g2.yml').read_bytes()
prior_workflow=git('show',PRIOR_OPERATOR+':.github/workflows/dg16-r5-full-g2.yml')
assert workflow==prior_workflow.replace(b'engineering/pro-dg16-v03-current540-20261126-01',BRANCH.encode()).replace(PRIOR_SOURCE.encode(),SOURCE.encode()).replace(sha(old('run.py')).encode(),sha(files['run.py']).encode())
negative=re.findall(rb"if \[\[ \"\$actual\" != '([0-9a-f]{64})' \]\]; then",workflow)
positive=re.findall(rb"\[\[ \"\$actual\" == '([0-9a-f]{64})' \]\] \|\| exit 1",workflow)
assert (len(negative),len(positive),workflow.count(sha(files['run.py']).encode()))==(14,3,17)
assert set(negative+positive)=={sha(files['run.py']).encode()}
lines=workflow.decode().splitlines(); blocks=[]; i=0
while i<len(lines):
    if lines[i].strip()=='run: |':
        indent=len(lines[i])-len(lines[i].lstrip()); block=[]; i+=1
        while i<len(lines) and (not lines[i].strip() or len(lines[i])-len(lines[i].lstrip())>indent):
            block.append(lines[i][indent+2:]);i+=1
        blocks.append('\n'.join(block)+'\n')
    else:i+=1
for block in blocks:
    p=subprocess.run(['bash','-n'],input=block.encode(),capture_output=True,timeout=5)
    assert p.returncode==0 and not p.stdout and not p.stderr
assert len(blocks)==17
assert (run.RUN_SECONDS,run.BANK_SECONDS,run.RECEIVE_SECONDS,run.HOLD_SECONDS,run.FINAL_SECONDS,run.SETUP_SECONDS)==(19800,14400,300,3600,180,600)
assert policy['resource_policy']==prior_policy['resource_policy']
assert run.PUBLIC_NAMES==utility.PUBLIC_NAMES
assert git('status','--porcelain=v1','--untracked-files=all').decode().splitlines()==sorted('?? '+r['path'] for r in seal['operator_files'])

result={'schema':'dg16.independent-corrected-source-checks.v1','reviewer':REVIEWER,'authority':'NONE',
 'route_envelope_sha256':sha(envelope_path.read_bytes()),'executing_package_members':len(envelope['executing_package']['members']),
 'source_commit':SOURCE,'source_tree':source['tree'],'predecision_tree':seal['derived_predecision_tree'],
 'source_delta':source_delta,'builder_digest':cases['package_evidence']['builder_sha256'],'evaluator_bytes_unchanged':True,
 'code_preservation':code_preservation,'complete_pin_cascade':pins,
 'profile_derivation':{'nodes':len(mapping['nodes']),'registered_shell_tests':len(registered),'command_stream':desc(commands),
   'registry_complete_reassembly':True,'mapping_equal_author_derivation':True,'source_report_slots':len(slot_checks),
   'declared_methods':sum(row['test_count'] for row in slot_checks),'programs':len({r['program'] for r in slot_checks}),
   'wrappers':len({r['wrapper'] for r in slot_checks}),'selection_arrays_skip_guards_inline_stderr_unchanged':True,
   'slot_checks':slot_checks,'source_closure_members':len(slots['source_closure']),'role_source_files':len(roles['source_files']),
   'catalog_files':len(catalog['files']),'catalog_method_ids':len(catalog['tests']),'catalog_reference_count':sum(len(r['references']) for r in catalog['tests']),
   'catalog_owner_frames_rederived':True,'catalog_literals_prefixes_unchanged':True},
 'actual_consumers':{'closed_relation_loader':'PASS','source_manifest_reader':'PASS','absent_decision_refusals':refusals},
 'current_author_excluded':True,'previous_author_exclusions_preserved':True,'reviewer_independent_under_actual_predicate':True,
 'policy_semantic_fields_unchanged':True,'workflow_only_exact_rebind':True,'workflow_adapter_pins':17,'conditional_guards':14,'direct_guards':3,'bash_syntax_blocks':len(blocks),
 'resource_policy':policy['resource_policy'],'candidate_writes':False,'protected_execution':False,'remote_effects':False,
 'full_source_copy_made':False,'original_acceptance_awarded':False}
with (ROOT/'CHECKS.json').open('xb') as stream:stream.write(encode(result))
print(json.dumps({'status':'PASS_BOUNDED_CHECKS_ONLY','source':SOURCE,'nodes':119,'shell_tests':91,'slots':112,'methods':2115,'pins':len(pins),'absence_refusals':len(refusals),'candidate_writes':False,'original_acceptance_awarded':False},sort_keys=True))
