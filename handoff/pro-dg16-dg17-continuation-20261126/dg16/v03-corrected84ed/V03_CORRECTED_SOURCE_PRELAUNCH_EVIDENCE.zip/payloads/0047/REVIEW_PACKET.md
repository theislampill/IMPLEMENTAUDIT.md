# DG16 V03 corrected-source preparation

Report state: FINAL

Author: `/root/recover_v03`. Authority: `NONE`. Root retains every decision,
publication, operation and acceptance effect. This is a new successor preparation
after spent run `45753254661`, with no retry or reinterpretation of that occurrence.

## Review object

The candidate worktree is
`/workspace/scratch/ac0b432d8253/v03-corrected-source-preparation/candidate`.
Its detached HEAD remains the product source. There is no operator commit and no
new remote branch. The exact 22 added files are listed in
`CANDIDATE_FILE_MANIFEST.json`; `SEAL.json` binds the review object and evidence.

| Binding | Exact value |
| --- | --- |
| Product source / required sole parent | `84ed2972d370f6c34100d48657f0c96a570e0b49` |
| Product tree | `53ad93aa1a94c324340f2de7ee2ba272c74fc57e` |
| Pre-decision operator starting data | `fdcc7c1cce85350036db9d4674e27491b0ba5d3d` |
| Derived candidate tree before decisions | `e118a03deeca1991bed708917a451365b20fa5bf` |
| Proposed trigger branch | `engineering/pro-dg16-v03-current84ed-20261126-02` |
| Proposed control branch | `engineering/pro-dg16-v03-current84ed-20261126-02-control` |
| Policy SHA256 | `8563d116a17ffeb526c5a8fe107e738bca6ec167c8649f7b2f6f7ff281f38b20` |
| Relation inputs SHA256 | `ce71206318a76872cb27f118e219445d56c7e60a995747fa7ff654caacf37ca7` |
| Adapter SHA256 | `09a7210bff5e39f9f4937f42b9554c0d912c53e0e09b92aec1b3feba84e91d54` |
| Pair driver SHA256 | `2e55eb2ed8366e35d29c54339d69bf0db71033abd0171fda8a8cb22d0fe5790b` |

The candidate tree was computed from exact Git tree framing over all 1,989 source
members plus the 22 actual operator blobs. The same implementation reproduced the
known source tree before computing the proposed candidate tree. No tree object or
commit was written by this lane.

## Exact source and profile derivation

The source commit has sole parent `540a12c1385fabc3170745103dd0ccb5ba8c9063` and
changes only `fixtures/semantic-preservation/cases.json`. Its builder identity
equals the actual unchanged `scripts/package-contract.py` SHA256
`0310b26990bf95ee67a143c3378ef315cbef92b1d70ca9d7cb0929d5b03c0854`.
The equality predicate is unchanged. `PRODUCT_REPAIR.patch` records that exact
source delta; this preparation does not claim to have performed Root's earlier
focused bootstrap or semantic test executions.

The complete source census was rederived from Git objects, including blob framing,
mode, length and SHA256, and compared against the physical worktree. It has 1,989
files totaling 175,634,600 bytes. The actual maintained pure compiler rederived
119 nodes and 91 registered shell tests; the physical registered-test population
matches, and the complete registry bytes reassemble. Its 49,666-byte command
stream retains SHA256
`de2ef1f15fd8e115cc61523feafd87e42a353ce277861ab2d08d0c033b8b950d`.

All 112 report selections were revalidated against their complete unchanged
program and wrapper bytes, exact invocation lines and actual registry node IDs.
There are 108 distinct programs and 11 wrappers. Every selected identity was
recounted, totaling 2,115 declared methods. The complete selection arrays, skip
guards and inline stderr specifications are unchanged. This is exact reuse of
source-bound selections, including generated suites, after proving the complete
source delta; no new execution or inferred selection is claimed. The source
closure was rehashed and includes the repaired fixture identity.

All 30 output-role source files, pending source pins and six historical source
members were checked. Every semantic output-role value is unchanged. The
diagnostic catalog's exact source files are unchanged; its current source identity,
profile digest, method references and owner frame locations were rederived. No
literal matching rule was added and no existing current reference was dropped.

## Changes and preserved predicates

`OPERATOR_DIFF.patch` compares the 22 actual files to the immutable pre-decision
operator, not to issued decision files. Fourteen files change through source,
profile, branch, author and dependent digest bindings; eight remain byte-identical.

Every Python function and class body is byte-identical to the starting operator.
The verifier also masks only an explicitly enumerated set of top-level identity
and digest constants and requires all remaining source bytes to match. In
particular, these complete files are unchanged:

- `finite_relation.py`
- `full_stdout.py`
- `full_output_relation.py`
- `pending_relation.py`
- `full_evidence.py`
- `host_utility.py`
- `stdout_location.py`
- `pair_diagnostics.py`

The inherited 13 finite rules and six narrowings are preserved. All 11 additional
rules, the full applicability conditions, runtime source predicate, resource
policy, observable frontier and nonclaims are unchanged. Complete successful
legacy and DAG routes, original raw receiving and every full relation scope
remain required. Original whole stdout differences have not been explained away.

The workflow differs only in the exact branch, source commit and all 17 adapter
digest occurrences. Its 14 conditional guards and three direct guards remain
unchanged in form and placement. Creation-only routing, attempt 1, the sole source
parent guard, read-only contents permission, Ubuntu 26.04 and the 350-minute job
timeout are preserved.

The operation retains 19,800 seconds overall, 14,400 seconds for the pair, 300 for
receiving, a nonextendable 3,600-second live review hold, 180 for closing readback,
and 600 for setup. The 18,480-second minimum before the pair, all raw/private/public
bounds and separate original product limits remain intact. Local source checks do
not discharge hosted runtime or live currentness requirements.

## Authorship and decisions

The proposed policy and current author constants identify `/root/recover_v03`.
Both actual decision validators preserve all earlier author exclusions and append
this author. The current author cannot serve as independent code reviewer or
independent live proof reviewer. Root remains the separate `/root` decision
identity. Historical authors remain only historical provenance or exclusion data.

The candidate contains no `dg16-r5-full-g2-decisions` directory, review record,
Root adoption, grant or consumption record. The actual adapter's policy-adoption
reader refuses because the required independent review file is absent. No review
or Root record was manufactured for a positive fixture.

## Verification performed

Run once on the frozen files for an independently repeatable local check:

```bash
python3 -B /workspace/scratch/ac0b432d8253/v03-corrected-source-preparation/verify_operator.py
```

The completed local check verifies every source and operator member, exact Git
tree population, the complete dependent pin chain, the actual closed relation
loader, source manifest reader and the unmodified physical source-census consumer.
The latter received one real, complete, isolated source copy; that copy was
removed afterwards. It also compiles all 15 Python modules without executing
their mains, checks all 17 workflow shell blocks with `bash -n`, checks the exact
intended diffs for whitespace errors, proves decisions absent, verifies author
exclusion and checks the final worktree status.

`VERIFICATION.json` is a local assembly result with no acceptance authority.
`SOURCE_GATE_PREPARATION.json` binds the actual physical source-census result.
`PROTECTED_FUNCTIONS.json` retains every exact function/class descriptor.

Two local helper-check defects were caught and corrected before the final result:
the distinction between 14 conditional guards and 17 total pins, and `git diff
--no-index --check` returning 1 for an intended nonempty diff with no whitespace
diagnostics. These changed only preparation checks. Their failed occurrences and
subsequent evidence remain in `LOCAL_ASSEMBLY_OCCURRENCES.json`.

The initial worktree creation failed because the filesystem had only 1.5 MiB
available. Git removed its incomplete checkout. Root then removed four verified
clean, reproducible historical worktrees while preserving their Git objects and
sibling evidence. The same authorized checkout succeeded after actual capacity
changed. `STORAGE_ANDON.json` preserves the failure; no existing resource was
removed by this lane.

## Remaining owner actions

1. A fresh independent reviewer must inspect this exact sealed packet, actual
   source, preserved comparisons, whole pin chain and authentic authorship. The
   reviewer returns findings and its own honest disposition. This author supplies
   neither an independent PASS nor readiness authority.
2. Root may then issue its actual exact pre-run adoption using the six bindings
   above and the review/seal digests. Root composes the reviewed 22 files plus
   precisely the two actual decision files, with sole parent `84ed2972...`.
3. Verify that final commit's exact tree and decisions, perform the complete live
   ref/ancestry census and branch/run absence checks, and make any authorized
   one-use disposition bind that final commit. No final commit SHA exists in this
   preparation. Proposed branch freshness was not asserted from local evidence.
4. Before launch, assign a different actual independent live reviewer and bind
   the receiver to this new candidate, source and eventual final commit. The
   historical `v03-resumption` receiver evidence and `540a12c1` run stay historical;
   their bindings cannot receive this successor. The live control branch, exact
   request/proof/private-observation hashes, 4,096-byte records, fixed hold and
   closing readback remain required by the actual unchanged consumers.

No protected full verifier, provider operation, workflow trigger, remote ref,
commit, push, cancellation, rerun or controller transition was performed. The
original DG16 criterion remains unqualified by this preparation. The source
repair addresses the observed early builder-identity refusal; actual full
correspondence remains a future observation with the original comparison intact.

## Resource disposition

Only this preparation root and its registered detached worktree are owned by this
lane. The worktree and frozen reports remain present for review. No temporary
physical source copy, running process or monitor remains. Root decides later
retention or cleanup. No `AGENTS.md` change is warranted by this exact rebind;
the existing source, pin and review rules already govern it.

Disposition: `PREPARATION_FINAL_PENDING_FRESH_INDEPENDENT_REVIEW_AND_ROOT_ACTIONS`.
