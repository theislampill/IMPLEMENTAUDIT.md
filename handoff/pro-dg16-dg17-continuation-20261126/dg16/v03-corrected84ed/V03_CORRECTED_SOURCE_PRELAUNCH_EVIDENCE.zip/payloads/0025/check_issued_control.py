#!/usr/bin/env python3
"""Check already-issued live records with the actual consumer and real UTC time.

This is a local data check, not a fresh provider observation, Root issuance,
publication or currentness authority. Root must separately refresh actual live
provider status immediately before publication. No record is generated here.
"""
import argparse
import json
from pathlib import Path
import sys
import time
from types import SimpleNamespace

sys.dont_write_bytecode = True
import bind_final as bound
import receive_public_artifact as receive


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binding',required=True)
    parser.add_argument('--run-id',required=True,type=int)
    parser.add_argument('--review-zip',required=True)
    parser.add_argument('--live-receipt',required=True)
    parser.add_argument('--issued-records',required=True)
    parser.add_argument('--out',required=True)
    args = parser.parse_args()
    binding = bound.load_binding(args.binding)
    receive.TREE = binding['workflow_tree']
    receive.ADOPTION = binding['Root_policy_adoption']['sha256']
    utility, _, full = receive.consumers()
    archive = receive.archive(args.review_zip,True,utility)
    request, proof = receive.request(archive['files'],SimpleNamespace(
        run_id=args.run_id,workflow_commit=binding['workflow_commit']),full,True)
    receipt = bound.strict(bound.checked(args.live_receipt,65536))
    bound.need(receipt['status'] == 'ACTUAL_REVIEW_PACKET_STRUCTURALLY_VALID_WHILE_JOB_LIVE' and
        receipt['run_id'] == args.run_id and receipt['workflow_commit'] == binding['workflow_commit'] and
        receipt['final_binding'] == bound.desc(bound.checked(args.binding,65536)) and
        receipt['artifact'] == archive['zip'] and receipt['request'] == bound.desc(archive['files']['REQUEST.json']) and
        receipt['proof'] == bound.desc(archive['files']['PROOF.json']) and
        receipt['receiver'] == binding['independent_live_reviewer'] and
        receipt['provider_digest_verified'] is True and receipt['decisions_issued'] == [], 'ACTUAL_LIVE_RECEIPT_BINDING')
    gate = bound.consumer('live_control.py')
    directory = Path(args.issued_records).absolute()
    bound.need(directory.resolve(strict=True) == directory and directory.is_dir() and not directory.is_symlink(),
               'ISSUED_CONTROL_DIRECTORY')
    names = {path.name for path in directory.iterdir()}
    bound.need(names in ({'CONTROL.json'},set(gate.NAMES)), 'ISSUED_CONTROL_POPULATION')
    payload = {name:bound.checked(directory/name,4096) for name in names}
    observed = time.time()
    result = gate.validate(payload,archive['files']['REQUEST.json'],now=observed)
    if result['decision'] == 'CONSUME':
        bound.need(result['independent_reviewer'] == binding['independent_live_reviewer'], 'APPOINTED_LIVE_REVIEWER_MISMATCH')
    value = {'schema':'dg16.v03-issued-live-control-readback.v1','authority':'NONE',
        'status':'SUPPLIED_ISSUED_RECORDS_VALID_WITHIN_REQUEST_WINDOW_NO_PUBLICATION',
        'workflow_commit':binding['workflow_commit'],'run_id':args.run_id,
        'request':bound.desc(archive['files']['REQUEST.json']),
        'proof':bound.desc(archive['files']['PROOF.json']),
        'private_observations':proof['private_observations'],
        'observed_utc_epoch':observed,'expires_utc_epoch':request['expires_utc_epoch'],
        'payload':{name:bound.desc(raw) for name,raw in sorted(payload.items())},'actual_consumer_result':result,
        'requires_fresh_live_provider_readback_before_publication':True,
        'provider_observation_performed':False,'decisions_issued':[],'published':False,'original_acceptance':False}
    bound.need(Path(args.out).absolute().parent == bound.RUNTIME, 'OWNED_RUNTIME_OUTPUT_DIRECTORY_REQUIRED')
    bound.write_evidence(args.out,value)
    print(json.dumps({'status':value['status'],'receipt':bound.desc(bound.encode(value)),'decisions_issued':[]}))


if __name__ == '__main__':
    raise SystemExit(main())
