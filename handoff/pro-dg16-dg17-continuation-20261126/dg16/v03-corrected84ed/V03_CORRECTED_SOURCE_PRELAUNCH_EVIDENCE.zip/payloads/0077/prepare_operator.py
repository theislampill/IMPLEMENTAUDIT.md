#!/usr/bin/env python3
"""Prepare an exact corrected-source operator; no decisions or execution.

The only writes are new files beneath this preparation root, including the
already-delegated isolated worktree. Git object and source reads are immutable.
"""
import ast
import copy
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import types

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/cca101c63aff/repository')
CANDIDATE = ROOT / 'candidate'
Q = CANDIDATE / 'qualification/dg16-r5-full-g2'
SOURCE = '84ed2972d370f6c34100d48657f0c96a570e0b49'
SOURCE_TREE = '53ad93aa1a94c324340f2de7ee2ba272c74fc57e'
PRIOR_SOURCE = '540a12c1385fabc3170745103dd0ccb5ba8c9063'
PRIOR_TREE = '1839064374ba7a064a09db12123093a608596ecc'
PRIOR_OPERATOR = 'fdcc7c1cce85350036db9d4674e27491b0ba5d3d'
BRANCH = 'engineering/pro-dg16-v03-current84ed-20261126-02'
PRIOR_BRANCH = 'engineering/pro-dg16-v03-current540-20261126-01'
AUTHOR = '/root/recover_v03'
WORKFLOW = '.github/workflows/dg16-r5-full-g2.yml'
PREFIX = 'qualification/dg16-r5-full-g2/'


def git(*args, directory=REPO):
    return subprocess.check_output(['git', '-C', str(directory), *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def desc(raw):
    return dict(bytes=len(raw), sha256=sha(raw))


def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def write_new(path, raw, mode=0o644):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        info = path.lstat()
        assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and not path.is_symlink()
        assert path.read_bytes() == raw and info.st_mode & 0o777 == mode, str(path)
        return
    with path.open('xb') as stream:
        stream.write(raw)
    path.chmod(mode)


def document(path, value):
    write_new(path, encode(value))


def read(revision, name):
    return git('show', revision + ':' + name)


def stamp(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_nlink,
            info.st_uid, info.st_gid, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def literal_constants(raw):
    result = {}
    for node in ast.parse(raw).body:
        if isinstance(node, ast.Assign):
            try:
                value = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                continue
            for target in node.targets:
                if isinstance(target, ast.Name):
                    result[target.id] = value
    return result


def set_constant(name, key, value):
    raw = current[name].decode()
    pattern = r'(?m)^' + re.escape(key) + r'\s*=\s*[^\n]+'
    assert len(re.findall(pattern, raw)) == 1, (name, key)
    current[name] = re.sub(pattern, key + ' = ' + repr(value), raw).encode()


def pin(name):
    return sha(current[name])


assert git('rev-parse', SOURCE + '^{tree}').decode().strip() == SOURCE_TREE
assert git('show', '-s', '--format=%P', SOURCE).decode().strip() == PRIOR_SOURCE
assert git('rev-parse', 'HEAD', directory=CANDIDATE).decode().strip() == SOURCE
assert git('status', '--porcelain=v1', directory=CANDIDATE) == b''
assert not Q.exists()
assert not (CANDIDATE / 'qualification/dg16-r5-full-g2-decisions').exists()
assert git('diff', '--name-status', PRIOR_SOURCE, SOURCE) == b'M\tfixtures/semantic-preservation/cases.json\n'

operator_names = git('diff', '--name-only', PRIOR_SOURCE, PRIOR_OPERATOR).decode().splitlines()
assert len(operator_names) == 22 and WORKFLOW in operator_names
assert all(name.startswith(PREFIX) or name == WORKFLOW for name in operator_names)
old_files = {name: read(PRIOR_OPERATOR, name) for name in operator_names}
old = {name.removeprefix(PREFIX): raw for name, raw in old_files.items() if name.startswith(PREFIX)}
current = dict(old)
old_manifest = json.loads(old['SOURCE_MANIFEST.json'])
old_members = {row['path']: row for row in old_manifest['members']}
assert (old_manifest['commit'], old_manifest['tree']) == (PRIOR_SOURCE, PRIOR_TREE)

# Derive the complete source manifest directly from the source Git tree and
# verify both Git object framing and the actual isolated physical checkout.
rows, buffers, bookends = [], {}, []
process = subprocess.Popen(['git', '-C', str(REPO), 'cat-file', '--batch'],
                           stdin=subprocess.PIPE, stdout=subprocess.PIPE)
try:
    for item in git('ls-tree', '-r', '-z', SOURCE).split(b'\0'):
        if not item:
            continue
        header, name = item.split(b'\t', 1)
        mode, kind, oid = header.decode().split()
        name = name.decode()
        assert kind == 'blob' and mode in ('100644', '100755')
        process.stdin.write((oid + '\n').encode())
        process.stdin.flush()
        actual, kind, size = process.stdout.readline().decode().split()
        assert actual == oid and kind == 'blob'
        raw = process.stdout.read(int(size))
        assert len(raw) == int(size) and process.stdout.read(1) == b'\n'
        assert blob(raw) == oid
        row = dict(path=name, mode=mode, git_blob=oid, **desc(raw))
        path = CANDIDATE / name
        before = path.lstat()
        observed = path.read_bytes()
        after = path.lstat()
        assert stamp(before) == stamp(after) and stat.S_ISREG(before.st_mode)
        assert before.st_nlink == 1 and not path.is_symlink()
        assert before.st_mode & 0o777 == int(mode, 8) & 0o777
        assert observed == raw
        rows.append(row)
        buffers[name] = raw
        bookends.append([name, mode, len(raw), sha(raw)])
finally:
    process.stdin.close()
    assert process.wait(timeout=10) == 0
members = {row['path']: row for row in rows}
manifest = dict(old_manifest, commit=SOURCE, tree=SOURCE_TREE, file_count=len(rows),
                total_bytes=sum(row['bytes'] for row in rows), members=rows)
assert (manifest['file_count'], manifest['total_bytes']) == (1989, 175634600)
delta = [dict(path=name, before=old_members.get(name), after=members.get(name))
         for name in sorted(set(old_members) | set(members))
         if old_members.get(name) != members.get(name)]
assert len(delta) == 1 and delta[0]['path'] == 'fixtures/semantic-preservation/cases.json'
cases = json.loads(buffers[delta[0]['path']])
builder = cases['package_evidence']['builder_path']
assert builder == 'scripts/package-contract.py'
assert cases['package_evidence']['builder_sha256'] == sha(buffers[builder])
baseline = dict(schema='dg16.corrected-source-preparation.baseline.v1', authority='NONE', author=AUTHOR,
                source_commit=SOURCE, source_tree=SOURCE_TREE, sole_parent=PRIOR_SOURCE,
                operator_starting_data=PRIOR_OPERATOR, initial_worktree_clean=True,
                source_delta=delta, source_files=len(rows), source_bytes=manifest['total_bytes'],
                source_physical_bookends=desc(encode(bookends)),
                fixture_builder_identity=desc(buffers[builder]),
                source_fixture_pin_matches_actual_builder=True,
                operator_starting_files=[dict(path=name, **desc(raw)) for name, raw in old_files.items()],
                effects=dict(protected_verifier=0, hosted_operation=0, decisions=0))
document(ROOT / 'BASELINE.json', baseline)
current['SOURCE_MANIFEST.json'] = encode(manifest)

# The maintained compiler is a pure derivation; no verifier or test is run.
compiler_path = 'skills/implementaudit/scripts/compile-work-graph.py'
compiler = types.ModuleType('exact_84ed_static_compiler')
compiler.__file__ = str(CANDIDATE / compiler_path)
exec(compile(buffers[compiler_path], compiler.__file__, 'exec'), compiler.__dict__)
registry = buffers['scripts/verify-package.sh']
physical = sorted(name for name in members if re.fullmatch(r'tests/[^/]+\.test\.sh', name))
registered = compiler.verifier_registered_tests_v1(registry)
assert registered == physical
mapping = compiler.compile_verifier_graph_v1(registry, physical,
               {'qualification': 'STATIC_SOURCE_DERIVATION_NOT_EXECUTION'})
commands = compiler.verifier_command_stream_v1(mapping, registry)
assert b''.join(node['source'].encode() for node in mapping['nodes']) == registry
assert (len(mapping['nodes']), len(registered)) == (119, 91)
assert sha(commands) == 'de2ef1f15fd8e115cc61523feafd87e42a353ce277861ab2d08d0c033b8b950d'
document(ROOT / 'derivation/STATIC_MAPPING.json', mapping)
write_new(ROOT / 'derivation/commands.bin', commands)

# Revalidate every frozen selection against its complete identical source
# program and shell wrapper. This is exact source-byte reuse of the reviewed
# selections, including generated/additive suites, not a new execution claim.
# The sole changed input is a builder identity in fixture data, not a selector,
# report emitter, method definition, skip guard, loader, or report formatter.
old_slots = json.loads(old['REPORT_SLOTS.json'])
slots = copy.deepcopy(old_slots)
slots.update(source_commit=SOURCE, source_tree=SOURCE_TREE)
selection_checks = []
assert slots['registry_sha256'] == sha(registry)
assert [row['ordinal'] for row in slots['slots']] == list(range(len(slots['slots'])))
for slot in slots['slots']:
    program, wrapper = slot['program'], slot['wrapper']
    assert members[program] == old_members[program]
    assert members[wrapper] == old_members[wrapper]
    assert buffers[wrapper].decode().splitlines()[slot['line'] - 1].strip() == slot['invocation']
    assert slot['registry_node'] in {node['id'] for node in mapping['nodes']}
    assert slot['test_count'] == len(slot['tests'])
    assert len({test['id'] for test in slot['tests']}) == len(slot['tests'])
    for test in slot['tests']:
        assert test['printed_identity'] == test['id'].split('.')[-1] + ' (' + test['id'] + ')'
    selection_checks.append(dict(ordinal=slot['ordinal'], program=program, wrapper=wrapper,
        program_source=desc(buffers[program]), wrapper_source=desc(buffers[wrapper]),
        selection=slot['derivation'], invocation_line=slot['line'],
        selected_methods=len(slot['tests']),
        exact_complete_source_and_selection_equal_to_reviewed_predecessor=True))
    for group in slot.get('source_class_groups', []):
        guard = group['skip_guard']
        if guard is not None:
            name = guard['source_path']
            assert members[name] == old_members[name]
            assert guard['source'] == desc(buffers[name])
    for row in slot.get('source_inline_stderr', []):
        assert members[row['source_path']] == old_members[row['source_path']]
        assert row['source'] == desc(buffers[row['source_path']])
slots['source_closure'] = {name: {key: members[name][key] for key in ('bytes', 'sha256', 'mode')}
                          for name in sorted(old_slots['source_closure'])}
assert slots['slots'] == old_slots['slots']
assert (slots['slot_count'], len(slots['slots']), sum(row['test_count'] for row in slots['slots'])) == (112, 112, 2115)
current['REPORT_SLOTS.json'] = encode(slots)

old_roles = json.loads(old['OUTPUT_ROLES.json'])
roles = copy.deepcopy(old_roles)
roles.update(source_commit=SOURCE, source_tree=SOURCE_TREE)
roles['source_files'] = {name: {key: members[name][key] for key in ('bytes', 'sha256', 'mode')}
                        for name in old_roles['source_files']}
assert roles['source_files'] == old_roles['source_files']
for name, digest in roles['pending_source_pins'].items():
    assert members[name]['sha256'] == digest
history = json.loads(buffers['test-support/work-graph-registry/original117-manifest.json'])
for name, size, digest, mode in roles['historical_composition_sources']:
    row = history['files']['skills/implementaudit/scripts/' + name]
    raw = buffers['test-support/work-graph-registry/' + row['specimen']]
    assert (len(raw), sha(raw), int(row['mode'], 8) if isinstance(row['mode'], str) else row['mode']) == (size, digest, mode)
current['OUTPUT_ROLES.json'] = encode(roles)

old_catalog = json.loads(old['CAPTURE_DIAGNOSTIC_CATALOG.json'])
catalog = copy.deepcopy(old_catalog)
catalog.update(source_commit=SOURCE, source_tree=SOURCE_TREE,
               owner_sha256=members['scripts/qualify-work-graph-verifier.py']['sha256'],
               report_slots_sha256=pin('REPORT_SLOTS.json'))
for row in catalog['files']:
    name = row['path']
    assert members[name] == old_members[name]
    row.update(**desc(buffers[name]), lines=len(buffers[name].splitlines()))
names = {}
for slot in slots['slots']:
    for ordinal, test in enumerate(slot['tests']):
        raw = test['printed_identity'].encode()
        names.setdefault((len(raw), sha(raw)), []).append([slot['ordinal'], ordinal])
catalog['tests'] = [dict(id=f'T{index:06d}', bytes=key[0], sha256=key[1], references=refs)
                    for index, (key, refs) in enumerate(sorted(names.items(), key=lambda row: row[0][1]))]
assert catalog['tests'] == old_catalog['tests']
owner_ast = ast.parse(buffers['scripts/qualify-work-graph-verifier.py'])
owner_functions = {node.name: node for node in owner_ast.body if isinstance(node, ast.FunctionDef)}
for cls in (node for node in owner_ast.body if isinstance(node, ast.ClassDef)):
    owner_functions.update({cls.name + '.' + node.name: node for node in cls.body if isinstance(node, ast.FunctionDef)})
for site in catalog['owner_frames'] + catalog['observation_calls']:
    node = owner_functions[site['name']]
    site.update(first=min([node.lineno] + [d.lineno for d in node.decorator_list]), last=node.end_lineno)
catalog['current_source_catalog_rebinding'] = dict(changed_line_references_not_reused=0,
    complete_raw_stream_custody_unchanged=True, new_literal_patterns_added=0,
    unknowns_still_hashed_and_raw_private_streams_retained=True)
current['CAPTURE_DIAGNOSTIC_CATALOG.json'] = (
    json.dumps(catalog, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()

derivation = dict(schema='dg16.corrected-source-static-profile-derivation.v1', authority='NONE', author=AUTHOR,
    source_commit=SOURCE, source_tree=SOURCE_TREE, predecessor_source_commit=PRIOR_SOURCE,
    predecessor_operator_commit=PRIOR_OPERATOR, source_files=len(rows), source_bytes=manifest['total_bytes'],
    source_delta=delta,
    registry=dict(**desc(registry), mapped_nodes=len(mapping['nodes']), registered_tests=len(registered),
        physical_registration_equal=True, complete_registry_bytes_reassembled=True,
        command_stream=desc(commands), derivation='EXACT_CURRENT_MAINTAINED_PURE_COMPILER', execution=False),
    report_slots=dict(slot_count=len(slots['slots']), declared_methods=sum(len(x['tests']) for x in slots['slots']),
        programs=len({x['program'] for x in slots['slots']}), wrappers=len({x['wrapper'] for x in slots['slots']}),
        source_closure_count=len(slots['source_closure']), complete_source_selections=selection_checks,
        selection_body_bytes_unchanged=True, all_skip_guards_and_inline_stderr_unchanged=True,
        rederivation_basis='All frozen selections rebound only after exact complete program/wrapper identity and complete source-tree delta checks; source closure digests rederived. Counts recounted from all exact selected identities. No runtime execution or new selection inference.',
        source_closure_changes=[dict(path=name, before=old_slots['source_closure'][name], after=slots['source_closure'][name])
            for name in slots['source_closure'] if old_slots['source_closure'][name] != slots['source_closure'][name]]),
    output_roles=dict(source_files=len(roles['source_files']), exact_source_files_unchanged=True,
        all_semantic_values_unchanged=True, all_pending_source_pins_rederived=True,
        historical_six_members_rederived=True),
    catalog=dict(files=len(catalog['files']), tests=len(catalog['tests']), literals=len(catalog['literals']),
        prefixes=len(catalog['prefixes']), owner_frames_rederived=True,
        exact_catalog_sources_unchanged=True, new_literal_patterns_added=0, removed_references=0),
    execution_performed=False, source_test_assertions_modified=False)
document(ROOT / 'derivation/DERIVATION.json', derivation)

# Bind only identities and downstream digest constants. Every function body in
# every Python operator must remain byte-identical to the starting data.
for name in ('run.py', 'pair_driver.py', 'capture_evidence.py'):
    set_constant(name, 'SOURCE_COMMIT', SOURCE)
    set_constant(name, 'SOURCE_TREE', SOURCE_TREE)
set_constant('checkout_prepare.py', 'SOURCE_COMMIT', SOURCE)
set_constant('run.py', 'BRANCH', BRANCH)
set_constant('live_control.py', 'CONTROL_BRANCH', BRANCH + '-control')
for name in ('policy_control.py', 'live_control.py'):
    constants = literal_constants(old[name])
    assert AUTHOR not in constants['CURRENT_AUTHORS']
    set_constant(name, 'CURRENT_AUTHORS', constants['CURRENT_AUTHORS'] + (AUTHOR,))
    set_constant(name, 'AUTHOR', AUTHOR)
    set_constant(name, 'ADAPTER_AUTHOR', AUTHOR)
set_constant('capture_evidence.py', 'CATALOG_SHA', pin('CAPTURE_DIAGNOSTIC_CATALOG.json'))
set_constant('full_relation.py', 'REPORT_PROFILE_SHA', pin('REPORT_SLOTS.json'))
set_constant('full_relation.py', 'REPORT_PROFILE_BYTES', len(current['REPORT_SLOTS.json']))
set_constant('full_relation.py', 'ROLE_PROFILE_SHA', pin('OUTPUT_ROLES.json'))
inputs = json.loads(old['RELATION_INPUTS.json'])
inputs.update(source_commit=SOURCE, source_tree=SOURCE_TREE)
inputs['files'] = {name: desc(current[name]) for name in inputs['files']}
current['RELATION_INPUTS.json'] = encode(inputs)
prior_policy = json.loads(old['POLICY.json'])
policy = copy.deepcopy(prior_policy)
policy.update(author=AUTHOR, source_commit=SOURCE, source_tree=SOURCE_TREE,
    status='PROPOSED_CORRECTED_SOURCE_REBIND_REQUIRES_FRESH_INDEPENDENT_REVIEW_AND_ROOT_ADOPTION',
    receiver_inputs_sha256=pin('RELATION_INPUTS.json'), full_receiver_sha256=pin('full_relation.py'))
policy['successor_rebinding'] = dict(authority='NONE', rebinding_author=AUTHOR,
    predecessor_source_commit=PRIOR_SOURCE, predecessor_policy_sha256=sha(old['POLICY.json']),
    historical_rebinding=prior_policy['successor_rebinding'], current_source_commit=SOURCE, current_source_tree=SOURCE_TREE,
    count_provenance='Actual exact-source pure compiler, complete unchanged program/wrapper selection bindings and recounted 112 slots / 2115 declared methods; only the source fixture builder digest changed.',
    derivation_sha256=sha(encode(derivation)),
    rule_text_changed='None. Every finite and new normalization rule, protected semantic assertion, allocation relation and timing relation is unchanged.',
    requires='Fresh independent immutable code/policy review and actual Root pre-run adoption for one new corrected-source operation.',
    scope='Preparation only; no run, review decision, adoption, grant or execution credit.')
assert policy['inherited_finite_adoption'] == prior_policy['inherited_finite_adoption']
assert policy['new_rules'] == prior_policy['new_rules']
assert policy['resource_policy'] == prior_policy['resource_policy']
assert policy['full_applicability'] == prior_policy['full_applicability']
current['POLICY.json'] = encode(policy)
for name in ('pair_driver.py', 'run.py'):
    for constant, member in (
        ('DIAGNOSTICS_SHA', 'pair_diagnostics.py'), ('FULL_RELATION_SHA', 'full_relation.py'),
        ('RELATION_INPUTS_SHA', 'RELATION_INPUTS.json'), ('POLICY_SHA', 'POLICY.json'),
        ('POLICY_CONTROL_SHA', 'policy_control.py'), ('CHECKOUT_PREPARE_SHA', 'checkout_prepare.py'),
        ('CAPTURE_EVIDENCE_SHA', 'capture_evidence.py')):
        set_constant(name, constant, pin(member))
set_constant('run.py', 'MANIFEST_SHA', pin('SOURCE_MANIFEST.json'))
set_constant('run.py', 'LIVE_CONTROL_SHA', pin('live_control.py'))
set_constant('run.py', 'PAIR_DRIVER_SHA', pin('pair_driver.py'))
workflow = old_files[WORKFLOW].decode()
assert workflow.count(PRIOR_BRANCH) == 2 and workflow.count(PRIOR_SOURCE) == 2
workflow = workflow.replace(PRIOR_BRANCH, BRANCH).replace(PRIOR_SOURCE, SOURCE)
guarded = re.findall(r"if \[\[ \"\$actual\" != '([0-9a-f]{64})' \]\]; then", workflow)
direct = re.findall(r"\[\[ \"\$actual\" == '([0-9a-f]{64})' \]\] \|\| exit 1", workflow)
assert len(guarded) == 14 and len(direct) == 3 and set(guarded + direct) == {sha(old['run.py'])}
assert workflow.count(sha(old['run.py'])) == len(guarded) + len(direct) == 17
workflow = workflow.replace(guarded[0], pin('run.py')).encode()

def functions(raw):
    text = raw.decode()
    return {node.name: ast.get_source_segment(text, node).encode()
            for node in ast.parse(text).body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}

preserved = {}
for name in current:
    if name.endswith('.py'):
        assert functions(current[name]) == functions(old[name]), name
        preserved[name] = {key: desc(raw) for key, raw in functions(current[name]).items()}
for name in ('finite_relation.py', 'full_stdout.py', 'full_output_relation.py',
             'pending_relation.py', 'full_evidence.py', 'host_utility.py', 'stdout_location.py', 'pair_diagnostics.py'):
    assert current[name] == old[name], name

# Materialize only after the full in-memory derivation and preservation checks.
for name, raw in current.items():
    mode = int(git('ls-tree', PRIOR_OPERATOR, PREFIX + name).decode().split()[0], 8) & 0o777
    write_new(Q / name, raw, mode)
write_new(CANDIDATE / WORKFLOW, workflow)
all_files = {PREFIX + name: raw for name, raw in current.items()}
all_files[WORKFLOW] = workflow
diff = ''.join(''.join(difflib.unified_diff(old_files[name].decode().splitlines(True),
                    all_files[name].decode().splitlines(True), fromfile='a/' + name, tofile='b/' + name))
               for name in sorted(all_files))
write_new(ROOT / 'OPERATOR_DIFF.patch', diff.encode())
write_new(ROOT / 'PRODUCT_REPAIR.patch', git('diff', '--binary', PRIOR_SOURCE, SOURCE))
document(ROOT / 'PROTECTED_FUNCTIONS.json', dict(schema='dg16.operator-function-preservation.v1',
    authority='NONE', predecessor_operator_commit=PRIOR_OPERATOR,
    all_top_level_functions_and_classes_byte_identical=True, files=preserved))
bindings = dict(source_commit=SOURCE, source_tree=SOURCE_TREE, policy_sha256=pin('POLICY.json'),
    receiver_inputs_sha256=pin('RELATION_INPUTS.json'), adapter_sha256=pin('run.py'),
    pair_driver_sha256=pin('pair_driver.py'))
packet = dict(schema='dg16.corrected-source-prepared-operator.v1', authority='NONE', author=AUTHOR,
    report_state='PARTIAL', branch=BRANCH, control_branch=BRANCH + '-control',
    required_sole_parent=SOURCE, source_tree=SOURCE_TREE, predecessor_operator_commit=PRIOR_OPERATOR,
    bindings=bindings, files=[dict(path=name, mode='100755' if (CANDIDATE/name).stat().st_mode & 0o111 else '100644',
                                  git_blob=blob(raw), **desc(raw)) for name, raw in sorted(all_files.items())],
    static_derivation=desc(encode(derivation)), protected_function_report=desc((ROOT/'PROTECTED_FUNCTIONS.json').read_bytes()),
    decisions_issued=[], decision_files_present=False, operation_launched=False, protected_verifier_runs=0,
    requires=['Fresh independent review of this exact candidate', 'Root exact policy adoption',
              'Root final composition and live launch preflight', 'Separate exact one-use Root operation disposition'],
    live_reviewer_constraint='Current author /root/recover_v03 is excluded from code and live independent review by both actual validators.')
document(ROOT / 'PREPARED_OPERATOR.json', packet)
print(json.dumps(dict(bindings=bindings, source_files=len(rows), source_bytes=manifest['total_bytes'],
    mapped_nodes=len(mapping['nodes']), registered_tests=len(registered), slots=len(slots['slots']),
    declared_methods=sum(x['test_count'] for x in slots['slots']), operator_files=len(all_files),
    all_python_function_and_class_bytes_unchanged=True, decisions_issued=False), sort_keys=True))
