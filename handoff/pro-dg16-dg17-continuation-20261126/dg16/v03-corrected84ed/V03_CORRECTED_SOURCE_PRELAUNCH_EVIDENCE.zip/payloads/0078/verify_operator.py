#!/usr/bin/env python3
"""Verify the prepared files using the actual loaders and source census.

No operator main, producer, verifier pair, controller transition or decision is
invoked. The one physical source copy is owned, enumerated and removed here.
"""
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
C = ROOT / 'candidate'
Q = C / 'qualification/dg16-r5-full-g2'
REPO = Path('/workspace/scratch/cca101c63aff/repository')
OLD_WORKTREE = Path('/workspace/scratch/cca101c63aff/v03-stdout-localization/current-candidate')
SOURCE = '84ed2972d370f6c34100d48657f0c96a570e0b49'
TREE = '53ad93aa1a94c324340f2de7ee2ba272c74fc57e'
OLD_SOURCE = '540a12c1385fabc3170745103dd0ccb5ba8c9063'
OLD_OPERATOR = 'fdcc7c1cce85350036db9d4674e27491b0ba5d3d'
BRANCH = 'engineering/pro-dg16-v03-current84ed-20261126-02'
OLD_BRANCH = 'engineering/pro-dg16-v03-current540-20261126-01'
AUTHOR = '/root/recover_v03'
PREFIX = 'qualification/dg16-r5-full-g2/'
WORKFLOW = '.github/workflows/dg16-r5-full-g2.yml'


def git(*args, directory=REPO):
    return subprocess.check_output(['git', '-C', str(directory), *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def desc(raw):
    return dict(bytes=len(raw), sha256=sha(raw))


def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def write(path, value):
    raw = encode(value)
    if path.exists():
        assert path.read_bytes() == raw
        return
    with path.open('xb') as stream:
        stream.write(raw)


def old(name):
    return git('show', OLD_OPERATOR + ':' + name)


def stamp(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_nlink,
            info.st_uid, info.st_gid, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def module(path):
    spec = importlib.util.spec_from_file_location('verify_corrected_' + path.stem, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def constants(raw):
    result = {}
    for node in ast.parse(raw).body:
        if isinstance(node, ast.Assign):
            try:
                value = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                continue
            for target in node.targets:
                if isinstance(target, ast.Name):
                    result[target.id] = value
    return result


def functions(raw):
    text = raw.decode()
    return {node.name: ast.get_source_segment(text, node).encode()
            for node in ast.parse(text).body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}


def masked_constants(raw, allowed):
    lines = raw.decode().splitlines(keepends=True)
    for node in ast.parse(raw).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1:
            target = node.targets[0]
            if isinstance(target, ast.Name) and target.id in allowed:
                assert node.lineno == node.end_lineno
                lines[node.lineno - 1] = target.id + ' = EXACT_BOUND_IDENTITY_OR_DIGEST\n'
    return ''.join(lines).encode()


def tree_oid(rows):
    root = {}
    for row in rows:
        parts = row['path'].split('/')
        here = root
        for name in parts[:-1]:
            here = here.setdefault(name, {})
        assert parts[-1] not in here
        here[parts[-1]] = (row['mode'], row['git_blob'])
    def visit(directory):
        raw = b''
        for name, item in sorted(directory.items(), key=lambda pair: pair[0].encode() + (b'/' if type(pair[1]) is dict else b'')):
            mode, oid = ('40000', visit(item)) if type(item) is dict else item
            raw += mode.encode() + b' ' + name.encode() + b'\0' + bytes.fromhex(oid)
        return hashlib.sha1(b'tree ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    return visit(root)


prepared_raw = (ROOT / 'PREPARED_OPERATOR.json').read_bytes()
prepared = json.loads(prepared_raw)
assert prepared['author'] == AUTHOR and prepared['required_sole_parent'] == SOURCE
expected_paths = {row['path'] for row in prepared['files']}
assert len(expected_paths) == len(prepared['files']) == 22
assert expected_paths == set(git('diff', '--name-only', OLD_SOURCE, OLD_OPERATOR).decode().splitlines())
operator, prior = {}, {}
for row in prepared['files']:
    path = C / row['path']
    before = path.lstat()
    raw = path.read_bytes()
    assert stamp(before) == stamp(path.lstat()) and stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    assert desc(raw) == {key: row[key] for key in ('bytes', 'sha256')} and blob(raw) == row['git_blob']
    assert before.st_mode & 0o777 == int(row['mode'], 8) & 0o777
    operator[row['path']] = raw
    prior[row['path']] = old(row['path'])
    assert (OLD_WORKTREE / row['path']).read_bytes() == prior[row['path']]

manifest_raw = operator[PREFIX + 'SOURCE_MANIFEST.json']
manifest = json.loads(manifest_raw)
assert (manifest['commit'], manifest['tree']) == (SOURCE, TREE)
assert tree_oid(manifest['members']) == TREE
git_rows = git('ls-tree', '-r', '-z', SOURCE).split(b'\0')
exact_git = {}
for item in git_rows:
    if item:
        header, name = item.split(b'\t', 1)
        mode, kind, oid = header.decode().split()
        assert kind == 'blob'
        exact_git[name.decode()] = (mode, oid)
assert exact_git == {row['path']: (row['mode'], row['git_blob']) for row in manifest['members']}
source_bookends = []
for row in manifest['members']:
    path = C / row['path']
    before = path.lstat()
    raw = path.read_bytes()
    assert stamp(before) == stamp(path.lstat()) and stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    assert not path.is_symlink() and before.st_mode & 0o777 == int(row['mode'], 8) & 0o777
    assert desc(raw) == {key: row[key] for key in ('bytes', 'sha256')} and blob(raw) == row['git_blob']
    source_bookends.append([row['path'], row['mode'], len(raw), sha(raw)])
assert (len(source_bookends), sum(row[2] for row in source_bookends)) == (1989, 175634600)
assert not set(exact_git) & expected_paths

compiled = []
preserved = {}
allowed = {
    'run.py': {'SOURCE_COMMIT', 'SOURCE_TREE', 'BRANCH', 'MANIFEST_SHA', 'PAIR_DRIVER_SHA',
               'FULL_RELATION_SHA', 'RELATION_INPUTS_SHA', 'POLICY_SHA', 'POLICY_CONTROL_SHA',
               'LIVE_CONTROL_SHA', 'CHECKOUT_PREPARE_SHA', 'CAPTURE_EVIDENCE_SHA'},
    'pair_driver.py': {'SOURCE_COMMIT', 'SOURCE_TREE', 'FULL_RELATION_SHA', 'RELATION_INPUTS_SHA',
                      'POLICY_SHA', 'POLICY_CONTROL_SHA', 'CHECKOUT_PREPARE_SHA', 'CAPTURE_EVIDENCE_SHA'},
    'full_relation.py': {'REPORT_PROFILE_SHA', 'REPORT_PROFILE_BYTES', 'ROLE_PROFILE_SHA'},
    'capture_evidence.py': {'SOURCE_COMMIT', 'SOURCE_TREE', 'CATALOG_SHA'},
    'checkout_prepare.py': {'SOURCE_COMMIT'},
    'policy_control.py': {'AUTHOR', 'ADAPTER_AUTHOR', 'CURRENT_AUTHORS'},
    'live_control.py': {'AUTHOR', 'ADAPTER_AUTHOR', 'CURRENT_AUTHORS', 'CONTROL_BRANCH'},
}
for name, raw in operator.items():
    if not name.endswith('.py'):
        continue
    compile(raw, str(C/name), 'exec', dont_inherit=True)
    filename = Path(name).name
    assert masked_constants(raw, allowed.get(filename, set())) == masked_constants(prior[name], allowed.get(filename, set())), filename
    assert functions(raw) == functions(prior[name])
    compiled.append(filename)
    preserved[filename] = dict(functions_and_classes=len(functions(raw)), all_body_bytes_unchanged=True,
                               mutable_constant_names=sorted(allowed.get(filename, set())))
whole_protected = ('finite_relation.py', 'full_stdout.py', 'full_output_relation.py', 'pending_relation.py',
                   'full_evidence.py', 'host_utility.py', 'stdout_location.py', 'pair_diagnostics.py')
assert all(operator[PREFIX+name] == prior[PREFIX+name] for name in whole_protected)

run, pair, full = (module(Q/name) for name in ('run.py', 'pair_driver.py', 'full_relation.py'))
assert (run.SOURCE_COMMIT, run.SOURCE_TREE, run.BRANCH) == (SOURCE, TREE, BRANCH)
assert (pair.SOURCE_COMMIT, pair.SOURCE_TREE) == (SOURCE, TREE)
inputs = json.loads(operator[PREFIX+'RELATION_INPUTS.json'])
relation = full.load(Q, inputs, pair.adapter_module, pair.bounded_json)
assert relation['source'] == manifest
utility = run.load_utility()
actual_manifest = run.read_manifest(utility)
assert actual_manifest == {row['path']: row for row in manifest['members']}

# Required actual physical population guard. No Git metadata or operator files
# are mixed into this exact product copy. Cleanup is bounded to this own root.
with tempfile.TemporaryDirectory(prefix='physical-source-check-', dir=ROOT) as directory:
    physical = Path(directory) / 'source'
    physical.mkdir()
    for row in manifest['members']:
        target = physical / row['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(C/row['path'], target)
        target.chmod(int(row['mode'], 8) & 0o777)
    actual_census = run.verify_source(physical, actual_manifest, utility, False)
    verified_temporary_parent = directory
assert not Path(verified_temporary_parent).exists()
assert actual_census == dict(file_count=1989, total_bytes=175634600, manifest_sha256=run.MANIFEST_SHA, all_members_match=True)
source_gate = dict(schema='dg16.preparation-actual-source-gate.v1', authority='NONE', author=AUTHOR,
    scope='REAL_EXACT_PHYSICAL_SOURCE_COPY_THROUGH_UNMODIFIED_CONSUMER_NOT_HOSTED_OPERATION',
    source_commit=SOURCE, source_tree=TREE, adapter_sha256=sha(operator[PREFIX+'run.py']), observed=actual_census,
    consumer_monkeypatched=False, producer_executed=False, temporary_source_copy_removed=True)
write(ROOT/'SOURCE_GATE_PREPARATION.json', source_gate)

fixed = {'UTILITY_SHA': 'host_utility.py', 'PAIR_DRIVER_SHA': 'pair_driver.py',
    'DIAGNOSTICS_SHA': 'pair_diagnostics.py', 'FULL_RELATION_SHA': 'full_relation.py',
    'RELATION_INPUTS_SHA': 'RELATION_INPUTS.json', 'POLICY_SHA': 'POLICY.json',
    'POLICY_CONTROL_SHA': 'policy_control.py', 'LIVE_CONTROL_SHA': 'live_control.py',
    'CHECKOUT_PREPARE_SHA': 'checkout_prepare.py', 'CAPTURE_EVIDENCE_SHA': 'capture_evidence.py',
    'MANIFEST_SHA': 'SOURCE_MANIFEST.json', 'CATALOG_SHA': 'CAPTURE_DIAGNOSTIC_CATALOG.json',
    'REPORT_PROFILE_SHA': 'REPORT_SLOTS.json', 'ROLE_PROFILE_SHA': 'OUTPUT_ROLES.json',
    'STDOUT_OBSERVER_SHA': 'stdout_location.py'}
pin_graph = []
for filename in compiled:
    for key, value in constants(operator[PREFIX+filename]).items():
        if key in fixed:
            target = fixed[key]
            assert value == sha(operator[PREFIX+target]), (filename, key)
            pin_graph.append(dict(host=filename, field=key, member=target, sha256=value))
for name, row in inputs['files'].items():
    assert row == desc(operator[PREFIX+name])
    pin_graph.append(dict(host='RELATION_INPUTS.json', field='files.'+name, member=name, **row))
assert full.REPORT_PROFILE_BYTES == len(operator[PREFIX+'REPORT_SLOTS.json'])
source_pins = {row['path']: row for row in manifest['members']}
qualifier = source_pins['scripts/qualify-work-graph-verifier.py']['sha256']
assert pair.OWNER_SHA256 == qualifier
for filename in ('checkout_prepare.py', 'capture_evidence.py'):
    assert constants(operator[PREFIX+filename])['OWNER_SHA'] == qualifier
assert constants(operator[PREFIX+'checkout_prepare.py'])['COMPILER_SHA'] == source_pins['skills/implementaudit/scripts/compile-work-graph.py']['sha256']
for name, digest in full.SUCCESSOR_OWNER_PINS.items():
    assert source_pins['scripts/'+name]['sha256'] == digest
for profile, field in ((relation['slots'], 'source_closure'), (relation['roles'], 'source_files')):
    for name, row in profile[field].items():
        assert row == {key: source_pins[name][key] for key in ('bytes', 'sha256', 'mode')}
catalog = json.loads(operator[PREFIX+'CAPTURE_DIAGNOSTIC_CATALOG.json'])
assert catalog['source_commit'] == SOURCE and catalog['source_tree'] == TREE
assert catalog['report_slots_sha256'] == sha(operator[PREFIX+'REPORT_SLOTS.json']) and catalog['owner_sha256'] == qualifier
for row in catalog['files']:
    assert all(row[key] == source_pins[row['path']][key] for key in ('bytes', 'sha256'))

policy = json.loads(operator[PREFIX+'POLICY.json'])
prior_policy = json.loads(prior[PREFIX+'POLICY.json'])
assert operator[PREFIX+'POLICY.json'] == encode(policy)
assert operator[PREFIX+'RELATION_INPUTS.json'] == encode(inputs)
assert policy['author'] == AUTHOR and policy['source_commit'] == SOURCE and policy['source_tree'] == TREE
assert policy['receiver_inputs_sha256'] == run.RELATION_INPUTS_SHA and policy['full_receiver_sha256'] == run.FULL_RELATION_SHA
allowed_policy = {'author', 'source_commit', 'source_tree', 'status', 'receiver_inputs_sha256', 'full_receiver_sha256', 'successor_rebinding'}
assert {key:value for key,value in policy.items() if key not in allowed_policy} == {
    key:value for key,value in prior_policy.items() if key not in allowed_policy}
assert policy['successor_rebinding']['historical_rebinding'] == prior_policy['successor_rebinding']
assert policy['successor_rebinding']['derivation_sha256'] == sha((ROOT/'derivation/DERIVATION.json').read_bytes())
policy_gate, live_gate = module(Q/'policy_control.py'), module(Q/'live_control.py')
assert policy_gate.AUTHOR == policy_gate.ADAPTER_AUTHOR == live_gate.AUTHOR == live_gate.ADAPTER_AUTHOR == AUTHOR
assert policy_gate.CURRENT_AUTHORS == live_gate.CURRENT_AUTHORS == constants(prior[PREFIX+'policy_control.py'])['CURRENT_AUTHORS'] + (AUTHOR,)
assert not policy_gate.independent(AUTHOR) and not policy_gate.independent('/root')
assert live_gate.CONTROL_BRANCH == BRANCH + '-control'
assert not (Q.parent/'dg16-r5-full-g2-decisions').exists()
try:
    run.actual_policy_adoption(utility)
except FileNotFoundError as error:
    assert error.filename == str(Q.parent/'dg16-r5-full-g2-decisions/INDEPENDENT_COLD_REVIEW.json')
    absent_decisions_refused = True
else:
    raise AssertionError('Missing independent review and Root adoption did not refuse')

workflow = operator[WORKFLOW]
expected_workflow = prior[WORKFLOW].replace(OLD_BRANCH.encode(), BRANCH.encode()).replace(OLD_SOURCE.encode(), SOURCE.encode()).replace(
    sha(prior[PREFIX+'run.py']).encode(), sha(operator[PREFIX+'run.py']).encode())
assert workflow == expected_workflow
negative = re.findall(rb"if \[\[ \"\$actual\" != '([0-9a-f]{64})' \]\]; then", workflow)
positive = re.findall(rb"\[\[ \"\$actual\" == '([0-9a-f]{64})' \]\] \|\| exit 1", workflow)
assert (len(negative), len(positive)) == (14, 3)
assert set(negative+positive) == {sha(operator[PREFIX+'run.py']).encode()}
assert workflow.count(sha(operator[PREFIX+'run.py']).encode()) == 17
blocks = []
lines = workflow.decode().splitlines()
i = 0
while i < len(lines):
    line = lines[i]
    if line.strip() == 'run: |':
        indent = len(line)-len(line.lstrip())
        parts = []
        i += 1
        while i < len(lines) and (not lines[i].strip() or len(lines[i])-len(lines[i].lstrip()) > indent):
            parts.append(lines[i][indent+2:])
            i += 1
        blocks.append('\n'.join(parts)+'\n')
        continue
    i += 1
for block in blocks:
    checked = subprocess.run(['bash', '-n'], input=block.encode(), capture_output=True, timeout=5)
    assert checked.returncode == 0 and checked.stderr == b''
for relative in ('qualification/dg16-r5-full-g2', WORKFLOW):
    checked = subprocess.run(['git', 'diff', '--no-index', '--check', str(OLD_WORKTREE/relative), str(C/relative)],
                             capture_output=True, timeout=15)
    # --no-index implies --exit-code: both declared comparisons contain exact
    # intended changes. Exit 1 with no check diagnostics is the expected clean
    # whitespace result for those changed inputs, not an absent diff.
    assert checked.returncode == 1 and checked.stdout == checked.stderr == b'', (relative, checked.returncode)

bounds = dict(orchestration_seconds=run.RUN_SECONDS, pair_seconds=run.BANK_SECONDS,
    receiving_seconds=run.RECEIVE_SECONDS, review_seconds=run.HOLD_SECONDS,
    closing_seconds=run.FINAL_SECONDS, setup_seconds=run.SETUP_SECONDS,
    private_canonical_bytes=run.PRIVATE_CANONICAL_BYTES,
    product_C5_120_seconds_changed=policy['resource_policy']['product_C5_120_seconds_changed'],
    policy_resource_bounds=policy['resource_policy'])
assert tuple(bounds[key] for key in ('orchestration_seconds','pair_seconds','receiving_seconds','review_seconds','closing_seconds','setup_seconds')) == (19800,14400,300,3600,180,600)
assert bounds['private_canonical_bytes'] == 1024**2
assert policy['resource_policy'] == prior_policy['resource_policy']
assert run.PUBLIC_NAMES == module(Q/'host_utility.py').PUBLIC_NAMES

status = git('status', '--porcelain=v1', '--untracked-files=all', directory=C).decode().splitlines()
assert set(status) == {'?? '+path for path in expected_paths}
assert git('diff', '--name-only', directory=C) == b''
assert git('diff', '--cached', '--name-only', directory=C) == b''
assert git('rev-parse', 'HEAD', directory=C).decode().strip() == SOURCE
for row in manifest['members']:
    path = C/row['path']
    info = path.lstat()
    raw = path.read_bytes()
    assert info.st_nlink == 1 and stat.S_ISREG(info.st_mode) and not path.is_symlink()
    assert desc(raw) == {key: row[key] for key in ('bytes','sha256')} and blob(raw) == row['git_blob']
    assert info.st_mode & 0o777 == int(row['mode'],8) & 0o777
for row in prepared['files']:
    assert desc((C/row['path']).read_bytes()) == {key:row[key] for key in ('bytes','sha256')}

candidate_tree = tree_oid(manifest['members'] + prepared['files'])
file_manifest = dict(schema='dg16.corrected-source-candidate-manifest.v1', authority='NONE', author=AUTHOR,
    source_commit=SOURCE, source_tree=TREE, required_sole_parent=SOURCE,
    proposed_branch=BRANCH, proposed_control_branch=BRANCH+'-control',
    derived_predecision_tree=candidate_tree,
    tree_derivation='Git tree framing from all exact source rows and 22 actual added operator blobs; no Git object or commit created',
    product_files=1989, product_bytes=175634600, added_operator_files=prepared['files'],
    added_decision_files=[], hosted_operations=0, protected_verifier_runs=0)
write(ROOT/'CANDIDATE_FILE_MANIFEST.json', file_manifest)
result = dict(schema='dg16.corrected-source-prepared-operator-verification.v1', report_state='FINAL',
    authority='NONE', author=AUTHOR, source_commit=SOURCE, source_tree=TREE, derived_predecision_tree=candidate_tree,
    source_members=1989, source_bytes=175634600, source_bookend_census=desc(encode(source_bookends)),
    source_files_unchanged=True, exact_git_tree_manifest_and_physical_members=True,
    compiled_python_modules=compiled, immutable_python_code_except_enumerated_bindings=preserved,
    protected_whole_files={name:desc(operator[PREFIX+name]) for name in whole_protected},
    actual_closed_relation_loader_passed=True, actual_source_manifest_consumer_passed=True,
    actual_physical_source_census_consumer_passed=True, actual_source_census=actual_census,
    actual_source_census_scope=source_gate['scope'], temporary_full_source_copy_removed=True,
    complete_pin_cascade=pin_graph, all_profile_source_pins_verified=True,
    inherited_finite_adoption_unchanged=True, all_new_normalization_rules_unchanged=True,
    full_applicability_unchanged=True, source_report_slots=112, source_declared_methods=2115,
    workflow_only_exact_branch_source_and_adapter_pin_changes=True,
    workflow_adapter_pins=17, negative_guards=14, direct_guards=3,
    shell_blocks_syntax_checked=len(blocks), diff_whitespace_check_passed=True,
    prior_author_exclusions_preserved=True, current_author_excluded_from_independent_review=True,
    Root_separate_from_author=True, actual_missing_decisions_refused=absent_decisions_refused,
    exact_decision_files_absent=True, decisions_issued=False, commits_created=0,
    protected_verifier_runs=0, hosted_operations=0, public_filenames_unchanged=True,
    raw_or_normalized_windows_exported=False, bounds=bounds,
    worktree_status_exact_added_operator_files=status,
    preflight_status='LOCAL_ASSEMBLY_GREEN_REQUIRES_FRESH_INDEPENDENT_REVIEW_AND_ROOT_ACTIONS')
write(ROOT/'VERIFICATION.json', result)
print(json.dumps({key:result[key] for key in ('source_commit','derived_predecision_tree','source_members','source_bytes',
    'source_files_unchanged','actual_closed_relation_loader_passed','actual_physical_source_census_consumer_passed',
    'source_report_slots','source_declared_methods','shell_blocks_syntax_checked','actual_missing_decisions_refused',
    'current_author_excluded_from_independent_review','hosted_operations')}, sort_keys=True))
