#!/usr/bin/env python3
"""Read-only exact final-object binding; writes evidence, never a decision.

Requires the Root-specified final Git object to have been fetched separately.
No network, lazy fetch, source copy, producer or operator main is used here.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import types

sys.dont_write_bytecode = True
OWN = Path(__file__).resolve().parent.parent
RUNTIME = OWN / 'runtime'
PREPARATION = Path('/workspace/scratch/ac0b432d8253/v03-corrected-source-preparation')
OPERATOR = PREPARATION / 'candidate/qualification/dg16-r5-full-g2'
REPO = Path('/workspace/scratch/cca101c63aff/repository')
SOURCE = '84ed2972d370f6c34100d48657f0c96a570e0b49'
SOURCE_TREE = '53ad93aa1a94c324340f2de7ee2ba272c74fc57e'
PREDECISION_TREE = 'e118a03deeca1991bed708917a451365b20fa5bf'
SEAL_SHA = 'f113bae864a61c4ab1a381f876306e36f874555a740fc5da164cf496d8cf2031'
BRANCH = 'engineering/pro-dg16-v03-current84ed-20261126-02'
REPOSITORY = 'theislampill/IMPLEMENTAUDIT.md'
FINAL_COMMIT = '07c56d666919e3b741da512c23886546388aac1e'
FINAL_TREE = '48c67b0ba7ccb2bbbfd3a8515a8c314c081d8cac'
ADOPTION_SHA = '27128a0008b6725e06938c183faa66705d83f9ea5cfd2a2aea28fee5b7907065'
DECISIONS = 'qualification/dg16-r5-full-g2-decisions/'
AUTHOR = '/root/recover_v03'


class Refusal(ValueError):
    pass


def need(ok, code):
    if not ok:
        raise Refusal(code)


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def desc(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def strict(raw):
    def pairs(rows):
        value = {}
        for key, item in rows:
            need(key not in value, 'DUPLICATE_JSON_KEY')
            value[key] = item
        return value
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(Refusal('NONFINITE_JSON')))


def checked(path, limit):
    path = Path(path)
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and not path.is_symlink() and
         0 < before.st_size <= limit, 'RECEIVER_INPUT_BOUND_OR_KIND')
    raw = path.read_bytes()
    after = path.lstat()
    fields = ('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
    need(all(getattr(before,k) == getattr(after,k) for k in fields) and len(raw) == before.st_size,
         'RECEIVER_INPUT_CHANGED')
    return raw


def candidate():
    raw = checked(PREPARATION/'SEAL.json', 65536)
    need(desc(raw)['sha256'] == SEAL_SHA, 'CANDIDATE_SEAL_CHANGED')
    seal = strict(raw)
    need(seal['source_commit'] == SOURCE and seal['source_tree'] == SOURCE_TREE and
         seal['derived_predecision_tree'] == PREDECISION_TREE and seal['branch'] == BRANCH and
         len(seal['operator_files']) == 22, 'CANDIDATE_BINDING_CHANGED')
    for row in seal['operator_files']:
        path = PREPARATION/'candidate'/row['path']
        raw = checked(path, 2*1024**2)
        need(desc(raw) == {key:row[key] for key in ('bytes','sha256')} and
             path.stat().st_mode & 0o777 == int(row['mode'],8) & 0o777, 'SEALED_OPERATOR_MEMBER_CHANGED')
    return seal


def consumer(name):
    seal = candidate()
    rows = [row for row in seal['operator_files'] if row['path'] == 'qualification/dg16-r5-full-g2/'+name]
    need(len(rows) == 1, 'CONSUMER_NOT_IN_SEALED_OPERATOR')
    raw = checked(OPERATOR/name, 2*1024**2)
    need(desc(raw) == {key:rows[0][key] for key in ('bytes','sha256')}, 'REVIEWED_CONSUMER_DIGEST')
    module = types.ModuleType('bound_84ed_' + name.replace('.','_'))
    module.__file__ = str(OPERATOR/name)
    exec(compile(raw, module.__file__, 'exec'), module.__dict__)
    return module


def git(*args):
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_NO_LAZY_FETCH='1',
               GIT_NO_REPLACE_OBJECTS='1', GIT_TERMINAL_PROMPT='0')
    result = subprocess.run(['git','-c','core.fsmonitor=false','-c','core.hooksPath=/dev/null',
                             '-C',str(REPO),*args], capture_output=True, timeout=20, env=env)
    need(result.returncode == 0, 'EXACT_LOCAL_GIT_OBJECT_REQUIRED_NO_FETCH')
    need(len(result.stdout) <= 4*1024**2, 'LOCAL_GIT_READ_BOUND')
    return result.stdout


def verify_final_commit(commit, live_reviewer=None):
    need(commit == FINAL_COMMIT, 'ROOT_SPECIFIED_FINAL_COMMIT_REQUIRED')
    seal = candidate()
    need(git('show','-s','--format=%P',commit).decode().strip() == SOURCE, 'FINAL_SOLE_SOURCE_PARENT')
    need(git('rev-parse',commit+'^{tree}').decode().strip() == FINAL_TREE, 'FINAL_TREE_BINDING')
    need(git('rev-parse',SOURCE+'^{tree}').decode().strip() == SOURCE_TREE, 'PRODUCT_TREE_BINDING')
    gate = consumer('policy_control.py')
    expected = {row['path'] for row in seal['operator_files']} | {DECISIONS+name for name in gate.DECISION_FILES}
    changed = git('diff-tree','--no-commit-id','--no-renames','--name-status','-r',SOURCE,commit).decode().splitlines()
    need(set(changed) == {'A\t'+name for name in expected} and len(changed) == 24, 'EXACT_FINAL_24_ADDITIONS')
    for row in seal['operator_files']:
        raw = git('show',commit+':'+row['path'])
        entry = git('ls-tree',commit,row['path']).decode().split()
        need(entry[:3] == [row['mode'],'blob',row['git_blob']] and
             desc(raw) == {key:row[key] for key in ('bytes','sha256')}, 'FINAL_REVIEWED_MEMBER_CHANGED')
    payload = {}
    for name in gate.DECISION_FILES:
        path = DECISIONS+name
        entry = git('ls-tree',commit,path).decode().split()
        need(entry[:2] == ['100644','blob'], 'DECISION_REGULAR_BLOB_REQUIRED')
        raw = git('show',commit+':'+path)
        need(0 < len(raw) <= 65536, 'DECISION_FILE_BOUND')
        payload[name] = raw
    policy = strict(checked(OPERATOR/'POLICY.json',65536))
    readback = gate.validate(payload, seal['bindings'], policy)
    need(readback['candidate_seal_sha256'] == SEAL_SHA and
         readback['adoption_sha256'] == ADOPTION_SHA, 'ACTUAL_ROOT_ADOPTION_BINDING')
    if live_reviewer is not None:
        need(gate.independent(live_reviewer), 'INDEPENDENT_LIVE_REVIEWER_REQUIRED')
    return {'schema':'dg16.v03-final-receiver-binding.v1','authority':'NONE',
        'status':'FINAL_COMMIT_VERIFIED_LIVE_REVIEWER_PENDING' if live_reviewer is None else 'FINAL_COMMIT_AND_REVIEWER_BOUND_NOT_AUTHORIZATION',
        'repository':REPOSITORY,'branch':BRANCH,'control_branch':BRANCH+'-control',
        'source_commit':SOURCE,'source_tree':SOURCE_TREE,'predecision_tree':PREDECISION_TREE,
        'candidate_seal_sha256':SEAL_SHA,'bindings':seal['bindings'],
        'workflow_commit':commit,'workflow_tree':FINAL_TREE,
        'independent_live_reviewer':live_reviewer,
        'independent_code_review':desc(payload['INDEPENDENT_COLD_REVIEW.json']),
        'Root_policy_adoption':desc(payload['ROOT_POLICY_ADOPTION.json']),
        'actual_policy_gate':readback,'all22_reviewed_members_match':True,
        'sole_source_parent_verified':True,'only24_exact_additions':True,
        'provider_observation_performed':False,'source_copies_created':0,
        'execution_authorization':False,'decisions_issued':[],'original_acceptance':False}


def load_binding(path, require_live_reviewer=True):
    raw = checked(path,65536)
    value = strict(raw)
    need(type(value) is dict and value.get('schema') == 'dg16.v03-final-receiver-binding.v1' and
         value.get('status') in ('FINAL_COMMIT_VERIFIED_LIVE_REVIEWER_PENDING','FINAL_COMMIT_AND_REVIEWER_BOUND_NOT_AUTHORIZATION'),
         'FINAL_BINDING_NOT_READY')
    need(value == verify_final_commit(value.get('workflow_commit'), value.get('independent_live_reviewer')) and
         raw == encode(value), 'FINAL_BINDING_READBACK_CHANGED')
    if require_live_reviewer:
        need(value['independent_live_reviewer'] is not None, 'LIVE_REVIEWER_APPOINTMENT_PENDING')
    return value


def write_evidence(path, value):
    path = Path(path).absolute()
    need(path.parent in (OWN,RUNTIME) and not path.is_symlink(), 'OWNED_OUTPUT_DIRECTORY_REQUIRED')
    if path.parent == RUNTIME:
        RUNTIME.mkdir(exist_ok=True)
    need(path.parent.resolve(strict=True) == path.parent and not path.parent.is_symlink(), 'OUTPUT_DIRECTORY_CHANGED')
    with path.open('xb') as stream:
        stream.write(encode(value))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workflow-commit',required=True)
    parser.add_argument('--live-reviewer',help='Only an actually appointed independent reviewer; omission remains pending.')
    parser.add_argument('--out',required=True)
    args = parser.parse_args()
    value = verify_final_commit(args.workflow_commit,args.live_reviewer)
    write_evidence(args.out,value)
    print(json.dumps({'status':value['status'],'binding':desc(encode(value)),
                      'execution_authorization':False,'decisions_issued':[]}))


if __name__ == '__main__':
    raise SystemExit(main())
