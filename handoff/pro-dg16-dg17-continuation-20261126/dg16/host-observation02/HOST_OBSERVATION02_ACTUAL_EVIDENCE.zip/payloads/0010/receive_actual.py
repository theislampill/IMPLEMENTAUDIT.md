"""Receive one retained actual measurement; never invoke its observer or owners."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import re
import stat
import subprocess
import sys
import zipfile

OUT = Path(__file__).parent
INPUT = Path('/workspace/scratch/ac0b432d8253/host-measure-root-operation-02')
PREP = Path('/workspace/scratch/ac0b432d8253/host-measure-successor02')
REPO = Path('/workspace/scratch/cca101c63aff/repository')
REVIEW = OUT.parent / 'successor-02'
OPERATOR = '49886a1c19d92177742b4614a0f1bfe132914138'
TREE = '56f5c473369fdd774949653ce6d672278a5a50b4'
PARENT = 'e05ad38af3e1835aa8f6c000b17a98ed54454041'
SOURCE = '540a12c1385fabc3170745103dd0ccb5ba8c9063'
SOURCE_TREE = '1839064374ba7a064a09db12123093a608596ecc'
GRANT_COMMIT = 'ab4024b3501c5089d197d6a5ff0c2079ade32bcd'
GRANT_SHA = '810e212eefe7f6efd77e32b29ed1619da0bbb5de727779fc436d671ccf2af32a'
PROPOSAL_SHA = '520482259f480e65384eca173e0336555e82a9dd1004199a3009afe54c1e44a5'
ZIP_SHA = 'abe3a0000950b8edca71a66747576c6a4c894b534d73e14a514d447ba91e920d'
PUBLIC_SHA = '6be97826b93ee877f69837f66b123a41a7a451bf91dd7cbe98676742f923d729'
RUN, JOB, ARTIFACT = 45765672251, 139725875323, 15091782173
BRANCH = 'engineering/pro-dg16-host-rollover-observe-20261126-02'
WORKFLOW = '.github/workflows/dg16-host-rollover-observe.yml'
PACKET = 'qualification/dg16-r5-g1-hosted-episode-v21/packet'
GRANT_ROOT = 'handoff/pro-dg16-dg17-continuation-20261126/dg16/host-observation02'
MAXIMUM = 98304
GIT_ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True,
                       allow_nan=False) + '\n').encode('ascii')

def write_json(name, value):
    (OUT / name).write_bytes((json.dumps(value, indent=2, sort_keys=True) + '\n').encode())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, env=GIT_ENV)

def literal(raw, name):
    node = next(n.value for n in ast.parse(raw).body if isinstance(n, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id == name for t in n.targets))
    return ast.literal_eval(node)

names = ('ACTUAL_ARTIFACT.zip', 'HOST_RUNTIME.json', 'ACTUAL_PROVIDER_RECEIVING.json',
    'ACTUAL_JOB.log', 'DECODED_LOG_RESPONSE.json', 'ACTUAL_START.json',
    'ROOT_ONE_USE_OPERATION.json', 'ROOT_REVIEW_RECEIVING.json',
    'PUBLICATION_READBACK.json', 'LIVE_PREFLIGHT.json')
inputs = {name: (INPUT / name).read_bytes() for name in names}
input_manifest = [dict(path=str(INPUT / name), bytes=len(raw), sha256=sha(raw))
                  for name, raw in inputs.items()]
grant = json.loads(inputs['ROOT_ONE_USE_OPERATION.json'])
assert sha(inputs['ROOT_ONE_USE_OPERATION.json']) == GRANT_SHA
assert sha((PREP / 'PROPOSAL.json').read_bytes()) == PROPOSAL_SHA
proposal = json.loads((PREP / 'PROPOSAL.json').read_bytes())
assert sha((REVIEW / 'RECEIPT.json').read_bytes()) == grant['independent_receipt_sha256']
assert sha((REVIEW / 'MANIFEST.json').read_bytes()) == grant['independent_manifest_sha256']
assert grant['operator_commit'] == OPERATOR and grant['operator_tree'] == TREE
assert grant['sole_parent'] == PARENT and grant['source_commit'] == SOURCE
assert grant['source_tree'] == SOURCE_TREE and grant['proposal_sha256'] == PROPOSAL_SHA
assert grant['branch'] == BRANCH and grant['workflow'] == WORKFLOW
for field, name in [('live_preflight_sha256', 'LIVE_PREFLIGHT.json'),
                    ('root_candidate_receiving_sha256', 'ROOT_REVIEW_RECEIVING.json'),
                    ('final_object_readback_sha256', 'PUBLICATION_READBACK.json')]:
    assert grant[field] == sha(inputs[name])
for name in ('ROOT_ONE_USE_OPERATION.json', 'LIVE_PREFLIGHT.json',
             'PUBLICATION_READBACK.json', 'ROOT_REVIEW_RECEIVING.json'):
    assert git('show', GRANT_COMMIT + ':' + GRANT_ROOT + '/' + name) == inputs[name]
for name, local in [('PROPOSAL.json', PREP / 'PROPOSAL.json'),
                    ('INDEPENDENT_RECEIPT.json', REVIEW / 'RECEIPT.json'),
                    ('INDEPENDENT_MANIFEST.json', REVIEW / 'MANIFEST.json'),
                    ('INDEPENDENT_REVIEW.md', REVIEW / 'REVIEW.md')]:
    assert git('show', GRANT_COMMIT + ':' + GRANT_ROOT + '/' + name) == local.read_bytes()
assert git('show', '-s', '--format=%T%n%P', OPERATOR).decode().splitlines() == [TREE, PARENT]
expected_paths = sorted(row['path'] for row in proposal['files'])
assert git('diff', '--no-ext-diff', '--no-textconv', '--name-status', PARENT, OPERATOR).decode().splitlines() == [
    'A\t' + path for path in expected_paths]
published = {}
for row in proposal['files']:
    raw = git('show', OPERATOR + ':' + row['path'])
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    assert raw == (PREP / 'staging' / row['path']).read_bytes()
    published[row['path']] = raw
owners = {}
for name, pin in proposal['lower_owner_pins'].items():
    raw = git('show', OPERATOR + ':' + PACKET + '/' + name)
    assert sha(raw) == pin
    owners[name] = raw
assert git('rev-parse', SOURCE + '^{tree}').decode().strip() == SOURCE_TREE
source_manifest = json.loads(owners['SOURCE_MANIFEST.json'])
assert (source_manifest['commit'], source_manifest['tree'], source_manifest['file_count'],
        source_manifest['total_bytes']) == (SOURCE, SOURCE_TREE, 1989, 175634600)

start = json.loads(inputs['ACTUAL_START.json'])
assert start['grant_sha256'] == GRANT_SHA and start['grant_publication'] == GRANT_COMMIT
assert start['operator'] == OPERATOR and start['branch'] == BRANCH
assert start['branch_creations_spent'] == 1 and start['reruns_authorized'] is False
assert start['immediate_absence']['exit_code'] == 2 and start['immediate_absence']['output'] == ''
assert start['actual_create']['branch'] == BRANCH
preflight = json.loads(inputs['LIVE_PREFLIGHT.json'])
assert all(preflight[k]['total_count'] == 0 for k in ('queued', 'in_progress', 'host02_runs'))
assert preflight['branch_absence']['exit_code'] == 2 and preflight['branch_absence']['output'] == ''

provider = json.loads(inputs['ACTUAL_PROVIDER_RECEIVING.json'])
run = provider['run']
assert (run['id'], run['head_branch'], run['head_sha'], run['path'], run['event'],
        run['status'], run['conclusion'], run['run_attempt']) == (
        RUN, BRANCH, OPERATOR, WORKFLOW, 'push', 'completed', 'success', 1)
assert run['repository']['full_name'] == run['head_repository']['full_name'] == 'theislampill/IMPLEMENTAUDIT.md'
assert run['head_commit']['id'] == OPERATOR and run['head_commit']['tree_id'] == TREE
jobs = provider['jobs']['jobs']; assert len(jobs) == 1
job = jobs[0]
assert (job['id'], job['run_id'], job['name'], job['status'], job['conclusion']) == (
        JOB, RUN, 'observe', 'completed', 'success')
assert all(s['status'] == 'completed' and s['conclusion'] == 'success' for s in job['steps'])
workflow = json.loads(published[WORKFLOW])
step_names = [s['name'] for s in workflow['jobs']['observe']['steps']]
assert [s['name'] for s in job['steps'] if s['name'] in step_names] == step_names
artifacts = provider['artifacts']['artifacts']; assert len(artifacts) == 1
artifact = artifacts[0]
assert (artifact['id'], artifact['name'], artifact['size_in_bytes'], artifact['digest'], artifact['expired']) == (
        ARTIFACT, 'dg16-host-rollover-' + str(RUN) + '-attempt-1', 4832, 'sha256:' + ZIP_SHA, False)
assert artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == OPERATOR
assert artifact['workflow_run']['head_branch'] == BRANCH
assert artifact['workflow_run']['repository_id'] == artifact['workflow_run']['head_repository_id'] == run['repository']['id']
created = datetime.datetime.fromisoformat(artifact['created_at'].replace('Z', '+00:00'))
expires = datetime.datetime.fromisoformat(artifact['expires_at'].replace('Z', '+00:00'))
assert expires - created == datetime.timedelta(days=3)

assert len(inputs['ACTUAL_ARTIFACT.zip']) == 4832 and sha(inputs['ACTUAL_ARTIFACT.zip']) == ZIP_SHA
with zipfile.ZipFile(INPUT / 'ACTUAL_ARTIFACT.zip') as archive:
    members = archive.infolist(); assert len(members) == 1
    info = members[0]
    assert info.filename == 'HOST_RUNTIME.json' and not info.is_dir()
    assert stat.S_ISREG(info.external_attr >> 16) and not info.flag_bits & 1
    assert info.file_size == 27688 <= MAXIMUM and info.compress_size <= 4832
    with archive.open(info, 'r') as stream:
        public = stream.read(MAXIMUM + 1)
    assert len(public) == info.file_size and sha(public) == PUBLIC_SHA
    archive_record = dict(members=1, name=info.filename, bytes=info.file_size,
        compressed_bytes=info.compress_size, mode=oct(info.external_attr >> 16),
        regular=True, encrypted=False, bounded_read=True, crc_read_completed=True)
assert public == inputs['HOST_RUNTIME.json']
value = json.loads(public)
assert canonical(value) == public
(OUT / 'HOST_RUNTIME.received.json').write_bytes(public)
script = next(s['run'] for s in workflow['jobs']['observe']['steps'] if s.get('id') == 'observe')
code = script.split("<<'PY'\n", 1)[1].rsplit('\nPY\n', 1)[0]
assert sha(code.encode()) == '87b89ba3d8623f324cf41c2890497b0f4fb0ee6eacf19488a3ee12dec50fd29c'
(OUT / 'reviewed_public_filter.py').write_bytes(code.encode())
# Sole permitted executable replay: pure receiving filter, never the observer or a source owner.
filtered = subprocess.run([sys.executable, '-I', '-S', '-B', str(OUT / 'reviewed_public_filter.py'),
    str(OUT / 'HOST_RUNTIME.received.json'), str(OUT / 'HOST_RUNTIME.filtered.json'),
    '0', OPERATOR, str(RUN)], capture_output=True, timeout=10)
assert filtered.returncode == 0 and filtered.stderr == b''
assert (OUT / 'HOST_RUNTIME.filtered.json').read_bytes() == public
(OUT / 'filter-receiving.log').write_bytes(filtered.stdout)

log = inputs['ACTUAL_JOB.log']
assert len(log) == 57109 and json.loads(inputs['DECODED_LOG_RESPONSE.json'])['content'].encode('utf8') == log
lines = log.decode('utf8').splitlines()
messages = [re.sub(r'^\ufeff?\d{4}-\d\d-\d\dT[^ ]+ ', '', line) for line in lines]
image_group = messages.index('##[group]Runner Image')
image_end = messages.index('##[endgroup]', image_group)
assert 'Image: ubuntu-24.04' in messages[image_group:image_end]
image_versions = [line.removeprefix('Version: ') for line in messages[image_group:image_end] if line.startswith('Version: ')]
assert image_versions == ['20261116.376.1']
image = image_versions[0]
ordered_events = ['Allowed diagnostic image: ' + image, OPERATOR, SOURCE,
    'Pinned absent launcher provision completed; no launcher execution.',
    'Bounded public observation captured.',
    'SHA256 digest of uploaded artifact zip is ' + ZIP_SHA]
positions = [messages.index(item) for item in ordered_events]
assert positions == sorted(positions) and len(set(positions)) == len(positions)
assert not any(line == 'Existing launcher path retained for read-only measurement.' for line in messages)
assert value['observed_image_version'] == value['facts']['image_version'] == value['context']['image_version'] == image
assert value['context']['workflow_commit'] == OPERATOR and value['context']['run_id'] == str(RUN)
assert value['schema'] == 'dg16.host-rollover-observation.v2' and value['status'] == 'CAPTURED_UNQUALIFIED'
assert value['source']['opening'] == value['source']['closing']
assert (value['source']['commit'], value['source']['tree']) == (SOURCE, SOURCE_TREE)
assert (value['source']['opening']['files'], value['source']['opening']['bytes'],
        value['source']['opening']['entries']) == (1989, 175634600, 2534)
assert all(value['source']['opening'][k] is True for k in (
    'all_manifest_members_match', 'includes_ignored_files', 'git_head_checked_separately'))
for name, pin in value['executing_body_pins'].items():
    assert sha(git('show', OPERATOR + ':' + name)) == pin
assert all(value[k] is False for k in ('automatic_adoption', 'provider_setup', 'native_execution', 'private_inputs_read'))
assert value['commands_executed'] == [] and value['observer_network_calls'] == 0 and value['original_awards'] == []
assert value['closing_unchanged'] is True

profiles = literal(owners['host_utility.py'], 'G1_HOST_PROFILES')
assert value['prior_finite_profile_policy_sha256'] == sha(canonical(profiles))
matches = [p for p in profiles if canonical(p['facts']) == canonical(value['facts'])]
assert [p['id'] for p in matches] == value['profile_comparison']['matching_profile_ids'] == ['G1_UBUNTU24_20261116_376_1']
for name in ('python3.12', 'git', 'bwrap'):
    assert value['tools'][name]['sha256'] == matches[0]['core_tool_sha256'][name]
assert set(value['tools']) == {'python3.12', 'git', 'bash', 'bwrap', 'env', 'openssl'}
assert all(row['available'] is True and row['trusted_file_custody'] is True and
           row['setid_or_file_capabilities'] is False for row in value['tools'].values())
assert value['tools']['bwrap']['stat']['ctime_ns'] <= value['opening_unix_ns']

expected = literal(owners['runtime_preflight.py'], 'EXPECTED')
runtime = value['runtime_selectors']
assert runtime['selector_count'] == len(runtime['selectors']) == len(expected) == 12
assert runtime['source_current'] is True and runtime['source_failure_sha256'] is None
assert runtime['automatic_adoption'] is False and runtime['complete_runtime_qualification'] is False
fields = ('bytes', 'sha256', 'mode', 'resolved', 'link')
observed, physical, deltas = {}, {}, []
assert [r['path'] for r in runtime['selectors']] == sorted(expected)
for row in runtime['selectors']:
    path = row['path']; a, b = row['opening'], row['closing']
    assert a == b and a['kind'] == 'FILE' and a['error_class'] is None and a['error_sha256'] is None
    assert row['bookends_equal'] is True and row['expected'] == expected[path]
    observed[path] = {key: a[key] for key in fields}
    physical[path] = a['capture_sha256']
    different = [key for key in fields if observed[path][key] != expected[path][key]]
    assert row['match'] == row['opening_match'] == row['closing_match'] == (not different)
    if different:
        deltas.append(dict(path=path, different_fields=different,
                          previous=expected[path], observed=observed[path]))
assert len(deltas) == 1 and deltas[0]['path'] == '/etc/ld.so.cache'
assert deltas[0]['different_fields'] == ['bytes', 'sha256']
assert runtime['status'] == 'REFUSED'
assert observed['/etc/ld.so.cache'] == dict(bytes=38396,
    sha256='347fdaed89f5b040c24b9d44f4b0700e8de4ef0585eb7e3d1ec6d3bdf664cd84',
    mode=420, resolved='/etc/ld.so.cache', link=None)
tuple_record = dict(schema='dg16.measured-finite-runtime-tuple.v1', authority='NONE',
    scope='OBSERVED_TUPLE_INPUT_ONLY_NOT_ADMITTED', run_id=RUN, job_id=JOB, attempt=1,
    operation_commit=OPERATOR, source_commit=SOURCE, source_tree=SOURCE_TREE,
    image_version=image, facts=value['facts'], matched_prior_host_profile=matches[0]['id'],
    artifact_zip_sha256=ZIP_SHA, public_json_sha256=PUBLIC_SHA, selector_count=12,
    observed=observed, observed_tuple_sha256=sha(canonical(observed)),
    previous_expected=expected, previous_tuple_sha256=sha(canonical(expected)),
    physical_bookend_sha256=physical, all_opening_closing_equal=True, deltas=deltas,
    runtime_status='REFUSED', automatic_adoption=False, complete_runtime_qualification=False,
    original_awards=[])
write_json('MEASURED_RUNTIME_TUPLE.json', tuple_record)
checks = dict(schema='dg16.host-observation02-independent-actual-checks.v1', authority='NONE',
    scope='ACTUAL_MEASUREMENT_RECEIVING_ONLY', input_manifest=input_manifest,
    operator_commit=OPERATOR, operator_tree=TREE, sole_parent=PARENT,
    published_operation_bytes_equal_reviewed=True, published_grant_commit=GRANT_COMMIT,
    published_grant_sha256=GRANT_SHA, published_grant_and_review_bindings_match=True,
    run_id=RUN, job_id=JOB, attempt=1, provider_run_and_job='success', provider_job_count=1,
    artifact_id=ARTIFACT, provider_artifact_count=1, artifact_zip_sha256=ZIP_SHA,
    archive=archive_record, public_json_sha256=PUBLIC_SHA, public_json_bytes=len(public),
    closed_filter_receiving_exit=filtered.returncode, filtered_bytes_equal_artifact=True,
    embedded_filter_sha256=sha(code.encode()), raw_log_bytes=len(log), raw_log_sha256=sha(log),
    log_equals_decoded_response_content=True,
    log_event_lines=[dict(line=index + 1, message=event) for index, event in zip(positions, ordered_events)],
    actual_image=image, three_image_labels_match_setup_log=True,
    root_credentials={k: value['facts'][k] for k in ('uid', 'euid', 'gid', 'egid')},
    matched_prior_host_profile=matches[0]['id'], all_six_tools_available_and_trusted=True,
    launcher_preparation='PINNED_ABSENT_LAUNCHER_PROVISION_COMPLETED_BEFORE_MEASUREMENT',
    source=value['source'], measured_body_read_bytes=value['limits']['actual_profile_and_source_read_bytes'],
    observer_elapsed_seconds=(value['closing_unix_ns'] - value['opening_unix_ns']) / 1e9,
    runtime_selectors=12, runtime_captures=24, stable_bookends=12, matches_prior_tuple=11,
    changed_selectors=1, deltas=deltas, observed_tuple_sha256=tuple_record['observed_tuple_sha256'],
    runtime_status='REFUSED', automatic_adoption=False, complete_runtime_qualification=False,
    observer_executed_by_reviewer=False, source_owner_executed_by_reviewer=False,
    hosted_or_native_or_model_operation_by_reviewer=False, original_awards=[])
write_json('ACTUAL_CHECKS.json', checks)
print(json.dumps({k: checks[k] for k in ('scope', 'run_id', 'job_id', 'attempt',
    'public_json_sha256', 'closed_filter_receiving_exit', 'actual_image',
    'matched_prior_host_profile', 'measured_body_read_bytes', 'observer_elapsed_seconds',
    'runtime_selectors', 'stable_bookends', 'matches_prior_tuple', 'changed_selectors',
    'observed_tuple_sha256', 'runtime_status', 'original_awards')}, indent=2))
