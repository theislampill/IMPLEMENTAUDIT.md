# Independent actual receiving — DG16 observation 02

**Disposition: PASS for actual measurement receiving.** The received result is **CAPTURED_UNQUALIFIED**. Its existing runtime comparison remains **REFUSED**. This receipt establishes a bounded observed host/runtime tuple and artifact receipt, with no automatic profile adoption, complete runtime qualification, native result, or original award.

## Actual operation and grant binding

Provider records bind run **45765672251**, job **139725875323**, attempt **1**, to push branch `engineering/pro-dg16-host-rollover-observe-20261126-02` and operation commit `49886a1c19d92177742b4614a0f1bfe132914138`, tree `56f5c473369fdd774949653ce6d672278a5a50b4`. The run, sole job, and recorded steps completed successfully.

The operation's sole parent is `e05ad38af3e1835aa8f6c000b17a98ed54454041`. Local immutable Git objects independently confirm exactly the three reviewed additions and their exact bodies. All four inherited packet owners also match the reviewed pins. No remote lookup or fetch was performed by this receiver.

The exact grant is SHA256 `810e212eefe7f6efd77e32b29ed1619da0bbb5de727779fc436d671ccf2af32a`, published at `ab4024b3501c5089d197d6a5ff0c2079ade32bcd`. All eight published grant/review records were compared byte-for-byte with the retained grant, proposal, prior independent receipt/manifest/report, preflight, and publication/root readback records. The recorded initial absence and single branch creation agree with the exact operation and attempt-one metadata. These immutable issuance/start records are historical evidence; this receipt creates no further use or retry authority.

## Archive and exact log

The provider reports exactly one artifact: **15091782173**, named `dg16-host-rollover-45765672251-attempt-1`, expiring three days after creation. Its 4,832-byte ZIP SHA256 is `abe3a0000950b8edca71a66747576c6a4c894b534d73e14a514d447ba91e920d`, matching both provider metadata and the upload log.

Independent archive inspection found exactly one nonencrypted regular member, `HOST_RUNTIME.json`, mode 0600, 27,688 uncompressed bytes and 4,684 compressed bytes. A bounded member read completed CRC verification and yielded SHA256 `6be97826b93ee877f69837f66b123a41a7a451bf91dd7cbe98676742f923d729`. It is byte-for-byte identical to Root's retained JSON.

The exact published closed filter was replayed only as a local receiving validator. It returned exit 0, empty stderr, and exactly the same 27,688 bytes. The observer and source owners were not executed.

The retained job log is 57,109 bytes, SHA256 `7eac088146f27f55a326dc2a7350248cd9741a0f52dbf92faf0bec77a0cb99c2`. Its bytes exactly equal the UTF-8 content field of `DECODED_LOG_RESPONSE.json`; the BOM and content were preserved. The Runner Image group, rather than the separate provisioner version, identifies Ubuntu 24.04 image **20261116.376.1**. Log order joins successful image guard, exact operation checkout, exact source540 checkout, pinned absent-launcher provision, successful public capture, and the matching artifact digest.

## Host, setup, and source facts

All three schema-v2 image labels agree with the Runner Image log: `observed_image_version`, `facts.image_version`, and `context.image_version` are `20261116.376.1`. The allowed diagnostic policy remains exactly the reviewed two-image list.

Observed facts are Linux, x86_64, Ubuntu VERSION_ID 24.04, Python 3.12.3, image_os ubuntu24, with UID/EUID/GID/EGID all zero. The complete facts match the existing finite host profile `G1_UBUNTU24_20261116_376_1`. Python, Git, and bwrap hashes also match that profile. All six fixed tools are reported available, executable, with root-owned nonwritable custody chains and no setid/file capabilities; the closed validator recomputes these properties from the recorded metadata.

The actual log reports the pinned absent-launcher provision completed before measurement. The resulting bwrap file is 72,160 bytes with SHA256 `52231e1caf55bcbc667b269f49c63599a6f7db4767ae6a039580d0ff853db712`; its creation/change time precedes the observer opening time. This is the declared setup effect. No bwrap invocation or AppArmor operation belongs to the reviewed workflow.

The authenticated observer reports equal opening/closing source censuses for source `540a12c1385fabc3170745103dd0ccb5ba8c9063`, tree `1839064374ba7a064a09db12123093a608596ecc`: **1,989 files, 175,634,600 bytes, and 2,534 entries per pass**, including ignored files with Git HEAD checked separately. Both physical census digests are `f8ec6beb7bdcd2f5049e4044d5d2dcf1b97f067c9cf317c69074f3c31f799ce3`. The source manifest's exact body pin and all executing-body pins agree with the published operation objects.

The observer reports closing_unchanged true and current selected source. Its reported opening-to-closing interval is **3.069973521 seconds**. The historical-reader body counter is **382,427,265 bytes**, within its 512 MiB scope. That counter does not include every immutable-owner, metadata, library, or runtime read; the existing separate scopes remain in force.

## Full runtime result

All **12 selectors**, captured twice, have equal complete opening and closing records, including their physical capture digests. Eleven five-field tuples match the existing expected tuple exactly. The sole changed selector is `/etc/ld.so.cache`:

| Field | Existing expected value | Actual stable value |
|---|---|---|
| bytes | 38,836 | **38,396** |
| SHA256 | `b0b5f4c96e3aedcc1c035c54839b5c39b92ff95a5359726052ba200474f0dc4b` | **`347fdaed89f5b040c24b9d44f4b0700e8de4ef0585eb7e3d1ec6d3bdf664cd84`** |
| mode | 0644 | 0644 |
| resolved | `/etc/ld.so.cache` | `/etc/ld.so.cache` |
| link | null | null |

Its opening and closing physical capture digest is `7e5d8ba46af4a11a691ac3fb46a5e1efa27e82120ca7adbc11da3e6850c53948`. The full prior five-field tuple has canonical SHA256 `92fd85a28a6329e72c0afdf907bd24df38e74818419c764039db2a5ff87453f9`; the complete observed tuple has canonical SHA256 **`22f697fa5ef3e10fb535dbf6d519d4eb5eaa259d5dda1797a8b2c4ad95d45672`**. Canonical encoding is the existing sorted-key, compact, ASCII JSON encoding with one trailing LF.

`MEASURED_RUNTIME_TUPLE.json` retains every measured path, byte count, digest, mode, resolved path, link, physical bookend digest, and the prior tuple. No cache field was dropped, normalized, regenerated, or substituted. The cache difference's cause is not established here.

## Inputs for a prospective finite runtime/main successor

`PROSPECTIVE_PROFILE_INPUTS.json` binds the complete measured tuple, host facts, core tools, source, run/job/attempt, and artifact hashes. This is usable input to a separate prospective decision for **image 20261116.376.1**. This run supplies no runtime tuple for image `20261122.23.1`.

In the current selected source, the cache expectation belongs to `startup_pins[/etc/ld.so.cache]` in `fixtures/work-graph-c5-inputs/package-r5-hosted-single-copy-canonical02-python312.json`; the early comparison owner is the exact packet's `runtime_preflight.py` EXPECTED map. A prospective source selection must keep these declarations consistent, retain the entire twelve-member population and exact cache tuple, and preserve the old evidence. Any selected-source/fixture change requires its own commit/tree, loader and operation bindings, source manifest, review, and subsequent actual admission/currentness evidence. Measurement of source540 cannot establish a different source's currentness.

Physical capture and source-census digests remain occurrence evidence. Future operations must produce their own stable physical bookends. Complete maintained runtime acquisition, native/main qualification, and original acceptance remain separate work under Root's authority.

## Scope and preserved boundaries

This receiver independently validates retained provider metadata, published code/authority bindings, archive bytes, closed projection, log/image joins, and the full reported tuple. It does not reconstruct the disposed runner filesystem or supply a full syscall trace. The result remains CAPTURED_UNQUALIFIED with runtime REFUSED, automatic_adoption false, complete_runtime_qualification false, and **original_awards empty**.

The predecessor01 terminal receipt remains unchanged: its first branch/attempt was spent, observation count zero, replay unauthorized. Its generic guard message still does not localize the first failed comparison. This successful successor does not repair or relabel that history.

All new writes are confined to `host-measure-independent/actual-02`. No observer/source-owner execution, new hosted/provider/native/model operation, profile adoption, source mutation, grant, Root-controller mutation, or original award occurred during receiving.
