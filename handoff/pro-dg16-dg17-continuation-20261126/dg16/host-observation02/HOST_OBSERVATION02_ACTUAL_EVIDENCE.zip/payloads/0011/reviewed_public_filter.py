import hashlib, json, os, re, stat, sys
from pathlib import PurePosixPath

MAXIMUM = 98304
ALLOWED_IMAGES = ('20261116.376.1', '20261122.23.1')
BASELINE = json.loads('[{"core_tool_sha256":{"bwrap":"52231e1caf55bcbc667b269f49c63599a6f7db4767ae6a039580d0ff853db712","git":"824d5b2fffef332ec7ba053e579659bb12f26a0b4747da6f9c6dc0e71d36f235","python3.12":"e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f"},"facts":{"architecture":"x86_64","egid":0,"euid":0,"gid":0,"image_os":"ubuntu24","image_version":"20261101.360.1","os":{"ID":"ubuntu","VERSION_ID":"24.04"},"platform":"linux","python_version":[3,12,3],"uid":0},"id":"G1_UBUNTU24_20261101_360_1"},{"core_tool_sha256":{"bwrap":"52231e1caf55bcbc667b269f49c63599a6f7db4767ae6a039580d0ff853db712","git":"824d5b2fffef332ec7ba053e579659bb12f26a0b4747da6f9c6dc0e71d36f235","python3.12":"e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f"},"facts":{"architecture":"x86_64","egid":0,"euid":0,"gid":0,"image_os":"ubuntu24","image_version":"20261111.370.1","os":{"ID":"ubuntu","VERSION_ID":"24.04"},"platform":"linux","python_version":[3,12,3],"uid":0},"id":"G1_UBUNTU24_20261111_370_1"},{"core_tool_sha256":{"bwrap":"52231e1caf55bcbc667b269f49c63599a6f7db4767ae6a039580d0ff853db712","git":"824d5b2fffef332ec7ba053e579659bb12f26a0b4747da6f9c6dc0e71d36f235","python3.12":"e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f"},"facts":{"architecture":"x86_64","egid":0,"euid":0,"gid":0,"image_os":"ubuntu24","image_version":"20261111.127.1","os":{"ID":"ubuntu","VERSION_ID":"24.04"},"platform":"linux","python_version":[3,12,3],"uid":0},"id":"G1_UBUNTU24_20261111_127_1"},{"core_tool_sha256":{"bwrap":"52231e1caf55bcbc667b269f49c63599a6f7db4767ae6a039580d0ff853db712","git":"08ca4d2ee4d8915e86f1faaa52603752507c57af1d16d451dec9992bc9b6d801","python3.12":"e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f"},"facts":{"architecture":"x86_64","egid":0,"euid":0,"gid":0,"image_os":"ubuntu24","image_version":"20261116.133.1","os":{"ID":"ubuntu","VERSION_ID":"24.04"},"platform":"linux","python_version":[3,12,3],"uid":0},"id":"G1_UBUNTU24_20261116_133_1"},{"core_tool_sha256":{"bwrap":"52231e1caf55bcbc667b269f49c63599a6f7db4767ae6a039580d0ff853db712","git":"08ca4d2ee4d8915e86f1faaa52603752507c57af1d16d451dec9992bc9b6d801","python3.12":"e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f"},"facts":{"architecture":"x86_64","egid":0,"euid":0,"gid":0,"image_os":"ubuntu24","image_version":"20261116.376.1","os":{"ID":"ubuntu","VERSION_ID":"24.04"},"platform":"linux","python_version":[3,12,3],"uid":0},"id":"G1_UBUNTU24_20261116_376_1"}]')
EXECUTING_PINS = json.loads('{"engineering/dg16-host-rollover-observation/observe.py":"9b58d6c9acd8f8e0fbe169c932d00f729f915576655eaf3db1e2ba5da97f4237","engineering/dg16-host-rollover-observation/profile_reader.py":"15a0be03138e3d6767a20d17c3d9066c6f7ba27c47024f6494729b7c4da62b62","qualification/dg16-r5-g1-hosted-episode-v21/packet/SOURCE_MANIFEST.json":"a1144d6023ca1704e308f7d4b533cea573e06de75c9470b35bb3dcd556122418","qualification/dg16-r5-g1-hosted-episode-v21/packet/host_utility.py":"51a88c08bbea3fd82986aaa6028aa16b92f5500de48950300398e542d5701b5a","qualification/dg16-r5-g1-hosted-episode-v21/packet/operation.py":"3d4ab528a6e8b814a0c477b2b8498ac2bad3752307489d17e0909d7ae6ec2d94","qualification/dg16-r5-g1-hosted-episode-v21/packet/runtime_preflight.py":"808f4892a53490990cd827d70902f2930c7ee11525f4fb0f94a1a905e2ec6245"}')
HELD_BODY_BYTES = 691163
RUNTIME_PATHS = ('/etc/ld.so.cache', '/lib/x86_64-linux-gnu/libc.so.6', '/lib/x86_64-linux-gnu/libgcc_s.so.1', '/lib/x86_64-linux-gnu/libpthread.so.0', '/lib/x86_64-linux-gnu/libstdc++.so.6', '/lib64/ld-linux-x86-64.so.2', '/usr/bin/python3.12', '/usr/lib/python3.12/_sysconfigdata__linux_x86_64-linux-gnu.py', '/usr/lib/python3.12/posixpath.py', '/usr/lib/python3.12/site.py', '/usr/lib/python3.12/sitecustomize.py', '/usr/lib/python3.12/sysconfig.py')
RUNTIME_PIN_SHA256 = '92fd85a28a6329e72c0afdf907bd24df38e74818419c764039db2a5ff87453f9'
TOOLS = ('python3.12', 'git', 'bash', 'bwrap', 'env', 'openssl')
FACT_FIELDS = {'platform', 'architecture', 'os', 'python_version', 'image_os', 'image_version',
               'uid', 'euid', 'gid', 'egid'}
STAT_FIELDS = {'dev', 'ino', 'mode', 'nlink', 'uid', 'gid', 'size', 'mtime_ns', 'ctime_ns'}
FILE_FIELDS = {'requested', 'canonical', 'requested_stat', 'bytes', 'sha256', 'stat',
               'ancestors', 'xattrs', 'capability'}
TOOL_FLAGS = {'available', 'root_owned_nonwritable_chain', 'setid_or_file_capabilities',
              'executable_mode', 'execute_access', 'trusted_file_custody'}
RUNTIME_FIELDS = {'bytes', 'sha256', 'mode', 'resolved', 'link'}

def encode(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True,
                       allow_nan=False) + '\n').encode('ascii')

def same(actual, expected):
    assert encode(actual) == encode(expected)

def keys(value, population):
    assert type(value) is dict and set(value) == population

def integer(value, maximum=2**63 - 1, minimum=0):
    assert type(value) is int and minimum <= value <= maximum

def digest(value):
    assert type(value) is str and re.fullmatch('[0-9a-f]{64}', value)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def absolute(value):
    assert type(value) is str and 1 <= len(value) <= 4096 and '\x00' not in value
    path = PurePosixPath(value)
    assert path.is_absolute() and str(path) == value and '..' not in path.parts
    assert not value.startswith('//')
    return path

def file_stat(value, kinds):
    keys(value, STAT_FIELDS)
    for name in STAT_FIELDS:
        integer(value[name], 2**64 - 1)
    assert stat.S_IFMT(value['mode']) in kinds and value['mode'] <= 0xffff
    assert value['nlink'] >= 1 and value['uid'] < 2**32 and value['gid'] < 2**32

def xattrs(value):
    keys(value, {'count', 'name_sha256', 'posix_acl_present', 'security_capability_present'})
    integer(value['count'], 32)
    names = value['name_sha256']
    assert type(names) is list and len(names) == value['count']
    for name in names: digest(name)
    assert names == sorted(set(names))
    same(value['posix_acl_present'], any(sha(name) in names for name in
         (b'system.posix_acl_access', b'system.posix_acl_default')))
    same(value['security_capability_present'], sha(b'security.capability') in names)

def file_measurement(row, requested, maximum, roots, extra=frozenset()):
    keys(row, FILE_FIELDS | extra)
    assert row['requested'] == requested
    canonical = absolute(row['canonical'])
    assert any(canonical.is_relative_to(root) for root in map(PurePosixPath, roots))
    file_stat(row['stat'], {stat.S_IFREG})
    file_stat(row['requested_stat'], {stat.S_IFREG, stat.S_IFLNK})
    if row['requested'] == row['canonical']: same(row['requested_stat'], row['stat'])
    integer(row['bytes'], maximum); digest(row['sha256'])
    assert row['bytes'] == row['stat']['size']
    xattrs(row['xattrs'])
    ancestors = row['ancestors']
    assert type(ancestors) is list and len(ancestors) == len(canonical.parents)
    for ancestor, path in zip(ancestors, canonical.parents):
        keys(ancestor, {'path', 'stat', 'xattrs'})
        assert ancestor['path'] == str(path)
        file_stat(ancestor['stat'], {stat.S_IFDIR}); xattrs(ancestor['xattrs'])
    cap = row['capability']
    keys(cap, {'observed', 'present', 'bytes', 'sha256'})
    assert cap['observed'] is True
    integer(cap['bytes'], 65536); digest(cap['sha256'])
    same(cap['present'], cap['bytes'] > 0)
    if cap['present']: assert row['xattrs']['security_capability_present'] is True
    else: assert cap['sha256'] == sha(b'')

def tool_measurement(row, name):
    assert type(row) is dict and type(row.get('available')) is bool
    if not row['available']:
        same(row, dict(requested='/usr/bin/' + name, available=False, code='FILE_UNAVAILABLE', errno=2))
        return
    file_measurement(row, '/usr/bin/' + name, 64 * 1024**2, ('/usr',), TOOL_FLAGS)
    info = row['stat']
    chain = info['uid'] == 0 and not info['mode'] & 0o022 and all(
        p['stat']['uid'] == 0 and not p['stat']['mode'] & 0o022 for p in row['ancestors'])
    privileged = bool(info['mode'] & 0o6000 or row['capability']['present'])
    executable = bool(info['mode'] & 0o111)
    assert type(row['execute_access']) is bool
    same({key: row[key] for key in TOOL_FLAGS}, dict(available=True,
        root_owned_nonwritable_chain=bool(chain), setid_or_file_capabilities=privileged,
        executable_mode=executable, execute_access=row['execute_access'],
        trusted_file_custody=bool(chain and not privileged and executable and row['execute_access'])))

def runtime_fields(row, capture=False):
    keys(row, RUNTIME_FIELDS | ({'kind', 'capture_sha256', 'error_class', 'error_sha256'} if capture else set()))
    integer(row['bytes'], 32 * 1024**2); digest(row['sha256'])
    integer(row['mode'], 4095); absolute(row['resolved'])
    assert row['link'] is None or type(row['link']) is str and 0 < len(row['link']) <= 4096 and '\x00' not in row['link']
    if capture:
        assert row['kind'] == 'FILE' and row['error_class'] is None and row['error_sha256'] is None
        digest(row['capture_sha256'])

def runtime_measurement(value, tools):
    keys(value, {'schema', 'source_revision', 'status', 'selector_count', 'source_current',
                 'source_failure_sha256', 'selectors', 'complete_runtime_qualification', 'automatic_adoption'})
    rows = value['selectors']
    assert type(rows) is list and len(rows) == 12
    rebuilt = []; expected = {}
    for row, name in zip(rows, RUNTIME_PATHS):
        keys(row, {'path', 'expected', 'opening', 'closing', 'opening_match',
                   'closing_match', 'bookends_equal', 'match'})
        assert row['path'] == name
        runtime_fields(row['expected']); runtime_fields(row['opening'], True); runtime_fields(row['closing'], True)
        same(row['opening'], row['closing'])
        expected[name] = row['expected']
        match = all(row['opening'][key] == row['expected'][key] for key in RUNTIME_FIELDS)
        rebuilt.append(dict(path=name, expected=row['expected'], opening=row['opening'], closing=row['closing'],
                            opening_match=match, closing_match=match, bookends_equal=True, match=match))
        if name == '/usr/bin/python3.12':
            tool = tools['python3.12']
            same({key: row['opening'][key] for key in ('bytes', 'sha256', 'mode', 'resolved')},
                 dict(bytes=tool['bytes'], sha256=tool['sha256'], mode=stat.S_IMODE(tool['stat']['mode']),
                      resolved=tool['canonical']))
    assert sha(encode(expected)) == RUNTIME_PIN_SHA256
    same(value, dict(schema='dg16.early-fixed-runtime-selectors.v1',
        source_revision='R5_HOSTED_UBUNTU24_STAGE_B_CANONICAL02_RUNTIME_SOURCE_20261126_V22',
        status='MATCH' if all(row['match'] for row in rebuilt) else 'REFUSED', selector_count=12,
        source_current=True, source_failure_sha256=None, selectors=rebuilt,
        complete_runtime_qualification=False, automatic_adoption=False))

def success(value, head, run):
    keys(value, {'schema', 'authority', 'status', 'context', 'allowed_image_versions', 'observed_image_version',
        'requested_image_observed', 'facts', 'boot_identity_sha256', 'os_release', 'tools',
        'prior_finite_profile_policy_sha256', 'profile_comparison', 'core_tool_comparison',
        'runtime_selectors', 'source', 'executing_body_pins', 'opening_unix_ns', 'closing_unix_ns',
        'limits', 'closing_unchanged', 'automatic_adoption', 'commands_executed', 'observer_network_calls',
        'provider_setup', 'native_execution', 'private_inputs_read', 'original_awards'})
    image = value['observed_image_version']
    assert type(image) is str and image in ALLOWED_IMAGES
    assert re.fullmatch('[0-9a-f]{40}', head) and re.fullmatch('[1-9][0-9]{0,19}', run)
    same(value['context'], dict(repository='theislampill/IMPLEMENTAUDIT.md',
        branch='engineering/pro-dg16-host-rollover-observe-20261126-02',
        workflow='.github/workflows/dg16-host-rollover-observe.yml', job='observe', run_id=run,
        run_attempt=1, workflow_commit=head, fresh_branch_push=True, image_version=image))
    same({key: value[key] for key in ('schema', 'authority', 'status', 'allowed_image_versions', 'observed_image_version',
         'requested_image_observed', 'closing_unchanged', 'automatic_adoption', 'commands_executed',
         'observer_network_calls', 'provider_setup', 'native_execution', 'private_inputs_read', 'original_awards')},
         dict(schema='dg16.host-rollover-observation.v2', authority='NONE', status='CAPTURED_UNQUALIFIED',
         allowed_image_versions=list(ALLOWED_IMAGES), observed_image_version=image,
         requested_image_observed=True, closing_unchanged=True,
         automatic_adoption=False, commands_executed=[], observer_network_calls=0, provider_setup=False,
         native_execution=False, private_inputs_read=False, original_awards=[]))
    facts = value['facts']; keys(facts, FACT_FIELDS)
    version = facts['python_version']
    assert type(version) is list and len(version) == 3
    for component in version: integer(component, 9999)
    same(facts, dict(platform='linux', architecture='x86_64', os={'ID': 'ubuntu', 'VERSION_ID': '24.04'},
        python_version=version, image_os='ubuntu24', image_version=image, uid=0, euid=0, gid=0, egid=0))
    digest(value['boot_identity_sha256'])
    file_measurement(value['os_release'], '/etc/os-release', 16384, ('/etc', '/usr/lib'))
    tools = value['tools']; keys(tools, set(TOOLS))
    for name in TOOLS: tool_measurement(tools[name], name)
    assert tools['python3.12']['available'] is True
    runtime_measurement(value['runtime_selectors'], tools)
    source = value['source']; keys(source, {'commit', 'tree', 'opening', 'closing'})
    assert type(source['opening']) is dict
    bookend_hash = source['opening']['physical_bookend_sha256']; digest(bookend_hash)
    bookend = dict(files=1989, bytes=175634600, entries=2534, physical_bookend_sha256=bookend_hash,
        all_manifest_members_match=True, includes_ignored_files=True, git_head_checked_separately=True)
    same(source, dict(commit='540a12c1385fabc3170745103dd0ccb5ba8c9063',
        tree='1839064374ba7a064a09db12123093a608596ecc', opening=bookend, closing=bookend))
    same(value['executing_body_pins'], EXECUTING_PINS)
    assert value['prior_finite_profile_policy_sha256'] == sha(encode(BASELINE))
    comparisons = [dict(profile_id=p['id'], different_fields=sorted(key for key in FACT_FIELDS
        if type(facts[key]) is not type(p['facts'][key]) or facts[key] != p['facts'][key])) for p in BASELINE]
    matches = [row['profile_id'] for row in comparisons if not row['different_fields']]
    same(value['profile_comparison'], dict(classification='MATCHES_REVIEWED_PROFILE' if len(matches) == 1
        else 'OUTSIDE_REVIEWED_PROFILES', matching_profile_ids=matches, profiles=comparisons,
        native_qualification=False, original_acceptance=False, original_awards=[]))
    same(value['core_tool_comparison'], {name: dict(observed_sha256=tools[name].get('sha256'),
        matches_profile_ids=[p['id'] for p in BASELINE if tools[name]['available']
            and tools[name]['sha256'] == p['core_tool_sha256'][name]]) for name in ('python3.12', 'git', 'bwrap')})
    actual_read = 2 * 175634600 + HELD_BODY_BYTES + 2 * 41 + 4 * 37 + 2 * value['os_release']['bytes'] \
        + 2 * sum(row['bytes'] for row in tools.values() if row['available'])
    integer(actual_read, 512 * 1024**2)
    same(value['limits'], dict(deadline_seconds=120, cpu_seconds=60, address_space_bytes=768 * 1024**2,
        maximum_profile_and_source_read_bytes=512 * 1024**2, actual_profile_and_source_read_bytes=actual_read,
        runtime_selector_count=12, runtime_capture_count=24, maximum_runtime_selector_bytes=32 * 1024**2,
        maximum_runtime_capture_bytes=24 * 32 * 1024**2, source_owner_maximum_member_bytes=1024**2,
        source_owner_read_bytes_metered=False, maximum_open_files=64, maximum_output_file_bytes=MAXIMUM,
        maximum_public_bytes=MAXIMUM))
    integer(value['opening_unix_ns']); integer(value['closing_unix_ns'])

def refusal():
    return dict(schema='dg16.host-rollover-observation-refusal.v1', authority='NONE',
                status='REFUSED', code='WORKFLOW_OUTPUT_REFUSED', automatic_adoption=False, original_awards=[])

value = refusal()
captured = False
try:
    assert len(sys.argv) == 6
    info = os.stat(sys.argv[1], follow_symlinks=False)
    assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_size <= MAXIMUM
    fd = os.open(sys.argv[1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream: raw = stream.read(MAXIMUM + 1)
    parsed = json.loads(raw)
    assert len(raw) <= MAXIMUM and encode(parsed) == raw
    if parsed['schema'] == 'dg16.host-rollover-observation.v2':
        assert sys.argv[3] == '0'
        success(parsed, sys.argv[4], sys.argv[5])
        captured = True
    else:
        assert sys.argv[3] != '0'
        assert type(parsed['code']) is str and re.fullmatch('[A-Z0-9_]{1,64}', parsed['code'])
        same(parsed, dict(schema='dg16.host-rollover-observation-refusal.v1', authority='NONE',
             status='REFUSED', code=parsed['code'], automatic_adoption=False, original_awards=[]))
    value = parsed
except (AssertionError, KeyError, TypeError, ValueError, OSError, RecursionError, OverflowError):
    pass
public = encode(value)
assert len(public) <= MAXIMUM
with open(sys.argv[2], 'xb') as stream: stream.write(public)
print('Bounded public observation captured.' if captured else 'REFUSED: OBSERVATION_NOT_CAPTURED')
raise SystemExit(0 if captured else 1)