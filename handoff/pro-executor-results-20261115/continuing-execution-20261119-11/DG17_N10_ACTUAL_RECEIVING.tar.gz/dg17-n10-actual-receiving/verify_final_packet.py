from pathlib import Path,PurePosixPath
import hashlib,json,tarfile,stat
from datetime import datetime,timezone
O=Path('/workspace/scratch/2678f1e431c3/dg17-n10-actual-receiving')
def sha(b):return hashlib.sha256(b).hexdigest()
s=json.loads((O/'SEAL.json').read_bytes());m=json.loads((O/'MANIFEST.json').read_bytes())
for key in ['report','result','manifest','archive','input_identity_manifest','data_verification']:
    row=s[key];p=O/row['path'];b=p.read_bytes()
    assert len(b)==row['bytes'] and sha(b)==row['sha256'] and oct(stat.S_IMODE(p.stat().st_mode))==row['mode'],key
for row in m['files']:
    p=O/row['path'];b=p.read_bytes()
    assert len(b)==row['bytes'] and sha(b)==row['sha256'] and oct(stat.S_IMODE(p.stat().st_mode))==row['mode'],row['path']
with tarfile.open(O/s['archive']['path'],'r:gz') as tf:
    members=tf.getmembers();expected={r['path'] for r in m['files']}|{'MANIFEST.json'}
    got=[]
    for mem in members:
        pp=PurePosixPath(mem.name);assert mem.isfile() and not pp.is_absolute() and '..' not in pp.parts
        rel='/'.join(pp.parts[1:]);got.append(rel);assert tf.extractfile(mem).read()==(O/rel).read_bytes(),rel
    assert len(got)==len(set(got)) and set(got)==expected
b=(O/'SEAL.json').read_bytes()
result={'schema':'ordinary.n10.receiving-final-readback.v1','status':'PASS','at_local_utc':datetime.now(timezone.utc).isoformat(),'payload_files':len(m['files']),'archive_files':len(got),'seal_bytes':len(b),'seal_sha256':sha(b),'disposition':s['disposition'],'report_sha256':s['report']['sha256'],'result_sha256':s['result']['sha256'],'manifest_sha256':s['manifest']['sha256'],'archive_sha256':s['archive']['sha256'],'scope':'Own receiving packet readback only; no source/actor/target execution or original award.'}
(O/'FINAL_READBACK.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
