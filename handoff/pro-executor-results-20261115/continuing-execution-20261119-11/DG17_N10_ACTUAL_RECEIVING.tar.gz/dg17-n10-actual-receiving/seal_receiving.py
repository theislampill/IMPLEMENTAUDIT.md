from pathlib import Path, PurePosixPath
import json,hashlib,stat,tarfile,gzip,io
from datetime import datetime,timezone
O=Path('/workspace/scratch/2678f1e431c3/dg17-n10-actual-receiving')
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return p.read_bytes()
def info(p):b=read(p);return {'path':p.name,'bytes':len(b),'sha256':sha(b),'mode':oct(stat.S_IMODE(p.stat().st_mode))}
r=json.loads(read(O/'RESULT.json'));report=read(O/'REPORT.md').decode()
assert r['disposition']=='NONVERDICT' and report.rstrip().endswith('N10_RECEIVING_DISPOSITION: NONVERDICT')
assert {f['id'] for f in r['findings']}=={'N10-R01','N10-R02'}
v=json.loads(read(O/'DATA_VERIFICATION.json'));assert v['passed']==12 and v['failed']==0
inputs=json.loads(read(O/'RECEIVED_INPUTS.json'))
for row in inputs['files']:
    p=Path(row['path']);assert p.is_file() and not p.is_symlink(),str(p)
    b=read(p);assert len(b)==row['bytes'] and sha(b)==row['sha256'] and oct(stat.S_IMODE(p.stat().st_mode))==row['mode'],str(p)
excluded_names={'MANIFEST.json','SEAL.json','DG17_N10_ACTUAL_RECEIVING.tar.gz','FINAL_READBACK.json','SEAL_OPERATION_RETURN.json'}
excluded_prefixes=('evidence/38_seal_packet.','evidence/39_final_readback.')
def exclude(rel):return rel in excluded_names or rel.startswith(excluded_prefixes)
paths=sorted(p for p in O.rglob('*') if p.is_file() and not exclude(p.relative_to(O).as_posix()))
for p in paths:
    assert not p.is_symlink()
    p.chmod(0o444)
rows=[]
for p in paths:
    b=read(p);rows.append({'path':p.relative_to(O).as_posix(),'bytes':len(b),'sha256':sha(b),'mode':oct(stat.S_IMODE(p.stat().st_mode))})
manifest={'schema':'ordinary.n10.receiving-manifest.v1','receiver':r['reviewer'],'disposition':r['disposition'],'payload_file_count':len(rows),'payload_bytes':sum(x['bytes'] for x in rows),'files':rows,'exclusions':sorted(excluded_names),'excluded_evidence_prefixes':list(excluded_prefixes),'post_seal_epilogue':'Actual sealing/final-readback command captures and optional exact sealing tool return are explicitly outside the pre-seal payload; no recursive self-hash is asserted.','input_binding':'RECEIVED_INPUTS.json binds exact reviewed source/evidence observations; target payloads were opaque hashes only.'}
mp=O/'MANIFEST.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');mp.chmod(0o444)
archive=O/'DG17_N10_ACTUAL_RECEIVING.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w') as tf:
            for p in paths+[mp]:
                rel=p.relative_to(O).as_posix();b=read(p);t=tarfile.TarInfo('dg17-n10-actual-receiving/'+rel)
                t.size=len(b);t.mode=stat.S_IMODE(p.stat().st_mode);t.mtime=0;t.uid=t.gid=0;t.uname=t.gname=''
                tf.addfile(t,io.BytesIO(b))
archive.chmod(0o444)
with tarfile.open(archive,'r:gz') as tf:
    members=tf.getmembers();expected={p.relative_to(O).as_posix() for p in paths+[mp]}
    actual=set()
    for mem in members:
        pp=PurePosixPath(mem.name);assert mem.isfile() and pp.parts[0]=='dg17-n10-actual-receiving' and '..' not in pp.parts
        rel='/'.join(pp.parts[1:]);assert rel not in actual;actual.add(rel)
        assert tf.extractfile(mem).read()==read(O/rel)
    assert actual==expected
seal={'schema':'ordinary.n10.receiving-seal.v1','receiver':r['reviewer'],'report_state':'FINAL','disposition':r['disposition'],'scope':r['disposition_scope'],'sealed_at_local_utc':datetime.now(timezone.utc).isoformat(),'report':info(O/'REPORT.md'),'result':info(O/'RESULT.json'),'manifest':info(mp),'archive':info(archive),'input_identity_manifest':info(O/'RECEIVED_INPUTS.json'),'data_verification':info(O/'DATA_VERIFICATION.json'),'payload_file_count':len(rows),'archive_file_count':len(members),'reviewed_inputs_rechecked_unchanged':len(inputs['files']),'data_checks_passed':12,'data_checks_failed':0,'findings':['N10-R01','N10-R02'],'original_award':False,'formal_audit_assess_activation':False,'target_or_source_execution_by_receiver':False,'helper_substantive_rereview':False,'new_child':False,'root_currentness_scope':'Caller-supplied G0005 custody only; no receiver controller operation.','post_seal_capture_exclusions':list(excluded_prefixes)+['FINAL_READBACK.json','SEAL_OPERATION_RETURN.json'],'seal_meaning':'Local byte custody, not a provider signature, trusted timestamp, authenticated raw transcript, native event or acceptance award.'}
sp=O/'SEAL.json';sp.write_text(json.dumps(seal,indent=2)+'\n');sp.chmod(0o444)
print(json.dumps({'seal':info(sp),'report':seal['report'],'result':seal['result'],'manifest':seal['manifest'],'archive':seal['archive'],'payload_files':len(rows),'reviewed_inputs_unchanged':len(inputs['files']),'status':'SEALED'},indent=2))
