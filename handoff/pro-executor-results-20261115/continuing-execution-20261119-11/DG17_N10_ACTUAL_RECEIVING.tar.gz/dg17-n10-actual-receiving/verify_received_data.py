from pathlib import Path, PurePosixPath
import hashlib,json,stat,tarfile
B=Path('/workspace/scratch/2678f1e431c3')
O=B/'dg17-n10-actual-receiving'
P=B/'dg17-n10-recovered-prospective-v2'
T=B/'ordinary-work-observation-20261118'
E=B/'ordinary-work-observation-evidence-20261118'
H=B/'ordinary-source-assessment-20261118'
checks=[]
seen={}
def data(p):
    p=Path(p); s=p.lstat()
    if not stat.S_ISREG(s.st_mode): raise ValueError('Nonregular input '+str(p))
    b=p.read_bytes()
    seen[str(p)]={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'mode':oct(stat.S_IMODE(s.st_mode))}
    return b
def obj(p):return json.loads(data(p))
def expect(c,detail):
    if not c:raise AssertionError(detail)
def binding(p,row,mode=True):
    b=data(p)
    expect(len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],'Identity mismatch '+str(p))
    if mode and 'mode' in row:expect(seen[str(p)]['mode']==row['mode'],'Mode mismatch '+str(p))
    return b
def check(name,fn):
    try:
        detail=fn()
        checks.append({'check':name,'status':'PASS','detail':detail})
    except Exception as e:
        checks.append({'check':name,'status':'FAIL','error_type':type(e).__name__,'error':str(e)})
def prep():
    s=obj(P/'SEALED_PACKET.json')
    for key in ['archive','manifest','report','result','delta','affected_verification']:binding(P/s[key]['path'],s[key])
    expect(s['archive']['sha256']=='61334e07430020d1d434e35df22f6b3d9ced58dc2a1187cf8f66a41bf3dbb504','Assigned preparation archive')
    m=obj(P/'MANIFEST.json')
    for row in m['members']:binding(P/row['path'],row)
    expected={r['path'] for r in m['members']}|{'MANIFEST.json'}
    with tarfile.open(P/s['archive']['path'],'r:gz') as tf:
        members=tf.getmembers()
        names=[]
        for mem in members:
            path=PurePosixPath(mem.name)
            expect(mem.isfile() and not path.is_absolute() and '..' not in path.parts,'Unsafe outer member')
            expect(path.parts[0]=='ordinary-work-prospective-v2','Observed outer prefix changed')
            rel='/'.join(path.parts[1:]);names.append(rel)
            expect(tf.extractfile(mem).read()==data(P/rel),'Outer member differs '+rel)
        expect(len(names)==len(set(names)) and set(names)==expected,'Outer archive population')
    return {'manifest_files':len(m['members']),'archive_files':len(names),'opaque_target_archive_only':True}
check('Preparation seal, manifest, and outer archive',prep)
def contracts():
    a=data(P/'reviewer-private/contracts/R0037-ACCEPTANCE.md')
    i=data(P/'reviewer-private/contracts/issue-211-body.md')
    expect(hashlib.sha256(a).hexdigest()=='eed53023153b5b505ad562ace0979dc3b8dab7aeb3660b0c1905c216c6d9b4a9','Acceptance body')
    expect(hashlib.sha1(b'blob '+str(len(a)).encode()+b'\0'+a).hexdigest()=='1d0f8a1b3dcfef7b99ee1c82a2164797371c37e1','Acceptance Git blob')
    expect(hashlib.sha256(i).hexdigest()=='ca62f4899a45544549f623a0312c16121bb99f432ccb87a87b7361974ceb94c4','Issue body')
    expect('Children encoded as fixed lifecycle | Hidden lifecycle fails; zero-child and one-child paths remain valid | Cross-loop neutrality' in i.decode().splitlines()[567],'Original literal N10')
    return {'issue_line':568,'acceptance_line':199,'no_new_trial_or_mutation_requirement':True}
check('Original literal and retained Git/blob body identity',contracts)
def previous():
    out=[]
    for rel in ['dg17-n10-prospective-review','dg17-n10-prospective-review-v2']:
        p=B/rel;s=obj(p/'SEALED_REVIEW.json')
        for key in ['archive','manifest','report','findings','final_readback']:binding(p/s[key]['path'],s[key])
        out.append({'path':str(p),'disposition':s['disposition']})
    return {'prior_claims_only':out}
check('Prior prospective review return bindings',previous)
def selected_source():
    m=obj(T/'SOURCE_IDENTITY.json');rows={r['path']:r for r in m['members']}
    actual={x.relative_to(T/'source-layout').as_posix() for x in (T/'source-layout').rglob('*') if x.is_file() or x.is_symlink()}
    expect(actual==set(rows),'Selected source population')
    for rel,row in rows.items():
        b=binding(T/'source-layout'/rel,dict(row,mode=row['copy_mode']))
        expect(hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['git_blob_sha1'],'Selected Git blob '+rel)
        expect(b==data(P/'neutral-stage/source-layout'/rel),'Staged versus frozen source '+rel)
    expect(m['source_commit']=='a297957be11feb494c0ec467235794a1e0c54751','Source commit reference')
    expect(m['source_tree']=='b08dc4ecf4028beeedb579a312eccae23cb5d863','Source tree reference')
    return {'files':len(rows),'skills':sum(x.startswith('skills/') for x in rows),'full_original_root_tree_rebuilt':False,'git_blob_check':'All selected retained bodies'}
check('Exact selected source bodies, modes and Git blobs',selected_source)
def neutral():
    pre=obj(E/'PRE_STAGE1_MANIFEST.json');changed=[]
    expected=set()
    for row in pre['files']:
        rel=PurePosixPath(row['path']).relative_to('neutral-stage').as_posix()
        expected.add(rel);b=data(T/rel)
        binding(P/row['path'],row)
        if len(b)!=row['bytes'] or hashlib.sha256(b).hexdigest()!=row['sha256'] or seen[str(T/rel)]['mode']!=row['mode']:changed.append(rel)
    actual={x.relative_to(T).as_posix() for x in T.rglob('*') if x.is_file() or x.is_symlink()}
    expect(actual==expected,'Task file population')
    expect(changed==['work/notice.txt'],'Only released notice changed')
    expect(data(T/'work/notice.txt')==data(T/'work/approved-notice.txt'),'Final notice exact approved')
    expect(data(T/'work/notice.txt')==data(E/'stage2-notice.postimage.txt'),'Retained postimage')
    expect(data(E/'stage2-notice.preimage.txt')==data(P/'neutral-stage/work/notice.txt'),'Retained preimage')
    return {'task_files':len(expected),'unchanged':len(expected)-1,'changed':changed,'final_state_only_not_transient_effect_attestation':True}
check('Original task baseline and current business scope',neutral)
def mission():
    expected={'STAGE1_ADMISSION.txt':'6c7efa08d1042ed48acd45817e0ccd11ac74be9a9f733d53a93dedb547c12840','STAGE2_NOTICE.txt':'3cbb9c414be2662bae9111da0adae5a53bcfde40e6be22271ab6cbd574ddf98b','STAGE3_REVIEW_CONTINUATION.txt':'7e0a173ce02e79c3417943002ef0a626623b85c7480d51bdd035cdca82fbd84c','IDENTITY_RESERVATION.txt':'36086ae8921184f33c1aa5a01bb7de68fe20e8043d03cd9e816e703f732cff1a'}
    for name,sha in expected.items():
        b=data(T/'missions'/name);expect(hashlib.sha256(b).hexdigest()==sha,'Mission '+name);expect(b==data(P/'neutral-stage/missions'/name),'Frozen mission '+name)
    initial=obj(E/'ROOT_STAGE1_ACTUAL_DISPATCH.json')
    expect(initial['actual_arguments']['fork_turns']=='none','Actual governor fresh request')
    expect(initial['actual_received_result']['task_name']=='/root/ordinary_work_governor','Governor dispatch identity')
    low=(initial['actual_arguments']['message']+data(T/'missions/STAGE1_ADMISSION.txt').decode()).lower()
    forbidden=['n10','zero-child','one-child','hidden lifecycle','fixed lifecycle','four-child','mutation kill','must reject','expected answer','expected disposition','exactly one child']
    expect(not [x for x in forbidden if x in low],'Forbidden initial answer cue')
    return {'mission_files':4,'initial_actual_message_cue_check':'clear for frozen list','semantic_fairness':'separate reviewer judgment; lexical check alone insufficient'}
check('Mission identities and initial neutral dispatch',mission)
def notice_receipts():
    d=obj(E/'stage2-tool-receipts.json');ops=d['operations']
    expect(len(ops)==8 and [o['sequence'] for o in ops]==list(range(1,9)),'Stage2 sequence')
    a=ops[3];b=ops[5]
    expect(a['arguments']==b['arguments'],'Same original checker command')
    expect(a['result']['chunk_id']=='8282af' and a['result']['exit_code']==1,'Actual baseline result')
    expect(b['result']['chunk_id']=='e09df2' and b['result']['exit_code']==0,'Actual post result')
    expect(json.loads(a['result']['output'])['notice_matches_approved'] is False,'Baseline mismatch')
    expect(json.loads(b['result']['output'])['notice_matches_approved'] is True,'Post equality')
    expect(hashlib.sha256(data(T/'support/check_notice.py')).hexdigest()=='fe6192e97f593a586b7e102796e83ece97b8b74543b2d7652a97272399993ee4','Checker source identity')
    return {'baseline':a['result'],'post':b['result'],'receiver_checker_executions':0,'useful_completion':'Read/act/verify retained'}
check('Actual zero-child notice evidence',notice_receipts)
def envelope_resolver():
    env=obj(E/'ISSUED_REVIEW_ENVELOPE_G0004.json');res=obj(E/'STAGE3_RESOLVER_RECEIPT_G0004.json');r=obj(E/'ROOT_ACTUAL_REVIEWER_RESERVATION_G0004.json')
    facts=obj(E/'ACTUAL_PRELOAD_FACTS_G0004.json');led=obj(E/'stage3-tool-receipts.json')
    expect(hashlib.sha256(data(E/'ISSUED_REVIEW_ENVELOPE_G0004.json')).hexdigest()=='4a8bb2a4ddc5b10896038c8ea674f6e5ef275be7b9c70e7cdcea18b986fc00b5','Envelope')
    expect(hashlib.sha256(data(E/'STAGE3_RESOLVER_RECEIPT_G0004.json')).hexdigest()=='e804c8e3bd0258f23036000797b89ca8194fc5e6d32942c8f5c234811a2e6e9a','Resolver receipt')
    expect(res['actual_resolver']['submitted_arguments']==led['operations'][6]['arguments'] and res['actual_resolver']['result']==led['operations'][6]['result'],'Actual resolver record')
    expect(res['actual_resolver']['result']['exit_code']==0 and res['actual_resolver']['result']['output'].strip()==env['child_source']['path'],'Actual selected path')
    expect(res['actual_preload']['result']==led['operations'][5]['result'],'Actual preload result')
    expect(r['actual_arguments']==env['identity_reservation']['actual_submitted_fork_arguments'],'Reserved host request')
    expect(r['actual_arguments']['fork_turns']=='none','Fork-none')
    who=r['actual_return']['task_name']
    expect(who==env['independence']['actual_reviewer_identity']=='/root/bounded_source_reviewer','Same reserved reviewer')
    expect(who not in [env['independence']['actual_helper_author_identity'],env['independence']['excluded_protocol_author']],'Non-author identity')
    for key in ['source_identity','review_object','authority','reservation']:binding(Path(facts[key]['path']),facts[key])
    for row in facts['subject_current_files']:binding(Path(row['path']),row)
    expect(facts['root_currentness']['actual_require_result']['exit_code']==0,'Recorded caller custody')
    return {'preload_chunk':'4f1fcd','resolver_chunk':'2c77d0','currentness':'caller custody plus actual local identity observations','native_actor_controller':False,'operational_release_not_supplied_by_reservation':True}
check('Reservation, envelope and actual resolver bindings',envelope_resolver)
def reviewer_role():
    p=obj(H/'PRELOAD_VERIFICATION.json');role=obj(H/'ROLE_LOAD.json');ops=obj(H/'TOOL_OPERATIONS.json')['operations']
    for row in p['observations']:binding(Path(row['path']),row)
    expect(p['status']=='APPLICABLE_PREREQUISITES_VERIFIED' and not p['problems'],'Actual preload')
    stored=next(x for x in ops if x['sequence']==7)
    actual=role['actual_role_load_operation']
    expect(stored['arguments']==actual['arguments'] and stored['result']==actual['result'],'Exact role read receipt')
    raw=actual['result']['output'].encode()
    expect(raw==data(Path(role['selected_path'])),'Role body actual returned bytes')
    expect(hashlib.sha256(raw).hexdigest()==role['selected_sha256'],'Role SHA')
    return {'preload_inputs':len(p['observations']),'role_load_chunk':actual['result']['chunk_id'],'role_load_exit':actual['result']['exit_code'],'recorded_visible_announcement':role['visible_announcement'],'required_marker_in_recorded_announcement':'CHILD_SKILL_ROUTE=audit-assess' in role['visible_announcement'],'announcement_cannot_be_inferred_from_source_text':True}
check('Actual reviewer preload and role-load receipt',reviewer_role)
def helper_return():
    s=obj(H/'SEAL.json');m=obj(H/'MANIFEST.json');r=obj(H/'RESULT.json')
    for key in ['report','result','manifest']:binding(Path(s[key]['path']),s[key])
    total=0
    for row in m['files']:total+=len(binding(H/row['path'],row))
    expect(len(m['files'])==58 and total==m['payload_bytes']==1750504,'Bound canonical return totals')
    expect(r['reviewer']==s['owner']=='/root/bounded_source_reviewer','Return identity')
    expect(r['return_owner']==s['return_owner']=='/root/ordinary_work_governor','Return owner')
    expect(r['disposition']==s['disposition']=='NEEDS_REVISION','Source outcome retained')
    expect(r['source_only'] and r['candidate_commit'] is None and not r['launch_authorization'] and not r['readiness_or_acceptance_authority'],'Authority ceiling')
    expect(r['review_accounting']['substantive_review_count_this_context']==1 and s['role_load_count']==1,'Recorded one actual canonical review')
    expect([(x['id'],x['disposition']) for x in r['findings']]==[('ASR-001','NEEDS_REVISION'),('ASR-002','NONVERDICT')],'Return finding disposition')
    return {'files_hashed_opaquely':58,'bytes':total,'substantive_target_read_or_rereview_by_receiver':False,'finding_merits_read_as_bounded_return_not_adjudicated':True}
check('Canonical helper return seal and bounded result',helper_return)
def stage4():
    d=obj(E/'STAGE4_RETURN_DECISION_G0005.json')
    expect(hashlib.sha256(data(E/'STAGE4_RETURN_DECISION_G0005.json')).hexdigest()=='bc9c8cbcf21fbec563bae88d671f74f79da4d5ed649ab9a6bf6f38d67a438c27','Immutable decision identity')
    l=obj(E/'stage4-tool-receipts.json')
    expect(l['operations'][3]['result']['chunk_id']=='a01d48' and l['operations'][3]['result']['exit_code']==0,'Actual re-derivation return')
    result=json.loads(l['operations'][3]['result']['output'])
    expect(result['problems']==[] and result['received_disposition']=='NEEDS_REVISION','Actual bounded receiving')
    expect(d['governor']=='/root/ordinary_work_governor','Same governor return owner')
    return {'governor_validation':l['operations'][3]['result'],'decision_sha256':hashlib.sha256(data(E/'STAGE4_RETURN_DECISION_G0005.json')).hexdigest(),'no_controller_operation_by_receiver':True}
check('Stage4 immutable decision and actual governor receipt',stage4)
def tail():
    l=obj(E/'stage4-tool-receipts.json');old=obj(E/'stage4-tool-receipts.json.pre-root-tail')
    p=obj(E/'stage4-persistence-operation-5.json');oldp=obj(E/'stage4-persistence-operation-5.json.pre-root-tail')
    t=l['operations'][-1]['result']
    expect(t==p['result'] and t['chunk_id']=='c950e7' and t['exit_code']==0,'Actual shared tail')
    expected=json.loads(json.dumps(old));expected['operations'][-1]['result']=t;expected['operations'][-1]['result_state']=l['operations'][-1]['result_state'];expected['tail_receipt_boundary']=l['tail_receipt_boundary']
    expect(expected==l,'Only approved ledger append fields')
    ep=json.loads(json.dumps(oldp));ep['result']=t;ep['result_state']=p['result_state'];expect(ep==p,'Only approved operation append fields')
    outputs=json.loads(t['output'])['evidence_outputs']
    binding(E/'stage4-tool-receipts.json.pre-root-tail',outputs[0],mode=False)
    binding(E/'STAGE4_RETURN_DECISION_G0005.json',outputs[1])
    return {'tail_chunk':'c950e7','two_ledgers_changed_only_by_result_and_custody_fields':True,'original_backups_bound':True,'immutable_decision_unchanged':True}
check('Root stage4 tail append and retained original bytes',tail)
# Bind the complete authorized receipt containers without reading target source as text.
for p in sorted(E.iterdir()):
    if p.is_file():data(p)
for n in ['ROOT_N10_STAGE1_RECEIVING_G0004.json','ROOT_N10_STAGE2_RECEIVING_G0004.json','ROOT_REVIEW_PRELOAD_RECEIVING_G0004.json','ROOT_N10_STAGE4_RECEIVING_G0005.json']:data(B/'recovery-evidence'/n)
out={'schema':'ordinary.n10.independent-data-checks.v1','reviewer':'/root/dg17_n09_prospective_reviewer','scope':'Data identity/receipt checks only, not the N10 semantic verdict','checks':checks,'passed':sum(x['status']=='PASS' for x in checks),'failed':sum(x['status']=='FAIL' for x in checks),'receiver_target_or_source_execution':False,'known_limits':['No provider-authenticated raw transcript or hidden-context claim','No full original root Git tree reconstruction','Exact missing original prompts or results are not reconstructed','Canonical target packet is hashed only, without a second substantive review']}
(O/'DATA_VERIFICATION.json').write_text(json.dumps(out,indent=2)+'\n')
(O/'RECEIVED_INPUTS.json').write_text(json.dumps({'schema':'ordinary.n10.received-input-identities.v1','files':[seen[k] for k in sorted(seen)],'file_count':len(seen),'scope':'Local sequential byte identities. Not original host timestamps, immutable access enforcement, or provider attestation.'},indent=2)+'\n')
print(json.dumps({'passed':out['passed'],'failed':out['failed'],'input_files_bound':len(seen),'checks':[{'check':x['check'],'status':x['status'],**({'error':x['error']} if 'error' in x else {})} for x in checks]},indent=2))
raise SystemExit(1 if out['failed'] else 0)

