python - <<'PY'
from pathlib import Path
import json
p=Path('/workspace/scratch/2678f1e431c3/ordinary-work-observation-evidence-20261118/stage2-tool-receipts.json')
d=json.loads(p.read_bytes())
for op in d['operations'][2:7]:print(json.dumps(op,indent=2))
PY
