python /workspace/scratch/2678f1e431c3/dg17-n10-actual-receiving/verify_received_data.py
