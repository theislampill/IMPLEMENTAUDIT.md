python - <<'PY'
from pathlib import Path
import json
b=Path('/workspace/scratch/2678f1e431c3')
for rel in ['dg17-n10-prospective-review/SEALED_REVIEW.json','dg17-n10-prospective-review-v2/SEALED_REVIEW.json']:
 print('FILE',rel); print((b/rel).read_text())
for rel,seqs in [('ordinary-work-observation-evidence-20261118/stage3-tool-receipts.json',[6]),('ordinary-work-observation-evidence-20261118/stage4-tool-receipts.json',[4])]:
 d=json.loads((b/rel).read_bytes());print('FILE',rel)
 for op in d['operations']:
  if op['sequence'] in seqs: print(json.dumps(op,indent=2))
PY
