python - <<'PY'
from pathlib import Path
import json
p=Path('/workspace/scratch/2678f1e431c3/ordinary-source-assessment-20261118')
d=json.loads((p/'RESULT.json').read_bytes())
for k in ['route_evidence','independence','review_accounting','coordination','final_identity_readback','capture_limits']:print(k,json.dumps(d[k],indent=2))
v=json.loads((p/'PRELOAD_VERIFICATION.json').read_bytes());print('PRELOAD non-observations',json.dumps({k:v for k,v in v.items() if k!='observations'},indent=2))
t=json.loads((p/'TOOL_OPERATIONS.json').read_bytes());print('TOOL HEADER',json.dumps({k:v for k,v in t.items() if k!='operations'},indent=2))
print('TOOLS SUMMARY')
for op in t['operations']:
 print(json.dumps({k:(dict(v,output='[body not displayed; retained in bound original receipt]') if k=='result' and isinstance(v,dict) and 'output' in v else v) for k,v in op.items() if k not in ['arguments'] and not isinstance(v,list)},ensure_ascii=False)[:1000])
PY
