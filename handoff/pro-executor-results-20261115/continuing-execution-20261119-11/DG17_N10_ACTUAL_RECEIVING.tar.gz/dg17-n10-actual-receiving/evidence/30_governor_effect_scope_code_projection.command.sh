python - <<'PY'
from pathlib import Path
import json,hashlib
p=Path('/workspace/scratch/2678f1e431c3/ordinary-work-observation-evidence-20261118')
for name,numbers in [('admission-tool-receipts.json',[1,2,7,8,9,10]),('stage2-tool-receipts.json',[8]),('stage3-tool-receipts.json',[8]),('stage4-tool-receipts.json',[5])]:
 d=json.loads((p/name).read_bytes());print('FILE',name)
 for op in d['operations']:
  if op['sequence'] not in numbers: continue
  c=op['arguments']['cmd'];print('SEQUENCE',op['sequence'],'command_bytes',len(c.encode()),'command_sha256',hashlib.sha256(c.encode()).hexdigest())
  for i,l in enumerate(c.splitlines(),1):
   if len(l)>3000: print(f'{i}: [Single long embedded prior-evidence/receipt literal omitted from display, {len(l)} characters; complete original retained in bound ledger.]')
   else: print(f'{i}: {l}')
  if op['sequence']==7 or op['sequence']>=8:print('RESULT',json.dumps(op['result']))
PY
