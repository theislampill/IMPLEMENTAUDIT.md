python - <<'PY'
from pathlib import Path
import json,tarfile
b=Path('/workspace/scratch/2678f1e431c3')
p=b/'dg17-n10-recovered-prospective-v2'
m=json.loads((p/'MANIFEST.json').read_bytes()); print('preparation_excludes',m['excludes'])
with tarfile.open(p/'DG17_N10_PROSPECTIVE_PACKET_V2.tar.gz','r:gz') as t:
 a=t.getmembers();print('archive_member_count',len(a),'first',[x.name for x in a[:4]],'last',[x.name for x in a[-4:]])
for rel,key in [('ordinary-work-observation-evidence-20261118/ACTUAL_PRELOAD_FACTS_G0004.json','actual_source_members'),('ordinary-source-assessment-20261118/PRELOAD_VERIFICATION.json','observations'),('ordinary-source-assessment-20261118/FINAL_READBACK.json',None)]:
 d=json.loads((b/rel).read_bytes());print('FILE',rel)
 if key:print('first',json.dumps(d[key][0]));print('non-list',json.dumps({k:v for k,v in d.items() if not isinstance(v,list)},indent=2))
 else: print('keys',list(d))
print('mode_counts',{})
for rel in ['dg17-n10-recovered-prospective-v2','ordinary-source-assessment-20261118']:
 from collections import Counter
 print(rel,dict(Counter(oct(x.stat().st_mode&0o7777) for x in (b/rel).rglob('*') if x.is_file())))
PY
