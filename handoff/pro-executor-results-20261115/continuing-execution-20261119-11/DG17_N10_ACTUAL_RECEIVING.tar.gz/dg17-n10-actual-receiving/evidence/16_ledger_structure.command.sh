python - <<'PY'
from pathlib import Path
import json
p=Path('/workspace/scratch/2678f1e431c3/ordinary-work-observation-evidence-20261118')
for name in ['admission-tool-receipts.json','stage2-tool-receipts.json','stage3-tool-receipts.json','stage4-tool-receipts.json']:
 d=json.loads((p/name).read_bytes()); print('FILE',name,'TYPE',type(d).__name__)
 if isinstance(d,dict):
  for k,v in d.items(): print(k,type(v).__name__,len(v) if hasattr(v,'__len__') else v)
 elif isinstance(d,list):
  for i,v in enumerate(d): print(i, list(v) if isinstance(v,dict) else type(v).__name__)
PY
