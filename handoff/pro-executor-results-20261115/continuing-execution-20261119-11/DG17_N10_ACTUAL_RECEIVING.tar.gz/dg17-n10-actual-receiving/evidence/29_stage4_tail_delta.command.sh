python - <<'PY'
from pathlib import Path
import json
p=Path('/workspace/scratch/2678f1e431c3/ordinary-work-observation-evidence-20261118')
def diff(a,b,k=''):
 if type(a)!=type(b): return [(k,a,b)]
 if isinstance(a,dict):
  out=[]
  for n in sorted(set(a)|set(b)):
   if n not in a or n not in b: out.append((k+'/'+n,a.get(n,'ABSENT'),b.get(n,'ABSENT')))
   else: out.extend(diff(a[n],b[n],k+'/'+n))
  return out
 if isinstance(a,list):
  if len(a)!=len(b): return [(k,a,b)]
  return sum((diff(x,y,k+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [(k,a,b)]
for name in ['stage4-tool-receipts.json','stage4-persistence-operation-5.json']:
 a=json.loads((p/(name+'.pre-root-tail')).read_bytes());b=json.loads((p/name).read_bytes())
 print('FILE',name); print(json.dumps(diff(a,b),indent=2))
d=json.loads((p/'STAGE4_RETURN_DECISION_G0005.json').read_bytes());print('DECISION KEYS',list(d))
PY
