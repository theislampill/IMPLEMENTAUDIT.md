python - <<'PY'
from pathlib import Path
import json
p=Path('/workspace/scratch/2678f1e431c3/ordinary-work-observation-evidence-20261118')
for name in ['admission-tool-receipts.json','stage2-tool-receipts.json','stage3-tool-receipts.json','stage4-tool-receipts.json']:
 d=json.loads((p/name).read_bytes()); print('FILE',name)
 for i,op in enumerate(d['operations'],1):
  print('OP',i,'KEYS',list(op))
  for k,v in op.items():
   if isinstance(v,dict):
    z={}
    for a,b in v.items():
     z[a]=({'bytes':len(b.encode()),'prefix':b[:160]} if isinstance(b,str) and len(b)>350 else b)
    print(k,json.dumps(z))
   elif isinstance(v,str) and len(v)>350: print(k, 'chars',len(v),'prefix',repr(v[:160]))
   else: print(k,v)
PY
