python - <<'PY'
from pathlib import Path
import json
b=Path('/workspace/scratch/2678f1e431c3')
d=json.loads((b/'ordinary-work-observation-evidence-20261118/STAGE4_RETURN_DECISION_G0005.json').read_bytes())
for key in ['actual_relay','currentness_rederivation','current_work','ordinary_source_repair_decision','retained_capture_limits','retained_coordination_limit','effects']:
 print(key,json.dumps(d[key],indent=2))
r=json.loads((b/'ordinary-source-assessment-20261118/RECONCILIATION_STATUS.json').read_bytes())
for key in ['context_observation','pending','orchestration_store_limit','remaining_work_if_released']:
 print('RECONCILIATION',key,json.dumps(r[key],indent=2))
PY
