python - <<'PY'
from pathlib import Path
import json,hashlib
p=Path('/workspace/scratch/2678f1e431c3/dg17-n10-actual-receiving/evidence')
for label in ('09_actual_stage1','10_actual_stage2','11_actual_dispatches'):
 for f in sorted(p.glob(label+'.*')):
  b=f.read_bytes()
  print(f.name,len(b),hashlib.sha256(b).hexdigest())
  if f.suffix=='.json': print(b.decode())
PY
