python - <<'PY'
from pathlib import Path
import json,ast
b=Path('/workspace/scratch/2678f1e431c3')
for rel in ['ordinary-work-observation-evidence-20261118/CALLER_ADMISSION.json','ordinary-work-observation-evidence-20261118/CALLER_STAGE2_RELEASE_G0004.json','ordinary-work-observation-20261118/inputs/REVIEW_OBJECT.json']:
 print('FILE',rel)
 for i,l in enumerate((b/rel).read_text().splitlines(),1):print(f'{i}: {l}')
p=b/'ordinary-work-observation-evidence-20261118/stage3-tool-receipts.json';d=json.loads(p.read_bytes());cmd=d['operations'][7]['arguments']['cmd']
body='\n'.join(cmd.splitlines()[1:-1]);tree=ast.parse(body)
for node in tree.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='body' for t in node.targets):
  v=ast.literal_eval(node.value);print('Stage3 op8 body literal, parsed as data only:');print(v)
PY
