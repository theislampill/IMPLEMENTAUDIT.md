python - <<'PY'
from pathlib import Path
import json
base=Path('/workspace/scratch/2678f1e431c3/ordinary-work-observation-evidence-20261118')
for name in ['ROOT_STAGE1_ACTUAL_DISPATCH.json','ROOT_STAGE2_ACTUAL_CONTINUATION_G0004.json','ROOT_ACTUAL_REVIEWER_RESERVATION_G0004.json']:
 print(json.dumps({'file':name,'data':json.loads((base/name).read_bytes())},indent=2))
PY
