python - <<'PY'
from pathlib import Path
p=Path('/workspace/scratch/2678f1e431c3/ordinary-work-observation-20261118')
for name in ['missions/STAGE1_ADMISSION.txt','missions/STAGE2_NOTICE.txt','missions/STAGE3_REVIEW_CONTINUATION.txt','work/WORK_ORDERS.md','work/DELIVERY_NOTE.md','AUTHORITY.md','PRECEDENCE.json']:
 print('FILE',name)
 for i,l in enumerate((p/name).read_text().splitlines(),1): print(f'{i:4}: {l}')
PY
