python - <<'PY'
from pathlib import Path
import json
b=Path('/workspace/scratch/2678f1e431c3')
for rel in ['dg17-n10-recovered-prospective-v2/SEALED_PACKET.json','dg17-n10-recovered-prospective-v2/MANIFEST.json','ordinary-work-observation-20261118/SOURCE_IDENTITY.json','ordinary-work-observation-evidence-20261118/PRE_STAGE1_MANIFEST.json','ordinary-source-assessment-20261118/MANIFEST.json']:
 d=json.loads((b/rel).read_bytes());print('FILE',rel)
 if 'SEALED' in rel: print(json.dumps(d,indent=2))
 else:
  for k,v in d.items(): print(k, json.dumps(v[:1] if isinstance(v,list) else v))
for name in ['ROOT_N10_STAGE1_RECEIVING_G0004.json','ROOT_N10_STAGE2_RECEIVING_G0004.json','ROOT_REVIEW_PRELOAD_RECEIVING_G0004.json','ROOT_N10_STAGE4_RECEIVING_G0005.json']:
 print('FILE recovery-evidence/'+name);print((b/'recovery-evidence'/name).read_text())
PY
