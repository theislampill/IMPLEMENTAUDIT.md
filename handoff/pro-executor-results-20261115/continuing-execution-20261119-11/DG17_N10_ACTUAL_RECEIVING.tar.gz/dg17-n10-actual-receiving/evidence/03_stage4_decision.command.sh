nl -ba /workspace/scratch/2678f1e431c3/ordinary-work-observation-evidence-20261118/STAGE4_RETURN_DECISION_G0005.json
