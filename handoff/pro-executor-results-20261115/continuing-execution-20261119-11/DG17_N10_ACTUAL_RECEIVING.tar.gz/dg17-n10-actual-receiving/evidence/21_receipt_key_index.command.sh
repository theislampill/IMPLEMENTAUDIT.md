python - <<'PY'
from pathlib import Path
import json
b=Path('/workspace/scratch/2678f1e431c3')
paths=['ordinary-source-assessment-20261118/RESULT.json','ordinary-source-assessment-20261118/PRELOAD_VERIFICATION.json','ordinary-source-assessment-20261118/RECONCILIATION_STATUS.json','ordinary-source-assessment-20261118/TOOL_OPERATIONS.json','ordinary-work-observation-evidence-20261118/ACTUAL_PRELOAD_FACTS_G0004.json','dg17-n10-recovered-prospective-v2/MANIFEST.json','ordinary-work-observation-20261118/SOURCE_IDENTITY.json','ordinary-work-observation-evidence-20261118/PRE_STAGE1_MANIFEST.json']
for path in paths:
 d=json.loads((b/path).read_bytes());print('FILE',path)
 if isinstance(d,dict):
  for k,v in d.items(): print(k,type(v).__name__,len(v) if hasattr(v,'__len__') else v)
 elif isinstance(d,list): print('length',len(d),'first_keys',list(d[0]))
PY
