nl -ba /workspace/scratch/2678f1e431c3/ordinary-work-observation-evidence-20261118/STAGE2_NOTICE_RESULT.json
