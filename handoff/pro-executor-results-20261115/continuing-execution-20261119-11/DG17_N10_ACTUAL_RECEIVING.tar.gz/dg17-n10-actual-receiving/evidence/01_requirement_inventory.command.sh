python - <<'PY'
from pathlib import Path
import json
base=Path('/workspace/scratch/2678f1e431c3/dg17-n10-recovered-prospective-v2')
for rel in ['reviewer-private','review-basis','neutral-stage/missions','neutral-stage/inputs','neutral-stage/support']:
 p=base/rel
 print(json.dumps({'root':str(p),'entries':[{'path':str(f.relative_to(base)),'bytes':f.stat().st_size} for f in sorted(p.rglob('*')) if f.is_file()]},indent=2))
PY
