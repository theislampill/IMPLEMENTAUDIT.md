python - <<'PY'
from pathlib import Path
import re,json
b=Path('/workspace/scratch/2678f1e431c3')
paths=['dg17-n10-recovered-prospective-v2/reviewer-private/ORACLE.json','dg17-n10-recovered-prospective-v2/reviewer-private/MODEL_CONTROLS.json']
for rel in paths:
 print('FILE',rel)
 for i,l in enumerate((b/rel).read_text().splitlines(),1): print(f'{i}: {l}')
patterns=re.compile('actual_operational_continuation|visible_announcement|announcement_order|actual_relay|caller_reported_exact_error|full_direct_send_tool_result|required_marker|operational_release_evidence|remaining_boundary|role_load_count')
for rel in ['ordinary-source-assessment-20261118/PRELOAD_VERIFICATION.json','ordinary-source-assessment-20261118/ROLE_LOAD.json','ordinary-work-observation-evidence-20261118/STAGE4_RETURN_DECISION_G0005.json']:
 print('ANCHORS',rel)
 for i,l in enumerate((b/rel).read_text().splitlines(),1):
  if patterns.search(l): print(f'{i}: {l[:400]}'+(' [long retained line not fully displayed]' if len(l)>400 else ''))
PY
