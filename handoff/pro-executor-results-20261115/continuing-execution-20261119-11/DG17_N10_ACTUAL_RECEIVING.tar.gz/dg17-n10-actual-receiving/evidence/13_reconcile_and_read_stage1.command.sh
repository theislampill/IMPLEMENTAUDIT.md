python - <<'PY'
from pathlib import Path
import json,hashlib
base=Path('/workspace/scratch/2678f1e431c3')
ev=base/'dg17-n10-actual-receiving/evidence'
src=base/'ordinary-work-observation-evidence-20261118'
for label,name in [('09_actual_stage1','STAGE1_ADMISSION_RECORD.json'),('10_actual_stage2','STAGE2_NOTICE_RESULT.json')]:
 b=(src/name).read_bytes(); expected=b''.join((f'{i:6}\t'.encode()+s) for i,s in enumerate(b.splitlines(keepends=True),1))
 assert expected==(ev/(label+'.stdout')).read_bytes(),name
 print(json.dumps({'current_file':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'matches_retained_capture':True}))
names=['ROOT_STAGE1_ACTUAL_DISPATCH.json','ROOT_STAGE2_ACTUAL_CONTINUATION_G0004.json','ROOT_ACTUAL_REVIEWER_RESERVATION_G0004.json']
expected=''.join(json.dumps({'file':name,'data':json.loads((src/name).read_bytes())},indent=2)+'\n' for name in names).encode()
assert expected==(ev/'11_actual_dispatches.stdout').read_bytes()
print('Current three dispatch records match retained capture exactly.')
print((ev/'09_actual_stage1.stdout').read_text())
PY
