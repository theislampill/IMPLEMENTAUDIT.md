python - <<'PY'
from pathlib import Path
p=Path('/workspace/scratch/2678f1e431c3/ordinary-work-observation-evidence-20261118')
for name in ['ISSUED_REVIEW_ENVELOPE_G0004.json','STAGE3_RESOLVER_RECEIPT_G0004.json']:
 print('FILE',name)
 for i,l in enumerate((p/name).read_text().splitlines(),1): print(f'{i:4}: {l}')
PY
