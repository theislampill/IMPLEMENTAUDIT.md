python - <<'PY'
from pathlib import Path
p=Path('/workspace/scratch/2678f1e431c3/dg17-n10-actual-receiving/evidence')
for name in ['10_actual_stage2.stdout','11_actual_dispatches.stdout']:
 print('CAPTURE',name)
 print((p/name).read_text())
PY
