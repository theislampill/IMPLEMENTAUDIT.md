python - <<'PY'
from pathlib import Path
p=Path('/workspace/scratch/2678f1e431c3/ordinary-source-assessment-20261118')
for name in ['ROLE_LOAD.json','EARLY_CALL_CAPTURE.json','SEAL.json']:
 print('FILE',name)
 for i,l in enumerate((p/name).read_text().splitlines(),1): print(f'{i:4}: {l}')
PY
