rg --files /workspace/scratch/2678f1e431c3/dg17-n10-prospective-review /workspace/scratch/2678f1e431c3/dg17-n10-prospective-review-v2 -g '*SEAL*' -g '*MANIFEST*' -g '*RESULT*' -g '*FINDINGS*'
