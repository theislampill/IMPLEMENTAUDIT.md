python - <<'PY'
from pathlib import Path
b=Path('/workspace/scratch/2678f1e431c3')
items=[('dg17-n10-recovered-prospective-v2/reviewer-private/contracts/R0037-ACCEPTANCE.md',[(190,204)]),('dg17-n10-recovered-prospective-v2/reviewer-private/contracts/issue-211-body.md',[(560,573)]),('ordinary-work-observation-20261118/source-layout/skills/implementaudit/SKILL.md',[(62,154)]),('ordinary-work-observation-20261118/source-layout/skills/implementaudit/references/plan-lifecycle.md',[(171,233),(339,371)]),('ordinary-work-observation-20261118/source-layout/skills/implementaudit/references/child-agents.md',[(57,86),(314,347)]),('ordinary-work-observation-20261118/source-layout/skills/implementaudit/references/transcript-contract.md',[(388,406),(425,457)])]
for p,ranges in items:
 lines=(b/p).read_text().splitlines();print('FILE',p)
 for start,end in ranges:
  print('RANGE',start,end)
  for i in range(start-1,min(end,len(lines))): print(f'{i+1}: {lines[i]}')
PY
