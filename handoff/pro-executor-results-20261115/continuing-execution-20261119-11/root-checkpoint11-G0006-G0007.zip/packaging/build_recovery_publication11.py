"""Build a local, additive evidence stage from one frozen, bounded census.

Adapted from Root's build_recovery_publication10.py. This utility performs no
provider, remote Git, controller, ref, commit, HEAD, or real-index operation.
Archive content is data; only the unchanged prior reassembler is executed.
"""
from pathlib import Path
import datetime, hashlib, json, os, re, shutil, stat, subprocess, tarfile, zipfile

BASE = Path('/workspace/scratch/2678f1e431c3')
REPO = BASE / 'recovery-repo'
SUPPORT = BASE / 'checkpoint11-packaging-support-20261119'
SNAPSHOT = SUPPORT / 'snapshot'
OUT = BASE / 'recovery-publication11'
STAGE = OUT / 'stage'
PARENT = '0f3839da15d4b9a24dda364b77dbb01a50d3f454'
BASE_TREE = 'da9c0d6e2ea5f97239e09ce277074cd2752472c8'
ROOT_HEAD = '6d9e145e2f2df5a0a8a150c85a4f3e2afd918d27'
PREFIX = 'handoff/pro-executor-results-20261115/continuing-execution-20261119-11/'
PART_BYTES = 393216
CHUNK_BYTES = 49152
ROOT_RECEIPT = '03a4c376cf2aa12c233d4cbdeef5ec86ebec5d0d'
RUN_ROOT = 'recovery-repo/.IMPLEMENTAUDIT/runs/dg16-dg18-recovered-custody-20261118-Zsj2RI'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def desc(raw):
    return {'bytes': len(raw), 'sha256': sha(raw)}


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def safe(name):
    p = Path(name)
    assert name and not p.is_absolute() and '..' not in p.parts and '\\' not in name


def scan(raw, name):
    # The sensitive-content scanner is preserved from publication 10.
    for rule in [rb'gh[pousr]_[A-Za-z0-9]{30,}', rb'AKIA[A-Z0-9]{16}',
                 rb'X-Amz-Signature=[A-Fa-f0-9]{64}', rb'[?&]sig=[A-Za-z0-9%+/]{20,}',
                 rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n[A-Za-z0-9+/=]{32,}']:
        assert re.search(rule, raw) is None, ('sensitive-pattern-needs-review', name)


def add_file(target, path, name):
    safe(name)
    assert name not in target and path.is_file() and not path.is_symlink(), str(path)
    raw = path.read_bytes()
    scan(raw, name)
    target[name] = (raw, stat.S_IMODE(path.stat().st_mode))


def add_dir(target, root, prefix):
    for p in sorted(root.rglob('*')):
        assert not p.is_symlink(), p
        if p.is_file():
            add_file(target, p, prefix + str(p.relative_to(root)))


initial = json.loads((SUPPORT / 'INITIAL_SNAPSHOT_CENSUS.json').read_text())
archive_census = json.loads((SUPPORT / 'ARCHIVE_SNAPSHOT_CENSUS.json').read_text())
FROZEN_AT = initial['created_utc']


def make_zip(name, inputs, scope):
    for key, (raw, mode) in inputs.items():
        safe(key)
        scan(raw, key)
    manifest = {'schema': 'root.actual-evidence-snapshot.v1', 'scope': scope,
                'created_utc': FROZEN_AT,
                'files': [{'path': k, **desc(v[0]), 'mode': oct(v[1])} for k, v in sorted(inputs.items())],
                'no_current_authority_or_ref_restoration_from_snapshot': True,
                'packager_acceptance_judgment': False,
                'provider_calls_by_packager': 0}
    assert 'SNAPSHOT_MANIFEST.json' not in inputs
    inputs['SNAPSHOT_MANIFEST.json'] = ((json.dumps(manifest, indent=2) + '\n').encode(), 0o644)
    path = OUT / name
    with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for key, (raw, mode) in sorted(inputs.items()):
            info = zipfile.ZipInfo(key, (1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | mode) << 16
            archive.writestr(info, raw)
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(inputs)
        for key, (raw, mode) in inputs.items():
            assert archive.read(key) == raw
            assert stat.S_IMODE(archive.getinfo(key).external_attr >> 16) == mode
    return path


assert not OUT.exists(), 'Never overwrite a prior attempt'
OUT.mkdir()
STAGE.mkdir()

# Re-read only the owned frozen copy, never future candidate or review outputs.
all_rows = initial['files'] + archive_census['files']
assert len({r['path'] for r in all_rows}) == len(all_rows)
for row in all_rows:
    path = SNAPSHOT / row['path']
    raw = path.read_bytes()
    assert desc(raw) == {k: row[k] for k in ('bytes', 'sha256')}, row['path']
    assert oct(stat.S_IMODE(path.stat().st_mode)) == row['mode'], row['path']
    scan(raw, row['path'])
    assert not any(part in path.relative_to(SNAPSHOT).parts for part in (
        'fresh-remote.git', 'g132-actual-candidate-independent-review-20261119',
        'helper-candidate-head-review-20261119'))
assert sum(r['path'].startswith('review-entry-observation-20261119/') for r in all_rows) == 88
assert sum(r['path'].startswith('dg17-helper-api-candidate-20261119/') for r in all_rows) == 55
assert sum(r['path'].startswith('g132-api-candidate-preparation-20261119/') for r in all_rows) == 42

pinned = [
    ('dg17-exact-host-recovery-revision1/DG17_EXACT_A297_HOST_SOURCE_REVISION1.tar.gz', 399805,
     '7cfc05e7a04083ef81b0c2641a03769cc9d821fdb1f6b3f55fe0a6e2a06a0139'),
    ('dg17-n10-actual-receiving/DG17_N10_ACTUAL_RECEIVING.tar.gz', 184062,
     '00e171d038bf653dfc111a9f8b314d3469ec4657683fa9f38dc308c35529972e'),
    ('g132-selected-host-object-receiving/G132_SELECTED_HOST_OBJECT_RECEIVING.zip', 1128357,
     '8728bd73119c877694e14ed5dd2ba55262e99874cbadae68565a15b7872bcd1c'),
    ('g132-actual-candidate-rebind-20261119/G132_ACTUAL_CANDIDATE_REBIND_SOURCE.zip', 1978677,
     'aeb9cd668e778d2aec50bbf8a960e48f18e7b1ed958e59ad054611eb44b85fd4'),
    ('dg17-h03-actual-receiving/DG17_H03_ACTUAL_RECEIVING.tar.gz', 73067,
     'fa262a24894db944382018053154395d0eb1b6647f7660ef872b6a3853a11d63'),
    ('recovery-evidence/PR255_PRIOR_BODY_G0006.md', 63432,
     '9e9e49463b763a1fe33268f374aec9dc6c689b5ecd3e3cf18e974faaf9f26827'),
    (RUN_ROOT + '/STATE.md', 49312,
     '6a2eebde3f1b22ef1079344f91664f13b8ed644e72201b0dac6b651c21115cbc'),
    (RUN_ROOT + '/ROADMAP.md', 8231,
     'dbfd8d47c1d61792a86f2a7a964b9bb93b87b0f3cfde865e3064be65ac4b6fcb')]
pin_results = []
for name, size, digest in pinned:
    raw = (SNAPSHOT / name).read_bytes()
    assert desc(raw) == {'bytes': size, 'sha256': digest}, name
    pin_results.append({'path': name, **desc(raw), 'verified': True})
dump(SUPPORT / 'SOURCE_PIN_VERIFICATION.json', {'pins': pin_results, 'snapshot_only': True})

candidate_pins = []
for directory, expected_commit, expected_parent, expected_tree in [
    ('dg17-helper-api-candidate-20261119', 'dc64d434d7bcafdd6d4487d275adbed4dd08b4a1',
     'a297957be11feb494c0ec467235794a1e0c54751', 'b783f0cd9eb9f79dc72af2addb5d557005337467'),
    ('g132-api-candidate-preparation-20261119', 'bd347ba6848e976c993ec82f5aa85d8e5964f6e1',
     '301aeecde08ba6f169bc3cd837eae6f6ad068219', 'bc3f8f1a10cbea041a6bf066acda113f3252360b')]:
    raw = (SNAPSHOT / directory / 'REMOTE_COMMIT.raw').read_bytes()
    commit = hashlib.sha1(b'commit ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    header = raw.split(b'\n\n', 1)[0].decode().splitlines()
    parents = [line[7:] for line in header if line.startswith('parent ')]
    trees = [line[5:] for line in header if line.startswith('tree ')]
    assert commit == expected_commit and parents == [expected_parent] and trees == [expected_tree]
    candidate_pins.append({'snapshot_directory': directory, 'commit': commit,
                           'sole_parent': expected_parent, 'tree': expected_tree,
                           'raw_commit': desc(raw), 'historical_snapshot_only': True})
dump(SUPPORT / 'CANDIDATE_BYTE_IDENTITIES.json', {'candidates': candidate_pins})

generated = []


def grouped_zip(name, directories, scope):
    inputs = {}
    for directory in directories:
        add_dir(inputs, SNAPSHOT / directory, directory + '/')
    path = make_zip(name, inputs, scope)
    generated.append((name, path, path.stat().st_size, sha(path.read_bytes()), scope,
                      {'kind': 'frozen-directory-snapshot', 'directories': directories}))


grouped_zip('dg17-helper-revision1-review-route-and-return.zip', [
    'helper-revision1-independent-review-20261119',
    'helper-revision-review-control-20261119',
    'helper-revision-governor-return-20261119'],
    'Complete closed helper revision review, actual route records and governor return, including Root actual final tail; no packager source or acceptance judgment.')
grouped_zip('dg17-helper-completed-candidate-preparation.zip', [
    'dg17-helper-candidate-gate-preparation-20261119', 'dg17-helper-api-candidate-20261119'],
    'Completed gate preparation and one fixed 55-file API/native candidate evidence census for dc64d434; fresh-remote.git and future launch/head-review records excluded; no ref or job at cutoff.')
grouped_zip('dg17-n10-actual-receiving-addendum.zip', ['dg17-n10-actual-receiving-addendum'],
    'Complete closed actual receiving addendum; Root G0006 full-case NONVERDICT and missing-marker limitation remain in the separate Root snapshot.')
grouped_zip('g132-completed-api-candidate-preparation.zip', ['g132-api-candidate-preparation-20261119'],
    'One fixed 42-file completed API/native candidate evidence census for unreferenced bd347ba; sole parent 301aeec and tree bc3f8f; no independent review, adoption or original effect award.')
grouped_zip('dg17-h03-actual-task-and-observation.zip', [
    'review-entry-observation-20261119', 'review-entry-observation-evidence-20261119'],
    'Exact 88 task files and complete 33-file closed actual actor/caller evidence. Root G0006 scoped semantic acceptance has partial capture; whole case remains unawarded NONVERDICT.')

root_inputs = {}
add_dir(root_inputs, SNAPSHOT / 'recovery-evidence', 'root/')
add_dir(root_inputs, SNAPSHOT / 'recovery-publication10', 'completed-publication10/')
add_dir(root_inputs, SNAPSHOT / RUN_ROOT, 'historical-runtime-at-cutoff/')
for row in archive_census['files']:
    if not row['path'].endswith(('.zip', '.tar.gz')):
        add_file(root_inputs, SNAPSHOT / row['path'], 'outer-seals-and-actual-tail/' + row['path'])
for name in ['build_recovery_publication10.py', 'read_recovery10_chunk.py']:
    add_file(root_inputs, SNAPSHOT / name, 'packaging/prior/' + name)
add_file(root_inputs, SNAPSHOT / 'recovery-publication10/stage/reassemble_archives.py',
         'packaging/prior/reassemble_archives.py')
for name in ['build_recovery_publication11.py', 'read_recovery11_chunk.py']:
    add_file(root_inputs, BASE / name, 'packaging/' + name)
for name in ['INITIAL_SNAPSHOT_CENSUS.json', 'ARCHIVE_SNAPSHOT_CENSUS.json',
             'SOURCE_PIN_VERIFICATION.json', 'CANDIDATE_BYTE_IDENTITIES.json',
             'SELECTED_ARCHIVE_STRUCTURE_AND_CANDIDATE_IDENTITIES.json',
             'INITIAL_LOCAL_GIT_CHECKS.json']:
    add_file(root_inputs, SUPPORT / name, 'packaging/' + name)
root_scope = ('G0006/G0007 Root evidence, exact prior PR body, completed publication10 readbacks, '
              'historical G0007 STATE/ROADMAP and G0006 progress, detached seals and actual final tails. '
              'No present authority or new acceptance derives from the snapshot; all prior UNKNOWNs and failed receipts are preserved.')
root_zip = make_zip('root-checkpoint11-G0006-G0007.zip', root_inputs, root_scope)
generated.append((root_zip.name, root_zip, root_zip.stat().st_size, sha(root_zip.read_bytes()),
                  root_scope, {'kind': 'bounded-root-snapshot', 'snapshot_created_utc': FROZEN_AT}))

scopes = [
    'Exact sealed helper source revision1; source bytes only, no packager review, launch or original award.',
    'Exact original N10 receiving archive; full-case NONVERDICT and missing-marker limitation preserved.',
    'Exact selected-host object receiving archive and historical object custody; no protected replay or restored authority.',
    'Exact actual-candidate rebind source archive; no independent review or adoption claimed in this checkpoint.',
    'Exact actual H03 receiving archive; partial historical capture and whole-case NONVERDICT preserved.']
sources = []
for (name, size, digest), scope in zip(pinned[:5], scopes):
    path = SNAPSHOT / name
    sources.append((path.name, path, size, digest, scope,
                    {'kind': 'exact-sealed-archive', 'snapshot_path': name}))
sources.extend(generated)

archives = []
archive_checks = []
for name, path, size, digest, scope, origin in sources:
    raw = path.read_bytes()
    assert len(raw) == size and sha(raw) == digest, name
    scan(raw, name)
    members = []
    if name.endswith('.zip'):
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None
            for item in archive.infolist():
                safe(item.filename)
                assert not item.is_dir() and not stat.S_ISLNK(item.external_attr >> 16)
                scan(archive.read(item), name + '::' + item.filename)
                members.append(item.filename)
    else:
        with tarfile.open(path, 'r:gz') as archive:
            for item in archive.getmembers():
                safe(item.name)
                assert item.isfile()
                scan(archive.extractfile(item).read(), name + '::' + item.name)
                members.append(item.name)
    assert len(members) == len(set(members))
    parts = []
    if len(raw) <= PART_BYTES:
        (STAGE / name).write_bytes(raw)
    else:
        for number, offset in enumerate(range(0, len(raw), PART_BYTES), 1):
            piece = raw[offset:offset + PART_BYTES]
            partname = name + f'.part{number:03d}'
            (STAGE / partname).write_bytes(piece)
            parts.append({'name': partname, **desc(piece)})
    archives.append({'name': name, **desc(raw), 'members': len(members), 'scope': scope,
                     'origin': origin, 'transport_parts': parts})
    archive_checks.append({'name': name, 'members': len(members), 'safe_unique_regular_members': True,
                           'all_member_bytes_sensitive_scanned': True, **desc(raw)})
dump(OUT / 'ARCHIVE_VERIFICATION.json', {'archives': archive_checks, 'archive_count': len(archives)})

reassembler = SNAPSHOT / 'recovery-publication10/stage/reassemble_archives.py'
shutil.copyfile(reassembler, STAGE / 'reassemble_archives.py')
assert (STAGE / 'reassemble_archives.py').read_bytes() == reassembler.read_bytes()
prior_body = (SNAPSHOT / 'recovery-evidence/PR255_PRIOR_BODY_G0006.md').read_bytes()
(STAGE / 'PR255_PRIOR_BODY.md').write_bytes(prior_body)
(STAGE / 'README.md').write_text('''# Checkpoint 11: completed evidence and bounded source recovery

This additive stage preserves completed inputs selected by Root. Its claims and
publication remain subject to Root review. The packager makes no source,
independent-review, acceptance, adoption, launch, release or closure judgment.
No provider, native remote, controller, ref, commit or HEAD operation is performed
by the packaging utility. The local tree is computed using its own index and
object directory. All 3,577 prior leaves remain byte-exact with unchanged modes.

## Included evidence

- The exact sealed helper revision1 archive, its detached seal, the complete
  closed independent review and actual route records, and the complete governor
  return including Root's actual final tail.
- Completed helper gate preparation and one fixed 55-file candidate census.
  The recorded candidate is dc64d434d7bcafdd6d4487d275adbed4dd08b4a1,
  sole parent a297957be11feb494c0ec467235794a1e0c54751, with tree
  b783f0cd9eb9f79dc72af2addb5d557005337467. No candidate ref or job existed
  at the supplied cutoff. Future launch and head-review evidence is excluded.
- Exact N10 receiving and the complete closed addendum. Root's existing G0006
  original adjudication retains the full-case NONVERDICT and missing-marker
  limitation. This stage adds no original N10 award.
- Exact G132 selected-host object receiving and one fixed 42-file completed
  candidate census. The recorded unreferenced candidate is
  bd347ba6848e976c993ec82f5aa85d8e5964f6e1, sole parent
  301aeecde08ba6f169bc3cd837eae6f6ad068219, with tree
  bc3f8f1a10cbea041a6bf066acda113f3252360b. The exact new actual-candidate
  rebind source archive, detached seal and actual post-seal tail are included.
  No independent review or source adoption is claimed here.
- The exact 88 H03 task files, complete closed actual actor/caller evidence,
  exact actual receiving archive, detached seal and final persistence result.
  Root's existing G0006 adjudication accepts the scoped semantic observation
  with partial capture; the whole case remains unawarded NONVERDICT.
- Root G0006/G0007 evidence, completed publication10 JSON and blob results,
  historical STATE/ROADMAP and G0006 progress at the fixed cutoff. Optional
  PROGRESS_G0007.jsonl was absent at that cutoff. The supplied G0007 receipt
  is 03a4c376cf2aa12c233d4cbdeef5ec86ebec5d0d. These snapshots cannot confer
  present host authority, and any later Root updates are separate evidence.

The active g132-actual-candidate-independent-review-20261119 and
helper-candidate-head-review-20261119 directories are excluded entirely.
Both fresh-remote.git directories are excluded. No future findings or hosted
results are included or pre-awarded. Original failed receipts, UNKNOWNs and
missing captures remain as recorded. Protected operations are not replayed.

## Exact history and transport

PR255_PRIOR_BODY.md preserves all 63,432 bytes of the pre-condensation body,
SHA-256 9e9e49463b763a1fe33268f374aec9dc6c689b5ecd3e3cf18e974faaf9f26827.
It is also retained under its original name in the Root snapshot.

MANIFEST.json binds every archive, transport part, scope and stage input.
Archive parts are at most 393,216 bytes; the delivery reader uses 49,152-byte
binary chunks encoded as base64. Run `python reassemble_archives.py` to verify
and reconstruct the archives. That unchanged prior utility does not extract or
execute archive content. Outer seals and actual final tails reside under
outer-seals-and-actual-tail in the Root snapshot. Packaging inventories bind the
fixed candidate censuses so later activity cannot enter this checkpoint.

This checkpoint adds evidence only. Existing acceptance boundaries and prior
evidence stay intact. Root is the sole integration and publication writer.
''')

manifest = {'schema': 'implementaudit.additive-continuation-evidence.v1',
            'created_utc': FROZEN_AT, 'parent': PARENT, 'expected_parent': PARENT,
            'base_tree': BASE_TREE, 'prefix': PREFIX, 'archives': archives,
            'files': [{'name': p.name, 'mode': '100644', **desc(p.read_bytes())}
                      for p in sorted(STAGE.iterdir())],
            'archive_part_bytes': PART_BYTES, 'delivery_chunk_bytes': CHUNK_BYTES,
            'prior_leaves_expected': 3577, 'original_new_awards': [],
            'active_review_directories_excluded': initial['active_directories_excluded'],
            'candidate_census_frozen_once': True, 'candidate_pins': candidate_pins,
            'root_continuity_snapshot': {'epoch': 'G0007', 'receipt': ROOT_RECEIPT,
                                         'historical_only': True, 'present_authority_claimed': False},
            'packager_acceptance_judgment': False, 'provider_calls_by_packager': 0,
            'no_protected_or_original_replay': True}
dump(STAGE / 'MANIFEST.json', manifest)
for path in STAGE.iterdir():
    os.chmod(path, 0o644)
    scan(path.read_bytes(), 'stage/' + path.name)

verify = OUT / 'reassembly-verification'
shutil.copytree(STAGE, verify)
result = subprocess.run(['python', str(verify / 'reassemble_archives.py')], capture_output=True, text=True)
dump(OUT / 'REASSEMBLY_VERIFICATION.json', {'returncode': result.returncode,
     'stdout': result.stdout, 'stderr': result.stderr, 'unchanged_reassembler': desc(reassembler.read_bytes())})
assert result.returncode == 0

plain_env = dict(os.environ)
for variable in ['GIT_INDEX_FILE', 'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES', 'GIT_DIR', 'GIT_WORK_TREE']:
    plain_env.pop(variable, None)
plain_env['GIT_OPTIONAL_LOCKS'] = '0'
object_directory = OUT / 'git-objects'
object_directory.mkdir()
env = dict(plain_env, GIT_INDEX_FILE=str(OUT / 'publication.index'),
           GIT_OBJECT_DIRECTORY=str(object_directory),
           GIT_ALTERNATE_OBJECT_DIRECTORIES=str(REPO / '.git/objects'))


def git(*args, isolated=True):
    proc = subprocess.run(['git', *args], cwd=REPO, env=env if isolated else plain_env, capture_output=True)
    record = {'args': args, 'isolated_index_and_objects': isolated, 'returncode': proc.returncode,
              'stdout': desc(proc.stdout), 'stderr': proc.stderr.decode()}
    if len(proc.stdout) < 2000:
        record['stdout_text'] = proc.stdout.decode()
    with (OUT / 'LOCAL_GIT_COMMANDS.jsonl').open('a') as stream:
        stream.write(json.dumps(record) + '\n')
    assert proc.returncode == 0, (args, proc.returncode, proc.stderr.decode())
    return proc.stdout


def repo_guard():
    return {'head': git('rev-parse', 'HEAD', isolated=False).decode().strip(),
            'status': git('status', '--porcelain=v1', isolated=False).decode(),
            'real_index': desc((REPO / '.git/index').read_bytes()),
            'head_file': desc((REPO / '.git/HEAD').read_bytes()),
            'refs': desc(git('for-each-ref', '--format=%(refname) %(objectname)', isolated=False))}


before = repo_guard()
dump(OUT / 'ROOT_REPO_GUARD_BEFORE.json', before)
assert before['head'] == ROOT_HEAD and before['status'] == ''
assert git('rev-parse', PARENT + '^{tree}').decode().strip() == BASE_TREE
assert not git('ls-tree', PARENT, PREFIX).strip()
git('read-tree', PARENT)
additions = []
for path in sorted(STAGE.iterdir()):
    raw = path.read_bytes()
    blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    assert git('hash-object', '-w', str(path)).decode().strip() == blob
    git_path = PREFIX + path.name
    git('update-index', '--add', '--cacheinfo', '100644', blob, git_path)
    additions.append({'path': git_path, 'name': path.name, 'mode': '100644',
                      'type': 'blob', 'sha': blob, **desc(raw)})
tree = git('write-tree').decode().strip()
diff_check = subprocess.run(['git', 'diff', '--check', PARENT, tree], cwd=REPO,
                            env=env, capture_output=True, text=True)
dump(OUT / 'DIFF_CHECK.json', {'returncode': diff_check.returncode,
     'stdout': diff_check.stdout, 'stderr': diff_check.stderr,
     'exact_archival_content_is_not_rewritten_for_whitespace': True})
assert diff_check.returncode in (0, 2), 'Unexpected diff-check failure'
changes = git('diff', '--name-status', PARENT, tree).decode().splitlines()
assert len(changes) == len(additions) and all(line.startswith('A\t' + PREFIX) for line in changes)


def leaves(raw):
    result = {}
    for record in raw.split(b'\0'):
        if not record:
            continue
        metadata, path = record.split(b'\t', 1)
        assert path not in result
        result[path] = metadata
    return result


prior_raw = git('ls-tree', '-rz', '--full-tree', PARENT)
after_raw = git('ls-tree', '-rz', '--full-tree', tree)
(OUT / 'PRIOR_TREE_LEAVES.raw').write_bytes(prior_raw)
(OUT / 'STAGED_TREE_LEAVES.raw').write_bytes(after_raw)
prior_leaves = leaves(prior_raw)
staged_leaves = leaves(after_raw)
assert len(prior_leaves) == 3577
assert all(staged_leaves.get(path) == metadata for path, metadata in prior_leaves.items())
assert len(staged_leaves) == len(prior_leaves) + len(additions)
assert set(staged_leaves) - set(prior_leaves) == {row['path'].encode() for row in additions}
dump(OUT / 'PRIOR_LEAF_PRESERVATION.json', {'base_tree': BASE_TREE, 'tree': tree,
     'prior_leaf_count': len(prior_leaves), 'staged_leaf_count': len(staged_leaves),
     'addition_count': len(additions), 'prior_paths_modes_types_and_blobs_unchanged': True,
     'prior_raw': desc(prior_raw), 'staged_raw': desc(after_raw)})
after = repo_guard()
dump(OUT / 'ROOT_REPO_GUARD_AFTER.json', after)
assert after == before, 'Root HEAD, refs, real index or worktree changed during packaging'

object_counts = {}
for path in object_directory.glob('[0-9a-f][0-9a-f]/*'):
    oid = path.parent.name + path.name
    kind = git('cat-file', '-t', oid).decode().strip()
    assert kind in ('blob', 'tree'), ('unexpected-created-object-type', kind)
    object_counts[kind] = object_counts.get(kind, 0) + 1
dump(OUT / 'LOCAL_MUTATION_BOUNDARY.json', {'owned_index': str(OUT / 'publication.index'),
     'owned_object_directory': str(object_directory), 'object_counts': object_counts,
     'root_head_real_index_refs_worktree_unchanged': True, 'provider_calls': 0,
     'native_remote_operations': 0, 'commit_objects_created': 0, 'ref_operations': 0,
     'controller_operations': 0, 'acceptance_judgments': 0})

publication = {'schema': 'implementaudit.exact-additive-evidence-publication.v1',
               'parent': PARENT, 'expected_parent': PARENT, 'base_tree': BASE_TREE,
               'tree': tree, 'branch': 'engineering/pro-executor-original-completion-20261115',
               'prefix': PREFIX, 'additions': additions,
               'total_bytes': sum(row['bytes'] for row in additions), 'force': False,
               'root_continuity': 'G0007@' + ROOT_RECEIPT,
               'root_continuity_historical_snapshot_only': True,
               'archives': archives, 'manifest': desc((STAGE / 'MANIFEST.json').read_bytes()),
               'prior_leaves_unchanged': 3577, 'original_new_awards': [],
               'provider_calls_by_packager': 0, 'packager_acceptance_judgment': False,
               'scope': 'Local bounded additive completed evidence stage; claims and integration await Root review; active reviews and future host results excluded.',
               'local_verification': {'reassembly_exit': result.returncode,
                                      'diff_check_exit': diff_check.returncode,
                                      'root_repo_guard_unchanged': True,
                                      'isolated_object_counts': object_counts}}
dump(OUT / 'PUBLICATION.json', publication)
summary = {'files': len(additions), 'bytes': publication['total_bytes'], 'tree': tree,
           'parent': PARENT, 'base_tree': BASE_TREE, 'manifest': publication['manifest'],
           'archives': [{k: row[k] for k in ['name', 'bytes', 'sha256', 'members']} for row in archives],
           'reassembly_exit': result.returncode, 'diff_check_exit': diff_check.returncode,
           'prior_leaves_unchanged': 3577, 'root_HEAD_real_index_refs_worktree_unchanged': True,
           'provider_calls': 0, 'object_counts': object_counts,
           'publication': desc((OUT / 'PUBLICATION.json').read_bytes())}
dump(OUT / 'LOCAL_STAGE_SUMMARY.json', summary)
print(json.dumps(summary, indent=2))
