from pathlib import Path
import base64, hashlib, json, sys
root = Path('/workspace/scratch/2678f1e431c3/recovery-publication11')
publication = json.loads((root / 'PUBLICATION.json').read_text())
index, offset = map(int, sys.argv[1:])
assert 0 <= index < len(publication['additions']) and offset >= 0 and offset % 49152 == 0
row = publication['additions'][index]
assert Path(row['name']).name == row['name']
body = (root / 'stage' / row['name']).read_bytes()
assert len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256']
assert hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest() == row['sha']
piece = body[offset:offset + 49152]
assert piece
print(json.dumps({'index': index, 'offset': offset, 'bytes': len(piece), 'base64': base64.b64encode(piece).decode()}))
