from pathlib import Path
import subprocess,sys,json,hashlib,datetime,time
root=Path(__file__).resolve().parent
label,command=sys.argv[1:3]
assert label.replace('_','').replace('-','').isalnum()
stem=root/'evidence'/label
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
t0=time.monotonic()
p=subprocess.run(['bash','-lc',command],cwd='/workspace/scratch/2678f1e431c3',capture_output=True)
finished=datetime.datetime.now(datetime.timezone.utc).isoformat()
Path(str(stem)+'.command.sh').write_text(command+'\n')
Path(str(stem)+'.stdout').write_bytes(p.stdout)
Path(str(stem)+'.stderr').write_bytes(p.stderr)
rec={'command':command,'argv':['bash','-lc',command],'cwd':'/workspace/scratch/2678f1e431c3','started_at':started,'finished_at':finished,'elapsed_seconds':time.monotonic()-t0,'exit_code':p.returncode,'stdout_bytes':len(p.stdout),'stderr_bytes':len(p.stderr),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'capture_truncated':False,'limit':'Full separate process streams; their cross-stream order and provider-authenticated metadata are unavailable.'}
Path(str(stem)+'.json').write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps({k:v for k,v in rec.items() if k not in ['command','argv']},indent=2),flush=True)
sys.stdout.buffer.write(p.stdout)
sys.stdout.buffer.write(p.stderr)
sys.stdout.flush()
raise SystemExit(p.returncode)
