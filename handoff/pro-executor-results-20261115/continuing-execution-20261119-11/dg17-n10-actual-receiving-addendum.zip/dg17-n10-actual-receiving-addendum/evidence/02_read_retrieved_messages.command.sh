nl -ba /workspace/scratch/2678f1e431c3/dg17-n10-actual-receiving-addendum/RETRIEVED_MESSAGES_INPUT.json
