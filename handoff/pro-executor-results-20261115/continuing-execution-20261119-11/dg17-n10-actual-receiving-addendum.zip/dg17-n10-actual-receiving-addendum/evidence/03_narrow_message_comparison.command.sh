python - <<'PY'
from pathlib import Path
import hashlib,json
b=Path('/workspace/scratch/2678f1e431c3');o=b/'dg17-n10-actual-receiving-addendum';old=b/'dg17-n10-actual-receiving'
sha=lambda x:hashlib.sha256(x).hexdigest()
d=json.loads((o/'RETRIEVED_MESSAGES_INPUT.json').read_bytes())
s=json.loads((old/'SEAL.json').read_bytes());ib=(old/'RECEIVED_INPUTS.json').read_bytes();assert sha(ib)==s['input_identity_manifest']['sha256']
identities={r['path']:r for r in json.loads(ib)['files']}
paths=[b/'ordinary-source-assessment-20261118/ROLE_LOAD.json',b/'ordinary-work-observation-20261118/source-layout/skills/implementaudit/references/transcript-contract.md']
for p in paths:
 raw=p.read_bytes();r=identities[str(p)];assert sha(raw)==r['sha256'] and len(raw)==r['bytes']
role=json.loads(paths[0].read_bytes());source=paths[1].read_text().splitlines()
r=d['reviewer'];g=d['governor']
assert r['identity']=='/root/bounded_source_reviewer' and g['identity']=='/root/ordinary_work_governor'
assert r['original_visible_header']=={'message_type':'NEW_TASK','sender':'/root','task_name':r['identity']}
assert g['original_visible_header']=={'message_type':'NEW_TASK','sender':'/root','task_name':g['identity']}
assert r['original_visible_post_load_announcement']==role['visible_announcement']
assert r['announcement_after_role_result']==role['actual_role_load_operation']['result']['chunk_id']=='915024'
marker='CHILD_SKILL_ROUTE=audit-assess'
assert r['marker_in_original_announcement']=='NOT_PRESENT' and marker not in r['original_visible_post_load_announcement']
assert source[394]=='CHILD_SKILL_ROUTE=<selected-child>'
old_result=json.loads((old/'RESULT.json').read_bytes());binding=old_result['evidence_identity']
for payload in [g['original_visible_stage3_payload'],r['original_visible_operational_payload']]:assert binding['envelope_sha256'] in payload
assert binding['resolver_receipt_sha256'] in r['original_visible_operational_payload']
assert role['selected_sha256'] in r['original_visible_operational_payload']
assert 'Root G0004 currentness was freshly required b6b5ac exit0' in g['original_visible_stage3_payload']
for key in ['original_transport_request_id','original_delivery_timestamp','original_host_transport_return']:assert g[key]=='UNAVAILABLE'
observations=[]
for who,key in [('governor','original_visible_stage3_payload'),('reviewer','original_visible_operational_payload'),('reviewer','original_visible_post_load_announcement')]:
 value=d[who][key].encode('utf-8');observations.append({'actor':d[who]['identity'],'field':key,'utf8_bytes':len(value),'sha256':sha(value),'meaning':'UTF-8 encoding of the retained JSON text value, not provider transport-byte identity.'})
out={'schema':'ordinary.n10.retrieved-message-narrow-verification.v1','status':'PASS','retrieval_file':{'path':str(b/'recovery-evidence/N10_RETRIEVED_OPERATIONAL_MESSAGES_G0005.json'),'bytes':len((o/'RETRIEVED_MESSAGES_INPUT.json').read_bytes()),'sha256':sha((o/'RETRIEVED_MESSAGES_INPUT.json').read_bytes())},'prior_seal_sha256':sha((old/'SEAL.json').read_bytes()),'original_role_and_transcript_source_match_prior_input_binding':True,'same_recorded_actor_headers':True,'original_envelope_resolver_role_references_match':True,'recovered_announcement_equals_original_sealed_role_record':True,'required_marker_in_recovered_announcement':False,'reviewer_explicit_original_marker_statement':r['marker_in_original_announcement'],'other_unseen_original_marker':r['other_unseen_original_marker'],'text_value_identities':observations,'transport_metadata':'UNAVAILABLE as retained; no provider raw-byte export','no_actor_source_execution_or_review_rerun':True,'scope':'Narrow data comparisons only; semantic dispositions in report/result.'}
(o/'NARROW_VERIFICATION.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
print('Bound original requirement excerpt:')
for i in range(387,406):print(f'{i+1}: {source[i]}')
PY
