python - <<'PY'
from pathlib import Path
import json,hashlib
p=Path('/workspace/scratch/2678f1e431c3/dg17-n10-actual-receiving-addendum')
setup=json.loads("{\"tool\":\"exec_command\",\"actual_arguments\":{\"cmd\":\"python - <<'PY'\\nfrom pathlib import Path\\np=Path('/workspace/scratch/2678f1e431c3/dg17-n10-actual-receiving-addendum')\\np.mkdir(exist_ok=False)\\n(p/'evidence').mkdir()\\nsource=Path('/workspace/scratch/2678f1e431c3/dg17-n10-actual-receiving/record_command.py').read_text()\\nsource=source.replace(\\\"/workspace/scratch/2678f1e431c3/dg17-n10-actual-receiving\\\",str(p))\\n(p/'record_command.py').write_text(source)\\nprint('Created fresh owned addendum directory and recorder only.')\\nPY\",\"max_output_tokens\":1500},\"actual_result\":{\"chunk_id\":\"1da076\",\"wall_time_seconds\":0.000038849,\"exit_code\":0,\"original_token_count\":15,\"output\":\"Created fresh owned addendum directory and recorder only.\\n\"}}")
(p/'BOOTSTRAP_TOOL_RECEIPT.json').write_text(json.dumps(setup,indent=2)+'\n')
s=Path('/workspace/scratch/2678f1e431c3/recovery-evidence/N10_RETRIEVED_OPERATIONAL_MESSAGES_G0005.json')
b=s.read_bytes();d=json.loads(b)
(p/'RETRIEVED_MESSAGES_INPUT.json').write_bytes(b)
print(json.dumps({'input_path':str(s),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'type':type(d).__name__}))
for k,v in d.items(): print(k,type(v).__name__,len(v) if hasattr(v,'__len__') else v)
old=Path('/workspace/scratch/2678f1e431c3/dg17-n10-actual-receiving')
expected={'SEAL.json':'344c3dd3e8b0eb55d2251672b155d55291ebe78120412e9314a7c2e78f03ad84','REPORT.md':'879c985ac3ddbc5b7e8937fe4268a437e25fb9c2bb96f66f1f008e800c04d039','RESULT.json':'3d27e79df1275940cd11b49345fd51bda8cbb2bc50d42a87a894fdd5a1082733'}
for name,sha in expected.items():
 b=(old/name).read_bytes();actual=hashlib.sha256(b).hexdigest();assert actual==sha
 print(json.dumps({'prior_packet_file':str(old/name),'bytes':len(b),'sha256':actual,'unchanged':True}))
PY
