from pathlib import Path
import json,hashlib,stat
from datetime import datetime,timezone
O=Path('/workspace/scratch/2678f1e431c3/dg17-n10-actual-receiving-addendum')
sha=lambda b:hashlib.sha256(b).hexdigest()
def row(p):b=p.read_bytes();return {'path':p.name,'bytes':len(b),'sha256':sha(b),'mode':oct(stat.S_IMODE(p.stat().st_mode))}
prior=Path('/workspace/scratch/2678f1e431c3/dg17-n10-actual-receiving')
for name,digest in {'SEAL.json':'344c3dd3e8b0eb55d2251672b155d55291ebe78120412e9314a7c2e78f03ad84','REPORT.md':'879c985ac3ddbc5b7e8937fe4268a437e25fb9c2bb96f66f1f008e800c04d039','RESULT.json':'3d27e79df1275940cd11b49345fd51bda8cbb2bc50d42a87a894fdd5a1082733'}.items():assert sha((prior/name).read_bytes())==digest
inp=Path('/workspace/scratch/2678f1e431c3/recovery-evidence/N10_RETRIEVED_OPERATIONAL_MESSAGES_G0005.json')
assert inp.read_bytes()==(O/'RETRIEVED_MESSAGES_INPUT.json').read_bytes() and sha(inp.read_bytes())=='31d9043b883cac61ce4daa77204a71f33811cef17e9fb59f41f6ec321bf81e24'
r=json.loads((O/'RESULT.json').read_bytes());assert r['original_N10_disposition']=='NONVERDICT' and not r['whole_child_route_promoted']
assert (O/'REPORT.md').read_text().rstrip().endswith('N10_ADDENDUM_DISPOSITION: '+r['disposition'])
excluded={'MANIFEST.json','SEAL.json','FINAL_READBACK.json','SEAL_OPERATION_RETURN.json'}
prefixes=('evidence/05_seal_addendum.','evidence/06_final_readback.')
files=sorted(p for p in O.rglob('*') if p.is_file() and p.relative_to(O).as_posix() not in excluded and not p.relative_to(O).as_posix().startswith(prefixes))
rows=[]
for p in files:
    assert not p.is_symlink();p.chmod(0o444);v=row(p);v['path']=p.relative_to(O).as_posix();rows.append(v)
m={'schema':'ordinary.n10.addendum-manifest.v1','files':rows,'file_count':len(rows),'exclusions':sorted(excluded),'excluded_evidence_prefixes':list(prefixes),'scope':'Small narrow addendum only; sealing/readback receipts are explicit post-seal epilogue.'}
mp=O/'MANIFEST.json';mp.write_text(json.dumps(m,indent=2)+'\n');mp.chmod(0o444)
s={'schema':'ordinary.n10.addendum-seal.v1','sealed_at_local_utc':datetime.now(timezone.utc).isoformat(),'disposition':r['disposition'],'original_N10_disposition':'NONVERDICT','report':row(O/'REPORT.md'),'result':row(O/'RESULT.json'),'manifest':row(mp),'retrieved_messages':row(O/'RETRIEVED_MESSAGES_INPUT.json'),'narrow_verification':row(O/'NARROW_VERIFICATION.json'),'prior_seal_sha256':'344c3dd3e8b0eb55d2251672b155d55291ebe78120412e9314a7c2e78f03ad84','prior_seal_report_result_unchanged':True,'payload_files':len(rows),'post_seal_epilogue':list(prefixes)+['FINAL_READBACK.json','SEAL_OPERATION_RETURN.json'],'source_actor_execution_or_replay':False,'old_seal_rewrite':False,'whole_route_or_original_award':False,'seal_meaning':'Local byte custody; not a provider raw export, transport signature, trusted time or acceptance award.'}
sp=O/'SEAL.json';sp.write_text(json.dumps(s,indent=2)+'\n');sp.chmod(0o444)
print(json.dumps({'seal':row(sp),'report':s['report'],'result':s['result'],'manifest':s['manifest'],'payload_files':len(rows),'status':'SEALED'},indent=2))
