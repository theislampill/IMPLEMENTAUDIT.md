"""Independent data-only operation05 receiver; never imports or executes targets."""
from pathlib import Path, PurePosixPath
import ast
import hashlib
import json
import re
import stat

ROOT=Path('/workspace/scratch/097486cde2dd/g132-selected-source-observer-r5-candidate')
OUT=Path(__file__).resolve().parent
R3=ROOT/'evidence/r3-source-candidate'
PRIOR=Path('/workspace/scratch/097486cde2dd/g132-source-custody-r3-independent-review')
OLD=R3/'evidence/diagnostic04-source/candidate'
SOURCE=R3/'evidence/diagnostic04-source/evidence/inherited-full-source/inherited-source'
OWNER='engineering/g132-engine-source-diagnostic/observe.py'
MAP='engineering/g132-engine-source-diagnostic/ENGINE_MAP.json'
WORKFLOW='.github/workflows/dg16-g132-engine-source-observe.yml'
COMMIT='760aaff5c478ff7354d36da186d62daba983aa49'
PARENT='f75533f95f0d099c87e7a04beb11b0a25628acdc'
SOURCE_TREE='f85b199c89e9f6938382ec5f7b2005f54acc8536'
HOST_TREE='b034e01fac9a3a6641847424e9ccb7f7df9b3e99'
BRANCH='pro/dg16-g132-engine-source-observe-20261122-05'
OPERATION='G132_ENGINE_SOURCE_OBSERVE_20261122_05_SELECTED_CUSTODY_R3'
checks=[]

def check(name,value):
    checks.append(dict(name=name,passed=bool(value)))
    if not value: raise ValueError(name)

def sha(raw): return hashlib.sha256(raw).hexdigest()
def git_id(kind,raw): return hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def read(path): return json.loads(path.read_bytes())

def receive_packet(root,seal_hash,seal_bytes,count,payload_bytes):
    raw=(root/'SEAL.json').read_bytes(); seal=json.loads(raw)
    check('seal '+root.name,len(raw)==seal_bytes and sha(raw)==seal_hash)
    paths=set(); total=0
    for row in seal['files']:
        name=row['path']; rel=PurePosixPath(name); path=root/name
        assert not rel.is_absolute() and '..' not in rel.parts and name not in paths
        assert stat.S_ISREG(path.lstat().st_mode)
        value=path.read_bytes()
        assert len(value)==row['bytes'] and sha(value)==row['sha256']
        assert 'git_blob' not in row or git_id('blob',value)==row['git_blob']
        paths.add(name); total+=len(value)
    check('all bytes and exact inventory '+root.name,
          len(paths)==count and total==payload_bytes and
          {str(p.relative_to(root)) for p in root.rglob('*') if not p.is_dir()}==paths|{'SEAL.json'})
    return seal

def tree_rows(path):
    rows={}
    for raw in path.read_bytes().split(b'\0'):
        if not raw: continue
        header,name=raw.split(b'\t',1);mode,kind,oid=header.decode().split(); name=name.decode()
        assert name not in rows
        rows[name]=(mode,kind,oid)
    return rows

def tree_id(rows):
    root={}
    for name,value in rows.items():
        node=root
        for part in name.split('/')[:-1]: node=node.setdefault(part,{})
        assert name.rsplit('/',1)[-1] not in node
        node[name.rsplit('/',1)[-1]]=value
    def digest(node):
        entries=[]
        for name,value in node.items():
            directory=isinstance(value,dict)
            mode,kind,oid=('40000','tree',digest(value)) if directory else value
            entries.append(((name+('/' if directory else '')).encode(),mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(oid)))
        return git_id('tree',b''.join(value for _,value in sorted(entries)))
    return digest(root)

seal=receive_packet(ROOT,'26ba73ab4c5f058ee5839fbcebecdee7ff896d67dcefa047bd80a49e866ac037',422481,1416,8683325)
r3=receive_packet(R3,'fd45ff497cadba67a4719ea9ab8018d3cd13b8f38b687de57634ac3c9403c176',372448,1373,6363913)
prior=receive_packet(PRIOR,'ea738b8112ccd8559831d1f69e46b30de59272ef2eafe5426e37ac3606822087',1485,5,1169140)
check('exact inherited independent R3 review',prior['candidate_seal_sha256']=='fd45ff497cadba67a4719ea9ab8018d3cd13b8f38b687de57634ac3c9403c176')
check('inherited source-only disposition',prior['disposition']=='PASS_SOURCE_REPAIR_AND_RETAINED_LOCAL_EVIDENCE_ONLY')

publication_raw=(ROOT/'evidence/r3-source-publication/PUBLICATION_RECEIPT.json').read_bytes()
check('exact Root source-publication receipt',len(publication_raw)==6703 and sha(publication_raw)=='9e382f02755dba6ac39706ff32bd358129d2345c11dd1dc44fc9095ddbadbeef')
publication=json.loads(publication_raw)
cp=publication['provider_commit']['structuredContent'];rp=publication['provider_ref']['structuredContent']
check('provider response bodies internally agree',cp['content']==cp['structuredContent']['content'] and rp['content']==rp['structuredContent']['content'])
commit=json.loads(cp['content']); ref=json.loads(rp['content'])
check('authentic retained source commit tuple',commit['sha']==publication['commit']==ref['object']['sha']==COMMIT and commit['tree']['sha']==publication['tree']==SOURCE_TREE and [p['sha'] for p in commit['parents']]==[PARENT] and publication['parent']==PARENT)
check('source ref and prior authority boundary',ref['ref']=='refs/heads/pro/dg16-g132-source-custody-r3-20261122-01' and publication['workflows']==[] and publication['original_awards']==[] and publication['protected_authority'] is False)
check('Root source receiving retained',publication['root_admission']=='31fd11/0' and publication['full_body_readback']=='58574a/0' and publication['currentness']=='ab06fd/0')

base=tree_rows(R3/'EXPECTED_TREE.raw'); host=tree_rows(ROOT/'EXPECTED_TREE.raw')
check('independently derived complete source tree',len(base)==1768 and tree_id(base)==SOURCE_TREE)
check('independently derived complete host tree',len(host)==1771 and tree_id(host)==HOST_TREE)
additions={OWNER,MAP,WORKFLOW}
check('exact three additions and every source leaf unchanged',set(host)-set(base)==additions and set(base)<=set(host) and all(host[k]==v for k,v in base.items()))
check('exact candidate file population',{str(p.relative_to(ROOT/'candidate')) for p in (ROOT/'candidate').rglob('*') if not p.is_dir()}==additions)
entries=read(ROOT/'PUBLICATION_ENTRIES.json');plan=read(ROOT/'PUBLICATION_PLAN.json')
check('exact publication plan',plan['base_commit']==COMMIT and plan['base_tree']==SOURCE_TREE and plan['source_parent']==PARENT and plan['expected_tree']==HOST_TREE and plan['expected_file_population']==1771 and plan['branch']==BRANCH and plan['operation']==OPERATION)
check('three publication bodies',len(entries)==3 and {r['path'] for r in entries}==additions)
for row in entries:
    body=(ROOT/'candidate'/row['path']).read_bytes()
    check('exact publication content '+row['path'],row['content'].encode()==body and row['mode']=='100644' and row['type']=='blob' and host[row['path']]==('100644','blob',git_id('blob',body)))
for row in plan['entries']:
    body=(ROOT/'candidate'/row['path']).read_bytes()
    check('publication planned hash '+row['path'],row['bytes']==len(body) and row['sha256']==sha(body) and row['git_blob']==git_id('blob',body) and row['mode']=='100644')

old=(OLD/OWNER).read_text();new=(ROOT/'candidate'/OWNER).read_text(); raw=new.encode()
check('exact observer body',len(raw)==21995 and sha(raw)=='3c0b6bc41662d70e519e2a444e09cd26730d98c5241fd6b3f53bde05a093a5ed')
old_ast=ast.parse(old);new_ast=ast.parse(new)
compile(raw,str(ROOT/'candidate'/OWNER),'exec',dont_inherit=True)
functions=lambda tree:{n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
assigns=lambda tree:{n.targets[0].id:n for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
of,nf=functions(old_ast),functions(new_ast);oa,na=assigns(old_ast),assigns(new_ast)
segment=lambda text,node:ast.get_source_segment(text,node)
check('only one added function',set(nf)-set(of)=={'captured_storage_description'} and not set(of)-set(nf))
check('only observe existing function changed',[n for n in of if segment(old,of[n])!=segment(new,nf[n])]==['observe'])
check('exact five changed global constants',set(oa)==set(na) and {n for n in oa if segment(old,oa[n])!=segment(new,na[n])}=={'SOURCE_COMMIT','SOURCE_TREE','SOURCE_PARENT','BRANCH','SETUP_PIN'})
restored=new
for name in ('SOURCE_COMMIT','SOURCE_TREE','SOURCE_PARENT','BRANCH','SETUP_PIN'):
    restored=restored.replace(segment(new,na[name]),segment(old,oa[name]),1)
start=restored.index('def captured_storage_description(');end=restored.index('def observe():',start)
restored=restored[:start]+restored[end:]
changes=[("        need(re.fullmatch('[0-9a-f]{40}',SOURCE_COMMIT) is not None,\n             'actual published R3 source commit is not bound; do not execute')\n",''),
 ("result['engine_loading_origin']='DIAGNOSTIC_CHECKOUT_R3_SETUP_EXACT_UNCHANGED_R2_ENGINE_MEMBERS'","result['engine_loading_origin']='DIAGNOSTIC_CHECKOUT_EXACT_R2_MEMBERS'"),
 ("result['source_preparation']=dict(commands=commands,expected_commit=SOURCE_COMMIT,expected_parent=SOURCE_PARENT)","result['source_preparation']=dict(commands=commands,expected_commit=SOURCE_COMMIT)"),
 ('setup.prepare_hosted_source_selected_v3(root,output,SOURCE_COMMIT,SOURCE_PARENT,records=commands)','setup.prepare_hosted_source(root,output,SOURCE_COMMIT,records=commands)'),
 ("        result['source_capture']['storage']=captured_storage_description(captured['state'])\n",'')]
for before,after in changes:
    assert restored.count(before)==1
    restored=restored.replace(before,after,1)
check('complete old observer restored byte for byte',restored==old)
for key,wanted in [('SOURCE_COMMIT',COMMIT),('SOURCE_TREE',SOURCE_TREE),('SOURCE_PARENT',PARENT),('BRANCH',BRANCH)]:
    check('exact observer binding '+key,ast.literal_eval(na[key].value)==wanted)
def dict_value(node):
    assert isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='dict' and not node.args
    return {k.arg:ast.literal_eval(k.value) for k in node.keywords}
setup=(R3/'candidate/scripts/qualify-work-graph-c5-setup.py').read_bytes()
check('exact setup pin and published owner',dict_value(na['SETUP_PIN'].value)==dict(bytes=len(setup),sha256=sha(setup)) and len(setup)==90827 and sha(setup)=='7ee5f2282d650692db140629ce436d6502ac0cf4f97786ed8c879192b603e9b0' and publication['changed_files'][0]['git_blob']==git_id('blob',setup))
caps=dict(address_bytes=1610612736,cpu_seconds=120,file_bytes=268435456,descriptors=256,wall_seconds=240,report_bytes=2097152)
bounds=dict(entries=4096,file_bytes=134217728,total_bytes=268435456,depth=40)
check('all exact observer caps unchanged',dict_value(na['CAPS'].value)==caps and segment(old,oa['CAPS'])==segment(new,na['CAPS']))
check('all exact capture bounds unchanged',dict_value(na['CAPTURE_BOUNDS'].value)==bounds and segment(old,oa['CAPTURE_BOUNDS'])==segment(new,na['CAPTURE_BOUNDS']))
check('finite image and Git08ca guard unchanged',segment(old,of['validate_context'])==segment(new,nf['validate_context']) and "('20261116.133.1','20261116.376.1')" in segment(new,nf['validate_context']) and dict_value(na['GIT_PIN'].value)==dict(bytes=4640384,sha256='08ca4d2ee4d8915e86f1faaa52603752507c57af1d16d451dec9992bc9b6d801',mode=493))
calls=[n for n in ast.walk(nf['observe']) if isinstance(n,ast.Call)]
prepares=[n for n in calls if isinstance(n.func,ast.Attribute) and n.func.attr.startswith('prepare_hosted_source')]
captures=[n for n in calls if isinstance(n.func,ast.Attribute) and n.func.attr=='complete_source']
descriptions=[n for n in calls if isinstance(n.func,ast.Name) and n.func.id=='captured_storage_description']
check('exact selected-v3 invocation',len(prepares)==1 and ast.unparse(prepares[0])=='setup.prepare_hosted_source_selected_v3(root, output, SOURCE_COMMIT, SOURCE_PARENT, records=commands)')
check('one capture and one later existing-state description',len(captures)==len(descriptions)==1 and descriptions[0].lineno>captures[0].lineno and ast.unparse(descriptions[0].args[0])=="captured['state']")
wrapper=next(n for n in ast.walk(nf['observe']) if isinstance(n,ast.Try) and len(n.body)==1 and isinstance(n.body[0],ast.Assign) and n.body[0].value is captures[0])
check('authentic exception receiver and unmodified rethrow',segment(old,of['capture_bound_diagnostic'])==segment(new,nf['capture_bound_diagnostic']) and segment(old,of['capture_bound_values'])==segment(new,nf['capture_bound_values']) and len(wrapper.handlers)==1 and ast.unparse(wrapper.handlers[0].type)=='BaseException' and isinstance(wrapper.handlers[0].body[-1],ast.Raise) and wrapper.handlers[0].body[-1].exc is None and not wrapper.orelse and not wrapper.finalbody)
allowed_names={'need','type','len','max','dict','sorted','sum'}
allowed_attributes={'items','startswith','count','endswith','encode','fullmatch','append'}
check('metadata has only scalar and container calls',all((isinstance(c.func,ast.Name) and c.func.id in allowed_names) or (isinstance(c.func,ast.Attribute) and c.func.attr in allowed_attributes) for c in ast.walk(nf['captured_storage_description']) if isinstance(c,ast.Call)))
check('context guards precede imports and effects',new.index("'actual published R3 source commit is not bound; do not execute'")<new.index("validate_context(result['context']")<new.index("setup=types.ModuleType"))
check('unchanged eleven-child audit and selected-only gate',"need(len(subprocess_calls)<11" in new and "try:source=setup.prepare_hosted_source_selected_v3" in new and "finally:allow_git=False" in new)
check('non-admission function and return-seal function unchanged',segment(old,of['base_result'])==segment(new,nf['base_result']) and segment(old,of['seal_return'])==segment(new,nf['seal_return']))

engine=read(ROOT/'candidate'/MAP)
check('exact inherited thirteen-member Engine map',(ROOT/'candidate'/MAP).read_bytes()==(OLD/MAP).read_bytes() and len(engine)==13)
owners=read(ROOT/'FULL_OWNER_PROOFS.json')['owners']
for row in owners:
    value=setup if row['path']=='scripts/qualify-work-graph-c5-setup.py' else (SOURCE/row['path']).read_bytes()
    assert len(value)==row['bytes'] and sha(value)==row['sha256'] and git_id('blob',value)==row['git_blob']==base[row['path']][2] and row['mode']==base[row['path']][0]
check('fourteen full owners authenticated unchanged',len(owners)==14)
for logical,pin in engine.items():
    physical='test-support/r5-hosted-git-08ca-source/work-graph-c5-executor.py' if logical=='scripts/work-graph-c5-executor.py' else logical
    value=(SOURCE/physical).read_bytes()
    assert pin==dict(bytes=len(value),sha256=sha(value))
check('all Engine physical owners bind',True)
profile=read(SOURCE/'fixtures/work-graph-c5-inputs/genuine-r5-hosted-ubuntu24-git-08ca-execution-profile.json')
check('unchanged seventeen selected Git rows',len(profile['git_files'])==17)

workflow=read(ROOT/'candidate'/WORKFLOW);expected=read(OLD/WORKFLOW)
expected['name']='Ordinary R3 selected-source custody and unchanged Engine observation'
expected['on']['push']['branches']=[BRANCH]
expected['concurrency']['group']='g132-engine-source-observe-20261122-05'
expected['jobs']['observe']['env']['EXPECTED_OBSERVER_SHA256']=sha(raw)
expected['jobs']['observe']['steps'][1]['run']=expected['jobs']['observe']['steps'][1]['run'].replace('pro/dg16-g132-engine-source-observe-20261121-04',BRANCH)
check('entire workflow differs only as declared',workflow==expected and (json.dumps(expected,indent=2)+'\n').encode()==(ROOT/'candidate'/WORKFLOW).read_bytes())
check('one exact push trigger no dispatch or cancellation',workflow['on']=={'push':{'branches':[BRANCH]}} and workflow['concurrency']['cancel-in-progress'] is False and workflow['permissions']=={'contents':'read'})
shell=workflow['jobs']['observe']['steps'][1]['run'].encode();syntax=read(ROOT/'BASH_SYNTAX.json')
check('actual syntax-only receipt matches exact workflow shell',syntax['exit']==0 and syntax['input_bytes']==len(shell) and syntax['input_sha256']==sha(shell))
check('attempt-one shell guard and no retry action','test "$GITHUB_RUN_ATTEMPT" = 1' in shell.decode() and 'workflow_dispatch' not in workflow['on'] and len(workflow['jobs']['observe']['steps'])==3)

for prefix,receipt_name in [('CONTROLS','CONTROLS_VALIDATION.json'),('ACTUAL_NONHOST','ACTUAL_NONHOST_VALIDATION.json')]:
    receipt=read(ROOT/receipt_name)
    for stream in ('stdout','stderr'):
        value=(ROOT/(prefix+'_'+stream.upper()+'.raw')).read_bytes()
        assert len(value)==receipt[stream+'_bytes'] and sha(value)==receipt[stream+'_sha256']
    check('actual retained streams '+prefix,receipt['owner_bytes']==len(raw) and receipt['owner_sha256']==sha(raw))
controls=read(ROOT/'CONTROLS_VALIDATION.json');control_text=(ROOT/'CONTROLS_STDERR.raw').read_text()
control_ast=ast.parse((ROOT/'test_hosted_diagnostic.py').read_bytes())
names={n.name for cls in control_ast.body if isinstance(cls,ast.ClassDef) for n in cls.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
received_names=set(re.findall(r'^(test_\S+) \(__main__\.[^\n]+\) \.\.\. ok$',control_text,re.M))
check('actual 23 controls bind to complete driver test population',controls['exit']==0 and controls['tests']==23 and len(names)==23 and names==received_names and '\nRan 23 tests in ' in control_text and control_text.endswith('\nOK\n'))
actual=read(ROOT/'ACTUAL_NONHOST_STDOUT.raw');receipt=read(ROOT/'ACTUAL_NONHOST_VALIDATION.json')
check('actual UID1000 exit2 refusal',receipt['exit']==2 and (ROOT/'ACTUAL_NONHOST_EXIT.raw').read_bytes()==b'2\n' and actual['process']['uid']==actual['process']['euid']==actual['process']['gid']==actual['process']['egid']==1000 and actual['failed_phase']=='context' and actual['reason']=='actual UID/GID zero is required' and actual['status']=='REFUSED')
check('actual refusal exact source and non-admission',actual['source_commit']==COMMIT and actual['source_tree']==SOURCE_TREE and actual['source_parent']==PARENT and actual['ordinary_git_children']==[] and actual['provider_imports']==0 and actual['native_admission'] is False and actual['original_execution'] is False and actual['original_awards']==[] and actual['overall_admission']=='UNQUALIFIED' and actual['resource_caps']==caps and actual['descriptor_restoration'] is None)
static=read(ROOT/'STRUCTURAL_VALIDATION.json')
check('retained 4601-check static result',static['check_count']==len(static['checks'])==4601 and all(row['passed'] is True for row in static['checks']) and static['expected_tree']==HOST_TREE and static['source_capture_calls']==1 and static['product_executions']==0)
unbound=ROOT/'evidence/unbound-draft';draft=read(unbound/'RESULTS.json');draft_source=(unbound/'candidate'/OWNER).read_bytes()
for row in draft:
    for stream in ('stdout','stderr'):
        value=(unbound/(row['name']+'_'+stream.upper()+'.raw')).read_bytes()
        assert len(value)==row[stream+'_bytes'] and sha(value)==row[stream+'_sha256']
    assert row['owner_bytes']==len(draft_source) and row['owner_sha256']==sha(draft_source)
draft_refusal=read(unbound/'ACTUAL_LOCAL_REFUSAL_STDOUT.raw')
check('prior unbound refusal preserved separately',draft[1]['exit']==2 and draft_refusal['source_commit']=='UNBOUND_R3_SOURCE_COMMIT_DO_NOT_EXECUTE' and draft_refusal['reason']=='actual published R3 source commit is not bound; do not execute' and draft_refusal['ordinary_git_children']==[] and draft_refusal['provider_imports']==0)

report=dict(schema='independent.g132.operation05.data-receiving.v1',authority='NONE',reviewer='/root/g132_source_custody_review',operation=OPERATION,
 candidate_seal_sha256=sha((ROOT/'SEAL.json').read_bytes()),payload_count=1416,payload_bytes=8683325,
 inherited_R3_candidate_seal_sha256=sha((R3/'SEAL.json').read_bytes()),inherited_R3_review_seal_sha256=sha((PRIOR/'SEAL.json').read_bytes()),
 source_commit=COMMIT,source_parent=PARENT,source_tree=SOURCE_TREE,host_tree=HOST_TREE,host_parent=COMMIT,
 source_files=1768,host_files=1771,observer_bytes=len(raw),observer_sha256=sha(raw),checks=checks,check_count=len(checks),
 retained_controls=23,retained_static_checks=4601,actual_local_refusal=dict(exit=2,uid=1000,phase='context'),
 reviewer_product_executions=0,reviewer_Git_commands=0,reviewer_hosted_operations=0,reviewer_controller_calls=0,
 reviewer_provider_calls=0,reviewer_original_executions=0,candidate_edits=False,protected_permission=False,native_admission=False,
 limitation='Single authorized initial push requires Root publication discipline; attempt1 is a per-run guard, not a persistent execution ledger.')
with (OUT/'MECHANICAL_RECEIVING.json').open('x') as stream:
    json.dump(report,stream,sort_keys=True,indent=2);stream.write('\n')
print(json.dumps(dict(status='PASS_DATA_RECEIVING',checks=len(checks),payloads=1416,payload_bytes=8683325,host_tree=HOST_TREE,source_commit=COMMIT,reviewer_product_executions=0)))
