"""Receive authentic retained operation05 bytes. No target execution or network."""
from pathlib import Path, PurePosixPath
from io import BytesIO
import ast
import hashlib
import json
import re
import stat
import zipfile
import zlib

ROOT=Path('/workspace/scratch/097486cde2dd/g132-selected-source-native-44967587571')
OUT=Path(__file__).resolve().parent
CANDIDATE=Path('/workspace/scratch/097486cde2dd/g132-selected-source-observer-r5-candidate')
PRIOR=Path('/workspace/scratch/097486cde2dd/g132-selected-source-observer-r5-independent-review')
SOURCE=CANDIDATE/'evidence/r3-source-candidate/evidence/diagnostic04-source/evidence/inherited-full-source/inherited-source'
RUN=44967587571
JOB=137040000736
ARTIFACT=14732286610
HOST='83efd3d5d240ad36ee8e09a76b87290587ece3fd'
HOST_TREE='b034e01fac9a3a6641847424e9ccb7f7df9b3e99'
COMMIT='760aaff5c478ff7354d36da186d62daba983aa49'
TREE='f85b199c89e9f6938382ec5f7b2005f54acc8536'
PARENT='f75533f95f0d099c87e7a04beb11b0a25628acdc'
BRANCH='pro/dg16-g132-engine-source-observe-20261122-05'
WORKFLOW='.github/workflows/dg16-g132-engine-source-observe.yml'
OWNER='engineering/g132-engine-source-diagnostic/observe.py'
OPERATION='G132_ENGINE_SOURCE_OBSERVE_20261122_05_SELECTED_CUSTODY_R3'
CAPS=dict(address_bytes=1610612736,cpu_seconds=120,file_bytes=268435456,descriptors=256,wall_seconds=240,report_bytes=2097152)
checks=[]

def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(path):return json.loads(path.read_bytes())
def check(name,value):
    checks.append(dict(name=name,passed=bool(value)))
    if not value:raise ValueError(name)

def receive_seal(directory,wanted,bytes_count):
    raw=(directory/'SEAL.json').read_bytes();seal=json.loads(raw)
    check('exact seal '+directory.name,len(raw)==bytes_count and sha(raw)==wanted)
    found=set();total=0
    for row in seal['files']:
        path=PurePosixPath(row['path']);p=directory/row['path']
        assert not path.is_absolute() and '..' not in path.parts and str(path) not in found
        assert stat.S_ISREG(p.lstat().st_mode)
        body=p.read_bytes();assert len(body)==row['bytes'] and sha(body)==row['sha256']
        if 'git_blob' in row:
            assert hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()==row['git_blob']
        found.add(str(path));total+=len(body)
    check('all sealed payloads and exact inventory '+directory.name,
          len(found)==seal['payload_count'] and total==seal['payload_bytes'] and
          {str(p.relative_to(directory)) for p in directory.rglob('*') if not p.is_dir()}==found|{'SEAL.json'})
    return seal

packet=receive_seal(ROOT,'869f539ce3ed44cb3e3bb25ead1aa19aa2a85e256288c6a154ea105e6efa274a',2327)
check('exact raw packet population',packet['payload_count']==11 and packet['payload_bytes']==176923 and packet['run_id']==RUN and packet['run_attempt']==1 and packet['head']==HOST and packet['operation']==OPERATION)
prior=receive_seal(PRIOR,'a3ba6074c80df13bc390bc714e53d9500b2a6d04676b4783aa93e5e075c9af6e',1559)
check('prior source-operation review scope',prior['disposition']=='PASS_EXACT_SOURCE_AND_ORDINARY_OPERATION_SPECIFICATION_ONLY' and prior['candidate_seal_sha256']=='26ba73ab4c5f058ee5839fbcebecdee7ff896d67dcefa047bd80a49e866ac037')
candidate_raw=(CANDIDATE/'SEAL.json').read_bytes();candidate_seal=json.loads(candidate_raw)
check('exact reviewed candidate seal',len(candidate_raw)==422481 and sha(candidate_raw)==prior['candidate_seal_sha256'])
candidate_rows={r['path']:r for r in candidate_seal['files']}
def selected_source(relative):
    raw=(CANDIDATE/relative).read_bytes();row=candidate_rows[relative]
    assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
    return raw
owner=selected_source('candidate/'+OWNER)
check('exact previously reviewed observer',len(owner)==21995 and sha(owner)=='3c0b6bc41662d70e519e2a444e09cd26730d98c5241fd6b3f53bde05a093a5ed')
workflow=json.loads(selected_source('candidate/'+WORKFLOW))
engine=json.loads(selected_source('candidate/engineering/g132-engine-source-diagnostic/ENGINE_MAP.json'))
profile_relative='evidence/r3-source-candidate/evidence/diagnostic04-source/evidence/inherited-full-source/inherited-source/fixtures/work-graph-c5-inputs/genuine-r5-hosted-ubuntu24-git-08ca-execution-profile.json'
profile=json.loads(selected_source(profile_relative))

def provider_body(response):
    assert response.get('isError') is False
    s=response['structuredContent']
    if 'structuredContent' in s:
        assert s['content']==s['structuredContent']['content']
    return json.loads(s['content'])

publication=read(ROOT/'PUBLICATION.json');commit=provider_body(publication['provider_commit']);ref=provider_body(publication['provider_ref'])
check('actual host publication tuple',publication['operation']==OPERATION and publication['branch']==BRANCH and publication['commit']==HOST and publication['tree']==HOST_TREE and publication['parent']==COMMIT and commit['sha']==HOST and commit['tree']['sha']==HOST_TREE and [r['sha'] for r in commit['parents']]==[COMMIT] and ref['ref']=='refs/heads/'+BRANCH and ref['object']['sha']==HOST)
check('one initial publication recorded without original authority',publication['first_branch_push'] is True and publication['protected_operation'] is False and publication['original_awards']==[] and len(publication['initial_runs'])==1 and publication['initial_runs'][0]['id']==RUN and publication['initial_runs'][0]['attempt']==1 and publication['initial_runs'][0]['sha']==HOST)
run=provider_body(read(ROOT/'RUN.json'))
check('actual terminal run bound to operation',run['id']==RUN and run['run_attempt']==1 and run['status']=='completed' and run['conclusion']=='success' and run['head_sha']==HOST and run['head_branch']==BRANCH and run['path']==WORKFLOW and run['event']=='push' and run['name']==workflow['name'])
jobs=read(ROOT/'JOBS.json');assert jobs['isError'] is False
jobs=jobs['structuredContent']['jobs']
check('exact terminal job and all steps',len(jobs)==1 and jobs[0]['id']==JOB and jobs[0]['run_id']==RUN and jobs[0]['name']=='observe' and jobs[0]['status']=='completed' and jobs[0]['conclusion']=='success' and all(s['status']=='completed' and s['conclusion']=='success' for s in jobs[0]['steps']))
artifacts=read(ROOT/'ARTIFACTS.json');assert artifacts['isError'] is False
artifacts=artifacts['structuredContent']['artifacts'];archive=(ROOT/'ARTIFACT.zip').read_bytes();transfer=read(ROOT/'TRANSFER.json')
check('exact native artifact and provider digest',len(artifacts)==1 and artifacts[0]['id']==ARTIFACT and artifacts[0]['name']==f'g132-engine-source-{RUN}-1' and artifacts[0]['size_in_bytes']==len(archive)==12542 and artifacts[0]['digest']=='sha256:'+sha(archive) and sha(archive)=='a5d9fa237a9d282bfefd5e462b4fc848f5c67b04a273d56dbb57720790a7e3ff' and artifacts[0]['workflow_run']['id']==RUN and artifacts[0]['workflow_run']['head_sha']==HOST and artifacts[0]['workflow_run']['head_branch']==BRANCH)
check('one retained artifact transfer',transfer['artifact_id']==ARTIFACT and transfer['archive_bytes']==len(archive) and transfer['archive_sha256']==sha(archive) and transfer['reference_requests']==transfer['body_gets']==1 and transfer['retries']==0)
expected_members={'NATIVE_EXIT_STATUS.raw','RETURN.json','OBSERVATION.json','STDERR.raw'}
transfer_rows={r['path']:r for r in transfer['members']}
with zipfile.ZipFile(BytesIO(archive)) as z:
    infos=z.infolist()
    check('exact bounded archive membership',len(infos)==4 and {i.filename for i in infos}==expected_members and all(not i.is_dir() and 0<=i.file_size<=CAPS['report_bytes'] and not i.flag_bits&1 for i in infos))
    for i in infos:
        value=z.read(i);expected=(ROOT/'raw'/i.filename).read_bytes();row=transfer_rows[i.filename]
        check('archive member and retained raw '+i.filename,value==expected and len(value)==i.file_size==row['bytes'] and sha(value)==row['sha256'] and zlib.crc32(value)==i.CRC==row['crc32'])
native=read(ROOT/'raw/RETURN.json')
check('actual native zero exit and no original admission',(ROOT/'raw/NATIVE_EXIT_STATUS.raw').read_bytes()==b'0\n' and native['native_exit_status']==0 and native['native_admission'] is False and native['original_awards']==[] and native['authority']=='NONE' and (ROOT/'raw/STDERR.raw').read_bytes()==b'')
check('native exact return-sealed members',set(native['members'])==expected_members-{'RETURN.json'})
for name,row in native['members'].items():
    value=(ROOT/'raw'/name).read_bytes()
    check('native return seal '+name,len(value)==row['bytes'] and sha(value)==row['sha256'])
logs=read(ROOT/'LOGS.json');assert logs['isError'] is False
logs=logs['structuredContent']['content']
check('independent provider log joins',f'Version: 20261116.376.1' in logs and HOST in logs and sha(owner) in logs and 'SHA256 digest of uploaded artifact zip is '+sha(archive) in logs and f'Final size is 12542 bytes. Artifact ID is {ARTIFACT}' in logs)

o=read(ROOT/'raw/OBSERVATION.json');context=o['context']
expected_context=dict(GITHUB_ACTIONS='true',RUNNER_ENVIRONMENT='github-hosted',GITHUB_REPOSITORY='theislampill/IMPLEMENTAUDIT.md',GITHUB_EVENT_NAME='push',GITHUB_REF='refs/heads/'+BRANCH,GITHUB_RUN_ATTEMPT='1',GITHUB_RUN_ID=str(RUN),GITHUB_SHA=HOST,GITHUB_JOB='observe',GITHUB_WORKFLOW_SHA=HOST,GITHUB_WORKFLOW_REF='theislampill/IMPLEMENTAUDIT.md/'+WORKFLOW+'@refs/heads/'+BRANCH,ImageOS='ubuntu24',ImageVersion='20261116.376.1')
check('actual complete hosted context',context==expected_context and all(o['process'][k]==0 for k in ('uid','euid','gid','egid')) and o['process']['executable']=='/usr/bin/python3.12')
check('actual exact observer and source identity',o['diagnostic_owner']['bytes']==len(owner) and o['diagnostic_owner']['sha256']==sha(owner) and o['source_commit']==COMMIT and o['source_tree']==TREE and o['source_parent']==PARENT)
check('caps and non-admission maintained',o['resource_caps']==CAPS and o['native_admission'] is False and o['overall_admission']=='UNQUALIFIED' and o['original_awards']==[] and all(o[k] is False for k in ('original_execution','session_constructed','provider_acquired','private_inputs_selected','launcher_provisioned','policy_changed')) and o['provider_imports']==0)
check('both exact Engine maps and currentness bookends',o['engine_loaded'] is True and o['engine_map']==o['actual_checkout_engine_map']==engine and len(engine)==13 and o['source_loading_bookends_current'] is True)
gitpin=dict(bytes=4640384,mode=493,sha256='08ca4d2ee4d8915e86f1faaa52603752507c57af1d16d451dec9992bc9b6d801')
check('actual Git08ca bookends',o['git_bookends_equal'] is True and o['git_before']==o['git_after'] and o['git_before']['kind']=='FILE' and all(o['git_before'][k]==v for k,v in gitpin.items()))

source=o['source_preparation'];path=source['path'];commands=source['commands']
check('actual selected source identity and genuine route',source['source_commit']==source['expected_commit']==COMMIT and source['source_tree']==TREE and source['ordered_parents']==[PARENT] and source['preparation']=='COMPLETE_SELECTED_PARENT_THEN_FRESH_CHILD_V3' and source['repository']=='https://github.com/theislampill/IMPLEMENTAUDIT.md.git' and source['credential_source']=='NONE' and source['parent_anchor']=='refs/heads/g132-source-parent' and source['child_fetch_unpack_limit']==64 and source['clean'] is True and source['complete_objects'] is True)
prefix=['/usr/bin/git','-c','credential.helper=','-c','core.askPass=/bin/false','-c','core.hooksPath=/dev/null','-c','gc.auto=0','-c','maintenance.auto=false']
expected_args=[['init','--template=','--object-format=sha1','--initial-branch=g132-source-unborn','--',path],
 ['-C',path,'remote','add','origin','https://github.com/theislampill/IMPLEMENTAUDIT.md.git'],
 ['-C',path,'fetch','--keep','--no-tags','--no-recurse-submodules','--refmap=','origin',PARENT+':refs/heads/g132-source-parent'],
 ['-C',path,'-c','fetch.unpackLimit=64','fetch','--no-tags','--no-recurse-submodules','--refmap=','origin',COMMIT],
 ['-C',path,'checkout','--detach',COMMIT],['-C',path,'show','-s','--format=%H%n%T%n%P','HEAD'],
 ['-C',path,'rev-parse','--is-shallow-repository'],['-C',path,'status','--porcelain=v1','--untracked-files=all','--ignored'],
 ['-C',path,'fsck','--strict','--full'],['-C',path,'rev-list','--objects','--all','--missing=print']]
check('exact ten actual native commands and audit argv',len(commands)==10 and [r['arguments'] for r in commands]==expected_args and o['ordinary_git_children']==[prefix+args for args in expected_args] and len({c['pid'] for c in commands})==10)
environment=dict(PATH='/usr/bin:/bin',LANG='C',LC_ALL='C',TZ='UTC',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_TERMINAL_PROMPT='0',GIT_ASKPASS='/bin/false',GIT_NO_LAZY_FETCH='1',GIT_NO_REPLACE_OBJECTS='1')
lifecycle=['HANDLE_RETURNED','EXIT_OBSERVED_WITHOUT_REAP','OWNED_GROUP_SIGNAL_BEFORE_REAP','CHILD_REAPED','GROUP_ABSENCE_OBSERVED']
command_summary=[]
for i,c in enumerate(commands,1):
    check('command custody '+str(i),c['lifecycle']==lifecycle and c['process_handle_returned'] is True and c['process_creation_outcome']=='HANDLE_RETURNED' and c['exit_observed_without_reap']==dict(code=1,pid=c['pid'],status=0,uid=0) and c['cleanup_child_state']=='EXITED_UNREAPED' and c['cleanup_owned_before_reap'] is True and c['owned_group_signal_attempted_before_reap'] is True and c['owned_group_signal_sent'] is True and c['wait_reaped'] is True and c['raw_wait_status']==c['returncode']==0 and c['owned_group_absent'] is True and c['descriptor_restoration'] is True and c['cleanup_errors']==[] and c['exception'] is None and c['command_received'] is True)
    check('command streams and unchanged bounds '+str(i),c['environment']==environment and c['eof']==dict(stdout=True,stderr=True) and c['output_overflow'] is False and c['timed_out'] is False and 0<=c['elapsed_seconds']<=60 and c['hashes_cover']=='captured bytes' and all(type(x) is int and 0<=x<=4194304 for x in c['stream_bytes'].values()) and all(re.fullmatch('[0-9a-f]{64}',h) for h in c['stream_sha256'].values()))
    if c['stream_bytes']['stderr']<=1024:
        value=c['stderr_excerpt'].encode();assert len(value)==c['stream_bytes']['stderr'] and sha(value)==c['stream_sha256']['stderr']
    for stream in ('stdout','stderr'):
        if c['stream_bytes'][stream]==0:assert c['stream_sha256'][stream]==sha(b'')
    command_summary.append(dict(ordinal=i,pid=c['pid'],arguments=c['arguments'],elapsed_seconds=c['elapsed_seconds'],exit=0,stream_bytes=c['stream_bytes'],custody_received=True))
identity_bytes=(COMMIT+'\n'+TREE+'\n'+PARENT+'\n').encode()
check('actual source identity output digest',commands[5]['stream_bytes']['stdout']==len(identity_bytes)==123 and commands[5]['stream_sha256']['stdout']==sha(identity_bytes))
check('actual nonshallow output digest',commands[6]['stream_bytes']['stdout']==6 and commands[6]['stream_sha256']['stdout']==sha(b'false\n'))
check('actual clean status and strict fsck empty outputs',all(c['stream_bytes']==dict(stdout=0,stderr=0) for c in commands[7:9]))
check('actual full reachable-list receiving',source['object_rows']==13965 and source['object_listing_sha256']==commands[9]['stream_sha256']['stdout']=='372ce71218272cd73cbf0287d6cb428e3f9f9c424f12829b5ea641576411f978' and commands[9]['stream_bytes']['stdout']==963759)
check('three source gates and unchanged Git validator passed',set(o['gates'])=={'git_namespace','producer_contract','captured_head_identity','unchanged_git_input_validator'} and all(g['status']=='PASS' for g in o['gates'].values()))
head=o['gates']['captured_head_identity']['value']
check('genuine actual captured loose HEAD identity',source['loose_head_present'] is True and source['loose_head_member']==head['loose_commit_member']=='.git/objects/76/0aaff5c478ff7354d36da186d62daba983aa49' and head['source_commit']==COMMIT and head['source_tree']==TREE and head['metadata_bytes']==308 and head['loose_commit_sha256']=='9b1f7dd815a4c25ddafba1a8c0433912c9712c0b72bcbd06ec4cef1c78a38f56' and head['basis']=='ACTUAL_CAPTURED_HEAD_AND_HASH_VERIFIED_COMMIT_TREE;OUTER_METADATA_IS_NOT_AUTHORITY')
producer=o['gates']['producer_contract']['value']
check('unchanged original producer contract observed only',producer['original_index']==48 and producer['original_command']=='bash tests/reproducible-release-asset.test.sh\n' and producer['checkout']==dict(clones=2,clone_flags=['--quiet','--no-local','--no-checkout'],checkout_flags=['--quiet','--detach'],status='--porcelain',lifetime='BOTH_WORKTREES_RETAINED_UNTIL_ORIGINAL_EXIT') and producer['compressor']=='GENUINE_ZOPFLI_0.2.3.post1_REQUIRED_NO_SUBSTITUTE' and len(producer['selected_programs'])==6)
gitrows=o['selected_git_file_rows'];validator=o['gates']['unchanged_git_input_validator']['value']
check('all seventeen exact selected Git rows and validator population',len(gitrows)==len(profile['git_files'])==17 and {r['path'] for r in gitrows}==set(profile['git_files'])==set(validator['files']) and set(validator['directories'])==set(profile['git_directories']))
for row in gitrows:
    expected=profile['git_files'][row['path']]
    assert row['expected']==expected and row['match'] is True and all(row['observed'].get(k)==v for k,v in expected.items())
    assert all(validator['files'][row['path']].get(k)==v for k,v in expected.items())
check('all Git input pin values independently compare',True)

capture=o['source_capture'];storage=capture['storage']
check('complete unfiltered actual capture within unchanged bounds',capture['projection']=='ALL_ACTUAL_BYTES_NO_GIT_OR_HIDDEN_OMISSIONS' and capture['files']==1782 and capture['directories']==445 and capture['files']+capture['directories']==2227<=4096 and capture['actual_file_bytes']==203325616<=268435456 and capture['objects']==1708 and capture['object_bytes']==202970293<=capture['actual_file_bytes'] and capture['state_sha256']=='45c8a268b7da2423957c288d585aa815cfbbec2d394f36a4cbbd6edb6833ae66')
check('authentic captured pack description',storage['basis']=='ALREADY_COMPLETED_AUTHENTIC_CAPTURE_STATE' and storage['extra_Git_commands']==storage['extra_capture_calls']==storage['extra_source_reads']==0 and storage['pack_file_count']==len(storage['pack_files'])==1 and storage['pack_file_bytes']==sum(r['bytes'] for r in storage['pack_files'])==storage['maximum_captured_file_bytes']==35454354 and storage['maximum_captured_file_bytes']<=134217728 and storage['pack_files'][0]==dict(path='.git/objects/pack/pack-53811ce62ad0caf2038517f85eda66afcd6dcd29.pack',bytes=35454354,sha256='30f0b477e54fee627e057deefe5f5df84a0677e50b16c1ed5ab5b5d7b57af0b9'))
elapsed=(o['finished_time_ns']-o['started_time_ns'])/1e9
check('actual bounded completion and restoration',o['status']=='OBSERVATION_COMPLETE_WITH_RECORDED_GATE_DISPOSITIONS' and o['descriptor_restoration'] is True and 0<elapsed<240 and len((ROOT/'raw/OBSERVATION.json').read_bytes())==106646<=CAPS['report_bytes'])

inputs=o['selected_host_input_observation'];pins=inputs['pins'];aliases=inputs['system_aliases']
mismatches=[]
for row in pins+aliases:
    computed=all(row['observed'].get(k)==v for k,v in row['expected'].items())
    assert computed==row['match']
    if not computed:
        mismatches.append(dict(path=row['path'],expected=row['expected'],observed={k:row['observed'].get(k) for k in row['expected']},differing_fields=[k for k,v in row['expected'].items() if row['observed'].get(k)!=v]))
check('exact observed host pin census',len(pins)==12 and sum(r['match'] for r in pins)==8 and len(aliases)==4 and all(r['match'] for r in aliases) and {r['path'] for r in mismatches}=={'/etc/ld.so.cache','/lib/x86_64-linux-gnu/libc.so.6','/lib64/ld-linux-x86-64.so.2','/lib/x86_64-linux-gnu/libpthread.so.0'})
check('independent selected host conjunction remains false',inputs['selected_bookends_equal'] is True and o['selected_host_input_matches'] is False and inputs['unchanged_owner_full_startup']==dict(match=False,reason='C5 provider startup/native pin changed: /etc/ld.so.cache') and inputs['nss']['result']['match'] is False and inputs['nss']['result']['reason']=='C5 provider actual passwd NSS is not files-only')
launcher=o['launcher_observation']
check('actual missing launcher remains a blocker',launcher['path']=='/usr/bin/bwrap' and launcher['match'] is False and launcher['observed']['kind']=='MISSING' and launcher['observed']['missing']==['bwrap'] and launcher['expected']==dict(bytes=72160,mode=493,sha256='52231e1caf55bcbc667b269f49c63599a6f7db4767ae6a039580d0ff853db712'))
check('selected host absence and bookends remain observations',len(inputs['absent'])==16 and all(r['kind']=='MISSING' for r in inputs['absent'].values()) and inputs['native_admission'] is False and inputs['overall_admission']=='UNQUALIFIED' and inputs['provider_acquired'] is False and inputs['provider_imports']==0)

result=dict(schema='independent.g132.operation05.native-receiving.v1',authority='NONE',reviewer='/root/g132_source_custody_review',operation=OPERATION,run_id=RUN,run_attempt=1,job_id=JOB,artifact_id=ARTIFACT,
 input_seal_sha256=sha((ROOT/'SEAL.json').read_bytes()),payload_count=11,payload_bytes=176923,archive_sha256=sha(archive),archive_bytes=len(archive),native_exit=0,
 source_commit=COMMIT,source_tree=TREE,source_parent=PARENT,host_commit=HOST,host_tree=HOST_TREE,host_parent=COMMIT,image_version=context['ImageVersion'],
 checks=checks,check_count=len(checks),command_receiving=command_summary,observer_elapsed_seconds=elapsed,commands_elapsed_seconds=sum(c['elapsed_seconds'] for c in commands),
 source_capture=capture,reachable_object_rows=source['object_rows'],host_pin_mismatches=mismatches,host_pin_census=dict(total=12,matched=8,mismatched=4),system_aliases_matched=4,Git_rows_matched=17,
 nss_refusal=inputs['nss']['result']['reason'],full_startup_refusal=inputs['unchanged_owner_full_startup']['reason'],launcher_status='MISSING',
 source_qualification='AUTHENTIC_HOSTED_SELECTED_SOURCE_AND_RECORDED_COMMAND_CUSTODY_PASS',full_host_qualification='BLOCKED',original_awards=[],protected_grant='UNISSUED',
 reviewer_product_Git_hosted_controller_provider_original_executions=0,
 evidence_limit='Retained authenticated observer metadata and command receipts; full Git pack, complete source snapshot bodies and raw rev-list output are not exported in this artifact. No historical cause proof, native original execution, peak-resource proof or transferable full-host admission.')
with (OUT/'MECHANICAL_RECEIVING.json').open('x') as f:json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(dict(status='PASS_NATIVE_RECEIVING_BOUNDED_SOURCE_ONLY',checks=len(checks),run_id=RUN,native_exit=0,commands=10,object_rows=13965,pack_bytes=35454354,captured_bytes=203325616,host_pin_mismatches=len(mismatches),nss='REFUSED',launcher='MISSING',original_awards=[])))
