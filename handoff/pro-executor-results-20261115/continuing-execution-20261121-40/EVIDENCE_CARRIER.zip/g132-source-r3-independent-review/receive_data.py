"""Independent data-only receiving. Never imports/executes the candidate or Git."""
from pathlib import Path, PurePosixPath
import ast
import configparser
import hashlib
import json
import stat
import struct
import zlib

ROOT = Path('/workspace/scratch/097486cde2dd/g132-source-custody-r3-candidate')
OUT = Path(__file__).resolve().parent
INHERITED = ROOT / 'evidence/diagnostic04-source/evidence/inherited-full-source/inherited-source'
RUN = ROOT / 'qualification/local-run-4i5puexs'
checks = []

def check(label, condition):
    checks.append({'name': label, 'passed': bool(condition)})
    if not condition:
        raise ValueError(label)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def git_id(kind, body):
    return hashlib.sha1(kind.encode() + b' ' + str(len(body)).encode() + b'\0' + body).hexdigest()

def read_json(path):
    return json.loads(path.read_bytes())

def tree_id(rows):
    root = {}
    for path, (mode, oid, kind) in rows.items():
        node = root
        for member in path.split('/')[:-1]:
            node = node.setdefault(member, {})
        name = path.rsplit('/', 1)[-1]
        check('tree unique ' + path, name not in node)
        node[name] = (mode, oid, kind)
    def digest(node):
        items = []
        for name, value in node.items():
            directory = isinstance(value, dict)
            mode, oid, kind = ('40000', digest(value), 'tree') if directory else value
            items.append(((name + ('/' if directory else '')).encode(), mode.encode() + b' ' + name.encode() + b'\0' + bytes.fromhex(oid)))
        return git_id('tree', b''.join(value for _, value in sorted(items)))
    return digest(root)

def delta(base, patch):
    at = 0
    def number():
        nonlocal at
        value = shift = 0
        while True:
            byte = patch[at]; at += 1
            value |= (byte & 127) << shift
            if not byte & 128:
                return value
            shift += 7
    if number() != len(base):
        raise ValueError('delta base length')
    wanted = number(); result = bytearray()
    while at < len(patch):
        op = patch[at]; at += 1
        if op & 128:
            offset = size = 0
            for i in range(4):
                if op & (1 << i):
                    offset |= patch[at] << (8*i); at += 1
            for i in range(3):
                if op & (1 << (i+4)):
                    size |= patch[at] << (8*i); at += 1
            size = size or 65536
            if offset + size > len(base):
                raise ValueError('delta copy bound')
            result += base[offset:offset+size]
        elif op:
            result += patch[at:at+op]; at += op
        else:
            raise ValueError('invalid delta opcode')
        if len(result) > wanted:
            raise ValueError('delta output bound')
    if len(result) != wanted:
        raise ValueError('delta length')
    return bytes(result)

def git_objects(repo):
    objects = {}; storage = {}; packs = []
    directory = repo / '.git/objects'
    for path in sorted(directory.glob('[0-9a-f][0-9a-f]/*')):
        raw = path.read_bytes(); decoded = zlib.decompress(raw)
        header, separator, body = decoded.partition(b'\0')
        kind, count = header.decode().split(' ')
        oid = path.parent.name + path.name
        check('loose object ' + str(path.relative_to(ROOT)), separator and int(count) == len(body) and git_id(kind, body) == oid)
        objects[oid] = (kind, body); storage[oid] = 'loose'
    for path in sorted((directory/'pack').glob('*.pack')):
        raw = path.read_bytes()
        check('pack checksum ' + str(path.relative_to(ROOT)), hashlib.sha1(raw[:-20]).digest() == raw[-20:])
        check('pack header ' + str(path.relative_to(ROOT)), raw[:4] == b'PACK' and struct.unpack('>I',raw[4:8])[0] in (2,3))
        count = struct.unpack('>I', raw[8:12])[0]
        at = 12; entries = []; offsets = {}; pack_ids = []
        for _ in range(count):
            start = at; byte = raw[at]; at += 1
            kind_code = (byte >> 4) & 7; size = byte & 15; shift = 4
            while byte & 128:
                byte = raw[at]; at += 1; size |= (byte & 127) << shift; shift += 7
            base = None
            if kind_code == 6:
                byte = raw[at]; at += 1; distance = byte & 127
                while byte & 128:
                    byte = raw[at]; at += 1; distance = ((distance + 1) << 7) | (byte & 127)
                base = start - distance
            elif kind_code == 7:
                base = raw[at:at+20].hex(); at += 20
            decoder = zlib.decompressobj(); payload = decoder.decompress(raw[at:-20])
            check('pack stream EOF ' + str(path.relative_to(ROOT)) + ' ' + str(start), decoder.eof and len(payload) == size)
            at += len(raw[at:-20]) - len(decoder.unused_data)
            entries.append((start, at, kind_code, base, payload))
        check('pack exact final offset ' + str(path.relative_to(ROOT)), at == len(raw) - 20)
        pending = list(entries)
        while pending:
            old = len(pending)
            for item in list(pending):
                start, end, kind_code, base, payload = item
                if kind_code in (1,2,3,4):
                    kind = {1:'commit',2:'tree',3:'blob',4:'tag'}[kind_code]; body = payload
                else:
                    found = offsets.get(base) if kind_code == 6 else objects.get(base)
                    if found is None:
                        continue
                    kind, source = found; body = delta(source,payload)
                oid = git_id(kind,body); offsets[start] = (kind,body)
                if oid in objects:
                    check('consistent repeated object ' + oid, objects[oid] == (kind,body))
                objects[oid] = (kind,body); storage[oid] = 'pack'; pack_ids.append(oid); pending.remove(item)
            check('pack delta resolution progresses ' + str(path.relative_to(ROOT)), len(pending) < old)
        index = path.with_suffix('.idx').read_bytes()
        check('pack index checksums ' + str(path.relative_to(ROOT)), index[:8] == b'\xfftOc\0\0\0\2' and hashlib.sha1(index[:-20]).digest() == index[-20:] and index[-40:-20] == raw[-20:])
        fan = struct.unpack('>256I', index[8:1032])
        check('pack index fanout count ' + str(path.relative_to(ROOT)), list(fan) == sorted(fan) and fan[-1] == count)
        ids = [index[1032+20*i:1052+20*i].hex() for i in range(count)]
        check('pack index exact object identities ' + str(path.relative_to(ROOT)), ids == sorted(pack_ids))
        packs.append({'path':str(path.relative_to(ROOT)),'bytes':len(raw),'sha256':sha(raw),'objects':count})
    return objects, storage, packs

def reachable(objects, start):
    found = set(); todo = [start]
    while todo:
        oid = todo.pop()
        if oid in found:
            continue
        check('reachable object exists ' + oid, oid in objects)
        found.add(oid); kind, body = objects[oid]
        if kind == 'commit':
            for line in body.split(b'\n\n',1)[0].splitlines():
                if line.startswith((b'tree ',b'parent ')):
                    todo.append(line.split(b' ',1)[1].decode())
        elif kind == 'tree':
            at = 0
            while at < len(body):
                zero = body.index(b'\0',at); header = body[at:zero]; at = zero+1
                mode, name = header.split(b' ',1)
                check('tree entry spelling ' + oid + ':' + name.decode(), b'/' not in name and name not in (b'.',b'..'))
                child = body[at:at+20].hex(); at += 20
                if mode != b'160000':
                    todo.append(child)
        elif kind == 'tag':
            todo.append(body.splitlines()[0].split(b' ',1)[1].decode())
    return found

seal_raw = (ROOT/'SEAL.json').read_bytes(); seal = json.loads(seal_raw)
check('exact candidate seal', len(seal_raw)==372448 and sha(seal_raw)=='fd45ff497cadba67a4719ea9ab8018d3cd13b8f38b687de57634ac3c9403c176')
inventory = []
for row in seal['files']:
    name = row['path']; rel = PurePosixPath(name); path = ROOT/name
    check('safe regular payload ' + name, not rel.is_absolute() and '..' not in rel.parts and stat.S_ISREG(path.lstat().st_mode))
    raw = path.read_bytes()
    check('exact payload ' + name, len(raw)==row['bytes'] and sha(raw)==row['sha256'] and git_id('blob',raw)==row['git_blob'])
    inventory.append(row)
actual = {str(path.relative_to(ROOT)) for path in ROOT.rglob('*') if not path.is_dir()}
check('exact complete payload inventory', actual == {row['path'] for row in inventory}|{'SEAL.json'})
check('exact payload population',len(inventory)==1373 and sum(x['bytes'] for x in inventory)==6363913)

source_parent = ROOT/'evidence/diagnostic04-source'
commit = (source_parent/'PARENT_COMMIT.raw').read_bytes()
check('base immutable commit object',git_id('commit',commit)=='f75533f95f0d099c87e7a04beb11b0a25628acdc')
check('base commit tree and sole parent',commit.split(b'\n\n',1)[0].splitlines()[:2]==[b'tree 9b9c2b3f1453b83b87b628b665fceff492bf5b1e',b'parent e76a07b2bae7c945e5a9d529ed8cf9069f4c9064'])
rows = {}
for raw in (source_parent/'PARENT_TREE.raw').read_bytes().split(b'\0'):
    if not raw: continue
    header, path = raw.split(b'\t',1); mode, kind, oid = header.decode().split(); name = path.decode()
    check('base unique path '+name,name not in rows);rows[name]=(mode,oid,kind)
check('base leaf population',len(rows)==1768)
check('base complete tree derivation',tree_id(rows)=='9b9c2b3f1453b83b87b628b665fceff492bf5b1e')
selected = 'scripts/qualify-work-graph-c5-setup.py'
before = (INHERITED/selected).read_bytes();after=(ROOT/'candidate'/selected).read_bytes()
check('base setup blob',git_id('blob',before)==rows[selected][1] and len(before)==83152)
check('candidate exact source',len(after)==90827 and sha(after)=='7ee5f2282d650692db140629ce436d6502ac0cf4f97786ed8c879192b603e9b0' and git_id('blob',after)=='515ecf98f5db25454dd8ddf8e61a134264a65458')
def functions(body):
    lines=body.splitlines(keepends=True);tree=ast.parse(body)
    return {node.name:b''.join(lines[node.lineno-1:node.end_lineno]) for node in tree.body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef))}
old = functions(before);new=functions(after)
check('single added function',set(new)-set(old)=={'prepare_hosted_source_selected_v3'} and not(set(old)-set(new)))
check('only hosted_git body changed',[name for name in old if old[name]!=new[name]]==['hosted_git'])
check('42 unchanged functions',len(old)-1==42)
restored=after.replace(new['hosted_git'],old['hosted_git'],1).replace(b'\n\n'+new['prepare_hosted_source_selected_v3'],b'',1)
check('complete source restoration',restored==before)
compile(after,str(ROOT/'candidate'/selected),'exec',dont_inherit=True)
updated=dict(rows);updated[selected]=('100755',git_id('blob',after),'blob')
check('exact proposed complete source tree',tree_id(updated)=='f85b199c89e9f6938382ec5f7b2005f54acc8536')
owners=read_json(ROOT/'FULL_OWNER_PROOFS.json')['owners']
for row in owners:
    raw=(INHERITED/row['path']).read_bytes()
    check('authenticated inherited owner '+row['path'], len(raw)==row['bytes'] and sha(raw)==row['sha256'] and git_id('blob',raw)==row['git_blob']==rows[row['path']][1] and row['mode']==rows[row['path']][0])
check('complete inherited owner count',len(owners)==14)

result=read_json(ROOT/'LOCAL_QUALIFICATION_RESULT.json')
check('retained124check result',result==read_json(RUN/'RESULT.json') and result['check_count']==len(result['checks'])==124 and all(x['passed'] is True for x in result['checks']))
check('actual qualification source and tool boundary',result['owner_sha256']==sha(after) and result['local_git_version']=='git version 2.47.3' and result['network_Git_operations']==0 and result['original_executions']==0)
ret=read_json(ROOT/'LOCAL_CONTROLS_RETURN.json')
for stream in ('stdout','stderr'):
    raw=(ROOT/('LOCAL_CONTROLS_'+stream.upper()+'.raw')).read_bytes()
    check('driver '+stream+' raw receipt',len(raw)==ret[stream+'_bytes'] and sha(raw)==ret[stream+'_sha256'])
check('actual local driver success',ret['exit']==0 and ret['stderr_bytes']==0)
processes=read_json(RUN/'PROCESS_RESULTS.json');process_summary=[]
modes=('success','nonzero','timeout','overflow','orphan_closed','held_pipes','outer_exception','missing_cwd','sigchld_ignore','legacy_orphan_closed')
check('ten process fixture population',len(processes)==len(modes))
for mode, received in zip(modes,processes):
    directory=RUN/mode;row=read_json(directory/'WORKER_RETURN.json')
    for stream in ('stdout','stderr'):
        raw=(directory/('WORKER_'+stream.upper()+'.raw')).read_bytes()
        check('worker raw '+mode+' '+stream,len(raw)==row[stream+'_bytes'] and sha(raw)==row[stream+'_sha256'])
    check('worker actual receipt '+mode,row['exit']==0 and row['stderr_bytes']==0 and received==json.loads((directory/'WORKER_STDOUT.raw').read_bytes()))
    command=received['records'][0]
    check('worker source identity '+mode,received['owner_sha256']==sha(before if mode.startswith('legacy_') else after))
    check('fixture containment boundary '+mode,received['fixture_children_remaining']==0 and all(x['reaped'] for x in received['fixture_descendants']) and command['descriptor_restoration'])
    if mode in ('missing_cwd','sigchld_ignore'):
        check('precreation refusal '+mode,command['pid'] is None and not command['process_handle_returned'] and not command['command_received'])
    elif not mode.startswith('legacy_'):
        order=command['lifecycle']
        check('owned group signal before actual reap '+mode,command['cleanup_owned_before_reap'] and command['owned_group_signal_attempted_before_reap'] and command['wait_reaped'] and order.index('OWNED_GROUP_SIGNAL_BEFORE_REAP')<order.index('CHILD_REAPED')<order.index('GROUP_ABSENCE_OBSERVED'))
        check('raw wait status maps '+mode,command['raw_wait_status'] is not None)
    check('only normal fixture accepted '+mode,command['command_received']==(mode=='success'))
    process_summary.append({'mode':mode,'returncode':command['returncode'],'command_received':command['command_received'],'wait_reaped':command['wait_reaped'],'group_absent':command['owned_group_absent'],'eof':command['eof'],'lifecycle':command.get('lifecycle'),'fixture_descendants':received['fixture_descendants']})
check('nonzero7 retained',processes[1]['records'][0]['returncode']==7)
check('new controlled closed-pipe descendant killed before fixture cleanup',processes[4]['fixture_descendants'][0]['state']=='EXITED' and processes[4]['fixture_descendants'][0]['exit_code']==-9 and not processes[4]['fixture_descendants'][0]['fixture_cleanup_signal'])
check('legacy descendant still running until fixture cleanup',processes[-1]['fixture_descendants'][0]['state']=='RUNNING' and processes[-1]['fixture_descendants'][0]['fixture_cleanup_signal'])
check('held-pipe outcome correctly limited',processes[5]['fixture_descendants'][0]['state']=='RUNNING' and processes[5]['fixture_descendants'][0]['fixture_cleanup_signal'] and not processes[5]['records'][0]['owned_group_absent'])

receipt=read_json(RUN/'SELECTED_SOURCE_RECEIPT.json');commands=receipt['commands']
check('selected ten successful actual commands',len(commands)==10 and all(x['command_received'] and x['returncode']==0 and x['wait_reaped'] and x['owned_group_absent'] and all(x['eof'].values()) for x in commands))
check('parent and child Git acquisition options','--keep' in commands[2]['arguments'] and '--refmap=' in commands[2]['arguments'] and 'fetch.unpackLimit=64' in commands[3]['arguments'])
selected_root=RUN/'selected-output/source';objects,storage,packs=git_objects(selected_root)
head=receipt['source_commit'];parent=receipt['ordered_parents'][0];closure=reachable(objects,head)
check('selected full object closure exactly9',closure==set(objects) and len(closure)==receipt['object_rows']==9)
check('genuine parent pack and loose HEAD',storage[parent]=='pack' and storage[head]=='loose' and len(packs)==1)
check('actual detached HEAD and normal parent anchor',(selected_root/'.git/HEAD').read_text().strip()==head and (selected_root/'.git/refs/heads/g132-source-parent').read_text().strip()==parent)
commit_body=objects[head][1];headers=commit_body.split(b'\n\n',1)[0].splitlines()
check('source exact tree and sole parent from Git bytes',headers[0]==b'tree '+receipt['source_tree'].encode() and [x[7:].decode() for x in headers if x.startswith(b'parent ')]==[parent])
remote_objects,_,_=git_objects(RUN/'remote');check('selected closure equals actual remote child reachability',closure==reachable(remote_objects,head))
unrelated=(RUN/'remote/.git/refs/heads/unrelated').read_text().strip();check('unrelated branch absent from acquired closure',unrelated not in objects)
clone_results=[]
for lane in ('a','b'):
    clone=RUN/('ordinary-clone-'+lane);clone_objects,_,clone_packs=git_objects(clone)
    check('ordinary clone complete ancestry '+lane,reachable(clone_objects,head)==closure and (clone/'.git/HEAD').read_text().strip()==head)
    clone_results.append({'lane':lane,'reachable_objects':len(closure),'packs':clone_packs})
capture=read_json(RUN/'ACTUAL_LOCAL_CAPTURE.json')
engine=read_json(ROOT/'evidence/diagnostic04-source/candidate/engineering/g132-engine-source-diagnostic/ENGINE_MAP.json')
check('exact13member Engine capture',capture['engine_map']==engine and len(engine)==13)
for logical,row in engine.items():
    physical='test-support/r5-hosted-git-08ca-source/work-graph-c5-executor.py' if logical=='scripts/work-graph-c5-executor.py' else logical
    raw=(INHERITED/physical).read_bytes();check('Engine physical owner '+logical,row=={'bytes':len(raw),'sha256':sha(raw)})
check('full local source capture bounds unchanged',capture['bounds']=={'depth':40,'entries':4096,'file_bytes':134217728,'total_bytes':268435456} and capture['capture_projection']=='ALL_ACTUAL_BYTES_NO_GIT_OR_HIDDEN_OMISSIONS' and capture['files']==14 and capture['directories']==14)
loose=(selected_root/capture['identity']['loose_commit_member']).read_bytes();check('captured loose commit identity independently agrees',sha(loose)==capture['identity']['loose_commit_sha256'] and hashlib.sha1(zlib.decompress(loose)).hexdigest()==head and capture['identity']['source_tree']==receipt['source_tree'])
refusals=read_json(RUN/'SOURCE_REFUSALS.json')
check('wrong-parent refusal retained',refusals[0]['case']=='wrong-parent' and len(refusals[0]['records'])==6 and 'sole parent differs' in refusals[0]['reason'])
large=RUN/'large-child-loose-refusal/source';large_objects,large_storage,_=git_objects(large);large_head=(large/'.git/HEAD').read_text().strip()
check('large genuine packed child refusal retained',refusals[1]['case']=='large-child-loose-refusal' and len(refusals[1]['records'])==10 and large_storage[large_head]=='pack' and not(large/'.git/objects'/large_head[:2]/large_head[2:]).exists())
fixture_commands=read_json(RUN/'FIXTURE_GIT_COMMANDS.json')
for i,row in enumerate(fixture_commands):
    check('retained fixture Git streams '+str(i),sha(row['stdout'].encode())==row['stdout_sha256'] and sha(row['stderr'].encode())==row['stderr_sha256'])
notes=read_json(ROOT/'EVIDENCE_NOTES.json')
check('overwritten early record honestly absent',not(ROOT/'RED_ACTUAL_GIT_RECORD.json').exists() and (ROOT/'POST_IMPLEMENTATION_NORMAL_GIT_RECORD.json').is_file() and 'overwritten' in notes['artifact_label_correction']['limitation'])
check('retained preimplementation two failures',read_json(ROOT/'RED_RESULT.json')['exit']==1 and b'FAILED (failures=2)' in (ROOT/'RED_STDERR.raw').read_bytes())
check('retained parent-storage assertion failure',read_json(ROOT/'PARENT_STORAGE_RED.json')['successful_source_commands']==10 and read_json(ROOT/'PARENT_STORAGE_RED.json')['parent_loose'] is True)

report={'schema':'independent.g132.source-custody-r3.data-receiving.v1','reviewer':'/root/g132_source_custody_review','authority':'NONE','candidate_seal_sha256':sha(seal_raw),'payload_count':len(inventory),'payload_bytes':sum(x['bytes'] for x in inventory),'base_commit':seal['base_commit'],'base_tree':seal['base_tree'],'expected_tree':seal['expected_tree'],'source_bytes':len(after),'source_sha256':sha(after),'checks':checks,'check_count':len(checks),'process_fixtures':process_summary,'selected_source':{'commit':head,'tree':receipt['source_tree'],'parent':parent,'objects':sorted(closure),'packs':packs,'ten_commands_received':True,'actual_local_git':result['local_git_version']},'ordinary_clone_controls':clone_results,'retained_fixture_git_commands':len(fixture_commands),'actual_product_executions_by_reviewer':0,'git_commands_by_reviewer':0,'provider_or_controller_calls':0,'candidate_edits':False,'Opus_sizes_independently_measured':False,'original_or_native_admission':False}
with (OUT/'MECHANICAL_RECEIVING.json').open('x') as stream:
    json.dump(report,stream,indent=2,sort_keys=True);stream.write('\n')
print(json.dumps({'status':'PASS_DATA_RECEIVING','checks':len(checks),'payloads':len(inventory),'payload_bytes':report['payload_bytes'],'selected_fixture_objects':len(closure),'source_tree':seal['expected_tree'],'no_product_or_git_execution':True}))
