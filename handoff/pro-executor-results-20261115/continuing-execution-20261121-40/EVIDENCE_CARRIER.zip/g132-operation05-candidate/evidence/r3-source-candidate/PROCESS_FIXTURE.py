"""Harmless finite child behaviors, used only by isolated local Git aliases."""
import json
import os
from pathlib import Path
import sys
import time

mode,marker=sys.argv[1:]
if mode=='nonzero':
    raise SystemExit(7)
if mode=='overflow':
    os.write(1,b'x'*32768)
    raise SystemExit(0)
if mode=='timeout':
    time.sleep(3)
    raise SystemExit(0)
if mode not in ('orphan_closed','held_pipes'):
    raise SystemExit('unknown fixture behavior')
reader,writer=os.pipe()
child=os.fork()
if child==0:
    os.close(reader)
    Path(marker).write_text(json.dumps(dict(pid=os.getpid(),pgid=os.getpgrp(),
        starttime=Path('/proc/self/stat').read_text().split()[21]))+'\n')
    if mode=='orphan_closed':
        null=os.open('/dev/null',os.O_RDWR)
        for fd in (0,1,2):os.dup2(null,fd)
        if null>2:os.close(null)
    os.write(writer,b'1');os.close(writer)
    time.sleep(10)
    os._exit(0)
os.close(writer)
assert os.read(reader,1)==b'1'
os.close(reader)
raise SystemExit(0)
