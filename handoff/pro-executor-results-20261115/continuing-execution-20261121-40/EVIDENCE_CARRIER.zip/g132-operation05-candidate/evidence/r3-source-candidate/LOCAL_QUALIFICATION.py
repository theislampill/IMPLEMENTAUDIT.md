#!/usr/bin/python3
"""Authorized ordinary local controls. No original or hosted/network operation."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shlex
import signal
import subprocess
import sys
import tempfile
import time
import types

ROOT=Path(__file__).resolve().parent
OWNER=ROOT/'candidate/scripts/qualify-work-graph-c5-setup.py'
LEGACY=ROOT/'evidence/diagnostic04-source/evidence/inherited-full-source/inherited-source/scripts/qualify-work-graph-c5-setup.py'
R2=ROOT/'evidence/diagnostic04-source/evidence/inherited-full-source/inherited-source'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def load(path):
    module=types.ModuleType('ordinary_local_setup')
    module.__file__=str(path)
    exec(compile(path.read_bytes(),str(path),'exec'),module.__dict__)
    return module
def save(path,value):path.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')

def worker(mode,owner,work):
    work=Path(work);owner=Path(owner)
    # This isolated worker is the only ancestor of its test children. Becoming
    # their subreaper lets it retain and reap fixture orphans without touching
    # any other job, process tree, or the product's ordinary host behavior.
    libc=ctypes.CDLL(None,use_errno=True)
    assert libc.prctl(36,1,0,0,0)==0,ctypes.get_errno()  # PR_SET_CHILD_SUBREAPER
    module=load(owner)
    marker=work/'fixture-child.json'
    records=[];output=None;error=None
    fixture_mode='timeout' if mode=='outer_exception' else mode
    arguments=['--version'] if mode in ('success','missing_cwd','sigchld_ignore') else [
        '-c','alias.fixture=!exec /usr/bin/python3.13 -I -S -B '+
        ' '.join(shlex.quote(str(x)) for x in (ROOT/'PROCESS_FIXTURE.py',fixture_mode,marker)),
        'fixture']
    class ControlDeadline(BaseException):pass
    def deadline(signum,frame):raise ControlDeadline('ordinary local outer deadline')
    old_alarm=signal.getsignal(signal.SIGALRM)
    old_child=signal.getsignal(signal.SIGCHLD)
    if mode=='outer_exception':
        signal.signal(signal.SIGALRM,deadline);signal.setitimer(signal.ITIMER_REAL,0.1)
    if mode=='sigchld_ignore':signal.signal(signal.SIGCHLD,signal.SIG_IGN)
    try:
        output=module.hosted_git(arguments,work/'absent-cwd' if mode=='missing_cwd' else work,
            records,wall_seconds=0.25 if mode in ('timeout','held_pipes') else 2,
            stream_limit=1024 if mode=='overflow' else 4194304)
    except BaseException as exc:
        error=dict(type=type(exc).__name__,reason=str(exc))
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        signal.signal(signal.SIGALRM,old_alarm)
        signal.signal(signal.SIGCHLD,old_child)
    marker_data=json.loads(marker.read_bytes()) if marker.exists() else None
    descendants=[]
    # Only this isolated worker's own children are inspected. WNOWAIT proves
    # custody before any fixture-only cleanup signal; no post-reap PID signal.
    def receive_fixture_child(pid,observed):
        before=dict(pid=pid,state='EXITED' if observed is not None else 'RUNNING',
            code=observed.si_code if observed else None,status=observed.si_status if observed else None)
        if observed is None:
            os.kill(pid,signal.SIGKILL)
            before['fixture_cleanup_signal']=True
        else:before['fixture_cleanup_signal']=False
        until=time.monotonic()+2
        while True:
            found,status=os.waitpid(pid,os.WNOHANG)
            if found==pid:break
            assert time.monotonic()<until,'fixture child cleanup exceeded bound'
            time.sleep(0.01)
        before.update(reaped=True,exit_code=os.waitstatus_to_exitcode(status))
        descendants.append(before)
    if marker_data:
        pid=marker_data['pid']
        receive_fixture_child(pid,os.waitid(os.P_PID,pid,os.WEXITED|os.WNOHANG|os.WNOWAIT))
    deadline_at=time.monotonic()+3
    while True:
        try:observed=os.waitid(os.P_ALL,0,os.WEXITED|os.WNOHANG|os.WNOWAIT)
        except ChildProcessError:break
        assert len(descendants)<=8 and time.monotonic()<deadline_at,'fixture children remain'
        if observed is None:
            time.sleep(0.01)
        else:receive_fixture_child(observed.si_pid,observed)
    result=dict(mode=mode,owner_sha256=sha(owner.read_bytes()),records=records,error=error,
        output_bytes=len(output) if output is not None else None,
        output_sha256=sha(output) if output is not None else None,fixture_marker=marker_data,
        fixture_descendants=descendants,fixture_children_remaining=0,
        product_module_executed=True,original_execution=False,hosted_execution=False)
    print(json.dumps(result,sort_keys=True))

def qualify():
    parent=ROOT/'qualification';parent.mkdir(exist_ok=True)
    run=Path(tempfile.mkdtemp(prefix='local-run-',dir=parent))
    checks=[];commands=[]
    def check(name,value):
        checks.append(dict(name=name,passed=bool(value)))
        if not value:
            save(run/'PARTIAL_CHECKS.json',checks)
            raise AssertionError(name)
    process_results=[]
    for mode in ('success','nonzero','timeout','overflow','orphan_closed','held_pipes',
                 'outer_exception','missing_cwd','sigchld_ignore','legacy_orphan_closed'):
        work=run/mode;work.mkdir(mode=0o700)
        actual_mode='orphan_closed' if mode=='legacy_orphan_closed' else mode
        owner=LEGACY if mode=='legacy_orphan_closed' else OWNER
        argv=['/usr/bin/python3.13','-I','-S','-B',str(__file__),'--worker',actual_mode,str(owner),str(work)]
        proc=subprocess.run(argv,cwd=work,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False,timeout=12)
        (work/'WORKER_STDOUT.raw').write_bytes(proc.stdout);(work/'WORKER_STDERR.raw').write_bytes(proc.stderr)
        save(work/'WORKER_RETURN.json',dict(argv=argv,exit=proc.returncode,stdout_bytes=len(proc.stdout),
            stdout_sha256=sha(proc.stdout),stderr_bytes=len(proc.stderr),stderr_sha256=sha(proc.stderr)))
        check(mode+' worker completed',proc.returncode==0 and not proc.stderr)
        value=json.loads(proc.stdout);process_results.append(value)
        record=value['records'][0]
        check(mode+' descriptor restoration',record['descriptor_restoration'] is True)
        check(mode+' own fixture children reaped',value['fixture_children_remaining']==0)
        if mode=='success':
            check('normal command accepted',value['error'] is None and record['returncode']==0 and record['command_received'])
        else:check(mode+' refuses',value['error'] is not None and not record['command_received'])
        if mode in ('missing_cwd','sigchld_ignore'):
            check(mode+' no process handle',not record['process_handle_returned'] and record['pid'] is None)
            continue
        check(mode+' direct child actually reaped',record['wait_reaped'] is True)
        if mode=='legacy_orphan_closed':
            leaf=next(x for x in value['fixture_descendants'] if x['pid']==value['fixture_marker']['pid'])
            check('old helper leaves controlled descendant running',leaf['state']=='RUNNING' and leaf['fixture_cleanup_signal'])
            continue
        order=record['lifecycle']
        check(mode+' owned group signal precedes actual reap',record['cleanup_owned_before_reap']
              and record['owned_group_signal_attempted_before_reap']
              and order.index('OWNED_GROUP_SIGNAL_BEFORE_REAP')<order.index('CHILD_REAPED')
              <order.index('GROUP_ABSENCE_OBSERVED'))
        check(mode+' true raw wait status retained',type(record['raw_wait_status']) is int)
        if mode in ('success','nonzero','orphan_closed'):
            check(mode+' normal exit observed without reap',record['exit_observed_without_reap'] is not None
                  and order.index('EXIT_OBSERVED_WITHOUT_REAP')<order.index('OWNED_GROUP_SIGNAL_BEFORE_REAP'))
        if mode=='nonzero':check('nonzero status retained',record['returncode']==7)
        if mode in ('timeout','held_pipes'):check(mode+' finite wall refusal',record['timed_out'])
        if mode=='overflow':check('bounded stream overflow refusal',record['output_overflow']
            and record['stream_bytes']['stdout']>1024 and record['hashes_cover']=='captured prefix only')
        if mode=='outer_exception':check('outer BaseException preserved',value['error']['type']=='ControlDeadline')
        if mode=='orphan_closed':
            leaf=next(x for x in value['fixture_descendants'] if x['pid']==value['fixture_marker']['pid'])
            check('new helper terminates controlled same-group descendant',leaf['state']=='EXITED'
                  and leaf['exit_code']==-signal.SIGKILL and not leaf['fixture_cleanup_signal'])
            check('surviving zombie group truthfully refuses',not record['owned_group_absent'] and not record['command_received'])
    save(run/'PROCESS_RESULTS.json',process_results)
    save(run/'PROCESS_CHECKS.json',checks)

    env=dict(PATH='/usr/bin:/bin',LANG='C',LC_ALL='C',TZ='UTC',GIT_CONFIG_NOSYSTEM='1',
        GIT_CONFIG_GLOBAL='/dev/null',GIT_NO_LAZY_FETCH='1',GIT_NO_REPLACE_OBJECTS='1',
        GIT_TERMINAL_PROMPT='0',GIT_ALLOW_PROTOCOL='file',
        GIT_AUTHOR_NAME='Local Fixture',GIT_AUTHOR_EMAIL='fixture@invalid',
        GIT_COMMITTER_NAME='Local Fixture',GIT_COMMITTER_EMAIL='fixture@invalid',
        GIT_AUTHOR_DATE='2026-11-21T00:00:00Z',GIT_COMMITTER_DATE='2026-11-21T00:00:00Z')
    def git(path,*args,allowed=(0,)):
        argv=['/usr/bin/git','-c','core.hooksPath=/dev/null','-c','gc.auto=0',
              '-c','maintenance.auto=false','-C',str(path),*args]
        p=subprocess.run(argv,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False,timeout=10)
        commands.append(dict(argv=argv,exit=p.returncode,stdout=p.stdout.decode('utf-8','replace'),
            stderr=p.stderr.decode('utf-8','replace'),stdout_sha256=sha(p.stdout),stderr_sha256=sha(p.stderr)))
        check('local fixture Git '+str(len(commands)),p.returncode in allowed)
        return p.stdout
    remote=run/'remote';remote.mkdir(mode=0o700)
    git(remote,'init','--template=','--initial-branch=selected')
    (remote/'tracked.txt').write_text('base\n');git(remote,'add','tracked.txt');git(remote,'commit','-m','fixture base')
    base=git(remote,'rev-parse','HEAD').decode().strip()
    (remote/'tracked.txt').write_text('parent\n');git(remote,'add','tracked.txt');git(remote,'commit','-m','fixture parent')
    parent_commit=git(remote,'rev-parse','HEAD').decode().strip()
    (remote/'tracked.txt').write_text('child\n');git(remote,'add','tracked.txt');git(remote,'commit','-m','fixture child')
    child=git(remote,'rev-parse','HEAD').decode().strip();child_tree=git(remote,'rev-parse','HEAD^{tree}').decode().strip()
    expected_objects={x.split()[0] for x in git(remote,'rev-list','--objects',child).splitlines()}
    git(remote,'checkout','-b','unrelated',base)
    (remote/'only-unrelated.txt').write_text('not in selected ancestry\n')
    git(remote,'add','only-unrelated.txt');git(remote,'commit','-m','unrelated fixture branch')
    unrelated=git(remote,'rev-parse','HEAD').decode().strip()
    git(remote,'checkout','-b','large-child',parent_commit)
    for i in range(70):(remote/('large-%03d.txt'%i)).write_text('large child item '+str(i)+'\n')
    git(remote,'add','.');git(remote,'commit','-m','large fixture child')
    large=git(remote,'rev-parse','HEAD').decode().strip()
    module=load(OWNER)
    bindings=dict(module.__dict__);bindings['HOSTED_SOURCE_URL']=str(remote)
    selected=module.prepare_hosted_source_selected_v3
    local=types.FunctionType(selected.__code__,bindings,selected.__name__,selected.__defaults__)
    local.__kwdefaults__=dict(selected.__kwdefaults__)
    check('production URL not mutated',module.HOSTED_SOURCE_URL=='https://github.com/theislampill/IMPLEMENTAUDIT.md.git')
    check('local source control uses exact product code object',local.__code__ is selected.__code__)
    output=run/'selected-output';output.mkdir(mode=0o700);records=[]
    save(run/'FIXTURE_GIT_COMMANDS.json',commands)
    try:received=local(ROOT/'candidate',output,child,parent_commit,records=records)
    except BaseException as exc:
        save(run/'SOURCE_ATTEMPT_FAILURE.json',dict(records=records,type=type(exc).__name__,reason=str(exc)))
        raise
    save(run/'SELECTED_SOURCE_RECEIPT.json',received)
    check('ten genuine selected-source command receipts',len(records)==10 and all(x['command_received'] for x in records))
    check('complete selected tuple',received['source_commit']==child and received['source_tree']==child_tree
          and received['ordered_parents']==[parent_commit] and received['clean'] and received['complete_objects'])
    source=Path(received['path'])
    actual_objects={x.split()[0] for x in git(source,'rev-list','--objects','--all').splitlines()}
    check('all and only selected ancestry object identities',actual_objects==expected_objects)
    check('unrelated branch was not acquired',unrelated.encode() not in actual_objects)
    check('full parent is genuinely packed',not (source/'.git/objects'/parent_commit[:2]/parent_commit[2:]).exists()
          and len(list((source/'.git/objects/pack').glob('*.pack')))==1)
    check('fresh child is genuinely loose',(source/received['loose_head_member']).is_file())
    check('empty init templates retained',not (source/'.git/hooks').exists())
    check('only normal parent anchor retained',git(source,'for-each-ref','--format=%(refname)').splitlines()==
          [b'refs/heads/g132-source-parent'])
    # Genuine ordinary product data acquisition on the bounded local fixture.
    # No original/session/provider is constructed or invoked.
    current=module.hosted_current_owner(R2)
    engine_map={name:dict(bytes=len(value[0]),sha256=sha(value[0])) for name,value in current.SOURCES.items()}
    expected_map=json.loads((ROOT/'evidence/diagnostic04-source/candidate/engineering/g132-engine-source-diagnostic/ENGINE_MAP.json').read_bytes())
    check('unchanged exact thirteen-member Engine',engine_map==expected_map)
    objects={};captured=current.B.complete_source(source,objects)
    current.P.validate_git_namespace(captured['state'],objects)
    captured_identity=current.captured_source_identity(captured,objects,dict(source_commit=child,source_tree=child_tree))
    current.CHECK()
    save(run/'ACTUAL_LOCAL_CAPTURE.json',dict(engine_map=engine_map,identity=captured_identity,
        files=len(captured['state']['files']),directories=len(captured['state']['directories']),
        capture_projection=captured['projection'],bounds=dict(current.P.SOURCE_BOUNDS),
        original_execution=False,session_constructed=False,native_admission=False))
    check('unchanged captured-HEAD owner accepts genuine local storage',captured_identity['source_commit']==child)
    for lane in ('a','b'):
        clone=run/('ordinary-clone-'+lane)
        git(run,'clone','--quiet','--no-local','--no-checkout',str(source),str(clone))
        git(clone,'checkout','--quiet','--detach',child)
        check('ordinary clone '+lane+' is clean',git(clone,'status','--porcelain')==b'')
        check('ordinary clone '+lane+' retains full ancestry',
              {x.split()[0] for x in git(clone,'rev-list','--objects','HEAD').splitlines()}==expected_objects)
    refusals=[]
    for label,expected,parent_expected in [('wrong-parent',child,base),('large-child-loose-refusal',large,parent_commit)]:
        output=run/label;output.mkdir(mode=0o700);records=[]
        try:local(ROOT/'candidate',output,expected,parent_expected,records=records)
        except (OSError,ValueError) as exc:refusals.append(dict(case=label,type=type(exc).__name__,reason=str(exc),records=records))
        else:raise AssertionError(label+' unexpectedly succeeded')
    check('wrong expected parent refuses at exact identity',refusals[0]['type']=='ValueError'
          and 'sole parent differs' in refusals[0]['reason'] and len(refusals[0]['records'])==6)
    check('large genuine fetched child stays packed and refuses',len(refusals[1]['records'])==10
          and not (run/'large-child-loose-refusal/source/.git/objects'/large[:2]/large[2:]).exists())
    save(run/'SOURCE_REFUSALS.json',refusals)
    git_version=git(run,'--version').decode().strip()
    save(run/'FIXTURE_GIT_COMMANDS.json',commands)
    result=dict(status='PASS_BOUNDED_ORDINARY_LOCAL_QUALIFICATION',run_directory=str(run),checks=checks,
        check_count=len(checks),owner_sha256=sha(OWNER.read_bytes()),local_git_version=git_version,
        production_URL_unchanged=True,test_only_transport_binding=str(remote),
        source_control_code_identity_equal=True,actual_local_product_capture=True,actual_local_Engine_members=13,
        original_executions=0,hosted_operations=0,network_Git_operations=0,provider_calls=0,controller_calls=0,
        actual_index_pack_failure_cause='UNPROVED',operation03_capture_disjunct='UNPROVED')
    save(run/'RESULT.json',result);save(ROOT/'LOCAL_QUALIFICATION_RESULT.json',result)
    print(json.dumps(dict(status=result['status'],check_count=result['check_count'],run_directory=str(run)),indent=2))

if __name__=='__main__':
    if sys.argv[1:2]==['--worker']:worker(*sys.argv[2:])
    else:qualify()
