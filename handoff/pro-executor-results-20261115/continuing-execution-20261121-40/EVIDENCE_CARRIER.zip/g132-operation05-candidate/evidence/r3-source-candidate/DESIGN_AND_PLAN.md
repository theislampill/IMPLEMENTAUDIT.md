# Prospective G132 source custody R3

Author: `/root/g132_capture_bound_engineering`. Integration/closure authority: NONE. Root initially supplied G0044 receipt `3fb3e2d80b1575b3a4ec28cc196957f9ce498523`, currentness `926f78/0`; after the child's context boundary Root freshly verified G0045 receipt `refs/implementaudit/continuity-receipts/dg16-dg18-recovery-20261119-b/G0045@da78b456997516f38e8e8b048c221bec6e4c0c4b` with `9be00b/0` and explicitly confirmed this bounded continuation. Only Root may integrate or publish. This task permits isolated ordinary local fixture repositories and child-process controls; it permits no hosted operation, original, protected grant, provider write, controller operation, historical mutation, or network Git operation.

## Evidence and scope

Operation 04 run 44963085468 attempt 1 failed on its first full-remote clone: exit 128, `fatal: fetch-pack: invalid index-pack output`, direct child reaped, group absence false, no timeout/overflow. No source tuple or capture diagnostic was reached. Its index-pack cause and group-member identities/states remain unproved. Operation 03's capture-bound operands remain unproved. Both runs stay terminal and are not replayed.

The unchanged source contract requires complete selected source bytes, full ancestry/object storage, clean nonshallow Git storage, exact commit/tree/parents, ordinary namespace, and a genuinely retained loose HEAD commit. It does not require fetching unrelated remote branches. `validate_git_namespace` permits a minimal core/origin configuration and forbids shallow/alternate/promisor/replacement storage. `_producer_contract` preserves all source program/package selectors and clone behavior.

## Chosen changes

Only `scripts/qualify-work-graph-c5-setup.py` is proposed for source publication on base f75533f95f0d099c87e7a04beb11b0a25628acdc (tree 9b9c2b3f1453b83b87b628b665fceff492bf5b1e, parent e76a07b2bae7c945e5a9d529ed8cf9069f4c9064). No Engine member, map, loader dispatch/pin, capture owner, runtime profile, or original prerequisite changes.

1. Repair ordinary `hosted_git` wait custody. Keep the direct child unreaped while observing completion with `waitid(P_PID, ..., WEXITED|WNOHANG|WNOWAIT)`. Before any reap, verify continued direct-child custody, then signal only that owned session/group. Reap with bounded actual `waitpid` receipt, preserving the true status. After reap, only the existing zero-signal absence observation is allowed; no cleanup signal may target a reusable numerical PGID. Default SIGCHLD disposition is required. Retain finite wall/output/cleanup bounds, complete bounded pipe capture, exception propagation, descriptor restoration, and truthful refusal when group absence or cleanup is unproved.

2. Add an explicit `prepare_hosted_source_selected_v3` route with a required exact expected parent. Preserve the existing `prepare_hosted_source` body byte for byte. The new route uses ten fixed Git commands: empty-template init; fixed-origin add; full exact-parent fetch into a fresh normal anchor with `--keep`; incremental exact-child fetch with `fetch.unpackLimit=64`; detached checkout; exact identity read; nonshallow check; clean check; strict/full fsck; complete object listing. Both fetches use no tags/submodules/configured ref mapping and no depth, filter, alternates, lazy fetching, replacement objects, manual repack/unpack, or synthetic source objects. All actual fetched storage remains present for full capture. The parent anchor is retained. The fresh unborn branch has a different name so Git does not refuse updating the anchor as the checked-out branch.

The finite child unpack threshold is prospective Git acquisition behavior, not a new snapshot bound. If the requested child delta is too large to be received loose, the route refuses on the existing loose-HEAD prerequisite; it does not repair storage after acquisition. The final parent must equal the supplied parent exactly. A future observer must call this explicit route and bind the actual published source commit/tree/parent and changed setup bytes; this packet does not invent that future commit identity.

The WNOWAIT route fixes a concrete ownership-order defect. Selected-source preparation reduces scope to the actual required closure and arranges supported genuine acquisition of the required loose HEAD. Neither change is claimed to diagnose or cure operation 04's index-pack failure or operation 03's unknown capture bound.

The initial local parent-acquisition proposal used `fetch.unpackLimit=0`. Its ten commands succeeded but actual inspection found the parent loose and no pack, so its packed-parent assertion failed. That source body, receipt, and failure remain in the packet. The final route uses Git's explicit documented `--keep` option; the actual local control verifies a received parent pack. The initially colliding unborn/anchor names likewise have a retained actual failure and superseded source body. Neither qualification correction changes a consumer guard.

## Alternatives and limits

Blindly killing a reaped PGID is rejected. Leaving the direct child unreaped until group cleanup preserves the owned identity. A full process census or universal descendant claim is outside scope; a descendant that changes session can remain outside this group contract, and remaining zombies may still cause a truthful group-absence refusal.

A single exact fetch satisfies history selection but may retain HEAD only in a pack, violating the existing owner. The two-fetch route uses Git itself to receive the fresh child objects. Manual object synthesis, repack/unpack, source omission, and looser capture/resource bounds are rejected. A change to original clone/build semantics is outside scope.

## Qualification plan

Before implementation, run focused red controls for the missing selected-source route and missing WNOWAIT custody receipt. Then qualify actual `hosted_git` in isolated subprocess workers: ordinary success, nonzero child, timeout, output overflow, a direct-child exit with a same-group descendant that closes pipes, a descendant holding pipes, outer exception, missing cwd, and refused auto-reap disposition. Use real Git aliases only to invoke harmless bounded test fixtures. Each worker owns/reaps its fixture descendants; fixture cleanup signals only still-owned children, never an unrelated/reaped PID.

Qualify selected-source behavior against a new local fixture repository containing complete parent ancestry, a fresh child, and an unrelated branch. Use the exact product function code with an explicitly disclosed local-only transport binding in a separate function-global mapping; the production function/module and fixed public URL remain unchanged. The local transport never performs a network Git operation. Require all ten real command receipts, exact selected closure, no unrelated refs/objects, packed parent plus genuinely loose child, clean/nonshallow/fsck, and compatibility with the unchanged ordinary clone flags. Exercise wrong-parent and loose-HEAD refusal using bounded counterfactual fixtures.

Read the full pinned source contract and retain complete bodies. Prove all other functions and dispatch/pins unchanged, derive the exact one-file candidate tree in memory from the authenticated parent, and retain source delta, tests, actual local receipts, prior authentic failure evidence, limitations, and full source packet. Do not run the original test, hosted operation, broad unrelated package suite, or historical recovery.

Acceptance: an independently reviewable prospective source candidate with real bounded local qualification and exact publication plan. Native hosted compatibility, index-pack cause, capture operands, protected execution, original awards, and closure remain unqualified.

Rollback: abandon the uncommitted candidate. No existing source checkout, packet, Git ref, or provider state is changed.

## Primary technical references

- Python 3.12 `os.waitid`: https://docs.python.org/3.12/library/os.html#os.waitid
- Linux `waitid`, WNOWAIT and zombie/wait custody: https://man7.org/linux/man-pages/man2/waitid.2.html
- Git exact-ref/object fetching and empty ref mapping: https://git-scm.com/docs/git-fetch/2.43.0.html
- Git `fetch.unpackLimit`: https://git-scm.com/docs/git-config/2.44.3.html
- Git init templates: https://git-scm.com/docs/git-init/2.43.0

These references support API semantics only. They do not establish any historical failure cause or qualify the actual hosted Git08ca environment.
