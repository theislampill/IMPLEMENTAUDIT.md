#!/usr/bin/python3
"""Verify retained inputs and derive the prospective tree without Git writes."""
import argparse
import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'evidence/diagnostic04-source/evidence/inherited-full-source/inherited-source'
OWNER = 'scripts/qualify-work-graph-c5-setup.py'
BASE = 'f75533f95f0d099c87e7a04beb11b0a25628acdc'
BASE_TREE = '9b9c2b3f1453b83b87b628b665fceff492bf5b1e'
BASE_PARENT = 'e76a07b2bae7c945e5a9d529ed8cf9069f4c9064'
BRANCH = 'pro/dg16-g132-source-custody-r3-20261122-01'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def git_hash(kind, raw):
    return hashlib.sha1(kind.encode() + b' ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

def derive_tree(rows):
    root = {}
    for path, value in rows.items():
        parts = path.split(b'/')
        node = root
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        node[parts[-1]] = value
    def digest(node):
        entries = []
        for name, value in node.items():
            if isinstance(value, dict):
                mode, kind, oid = b'40000', b'tree', digest(value).encode()
                key = name + b'/'
            else:
                mode, kind, oid = value
                key = name
            entries.append((key, mode + b' ' + name + b'\0' + bytes.fromhex(oid.decode())))
        return git_hash('tree', b''.join(value for _, value in sorted(entries)))
    return digest(root)

def verify(output):
    checks = []
    def check(name, value):
        checks.append(dict(name=name, passed=bool(value)))
        if not value:
            raise AssertionError(name)
    def save(name, value):
        (output / name).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')
    receiving = json.loads((ROOT / 'INPUT_RECEIVING.json').read_bytes())
    for receipt in receiving['receipts']:
        directory = ROOT / receipt['destination']
        seal_raw = (directory / 'SEAL.json').read_bytes()
        check('input seal ' + receipt['destination'], len(seal_raw) == receipt['seal_bytes']
              and sha(seal_raw) == receipt['seal_sha256'])
        seal = json.loads(seal_raw)
        expected = {'SEAL.json'}
        check('input payload population ' + receipt['destination'], len(seal['files']) == receipt['payload_files'])
        for row in seal['files']:
            path = row['path']
            check('input unique relative path ' + path, path not in expected
                  and not Path(path).is_absolute() and '..' not in Path(path).parts)
            expected.add(path)
            raw = (directory / path).read_bytes()
            check('input retained bytes ' + receipt['destination'] + '/' + path,
                  len(raw) == row['bytes'] and sha(raw) == row['sha256']
                  and ('git_blob' not in row or git_hash('blob', raw) == row['git_blob']))
        check('input complete inventory ' + receipt['destination'],
              {str(p.relative_to(directory)) for p in directory.rglob('*') if p.is_file()} == expected)
    adjudication_raw = (ROOT / 'evidence/ROOT_OPERATION04_ADJUDICATION.json').read_bytes()
    check('Root adjudication exact retained bytes', len(adjudication_raw) == receiving['root_adjudication']['bytes']
          and sha(adjudication_raw) == receiving['root_adjudication']['sha256'])
    prior = ROOT / 'evidence/diagnostic04-source'
    commit = (prior / 'PARENT_COMMIT.raw').read_bytes()
    check('authenticated exact base commit', git_hash('commit', commit) == BASE)
    headers = commit.split(b'\n\n', 1)[0].splitlines()
    check('exact base tree and sole parent',
          [x for x in headers if x.startswith(b'tree ')] == [b'tree ' + BASE_TREE.encode()]
          and [x for x in headers if x.startswith(b'parent ')] == [b'parent ' + BASE_PARENT.encode()])
    flat = {}
    for row in (prior / 'PARENT_TREE.raw').read_bytes().split(b'\0'):
        if not row:
            continue
        meta, path = row.split(b'\t', 1)
        mode, kind, oid = meta.split()
        check('unique base path ' + path.decode(), path not in flat)
        flat[path] = mode, kind, oid
    check('complete authenticated base tree', len(flat) == 1768 and derive_tree(flat) == BASE_TREE)
    proofs = []
    for path in sorted(SOURCE.rglob('*')):
        if not path.is_file():
            continue
        name = str(path.relative_to(SOURCE))
        raw = path.read_bytes()
        check('full source bound to base ' + name,
              flat[name.encode()][1] == b'blob' and flat[name.encode()][2].decode() == git_hash('blob', raw))
        proofs.append(dict(path=name, bytes=len(raw), sha256=sha(raw), git_blob=git_hash('blob', raw),
                           mode=flat[name.encode()][0].decode(), changed=name == OWNER))
    check('fourteen complete source owners retained', len(proofs) == 14)
    before = (SOURCE / OWNER).read_text()
    after = (ROOT / 'candidate' / OWNER).read_text()
    check('exact old setup body', len(before.encode()) == 83152
          and sha(before.encode()) == '2dd699956d7b59eacd4a3f092e526047f0f4d89d0f7420edc9e8de093f5bd92c')
    old_ast, new_ast = ast.parse(before), ast.parse(after)
    old_functions = {n.name:n for n in old_ast.body if isinstance(n, ast.FunctionDef)}
    new_functions = {n.name:n for n in new_ast.body if isinstance(n, ast.FunctionDef)}
    check('only one new selected preparation route', set(new_functions) - set(old_functions)
          == {'prepare_hosted_source_selected_v3'} and not set(old_functions) - set(new_functions))
    old_start, old_end = before.index('def hosted_git('), before.index('def prepare_hosted_source(')
    new_start, new_end = after.index('def hosted_git('), after.index('def prepare_hosted_source(')
    restored = after[:new_start] + before[old_start:old_end] + after[new_end:]
    selected_start = restored.index('def prepare_hosted_source_selected_v3(')
    selected_end = restored.index('def receive_hosted_inputs(', selected_start)
    restored = restored[:selected_start] + restored[selected_end:]
    check('complete setup restored after exactly declared delta', restored == before)
    function_proofs = []
    for name, node in old_functions.items():
        if name == 'hosted_git':
            continue
        old_body = ast.get_source_segment(before, node)
        new_body = ast.get_source_segment(after, new_functions[name])
        check('unchanged function body ' + name, old_body == new_body)
        function_proofs.append(dict(name=name, bytes=len(old_body.encode()), sha256=sha(old_body.encode()), unchanged=True))
    hg = new_functions['hosted_git']
    hg_text = ast.get_source_segment(after, hg)
    hg_calls = [n for n in ast.walk(hg) if isinstance(n, ast.Call)]
    check('no direct-child polling or blocking wait before cleanup',
          not any(isinstance(n.func, ast.Attribute) and n.func.attr in {'poll','wait','communicate'} for n in hg_calls))
    check('exact WNOWAIT exit observation',
          'os.waitid(os.P_PID, process.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)' in hg_text)
    check('exact bounded real waitpid after group signal',
          hg_text.index('os.killpg(process.pid, signal.SIGKILL)')
          < hg_text.index('os.waitpid(process.pid, os.WNOHANG)')
          < hg_text.index('os.killpg(process.pid, 0)'))
    kill_calls = sorted([n for n in hg_calls if isinstance(n.func, ast.Attribute) and n.func.attr == 'killpg'],
                        key=lambda n:n.lineno)
    check('only pre-reap cleanup signal and post-reap zero-signal observation',len(kill_calls) == 2
          and ast.unparse(kill_calls[0]) == 'os.killpg(process.pid, signal.SIGKILL)'
          and ast.unparse(kill_calls[1]) == 'os.killpg(process.pid, 0)')
    check('finite existing resource ceilings retained', 'wall_seconds=60, stream_limit=4194304' in hg_text
          and 'time.monotonic() + 5' in hg_text and "signal.getsignal(signal.SIGCHLD) != signal.SIG_DFL" in hg_text)
    selected_text = ast.get_source_segment(after, new_functions['prepare_hosted_source_selected_v3'])
    selected_calls = [n for n in ast.walk(new_functions['prepare_hosted_source_selected_v3'])
                      if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'hosted_git']
    check('ten selected preparation commands',len(selected_calls) == 10)
    check('supported parent pack and bounded genuine child acquisition',
          "'fetch', '--keep', '--no-tags'" in selected_text
          and "'fetch.unpackLimit=64', 'fetch'" in selected_text
          and selected_text.count("'--refmap='") == 2
          and "--initial-branch=g132-source-unborn" in selected_text)
    check('no shallow filter lazy alternate repack unpack synthesis in new route',
          all(value not in selected_text for value in ('--depth','--filter','--shallow','repack','unpack-objects',
              'hash-object','update-ref','--reference','--shared','--dissociate','--refetch')))
    check('exact sole parent and genuine loose HEAD required',
          "observed[2].split() != [expected_parent]" in selected_text
          and "loose = os.lstat(source / loose_member)" in selected_text
          and 'loose.st_nlink != 1 or not 0 < loose.st_size <= 1048576' in selected_text)
    check('only one candidate source file',
          {str(p.relative_to(ROOT/'candidate')) for p in (ROOT/'candidate').rglob('*') if p.is_file()} == {OWNER})
    candidate_raw = after.encode()
    candidate_row = dict(path=OWNER, local_path=str(ROOT/'candidate'/OWNER), bytes=len(candidate_raw),
                         sha256=sha(candidate_raw), git_blob=git_hash('blob',candidate_raw),
                         mode=flat[OWNER.encode()][0].decode())
    changed = dict(flat)
    changed[OWNER.encode()] = (flat[OWNER.encode()][0], b'blob', candidate_row['git_blob'].encode())
    expected_tree = derive_tree(changed)
    check('same complete population and sole changed blob', len(changed) == 1768
          and {name for name in flat if flat[name] != changed[name]} == {OWNER.encode()})
    (output/'EXPECTED_TREE.raw').write_bytes(b''.join(mode+b' '+kind+b' '+oid+b'\t'+path+b'\0'
        for path,(mode,kind,oid) in sorted(changed.items())))
    (output/'SOURCE_DELTA.patch').write_text(''.join(difflib.unified_diff(
        before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='base/'+OWNER,tofile='candidate/'+OWNER)))
    check('no trailing whitespace in candidate source',
          all(line.rstrip(b' \t') == line for line in candidate_raw.splitlines()))
    local = json.loads((ROOT/'LOCAL_QUALIFICATION_RESULT.json').read_bytes())
    check('actual final bounded local qualification bound to exact candidate',
          local['status'] == 'PASS_BOUNDED_ORDINARY_LOCAL_QUALIFICATION'
          and local['check_count'] == 124 and all(x['passed'] for x in local['checks'])
          and local['owner_sha256'] == candidate_row['sha256'])
    local_return = json.loads((ROOT/'LOCAL_CONTROLS_RETURN.json').read_bytes())
    check('local driver actually returned zero with no stderr',local_return['exit'] == 0 and local_return['stderr_bytes'] == 0)
    for channel in ('stdout','stderr'):
        raw=(ROOT/('LOCAL_CONTROLS_'+channel.upper()+'.raw')).read_bytes()
        check('local raw '+channel+' retained', len(raw)==local_return[channel+'_bytes']
              and sha(raw)==local_return[channel+'_sha256'])
    prior_observation = json.loads((ROOT/'evidence/operation04-raw/OBSERVATION.json').read_bytes())
    record = prior_observation['source_preparation']['commands'][0]
    check('actual operation04 failure preserved without cause promotion',
          prior_observation['status']=='REFUSED' and prior_observation['failed_phase']=='standalone_source_preparation'
          and len(prior_observation['source_preparation']['commands'])==1
          and record['returncode']==128 and record['wait_reaped'] and not record['owned_group_absent']
          and not record['timed_out'] and not record['output_overflow']
          and 'fatal: fetch-pack: invalid index-pack output' in record['stderr_excerpt'])
    save('FULL_OWNER_PROOFS.json',dict(base_commit=BASE,base_tree=BASE_TREE,owners=proofs,
          unchanged_function_bodies=function_proofs,complete_file_restoration=True))
    save('PUBLICATION_PLAN.json',dict(schema='g132.source-custody-r3.publication-plan.v1',
          status='PROSPECTIVE_SOURCE_ONLY_NO_PUBLICATION',branch=BRANCH,base_commit=BASE,base_tree=BASE_TREE,
          base_parent=BASE_PARENT,expected_tree=expected_tree,expected_population=1768,entries=[candidate_row],
          diff_name_status='M\t'+OWNER+'\n',future_source_commit=None,future_source_parent=BASE,
          future_observer_requirements=[
              'Root must publish and read back this exact one-file source tree before binding a fresh observer.',
              'Bind the actual new source commit, this expected tree, sole parent f755, and changed setup bytes.',
              'Call prepare_hosted_source_selected_v3(root, output, SOURCE_COMMIT, SOURCE_PARENT, records=records).',
              'Retain the exact thirteen-member Engine map, seventeen Git rows, all capture/security/resource guards.',
              'Use a distinct operation and branch; operations03/04 and original44888568054 remain terminal.',
              'Retain the authentic traceback diagnostic and update its exact changed setup pin; no forged source identity.'],
          original_awards=[],protected_grant='UNISSUED',root_provider_authority_only=True,
          existing_repository_object_writes=0,index_writes=0,ref_writes=0,provider_calls=0,controller_calls=0))
    save('PUBLICATION_ENTRIES.json',[dict(path=OWNER,mode=candidate_row['mode'],type='blob',content=after)])
    save('STRUCTURAL_VALIDATION.json',dict(status='PASS_STATIC_SOURCE_AND_RETAINED_EVIDENCE',checks=checks,
          check_count=len(checks),expected_tree=expected_tree,candidate=candidate_row,full_owner_count=14,
          changed_existing_functions=['hosted_git'],added_functions=['prepare_hosted_source_selected_v3'],
          unchanged_function_count=len(function_proofs),authority='NONE',hosted_qualification=False,
          actual_index_pack_failure_cause='UNPROVED',operation03_capture_disjunct='UNPROVED'))
    print(json.dumps(dict(status='PASS_STATIC_SOURCE_AND_RETAINED_EVIDENCE',checks=len(checks),
                         expected_tree=expected_tree,candidate=candidate_row),sort_keys=True,indent=2))

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=ROOT)
    args=parser.parse_args()
    args.output.mkdir(exist_ok=True,parents=True)
    verify(args.output)
