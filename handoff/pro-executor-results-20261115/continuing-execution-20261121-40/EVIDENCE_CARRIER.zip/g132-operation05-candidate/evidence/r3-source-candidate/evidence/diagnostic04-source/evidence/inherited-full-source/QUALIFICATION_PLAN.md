# Bounded G132 source and compatibility qualification

Owner/source: Root's continuing commission; exact published R2 commit
`f75533f95f0d099c87e7a04beb11b0a25628acdc`, expected tree
`9b9c2b3f1453b83b87b628b665fceff492bf5b1e`, sole parent
`e76a07b2bae7c945e5a9d529ed8cf9069f4c9064`.

Acceptance: receive all 1,768 tracked files / 167,143,205 bytes without source
changes; inspect loader/setup entry points; actually instantiate and load the
exact prospective Engine without original execution; retain full loaded-source
descriptors and process identity; observe the real complete isolated checkout
through an ordinary observer only after its safety boundary is inspected.

Evidence: immutable Git object/tree/blob checks; physical byte/mode checks;
captured command receipts; Engine source bindings; complete-checkout observer
result or a precise evidenced failure; focused red/green only if an ordinary
source defect is found; final manifest SHA-256.

Boundaries: no Root/controller/provider mutation; no commit/push/tag/release or
integration; no original execution, M1/M3 awards or authority claims; no historical
replay; no private-input/custody/sender fabrication; no requirements/pin change
under the current identity. A source repair, if needed, is an isolated prospective
candidate requiring Root's separate receiving and publication decision.

Rollback: discard this isolated qualification directory. The source repository,
provider state, source commit and controller remain untouched.

Validation selection: complete checkout identity and direct Engine-loading /
observer evidence address the stated open gates. Broad package/regression suites
are omitted until a concrete product change or relevant regression risk warrants
them. Source-only validation PASS and earlier diagnostic success are not promoted
to actual Engine, host, custody or original execution evidence.
