"""Bounded safety controls. Removing a fixed refusal must fail these controls."""
import hashlib
import ast
import json
import os
from pathlib import Path
import tempfile
import types
import unittest

BASE=Path(__file__).resolve().parent
OWNER=BASE/'candidate/engineering/g132-engine-source-diagnostic/observe.py'

class DiagnosticControls(unittest.TestCase):
    def setUp(self):
        self.assertTrue(OWNER.is_file(),'ordinary hosted diagnostic owner is not implemented')
        self.m=types.ModuleType('diagnostic_under_test')
        self.m.__file__=str(OWNER)
        exec(compile(OWNER.read_bytes(),str(OWNER),'exec'),self.m.__dict__)

    def context(self):
        return dict(GITHUB_ACTIONS='true',RUNNER_ENVIRONMENT='github-hosted',
            GITHUB_REPOSITORY='theislampill/IMPLEMENTAUDIT.md',GITHUB_EVENT_NAME='push',
            GITHUB_REF='refs/heads/'+self.m.BRANCH,
            GITHUB_RUN_ATTEMPT='1',GITHUB_RUN_ID='123',GITHUB_SHA='a'*40,
            GITHUB_WORKFLOW_SHA='a'*40,GITHUB_JOB='observe',
            GITHUB_WORKFLOW_REF='theislampill/IMPLEMENTAUDIT.md/.github/workflows/dg16-g132-engine-source-observe.yml@refs/heads/'+self.m.BRANCH,
            ImageOS='ubuntu24',ImageVersion='20261116.376.1')

    def test_exact_ordinary_context_is_data_accepted(self):
        for image in ('20261116.133.1','20261116.376.1'):
            context=self.context();context['ImageVersion']=image
            self.m.validate_context(context,(0,0,0,0))

    def test_replay_and_changed_host_are_refused(self):
        for key,value in [('GITHUB_RUN_ATTEMPT','2'),('ImageVersion','changed'),
                          ('GITHUB_REF','refs/heads/main'),('ImageVersion','20261116.133.2'),
                          ('ImageVersion','20261116.376.2'),('ImageVersion',''),('ImageOS','ubuntu22'),
                          ('GITHUB_REF','refs/heads/pro/dg16-g132-engine-source-observe-20261121-02'),
                          ('GITHUB_REF','refs/heads/pro/dg16-g132-engine-source-observe-20261121-01'),('GITHUB_REPOSITORY','other/repo'),
                          ('GITHUB_WORKFLOW_SHA','b'*40)]:
            context=self.context();context[key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):
                self.m.validate_context(context,(0,0,0,0))

    def test_nonroot_identity_is_refused(self):
        with self.assertRaises(ValueError):self.m.validate_context(self.context(),(1000,1000,1000,1000))

    def test_new_git_pin_cannot_accept_old_body(self):
        expected=dict(kind='FILE',bytes=4640384,sha256='08ca4d2ee4d8915e86f1faaa52603752507c57af1d16d451dec9992bc9b6d801',mode=493)
        self.m.validate_git_pin(expected)
        old=dict(expected,bytes=4640352,sha256='824d5b2fffef332ec7ba053e579659bb12f26a0b4747da6f9c6dc0e71d36f235')
        with self.assertRaises(ValueError):self.m.validate_git_pin(old)

    def test_source_tuple_and_completeness_are_required(self):
        expected=dict(source_commit='f75533f95f0d099c87e7a04beb11b0a25628acdc',
                      source_tree='9b9c2b3f1453b83b87b628b665fceff492bf5b1e',
                      ordered_parents=['e76a07b2bae7c945e5a9d529ed8cf9069f4c9064'],clean=True,complete_objects=True)
        self.m.validate_source(expected)
        for key,value in [('source_commit','b'*40),('source_tree','b'*40),
                          ('ordered_parents',[]),('clean',False),('complete_objects',False)]:
            with self.subTest(key=key),self.assertRaises(ValueError):self.m.validate_source(dict(expected,**{key:value}))

    def test_observation_declares_no_execution_or_native_admission(self):
        result=self.m.base_result()
        self.assertFalse(result['native_admission'])
        self.assertFalse(result['original_execution'])
        self.assertFalse(result['session_constructed'])
        self.assertFalse(result['provider_acquired'])
        self.assertEqual(result['original_awards'],[])
        self.assertEqual(result['overall_admission'],'UNQUALIFIED')

    def test_return_seal_retains_actual_nonzero_exit_and_streams(self):
        with tempfile.TemporaryDirectory(dir=BASE) as directory:
            root=Path(directory)
            (root/'OBSERVATION.json').write_bytes(b'{"status":"REFUSED"}\n')
            (root/'STDERR.raw').write_bytes(b'')
            (root/'NATIVE_EXIT_STATUS.raw').write_bytes(b'2\n')
            result=self.m.seal_return(root)
            self.assertEqual(result['native_exit_status'],2)
            self.assertEqual(result['members']['OBSERVATION.json']['sha256'],hashlib.sha256(b'{"status":"REFUSED"}\n').hexdigest())
            self.assertFalse(result['native_admission'])


class CaptureBoundControls(unittest.TestCase):
    """Counterfactual data and receiver controls; never invoke product capture."""

    def setUp(self):
        self.m=types.ModuleType('capture_diagnostic_under_test')
        self.m.__file__=str(OWNER)
        exec(compile(OWNER.read_bytes(),str(OWNER),'exec'),self.m.__dict__)
        self.assertTrue(hasattr(self.m,'capture_bound_values'),
                        'capture-bound scalar receiver is not implemented')
        self.assertTrue(hasattr(self.m,'capture_bound_diagnostic'),
                        'capture-bound exception receiver is not implemented')
        self.bounds=dict(entries=4096,file_bytes=134217728,total_bytes=268435456,depth=40)
        self.name='.git/objects/pack/counterfactual-data-only.pack'

    def values(self,**changes):
        row=dict(count=2,total=134217729,file_bytes=134217729,depth=3,
                 name=self.name,bounds=dict(self.bounds))
        row.update(changes)
        return self.m.capture_bound_values(**row)

    def inert_product_code_identity(self):
        # Compile for immutable code metadata only. Neither this function nor any
        # prefix top-level code executes; no Engine or snapshot is instantiated.
        raw=(BASE/'evidence/inherited-full-source/inherited-source/scripts/qualify-work-graph-prefix.py').read_bytes()
        root=Path('/counterfactual-source-never-created')
        code=compile(raw,str(root/'scripts/qualify-work-graph-prefix.py'),'exec')
        function_code=next(x for x in code.co_consts
                           if type(x) is types.CodeType and x.co_name=='snapshot_tree')
        prefix=types.ModuleType('inert_prefix_code_metadata')
        prefix.__file__=str(root/'scripts/qualify-work-graph-prefix.py')
        prefix.snapshot_tree=types.FunctionType(function_code,prefix.__dict__)
        prefix.SOURCE_BOUNDS=dict(self.bounds)
        current=types.SimpleNamespace(P=prefix,SOURCES={
            'scripts/qualify-work-graph-prefix.py':(raw,None)})
        return current,root,raw

    def test_each_strict_disjunct_is_reported_from_scalar_data(self):
        cases=[('entries',dict(count=4097,total=0,file_bytes=0)),
               ('file_bytes',dict(total=134217729,file_bytes=134217729)),
               ('total_bytes',dict(total=268435457,file_bytes=134217728))]
        for term,changes in cases:
            with self.subTest(term=term):
                value=self.values(**changes)
                self.assertEqual(value['bounds'],self.bounds)
                self.assertEqual(value['observed']['relative_path'],self.name)
                self.assertEqual(value['derived']['exceeded'],{
                    name:name==term for name in ('entries','file_bytes','total_bytes')})
                self.assertEqual(value['derived']['first_true_term'],term)

    def test_exact_equalities_cannot_invent_a_failure(self):
        with self.assertRaises(ValueError):
            self.values(count=4096,total=268435456,file_bytes=134217728,depth=39)

    def test_multiple_terms_preserve_all_values_and_source_or_order(self):
        value=self.values(count=4097,total=268435457,file_bytes=134217729)
        self.assertEqual(value['derived']['exceeded'],
                         dict(entries=True,file_bytes=True,total_bytes=True))
        self.assertEqual(value['derived']['first_true_term'],'entries')
        self.assertEqual(value['observed'],dict(count=4097,total=268435457,
            current_regular_file_bytes=134217729,parent_directory_depth=3,
            relative_path=self.name))

    def test_changed_bounds_invalid_scalars_and_unsafe_names_refuse(self):
        cases=[dict(count=True),dict(count=-1),dict(count=4098),dict(total=True),
               dict(file_bytes=-1),dict(file_bytes=2**63),dict(total=0),
               dict(total=268435456+134217729+1),dict(depth=40),dict(depth=True),
               dict(name='/absolute'),dict(name='a/../b'),dict(name='a//b'),
               dict(name='bad\nname'),dict(name='x'*16385),dict(name='\ud800')]
        for key in self.bounds:
            changed=dict(self.bounds);changed[key]+=1;cases.append(dict(bounds=changed))
        changed=dict(self.bounds);changed['extra']=1;cases.append(dict(bounds=changed))
        changed=dict(self.bounds);changed['depth']=True;cases.append(dict(bounds=changed))
        for case in cases:
            with self.subTest(case=ascii(case)),self.assertRaises((ValueError,UnicodeError)):
                self.values(**case)

    def test_non_target_exception_does_not_read_any_product_state(self):
        class Inaccessible:
            def __getattribute__(self,name):
                raise AssertionError('non-target exception touched product state')
        for error in (ValueError('namespace depth bound exceeded'),RuntimeError(
                'source input byte/entry bound exceeded')):
            value=self.m.capture_bound_diagnostic(error,Inaccessible(),None)
            self.assertEqual(value,dict(status='NOT_TARGET_EXCEPTION'))

    def test_same_message_and_same_named_locals_are_not_authentic_frames(self):
        current,root,raw=self.inert_product_code_identity()
        def foreign_frame():
            count=4097;total=0;before=None;name=self.name;depth=3
            raise ValueError('source input byte/entry bound exceeded')
        try:
            foreign_frame()
        except ValueError as exc:
            with self.assertRaises(ValueError):
                self.m.capture_bound_diagnostic(exc,current,root)
            self.assertEqual(exc.args,('source input byte/entry bound exceeded',))

    def test_changed_prefix_buffer_is_not_received_as_pinned_source(self):
        current,root,raw=self.inert_product_code_identity()
        current.SOURCES['scripts/qualify-work-graph-prefix.py']=(raw+b'\n',None)
        with self.assertRaises(ValueError):
            self.m.capture_bound_diagnostic(
                ValueError('source input byte/entry bound exceeded'),current,root)

    def test_counterfeit_function_with_copied_source_coordinates_refuses(self):
        _,root,raw=self.inert_product_code_identity()
        # This is independent test-fixture code. No product module executes and
        # no function in a product module is replaced. The claimed source bytes
        # are authentic; the executing fixture code is deliberately different.
        lines=['']*222
        lines[179]='def snapshot_tree(root, objects, bounds, *, excluded=()):'
        lines[180]='    count=2'
        lines[181]='    total=134217729'
        lines[184]='    def walk(fd, relative, depth):'
        lines[185]='        nonlocal count,total'
        lines[186]='        checked_bounds=bounds'
        lines[187]='        before=os.stat_result((33188,0,0,1,1000,1000,134217729,0,0,0))'
        lines[188]="        name='.git/objects/pack/counterfactual-data-only.pack'"
        lines[220]="        raise ValueError('source input byte/entry bound exceeded')"
        lines[221]="    walk(None,'.git/objects/pack',3)"
        prefix=types.ModuleType('explicit_counterfeit_fixture')
        prefix.__file__=str(root/'scripts/qualify-work-graph-prefix.py')
        prefix.os=os
        prefix.SOURCE_BOUNDS=dict(self.bounds)
        exec(compile('\n'.join(lines)+'\n',prefix.__file__,'exec'),prefix.__dict__)
        current=types.SimpleNamespace(P=prefix,SOURCES={
            'scripts/qualify-work-graph-prefix.py':(raw,None)})
        try:
            prefix.snapshot_tree(root,{},prefix.SOURCE_BOUNDS)
        except ValueError as exc:
            with self.assertRaises(ValueError):
                self.m.capture_bound_diagnostic(exc,current,root)

    def test_pinned_exception_location_and_unmodified_predicate(self):
        current,root,raw=self.inert_product_code_identity()
        tree=ast.parse(raw)
        snapshot=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='snapshot_tree')
        walk=next(x for x in snapshot.body if isinstance(x,ast.FunctionDef) and x.name=='walk')
        target=next(x for x in ast.walk(walk) if isinstance(x,ast.Raise)
                    and isinstance(x.exc,ast.Call) and x.exc.args
                    and isinstance(x.exc.args[0],ast.Constant)
                    and x.exc.args[0].value=='source input byte/entry bound exceeded')
        parent=next(x for x in ast.walk(walk) if isinstance(x,ast.If) and target in x.body)
        expected=ast.parse('count > bounds["entries"] or before.st_size > bounds["file_bytes"] or total > bounds["total_bytes"]',mode='eval')
        self.assertEqual((snapshot.lineno,walk.lineno,target.lineno),(180,185,221))
        self.assertEqual(ast.dump(parent.test),ast.dump(expected.body))

    def test_single_capture_call_is_wrapped_and_original_exception_reraised(self):
        tree=ast.parse(OWNER.read_bytes())
        observe=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='observe')
        calls=[x for x in ast.walk(observe) if isinstance(x,ast.Call)
               and isinstance(x.func,ast.Attribute) and x.func.attr=='complete_source']
        self.assertEqual(len(calls),1)
        wrapper=next(x for x in ast.walk(observe) if isinstance(x,ast.Try)
                     and len(x.body)==1 and isinstance(x.body[0],ast.Assign)
                     and x.body[0].value is calls[0])
        self.assertEqual(len(wrapper.handlers),1)
        self.assertEqual(ast.dump(wrapper.handlers[0].type),ast.dump(ast.Name(id='BaseException',ctx=ast.Load())))
        self.assertIsInstance(wrapper.handlers[0].body[-1],ast.Raise)
        self.assertIsNone(wrapper.handlers[0].body[-1].exc)
        self.assertFalse(wrapper.finalbody)
        self.assertFalse(wrapper.orelse)

    def test_distinct_branch_and_unchanged_non_admission(self):
        self.assertEqual(self.m.BRANCH,'pro/dg16-g132-engine-source-observe-20261121-04')
        result=self.m.base_result()
        self.assertEqual(result['original_awards'],[])
        self.assertFalse(result['native_admission'])
        self.assertFalse(result['original_execution'])
        self.assertEqual(result['overall_admission'],'UNQUALIFIED')


if __name__=='__main__':unittest.main(verbosity=2)


