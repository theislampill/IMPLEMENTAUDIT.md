# G132 operation 04 — bounded capture-failure diagnostic candidate

State: **FROZEN_FOR_INDEPENDENT_SOURCE_REVIEW**.  
Author: `/root/g132_capture_bound_engineering`.  
Authority: **NONE**. Root retains integration, provider publication, hosted execution, adjudication, and all controller authority.

## Result

Prepared a distinct ordinary diagnostic that can retain the precise operands of the unchanged source capture bound when the genuine product raises it. The existing complete-source operation is called once. The new code observes only the escaping exception, records a bounded subset of authentic frame metadata and scalars, then re-raises the original exception. Every inherited product owner and every original capture guard remain unchanged.

The final candidate passed **18 bounded local controls** at native wrapper `b76173/0` and **1,950 static/source/tree checks** at `3977f0/0`. Its actual local entry returned **2**, at `context`, with `actual UID/GID zero is required`; wrapper `e8b4b8/0` verified that expected native refusal. That process had UID/EUID/GID/EGID 1000, PID 6, PPID 5, `/usr/bin/python3.13`, and start ticks 540826. It started no Git child and reached no product Engine, product capture, or diagnostic traceback receiver.

No hosted operation, original execution, provider call, branch creation, Git object/index/ref write, controller operation, or protected grant was performed. No actual failing hosted path or count has been recovered yet. The candidate is ready for independent source review; it makes no native, original, profile, or closure award.

## Evidence motivating the delta

Actual operation 03 ran once as **44960479304**, attempt **1**, diagnostic commit **1980ef263b6d978d690f7fc65e2fac4cabe0de08**. Both authentic 13-member Engine maps matched the expected map. All 17 selected Git rows and the unchanged Git-input validator matched. Eleven fresh complete-source preparation commands returned zero with their command, reap, group, and descriptor receipts. The fresh checkout's exact source tuple remained:

- Commit `f75533f95f0d099c87e7a04beb11b0a25628acdc`.
- Tree `9b9c2b3f1453b83b87b628b665fceff492bf5b1e`.
- Sole parent `e76a07b2bae7c945e5a9d529ed8cf9069f4c9064`.

The actual capture then refused with `source input byte/entry bound exceeded`. The full pinned owner `scripts/qualify-work-graph-prefix.py` emits this at line 221 after adding the current regular file to `count` and `total`:

```python
count > bounds["entries"] or before.st_size > bounds["file_bytes"] or total > bounds["total_bytes"]
```

The exact unchanged limits are 4,096 entries, 134,217,728 bytes per regular file, 268,435,456 aggregate regular-file bytes, and depth 40. Operation 03 retained none of the operands or the failing relative path. Its **29,463 Git object-list rows are not filesystem entries** and cannot establish a disjunct. The namespace, producer, captured-HEAD, and final source/Git bookend gates were not reached. A packed-HEAD failure is not established.

The included prior raw packet has seal SHA256 `8525a9cee42b56ca98b2039cdd436102a5452b290c84f06c1ce8fcd9df524036`; the independent receiving seal is `a5a3baa813b7ff8e9706b3caf7ee03f44c9c212bc4ff4a270bff7f8aec6968e6`. Root's exact 2,764-byte adjudication has SHA256 `9568528f69311637aeeba2062c4c129895c9479b1aabcba6652e12b44ef745d3`. The raw artifact's four members were compared directly with their retained counterparts. Both Engine maps, all Git rows, all eleven command results, the source tuple, and the absence of operands were checked directly from that retained actual observation.

## What the receiver accepts

The receiver first requires an exact built-in `ValueError` carrying the single pinned message. Other exceptions return `NOT_TARGET_EXCEPTION` without touching product state. It receives the already-held prefix source buffer, requiring exactly **53,362 bytes** and SHA256 **ff5dbdce5b4419268b0fc11c4659763ad68d40e32f18f721b6093a7dd269b7ab**.

It then verifies the actual prefix module, function globals, source filename, function name, and source line. It compiles the already-held public buffer with `dont_inherit=True` solely to obtain the expected code object, and requires equality with the loaded `snapshot_tree` code. It does not execute that compiled buffer, load another product module, replace a function, change tracing, or call the product again.

The receiver traverses at most **64** traceback records. It requires the exact loaded `snapshot_tree` code object, followed only by that function's actual nested `walk` code object, with its terminal leaf at the pinned line **221**. It checks source-root identity, empty exclusions, exact original bounds, common module globals, and consistency of the nonlocal count and total.

The only frame-local keys read are:

| Key | Use |
|---|---|
| `root` | Check the specific fresh source invocation; not emitted |
| `excluded` | Require the unchanged empty exclusion tuple; not emitted |
| `bounds` | Require and emit the exact four original bound integers |
| `count` | Emit the current entry count after adding the regular file |
| `total` | Emit the current aggregate size after adding the regular file |
| `before` | Require an actual `os.stat_result`; emit only its `st_size` |
| `depth` | Emit the parent directory depth |
| `name` | Emit the validated relative path |

Integer domains are explicit. The relative path is limited to 16,384 UTF-8 bytes, must be relative and free of empty, dot, dot-dot, and control-character components, and must encode strictly. The receiver does not read or serialize `objects`, `state`, `stamps`, directory-entry arrays, file contents, arbitrary local dictionaries, descriptor contents, or private input bytes.

The returned record places the actual operands under `observed`, the unchanged limits under `bounds`, and the three comparisons plus first true disjunct under `derived`. This distinguishes captured values from subsequent arithmetic. It reports every true comparison and preserves the original left-to-right OR order when naming the first true term. Unsupported or inconsistent frame data becomes `UNAVAILABLE`; the existing exception is re-raised in every case. The observer's original outer refusal, nonzero return policy, resource cleanup, and no-admission declarations remain intact.

## Exact prospective publication

Operation: **G132_ENGINE_SOURCE_OBSERVE_20261121_04_CAPTURE_BOUND**.  
Prospective branch: **pro/dg16-g132-engine-source-observe-20261121-04**.  
Sole parent: **f75533f95f0d099c87e7a04beb11b0a25628acdc**.  
Expected complete tree: **baffbae6d7a19e289db100233704df2a0e721914**.

All three hosted entries use mode `100644`:

| Added path | Bytes | SHA256 | Git blob |
|---|---:|---|---|
| `.github/workflows/dg16-g132-engine-source-observe.yml` | 3,126 | `999962c5a8c81835347bb81f62a23925118ccced2dc54b7d60ae5bd2b47dab24` | `6eaae039a6f3cd9a3712e67d6c424c60af3aecf4` |
| `engineering/g132-engine-source-diagnostic/observe.py` | 20,455 | `49b7ea3deea034210964519c06cab344828194af147c0994c3f8831cb2816413` | `5c28c5dbcb1315e9f24d13f5a8ce4dae6c138db6` |
| `engineering/g132-engine-source-diagnostic/ENGINE_MAP.json` | 2,083 | `5d4e482896bd812dadbc49acd3d61daa3bd2ce774c650c967a86cab02d6235bf` | `e7ecd2aa57e0d62bc4491097422241d4bed9b915` |

The candidate's full parent/tree maps were derived with two read-only Git reads at `6ed362/0`, using disabled protocols, `GIT_NO_LAZY_FETCH=1`, replacement-object suppression, and optional locks disabled. The parent commit object's hash, tree, and sole parent were verified. The full 1,768-file parent tree was recomputed in memory; adding only the three listed files yields the 1,771-file expected tree above. No Git tree object was written and no proposed ref exists as a result of this work. `EXPECTED_TREE.raw` retains every proposed file/mode/blob row.

After removing the exact new four constants, two functions, exception-only wrapper, and branch substitution, the complete observer is byte-identical to operation 03's observer. Every existing function other than `observe` also has an identical AST. The full workflow differs only in branch, concurrency group, shell branch check, and helper self-hash. The map is byte-identical. All fourteen inherited full owner bodies have exact hashes and Git blobs bound to the authenticated parent tree in `FULL_OWNER_PROOFS.json`.

## Controls and measured limits

| Evidence | Result | Native wrapper |
|---|---|---|
| Initial missing-feature controls | Expected red: 10 failures, inherited 7 controls passed | `c537bd/0`; child exit 1 |
| Counterfeit function with copied filename/line metadata | Expected red before the compile-only source-code binding | `1b083b/0`; child exit 1 |
| Final bounded controls | All 18 passed | `b76173/0`; child exit 0 |
| Full static bytes/AST/input/tree verification and shell syntax | 1,950 checks passed | `3977f0/0` |
| Final actual nonhost observer entry | Authentic context refusal, no Git children | `e8b4b8/0`; child exit 2 |

The final controls cover isolated entry/file/total disjuncts, strict equality boundaries, simultaneous true comparisons and order, invalid scalar domains and paths, changed bounds, unrelated exception non-interference, wrong source buffers, foreign same-message frames, and a deliberately counterfeit function with copied source coordinates. The counterfeit fixture is separate test code; no product module runs and no product function is replaced. The controls also retain the seven inherited context, Git08ca, source tuple, no-admission, and return-seal checks. The final wrapper is checked statically for one complete-source call and an unconditional bare re-raise.

Positive scalar tests and synthetic negative traceback tests are **data/diagnostic controls**, not genuine hosted capture evidence. There is **no positive authentic product traceback observation** in this task. The compiled public owner buffer is never executed. The prospective hosted interpreter is Python 3.12; the actual local refusal and controls use Python 3.13. This work does not qualify a new genuine Python 3.12 traceback result.

The first local refusal, before code-binding hardening, is retained under `evidence/development-before-code-binding/`. It is not substituted for the final candidate's distinct local refusal. Both local entries refused before any product loading or Git child. No hosted retry occurred.

## Preserved limits and next decision

The observer keeps the exact finite image set, UID/context checks, physical source bodies, Git08ca pin, eleven-child Git audit boundary, fresh exact-source requirements, full capture limits, namespace/producer/captured-HEAD gates, process/network prohibitions, resource limits, alarms, artifact bounds, return policy, and false native/original admission. No source filtering, partial clone, repacking, unpacking, object synthesis, private-input selection, launcher provisioning, or host-policy change is introduced.

The four library/cache mismatches, actual NSS files-only refusal, and missing bwrap observed in operation 03 remain unqualified. The inherited post-reap descendant/group limitation remains: a refusal does not by itself prove active termination of a descendant survivor. The capture limits remain separate from any pre-clone aggregate disk quota. Captured state/object bytes are not newly exported for replay, and final currentness/bookend checks remain unreached when capture refuses.

A future distinct operation may refuse at an earlier gate, another capture bound, or a different exception; this receiver adds detail only for the exact pinned target failure. A malformed or oversized diagnostic input fails closed to an unavailable diagnostic while preserving the original refusal. The original G132 run 44888568054 remains spent; historical 301/A4-07 unknowns and queued 43098152901 remain unaffected.

Root supplied original delegation at G0043, receipt `33c5296d4d9bf5ae370780b3d9895a8ce1b825cd`, and subsequently supplied currentness G0044, receipt `3fb3e2d80b1575b3a4ec28cc196957f9ce498523`, native `af77f7/0`. This author did not read, invoke, or mutate the controller. Those are supplied context bindings, not this author's independent currentness claim.

Root's next step is independent review of this immutable candidate. Any later ordinary publication still requires Root's fresh absent-branch/run check, exact parent/tree/three-file verification, and one initial publication decision. This packet supplies no retry, grant reuse, protected execution, original award, or closure authority.
