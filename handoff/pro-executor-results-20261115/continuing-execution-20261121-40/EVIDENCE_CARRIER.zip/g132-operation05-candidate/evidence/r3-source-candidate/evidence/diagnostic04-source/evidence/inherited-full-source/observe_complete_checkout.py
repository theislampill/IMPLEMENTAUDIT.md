#!/usr/bin/env python3
"""Observe every actual local checkout byte; record refusals without weakening gates."""
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback
import types

BASE = Path(__file__).resolve().parent
ROOT = BASE/'r2-checkout'
EXPECTED = json.loads((BASE/'EXACT_CHECKOUT_RECEIPT.json').read_text())
report = dict(schema='g132.local-complete-checkout-observation.v1', authority='NONE',
              source_commit=EXPECTED['commit'], source_tree=EXPECTED['tree'],
              original_execution=False, session_constructed=False, provider_acquired=False,
              source_mutation=False, native_or_hosted_admission=False,
              process=dict(pid=os.getpid(),ppid=os.getppid(),uid=os.getuid(),euid=os.geteuid(),
                           gid=os.getgid(),egid=os.getegid(),python=sys.version,
                           executable=str(Path('/proc/self/exe').resolve()),
                           proc_starttime_ticks=Path('/proc/self/stat').read_text().split()[21]),
              started_time_ns=time.time_ns(), forbidden_events=[], gates={})
active=True

def audit(event,args):
    if not active:return
    forbidden = event in {'subprocess.Popen','os.fork','os.forkpty','os.exec','os.posix_spawn',
                         'os.system','os.remove','os.rmdir','os.rename','os.mkdir','os.link',
                         'os.symlink','os.chmod','os.chown','os.truncate','os.utime',
                         'os.setxattr','os.removexattr','socket.__new__','socket.connect',
                         'socket.bind','socket.getaddrinfo','ctypes.dlopen','ctypes.dlsym'}
    if event=='open':forbidden=bool(args[2] & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
    if forbidden:
        report['forbidden_events'].append(event)
        raise RuntimeError('read-only source observer refused '+event)

def gate(name,operation):
    try:
        value=operation()
        report['gates'][name]=dict(status='PASS',value=value)
    except BaseException as exc:
        report['gates'][name]=dict(status='REFUSED',exception_type=type(exc).__name__,reason=str(exc),
            frames=[dict(path=f.filename,line=f.lineno,function=f.name) for f in traceback.extract_tb(exc.__traceback__)])

sys.addaudithook(audit)
try:
    path=ROOT/'scripts/qualify-work-graph-c5-setup.py'
    raw=path.read_bytes()
    assert hashlib.sha256(raw).hexdigest()=='2dd699956d7b59eacd4a3f092e526047f0f4d89d0f7420edc9e8de093f5bd92c'
    setup=types.ModuleType('g132_readonly_source_observer')
    setup.__file__=str(path)
    exec(compile(raw,str(path),'exec'),setup.__dict__)
    current=setup.hosted_current_owner(ROOT)
    objects={}
    captured=current.B.complete_source(ROOT,objects)
    report['complete_source_capture']=dict(status='CAPTURED_ALL_ACTUAL_BYTES',
        projection=captured['projection'],files=len(captured['state']['files']),
        directories=len(captured['state']['directories']),object_count=len(objects),
        object_bytes=sum(map(len,objects.values())),
        actual_file_bytes=sum(x['bytes'] for x in captured['state']['files'].values()),
        state_sha256=hashlib.sha256(json.dumps(captured['state'],sort_keys=True,separators=(',',':')).encode()).hexdigest())
    gate('git_namespace',lambda:current.P.validate_git_namespace(captured['state'],objects))
    gate('producer_contract',lambda:current.B._producer_contract(captured['state']))
    gate('captured_head_identity',lambda:current.captured_source_identity(captured,objects,
        dict(source_commit=EXPECTED['commit'],source_tree=EXPECTED['tree'])))
    current.CHECK()
    report['source_currentness_after']=True
    report['state']=captured['state']
    report['status']='LOCAL_CAPTURE_COMPLETE_QUALIFICATION_REFUSED' if any(
        x['status']!='PASS' for x in report['gates'].values()) else 'LOCAL_SOURCE_RECEIVED_ONLY'
except BaseException as exc:
    report.update(status='OBSERVATION_FAILED',exception_type=type(exc).__name__,reason=str(exc),
        frames=[dict(path=f.filename,line=f.lineno,function=f.name) for f in traceback.extract_tb(exc.__traceback__)])
finally:
    active=False
    report['finished_time_ns']=time.time_ns()
    output=BASE/'LOCAL_CHECKOUT_OBSERVATION.json'
    output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='state'},sort_keys=True))
    print(json.dumps(dict(path=output.name,bytes=output.stat().st_size,
                         sha256=hashlib.sha256(output.read_bytes()).hexdigest()),sort_keys=True))
sys.exit(0 if report['status']=='LOCAL_SOURCE_RECEIVED_ONLY' else 2)
