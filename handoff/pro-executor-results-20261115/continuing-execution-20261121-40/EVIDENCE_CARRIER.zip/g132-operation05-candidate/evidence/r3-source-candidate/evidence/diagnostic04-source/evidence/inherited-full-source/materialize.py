#!/usr/bin/env python3
"""Receive an exact isolated checkout; never mutate the source repository."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

BASE = Path(__file__).resolve().parent
SOURCE = Path('/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b')
DEST = BASE / 'r2-checkout'
COMMIT = 'f75533f95f0d099c87e7a04beb11b0a25628acdc'
TREE = '9b9c2b3f1453b83b87b628b665fceff492bf5b1e'
PARENT = 'e76a07b2bae7c945e5a9d529ed8cf9069f4c9064'
COMMANDS = []

def git(repo, *args):
    argv = ['git', '-C', str(repo), *args]
    process = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    pid = process.pid
    out, err = process.communicate()
    COMMANDS.append(dict(argv=argv, pid=pid, returncode=process.returncode,
                         stdout_bytes=len(out), stdout_sha256=hashlib.sha256(out).hexdigest(),
                         stderr=err.decode()))
    if process.returncode:
        raise RuntimeError(f'git command failed: {args!r}: {err.decode()}')
    return out

started = time.time_ns()
source_head = git(SOURCE, 'rev-parse', 'HEAD').decode().strip()
source_status = git(SOURCE, 'status', '--porcelain=v1')
assert source_head == '6d9e145e2f2df5a0a8a150c85a4f3e2afd918d27'
assert not source_status
assert git(SOURCE, 'rev-parse', COMMIT+'^{tree}').decode().strip() == TREE
assert git(SOURCE, 'show', '-s', '--format=%P', COMMIT).decode().strip() == PARENT
raw = git(SOURCE, 'ls-tree', '-rlz', COMMIT)
entries = []
for line in raw.split(b'\0'):
    if not line:
        continue
    descriptor, name = line.split(b'\t', 1)
    mode, kind, blob, size = descriptor.decode().split()
    path = name.decode()
    assert kind == 'blob' and mode in ('100644', '100755')
    assert not Path(path).is_absolute() and '..' not in Path(path).parts
    entries.append(dict(path=path, mode=mode, git_blob=blob, bytes=int(size)))
assert len(entries) == 1768
assert sum(x['bytes'] for x in entries) == 167143205
assert not DEST.exists()
DEST.mkdir()
git(DEST, 'init', '--quiet')
(DEST / '.git/objects/info/alternates').write_text(str(SOURCE / '.git/objects')+'\n')
git(DEST, '-c', 'core.hooksPath=/dev/null', 'checkout', '--detach', '--quiet', COMMIT)
assert git(DEST, 'rev-parse', 'HEAD').decode().strip() == COMMIT
assert not git(DEST, 'status', '--porcelain=v1')
for entry in entries:
    path = DEST / entry['path']
    raw = path.read_bytes()
    assert len(raw) == entry['bytes']
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest() == entry['git_blob']
    assert bool(path.stat().st_mode & 0o111) == (entry['mode'] == '100755')
    entry['sha256'] = hashlib.sha256(raw).hexdigest()
assert git(SOURCE, 'rev-parse', 'HEAD').decode().strip() == source_head
assert git(SOURCE, 'status', '--porcelain=v1') == source_status
report = dict(schema='g132.isolated-complete-checkout.v1', status='EXACT',
              commit=COMMIT, tree=TREE, sole_parent=PARENT,
              file_count=len(entries), total_bytes=sum(x['bytes'] for x in entries),
              source_repository_unchanged=True, source_head=source_head,
              borrowed_immutable_objects=True, source_private_inputs_borrowed=False,
              pid=os.getpid(), ppid=os.getppid(), uid=os.getuid(), euid=os.geteuid(),
              started_time_ns=started, finished_time_ns=time.time_ns(),
              entries=entries, commands=COMMANDS)
output = BASE/'EXACT_CHECKOUT_RECEIPT.json'
output.write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('entries','commands')},sort_keys=True))
print(json.dumps(dict(receipt=output.name, bytes=output.stat().st_size,
                     sha256=hashlib.sha256(output.read_bytes()).hexdigest()),sort_keys=True))
