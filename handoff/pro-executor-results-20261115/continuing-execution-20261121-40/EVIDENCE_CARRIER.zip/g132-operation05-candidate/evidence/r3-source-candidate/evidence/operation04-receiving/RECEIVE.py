#!/usr/bin/env python3
"""Receive retained G132 diagnostic04 data only; no product/Git/provider calls."""
from pathlib import Path, PurePosixPath
from datetime import datetime
import base64
import hashlib
import json
import stat
import zipfile

B = Path('/workspace/scratch/097486cde2dd')
R = B / 'g132-native-44963085468'
C = B / 'g132-capture-bound-candidate'
S = B / 'g132-capture-bound-independent-review'
O = B / 'g132-capture-bound-native-independent-receiving'
RUN = 44963085468
JOB = 137025986456
COMMIT = '5f0dce5e1756be3d9bf964d83de45587749a31a4'
TREE = 'baffbae6d7a19e289db100233704df2a0e721914'
PARENT = 'f75533f95f0d099c87e7a04beb11b0a25628acdc'
BRANCH = 'pro/dg16-g132-engine-source-observe-20261121-04'
RAW_SEAL = '0dd20543c17f70593bd024afcdd7f07e827eae1d5422ed94fc6f480c4cf9a4bb'
CANDIDATE_SEAL = 'ed10206609b732337d8e2faed40df8db68dd7fd08311a2c619bae1569726a2b2'
REVIEW_SEAL = '33a80165f5a316479e34d7b5bba04f862ad280a34aea6ae40c0d90e72e268381'
ZIP_SHA = '2790146432e27e75a0bc6dd63a483fb6a9311848fa7c092724ca657e8e2cea41'
checks = []


def require(value, label):
    if not value:
        raise AssertionError(label)
    checks.append(label)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def record(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': sha(raw)}


def pairs(rows):
    d = {}
    for k, v in rows:
        if k in d:
            raise AssertionError('duplicate JSON key')
        d[k] = v
    return d


def read(path):
    return json.loads(path.read_bytes(), object_pairs_hook=pairs)


def receive(root, seal_name, expected_hash, expected_bytes, count, total):
    require(record(root / seal_name) == {'bytes': expected_bytes, 'sha256': expected_hash}, 'exact seal ' + str(root))
    s = read(root / seal_name); names = set(); size = 0
    for item in s['files']:
        name = item['path']; p = PurePosixPath(name)
        require(not p.is_absolute() and str(p) == name and all(x not in ('', '.', '..') for x in p.parts) and name not in names, 'safe unique member ' + name)
        names.add(name); file = root / name; size += item['bytes']
        require(file.is_file() and not file.is_symlink() and record(file) == {k: item[k] for k in ('bytes', 'sha256')}, 'exact sealed member ' + name)
    actual = set()
    for path in root.rglob('*'):
        mode = path.lstat().st_mode
        require(stat.S_ISREG(mode) or stat.S_ISDIR(mode), 'regular or directory member ' + path.relative_to(root).as_posix())
        if path.is_file() and path != root / seal_name:
            actual.add(path.relative_to(root).as_posix())
    require(actual == names and len(names) == count and size == total, 'complete inventory ' + str(root))
    return s


raw_seal = receive(R, 'SEAL.json', RAW_SEAL, 3865, 21, 268924)
require(raw_seal['run'] == RUN and raw_seal['job'] == JOB and raw_seal['attempt'] == 1 and raw_seal['commit'] == COMMIT and raw_seal['tree'] == TREE and raw_seal['source_parent'] == PARENT, 'raw operation identity')
require(record(R / 'SOURCE_CANDIDATE_SEAL.json') == record(C / 'SEAL.json') == {'bytes': 37883, 'sha256': CANDIDATE_SEAL}, 'exact reviewed source candidate seal binding')
require(record(R / 'SOURCE_REVIEW_SEAL.json') == record(S / 'SEAL.json') == {'bytes': 1516, 'sha256': REVIEW_SEAL}, 'exact independent source review seal binding')
candidate = read(C / 'SEAL.json')
# Full already-reviewed candidate is re-received as immutable data, not executed.
for row in candidate['files']:
    require(record(C / row['path']) == {k: row[k] for k in ('bytes', 'sha256')}, 'candidate retained exact ' + row['path'])
for row in read(S / 'SEAL.json')['files']:
    require(record(S / row['path']) == {k: row[k] for k in ('bytes', 'sha256')}, 'source review retained exact ' + row['path'])

run = read(R / 'PROVIDER_RUN.json')
for k, v in {'id': RUN, 'head_branch': BRANCH, 'head_sha': COMMIT, 'event': 'push', 'status': 'completed', 'conclusion': 'failure', 'run_attempt': 1, 'path': '.github/workflows/dg16-g132-engine-source-observe.yml', 'pull_requests': []}.items():
    require(run[k] == v, 'provider run ' + k)
discovery = read(R / 'PROVIDER_DISCOVERY.json')
require(discovery['total_count'] == 1 and len(discovery['workflow_runs']) == 1 and discovery['workflow_runs'][0]['id'] == RUN and discovery['workflow_runs'][0]['head_sha'] == COMMIT, 'single retained matching run discovery')
jobs = read(R / 'PROVIDER_JOBS_INITIAL.json')['jobs']
require(len(jobs) == 1, 'one provider job')
job = jobs[0]
for k, v in {'id': JOB, 'run_id': RUN, 'name': 'observe', 'status': 'completed', 'conclusion': 'failure'}.items():
    require(job[k] == v, 'provider job ' + k)
steps = {x['name']: x for x in job['steps']}
require(steps['Check out separate diagnostic owner']['conclusion'] == 'success' and steps['Observe exact Engine and one fresh complete source checkout']['conclusion'] == 'failure' and steps['Retain complete or partial actual outcomes']['conclusion'] == 'success', 'checkout/failure/artifact step sequence')
commit = read(R / 'PROVIDER_COMMIT.json')
require(commit['sha'] == COMMIT and commit['tree']['sha'] == TREE and [x['sha'] for x in commit['parents']] == [PARENT], 'provider actual commit/tree/sole parent')
branch = read(R / 'PUBLICATION_BRANCH_READBACK.json')
require(branch['ref'] == 'refs/heads/' + BRANCH and branch['object']['sha'] == COMMIT and branch['object']['type'] == 'commit', 'published exact branch reference')
publication = read(R / 'PUBLICATION_RECEIPT.json')
require(publication['commit'] == COMMIT and publication['tree'] == TREE and publication['sole_parent'] == PARENT and publication['branch'] == BRANCH and publication['original_execution'] is False and publication['protected_grant'] == 'UNISSUED', 'publication receipt operation/non-grant')
admission = read(R / 'PUBLICATION_ROOT_ADMISSION.json')
require(admission['candidate_seal_sha256'] == CANDIDATE_SEAL and admission['decision'] == 'ADMIT_DISTINCT_FIRST_PUSH_ORDINARY_CAPTURE_BOUND_DIAGNOSTIC' and admission['protected_grant'] == 'UNISSUED' and admission['original_execution'] is False, 'Root ordinary admission only')
readbacks = read(R / 'PUBLICATION_EXACT_FILE_READBACKS.json')
require(readbacks['commit'] == COMMIT and len(readbacks['files']) == 3, 'three actual body readbacks at exact commit')
expected_bodies = {}
for name in ['.github/workflows/dg16-g132-engine-source-observe.yml', 'engineering/g132-engine-source-diagnostic/observe.py', 'engineering/g132-engine-source-diagnostic/ENGINE_MAP.json']:
    raw = (C / 'candidate' / name).read_bytes(); expected_bodies[blob(raw)] = (name, raw)
seen = set()
for row in readbacks['files']:
    require(row['encoding'] == 'base64' and row['sha'] in expected_bodies and row['sha'] not in seen, 'exact unique hosted body identity')
    seen.add(row['sha']); decoded = base64.b64decode(row['content'], validate=False)
    require(decoded == expected_bodies[row['sha']][1] and blob(decoded) == row['sha'], 'actual provider body bytes ' + expected_bodies[row['sha']][0])
require(seen == set(expected_bodies), 'all three hosted body bytes received')

artifacts = read(R / 'PROVIDER_ARTIFACTS.json')['artifacts']
require(len(artifacts) == 1, 'one actual artifact')
artifact = artifacts[0]
require(artifact['id'] == 14730158293 and artifact['name'] == 'g132-engine-source-44963085468-1' and artifact['size_in_bytes'] == 9555 and artifact['digest'] == 'sha256:' + ZIP_SHA and artifact['expired'] is False, 'provider artifact identity/size/digest')
require(artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == COMMIT and artifact['workflow_run']['head_branch'] == BRANCH, 'artifact belongs to exact run/commit/branch')
require(record(R / 'PROVIDER_ARTIFACT.zip') == {'bytes': 9555, 'sha256': ZIP_SHA}, 'actual ZIP digest matches provider')
with zipfile.ZipFile(R / 'PROVIDER_ARTIFACT.zip') as archive:
    require(len(archive.namelist()) == 4 and set(archive.namelist()) == {'OBSERVATION.json', 'STDERR.raw', 'NATIVE_EXIT_STATUS.raw', 'RETURN.json'}, 'artifact exact four members')
    for name in archive.namelist():
        require(archive.read(name) == (R / name).read_bytes(), 'ZIP CRC/readback exact ' + name)
ret = read(R / 'RETURN.json')
require(ret['schema'] == 'g132.ordinary-hosted-engine-source-native-return.v1' and ret['native_exit_status'] == 2 and ret['authority'] == 'NONE' and ret['native_admission'] is False and ret['original_awards'] == [], 'actual native return receipt preserves refusal')
require(set(ret['members']) == {'OBSERVATION.json', 'STDERR.raw', 'NATIVE_EXIT_STATUS.raw'}, 'return complete member population')
for name, expected in ret['members'].items():
    require(record(R / name) == expected, 'return member hash ' + name)
require((R / 'NATIVE_EXIT_STATUS.raw').read_bytes() == b'2\n' and (R / 'STDERR.raw').read_bytes() == b'', 'actual exit 2 and observer stderr empty')
logs = read(R / 'PROVIDER_JOB_LOGS.json')['content']
require(logs.encode() == (R / 'JOB.raw').read_bytes(), 'exact provider/raw job logs')
for text in ['Version: 20261116.376.1', COMMIT, 'Process completed with exit code 2.', ZIP_SHA, 'Artifact ID 14730158293']:
    require(text in logs, 'job log corroboration ' + text)

o = read(R / 'OBSERVATION.json')
context = o['context']
for k, v in {'GITHUB_ACTIONS': 'true', 'RUNNER_ENVIRONMENT': 'github-hosted', 'GITHUB_REPOSITORY': 'theislampill/IMPLEMENTAUDIT.md', 'GITHUB_EVENT_NAME': 'push', 'GITHUB_REF': 'refs/heads/' + BRANCH, 'GITHUB_RUN_ATTEMPT': '1', 'GITHUB_RUN_ID': str(RUN), 'GITHUB_SHA': COMMIT, 'GITHUB_WORKFLOW_SHA': COMMIT, 'GITHUB_JOB': 'observe', 'GITHUB_WORKFLOW_REF': 'theislampill/IMPLEMENTAUDIT.md/.github/workflows/dg16-g132-engine-source-observe.yml@refs/heads/' + BRANCH, 'ImageOS': 'ubuntu24', 'ImageVersion': '20261116.376.1'}.items():
    require(context[k] == v, 'actual admitted context ' + k)
require(all(o['process'][k] == 0 for k in ['uid', 'euid', 'gid', 'egid']) and o['process']['executable'] == '/usr/bin/python3.12' and o['process']['python'].startswith('3.12.3 '), 'actual root identity and Python observation')
require(o['started_time_ns'] < o['finished_time_ns'] and 0 < (o['finished_time_ns'] - o['started_time_ns']) / 1e9 < 240, 'actual observer elapsed under declared wall bound')
owner = C / 'candidate/engineering/g132-engine-source-diagnostic/observe.py'
require({k: o['diagnostic_owner'][k] for k in ('bytes', 'sha256')} == record(owner), 'actual executing helper exact source body')
mapping = read(C / 'candidate/engineering/g132-engine-source-diagnostic/ENGINE_MAP.json')
require(o['engine_loaded'] is True and o['engine_loading_origin'] == 'DIAGNOSTIC_CHECKOUT_EXACT_R2_MEMBERS' and o['engine_map'] == mapping and len(mapping) == 13, 'initial diagnostic-checkout Engine authentic map')
require(o['source_commit'] == PARENT and o['source_tree'] == '9b9c2b3f1453b83b87b628b665fceff492bf5b1e' and o['source_parent'] == 'e76a07b2bae7c945e5a9d529ed8cf9069f4c9064', 'fixed source goal tuple not standalone admission')
git_pin = {'kind': 'FILE', 'bytes': 4640384, 'sha256': '08ca4d2ee4d8915e86f1faaa52603752507c57af1d16d451dec9992bc9b6d801', 'mode': 493}
require(all(o['git_before'][k] == v for k, v in git_pin.items()), 'exact initial-only Git08ca body')
git_rows = o['selected_git_file_rows']
require(len(git_rows) == 17, 'seventeen selected Git rows')
for row in git_rows:
    observed = row['observed']
    computed = observed is not None and observed.get('kind') == 'FILE' and all(observed.get(k) == v for k, v in row['expected'].items())
    require(computed is True and row['match'] is True, 'independent selected Git pin comparison ' + row['path'])
require(set(o['gates']) == {'unchanged_git_input_validator'} and o['gates']['unchanged_git_input_validator']['status'] == 'PASS', 'only reached unchanged Git-input gate passed')
host = o['selected_host_input_observation']; mismatches = []
for row in host['pins'] + host['system_aliases']:
    observed = row['observed']
    computed = observed is not None and observed.get('kind') == 'FILE' and all(observed.get(k) == v for k, v in row['expected'].items())
    require(row['match'] == computed, 'independent selected host comparison ' + row['path'])
    if not computed:
        mismatches.append(row['path'])
require(set(mismatches) == {'/etc/ld.so.cache', '/lib/x86_64-linux-gnu/libc.so.6', '/lib64/ld-linux-x86-64.so.2', '/lib/x86_64-linux-gnu/libpthread.so.0'}, 'four actual runtime/library cache mismatches remain')
require(o['selected_host_input_matches'] is False and host['unchanged_owner_full_startup']['match'] is False and host['nss']['result']['match'] is False, 'startup/NSS remains unqualified')
require(o['launcher_observation']['path'] == '/usr/bin/bwrap' and o['launcher_observation']['match'] is False and o['launcher_observation']['observed']['kind'] == 'MISSING', 'actual missing launcher observation')

require(o['status'] == 'REFUSED' and o['failed_phase'] == 'standalone_source_preparation' and o['exception_type'] == 'ValueError' and o['reason'] == 'hosted Git refused or ordinary command custody incomplete', 'exact actual earlier failure phase/reason')
prep = o['source_preparation']
require(set(prep) == {'commands', 'expected_commit'} and prep['expected_commit'] == PARENT and len(prep['commands']) == 1 and len(o['ordinary_git_children']) == 1, 'one clone only; no completed source-preparation tuple')
command = prep['commands'][0]
source_path = o['disposable_source_root'] + '/source'
args = ['clone', '--no-local', '--no-hardlinks', '--no-checkout', '--', 'https://github.com/theislampill/IMPLEMENTAUDIT.md.git', source_path]
prefix = ['/usr/bin/git', '-c', 'credential.helper=', '-c', 'core.askPass=/bin/false', '-c', 'core.hooksPath=/dev/null', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false']
require(command['arguments'] == args and o['ordinary_git_children'] == [prefix + args], 'actual one authorized exact clone argv')
require(command['environment'] == {'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C', 'TZ': 'UTC', 'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_TERMINAL_PROMPT': '0', 'GIT_ASKPASS': '/bin/false'}, 'actual fixed credential-free child environment')
for k, v in {'returncode': 128, 'command_received': False, 'wait_reaped': True, 'owned_group_absent': False, 'descriptor_restoration': True, 'cleanup_errors': [], 'exception': None, 'timed_out': False, 'output_overflow': False, 'process_handle_returned': True, 'process_creation_outcome': 'HANDLE_RETURNED', 'eof': {'stderr': True, 'stdout': True}, 'hashes_cover': 'captured bytes'}.items():
    require(command[k] == v, 'actual command/custody predicate ' + k)
require(command['pid'] == 2415 and command['elapsed_seconds'] == 10.19336235099999, 'actual command PID and recorded duration')
stderr = command['stderr_excerpt'].encode()
require(stderr == ("Cloning into '" + source_path + "'...\nfatal: fetch-pack: invalid index-pack output\n").encode(), 'exact complete clone stderr text')
require(command['stream_bytes'] == {'stderr': len(stderr), 'stdout': 0} and len(stderr) == 103 and command['stream_sha256'] == {'stderr': sha(stderr), 'stdout': sha(b'')}, 'full short clone stderr reconstructed and stream hashes verified')
require(o['descriptor_restoration'] is True, 'observer descriptor restoration reported true')
unreached = ['actual_checkout_engine_map', 'source_capture', 'capture_bound_diagnostic', 'git_after', 'git_bookends_equal', 'source_loading_bookends_current']
require(all(k not in o for k in unreached) and all(k not in o['gates'] for k in ['git_namespace', 'producer_contract', 'captured_head_identity']), 'all later capture/diagnostic/admission/bookend fields absent')
for k in ['native_admission', 'original_execution', 'session_constructed', 'provider_acquired', 'private_inputs_selected', 'launcher_provisioned', 'policy_changed']:
    require(o[k] is False, 'no promoted authority/effect ' + k)
require(o['provider_imports'] == 0 and o['original_awards'] == [] and o['authority'] == 'NONE' and o['overall_admission'] == 'UNQUALIFIED' and o['no_automatic_retry'] is True, 'unchanged non-admission/no-retry ceiling')
receive(R, 'SEAL.json', RAW_SEAL, 3865, 21, 268924)

result = {
    'schema': 'g132.capture-bound.actual-native-independent-receiving.v1',
    'disposition': 'PASS_RECEIVED_AUTHENTIC_NATIVE_FAILURE', 'reviewer': '/root/independent_review', 'authority': 'NONE',
    'root_binding': {'epoch': 'G0044', 'receipt': '3fb3e2d80b1575b3a4ec28cc196957f9ce498523', 'verified_native': 'fbef7e/0'},
    'identity': {'run': RUN, 'attempt': 1, 'job': JOB, 'commit': COMMIT, 'tree': TREE, 'sole_parent': PARENT, 'branch': BRANCH},
    'raw_seal': record(R / 'SEAL.json'), 'payload_count': 21, 'payload_bytes': 268924,
    'candidate_seal_sha256': CANDIDATE_SEAL, 'source_review_seal_sha256': REVIEW_SEAL,
    'artifact': {'id': 14730158293, **record(R / 'PROVIDER_ARTIFACT.zip'), 'all_four_members_exact': True, 'return_member_hashes_exact': True},
    'actual_observation': {'native_exit': 2, 'provider_conclusion': 'failure', 'image': context['ImageVersion'], 'process': o['process'],
        'engine_loaded_from_diagnostic_checkout': True, 'Engine_map_members': 13, 'selected_git_rows_match': 17,
        'git_initial_only': git_pin, 'host_pin_mismatches': mismatches, 'NSS_and_full_startup_qualified': False, 'launcher_present': False,
        'failed_phase': o['failed_phase'], 'reason': o['reason'], 'standalone_source_preparation_commands': 1,
        'command': command, 'observer_descriptor_restoration': o['descriptor_restoration'], 'unreached_fields': unreached},
    'limits': ['owned_group_absent=false is an authentic observed predicate failure; no group-member, living-process, zombie, or numerical-identity classification is established.',
        'The direct child was reaped. This does not prove termination or absence of its group.',
        'The original clone/index-pack root cause is unproved. No memory/file-limit/network/transient-cause attribution is made.',
        'No standalone exact source tuple, actual-source Engine, complete capture, capture exception operands, namespace/producer/HEAD gates, or final source/Git bookends were reached.',
        'The new traceback diagnostic did not execute; operation03 capture cause remains unknown.',
        'Initial Git and selected input observations are historical before-only observations, not final currentness or protected admission.',
        'Original G132 remains spent; no replay, new protected grant, original award, or closure is issued by receiving.'],
    'reviewer_operations': {'data_only': True, 'native_candidate_or_product_calls': 0, 'Git_calls': 0, 'provider_calls': 0, 'controller_calls': 0, 'source_edits': 0, 'retries': 0},
    'checks': checks}
(O / 'MECHANICAL_RECEIVING.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps({'disposition': result['disposition'], 'checks': len(checks), 'run': RUN, 'native_exit': 2,
                  'failed_phase': o['failed_phase'], 'clone_exit': 128, 'owned_group_absent': False,
                  'capture_reached': False, 'reviewer_execution': False}))
