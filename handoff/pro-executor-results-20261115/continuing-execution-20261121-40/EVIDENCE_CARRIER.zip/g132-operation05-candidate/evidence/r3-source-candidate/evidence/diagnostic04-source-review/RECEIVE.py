#!/usr/bin/env python3
"""Static/data receiving only. Never import or execute candidate/product code.

Compiles pinned source buffers solely for inert CPython 3.12 code comparison.
The only child commands read two exact local workflow blobs, with network and
lazy fetching disabled. Output writes stay inside this review directory.
"""
from pathlib import Path, PurePosixPath
import ast
import copy
import hashlib
import json
import os
import re
import stat
import subprocess
import sys
import types
import zipfile

BASE = Path('/workspace/scratch/097486cde2dd')
P = BASE / 'g132-capture-bound-candidate'
OUT = BASE / 'g132-capture-bound-independent-review'
SRC = P / 'evidence/inherited-full-source/inherited-source'
OLD = P / 'evidence/operation03/candidate/candidate'
CURRENT = P / 'candidate'
OWNER = 'engineering/g132-engine-source-diagnostic/observe.py'
WORKFLOW = '.github/workflows/dg16-g132-engine-source-observe.yml'
MAP = 'engineering/g132-engine-source-diagnostic/ENGINE_MAP.json'
SEAL = 'ed10206609b732337d8e2faed40df8db68dd7fd08311a2c619bae1569726a2b2'
PARENT = 'f75533f95f0d099c87e7a04beb11b0a25628acdc'
PARENT_TREE = '9b9c2b3f1453b83b87b628b665fceff492bf5b1e'
EXPECTED_TREE = 'baffbae6d7a19e289db100233704df2a0e721914'
BRANCH = 'pro/dg16-g132-engine-source-observe-20261121-04'
checks = []


def need(condition, label):
    if not condition:
        raise AssertionError(label)
    checks.append(label)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def oid(kind, data):
    return hashlib.sha1(kind.encode() + b' ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def rec(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': sha(raw)}


def pairs(rows):
    d = {}
    for k, v in rows:
        if k in d:
            raise AssertionError('duplicate JSON key')
        d[k] = v
    return d


def js(path):
    return json.loads(path.read_bytes(), object_pairs_hook=pairs)


def verify_packet():
    need(rec(P / 'SEAL.json') == {'bytes': 37883, 'sha256': SEAL}, 'exact candidate seal')
    seal = js(P / 'SEAL.json'); names = set(); total = 0
    for row in seal['files']:
        name = row['path']; parts = PurePosixPath(name).parts
        need(not name.startswith('/') and name == str(PurePosixPath(name)) and all(p not in ('', '.', '..') for p in parts) and name not in names, 'safe unique member ' + name)
        names.add(name); path = P / name; total += row['bytes']
        need(path.is_file() and not path.is_symlink() and rec(path) == {k: row[k] for k in ('bytes', 'sha256')}, 'exact member ' + name)
        if 'git_blob' in row:
            need(oid('blob', path.read_bytes()) == row['git_blob'], 'blob-bound member ' + name)
    actual = set()
    for path in P.rglob('*'):
        mode = path.lstat().st_mode
        need(stat.S_ISREG(mode) or stat.S_ISDIR(mode), 'regular/dir only ' + path.relative_to(P).as_posix())
        if path.is_file() and path.name != 'SEAL.json':
            actual.add(path.relative_to(P).as_posix())
        elif path.is_file() and path != P / 'SEAL.json':
            actual.add(path.relative_to(P).as_posix())
    need(actual == names and len(names) == seal['payload_count'] == 147 and total == seal['payload_bytes'] == 3520510, 'complete 147-member payload census')
    return seal


def tree_rows(raw):
    rows = {}
    for row in raw.split(b'\0'):
        if not row:
            continue
        meta, path = row.split(b'\t', 1)
        mode, kind, blob = meta.decode().split()
        name = path.decode()
        need(name not in rows and kind == 'blob', 'unique blob tree row ' + name)
        rows[name] = (mode, blob)
    return rows


def tree_oid(rows):
    root = {}
    for path, value in rows.items():
        node = root
        parts = path.split('/')
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        need(parts[-1] not in node, 'unique Git tree leaf ' + path)
        node[parts[-1]] = value
    def encode(node):
        contents = []
        for name in sorted(node, key=lambda n: (n + ('/' if isinstance(node[n], dict) else '')).encode()):
            entry = node[name]
            mode, value = ('40000', encode(entry)) if isinstance(entry, dict) else entry
            contents.append(mode.encode() + b' ' + name.encode() + b'\0' + bytes.fromhex(value))
        return oid('tree', b''.join(contents))
    return encode(root)


seal = verify_packet()
parent_raw = (P / 'PARENT_COMMIT.raw').read_bytes()
need(oid('commit', parent_raw) == PARENT, 'parent commit content address')
headers = parent_raw.split(b'\n\n', 1)[0].decode().splitlines()
need([x for x in headers if x.startswith('tree ')] == ['tree ' + PARENT_TREE] and
     [x for x in headers if x.startswith('parent ')] == ['parent e76a07b2bae7c945e5a9d529ed8cf9069f4c9064'], 'exact parent tree and sole parent')
parent_rows = tree_rows((P / 'PARENT_TREE.raw').read_bytes())
need(len(parent_rows) == 1768 and tree_oid(parent_rows) == PARENT_TREE, 'independent complete parent tree derivation')
proposed = dict(parent_rows); additions = []
for path in (WORKFLOW, MAP, OWNER):
    data = (CURRENT / path).read_bytes()
    need(path not in proposed, 'additive proposed path ' + path)
    proposed[path] = ('100644', oid('blob', data))
    additions.append({'path': path, 'mode': '100644', 'git_blob': oid('blob', data), 'bytes': len(data), 'sha256': sha(data)})
need(proposed == tree_rows((P / 'EXPECTED_TREE.raw').read_bytes()) and len(proposed) == 1771 and tree_oid(proposed) == EXPECTED_TREE, 'exact three-addition complete proposed tree')
publication = js(P / 'PUBLICATION_ENTRIES.json')
need(len(publication) == 3 and {x['path'] for x in publication} == {WORKFLOW, MAP, OWNER}, 'exact publication entry population')
for entry in publication:
    need(entry['type'] == 'blob' and entry['mode'] == '100644' and entry['content'].encode() == (CURRENT / entry['path']).read_bytes(), 'publication content equality ' + entry['path'])

proofs = js(P / 'FULL_OWNER_PROOFS.json')['owners']
need(len(proofs) == 14, 'fourteen full inherited owners')
for row in proofs:
    path = SRC / row['path']; raw = path.read_bytes()
    need(rec(path) == {k: row[k] for k in ('bytes', 'sha256')} and oid('blob', raw) == row['git_blob'] and parent_rows[row['path']] == (row['parent_mode'], row['git_blob']), 'unchanged authenticated owner ' + row['path'])
mapping = js(CURRENT / MAP)
need(len(mapping) == 13 and (CURRENT / MAP).read_bytes() == (OLD / MAP).read_bytes(), 'unchanged thirteen-member Engine map')
for name, pin in mapping.items():
    actual = 'test-support/r5-hosted-git-08ca-source/work-graph-c5-executor.py' if name == 'scripts/work-graph-c5-executor.py' else name
    need(rec(SRC / actual) == pin, 'exact Engine map body ' + name)

new_raw = (CURRENT / OWNER).read_bytes(); old_raw = (OLD / OWNER).read_bytes()
new_ast = ast.parse(new_raw); old_ast = ast.parse(old_raw)
new_functions = {n.name: n for n in new_ast.body if isinstance(n, ast.FunctionDef)}
old_functions = {n.name: n for n in old_ast.body if isinstance(n, ast.FunctionDef)}
need(set(new_functions) - set(old_functions) == {'capture_bound_values', 'capture_bound_diagnostic'}, 'only two added functions')
for name, old_node in old_functions.items():
    if name != 'observe':
        need(ast.dump(new_functions[name]) == ast.dump(old_node) and ast.get_source_segment(new_raw.decode(), new_functions[name]) == ast.get_source_segment(old_raw.decode(), old_node), 'unchanged complete existing function ' + name)
calls = [n for n in ast.walk(new_functions['observe']) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'complete_source']
need(len(calls) == 1, 'one actual complete-source call')
wrapper = next(n for n in ast.walk(new_functions['observe']) if isinstance(n, ast.Try) and len(n.body) == 1 and isinstance(n.body[0], ast.Assign) and n.body[0].value is calls[0])
need(len(wrapper.handlers) == 1 and isinstance(wrapper.handlers[0].type, ast.Name) and wrapper.handlers[0].type.id == 'BaseException' and isinstance(wrapper.handlers[0].body[-1], ast.Raise) and wrapper.handlers[0].body[-1].exc is None and not wrapper.orelse and not wrapper.finalbody, 'exception-only wrapper ends with unconditional bare re-raise')
class RestoreOld(ast.NodeTransformer):
    def visit_Try(self, node):
        if node is wrapper:
            return node.body[0]
        return self.generic_visit(node)
restored = RestoreOld().visit(new_ast)
restored.body = [n for n in restored.body if not (isinstance(n, ast.FunctionDef) and n.name in {'capture_bound_values', 'capture_bound_diagnostic'}) and not (isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id in {'CAPTURE_SOURCE', 'CAPTURE_PIN', 'CAPTURE_BOUNDS', 'CAPTURE_ERROR'})]
for node in restored.body:
    if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and node.targets[0].id == 'BRANCH':
        node.value.value = 'pro/dg16-g132-engine-source-observe-20261121-03'
need(ast.dump(restored) == ast.dump(old_ast), 'complete prior observer recovered after exact declared AST delta')

wf = js(CURRENT / WORKFLOW); old_wf = js(OLD / WORKFLOW)
expected_wf = copy.deepcopy(old_wf)
expected_wf['on']['push']['branches'] = [BRANCH]
expected_wf['concurrency']['group'] = 'g132-engine-source-observe-20261121-04'
expected_wf['jobs']['observe']['env']['EXPECTED_OBSERVER_SHA256'] = sha(new_raw)
expected_wf['jobs']['observe']['steps'][1]['run'] = expected_wf['jobs']['observe']['steps'][1]['run'].replace('pro/dg16-g132-engine-source-observe-20261121-03', BRANCH)
need(wf == expected_wf, 'workflow differs only by declared branch/group/hash changes')
need(wf['on'] == {'push': {'branches': [BRANCH]}} and list(wf['jobs']) == ['observe'] and wf['permissions'] == {'contents': 'read'}, 'single distinct push/job and read-only permission')
need(wf['jobs']['observe']['env']['EXPECTED_MAP_BYTES'] == str(len((CURRENT / MAP).read_bytes())), 'exact map size environment binding')
need(wf['jobs']['observe']['steps'][0]['uses'] == 'actions/checkout@11d5960a326750d5838078e36cf38b85af677262' and wf['jobs']['observe']['steps'][2]['uses'] == 'actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02', 'unchanged exact official action identities')

# Compile inert code only under an actual CPython 3.12 interpreter.
need(sys.version_info[:2] == (3, 12) and sys.implementation.name == 'cpython', 'actual CPython 3.12 data-check interpreter')
prefix_path = SRC / 'scripts/qualify-work-graph-prefix.py'; prefix_raw = prefix_path.read_bytes()
filename = '/ordinary-source-root-never-created/scripts/qualify-work-graph-prefix.py'
compile_default = compile(prefix_raw, filename, 'exec')
compile_no_inherit = compile(prefix_raw, filename, 'exec', dont_inherit=True)
snapshot_a = next(c for c in compile_default.co_consts if type(c) is types.CodeType and c.co_name == 'snapshot_tree')
snapshot_b = next(c for c in compile_no_inherit.co_consts if type(c) is types.CodeType and c.co_name == 'snapshot_tree')
walk_a = next(c for c in snapshot_a.co_consts if type(c) is types.CodeType and c.co_name == 'walk')
walk_b = next(c for c in snapshot_b.co_consts if type(c) is types.CodeType and c.co_name == 'walk')
need(compile_default == compile_no_inherit and snapshot_a == snapshot_b and walk_a == walk_b, '3.12 default/dont-inherit complete nested code equality')
need((snapshot_a.co_firstlineno, walk_a.co_firstlineno) == (180, 185), '3.12 actual compiler function coordinates')
for path in [CURRENT / OWNER, SRC / 'scripts/qualify-work-graph-c5-setup.py', SRC / 'scripts/load-work-graph-c5-executor.py', prefix_path]:
    tree = ast.parse(path.read_bytes())
    need(not any(isinstance(n, ast.ImportFrom) and n.module == '__future__' for n in ast.walk(tree)), 'no inherited future flags in compile chain ' + path.name)
    compile(path.read_bytes(), str(path), 'exec', dont_inherit=True)
prefix_ast = ast.parse(prefix_raw)
snap_ast = next(n for n in prefix_ast.body if isinstance(n, ast.FunctionDef) and n.name == 'snapshot_tree')
target_raise = next(n for n in ast.walk(snap_ast) if isinstance(n, ast.Raise) and isinstance(n.exc, ast.Call) and n.exc.args and isinstance(n.exc.args[0], ast.Constant) and n.exc.args[0].value == 'source input byte/entry bound exceeded')
target_if = next(n for n in ast.walk(snap_ast) if isinstance(n, ast.If) and target_raise in n.body)
need(target_raise.lineno == 221 and ast.dump(target_if.test) == ast.dump(ast.parse('count > bounds["entries"] or before.st_size > bounds["file_bytes"] or total > bounds["total_bytes"]', mode='eval').body), 'exact target line and unchanged three-disjunct predicate')
receiver_ast = ast.parse(new_raw)
receiver = next(n for n in receiver_ast.body if isinstance(n, ast.FunctionDef) and n.name == 'capture_bound_diagnostic')
local_keys = sorted({n.slice.value for n in ast.walk(receiver) if isinstance(n, ast.Subscript) and isinstance(n.value, ast.Attribute) and n.value.attr == 'f_locals' and isinstance(n.slice, ast.Constant)})
need(local_keys == ['before', 'bounds', 'count', 'depth', 'excluded', 'name', 'root', 'total'], 'only eight allowlisted frame-local keys')
need(not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ('exec', 'eval', '__import__', 'open') for n in ast.walk(receiver)), 'new receiver executes/imports/opens no product or data source')
inputs = ast.parse((SRC / 'scripts/work-graph-c5-inputs.py').read_bytes())
complete = next(n for n in inputs.body if isinstance(n, ast.FunctionDef) and n.name == 'complete_source')
snapshot_call = next(n for n in ast.walk(complete) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'snapshot_tree')
need(ast.dump(snapshot_call) == ast.dump(ast.parse('P.snapshot_tree(root, objects, P.SOURCE_BOUNDS)', mode='eval').body), 'actual complete_source passes same prefix bounds object directly')
engine = (SRC / 'scripts/load-work-graph-c5-executor.py').read_text()
need('module._R0035_C5_INPUT_CAPTURE=dict(prefix=modules[PREFIX],sources=base_sources,check=self.check)' in engine and 'module._R0035_C5_EXECUTOR_CAPTURE=dict(prefix=modules[PREFIX],base=modules[BASE]' in engine, 'base and executor share exact captured prefix module')

controls = js(P / 'CONTROLS_VALIDATION.json')
need(controls['exit'] == 0 and controls['controls_count'] == 18 and controls['observer_sha256'] == sha(new_raw), 'retained final controls exact owner/exit')
for stem, record_name in [('CONTROLS', 'CONTROLS_VALIDATION.json'), ('ACTUAL_NONHOST', 'ACTUAL_NONHOST_VALIDATION.json')]:
    r = js(P / record_name)
    for name in ('stdout', 'stderr'):
        need(rec(P / (stem + '_' + name.upper() + '.raw')) == {'bytes': r[name + '_bytes'], 'sha256': r[name + '_sha256']}, 'retained ' + stem + ' ' + name + ' hash')
need('Ran 18 tests' in (P / 'CONTROLS_STDERR.raw').read_text() and (P / 'CONTROLS_STDERR.raw').read_text().endswith('OK\n'), 'complete successful retained control census')
nonhost = js(P / 'ACTUAL_NONHOST_STDOUT.raw')
need((P / 'ACTUAL_NONHOST_EXIT.raw').read_bytes() == b'2\n' and nonhost['failed_phase'] == 'context' and nonhost['reason'] == 'actual UID/GID zero is required' and nonhost['ordinary_git_children'] == [] and 'engine_loaded' not in nonhost, 'authentic retained nonhost refusal before product loading')
need(controls['actual_positive_traceback_observed'] is False and controls['product_capture_calls'] == 0 and controls['product_imports'] == 0, 'local controls do not claim positive authentic product traceback')

actual = js(P / 'evidence/operation03/raw/OBSERVATION.json')
need(actual['failed_phase'] == 'complete_actual_source_capture' and actual['exception_type'] == 'ValueError' and actual['reason'] == 'source input byte/entry bound exceeded', 'retained actual operation03 exact motivating failure')
need(actual['engine_map'] == mapping and actual['actual_checkout_engine_map'] == mapping and len(actual['selected_git_file_rows']) == 17 and all(row['match'] for row in actual['selected_git_file_rows']), 'actual prior both Engine maps and selected Git rows')
need(len(actual['source_preparation']['commands']) == 11 and all(c['command_received'] and c['returncode'] == 0 for c in actual['source_preparation']['commands']), 'actual prior eleven successful preparation commands')
need(actual['source_preparation']['source_commit'] == PARENT and actual['source_preparation']['source_tree'] == PARENT_TREE and actual['source_preparation']['ordered_parents'] == ['e76a07b2bae7c945e5a9d529ed8cf9069f4c9064'], 'actual prior exact source tuple')
need('capture_bound_diagnostic' not in actual and 'source_capture' not in actual, 'prior failure contains no new operands or completed capture')
zip_path = P / 'evidence/operation03/raw/PROVIDER_ARTIFACT.zip'
with zipfile.ZipFile(zip_path) as archive:
    need(set(archive.namelist()) == {'OBSERVATION.json', 'STDERR.raw', 'NATIVE_EXIT_STATUS.raw', 'RETURN.json'}, 'actual prior archive exact four members')
    for name in archive.namelist():
        need(archive.read(name) == (zip_path.parent / name).read_bytes(), 'actual prior artifact member equality ' + name)

# Read only the two inherited workflow bodies; no source operations are run.
workflow_rows = {k: v for k, v in parent_rows.items() if k.startswith('.github/workflows/')}
need(set(workflow_rows) == {'.github/workflows/pages.yml', '.github/workflows/validate.yml'}, 'exact inherited workflow population')
git_reads = []
repo = '/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b'
env = {'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C', 'GIT_NO_LAZY_FETCH': '1', 'GIT_NO_REPLACE_OBJECTS': '1', 'GIT_OPTIONAL_LOCKS': '0', 'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_TERMINAL_PROMPT': '0'}
for path, (mode, blob) in workflow_rows.items():
    cmd = ['/usr/bin/git', '-c', 'protocol.allow=never', '-c', 'core.hooksPath=/dev/null', '-C', repo, 'cat-file', 'blob', blob]
    output_path = OUT / ('INHERITED_' + Path(path).name)
    previously_received = output_path.exists()
    if previously_received:
        body = output_path.read_bytes()
    else:
        done = subprocess.run(cmd, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10)
        need(done.returncode == 0 and not done.stderr, 'successful read-only local workflow read ' + path)
        body = done.stdout
        output_path.write_bytes(body)
    need(oid('blob', body) == blob, 'exact local inherited workflow body ' + path)
    git_reads.append({'argv': cmd, 'environment': env, 'exit': 0, 'stdout': rec(output_path), 'stderr_bytes': 0, 'retained_as': output_path.name,
                      'reused_exact_review_local_read': previously_received})
    text = body.decode(); lines = text.splitlines()
    need(lines.count('  push:') == 1, 'single inherited push clause ' + path)
    push_fields = []
    for line in lines[lines.index('  push:') + 1:]:
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        if len(line) - len(line.lstrip()) <= 2:
            break
        push_fields.append(line.strip())
    need(push_fields in (['branches:', '- main'], ['branches: [main]']), 'inherited push restricted to main ' + path)

verify_packet()
receipt = {
    'schema': 'g132.capture-bound.independent-source-review.v1', 'disposition': 'PASS_ORDINARY_SOURCE_ONLY',
    'reviewer': '/root/independent_review', 'authority': 'NONE',
    'root_binding': {'epoch': 'G0044', 'receipt': '3fb3e2d80b1575b3a4ec28cc196957f9ce498523', 'verified_native': 'df837d/0'},
    'packet': {'seal': rec(P / 'SEAL.json'), 'payloads': 147, 'payload_bytes': 3520510, 'all_members_exact': True},
    'source': {'parent': PARENT, 'parent_tree': PARENT_TREE, 'parent_files': 1768, 'proposed_tree': EXPECTED_TREE, 'proposed_files': 1771, 'additions': additions, 'full_unchanged_owners': 14, 'Engine_members': 13},
    'compile_only_compatibility': {'python': sys.version, 'executable': sys.executable, 'optimize': sys.flags.optimize,
        'module_default_equals_dont_inherit': compile_default == compile_no_inherit, 'snapshot_code_equals': snapshot_a == snapshot_b,
        'nested_walk_code_equals': walk_a == walk_b, 'snapshot_flags': snapshot_a.co_flags, 'walk_flags': walk_a.co_flags,
        'snapshot_firstline': snapshot_a.co_firstlineno, 'walk_firstline': walk_a.co_firstlineno,
        'allowed_locals': local_keys, 'product_modules_executed': 0, 'product_functions_invoked': 0,
        'exact_hosted_python_qualification': False, 'positive_authentic_product_traceback': False},
    'retained_controls': {'count': 18, 'native': 'b76173/0', 'actual_local_entry': 'e8b4b8/0', 'actual_local_child_exit': 2, 'not_reexecuted_by_reviewer': True},
    'prior_actual': {'run': '44960479304', 'attempt': 1, 'commit': '1980ef263b6d978d690f7fc65e2fac4cabe0de08', 'failed_phase': actual['failed_phase'], 'reason': actual['reason'], 'operand_recovery_not_in_prior_artifact': True},
    'read_only_git_receipts': git_reads,
    'reviewer_execution_counts': {'candidate_entries': 0, 'product_functions': 0, 'hosted_operations': 0, 'provider_operations': 0, 'controller_operations': 0, 'Git_read_only_blob_commands': 2, 'Git_mutations': 0},
    'checks': checks,
    'limitations': ['No positive authentic product traceback has been observed for this candidate.',
        'CPython 3.12.14 compile-only evidence is not an exact hosted interpreter/environment qualification.',
        'The same finite context, runtime/source/Git, and resource guards may legitimately refuse the next operation.',
        'Post-reap descendant detection, aggregate clone-disk exposure, and once-only branch publication remain inherited limitations.',
        'A bound failure leaves final source/Git bookends and subsequent namespace/producer/HEAD gates unreached.',
        'Root alone owns fresh publication/currentness, execution, adjudication, and any grant.']}
(OUT / 'MECHANICAL_RECEIVING.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
print(json.dumps({'disposition': receipt['disposition'], 'checks': len(checks), 'packet_members': 147,
                  'expected_tree': EXPECTED_TREE, 'python': sys.version.split()[0],
                  'compile_only_equal': True, 'candidate_entries': 0, 'product_calls': 0,
                  'read_only_git': len(git_reads)}))
