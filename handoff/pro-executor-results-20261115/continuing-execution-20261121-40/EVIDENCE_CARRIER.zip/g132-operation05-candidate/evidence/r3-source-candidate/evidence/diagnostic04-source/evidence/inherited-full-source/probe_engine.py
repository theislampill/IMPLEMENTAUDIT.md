#!/usr/bin/env python3
"""Actual exact Engine import only; no session, original, provider or child launch."""
import ast
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback
import types

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'r2-checkout'
RECEIPT = json.loads((BASE/'EXACT_CHECKOUT_RECEIPT.json').read_text())
EXPECTED = {entry['path']:entry for entry in RECEIPT['entries']}
report = dict(schema='g132.actual-engine-loading.v1', authority='NONE',
              source_commit=RECEIPT['commit'], source_tree=RECEIPT['tree'],
              scope='LOCAL_SOURCE_LOADING_ONLY', original_execution=False,
              session_constructed=False, provider_acquired=False,
              native_or_hosted_admission=False, source_mutation=False,
              process=dict(pid=os.getpid(), ppid=os.getppid(),
                           uid=os.getuid(), euid=os.geteuid(), gid=os.getgid(), egid=os.getegid(),
                           proc_starttime_ticks=Path('/proc/self/stat').read_text().split()[21],
                           executable=str(Path('/proc/self/exe').resolve()),
                           python=sys.version, argv=sys.argv),
              started_time_ns=time.time_ns(), source_map=[], exec_events=[], forbidden_events=[])

active = True
FORBIDDEN = {'subprocess.Popen','os.fork','os.forkpty','os.exec','os.posix_spawn',
             'os.system','os.remove','os.rmdir','os.rename','os.mkdir','os.link',
             'os.symlink','os.chmod','os.chown','os.truncate','os.utime',
             'os.setxattr','os.removexattr','socket.__new__','socket.connect',
             'socket.bind','socket.getaddrinfo','ctypes.dlopen','ctypes.dlsym'}

def audit(event, args):
    if not active:
        return
    if event == 'exec':
        report['exec_events'].append(dict(filename=args[0].co_filename))
    forbidden = event in FORBIDDEN
    if event == 'open':
        filename, mode, flags = args
        forbidden = bool(flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
    if forbidden:
        report['forbidden_events'].append(dict(event=event))
        raise RuntimeError('import-only guard refused '+event)

sys.addaudithook(audit)

def load_owner(path, name):
    physical = ROOT/path
    raw = physical.read_bytes()
    expected = EXPECTED[path]
    assert len(raw) == expected['bytes']
    assert hashlib.sha256(raw).hexdigest() == expected['sha256']
    module = types.ModuleType(name)
    module.__file__ = str(physical)
    exec(compile(raw, str(physical), 'exec'), module.__dict__)
    return module

phase = 'loader_import'
try:
    loader = load_owner('scripts/load-work-graph-c5-executor.py','g132_import_only_loader')
    assert loader.R5_GIT_08CA_SOURCE_REVISION == 'R5_HOSTED_UBUNTU24_GIT_08CA_SOURCE_20261121_V1'
    assert loader.R5_HOSTED_PROFILE == 'FIXED_GENUINE_C5_SHARED_IMAGE_R5_HOSTED_UBUNTU24_SINGLE_COPY_20261105_V1'
    phase = 'engine_capture'
    engine = loader._Engine(loader.R5_HOSTED_PROFILE, source_revision=loader.R5_GIT_08CA_SOURCE_REVISION)
    report.update(profile=engine.profile, source_revision=engine.source_revision,
                  execution_selection=engine.execution_selection)
    for logical,(raw,identity) in engine.sources.items():
        physical = [name for name in EXPECTED if loader._identity((ROOT/name).stat()) == identity]
        assert len(physical) == 1
        report['source_map'].append(dict(logical_path=logical, physical_path=physical[0],
            bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
            git_blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),
            captured_identity=list(identity), expected_pin=engine.pins.get(logical)))
    report['capture_complete'] = True
    phase = 'engine_load'
    current = engine.load()
    engine.check()
    assert current.SOURCES is engine.sources
    assert current.PROFILE == engine.profile
    report.update(engine_loaded=True, source_currentness_after=True,
                  executor_module=current.__name__, limits=dict(current.LIMITS),
                  source_members=len(engine.sources))
    phase = 'setup_admission_load'
    setup = load_owner('scripts/qualify-work-graph-c5-setup.py','g132_import_only_setup')
    via_setup = setup.hosted_current_owner(ROOT)
    via_setup.CHECK()
    assert via_setup.PROFILE == current.PROFILE
    assert {k:hashlib.sha256(v[0]).hexdigest() for k,v in via_setup.SOURCES.items()} == {
        k:hashlib.sha256(v[0]).hexdigest() for k,v in current.SOURCES.items()}
    report.update(setup_actual_loading=True, setup_captured_source_map_equal=True,
                  status='LOADED_LOCAL_SOURCE_ONLY')
except BaseException as exc:
    report.update(status='FAILED', failed_phase=phase, exception_type=type(exc).__name__,
                  exception=str(exc), frames=[dict(path=f.filename, line=f.lineno, function=f.name)
                  for f in traceback.extract_tb(exc.__traceback__)])
finally:
    active = False
    report['finished_time_ns'] = time.time_ns()
    output = BASE/'ENGINE_LOADING_RESULT.json'
    output.write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('source_map','exec_events','frames')}, sort_keys=True))
    if 'frames' in report:
        print(json.dumps(dict(frames=report['frames']), sort_keys=True))
    print(json.dumps(dict(path=output.name, bytes=output.stat().st_size,
                         sha256=hashlib.sha256(output.read_bytes()).hexdigest()), sort_keys=True))
sys.exit(0 if report['status']=='LOADED_LOCAL_SOURCE_ONLY' else 1)
