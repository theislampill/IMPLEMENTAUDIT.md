# G132 ordinary operation 04 — capture-bound exception observation

State: implementation plan under Root's delegated ordinary engineering authority. Author: `/root/g132_capture_bound_engineering`. Root alone controls provider publication, any distinct hosted operation, adjudication, and integration. No controller operation, provider write, branch creation, protected execution, original execution, grant, retry, or award is authorized to this author.

## Intent and evidence

Actual operation 03, run 44960479304 attempt 1 at commit 1980ef263b6d978d690f7fc65e2fac4cabe0de08, loaded both authentic 13-member Engines and completed all eleven fresh complete-source preparation commands. It then failed in `complete_actual_source_capture` with the unchanged `source input byte/entry bound exceeded` exception. The pinned prefix owner raises that exact exception at line 221 after incrementing `count` and `total` for the current regular file. Its predicate is `count > 4096 or before.st_size > 134217728 or total > 268435456`; depth remains 40. The retained artifact omitted all three current operands and the path. Its 29,463 Git object-list rows do not select a filesystem-bound disjunct.

The full pinned prefix, loader, inputs owner, other thirteen-member Engine bodies, separate setup owner, inherited exact-source evidence, operation 03 source/review/raw/receiving packets, and Root's terminal adjudication are retained under `evidence/`. This packet's copies have been verified against their supplied seals. Their historical decisions and limits are evidence, not transferred authority.

## Selected approach

Use the authentic exception that escapes the existing, single call to `actual.B.complete_source(actual_source, objects)`. A separate ordinary diagnostic function checks the exact pinned prefix source buffer and identifies its actual `snapshot_tree` and nested `walk` code objects. It compiles that already-held 53,362-byte public source buffer only to compare code objects; it never executes the compiled buffer, instantiates its product module, or replaces a function. This binds the executing function to the pinned bytes even against a counterfeit function with copied filename and line metadata. It walks at most 64 traceback records and requires the leaf to be the pinned regular-file refusal line 221, descended from that exact snapshot invocation. It checks the source root, module/code identities, empty exclusions, and the unchanged bounds. It reads only the allowlisted count, total, current stat size, depth, relative name, and four bound integers. No file content, object dictionary, partial capture state, arbitrary locals, descriptor contents, or private bytes enter the diagnostic result.

The result preserves the real operands and relative path with explicit limits, plus separately labelled derived comparisons and the first true disjunct in the unchanged source order. Unsupported or malformed traceback data yields an unavailable diagnostic. The existing exception is re-raised in all cases, leaving the original failure, native return, resource controls, and overall non-admission intact.

This approach observes a failure already produced by the genuine source owner. A second filesystem scan or second capture would observe a different time and add work; it is excluded. Modifying/monkeypatching the product to enrich its exception would change the owner and its Engine pins; it is excluded. Raising limits, omitting source members, and repacking, unpacking, or synthesizing Git objects remain excluded.

## Exact prospective delta and boundaries

- Distinct operation: `G132_ENGINE_SOURCE_OBSERVE_20261121_04_CAPTURE_BOUND`.
- Prospective branch: `pro/dg16-g132-engine-source-observe-20261121-04`.
- Sole parent: `f75533f95f0d099c87e7a04beb11b0a25628acdc`, tree `9b9c2b3f1453b83b87b628b665fceff492bf5b1e`, whose sole parent is `e76a07b2bae7c945e5a9d529ed8cf9069f4c9064`.
- Exactly three added hosted paths: the existing diagnostic workflow path, `engineering/g132-engine-source-diagnostic/observe.py`, and its unchanged `ENGINE_MAP.json`.
- Observer changes: branch literal, bounded diagnostic constants/functions, and an exception-only wrapper around the single unchanged complete-source call.
- Workflow changes: branch/concurrency/shell branch check and observer SHA256. All action pins, permissions, timeouts, clean environment, artifact retention, native-status preservation, and no-retry behavior stay unchanged.
- All inherited product bodies, the 13-member map, Git08ca pin, physical-file checks, source tuple/completeness, namespace/producer/HEAD checks, security/audit/resource/timing controls, and false native/original admission remain unchanged.

The four library/cache mismatches, NSS files-only refusal, missing bwrap, and later unreached source gates remain unqualified. Original G132 run 44888568054 stays spent. Historical 301/A4-07 unknowns and queued 43098152901 remain unaffected.

## Ordered work and acceptance

1. Re-receive the sealed inputs and retain complete source-owner bodies and actual operation 03 evidence. Verify all stated byte counts and hashes; stop on a discrepancy.
2. Write counterfactual controls before the new receiver. Cover each strict bound and equality, multiple true terms, invalid scalars/paths/bounds, non-target exceptions and foreign same-message traceback frames. Controls must identify themselves as data/diagnostic controls; no product capture or original is invoked.
3. Add the narrow diagnostic and distinct operation identity. Verify that every old observer function except `observe` is byte/AST-equivalent, and that removing the exact wrapper plus the new helpers recovers the old observer after the branch substitution. Verify the workflow by the exact permitted substitutions and the map byte for byte.
4. Run the bounded local controls and the actual nonhost observer entry for the final candidate. The actual nonhost entry must refuse before any ordinary Git child. Static source/AST checks establish the pinned exception location and untouched capture owner; no hosted or complete-source capture is inferred from local controls. Retain development-control failures and superseded local refusal evidence when a concrete source-binding counterfactual requires a revision.
5. Read only the already present parent commit/tree using Git with `GIT_NO_LAZY_FETCH=1`, disabled protocols, replacement objects and optional locks. Do not fetch missing historical objects. Derive the exact three-addition tree in memory, retain its full file/mode/blob map, and bind all fourteen full owner bodies to the parent tree.
6. Freeze the complete packet with byte/SHA256/Git-blob inventory, controls and actual-refusal records, exact source delta, publication proposal, proof of unchanged owners, and limitations. Root obtains independent source review before making any separate publication decision.

Acceptance is a reviewable diagnostic candidate and honest local evidence. It is not recovery of the actual hosted operands until a separately authorized, distinct ordinary operation genuinely throws and retains them. Positive scalar controls and rejection of counterfeit tracebacks do not establish that future hosted capture will fail at the same line. No broad package suite, historical recovery, private-input selection, launcher provisioning, or automatic replay is in this task.

Rollback: abandon this uncommitted, unpublished candidate. The parent, prior helper, evidence, product files, refs, and controller are not mutated by this work.
