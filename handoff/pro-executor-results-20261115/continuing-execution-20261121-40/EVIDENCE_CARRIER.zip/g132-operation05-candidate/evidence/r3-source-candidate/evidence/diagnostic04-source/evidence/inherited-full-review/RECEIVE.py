#!/usr/bin/env python3
"""Read-only G132 packet/tree receiving; no reviewed module is imported."""
import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import yaml

PACKET = Path('/workspace/scratch/097486cde2dd/g132-qualification/frozen-packet')
REPO = Path('/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b')
ROOT_PLAN = Path('/workspace/scratch/097486cde2dd/g132-publication/PLAN.json')
COMMIT = 'f75533f95f0d099c87e7a04beb11b0a25628acdc'
TREE = '9b9c2b3f1453b83b87b628b665fceff492bf5b1e'
PARENT = 'e76a07b2bae7c945e5a9d529ed8cf9069f4c9064'
CANDIDATE_TREE = '84d5ae6574a26ca38b6598de1f4ca054b2adc3e5'
MANIFEST_SHA = '75435d932de544b9bfdef13ba74387b64e95804757727ee6711dfe266ffdc1e8'


def digest(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}


def receive(path, expected=None):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode), str(path)
    actual = digest(path.read_bytes())
    if expected:
        assert all(actual[k] == expected[k] for k in actual if k in expected), str(path)
    return {'path': str(path), **actual, 'physical_mode': oct(stat.S_IMODE(info.st_mode))}


def git(*args):
    env = {**os.environ, 'GIT_NO_LAZY_FETCH': '1', 'GIT_ALLOW_PROTOCOL': ''}
    return subprocess.run(['git', '-c', 'protocol.allow=never', *args], cwd=REPO,
                          env=env, capture_output=True, check=True, timeout=30).stdout


def tree_hash(rows):
    root = {}
    for path, row in rows.items():
        current = root
        parts = path.split('/')
        assert all(part not in ('', '.', '..') for part in parts)
        for part in parts[:-1]:
            current = current.setdefault(part, {})
        assert parts[-1] not in current
        current[parts[-1]] = (row['mode'], row['git_blob'])
    def visit(directory):
        body = b''
        for name, value in sorted(directory.items(), key=lambda pair: pair[0].encode() +
                                  (b'/' if isinstance(pair[1], dict) else b'')):
            mode, oid = ('40000', visit(value)) if isinstance(value, dict) else value
            body += mode.encode() + b' ' + name.encode() + b'\0' + bytes.fromhex(oid)
        return hashlib.sha1(b'tree ' + str(len(body)).encode() + b'\0' + body).hexdigest()
    return visit(root)


manifest_row = receive(PACKET / 'PACKET_MANIFEST.json')
assert manifest_row['bytes'] == 8488 and manifest_row['sha256'] == MANIFEST_SHA
manifest = json.loads((PACKET / 'PACKET_MANIFEST.json').read_bytes())
members = [receive(PACKET / row['path'], row) for row in manifest['files']]
assert len(members) == 32 and sum(row['bytes'] for row in members) == 2055057
assert sorted(str(p.relative_to(PACKET)) for p in PACKET.rglob('*') if p.is_file()) == sorted(
    [row['path'] for row in manifest['files']] + ['PACKET_MANIFEST.json'])
assert git('show', '-s', '--format=%H%n%T%n%P', COMMIT).decode().splitlines() == [COMMIT, TREE, PARENT]

entries = {}
for line in git('ls-tree', '-rlz', COMMIT).split(b'\0'):
    if not line:
        continue
    metadata, path = line.split(b'\t', 1)
    mode, kind, oid, size = metadata.decode().split()
    assert kind == 'blob' and mode in ('100644', '100755')
    entries[path.decode()] = {'mode': mode, 'git_blob': oid, 'bytes': int(size)}
receipt = json.loads((PACKET / 'EXACT_CHECKOUT_RECEIPT.json').read_bytes())
assert entries == {r['path']: {k: r[k] for k in ('mode', 'git_blob', 'bytes')} for r in receipt['entries']}
assert len(entries) == 1768 and sum(r['bytes'] for r in entries.values()) == 167143205
assert tree_hash(entries) == TREE
plan = json.loads((PACKET / 'CANDIDATE_PUBLICATION_PLAN.json').read_bytes())
new = dict(entries)
for row in plan['files']:
    assert row['path'] not in new and row['change'] == 'ADD' and row['mode'] == '100644'
    receive(PACKET / 'candidate' / row['path'], row)
    new[row['path']] = {k: row[k] for k in ('mode', 'git_blob', 'bytes')}
assert tree_hash(new) == CANDIDATE_TREE == plan['prospective_tree']
assert len(new) == 1771 and sum(r['bytes'] for r in new.values()) == 167162864
assert git('diff', '--name-status', TREE, CANDIDATE_TREE).decode().splitlines() == [
    'A\t' + r['path'] for r in plan['files']]
assert git('diff', '--check', TREE, CANDIDATE_TREE) == b''
for row in plan['files']:
    assert git('show', CANDIDATE_TREE + ':' + row['path']) == (PACKET / 'candidate' / row['path']).read_bytes()
root_plan = json.loads(ROOT_PLAN.read_bytes())
assert root_plan['base_commit'] == COMMIT and root_plan['base_tree'] == TREE and root_plan['expected_tree'] == CANDIDATE_TREE

inherited = []
for path in sorted((PACKET / 'inherited-source').rglob('*')):
    if not path.is_file():
        continue
    relative = path.relative_to(PACKET / 'inherited-source').as_posix()
    raw = git('show', COMMIT + ':' + relative)
    assert raw == path.read_bytes()
    inherited.append({'path': relative, **digest(raw)})
assert len(inherited) == 14
engine_map = json.loads((PACKET / 'candidate/engineering/g132-engine-source-diagnostic/ENGINE_MAP.json').read_bytes())
loading = json.loads((PACKET / 'ENGINE_LOADING_RESULT.json').read_bytes())
assert loading['status'] == 'LOADED_LOCAL_SOURCE_ONLY' and loading['engine_loaded'] is True
assert loading['source_members'] == len(loading['source_map']) == len(engine_map) == 13
assert loading['setup_actual_loading'] and loading['setup_captured_source_map_equal'] and loading['source_currentness_after']
assert loading['forbidden_events'] == [] and not loading['original_execution'] and not loading['session_constructed']
assert loading['source_commit'] == COMMIT and loading['source_tree'] == TREE
for row in loading['source_map']:
    assert engine_map[row['logical_path']] == {k: row[k] for k in ('bytes', 'sha256')}
    receive(PACKET / 'inherited-source' / row['physical_path'], row)

local = json.loads((PACKET / 'LOCAL_CHECKOUT_OBSERVATION.json').read_bytes())
state = local['state']
state_sha = hashlib.sha256(json.dumps(state, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
assert state_sha == local['complete_source_capture']['state_sha256']
assert len(state['files']) == 1790 and len(state['directories']) == 441
assert sum(row['bytes'] for row in state['files'].values()) == 199391342
for row in receipt['entries']:
    actual = state['files'][row['path']]
    assert all(actual[k] == row[k] for k in ('bytes', 'sha256'))
    assert actual['mode'] == int(row['mode'], 8) & 0o777
assert local['status'] == 'LOCAL_CAPTURE_COMPLETE_QUALIFICATION_REFUSED'
assert {k: v['status'] for k, v in local['gates'].items()} == {
    'captured_head_identity': 'REFUSED', 'git_namespace': 'REFUSED', 'producer_contract': 'PASS'}

syntax = []
for path in sorted(PACKET.rglob('*.py')):
    ast.parse(path.read_bytes())
    syntax.append(path.relative_to(PACKET).as_posix())
workflow_path = 'candidate/.github/workflows/dg16-g132-engine-source-observe.yml'
workflow = json.loads((PACKET / workflow_path).read_bytes())
assert list(workflow['on']) == ['push'] and workflow['on']['push']['branches'] == [
    'pro/dg16-g132-engine-source-observe-20261121-01']
assert workflow['permissions'] == {'contents': 'read'} and workflow['concurrency']['cancel-in-progress'] is False
assert list(workflow['jobs']) == ['observe']
job = workflow['jobs']['observe']
assert job['runs-on'] == 'ubuntu-24.04' and job['timeout-minutes'] == 8
assert job['env']['EXPECTED_OBSERVER_SHA256'] == digest((PACKET / 'candidate/engineering/g132-engine-source-diagnostic/observe.py').read_bytes())['sha256']
assert int(job['env']['EXPECTED_MAP_BYTES']) == 2083
assert job['steps'][1]['timeout-minutes'] == 6
assert job['steps'][0]['uses'] == 'actions/checkout@11d5960a326750d5838078e36cf38b85af677262'
assert job['steps'][2]['uses'] == 'actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02'
assert job['steps'][2]['if'] == 'always()'
workflow_sources = []
for path in entries:
    if path.startswith('.github/workflows/'):
        raw = git('show', COMMIT + ':' + path)
        value = yaml.load(raw, Loader=yaml.BaseLoader)
        assert value['on']['push']['branches'] == ['main']
        workflow_sources.append({'path': path, **digest(raw), 'on': value['on']})
assert len(workflow_sources) == 2
validation = json.loads((PACKET / 'DIAGNOSTIC_VALIDATION.json').read_bytes())
assert [r['returncode'] for r in validation['records']] == [0, 0, 2]
refusal = json.loads((PACKET / 'ACTUAL_NONHOST_REFUSAL.json').read_bytes())
assert refusal['status'] == 'REFUSED' and refusal['failed_phase'] == 'context' and refusal['ordinary_git_children'] == []
assert json.loads(validation['records'][2]['stdout']) == refusal

result = {
    'schema': 'g132.ordinary-independent-source-receiving.v1',
    'reviewer': '/root/independent_review', 'source_author': '/root/g132_qualification',
    'authority': 'NONE', 'formal_audit_assess_activation': False,
    'completed_at': datetime.now(timezone.utc).isoformat(), 'status': 'PASS_SOURCE_RECEIVING_ONLY',
    'packet_manifest': manifest_row, 'packet_members': members, 'member_count': 32, 'member_bytes': 2055057,
    'source_commit': COMMIT, 'source_tree': TREE, 'source_parent': PARENT,
    'base_entries_compared_to_actual_git_tree': 1768, 'base_tracked_bytes': 167143205,
    'base_tree_reconstructed_without_writes': TREE, 'candidate_tree_reconstructed_without_writes': CANDIDATE_TREE,
    'candidate_files': plan['files'], 'candidate_total_files': 1771, 'candidate_total_bytes': 167162864,
    'actual_tree_readback': CANDIDATE_TREE, 'diff_check_exit': 0, 'root_plan': receive(ROOT_PLAN),
    'inherited_source_bodies_received': inherited, 'engine_map_received': engine_map,
    'historical_actual_engine_loading_received': {
        'status': loading['status'], 'direct_load': loading['engine_loaded'],
        'setup_load': loading['setup_actual_loading'], 'map_equal': loading['setup_captured_source_map_equal'],
        'process': loading['process'], 'source_members': 13, 'forbidden_events': []},
    'historical_local_complete_capture_received': {
        'state_sha256': state_sha, 'files': 1790, 'directories': 441, 'actual_file_bytes': 199391342,
        'tracked_subset_matches_manifest': True, 'status': local['status'],
        'gates': {k: {'status': v['status'], 'reason': v.get('reason')} for k, v in local['gates'].items()}},
    'syntax_parsed_not_executed': syntax, 'inherited_workflows': workflow_sources,
    'existing_control_receiving': {'records_exit_statuses': [0, 0, 2], 'seven_tests_retained': True,
                                  'actual_nonhost_refusal_received': True, 'controls_reexecuted': False},
    'reviewer_hosted_executions': 0, 'reviewer_original_executions': 0, 'reviewer_product_imports': 0,
    'provider_writes': 0, 'source_mutations': 0, 'ref_updates': 0, 'history_recovery_attempts': 0,
    'findings': [{'id': 'G132-SR-L1', 'severity': 'LOW', 'kind': 'inherited exceptional-path limit',
                  'source': 'scripts/qualify-work-graph-c5-setup.py:204-248',
                  'summary': 'Detected post-reap descendant group persistence refuses but is not actively terminated',
                  'survivor_observed': False, 'false_success_allowed': False}],
    'limits': [
        'Root owns exact first publication/currentness and sole diagnostic-parent admission',
        'Attempt 1 is checked; fresh branch creation is not independently enforced by observer event parsing',
        'Packed HEAD remains a valid refusal under the unchanged loose-object guard',
        'Complete capture bounds are not a pre-clone aggregate disk quota',
        'Hosted receipt retains capture summary/state digest, not full state/object bytes',
        'Native and original admission remain UNQUALIFIED; no original grant or closure'
    ]
}
print(json.dumps(result, sort_keys=True, indent=2))
