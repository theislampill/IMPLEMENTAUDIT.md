#!/usr/bin/python3
"""Local static derivation. Does not import product, run capture, or write Git."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parent
OLD=ROOT/'evidence/operation03/candidate/candidate'
NEW=ROOT/'candidate'
PARENT='f75533f95f0d099c87e7a04beb11b0a25628acdc'
PARENT_TREE='9b9c2b3f1453b83b87b628b665fceff492bf5b1e'
GRANDPARENT='e76a07b2bae7c945e5a9d529ed8cf9069f4c9064'
BRANCH='pro/dg16-g132-engine-source-observe-20261121-04'
OPERATION='G132_ENGINE_SOURCE_OBSERVE_20261121_04_CAPTURE_BOUND'
OWNER='engineering/g132-engine-source-diagnostic/observe.py'
MAP='engineering/g132-engine-source-diagnostic/ENGINE_MAP.json'
WORKFLOW='.github/workflows/dg16-g132-engine-source-observe.yml'
checks=[]
def check(name,value):
    checks.append(dict(name=name,passed=bool(value)))
    if not value:raise AssertionError(name)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git_hash(kind,raw):
    return hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def write(name,value):
    (ROOT/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')

# Receive every retained immutable input from its complete included manifest.
inputs=json.loads((ROOT/'INPUT_RECEIVING.json').read_bytes())
for entry in inputs['receipts']:
    directory=ROOT/entry['destination']
    manifest_raw=(directory/entry['manifest']).read_bytes()
    check('input seal '+entry['destination'],len(manifest_raw)==entry['manifest_bytes']
          and sha(manifest_raw)==entry['manifest_sha256'])
    manifest=json.loads(manifest_raw)
    expected={entry['manifest']}
    for row in manifest['files']:
        name=row['path'];expected.add(name)
        raw=(directory/name).read_bytes()
        check('input bytes '+entry['destination']+'/'+name,
              len(raw)==row['bytes'] and sha(raw)==row['sha256']
              and ('git_blob' not in row or git_hash('blob',raw)==row['git_blob']))
    actual={str(p.relative_to(directory)) for p in directory.rglob('*') if p.is_file()}
    check('complete input inventory '+entry['destination'],actual==expected)

raw03=ROOT/'evidence/operation03/raw'
for left,right in [
    ('evidence/operation03/source-review/SEAL.json','evidence/operation03/raw/SOURCE_REVIEW_SEAL.json'),
    ('evidence/operation03/candidate/SEAL.json','evidence/operation03/raw/SOURCE_CANDIDATE_SEAL.json'),
    ('evidence/inherited-full-source/PACKET_MANIFEST.json','evidence/operation03/raw/INHERITED_PACKET_MANIFEST.json'),
    ('evidence/inherited-full-review/SEAL.json','evidence/operation03/candidate/evidence/INHERITED_FULL_REVIEW_SEAL.json')]:
    check('retained input cross-binding '+left,(ROOT/left).read_bytes()==(ROOT/right).read_bytes())
with zipfile.ZipFile(raw03/'PROVIDER_ARTIFACT.zip') as archive:
    check('actual archive has exact four members',set(archive.namelist())=={
        'OBSERVATION.json','STDERR.raw','RETURN.json','NATIVE_EXIT_STATUS.raw'}
        and len(archive.namelist())==4)
    for name in archive.namelist():
        check('actual archive member bound '+name,archive.getinfo(name).file_size<=2097152)
        check('actual archive member equals retained bytes '+name,archive.read(name)==(raw03/name).read_bytes())
actual03=json.loads((raw03/'OBSERVATION.json').read_bytes())
map03=json.loads((NEW/MAP).read_bytes())
check('actual prior failure retained',actual03['status']=='REFUSED'
      and actual03['failed_phase']=='complete_actual_source_capture'
      and actual03['exception_type']=='ValueError'
      and actual03['reason']=='source input byte/entry bound exceeded'
      and (raw03/'NATIVE_EXIT_STATUS.raw').read_bytes()==b'2\n')
check('both actual prior thirteen-member maps',len(map03)==13
      and actual03['engine_map']==actual03['actual_checkout_engine_map']==map03)
check('all seventeen actual prior Git rows match',len(actual03['selected_git_file_rows'])==17
      and all(x['match'] is True for x in actual03['selected_git_file_rows'])
      and actual03['gates']['unchanged_git_input_validator']['status']=='PASS')
preparation=actual03['source_preparation']
check('eleven successful actual prior source commands',len(preparation['commands'])==11
      and all(x['returncode']==0 and x['command_received'] and x['descriptor_restoration']
              and x['owned_group_absent'] and x['wait_reaped'] for x in preparation['commands']))
check('actual prior exact complete source tuple',preparation['source_commit']==PARENT
      and preparation['source_tree']==PARENT_TREE and preparation['ordered_parents']==[GRANDPARENT]
      and preparation['clean'] and preparation['complete_objects'])
check('prior exact capture operands remain unavailable',
      'source_capture' not in actual03 and 'capture_bound_diagnostic' not in actual03
      and preparation['object_rows']==29463)

old=(OLD/OWNER).read_text();new=(NEW/OWNER).read_text()
old_ast=ast.parse(old);new_ast=ast.parse(new)
old_funcs={x.name:x for x in old_ast.body if isinstance(x,ast.FunctionDef)}
new_funcs={x.name:x for x in new_ast.body if isinstance(x,ast.FunctionDef)}
check('only two new observer functions',set(new_funcs)-set(old_funcs)=={
    'capture_bound_values','capture_bound_diagnostic'})
for name,node in old_funcs.items():
    if name!='observe':
        check('unchanged observer function '+name,ast.dump(node)==ast.dump(new_funcs[name]))

wrapper='''        try:
            captured=actual.B.complete_source(actual_source,objects)
        except BaseException as capture_exc:
            try:
                result['capture_bound_diagnostic']=capture_bound_diagnostic(capture_exc,actual,actual_source)
            except BaseException as diagnostic_exc:
                result['capture_bound_diagnostic']=dict(status='UNAVAILABLE',exception_type=type(diagnostic_exc).__name__)
            raise
'''
check('exact failure-only wrapper occurs once',new.count(wrapper)==1)
restored=new.replace(wrapper,'        captured=actual.B.complete_source(actual_source,objects)\n')
start=restored.index('def capture_bound_values(')
end=restored.index('def observe():',start)
restored=restored[:start]+restored[end:]
constant_lines=[line for line in restored.splitlines(keepends=True) if line.startswith('CAPTURE_')]
check('exact four new diagnostic constants',len(constant_lines)==4)
restored=''.join(line for line in restored.splitlines(keepends=True) if not line.startswith('CAPTURE_'))
restored=restored.replace("BRANCH='"+BRANCH+"'", "BRANCH='pro/dg16-g132-engine-source-observe-20261121-03'")
check('full observer restored byte-for-byte after declared delta',restored==old)

receiver=new_funcs['capture_bound_diagnostic']
local_reads=[]
for node in ast.walk(receiver):
    if isinstance(node,ast.Attribute) and node.attr=='f_locals':
        users=[x for x in ast.walk(receiver) if isinstance(x,ast.Subscript) and x.value is node]
        check('every locals access is a literal single-key subscript',len(users)==1
              and isinstance(users[0].slice,ast.Constant) and type(users[0].slice.value) is str)
        local_reads.append(users[0].slice.value)
check('exact frame-local whitelist',set(local_reads)=={
    'bounds','excluded','root','count','total','before','depth','name'})
for name in ('capture_bound_values','capture_bound_diagnostic'):
    calls=[x for x in ast.walk(new_funcs[name]) if isinstance(x,ast.Call)]
    check('new function has no product or filesystem execution '+name,
          all(not (isinstance(x.func,ast.Name) and x.func.id in
                   {'exec','eval','open','vars','repr','dir','getattr','setattr'})
              and not (isinstance(x.func,ast.Attribute) and x.func.attr in
                       {'complete_source','snapshot_tree','CHECK','read_bytes','read_text',
                        'stat','lstat','scandir','walk','settrace','setprofile'}) for x in calls))
compile_calls=[x for x in ast.walk(receiver) if isinstance(x,ast.Call)
               and isinstance(x.func,ast.Name) and x.func.id=='compile']
check('one compile-only comparison of the pinned held source',len(compile_calls)==1
      and [ast.dump(x) for x in compile_calls[0].args]==[
          ast.dump(ast.Name(id='source',ctx=ast.Load())),
          ast.dump(ast.Name(id='filename',ctx=ast.Load())),ast.dump(ast.Constant(value='exec'))]
      and len(compile_calls[0].keywords)==1 and compile_calls[0].keywords[0].arg=='dont_inherit'
      and isinstance(compile_calls[0].keywords[0].value,ast.Constant)
      and compile_calls[0].keywords[0].value.value is True)
check('no extra imports',
      [ast.dump(x) for x in old_ast.body if isinstance(x,(ast.Import,ast.ImportFrom))]==
      [ast.dump(x) for x in new_ast.body if isinstance(x,(ast.Import,ast.ImportFrom))])

old_workflow=(OLD/WORKFLOW).read_text();new_workflow=(NEW/WORKFLOW).read_text()
expected_workflow=old_workflow.replace('engine-source-observe-20261121-03',
                                     'engine-source-observe-20261121-04').replace(
    sha(old.encode()),sha(new.encode()))
check('workflow changes only distinct operation and selfhash',new_workflow==expected_workflow)
check('map byte-identical', (OLD/MAP).read_bytes()==(NEW/MAP).read_bytes())
workflow=json.loads(new_workflow)
shell=workflow['jobs']['observe']['steps'][1]['run'].encode()
proc=subprocess.run(['/usr/bin/bash','-n'],input=shell,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
check('workflow shell syntax',proc.returncode==0)
write('BASH_SYNTAX.json',dict(argv=['/usr/bin/bash','-n'],exit=proc.returncode,
    stdin_bytes=len(shell),stdin_sha256=sha(shell),stdout_bytes=len(proc.stdout),
    stdout_sha256=sha(proc.stdout),stderr_bytes=len(proc.stderr),stderr_sha256=sha(proc.stderr)))
(ROOT/'BASH_SYNTAX_STDOUT.raw').write_bytes(proc.stdout)
(ROOT/'BASH_SYNTAX_STDERR.raw').write_bytes(proc.stderr)

commit=(ROOT/'PARENT_COMMIT.raw').read_bytes()
check('authenticated exact parent commit',git_hash('commit',commit)==PARENT)
headers=commit.split(b'\n\n',1)[0].splitlines()
check('exact parent tree and sole parent',
      [x for x in headers if x.startswith(b'tree ')]==[b'tree '+PARENT_TREE.encode()]
      and [x for x in headers if x.startswith(b'parent ')]==[b'parent '+GRANDPARENT.encode()])
flat={}
for row in (ROOT/'PARENT_TREE.raw').read_bytes().split(b'\0'):
    if not row:continue
    meta,path=row.split(b'\t',1);mode,kind,oid=meta.split()
    check('unique parent path '+path.decode(),path not in flat)
    flat[path]=(mode,kind,oid)
check('parent file population',len(flat)==1768)
def derive_tree(rows):
    root={}
    for path,value in rows.items():
        parts=path.split(b'/');node=root
        for part in parts[:-1]:node=node.setdefault(part,{})
        node[parts[-1]]=value
    def digest(node):
        entries=[]
        for name,value in node.items():
            if isinstance(value,dict):
                mode,kind,oid=b'40000',b'tree',digest(value).encode();key=name+b'/'
            else:mode,kind,oid=value;key=name
            entries.append((key,mode+b' '+name+b'\0'+bytes.fromhex(oid.decode())))
        return git_hash('tree',b''.join(value for _,value in sorted(entries)))
    return digest(root)
check('independently recomputed parent tree',derive_tree(flat)==PARENT_TREE)
new_flat=dict(flat);entries=[]
for name in (WORKFLOW,OWNER,MAP):
    raw=(NEW/name).read_bytes()
    check('new path absent from parent '+name,name.encode() not in flat)
    row=dict(path=name,local_path=str(NEW/name),mode='100644',bytes=len(raw),
             sha256=sha(raw),git_blob=git_hash('blob',raw))
    entries.append(row)
    new_flat[name.encode()]=(b'100644',b'blob',row['git_blob'].encode())
tree=derive_tree(new_flat)
check('only three new files',len(new_flat)==1771 and set(new_flat)-set(flat)=={
    WORKFLOW.encode(),OWNER.encode(),MAP.encode()})
check('all existing file modes and blobs unchanged',all(new_flat[k]==v for k,v in flat.items()))
inherited=ROOT/'evidence/inherited-full-source'
manifest=json.loads((inherited/'PACKET_MANIFEST.json').read_bytes())
owner_proofs=[]
for row in manifest['files']:
    if not row['path'].startswith('inherited-source/'):continue
    relative=row['path'][len('inherited-source/'):]
    raw=(inherited/row['path']).read_bytes()
    check('full inherited owner bound to parent '+relative,
          flat[relative.encode()][1]==b'blob' and flat[relative.encode()][2].decode()==git_hash('blob',raw))
    owner_proofs.append(dict(path=relative,bytes=len(raw),sha256=sha(raw),git_blob=git_hash('blob',raw),
                            parent_mode=flat[relative.encode()][0].decode(),unchanged=True))
check('all fourteen full owner bodies retained',len(owner_proofs)==14)
write('FULL_OWNER_PROOFS.json',dict(parent=PARENT,parent_tree=PARENT_TREE,owners=owner_proofs))
expected_raw=b''.join(mode+b' '+kind+b' '+oid+b'\t'+path+b'\0'
    for path,(mode,kind,oid) in sorted(new_flat.items()))
(ROOT/'EXPECTED_TREE.raw').write_bytes(expected_raw)
write('PUBLICATION_PLAN.json',dict(operation=OPERATION,branch=BRANCH,base_commit=PARENT,
    base_tree=PARENT_TREE,source_parent=GRANDPARENT,expected_tree=tree,entries=entries,
    parent_file_population=len(flat),expected_file_population=len(new_flat),
    diff_name_status=''.join('A\t'+name+'\n' for name in sorted((WORKFLOW,OWNER,MAP))),
    git_objects_written=0,index_writes=0,ref_writes=0,provider_writes=0,
    protected_grant='UNISSUED',original_awards=[]))
write('PUBLICATION_ENTRIES.json',[dict(path=x['path'],mode=x['mode'],type='blob',
    content=(NEW/x['path']).read_text()) for x in entries])
patch=''
for name in (WORKFLOW,OWNER,MAP):
    patch+=''.join(difflib.unified_diff((OLD/name).read_text().splitlines(keepends=True),
         (NEW/name).read_text().splitlines(keepends=True),fromfile='operation03/'+name,tofile='operation04/'+name))
(ROOT/'SOURCE_DELTA.patch').write_text(patch)
check('no trailing whitespace in candidate additions',all(
    line.rstrip(b' \t')==line for name in (WORKFLOW,OWNER,MAP)
    for line in (NEW/name).read_bytes().splitlines()))
write('STRUCTURAL_VALIDATION.json',dict(status='PASS_STATIC_SOURCE_ONLY',operation=OPERATION,
    checks=checks,check_count=len(checks),all_checks_passed=all(x['passed'] for x in checks),
    expected_tree=tree,full_owner_count=len(owner_proofs),frame_local_whitelist=sorted(set(local_reads)),
    new_product_imports=0,new_product_capture_calls=0,new_hosted_operations=0,new_original_executions=0,
    git_objects_written=0,ref_writes=0,provider_reads=0,provider_writes=0,
    authentic_positive_traceback_observed=False,authority='NONE'))
print(json.dumps(dict(status='PASS_STATIC_SOURCE_ONLY',checks=len(checks),expected_tree=tree,
                     publication_entries=entries),indent=2))
