import json
from pathlib import Path
import tempfile
import types
import unittest

ROOT=Path(__file__).resolve().parent
OWNER=ROOT/'candidate/scripts/qualify-work-graph-c5-setup.py'
class MissingRepairControls(unittest.TestCase):
    def setUp(self):
        self.module=types.ModuleType('ordinary_setup_control')
        self.module.__file__=str(OWNER)
        exec(compile(OWNER.read_bytes(),str(OWNER),'exec'),self.module.__dict__)
    def test_selected_parent_route_exists(self):
        self.assertTrue(hasattr(self.module,'prepare_hosted_source_selected_v3'),
                        'explicit complete selected-parent preparation route is absent')
    def test_success_keeps_exit_waitable_until_group_cleanup(self):
        records=[]
        with tempfile.TemporaryDirectory(prefix='red-git-custody-',dir=ROOT) as directory:
            output=self.module.hosted_git(['--version'],directory,records)
        (ROOT/'RED_ACTUAL_GIT_RECORD.json').write_text(json.dumps(records,indent=2)+'\n')
        self.assertIn(b'git version',output)
        self.assertIsNotNone(records[0].get('exit_observed_without_reap'),
                             'normal command has no WNOWAIT exit observation')

if __name__=='__main__':unittest.main(verbosity=2)
