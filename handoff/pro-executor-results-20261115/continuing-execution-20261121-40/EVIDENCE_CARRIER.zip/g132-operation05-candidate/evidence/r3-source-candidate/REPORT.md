# G132 prospective source preparation and process custody R3

## Disposition

This packet contains a concrete one-file source proposal, complete source proofs, retained historical failure evidence, and successful bounded ordinary local qualification. It is ready for independent review as source evidence. It does not authorize integration, publication, a hosted operation, an original execution, or any closure award.

Root remains the only provider/integration writer. After this child's context boundary, Root freshly verified G0045 receipt `refs/implementaudit/continuity-receipts/dg16-dg18-recovery-20261119-b/G0045@da78b456997516f38e8e8b048c221bec6e4c0c4b` with `9be00b/0` and confirmed bounded continuation. This author made no controller call, provider call, network Git operation, original/protected execution, existing-repository object/index/ref write, or change to an older frozen packet. Ordinary fixture repositories and owned local child processes were created under the explicitly authorized isolated qualification root.

## Exact proposed source

| Property | Exact value |
| --- | --- |
| Base commit | `f75533f95f0d099c87e7a04beb11b0a25628acdc` |
| Base tree | `9b9c2b3f1453b83b87b628b665fceff492bf5b1e` |
| Base sole parent | `e76a07b2bae7c945e5a9d529ed8cf9069f4c9064` |
| Changed path | `scripts/qualify-work-graph-c5-setup.py` |
| Preserved Git mode | `100755` |
| Candidate bytes | 90,827 |
| Candidate SHA-256 | `7ee5f2282d650692db140629ce436d6502ac0cf4f97786ed8c879192b603e9b0` |
| Candidate Git blob | `515ecf98f5db25454dd8ddf8e61a134264a65458` |
| Expected complete source tree | `f85b199c89e9f6938382ec5f7b2005f54acc8536` |
| Complete file population | 1,768, with exactly one modified blob |
| Prospective source branch | `pro/dg16-g132-source-custody-r3-20261122-01`, not created |
| Future source commit | Unknown until Root publishes and reads it back |
| Required future source parent | `f75533f95f0d099c87e7a04beb11b0a25628acdc` |

`PUBLICATION_PLAN.json`, `PUBLICATION_ENTRIES.json`, `EXPECTED_TREE.raw`, and `SOURCE_DELTA.patch` describe the exact source change. The tree was derived in memory from the complete authenticated base commit and 1,768-entry base tree map. No Git objects or refs were written for that derivation.

The full-file restoration proof replaces only the changed `hosted_git` body and removes only the newly added `prepare_hosted_source_selected_v3`; the resulting bytes equal the original 83,152-byte setup owner exactly. All 42 other existing setup function bodies are byte-identical, including legacy `prepare_hosted_source`, `hosted_current_owner`, the loader dispatch and all pins. Fourteen complete inherited physical source bodies remain included and hash-bound to the exact base tree. All thirteen Engine members and their logical-to-physical bindings remain unchanged.

## Evidence motivating the change

Actual diagnostic04 run `44963085468`, attempt 1, hosted commit `5f0dce5e1756be3d9bf964d83de45587749a31a4`, passed its initial thirteen-member Engine, Git08ca body, all seventeen selected Git rows, and unchanged Git-input validator. Its first clone returned 128 with `fatal: fetch-pack: invalid index-pack output` after approximately 10.193 seconds. Timeout and overflow were false; direct-child reaping was true; group absence was false. The actual capture and its operand receiver were never reached.

The raw packet, independent receiving, Root adjudication, and previous source/review packets are included in full under `evidence/`. The raw seal remains `0dd20543c17f70593bd024afcdd7f07e827eae1d5422ed94fc6f480c4cf9a4bb`; the independent receiving seal remains `e7b1216bc6fe773f557dcbeb0b7d49ca76d0baccb8ed5c16ca96a5b32b75d837`. Root reported that results38 were subsequently published at `56f00601d9d6e3083a35014b53610541008f7af5`; this child did not perform that publication.

The exact index-pack cause and historical group membership/aliveness/zombie state remain unproved. Operation03's capture-bound disjunct and operands remain unproved. Operations03/04 and original `44888568054` remain terminal; this work does not replay them.

## Change 1: retain wait custody until group cleanup

The old helper could reap a normally exited direct child and then discover that its group still existed. Sending a later destructive signal to that reusable numerical PGID would not establish ownership. The proposed helper observes direct-child exit through `waitid(P_PID, ..., WEXITED | WNOHANG | WNOWAIT)`, retaining the child as waitable. It checks default SIGCHLD disposition before spawning and records the authentic observed pid, uid, exit kind, and status.

During cleanup, a fresh non-reaping observation establishes that the direct child is still owned. Only then does the helper signal its original session/group. Actual `waitpid(..., WNOHANG)` reaping follows under the existing five-second cleanup bound. The true raw wait status and resulting return code are retained. After reap, the only group call is the existing zero-signal absence observation; there is no cleanup signal after reap.

The ordinary command still has a maximum 60-second wall bound, 4,194,304-byte bound for each stream, finite cleanup, bounded captured prefixes on overflow, exception propagation, actual child-reap evidence, pipe/selector closure, descriptor restoration, and group-absence refusal. The new receipt exposes the observed ordering and does not convert group-signal success into a group-absence claim. Timeout, overflow, nonzero status, uncertain custody, cleanup errors, remaining zombies, and unproved absence still refuse.

This is a bounded same-group contract with exclusive direct-child wait custody. It is not a universal descendant census. A descendant that changes session, or a noncooperating actor that reaps this child, is outside the qualified assumption. The product does not become a child subreaper. Test workers use that facility solely to contain and reap their own fixtures.

Python documents `WNOWAIT` as leaving a child waitable for a later wait; Linux documents the distinction between observing exit and releasing the waitable child. These API references support the ordering design, not the historical failure diagnosis: [Python os.waitid](https://docs.python.org/3.12/library/os.html#os.waitid), [Linux waitid](https://man7.org/linux/man-pages/man2/waitid.2.html).

## Change 2: explicitly receive the complete selected source

The new route requires a distinct exact commit and expected sole parent. It retains the existing fresh, owned, empty output-directory and no-alias/overlap checks. Its ten ordinary Git commands are:

1. Initialize a fresh SHA-1 repository with empty templates and a distinct unborn branch name.
2. Add the unchanged fixed public origin.
3. Fetch the complete exact parent into `refs/heads/g132-source-parent` using `--keep`, `--no-tags`, `--no-recurse-submodules`, and empty `--refmap=`.
4. Incrementally fetch the exact child with `fetch.unpackLimit=64` and the same scope controls.
5. Check out the exact child detached.
6. Read and require the exact commit, tree syntax, and supplied sole parent.
7. Require genuinely nonshallow storage.
8. Require a clean worktree, including untracked and ignored contents.
9. Run strict, full object checking.
10. Enumerate all retained objects with missing-object detection.

The final direct file check requires an actual regular, single-link loose HEAD object under the unchanged one-megabyte commit-object bound. There is no post-fetch object reshaping. The normal parent anchor stays present. The received parent pack, loose child objects, complete selected ancestry, metadata, and worktree all remain available to the unchanged full capture. The child threshold is finite acquisition behavior: if the child stays packed, this route refuses rather than manufacturing the required loose commit.

Git's exact-object refspec and empty-refmap semantics support selecting the requested full history without unrelated remote branches. `--keep` explicitly retains the downloaded pack; `fetch.unpackLimit` determines whether a sufficiently small newly received object set is stored loose. These commands use no depth, filter, partial/lazy clone, alternates, replacement objects, manual repack/unpack, or synthetic source objects. References: [Git fetch](https://git-scm.com/docs/git-fetch/2.43.0.html), [Git configuration](https://git-scm.com/docs/git-config/2.44.3.html), [Git init templates](https://git-scm.com/docs/git-init/2.43.0).

The selected source remains complete for its exact commit and full ancestry. No source path, source byte, original program selector, or object in that closure is omitted. The unchanged original clone behavior is not modified. A prospective observer must explicitly choose the new route; the legacy preparation body is retained.

## Actual bounded local qualification

The final self-contained run is `qualification/local-run-4i5puexs`. It executed the candidate with local Git 2.47.3 and passed all **124 checks**, with actual driver exit 0 and empty stderr (`ada147` followed by terminal `815992/0`). The static retained-input, function, source, and complete-tree proof passed **2,213 checks** (`c9f493/0`). Full command receipts and raw outputs are retained.

| Local control | Observed result |
| --- | --- |
| Normal Git command | Exit 0; WNOWAIT observation, group signal, actual reap, then absence observation; accepted |
| Nonzero command | True exit 7 retained; refused |
| Timeout and stream overflow | Finite refusal; actual direct child reaped; descriptors restored |
| Direct child exits while descendant closes pipes | Old helper left the controlled descendant running; new helper's controlled descendant was observed killed by SIGKILL before fixture cleanup, while the remaining zombie group correctly refused |
| Descendant holds pipes | Wall refusal and pre-reap group signal; group absence remained unproved. At immediate fixture observation the child was not yet observed exited, so the still-owned fixture was signaled and reaped by the worker |
| Outer BaseException | Original `ControlDeadline` preserved; owned cleanup attempted before reap |
| Missing working directory | No process handle; truthful creation refusal and descriptor restoration |
| SIGCHLD ignored | Refused before creating a child |
| Selected ancestry fixture | Ten successful actual Git receipts; full selected object set exactly matched, unrelated branch not acquired, parent genuinely packed, fresh child genuinely loose |
| Actual unchanged product capture | Loaded exact thirteen-member Engine from included source bodies; full fixture capture, Git namespace validation, and captured-HEAD owner succeeded |
| Ordinary clone controls | Two fresh local clones with unchanged original clone flags retained full selected ancestry and clean detached checkouts |
| Wrong expected parent | Refused at exact identity after six commands |
| Large genuine child delta | Ten commands completed; HEAD stayed packed and the loose-HEAD prerequisite refused |

The local transport control uses a separate function-global mapping with only the origin bound to a newly created local fixture. It shares the exact product function code object. It does not mutate the production function/module or fixed production URL. There are zero network Git calls. The actual capture operated on a small genuine local Git fixture, not the real repository or an original execution. The producer contract was inspected and preserved; the tiny fixture does not claim the original program-selector population.

The local captured identity was commit `651fc01e840fd1d1278688beedc8a0191e52b1f5`, tree `3e3d4255d07142ff61a2fed598fe4fb8cc72b3fd`, with genuine loose member `.git/objects/65/1fc01e840fd1d1278688beedc8a0191e52b1f5`. The unchanged capture included fourteen files and fourteen directories with projection `ALL_ACTUAL_BYTES_NO_GIT_OR_HIDDEN_OMISSIONS`. Its bounds remained entries 4,096; current file 134,217,728 bytes; total 268,435,456 bytes; depth 40.

Earlier qualification failures remain recorded: unavailable task-children procfs, colliding initial unborn/parent-anchor names, and the initial `fetch.unpackLimit=0` acquisition that left the parent loose. The latter ten-command receipt and failed packed-parent assertion were retained before switching to supported `--keep`. No expected consumer condition was weakened. `EVIDENCE_NOTES.json` also discloses that a focused green rerun overwrote an early red-named normal-command record before freezing; it was renamed accurately, and no missing earlier receipt is fabricated.

## Root handoff and remaining limits

Independent review should receive the complete top-level seal, validate every included byte, inspect the exact two-function delta and unchanged owner proofs, and assess the actual local receipts with the above limitations. The static verifier accepts `--output` so a reviewer can write fresh derivations outside the frozen packet; completed product controls need not be repeated to receive it.

If Root accepts the source proposal, publication must preserve the one-file tree and sole parent above. A later distinct observer must bind the **genuine newly published source commit**, expected tree `f85b199c89e9f6938382ec5f7b2005f54acc8536`, sole parent `f75533f95f0d099c87e7a04beb11b0a25628acdc`, and the changed setup byte/hash pin. It must explicitly call `prepare_hosted_source_selected_v3(root, output, SOURCE_COMMIT, SOURCE_PARENT, records=records)` and keep the authentic capture-exception receiver. This packet creates neither that observer nor a hosted branch/operation.

Hosted Git08ca behavior, actual complete-repository storage size, the earlier index-pack failure, and the earlier capture operands remain unqualified. The four existing library/cache mismatches, NSS files-only refusal, and missing bubblewrap remain unqualified. All source/security/audit/resource guards, false admission fields, private-input exclusions, historical terminal dispositions, and original/protected restrictions remain intact.

Suggested source commit message: `Fix ordinary Git child custody and add complete selected-source preparation`.

No award, native admission, overall admission, readiness promotion, or closure is claimed by this author.
