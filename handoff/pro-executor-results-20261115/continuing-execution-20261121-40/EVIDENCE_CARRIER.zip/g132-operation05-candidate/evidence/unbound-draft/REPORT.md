# Operation05 draft — source commit binding unavailable

This is a concrete, **nonexecutable draft**, not a frozen executable publication candidate. Root has not yet supplied the actual newly published R3 source commit. The helper contains `UNBOUND_R3_SOURCE_COMMIT_DO_NOT_EXECUTE` and refuses that value before setup import, context acceptance, resource-limit changes, or Git execution. `SOURCE_BINDING.json` records `readiness: false`. No final seal has been issued.

## Exact intended operation

Operation: `G132_ENGINE_SOURCE_OBSERVE_20261122_05_SELECTED_CUSTODY_R3`.
Branch: `pro/dg16-g132-engine-source-observe-20261122-05`, not created.
Expected genuine source tree: `f85b199c89e9f6938382ec5f7b2005f54acc8536`.
Expected genuine source sole parent: `f75533f95f0d099c87e7a04beb11b0a25628acdc`.
Actual source commit: **unbound**.

The exact R3 setup pin is 90,827 bytes, SHA-256 `7ee5f2282d650692db140629ce436d6502ac0cf4f97786ed8c879192b603e9b0`. The draft explicitly calls `prepare_hosted_source_selected_v3(root, output, SOURCE_COMMIT, SOURCE_PARENT, records=commands)`.

The complete frozen R3 source packet is included under `evidence/r3-source-candidate`, with seal SHA-256 `fd45ff497cadba67a4719ea9ab8018d3cd13b8f38b687de57634ac3c9403c176`. It contains all full physical source bodies, authenticated complete tree maps, previous observer packets, historical actual failures and R3's existing qualification. No R3 product/process controls were repeated for this observer task.

## Declared delta from the exact published04 observer

The observer changes the prospective source tuple, exact setup pin, distinct branch, descriptive Engine loading origin and selected-source preparation call. The workflow changes only its distinct name/branch/concurrency identity and the exact helper selfhash. Its single initial-push trigger, attempt1 restriction, absence of dispatch/retry, fixed runner/actions, resource limits, audit child ceiling and artifact handling remain intact. The Engine map is byte-identical.

One new pure metadata function describes pack files directly under `.git/objects/pack/` whose names end in `.pack`, using their already-captured path, byte count and SHA-256. It also reports pack count, total pack bytes and maximum captured regular-file bytes. It is called once, only after the existing single authentic full capture completes. It performs no source read, Git command, object reshaping, capture, product execution or admission decision.

All existing observer functions other than `observe` are byte-identical, including the finite context validator and both authentic exception-receiver functions. The complete old observer is restored byte-for-byte after removing the declared new metadata function, reverting the declared constants and the five explicit observe-body edits. The exact thirteen-member Engine map, all seventeen Git08ca selections, observed image versions 133/376, physical owners, source/resource/security/audit constraints, original false-admission fields, unchanged original exception re-raise, and single-capture behavior remain preserved.

## Actual draft verification

- **23 bounded data/context controls passed**, using counterfactual scalar/metadata fixtures and compile-only pinned source metadata. They do not execute an Engine, source acquisition, product snapshot, original, or hosted operation.
- **Actual local draft invocation exited 2**, specifically refusing the unbound source commit. It recorded zero Git children and zero provider imports; original execution and native admission remained false. Wrapper receipt: `117753/0`. Complete stdout/stderr/return metadata are retained under `evidence/unbound-draft/` together with the exact unbound helper and workflow bodies.
- **4,595 static checks passed**, receipt `dd8cff/0`: complete inherited byte receiving, exact declared delta/restoration, unchanged full source bodies/map, single authentic capture, metadata-only description, exact workflow syntax/trigger, and complete in-memory Git tree derivation.

The current unbound helper is 21,994 bytes, SHA-256 `d516e2f0a4b9cccbc46b2f5ba46f4fbd7263677e62c55154e26c43ebc7c0dc77`. Its current three-addition draft tree is `3ad29d7608ed8d359fb1095380e9ea9b84e61324`, containing all 1,768 source files unchanged plus the three observer files. **Both the helper hash and host tree will change when the genuine source commit is bound.** They are not executable publication identities.

The metadata controls verify exact pack selection, hashes, sorting, byte totals, a maximum larger than any pack, empty data, strict existing equality bounds, malformed/overbound metadata refusal, no I/O/product calls, and the actual R3 route/pin/resource constants. The inherited controls retain replay/old-branch/changed-image/nonroot/Git-pin/source-tuple refusal, non-admission, return-seal handling, strict capture-bound disjuncts and rejection of counterfeit traceback/code identities.

## Owner-supplied external comparisons

Root relayed Opus measurements of a 277,761,404-byte full-clone pack, compared with the unchanged 268,435,456-byte file-size limit, and selected history reportedly containing 13,961 reachable objects at approximately 35.9 MB. This author has no authentic measurement bytes or independently received measurement protocol. Those numbers are **unverified external comparisons**, with no assumed MB unit base. They are not acceptance conditions and do not establish operation04's exact index-pack cause or operation03's capture-bound disjunct.

The future actual observer will retain its genuine source object-row count and add actual post-capture storage metadata so Root can make an independent comparison after receiving the resulting evidence. Historical causes, hosted compatibility, original/protected execution, admission and closure remain unproved.

## Remaining binding step

Root must supply the genuine published R3 commit identity and local source-publication readback evidence. The author can then verify the exact tree/sole parent, bind the constant, update the helper selfhash/workflow, derive the final three-file host tree, qualify the exact bound static/context/refusal artifact and freeze it for independent review. No provider, controller, Git network or original action is authorized to this author.

Root G0045 receipt/currentness `9be00b/0` governs the bounded task. No branch, hosted operation, original, protected grant, source publication or award was created here. The previous source and operation packets remain unchanged.
