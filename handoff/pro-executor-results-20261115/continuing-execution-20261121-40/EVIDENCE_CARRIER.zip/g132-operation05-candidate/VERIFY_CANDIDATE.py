#!/usr/bin/python3
"""Static observer proof and complete prospective tree; no product execution."""
import argparse
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
INHERITED=ROOT/'evidence/r3-source-candidate'
OLD=INHERITED/'evidence/diagnostic04-source/candidate'
NEW=ROOT/'candidate'
OWNER='engineering/g132-engine-source-diagnostic/observe.py'
MAP='engineering/g132-engine-source-diagnostic/ENGINE_MAP.json'
WORKFLOW='.github/workflows/dg16-g132-engine-source-observe.yml'
SOURCE_TREE='f85b199c89e9f6938382ec5f7b2005f54acc8536'
SOURCE_PARENT='f75533f95f0d099c87e7a04beb11b0a25628acdc'
BRANCH='pro/dg16-g132-engine-source-observe-20261122-05'
OPERATION='G132_ENGINE_SOURCE_OBSERVE_20261122_05_SELECTED_CUSTODY_R3'
PLACEHOLDER='UNBOUND_R3_SOURCE_COMMIT_DO_NOT_EXECUTE'
PUBLISHED_SOURCE='760aaff5c478ff7354d36da186d62daba983aa49'
PUBLICATION_RECEIPT_SHA256='9e382f02755dba6ac39706ff32bd358129d2345c11dd1dc44fc9095ddbadbeef'

def sha(raw):return hashlib.sha256(raw).hexdigest()
def git_hash(kind,raw):return hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def tree_hash(rows):
    root={}
    for path,value in rows.items():
        parts=path.split(b'/');node=root
        for part in parts[:-1]:node=node.setdefault(part,{})
        node[parts[-1]]=value
    def digest(node):
        entries=[]
        for name,value in node.items():
            if isinstance(value,dict):mode,kind,oid=b'40000',b'tree',digest(value).encode();key=name+b'/'
            else:mode,kind,oid=value;key=name
            entries.append((key,mode+b' '+name+b'\0'+bytes.fromhex(oid.decode())))
        return git_hash('tree',b''.join(value for _,value in sorted(entries)))
    return digest(root)

def verify(output):
    checks=[]
    def check(name,value):
        checks.append(dict(name=name,passed=bool(value)))
        if not value:raise AssertionError(name)
    def save(name,value):(output/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
    inputs=json.loads((ROOT/'INPUT_RECEIVING.json').read_bytes())
    for receipt in inputs['receipts']:
        directory=ROOT/receipt['destination'];raw=(directory/'SEAL.json').read_bytes()
        check('inherited exact seal',len(raw)==receipt['seal_bytes'] and sha(raw)==receipt['seal_sha256'])
        seal=json.loads(raw);expected={'SEAL.json'}
        check('inherited payload count',len(seal['files'])==receipt['payload_files'])
        for row in seal['files']:
            name=row['path'];check('unique inherited path '+name,name not in expected);expected.add(name)
            raw=(directory/name).read_bytes()
            check('inherited retained bytes '+name,len(raw)==row['bytes'] and sha(raw)==row['sha256']
                  and ('git_blob' not in row or git_hash('blob',raw)==row['git_blob']))
        check('complete inherited population',
              {str(p.relative_to(directory)) for p in directory.rglob('*') if p.is_file()}==expected)
    binding=json.loads((ROOT/'SOURCE_BINDING.json').read_bytes())
    bound=binding['actual_source_commit'] is not None
    source_commit=binding['actual_source_commit'] if bound else PLACEHOLDER
    check('exact source tree and parent binding',binding['expected_source_tree']==SOURCE_TREE
          and binding['expected_source_parent']==SOURCE_PARENT)
    check('truthful source binding state',binding['status']==('BOUND_TO_ROOT_PUBLISHED_SOURCE' if bound else 'UNBOUND_NONEXECUTABLE')
          and (bound or binding['readiness'] is False))
    if bound:
        receipt=binding['root_publication_receipt']
        publication_raw=(ROOT/receipt['path']).read_bytes()
        check('exact Root source-publication receipt',len(publication_raw)==receipt['bytes']==6703
              and sha(publication_raw)==receipt['sha256']==PUBLICATION_RECEIPT_SHA256)
        publication=json.loads(publication_raw)
        provider_commit=publication['provider_commit']['structuredContent']
        provider_ref=publication['provider_ref']['structuredContent']
        check('provider duplicate commit and ref bodies agree',
              provider_commit['content']==provider_commit['structuredContent']['content']
              and provider_ref['content']==provider_ref['structuredContent']['content'])
        commit=json.loads(provider_commit['content']);ref=json.loads(provider_ref['content'])
        check('genuine published source commit and exact sole parent',
              source_commit==PUBLISHED_SOURCE==publication['commit']==commit['sha']==ref['object']['sha']
              and publication['tree']==commit['tree']['sha']==SOURCE_TREE
              and publication['parent']==SOURCE_PARENT
              and [row['sha'] for row in commit['parents']]==[SOURCE_PARENT])
        check('exact published source branch and no workflows or original authority',
              publication['branch']=='pro/dg16-g132-source-custody-r3-20261122-01'
              and ref['ref']=='refs/heads/'+publication['branch']
              and publication['workflows']==[] and publication['original_awards']==[]
              and publication['protected_authority'] is False)
        check('Root admission and full source-body receiving retained',
              receipt['root_admission']==publication['root_admission']=='31fd11/0'
              and receipt['root_full_body_readback']==publication['full_body_readback']=='58574a/0'
              and publication['currentness']==binding['root_currentness']=='ab06fd/0')
    old=(OLD/OWNER).read_text();new=(NEW/OWNER).read_text()
    old_ast,new_ast=ast.parse(old),ast.parse(new)
    def functions(tree):return {node.name:node for node in tree.body if isinstance(node,ast.FunctionDef)}
    old_functions,new_functions=functions(old_ast),functions(new_ast)
    check('one added metadata-only function',set(new_functions)-set(old_functions)=={'captured_storage_description'}
          and not set(old_functions)-set(new_functions))
    function_proofs=[]
    for name,node in old_functions.items():
        if name=='observe':continue
        raw=ast.get_source_segment(old,node).encode()
        check('unchanged function '+name,raw==ast.get_source_segment(new,new_functions[name]).encode())
        function_proofs.append(dict(name=name,bytes=len(raw),sha256=sha(raw),unchanged=True))
    def assignments(tree):
        return {n.targets[0].id:n for n in tree.body if isinstance(n,ast.Assign)
                and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
    old_assign,new_assign=assignments(old_ast),assignments(new_ast)
    changed_constants={'SOURCE_COMMIT','SOURCE_TREE','SOURCE_PARENT','BRANCH','SETUP_PIN'}
    check('no added or removed global constants',set(old_assign)==set(new_assign))
    restored=new
    for name in changed_constants:
        restored=restored.replace(ast.get_source_segment(new,new_assign[name]),
                                  ast.get_source_segment(old,old_assign[name]),1)
    start=restored.index('def captured_storage_description(');end=restored.index('def observe():',start)
    restored=restored[:start]+restored[end:]
    changes=[(
        "        need(re.fullmatch('[0-9a-f]{40}',SOURCE_COMMIT) is not None,\n"
        "             'actual published R3 source commit is not bound; do not execute')\n",''),(
        "result['engine_loading_origin']='DIAGNOSTIC_CHECKOUT_R3_SETUP_EXACT_UNCHANGED_R2_ENGINE_MEMBERS'",
        "result['engine_loading_origin']='DIAGNOSTIC_CHECKOUT_EXACT_R2_MEMBERS'"),(
        "result['source_preparation']=dict(commands=commands,expected_commit=SOURCE_COMMIT,expected_parent=SOURCE_PARENT)",
        "result['source_preparation']=dict(commands=commands,expected_commit=SOURCE_COMMIT)"),(
        'setup.prepare_hosted_source_selected_v3(root,output,SOURCE_COMMIT,SOURCE_PARENT,records=commands)',
        'setup.prepare_hosted_source(root,output,SOURCE_COMMIT,records=commands)'),(
        "        result['source_capture']['storage']=captured_storage_description(captured['state'])\n",'')]
    for before,after in changes:
        check('declared observer replacement occurs once '+before[:72],restored.count(before)==1)
        restored=restored.replace(before,after,1)
    check('full observer restored after only declared delta',restored==old)
    check('exact source commit constant',ast.literal_eval(new_assign['SOURCE_COMMIT'].value)==source_commit)
    check('exact future source tree constant',ast.literal_eval(new_assign['SOURCE_TREE'].value)==SOURCE_TREE)
    check('exact future sole parent constant',ast.literal_eval(new_assign['SOURCE_PARENT'].value)==SOURCE_PARENT)
    check('exact distinct operation branch',ast.literal_eval(new_assign['BRANCH'].value)==BRANCH)
    setup=(INHERITED/'candidate/scripts/qualify-work-graph-c5-setup.py').read_bytes()
    check('R3 setup body remains exact',len(setup)==90827
          and sha(setup)=='7ee5f2282d650692db140629ce436d6502ac0cf4f97786ed8c879192b603e9b0')
    if bound:
        check('published changed source body equals retained R3 setup',len(publication['changed_files'])==1
              and publication['changed_files'][0]['path']=='scripts/qualify-work-graph-c5-setup.py'
              and publication['changed_files'][0]['mode']=='100755'
              and publication['changed_files'][0]['bytes']==len(setup)
              and publication['changed_files'][0]['sha256']==sha(setup)
              and publication['changed_files'][0]['git_blob']==git_hash('blob',setup))
    check('source setup pin matches unchanged included R3 source',
          ast.get_source_segment(new,new_assign['SETUP_PIN'])==
          "SETUP_PIN=dict(bytes=90827,sha256='7ee5f2282d650692db140629ce436d6502ac0cf4f97786ed8c879192b603e9b0')")
    summary=new_functions['captured_storage_description']
    allowed_names={'need','type','len','max','dict','sorted','sum'}
    allowed_attributes={'items','startswith','count','endswith','encode','fullmatch','append'}
    for call in (n for n in ast.walk(summary) if isinstance(n,ast.Call)):
        check('metadata call is bounded scalar/container operation '+ast.unparse(call.func),
              (isinstance(call.func,ast.Name) and call.func.id in allowed_names)
              or (isinstance(call.func,ast.Attribute) and call.func.attr in allowed_attributes))
    observe=new_functions['observe']
    calls=[n for n in ast.walk(observe) if isinstance(n,ast.Call)]
    captures=[n for n in calls if isinstance(n.func,ast.Attribute) and n.func.attr=='complete_source']
    descriptions=[n for n in calls if isinstance(n.func,ast.Name) and n.func.id=='captured_storage_description']
    check('exactly one product capture and one later state-only description',len(captures)==len(descriptions)==1
          and descriptions[0].lineno>captures[0].lineno
          and ast.unparse(descriptions[0].args[0])=="captured['state']")
    check('source-binding refusal precedes context and setup effects',
          new.index("'actual published R3 source commit is not bound; do not execute'")
          <new.index("validate_context(result['context']")<new.index("setup=types.ModuleType"))
    check('original audit maximum retained',"need(len(subprocess_calls)<11" in new)
    check('no new imports', [ast.dump(n) for n in old_ast.body if isinstance(n,(ast.Import,ast.ImportFrom))]
          ==[ast.dump(n) for n in new_ast.body if isinstance(n,(ast.Import,ast.ImportFrom))])
    check('full thirteen-member map byte-identical',(OLD/MAP).read_bytes()==(NEW/MAP).read_bytes()
          and len(json.loads((NEW/MAP).read_bytes()))==13)
    expected_workflow=json.loads((OLD/WORKFLOW).read_bytes())
    expected_workflow['name']='Ordinary R3 selected-source custody and unchanged Engine observation'
    expected_workflow['on']['push']['branches']=[BRANCH]
    expected_workflow['concurrency']['group']='g132-engine-source-observe-20261122-05'
    expected_workflow['jobs']['observe']['env']['EXPECTED_OBSERVER_SHA256']=sha(new.encode())
    expected_workflow['jobs']['observe']['steps'][1]['run']=expected_workflow['jobs']['observe']['steps'][1]['run'].replace(
        'pro/dg16-g132-engine-source-observe-20261121-04',BRANCH)
    check('workflow only declared distinct trigger name and selfhash delta',
          (json.dumps(expected_workflow,indent=2)+'\n').encode()==(NEW/WORKFLOW).read_bytes())
    check('one push trigger without dispatch or retry',set(expected_workflow['on'])=={'push'}
          and expected_workflow['on']['push']['branches']==[BRANCH]
          and expected_workflow['concurrency']['cancel-in-progress'] is False)
    shell=expected_workflow['jobs']['observe']['steps'][1]['run'].encode()
    process=subprocess.run(['/usr/bin/bash','-n'],input=shell,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
    check('workflow shell syntax only',process.returncode==0 and not process.stdout and not process.stderr)
    save('BASH_SYNTAX.json',dict(argv=['/usr/bin/bash','-n'],exit=process.returncode,
        input_bytes=len(shell),input_sha256=sha(shell),stdout_sha256=sha(process.stdout),stderr_sha256=sha(process.stderr)))
    flat={}
    for row in (INHERITED/'EXPECTED_TREE.raw').read_bytes().split(b'\0'):
        if not row:continue
        meta,path=row.split(b'\t',1);mode,kind,oid=meta.split()
        check('unique R3 base path '+path.decode(),path not in flat)
        flat[path]=(mode,kind,oid)
    check('complete inherited R3 tree independently derives',len(flat)==1768 and tree_hash(flat)==SOURCE_TREE)
    source_proofs=json.loads((INHERITED/'FULL_OWNER_PROOFS.json').read_bytes())
    owner_proofs=[]
    for row in source_proofs['owners']:
        name=row['path']
        raw=(INHERITED/'candidate'/name).read_bytes() if row['changed'] else (
            INHERITED/'evidence/diagnostic04-source/evidence/inherited-full-source/inherited-source'/name).read_bytes()
        check('full actual R3 owner retained '+name,flat[name.encode()][2].decode()==git_hash('blob',raw))
        owner_proofs.append(dict(path=name,bytes=len(raw),sha256=sha(raw),git_blob=git_hash('blob',raw),
                                mode=flat[name.encode()][0].decode(),unchanged_by_observer=True))
    check('all fourteen complete R3 owners retained',len(owner_proofs)==14)
    expected_paths={WORKFLOW,OWNER,MAP}
    check('only three candidate paths',
          {str(p.relative_to(NEW)) for p in NEW.rglob('*') if p.is_file()}==expected_paths)
    changed=dict(flat);entries=[]
    for name in sorted(expected_paths):
        raw=(NEW/name).read_bytes()
        check('new observer path absent from R3 source '+name,name.encode() not in flat)
        row=dict(path=name,mode='100644',bytes=len(raw),sha256=sha(raw),git_blob=git_hash('blob',raw),
                 local_path=str(NEW/name))
        entries.append(row);changed[name.encode()]=(b'100644',b'blob',row['git_blob'].encode())
    check('all R3 source blobs and modes unchanged',all(changed[name]==value for name,value in flat.items()))
    check('exact three additions',len(changed)==1771 and set(changed)-set(flat)=={p.encode() for p in expected_paths})
    tree=tree_hash(changed)
    (output/'EXPECTED_TREE.raw').write_bytes(b''.join(mode+b' '+kind+b' '+oid+b'\t'+path+b'\0'
        for path,(mode,kind,oid) in sorted(changed.items())))
    patch=''.join(''.join(difflib.unified_diff((OLD/name).read_text().splitlines(keepends=True),
        (NEW/name).read_text().splitlines(keepends=True),fromfile='operation04/'+name,tofile='operation05/'+name))
        for name in sorted(expected_paths))
    (output/'SOURCE_DELTA.patch').write_text(patch)
    state='BOUND_STATIC_CANDIDATE_REQUIRES_INDEPENDENT_REVIEW' if bound else 'DRAFT_ONLY_UNBOUND_NONEXECUTABLE'
    save('FULL_OWNER_PROOFS.json',dict(source_tree=SOURCE_TREE,owners=owner_proofs,
        unchanged_observer_functions=function_proofs,complete_observer_restoration=True))
    save('PUBLICATION_PLAN.json',dict(status=state,operation=OPERATION,branch=BRANCH,base_commit=binding['actual_source_commit'],
        base_tree=SOURCE_TREE,source_parent=SOURCE_PARENT,expected_tree=tree,entries=entries,
        expected_file_population=1771,source_file_population=1768,source_binding_ready=bound,
        diff_name_status=''.join('A\t'+name+'\n' for name in sorted(expected_paths)),
        protected_grant='UNISSUED',original_awards=[],provider_calls=0,controller_calls=0,
        git_object_writes=0,index_writes=0,ref_writes=0))
    save('PUBLICATION_ENTRIES.json',[dict(path=row['path'],mode=row['mode'],type='blob',content=(NEW/row['path']).read_text())
                                    for row in entries])
    save('STRUCTURAL_VALIDATION.json',dict(status=state,operation=OPERATION,checks=checks,check_count=len(checks),
        expected_tree=tree,source_binding_ready=bound,full_source_owner_count=14,unchanged_Engine_members=13,
        source_capture_calls=1,metadata_extra_Git_commands=0,metadata_extra_source_reads=0,
        product_executions=0,new_hosted_operations=0,new_original_executions=0,authority='NONE'))
    print(json.dumps(dict(status=state,checks=len(checks),expected_tree=tree,entries=entries),sort_keys=True,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=ROOT)
    args=parser.parse_args();args.output.mkdir(exist_ok=True,parents=True);verify(args.output)
