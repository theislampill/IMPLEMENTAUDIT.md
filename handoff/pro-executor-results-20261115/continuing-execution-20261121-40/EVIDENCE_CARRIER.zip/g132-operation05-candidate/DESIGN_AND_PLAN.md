# Operation05 ordinary selected-source observer

Root initially supplied G0045 currentness `9be00b/0` and the distinct bounded author task. Root later supplied G0046 currentness `ab06fd/0`, the genuine published R3 commit and its exact publication receipt, then explicitly authorized final binding/freeze. Root alone may integrate or publish. This packet permits source authoring, static/context/data controls and an actual local refusal only. It permits no hosted/provider/controller/network-Git/original effect, no replay, and no protected grant reuse.

## Intended distinct operation

Operation: `G132_ENGINE_SOURCE_OBSERVE_20261122_05_SELECTED_CUSTODY_R3`.
Branch: `pro/dg16-g132-engine-source-observe-20261122-05`.
The workflow has one exact initial-push trigger, attempt1 only, no dispatch and no retry.

The initial draft used `UNBOUND_R3_SOURCE_COMMIT_DO_NOT_EXECUTE` and actually refused before context acceptance, setup import, resource effects, or source/Git execution. That complete unbound draft and refusal are preserved under `evidence/unbound-draft`. Root's genuine published R3 commit is now `760aaff5c478ff7354d36da186d62daba983aa49`, with tree `f85b199c89e9f6938382ec5f7b2005f54acc8536` and sole parent `f75533f95f0d099c87e7a04beb11b0a25628acdc`. The exact 6,703-byte publication receipt, SHA-256 `9e382f02755dba6ac39706ff32bd358129d2345c11dd1dc44fc9095ddbadbeef`, is retained and its provider commit/ref tuple checked. The bound candidate is for independent review; this author grants no execution authority or native admission.

## Minimal observer delta

Start from exact published04 observer, Engine map and workflow. Update the distinct branch and workflow selfhash, eventual genuine source identity, exact 90,827-byte R3 setup SHA-256 pin, and descriptive loading origin. Call the explicit `prepare_hosted_source_selected_v3` with the bound commit and parent. Retain the existing eleven-child audit ceiling; the new source route uses ten commands.

Keep the exact thirteen-member Engine map, all seventeen selected Git08ca rows, the two finite observed images 133/376, all context/resource/security guards, original false-admission fields, fixed physical owners, and the existing single authentic full capture. The existing failure-only traceback receiver, exact code/source/frame identity proof and unchanged re-raise remain byte-identical. No private/source filtering, launcher provisioning, policy change, original session or native admission is introduced.

After the single actual complete capture succeeds, derive descriptive pack paths, byte sizes and SHA-256 values from its existing `state['files']`, and compute the maximum captured regular-file byte size. There is no reread, extra Git command, repack/unpack, second capture or substitute product snapshot. The summary accepts only the finite existing file population and file-size ceiling; selected pack path/hash output is bounded. It is descriptive evidence and grants no gate passage or original award.

## External comparison is not historical cause evidence

Root relayed owner-supplied Opus measurements: a full-clone pack of 277,761,404 bytes compared with the unchanged 268,435,456-byte process file-size limit, and selected-commit history reportedly containing 13,961 reachable objects at approximately 35.9 MB. This author has no authentic measurement bytes, exact measurement protocol, unit base, or independent receiving for those values. They remain unverified external comparisons. They do not establish operation04's exact index-pack cause or operation03's capture-bound disjunct.

The future observer already retains the genuine source preparation object-row count; the added capture metadata will permit Root to compare actual received storage after independent receiving. No supplied number becomes an acceptance predicate or a replacement for actual capture evidence.

## Qualification and final binding

Use pure context and scalar-data controls for the existing finite host/replay refusals, changed source tuple, unchanged non-admission, authentic traceback exclusions, and derived metadata. Compile-only source checks prove one capture call, unchanged traceback receiver, unchanged owner bodies, no added process/network calls, and exact three-file publication delta. Run only the actual local nonhost/unbound refusal; never present these controls as hosted execution.

Retain the complete frozen R3 source packet and all its inherited source/evidence. Derive the host tree against the authenticated R3 expected tree, preserving every source file. Root supplied the genuine source commit/readback before the placeholder was bound and helper selfhash/workflow finalized. The bound artifact passed 23 data/context controls, actual UID1000 nonhost refusal and 4,601 static checks. No R3 product control was repeated. The exact resulting host tree is `b034e01fac9a3a6641847424e9ccb7f7df9b3e99`, with 1,768 unchanged source files plus three observer additions and required host parent `760aaff5c478ff7354d36da186d62daba983aa49`.
