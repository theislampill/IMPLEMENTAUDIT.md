# Operation05: bound selected-source observer for independent review

The operation05 observer is bound to the genuine published R3 source commit **`760aaff5c478ff7354d36da186d62daba983aa49`**. This packet contains the exact three-file prospective host tree, all full source/evidence, successful ordinary local controls, actual nonhost refusal and complete source/change proofs. It is for independent review. This author grants no execution authority, native admission, original award or lifecycle closure.

## Exact source and host identities

| Property | Exact value |
| --- | --- |
| Operation | `G132_ENGINE_SOURCE_OBSERVE_20261122_05_SELECTED_CUSTODY_R3` |
| Prospective observer branch | `pro/dg16-g132-engine-source-observe-20261122-05`, not created |
| Genuine selected source commit | `760aaff5c478ff7354d36da186d62daba983aa49` |
| Genuine selected source tree | `f85b199c89e9f6938382ec5f7b2005f54acc8536` |
| Genuine selected source sole parent | `f75533f95f0d099c87e7a04beb11b0a25628acdc` |
| Required future observer commit parent | `760aaff5c478ff7354d36da186d62daba983aa49` |
| Exact expected observer host tree | `b034e01fac9a3a6641847424e9ccb7f7df9b3e99` |
| Host population | 1,771 files: all 1,768 source files unchanged, plus exactly three additions |

All three observer additions have Git mode `100644`:

| Path | Bytes | SHA-256 | Git blob |
| --- | ---: | --- | --- |
| `.github/workflows/dg16-g132-engine-source-observe.yml` | 3138 | `87200e5311eef5736a4e8bf42232631f4d76ef33fdadb492c9f29aa02d8b275c` | `e99aeec9aa7e70823b2bcb66f466209e8e37d1b9` |
| `engineering/g132-engine-source-diagnostic/ENGINE_MAP.json` | 2083 | `5d4e482896bd812dadbc49acd3d61daa3bd2ce774c650c967a86cab02d6235bf` | `e7ecd2aa57e0d62bc4491097422241d4bed9b915` |
| `engineering/g132-engine-source-diagnostic/observe.py` | 21995 | `3c0b6bc41662d70e519e2a444e09cd26730d98c5241fd6b3f53bde05a093a5ed` | `87a9605d91c4f4f6f862cfcfbf17831bb3b19e48` |

`PUBLICATION_PLAN.json`, `PUBLICATION_ENTRIES.json` and `EXPECTED_TREE.raw` specify the complete host publication target. `SOURCE_DELTA.patch` describes the minimal successor delta from the exact published04 observer. The complete base tree and candidate tree were derived in memory; this author wrote no Git objects, index or refs.

## Genuine source binding received

Root supplied the exact publication receipt at `evidence/r3-source-publication/PUBLICATION_RECEIPT.json`: **6,703 bytes**, SHA-256 **`9e382f02755dba6ac39706ff32bd358129d2345c11dd1dc44fc9095ddbadbeef`**. This author read and hash-verified it (`5b8439/0`) and checked its actual provider commit/ref bodies, exact tree and sole parent. The receipt records Root admission `31fd11/0`, full setup-body readback `58574a/0`, currentness `ab06fd/0` and zero source-branch workflows; Root also supplied post-receiving `00bea8/0`.

Root's source branch is `pro/dg16-g132-source-custody-r3-20261122-01`. Its one changed setup file remains exactly 90,827 bytes, SHA-256 `7ee5f2282d650692db140629ce436d6502ac0cf4f97786ed8c879192b603e9b0`, Git blob `515ecf98f5db25454dd8ddf8e61a134264a65458`, mode `100755`. That body is retained in the complete R3 source packet and matches the prospective observer's exact setup pin.

The complete frozen R3 candidate remains included under `evidence/r3-source-candidate`, with seal SHA-256 `fd45ff497cadba67a4719ea9ab8018d3cd13b8f38b687de57634ac3c9403c176`. It includes fourteen full physical source bodies, complete authenticated tree maps, previous observer/source-review packets, historical actual failures and the existing R3 process/source qualification. No R3 product/process control was repeated for this observer task.

The initial unbound draft, reports, exact helper/workflow bodies, tree, static proof and actual early refusal remain under `evidence/unbound-draft`. Root supplied the genuine commit before the placeholder was removed and the helper selfhash/workflow finalized. The source-binding guard remains as an early refusal if a future source identity is not a full hexadecimal commit. `SOURCE_BINDING.json` records genuine binding separately from execution authority.

## Minimal observer successor

The observer updates the exact source tuple, R3 setup pin, distinct branch, descriptive Engine loading origin and explicit preparation call:

`prepare_hosted_source_selected_v3(root, output, SOURCE_COMMIT, SOURCE_PARENT, records=commands)`

The normal parent/child acquisition route is already implemented and qualified in R3. The observer retains the original eleven-child audit ceiling; that route uses ten commands. It does not alter setup or any product owner in the source tree.

One added function describes storage from the already completed authentic capture. It reports each direct `.git/objects/pack/*.pack` file's captured relative path, byte count and SHA-256, plus pack count, total pack bytes and maximum captured regular-file bytes. Pack rows are sorted. The metadata receiver retains the finite 4,096-file ceiling and 134,217,728-byte per-file ceiling and bounds pack path/hash output. It performs no source read, Git command, byte capture, object reshaping or product call. Its only production invocation follows the existing successful full capture and receives exactly `captured['state']`.

This description is evidence, not a gate pass or admission. The source preparation's existing genuine object-row count remains available for later comparison. No externally supplied pack size or object count is an acceptance predicate.

All existing observer functions except `observe` remain byte-identical, including finite context validation, source validation and both authentic capture-exception receiver functions. Full-file restoration proves the old observer is recovered exactly after removing the one metadata function and reverting the declared constants and five observe-body edits. The authentic exception path still reads the exact pinned source/code/frame, preserves the real operands and re-raises the original exception. There is exactly one product capture call.

The Engine map is byte-identical. The exact thirteen-member Engine, all seventeen selected Git08ca rows, physical owner dispatch, two observed finite image versions `20261116.133.1` and `20261116.376.1`, runtime/capture/security/audit guards, private-input exclusions and false-admission fields remain intact. No launcher provisioning, policy change, original session or original award is introduced.

The workflow changes only its distinct name/branch/concurrency identity and exact helper selfhash. It preserves the single initial-push trigger, attempt1 restriction, no dispatch or retry, fixed runner and pinned actions, existing timeouts/resource environment, artifact handling and cancellation behavior.

## Completed verification of this exact bound artifact

| Verification | Actual result |
| --- | --- |
| Bound helper/source/selfhash update | `cd6a63/0` |
| Ordinary data/context/compile-only controls | **23 tests passed**, `794d49/0` wrapper |
| Actual local observer invocation | **Exit 2**, actual UID **1000**, reason `actual UID/GID zero is required` |
| Product imports/captures, Git children in actual local refusal | **0 / 0 / 0** |
| Static source/evidence/tree proof | **4,601 checks passed**, `450ecc/0` |
| Workflow shell check | Syntax-only `bash -n` passed; workflow was not executed |

The local refusal retained the genuine source commit in its report and stopped at context before Engine/setup import, source preparation or capture. Complete raw stdout/stderr and native return metadata are retained. Its empty stderr and actual exit 2 are independently bound to the final 21,995-byte helper SHA-256 `3c0b6bc41662d70e519e2a444e09cd26730d98c5241fd6b3f53bde05a093a5ed`.

The controls use finite counterfactual metadata/context fixtures and compile-only pinned code metadata. They do not instantiate an Engine or execute product capture. Metadata checks cover exact pack selection, hashes, ordering, totals, a maximum larger than the packs, empty data, strict equality bounds, malformed/overbound data refusal and absence of I/O/product calls. Inherited controls retain old-branch/retry/changed-image/nonroot/Git-pin/source-tuple refusals, non-admission fields, return-seal behavior, all capture-bound disjuncts and rejection of counterfeit traceback/code identities.

Static receiving verifies every inherited R3 payload byte against its frozen seal, the exact Root publication receipt and provider tuple, all fourteen full source bodies, unchanged Engine map, declared full-file restoration, one capture plus later metadata-only description, workflow syntax/trigger, and the complete three-addition host tree. The static verifier accepts `--output` so independent receiving can derive proofs outside the frozen packet. Completed R3 product controls need not be repeated to receive this artifact.

## Preserved bounds and unresolved facts

The process limits remain address space 1,610,612,736 bytes, CPU 120 seconds, file size 268,435,456 bytes, 256 descriptors, wall time 240 seconds and report size 2,097,152 bytes. The product snapshot limits remain 4,096 entries, 134,217,728 bytes per regular file, 268,435,456 total bytes and depth 40. None was raised.

Root relayed owner-supplied Opus measurements of a 277,761,404-byte full-clone pack, and selected history reportedly containing 13,961 reachable objects at approximately 35.9 MB. This author has no authentic measurement bytes, independently received measurement protocol or known MB unit base. Those figures are explicitly **external, unverified comparisons**. They do not establish diagnostic04's exact index-pack cause or operation03's capture-bound disjunct, and they appear in no runtime acceptance predicate.

No actual hosted operation05 run or genuine selected-source capture occurred in this author task. New pack metadata has been checked using ordinary data controls only. Future actual measurements require Root's distinct hosted qualification and independent receiving. The four library/cache mismatches, NSS files-only refusal and absent bubblewrap remain unqualified. Historical operations03/04 and original44888568054 remain terminal, with no replay or grant reuse.

## Authority and handoff

Root explicitly authorized finalization under G0046 currentness `ab06fd/0`. Root remains the sole provider/integration writer. This author made no provider/controller call, network operation, Git command, product execution, original/protected execution, branch/ref mutation or hosted launch during the observer task. Existing frozen packets were not modified.

Independent review should receive the complete seal, verify the exact genuine source binding and minimal observer delta, and assess all claims against the local-only evidence limitations. Any later publication must use the exact expected host tree and sole parent above. No source-ref update, original award, native admission, overall admission, readiness promotion or closure is asserted by this author.
