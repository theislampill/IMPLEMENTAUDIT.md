# Independent review of prospective retained-M4 host splice v1

Report state: FINAL

## Disposition

**NEEDS_REVISION at prospective source-binding scope.** One confirmed introduced defect remains: Python dictionary equality accepts different canonical JSON types inside `retained_m4`, so the source does not enforce the claimed exact retained binding across requests, decisions and receipts. The original fifteen current-operation proof population and original operational boundaries remain preserved in the inspected source. No original acceptance, operational readiness, source adoption or protected effect is awarded by this report.

The sixteen supplied tests passed. An independent focused run made 84 checks: 60 behaved as expected, while 24 unexpectedly accepted the four numeric/boolean aliases of the same single defect across six receiving interfaces. This is not a combined PASS, and prior narrower PASS reports have not been promoted into one.

## Route, independence and immutable identity

The review was dispatched by `/root` to `/root/g132_full_splice_review` under the installed `implementaudit` governor, using `audit-assess` and the bounded review guidance in `plan-lifecycle.md` and `audit-playbook.md`. Root confirmed that the exact dispatch is the route envelope. The reviewer was created with `fork_turns=none`, no model override and no candidate-authoring context. The reviewer did not author, repair or modify this candidate. Prior review reports in the packet were available as bounded lineage, not acceptance authorities for the combined candidate.

Requested model: inherited, no override. Host-declared identity: ChatGPT, GPT-6 Astra Pro; no separate runtime model attestation was obtained. This is a findings-only immutable-source review, not an executor-ready Git base/head attestation or an original acceptance decision.

Reviewed object:

- Packet: `/workspace/scratch/2678f1e431c3/g132-root-path/review-packet-m4-host-splice-v1`.
- Manifest: `REVIEW_MANIFEST.json`, **14,985 bytes**, SHA256 **37a2f579f299943c45a5f979d2528e99cc2780cad7feead1af0638f879438446**.
- Manifest population: **74 members**, all verified by byte count and SHA256. Every file was `0400`, all packet directories were `0500`, with no missing, additional or symlinked member. Checks were repeated after the focused run and at review completion.
- Baseline G3: **153,706 bytes**, SHA256 **b85cca1550ff8e7c1c89778180e53a5c70f306f0c8725ba60ef3ccd4bbc3a6ad**.
- Declared public host baseline: `301aeecde08ba6f169bc3cd837eae6f6ad068219`; declared product source remains `e76a07b2bae7c945e5a9d529ed8cf9069f4c9064`. This review establishes pinned-file comparison, not remote commit or runtime authentication.

| Candidate file | Bytes | SHA256 |
|---|---:|---|
| `candidate/host/g3_receiving.py` | 161649 | `e9e382904c01dd7caba212e5fffd2faad6ecbe86e59a66cd2c7cf754ba1fd46b` |
| `candidate/host/proof_consumer.py` | 68540 | `0083c29d1ae239136e511730a55a0f008c26c0d68e403ae47c8fe0bfd069ddf2` |
| `candidate/host/run.py` | 162016 | `4fed31348d9e1348e66bd0fac5c4f54b9844ee14e13901e6f12a654f4dab636e` |
| `candidate/entry/public_export.py` | 28918 | `1a16cdff53c4360d594c61c9b2ea9461e4050965f6ca7334fb06fc975a75504b` |
| `candidate/g132_hosted_validate_m4.py` | 9423 | `8406925847a241b5f7c4053f628709122f742844006e8ac8cd5c0c5bb0dc02c3` |

## F1 — Numeric/boolean aliases defeat exact retained binding

**Category:** Correctness / closed input contract. **Classification:** introduced by this transport splice. **Repair class:** product-or-skill defect. **Confidence:** HIGH. **Impact:** medium at the claimed exact binding boundary. **Effort:** small bounded source correction plus regenerated dependent pins. **Fix risk:** limited, provided all joins use the same exact representation and the existing source/currentness/permission checks remain intact. **Route:** dispatch-review / reconcile.

### Evidence and consequence

The new receiving comparisons use ordinary dictionary equality:

- `candidate/host/g3_receiving.py:2025`: `value['retained_m4'] == receive_exact_m4(retained_bodies)`.
- `candidate/host/g3_receiving.py:2089–2093`: the request/decision loop checks the top-level type and ordinary equality for `retained_m4`, followed by ordinary equality to freshly derived retained receiving.
- `candidate/host/g3_receiving.py:2170`: the retained receipt uses the same ordinary equality.
- `candidate/host/proof_consumer.py:393`: final request receiving compares the retained dictionary with independent exact-body receiving using ordinary equality.
- `candidate/host/proof_consumer.py:799`: `r['retained_m4'] == final['retained_m4'] == retained`.
- `candidate/g132_hosted_validate_m4.py:78–100`: the read-only callback uses these source-pinned validators, so it inherits the defect.

In Python, `False == 0` and `True == 1`; dictionaries therefore compare equal when those values are substituted. Canonical JSON encoding preserves the distinction. All the affected documents remain canonical JSON, yet their retained bindings differ in type and canonical bytes.

The concrete saved witness leaves the synthetic request's `currentness_transfer` equal to boolean `false`, replaces only the decision's retained `currentness_transfer` with integer `0`, and preserves the decision's exact actual request SHA256. Both the G3 decision validator and the read-only callback accept it. The request's retained binding hashes to `e6c60c7179931431889ae7c8f48b548f2da68efd4c024d43deea02c2281e0d33`; the decision's hashes to `97b862091d208021d4d6dc5ae2bac1fae921711528e47593f6b101c66bc4cd31`. These are different bindings despite the equality check succeeding.

The independently reproduced alias population is:

| Field | Exact derived type/value | Accepted substitution |
|---|---|---|
| `currentness_transfer` | boolean `false` | integer `0` |
| `new_acceptance` | boolean `false` | integer `0` |
| `required_m4_rerun` | boolean `false` | integer `0` |
| `source_applicability_and_live_root_decision_required_for_new_consumer` | boolean `true` | integer `1` |

Each substitution was unexpectedly accepted at final request validation, independent final request validation, final decision validation, retained Root receipt validation, independent receipt validation, and the source-pinned read-only callback: **4 × 6 = 24** unexpected accepts. The decision and receipt probes deliberately retain the unmodified request binding to test cross-document disagreement, not only a shared malformed value.

This finding does **not** show that `new_acceptance:true`, altered historical bodies, a different prior accepted run, authority, native execution, currentness or original acceptance can be obtained. The stronger `new_acceptance:true` negative was refused at all six joins. The defect is failure of the newly claimed exact closed binding.

### Bounded repair and acceptance criteria

Owner/source: Root's candidate author, with Root as the sole integration/acceptance owner. Use canonical encoded equality or recursive type-and-value equality for every retained receiving comparison, including the request/decision join and the independent request/receipt join. A top-level `dict` type check is insufficient.

Keep the derived exact historical body binding and all old proof/currentness checks unchanged. Add negative controls for numeric/boolean aliases at each receiving stage, including a decision containing integer `0` while its request contains boolean `false`. The correct closed binding must still pass. Refuse every alias, altered/missing body, and changed cross-document binding. Regenerate all changed source, consumer, exporter and callback pins in a distinct immutable candidate; do not overwrite this v1 packet or its adverse evidence.

Verification/rollback: the saved harness reproduces the defect against this exact v1 packet. A revised source packet needs an independently bounded re-review against its own manifest. Preserve v1 unchanged as the failing baseline. No runtime adoption or protected execution follows from the correction. Remaining risk is the unissued complete outer host binding and the separate actual operational evidence described below.

## Checks that held at the reviewed scope

1. **Exact historical bodies and dangling references.** All four staged bodies match their immutable retained-public counterparts. Altering each body by one newline is refused at all six receiving interfaces. For each of the three supported L04 dispositions, naming `retained_m4_receiving` without bodies is refused. The row function matches the independently reviewed pure v2 function's AST after its expected function rename. An accepted L04 still requires the explicit token and exactly `NONE_AT_DECLARED_SCOPE`.

2. **Original proof and permission separation.** The supplied suite checks unchanged original IDs, scopes, dispositions, residuals and all fifteen `FINAL_PROOF_KEYS`; unchanged proof/support populations, predicate names and bounds; and unchanged native guard/proof helper ASTs. The independent run changes each of the fifteen current proof bodies and receives a refusal. Retained evidence remains excluded from other rows and both gate evidence allowlists. Partial Q06 cannot grant complete G3. The complete-G3 all-original-rows conjunction remains present.

3. **Current-operation absence and authority limits.** `natural_L04` remains exactly `NOT_RECEIVED` in the independent receipt, and changing it to `OBSERVED_TRUE` is refused. The retained fact stays separate from local native observations. Original no-award limits and whole-DG16 reservations remain intact in the inspected source.

4. **Request/decision bytes and current time.** A decision bearing a different request SHA256 is refused by the callback. Changing the actual request's current proof digest without reissuing its decision is refused. Expired public requests and decisions are refused, with no injected clock, interval reset or time override. These checks remain public-schema/current-time checks, not issuer or provider authentication.

5. **Direct source pins.** The G3 and independent consumer module pins match actual candidate bytes; independent proof pins match both modules; the host data pin matches the independent pin record; the exporter pin matches `run.py`; and the product source manifest remains byte-identical. The new callback pins exact candidate G3 bytes and compiles only its selected pure validator dependency set. The exporter diff changes only `CORE_RUN_SHA256`.

6. **Actual source call sites, census and export.** Inspected changed functions stage four separate public bodies under `private/g3-retained-m4`; add them to G3 `held_files`, which is inherited by unchanged `final_census`; add them to the independent finite `FILES` population; and include them in acquisition/closing bookends inside unchanged deadline/aggregate controls. Original `PROOFS` and `SUPPORT` remain separate. The independent generic JSON map excludes the separately received Markdown historical report. Final request, independent receipt, final decision, retained receipt and both retained-receipt export paths pass retained bodies to the corresponding validators. This is source inspection; these host call sites were not executed.

The bounded AST change census records 18 changed/added top-level owners in G3, 14 in the independent consumer and 8 in `run.py`, with no removed top-level owner; the corresponding unchanged top-level node counts are 122, 81 and 126. Every changed runtime function was inspected. Full candidate Python sources were compiled for syntax only. The generator was not run and deterministic regeneration was not independently re-proved; actual frozen candidate sources and direct pins were reviewed instead.

## Reproduction and evidence

Run from the review directory:

```sh
python -I -B /workspace/scratch/2678f1e431c3/g132-full-splice-review/run_bounded_review.py
```

The harness verifies the immutable manifest and members before and after, extracts only inspected pure definitions, imports only the inspected public test/fixture module and read-only callback, and writes its results under the reviewer directory. It does not import or invoke a complete original/candidate host module. Exit 0 means the expected v1 review defect was reproduced and the bounded controls matched; it is **not** a candidate PASS.

- `RESULT.json`: individual outcomes for all 84 controls and exact synthetic witness hashes.
- `INDEPENDENT_CONTROLS.txt`: focused summary with 24 unexpected accepts.
- `F1_SYNTHETIC_REQUEST.json` and `F1_SYNTHETIC_DECISION.json`: actual saved public-schema witness documents, explicitly synthetic and never issuer evidence. They expire normally; rerunning the harness creates a fresh synthetic reproduction without altering the clock.
- `SUPPLIED_TESTS.txt`: 16 supplied tests passed, independently rerun with `python -I -B`.
- `PIN_CHECK_BEFORE.json`, `PIN_CHECK_AFTER.json`, `SOURCE_JOIN_CHECKS.json`, and `AST_CHANGE_CENSUS.json`: exact packet and source comparison evidence.
- `HARNESS_FIRST_REFUSAL.txt`: preserved reviewer extractor error caused by assuming the pure `Refusal` class used `pass`; the inspected independent consumer instead uses a harmless class docstring. The extractor was narrowed to permit only a docstring or `pass`, and the complete focused run then executed.
- `SOURCE_JOIN_CHECK_FIRST.txt`: preserved reviewer lookup error while asking for the host row-function name in the prior pure candidate; the prior name is `validate_candidate_rows`. The corrected comparison normalizes only the expected function rename and matches exactly.

All packet-carried historical failures and prior reviews remain unchanged. No secrets or private original input bodies were used. No GitHub/native/UID0 environment was simulated. No controller, claim, STATE, ROADMAP, frozen packet, repository source or protected operation was changed, and nothing was published remotely.

## Remaining boundaries and Root-owned next action

Root should receive F1, preserve this v1 failure, and commission/receive a distinct corrected source packet with updated dependent direct pins. This report does not issue a fresh whole-host inventory, source-applicability review, carrier composition, bootstrap/entry/workflow/publication binding or runtime admission. The packet's `UNISSUED_OUTER_BINDING.json` correctly leaves those as future Root-owned work; the old carrier's reviewed status cannot be transferred to new bytes.

Actual original host custody, provider and issuer authentication, selected current run, recipient/admission, sender binding/encryption, original publication, actual G1, both actual G3 stages, current Root authority and cross-session replay state remain separately required. Source tests do not prove those facts. The original protected **G132 remains `UNKNOWN_NO_REPLAY`**. Existing historical M4 acceptance is retained at its original episode and scope; there is no new M4 replay requirement and no new award here. Local natural L04 remains **`NOT_RECEIVED`**.

NEEDS_REVISION
