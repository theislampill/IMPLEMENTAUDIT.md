#!/usr/bin/env python3
"""Independent bounded v2 re-review: immutable public source, pure validators only.

No full original/candidate host module is imported, and no host, root-identity,
GitHub, native-event, currentness-controller or protected-operation API runs.
The supplied fixture builder creates explicitly synthetic public documents.
"""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import stat
import sys
import time

PACKET = Path('/workspace/scratch/2678f1e431c3/g132-root-path/outer-binding-v1/review-packet-m4-host-splice-v2')
OUT = Path(__file__).resolve().parent
MANIFEST_SHA = '234a5710da534bf3b701e6be6592f9e83d6082f45d126951449897d3d063aea2'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def enc(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()


def verify_packet(label):
    raw = (PACKET/'REVIEW_MANIFEST.json').read_bytes()
    assert len(raw) == 21302 and sha(raw) == MANIFEST_SHA
    manifest = json.loads(raw)
    assert len(manifest['files']) == 110
    for row in manifest['files']:
        path = PACKET/row['path']
        body = path.read_bytes()
        assert not path.is_symlink()
        assert len(body) == row['bytes'] and sha(body) == row['sha256']
        assert stat.S_IMODE(path.stat().st_mode) == 0o400
    actual = {str(p.relative_to(PACKET)) for p in PACKET.rglob('*') if p.is_file()}
    expected = {x['path'] for x in manifest['files']} | {'REVIEW_MANIFEST.json'}
    assert actual == expected
    assert all(stat.S_IMODE(p.stat().st_mode) == 0o500
               for p in [PACKET, *[x for x in PACKET.rglob('*') if x.is_dir()]])
    return {'label': label, 'bytes': len(raw), 'sha256': sha(raw), 'members': 110, 'valid': True}


G_CONSTANTS = set('SOURCE_COMMIT SOURCE_TREE SOURCE_PARENT SOURCE_FILES SOURCE_BYTES SCOPE_SHA CONTROL_BRANCH CONTROL_PATH FINAL_CONTROL_PATH ROOT JOIN PAIR SCOPE SELECTED OWNER_ARRANGEMENT BEFORE AFTER ORIGINAL_IDS ORIGINAL_SCOPES DISPOSITIONS RESIDUALS FINAL_PROOF_KEYS NATIVE_PREREQUISITE_PROFILE NATIVE_PREDICATES FILE_LIMIT REQUEST_LIMIT DECISION_LIMIT HOLD_SECONDS M4_PINS M4_DECISION ORIGINAL_L04_TEXT ORIGINAL_L04_BINDING'.split())
G_FUNCTIONS = set('need sha encode parse exact digest integer descriptor receive_exact_m4 validate_g1_facts validate_public_request validate_decision validate_public_final_request validate_row_decisions validate_final_decision validate_original_receipt'.split())
P_FUNCTIONS = set('require sha encode digest integer exact parse descriptor pins_contract source_identity validate_root bounded_g1_facts validate_final validate_receipt receive_retained_m4'.split())


def pure(path, proof=False):
    selected = []
    for node in ast.parse(path.read_bytes()).body:
        if isinstance(node, ast.Assign):
            names = {x.id for t in node.targets for x in ast.walk(t) if isinstance(x, ast.Name)}
            if not proof and not names & G_CONSTANTS:
                continue
            for part in ast.walk(node.value):
                if isinstance(part, ast.Call):
                    safe = isinstance(part.func, ast.Name) and part.func.id in {'dict', 'list', 'set', 'frozenset', 'zip', 'range'}
                    safe |= isinstance(part.func, ast.Attribute) and part.func.attr == 'split'
                    assert safe, 'Unexpected constant call'
            selected.append(node)
        elif isinstance(node, ast.ClassDef) and node.name == 'Refusal':
            assert not node.decorator_list
            assert all(isinstance(item, ast.Pass) or
                       (isinstance(item, ast.Expr) and isinstance(item.value, ast.Constant)
                        and isinstance(item.value.value, str)) for item in node.body)
            selected.append(node)
        elif isinstance(node, ast.FunctionDef) and node.name in (P_FUNCTIONS if proof else G_FUNCTIONS):
            assert not node.decorator_list
            selected.append(node)
    ns = {'hashlib': hashlib, 'json': json, 're': re}
    exec(compile(ast.Module(body=selected, type_ignores=[]), '<independent-pure-public-source-review>', 'exec'), ns)
    for denied in ('execute', 'consume', 'decide', 'context', 'prepare', 'Path', 'os', 'subprocess', 'urllib'):
        assert denied not in ns
    return ns


def import_safe(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    before = verify_packet('before')
    g = pure(PACKET/'candidate/host/g3_receiving.py')
    p = pure(PACKET/'candidate/host/proof_consumer.py', proof=True)
    # Only the inspected test/fixture module and read-only callback are imported.
    t = import_safe(PACKET/'candidate/test_binding_splice.py', 'review_public_fixtures')
    cb = import_safe(PACKET/'candidate/g132_hosted_validate_m4.py', 'review_readonly_callback')
    d = t.synthetic_documents(g, p)
    m4 = {name: (PACKET/'candidate/host/retained-m4'/name).read_bytes() for name in g['M4_PINS']}
    source = (PACKET/'candidate/host/g3_receiving.py').read_bytes()
    checks = []

    def invoke(stage, changed=None, bodies=None):
        v = d[stage] if changed is None else changed
        b = m4 if bodies is None else bodies
        if stage == 'final':
            return g['validate_public_final_request'](enc(v), retained_bodies=b)
        if stage == 'independent_final':
            all_bodies = {k: raw for k, raw in d['bodies'].items() if k not in m4}
            all_bodies.update(b)
            return p['validate_final'](enc(v), enc(d['initial']), d['initial'], all_bodies, d['pins'])
        if stage == 'decision':
            return g['validate_final_decision'](enc(v), d['final'], sha(enc(d['final'])), time.time_ns()//1000000, retained_bodies=b)
        if stage == 'projection':
            return g['validate_original_receipt'](enc(v), retained_bodies=b)
        if stage == 'receipt':
            return p['validate_receipt'](enc(v), enc(d['initial']), enc(d['final']), enc(d['first']), d['pins'], retained_bodies=b)
        if stage == 'callback':
            return cb.validate_bytes(source, 'original-final', d['final']['run_id'], enc(d['final']), enc(v), retained_bodies=b)
        raise AssertionError(stage)

    d['independent_final'] = copy.deepcopy(d['final'])
    d['callback'] = copy.deepcopy(d['decision'])
    stages = ('final', 'independent_final', 'decision', 'projection', 'receipt', 'callback')

    def record(name, call, expected):
        try:
            call()
            observed, code = 'ACCEPTED', None
        except Exception as exc:
            observed, code = 'REFUSED', type(exc).__name__ + ':' + str(exc)
        row = {'name': name, 'expected': expected, 'observed': observed, 'code': code, 'matched': observed == expected}
        checks.append(row)
        return row

    for stage in stages:
        record('positive/' + stage, lambda stage=stage: invoke(stage), 'ACCEPTED')
    for name in m4:
        changed = dict(m4)
        changed[name] += b'\n'
        for stage in stages:
            record('changed_body/' + name + '/' + stage, lambda stage=stage, changed=changed: invoke(stage, bodies=changed), 'REFUSED')
    for disposition in g['DISPOSITIONS']:
        rows = copy.deepcopy(d['decision']['original_rows'])
        rows[4]['disposition'] = disposition
        rows[4]['evidence'] = ['retained_m4_receiving']
        rows[4]['residuals'] = ['NONE_AT_DECLARED_SCOPE'] if disposition == 'ACCEPTED_AT_DECLARED_SCOPE' else ['NATURAL_RLGWO_PREREQUISITE_UNRECEIVED']
        record('dangling_row/' + disposition, lambda rows=rows: g['validate_row_decisions'](rows, d['decision']['gate_decisions']), 'REFUSED')

    aliases = {'currentness_transfer': 0, 'new_acceptance': 0, 'required_m4_rerun': 0,
               'source_applicability_and_live_root_decision_required_for_new_consumer': 1}
    for field, alias in aliases.items():
        for stage in stages:
            changed = copy.deepcopy(d[stage])
            changed['retained_m4'][field] = alias
            assert enc(changed['retained_m4']) != enc(d[stage]['retained_m4'])
            record('F1_typed_alias/' + field + '/' + stage,
                   lambda stage=stage, changed=changed: invoke(stage, changed), 'REFUSED')
    for stage in stages:
        changed = copy.deepcopy(d[stage]); changed['retained_m4']['new_acceptance'] = True
        record('stronger_acceptance_refusal/' + stage, lambda stage=stage, changed=changed: invoke(stage, changed), 'REFUSED')
    for key in p['PROOFS']:
        changed = dict(d['bodies']); changed[key] += b'changed'
        record('current_proof_byte_change/' + key,
               lambda changed=changed: p['validate_final'](enc(d['final']), enc(d['initial']), d['initial'], changed, d['pins']), 'REFUSED')
    changed = copy.deepcopy(d['decision']); changed['request_sha256'] = 'c'*64
    record('actual_request_digest_refusal', lambda: invoke('callback', changed), 'REFUSED')
    changed_request = copy.deepcopy(d['final']); changed_request['proofs']['final_native'] = 'c'*64
    record('callback_actual_request_byte_change', lambda: cb.validate_bytes(source, 'original-final', changed_request['run_id'], enc(changed_request), enc(d['decision']), retained_bodies=m4), 'REFUSED')
    expired = copy.deepcopy(d['final'])
    for key in ('shared_window_started_unix_ms', 'issued_unix_ms', 'expires_unix_ms'):
        expired[key] -= 700000
    record('callback_actual_time_expired', lambda: cb.validate_bytes(source, 'original-final', expired['run_id'], enc(expired), retained_bodies=m4), 'REFUSED')
    record('decision_actual_time_expired', lambda: g['validate_final_decision'](enc(d['decision']), d['final'], sha(enc(d['final'])), d['final']['expires_unix_ms'], retained_bodies=m4), 'REFUSED')
    gates = copy.deepcopy(d['decision']['gate_decisions']); gates['G3']['disposition'] = 'ACCEPTED_AT_DECLARED_SCOPE'
    record('partial_Q06_cannot_award_G3', lambda: g['validate_row_decisions'](d['decision']['original_rows'], gates, retained_bodies=m4), 'REFUSED')
    changed = copy.deepcopy(d['receipt']); changed['natural_L04'] = 'OBSERVED_TRUE'
    record('local_natural_L04_stays_unreceived', lambda: invoke('receipt', changed), 'REFUSED')

    # Independent reverse-join controls retain the actual changed request digest.
    numeric_request = copy.deepcopy(d['final'])
    numeric_request['retained_m4']['currentness_transfer'] = 0
    boolean_decision = copy.deepcopy(d['decision'])
    boolean_decision['request_sha256'] = sha(enc(numeric_request))
    record('F1_reverse_boolean_decision_numeric_request', lambda: g['validate_final_decision'](
        enc(boolean_decision), numeric_request, sha(enc(numeric_request)), time.time_ns()//1000000,
        retained_bodies=m4), 'REFUSED')
    boolean_receipt = copy.deepcopy(d['receipt'])
    boolean_receipt['final_request_sha256'] = sha(enc(numeric_request))
    record('F1_reverse_boolean_receipt_numeric_final', lambda: p['validate_receipt'](
        enc(boolean_receipt), enc(d['initial']), enc(numeric_request), enc(d['first']), d['pins'],
        retained_bodies=m4), 'REFUSED')

    # Isolated witness documents use synthetic public schema, never issuer evidence.
    witness = copy.deepcopy(d['decision'])
    witness['retained_m4']['currentness_transfer'] = 0
    for name, document in (('F1_SYNTHETIC_REQUEST.json', d['final']), ('F1_SYNTHETIC_DECISION.json', witness)):
        (OUT/name).write_bytes(enc(document))
    witness_meta = {
        'synthetic_public_control_only': True,
        'request_sha256': sha(enc(d['final'])), 'decision_sha256': sha(enc(witness)),
        'request_retained_m4_sha256': sha(enc(d['final']['retained_m4'])),
        'decision_retained_m4_sha256': sha(enc(witness['retained_m4'])),
        'python_equality': witness['retained_m4'] == d['final']['retained_m4'],
        'canonical_bytes_equal': enc(witness['retained_m4']) == enc(d['final']['retained_m4']),
        'note': 'Request/decision files expire normally. Rerun this script for a fresh synthetic reproduction; no clock override is used.',
    }
    assert witness_meta['python_equality'] and not witness_meta['canonical_bytes_equal']
    for path in (PACKET/'candidate').rglob('*.py'):
        compile(path.read_bytes(), str(path), 'exec')  # Compilation only, never execution.
    after = verify_packet('after')
    result = {
        'schema': 'g132.independent-full-splice-source-review.v2',
        'disposition': 'PASS', 'authority': 'NONE',
        'reviewed_manifest': before, 'packet_after': after,
        'python': {'executable': sys.executable, 'version': sys.version},
        'scope': 'PROSPECTIVE_SOURCE_BINDING_AND_PURE_READONLY_VALIDATION_ONLY',
        'original_consumer_invoked': False, 'full_host_module_imported': False,
        'protected_effects_performed': False, 'root_or_GitHub_environment_simulated': False,
        'old_G132': 'UNKNOWN_NO_REPLAY', 'local_natural_L04': 'NOT_RECEIVED',
        'operational_acceptance': 'NOT_EVALUATED_OR_AWARDED', 'new_awards': [],
        'checks': checks, 'check_count': len(checks),
        'unexpected_acceptance_count': sum(not row['matched'] for row in checks),
        'F1_witness': witness_meta,
    }
    assert all(row['matched'] for row in checks)
    assert result['unexpected_acceptance_count'] == 0
    (OUT/'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('disposition', 'check_count', 'unexpected_acceptance_count', 'F1_witness')}, indent=2))
    print('All v2 bounded controls matched, including the prior F1 aliases; no candidate or packet was changed.')


if __name__ == '__main__':
    main()
