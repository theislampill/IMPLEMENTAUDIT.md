# Independent v2 retained-M4 source re-review

Report state: FINAL

## Disposition

**PASS at prospective combined source-binding scope only.** V2 corrects F1: every affected retained binding is compared using canonical JSON bytes, including both directions of the request/decision and final-request/independent-receipt joins. The same independent adverse inputs that exposed the v1 defect now refuse. The correct typed binding continues to pass.

This PASS applies to the exact immutable v2 packet identified below, together with the preserved v1 full-splice inspection and this independently verified narrow repair. It does not replace v1's **NEEDS_REVISION**, authorize adoption, establish outer-host applicability, authenticate original operation evidence or award original acceptance. The original protected G132 remains **`UNKNOWN_NO_REPLAY`**. Local natural L04 remains **`NOT_RECEIVED`**.

## Exact reviewed identity and independence

Review subject: `/workspace/scratch/2678f1e431c3/g132-root-path/outer-binding-v1/review-packet-m4-host-splice-v2`.

Manifest: `REVIEW_MANIFEST.json`, **21,302 bytes**, SHA256 **234a5710da534bf3b701e6be6592f9e83d6082f45d126951449897d3d063aea2**. The **110** manifested members match their byte counts and digests; all member files are `0400` and packet directories are `0500`, with no unexpected or missing members. The packet was checked before and after the independent controls and again at completion.

| Reviewed source | Bytes | SHA256 |
|---|---:|---|
| `candidate/host/g3_receiving.py` | 161717 | `dc9eaf0c86195f32d8d2b711cafa9f0147284e37570439a75da6b1722e14fbe3` |
| `candidate/host/proof_consumer.py` | 68580 | `896828771a2b577c3a505bef6d04118e87700294cdb765b31d8586abf73dfb0e` |
| `candidate/host/run.py` | 162016 | `18270f85bbbc6394026ecfbfa68983de000fce00f3e670f3bd2e4589b717606a` |
| `candidate/entry/public_export.py` | 28918 | `46054662f8d6d2898f49de7f3ad6c61cc41ea92e9296ce385066bec536614513` |
| `candidate/g132_hosted_validate_m4.py` | 9423 | `0b2cf66b9505a18d9f4111f01bae249d69f9d960d4e908c460c739d7faf27c29` |
| `candidate/host/INDEPENDENT_PROOF_PINS.json` | 732 | `6edac84ec42c61643f5e7342f6eb8c530981fe65091c45cca2d9fde14e4cd8b4` |

The original frozen G3 baseline remains **153,706 bytes**, SHA256 `b85cca1550ff8e7c1c89778180e53a5c70f306f0c8725ba60ef3ccd4bbc3a6ad`. The product source manifest remains byte-identical to both v1 and the packet's original baseline.

Reviewer: `/root/g132_full_splice_review`, routed by Root under `implementaudit`/`audit-assess`. Root's exact re-dispatch is the governor envelope. The reviewer retains its prior fresh non-author context and did not author or repair v2. Prior v1 review findings and witnesses were deliberately visible and reused; author working context was not reused. Requested model remained inherited with no override; host-declared identity is ChatGPT, GPT-6 Astra Pro, with no separate runtime model attestation. This findings-only source review makes no Git commit base/head or executor-ready lifecycle claim.

## F1 closure on v2

V1 compared retained dictionaries using Python equality. Boolean `false` and integer `0`, or boolean `true` and integer `1`, could compare equal despite different canonical JSON bytes. V1's saved review and exact witnesses remain unchanged. Its independent report is 15,046 bytes at SHA256 `22e34a2eaa7f5b3ccad332b163a16a98658727c84efc3bec0f84aacf78fc6c0e`; its independent result is 18,054 bytes at `c48b3d890f9e3709e9eef5c9f3358e06d20e0f225a8ea3f0a02f21993aff0195`.

The actual v1-to-v2 source diff was independently derived. Runtime function changes are confined to:

| Owner | Verified correction |
|---|---|
| G3 `validate_public_final_request`, line 2025 | `encode(request retained binding)` must equal `encode(exact-body receiving)`. |
| G3 `validate_final_decision`, lines 2089–2093 | The retained field leaves the generic dictionary-equality loop. Encoded decision, request and exact-body receiving must all match. |
| G3 `validate_original_receipt`, line 2171 | Encoded receipt binding must equal encoded exact-body receiving. |
| Independent `validate_final`, line 393 | Encoded final-request binding must equal encoded independent exact-body receiving. |
| Independent `validate_receipt`, line 799 | Encoded receipt, final request and independently derived receiving must all match. |

The original encoders preserve JSON types. The repair does not coerce numeric values into booleans or replace supplied values with expected values. Exact historical-body receiving still occurs. Both a numeric decision against a boolean request and a boolean decision against a numeric request now refuse. The independent receipt/final-request relationship likewise refuses either direction; the reverse controls retain the actual altered request digest so the refusal addresses retained binding, not a stale hash.

No other runtime function body changes between v1 and v2. `run.py` changes only `MODULE_PINS` and `G3_DATA_PINS`; the exporter changes only `CORE_RUN_SHA256`; the callback changes only `SOURCE_BYTES` and `SOURCE_SHA256`. Callback extraction, allowed pure functions, filesystem reading and actual-clock behavior remain unchanged. The original sixteen-test file is byte-for-byte unchanged. Evidence: `INDEPENDENT_V1_V2_DELTA.json` and the five independently generated source diffs.

**Finding disposition:** F1 is corrected on this exact v2 source. **Classification:** introduced v1 correctness/closed-binding defect, repaired in v2. **Repair class:** product-or-skill defect. **Confidence:** HIGH. **Owner:** Root's candidate author, with integration and acceptance solely owned by Root. **Verification:** all 26 explicit typed-binding adversaries refuse, including both reverse joins, while valid typed controls pass. **Rollback:** preserve the immutable v1 failing packet and review; any future source change needs a new exact identity and affected review. **Remaining risk:** the separate unissued outer binding and actual operational boundaries below. No new bounded source defect was established.

## Independent execution and preserved invariants

Three independent runs completed using the local primary Python **3.12.14** interpreter, with `-I -B`:

| Evidence | Result |
|---|---|
| Original supplied source/binding suite | **16 tests passed** |
| Added supplied typed-binding suite | **8 test methods passed**, containing 24 aliases plus 2 reverse joins |
| Adapted independently authored v1 oracle | **86/86 controls matched**, **0 unexpected accepts** |

The independent oracle retains all 84 prior expected behavioral checks and adds two reverse joins. Its previous 24 unexpected accepts are now refusals. It includes six valid positive receiving paths; altered bytes in each of the four historical bodies across all six receiving interfaces; dangling L04 evidence under each of the three dispositions; all fifteen current-proof byte changes; stronger acceptance refusal; actual request-digest disagreement; stale request/decision time; partial Q06 versus full G3; and local natural L04 absence. The two new reverse controls preserve the correct digest of the altered request.

The independent extraction remains pure. No full original/candidate host module was imported or invoked. The inspected fixture module creates explicitly synthetic public documents; the callback is read-only. Full Python sources were compiled for syntax only. No fake UID0, GitHub environment, native history or currentness-controller state was supplied. No clock was overridden, no time interval was reset, and no private original input bodies were used.

The exact adaptation is disclosed in `ORACLE_ADAPTATION.json` and `ORACLE_ADAPTATION.diff`. The v1 oracle remains unchanged at 12,871 bytes / SHA256 `dd837c6d90cae39fe280f5ebbce068f37644a1f6d94710afe02ace98f12db459`. The v2 oracle is 13,762 bytes / SHA256 `381ea38835acba60d5c07d69178214e54487fbc9eb7f6187a8b1be10c9686ecc`. Changes are limited to packet path/pin/population, v2 output disposition/assertions, output wording, and the two reverse-join cases. Its validation expectations were not relaxed.

The previous v1 full-splice source review remains the basis for unchanged host acquisition, held-file census, independent closing bookends and export call sites. Exact function-delta comparison proves those owners unchanged, and the original suite reruns their scope, population and call-site checks. The repair preserves:

- all fifteen current-operation proof keys and their byte joins;
- original IDs, scopes, dispositions, residuals, native predicate names, proof/support populations and currentness guards;
- L04-only permission for `retained_m4_receiving`, with no addition to Q06, other row evidence or either gate's evidence population;
- the full-G3 all-original-rows conjunction and the explicit partial-Q06 refusal;
- existing custody, file, aggregate and time bounds;
- independent `natural_L04: NOT_RECEIVED`, no current native transition invented from historical acceptance, and all no-award reservations.

Eleven independent static source checks passed: host module pins; independent module pins; the host pin-record digest; exporter core digest; callback G3 size/digest; unchanged other module and data pins; unchanged product manifest; and unchanged historical M4 bodies. Evidence: `SOURCE_JOIN_CHECKS.json`.

The author's retained RED verification binds the original v1 source and records 26 pre-repair failures. Its read-only CLI record shows exact-boolean positive exit 0 and numeric-decision negative exit 1 with `FINAL_RETAINED_M4_BINDING`. Those pinned records were inspected as author evidence; the CLI transport was not separately rerun because its implementation is unchanged and this review independently reran the source-bound callback and typed refusal paths. Author Python 3.13 evidence remains retained; this review's executed interpreter was Python 3.12.14. Neither is actual hosted execution qualification.

No v2 harness exception occurred. Both previously preserved v1 reviewer harness errors remain in lineage. All sixteen files listed by the v1 review-output manifest, plus that manifest itself, match their original bytes in v2 lineage. The complete original v1 packet and the original v1 review outputs were rechecked unchanged at completion.

## Evidence and reproduction

All new reviewer outputs are confined to `/workspace/scratch/2678f1e431c3/g132-full-splice-review/v2`.

```sh
python -I -B /workspace/scratch/2678f1e431c3/g132-full-splice-review/v2/run_bounded_review_v2.py
```

`RESULT.json` records every independent control and before/after manifest identity. `SUPPLIED_ORIGINAL16.txt` and `SUPPLIED_TYPED_BINDING.txt` record the supplied suite reruns. `PIN_CHECK_BEFORE.json` and `PIN_CHECK_AFTER.json` bind the immutable population. `INDEPENDENT_V1_V2_DELTA.json`, `SOURCE_JOIN_CHECKS.json` and the per-file diffs bind the source comparison. New synthetic witness files remain ordinary expiring test documents and are never Root issuance evidence. Rerunning the oracle refreshes only synthetic test inputs under this reviewer directory using actual local time.

The deterministic build generator was not executed by this reviewer; the frozen generated runtime bodies, their narrow changes and all direct pin joins were independently checked. Nothing in this review changes a frozen packet, controller, claim, STATE, ROADMAP, repository source or protected operation. No remote publication occurred.

## Remaining operational boundaries and Root-owned next decision

This is the **prospective combined source-binding PASS** requested by Root. Root may now reconcile this evidence into ordinary source preparation. It does not issue the fresh whole-host public inventory, carrier composition, bootstrap/entry/workflow/publication dependency closure, source-applicability decision or runtime admission. Those remain explicitly unissued, with Root as owner and the exact completed outer package as the revisit trigger. An old reviewed-carrier status does not transfer to changed bytes.

Actual current host custody, provider and issuer authentication, selected run, recipient/control interfaces, sender binding/encryption, original publication, actual G1 and both actual G3 stages remain distinct operational requirements. Current Root authority, source applicability and cross-session no-replay state remain mandatory. The supplied G000A continuity pointer is Root's control context, not a native admission or candidate proof.

Existing historical M4 acceptance remains accepted at its original episode without a new replay requirement. This review issues no original award, whole-cell/programme acceptance, native acceptance, protected effect, readiness for protected launch or audit closure. **G132 remains `UNKNOWN_NO_REPLAY`; local natural L04 remains `NOT_RECEIVED`.**

PASS
