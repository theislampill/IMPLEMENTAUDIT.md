"""F1 regression controls: synthetic JSON, pure source, actual local clock."""
import copy
import importlib.util
from pathlib import Path
import time
import unittest

HERE = Path(__file__).resolve().parent
ALIASES = {
    'currentness_transfer': 0,
    'new_acceptance': 0,
    'required_m4_rerun': 0,
    'source_applicability_and_live_root_decision_required_for_new_consumer': 1,
}


def inspected_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class RetainedBindingTypeTests(unittest.TestCase):
    def setUp(self):
        self.t = inspected_module(HERE / 'test_binding_splice.py', 'typed_binding_fixture_helpers')
        self.g = self.t.pure(HERE / 'host/g3_receiving.py')
        self.p = self.t.pure(HERE / 'host/proof_consumer.py', proof=True)
        self.cb = inspected_module(HERE / 'g132_hosted_validate_m4.py', 'typed_binding_readonly_callback')
        self.d = self.t.synthetic_documents(self.g, self.p)
        self.m4 = self.t.retained_bodies()

    def invoke(self, stage, value):
        enc, sha, d = self.t.encoded, self.t.sha, self.d
        if stage == 'final':
            return self.g['validate_public_final_request'](enc(value), retained_bodies=self.m4)
        if stage == 'independent_final':
            return self.p['validate_final'](enc(value), enc(d['initial']), d['initial'], d['bodies'], d['pins'])
        if stage == 'decision':
            return self.g['validate_final_decision'](enc(value), d['final'], sha(enc(d['final'])),
                time.time_ns() // 1000000, retained_bodies=self.m4)
        if stage == 'projection':
            return self.g['validate_original_receipt'](enc(value), retained_bodies=self.m4)
        if stage == 'receipt':
            return self.p['validate_receipt'](enc(value), enc(d['initial']), enc(d['final']), enc(d['first']),
                d['pins'], retained_bodies=self.m4)
        if stage == 'callback':
            return self.cb.validate_bytes((HERE / 'host/g3_receiving.py').read_bytes(), 'original-final',
                d['final']['run_id'], enc(d['final']), enc(value), retained_bodies=self.m4)
        raise AssertionError(stage)

    def assert_aliases_refused(self, stage, field_source):
        for field, alias in ALIASES.items():
            with self.subTest(stage=stage, field=field):
                changed = copy.deepcopy(self.d[field_source])
                changed['retained_m4'][field] = alias
                # Reproduce the exact mechanism, without mocking a clock or host.
                self.assertEqual(changed['retained_m4'], self.d[field_source]['retained_m4'])
                self.assertNotEqual(self.t.encoded(changed['retained_m4']),
                                    self.t.encoded(self.d[field_source]['retained_m4']))
                with self.assertRaises(Exception):
                    self.invoke(stage, changed)

    def test_public_request_refuses_four_boolean_number_aliases(self):
        self.assert_aliases_refused('final', 'final')

    def test_independent_final_refuses_four_boolean_number_aliases(self):
        self.assert_aliases_refused('independent_final', 'final')

    def test_decision_refuses_four_numeric_bindings_against_boolean_request(self):
        self.assert_aliases_refused('decision', 'decision')

    def test_retained_receipt_refuses_four_boolean_number_aliases(self):
        self.assert_aliases_refused('projection', 'projection')

    def test_independent_receipt_refuses_four_boolean_number_aliases(self):
        self.assert_aliases_refused('receipt', 'receipt')

    def test_callback_refuses_four_numeric_decisions_against_boolean_request(self):
        self.assert_aliases_refused('callback', 'decision')

    def test_boolean_decision_cannot_join_numeric_request(self):
        request = copy.deepcopy(self.d['final'])
        request['retained_m4']['currentness_transfer'] = 0
        decision = copy.deepcopy(self.d['decision'])
        decision['request_sha256'] = self.t.sha(self.t.encoded(request))
        with self.assertRaises(Exception):
            self.g['validate_final_decision'](self.t.encoded(decision), request, decision['request_sha256'],
                time.time_ns() // 1000000, retained_bodies=self.m4)

    def test_boolean_independent_receipt_cannot_join_numeric_final_request(self):
        request = copy.deepcopy(self.d['final'])
        request['retained_m4']['currentness_transfer'] = 0
        receipt = copy.deepcopy(self.d['receipt'])
        receipt['final_request_sha256'] = self.t.sha(self.t.encoded(request))
        with self.assertRaises(Exception):
            self.p['validate_receipt'](self.t.encoded(receipt), self.t.encoded(self.d['initial']),
                self.t.encoded(request), self.t.encoded(self.d['first']), self.d['pins'], retained_bodies=self.m4)


if __name__ == '__main__':
    unittest.main(verbosity=2)
