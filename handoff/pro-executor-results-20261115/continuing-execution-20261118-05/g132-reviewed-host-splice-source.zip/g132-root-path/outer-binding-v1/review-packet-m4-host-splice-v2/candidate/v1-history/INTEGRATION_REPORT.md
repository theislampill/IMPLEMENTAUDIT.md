# Retained M4 through the actual hosted G3 source interfaces

## Result and review boundary

This is a concrete prospective source splice for the existing hosted route.
It carries the four exact, already-public M4 receiving bodies through actual
host acquisition, held-file census, final request, independent proof receipt,
Root final decision, retained Root receipt, and public export validation. A
source-pinned read-only Pro callback understands the new final schema.

The candidate does not create a new root route. It does not execute an original
consumer, create a current receipt, issue policy, authenticate Root, or grant an
effect. It is an overlay on the exact public host baseline
`301aeecde08ba6f169bc3cd837eae6f6ad068219`, with complete changed source bodies and
direct pin joins for review. Outer host inventory, carrier/bootstrap binding,
source applicability, and actual hosted execution remain with Root. The old
protected G132 operation remains `UNKNOWN_NO_REPLAY`.

The frozen original G3 module remains 153,706 bytes at
`b85cca1550ff8e7c1c89778180e53a5c70f306f0c8725ba60ef3ccd4bbc3a6ad`.
No original source, approved source pin, immutable review packet, private input
body, or Root controller was changed.

## The original requirement is already satisfied at M4's declared episode

The accepted input is Root's existing M4/R35-L04 receiving for run
`44076469956`, with no missing original M4 predicates and no required M4 rerun.
The exact receipt is 33,448 bytes at
`2915fe9d6723ad9c745906d763d1de5818de7f4ae79db3bba196b5d8d678d0db`.
The original useful preparation, blocked admission/effect, consumed return,
completed comparison inputs, and natural material transition are retained
historical facts. The original requirement did not add comparison equality or
completion of G132. Its adverse comparisons and other old failures remain.

The prior pure input/row candidate's v1 gap was a dangling retained-evidence
reference on partial/unreceived L04. V2 requires exact body receiving whenever
the new token is named, for every disposition. Its immutable manifest is
`102bba7f73733ddd6891a3d7c0466fa473e810dfda214f286d7b3a3bd0bb324f`.
The independently received v2 report is 8,257 bytes at
`00d31d1dac233144418db1577c2356051186605d42b0793586e03a2054f808e8`;
the structured result is 6,258 bytes at
`00daa503d84c667019ea301898655455da1ea8b6899f46c3343531f8402326ae`.
That PASS applies to the pure F1 repair and preserved row contract. This larger
source splice needs its own independent review.

The original frozen-source read-only callback also received independent PASS
at its exact public-schema/run/time scope. Its report is 12,166 bytes at
`cdbae4ca19feb8600e3500eaaaf471b97a8b8f94e199c3e9c89b6d44b035ee03`,
and result is 8,724 bytes at
`d645e5a0bc66ec956cb9fba5ff841ddfc7c4eba70a4cffcd32624543dd14d9c9`.
That review explicitly requires fresh review of any changed source or extraction
set. The new callback in this packet is consequently a new review subject.

## One distinct historical-input binding

The new field is `retained_m4`. It is separate from `proofs`, `PROOFS`,
`FINAL_PROOF_KEYS`, and every original row/gate evidence allowlist. It contains
the exact closed receiving produced from all four historical bodies: Root
receiving, independent report, independent result, and final check. Body byte
counts and SHA256 values, original scope, prior accepted run and decision,
reserved claims, and the absence of any currentness/acceptance transfer are
explicit. A digest-only summary cannot replace those body inputs.

The transport versions change only for affected final records:

| Record | Candidate schema | Exact new relationship |
|---|---|---|
| Final request | `dg16.g3-original-receiving-request.v3` | The actual request bytes bind `retained_m4` alongside the unchanged fifteen current-operation proof digests. |
| Independent proof receipt | `dg16.independent-proof-consumption-receipt.v2` | The independently acquired four bodies produce the same binding; the receipt still binds the exact final request bytes and original proof/support populations. |
| Root final decision | `dg16.g3-root-original-decision.v3` | The decision binds the actual request digest, live run/nonce/current receipt, original proofs, deadline and exactly the same retained binding. |
| Retained Root receipt | `dg16.g3-root-original-decision-retained.v3` | The actual retained projection carries that binding and revalidates its rows with exact retained bodies. |

Component request/decision schemas remain v2. The current job's proof receipt
still says `natural_L04: NOT_RECEIVED`. The new field records the prior accepted
episode separately; it does not turn missing local natural observations into
present observations. The independent consumer still issues no original awards
and no review/admission.

The added evidence token is permitted only on L04. An accepted L04 still needs
all four exact bodies, the explicit token, and exactly
`NONE_AT_DECLARED_SCOPE`. Q06, other rows, G1 gate evidence and G3 gate evidence
cannot use it. Complete G3 still requires the complete applicable original
conjunction, including Q06's current complete live shape. No retained M4 field
can supply a current G1 result, G0002 receipt, native graph, original proof body,
independent applicability review, or live Root decision.

## Exact source and call-site coverage

`build_splice.py` verifies every baseline hash and the independently reviewed
v2 row-source hash before constructing source. It preserves bytes outside
selected source nodes. New source is compiled for syntax only; neither original
nor prospective host modules are imported or invoked.

| Source | Changed interfaces | What remains mandatory |
|---|---|---|
| `host/g3_receiving.py` | Exact historical-input helpers; reviewed v2 L04 row logic; `prepare`, `held_files`, `prepare_final_request`, `validate_public_final_request`, `read_root_decision`, `validate_final_decision`, `decide`, `validate_original_receipt`; refusal-code census. | Actual zero IDs and GitHub context; original `receive`/`consume`; actual G1 raw receiving; actual current native graph; both original Root stages; all holds, time bounds and currentness checks. |
| `host/proof_consumer.py` | Independent retained-body receiver; separate input-file population; final-request binding; actual acquisition/bookends; independent receipt and closed receiving. | All fifteen original proofs, seven support bodies, all original predicate names, graph/rederivation checks, original local natural absence, original no-award limitations and unchanged time/byte caps. |
| `host/run.py` | Public body staging; exact retained bodies supplied to final request and independent receipt export; exact bodies supplied to both retained-receipt export paths; direct module/data pins and refusal labels. | Actual original host sequence, existing independent consumer call, maintained G1 callbacks, actual source/currentness, and fixed public artifact populations. |
| `entry/public_export.py` | Exact new `CORE_RUN_SHA256` only. | Every public exporter function and custody/eligibility check. |
| `g132_hosted_validate_m4.py` | Exact new G3 source pin; inspected pure final validators; explicit retained-body argument and readonly input directory. | Actual current time, exact selected attempt-1 run, canonical request/decision bytes and full request binding. Provider/issuer authentication and publication/consumption remain separate. |

The public M4 bodies are staged into `private/g3-retained-m4`, separately from
the eleven original private inputs and from current native graph input files.
The original held-file census includes all four, so the existing initial and
final identity checks cover them. `final_census` remains unchanged and inherits
those four entries through its existing `held_files` call.

The independent consumer adds the four files to its own finite acquisition
population. Its existing `Population` acquisition and close/reclose bookends
therefore cover them, and their work is charged inside the unchanged 30-second
consumer and shared/enclosing deadlines. The total declared input population
becomes 32 from 28, with an explicit four retained-M4 inputs. The original
1 MiB per-body, 8 MiB aggregate, 60-second final-decision and 180-second reserve
bounds are unchanged. Original current-operation body counts are unchanged.

The generic JSON map in `check_bodies` excludes these four new historical
inputs after their separate exact receiving. This is necessary because the
independent M4 report is Markdown. All current-operation JSON parsing and
semantic proof predicates remain in place.

The independent M4 receiving implementation does not import or call G3's
receiver. It independently checks the exact public body pins, accepted Root
subject/scope/reserved fields and support joins, and emits the same binding.
This is independent transport/input receiving of an already accepted fact, not
a second historical native event or an independent re-award of M4.

## Current Pro callback

The new callback variant receives the new final request and decision without
running a host consumer. Its actual command shape is:

```text
/usr/bin/python3 -I -B RECEIVED_CALLBACK
  --source RECEIVED_CANDIDATE_G3
  --stage original-final
  --run-id ACTUAL_ORIGINAL_RECEIVER_SELECTED_RUN
  --request RECEIVED_REQUEST --request-sha256 EXACT_REQUEST_SHA
  --decision ACTUAL_ROOT_DECISION --decision-sha256 EXACT_DECISION_SHA
  --retained-m4-directory EXACT_RECEIVED_PUBLIC_M4_DIRECTORY
```

The paths and hashes come from actual receiving. The directory contains the
four exact readonly public M4 bodies. The helper supplies neither those actual
provider facts nor the Root decision. It reports request/decision digests and
the retained binding digest, with authority NONE, no acceptance and no native
authentication. It has no clock override or interval-reset path. The existing
frozen-source callback remains unchanged and continues to refuse the new schema.

## Verification and its limits

Sixteen tests passed. They execute only inspected AST-selected pure functions
from the host candidates and the new read-only callback over synthetic public
documents and the exact public M4 bytes. Full source modules are only compiled
for syntax. No test supplies a fake root identity or GitHub environment, calls
an original consumer, or runs archived actors.

The controls cover positive request/proof/decision/receipt joins; missing or
changed M4 bodies at every join; changed transport fields; changed current
proof bytes; Q06/other-row/gate evidence isolation; partial-Q06 whole-G3
refusal; live decision nonce/current-receipt/request-digest and expiry checks;
original proof population/predicate/bound preservation; exact native guard and
proof-function AST preservation; staging/census/export call sites; and direct
source-pin joins. The new callback rejects the old source, missing retained
bytes and expired final requests.

`CALLBACK_CLI_CONTROLS.json` additionally records actual isolated read-only CLI
execution. The current synthetic final request/decision returned exit 0; the
expired synthetic request returned exit 1 with `ORIGINAL_REQUEST_NOT_CURRENT`.
These are public-schema controls, not execution or issuer evidence.

`SMOKE_A.txt` preserves the frozen v2 closed-schema rejection and initial
missing-splice failure. `CALLBACK_RED.txt` and `EXPORT_PIN_RED.txt` preserve the
missing callback and exporter-pin checks before their implementation.
`SOURCE_TEST_FIRST.txt` preserves the first suite's census assertion failure:
the harness looked for an underscore spelling in a path that correctly used
hyphens. The harness was corrected to compare the exact census AST; the source
was not changed to conceal a failed requirement. Subsequent complete results
and deterministic rebuild readback are retained.

The local test interpreter is recorded in `VERIFICATION.json`. These checks do
not qualify the future Ubuntu/Python 3.12 host or prove its actual execution.

## Genuine remaining source/authority/effect gates

`OUTER_PIN_IMPACT.json` records a bounded read-only scan of all 49 selected host
workflow/entry/episode files at the exact baseline. The affected host validator
call sites are in the three candidate modules above. The outer dependency
frontier includes the public packet manifest, the carrier composition's exact
`run.py` descriptor, and the public exporter pin.

`UNISSUED_OUTER_BINDING.json` provides exact old/new known member descriptors,
four new public members, and the proposed carrier core descriptor. It is not a
runtime admission or manifest. The original carrier composition says
`REVIEWED_EXACT_CARRIER_COMPOSITION`; that old statement must not be copied onto
new bytes and presented as fresh review. Root must receive the source review,
derive the fresh carrier/source applicability binding, regenerate the complete
public inventory, and bind bootstrap/entry/workflow/publication pins to the
final exact package. This source packet does not issue those records.

After those source bindings, actual host/recipient/admission, original sender
binding/encryption, original publication, actual G1 and both actual G3 stages
still require their real current interfaces. Current Root authority,
cross-session no-replay state, original resource/deadline bounds, and separate
scoped decisions remain mandatory. No old grant or uncertain operation can be
reused. No protected launch is proposed until executability is established.

This packet is reviewable source preparation. It preserves existing M4/M5
acceptance, the original product and denominators, all original failures, the
old UNKNOWN effect, and the absence of any whole-cell or programme award.
