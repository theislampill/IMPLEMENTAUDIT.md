# Retained-M4 host splice v2: exact JSON type binding

## Disposition and scope

V2 is a distinct prospective source correction for the independent v1 finding
F1. It is **pending independent re-review**. It issues no source adoption,
applicability decision, runtime admission, protected effect or original award.
The original protected G132 remains `UNKNOWN_NO_REPLAY`; historical M4/L04
acceptance remains accepted at its original episode without a replay requirement.

The complete frozen v1 packet remains unchanged: 74 members, manifest 14,985
bytes, SHA256 `37a2f579f299943c45a5f979d2528e99cc2780cad7feead1af0638f879438446`.
Its independent disposition is **NEEDS_REVISION**, retained in
`../prior-full-splice-v1-review/REPORT.md` and `RESULT.json`. The prior report is
15,046 bytes at `22e34a2eaa7f5b3ccad332b163a16a98658727c84efc3bec0f84aacf78fc6c0e`;
the result is 18,054 bytes at
`c48b3d890f9e3709e9eef5c9f3358e06d20e0f225a8ea3f0a02f21993aff0195`.
All sixteen independently manifested review outputs, including the exact
synthetic witness and adverse extractor records, are preserved in that folder.

The earlier v1 integration explanation and verification are retained under
`v1-history/`. Their earlier passing supplied tests do not override the later
independent defect finding. This document and v2 verification describe the new
source subject; the earlier documents remain historical evidence.

## Reproduced defect

Python dictionary equality treats `False == 0` and `True == 1` as true. V1 used
dictionary equality for `retained_m4`, allowing different canonical JSON types
and bytes to pass the claimed exact binding. The original fifteen proof
population, current proof predicates, native guards and acceptance limits did
not change, and the review did not establish an original acceptance bypass.

The saved reviewer witness has boolean `currentness_transfer:false` in its
synthetic request and integer `currentness_transfer:0` in its synthetic decision,
while the decision still binds the exact request hash. It is historical
synthetic evidence with ordinary expiry, not an issued Root decision.

Before editing source, this worker verified the copied candidate bytes against
v1 and ran newly written negative tests. All **24** original alias cases were
reproduced: four fields across six joins. Two reverse cross-document cases also
failed: a boolean decision against a numeric request, and a boolean independent
receipt against a numeric final request. `TYPED_BINDING_RED.txt` therefore
records **26 failures**, with eight test methods. Its SHA256 is
`ae177655b39bab85c5705978ab066e20b0076dfa3f4b49f84f416080fec46e9b`.
`TYPED_BINDING_RED_VERIFICATION.json` binds the pre-repair source identities.

## Minimum source correction

Every retained transport comparison now compares the original canonical JSON
encoding. The existing encoders preserve JSON types; no value is coerced or
normalized into an expected boolean. Exact historical-body receiving still
runs before the comparison.

| Source function | New retained comparison |
|---|---|
| G3 `validate_public_final_request` | Encoded request binding equals encoded exact-body receiving. |
| G3 `validate_final_decision` | Encoded decision binding equals encoded request binding equals encoded exact-body receiving. The retained field is removed from the generic dictionary-equality loop and checked here instead. |
| G3 `validate_original_receipt` | Encoded retained-receipt binding equals encoded exact-body receiving. |
| Independent `validate_final` | Encoded final-request binding equals encoded independent exact-body receiving. |
| Independent `validate_receipt` | Encoded independent-receipt binding equals encoded final-request binding equals encoded independent exact-body receiving. |

The Pro callback's selected function set and implementation are unchanged; its
source byte count and SHA256 now pin the repaired G3 source. It consequently
uses the corrected comparisons. The host module pins, independent proof pin
record, host data pin and exporter core pin are regenerated from actual new
bytes. `V1_V2_SOURCE_DELTA.json` records the exact change census.

Only those five validator function bodies change between v1 and v2. The other
changed runtime owners are direct pin constants in `run.py`, the exporter and
the read-only callback. No native guard, current proof function, body-acquisition
owner, census, held-file check, time window, issuer requirement, product source
manifest, row scope or original requirement changes.

## Preserved whole-path design

The four exact already-public M4 bodies remain a separate historical input
population. They are staged separately from the eleven private original inputs,
held by the existing G3 census, and acquired/reclosed by the independent proof
consumer. The final request, independent receipt, final Root decision and
retained receipt carry the same explicit binding.

The original fifteen `FINAL_PROOF_KEYS`, original proof/support populations and
all original current-operation predicate names remain unchanged. The retained
token remains L04-only. Q06, other rows and both gate evidence lists cannot use
it. Complete G3 still requires the full applicable original conjunction,
including Q06's complete current live shape. A prior M4 receipt cannot supply
current G1, a G0002 receipt, native graph history, current source applicability,
Root authority or protected effects.

The new host's independent proof receipt still states `natural_L04: NOT_RECEIVED`.
The accepted prior episode is separate; it is not an invented local observation.
All original no-award and stronger-claim reservations remain.

## Verification and exact limits

The original sixteen source/binding tests are carried byte-for-byte. They still
pass. The eight added typed-binding methods now pass, with all 26 numeric/boolean
negative controls refusing. The actual request-digest relationship is retained
in the cross-document tests; they are not merely disconnected malformed fields.

The suites run only inspected AST-selected pure validators and the read-only
callback, using explicit synthetic public documents and exact public M4 bodies.
They use the actual local clock with no clock override, root identity or GitHub
environment substitution. Original or prospective host consumers are never
imported or executed. Full source compilation is syntax checking only.

Fresh isolated read-only CLI evidence, current direct pin identities and the
deterministic rebuild are recorded in `VERIFICATION.json`. The positive control
keeps exact boolean values; the adverse CLI control supplies a numeric decision
binding against the same exact boolean request. No CLI result authenticates
provider facts, Root issuance or native execution.

## Remaining outer binding and operational boundary

Dependent outer pin finalization was paused for F1. The new direct source hashes
are now available for mechanical continuation, but source adoption waits for the
new independent review. `UNISSUED_OUTER_BINDING.json` remains an unissued source
proposal. No old `REVIEWED_EXACT_CARRIER_COMPOSITION` statement is transferred to
new bytes, and no old policy or grant is reused.

The exact whole-host/carrier/bootstrap/entry/workflow/publication dependency
closure and current Pro recipient/sender/control interfaces remain the next
ordinary source-preparation work. Fresh applicability and authority decisions
must stay distinguishable from mechanically computed source hashes. Actual
G1/G3, current custody and any later distinct protected proposal remain with
Root. No protected operation is ready or issued by this repair.
