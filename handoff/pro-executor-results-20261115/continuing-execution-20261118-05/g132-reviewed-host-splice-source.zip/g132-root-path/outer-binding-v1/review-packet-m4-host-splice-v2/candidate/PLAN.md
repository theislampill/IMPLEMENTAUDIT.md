# Prospective retained-M4 host splice

Authority is ordinary isolated source engineering only. The output is a new
candidate, never an adopted host or issued policy. The original protected
operation remains UNKNOWN_NO_REPLAY. No original module, guarded consumer,
operator, controller, native actor, host environment or GitHub effect is run.

## Exact design

Keep the fifteen current-operation proofs, their row/gate permissions, native
predicates, live G1/G0002 checks, deadlines and original scopes unchanged. Carry
one additional closed `retained_m4` transport binding, derived from all four
exact already-public accepted-M4 bodies, through final request, independent
proof receipt, final Root decision and retained Root receipt. The only new row
evidence permission remains `retained_m4_receiving` on L04.

The new host does not claim a local natural transition: its independent
receipt retains `natural_L04: NOT_RECEIVED`. The accepted prior episode is
identified separately. There is no new M4 prerequisite and no replay.

## Source changes to prepare

1. Deterministically derive candidate `g3_receiving.py`, `proof_consumer.py` and
   `run.py` from exact public 301a baseline bytes. Copy the independently
   reviewed v2 row core and exact retained public body pins without modifying
   either immutable review packet.
2. Stage the public M4 bodies separately from the eleven private original
   inputs. Include all four in the original held-file census and the proof
   consumer's actual acquisition/bookends. Keep its original aggregate/time
   caps and increase only the declared finite population count by four.
3. Wire every affected host request/decision/receipt call site to exact body
   receiving. Keep the independent proof reader independent of the G3 module.
   Exclude the retained Markdown report from generic current-proof JSON parsing.
4. Regenerate the candidate's direct G3/proof module and independent-proof pin
   joins. Preserve the product source manifest byte-for-byte. Record outer
   host/bootstrap/publication/applicability pins as a fresh Root binding gate.
5. Add a source-pinned read-only Pro callback variant for the new final schema.
   It must still use actual current time, receive actual request/decision bytes,
   and create no request, decision, admission, publication or consumption.
6. Run only AST-selected pure source functions over explicit synthetic public
   documents and exact public historical M4 bytes. Test positive joins and real
   refusal boundaries. Compile full candidate sources without importing them.
7. Freeze source, generator, tests, baseline identities, public inputs and prior
   review lineage in a new immutable packet for independent review.

## Terminal boundary

Source review and synthetic validation do not authenticate native execution,
current custody, issuer identity, new applicability or a protected effect.
Root must integrate/receive the new complete source package and independently
bind its actual recipient/control composition before any fresh protected
proposal. Existing M4/M5 acceptance and all old failures/unknowns remain intact.
