"""Pure source-binding controls only; no host, consumer or native actor runs."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import time
import unittest

HERE = Path(__file__).resolve().parent
WORKER = HERE.parent
BASE = HERE / 'baseline'
CANDIDATE = HERE / 'host'
G3_CONSTANTS = {'SOURCE_COMMIT', 'SOURCE_TREE', 'SOURCE_PARENT', 'SOURCE_FILES', 'SOURCE_BYTES',
    'SCOPE_SHA', 'CONTROL_BRANCH', 'CONTROL_PATH', 'FINAL_CONTROL_PATH', 'ROOT', 'JOIN', 'PAIR', 'SCOPE',
    'SELECTED', 'OWNER_ARRANGEMENT', 'BEFORE', 'AFTER', 'ORIGINAL_IDS', 'ORIGINAL_SCOPES',
    'DISPOSITIONS', 'RESIDUALS', 'FINAL_PROOF_KEYS', 'NATIVE_PREREQUISITE_PROFILE', 'NATIVE_PREDICATES',
    'FILE_LIMIT', 'REQUEST_LIMIT', 'DECISION_LIMIT', 'HOLD_SECONDS', 'M4_PINS', 'M4_DECISION',
    'ORIGINAL_L04_TEXT', 'ORIGINAL_L04_BINDING'}
G3_FUNCTIONS = {'need', 'sha', 'encode', 'parse', 'exact', 'digest', 'integer', 'descriptor',
    'receive_exact_m4', 'validate_g1_facts', 'validate_public_request', 'validate_decision',
    'validate_public_final_request', 'validate_row_decisions', 'validate_final_decision',
    'validate_original_receipt'}
PROOF_FUNCTIONS = {'require', 'sha', 'encode', 'digest', 'integer', 'exact', 'parse', 'descriptor',
    'pins_contract', 'source_identity', 'validate_root', 'bounded_g1_facts', 'validate_final',
    'validate_receipt', 'receive_retained_m4'}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()


def source_tree(path):
    return ast.parse(path.read_bytes())


def pure(path, *, proof=False):
    """Do not import either original/candidate module or compile effect functions."""
    selected = []
    functions = PROOF_FUNCTIONS if proof else G3_FUNCTIONS
    for node in source_tree(path).body:
        if isinstance(node, ast.Assign):
            names = {x.id for target in node.targets for x in ast.walk(target) if isinstance(x, ast.Name)}
            if proof or names & G3_CONSTANTS:
                # These are inspected public constant expressions. Refuse API,
                # process, filesystem and arbitrary constant-call evaluation.
                for part in ast.walk(node.value):
                    if isinstance(part, ast.Call):
                        safe = isinstance(part.func, ast.Name) and part.func.id in {'dict', 'list', 'set', 'frozenset', 'zip', 'range'}
                        safe |= isinstance(part.func, ast.Attribute) and part.func.attr == 'split'
                        if not safe:
                            raise AssertionError('UNINSPECTED_CONSTANT_CALL')
                selected.append(node)
        elif isinstance(node, ast.ClassDef) and node.name == 'Refusal':
            selected.append(node)
        elif isinstance(node, ast.FunctionDef) and node.name in functions:
            if node.decorator_list:
                raise AssertionError('PURE_FUNCTION_DECORATOR')
            selected.append(node)
    namespace = {'hashlib': hashlib, 'json': json, 're': re}
    exec(compile(ast.Module(body=selected, type_ignores=[]), '<pure-prospective-binding>', 'exec'), namespace)
    return namespace


def fixture_helpers():
    path = WORKER / 'test_hosted_validate.py'
    spec = importlib.util.spec_from_file_location('synthetic_public_fixture_helpers', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def retained_bodies():
    path = WORKER / 'review-packet-m4-join-v2' / 'retained-public-m4'
    return {name: (path / name).read_bytes() for name in ('M4_ROOT_RECEIVING.json',
        'M4_INDEPENDENT_REPORT.md', 'M4_INDEPENDENT_RESULT.json', 'M4_FINAL_CHECK.json')}


def synthetic_documents(g, p):
    """Fabricated public-schema controls, never an execution/issuer attestation."""
    fixtures = fixture_helpers()
    initial, first = fixtures.component()
    final, decision = fixtures.final_documents(g)
    bodies = {name: encoded({'synthetic_public_control': name}) for name in p['PROOFS']}
    bodies['module'] = (CANDIDATE / 'g3_receiving.py').read_bytes()
    bodies['negative_applicability'] = (BASE / 'ADVERSE_APPLICABILITY.json').read_bytes()
    initial['g1_return_sha256'] = sha(bodies['g1_receiving'])
    initial['scope_return_sha256'] = sha(bodies['scope_receiving'])
    first['request_sha256'] = sha(encoded(initial))
    first['outputs'] = {p['PAIR']: initial['g1_return_sha256'], p['SCOPE']: initial['scope_return_sha256']}
    first['issued_unix_ms'] = initial['issued_unix_ms'] + 100
    first['expires_unix_ms'] = initial['expires_unix_ms']
    bodies['root_consumption'] = encoded(first)
    final['schema'] = 'dg16.g3-original-receiving-request.v3'
    final['initial_request_sha256'] = sha(encoded(initial))
    final['shared_window_started_unix_ms'] = initial['issued_unix_ms']
    final['issued_unix_ms'] = initial['issued_unix_ms'] + 200
    final['expires_unix_ms'] = initial['shared_expires_unix_ms']
    final['proofs'] = {name: sha(bodies[name]) for name in g['FINAL_PROOF_KEYS']}
    final['g1_facts']['raw_receiving_sha256'] = initial['g1_return_sha256']
    final['retained_m4'] = g['receive_exact_m4'](retained_bodies())
    decision['schema'] = 'dg16.g3-root-original-decision.v3'
    decision['request_sha256'] = sha(encoded(final))
    for key in ('run_id', 'attempt', 'nonce', 'source_commit', 'source_tree', 'final_graph_sha256',
                'current_receipt_sha256', 'proofs', 'expires_unix_ms', 'retained_m4'):
        decision[key] = copy.deepcopy(final[key])
    decision['issued_unix_ms'] = final['issued_unix_ms'] + 100
    l04 = decision['original_rows'][4]
    l04.update(disposition='ACCEPTED_AT_DECLARED_SCOPE', evidence=['retained_m4_receiving'], residuals=['NONE_AT_DECLARED_SCOPE'])
    pins = json.loads((CANDIDATE / 'INDEPENDENT_PROOF_PINS.json').read_bytes())
    support = {name: encoded({'synthetic_public_control': name}) for name in p['SUPPORT']}
    began = final['issued_unix_ms'] + 100
    end = began + 100
    receipt = {
        'schema': 'dg16.independent-proof-consumption-receipt.v2', 'consumer': p['VERSION'], 'authority': 'NONE',
        'source_commit': p['SOURCE'], 'source_tree': p['TREE'], 'run_id': initial['run_id'], 'attempt': 1,
        'nonce': initial['nonce'], 'initial_request_sha256': sha(encoded(initial)), 'final_request_sha256': sha(encoded(final)),
        'first_root_decision_sha256': sha(encoded(first)),
        'proof_bodies': {name: p['descriptor'](raw) for name, raw in bodies.items()},
        'support_bodies': {name: p['descriptor'](raw) for name, raw in support.items()},
        'bookends_sha256': 'b' * 64, 'bookends_bytes': 1000,
        'consumer_sha256': pins['consumer_sha256'], 'scope_module_sha256': pins['scope_module_sha256'],
        'compiler_sha256': p['COMPILER_SHA'], 'owner_sha256': p['OWNER_SHA'], 'original_scope_sha256': p['SCOPE_SHA'],
        'adverse_sha256': p['ADVERSE_SHA'], 'initial_graph_sha256': final['initial_graph_sha256'],
        'final_graph_sha256': final['final_graph_sha256'], 'current_receipt_sha256': final['current_receipt_sha256'],
        'predicate_results': {name: 'OBSERVED_TRUE' for name in p['PREDICATES']},
        'native_observation_sha256': [final['proofs']['final_native']] * 2,
        'maintained_g1_receiving_sha256': initial['g1_return_sha256'],
        'started_unix_ms': began, 'finished_unix_ms': end, 'elapsed_ns': 100000000,
        'shared_expires_unix_ms': initial['shared_expires_unix_ms'],
        'final_decision_remaining_ms': initial['shared_expires_unix_ms'] - end,
        'enclosing_reserve_remaining_ms': 240000,
        'aggregate_input_bytes': sum(map(len, bodies.values())) + sum(map(len, support.values()))
             + len(encoded(initial)) + len(encoded(final)) + sum(map(len, retained_bodies().values())) + 1024,
        'limits': p['LIMITS'],
        'measurement_scope': 'ENTRY_THROUGH_INPUT_CLOSURE_OUTPUT_PERSISTENCE_CHARGED_BY_ENCLOSING_HOST',
        'budget_scope': 'ORIGINAL_SHARED_WINDOW_AND_CORE_INTERVAL_NO_RESET_OR_SUBTRACTION',
        'evidence_scope': 'ACTUALLY_EXECUTED_SOURCE_BOUND_SEMANTIC_BODY_CONSUMPTION',
        'status': 'OBSERVATIONS_RETAINED_FOR_ROOT_AND_INDEPENDENT_REVIEW',
        'original_rows': {name: 'PARTIAL_REQUIRES_EPISODE_SPECIFIC_ROOT_AND_INDEPENDENT_APPLICABILITY' for name in p['IDS']},
        'natural_L04': 'NOT_RECEIVED', 'full_G2': 'NOT_RECEIVED', 'whole_DG16': 'NOT_AWARDED',
        'global_liveness': 'NOT_ESTABLISHED', 'retirement_or_transfer': 'NOT_PERFORMED',
        'original_awards': [], 'review_or_admission_issued': False, 'limitations': p['LIMITATIONS'],
        'retained_m4': copy.deepcopy(final['retained_m4']),
    }
    projection = {
        'schema': 'dg16.g3-root-original-decision-retained.v3', 'authority': 'ROOT_GOVERNOR_RECORDED_DECISION',
        'source_commit': g['SOURCE_COMMIT'], 'source_tree': g['SOURCE_TREE'], 'run_id': initial['run_id'], 'attempt': 1,
        'request_sha256': sha(encoded(final)), 'decision_sha256': sha(encoded(decision)), 'control_commit': 'b' * 40,
        'current_graph_sha256': final['final_graph_sha256'], 'current_receipt_sha256': final['current_receipt_sha256'],
        'independent_review_sha256': decision['independent_review_sha256'],
        'source_applicability_review_sha256': decision['source_applicability_review_sha256'],
        'original_rows': copy.deepcopy(decision['original_rows']), 'gate_decisions': copy.deepcopy(decision['gate_decisions']),
        'whole_DG16_awarded': False, 'full_g2': 'NOT_DISPATCHED_OR_CONSUMED_IN_THIS_HOST',
        'status': 'ROOT_G3_DECISION_RETAINED', 'automatic_awards': False, 'retained_m4': copy.deepcopy(final['retained_m4']),
    }
    all_bodies = {**bodies, **retained_bodies()}
    return dict(initial=initial, first=first, final=final, decision=decision, receipt=receipt,
                projection=projection, bodies=all_bodies, pins=pins)


class BindingSpliceTests(unittest.TestCase):
    def namespaces(self):
        self.assertTrue((CANDIDATE / 'g3_receiving.py').exists(), 'MISSING_PROSPECTIVE_HOST_SPLICE')
        return pure(CANDIDATE / 'g3_receiving.py'), pure(CANDIDATE / 'proof_consumer.py', proof=True)

    def documents(self):
        g, p = self.namespaces()
        return g, p, synthetic_documents(g, p)

    def test_frozen_v2_cannot_receive_separate_retained_input(self):
        g = pure(BASE / 'g3_receiving.py')
        request, _ = fixture_helpers().final_documents(g)
        request['retained_m4'] = {'synthetic': True}
        with self.assertRaisesRegex(Exception, 'CLOSED_SCHEMA_REFUSED'):
            g['validate_public_final_request'](encoded(request))

    def test_new_binding_traverses_request_decision_and_retained_receipt(self):
        g, p, d = self.documents()
        m4 = retained_bodies()
        self.assertEqual(g['validate_public_final_request'](encoded(d['final']), retained_bodies=m4), d['final'])
        self.assertEqual(g['validate_final_decision'](encoded(d['decision']), d['final'], sha(encoded(d['final'])),
                         time.time_ns() // 1000000, retained_bodies=m4), d['decision'])
        self.assertEqual(g['validate_original_receipt'](encoded(d['projection']), retained_bodies=m4), d['projection'])
        self.assertEqual(g['receive_exact_m4'](m4), p['receive_retained_m4'](m4))
        self.assertEqual(d['projection']['original_rows'][0]['disposition'], 'PARTIAL_SCOPE_ONLY')
        self.assertFalse(d['projection']['whole_DG16_awarded'])

    def test_independent_final_request_consumes_all_original_proofs_and_retained_bytes(self):
        _, p, d = self.documents()
        self.assertEqual(p['validate_final'](encoded(d['final']), encoded(d['initial']), d['initial'], d['bodies'], d['pins']), d['final'])
        changed = dict(d['bodies']); changed['final_native'] += b'changed'
        with self.assertRaisesRegex(Exception, 'FINAL_PROOF_BODY_JOIN_REFUSED'):
            p['validate_final'](encoded(d['final']), encoded(d['initial']), d['initial'], changed, d['pins'])

    def test_independent_receipt_preserves_local_natural_absence(self):
        _, p, d = self.documents()
        args = (encoded(d['initial']), encoded(d['final']), encoded(d['first']), d['pins'])
        value = p['validate_receipt'](encoded(d['receipt']), *args, retained_bodies=retained_bodies())
        self.assertEqual(value['natural_L04'], 'NOT_RECEIVED')
        self.assertEqual(value['original_awards'], [])
        for wrong in ('OBSERVED_TRUE', 'ACCEPTED_RETAINED_M4_AS_LOCAL'):
            changed = copy.deepcopy(d['receipt']); changed['natural_L04'] = wrong
            with self.assertRaisesRegex(Exception, 'RECEIPT_CLOSED_SCOPE_REFUSED'):
                p['validate_receipt'](encoded(changed), *args, retained_bodies=retained_bodies())

    def test_no_binding_stage_accepts_missing_or_mutated_retained_bodies(self):
        g, p, d = self.documents()
        bad = retained_bodies(); bad['M4_ROOT_RECEIVING.json'] += b'\n'
        for m4 in (None, bad):
            for name, call in (
                ('request', lambda: g['validate_public_final_request'](encoded(d['final']), retained_bodies=m4)),
                ('decision', lambda: g['validate_final_decision'](encoded(d['decision']), d['final'], sha(encoded(d['final'])),
                                       time.time_ns() // 1000000, retained_bodies=m4)),
                ('retained_receipt', lambda: g['validate_original_receipt'](encoded(d['projection']), retained_bodies=m4)),
                ('independent_receipt', lambda: p['validate_receipt'](encoded(d['receipt']), encoded(d['initial']),
                    encoded(d['final']), encoded(d['first']), d['pins'], retained_bodies=m4))):
                with self.subTest(stage=name, missing=m4 is None), self.assertRaises(Exception):
                    call()

    def test_mutated_transport_binding_refused_at_every_join(self):
        g, p, d = self.documents()
        for name in ('final', 'decision', 'projection', 'receipt'):
            changed = copy.deepcopy(d[name]); changed['retained_m4']['prior_accepted_run'] = '44076469957'
            with self.subTest(stage=name), self.assertRaises(Exception):
                if name == 'final':
                    g['validate_public_final_request'](encoded(changed), retained_bodies=retained_bodies())
                elif name == 'decision':
                    g['validate_final_decision'](encoded(changed), d['final'], sha(encoded(d['final'])),
                        time.time_ns() // 1000000, retained_bodies=retained_bodies())
                elif name == 'projection':
                    g['validate_original_receipt'](encoded(changed), retained_bodies=retained_bodies())
                else:
                    p['validate_receipt'](encoded(changed), encoded(d['initial']), encoded(d['final']),
                        encoded(d['first']), d['pins'], retained_bodies=retained_bodies())

    def test_new_input_cannot_enter_global_proof_population(self):
        g, _, d = self.documents()
        changed = copy.deepcopy(d['final']); changed['proofs']['retained_m4_receiving'] = 'b' * 64
        with self.assertRaises(Exception):
            g['validate_public_final_request'](encoded(changed), retained_bodies=retained_bodies())
        original = pure(BASE / 'g3_receiving.py')
        for name in ('ORIGINAL_IDS', 'ORIGINAL_SCOPES', 'DISPOSITIONS', 'RESIDUALS', 'FINAL_PROOF_KEYS'):
            self.assertEqual(g[name], original[name])

    def test_current_decision_binding_and_expiry_remain_mandatory(self):
        g, _, d = self.documents()
        for field in ('nonce', 'current_receipt_sha256', 'request_sha256'):
            changed = copy.deepcopy(d['decision']); changed[field] = 'c' * (32 if field == 'nonce' else 64)
            with self.subTest(field=field), self.assertRaises(Exception):
                g['validate_final_decision'](encoded(changed), d['final'], sha(encoded(d['final'])),
                    time.time_ns() // 1000000, retained_bodies=retained_bodies())
        with self.assertRaisesRegex(Exception, 'FINAL_ROOT_DECISION_EXPIRED_OR_FUTURE'):
            g['validate_final_decision'](encoded(d['decision']), d['final'], sha(encoded(d['final'])),
                d['final']['expires_unix_ms'], retained_bodies=retained_bodies())

    def test_retained_l04_cannot_award_q06_or_whole_g3(self):
        g, _, d = self.documents()
        changed = copy.deepcopy(d['decision']); changed['original_rows'][0]['evidence'] = ['retained_m4_receiving']
        with self.assertRaisesRegex(Exception, 'FINAL_ORIGINAL_ROW_SCOPE'):
            g['validate_row_decisions'](changed['original_rows'], changed['gate_decisions'], retained_bodies=retained_bodies())
        changed = copy.deepcopy(d['decision']); changed['gate_decisions']['G3']['disposition'] = 'ACCEPTED_AT_DECLARED_SCOPE'
        with self.assertRaisesRegex(Exception, 'PARTIAL_ROWS_CANNOT_GRANT_COMPLETE_G3_SCOPE'):
            g['validate_row_decisions'](changed['original_rows'], changed['gate_decisions'], retained_bodies=retained_bodies())
        for gate in ('G1', 'G3'):
            changed = copy.deepcopy(d['decision']); changed['gate_decisions'][gate]['evidence'] = ['retained_m4_receiving']
            with self.subTest(gate=gate), self.assertRaisesRegex(Exception, 'FINAL_GATE_DECISION_SCOPE'):
                g['validate_row_decisions'](changed['original_rows'], changed['gate_decisions'], retained_bodies=retained_bodies())

    def test_original_proof_predicates_and_bounds_preserved(self):
        _, new = self.namespaces(); old = pure(BASE / 'proof_consumer.py', proof=True)
        for name in ('PROOFS', 'SUPPORT', 'PREDICATES', 'LIMITATIONS', 'BODY_MAX', 'AGGREGATE_MAX',
                     'CONSUMER_SECONDS', 'FINAL_SECONDS', 'RESERVE_SECONDS', 'SELECTED_READS', 'BLOCKED'):
            self.assertEqual(new[name], old[name], name)
        expected = dict(old['LIMITS']); expected['retained_m4_input_bodies'] = 4; expected['total_input_bodies'] += 4
        self.assertEqual(new['LIMITS'], expected)
        self.assertEqual(set(new['FILES']) - set(old['FILES']), set(retained_bodies()))

    def test_native_guard_and_original_proof_semantics_unchanged(self):
        for file, names in (
            ('g3_receiving.py', ('context', 'consume', 'receive', 'validate_g1_facts', 'g1_public_facts', 'observe', 'actual_upstream')),
            ('proof_consumer.py', ('graph_contract', 'canonical_input_contract', 'known_input_contract',
                                  'native_identity', 'bounded_timer', 'validate_first', 'validate_root'))):
            old = {n.name: n for n in source_tree(BASE / file).body if isinstance(n, ast.FunctionDef)}
            new = {n.name: n for n in source_tree(CANDIDATE / file).body if isinstance(n, ast.FunctionDef)}
            for name in names:
                with self.subTest(file=file, function=name):
                    self.assertEqual(ast.dump(old[name], include_attributes=False), ast.dump(new[name], include_attributes=False))

    def test_census_staging_and_export_call_sites_are_bound(self):
        g3 = {n.name: n for n in source_tree(CANDIDATE / 'g3_receiving.py').body if isinstance(n, ast.FunctionDef)}
        run = {n.name: n for n in source_tree(CANDIDATE / 'run.py').body if isinstance(n, ast.FunctionDef)}
        held = ast.dump(g3['held_files'], include_attributes=False)
        expected_census = ast.parse("names += [private/'g3-retained-m4'/name for name in M4_PINS]").body[0]
        self.assertIn(ast.dump(expected_census, include_attributes=False), held)
        for name in ('prepare_final_request', 'decide'):
            self.assertIn('retained_m4_private', ast.unparse(g3[name]), name)
        self.assertIn('retained_bodies', ast.unparse(g3['read_root_decision']))
        for name in ('stage_received_inputs', 'closed_effect_observations', 'validated_effects', 'emit_root_request'):
            text = ast.unparse(run[name])
            self.assertTrue('retained_m4' in text or 'retained_bodies' in text, name)
        for name in ('prepare_final_request', 'decide'):
            for node in ast.walk(g3[name]):
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in (
                    'validate_public_final_request', 'validate_original_receipt'):
                    self.assertIn('retained_bodies', [k.arg for k in node.keywords])
        proof = {n.name: n for n in source_tree(CANDIDATE / 'proof_consumer.py').body if isinstance(n, ast.FunctionDef)}
        self.assertIn('RETAINED_M4_FILES', ast.unparse(proof['check_bodies']))
        self.assertIn('retained_bodies', ast.unparse(proof['execute']))

    def test_direct_source_pins_match_candidate_bytes(self):
        assignments = {n.targets[0].id: n.value for n in source_tree(CANDIDATE / 'run.py').body
                       if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name)}
        modules = ast.literal_eval(assignments['MODULE_PINS']); data = ast.literal_eval(assignments['G3_DATA_PINS'])
        for name in ('g3_receiving', 'proof_consumer'):
            self.assertEqual(modules[name], sha((CANDIDATE / (name + '.py')).read_bytes()))
        pins = json.loads((CANDIDATE / 'INDEPENDENT_PROOF_PINS.json').read_bytes())
        self.assertEqual(pins['scope_module_sha256'], modules['g3_receiving'])
        self.assertEqual(pins['consumer_sha256'], modules['proof_consumer'])
        self.assertEqual(data['INDEPENDENT_PROOF_PINS.json'], sha((CANDIDATE / 'INDEPENDENT_PROOF_PINS.json').read_bytes()))
        self.assertEqual((CANDIDATE / 'SOURCE_MANIFEST.json').read_bytes(), (BASE / 'SOURCE_MANIFEST.json').read_bytes())
        exporter = source_tree(HERE / 'entry/public_export.py')
        export_pin = next(n.value.value for n in exporter.body if isinstance(n, ast.Assign)
                          and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'CORE_RUN_SHA256')
        self.assertEqual(export_pin, sha((CANDIDATE / 'run.py').read_bytes()))

    def test_pure_test_namespaces_exclude_effects_and_host_api(self):
        for namespace in self.namespaces():
            for name in ('execute', 'context', 'consume', 'decide', 'prepare', 'os', 'Path', 'subprocess', 'urllib'):
                self.assertNotIn(name, namespace)

    def shim(self):
        path = HERE / 'g132_hosted_validate_m4.py'
        self.assertTrue(path.exists(), 'MISSING_PROSPECTIVE_SOURCE_BOUND_CALLBACK')
        spec = importlib.util.spec_from_file_location('prospective_public_validation_callback', path)
        module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        return module

    def test_pro_callback_joins_current_final_request_decision_and_exact_m4(self):
        _, _, d = self.documents(); shim = self.shim()
        value = shim.validate_bytes((CANDIDATE / 'g3_receiving.py').read_bytes(), 'original-final',
            d['final']['run_id'], encoded(d['final']), encoded(d['decision']), retained_bodies=retained_bodies())
        self.assertEqual(value['request_sha256'], sha(encoded(d['final'])))
        self.assertEqual(value['decision_sha256'], sha(encoded(d['decision'])))
        self.assertEqual(value['retained_m4_binding_sha256'], sha(encoded(d['final']['retained_m4'])))
        self.assertFalse(value['native_history_authenticated'])
        self.assertFalse(value['original_acceptance'])
        self.assertEqual(value['new_awards'], [])

    def test_pro_callback_refuses_old_source_missing_bodies_and_expiry(self):
        _, _, d = self.documents(); shim = self.shim()
        args = ('original-final', d['final']['run_id'], encoded(d['final']))
        with self.assertRaisesRegex(Exception, 'EXACT_PROSPECTIVE_G3_SOURCE_REQUIRED'):
            shim.validate_bytes((BASE / 'g3_receiving.py').read_bytes(), *args, retained_bodies=retained_bodies())
        with self.assertRaises(Exception):
            shim.validate_bytes((CANDIDATE / 'g3_receiving.py').read_bytes(), *args)
        expired = copy.deepcopy(d['final'])
        for key in ('shared_window_started_unix_ms', 'issued_unix_ms', 'expires_unix_ms'):
            expired[key] -= 700000
        with self.assertRaisesRegex(Exception, 'ORIGINAL_REQUEST_NOT_CURRENT'):
            shim.validate_bytes((CANDIDATE / 'g3_receiving.py').read_bytes(), 'original-final', expired['run_id'],
                encoded(expired), retained_bodies=retained_bodies())


if __name__ == '__main__':
    unittest.main(verbosity=2)
