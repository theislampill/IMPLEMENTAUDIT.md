#!/usr/bin/env python3
"""Deterministic isolated source construction; never import or run host code."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
WORKER = HERE.parent
BASE = HERE / 'baseline'
OUT = HERE / 'host'
BASE_PINS = {
    'g3_receiving.py': (153706, 'b85cca1550ff8e7c1c89778180e53a5c70f306f0c8725ba60ef3ccd4bbc3a6ad'),
    'proof_consumer.py': (64350, 'a760c0f381da40d4b01c46146fbb947aa919bedb59fbf2758dcc68d5c606a0a5'),
    'run.py': (160385, '5e8f800a384ae80fa280bffefb4348263fe6de77b6e905df4e19bf4a176ccf5a'),
    'INDEPENDENT_PROOF_PINS.json': (732, 'b393f2a79b032b28db5c3c5edca8d63a9a694bf48feb4d127059c21902dc7293'),
    'SOURCE_MANIFEST.json': (495602, '7cd236053a3f27003aad3d3cd30b37ef95b09b0eea786f5896155af1498d8117'),
}
ROW_SOURCE = WORKER / 'review-packet-m4-join-v2/retained_m4_join_candidate.py'
ROW_SHA = '4323cfd28e169bd38919e2086f4f45b892bf2e1521a5cd7a59b6eb6f860f37a9'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()


def once(text, before, after):
    if text.count(before) != 1:
        raise ValueError('EXACT_SPLICE_ANCHOR_REQUIRED: ' + repr(before[:90]))
    return text.replace(before, after, 1)


def node(source, name, kind=ast.FunctionDef):
    found = [n for n in ast.parse(source).body if isinstance(n, kind) and
             (getattr(n, 'name', None) == name if kind != ast.Assign else
              len(n.targets) == 1 and isinstance(n.targets[0], ast.Name) and n.targets[0].id == name)]
    if len(found) != 1:
        raise ValueError('EXACT_SOURCE_NODE_REQUIRED: ' + name)
    return found[0]


def segment(source, n):
    return ''.join(source.splitlines(keepends=True)[n.lineno - 1:n.end_lineno]).replace('\r\n', '\n')


def replace_node(source, n, replacement):
    lines = source.splitlines(keepends=True)
    return ''.join(lines[:n.lineno - 1]) + replacement.rstrip('\n') + '\n' + ''.join(lines[n.end_lineno:])


def function(source, name, changes=(), replacement=None):
    n = node(source, name)
    text = segment(source, n) if replacement is None else replacement
    for before, after in changes:
        text = once(text, before, after)
    return replace_node(source, n, text)


def assignment(source, name, expression):
    return replace_node(source, node(source, name, ast.Assign), name + ' = ' + expression)


def add_field(source, name, field):
    n = node(source, name, ast.Assign)
    value = n.value
    if not (isinstance(value, ast.Call) and isinstance(value.func, ast.Attribute)
            and value.func.attr == 'split' and isinstance(value.func.value, ast.Constant)):
        raise ValueError('CLOSED_FIELD_CONSTANT_REQUIRED')
    return assignment(source, name, repr(value.func.value.value + ' ' + field) + '.split()')


def refusal_literals(source):
    result = set()
    for n in ast.walk(ast.parse(source)):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ('need', 'require') and len(n.args) >= 2:
            value = n.args[1]
            if isinstance(value, ast.Constant) and isinstance(value.value, str) and re.fullmatch('[A-Z][A-Z0-9_]+', value.value):
                result.add(value.value)
    return result


def g3_splice(source, reviewed):
    constants = ('M4_PINS', 'ORIGINAL_L04_TEXT', 'ORIGINAL_L04_BINDING', 'M4_DECISION')
    helpers = '\n'.join(segment(reviewed, node(reviewed, name, ast.Assign)) for name in constants)
    helpers += '\n' + '\n'.join(segment(reviewed, node(reviewed, name)) for name in
                                ('descriptor', 'receive_exact_m4', 'read_m4_bodies'))
    helpers += '''
def retained_m4_private(api):
    """Actual private copies, separately staged from the original private bundle."""
    _, private, _, _ = context(api)
    return read_m4_bodies(private/'g3-retained-m4')

'''
    source = once(source, 'class Refusal(Exception):', helpers + '\nclass Refusal(Exception):')
    rows = segment(reviewed, node(reviewed, 'validate_candidate_rows'))
    rows = once(rows, 'def validate_candidate_rows(', 'def validate_row_decisions(')
    source = function(source, 'validate_row_decisions', replacement=rows)
    source = function(source, 'prepare', [
        ("    diagnostic.phase('INPUTS')\n", "    diagnostic.phase('INPUTS')\n    receive_exact_m4(retained_m4_private(api))\n")])
    source = function(source, 'held_files', [
        ("    names += [private/'NATIVE_PREREQUISITE_RECEIVING.json']",
         "    names += [private/'NATIVE_PREREQUISITE_RECEIVING.json']\n    # Exact prior acceptance inputs are held separately from current native proofs.\n    names += [private/'g3-retained-m4'/name for name in M4_PINS]")])
    source = function(source, 'prepare_final_request', [
        ("    g = private/'g3'", "    g = private/'g3'\n    retained_bodies = retained_m4_private(api)\n    retained_m4 = receive_exact_m4(retained_bodies)"),
        ("schema='dg16.g3-original-receiving-request.v2'", "schema='dg16.g3-original-receiving-request.v3'"),
        ("initial_request_sha256=sha(read_file(private/'G3_ROOT_REQUEST.json',REQUEST_LIMIT)), proofs=proofs,",
         "initial_request_sha256=sha(read_file(private/'G3_ROOT_REQUEST.json',REQUEST_LIMIT)), proofs=proofs,\n        retained_m4=retained_m4,"),
        ("    validate_public_final_request(raw)", "    validate_public_final_request(raw, retained_bodies=retained_bodies)")])
    source = function(source, 'validate_public_final_request', [
        ('def validate_public_final_request(raw):', 'def validate_public_final_request(raw, *, retained_bodies=None):'),
        ("'shared_window_seconds','status'))", "'shared_window_seconds','status','retained_m4'))"),
        ("value['schema']=='dg16.g3-original-receiving-request.v2'", "value['schema']=='dg16.g3-original-receiving-request.v3'"),
        ("    need(encode(value)==raw,'PUBLIC_CANONICAL_BYTES')",
         "    need(value['retained_m4'] == receive_exact_m4(retained_bodies), 'FINAL_RETAINED_M4_BINDING')\n    need(encode(value)==raw,'PUBLIC_CANONICAL_BYTES')")])
    source = function(source, 'validate_final_decision', [
        ('def validate_final_decision(raw,request,request_sha,now_unix_ms):',
         'def validate_final_decision(raw,request,request_sha,now_unix_ms, *, retained_bodies=None):'),
        ("'retirement_or_transfer','issued_unix_ms','expires_unix_ms'))",
         "'retirement_or_transfer','issued_unix_ms','expires_unix_ms','retained_m4'))"),
        ("value['schema']=='dg16.g3-root-original-decision.v2'", "value['schema']=='dg16.g3-root-original-decision.v3'"),
        ("'proofs','expires_unix_ms'):", "'proofs','expires_unix_ms','retained_m4'):"),
        ("    validate_row_decisions(value['original_rows'],value['gate_decisions'])",
         "    need(value['retained_m4'] == receive_exact_m4(retained_bodies), 'FINAL_RETAINED_M4_BINDING')\n    validate_row_decisions(value['original_rows'],value['gate_decisions'], retained_bodies=retained_bodies)")])
    source = function(source, 'read_root_decision', [
        ('def read_root_decision(request, request_sha, deadline, final=False):',
         'def read_root_decision(request, request_sha, deadline, final=False, *, retained_bodies=None):'),
        ('decision = validate(decision_raw, request, request_sha, int(time.time()*1000))',
         "decision = validate(decision_raw, request, request_sha, int(time.time()*1000),\n                                    **({'retained_bodies': retained_bodies} if final else {}))")])
    source = function(source, 'decide', [
        ('    request=validate_public_final_request(raw)',
         '    retained_bodies=retained_m4_private(api)\n    request=validate_public_final_request(raw, retained_bodies=retained_bodies)'),
        ("read_root_decision(request,sha(raw),held['expires_monotonic'],True)",
         "read_root_decision(request,sha(raw),held['expires_monotonic'],True, retained_bodies=retained_bodies)"),
        ("schema='dg16.g3-root-original-decision-retained.v2'", "schema='dg16.g3-root-original-decision-retained.v3'"),
        ("original_rows=decision['original_rows'],gate_decisions=decision['gate_decisions'],",
         "original_rows=decision['original_rows'],gate_decisions=decision['gate_decisions'],\n        retained_m4=decision['retained_m4'],"),
        ('    validate_original_receipt(encode(projection))',
         '    validate_original_receipt(encode(projection), retained_bodies=retained_bodies)')])
    source = function(source, 'validate_original_receipt', [
        ('def validate_original_receipt(raw):', 'def validate_original_receipt(raw, *, retained_bodies=None):'),
        ("'whole_DG16_awarded','full_g2','status','automatic_awards'))",
         "'whole_DG16_awarded','full_g2','status','automatic_awards','retained_m4'))"),
        ("value['schema']=='dg16.g3-root-original-decision-retained.v2'", "value['schema']=='dg16.g3-root-original-decision-retained.v3'"),
        ("    validate_row_decisions(value['original_rows'],value['gate_decisions'])",
         "    need(value['retained_m4'] == receive_exact_m4(retained_bodies), 'FINAL_RETAINED_M4_BINDING')\n    validate_row_decisions(value['original_rows'],value['gate_decisions'], retained_bodies=retained_bodies)")])
    prior = ast.literal_eval(node(source, 'REFUSAL_CODES', ast.Assign).value.args[0])
    added_codes = refusal_literals(source) - refusal_literals((BASE / 'g3_receiving.py').read_bytes().decode())
    source = assignment(source, 'REFUSAL_CODES', 'frozenset(' + repr(tuple(sorted(set(prior) | added_codes))) + ')')
    return source


INDEPENDENT_RECEIVER = '''
def receive_retained_m4(bodies):
    """Independent exact-history input receiving, never a new local transition."""
    require(type(bodies) is dict and set(bodies) == set(M4_PINS), 'RETAINED_M4_POPULATION_REFUSED')
    for name, wanted in M4_PINS.items():
        require(type(bodies[name]) is bytes and descriptor(bodies[name]) == wanted, 'RETAINED_M4_BODY_REFUSED')
    root = parse(bodies['M4_ROOT_RECEIVING.json'], maximum=BODY_MAX)
    expected = {
        'schema': 'implementaudit.Root-original-scope-receiving.v1', 'receiver': '/root',
        'decision': 'ACCEPT_ORIGINAL_M4_L04_NATIVE_NATURAL_TRANSITION_AT_DECLARED_EPISODE',
        'operation': 'M4', 'criterion': 'R35-L04', 'actual_run': 44076469956,
        'launch_commit': '5d8bd6aa60b7490788b1905e2dec14701fdcef35',
        'root_consumption_commit': '1fa59671a71f3c3f22c70aa2918d02125ab98bd7',
        'missing_original_M4_predicates_at_episode': [], 'required_M4_rerun': False,
        'G132': 'UNKNOWN_NO_REPLAY', 'ancestor_JOIN': 'BLOCKED', 'Q06_whole_award': False,
        'audit_complete': False, 'native_Stop_acceptance': False, 'other_operation_awards': [],
    }
    for key, wanted in expected.items():
        require(type(root.get(key)) is type(wanted) and root[key] == wanted, 'RETAINED_M4_ACCEPTED_SCOPE_REFUSED')
    require(root['original_text'] == M4_ORIGINAL_TEXT and root['original_scope_and_binding'] == M4_ORIGINAL_BINDING,
            'RETAINED_M4_ORIGINAL_REQUIREMENT_REFUSED')
    for key, name in (('review', 'M4_INDEPENDENT_REPORT.md'), ('result', 'M4_INDEPENDENT_RESULT.json'),
                      ('final_check', 'M4_FINAL_CHECK.json')):
        require({field: root[key][field] for field in ('bytes', 'sha256')} == M4_PINS[name],
                'RETAINED_M4_ROOT_SUPPORT_REFUSED')
    return {
        'schema': 'g132.prospective-retained-m4-input-receiving.v1', 'authority': 'NONE',
        'criterion': 'R35-L04', 'original_scope': SCOPES['R35-L04'], 'prior_accepted_run': '44076469956',
        'prior_root_decision': expected['decision'], 'bodies': {name: dict(pin) for name, pin in M4_PINS.items()},
        'missing_predicates_at_prior_episode': [], 'required_m4_rerun': False,
        'currentness_transfer': False, 'new_acceptance': False, 'g132': 'UNKNOWN_NO_REPLAY',
        'source_applicability_and_live_root_decision_required_for_new_consumer': True,
    }

'''


def proof_splice(source, reviewed):
    pins = ast.literal_eval(node(reviewed, 'M4_PINS', ast.Assign).value)
    text = ast.literal_eval(node(reviewed, 'ORIGINAL_L04_TEXT', ast.Assign).value)
    binding = ast.literal_eval(node(reviewed, 'ORIGINAL_L04_BINDING', ast.Assign).value)
    declarations = 'M4_PINS = ' + repr(pins) + '\n'
    declarations += 'M4_ORIGINAL_TEXT = ' + repr(text) + '\nM4_ORIGINAL_BINDING = ' + repr(binding) + '\n'
    declarations += "RETAINED_M4_FILES = {name: 'g3-retained-m4/' + name for name in M4_PINS}\n"
    source = once(source, 'FILES = PROOFS | SUPPORT | CONTROLS',
                  declarations + 'FILES = PROOFS | SUPPORT | CONTROLS | RETAINED_M4_FILES')
    source = once(source, 'class Refusal(Exception):', INDEPENDENT_RECEIVER + '\nclass Refusal(Exception):')
    source = assignment(source, 'VERSION', repr('dg16.independent-proof-consumer.v1.r3-retained-m4'))
    limits = segment(source, node(source, 'LIMITS', ast.Assign))
    limits = once(limits, "'total_input_bodies':28", "'total_input_bodies':32,'retained_m4_input_bodies':4")
    source = replace_node(source, node(source, 'LIMITS', ast.Assign), limits)
    source = add_field(source, 'FINAL_FIELDS', 'retained_m4')
    source = add_field(source, 'RECEIPT_FIELDS', 'retained_m4')
    source = function(source, 'validate_final', [
        ("final['schema']=='dg16.g3-original-receiving-request.v2'", "final['schema']=='dg16.g3-original-receiving-request.v3'"),
        ("    exact(final['proofs'],PROOFS)",
         "    require(final['retained_m4'] == receive_retained_m4({name: bodies[name] for name in RETAINED_M4_FILES}),\n            'FINAL_RETAINED_M4_BINDING_REFUSED')\n    exact(final['proofs'],PROOFS)")])
    source = function(source, 'check_bodies', [
        ("if key not in {'module'} and key not in CONTROLS}",
         "if key not in {'module'} and key not in CONTROLS and key not in RETAINED_M4_FILES}")])
    source = function(source, 'execute', [
        ("        scope_raw=population.read('original_scope'", 
         "        retained_bodies={name: bodies[name] for name in RETAINED_M4_FILES}\n        retained_m4=receive_retained_m4(retained_bodies)\n        scope_raw=population.read('original_scope'"),
        ("'schema':'dg16.independent-proof-consumption-receipt.v1'", "'schema':'dg16.independent-proof-consumption-receipt.v2'"),
        ("'natural_L04':'NOT_RECEIVED','full_G2':'NOT_RECEIVED','whole_DG16':'NOT_AWARDED',",
         "'natural_L04':'NOT_RECEIVED','retained_m4':retained_m4,'full_G2':'NOT_RECEIVED','whole_DG16':'NOT_AWARDED',"),
        ("validate_receipt(receipt_raw,bodies['initial_request'],bodies['final_request'],bodies['root_consumption'],pins)",
         "validate_receipt(receipt_raw,bodies['initial_request'],bodies['final_request'],bodies['root_consumption'],pins,\n                                                    retained_bodies=retained_bodies)")])
    source = function(source, 'validate_receipt', [
        ('def validate_receipt(raw,initial_raw,final_raw,actual_root_raw,pins):',
         'def validate_receipt(raw,initial_raw,final_raw,actual_root_raw,pins, *, retained_bodies=None):'),
        ("    validate_root(actual_root_raw,initial_raw,initial)",
         "    validate_root(actual_root_raw,initial_raw,initial)\n    retained=receive_retained_m4(retained_bodies)\n    require(r['retained_m4'] == final['retained_m4'] == retained, 'RECEIPT_RETAINED_M4_BINDING_REFUSED')"),
        ("'schema':'dg16.independent-proof-consumption-receipt.v1'", "'schema':'dg16.independent-proof-consumption-receipt.v2'"),
        ("+len(initial_raw)+len(final_raw),AGGREGATE_MAX)",
         "+len(initial_raw)+len(final_raw)+sum(len(raw) for raw in retained_bodies.values()),AGGREGATE_MAX)")])
    return source


def run_splice(source, g3_raw, proof_raw, pin_raw):
    helper = '''
def retained_m4_packet_bodies():
    """Exact already-public source inputs; this does not assert private host custody."""
    g3=load_module('g3_receiving')
    root=Path(__file__).absolute().parent/'retained-m4'
    bodies={name:read_regular(root/name,pin['bytes']) for name,pin in g3.M4_PINS.items()}
    g3.receive_exact_m4(bodies)
    return bodies

'''
    source = once(source, 'def stage_received_inputs(output, approved):', helper + '\ndef stage_received_inputs(output, approved):')
    source = function(source, 'stage_received_inputs', [
        ("    g3 = load_module('g3_receiving')",
         "    g3 = load_module('g3_receiving')\n    # Separate public prior-acceptance input population; the private bundle is unchanged.\n    retained_m4=retained_m4_packet_bodies()\n    retained_root=private/'g3-retained-m4'\n    retained_root.mkdir(mode=0o700)\n    for name,raw in retained_m4.items():\n        E.write_once(retained_root/name,raw,len(raw))\n    g3.receive_exact_m4(g3.read_m4_bodies(retained_root))")])
    source = function(source, 'closed_effect_observations', [
        ("            public=validator(parse_json(raw) if label=='NSS_CONFIGURATION' else raw)",
         "            public=(validator(raw,retained_bodies=retained_m4_packet_bodies()) if label=='G3_ORIGINAL_RECEIPT'\n                    else validator(parse_json(raw) if label=='NSS_CONFIGURATION' else raw))")])
    source = function(source, 'validated_effects', [
        ("getattr(load_module('g3_receiving'),validator)(canonical(record['public']))==record['public']",
         "getattr(load_module('g3_receiving'),validator)(canonical(record['public']),\n                     **({'retained_bodies':retained_m4_packet_bodies()} if label=='G3_ORIGINAL_RECEIPT' else {}))==record['public']")])
    source = function(source, 'emit_root_request', [
        ("    receipt_check=lambda raw:consumer.validate_receipt(raw,initial_raw,final_raw,actual_root_raw,pins)",
         "    retained_bodies=module.read_m4_bodies(private/'g3-retained-m4') if final else None\n    receipt_check=lambda raw:consumer.validate_receipt(raw,initial_raw,final_raw,actual_root_raw,pins,\n                                                     retained_bodies=retained_bodies)"),
        ("('FINAL_REQUEST.json','G3_FINAL_REQUEST.json',module.validate_public_final_request)",
         "('FINAL_REQUEST.json','G3_FINAL_REQUEST.json',lambda raw:module.validate_public_final_request(raw,retained_bodies=retained_bodies))")])
    modules = ast.literal_eval(node(source, 'MODULE_PINS', ast.Assign).value)
    modules['g3_receiving'] = sha(g3_raw); modules['proof_consumer'] = sha(proof_raw)
    source = assignment(source, 'MODULE_PINS', repr(modules))
    data = ast.literal_eval(node(source, 'G3_DATA_PINS', ast.Assign).value)
    data['INDEPENDENT_PROOF_PINS.json'] = sha(pin_raw)
    source = assignment(source, 'G3_DATA_PINS', repr(data))
    codes = ast.literal_eval(node(source, 'KNOWN_FAILURE_CODES', ast.Assign).value)
    # Only this splice's new G3 refusal labels need new public enum entries.
    # Independent-consumer failures retain their existing wrapper category.
    more = refusal_literals(g3_raw.decode()) - refusal_literals((BASE / 'g3_receiving.py').read_bytes().decode())
    source = assignment(source, 'KNOWN_FAILURE_CODES', repr(tuple(sorted(set(codes) | more))))
    return source


def callback_splice(g3_raw):
    path = WORKER / 'review-packet-hosted-validation-v1/g132_hosted_validate.py'
    raw = path.read_bytes()
    if sha(raw) != '8c26a5c20f63e56c5529e0b472b34e4b8ed7bea972b481bf992a6b0f4ff441c4':
        raise ValueError('EXACT_ORIGINAL_CALLBACK_TEMPLATE_REQUIRED')
    source = raw.decode()
    source = assignment(source, 'SOURCE_BYTES', str(len(g3_raw)))
    source = assignment(source, 'SOURCE_SHA256', repr(sha(g3_raw)))
    old_functions = ast.literal_eval(node(source, 'PURE_FUNCTIONS', ast.Assign).value.args[0])
    old_constants = ast.literal_eval(node(source, 'PURE_CONSTANTS', ast.Assign).value.args[0])
    source = assignment(source, 'PURE_FUNCTIONS', 'frozenset(' + repr(tuple(old_functions) + ('descriptor', 'receive_exact_m4')) + ')')
    source = assignment(source, 'PURE_CONSTANTS', 'frozenset(' + repr(tuple(old_constants) +
        ('M4_PINS', 'M4_DECISION', 'ORIGINAL_L04_TEXT', 'ORIGINAL_L04_BINDING')) + ')')
    source = source.replace('EXACT_FROZEN_G3_SOURCE_REQUIRED', 'EXACT_PROSPECTIVE_G3_SOURCE_REQUIRED')
    source = function(source, 'validate_bytes', [
        ('def validate_bytes(source_raw, stage, selected_run_id, request_raw, decision_raw=None):',
         'def validate_bytes(source_raw, stage, selected_run_id, request_raw, decision_raw=None, *, retained_bodies=None):'),
        ("    owner = pure_owner(source_raw)",
         "    need(stage == 'original-final' or retained_bodies is None, 'RETAINED_M4_FINAL_STAGE_ONLY')\n    owner = pure_owner(source_raw)\n    retained_args = {'retained_bodies': retained_bodies} if stage == 'original-final' else {}"),
        ("else 'validate_public_final_request'](request_raw)",
         "else 'validate_public_final_request'](request_raw, **retained_args)"),
        ("            decision_raw, request, request_sha, time.time_ns() // 1000000)",
         "            decision_raw, request, request_sha, time.time_ns() // 1000000, **retained_args)"),
        ("    return value", "    if stage == 'original-final':\n        value['retained_m4_binding_sha256'] = sha(owner['encode'](request['retained_m4']))\n    return value")])
    reader = '''
def read_retained_m4(directory, owner):
    """Fresh exact readonly public bodies; no historical custody is inferred."""
    directory = Path(directory)
    need(directory.is_absolute() and directory.resolve(strict=True) == directory, 'M4_CANONICAL_DIRECTORY')
    start = directory.lstat()
    need(stat.S_ISDIR(start.st_mode) and start.st_uid == os.geteuid() and not start.st_mode & 0o022,
         'M4_OWNED_DIRECTORY')
    bodies = {}
    for name, pin in owner['M4_PINS'].items():
        path = directory/name
        need(stat.S_IMODE(path.lstat().st_mode) in (0o400, 0o444), 'M4_READONLY_BODY_REQUIRED')
        bodies[name] = read_pinned(path, pin['sha256'], pin['bytes'])
    end = directory.lstat()
    need((start.st_dev,start.st_ino,start.st_mode,start.st_uid,start.st_gid,start.st_mtime_ns,start.st_ctime_ns)
         == (end.st_dev,end.st_ino,end.st_mode,end.st_uid,end.st_gid,end.st_mtime_ns,end.st_ctime_ns),
         'M4_DIRECTORY_CHANGED')
    owner['receive_exact_m4'](bodies)
    return bodies

'''
    source = once(source, 'def main():', reader + '\ndef main():')
    source = function(source, 'main', [
        ("    parser.add_argument('--decision-sha256')", "    parser.add_argument('--decision-sha256')\n    parser.add_argument('--retained-m4-directory', type=Path)"),
        ("    value = validate_bytes(source, args.stage, args.run_id, request, decision)",
         "    need((args.stage == 'original-final') == (args.retained_m4_directory is not None),\n         'RETAINED_M4_FINAL_STAGE_ONLY')\n    retained = read_retained_m4(args.retained_m4_directory, pure_owner(source)) if args.retained_m4_directory is not None else None\n    value = validate_bytes(source, args.stage, args.run_id, request, decision, retained_bodies=retained)")])
    source = source.replace('g132.exact-original-public-g3-validation.v1', 'g132.prospective-retained-m4-public-g3-validation.v1')
    source = source.replace('STRICT_ORIGINAL_PUBLIC_SCHEMA_BYTES_TIME_AND_SELECTED_RUN_ONLY',
                            'STRICT_PROSPECTIVE_PUBLIC_SCHEMA_BYTES_TIME_SELECTED_RUN_AND_RETAINED_M4_ONLY')
    source = source.replace('exact original public-schema validator', 'exact prospective public-schema validator')
    source = source.replace('Read-only Pro callback shim for actual received public G3 documents.',
                            'Read-only prospective Pro callback for public G3 documents and retained M4.')
    source = source.replace('Only byte-pinned original pure validator definitions are compiled.',
                            'Only byte-pinned prospective pure validator definitions are compiled.')
    return source.encode()


def main():
    raw = {}
    for name, (length, pin) in BASE_PINS.items():
        raw[name] = (BASE / name).read_bytes()
        if len(raw[name]) != length or sha(raw[name]) != pin:
            raise ValueError('BASELINE_PIN_MISMATCH: ' + name)
    reviewed_raw = ROW_SOURCE.read_bytes()
    if sha(reviewed_raw) != ROW_SHA:
        raise ValueError('REVIEWED_V2_ROW_SOURCE_REQUIRED')
    reviewed = reviewed_raw.decode()
    g3 = g3_splice(raw['g3_receiving.py'].decode(), reviewed).encode()
    proof = proof_splice(raw['proof_consumer.py'].decode(), reviewed).encode()
    pins = json.loads(raw['INDEPENDENT_PROOF_PINS.json'])
    pins.update(scope_module_sha256=sha(g3), consumer_sha256=sha(proof))
    pin_raw = encoded(pins)
    run = run_splice(raw['run.py'].decode(), g3, proof, pin_raw).encode()
    callback = callback_splice(g3)
    compile(callback, '<prospective-readonly-callback-syntax-only>', 'exec')
    (HERE / 'g132_hosted_validate_m4.py').write_bytes(callback)
    outer_root = HERE / 'baseline-outer/qualification/dg16-r5-g1-hosted-entry'
    export_raw = (outer_root / 'public_export.py').read_bytes()
    if sha(export_raw) != '33099addf32f5528e1030dc3211dca8dfb91457ef57951cfc3e2e4aa34ca6b8c':
        raise ValueError('EXACT_PUBLIC_EXPORTER_BASELINE_REQUIRED')
    export_new = assignment(export_raw.decode(), 'CORE_RUN_SHA256', repr(sha(run))).encode()
    compile(export_new, '<prospective-public-export-syntax-only>', 'exec')
    (HERE / 'entry').mkdir(exist_ok=True)
    (HERE / 'entry/public_export.py').write_bytes(export_new)
    generated = {'g3_receiving.py': g3, 'proof_consumer.py': proof, 'run.py': run,
                 'INDEPENDENT_PROOF_PINS.json': pin_raw, 'SOURCE_MANIFEST.json': raw['SOURCE_MANIFEST.json']}
    OUT.mkdir(exist_ok=True)
    rows = []
    patches = []
    for name, body in generated.items():
        if name.endswith('.py'):
            compile(body, '<prospective-source-syntax-only>/' + name, 'exec')
        (OUT / name).write_bytes(body)
        rows.append({'path': 'host/' + name, 'bytes': len(body), 'sha256': sha(body)})
        if name.endswith('.py'):
            patches.extend(difflib.unified_diff(raw[name].decode().splitlines(keepends=False),
                body.decode().splitlines(keepends=False), fromfile='baseline/' + name, tofile='host/' + name, lineterm=''))
    m4_pins = ast.literal_eval(node(reviewed, 'M4_PINS', ast.Assign).value)
    (OUT / 'retained-m4').mkdir(exist_ok=True)
    for name, pin in m4_pins.items():
        body = (WORKER / 'review-packet-m4-join-v2/retained-public-m4' / name).read_bytes()
        if len(body) != pin['bytes'] or sha(body) != pin['sha256']:
            raise ValueError('RETAINED_PUBLIC_M4_PIN')
        (OUT / 'retained-m4' / name).write_bytes(body)
        rows.append({'path': 'host/retained-m4/' + name, **pin})
    patches.extend(difflib.unified_diff(export_raw.decode().splitlines(keepends=False),
        export_new.decode().splitlines(keepends=False), fromfile='baseline-outer/public_export.py',
        tofile='entry/public_export.py', lineterm=''))
    (HERE / 'HOST_SPLICE.diff').write_text('\n'.join(patches) + '\n')
    manifest = {
        'schema': 'g132.prospective-retained-m4-host-source-splice.v1', 'authority': 'NONE',
        'baseline_host_commit': '301aeecde08ba6f169bc3cd837eae6f6ad068219',
        'baseline_files': {name: {'bytes': value[0], 'sha256': value[1]} for name, value in BASE_PINS.items()},
        'reviewed_row_source_sha256': ROW_SHA,
        'reviewed_row_manifest_sha256': '102bba7f73733ddd6891a3d7c0466fa473e810dfda214f286d7b3a3bd0bb324f',
        'files': rows + [{'path': 'g132_hosted_validate_m4.py', 'bytes': len(callback), 'sha256': sha(callback)},
                         {'path': 'entry/public_export.py', 'bytes': len(export_new), 'sha256': sha(export_new)}],
        'product_source_manifest_changed': False, 'original_fifteen_proofs_changed': False,
        'global_evidence_permission_expanded': False, 'local_natural_L04': 'NOT_RECEIVED',
        'private_original_input_population_changed': False,
        'full_candidate_module_imported': False, 'original_consumer_invoked': False,
        'protected_effects': False, 'G132': 'UNKNOWN_NO_REPLAY', 'new_awards': [],
        'outer_host_bootstrap_inventory_and_fresh_applicability': 'ROOT_BINDING_REQUIRED_NOT_ISSUED',
        'complete_hosted_executability': 'UNPROVEN',
    }
    (HERE / 'SOURCE_SPLICE_MAP.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    original_public_manifest = json.loads((outer_root / 'PUBLIC_PACKET_MANIFEST.json').read_bytes())
    known_changes = {}
    for name in ('g3_receiving.py', 'proof_consumer.py', 'run.py', 'INDEPENDENT_PROOF_PINS.json'):
        known_changes[name] = {'old': original_public_manifest['members'][name],
                              'proposed_new': {'bytes': len(generated[name]), 'sha256': sha(generated[name]), 'mode': 0o400}}
    additions = {'retained-m4/' + name: {**pin, 'mode': 0o400} for name, pin in m4_pins.items()}
    proposal = {
        'schema': 'g132.unissued-retained-m4-outer-binding-proposal.v1', 'authority': 'NONE',
        'status': 'SOURCE_REVIEW_INPUT_ONLY_NOT_A_RUNTIME_ADMISSION_OR_MANIFEST',
        'public_manifest_member_replacements': known_changes, 'public_manifest_member_additions': additions,
        'carrier_composition_pointer': '/core_bodies/run.py',
        'carrier_composition_proposed_descriptor': {'bytes': len(run), 'sha256': sha(run)},
        'carrier_composition_modified_or_reissued': False,
        'public_exporter_source_prepared': {'path': 'entry/public_export.py', 'bytes': len(export_new), 'sha256': sha(export_new)},
        'outer_binding_prerequisites': [
            'Root independently receives this exact new source/callsite/census packet and its applicability',
            'Root derives a new exact carrier composition and related admission binding; the old REVIEWED_EXACT state is not reusable',
            'Root regenerates the whole host public inventory including the four already-public retained inputs and every changed source/policy body',
            'Root rebinds bootstrap/entry/workflow/publication hashes to that exact final inventory and source',
            'Root receives fresh actual runtime/recipient/control contexts and current scoped decisions before any protected use',
        ],
        'product_source_identity_changed': False, 'private_original_inputs_changed': False,
        'protected_effect_ready': False, 'G132': 'UNKNOWN_NO_REPLAY', 'new_awards': [],
    }
    (HERE / 'UNISSUED_OUTER_BINDING.json').write_text(json.dumps(proposal, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'generated_source_files': 4, 'direct_pin_record': True, 'public_retained_inputs': 4,
                      'consumer_invoked': False, 'root_environment_simulated': False,
                      'map_sha256': sha((HERE / 'SOURCE_SPLICE_MAP.json').read_bytes())}))


if __name__ == '__main__':
    main()
