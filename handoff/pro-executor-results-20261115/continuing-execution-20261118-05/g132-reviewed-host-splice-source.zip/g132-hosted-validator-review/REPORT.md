# Independent review: read-only hosted public validator interface

**Disposition: PASS at the exact frozen-original public-schema validation scope. Authority: NONE.**

The interface safely loads only the inspected, byte-pinned original pure validators and checks public request/decision bytes, stage, selected run, attempt 1, and real wall-clock validity. No original consumer, context, controller, or effect path is loaded or executed. No source defect was found within this declared scope.

This is not an actual hosted callback integration or G3 acceptance result. Every runtime document in this review was explicitly synthetic. Actual provider authentication, current Root issuance/custody, publication, complete original proof receiving, replay state, and hosted execution remain separate requirements. The frozen final validator still refuses accepted L04; the separately reviewed M4 join is not integrated into this interface.

## 1. Exact reviewed identities

Packet: `/workspace/scratch/2678f1e431c3/g132-root-path/review-packet-hosted-validation-v1`.

| Artifact | Bytes | SHA256 |
|---|---:|---|
| `REVIEW_MANIFEST.json` | 1,571 | `631f2a61634e2f7d6db4263d556d0ac91eaa1cbe6ecad7ad17b1200172ae1b79` |
| `g132_hosted_validate.py` | 7,561 | `8c26a5c20f63e56c5529e0b472b34e4b8ed7bea972b481bf992a6b0f4ff441c4` |
| `test_hosted_validate.py` | 12,836 | `1136999cc40129c38e0e5e5e6c6e1ffeafc6d811b7ac83b0f32f97fd23c7a24b` |
| `HOSTED_VALIDATOR_INTERFACE.md` | 5,086 | `ce7b384dd68e56987cb26be76582e69cc1b276598efcad6b2980837a311ac629` |
| Original `g3_receiving.py` | 153,706 | `b85cca1550ff8e7c1c89778180e53a5c70f306f0c8725ba60ef3ccd4bbc3a6ad` |

All five packet members matched their declared bytes and hashes before and after testing; all retained mode 0400. The external original source was reread after testing and remained byte-identical. No immutable source, report, permission, or original input body was modified.

## 2. Loading and execution inspection

The entire small interface, supplied tests, and interface report were read before execution. The original definitions selected by the interface were inspected as source, including destructuring assignments, function defaults, class bases, and calls.

At interface lines 45–72, `pure_owner` requires an exact `bytes` value, the fixed 153,706-byte size, and SHA256 `b85c…a6ad` **before AST parsing or compilation**. It selects the declared validator functions, constants, and the original `Refusal` class. Original imports, decorators, consumers, host context, and main entry are excluded.

The selected callable dependency closure consists of bounded JSON parsing/canonical encoding, exact-schema and digest/integer checks, public request/decision validation, G1 fact-shape validation, and pure row decisions. It invokes no original filesystem, process, network, controller, or currentness acquisition code. Definition-time defaults are constants or a bound limit name; the exception class simply extends `Exception`. There are no selected decorators, metaclass expressions, or executable annotations.

The loader carries several harmless extra constants because they share tuple assignments with requested constants: phase and numeric limits/poll settings. No extra callable is thereby selected. The compiled namespace contains neither `consume`, `decide`, `context`, `main`, `guarded`, nor process/network modules.

`exec` here compiles an inspected subset of one exact trusted source identity. This is not a general sandbox for arbitrary future source. Any future source/pin or extraction-set change needs its own review; the present PASS does not authorize widening that set.

`read_pinned` uses canonical absolute paths, current local file ownership, ordinary single-link files, a fixed byte bound, stable inode/stat identity, no file xattrs, a no-follow read-only open, and an exact expected digest. It writes nothing. Its local file checks establish the bytes read at that call; they do not authenticate an external sender, a provider run, or current Root custody.

## 3. Request, decision, run, and real-time bindings

The interface has only the `components` and `original-final` stages. Each selects the corresponding original public request and decision validators. Unknown stages and cross-stage documents are refused.

The original validators preserve their closed schemas, fixed source/tree/parent and control-route identities, canonical JSON encoding, duplicate-key rejection, limits, and attempt-1 requirement. The shim additionally compares the request run ID to the caller-selected run ID. This is an actual equality check; the caller still has to obtain that selected run from the authentic original receiver.

For a decision, the shim computes SHA256 from the actual request bytes and supplies that digest, the validated request, and a fresh real timestamp to the original decision validator. The original checks preserve the request digest and run/attempt/nonce/source/graph/deadline bindings. The final stage also binds the exact proof map and current-receipt digest. Caller-provided summaries cannot substitute for request or decision bytes in this invocation.

The clock is `time.time_ns()` in the executing process, with no clock argument or CLI override. Entry requires `issued_unix_ms <= now < expires_unix_ms`; decision validation obtains a fresh time sample; a closing check again requires the original request not to have expired. The interface does not rebase an old request, extend a hold, or turn a historical receipt into a current native event. This proves only the local checks at execution time. A consumer must retain its own currentness/deadline gates at the later consequential boundary.

Success returns metadata and exact digests, with `authority: NONE`, `native_history_authenticated: false`, `original_consumer_invoked: false`, `original_acceptance: false`, and no awards. A valid issuer role string in a synthetic document is not treated as authenticated Root issuance.

## 4. Fresh bounded tests

Command:

```text
python -I -B /workspace/scratch/2678f1e431c3/g132-hosted-validator-review/run_bounded_review.py
```

Exit 0. **All 11 supplied tests passed, with zero failures, errors, or skips.** Fifteen additional narrowly selected refusal probes produced the expected codes. Four isolated CLI calls completed with the expected exit states. No clock was replaced or simulated.

| Concrete threat/control | Fresh observation |
|---|---|
| Same-length source corruption, with an invalid first source byte | `EXACT_FROZEN_G3_SOURCE_REQUIRED`, before a parser could report syntax failure. |
| Appended changed source | Refused by the supplied changed-source test. |
| Request/decision SHA mismatch, both stages | `ROOT_DECISION_ACTION_OR_REQUEST` or `FINAL_ROOT_DECISION_ACTION`. |
| Decision run mismatch, both stages | Original stage-specific binding refusal. |
| Selected run differs from a schema-valid request | `SELECTED_RUN_MISMATCH`. |
| Request attempt 2, both stages | Original identity/context refusal. |
| Unknown or wrong stage | Refused. |
| Expired or future request, both stages | `ORIGINAL_REQUEST_NOT_CURRENT`; no timestamp rebasing. |
| Future decision, both stages | Original stage-specific expired/future refusal. |
| Decision nonce mismatch | `ROOT_DECISION_BINDING`. |
| Final decision proof-map mismatch | `FINAL_ROOT_DECISION_BINDING`. |
| Noncanonical/duplicate-key JSON | Refused. |
| Changed file digest or symlink path | Refused. |
| Accepted L04 in the frozen final validator | `NATURAL_RLGWO_SCOPE_NOT_ESTABLISHED`; no silent M4 substitution. |

The isolated CLI used `/usr/bin/python3 -I -B` with exact received shim bytes and disposable public fixtures. The complete stdout and stderr streams are retained:

| CLI case | Exit | Result |
|---|---:|---|
| Current synthetic component request and decision | 0 | Exact request/decision digests, selected run, and attempt matched; authority NONE and no acceptance. |
| Current synthetic original-final request and partial decision | 0 | Exact request/decision digests matched; no acceptance. |
| Expired synthetic component request | 1 | `ORIGINAL_REQUEST_NOT_CURRENT`. |
| Synthetic request with a wrong expected body pin | 1 | `SELECTED_BODY_PIN`. |

All four stderr streams were empty. The positive final fixture declares partial rows; it does not establish original G1 facts, native G3 history, any proof body, or a Root award.

The review harness creates no public request, Root decision, or native event outside its explicitly synthetic fixture directory. Test writes, process captures, and review artifacts are confined to `/workspace/scratch/2678f1e431c3/g132-hosted-validator-review`. CLI child processes only ran this read-only validator; no original module was imported and no original consumer/context was executed.

The packet's earlier smoke-A exit 1, attributed to `MISSING_READ_ONLY_HOSTED_VALIDATOR`, remains retained as author-reported adverse history. Fresh expected refusals and nonzero CLI results are preserved in `VERIFICATION.json` and raw capture files; positive tests do not erase them. There were no unexpected fresh failures.

## 5. Exact residual to actual hosted callbacks and current Root custody

The packet supplies a reviewed validation executable and a callback recipe. It does not include an installed/live callback implementation or prove any actual provider-to-Root-to-host sequence. For actual use, Root still needs the following existing joins:

1. **Receive the executable and caller context.** Bind the exact shim bytes and fixed original source through the current selected source manifest. The helper cannot authenticate its own caller or pin its own loaded code. Use a bounded process invocation and preserve complete stdout, exit, timeout, and uncertain outcomes.
2. **Authenticate the selected request.** The original receiver must establish actual provider metadata, repository/workflow/source, run/attempt, artifact, and request-body identity. The supplied `--run-id` and digest are expected-value checks, not evidence that the caller selected a real authorized run.
3. **Connect the callbacks to held exact bytes.** `validateRequest` must compare the returned request digest to the actual held request bytes and verify the intended stage/run. `validateDecision` must use that same held request and actual Root decision, and compare both returned digests. A success receipt detached from its process capture or from those exact files is insufficient.
4. **Acquire a real current Root decision.** The `issuer` field is checked as original syntax only. Current Root authority, its live capability, source applicability, held inputs, deadline, and current custody must be established outside this helper. Request/decision byte equality must not be promoted to issuer authentication.
5. **Complete the original hosted path.** Actual `readRequest`, `decide`, original control publication, cross-session replay/single-use state, held-source/currentness checks, independent proof receiving, original hosted consumption, and final result receiving remain with their original owners. This shim performs none of them. A local schema pass is not a substitute for their execution.
6. **Integrate M4 coherently before claiming accepted original-final G3.** This shim intentionally preserves b85c's L04 refusal. A future accepted-L04 path needs the previously identified request/body/transport, decision, retained-receipt, custody, source, and review joins, followed by a newly pinned extraction interface. Keep M4 transport distinct from the global original row/gate proof allowlist. Existing accepted M4 is not reopened or replayed by this requirement.

No source acceptance or publication occurred. No hosted operation, GitHub/ref mutation, controller operation, grant, protected effect, or native event was performed. Original G132 remains `UNKNOWN_NO_REPLAY`; existing M4 acceptance and all other unresolved scopes retain their prior status.

**Final scope:** PASS for this exact read-only frozen-original public validation interface. Actual hosted callback integration, current Root custody, and original G3 acceptance remain unproven.
