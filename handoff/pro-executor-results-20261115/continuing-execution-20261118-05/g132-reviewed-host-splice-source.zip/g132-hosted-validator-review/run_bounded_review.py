"""Independent bounded review of exact read-only hosted validator interface.

No original module imports or side-effecting original functions. Real clock is
used throughout. All authored fixtures/logs are confined to this review folder.
"""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
import time
import unittest

OUT = Path(__file__).resolve().parent
PACKET = Path('/workspace/scratch/2678f1e431c3/g132-root-path/review-packet-hosted-validation-v1')
FROZEN = Path('/workspace/scratch/095d3235c921/evidence/g132-portability/upstream-approved/g3_receiving.py')
MANIFEST_SHA = '631f2a61634e2f7d6db4263d556d0ac91eaa1cbe6ecad7ad17b1200172ae1b79'
SOURCE_SHA = 'b85cca1550ff8e7c1c89778180e53a5c70f306f0c8725ba60ef3ccd4bbc3a6ad'

def descriptor(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def exact_packet():
    raw = (PACKET / 'REVIEW_MANIFEST.json').read_bytes()
    assert descriptor(raw) == {'bytes': 1571, 'sha256': MANIFEST_SHA}
    manifest = json.loads(raw)
    for item in manifest['files']:
        path = PACKET / item['path']
        assert descriptor(path.read_bytes()) == {k: item[k] for k in ('bytes', 'sha256')}
        assert stat.S_IMODE(path.stat().st_mode) == 0o400
    source = FROZEN.read_bytes()
    assert descriptor(source) == {'bytes': 153706, 'sha256': SOURCE_SHA}
    return manifest, source

manifest, source = exact_packet()
tempfile.tempdir = str(OUT)

def inspected_module(name, path):
    # Both complete small modules were read before this invocation. Their top
    # level is standard imports/declarations; __main__ paths are not invoked.
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

shim = inspected_module('reviewed_hosted_shim', PACKET / 'g132_hosted_validate.py')
tests = inspected_module('reviewed_synthetic_hosted_tests', PACKET / 'test_hosted_validate.py')
owner = shim.pure_owner(source)
for excluded in ('consume', 'decide', 'context', 'main', 'guarded', 'os', 'time', 'subprocess', 'urllib'):
    assert excluded not in owner, excluded
assert set(shim.PURE_FUNCTIONS) <= set(owner)

# Record exactly what the loader selects, including harmless constants sharing
# a destructuring assignment with a requested constant.
selected = []
calls = set()
extra_constants = set()
for node in ast.parse(source).body:
    include = False
    if isinstance(node, ast.Assign):
        names = {part.id for target in node.targets for part in ast.walk(target) if isinstance(part, ast.Name)}
        if names & shim.PURE_CONSTANTS:
            include = True
            extra_constants.update(names - shim.PURE_CONSTANTS)
    elif isinstance(node, ast.ClassDef) and node.name == 'Refusal':
        assert not node.decorator_list and not node.keywords
        assert len(node.bases) == 1 and isinstance(node.bases[0], ast.Name) and node.bases[0].id == 'Exception'
        include = True
    elif isinstance(node, ast.FunctionDef) and node.name in shim.PURE_FUNCTIONS:
        assert not node.decorator_list and node.returns is None
        assert all(arg.annotation is None for arg in node.args.posonlyargs + node.args.args + node.args.kwonlyargs)
        assert all(isinstance(x, (ast.Constant, ast.Name)) for x in node.args.defaults)
        assert not node.args.kw_defaults
        include = True
    if include:
        selected.append({'kind': type(node).__name__, 'name': getattr(node, 'name', ast.unparse(node.targets[0]) if isinstance(node, ast.Assign) else ''),
                         'first_line': node.lineno, 'last_line': node.end_lineno})
        calls.update(ast.unparse(n.func) for n in ast.walk(node) if isinstance(n, ast.Call))
selection = {'source': descriptor(source), 'selected_nodes': selected,
             'selected_calls': sorted(calls), 'extra_harmless_constants_from_shared_assignments': sorted(extra_constants),
             'original_consumers_or_host_context_selected': False,
             'reviewed_definition_time_expressions_have_no_effects': True}
(OUT / 'AST_SELECTION.json').write_text(json.dumps(selection, indent=2, sort_keys=True) + '\n')

suite = unittest.defaultTestLoader.loadTestsFromTestCase(tests.HostedValidateTests)
with (OUT / 'SUPPLIED_TESTS.txt').open('w') as stream:
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)

probes = []
def expected_refusal(label, expected, stage, request, decision=None, selected_run=None, source_raw=None):
    try:
        shim.validate_bytes(source if source_raw is None else source_raw, stage, tests.RUN if selected_run is None else selected_run,
                            tests.encoded(request), None if decision is None else tests.encoded(decision))
    except Exception as exc:
        actual = str(exc)
        probes.append({'case': label, 'expected': expected, 'outcome': 'REFUSED', 'code': actual})
        assert actual == expected, (label, actual)
    else:
        probes.append({'case': label, 'expected': expected, 'outcome': 'UNEXPECTED_VALIDATION'})
        raise AssertionError(label)

request, decision = tests.component()
tampered_source = b'!' + source[1:]
assert len(tampered_source) == len(source)
expected_refusal('same_length_source_digest_mismatch_before_AST_parse', 'EXACT_FROZEN_G3_SOURCE_REQUIRED',
                 'components', request, source_raw=tampered_source)

for stage in ('components', 'original-final'):
    make = tests.component if stage == 'components' else lambda: tests.final_documents(owner)
    request, decision = make()
    decision['request_sha256'] = 'c' * 64
    expected_refusal(stage + '_decision_request_digest_mismatch',
                     'ROOT_DECISION_ACTION_OR_REQUEST' if stage == 'components' else 'FINAL_ROOT_DECISION_ACTION',
                     stage, request, decision)
    request, decision = make()
    decision['run_id'] = '999999992'
    expected_refusal(stage + '_decision_run_mismatch',
                     'ROOT_DECISION_BINDING' if stage == 'components' else 'FINAL_ROOT_DECISION_BINDING',
                     stage, request, decision)
    request, decision = make()
    request['attempt'] = 2
    expected_refusal(stage + '_request_attempt2',
                     'PUBLIC_REQUEST_IDENTITY' if stage == 'components' else 'FINAL_PUBLIC_CONTEXT', stage, request)
    request, decision = make()
    clock_fields = ('issued_unix_ms', 'expires_unix_ms', 'shared_expires_unix_ms') if stage == 'components' else (
        'shared_window_started_unix_ms', 'issued_unix_ms', 'expires_unix_ms')
    for key in clock_fields:
        request[key] -= 700000
    expected_refusal(stage + '_expired_no_clock_override', 'ORIGINAL_REQUEST_NOT_CURRENT', stage, request)
    request, decision = make()
    for key in clock_fields:
        request[key] += 700000
    expected_refusal(stage + '_future_request', 'ORIGINAL_REQUEST_NOT_CURRENT', stage, request)
    request, decision = make()
    decision['issued_unix_ms'] = time.time_ns() // 1000000 + 60000
    expected_refusal(stage + '_future_decision',
                     'ROOT_DECISION_EXPIRED_OR_FUTURE' if stage == 'components' else 'FINAL_ROOT_DECISION_EXPIRED_OR_FUTURE',
                     stage, request, decision)

request, decision = tests.final_documents(owner)
decision['proofs'] = copy.deepcopy(decision['proofs'])
decision['proofs']['module'] = 'c' * 64
expected_refusal('final_decision_proof_population_binding_mismatch', 'FINAL_ROOT_DECISION_BINDING',
                 'original-final', request, decision)

request, decision = tests.final_documents(owner)
decision['original_rows'][4]['disposition'] = 'ACCEPTED_AT_DECLARED_SCOPE'
decision['original_rows'][4]['residuals'] = ['NONE_AT_DECLARED_SCOPE']
expected_refusal('frozen_L04_guard_not_silently_replaced_by_M4_candidate', 'NATURAL_RLGWO_SCOPE_NOT_ESTABLISHED',
                 'original-final', request, decision)

cli_observations = []
with tempfile.TemporaryDirectory(prefix='isolated-cli-inputs-', dir=OUT) as temp:
    folder = Path(temp)
    source_path = folder / 'original_source.py'
    source_path.write_bytes(source)
    source_path.chmod(0o400)
    def cli(label, stage, request, decision, expected_exit, expected_code=None, request_pin=None):
        request_raw = tests.encoded(request)
        request_path = folder / (label + '-request.json')
        request_path.write_bytes(request_raw)
        request_path.chmod(0o400)
        argv = ['/usr/bin/python3', '-I', '-B', str(PACKET / 'g132_hosted_validate.py'),
                '--source', str(source_path), '--stage', stage, '--run-id', tests.RUN,
                '--request', str(request_path), '--request-sha256', request_pin or hashlib.sha256(request_raw).hexdigest()]
        decision_raw = None
        if decision is not None:
            decision_raw = tests.encoded(decision)
            decision_path = folder / (label + '-decision.json')
            decision_path.write_bytes(decision_raw)
            decision_path.chmod(0o400)
            argv.extend(['--decision', str(decision_path), '--decision-sha256', hashlib.sha256(decision_raw).hexdigest()])
        began = time.time_ns() // 1000000
        proc = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10, check=False)
        ended = time.time_ns() // 1000000
        (OUT / (label + '.stdout.txt')).write_bytes(proc.stdout)
        (OUT / (label + '.stderr.txt')).write_bytes(proc.stderr)
        receipt = json.loads(proc.stdout)
        observation = {'case': label, 'stage': stage, 'returncode': proc.returncode,
                       'observed_started_unix_ms': began, 'observed_ended_unix_ms': ended,
                       'request': descriptor(request_raw), 'decision': None if decision_raw is None else descriptor(decision_raw),
                       'stdout': descriptor(proc.stdout), 'stderr': descriptor(proc.stderr), 'receipt': receipt}
        cli_observations.append(observation)
        assert proc.returncode == expected_exit and not proc.stderr, label
        if expected_code is not None:
            assert receipt['status'] == 'REFUSED' and receipt['code'] == expected_code, label
        else:
            assert receipt['request_sha256'] == hashlib.sha256(request_raw).hexdigest()
            if decision_raw is not None:
                assert receipt['decision_sha256'] == hashlib.sha256(decision_raw).hexdigest()
            assert receipt['run_id'] == tests.RUN and receipt['attempt'] == 1
            assert receipt['authority'] == 'NONE' and receipt['new_awards'] == []
            assert not receipt['original_consumer_invoked'] and not receipt['original_acceptance'] and not receipt['native_history_authenticated']
    request, decision = tests.component()
    cli('current-components', 'components', request, decision, 0)
    request, decision = tests.final_documents(owner)
    cli('current-original-final', 'original-final', request, decision, 0)
    request, _ = tests.component()
    for key in ('issued_unix_ms', 'expires_unix_ms', 'shared_expires_unix_ms'):
        request[key] -= 700000
    cli('expired-components', 'components', request, None, 1, 'ORIGINAL_REQUEST_NOT_CURRENT')
    request, _ = tests.component()
    cli('changed-request-pin', 'components', request, None, 1, 'SELECTED_BODY_PIN', request_pin='a' * 64)

after_manifest, after_source = exact_packet()
assert manifest == after_manifest and source == after_source
verification = {
    'schema': 'g132.independent-readonly-hosted-validator-review.v1', 'authority': 'NONE',
    'packet_manifest': {'bytes': 1571, 'sha256': MANIFEST_SHA},
    'packet_members_exact_before_and_after': len(manifest['files']),
    'original_source': descriptor(source), 'original_source_unchanged': True,
    'supplied_tests_run': result.testsRun, 'supplied_failures': len(result.failures),
    'supplied_errors': len(result.errors), 'supplied_skipped': len(result.skipped),
    'supplied_tests_successful': result.wasSuccessful(), 'additional_controlled_probes': probes,
    'isolated_cli_observations': cli_observations,
    'original_module_imported': False, 'original_consumer_or_context_executed': False,
    'real_wall_clock_used': True, 'clock_overrides': False,
    'all_public_documents_explicitly_synthetic': True, 'root_or_host_environment_simulated': False,
    'network_or_GitHub_mutation': False, 'controller_operation': False, 'protected_effect': False,
    'new_awards': [], 'original_acceptance': False, 'writes_confined_to': str(OUT),
}
(OUT / 'VERIFICATION.json').write_text(json.dumps(verification, indent=2, sort_keys=True) + '\n')
print(json.dumps({'supplied_tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
                  'probes': probes, 'cli': [{'case': x['case'], 'returncode': x['returncode'], 'code': x['receipt'].get('code')} for x in cli_observations],
                  'packet_unchanged': True, 'source_unchanged': True}, indent=2))
raise SystemExit(0 if result.wasSuccessful() else 1)
