# Independent continuity-scope assessment

**FINAL — additive qualification is required for the stale continuity claims. The supplied mismatch does not justify replaying actors/effects or automatically revoking the original scoped model-policy decisions.** The procedural lapse must remain visible: an old verified receipt identity was cited after its bound STATE changed. Fresh G0009 repairs current local continuity prospectively; it does not certify the earlier changed bytes or interval.

Reviewer: `/root/g2_delivery_checks`, ordinary read-only receiver, authority **NONE**. Model is GPT-6 Astra Pro by host/self-report; exact deployment ID is unavailable. Scope is limited to the supplied G0007/G0008/G0009 records, named model observations/decisions and checkpoint04. No conclusion is made about unsupplied earlier epochs.

## Mechanism and exact facts

The installed helper is unchanged: 14,707 bytes, SHA-256 `9c9945fdf650c72b8019f0dd908fff360162cc11ae7eb3197ccafe0f6ab3730f`. Its verification path recomputes STATE and ROADMAP hashes, then compares them to the receipt together with controller, claim, HEAD/tree and invalidation identities; it also compares the recorded next action. Retaining the same epoch/ref name does not retain validity after a content change.

Read-only Git inspection confirms these actual receipt blobs:

| Receipt | Git OID | Bound STATE SHA-256 |
|---|---|---|
| G0007 | `1a50c384466ee4be4cf03554f826cda54a8695e7` | `98b559e135a1e15d58bfaf29f0e20d63f308dfda9538bf06a99495a9294f5686` |
| G0008 | `69e53e2443d671d027d8988ace40087dd6a95124` | `62bd2ffc16bcc731346b8a28b9757f89d2be017ed4963d315397d798f846dd64` |
| G0009 | `2e79476de3117b53d3999d7b15a5fb59c51b3787` | `2cf82bc15a0465f8ccfcaea1aea59fbce6d59de46949d8b9203e657b42d244c6` |

Controller OID, claim ID and Root HEAD/tree are identical across all three records. The observed current refs agree with G0009's controller and invalidation. G0009 explicitly records `manual-resume`.

Checkpoint04's actual STATE is **40,585 bytes**, SHA-256 `2c571c916c665e6bbee23f3d527591d61173ca496f95b845c9471d69a38406e9`, which differs from G0008's bound hash. Its standalone and staged copies are equal. Connected provider readback independently confirms the same exact Git blob `d71a4745031f93c741b7537ae0df39bd58abd847`, plus commit `f2184f384ff599aaf4dc8a1e779d8207d61637a4`, sole parent `1586c5f1ebcf7ed5ce9d8bf7cc0fc416815ce50d`, and tree `af6e666fc7cbbbf7e952f7cc5f6a5e91c8d6a810`. Root's retained full-tree receipt supplies the exact published path and the 22-addition / 3,425-unchanged-prior-path join.

Current STATE is 45,087 bytes at G0009's hash. Current ROADMAP is 2,208 bytes, SHA-256 `8ec9fe544b9bbda210455191dc10c5045d2e74df56e9c90d99b426cd56178b3d`, also matching G0009. The exact [G0009_REANCHOR.json](sandbox:/workspace/scratch/2678f1e431c3/root-continuity-recovery/G0009_REANCHOR.json), SHA-256 `1e3e32522f53fea587f59bece2a4d749ccdf4c789ddca09e28ed1c471161e817`, records old require/verify exits 1 and new resume/verify/require exits 0. Those execution outcomes are received from Root's record; this receiver did not invoke the helper.

## Bounded chronology and impact

All times below are explicit Root-authored UTC records. They are not a claim of continuous independent file observation. Git commit dating is not treated as authenticated publication timing.

| Record / time | Classification and required qualification |
|---|---|
| P09/N08/M07 Root decision, `08:50:06.365820` | Precedes the documented G0007 STATE update at `08:51:39.020633`. Retain its original decision and historical G0007 reference; the later mismatch does not retroactively invalidate it. |
| Willow predispatch, `08:55:36.763678`; actual dispatch, `08:56:52.736905` | Its `current_continuity: G0007@…` postdates that documented STATE update. This is a stale current-state label, usable only as the retained last-verified receipt identity. Preserve the predispatch continuity lapse explicitly. |
| M08 baseline eligibility, `09:06:49.909890`; Maple dispatch, `09:07:02.913009` | Uses G0008 and precedes the first documented later G0008 STATE write. Retain this historical applicability; do not extend it into later changed-state custody. |
| G132 pure-v2 join receipt, `09:08:32.277736` | Same pre-write G0008 classification. This was bounded source receiving, with protected grant and live-custody transfer explicitly false. |
| M08 Root decision, `09:14:40.810414`; current-frontier projection, `09:15:23.789454` | Both precede the documented `09:16:33.357235` STATE write. Their original G0008 fields are dated last-verified references, not certification of the later checkpoint STATE. |
| STATE update, `09:16:33.357235`; checkpoint04 publication/readback recorded by `09:20:45.810251` | The exact published STATE mismatch is proved. Publication remains an actual owner-authorized effect with retained readback, but this interval must not be called freshly G0008 receipt-qualified or fully continuity-compliant. |
| Second STATE update, `09:20:45.810251` | Root records 41,750 bytes. This bounded pass did not receive its full standalone pre-G0009 body/hash; no additional hash is invented. The first exact mismatch already establishes the relevant defect. |
| G0009 manual re-anchor; result recorded `09:25:07.989377` | Current byte bindings agree. The repair is prospective and is not a host compaction, C02 event, native callback, replay or historical custody transfer. |

“Pre-write” above means that the supplied subsequent write does not demonstrate staleness at the earlier decision. It does not manufacture a fresh verification call at every decision timestamp.

## Effect on original observations and adjudications

M08's four expressly bound evidence files still match their recorded byte counts and hashes, including both independent reports, frozen oracle and actual mutant record. The original Willow/Maple prompt hashes are unchanged, and neither prompt contains the old Root receipt tokens. P09/N08/M07 and M08 Root decisions and the DG17 frontier are copied byte-identically into the checkpoint stage.

The decisions expressly concern controlled selected-source **model-policy** observations. They exclude native/full-governor/whole-cell credit. Stale Root metadata cannot supply those excluded proofs. No supplied evidence shows that it changed the model inputs, observed outputs, frozen oracle, independent judgments or original discriminator. Retain the actual observations and scoped decisions, while attaching the continuity qualification to Willow's predispatch and to the subsequent publication/state interval. Root alone receives that distinction and decides the additive disposition; this report makes no new award.

## Minimal additive correction for Root

Preserve original files, hashes and timestamps. Add one qualified record identifying:

1. Willow's named predispatch `current_continuity` as **last verified / known stale for the changed STATE**, with the original procedural failure retained.
2. The pre-write G0008 decisions/frontier as dated historical references, and checkpoint04 CURRENT_STATE as a **post-write historical snapshot not certified by G0008**. Preserve the ordinary publication and exact readback without claiming fresh continuity for that interval.
3. Exact G0009 manual recovery and its current byte bindings, applying prospectively with no retrospective receipt, actor/effect replay or automatic award revocation.
4. The adopted countermeasure: leave verified STATE/ROADMAP unchanged, record progress in the sibling log, and incorporate changes only during a deliberate later re-anchor. The frozen STATE's pre-resume pending wording is superseded by the separately recorded successful recovery result; it should not be edited merely to update that wording.

## Evidence and action limits

[FINDINGS.json](sandbox:/workspace/scratch/2678f1e431c3/continuity-impact-review/FINDINGS.json) records 29 verified static receiving checks and exact input descriptors. [RECEIPT_READBACK.json](sandbox:/workspace/scratch/2678f1e431c3/continuity-impact-review/RECEIPT_READBACK.json) preserves the parsed actual Git blobs. [PUBLICATION_PROVIDER.json](sandbox:/workspace/scratch/2678f1e431c3/continuity-impact-review/PUBLICATION_PROVIDER.json) preserves the immutable connected-provider readback.

No controller action, root/claim/source/evidence mutation, actor/effect replay, remote write, new event, grant, award or test campaign was performed. Only this receiver's report and read-only evidence copies were saved.
