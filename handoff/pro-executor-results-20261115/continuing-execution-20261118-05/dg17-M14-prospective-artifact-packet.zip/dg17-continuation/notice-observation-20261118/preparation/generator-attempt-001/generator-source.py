"""Materialize a neutral-path successor from a retained failed preparation.

No fixture/history/oracle regeneration and no model dispatch. Root specifically
authorized this neutral directory after the actual prompt-path guard failure.
"""
from pathlib import Path
import ast,datetime,difflib,hashlib,json,shutil

HERE=Path(__file__).resolve().parent
PRIOR=HERE/'cheap-path-observation-20261118'
OUT=HERE/'notice-observation-20261118'
AUTHOR='/root/g2_live_independent_20261118'

def sha(raw):return hashlib.sha256(raw).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(path,raw):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f:f.write(raw if isinstance(raw,bytes) else raw.encode())
def jsave(path,value):save(path,json.dumps(value,indent=2,sort_keys=True)+'\n')
def files(root):
    return {p.relative_to(root).as_posix():{'bytes':len(p.read_bytes()),'sha256':sha(p.read_bytes())}
            for p in sorted(root.rglob('*')) if p.is_file()}

def main():
    assert not OUT.exists(),'Preserve any existing successor; do not overwrite'
    prior_before=files(PRIOR)
    prior_receipt=json.loads((PRIOR/'preparation/generator-attempt-001/receipt.json').read_text())
    failure=(PRIOR/'preparation/generator-attempt-001/stderr.bin').read_bytes()
    assert prior_receipt['exit_code']==1 and b'AssertionError: cheap-path' in failure
    assert not any((PRIOR/'actors'/label/'live').exists() for label in ['cedar','alder'])
    oracle_raw=(PRIOR/'private/ORACLE.json').read_bytes();oracle=json.loads(oracle_raw)
    failed_source=(PRIOR/'preparation/generator-attempt-001/generator-source.py').read_bytes()
    assert failed_source==(HERE/'prepare_cheap_path_packet.py').read_bytes()
    OUT.mkdir()
    # Carry actual source, oracle, fixture, baseline, origin and recorder bytes intact.
    for name in ['intake','private','actors']:
        shutil.copytree(PRIOR/name,OUT/name,copy_function=shutil.copyfile)
    for name in ['PREPARATION_OPEN.json','SOURCE_MAP.json']:
        save(OUT/name,(PRIOR/name).read_bytes())
    shutil.copytree(PRIOR/'preparation/generator-attempt-001',OUT/'predecessor/generator-attempt-001',copy_function=shutil.copyfile)
    prompt_changes=[]
    for label in ['cedar','alder']:
        name='PROMPT_'+label+'.txt';old=(PRIOR/'dispatch'/name).read_bytes()
        old_path=str(PRIOR/'actors'/label).encode();new_path=str(OUT/'actors'/label).encode()
        assert old.count(old_path)>0
        new=old.replace(old_path,new_path)
        save(OUT/'dispatch'/name,new);save(OUT/'predecessor/dispatch'/name,old)
        patch=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='failed-path/'+name,tofile='neutral-path/'+name))
        save(OUT/'predecessor'/('path-only-'+label+'.patch'),patch)
        prompt_changes.append({'actor':label,'old_path':old_path.decode(),'new_path':new_path.decode(),'replacements':old.count(old_path),
                               'original_prompt_bytes':len(old),'original_prompt_sha256':sha(old),'successor_prompt_bytes':len(new),'successor_prompt_sha256':sha(new),'only_path_replacement':old.replace(old_path,new_path)==new})
    # The controls assignment was defined in the failed source before its guard.
    # Materialize that exact AST value, substituting only its already frozen
    # EXPECTED constant. The forbidden-phrase population is not weakened.
    module=ast.parse(failed_source)
    function=next(n for n in module.body if isinstance(n,ast.FunctionDef) and n.name=='main')
    assignment=next(n for n in function.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='controls')
    class FrozenExpected(ast.NodeTransformer):
        def visit_Name(self,node):
            assert node.id=='EXPECTED',node.id
            return ast.copy_location(ast.Constant(value=oracle['expected_notice_utf8']),node)
    controls=ast.literal_eval(FrozenExpected().visit(assignment.value))
    guard_results=[]
    for label in ['cedar','alder']:
        text=(OUT/'dispatch'/('PROMPT_'+label+'.txt')).read_text()
        hits=[phrase for phrase in controls['forbidden_mission_phrases'] if phrase.lower() in text.lower()]
        guard_results.append({'actor':label,'forbidden_phrases':controls['forbidden_mission_phrases'],'hits':hits})
        assert not hits,hits
    jsave(OUT/'private/MODEL_CONTROLS.json',controls)
    save(OUT/'private/prepare_notice_packet.py',Path(__file__).read_bytes())
    save(OUT/'private/test_packet.py',(HERE/'test_cheap_path_packet.py').read_bytes())
    copied=[]
    for relative in sorted(prior_before):
        if relative.startswith(('private/','actors/','intake/')) or relative in ['SOURCE_MAP.json','PREPARATION_OPEN.json']:
            assert (OUT/relative).read_bytes()==(PRIOR/relative).read_bytes(),relative
            copied.append({'path':relative,**prior_before[relative]})
    assert (OUT/'private/ORACLE.json').read_bytes()==oracle_raw
    assert files(PRIOR)==prior_before,'Predecessor custody changed during repair'
    report={'schema':'dg17.notice-neutral-path-successor.v1','at':now(),'author':AUTHOR,'authority':'NONE','status':'UNSEALED_PENDING_BOUNDED_PREFLIGHT_AND_NONAUTHOR_REVIEW',
            'reason':'Actual forbidden-mission guard rejected the family-revealing cheap-path directory in command paths. Root authorized a new neutral directory, preserving the guard and original failed state.',
            'predecessor':str(PRIOR),'predecessor_files':prior_before,'predecessor_unchanged_after_repair':True,'failed_generator_source_sha256':sha(failed_source),'failed_process_exit':1,
            'failure_stderr_sha256':sha(failure),'successor':str(OUT),'changes':prompt_changes,'guard_results':guard_results,
            'exact_copied_members':copied,'oracle_sha256':sha(oracle_raw),'oracle_changed':False,'source_policy_changed':False,'fixture_changed':False,'workbench_changed':False,
            'actor_dispatches':0,'historical_observations_regenerated':False,'scope':'Prospective material prompt-path repair before any actor/model outcome; not tuning an outcome or acceptance criterion'}
    jsave(OUT/'SUCCESSOR_PROVENANCE.json',report)
    print(json.dumps({'packet':str(OUT),'status':'UNSEALED','actor_dispatches':0,'predecessor_unchanged':True,'exact_copied_members':len(copied),'oracle_sha256':sha(oracle_raw),'prompt_guard_pass':True,'prompt_changes':prompt_changes},indent=2))

if __name__=='__main__':main()
