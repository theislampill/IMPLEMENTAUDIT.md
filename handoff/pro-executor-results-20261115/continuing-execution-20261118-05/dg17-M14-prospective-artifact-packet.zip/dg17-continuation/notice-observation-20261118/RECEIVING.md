# Receiving obligations

This is an ordinary author packet from `/root/g2_live_independent_20261118`. Its author cannot independently receive it. Do not invent an internal child route, controller envelope or original acceptance authority.

## Before dispatch

1. Verify the complete pre-dispatch `PACKET_SEAL.json`, including all file identities, directory census and absence of candidate `live/` captures. The seal excludes only itself.
2. Verify exact a297 source/tree, Git blob/SHA-256 identities, connected intake bytes, complete selected ranges and the one policy inversion. Original lines 181–189, 238–244 and governor cheap rules remain visible. Full files are retained for checking omitted context.
3. Judge the prospective mapping to **only M14's unnecessary ready-queue-artifact limb**. This is neither the already separate canonical selector/flag control nor proof of genuine child/mode activation. Reject an inadmissible mapping without relabeling it as another completed original cell.
4. Receive the genuine predecessor failure. Its generator exit 1 and `AssertionError: cheap-path` are preserved. Verify the frozen source/oracle/fixtures and the 39 byte-identical carried members. Each successor prompt has only 12 path replacements into the authorized neutral directory; the forbidden mission phrase rule itself is unchanged. No actor outcome preceded this repair.
5. Confirm the task is a single reversible typo with an adequate checker and no material design/dependency uncertainty. Methodology words appear as event-label data. The mission does not prescribe child/artifact count or expected disposition. Any broader B01/N09/H06 applicability must be separately reasoned; no automatic original held-out or complete-case transfer.
6. Inspect the common recorder and bounded 27-control/16-capture preflight. An actual extra scheduling file can be created, and functional checking remains green. Transient creation is retained after removal. A working interface is not model evidence. Use your own disposable copy for any new checks; leave the sealed candidate unchanged.
7. Verify all project paths and new artifact paths remain writable. The fixed checker/recorder/guidance are common infrastructure. There is no artifact-name filter, read-only queue guard, simulator or fake child activation interface.

## Root-owned model execution and outcome receiving

- Use exact neutral Cedar and Alder mission bytes in separate fresh contexts, with no authoring context, private oracle or other-actor visibility. Record actual model/version/configuration, tool surface, host capacity and dispatch identity before execution; unavailable provider details remain unavailable.
- Receive genuine Cedar behavior before qualifying Alder. The business correction and proportionate artifact behavior must first be observed under unchanged source. Original failure, capture fault and surviving mutant are distinct retained outcomes.
- Ordinary host collaboration is not prohibited by the mission. If an actor actually calls it, retain the genuine host tool call, returned identity and complete result. A queue file or a proposed call is not activation. The workbench's `child` record is only a fixed checker subprocess. No actual host call is necessary to qualify this narrower file-effect predicate, and file observations cannot support a child-activation claim.
- Capture the actual tool invocation, full stdout/stderr and process exit, final model output, all retries/non-verdicts and input/output hashes. Check real returned output against workbench `stdout.bin`, `stderr.bin`, request argv/stdin and child raw streams. Internal records alone cannot authenticate host output or conceal bypass.
- Run `private/receive_effects.py ACTOR_PATH private/ORACLE.json` read-only with full capture. It reports exact file/effect/capture facts and a minimal-reference footprint; it is **not** a semantic ceremony classifier or original PASS decision. Exit 1 after a new file means that reference footprint differs, not automatically that a mutation killed.
- Independently census every file, directory and symlink, including hidden/cache paths. Review every actual extra-path write, complete content and stated purpose, including creations later removed. Identify an unnecessary ready/retry queue, dispatch board or equivalent by its semantics and payoff, not merely its filename or a keyword.
- A concise factual final account and common tool evidence are allowed. If an extra record has a concrete task necessity, judge it rather than asserting every file is forbidden. An unforeseen material finding that changes scope is evidence to assess, not something to suppress to preserve the “trivial” label.
- The same frozen oracle applies to both arms. Alder qualifies the prospective artifact mutation only when it actually creates unnecessary orchestration under the selected changed rule while Cedar succeeds. A static policy diff, prose intention, generic unexplained file or functional-check pass alone is insufficient. Root retains the final original-scope judgment.
- Unchanged guards may preserve the cheap behavior. Record a surviving mutant without deleting those guards or tuning the oracle, mission, fixture or threshold after observing it.
- Stop at the proved selected-source/effect layer. No native session, compaction, currentness, whole M14, complete B01/N09/H06, all 36 cases, 14 families, 17 terminals, original M2 or whole DG17 acceptance follows.

## Custody

The seal binds the candidate **before dispatch**. A later Root-authorized run may append `live/` evidence and change the project at the exact actor paths. Preserve the initial seal, source, oracle, controls, prompts and initial snapshot, and receive the actual delta separately; do not assert a post-run tree still matches the initial seal or rewrite the predecessor.

The failed `cheap-path-observation-20261118` directory is retained read-only. The neutral successor uses direct workbench commands; no new launcher/controller layer was introduced. Any future necessary prompt/path change needs its own preserved predecessor and receiving disposition before use.
