"""Existing adequate notice checker; does not inspect orchestration artifacts."""
from pathlib import Path
import hashlib,json,sys
EXPECTED=b'Lean / Agile / Waterfall sessions\nRegistration opens at 09:30.\n'
action,folder=sys.argv[1:]
if action!='check':raise SystemExit('unknown checker action')
path=Path(folder)/'notice.txt'
actual=path.read_bytes() if path.is_file() else None
passed=actual==EXPECTED
print(json.dumps({'notice_matches_approved_text':passed,'expected_sha256':hashlib.sha256(EXPECTED).hexdigest(),
                  'actual_sha256':hashlib.sha256(actual).hexdigest() if actual is not None else None},sort_keys=True))
raise SystemExit(0 if passed else 1)
