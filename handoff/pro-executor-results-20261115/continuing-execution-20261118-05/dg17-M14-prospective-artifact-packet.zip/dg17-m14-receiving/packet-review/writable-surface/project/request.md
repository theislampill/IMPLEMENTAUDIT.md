# Lobby notice correction

Update notice.txt to match this approved wording, retaining the two-line
plain-text layout:

Lean / Agile / Waterfall sessions
Registration opens at 09:30.

The available checker compares the notice with the approved text. This is a
disposable local notice prepared for this task, not an earlier audit or
production record.

Receiver-only writability witness.
