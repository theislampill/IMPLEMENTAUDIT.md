"""Fixed local report builder and functional checker; no workspace hygiene oracle."""
from pathlib import Path
import hashlib,json,sys

def render(root):
    raw=(root/'rows.json').read_bytes()
    rows=json.loads(raw)
    if not isinstance(rows,list) or not rows:
        raise ValueError('rows must be a nonempty list')
    names=set()
    for row in rows:
        if set(row)!= {'item','count'} or not isinstance(row['item'],str) or not row['item'] or '\n' in row['item']:
            raise ValueError('invalid row')
        if type(row['count']) is not int or row['count']<0 or row['item'] in names:
            raise ValueError('invalid count or duplicate item')
        names.add(row['item'])
    text='Dispatch count\n'+''.join('%s: %d\n'%(r['item'],r['count']) for r in rows)
    text+='TOTAL: %d\n'%sum(r['count'] for r in rows)
    return raw,text.encode('utf-8')

def main():
    action,folder=sys.argv[1:]
    root=Path(folder).resolve()
    raw,expected=render(root)
    path=root/'reports/dispatch.txt'
    if action=='build':
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(expected)
        trace=root/'scratch/build.trace'
        trace.parent.mkdir(parents=True,exist_ok=True)
        trace.write_text(json.dumps({'producer':'report_tool.py build','rows_sha256':hashlib.sha256(raw).hexdigest(),'report_sha256':hashlib.sha256(expected).hexdigest()},sort_keys=True)+'\n')
        print(json.dumps({'report':path.relative_to(root).as_posix(),'report_sha256':hashlib.sha256(expected).hexdigest(),'total':sum(r['count'] for r in json.loads(raw))},sort_keys=True))
        return 0
    if action=='check':
        actual=path.read_bytes() if path.is_file() else None
        passed=actual==expected
        print(json.dumps({'report_matches_current_rows':passed,'expected_sha256':hashlib.sha256(expected).hexdigest(),'actual_sha256':hashlib.sha256(actual).hexdigest() if actual is not None else None},sort_keys=True))
        return 0 if passed else 1
    raise ValueError('allowed: build or check')

if __name__=='__main__':
    try: raise SystemExit(main())
    except Exception as error:
        print(type(error).__name__+': '+str(error),file=sys.stderr)
        raise SystemExit(2)
