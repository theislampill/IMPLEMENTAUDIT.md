"""Recorded local file interface. All project files are writable; not an OS sandbox."""
from pathlib import Path
import base64,datetime,fcntl,hashlib,json,os,signal,stat,subprocess,sys
ROOT=Path(__file__).resolve().parent
PROJECT=ROOT/'project'
SUPPORT=ROOT/'support'

def sha(raw): return hashlib.sha256(raw).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write_json(path,value): path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')

def census(root):
    result={}
    for directory,dirs,files in os.walk(root,followlinks=False):
        for name in sorted(dirs+files):
            path=Path(directory)/name
            relative=path.relative_to(root).as_posix()
            info=path.lstat()
            row={'mode':stat.S_IMODE(info.st_mode),'mtime_ns':info.st_mtime_ns}
            if path.is_symlink():
                row.update(kind='symlink',target=os.readlink(path))
            elif path.is_file():
                raw=path.read_bytes();row.update(kind='file',bytes=len(raw),sha256=sha(raw))
            elif path.is_dir(): row.update(kind='directory')
            else: row.update(kind='other',size=info.st_size)
            result[relative]=row
    return dict(sorted(result.items()))

def resolve(name,root=PROJECT):
    item=Path(name)
    if not name or item.is_absolute() or '..' in item.parts:
        raise ValueError('path outside owned project')
    path=(root/item).resolve()
    if path==root.resolve() or not path.is_relative_to(root.resolve()):
        raise ValueError('path outside owned project')
    return path

def bytes_identity(row):
    return {key:row[key] for key in ('kind','bytes','sha256','target') if key in row}

def delta(before,after):
    return {name:{'before':before.get(name),'after':after.get(name)}
            for name in sorted(set(before)|set(after))
            if bytes_identity(before.get(name,{}))!=bytes_identity(after.get(name,{}))}

def child(action,capture):
    cmd=[sys.executable,'-I','-B',str(SUPPORT/'report_tool.py'),action,str(PROJECT)]
    began=now()
    proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    timed_out=False
    try: out,err=proc.communicate(timeout=20)
    except subprocess.TimeoutExpired:
        timed_out=True;os.killpg(proc.pid,signal.SIGKILL);out,err=proc.communicate(timeout=5)
    (capture/'child.stdout.bin').write_bytes(out)
    (capture/'child.stderr.bin').write_bytes(err)
    result={'argv':cmd,'started_at':began,'finished_at':now(),'exit_code':proc.returncode,'timed_out':timed_out,
            'stdout':out.decode('utf-8',errors='replace'),'stderr':err.decode('utf-8',errors='replace'),
            'stdout_bytes':len(out),'stderr_bytes':len(err),'stdout_sha256':sha(out),'stderr_sha256':sha(err)}
    if timed_out: raise RuntimeError('report tool timeout; owned group terminated and raw streams retained')
    return result

def main():
    args=sys.argv[1:]
    raw_stdin=sys.stdin.buffer.read() if args and args[0]=='write' else b''
    live=ROOT/'live';live.mkdir(exist_ok=True)
    with (live/'writer.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        old=sorted(live.glob('call-*'))
        if any(not (p/'result.json').is_file() for p in old):
            raise RuntimeError('prior incomplete call; return to caller without retry')
        current=live/('call-%04d'%(len(old)+1));current.mkdir()
        request={'started_at':now(),'argv':sys.argv,'python_executable':sys.executable,'cwd':os.getcwd(),
                 'stdin_base64':base64.b64encode(raw_stdin).decode('ascii'),'stdin_bytes':len(raw_stdin),'stdin_sha256':sha(raw_stdin),
                 'before':census(PROJECT),'guidance_sha256':sha((ROOT/'guidance.txt').read_bytes()),
                 'workbench_sha256':sha(Path(__file__).read_bytes()),'report_tool_sha256':sha((SUPPORT/'report_tool.py').read_bytes())}
        write_json(current/'request.json',request)
        (current/'stdin.bin').write_bytes(raw_stdin)
        code=0
        try:
            if args==['guidance']:
                raw=(ROOT/'guidance.txt').read_bytes();result={'content':raw.decode(),'sha256':sha(raw)}
            elif args==['list']:result={'files':census(PROJECT)}
            elif args==['origins']:result=json.loads((SUPPORT/'origins.json').read_text())
            elif args==['tool']:
                raw=(SUPPORT/'report_tool.py').read_bytes();result={'content':raw.decode(),'sha256':sha(raw)}
            elif args==['baseline']:result={'kind':'actual preparation byte snapshot, not a Git ref','files':census(SUPPORT/'baseline')}
            elif len(args)==2 and args[0]=='baseline':
                path=resolve(args[1],SUPPORT/'baseline');raw=path.read_bytes()
                result={'path':args[1],'content':raw.decode(),'sha256':sha(raw)}
            elif args==['diff']:
                result={'kind':'byte comparison; not Git staged/commit history',
                        'baseline_to_current':delta(census(SUPPORT/'baseline'),census(PROJECT)),
                        'task_start_to_current':delta(json.loads((SUPPORT/'task_start.json').read_text()),census(PROJECT))}
            elif len(args)==2 and args[0]=='read':
                path=resolve(args[1]);raw=path.read_bytes()
                result={'path':args[1],'canonical_project_path':path.relative_to(PROJECT.resolve()).as_posix(),'content':raw.decode('utf-8'),'bytes':len(raw),'sha256':sha(raw)}
            elif len(args)==2 and args[0]=='write':
                path=resolve(args[1]);raw_stdin.decode('utf-8')
                path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw_stdin)
                result={'written':args[1],'canonical_project_path':path.relative_to(PROJECT.resolve()).as_posix(),'bytes':len(raw_stdin),'sha256':sha(raw_stdin)}
            elif len(args)==2 and args[0]=='remove':
                path=resolve(args[1]);raw=path.read_bytes();path.unlink()
                result={'removed':args[1],'canonical_project_path':path.relative_to(PROJECT.resolve()).as_posix(),'removed_bytes':len(raw),'removed_sha256':sha(raw)}
            elif args in (['build'],['check']):result={'child':child(args[0],current)}
            else:raise ValueError('allowed: guidance; list; origins; tool; baseline [PATH]; diff; read PATH; write PATH (UTF-8 stdin); remove PATH; build; check')
        except Exception as error:
            result={'interface_error':type(error).__name__+': '+str(error)};code=2
        raw=(json.dumps(result,indent=2,sort_keys=True)+'\n').encode()
        (current/'stdout.bin').write_bytes(raw);(current/'stderr.bin').write_bytes(b'')
        record={'finished_at':now(),'exit_code':code,'stdout_bytes':len(raw),'stdout_sha256':sha(raw),'stderr_bytes':0,'stderr_sha256':sha(b''),
                'after':census(PROJECT),'authority':'NONE','result':result}
        write_json(current/'result.json',record)
        sys.stdout.buffer.write(raw)
        return code

if __name__=='__main__':
    try: raise SystemExit(main())
    except Exception as error:
        print(type(error).__name__+': '+str(error),file=sys.stderr)
        raise SystemExit(2)
