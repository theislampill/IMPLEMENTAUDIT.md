# Read-only host image observation — frozen local proposal

The distinct operation `G132_HOST_IMAGE_OBSERVATION_20261122_01` is ready for independent source
and operation review. Root retains admission, publication and launch authority.
Source `c53ed7de85de22ce313233472c8d8f02ad8e9d02` / tree `d60733459425a059d961b6adc2aae9811bbb761c` is unchanged. Failed boot operation 01 is
preserved and is not retried. Current child receipt: `refs/implementaudit/continuity-receipts/dg16-dg18-restored-20261122/G0002@9eb19af26c4fe90a35422856c79d5d03ee59ee47`.

## Why this observation is needed

Actual run 44998068134 attempt 1 reported image 20261116.133.1 while the frozen
boot operation required 20261116.376.1. The initial gate preceded log-directory
creation; collection also refused the context. The actual job log is 20,560
bytes, SHA-256 115fa6e22ee0eaddc3ccc184395d78a7b61408844274a6c26aa5729d3135aa7c.
The new image's finite native/NSS facts have not yet been received.

## Candidate and meaningful limits

The four phases are context, complete fresh selected-source preparation, inputs,
and collect. Context is retained before image comparison can suppress evidence.
An unexpected image remains UNQUALIFIED and is never adopted. The exact public
provider/run/attempt/root/boot tuple still gates the read-only observation.
The unchanged c53 setup/loader/receiver obtains twelve selected pins, four
aliases, NSS/passwd preimage selectors, NSCD and absent-path facts, closing
bookends, and the separate original full-startup result. Raw account bodies stay
in the original receiver's process-local memory. No session is constructed.

No launcher, policy, NSS administration, namespace probe, protected finalizer,
runtime/private provider or original operation is exposed. All original native
pins and limits remain unchanged: 240-second process wall, 120-second CPU,
1,610,612,736-byte address space, 256 descriptors, 268,435,456-byte file bound,
8-minute job, attempt 1 and no automatic retry.

The R2 exact file reader, copy and closed-export verifier are byte-identical.
The manifest-inclusive export bound is 2,097,152 bytes; upload selects thirteen
explicit public paths only after successful collection. Partial/adverse bytes
and missing observations remain explicit. This is a byte bound on selected
export files, not a claim about the provider's ZIP wrapper size.

## Exact proposed host files

| File | Bytes | SHA-256 | Git blob |
|---|---:|---|---|
| engineering/g132-host-image-operation/run-owned.py | 25820 | cf4719fd7a03ee6c7749a7603e9908de336a9933489ec31f74c6a5f9138da4f2 | 8d15bd2af7e41e2fdb5b69acee642915d913b999 |
| .github/workflows/dg16-g132-host-image-observation.yml | 8054 | bc59676b93f95d60de02b5707f439a1c8ce34a49c11c2afd4912247de1e8b40d | 7d4e1b50a03c50d8ba5de287f2a48c3fc9c03f91 |

Both entries are mode 100644. Proposed parent is `c53ed7de85de22ce313233472c8d8f02ad8e9d02`; the pure in-memory
expected host tree is `64c290e00ab1c96895858873522142e69778de22`. No commit, tree object or ref was created.

## Verification and remaining premise

The local bootstrap RED reproduced refusal before log allocation. Seven focused
new context/export controls then passed; their complete stdout/stderr and exit
records are retained. Hosted identity and process-limit application were fixture
boundaries; real temporary files and the real export functions were used.
Source compilation, Bash syntax, unchanged helper comparisons, finite invocation
checks, exact nine source-reference members and the host-tree calculation yield
39 passing data/source checks and 0 gaps.
No source qualification, original test, native host measurement or hosted run
was repeated. PLAN.md and DESIGN.md retain the bounded reasoning and test scope.

The proposal is sufficient to receive its finite current-host facts if its source,
identity and closing checks complete. It does not itself adopt the image or
establish protected readiness. The original NSS validator reports its first
refusal: non-files-only NSS prevents inferring later account success. Those
unknown conditions, the separate full-startup result and the unperformed copied
runtime remain visible. Root must adjudicate actual results before any new NSS
administrative operation or accepted host-profile change.
