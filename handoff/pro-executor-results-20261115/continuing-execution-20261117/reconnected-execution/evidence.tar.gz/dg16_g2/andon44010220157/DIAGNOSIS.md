# G2 run 44010220157: bounded Andon diagnosis

**Return to:** `/root`  
**Authority:** NONE  
**Entry:** Direct `audit-andon` cord-pull; no canonical Andon registration or lifecycle decision  
**Disposition:** Two concrete source-backed volatile emitters identified. The first stderr candidate has an exact 103-byte positional match. Neither historical emitting-byte attribution nor full G2 acceptance is established. Run the two existing, ordinary selected measurements below before choosing a correction.

## Actual current failure

The authentic public packet establishes a completed pair whose whole relation is unequal. It does not establish an incomplete verifier execution. Both execution and receiving causal observations reached their respective COMPLETE phases without a causal exception. The episode then refused acceptance with `FULL_PAIR_NOT_COMPLETELY_RECEIVED`; its disposition is `VALIDATED_UNACCEPTED_NONZERO_RECEIVE` and receiving is `NOT_RECEIVED`. No live independent-review hold was started.

| Current observation | Legacy | DAG |
|---|---:|---:|
| Process exit | 0 | 0 |
| Actual report slots | 111 | 111 |
| Actual report skips | 193 | 193 |
| Normalized stderr bytes | 193,875 | 193,875 |
| Raw stderr bytes | 190,228 | 190,228 |
| First unequal normalized stderr offset | 103 | 103 |
| Normalized stdout bytes | 198,313 | 198,313 |
| First unequal normalized stdout offset | 4,907 | 4,907 |

Portal, repro, pending-loader and pending-durability relations are equal. `whole` has four differing fields. Two are the stdout/stderr hashes, whose public location digests match the maintained schema paths; the two unequal byte fields account for the other two. A byte field's `difference_count: 1` means that one complete field differs. It does **not** mean one character or one line differs, and the four whole-field differences do not imply four independent defects.

The stderr location is raw byte 103, before report ordinal 0. The 128-byte spans at `[39,167)` have different hashes. Their bytes were not exported. The report interval names `tests/host_session_binding_hardening.py`, 34,077 bytes, SHA-256 `0890585f57d5da90842db1c0a6f8d155a9e3d1f386286510ef9e4569f104fe21`. The locator explicitly labels this association `VALIDATED_REPORT_INTERVAL_NOT_EMITTER`. Several shell checks and tests execute before that first unittest report. Its source descriptor must not be promoted into attribution to the hardening program.

The final cleanup record states that private outputs were not uploaded and their retention was live-job-only. The complete seven-member ZIP contains no raw canonical stream. Its descriptors cannot recover the missing literal bytes. The new metadata narrows the investigation; it does not repair that historical information loss.

## Evidence receiving and source binding

The supplied ZIP was rechecked as 16,577 bytes with SHA-256 `fecde4055d5db19ca1b77981a2f7d40b71041b8598609180d882e4e6a0d90467`. All seven extracted members are byte-identical to the ZIP members. All six data-member descriptors in `ARTIFACT_MANIFEST.json` match. Public documents were decoded with the **exact packet's** `host_utility.public_codec`, including PROBE's shared strings table.

The product manifest binds commit `05371833d30e81815475d0d00aa107b6be5fbba3`, tree `d5a35d88ae08df60a48ad758ffc2fe5482de6083`, 1,766 members and 167,023,479 bytes. Nine pertinent local files were individually matched by byte count, SHA-256 and Git blob identity to that manifest. Eight came from the `source205` export; the observation-bound mutation test came from the retained corrected source. This is exact member binding, not a claim that the `source205` directory is a current or complete checkout.

The small read-only `source_discriminator.py` preserves these checks and the source arithmetic in `SOURCE_DISCRIMINATOR.json`. It parses source and public evidence only. It executes no product fixture, owner function, native operation or verifier.

## Stderr: exact-position source hypothesis

The causal source chain is concrete:

1. `scripts/verify-package.sh:688` runs `tests/continuity-contract.test.sh`, before the first report-producing test at line 694.
2. `tests/continuity-contract.test.sh:531–547` prepares two racing successor fixtures for controller `split-brain`. The claim at line 544 captures stdout but leaves stderr inherited. The initial predecessor claim at line 539 explicitly suppresses stderr.
3. `skills/implementaudit/scripts/claim-run.sh:576–587` allocates a fresh run name and derives a 32-hex claim ID from `/dev/urandom`.
4. `claim-run.sh:278` routes the controller binding to `initialization-prepare`.
5. `skills/implementaudit/scripts/claim-run-rotation.py:4504–4517` incorporates the claim ID into `refs/implementaudit/controller-initializations/<controller>/<claim-id>`. Lines 4561–4584 create the initialization record and return that ref plus its blob OID.
6. `claim-run-rotation.py:4797` writes the resulting token to stderr.

The literal prefix before the first claim byte is:

```text
claim-run.sh: initialization pending; token=refs/implementaudit/controller-initializations/split-brain/
```

Its length is **exactly 103 bytes**. The actual first stderr difference is also offset 103. The diagnostic's claim ID and dependent initialization-record OID can vary between fresh fixture runs. The existing stderr relation changes only validated unittest elapsed operands; these leading diagnostic bytes survive unchanged.

This is a strong, directly testable explanation for the current first stderr difference. The missing raw spans prevent asserting that the actual historical prefix was this string. Equal overall lengths also do not rule out later unequal stderr bytes.

### Minimum authentic stderr discriminator

On a suitable ordinary runner, use product053 and execute the existing unmodified command twice in separate fresh test invocations:

```bash
bash tests/continuity-contract.test.sh
```

Capture each invocation's complete stdout, stderr and exit before reading excerpts. Stop after the first invocation if it fails or produces incomplete evidence. Do not substitute a new claim implementation or bypass the maintained physical-interpreter guard.

The decision-changing observation is whether both unchanged cases pass and the first stderr inequality is at the first claim byte of the exact initialization message above. Inspect all remaining differences as well. The two actual claim tokens and their framing must be available in the disposable test output; a record containing only unequal span hashes would leave the same attribution problem unresolved. This test creates only its existing disposable fixture repositories; it does not need native host admission or a full G2 pair.

## Stdout: a remaining volatile test report

A second concrete emitter survives the prior two-line diagnostic correction:

- Current `tests/observation-bound-mutation-integrity.test.sh:1223–1225` prints the guard-loss JSON record with fields `case`, `status`, `guard_exit`, `observed_syscalls`, `stage_fsync_calls` and `recorded_protected_effects`.
- Its `observed_syscalls[].path` values are actual repository-relative source/backup/stage paths. Its `recorded_protected_effects[][0]` values include the same backup/stage paths.
- The backup and stage paths at lines 1186–1188 contain the freshly claimed `.IMPLEMENTAUDIT/runs/d48-fence-<allocation>` and the mutation transaction ID.
- `tests/distributed_generation_fence.py:34–52` creates a fresh disposable repository and claims the run. `claim-run.sh` supplies the allocation and fresh claim ID; the transaction derives from that identity.
- The default `state_family` reaches `guard_loss_effect_recording_heldouts` at line 3073, before `terminal_journal_custody_heldouts` at line 3074 and its previously corrected `R36_FINAL_DIRECTORY_FSYNC` report.

`full_stdout.normalize` does parse top-level JSON, but this record has none of its recognized scopes or exact pending/turn report identities. It therefore leaves the record unchanged. The special D48 normalization applies only to the separate `D48_RESULT_PREFIX_CAPTURE=` line. It does not rewrite this guard-loss JSON.

This establishes a remaining source-level route for allocation-dependent stdout. It does **not** bind that record to historical normalized offset 4,907. The public packet has no stdout raw-location map or literal prefix. Do not call the stdout issue solved by the prior final-directory-fsync change, and do not attribute the actual offset solely from source order.

### Minimum authentic stdout discriminator

The test already has a case selector. Run this unchanged case twice on product053, with the same complete capture and first-failure stop discipline:

```bash
bash tests/observation-bound-mutation-integrity.test.sh --guard-loss-effect-recording-heldouts after-displacement
```

Compare every emitted JSON field and every remaining byte. Specifically determine whether allocation-bearing paths differ while status, effect order, effects, guard failure and the unchanged source assertions agree. The real case must reach `R36_GUARD_LOSS_EFFECT_RECORDING_HELDOUTS=PASS`. Source inspection or synthesized dictionaries do not satisfy this observation. This isolated cooperating fixture requires no native host-admission run and no complete package suite.

## Countermeasure scope and escalation recommendation

**Local versus systemic disposition:** There are two specific test-output volatility mechanisms to discriminate. The current receiver correctly refuses unequal streams under its adopted rules. There is no evidence here for a scheduler ordering bug, a hardening-test defect, or a need to replace the comparator. The capture limitation is also concrete: the exported metadata cannot identify the lost raw emitter. It warrants preserving the complete output of the small selected measurements; it does not warrant a new general tracing framework.

After the measurements confirm the actual behavior, the narrow source options are:

1. For the continuity fixture, keep the runtime helper's operational initialization diagnostic intact. At the two test-owned calls, capture and check the expected diagnostic, then emit an appropriate stable test result. Do not change all callers of `claim-run` merely to make this test's stream deterministic.
2. For the guard-loss fixture, retain every assertion over the actual complete paths and actual effect set. If its public test summary is meant to be deterministic, it can report the already-validated source/backup/stage roles and effects. Raw path values must not be erased before their assertions. Because the printed effect paths carry more meaning than the previously removed random hashes, simply dropping the fields without a demonstrated substitute is not yet justified.
3. A broader normalization exception would require a separate owner decision and evidence for the exact allowed relationship. This diagnosis supplies no such adoption.

Targets are the identified test-owned diagnostics. Non-targets are production initialization behavior, fixture effect validation, guard-loss behavior, canonical success/failure semantics, the comparator, all existing normalization rules and unrelated emitted bytes. A future correction should show that the non-target assertions and behavior remain intact and use the smallest existing cases that exercise those changes.

**Escalation recommendation:** Return to `/root` for the two ordinary source measurements and subsequent owner/source decision. Do not request another expensive full G2 run merely to recover these readily scoped observations. The current full-G2 inequality remains unresolved, and no original row or gate is newly accepted.

**Follow-up evidence obligation:** Preserve the new source/runtime bindings, complete selected-case stdout/stderr, actual exits, all observed differences and before/after source identities. If a local repair is then authorized, verify it with those same selected cases and unchanged assertions. Before any later full pair, ensure the proposed receiving step can expose or classify the remaining unequal bytes during their actual lifetime; a nearest-report association is insufficient.

## Work performed and authority boundary

No product/source changes, host changes, ref mutations, native operations or full verifier reruns were performed. No child was created. The read-only source discriminator and this bounded return are the only new artifacts. No historical evidence was overwritten. The caller-supplied continuity receipt `refs/implementaudit/continuity-receipts/pro-dg16-18-continuation/G0010@ae4df030bc80e93f97fb9e87d4b215be5ae93632` is recorded only as the dispatch binding; this child did not mint or independently claim currentness.

The previously removed random stdout hashes remain a separate demonstrated correction. They did not purport to fix stderr or all other stdout emitters. No repair is applied by this return, and nothing here grants PASS, AUDIT_COMPLETE, full G2, canonical conversion, retirement, release or closure authority.
