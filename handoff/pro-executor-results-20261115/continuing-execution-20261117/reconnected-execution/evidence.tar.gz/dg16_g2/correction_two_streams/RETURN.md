# Two test-owned stream corrections: bounded source return

**Return to:** `/root`  
**Authority:** NONE  
**Classification:** Source-only intermediate; no original G2 acceptance  
**Dispatch binding supplied by parent:** `refs/implementaudit/continuity-receipts/pro-dg16-18-continuation/G0010@ae4df030bc80e93f97fb9e87d4b215be5ae93632`

The proposed patch changes exactly two test files. It changes no production helper, comparator, normalizer, selector, runtime owner, or existing assertion. The exact patch is `two-stream-correction.patch`, 4,353 bytes, SHA-256 `57a4db98d27ef7c518a40c0d68019c5678d7e1d8831227c22ed122fab8a7b1c3`. Root owns its review, any remote application, actual hosted verification, and all acceptance decisions.

## Source and authentic evidence

Both input members match the supplied product manifest for commit `05371833d30e81815475d0d00aa107b6be5fbba3`, tree `d5a35d88ae08df60a48ad758ffc2fe5482de6083`, by byte length, SHA-256, and Git blob identity. This is exact member binding; it does not assert that `source205` is a current complete checkout.

| Repository path | Original bytes | Candidate bytes | Candidate Git blob |
|---|---:|---:|---|
| `tests/continuity-contract.test.sh` | 37,824 | 38,765 | `784fbe88fd1d2c98238303a6b83b35bcb4ef62f0` |
| `tests/observation-bound-mutation-integrity.test.sh` | 246,413 | 246,874 | `347bcc8c6ff4e65afb48d63d6e84f104c1c88bbb` |

Candidate SHA-256 values are respectively `09d35d920677e39b1205e2a6c86d8df9883beb1c91fae0aae319c1d1255ad689` and `9858618db8f04eef7cf1314ca1db621f3997cc6b65bc737e427497fd15a95a0d`. Product modes remain `100644` and `100755`; the content-only patch contains no mode change.

`original/` retains the two exact inputs. `authentic_evidence/` retains byte-identical copies of both actual run 44045757411 ZIPs and every one of their 22 members, including all complete raw streams. The original input paths and original artifact directories were rechecked unchanged. `INPUT_BINDING.json` records their identities and locations.

The authentic measurements remain original-source observations: both selected commands exited zero twice; continuity stderr differed at byte 103 and guard-loss stdout at byte 221. Nothing in the correction relabels or overwrites those captures.

## Continuity diagnostic ownership

The two racing successor preparations now redirect their complete helper stderr into distinct test-owned files. Before fixture checkpointing can change initialization state, the test reads the fresh `.claimed` claim ID, derives its exact initialization ref, and reads that ref's actual OID. It writes the expected complete initialization line to another test-owned file and compares it byte-for-byte to the first captured line.

The remaining captured stderr is forwarded unchanged. Thus the existing stable ignore note and any additional later diagnostics stay visible. The only successfully checked bytes removed from the public stream are the two volatile initialization lines. The complete operational diagnostic remains emitted by the unchanged production helper and retained in each test-owned capture during execution.

The original claim arguments, claim exit check, initialization calls, racing activation behavior, winner/loser checks, and terminal marker are unchanged. Missing refs or an initialization diagnostic that does not bind the fresh claim fail explicitly. The actual new ref/OID assertion has not yet been exercised on a hosted runner.

## Guard-loss role reporting

The JSON summary is moved below every original complete-path and actual-effect assertion, including the final `fence.assert_guard_effects(..., clean=False)`. Only then does an exact dictionary map `target` to `source`, the actual `backup_rel` to `backup`, and the actual `stage_rel` to `stage`.

The existing fields remain: `case`, `status`, `guard_exit`, `observed_syscalls`, `stage_fsync_calls`, and `recorded_protected_effects`. Each event retains every field, with only its `path` value replaced by the role. Recorded effect pairs retain their order, count, and effect. The original events, rows, actual paths, journal, payload, and assertions are not mutated.

Every path that would enter either summary collection must belong to the exact role map. An unknown event or recorded-effect path is refused before any summary is printed. No prefix matching, regex replacement, basename folding, or general normalization is introduced.

All three loss variants use that same emission point. Their existing expected effect sequences establish these role sequences:

| Existing variant | Ordered recorded protected effects |
|---|---|
| `after-displacement` | `(source, replace)`, `(backup, replace)` |
| `after-stage-create` | `(source, replace)`, `(backup, replace)`, `(stage, create)` |
| `after-stage-write` | `(source, replace)`, `(backup, replace)`, `(stage, create)`, `(stage, write)` |

The `protected-success` branch emits no such JSON summary and is unchanged. This table is source inspection, not new runtime evidence for the stage variants.

## Bounded verification

Both `bash -n` commands returned 0. The original and candidate changed Python heredocs compile. Exact inverse edits establish byte equality for the entire rest of both files; this includes every existing assertion in its original order and every selector. The patch has only the two named paths.

`git apply --check --whitespace=error-all` returned 0 with empty stdout/stderr against a separate copy of the exact originals. Applying it there also returned 0 and reproduced both candidate files byte-for-byte. `PATCH_APPLICATION.json` retains the commands and results. The earlier `git diff --no-index --check original candidate` returned 1 with no diagnostics, reflecting the known source differences; the subsequent apply check supplies the successful explicit whitespace check.

`verify_correction.py` is a bounded source/evidence analysis, not a product test. It compiles the changed heredoc without running it and executes only the four-statement summary projection against data recovered from the retained actual report. It proves that substituting original paths back into the role summary exactly recovers every original JSON field, effect, order, count, status, and guard state. Analysis controls with an unknown event path or recorded-effect path both refuse before printing.

The continuity analysis checks the captured initialization-line framing against the recorded parsed fields, removes only those two lines, and retains every other byte. That parsing evidence is not an execution of the new fresh-ref binding assertion.

| Capture transformation only | Predicted stdout | Predicted stderr | Pair relation |
|---|---:|---:|---|
| Continuity | 130 bytes, unchanged | 362 bytes, original stable notes | Equal for both retained captures |
| Guard loss, `after-displacement` | 359 bytes, roles plus unchanged markers | 0 bytes, unchanged | Equal for both retained captures |

These predicted streams live only under `analysis_only/`; they are labelled in `STATIC_AND_TRANSFORMATION.json` as **ANALYSIS_ONLY_NOT_NEW_HOSTED_EXECUTION**. They do not replace authentic evidence or prove any new hosted pass. No full suite, product fixture, native operation, local guard bypass, remote effect, or child agent was invoked.

## Minimum actual hosted verification

On the corrected source with an exact recorded source/runtime binding, run the same two existing commands, each twice in separate fresh test invocations:

```bash
bash tests/continuity-contract.test.sh
bash tests/observation-bound-mutation-integrity.test.sh --guard-loss-effect-recording-heldouts after-displacement
```

For each command, retain complete stdout, complete stderr, actual exit, source/runtime bookends, and cleanup evidence. Stop that pair after its first invocation if it fails or its capture is incomplete. Both invocations must exit zero with their existing terminal marker. Compare all raw bytes and all summary fields, requiring equality for these corrected selected-case pairs. Preserve any unexpected bytes before further diagnosis.

The continuity run must actually exercise both new claim/ref/OID comparisons. The guard-loss run must actually reach its unchanged assertions and then report the role-bearing summary. The source table for the stage variants is not an alternative to any later owner-required runtime verification of those variants.

Passing these selected cases would establish bounded post-correction evidence. It would not accept the original full G2 relation, complete an independent review, grant a lifecycle transition, or authorize closure.

## Rollback and handoff

Discard the two candidates or reverse this exact patch to restore the original source members. The frozen return manifest binds the patch, candidates, analysis, original evidence, and this report. No source outside `correction_two_streams/` was written. No canonical run state or continuity receipt was minted or altered.
