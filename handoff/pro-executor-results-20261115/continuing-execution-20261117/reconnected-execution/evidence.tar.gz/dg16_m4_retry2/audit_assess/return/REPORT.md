# Independent receiving of the completed DG17 episode

Report state: FINAL

**Disposition: NEEDS_REVISION.** The packet supports actual admitted-source observation, a substantive diagnostic need, recorded governed and direct child returns, independent local governor rederivation, and a verified separate local repair. It does **not** support complete prompt-independent P07/H07/T4 qualification: the governed dispatch wrapper explicitly supplies the topology answer tested by the unchanged original contract. Preserve the useful observations and repair at their demonstrated scopes. Do not turn this result into an original-case award, native currentness, or closure.

## Review identity and immutable inputs

- Reviewer: `/root/m4_assess_1`; return owner: `/root`; authority ceiling: **NONE**.
- Requested model: inherited parent ChatGPT, GPT-6 Astra Pro. Actual observable identity: **ChatGPT, GPT-6 Astra Pro**, from this reviewer's developer instruction. No independent backend deployment/model attestation is exposed.
- Fresh context: the route declares `fork_turns=none`; my received context contains this commission and governing instructions, with no authoring history. I did not author the subject, prompts, repair, package, or native selection.
- Other-reviewer visibility: I read `roles/INDEPENDENT_RECEIVING.json` as prospective role/admission evidence, and the diagnostic child returns and governor decision as objects of review. No prior final semantic assessment of this completed episode was supplied or used. Later parent messages requested preservation of adverse findings and narrow scopes; they did not supply a positive disposition.
- First measured reviewer time: **2026-11-17T04:08:39.895819+00:00**. Finish time: **2026-11-17T04:16:23.433742+00:00**. The start is the first UTC observation during the initial envelope/mission read, not a claimed backend dispatch timestamp.

| Binding | Exact value |
|---|---|
| Envelope | 5,638 bytes; SHA256 `cca9ac323ce3a874ab1e0626e79bccf626786be4e3fe8e6757139300def7de90` |
| Mission | 1,185 bytes; SHA256 `bc831b3a87353764855683987de55d0d21aed795a66e59f5a46ff8fab23fbf6c` |
| Immutable packet | 389,541 bytes; 1,558 members; SHA256 `40d01d44a22abd45d6bb9d745550f88983f3158ab1f1d69913fa08a197f72af3` |
| Complete executing review package | 34,770-byte manifest; 77 members; SHA256 `ce75a9d550cc69e605b75737fdd244c45c5ad89d99ed8864fbf0688421f7d2a3` |
| Review source | `05371833d30e81815475d0d00aa107b6be5fbba3`; tree `d5a35d88ae08df60a48ad758ffc2fe5482de6083` |
| Selected review skill | `package/skills/audit-assess/SKILL.md`; 2,039 bytes; SHA256 `6f5d5738b9efd5fa5d4c35868400220458a2f81179d4081fce508ef65c3f72e4` |
| Resolver receipt | 786 bytes; SHA256 `b45698b7828a9f6656e8ad747862f0d0fde4cfa6aa793847cfa35bd32d6bc320`; exit 0 |
| Original target source | `a297957be11feb494c0ec467235794a1e0c54751`; tree `b08dc4ecf4028beeedb579a312eccae23cb5d863`; 78 package members |
| Original episode | run `44006227023`, attempt 1; launch `7dc17525563dcadcf631085b5db1fbd1e44120d8`; task commit `2f182c7a64775451f6ef095aa29cdae4044941ef` |
| Current selection | M4 run `44014110985`, attempt 1; launch `52430e1fee2338ae6dcd8be73ae51d3196686416`; node `DG17_RECEIVING` |

The two source packages are distinct; no equivalence is claimed. I read the exact selected audit-assess skill and applicable shared review-owner material in `plan-lifecycle.md` and `audit-playbook.md`; installed aliases were not substituted. The resolver's recorded stdout digest equals the exact selected skill pathname plus newline. I inspected its source and receipt without rerunning target computation or activating a controller.

I verified every listed byte count and SHA256 for the 77-member review package and 1,558-member immutable packet, with no mismatches, duplicate paths, or member symlinks. Review-package Git blob IDs also match. I separately checked all 78 original target-package members against the admitted packet, including their Git blob IDs. Native captures `DG17_FINAL/commands/001-source-tree` and `003-package-source-unchanged` bind the original package scope to a297 and record a clean package-path diff to its launch. The launch's immediate parent is `5488adffe48660376a758a828a0748b97c1c0efd`, not a297; package equality does not assert full launch-tree equality.

All extracted files match their exact native-selected archives: 1,132 files from `DG17_FINAL.zip`, 150 from `DG17_GOVERNOR.tar.gz`, and 29 from `DG17_ORIGINAL_CONTRACTS.tar.gz`. I checked 291 captured stdout/stderr/stdin streams across 108 original-host and 32 local-governor command records. These path/capture counts include repeated snapshots; they do not multiply independent support.

Nineteen frozen files are directly present under `DG17_ORIGINAL_CONTRACTS/episode_06`. The separately named neutral mission file is absent there, but its full text is embedded between explicit markers in `DG17_GOVERNOR/governed-prompt.txt`: exactly 909 bytes, SHA256 `ad688ca803ad80ff6f7ce5d3371a4e985f79618ff30b910d108418c6eb131d28`. This reconstructs the twentieth frozen content exactly; it does not cure the added wrapper cue.

## Original requirements and material finding

The unchanged original body has SHA256 `ca62f4899a45544549f623a0312c16121bb99f432ccb87a87b7361974ceb94c4`. Its P07 row, line 555, requires governed Andon with return and rederivation. H07, line 583, requires the same abnormality through both entries, the appropriate return owner, and no authority gain. Terminal clause 4, lines 879–882, is the corresponding T4 governor-child/direct-invocable obligation. Lines 588–595 require model-facing missions independent of target headings, loop labels, topology answer, and expected disposition, with exact prompt and identity evidence retained. The frozen rubric, SHA256 `750e8778710f898b4b40ac2aa1694290742890eba29c2865c3a03163aff73381`, lists `L4` among forbidden mission phrases at lines 57–68 and preserves six receiving predicates.

### F01 — The added governed wrapper supplies the tested topology answer

**Finding: NEEDS_REVISION; high confidence; STIMULUS defect; owner: the governor's model-facing dispatch wrapper.**

`DG17_GOVERNOR/governed-prompt.txt`, line 1, says: “This is the governed entry: L4 -> audit-andon -> local governor.” Its exact prompt is 4,078 bytes, SHA256 `e7d1bbeeeb2b6e8eb38c98af67ffaa4fd92f0462c28cc4dae3831352345f9274`; the same text is present in `governed-dispatch.json` under the actual spawn arguments. This is the tested topology answer supplied as an instruction to the model. Calling the interior 909-byte text the neutral mission does not make the full presented prompt independent of that answer.

This finding does **not** prohibit the selected skill from containing its normative routing policy. The target audit-andon skill requires a genuine governor envelope, exact package/currentness/object identity, current abnormality, authority ceiling, and diagnostic value. Actual caller identity, source policy, safety restrictions, and legitimate route metadata remain necessary. The concrete adverse evidence is the wrapper's explicit answer-shaped arrow, beyond those required facts. The direct prompt's explicit cord-pull and caller/authority information are not, by themselves, a newly invented violation.

The task's causal answer was not disclosed in the neutral leaf mission. Both diagnostic accounts and the repair can remain useful. The impact is narrower: the episode cannot prove the original prompt-independent topology/loop behavior as a complete qualified model-facing cell. Scope and risk are acceptance overclaim, not a demonstrated defect in the repaired report or in audit-andon source. The bounded route is governor-owned prompt correction followed by actual fresh qualification at the unchanged oracle and source boundary; no product, package, or host repair follows from this finding. Preserve this pre-correction prompt and its nonqualifying result. This review does not declare any stimulus repair or its required controls complete.

### F02 — Coincident concrete return owners limit the return-owner discriminator

**Finding: NONVERDICT for the stronger discrimination claim; high confidence about the aliasing; no defect asserted in ordinary dual use.**

Both entry records return to `/root/dg17_governor`, once in its governed capacity and once as the direct cord-pull caller. Different role labels do not create different concrete recipients. That is valid ordinary dual use and supports two bounded entry/return observations. It cannot by itself distinguish correct direct-to-caller return from an implementation that always returns to that same governing actor.

Original body lines 599–613 separately require independently removed/inverted controls, including governed/direct return ownership. No such negative is demonstrated by these two positive returns. Preserve the observed positive scope, but do not award an inverted return-owner control or a mutation family from it. A future claim of that discrimination needs an actual case whose return-owner observations distinguish the two behaviors, or the existing native owner's equivalent independently inverted control. This is not a demand for different actors in every valid ordinary invocation, a new host campaign, or a new prerequisite for the separate local repair.

## Substantive chain established by the packet

### Identity, actual failure, admission, and need

`DG17_FINAL/commands/042-verify-report` records the real verifier's exit 1 at 02:53:35 UTC, complete 266-byte mismatch output, empty stderr, and no timeout. The harness's `expected_exit: 1` does not turn that failure into report acceptance. Admitted STATE registers `p07-actual-report` as `failed-criterion`, preserves the witness, and contains report use. Its G0002 resume, verification, require-current, full-root validator, and canonical resolver captures follow at 02:53:35–38 and succeed. This is actual archived admission evidence at the original hosted scope, beyond the earlier local interpreter/custody admission failure. It does not erase that earlier failure or establish native Stop.

The prospective appointment names `/root/dg17_governor` as accountable local governor, with local copied-subject repair authority only. The sponsor remains explicitly exposed to the receiver rubric and nonqualifying for blinded principal-Root diagnosis. The appointment preserves remote effects and integration authority with the principal. The prior role-admission record permits a fresh actor to occupy the bounded local role; it is not itself a final episode verdict.

The local governor verified the actual hosted failure/currentness streams in command 006 at 02:57:17, before recorded governed dispatch. Its own verifier rerun, command 009 at 02:58:48, followed dispatch capture 008 at 02:58:39. Therefore the supported ordering is **actual hosted failure → registration/admission → fresh local governor receipt of the verified failure → dispatch**. Do not claim that this fresh local actor personally ran the verifier before registration or before dispatch. That stronger temporal premise is not in the evidence.

The diagnostic need is substantive. Current profile selection and in-memory rendering agree with the unchanged expected report; stored output and the selected cache entry contain historical formatting. The key sees jobs and profile name but omits heading/separator used by rendering. The old and current effective profiles therefore select the same stored bytes. The original three unit checks pass despite the exact verifier failing. Wrong selection, broken rendering, an obsolete expected report, and stale reuse are decision-distinct hypotheses; the inspected source and data discriminate them. A mere output edit or cache deletion would leave recurrence, while disabling reuse would violate the unchanged-input requirement. Evidence: original subject sources/requirements/history and governor commands 007, 009, 010, 012, 022–025.

### Actual returns and governor-owned decision

The exact recorded spawn arguments use separate `fork_turns=none` children, `governed_diagnosis` and `direct_diagnosis`. Their final messages return to their recorded caller; governed completion precedes direct dispatch. Prompt/result hashes are retained in `governed/direct-dispatch.json`, `governed/direct-return-evidence.json`, and the exact result texts. Governed result: 13,243 bytes, SHA256 `476b9c9eeed8c213783ab04c03c84ee211c1e5155ce650cb81439397c1baafbd`. Direct result: 12,875 bytes, SHA256 `81d3c2bdf8207794f2ce797a86822dfb777d061f500dc4f33ea09e67aca31e8d`.

Both supply bounded causal accounts, local/systemic distinctions, alternatives, escalation recommendations, and concrete verification needs. Neither result claims to repair, register a new canonical L4, acquire currentness, route another child, or accept/close the object. The direct record uses the same frozen subject and excludes the governed answer from its prompt. The two results share the same evidence and model family; agreement is not two independent mechanisms or two acceptance votes.

These are archived collaboration captures and model-reported load/observation details. Full standalone native leaf tool transcripts are not included in this packet; the reports refer to them. I do not promote those references into independent backend authentication or a complete census of every leaf read. The governor's independently captured source checks and local build evidence directly corroborate the substantive diagnosis, rather than relying on child prose alone.

`DG17_GOVERNOR/commands/018` and `019` capture separate post-return STATE then ROADMAP reads. Command 021 binds the actual G0003 return identity and streams. Command 022, at 03:09:34, freshly reads source, derives the cache defect, and chooses the bounded local repair. The decision is separately authored after receipt, not a child-authorized transition. The return commit is `4306750242f3c2a99bbbb90b00e9098fa4d63f9b`; the exact combined return SHA256 is `55fd73f2335337fdffbb6ccc27b11ad93c77e88ad663c3f5bcc4cded3a571c18`.

### Local repair and preserved failures

The repair passes the same resolved profile object to cache identity and rendering, with two corresponding storage parameter/value changes. It changes three source lines in two files, adds populated-cache regression tests, and generates the current report through the builder. The selector, renderer, accepted output oracle, original verifier/tests, original frozen subject, and selected package are preserved. Hashing the resolved selected profile covers its actual rendering fields without depending on unselected profile contents.

| Captured local evidence | Actual result |
|---|---|
| 024 unmodified copied build; 025 original verifier | `reused=true`, old key; verifier exit 1 |
| 026 added regression suite before source change | Exit 1; four failures, including legacy reuse and heading/separator transitions |
| 027 same suite after correction | Exit 0; eight methods pass, including the three original methods |
| 028 corrected actual builder; 029 unchanged verifier | `reused=false`, new key; verifier exit 0 |
| 030 unchanged second build; 031 final bytes/scope | `reused=true`, same new key; exact output and preservation confirmed |

The new tests use explicit expected strings or unchanged fixture bytes, exercise populated caches, and use a renderer-fails-if-called sentinel for unchanged reuse. I inspected the complete tests and red/green streams without rerunning them.

The corrected report is 105 bytes, SHA256 `88c2a81102e1f564bcfa7f261c10239ae270f0082865be5ac6266628d576cddc`. The new key is `dccc7dfc0bd97f08dc541c845ce06bb0cb2930747f1e9a982a578d6a717e088b`. The original 97-byte failing output and old cache remain preserved. The precise original historical write sequence remains unproven; the later unmodified local-copy build directly demonstrates the recurrence path instead.

This is a **separate local repair**, not hosted repair. `DG17_FINAL/final/STATE.md` remains BLOCKED/open, and `CLEANUP.json` says custody terminated, task removed, archive historical, audit closure false. The hosted data-only return channel records the separate decision; it does not execute its proposed repair or authorize consequences.

## Claim-level and original-requirement disposition

| Claim | Bounded disposition |
|---|---|
| C1: exact admitted source/package and frozen subject | PASS at verified archived identity scope; source a297 and review source 053 remain distinct |
| C2: prior substantive failure and nontrivial need | PASS at actual producer/admission and fresh receiving scope; no stronger fresh-actor pre-registration execution premise |
| C3: governed child return and governor rederivation | Actual chain supported; NEEDS_REVISION for complete prompt-independent qualification because of F01 |
| C4: direct entry on the same abnormality, bounded return | PASS for the observed direct use/no-authority result; F02 limits stronger return-owner discrimination |
| C5: fresh local governor decision and separate repair | PASS at the preserved local source/output/evidence scope; no hosted repair or blinded principal claim |
| C6: scope preservation and authority | PASS as a bounded receiving recommendation; all acceptance/currentness/closing decisions remain with their actual owners |

Frozen rubric receiving checks are supported as follows: R1 has the distributed ordering stated above, with the stronger same-fresh-actor timing premise unproved; R2 has archived complete-package/currentness/registration/resolver support; R3 has recorded fresh skill-specific bounded diagnosis, subject to F01 and capture limits; R4 has actual recorded returns and independently captured rederivation; R5 has actual local-copy failure/repair/output/reuse evidence, not hosted correction; R6 is preserved by retained failures, scope limits, and no wider award. Passing some of these facts does not cancel the model-facing control failure.

Recommended original-row reconciliation, for Root's separate decision:

- **P07:** replace no-execution-only characterization with the observed admitted governed-return/rederivation/local-repair facts, while retaining **NEEDS_REVISION for prompt-independent qualification**. No whole-case award.
- **H07:** retain the observed same-abnormality dual entry and bounded returns; **NEEDS_REVISION for the contaminated governed comparison**, and **NONVERDICT for a discriminating/inverted return-owner control**. No whole-case or mutation-family award.
- **T4:** preserve the previously accepted direct-return limb and add the supported actual governed/local observations. The complete clause remains unawarded; the frozen rubric itself excludes whole-T4/T13 credit. No native Stop, host-authentication, whole-DG17, or whole-programme acceptance follows.

The smallest material remaining positive predicate is an actual fresh model-facing governed/same-abnormality comparison without an instruction that supplies the tested topology answer, still using the unchanged failure, oracle, substantive diagnostic/repair obligations, source policy, and genuine authority/currentness envelope. Required skill policy and necessary metadata stay intact. A stronger inverted return-owner claim separately needs a discriminating witness; it cannot be fabricated from these positives. Preserve all prior exposure and prompted evidence. No new host investigation or product repair is justified by this review alone.

The current M4 selection is genuine packet evidence: graph digest `e222965409fc5845e16deb6ce1529498b8395b116ff4a71fe9f856c0e230b71e`, input digest `71d5f5e747ceabd31c8543ceee2dd2791b95f73f7bb9f5531562718b730fda72`, dispatch ID `e2e7439c72ceb2fe08c4365c88baee407dce55054da65af20aa5a13ae474a704`. This report is its bounded return, not evidence that QUALIFY has consumed it. Parent G000E and native selection/closure captures are supplied custody evidence, not currentness minted by this reviewer. Root's separate consumption and actual native closing recheck remain pending. `G132=UNKNOWN_NO_REPLAY`, whole JOIN blocked, and source-only/data-only controls remain at their actual scope.

No repair, target test rerun, child dispatch, remote action, parent/source/host mutation, authority grant, or lifecycle/acceptance/closure action was performed by this reviewer. Only the requested return artifacts were written.

NEEDS_REVISION
