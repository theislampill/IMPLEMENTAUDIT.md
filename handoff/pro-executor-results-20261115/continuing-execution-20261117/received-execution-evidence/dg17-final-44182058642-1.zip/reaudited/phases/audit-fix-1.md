# Exact-byte audit fix

The markers below are specification anchors, not claimed execution.
IMPLEMENTAUDIT_PHASE_START
Phase: 2 of 2 — Exact-byte audit fix
Task: Repair the actually observed missing final LF without changing either operational record.
Type: brownfield
Run root: .IMPLEMENTAUDIT/runs/greeting-update-nvUv5b
Baseline ref: 75c615e5c34a73e45f59e2020557f9f338722c14
Owner/source: subject/app.txt
Audit object: .IMPLEMENTAUDIT/runs/greeting-update-nvUv5b/ROADMAP.md
Terminal object state to prove: The complete greeting file has the exact required bytes.
Depends on phases: 1
Smoke A: /usr/bin/python3 -B subject/verify.py smoke on the exact preimage before the byte mutation
Smoke B: /usr/bin/python3 -B subject/verify.py smoke after the byte correction and 5S

## Current state excerpts

- The exact retained subject/app.txt candidate has both required records and no final LF.
- audit-after-reanchor-final.log contains the actual complete-byte predicate refusal; operational checks passed at that same candidate.

## Work

Append only the missing final LF after the actual Root final-gap decision. Preserve the original finding, phase evidence and complete final predicate.

## Implementation steps (ordered)

- Step 1: Restore the required final LF — target: subject/app.txt; change: append one missing LF without changing either record; verify: /usr/bin/python3 -B subject/verify.py final; expected: exit 0
  mutation-authority: {"operation":"replace","source":"subject/app.txt","destination":null}

## Scope boundaries

In scope: the actual missing final LF in subject/app.txt only.
Out of scope: changing either operational record, incoming/greeting.txt, subject/verify.py, package source or unrelated files.
Mutation scope: {"in":["subject/app.txt"],"out":["incoming/greeting.txt","subject/verify.py"]}

## STOP conditions (plan-specific)

- Stop if subject/app.txt differs from the exact retained final-audit preimage; a changed candidate needs re-anchoring.
- Stop if subject/verify.py final remains nonzero after the one admitted byte correction; preserve its complete new failure.

## Acceptance criteria

- [x] subject/verify.py final returns exit 0 at the exact repaired candidate.

## Mandatory commands

- /usr/bin/python3 -B subject/verify.py final > .IMPLEMENTAUDIT/runs/greeting-update-nvUv5b/evidence/phase-2-final.log 2>&1 — property: behavioral; scope: complete deliverable byte equality; coverage: full; capture: .IMPLEMENTAUDIT/runs/greeting-update-nvUv5b/evidence/phase-2-final.log; expected: exit 0

## Evidence required

- Actual Root final-gap decision and exact failed preimage.
- Complete observed-mutation result, final predicate result and status-invariant recheck.
- Markdown fallback: STATE.md and whole command captures; no sidecar is required.

## Rollback / defer path

Contain the deliverable if the bounded correction fails. Keep the original failed candidate and every result. Root must make a new actual decision before any further write; the committed mutation step is never replayed.

## Maintenance notes

- This is a bounded final-audit correction; no package or durable AGENTS change is inferred.

IMPLEMENTAUDIT_PHASE_VERIFY
Actual outcomes are recorded only after commands return.
AGENTS_UPDATE_DECISION
No durable repo-specific learning is presumed.
CONTINUITY_DECISION
Only the existing source owner issues currentness receipts.
IMPLEMENTAUDIT_PHASE_DONE
Status: done
