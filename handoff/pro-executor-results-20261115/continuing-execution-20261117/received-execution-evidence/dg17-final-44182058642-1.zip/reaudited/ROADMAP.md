# IMPLEMENTAUDIT Roadmap

## Goal

Update the greeting operational records using the current incoming/greeting.txt dependency. The complete subject/app.txt bytes must be the greeting, LF, status=ready, LF, with no additional or missing bytes.

## Audit object

The greeting owner file and its complete final-byte obligation remain open until actual verification. Completing a phase alone cannot satisfy that obligation.

## Action selection

Selected: exact currentness, current dependency evidence, passing plan authority gates, complete greeting implementation, Smoke A/B, phase acceptance, cleanliness, exact final audit and bounded repairs only after actual Root decisions.
Omitted: diagnostic children for mechanically explicit predicates, native Stop, release, protected operations, package changes, and unrelated tests.

## Baseline ref

7aaaae404ed060e0e1d8548e9da1ae2b68a00007

## Phases

| Phase | Objective | Owner/source | Depends on | Smoke A | Smoke B | Review | Status |
|---|---|---|---|---|---|---|---|
| 1 | Verify and update the current greeting | subject/app.txt | incoming/greeting.txt | status record | status and greeting records | PASS at separately retained review | done |

| 2 | Repair the actual exact-byte gap | subject/app.txt | 1 | retained exact failed final predicate | exact final and status checks | Root bounded decision received | done |

## Complete deliverable obligation

- [ ] /usr/bin/python3 -B subject/verify.py final returns exit 0 at the exact resulting owner bytes.

## Scope boundaries

Only subject/app.txt is an implementation target. Runtime records are owned by the admitted governor. Only the separately declared fixture controller may supply changed dependency or candidate inputs. Predicates and package source remain unchanged.
