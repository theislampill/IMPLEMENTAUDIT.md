# Sidecars

Graphify: not configured. ActiveGraph: not configured. Markdown fallback: STATE.md, ROADMAP.md and full command captures.
