#!/usr/bin/env bash
set -euo pipefail

# Action-selection contract test (#48, IA-ACTION-DEPTH): runs the checker on
# the live repo, then proves the checker actually fails on mutated copies
# (embedded negative controls, not whole-file grep optimism).

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_root"

fail() {
  printf 'action-selection-contract.test: %s\n' "$*" >&2
  exit 1
}

if command -v python >/dev/null 2>&1; then
  py_cmd=(python)
elif command -v python3 >/dev/null 2>&1; then
  py_cmd=(python3)
elif command -v py >/dev/null 2>&1; then
  py_cmd=(py -3)
else
  fail "python, python3, or py -3 is required"
fi

# 1. Positive: live repo passes.
bash scripts/check-action-selection-contract.sh \
  || fail "checker fails on the live repo"

# Sandbox for negative controls.
tmp_root="$(mktemp -d)"
trap 'rm -rf "$tmp_root"' EXIT

reset_sandbox() {
  rm -rf "$tmp_root"
  mkdir -p \
    "$tmp_root/skills/implementaudit/references" \
    "$tmp_root/skills/implementaudit/templates" \
    "$tmp_root/fixtures/audit-action-selection" \
    "$tmp_root/fixtures/distributed-runtime" \
    "$tmp_root/fixtures/native-integration" \
    "$tmp_root/fixtures/audit-object-routing"
  cp skills/implementaudit/SKILL.md "$tmp_root/skills/implementaudit/"
  cp skills/implementaudit/references/planning-depth.md \
    "$tmp_root/skills/implementaudit/references/"
  cp skills/implementaudit/references/audit-playbook.md \
    "$tmp_root/skills/implementaudit/references/"
  cp skills/implementaudit/references/lean-operating-discipline.md \
    "$tmp_root/skills/implementaudit/references/"
  cp skills/implementaudit/references/child-agents.md \
    "$tmp_root/skills/implementaudit/references/"
  cp skills/implementaudit/references/plan-lifecycle.md \
    "$tmp_root/skills/implementaudit/references/"
  cp skills/implementaudit/templates/THINKING.md \
    skills/implementaudit/templates/ROADMAP.md \
    "$tmp_root/skills/implementaudit/templates/"
  cp fixtures/audit-action-selection/*.md \
    "$tmp_root/fixtures/audit-action-selection/"
  cp fixtures/audit-action-selection/*.json \
    "$tmp_root/fixtures/audit-action-selection/"
  cp fixtures/distributed-runtime/r48-admission-cases.json \
    "$tmp_root/fixtures/distributed-runtime/"
  cp fixtures/native-integration/single-plan-native-route.md \
    "$tmp_root/fixtures/native-integration/"
  cp fixtures/audit-object-routing/deep-pressure-disclosure.md \
    "$tmp_root/fixtures/audit-object-routing/"
}

expect_fail() {
  local label="$1"
  if bash scripts/check-action-selection-contract.sh --repo-root "$tmp_root" \
    >/dev/null 2>&1; then
    fail "negative control not detected: $label"
  fi
}

# 2. Sanity: untouched sandbox passes.
reset_sandbox
bash scripts/check-action-selection-contract.sh --repo-root "$tmp_root" \
  >/dev/null 2>&1 || fail "checker fails on the untouched sandbox copy"

# 3. Keyword-freedom clause removed from the contract -> must fail.
reset_sandbox
grep -v "Depth never requires an activation keyword" \
  "$tmp_root/skills/implementaudit/references/planning-depth.md" \
  >"$tmp_root/planning-depth.tmp"
mv "$tmp_root/planning-depth.tmp" \
  "$tmp_root/skills/implementaudit/references/planning-depth.md"
expect_fail "planning-depth.md without the keyword-freedom clause"

# 4. Action-selection record loses its template home -> must fail.
reset_sandbox
sed 's/^## Action selection$/## Renamed section/' \
  "$tmp_root/skills/implementaudit/templates/THINKING.md" \
  >"$tmp_root/thinking.tmp"
mv "$tmp_root/thinking.tmp" \
  "$tmp_root/skills/implementaudit/templates/THINKING.md"
expect_fail "THINKING.md without the Action selection section"

# 5. A negative fixture disappears -> must fail.
reset_sandbox
rm "$tmp_root/fixtures/audit-action-selection/negative-keyword-gated-depth.md"
expect_fail "missing negative-keyword-gated-depth fixture"

# 6. Command-mode advertisement in the new surfaces -> must fail.
reset_sandbox
printf '\nAdvertised mode: /implementaudit deep\n' \
  >>"$tmp_root/fixtures/audit-action-selection/ordinary-task-deepens.md"
expect_fail "command-mode advertisement in an action-selection fixture"

# 7. The engineering-value owner clause disappears -> must fail.
reset_sandbox
sed '/^## Engineering-value admission and control lifecycle$/,/^## Unit independence and change class$/{
  /^## Unit independence and change class$/!d
}' "$tmp_root/skills/implementaudit/references/planning-depth.md" \
  >"$tmp_root/planning-depth.tmp"
mv "$tmp_root/planning-depth.tmp" \
  "$tmp_root/skills/implementaudit/references/planning-depth.md"
expect_fail "missing engineering-value admission owner"

# 8. A changed expected answer cannot make an invalid control green.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
payload["cases"][0]["expected"] = "ADMIT"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "changed expected answer for the tiny cheap path"

# 9. Truthy strings cannot impersonate observed boolean state.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
payload["cases"][1]["observations"]["activation"] = "yes"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "truthy string substituted for an observed boolean"

# 10. Process-heavy evidence derives activation even when the caller's flag is false.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C01-tiny-cheap-path")
case["observations"]["process_heavy_or_disputed"] = True
case["expected"] = "DEEP_RETROSPECTIVE"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
bash scripts/check-action-selection-contract.sh --repo-root "$tmp_root" \
  >/dev/null 2>&1 || fail "held-out process-heavy activation derivation failed"

# 11. Closed disjoint cells still need an explicit reconciliation point.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C45-disjoint-cells-no-shared-cell")
case["observations"]["disjoint_cells"] = 1
case["observations"]["reconciliation_point"] = False
case["expected"] = "SERIALISE_SHARED"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
bash scripts/check-action-selection-contract.sh --repo-root "$tmp_root" \
  >/dev/null 2>&1 || fail "held-out missing reconciliation point was called parallel-safe"

# 12. A protective buffer is not waste merely because it consumes capacity.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C73-protective-buffer")
case["expected"] = "REJECT"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "protective buffer misclassified as waste"

# 13. Feedback frequency without actionable information is not value evidence.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C75-actionable-feedback")
case["observations"]["actionable_information"] = False
case["expected"] = "SELECT_PROPORTIONATE_CONTROL"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "non-actionable feedback retained as proportionate"

# 14. Temporary option value ends when carrying cost dominates.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C79-bounded-option-value")
case["observations"]["benefit_exceeds_carrying_cost"] = False
case["expected"] = "RETIRE"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
bash scripts/check-action-selection-contract.sh --repo-root "$tmp_root" \
  >/dev/null 2>&1 || fail "held-out option retirement was not derived from carrying cost"

# 15. Universal utilisation/WIP/cadence rules cannot self-authorise.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C77-sustainable-recovery-capacity")
case["observations"]["universal_rule"] = True
case["expected"] = "SELECT_PROPORTIONATE_CONTROL"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "universal maximum-utilisation rule accepted"

# 16. The native rule must stay ceremony-free.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C75-actionable-feedback")
case["observations"]["methodology_ceremony"] = True
case["expected"] = "SELECT_PROPORTIONATE_CONTROL"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "methodology ceremony accepted as a native control"

# 17. The executable population remains bound to its native owner prose.
reset_sandbox
grep -v "Feedback value depends on actionable" \
  "$tmp_root/skills/implementaudit/references/planning-depth.md" \
  >"$tmp_root/planning-depth.tmp"
mv "$tmp_root/planning-depth.tmp" \
  "$tmp_root/skills/implementaudit/references/planning-depth.md"
expect_fail "actionability rule removed from native owner prose"

# 18. A completed cell recomputes the frontier and activates newly ready work.
# This catches a scheduler that records static parallel safety but never uses
# freed capacity after a dependency transition.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C01-tiny-cheap-path")
case["kind"] = "scheduling"
case["observations"] = {
    "event": "cell_complete",
    "work_units": 4,
    "host_capacity": 2,
    "operator_ceiling": -1,
    "active_cells": 1,
    "ready_cells": 1,
    "parallelism_allowed": True,
    "cell_independence_known": True,
    "closed_write_boundaries": True,
    "closed_acceptance_boundaries": True,
    "closed_resource_boundaries": True,
    "closed_authority_boundaries": True,
    "authority_boundary_open": False,
    "irreversible_external": False,
    "authorization_current": True,
}
case["expected"] = "RECOMPUTE_AND_ACTIVATE"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
bash scripts/check-action-selection-contract.sh --repo-root "$tmp_root" \
  >/dev/null 2>&1 || fail "completed cell did not activate newly ready independent work"

# 19. A shared resource claim cannot be relabelled as work-conserving activation.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C95-resource-claim-conflict-serialises")
case["expected"] = "ACTIVATE_READY_CELLS"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "resource conflict relabelled as parallel activation"

# 20. Unknown independence cannot be treated as an activatable ready cell.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C92-unknown-independence-defers")
case["expected"] = "ACTIVATE_READY_CELLS"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "unknown independence relabelled as parallel activation"

# 21. Host capacity one retains the ordinary cheap serial path.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C97-host-capacity-one-cheap-serial")
case["expected"] = "ACTIVATE_READY_CELLS"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "host-capacity-one cheap path relabelled as parallel activation"

# 22. An unchanged reminder is not a frontier event or redispatch warrant.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C99-reminder-does-not-redispatch")
case["expected"] = "RECOMPUTE_AND_ACTIVATE"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "unchanged reminder relabelled as a frontier event"

# 23. The executable scheduling population must remain bound to its native
# ready-frontier execution owner, not merely to fixture verdicts.
reset_sandbox
grep -v "Maintain a ready-cell frontier" \
  "$tmp_root/skills/implementaudit/references/child-agents.md" \
  >"$tmp_root/child-agents.tmp"
mv "$tmp_root/child-agents.tmp" \
  "$tmp_root/skills/implementaudit/references/child-agents.md"
expect_fail "ready-frontier execution owner removed"

# 24. The always-loaded runtime loop must progressively activate closed
# frontier accounting rather than merely permit it in a deep reference.
reset_sandbox
grep -v "reacquire a closed DONE/ACTIVE/READY/BLOCKED census" \
  "$tmp_root/skills/implementaudit/SKILL.md" \
  >"$tmp_root/SKILL.tmp"
mv "$tmp_root/SKILL.tmp" "$tmp_root/skills/implementaudit/SKILL.md"
expect_fail "closed frontier census runtime route removed"

# 25. Two currently authorised cells that overlap an authority boundary still
# serialize; current authorization is not proof of independent authority.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C102-authority-boundary-conflict-serialises")
case["expected"] = "ACTIVATE_READY_CELLS"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "authority conflict relabelled as parallel activation"

# 26. The authority observation, not the fixture label, drives the conflict.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C102-authority-boundary-conflict-serialises")
case["observations"]["closed_authority_boundaries"] = True
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "authority-conflict observation did not change the derived verdict"

# 27. The serial cheap path must not grow a mandatory scheduler dashboard.
reset_sandbox
sed 's/, dashboard//' \
  "$tmp_root/skills/implementaudit/references/child-agents.md" \
  >"$tmp_root/child-agents.tmp"
mv "$tmp_root/child-agents.tmp" \
  "$tmp_root/skills/implementaudit/references/child-agents.md"
expect_fail "dashboard prohibition removed from cheap-path owner"

# 28. Completion must recompute and activate a newly ready cell.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C104-completion-recomputes-frontier")
case["expected"] = "HOLD_FRONTIER"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "completion bypassed ready-frontier recomputation"

# 29. An operator ceiling must remain an upper bound, not disappear into host capacity.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C109-operator-ceiling-bounds-frontier")
case["observations"]["operator_ceiling"] = -1
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "operator ceiling ignored"

# 30. A live self-confirmation trigger cannot fall back to same-root execution.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C115-triggered-planner-executor-separation")
case["expected"] = "SAME_ROOT"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "self-confirmation trigger collapsed to same-root execution"

# 31. Cost cannot select a route whose capability is insufficient.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C120-cheaper-incapable-route-rejected")
case["expected"] = "DELEGATE_LEAST_COST_SUFFICIENT"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "incapable lower-cost route selected"

# 32. The cross-boundary context/revalidation owner clause is mandatory.
reset_sandbox
sed '/This prompt is an explicit context capsule/,/issuing any disposition\./d' \
  "$tmp_root/skills/implementaudit/references/plan-lifecycle.md" \
  >"$tmp_root/plan-lifecycle.tmp"
mv "$tmp_root/plan-lifecycle.tmp" \
  "$tmp_root/skills/implementaudit/references/plan-lifecycle.md"
expect_fail "missing context capsule and fresh-source revalidation"

# 33. Cross-repo behavior cannot be credited from a success-shaped receipt
# that hides activation-keyword leakage.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/dominance-dogfood-receipt.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
payload["activation_prompt_leakage"] = True
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "dogfood receipt with activation-keyword leakage"

# 34. The timed-out combined cell must remain rejected non-evidence.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/dominance-dogfood-receipt.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
payload["cells"][-1]["disposition"] = "PASS"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "timed-out dogfood cell promoted to PASS"

# 35. Current authorization cannot impersonate an unresolved authority boundary.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C126-open-authority-boundary-defers")
case["expected"] = "ACTIVATE_READY_CELLS"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "open authority boundary activated"

# 36. Drift is a reconciliation event even on the serial cheap path.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C127-small-drift-still-reconciles")
case["expected"] = "SERIAL_CHEAP_PATH"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "serial cheap path hid drift reconciliation"

# 37. Recomputing under a zero ceiling cannot activate a ready cell.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C130-zero-ceiling-completion-recomputes-without-activation")
case["expected"] = "RECOMPUTE_AND_ACTIVATE"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "zero-ceiling recomputation activated a ready cell"

# 38. A completion frees only the bounded slot left after the closed frontier
# census; it does not reset active work to zero or spend the whole ceiling.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C131-completion-frees-one-bounded-slot")
case["observations"]["done_cells"] = 2
case["observations"]["active_cells"] = 0
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "completed cell reset the active census and overspent the ceiling"

# 39. The executable discriminator remains bound to the native runtime owner.
reset_sandbox
grep -v "state prevents dispatch" \
  "$tmp_root/skills/implementaudit/references/child-agents.md" \
  >"$tmp_root/child-agents.tmp"
mv "$tmp_root/child-agents.tmp" \
  "$tmp_root/skills/implementaudit/references/child-agents.md"
expect_fail "closed frontier census runtime owner removed"

# 40. A larger population derives three free slots from current occupancy;
# changing DONE/ACTIVE labels without changing the total must change dispatch.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C132-closed-population-bounds-three-slots")
case["observations"]["done_cells"] = 4
case["observations"]["active_cells"] = 1
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "larger closed population ignored active occupancy"

# 41. READY cardinality, not spare ceiling alone, bounds dispatch.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C133-ready-population-bounds-one-dispatch")
case["expected"] = "DISPATCH_5_READY_CELLS"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "spare ceiling overrode ready cardinality"

# 42. An unknown cell cannot be relabelled BLOCKED to manufacture free capacity.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C134-unknown-population-refuses-capacity-assumption")
case["observations"]["unknown_cells"] = 0
case["observations"]["blocked_cells"] = 1
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "unknown cell was laundered into free capacity"

# 43. A complete-looking but stale state partition is not dispatch authority.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R34-C135-stale-population-refuses-dispatch")
case["observations"]["state_evidence_current"] = True
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "stale frontier state was treated as current dispatch authority"

# 44. An executor-ready handoff cannot claim READY before live source grounds
# its exact state, scope, edits, and verification route.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R31-C137-uninspected-plan-held")
case["expected"] = "EXECUTOR_PLAN_READY"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "uninspected speculative executor plan claimed READY"

# 45. The READY positive requires every reconstructibility field; schema shape
# plus generic STOP/rollback prose cannot replace exact current-state evidence.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R31-C136-grounded-executor-plan-ready")
case["observations"]["current_state_exact"] = False
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "generic plan shape replaced exact current state"

# 46. The executable discriminator remains bound to the R001F lifecycle owner.
reset_sandbox
grep -v "cannot claim READY" \
  "$tmp_root/skills/implementaudit/references/plan-lifecycle.md" \
  >"$tmp_root/plan-lifecycle.tmp"
mv "$tmp_root/plan-lifecycle.tmp" \
  "$tmp_root/skills/implementaudit/references/plan-lifecycle.md"
expect_fail "executor-plan source-grounding owner removed"

# 47. Live grounding does not authorize optional ancillary tidy-up files.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(item for item in payload["cases"] if item["id"] == "R31-C136-grounded-executor-plan-ready")
case["observations"]["scope_exact"] = False
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "optional ancillary file expanded executor authority"

# 48. Remove the closed-scope owner phrase while leaving source grounding.
reset_sandbox
grep -v "Optional ancillary files remain out of scope" \
  "$tmp_root/skills/implementaudit/references/plan-lifecycle.md" \
  >"$tmp_root/plan-lifecycle.tmp"
mv "$tmp_root/plan-lifecycle.tmp" \
  "$tmp_root/skills/implementaudit/references/plan-lifecycle.md"
expect_fail "closed executor mutation scope owner removed"

# 49. The catalogue trigger must route scheduling decisions to the executable
# owner instead of allowing a description-only claim of skill use.
reset_sandbox
grep -v "For scheduling/dispatch/resource ceilings, read" \
  "$tmp_root/skills/implementaudit/SKILL.md" \
  >"$tmp_root/SKILL.tmp"
mv "$tmp_root/SKILL.tmp" \
  "$tmp_root/skills/implementaudit/SKILL.md"
expect_fail "scheduling catalogue route removed"

# 50. Reconciliation must expose population conservation and occupied-capacity
# arithmetic before dispatch; merely asserting that reconciliation occurred is
# not an observable scheduling discriminator.
reset_sandbox
grep -v "Before dispatch, expose:" \
  "$tmp_root/skills/implementaudit/references/child-agents.md" \
  >"$tmp_root/child-agents.tmp"
mv "$tmp_root/child-agents.tmp" \
  "$tmp_root/skills/implementaudit/references/child-agents.md"
expect_fail "frontier conservation proof owner removed"

# 51. Occupancy arithmetic is deterministic plumbing. Removing its tool-use
# boundary must fail even when the equations remain as plausible prose.
reset_sandbox
grep -v "Use deterministic tooling, not model estimates" \
  "$tmp_root/skills/implementaudit/references/child-agents.md" \
  >"$tmp_root/child-agents.tmp"
mv "$tmp_root/child-agents.tmp" \
  "$tmp_root/skills/implementaudit/references/child-agents.md"
expect_fail "deterministic frontier arithmetic boundary removed"

# 52. A zero operator ceiling is an explicit no-dispatch bound, not an absent
# ceiling that silently falls back to host capacity.
reset_sandbox
grep -v "capacity = 0 at ceiling 0" \
  "$tmp_root/skills/implementaudit/references/child-agents.md" \
  >"$tmp_root/child-agents.tmp"
mv "$tmp_root/child-agents.tmp" \
  "$tmp_root/skills/implementaudit/references/child-agents.md"
expect_fail "zero-ceiling capacity branch removed"

# 53. Completion may leave ACTIVE at zero, but it cannot infer that other
# governed activity vanished merely because one cell completed.
reset_sandbox
grep -v "never infer other ACTIVE=0" \
  "$tmp_root/skills/implementaudit/references/child-agents.md" \
  >"$tmp_root/child-agents.tmp"
mv "$tmp_root/child-agents.tmp" \
  "$tmp_root/skills/implementaudit/references/child-agents.md"
expect_fail "completion inferred other active cells were zero"

# 54. A high-consequence control cannot pass without the complete target,
# feedback, containment, and recovery envelope.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == "R44-C142-high-consequence-control-trigger")
case["observations"]["containment"] = False
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "high-consequence control accepted without containment"

# R002C-1. Hazardous stopping selects the existing containment/recovery envelope
# even when a reversible action is not labelled high-consequence. Incomplete
# envelopes defer; a complete bounded degraded route remains available.
while IFS='|' read -r label observation_delta expected_outcome; do
  reset_sandbox
  "${py_cmd[@]}" - \
    "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" \
    "$observation_delta" "$expected_outcome" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == "R44-C143-low-consequence-cheap-path")
case["observations"].update(json.loads(sys.argv[2]))
case["expected"] = sys.argv[3]
path.write_text(json.dumps(payload), encoding="utf-8")
PY
  bash scripts/check-action-selection-contract.sh --repo-root "$tmp_root" \
    >/dev/null 2>&1 || fail "hazardous stopping control failed: $label"
done <<'EOF'
hazard-only|{"stopping_hazardous":true}|DEFER
hazard-live|{"stopping_hazardous":true,"live_pressure":true}|DEFER
complete-unbounded|{"stopping_hazardous":true,"containment":true}|DEFER
bounded-missing-containment|{"stopping_hazardous":true,"bounded_degraded_operation":true}|DEFER
complete-bounded|{"stopping_hazardous":true,"bounded_degraded_operation":true,"containment":true}|BOUNDED_DEGRADED_OPERATION
bounded-missing-target|{"stopping_hazardous":true,"bounded_degraded_operation":true,"containment":true,"target_state":false}|DEFER
bounded-missing-feedback|{"stopping_hazardous":true,"bounded_degraded_operation":true,"containment":true,"feedback":false}|DEFER
bounded-missing-recovery|{"stopping_hazardous":true,"bounded_degraded_operation":true,"containment":true,"recovery":false}|DEFER
EOF

# 55. Method labels never replace the consequence-control discriminator.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == "R44-C145-risk-matrix-insufficient")
case["expected"] = "SELECT_CONSEQUENCE_CONTROL"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "risk-matrix label accepted as sufficient control evidence"

# 56. A bounded control with an established safe stop and no material trigger
# is the cheap path; it must not inherit BLOCK from the rejected material case.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == "R34-C146-safe-stop-control-cheap-path")
case["expected"] = "BLOCK"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "safe-stop control inherited material BLOCK"

# 57. A nominal override remains insufficient even when every other field
# resembles the safe-stop control cheap path.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == "R34-C146-safe-stop-control-cheap-path")
case["observations"]["nominal_override_only"] = True
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "nominal override accepted as safe-stop cheap path"

# 58. An omitted semantic owner cannot be relabelled as a serial cheap plan.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/verifier-plan-cases.json" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == "R0022-V01-owner-omitted-under-scoped")
case["expected"] = "SERIAL_CHEAP_PATH"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "under-scoped verifier plan accepted with omitted semantic owner"

# 59. Consumer and effect omissions are equally unable to retain a cheap plan.
for case_id in R0022-V02-consumer-omitted-under-scoped R0022-V03-effect-omitted-under-scoped; do
  reset_sandbox
  "${py_cmd[@]}" - \
    "$tmp_root/fixtures/audit-action-selection/verifier-plan-cases.json" \
    "$case_id" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
case_id = sys.argv[2]
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == case_id)
case["expected"] = "SERIAL_CHEAP_PATH"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
  expect_fail "under-scoped verifier plan accepted for $case_id"
done

# 60. Wider transitive, package, public, and external impacts have their own
# affected verifier and cannot collapse to the cheap local path.
for case_id in R0022-V07-transitive-consumer-verifier-plan R0022-V08-package-consumer-verifier-plan R0022-V09-public-consumer-verifier-plan R0022-V10-external-consumer-verifier-plan; do
  reset_sandbox
  "${py_cmd[@]}" - \
    "$tmp_root/fixtures/audit-action-selection/verifier-plan-cases.json" \
    "$case_id" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
case_id = sys.argv[2]
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == case_id)
case["expected"] = "SERIAL_CHEAP_PATH"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
  expect_fail "under-scoped verifier plan accepted for $case_id"
done

# 61. Relation, registry, ambiguity, and projection uncertainty each has one
# live predicate; no second true predicate may mask its omission.
for case_id in R0022-V11-unknown-relation-only-escalates R0022-V12-registry-change-only-escalates R0022-V13-package-or-release-ambiguity-only-escalates R0022-V14-stale-projection-only-escalates; do
  reset_sandbox
  "${py_cmd[@]}" - \
    "$tmp_root/fixtures/audit-action-selection/verifier-plan-cases.json" \
    "$case_id" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
case_id = sys.argv[2]
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == case_id)
case["expected"] = "SERIAL_CHEAP_PATH"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
  expect_fail "conservative verifier plan relabelled as cheap for $case_id"
done

# 62. Multiple independent affected consumers retain the composed outcome.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/verifier-plan-cases.json" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == "R0022-V15-generated-package-composed-verifier-plan")
case["expected"] = "VERIFY_PACKAGE_CONSUMER"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "multi-impact verifier plan lost composed outcome"

# 63. The reviewed 31/18/4/6/1 proof-layer partition is exact and retains the
# external/domain rows as unverified rather than silently closing them.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/security-profile-cases.json" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
payload["proof_layer_partition"]["external_domain_unverified"] = 5
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "security profile accepted a changed proof-layer partition"

# 64. Each bounded security-profile control has a distinct observable outcome;
# relabelling one as its distractor must fail against the real checker.
while IFS='|' read -r case_id wrong_expected; do
  reset_sandbox
  "${py_cmd[@]}" - \
    "$tmp_root/fixtures/audit-action-selection/security-profile-cases.json" \
    "$case_id" "$wrong_expected" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
case_id, wrong_expected = sys.argv[2:]
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == case_id)
case["expected"] = wrong_expected
path.write_text(json.dumps(payload), encoding="utf-8")
PY
  expect_fail "security-profile control relabelled for $case_id"
done <<'EOF'
R002E-S01-material-profile-selected|NO_SECURITY_PROFILE
R002E-S02-low-exposure-cheap-path|SELECT_NATIVE_SECURITY_PROFILE
R002E-S03-stale-provenance-blocked|SELECT_NATIVE_SECURITY_PROFILE
R002E-S04-authentication-is-not-authorization|SELECT_NATIVE_SECURITY_PROFILE
R002E-S05-availability-is-not-trust-restoration|SELECT_NATIVE_SECURITY_PROFILE
R002E-S06-label-only-proof-rejected|SELECT_NATIVE_SECURITY_PROFILE
R002E-S07-no-trigger-no-profile|SELECT_NATIVE_SECURITY_PROFILE
R002E-S08-unbounded-adversary-held|SELECT_NATIVE_SECURITY_PROFILE
R002E-S09-missing-assurance-evidence-held|SELECT_NATIVE_SECURITY_PROFILE
EOF

# 65. Assurance evidence and the limits of that evidence are independent
# completeness dimensions; the fixture must hold when evidence itself is absent.
"${py_cmd[@]}" - \
  fixtures/audit-action-selection/security-profile-cases.json <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
cases = payload["cases"]
missing = [case["id"] for case in cases
           if "assurance_evidence" not in case["observations"]]
if missing:
    raise SystemExit("security-profile cases missing assurance_evidence: " + ", ".join(missing))
case = next((item for item in cases
             if item["id"] == "R002E-S09-missing-assurance-evidence-held"), None)
if case is None:
    raise SystemExit("missing assurance-evidence negative control")
if case["observations"]["assurance_evidence"] is not False:
    raise SystemExit("missing assurance-evidence control is not false")
if case["observations"]["assurance_limits"] is not True:
    raise SystemExit("missing assurance-evidence control also removed assurance limits")
if case["expected"] != "HOLD_INCOMPLETE_PROFILE":
    raise SystemExit("missing assurance-evidence control has wrong outcome")
PY

# 66. Every accepted trigger-family clause is independently pinned. Removing
# any one from the sandbox owner must make the static checker fail.
while IFS= read -r trigger_clause; do
  reset_sandbox
  "${py_cmd[@]}" - \
    "$tmp_root/skills/implementaudit/references/planning-depth.md" \
    "$trigger_clause" <<'PY'
import pathlib, sys
path = pathlib.Path(sys.argv[1])
clause = sys.argv[2]
text = path.read_text(encoding="utf-8")
if text.count(clause) != 1:
    raise SystemExit(f"trigger clause occurrence mismatch for {clause!r}")
path.write_text(text.replace(clause, "[deleted trigger clause]"), encoding="utf-8")
PY
  expect_fail "security-profile trigger clause removed: $trigger_clause"
done <<'EOF'
material protected consequence
or untrusted capability
changed trust, privilege, or delegation boundary
consequential security authority
provenance-dependent claim
adaptive-adversary or common-mode risk
weak detection or recovery
consequential security, privacy, safety, availability, or usability decision
EOF

# 67. Each named non-proof proxy is independently pinned in the accepted prose.
# A generic whole-system sentence cannot mask deletion of a concrete proxy.
while IFS= read -r proxy_token; do
  reset_sandbox
  "${py_cmd[@]}" - \
    "$tmp_root/skills/implementaudit/references/audit-playbook.md" \
    "$proxy_token" <<'PY'
import pathlib, sys
path = pathlib.Path(sys.argv[1])
token = sys.argv[2]
text = path.read_text(encoding="utf-8")
if text.count(token) != 1:
    raise SystemExit(f"proxy token occurrence mismatch for {token!r}")
path.write_text(text.replace(token, "[deleted proxy token]"), encoding="utf-8")
PY
  expect_fail "security-profile non-proof proxy removed: $proxy_token"
done <<'EOF'
scanner
penetration-test result
SBOM
signature
CVSS score
certificate
encryption label
zero-trust slogan
EOF

# 68. Each trigger family is causally sufficient by itself: with every trigger
# false the complete control observes NO_SECURITY_PROFILE, then toggling only
# the named trigger selects the native profile.
while IFS= read -r trigger_field; do
  reset_sandbox
  "${py_cmd[@]}" - \
    "$tmp_root/fixtures/audit-action-selection/security-profile-cases.json" \
    "$trigger_field" false <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
trigger_field, enabled = sys.argv[2], sys.argv[3] == "true"
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == "R002E-S01-material-profile-selected")
trigger_fields = (
    "material_protected_consequence", "exposed_or_untrusted_capability",
    "trust_or_privilege_boundary_change", "consequential_security_authority",
    "provenance_dependent_claim", "adaptive_or_common_mode_risk",
    "weak_detection_or_recovery",
    "consequential_security_privacy_safety_availability_usability_decision",
)
for field in trigger_fields:
    case["observations"][field] = False
case["observations"][trigger_field] = enabled
case["expected"] = "SELECT_NATIVE_SECURITY_PROFILE" if enabled else "NO_SECURITY_PROFILE"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
  bash scripts/check-action-selection-contract.sh --repo-root "$tmp_root" \
    >/dev/null 2>&1 || fail "all-false trigger counterfactual failed for $trigger_field"
  "${py_cmd[@]}" - \
    "$tmp_root/fixtures/audit-action-selection/security-profile-cases.json" \
    "$trigger_field" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
trigger_field = sys.argv[2]
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == "R002E-S01-material-profile-selected")
case["observations"][trigger_field] = True
case["expected"] = "SELECT_NATIVE_SECURITY_PROFILE"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
  bash scripts/check-action-selection-contract.sh --repo-root "$tmp_root" \
    >/dev/null 2>&1 || fail "sole-trigger counterfactual failed for $trigger_field"
done <<'EOF'
material_protected_consequence
exposed_or_untrusted_capability
trust_or_privilege_boundary_change
consequential_security_authority
provenance_dependent_claim
adaptive_or_common_mode_risk
weak_detection_or_recovery
consequential_security_privacy_safety_availability_usability_decision
EOF

# 69. Authentication, restored availability, and a named label/instrument are
# causal non-proof proxies even when the full profile is otherwise complete.
while IFS='|' read -r proxy_field rejected_outcome; do
  reset_sandbox
  "${py_cmd[@]}" - \
    "$tmp_root/fixtures/audit-action-selection/security-profile-cases.json" \
    "$proxy_field" false "SELECT_NATIVE_SECURITY_PROFILE" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
proxy_field, enabled, expected = sys.argv[2], sys.argv[3] == "true", sys.argv[4]
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == "R002E-S01-material-profile-selected")
case["observations"][proxy_field] = enabled
case["expected"] = expected
path.write_text(json.dumps(payload), encoding="utf-8")
PY
  bash scripts/check-action-selection-contract.sh --repo-root "$tmp_root" \
    >/dev/null 2>&1 || fail "false proxy counterfactual failed for $proxy_field"
  "${py_cmd[@]}" - \
    "$tmp_root/fixtures/audit-action-selection/security-profile-cases.json" \
    "$proxy_field" true "$rejected_outcome" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
proxy_field, enabled, expected = sys.argv[2], sys.argv[3] == "true", sys.argv[4]
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == "R002E-S01-material-profile-selected")
case["observations"][proxy_field] = enabled
case["expected"] = expected
path.write_text(json.dumps(payload), encoding="utf-8")
PY
  bash scripts/check-action-selection-contract.sh --repo-root "$tmp_root" \
    >/dev/null 2>&1 || fail "true proxy counterfactual failed for $proxy_field"
done <<'EOF'
authentication_as_authorization|REJECT_AUTHENTICATION_PROXY
availability_as_trust|REJECT_AVAILABILITY_PROXY
label_or_instrument_as_whole_system_proof|REJECT_WHOLE_SYSTEM_PROXY
EOF

# R002E-1. The cheap route still requires current provenance and rejects
# authentication, availability, or an instrument used as the protected proof.
while IFS='|' read -r observation_delta expected_outcome; do
  reset_sandbox
  "${py_cmd[@]}" - \
    "$tmp_root/fixtures/audit-action-selection/security-profile-cases.json" \
    "$observation_delta" "$expected_outcome" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == "R002E-S02-low-exposure-cheap-path")
case["observations"].update(json.loads(sys.argv[2]))
case["expected"] = sys.argv[3]
path.write_text(json.dumps(payload), encoding="utf-8")
PY
  bash scripts/check-action-selection-contract.sh --repo-root "$tmp_root" \
    >/dev/null 2>&1 || fail "security cheap-path contradiction accepted: $observation_delta"
done <<'EOF'
{"provenance_current":false}|BLOCK_STALE_PROVENANCE
{"authentication_as_authorization":true}|REJECT_AUTHENTICATION_PROXY
{"availability_as_trust":true}|REJECT_AVAILABILITY_PROXY
{"label_or_instrument_as_whole_system_proof":true}|REJECT_WHOLE_SYSTEM_PROXY
EOF

# R002E-2. No trigger and no claimed cheap envelope creates no profile merely
# because provenance is unavailable; the ordinary no-claim route stays direct.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/security-profile-cases.json" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == "R002E-S07-no-trigger-no-profile")
case["observations"]["provenance_current"] = False
path.write_text(json.dumps(payload), encoding="utf-8")
PY
bash scripts/check-action-selection-contract.sh --repo-root "$tmp_root" \
  >/dev/null 2>&1 || fail "unclaimed provenance created a security profile"

# P34-1. Executor capacity is not downstream or recovery capacity and cannot
# authorize a material retry by itself.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == "R48-C147-host-slots-not-downstream-capacity")
case["expected"] = "ADMIT"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "host slots alone authorized retry"

# P34-2. A short queue is an observation, not semantic retry authority or
# downstream/recovery headroom.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == "R48-C148-queue-depth-not-retry-authority")
case["expected"] = "ADMIT"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "queue depth alone authorized retry"

# P34-3. Definitive, untriggered local work remains on the serial cheap path and
# never gains retry admission merely because executor capacity is free.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == "R48-C149-local-retry-cheap-path-stays-serial")
case["expected"] = "ADMIT"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "local cheap path gained a retry queue"

# P34-4. Planning depth owns the conjunctive admission rule.
reset_sandbox
grep -v "Material retry, recovery, or redispatch admission is conjunctive" \
  "$tmp_root/skills/implementaudit/references/planning-depth.md" \
  >"$tmp_root/planning-depth.tmp"
mv "$tmp_root/planning-depth.tmp" \
  "$tmp_root/skills/implementaudit/references/planning-depth.md"
expect_fail "planning-depth retry admission owner removed"

# P34-5. Lean discipline owns the same admission factors through the control
# lifecycle rather than allowing capacity proxies to self-authorise.
reset_sandbox
grep -v "For retry, recovery, or redispatch, admit only when semantic eligibility" \
  "$tmp_root/skills/implementaudit/references/lean-operating-discipline.md" \
  >"$tmp_root/lean.tmp"
mv "$tmp_root/lean.tmp" \
  "$tmp_root/skills/implementaudit/references/lean-operating-discipline.md"
expect_fail "lean retry admission owner removed"

# P34-6. Child-agent scheduling must not reinterpret free executor capacity as
# retry authority.
reset_sandbox
grep -v "establish semantic retry eligibility" \
  "$tmp_root/skills/implementaudit/references/child-agents.md" \
  >"$tmp_root/child-agents.tmp"
mv "$tmp_root/child-agents.tmp" \
  "$tmp_root/skills/implementaudit/references/child-agents.md"
expect_fail "child-agent retry admission boundary removed"

# P34-7. A contradictory record cannot bypass retry/effect predicates merely by
# selecting the cheap-local flags.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == "R48-C150-contradictory-cheap-retry-refused")
case["expected"] = "CHEAP_PATH"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "contradictory retry record bypassed through cheap-local flags"

# P34-8. Effect-state vocabulary is validated before any disposition; the former
# noncanonical token cannot enter the cheap path.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/audit-action-selection/engineering-value-cases.json" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == "R48-C149-local-retry-cheap-path-stays-serial")
case["observations"]["effect_state"] = "NOT_ATTEMPTED"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
expect_fail "noncanonical effect state entered cheap path"

# P34-9. The planning owner must retain the exact coherent cheap-path predicates.
reset_sandbox
grep -v 'CHEAP_PATH.*requires canonical.*NOT_STARTED' \
  "$tmp_root/skills/implementaudit/references/planning-depth.md" \
  >"$tmp_root/planning-depth.tmp"
mv "$tmp_root/planning-depth.tmp" \
  "$tmp_root/skills/implementaudit/references/planning-depth.md"
expect_fail "planning cheap-path coherence predicates removed"

# P34-10. Reproduce the independent held-out H13 shape against the fixture-aware
# checker while retaining the coherent local positive in the same six-case set.
reset_sandbox
"${py_cmd[@]}" - \
  "$tmp_root/fixtures/distributed-runtime/r48-admission-cases.json" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = payload["cases"][1]
case["id"] = "H13-contradictory-cheap-with-retry-state"
case["observations"] = {
    "distributed_trigger": False,
    "cheap_local_operation": True,
    "semantic_retry_eligible": True,
    "effect_state": "FAILED_NO_EFFECT",
    "deadline_remaining_ms": 0,
    "queue_age_ms": 0,
    "max_queue_age_ms": 0,
    "requested_units": 1,
    "downstream_available_units": 0,
    "recovery_available_units": 0,
}
case["expected"] = "REFUSE"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
bash scripts/check-action-selection-contract.sh \
  --repo-root "$tmp_root" \
  --distributed-runtime-fixture \
  "$tmp_root/fixtures/distributed-runtime/r48-admission-cases.json" \
  >/dev/null 2>&1 || fail "held-out contradictory cheap-local record was not refused"

"${py_cmd[@]}" - \
  "$tmp_root/fixtures/distributed-runtime/r48-admission-cases.json" <<'PY'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
case = next(x for x in payload["cases"] if x["id"] == "H13-contradictory-cheap-with-retry-state")
case["expected"] = "CHEAP_PATH"
path.write_text(json.dumps(payload), encoding="utf-8")
PY
if bash scripts/check-action-selection-contract.sh \
  --repo-root "$tmp_root" \
  --distributed-runtime-fixture \
  "$tmp_root/fixtures/distributed-runtime/r48-admission-cases.json" \
  >/dev/null 2>&1; then
  fail "held-out contradictory cheap-local false green was not detected"
fi

# P34-11. Exercise typed inputs and each admission predicate through the actual
# fixture-aware checker. Removing any predicate must admit a named bad record;
# changing a strict numeric type check must accept a named malformed record.
reset_sandbox
"${py_cmd[@]}" - \
  "$repo_root/scripts/check-action-selection-contract.sh" \
  "$tmp_root" <<'PY'
import copy
import json
from pathlib import Path
import subprocess
import sys

owner = Path(sys.argv[1])
sandbox = Path(sys.argv[2])
fixture_path = sandbox / "fixtures/distributed-runtime/r48-admission-cases.json"
baseline = json.loads(fixture_path.read_text(encoding="utf-8"))
checked = 0

def check(label, payload, valid):
    global checked
    fixture_path.write_text(json.dumps(payload), encoding="utf-8")
    result = subprocess.run(
        ["bash", str(owner), "--repo-root", str(sandbox),
         "--distributed-runtime-fixture", str(fixture_path)],
        capture_output=True, text=True, check=False,
    )
    output = result.stdout + result.stderr
    if valid:
        if result.returncode != 0 or "D48-C04=PASS cases=6/6" not in output:
            raise SystemExit(f"distributed retry {label}: valid case refused: {output}")
    elif result.returncode == 0:
        raise SystemExit(f"distributed retry {label}: malformed case accepted")
    elif "fixture" not in output or "Traceback" in output:
        raise SystemExit(f"distributed retry {label}: no attributable fixture refusal: {output}")
    checked += 1

def observation(label, changes, expected, case_index=0):
    payload = copy.deepcopy(baseline)
    payload["cases"][case_index]["observations"].update(changes)
    payload["cases"][case_index]["expected"] = expected
    check(label, payload, True)

check("positive", baseline, True)
for field in ("deadline_remaining_ms", "queue_age_ms", "max_queue_age_ms",
              "requested_units", "downstream_available_units", "recovery_available_units",
              "host_free_slots", "queue_depth"):
    for value in (True, -1):
        payload = copy.deepcopy(baseline)
        payload["cases"][0]["observations"][field] = value
        check(f"typed-{field}-{value}", payload, False)
for field, value in (("requested_units", 1.0), ("downstream_available_units", "1"),
                     ("distributed_trigger", 1), ("cheap_local_operation", 0),
                     ("semantic_retry_eligible", "true"), ("effect_state", [])):
    payload = copy.deepcopy(baseline)
    payload["cases"][0]["observations"][field] = value
    check(f"typed-{field}", payload, False)
for field in baseline["cases"][0]["observations"]:
    payload = copy.deepcopy(baseline)
    del payload["cases"][0]["observations"][field]
    check(f"missing-{field}", payload, False)
for label, changes, expected in (
    ("deadline-expired", {"deadline_remaining_ms": 0}, "REFUSE"),
    ("queue-age-over-policy", {"queue_age_ms": 1001, "max_queue_age_ms": 1000}, "REFUSE"),
    ("queue-age-at-policy", {"queue_age_ms": 1000, "max_queue_age_ms": 1000}, "ADMIT"),
    ("no-requested-work", {"requested_units": 0}, "REFUSE"),
    ("semantic-ineligible", {"semantic_retry_eligible": False}, "REFUSE"),
    ("no-distributed-trigger", {"distributed_trigger": False}, "REFUSE"),
    ("triggered-cheap-label", {"cheap_local_operation": True}, "REFUSE"),
    ("host-proxy-not-downstream", {"downstream_available_units": 0,
                                   "host_free_slots": 10000, "queue_depth": 0}, "REFUSE"),
    ("queue-proxy-not-recovery", {"recovery_available_units": 0,
                                 "host_free_slots": 10000, "queue_depth": 0}, "REFUSE"),
    ("host-proxies-not-an-extra-gate", {"host_free_slots": 0, "queue_depth": 10000}, "ADMIT"),
):
    observation(label, changes, expected)
for state in ("NOT_STARTED", "IN_FLIGHT", "UNKNOWN", "COMMITTED_VERIFIED",
              "COMPENSATION_PENDING", "COMPENSATED_VERIFIED", "MANUAL_RECONCILIATION"):
    observation(f"non-retriable-{state}", {"effect_state": state}, "REFUSE")
for field, value in (("distributed_trigger", True), ("semantic_retry_eligible", True),
                     ("effect_state", "FAILED_NO_EFFECT"), ("deadline_remaining_ms", 1),
                     ("queue_age_ms", 1), ("max_queue_age_ms", 1),
                     ("requested_units", 1), ("downstream_available_units", 1),
                     ("recovery_available_units", 1)):
    observation(f"contradictory-cheap-{field}", {field: value}, "REFUSE", 5)
for label, payload in (("null-root", None), ("list-root", []), ("scalar-root", 7)):
    check(label, payload, False)
for field, value in (("schema", "foreign"), ("cell", "foreign"), ("cases", None),
                     ("extra", True)):
    payload = copy.deepcopy(baseline)
    payload[field] = value
    check(f"schema-{field}", payload, False)
for label, value in (("null-case", None), ("list-case", []), ("scalar-case", 7)):
    payload = copy.deepcopy(baseline)
    payload["cases"][0] = value
    check(label, payload, False)
for field, value in (("id", 1), ("expected", True), ("observations", []), ("extra", True)):
    payload = copy.deepcopy(baseline)
    payload["cases"][0][field] = value
    check(f"case-{field}", payload, False)
payload = copy.deepcopy(baseline)
payload["cases"][0]["observations"]["extra"] = True
check("extra-observation", payload, False)
payload = copy.deepcopy(baseline)
payload["cases"][1]["id"] = payload["cases"][0]["id"]
check("duplicate-case", payload, False)
payload = copy.deepcopy(baseline)
payload["cases"].pop()
check("missing-case", payload, False)
print(f"distributed retry boundary controls: {checked}/{checked}")
PY

printf 'action-selection-contract.test: ok\n'
