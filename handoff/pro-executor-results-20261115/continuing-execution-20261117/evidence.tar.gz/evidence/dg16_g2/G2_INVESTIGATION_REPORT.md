# DG16 G2 bounded source investigation — 17 November 2026

Report state: FINAL  
Author: /root/dg16_g2  
Authority: NONE  
Disposition: Root can proceed with one ordinary hosted, two-observation discriminator over an existing selected test case. Historical G2 remains failed and its emitting-byte attribution remains UNKNOWN.

## Actionable result

A concrete candidate exists beyond the previously retained observation limit. On exact source `205aeab7c93299b0666b261485ab5658d8e183de` / tree `9ffbaf95080092bf4a45b8772a97ed16068544a7`, the registered observation-bound mutation test prints the SHA-256 values of two complete result files containing freshly generated fixture identities. Its existing single-case selector reaches that emitting code without running the canonical suite:

```bash
bash tests/observation-bound-mutation-integrity.test.sh --terminal-journal-custody-heldouts final-directory-fsync
```

The exact emitting chain is:

1. `scripts/verify-package.sh:705` invokes the original test with no arguments.
2. The test's default `state_family` invokes `terminal_journal_custody_heldouts` at line3076.
3. The built-in selector at line3089 selects the same function and requested case.
4. `tests/distributed_generation_fence.py:34-52` creates a new disposable fixture and claims its run.
5. `skills/implementaudit/scripts/claim-run.sh:576-587` allocates a fresh run and obtains `claim_id` from `/dev/urandom`.
6. `skills/implementaudit/scripts/apply-observed-mutation.sh:1202` derives the transaction ID; `result_record` at lines2142-2147 includes both transaction and claim IDs.
7. The test's lines1477-1487 emit `R36_FINAL_DIRECTORY_FSYNC=`, including hashes of the full retained result and predecessor checkpoint.

The unchanged stdout normalizer does not rewrite that prefixed record. `full_evidence.documents` recognizes only JSON starting with a column-zero opening brace; this line starts with the R36 label. The finite repro replacements and later D48/build/install replacements match their separately named prefixes. This establishes a source-backed candidate for an ordinary output measurement. It does not establish which bytes differed in historical run43796080658, does not prove a stderr cause, and does not authorize deleting the hashes or expanding normalization.

## One actual local attempt

The selected existing case was invoked once against a 955-member, 12,562,803-byte partial snapshot. Every restored file's Git blob identity matched source205. This is exact-blob source restoration, not complete-tree qualification.

The command exited1 after0.22 seconds at the unchanged physical-Python guard, before the target marker. The captured error says:

> claim-run.sh: a supported physical Python 3 interpreter is required; set IMPLEMENTAUDIT_PYTHON to its absolute path

The test did not reach the proposed measurement. No guard, environment ownership, helper, expectation or comparator was relaxed. The fixture's cleanup left its task temporary directory empty.

| Captured output | Bytes | SHA-256 |
|---|---:|---|
| stdout | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| stderr | 994 | `b0ee884e73b60ea339c02070ee372055afabf9020087c34723555cfb0d5acb67` |

The local clone preparation first failed with git exit128 because the recovered repository is a partial/promisor repository and cloning all refs requested unavailable object `801cb84818246d088da9289827d27e6598274fc6`. No clone checkout resulted. The narrower exact-source archive was then restored and every extracted blob checked. The provisioning failure is retained in the JSON report; it is not a test failure or source RED.

## Authentic historical artifact checked anew

The GitHub artifact download was performed through the purpose-built connector. Artifact `14201598851`, run `43796080658`, attempt1 is an exact 15,712-byte ZIP with SHA-256:

`7b1056758b5077b010a30064e0eb40a6f7059b08f494982855b438ff4781e4ad`

The archive contains exactly these seven public wire documents:

`RESULT.json`, `HOST.json`, `SOURCE.json`, `PROBE.json`, `CLEANUP.json`, `FAILURE.json`, `ARTIFACT_MANIFEST.json`.

No `stdout.log`, `stderr.log`, private full-relation observation or raw capture member exists. The PROBE wire member is34,212 bytes, SHA-256 `cb606e84004147a2b75a24d58105acf3b8f51c958f2fab74ab4bea61a30be006`, matching the earlier retained wire identity. The separately immutable decoded PROBE from commit30caa27f is59,920 bytes, SHA-256 `71691cb51d07e98a777a839e6f9b6e64d61c8d2cd8b719df97ad7963fdc6383b`, Git blob `8560fab88e6a767f41f0cc8aaef37281fa9aa2cd`.

Fresh provider run and job reads agree: the run completed with failure; both actual computations completed, the independent raw-receiving step failed, and the later preparation/live-review hold steps were skipped. These are provider observations plus the retained proof, not reconstructed raw streams.

## What the four historical differences prove

The preserved public proof uses schema `dg16.full-correspondence-proof.v1`. It reports119 mapped nodes,91 registered tests,111 report slots on each route, both process exit0, and exactly four differences in `whole`. The other four declared relations compare equal at their historical scope.

The two retained VALUE witnesses hash the public schema paths `[result,stderr_sha256]` and `[result,stdout_sha256]`. Their location digests were independently recomputed and matched:

| Public path | Location SHA-256 |
|---|---|
| result.stderr_sha256 | `4985477570aa4572468a9c3cba1e855e1388d6c584ca87ddea9e44e9e951ae70` |
| result.stdout_sha256 | `834e24f5c25a08798f6e558eae0adc6d40a324afbb496cf369d0bde84f502ee1` |

The maintained projection derives those hash fields from the normalized stream bytes and also includes the bytes themselves. The two differing derived hashes therefore require two differing byte fields, exhausting the total of four. The result supports two stream inequalities plus their two derived-hash inequalities. It does not identify four independent producer defects.

Historical v1 retained no actual first-differing offsets or normalized lengths. It retained two typed VALUE witnesses before the comparator's witness budget filled. The correction at `613589dc29f1fd749c966151351e928a13affde2` adds future per-stream metadata and preserves the comparison. Its fixture offsets3/4 are not historical positions. The actual normalized bytes, literal normalized SHA-256 values, and producing-source spans cannot be recovered by reading or inverting the retained typed digests.

The source-bound DAG carrier remains serial and preserves registry source order. Generic parallel completion ordering is not supported as an explanation. This does not establish determinism of every transitive emitter.

## Ordinary hosted proposal and measurement

`proposal/dg16-g2-r36-stdout-probe.yml` is a local proposal only. Root owns its review, any publication and actual execution.

It uses the same ubuntu-26.04 image label and immutable checkout/upload action pins as the authentic G2 workflow. It checks out source205 exactly, checks its full commit/tree and clean status, uses the existing system interpreter, and executes the selected existing case once, then a second time only if the first observation satisfies every existing capture precondition. No package suite, G1/G2/G3 driver, G132 input, installed skill, tool install or remote mutation runs inside it.

Each declared observation retains its complete stdout, stderr, return code, timeout flag, raw-stream digests, marker count, parsed actual marker and terminal-marker observation. Source/runtime/workflow identities and final source status are retained. A derived comparison records each actual field's equality; it does not assert that the two raw hashes must differ or that other fields must agree. All expected relationships remain hypotheses until the captured values are read.

Interpretation after the actual run:

- First establish both original cases completed with their unchanged assertions, exact source and actual terminal marker.
- Examine every observed field. Report hash differences, semantic differences, missing markers and unequal populations as observed.
- If only raw-record hashes differ while every other emitted field agrees, the observation discriminates volatile diagnostic identities at this exact selected-case scope.
- If any other field differs or either case fails, retain the observation and classify the actual result before proposing a change.
- This is no full-G2 equality result and cannot close M2 or attribute its historical stderr.

Privacy is limited to fresh disposable test data. The workflow uploads only the two test stdout/stderr files and their explicit source/result/comparison/manifest records. It does not upload fixture directories, home directories, environment dumps, Git credential configuration, the recovered private inputs, or signed download URLs. Complete raw test outputs remain available for review; the proposal does not truncate them.

Static YAML, embedded Python and Bash syntax checks passed. Ten inert workflow-control cases also passed; these used mocked processes and did not rerun the selected test. They verify that nonzero exit, timeout, missing/malformed marker, wrong marker field population/type, missing terminal marker or dirty source stop after one invocation while still emitting COMPARISON with field_equal null and first_failing_predicate. The valid inert pair reaches the two-observation comparison. No hosted execution was performed by this agent. The final proposal is8,395 bytes, SHA-256 `231a64bdc14a8034db117885f4c9861874b8bcc4d7856f2a3d8d66a1bb5f56e1`.

Both inherited source205 workflows were inspected: pages.yml and validate.yml accept push only on main; validate also accepts pull_request, and pages permits workflow_dispatch. The proposed engineering/dg16-g2-r36-stdout-probe-20261117 branch matches neither inherited push trigger. No PR or manual dispatch is part of this proposal. This trigger conclusion is bound to source205; a different publication-carrier base needs its own inherited-trigger check.

## Original-row delta and authority boundary

| Original row | Delta from this investigation | Acceptance ceiling |
|---|---|---|
| R35-P02 | A concrete emitting-source chain and existing single-case discriminator identified; one real local setup refusal retained. | A prospective testable hypothesis, not a completed producer repair or original-row acceptance. |
| R35-V03 | Authentic archive inventory now directly rechecked; no historical raw capture found. | M2 remains OPEN with its failed complete normalized relation. |
| R35-V04 | Original failure preserved; no success inferred from two exit0 computations. | No new failure-family or whole-row award. |
| R35-Q01 | Comparator, normalization, original expectations and all historical failure evidence unchanged. | No evaluator adoption or new accepted result. |

No original row or cell is newly accepted. No source or comparator patch was made. No full comparison was rerun. No G132 operation or replay decision was made. G132 remains exclusively Root-owned.

The immediate successor is the ordinary selected-case measurement, already authorized by Root. Any later full G2 operation still requires its own exact Root decision and a real observer capable of consuming actual unequal spans before teardown. Raw offsets must be mapped through every variable-length normalization edit; a nearest report slot or source-file guess is not an emitting-source join.
