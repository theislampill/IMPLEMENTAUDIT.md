# DG17 actual phase-return transport

## Frozen source and publication

`SOURCE_FREEZE.json` binds the executable/input candidate. Selected source is a297957be11feb494c0ec467235794a1e0c54751, tree b08dc4ecf4028beeedb579a312eccae23cb5d863. Publish exactly one ordinary direct child on `pro/dg17-phase-return-20261117`. `PUBLICATION_ENTRIES.draft.json` supplies nine `create_tree` blob entries, based on the a297 tree. All new file modes are 100644. Root owns publication and all remote effects.

The request currently has `review.status: PENDING`; the driver refuses that state. After actual independent review, Root inserts only the real review attestation and, if necessary, the actual current parent receipt, then regenerates the request entry in the publication list. Executable/input edits require a recorded delta review. Request bytes are bound into the live session at admission and must remain unchanged thereafter.

The selected package has 78 members and remains unchanged. `transport_primitives.py` is byte-for-byte the proven P07/H07 transport file, SHA256 f84f634f202344c95cf04703054fe47d9c9c1cdbbda295e5d5007c71bdeaf82d. Only its run, custody, mailbox, validation and cleanup primitives are called here. Its P07 preparation, child routing and DG18 observation are not invoked.

## Actual command interfaces

The workflow invokes `/usr/bin/python3 -I -B handoff/dg17-phase-return/hosted_phase.py OPERATION --output "$DG17_OUTPUT"`. Only `prepare` also takes `--request handoff/dg17-phase-return/request.json`. `OPERATION` is one of `prepare`, `plan`, `dispatch`, `phase`, `audit`, `fix`, `reaudit`, `finalize`; it is not derived from returned prose.

The runner admits one real isolated Git task, creates its real a297 claim and controller, authors the seven promised runtime records and phase, performs inspect-initialization/activate-controller, then uses current-controller/invalidate, separate STATE and ROADMAP reads, resume/verify/require-current. Every later source-owner action retains those unchanged gates. All file replacements use `apply-observed-mutation.sh` behind `check-evidence-anchor.sh --mutation-window`, with a fresh exact phase/step, preimage, candidate and landed predicate.

The host deadline is 45 minutes from actual preparation; the workflow has a 50-minute bound. No hosted timer exists before launch. Attempt numbers other than 1 refuse. There is no automatic retry or branch rerun. Root's six response commits each add exactly one previously absent mailbox path and have the exact preceding accepted commit as their sole parent. Mailbox-only commits are excluded from the workflow trigger.

## Root observation and decision sequence

| Actual artifact | Mailbox file under `handoff/dg17-phase-return/mailbox/` | Finite continuing action | Actual next owner action |
|---|---|---|---|
| `dg17-phase-planning` | `01-planning.json` | `correct-plan` | Register Root's actual L4 decision, correct only the received scope, run the deciding authority check, expose corrected currentness; no subject dispatch. |
| `dg17-phase-plan-corrected` | `02-dispatch.json` | `dispatch-reviewed-phase` | Receive Root's post-check L1 rederivation, reacquire currentness, Smoke A, observed replacement, mandatory greeting check, named 5S checks, Smoke B. |
| `dg17-phase-regression` | `03-regression.json` | `repair-operational-record` | Register actual Root containment/repair decision; use a fresh step to correct only the status record; perform mandatory check, 5S and Smoke B; expose actual results. |
| `dg17-phase-phase-repaired` | `04-phase-completion.json` | `complete-phase-and-audit` | Root receives results and makes the actual phase/5S decision; record the completed one-phase census with the full-byte obligation open, then perform exact final audit. |
| `dg17-phase-audit-gap` | `05-final-gap.json` | `repair-final-record` | Register actual Root L5/L4 decision; author a bounded audit-fix plus canonical phase-2 authority; actual Smoke A, one observed byte correction, mandatory verification, 5S and Smoke B. |
| `dg17-phase-final-repaired` | `06-reaudit.json` | `complete-fix-and-reaudit` | Receive an actual independent exact-candidate review and a separate Root decision, complete the fix phase, reacquire currentness, and perform exact re-audit. |
| `dg17-phase-reaudited` | none | none | Retain actual re-audit evidence and terminal task custody. Separate original-case receiving remains Root's responsibility. |

Every decision also permits `retain-contained`. It stops further execution, preserves the actual reason/next action, emits a contained snapshot, and reaches cleanup. Containment does not require a new independent review or a fabricated clean 5S decision.

Root reads each artifact's `PACKET.json`, its exact files and actual command captures before submitting the next data action. Copy the complete `binding` object without reconstructing it. The binding includes source, launch, task, claim, controller, current receipt, owner bytes, phase hashes, stage, previous mailbox commit, exact command witnesses and the complete observation-inventory digest. Each artifact is historical immediately after the task moves; later actions must consume the latest exposed binding.

## Decision data shape

The driver accepts an object with exactly these fields:

- `schema`: `dg17.actual-phase-decision.v1`.
- `binding`: the exact current PACKET binding.
- `action`: the one continuing action shown above, or `retain-contained`.
- `record`: Root's actual bounded decision described below.
- `provenance`: Root's actual source/tool provenance described below.

`record` has exactly `classification`, `witnesses`, `containment`, `return_owner`, `owner_source`, `dependencies`, `acceptance`, `next_action`, and `reason`. `classification` is `failed-criterion` for plan correction and the final gap, `regression` for the observed Smoke delta, and `none` for the three evidence-based continuation/completion decisions. `return_owner` is L1 for planning/dispatch, L3 for the operational repair, and L5 for the phase-completion/final-gap/re-audit decisions. `witnesses` must equal the current binding's `witness_command_ids` list exactly. Other fields are actual single-line Root statements of 8–4096 characters without pipe delimiters. Do not prefill or manufacture those statements from receiver expectations.

For continuing `complete-phase-and-audit` and `complete-fix-and-reaudit` actions only, `record` also contains `five_s`, with exactly `seiri`, `seiton`, `seiso`, `seiketsu`, `shitsuke`. Each is Root's actual `clean` disposition or `deferred: <concrete reason>` longer than 18 characters. The actual named a297 `repo-state.sh added-lines/changed-files` captures are present. The supplementary `git diff --check` and exact changed-file census are also retained.

`provenance` has exactly `actor`, `loaded_governor_source`, `loaded_governor_sha256`, `parent_receipt`, `tool_observation`, and `decision_record_sha256`. Loaded source must truthfully be `a297957be11feb494c0ec467235794a1e0c54751:skills/implementaudit/SKILL.md` with the exact SHA256 in request.package_members. Root must actually load that source for this role; this field is not evidence of loading by itself. `parent_receipt` and `tool_observation` identify the actual current Root receipt and actual tool/connector observation or retained decision record. Record digest uses Python `sha256(json.dumps(record, sort_keys=True, separators=(",", ":")).encode()).hexdigest()`, including Python's default `ensure_ascii=True`.

For continuing `complete-fix-and-reaudit` only, the envelope additionally requires `independent_review`, with exactly `binding`, `reviewer`, `independence_evidence`, `prompt_sha256`, `result_text`, `result_sha256`, and `tool_observation`. Bind the current final-repaired packet, preserve the actual independent review text, and hash its UTF-8 bytes. Prompt digest is an exact lower-case 64-hex SHA256. This is review evidence returned to Root; it grants no authority. Root's separate record/action remains necessary.

No returned command, path, replacement bytes or code is executed. All effect targets and argv are fixed in the reviewed driver. Provider commit/blob custody and supplied role strings do not establish native session authentication. Actual tool provenance and review independence require independent receiving; the transport never claims them merely because fields exist.

## Evidence and cleanup

Each subprocess retains separate complete stdout, stderr, exit, timestamps and owned-process-group cleanup. Mandatory phase capture files preserve the complete producer output; subject checks have an explicit empty-stderr guard. Failed outputs are never replaced by a later capture. Observed mutation owners retain their native transaction records. Each snapshot includes current state/roadmap, phase files, runtime evidence, the actual subject and all command records.

Before an action has effects, the consumed mailbox commit and `ACTION_IN_FLIGHT_<operation>` state are persisted. A mid-action failure is not represented as an untouched prior stage. Finalization uses the unchanged proven cleanup primitive: archive exact owned task custody; delete only when every owned command group is observed absent; otherwise retain the task and explicit terminal-state uncertainty. Neither cleanup nor a green command claims audit closure or native Stop. The complete artifact is `dg17-phase-complete-evidence`.

## Prelaunch observations and scope

Python AST and workflow/YAML checks pass. Ordinary phase-structure checks are retained in `../format_check/RESULT.json`; they bind their exact rendered inputs and are not live run-root or case execution. The final driver subsequently clarified phase-2 Smoke A to the fresh status baseline and added that actual command; the checked schema shape is unchanged. No host, subject predicate, mutation, model call, full suite or original case ran in this authoring lane.

Earlier phase-format failures and pre-execution fixture revisions are retained in `../prospective_phase/preflight_*`. Missing whole-capture syntax, command/metadata separator and maintenance-list syntax were preparer errors. The final controlled serialization gap is a missing final LF. Mandatory greeting acceptance and the status Smoke A/B invariant are distinct so a prior mandatory failure is not mislabeled as Smoke B. Those preparations award no original case and imply no product source defect.

The independent N12 source-semantic packet is at `../N12/RESULT.json`; it is not replayed or promoted by this workflow. All original case and clause awards remain contingent on actual events and independent receiving. No protected grant, merge, release, installation, issue closure, model CLI or personal machine is involved.
