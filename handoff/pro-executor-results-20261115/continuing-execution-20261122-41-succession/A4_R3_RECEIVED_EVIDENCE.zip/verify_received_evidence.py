#!/usr/bin/env python3
"""Read retained A4 R3 bytes; never import/execute the diagnostic or a workflow."""
import hashlib
import json
from pathlib import Path
import zipfile

BASE = Path(__file__).resolve().parent
D = BASE / 'diagnostic'
HOST = 'd258984cb3dad509b07623e797a1669ff4136f00'
SOURCE = '51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
checks = []

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def check(name, condition, detail=None):
    checks.append({'check': name, 'verified': bool(condition), 'detail': detail})

run = json.loads(read(BASE / 'run-44969346074.provider.json')['result']['structuredContent']['content'])
jobs = read(BASE / 'run-attempt1-jobs-raw.json')
artifacts = read(BASE / 'run-artifacts-raw.json')
artifact = artifacts['artifacts'][0]
check('provider exact completed successful first attempt', run['id'] == 44969346074 and run['head_sha'] == HOST and run['run_attempt'] == 1 and run['status'] == 'completed' and run['conclusion'] == 'success')
check('complete provider job population', jobs['total_count'] == len(jobs['jobs']) == 1 and jobs['jobs'][0]['id'] == 137045470127 and jobs['jobs'][0]['head_sha'] == HOST and jobs['jobs'][0]['run_attempt'] == 1 and jobs['jobs'][0]['conclusion'] == 'success')
check('complete provider artifact population', artifacts['total_count'] == len(artifacts['artifacts']) == 1 and artifact['id'] == 14732334790 and artifact['workflow_run']['id'] == run['id'] and artifact['workflow_run']['head_sha'] == HOST)
outer = BASE / 'dg18-a4-compiler-memory-r3-44969346074-1.zip'
outer_pin = digest(outer)
check('outer bytes equal provider size and SHA256', outer_pin['bytes'] == artifact['size_in_bytes'] and 'sha256:' + outer_pin['sha256'] == artifact['digest'], outer_pin)
with zipfile.ZipFile(outer) as z:
    check('outer ZIP exact membership and CRC', sorted(z.namelist()) == ['DIAGNOSTIC.zip', 'ZIP_RECEIPT.json'] and z.testzip() is None)
    check('outer extraction byte equality', all(z.read(n) == (BASE / 'artifact' / n).read_bytes() for n in z.namelist()))
receipt = read(BASE / 'artifact/ZIP_RECEIPT.json')
inner = BASE / 'artifact/DIAGNOSTIC.zip'
check('inner bytes equal retained receipt', digest(inner) == receipt['archive'], digest(inner))
manifest = read(D / 'MANIFEST.json')
members = manifest['members']
paths = [m['path'] for m in members]
check('manifest exact unique bounded population', len(paths) == len(set(paths)) == 83 and sum(m['bytes'] for m in members) == manifest['bytes'] == 885116)
check('all 83 manifest members match bytes and SHA256', all(digest(D / m['path']) == {k: m[k] for k in ('bytes', 'sha256')} for m in members))
with zipfile.ZipFile(inner) as z:
    check('inner exact 84-member population and CRC', len(z.namelist()) == len(set(z.namelist())) == receipt['members'] == 84 and set(z.namelist()) == set(paths) | {'MANIFEST.json'} and z.testzip() is None)
    check('inner extraction byte equality', all(z.read(n) == (D / n).read_bytes() for n in z.namelist()))
intent = read(D / 'INTENT.json')
result = read(D / 'RESULT.json')
before = read(D / 'SOURCE_BEFORE.json')
check('artifact exact source host run attempt', intent['host_commit'] == HOST and intent['source_commit'] == SOURCE and intent['run_id'] == run['id'] and intent['attempt'] == 1 and intent['host_tree'] == run['head_commit']['tree_id'])
host_commit = json.loads(read(BASE / 'host-commit.provider.json')['result']['structuredContent']['content'])
product_commit = json.loads(read(BASE / 'product-commit.provider.json')['result']['structuredContent']['content'])
check('provider host tree and sole product parent', host_commit['sha'] == HOST and host_commit['tree']['sha'] == intent['host_tree'] and [p['sha'] for p in host_commit['parents']] == [SOURCE])
check('provider product tree', product_commit['sha'] == SOURCE and product_commit['tree']['sha'] == intent['source_tree'] == before['source_tree'])
check('source before and after byte equality', (D / 'SOURCE_BEFORE.json').read_bytes() == (D / 'SOURCE_AFTER.json').read_bytes())
for record in read(BASE / 'source-receiving.json'):
    path = BASE / 'source' / record['path']
    raw = path.read_bytes()
    oid = hashlib.sha1(('blob ' + str(len(raw)) + '\0').encode() + raw).hexdigest()
    check('provider Git blob and hash ' + record['path'], oid == record['provider_git_blob_sha'] and digest(path) == {k: record[k] for k in ('bytes', 'sha256')})
for relative, pin in before['members'].items():
    check('artifact product pin ' + relative, digest(BASE / 'source' / ('product-' + Path(relative).name)) == pin)
for key, name in [('helper', 'compile_memory.py'), ('adapter', 'compile_adapter.py'), ('observed_profile_helper', 'observed_tool_profile.py'), ('conhost_custody_helper', 'conhost_custody.py')]:
    check('artifact helper pin ' + name, digest(BASE / 'source' / ('source-' + name)) == intent[key])
workflow = (BASE / 'dg18-a4-compiler-memory-r3.yml').read_bytes()
wf_provider = read(BASE / 'workflow-r3.provider.json')['result']['structuredContent']
check('workflow exact provider blob', hashlib.sha1(('blob ' + str(len(workflow)) + '\0').encode() + workflow).hexdigest() == wf_provider['sha'])
issue = read(BASE / 'issue-215.provider.json')['result']['structuredContent']['issue']
comments = read(BASE / 'issue-215-comments.provider.json')['result']['structuredContent']['comments']
check('issue body exact provider text', (BASE / 'issue-215-body.md').read_bytes() == issue['body'].encode('utf-8'))
check('issue normative comment complete population and exact bytes', issue['comments'] == len(comments) == 1 and comments[0]['id'] == 5638756120 and (BASE / 'issue-215-comment-5638756120.md').read_bytes() == comments[0]['body'].encode('utf-8'))
ceiling = {'authority': 'NONE', 'award': None, 'baseline_subtracted_bytes': 0, 'automatic_retry': False, 'original_28_methods_invoked': False, 'original_method_executions': 0, 'original_guard_bytes': 67108864, 'original_guard_changed': False, 'original_guard_invoked': False, 'product_body_executions': 0, 'frozen_R01_R09_contract_available': False, 'A4_07': 'UNKNOWN_NO_REPLAY'}
check('receipt result and intent retain original claim ceiling', all(all(type(d.get(k)) is type(v) and d[k] == v for k, v in ceiling.items()) for d in [intent, result, receipt, manifest]))
measurements = {}
for mode in ['native', 'r2', 'audit']:
    m = read(D / mode / 'job/measurement.json')
    r = read(D / mode / 'RESULT.json')
    started = read(D / mode / 'STARTED.json')
    command = read(D / mode / 'COMMAND_INTENT.json')
    events = m['process_events']
    created = [e['pid'] for e in events if e['event'] == 'NEW_PROCESS']
    exited = [e['pid'] for e in events if e['event'] == 'EXIT_PROCESS']
    expected = {'status': 'COMPLETE_UNADMITTED', 'exit_code': 0, 'started_suspended': True, 'assigned_before_resume': True, 'root_job_membership_confirmed': True, 'completion_port_associated_before_assignment': True, 'complete_memory_scope_valid': True, 'cleanup_complete': True, 'terminal_active_processes': 0, 'terminal_breakaway_allowed': False, 'initial_job_flags': 8192, 'terminal_job_flags': 8192, 'kernel_total_processes': 2, 'creation_event_count': 2, 'exit_event_count': 2, 'active_process_zero_count': 1, 'abnormal_exit_event_count': 0, 'kernel_terminated_processes': 0, 'baseline_subtracted_bytes': 0, 'harness_included': False, 'metric_admission': 'UNADMITTED_DIAGNOSTIC', 'diagnostic_timeout_seconds': 120}
    check(mode + ' Job conjunction', all(type(m.get(k)) is type(v) and m[k] == v for k, v in expected.items()) and m['process_observation_failures'] == [])
    check(mode + ' unique complete process lifecycle', len(created) == len(set(created)) == len(exited) == 2 and set(created) == set(exited) and [e['event'] for e in events] == ['NEW_PROCESS', 'NEW_PROCESS', 'EXIT_PROCESS', 'EXIT_PROCESS', 'ACTIVE_PROCESS_ZERO'] and events[-1]['pid'] == 0)
    observed = m['observed_processes']
    root = [o for o in observed if o['pid'] == m['root_pid']]
    companion = [o for o in observed if o['pid'] != m['root_pid']]
    check(mode + ' exact Python and held conhost images', len(root) == len(companion) == 1 and set(created) == {o['pid'] for o in observed} and all(o['in_job'] for o in observed) and root[0]['image'] == intent['tools']['python']['path'] and root[0]['image_sha256'] == intent['tools']['python']['sha256'] and companion[0]['image'] == intent['conhost_image']['path'] and companion[0]['image_sha256'] == intent['conhost_image']['sha256'])
    check(mode + ' root identity command and empty streams', m['root_pid'] == r['pid'] == started['pid'] and r['mode'] == started['mode'] == command['mode'] == mode and m['command'] == command['command'] and all((D / mode / 'job' / n).stat().st_size == 0 for n in ['stdout.bin', 'stderr.bin']))
    check(mode + ' result claim ceiling', all(type(r.get(k)) is type(v) and r[k] == v for k, v in ceiling.items()))
    measurements[mode] = {'pid': m['root_pid'], 'conhost_pid': companion[0]['pid'], 'elapsed_ms': m['elapsed_ms'], 'peak_job_committed_bytes': m['peak_job_committed_bytes'], 'peak_single_process_committed_bytes': m['peak_single_process_committed_bytes']}
    if mode != 'audit':
        samples = [read(f) for f in sorted((D / mode / 'native-memory').glob('*.json'))]
        peaks = [s['lifetime_peak_working_set_bytes'] for s in samples]
        check(mode + ' ten ordered native memory records', len(samples) == 10 and [s['sequence'] for s in samples] == list(range(1, 11)) and all(s['pid'] == m['root_pid'] and s['guard_invoked'] is False and s['award'] is None for s in samples) and peaks == sorted(peaks) and peaks[-1] == r['last_lifetime_peak_working_set_bytes'])
        measurements[mode]['last_retained_lifetime_peak_working_set_bytes'] = peaks[-1]
        check(mode + ' four exact two-source compile requests', r['requests'] == r['retained_results'] == 4 and r['compile_restored'] is True and r['code_equivalence'] is True and [x['request'] for x in r['request_population']] == [1, 2, 3, 4])
reuse = read(D / 'r2/RESULT.json')['adapter']
check('reuse exact cache population and restoration', reuse['requests'] == 4 and reuse['cache_hits'] == reuse['native_compilations'] == 2 and reuse['installed'] is False and reuse['restore_error'] is None and reuse['bypasses'] == 0 and reuse['module_instances_cached'] is False and reuse['filenames_rewritten'] is False)
controls = read(D / 'audit/RESULT.json')['controls']
check('bounded audit controls retained', controls == {'compile_restored': True, 'construction_refusals': 3, 'hit_refused': True, 'hook_events': 4, 'installation_refusals': 1, 'miss_refused': True, 'native_refused': True})
for prefix, count, expected_hash in [('GIT', 26, intent['tools']['git']['sha256']), ('CONHOST', 8, intent['conhost_image']['sha256'])]:
    rows = [read(f) for f in sorted(D.glob(prefix + '_OBSERVATION-*.json'))]
    closed = read(D / (prefix + '_CLOSED.json'))
    check(prefix + ' complete ordered custody records', len(rows) == count and [r['sequence'] for r in rows] == list(range(1, count + 1)) and all(r['errors'] == [] and r['handle_closed'] is False and r['run_id'] == run['id'] and r['host_commit'] == HOST and r['receiver_pid'] == 1964 and all(c['equal'] is True for c in r['comparisons'].values()) for r in rows))
    check(prefix + ' initial and terminal held hashes', rows[0]['hash_required'] is rows[-1]['hash_required'] is True and rows[0]['hash']['sha256'] == rows[-1]['hash']['sha256'] == expected_hash)
    check(prefix + ' all handles closed with terminal rehash', closed['errors'] == [] and closed['file_handle_closed'] is True and closed['terminal_rehash_complete'] is True and all(h['closed'] is True for h in closed['directory_handles']))
delta = {'reuse_minus_native_last_retained_lifetime_peak_working_set_bytes': measurements['r2']['last_retained_lifetime_peak_working_set_bytes'] - measurements['native']['last_retained_lifetime_peak_working_set_bytes'], 'reuse_minus_native_peak_job_committed_bytes': measurements['r2']['peak_job_committed_bytes'] - measurements['native']['peak_job_committed_bytes']}
output = {'scope': 'Deterministic receiving of stored bytes only; no diagnostic or original method executed', 'authority': 'NONE', 'all_checks_verified': all(c['verified'] for c in checks), 'checks_count': len(checks), 'checks': checks, 'measurements': measurements, 'deltas': delta, 'original_A4_award': None}
(BASE / 'receiving-verification.json').write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps({k: v for k, v in output.items() if k != 'checks'}, indent=2))
raise SystemExit(0 if output['all_checks_verified'] else 1)
