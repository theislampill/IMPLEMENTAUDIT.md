# P04 v2 — corrections received and verified for independent rereview

This is a source-author handback, not an independent readiness decision or original case award. The v1 independent GAP was received at report SHA-256 `f8bebf3f7266f1ad2143b7a2374c3f0e9b600c0fcf422fbe1ea03d49ab0993b8`, seal `56e878f3418a9440a1f5448f76d273edb09c11377149fc721500801a5154152e`. All four review members and all 24 frozen v1 members were verified before revision. V1 and its failures remain unchanged.

## Corrections to the two blocking findings

**P04-R1 — actual subject HEAD and tree.** Preparation now obtains both identities through real Git readback and retains `SUBJECT_BASELINE.json`; both are stored in the actual episode context and included in the stale request. Before authoring G0002, the driver rereads both and refuses drift. The new epoch row contains both verified subject HEAD and tree on that selected row. Final receiving rereads the same pair. The original claim owner and its AWK predicate are unchanged; the original product tree is never substituted for the disposable subject tree.

**P04-R2 — partial command and surviving effect custody.** Every command now writes its dispatch intent before invocation. A normal return retains exact stdout/stderr and its actual return code. A real TimeoutExpired retains whichever partial binary streams the exception provides, labels their completeness PARTIAL_OR_UNKNOWN, retains a null return code, and records effect outcome UNKNOWN with no automatic replay. An unavailable stream is distinct from an observed empty stream. Other dispatch/capture errors likewise do not invent an effect result or descendant termination.

The workflow now runs `retain-surviving-evidence` under `if: always()` before the final upload. This separate observation path does not construct an Episode, need context.json, verify a receipt, call a continuity/mutation helper, change the subject or retry any operation. It records surviving target/input and run-root/transaction bodies and physical identities, local Git HEAD/tree/refs/status and object population, including unreferenced object bodies. It writes only a sibling derivative evidence directory. Missing, unreadable, unsafe, drifting or limit-exceeding material is explicit; absence at observation is not evidence that an earlier effect never occurred. There is no atomic snapshot, quiescence, authority or acceptance claim.

The final artifact includes both the original `dg17-p04-original/evidence` and `dg17-p04-original-survivors` populations. A hard host loss or cancellation that prevents even the always-run step remains unavailable evidence; this source change cannot manufacture lost state.

## Meaningful public/disposable controls

The identical six-test oracle was first run against frozen v1: **6 failures, 0 errors**. It reproduced the real selected-row AWK refusal and a real subprocess timeout after a public file change and binary output; v1 had not preserved those raw streams. Missing identity/finalizer capabilities and workflow placement were also discriminated. The actual RED stdout/stderr, command/source/test bindings and disposable outcomes are retained.

The same tests pass against the final v2 driver/workflow: **6 passed, 0 failures, 0 errors**, actual command receipt `SEALED_SOURCE_CONTROL_RESULT.json`. The test file is unchanged across RED and final GREEN: SHA-256 `fd64989df18d172a6727adc0bb26476a54bf52fe3c627363ebe7d2b53ad67048`.

| Control | Actual distinction observed |
|---|---|
| Original selected-row predicate | Actual public subject HEAD/tree pass the unchanged AWK; wrong HEAD and wrong tree each refuse |
| Live subject readback | The driver reads real Git identities and rejects an intentionally wrong expected tree |
| Real timeout | A public child changes a public target, writes a test-only transaction-shaped file and emits NUL/non-UTF8 bytes before timing out; exact partial streams survive and effect remains UNKNOWN |
| Nonzero partial effect | A separate public child changes a target, leaves test-only transaction state and exits 9; finalization retains those bodies and a real unreferenced public Git object |
| Missing/symlink state | Missing input is recorded as absent at observation with historical effect UNKNOWN; an external public sentinel behind a symlink is not followed |
| Always-run retention | The workflow contains exactly one unconditional survivor step before unconditional upload, and uploads both evidence populations |

These are harness regressions, not original mutation/controller/GitHub executions. The fixtures are visibly PUBLIC_TEST_ONLY and contain no original claim, receipt or grant. They confer no P04 award.

## Nonblocking capture annotation correction

V1's legacy phase warnings remain historical. An initial v2 attempt to annotate split-stream captures was genuinely rejected by the unchanged phase validator because its declared full-capture file must contain both streams. That additional RED is preserved under `history/v2-split-capture-red/` and in the top-level actual result/streams.

The final phase instead declares the actual three outer driver commands and their real combined stdout/stderr workflow log files. The driver continues to retain both native raw streams separately with exact argv, exits, timing and hashes; independent original receiving still needs those native captures. Timeout partial output cannot satisfy planned full-capture acceptance. The original unchanged phase validator now returns **exit 0**, `validate-phase: ok`, with **empty stderr**. No validator rule or original acceptance predicate was weakened.

## Final source identities and unchanged authority

- Driver SHA-256: `631b2b455121db0bedb529e23b953df3b3aeee80b391fc9299ec82d376b247d1`.
- Workflow SHA-256: `b6b8c80dd209098031336e8a6d22322ea9f8b85e7aeaccfdf4da80ea175c22df`.
- Original source remains `a297957be11feb494c0ec467235794a1e0c54751`, tree `b08dc4ecf4028beeedb579a312eccae23cb5d863`; SOURCE_BINDINGS.json remains byte-identical to v1.
- Initial Root authorization and live re-anchor control remain UNISSUED. Their schemas, exact effect, new branch names, fixed source ownership and same-host pending task are preserved. Updated final hashes are in ISSUANCE_REQUIREMENTS.json.
- V1's independent prospective applicability judgment is retained at its original scope. The same reviewer must receive this v2 correction before Root considers dispatch; this author does not close its own findings.

No original controller, hosted case, original mutation, provider operation, grant or Root decision was executed by this author. No protected G132 effect, historical a0f134 replay, mutation-family credit, terminal clause, integration, release, closure or denominator change follows. After source receiving, Root still must issue the genuine initial authorization, execute the case, receive the actual stale packet, issue the genuine live route and obtain independent original final receiving.

## Self-critique

1. Public controls establish the repaired capture and predicate behavior only. They do not establish a hosted original case or imply that a future original initialization succeeds.
2. Surviving evidence is observational and may be partial or non-atomic. The receiver must retain unavailable/UNKNOWN outcomes and never infer safe replay from an error or missing path.
3. The actual Root issuer, current authority and live decision remain external evidence requirements. Prefix checks or JSON strings cannot substitute for the real Root/provider issuance receipts.
