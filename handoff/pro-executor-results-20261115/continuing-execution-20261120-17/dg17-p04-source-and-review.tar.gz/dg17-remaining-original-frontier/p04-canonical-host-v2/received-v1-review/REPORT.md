# Independent review — original DG17 P04 hosted proposal

**Disposition: GAP. Do not treat this frozen revision as technically ready for the proposed dispatch.** Two concrete findings require a revised, separately frozen packet: the G0002 row lacks the subject tree required by the unchanged original owner, and failure paths can lose the raw command and surviving task evidence needed to reconcile an uncertain mutation. This is a nonauthor engineering/readiness opinion with **no control, mutation, acceptance, or closure authority**.

## Bound candidate and review scope

- Reviewer: `/root/dg17_p04_independent_review`.
- Frozen input: `p04-canonical-host-v1/FROZEN_MANIFEST.json`, SHA-256 `0dc05deb3b02d95c9dc7c80cc78eaa90e4eca5c64544f6049497ab2370dd4e29`.
- Independently verified population: **24 members, 171699 bytes**, every declared length and hash matched.
- Driver: SHA-256 `30b03ea815899bc7b43a3ceb9f745f513671cf7e03d49c9dc5668f2610de574d`.
- Workflow: SHA-256 `ec7b6cc4a9dbbdc1ffdff1f6469c3649193385f419e61831aa37aa454455b110`.
- Original source: commit `a297957be11feb494c0ec467235794a1e0c54751`, tree `b08dc4ecf4028beeedb579a312eccae23cb5d863`.

I independently read all 23 source blobs from the parent-designated local Git object store with lazy fetching and optional locks disabled. Every exact body matched `SOURCE_BINDINGS.json`; the nine retained inspected source bodies matched as well. The issue body matched its pinned SHA-256. I parsed the driver as syntax, checked the declared 20-stage sequence, and established that its live phase string produces the retained static GREEN phase. I reviewed the author's retained validator RED, correction and GREEN, including both warnings. I did not rerun a controller, initialization, host, original mutation, provider, model-policy actor, or native skill operation.

The only executed discriminator was the unchanged owner's literal AWK epoch predicate applied to explicitly synthetic strings. Its actual exit 1 and complete input/output are retained in `STATIC_G0002_RED.json`; this is a static source witness, not a hosted or controller result. `STATIC_CHECKS.json` records the independently repeated identity checks.

## P04 applicability and precise claim boundary

The original issue defines P04 as **custody/currentness mismatch during L2 resume → L4 refuses mutation, preserves mismatch, routes re-anchor** (`ISSUE211_BODY.md:552`). Its L2 definition includes actual durable run state and currentness (`313–323`); L4 permits mechanical detection and deterministic safe dispositions (`340–346`). It does not require a model-policy actor or a native Stop hook for this row. The structural/model boundary and conditional model controls remain binding (`541–545`, `588–595`).

**The proposed architecture can, after correction and actual execution, establish the complete literal P04 operational conjunction at the recorded ordinary original-owner layer. This exact frozen revision cannot establish its declared successful continuation.** A fresh claimed run, actual initial receipt, real subsequent invalidation, original consumer refusal, durable mismatch witness, genuine Root control, and canonical re-entry on the same subject form a materially stronger case than helper exit 77 in isolation. The unchanged positive continuation is the discriminating evidence that the refusal was caused by currentness rather than a permanent independent authority failure.

This applicability judgment does not make an initial or future Root JSON self-authenticating. Root must actually receive the stale artifact, retain its independent current authority and provider issuance evidence, and issue the recovery control only for the observed live request. Its control can serve as the real procedural governor route for this mechanically specified case. The experiment does not thereby establish model judgment quality. If a future receiving claim instead relies on a model's independent recognition or choice of route as the measured behavior, calling that model “Root” or “governance” does not exempt it from the issue's model-facing controls; the current packet contains no such controlled model experiment.

No case is awarded by this review. Root authorization and control are UNISSUED, host/controller work is unperformed, and final independent original receiving remains necessary. No mutation family, other case, terminal clause, native activation, native Stop/session, current-source equivalence beyond the pinned a297 source, integration or release follows from this prospective applicability.

## Blocking findings

### P04-R1 — G0002 lacks the subject tree required by the original owner

**Severity: HIGH; readiness blocking.** The driver stores the subject's seed HEAD as `baseline`, but stores no subject tree (`operate.py:235–239`). It authors the G0002 epoch row with a Repo identity cell containing only `subject HEAD {baseline}` (`349`).

The original `claim-run.sh:306` selects the requested epoch/boundary row only if its Repo identity cell contains **both** actual subject HEAD and actual `HEAD^{tree}`. Verification/require repeats that condition at `328`. The retained G0001 row cannot supply the missing tree: the owner checks those predicates on the selected G0002 row itself. The original product tree is also not the disposable subject's tree.

Therefore, even after a genuine valid Root recovery decision, the declared `resume-current` stage will refuse before issuing G0002. The later verification and identical `COMMITTED` continuation cannot be reached. The exact predicate on the proposed row shape returned 1 in the bounded static discriminator; no controller execution is claimed.

**Smallest countermeasure:** capture and retain the actual subject HEAD and tree through ordinary readback, require their expected identities, and include both in the authored G0002 row. Keep the original owner and its acceptance predicate unchanged. Preserve this frozen revision and static RED as the failed predecessor; produce and review a new packet rather than editing the sealed input in place.

### P04-R2 — failure paths can discard the evidence of an uncertain effect

**Severity: HIGH; readiness blocking.** `Episode.command()` invokes `subprocess.run(..., capture_output=True, timeout=120)` and writes the raw captures only after that call returns (`operate.py:122–140`). A `TimeoutExpired` exception bypasses those writes. The outer handler records only exception type/text (`522–528`); it does not retain the exception's partial stdout/stderr or a complete typed dispatch/termination outcome.

The only full run-root copy and final target/ref observation occurs in `final()` (`368–387`). The workflow's `final-receive` stage (`71–72`) has the normal success condition and is skipped after any preceding failure. The always-run upload (`73–81`) uploads only the evidence directory. It does not preserve the subject, transaction files, or its Git object store unless an earlier stage already copied the relevant material.

A mutation that times out after creating a transaction or changing the target can consequently leave those actual facts outside the upload before runner disposal. Even an ordinary nonzero mutation return can skip the post-attempt identity and run-root captures. The existing failure record and no-replay rule are useful, but they cannot establish an empty effect set or reconstruct lost state.

**Smallest countermeasure:** preserve partial raw command streams and typed timeout/dispatch/unknown metadata, then add failure-tolerant, nonmutating evidence finalization for every reachable unsuccessful termination. Capture surviving target/input identities and bodies, run-root/transaction state, and required Git ref/object evidence, or explicitly record what was unavailable or lost. The finalizer must preserve earlier failures and must not replay a mutation, manufacture a receipt, assume absence, or require successful currentness as a prerequisite to retaining failure evidence. Evidence retention must precede disposal; the completed disposable target need not be reverted.

## What is correctly scoped in this candidate

The ordinary mutation consumer validates claim custody and the exact phase mutation-authority projection before it reaches the currentness check (`apply-observed-mutation.sh:876–901` versus `2258–2262`). The authored phase declares exactly one replace operation on `task/route-map.json`, excludes the two input files, and supplies differing preimage/candidate bytes (`operate.py:419–513`). Thus a real `STALE_CONTINUITY_RECEIPT` result from this exact path would not be explained by an earlier missing phase projection. Genuine initial Root authorization is still an external prelaunch requirement, not a result of the retained static validator GREEN.

The workflow uses one job and one work directory, with separate completed initial and resume STATE/ROADMAP read steps. It creates a fresh subject and attempt-one controller, uses the real system interpreter with the original selector, and contains no interpreter shim or original-source patch. Both phases remain the same pending task; the command hash, input/target physical identities and transaction absence are checked around the stale attempt and before the positive continuation. The re-anchor control is bound to the exact run/attempt, controller, claim, original receipt, invalidation, command, request bytes and target hashes. The separate control carrier checks its sole parent, sole added path and closing ref. These are meaningful prospective controls, not observations of an executed episode.

The stale request creates a 1200-second decision deadline, and control consumption checks that deadline. Root must receive and issue within the live hold; a missing or mismatched control cannot be converted into success. The source checkout is isolated from the disposable subject and control carrier. Source readback requires exactly four additions and no checkout dirt; Root must additionally verify the publication's sole parent is a297 through its actual provider records. The driver does not independently establish the authenticity or semantic currentness of Root's receipt from its prefix check.

## Nonblocking observations and receiving obligations

The author's phase GREEN retains the original legacy coverage and acceptance-bank warnings. The actual completed-command capture mechanism is concrete, but the newly authored mandatory-command rows omit the requested coverage/capture annotations. A revised packet should make those rows explicit without suppressing the warnings or relabeling them as native evidence. This documentary issue is separate from the blocking timeout omission.

For the revised operation, actual receiving still needs the full Root authorization and issuance record; exact published parent/tree/four-file readback; real host and initial custody evidence; actual refusal and unchanged target/input observations; authentic live Root control and provider proof; separate canonical reads and G0002 resume/verify/require; identical-command `COMMITTED` output and effects; final scope/cleanup facts; and a nonauthor original-case disposition. A successful upload or an observation JSON is not that disposition.

Preserve the prior installed-owner P04 evidence at its original identity. The historical a0f134 helper-branch effect remains **UNKNOWN_NO_REPLAY** and is unrelated to the new operation. Preserve the source author's actual phase RED and GREEN, this review's static RED, all unsuccessful future returns, and any unavailable/lost outcomes. Original case/terminal/family denominators remain unchanged. The parent-owned Root continuity receipt was not inherited or exercised by this reviewer.

## Returned decision

**GAP for the reviewed frozen packet; two narrow harness corrections, no original-source change.** The deterministic original-owner plus genuine live-governor-control design is prospectively applicable to literal P04, but it must first satisfy the unchanged G0002 owner contract and preserve its actual failure evidence. Root retains all decisions about revision, publication, execution, integration and eventual original receiving.
