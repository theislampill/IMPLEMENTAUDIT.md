# Root-only issuance and receiving

This v2 packet is prospective and supersedes only the still-unissued v1 proposal. Its author has issued no Root decision and has not run an original controller, hosted case or provider mutation. Public disposable capture/retention regression controls are separately labeled. The two JSON bodies below must be genuinely authored by Root from actual current evidence. Placeholder, copied or retrospective decisions are invalid.

## Initial source/applicability review

Send the final frozen manifest, PLAN.md, operate.py, workflow, SOURCE_BINDINGS.json, and retained local structural RED/GREEN to an actual nonauthor. Require an explicit disposition on whether the complete literal original P04 case can be established by this deterministic canonical-owner episode plus actual Root route. Author/evaluator cognition is not an experimental policy actor. If the review finds an unevaluated model judgment or missing L4/L2 composition, keep that gap rather than claiming a complete case from helper exit 77.

The packet contains no model-policy prompts or claims. The actual Root authorization and live Root route remain outside the harness. Root alone supplies authority; independent review returns findings only.

## Prelaunch Root authorization — exact fields

After receiving a suitable independent source disposition, create `handoff/dg17-p04-original-20261120/ROOT_AUTHORIZATION.json` with exactly these keys:

| Key | Actual value required |
|---|---|
| `schema` | `dg17.p04.root-operation-authorization.v1` |
| `issuer` | `/root`, backed by the real Root issuance record and provider call |
| `issued_at` | Actual UTC issuance timestamp |
| `root_continuity_receipt` | The actual currently verified Root receipt, not this author's or a historical default |
| `operation_id` | `dg17-p04-canonical-resume-20261120-01` |
| `source_commit` | `a297957be11feb494c0ec467235794a1e0c54751` |
| `source_tree` | `b08dc4ecf4028beeedb579a312eccae23cb5d863` |
| `branch` | `pro/dg17-p04-canonical-resume-20261120-01` |
| `control_branch` | `pro/dg17-p04-canonical-reanchor-control-20261120-01` |
| `script_sha256` | Exact final sealed operate.py SHA-256 |
| `workflow_sha256` | Exact final sealed dg17-p04-original-host.yml SHA-256 |
| `source_bindings_sha256` | Exact sealed SOURCE_BINDINGS.json SHA-256 |
| `target` | `task/route-map.json` |
| `preimage_sha256` | SHA-256 of exact bytes `{"route":"blue"}\n` |
| `candidate_sha256` | SHA-256 of exact bytes `{"route":"green"}\n` |
| `authority` | `ORDINARY_DISPOSABLE_TASK_AND_EXACT_SOURCE_QUALIFICATION` |
| `independent_source_review` | Actual object identifying reviewer, report path/hash and `manifest_sha256`; no invented PASS or transferred authority |

Publication must have sole parent a297, exact four additions and no source modifications:

1. `.github/workflows/dg17-p04-original-host.yml` from the sealed workflow.
2. `handoff/dg17-p04-original-20261120/operate.py` from the sealed driver.
3. `handoff/dg17-p04-original-20261120/SOURCE_BINDINGS.json` from the sealed bindings.
4. The genuinely issued Root authorization above.

Reconcile both proposed refs before publishing; a 404 alone does not settle any unknown prior write. These operation identities are newly selected and distinct from the historical `qualification/dg17-exact-a297-host-parent-r2-20261119` / a0f134 UNKNOWN. Do not issue the control branch yet. Preserve every actual provider intent, result, blob/tree/commit/ref identity and exact readback. Root is the only writer.

The workflow has a 35-minute limit. The hold deadline is 1,200 seconds after the actual stale request; source setup must finish before that timer starts. Root must remain available to receive the stale artifact and issue the live decision. Do not launch then abandon the hold.

## Actual stale receiving and Root route

The first artifact is `dg17-p04-stale-<actual-run-id>-a1`. Receive its actual ZIP/body/hash and full `STALE_REQUEST.json`, `ACTUAL_STALE_RESULT.json`, source/host/context records, before/after identities, all command stdout/stderr and stale Git object bodies. Establish from those actual returns:

- One new actual controller/claim and initial G0001 receipt were obtained through canonical source commands.
- The actual subject HEAD and HEAD^{tree} match the retained SUBJECT_BASELINE.json and actual context. These are the disposable subject identities, not the original product commit/tree.
- The manual-resume invalidation is real and makes that receipt stale.
- The authorized mutation command returned exit 77, `UNSUPPORTED_OWNER_DECISION`, `STALE_CONTINUITY_RECEIPT`, with an empty actual effect set.
- The target and both inputs retain their exact physical identities and bytes; the mutation transaction is absent.
- The request belongs to the exact published workflow commit, run and attempt, and its hold is still live.

Only after receiving that evidence may Root genuinely choose `CONTAIN_AND_REANCHOR_THEN_REVALIDATE_PENDING_EFFECT`. If any premise fails, do not fabricate an approving control. Preserve the failure; let the bounded job stop or use an authorized containment action.

Create `handoff/dg17-p04-original-20261120/ROOT_REANCHOR_DECISION.json` with exactly these keys:

- `schema`: `dg17.p04.root-reanchor-decision.v1`.
- `issuer`: `/root`, with actual Root/provider issuance evidence.
- `issued_at`: actual issuance time.
- `root_continuity_receipt`: actual current Root receipt at issuance.
- `operation_id`, `workflow_commit`, `run_id`, `run_attempt`, `controller`, `claim_id`, `initial_receipt`, `invalidation`, `command_sha256`, `target`, `preimage_sha256`, `candidate_sha256`: exact values from the actual stale request.
- `request_sha256`: SHA-256 of the exact received STALE_REQUEST.json bytes, including its retained formatting/newline.
- `decision`: `CONTAIN_AND_REANCHOR_THEN_REVALIDATE_PENDING_EFFECT`.
- `observed_refusal`: exact object from the actual request's `actual_refusal` field.
- `scope_expansion`: false.

Publish one control commit whose sole parent is the exact workflow commit and whose sole change is adding that decision file, then create the predeclared control branch once. The running job fetches the immutable observed control object, checks parent/tree/body/request binding and closing ref, then re-anchors the same live subject. Preserve actual provider creation/readback records for the independent receiver; an issuer string by itself is not authority evidence.

## Final receiving

Receive `dg17-p04-final-<actual-run-id>-a1` and the actual terminal job/run result. A finished upload does not mean the case passed. The final upload now includes both `dg17-p04-original/evidence` and the sibling `dg17-p04-original-survivors` directory; receive both populations and their manifests. On success, obtain the driver evidence manifest, original raw refusal, actual Root decision consumption, separate post-boundary reads, canonical G0002 resume/verify/require receipts, original unchanged consumer's `COMMITTED` return and all actual effects, final tracked-file census and input identities, and actual run-root/Andon records.

Each command now retains a pre-dispatch intent and actual result record. TimeoutExpired partial stdout/stderr are kept as exact available bytes, marked PARTIAL_OR_UNKNOWN; returncode remains null and effect outcome UNKNOWN. Missing partial streams are explicitly unavailable, never equated with observed empty output. A nonzero or timed-out original effect must not be replayed from its exit alone.

The always-run survivor finalizer does not require a valid context file, current receipt or success-path final receiver. It performs read-only local observations of surviving files and Git objects/refs, writes only a separate derivative evidence directory and never calls original continuity/mutation helpers. Its report has no authority or acceptance verdict. A missing file at capture time is not proof that the earlier effect never occurred. It follows no symlinks and reports unreadable/unsafe, changed, absent and bounded-retention gaps explicitly. Host loss or cancellation that prevents this finalizer from running remains an unavailable-evidence boundary; no source change can retroactively invent that evidence.

Use a nonauthor original receiver. Its decision must separately cover complete P04, behavior without full acceptance, source/infrastructure only and hard gaps. No mutation family, other case, terminal clause, native Stop/session, whole DG17, source currentness beyond a297, integration/merge or release follows automatically. Preserve prior installed-owner P04 evidence and all historical UNKNOWN effects.
