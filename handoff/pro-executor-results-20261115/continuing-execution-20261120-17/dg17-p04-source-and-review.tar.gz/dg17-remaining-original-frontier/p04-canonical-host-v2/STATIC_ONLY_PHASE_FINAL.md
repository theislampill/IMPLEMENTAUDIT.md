IMPLEMENTAUDIT_PHASE_START
Phase: 1 of 1 — Apply the authorized route-map replacement
Task: Replace the exact task route-map preimage with the authorized candidate only under current continuity
Type: brownfield
Run root: .IMPLEMENTAUDIT/runs/p04-static-QwErTy
Baseline ref: a297957be11feb494c0ec467235794a1e0c54751
Owner/source: task/route-map.json
Mandatory commands: canonical continuity verification; exact original mutation consumer; exact post-state receiving
Acceptance criteria: 3
Evidence required: complete actual command captures and target/input identities
Depends on phases: none

## Why

The owner authorized one exact route-map replacement. A pending task must not mutate through a stale continuity receipt.

## Current state excerpts

- The target task/route-map.json contains the exact bytes retained in input/preimage.json at the seed commit.
- input/candidate.json contains the sole authorized replacement; unrelated inputs are preserved.

## Work

Submit the existing canonical mutation consumer for this exact target and phase authority. If its currentness gate refuses, preserve the actual mismatch and wait for the real Root recovery decision before re-anchoring.

## Implementation steps (ordered)

- Step 1: Replace the authorized route map — target: task/route-map.json; change: replace the exact input/preimage.json bytes with input/candidate.json; verify: invoke the unchanged apply-observed-mutation.sh owner and compare the complete post-state; expected: COMMITTED only with current canonical continuity and the same exact phase authority
  mutation-authority: {"operation":"replace","source":"task/route-map.json","destination":null}

## Scope boundaries

In scope: task/route-map.json
Mutation scope: {"in":["task/route-map.json"],"out":["input/candidate.json","input/preimage.json"]}
Out of scope: the two input files, original product sources, external effects, protected generations and unrelated task files.

## STOP conditions (plan-specific)

- Stop if the canonical continuity receipt is stale or its controller/claim no longer identifies this exact pending task; retain the actual refusal and recover through the original owner.
- Stop if target bytes differ from input/preimage.json before the first effect, or if applying the candidate requires an unlisted target.

## Acceptance criteria

- [ ] The source mutation owner refuses the actual stale request before target or transaction effects.
- [ ] The actual Root decision and canonical G0002 receipt re-anchor this same task before the still-unperformed replacement is submitted.
- [ ] The original consumer commits the exact candidate and retains both input physical identities.

## Mandatory commands

- /usr/bin/python3 -B "/PUBLIC_STATIC_ONLY/source/handoff/dg17-p04-original-20261120/operate.py" require-current --source "/PUBLIC_STATIC_ONLY/source" --work "/PUBLIC_STATIC_ONLY/work" > "/PUBLIC_STATIC_ONLY/work/evidence/host-actions/require-current.log" 2>&1 — property: behavioral; scope: the exact claimed controller through its unchanged canonical owner; coverage: full; capture: /PUBLIC_STATIC_ONLY/work/evidence/host-actions/require-current.log; acceptance: non-textual; expected: driver exit 0 only after the native owner returns the exact actual canonical receipt token following verified re-anchor.
- /usr/bin/python3 -B "/PUBLIC_STATIC_ONLY/source/handoff/dg17-p04-original-20261120/operate.py" stale-attempt --source "/PUBLIC_STATIC_ONLY/source" --work "/PUBLIC_STATIC_ONLY/work" > "/PUBLIC_STATIC_ONLY/work/evidence/host-actions/stale-attempt.log" 2>&1 — property: behavioral; scope: the authorized replacement while currentness is stale; coverage: full; capture: /PUBLIC_STATIC_ONLY/work/evidence/host-actions/stale-attempt.log; acceptance: non-textual; expected: driver exit 0 only after native exit 77 with typed STALE_CONTINUITY_RECEIPT and actually unchanged target/input identities.
- /usr/bin/python3 -B "/PUBLIC_STATIC_ONLY/source/handoff/dg17-p04-original-20261120/operate.py" apply-current --source "/PUBLIC_STATIC_ONLY/source" --work "/PUBLIC_STATIC_ONLY/work" > "/PUBLIC_STATIC_ONLY/work/evidence/host-actions/apply-current.log" 2>&1 — property: behavioral; scope: the identical pending replacement after actual re-anchor; coverage: full; capture: /PUBLIC_STATIC_ONLY/work/evidence/host-actions/apply-current.log; acceptance: non-textual; expected: driver exit 0 only after native exit 0 with typed COMMITTED and exact post-state verification.

The mandatory command rows name actual workflow driver commands and their combined outer stdout/stderr files. Each driver additionally retains the exact native argv and both native raw streams separately under captures/, with exit, timing and identity metadata. These native captures remain required original receiving evidence. A timeout is explicitly partial/UNKNOWN rather than satisfying the planned full-capture acceptance.

## Evidence required in transcript

- Actual native commands, stdout/stderr and exits; claim, receipt and invalidation object bodies.
- Exact target/input bytes and physical identities before refusal and after continuation.
- The genuine Root containment/re-anchor decision and its provider identity, followed by independent original receiving.

## Rollback / defer path

Preserve the disposable task and complete evidence on any failure. Do not repeat an uncertain effect or mutate an original controller. A completed task target need not be reverted; it is confined to this fresh qualification repository.

## Graphify / ActiveGraph / Markdown fallback status

Graphify: absent
ActiveGraph: absent
Markdown fallback: yes

## Cleanliness override, if any

No override. Only the one declared target may differ among tracked task files.

## Maintenance notes

- Retain the exact stale refusal, genuine Root control and final transaction receipts through independent original receiving; these records keep the same pending effect identifiable across re-anchor.
- Preserve the unchanged product source and both authorized input bodies; this episode introduces no runtime owner or helper guard change.

IMPLEMENTAUDIT_PHASE_VERIFY

No acceptance passage is asserted in this initial phase. Real observations and independent adjudication remain required.

AGENTS_UPDATE_DECISION

Decision: not warranted
Reason: this is one bounded qualification episode, not a durable product rule.

CONTINUITY_DECISION

Decision: preserve actual task receipts and failure evidence after the native owners return them.
Evidence boundary: no copied receipt, invented Root decision, model judgment or original case award.

IMPLEMENTAUDIT_PHASE_DONE

Status: open
