#!/usr/bin/env python3
"""Public disposable harness controls only; never invoke an original controller."""
import argparse
import ast
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import types
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
PARSER = argparse.ArgumentParser()
PARSER.add_argument("--driver", required=True)
PARSER.add_argument("--workflow", required=True)
PARSER.add_argument("--owner", required=True)
PARSER.add_argument("--work", required=True)
ARGS = PARSER.parse_args()
ROOT = Path(ARGS.work).absolute()
ROOT.mkdir(parents=True)
SPEC = importlib.util.spec_from_file_location("p04_driver_under_test", ARGS.driver)
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)
ACTUAL_RUN = subprocess.run


def git(repo, *args, data=None):
    return ACTUAL_RUN(["git", "-C", str(repo), *args], input=data, capture_output=True, check=True,
                      env={**os.environ, "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": "/dev/null"}).stdout


def fixture(name):
    work = ROOT / name
    subject, evidence = work / "subject", work / "evidence"
    subject.mkdir(parents=True); evidence.mkdir()
    for relative, body in [(M.TARGET, M.PREIMAGE), *M.INPUTS.items(), (".gitignore", b".IMPLEMENTAUDIT/\n")]:
        path = subject / relative; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(body)
    git(subject, "init", "--initial-branch=public-control")
    git(subject, "config", "user.name", "Public disposable regression control")
    git(subject, "config", "user.email", "p04-public-control@example.invalid")
    git(subject, "add", ".")
    git(subject, "commit", "-m", "Public test input only; no original controller or acceptance")
    episode = M.Episode.__new__(M.Episode)
    episode.work, episode.subject, episode.evidence = work, subject, evidence
    episode.action, episode.counter = "public-control", 0
    return episode


def original_predicate():
    source = Path(ARGS.owner).read_text()
    line = next(line for line in source.splitlines() if 'next="$(awk ' in line)
    predicate = line.split("'function q(x)", 1)[1].rsplit("' \"$state\"", 1)[0]
    return "function q(x)" + predicate


def current_row(context):
    if hasattr(M, "reanchor_epoch_row"):
        return M.reanchor_epoch_row(context, "PUBLIC_CONTROL_ONLY", "3" * 40)
    # Receive the real v1 authored expression, rather than recreating its typo.
    tree = ast.parse(Path(ARGS.driver).read_text())
    node = next(n.value for n in ast.walk(tree) if isinstance(n, ast.AugAssign)
                and isinstance(n.value, ast.JoinedStr)
                and any(isinstance(v, ast.Constant) and isinstance(v.value, str)
                        and "| G0002 | manual-resume |" in v.value for v in n.value.values))
    expression = compile(ast.Expression(node), "<actual-v1-row-expression>", "eval")
    return eval(expression, {"self": types.SimpleNamespace(config=context), "stamp": "PUBLIC_CONTROL_ONLY",
                             "consumed": {"oid": "3" * 40}})


def awk(state, head, tree):
    return ACTUAL_RUN(["awk", "-F|", "-v", "e=G0002", "-v", "b=manual-resume",
                       "-v", "h=" + head, "-v", "t=" + tree, original_predicate()],
                      input=state.encode(), capture_output=True)


class RegressionControls(unittest.TestCase):
    def test_g0002_selected_row_satisfies_unchanged_owner(self):
        episode = fixture("epoch-row")
        head = git(episode.subject, "rev-parse", "HEAD").decode().strip()
        tree = git(episode.subject, "rev-parse", "HEAD^{tree}").decode().strip()
        context = {"baseline": head, "baseline_tree": tree}
        state = "Current epoch: G0002\n| Next action | apply the authorized pending effect |\n" + current_row(context)
        result = awk(state, head, tree)
        (episode.evidence / "actual-owner-predicate.json").write_text(json.dumps({
            "scope": "PUBLIC_STATIC_OWNER_PREDICATE_ONLY", "head": head, "tree": tree,
            "predicate": original_predicate(), "state": state, "returncode": result.returncode,
            "stdout_hex": result.stdout.hex(), "stderr_hex": result.stderr.hex()}, indent=2) + "\n")
        self.assertEqual(result.returncode, 0, "actual selected G0002 row fails unchanged original AWK")
        self.assertEqual(result.stdout, b"apply the authorized pending effect\n")
        self.assertEqual(awk(state, "4" * 40, tree).returncode, 1, "wrong subject HEAD was admitted")
        self.assertEqual(awk(state, head, "5" * 40).returncode, 1, "wrong subject tree was admitted")

    def test_live_subject_identity_rejects_tree_drift(self):
        episode = fixture("identity-readback")
        self.assertTrue(hasattr(episode, "subject_identity"), "actual HEAD/tree receiver is absent")
        expected = {"head": git(episode.subject, "rev-parse", "HEAD").decode().strip(),
                    "tree": git(episode.subject, "rev-parse", "HEAD^{tree}").decode().strip()}
        self.assertEqual(episode.subject_identity(expected), expected)
        with self.assertRaisesRegex(RuntimeError, "SUBJECT_HEAD_OR_TREE_DRIFT"):
            episode.subject_identity({"head": expected["head"], "tree": "6" * 40})

    def test_timeout_retains_partial_binary_streams_and_unknown_effect(self):
        episode = fixture("timeout")
        target = episode.subject / M.TARGET
        transaction = episode.subject / ".IMPLEMENTAUDIT/runs/public-control-AbCdEf/mutation-transactions/public-test"
        script = ("import os,sys,time;from pathlib import Path;"
                  "p=Path(sys.argv[1]);q=Path(sys.argv[2]);q.mkdir(parents=True);"
                  "(q/'PUBLIC_TEST_ONLY.json').write_text('{\\\"test_only\\\":true}');"
                  "p.write_bytes(b'public partial effect\\n');"
                  "os.write(1,b'public stdout\\x00\\xff');os.write(2,b'public stderr\\x00\\xfe');time.sleep(30)")
        def short_run(*args, **kwargs):
            kwargs["timeout"] = 1
            return ACTUAL_RUN(*args, **kwargs)
        with patch.object(M.subprocess, "run", side_effect=short_run):
            with self.assertRaises(subprocess.TimeoutExpired):
                episode.command([sys.executable, "-c", script, str(target), str(transaction)])
        self.assertEqual(target.read_bytes(), b"public partial effect\n")
        self.assertTrue((transaction / "PUBLIC_TEST_ONLY.json").exists())
        stdout = episode.evidence / "captures/public-control-01.stdout"
        stderr = episode.evidence / "captures/public-control-01.stderr"
        self.assertTrue(stdout.exists(), "real TimeoutExpired partial stdout was not retained")
        self.assertTrue(stderr.exists(), "real TimeoutExpired partial stderr was not retained")
        self.assertEqual(stdout.read_bytes(), b"public stdout\x00\xff")
        self.assertEqual(stderr.read_bytes(), b"public stderr\x00\xfe")
        record = json.loads((episode.evidence / "captures/public-control-01.json").read_text())
        self.assertEqual(record["command_outcome"], "TIMEOUT")
        self.assertEqual(record["effect_outcome"], "UNKNOWN")
        self.assertEqual(record["stdout_completeness"], "PARTIAL_OR_UNKNOWN")
        self.assertIsNone(record["returncode"])
        self.assertFalse(record["automatic_replay"])

    def test_nonzero_partial_effect_and_git_objects_survive_finalization(self):
        episode = fixture("nonzero")
        target = episode.subject / M.TARGET
        run = episode.subject / ".IMPLEMENTAUDIT/runs/public-control-QwErTy"
        script = ("import sys;from pathlib import Path;p=Path(sys.argv[1]);r=Path(sys.argv[2]);"
                  "(r/'mutation-transactions/public-test').mkdir(parents=True);"
                  "(r/'STATE.md').write_text('PUBLIC TEST ONLY: no actual controller\\n');"
                  "(r/'mutation-transactions/public-test/journal.json').write_text('{\\\"test_only\\\":true}');"
                  "p.write_bytes(b'public nonzero partial effect\\n');sys.stderr.write('public failure\\n');sys.exit(9)")
        with self.assertRaisesRegex(RuntimeError, "COMMAND_REFUSED"):
            episode.command([sys.executable, "-c", script, str(target), str(run)])
        oid = git(episode.subject, "hash-object", "-w", "--stdin", data=b"unreferenced public object\n").decode().strip()
        self.assertTrue(hasattr(M, "retain_surviving_evidence"), "always-run survivor recorder is absent")
        out = M.retain_surviving_evidence(episode.work)
        report = json.loads((out / "RETENTION.json").read_text())
        target_row = next(r for r in report["filesystem"] if r["path"] == "subject/" + M.TARGET)
        self.assertEqual((out / target_row["body_path"]).read_bytes(), b"public nonzero partial effect\n")
        transaction_row = next(r for r in report["filesystem"] if r["path"].endswith("mutation-transactions/public-test/journal.json"))
        self.assertEqual((out / transaction_row["body_path"]).read_bytes(), b'{"test_only":true}')
        object_row = next(r for r in report["git_objects"] if r["oid"] == oid)
        self.assertEqual((out / object_row["body_path"]).read_bytes(), b"unreferenced public object\n")
        self.assertEqual(report["authority"], "NONE")
        self.assertEqual(report["original_award_delta"], [])
        self.assertFalse(report["requires_currentness"])

    def test_missing_state_and_symlink_are_explicit_without_following(self):
        episode = fixture("unavailable")
        outside = episode.work / "PUBLIC_OUTSIDE_SENTINEL.txt"
        outside.write_bytes(b"PUBLIC_OUTSIDE_MUST_NOT_BE_FOLLOWED\n")
        target = episode.subject / M.TARGET
        target.unlink(); target.symlink_to(outside)
        (episode.subject / "input/preimage.json").unlink()
        self.assertTrue(hasattr(M, "retain_surviving_evidence"), "failure-tolerant recorder is absent")
        out = M.retain_surviving_evidence(episode.work)
        report = json.loads((out / "RETENTION.json").read_text())
        target_row = next(r for r in report["filesystem"] if r["path"] == "subject/" + M.TARGET)
        self.assertEqual(target_row["kind"], "symlink")
        self.assertEqual(target_row["body_status"], "UNAVAILABLE_SYMLINK_NOT_FOLLOWED")
        missing = next(r for r in report["filesystem"] if r["path"] == "subject/input/preimage.json")
        self.assertEqual(missing["kind"], "absent_at_observation")
        self.assertEqual(missing["historical_effect"], "UNKNOWN")
        self.assertTrue(all(b"PUBLIC_OUTSIDE_MUST_NOT_BE_FOLLOWED" not in f.read_bytes()
                            for f in (out / "bodies").glob("*") if f.is_file()))

    def test_workflow_retains_survivors_before_always_upload(self):
        import yaml
        workflow = yaml.load(Path(ARGS.workflow).read_text(), Loader=yaml.BaseLoader)
        steps = workflow["jobs"]["original-p04"]["steps"]
        matches = [(i, row) for i, row in enumerate(steps) if "retain-surviving-evidence" in row.get("run", "")]
        self.assertEqual(len(matches), 1, "one explicit survivor finalizer is required")
        index, row = matches[0]
        self.assertEqual(row.get("if"), "always()")
        self.assertLess(index, len(steps) - 1)
        self.assertEqual(steps[-1].get("if"), "always()")
        self.assertIn("dg17-p04-original-survivors", steps[-1]["with"]["path"])


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(RegressionControls)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    (ROOT / "CONTROL_RESULT.json").write_text(json.dumps({"tests_run": result.testsRun,
        "failures": len(result.failures), "errors": len(result.errors), "successful": result.wasSuccessful(),
        "scope": "PUBLIC_DISPOSABLE_HARNESS_CONTROLS_ONLY", "original_controller_execution": False,
        "hosted_execution": False, "provider_effects": False, "original_awards": []}, indent=2) + "\n")
    raise SystemExit(0 if result.wasSuccessful() else 1)
