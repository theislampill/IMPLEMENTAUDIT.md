# Independent v2 review — original DG17 P04 hosted proposal

**Disposition: READY as a bounded source-readiness recommendation.** The two blocking v1 findings are satisfied by this exact v2 revision. I found no remaining source blocker in the reviewed delta. This opinion returns findings to Root; it issues no authorization, controller transition, provider action, original acceptance award or closure.

The prior original-applicability judgment is preserved: an actually executed deterministic original-owner episode plus genuine live Root/governor control can establish the complete literal P04 operational conjunction at the recorded ordinary a297 owner layer. This source review and the public regression controls do not establish that hosted outcome.

## Exact revision received

| Item | Verified identity |
|---|---|
| V2 input manifest | `5f3e567d501cb1d003b78efe3b3ec0ce66372feea19a50e98efea92ebd9c1ea2` |
| V2 population | 599 declared members, 694707 bytes; every length/hash matched |
| Driver | `631b2b455121db0bedb529e23b953df3b3aeee80b391fc9299ec82d376b247d1` |
| Workflow | `b6b8c80dd209098031336e8a6d22322ea9f8b85e7aeaccfdf4da80ea175c22df` |
| Source bindings | `d56abbb4c481f2caa02d4f842e8a7f6d46be526a7c457b4f4c88a270cea36ee5`, byte-identical to v1 |
| Original source | Commit `a297957be11feb494c0ec467235794a1e0c54751`, tree `b08dc4ecf4028beeedb579a312eccae23cb5d863` |
| Prior independent report | `f8bebf3f7266f1ad2143b7a2374c3f0e9b600c0fcf422fbe1ea03d49ab0993b8` |
| Prior independent seal | `56e878f3418a9440a1f5448f76d273edb09c11377149fc721500801a5154152e` |

All 24 v1 members and all four prior review members remain unchanged. I independently regenerated the four-file textual delta and matched it exactly to `V1_TO_V2.patch`. The new driver parses, the 20 episode stages retain their order with the new observational finalizer appended, and the workflow still has one job, the exact branch trigger and contents-read-only permission. The issuance key sets and final source hashes match the live driver and workflow. `STATIC_CHECKS.json` records these checks and the full v2 member identities.

## Finding dispositions

### P04-R1 — satisfied at source

The driver now reads both actual subject HEAD and `HEAD^{tree}` through `subject_identity()` (`operate.py:403–411`). Preparation retains `SUBJECT_BASELINE.json` and stores both in context (`481–507`). The actual stale request includes a verified subject identity (`554`); re-anchor rereads and compares the live pair before writing (`615`); final receiving compares it again (`642`).

`reanchor_epoch_row()` writes both identities into the selected G0002 Repo identity cell (`106–109`). It uses the disposable subject's tree, not the original product tree. The original `claim-run.sh` predicate is unchanged.

The independently executed public control used a real disposable Git subject and the unchanged original AWK predicate. The corrected row passed; a wrong HEAD and a wrong tree each refused. A separate live-readback control also refused a deliberately wrong expected tree. These are meaningful harness/predicate controls, not an original controller or receipt execution.

### P04-R2 — satisfied for the bounded supported failure paths

`capture_command()` now writes an intent before dispatch and preserves the actual returned streams, or the exact binary partial streams supplied by a real `TimeoutExpired` (`operate.py:112–156`). Timeout records have a null return code, `effect_outcome: UNKNOWN`, explicit partial/unavailable stream completeness and no automatic replay. Descendant termination is not invented. A normal nonzero return retains its complete raw output before the caller raises.

The workflow now runs `retain-surviving-evidence` with `if: always()` before an also-unconditional final upload (`workflow:73–87`). The action is selected before constructing an Episode (`operate.py:799`), so it does not require a valid context file or receipt. Its implementation (`159–373`) calls no continuity or mutation helper and writes only a separate evidence directory. It observes surviving target/input and run-root/transaction bodies, physical identities, local Git HEAD/tree/refs/status and object bodies, including unreferenced objects. Missing, unsafe, unreadable, changed or limit-exceeding evidence receives an explicit unavailable outcome. The final upload includes both evidence populations.

The independent public controls observed a real timed-out child that had already changed a public file and emitted NUL/non-UTF8 output. Both partial streams survived with UNKNOWN effect status. A separate exit-9 child left a public partial effect and transaction-shaped file; the finalizer retained their actual bytes and an unreferenced public Git object. Missing state and a symlink were recorded without treating absence as proof of no historical effect or following the symlink to its public sentinel.

The finalizer expressly does not claim atomic capture, quiescence, currentness or acceptance. Its bounded retention may be incomplete, and host loss/cancellation can prevent even an always-run step. Those remain honest evidence-availability limits, not a reason to fabricate a result or replay an uncertain operation. Root must receive both artifacts and retain any such limits in the eventual disposition.

### P04-O1 — documentary correction received

The new phase names the actual outer workflow commands, their combined stdout/stderr log files, full coverage and non-textual acceptance (`operate.py:740–746`). The driver separately retains the exact native argv and raw streams required for original receiving. The workflow implements those redirections.

The unchanged phase validator's retained final run returned 0, `validate-phase: ok`, with empty stderr; its record is bound to the final driver. I verified the raw stream hashes. The earlier v1 warnings and v2 split-capture RED remain retained. A timeout's explicitly partial captures cannot be relabeled as successful full-capture acceptance.

### P04-O2 — external authority boundary preserved

The driver still cannot authenticate Root from an issuer string or receipt prefix alone. `ROOT_OPERATOR.md` retains the requirement for genuine current Root authority, the actual independent report/manifest binding, exact provider intent/readback and the required parent/tree/change scopes. Initial authorization and the live re-anchor decision remain UNISSUED. No reviewer continuity or authority is inherited from Root.

## Actual independent verification

I executed the unchanged six-test public harness oracle once against the exact final v2 driver and workflow, under this review directory. **Six tests passed; zero failures and zero errors.** The source test digest was `fd64989df18d172a6727adc0bb26476a54bf52fe3c627363ebe7d2b53ad67048`, matching the retained author v1 RED and final v2 GREEN. Raw independent stdout/stderr, the complete invocation, source hashes and actual outcome are in `PUBLIC_CONTROL_RESULT.json` and the public-control evidence population.

The author retained six actual v1 failures and final v2 success under the same oracle; I verified the recorded raw stream identities and source bindings rather than treating the report prose as execution. No additional original controller, host, provider, original mutation-helper operation, model-policy actor or Root decision was performed by this review. The public fixtures are explicitly test-only and assert no original claim, grant or receipt.

## Original applicability and remaining actual receiving

The v1 applicability basis remains unchanged: original issue #211 P04 requires the actual L2 custody/currentness mismatch and the refusal, preserved mismatch and re-anchor route (`552`). L4 allows mechanical detection and deterministic safe dispositions (`340–346`). The single actual pending task and unchanged positive continuation discriminate the currentness refusal from an unrelated permanent authorization denial.

A genuine live Root procedural control can supply the actual governor route for this mechanically specified episode. No claim about independent model judgment follows. If a later claim instead treats model recognition or route selection as the measured behavior, the conditional model-facing rules (`588–595`) apply; the current packet is not that experiment. Structural controls also cannot establish real host activation (`541–545`).

Root can use this READY source opinion for its next authorized prelaunch work. Actual execution still needs genuine initial Root authorization; exact sole-parent-a297/four-addition publication and readback; real qualifying host setup and source-owned initialization; actual G0001 and manual-resume invalidation; the typed refusal plus empty actual effect set and unchanged subject; actual Root receipt of that artifact and narrowly bound live control within the hold; separate canonical reads and actual G0002 resume/verify/require; the identical pending command's real COMMITTED return; final scope and survivor evidence; and nonauthor original receiving. A finished workflow upload or author observation is not an acceptance decision.

The historical a0f134 effect remains UNKNOWN_NO_REPLAY. Prior installed-owner P04 evidence remains at its original identity. V1's GAP, its REDs, v2's intermediate RED and all actual future failure/unavailable outcomes remain preserved. No mutation-family, other-case, terminal-clause, native Stop/session, whole-DG17, source-currentness, integration, release or closure credit is issued here; all denominators remain unchanged.

**Returned recommendation: READY at the exact v2 source layer; original P04 execution and award remain unperformed and Root-owned.**
