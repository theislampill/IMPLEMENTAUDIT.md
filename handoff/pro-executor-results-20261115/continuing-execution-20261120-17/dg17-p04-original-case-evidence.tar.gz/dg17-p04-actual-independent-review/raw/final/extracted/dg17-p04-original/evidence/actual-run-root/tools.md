# Tools

{
  "bash": "/usr/bin/bash",
  "git": "/usr/bin/git",
  "python": "/usr/bin/python3",
  "claim_owner": "/home/runner/work/IMPLEMENTAUDIT.md/IMPLEMENTAUDIT.md/skills/implementaudit/scripts/claim-run.sh"
}

Only the declared owner operations and bounded receiving task are authorized.
