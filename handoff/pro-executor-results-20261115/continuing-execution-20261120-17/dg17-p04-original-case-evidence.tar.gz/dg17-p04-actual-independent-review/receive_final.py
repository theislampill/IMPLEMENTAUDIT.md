#!/usr/bin/env python3
"""Read retained original P04 evidence; write only this reviewer directory.

This does not invoke any original helper, controller, host, or provider. The
checks below observe bytes already received. No command is replayed.
"""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib
import json
import shutil
import zipfile

BASE = Path('/workspace/scratch/530bc07ea12b')
OUT = BASE / 'dg17-p04-actual-independent-review'
FINAL = BASE / 'p04-original-actual/final'
STALE = BASE / 'p04-original-actual/stale/extracted'
P = FINAL / 'extracted/dg17-p04-original/evidence'
S = FINAL / 'extracted/dg17-p04-original-survivors'
CONTROL = BASE / 'p04-original-control-publication'
SOURCE = BASE / 'dg17-remaining-original-frontier/p04_source'
checks = {}
details = {}

def h(b): return hashlib.sha256(b).hexdigest()
def j(p): return json.loads(p.read_bytes())
def check(name, value): checks[name] = bool(value)
def stamp(t): return datetime.fromisoformat(t.replace('Z', '+00:00'))
def git_oid(kind, body): return hashlib.sha1((kind+' '+str(len(body))+'\0').encode()+body).hexdigest()
def unwrap(x):
    if 'structuredContent' in x: x=x['structuredContent']
    if isinstance(x,dict) and isinstance(x.get('content'),str): return json.loads(x['content'])
    return x
def cp(src, dst):
    dst.parent.mkdir(parents=True,exist_ok=True)
    if dst.exists():
        if src.read_bytes()!=dst.read_bytes(): raise ValueError('refuse to overwrite different retained bytes: '+str(dst))
    else: shutil.copyfile(src,dst)

# Receive exact populations and preserve provider provenance without fetching.
zbytes=(FINAL/'ARTIFACT.zip').read_bytes()
check('final_zip_521899_exact_sha',len(zbytes)==521899 and h(zbytes)=='2f108a9aa2712bdf42596210777a522b27616d1364c3ae381e697d558ebf0b29')
with zipfile.ZipFile(FINAL/'ARTIFACT.zip') as z:
    entries=[i for i in z.infolist() if not i.is_dir()]
    names=[i.filename for i in entries]
    check('zip_names_unique_and_relative',len(set(names))==len(names) and all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts for n in names))
    rows=[]
    for i in entries:
        b=z.read(i)
        rows.append({'path':i.filename,'bytes':len(b),'sha256':h(b),'extracted_exact':(FINAL/'extracted'/i.filename).read_bytes()==b})
    check('all_739_zip_members_exact',len(rows)==739 and sum(r['bytes'] for r in rows)==974638 and all(r['extracted_exact'] for r in rows))
    disk={str(f.relative_to(FINAL/'extracted')) for f in (FINAL/'extracted').rglob('*') if f.is_file()}
    check('final_extraction_population_exact',disk==set(names))
    details['zip_members']=rows
for f in FINAL.rglob('*'):
    if f.is_file(): cp(f,OUT/'raw/final'/f.relative_to(FINAL))
for f in CONTROL.glob('*.json'): cp(f,OUT/'raw/control-publication'/f.name)
for rel in ['skills/implementaudit/scripts/apply-observed-mutation.sh','skills/implementaudit/scripts/claim-run.sh','skills/implementaudit/references/continuity.md']:
    cp(SOURCE/rel,OUT/'raw/source'/rel)
cp(BASE/'dg17-remaining-original-frontier/ISSUE211_BODY.md',OUT/'raw/source/ISSUE211_BODY.md')
for name in ['REPORT.md','FINDINGS.json','SEAL.json']:
    cp(BASE/'dg17-p04-v2-independent-review'/name,OUT/'raw/source-review-v2'/name)
for root,label,count in [(P,'main',636),(S,'survivor',101)]:
    manifest=j(root/'MANIFEST.json')['files']
    listed={r['path'] for r in manifest}
    actual={str(f.relative_to(root)) for f in root.rglob('*') if f.is_file() and f.name!='MANIFEST.json'}
    check(label+'_manifest_population_exact',len(manifest)==count and len(listed)==len(manifest) and listed==actual)
    check(label+'_manifest_all_bytes_exact',all(len((root/r['path']).read_bytes())==r['bytes'] and h((root/r['path']).read_bytes())==r['sha256'] for r in manifest))
stale_files=[f for f in STALE.rglob('*') if f.is_file()]
check('all_248_stale_members_byte_identical',len(stale_files)==248 and all(f.read_bytes()==(P/f.relative_to(STALE)).read_bytes() for f in stale_files))
prior=j(OUT/'STALE_RECEIVING.json')
check('prior_40_stale_checks_pass_and_no_award',len(prior['checks'])==40 and all(prior['checks'].values()) and prior['complete_original_P04_awarded'] is False)
receipt=j(FINAL/'RECEIPT.json')
check('actual_download_single_get_no_retry',receipt['actual_http_status']==200 and receipt['automatic_retry'] is False and receipt['network_body_gets_selected']==1 and receipt['artifact_id']==14599022077)
check('job_log_exact',len((FINAL/'ACTUAL_JOB.log').read_bytes())==33546 and h((FINAL/'ACTUAL_JOB.log').read_bytes())=='98ad9048b10d85b22d92f10c31deff77947b3e6c89824069394d0c04f7054a87')

# Every original native invocation is retained with intent and exact raw streams.
records={}
capture_checks=[]
for f in sorted((P/'captures').glob('*.json')):
    if f.name.endswith('.intent.json'): continue
    r=j(f); intent=j(f.with_name(f.stem+'.intent.json'))
    ok=all(r[k]==v for k,v in intent.items())
    for stream in ['stdout','stderr']:
        b=(P/r[stream+'_path']).read_bytes()
        ok=ok and len(b)==r[stream+'_bytes'] and h(b)==r[stream+'_sha256'] and r[stream+'_available'] is True and r[stream+'_completeness']=='COMPLETE'
    ok=ok and r['command_outcome']=='RETURNED' and r['automatic_replay'] is False and r['exception_type'] is None and stamp(r['completed_at'])>=stamp(r['started_at'])
    capture_checks.append({'capture':f.name,'sha256':h(f.read_bytes()),'returncode':r['returncode'],'complete_and_exact':ok})
    records[f.stem]=r
def out(name): return (P/records[name]['stdout_path']).read_bytes()
check('143_native_captures_complete_exact',len(records)==143 and all(x['complete_and_exact'] for x in capture_checks))
nonzero=[(n,r['returncode']) for n,r in records.items() if r['returncode']!=0]
check('only_stale_77_and_absent_branch_polls_2',all((n=='stale-attempt-01-actual-mutation-refusal' and rc==77) or (n.startswith('wait-root-control-') and rc==2 and 'ls-remote' in records[n]['argv']) for n,rc in nonzero))
details['capture_checks']=capture_checks
details['nonzero_native_returns']=[{'capture':n,'returncode':rc} for n,rc in nonzero]
ctx=j(P/'ACTUAL_CONTEXT.json'); request=j(P/'STALE_REQUEST.json'); cons=j(P/'CONTROL_CONSUMPTION.json')
run=unwrap(j(FINAL/'ACTUAL_FINAL_RUN.json')); jobs=unwrap(j(FINAL/'ACTUAL_FINAL_JOBS.json'))['jobs']; artifacts=unwrap(j(FINAL/'ACTUAL_ARTIFACTS.json'))['artifacts']
check('same_run_attempt_workflow_completed_success',run['id']==ctx['run_id']==44667611776 and run['run_attempt']==ctx['run_attempt']==1 and run['head_sha']==ctx['workflow_commit']=='8851761ccb0876eba0a927f42959089ff6c432cd' and run['status']=='completed' and run['conclusion']=='success')
job=jobs[0]
check('same_actual_job_all_27_steps_success',len(jobs)==1 and job['id']==136060649329 and job['run_id']==44667611776 and job['status']=='completed' and job['conclusion']=='success' and len(job['steps'])==27 and all(x['status']=='completed' and x['conclusion']=='success' for x in job['steps']))
check('both_provider_artifacts_same_run_and_head',len(artifacts)==2 and {a['id'] for a in artifacts}=={14599135535,14599022077} and all(a['workflow_run']['id']==44667611776 and a['workflow_run']['head_sha']==ctx['workflow_commit'] for a in artifacts))
check('provider_artifact_sizes_digests_exact',all(a['size_in_bytes']==(128349 if a['id']==14599135535 else 521899) and a['digest']=='sha256:'+('7dab58b74901edaf5e0816da8dd6148cd194ae3c7f01b5fc722f4595b434be21' if a['id']==14599135535 else h(zbytes)) for a in artifacts))

# Root issuance and actual provider custody, then host consumption.
decision_bytes=(CONTROL/'ROOT_REANCHOR_DECISION.json').read_bytes(); decision=json.loads(decision_bytes)
issuance=j(CONTROL/'ROOT_ISSUANCE.json'); tool=j(CONTROL/'ACTUAL_ISSUANCE_TOOL_RETURN.json'); complete=j(CONTROL/'PUBLICATION_COMPLETE.json')
check('actual_root_issuance_tool_success',tool['exit_code']==0 and tool['chunk_id']=='fa243c' and json.loads(tool['output'])['decision_sha256']==h(decision_bytes))
check('root_g0012_actual_currentness',issuance['native_currentness']['returncode']==0 and issuance['native_currentness']['stderr']=='' and issuance['native_currentness']['stdout'].strip()=='refs/implementaudit/continuity-receipts/dg16-dg18-recovery-20261119-b/G0012@823683fcfb2c7734aebc04d0b25e2b681ecf564a')
check('root_received_exact_55_stale_captures',issuance['verified_capture_count']==55 and len(issuance['captures'])==55 and all(h((P/'captures'/r['capture']).read_bytes())==r['sha256'] for r in issuance['captures']))
check('decision_exact_published_host_body',len(decision_bytes)==1614 and h(decision_bytes)=='76fce9a8d2dda4d67616c979a214d232fd13ed06c05b0193d61f67b4d451ff06' and git_oid('blob',decision_bytes)=='47626c659afcb390503244b50c79352a437a9e8b' and decision_bytes==(P/'ACTUAL_ROOT_REANCHOR_DECISION.json').read_bytes()==out('wait-root-control-40'))
readbacks={r['value']['key']:r['value']['r'] for r in j(CONTROL/'REF_AND_DECISION_READBACK.json') if r['status']=='fulfilled'}
check('actual_provider_ref_and_decision_exact',len(readbacks)==2 and all(r.get('isError') is False for r in readbacks.values()) and unwrap(readbacks['ref'])['object']['sha']==cons['oid'] and readbacks['decision']['structuredContent']['content'].encode()==decision_bytes)
commit=unwrap(j(CONTROL/'COMMIT_READBACK_ACTUAL.json'))
check('control_commit_exact_sole_parent_tree',commit['sha']==cons['oid']=='3a7a51d861ffe7607ebf18c530301d8cd939d1e6' and [r['sha'] for r in commit['parents']]==[ctx['workflow_commit']] and commit['tree']['sha']=='e82b34aa60a7a30a1a8c3e7dec621226cc454bf7' and git_oid('commit',out('wait-root-control-38'))==cons['oid'])
check('host_verified_control_only_one_file_addition',out('wait-root-control-39')==b'A\thandoff/dg17-p04-original-20261120/ROOT_REANCHOR_DECISION.json\n' and out('wait-root-control-36')==out('wait-root-control-41'))
check('control_publication_receipt_files_exact',all((CONTROL/r['path']).stat().st_size==r['bytes'] and h((CONTROL/r['path']).read_bytes())==r['sha256'] for r in complete['receipt_files']))
check('single_control_creation_no_retry',complete['one_ref_creation'] is True and complete['automatic_retry'] is False and complete['old_leaves_unchanged']==1941 and complete['new_leaves']==1)
remote=j(CONTROL/'PREISSUANCE_ACTUAL_REMOTE_READS.json')
prejobs=unwrap(remote['g12_p04_jobs'])['jobs']
check('preissuance_actual_hold_live',len(prejobs)==1 and prejobs[0]['id']==job['id'] and prejobs[0]['status']=='in_progress' and any(x['status']=='in_progress' and 'Root' in x['name'] for x in prejobs[0]['steps']))
check('preissuance_control_absence_and_failed_read_preserved',remote['g12_p04_control_ref']['isError'] is True and remote['g12_p04_control_ref']['structuredContent']['error_code']=='NOT_FOUND' and remote['g12_p04_job']['isError'] is True)
check('root_decision_after_stale_before_consumption_before_deadline',stamp(request['observed_at'])<stamp(decision['issued_at'])<stamp(cons['consumed_at'])<datetime.fromtimestamp(1795146342,timezone.utc))
check('decision_and_consumption_bind_same_request',decision['request_sha256']==cons['request_sha256']==h((P/'STALE_REQUEST.json').read_bytes()) and cons['decision_sha256']==h(decision_bytes))
details['hold']={'stale_observed_at':request['observed_at'],'root_issued_at':decision['issued_at'],'consumed_at':cons['consumed_at'],'deadline':'2026-11-20T03:45:42+00:00','bound_seconds':1200,'elapsed_stale_to_consumed_seconds':(stamp(cons['consumed_at'])-stamp(request['observed_at'])).total_seconds(),'actual_absent_polls':sum(rc==2 for _,rc in nonzero)}

# Same pending task and separately completed recovery steps.
sequence=['read-resume-state-01','read-resume-roadmap-01','author-reanchor-01','author-reanchor-02','resume-current-01','verify-current-01','require-current-01','apply-current-01-actual-current-mutation','final-receive-01']
check('separate_recovery_steps_completed_in_order',all(records[n]['returncode']==0 for n in sequence) and stamp(cons['consumed_at'])<stamp(records[sequence[0]]['started_at']) and all(stamp(records[a]['completed_at'])<=stamp(records[b]['started_at']) for a,b in zip(sequence,sequence[1:])))
check('resume_separate_reads_exact_preserved_bodies',out('read-resume-state-01')==(P/'before-reanchor/STATE.md').read_bytes() and out('read-resume-roadmap-01')==(P/'before-reanchor/ROADMAP.md').read_bytes())
current_token=(P/'current-receipt.txt').read_bytes()
check('actual_g0002_resumed_verified_required_identically',current_token==out('resume-current-01')==out('verify-current-01')==out('require-current-01')==out('final-receive-05') and current_token.decode().strip().endswith('/G0002@f7e15a8ef03b2cc0475891f33d8c1ec392ac891d'))
objects=j(P/'final-git-objects.json'); native_objects={r['argv'][-1]:out(n) for n,r in records.items() if r['argv'][-3:-1]==['cat-file','blob']}
check('six_final_git_blobs_exact',len(objects)==6 and all(o['oid'] in native_objects and len(native_objects[o['oid']])==o['body_bytes'] and h(native_objects[o['oid']])==o['body_sha256'] and git_oid('blob',native_objects[o['oid']])==o['oid'] for o in objects))
g1=native_objects['c560761d1795f5c9f41ce03ba51334b00c4192ef'].decode().strip().split('\t')
g2=native_objects['f7e15a8ef03b2cc0475891f33d8c1ec392ac891d'].decode().strip().split('\t')
check('g0002_same_controller_claim_subject_pair_next_action',g1[:6]==g2[:6] and g1[11]==g2[11] and g2[1]==ctx['controller'] and g2[3]==ctx['claim_id'] and g2[4:6]==[ctx['baseline'],ctx['baseline_tree']])
check('g0002_new_actual_invalidation_boundary_epoch',g1[8]=='aaff78bf57829dd27ddb9cb496cf72bd4cdd0b6f' and g2[8:11]==['84c6d1e5dc3a6ca24ba17dec5e4f96f67affbd15','manual-resume','G0002'])
check('g0002_actual_canonical_pair_hashes',g2[6:8]==[h((P/'reanchored/STATE.md').read_bytes()),h((P/'reanchored/ROADMAP.md').read_bytes())] and all((P/'reanchored'/n).read_bytes()==(P/'actual-run-root'/n).read_bytes() for n in ['STATE.md','ROADMAP.md']))
state=(P/'reanchored/STATE.md').read_text(); roadmap=(P/'reanchored/ROADMAP.md').read_text()
check('actual_state_preserves_andon_witness_and_route',all(t in state for t in ['Current epoch: G0002',ctx['baseline'],ctx['baseline_tree'],'Class: evidence-mismatch','STALE_CONTINUITY_RECEIPT',h((P/'STALE_REQUEST.json').read_bytes()),cons['oid'],'CONTAIN_AND_REANCHOR_THEN_REVALIDATE_PENDING_EFFECT']) and all(t in roadmap for t in [cons['oid'],'target effect remains unperformed','identical authorized command']))
initial=j(P/'initial-identities.json'); before=j(P/'before-current-apply-identities.json'); after=j(P/'after-current-apply-identities.json')
check('same_unchanged_files_and_absent_transaction_until_current_apply',all(j(P/n)==initial for n in ['before-stale-identities.json','after-stale-identities.json','before-reanchor-authoring-identities.json','before-current-apply-identities.json']) and initial['transaction_exists'] is False)
check('unchanged_input_and_ignore_physical_identities_after_apply',all(after[n]==initial[n] for n in ['input/preimage.json','input/candidate.json','.gitignore']) and after['transaction_exists'] is True)
old=records['stale-attempt-01-actual-mutation-refusal']; new=records['apply-current-01-actual-current-mutation']
check('identical_stale_and_current_argv_cwd_environment',all(old[k]==new[k] for k in ['argv','cwd','environment_keys','environment_scope']))
stale_result=j(P/'ACTUAL_STALE_RESULT.json'); result=j(P/'ACTUAL_CURRENT_MUTATION_RESULT.json')
check('raw_current_stdout_exact_semantics',json.loads(out('apply-current-01-actual-current-mutation'))==result)
check('same_phase_authority_binding_without_scope_expansion',result['authority_binding_sha256']==stale_result['authority_binding_sha256']=='9ec54c93c05c5cd7072b66e65c469f0e7f8cd891ee9d5a036db307faabed0810' and all(result[k]==stale_result[k] for k in ['claim_id','phase','step','operation','source_path','destination_path','candidate_identities']))
check('actual_initial_phase_body_unchanged',h((P/'actual-run-root/phases/phase-1.md').read_bytes())==prior['derived_expected_initial_phase_sha256']=='fd3137a313dff36208c32247000d43a0b0263ca6511dff9a22cd2549abfb9fa3')
check('original_current_command_committed',new['returncode']==0 and result['status']=='COMMITTED' and result['reason_code']=='NONE' and result['residue']==[] and result['transaction_id']==ctx['claim_id']+'-p1-s1')
check('actual_target_after_exact_candidate',after['task/route-map.json']['sha256']=='39fef72684e7ee4abe5cf0970e66a183d31ab6fd15f8b6b8990f0a78b0279868' and after['task/route-map.json']['bytes']==18 and result['post_identities'][0]['identity']['inode']==after['task/route-map.json']['inode'])

# Scope, actual effects, persisted checkpoint and observational cleanup census.
plan=result['planned_effect_set']; actual=result['actual_effect_set']; plans={(r['scope'],r['path']):r for r in plan}
check('25_planned_paths_exact_canonical_digest',len(plan)==25 and h(json.dumps(plan,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())==result['planned_effect_set_sha256']=='11e612f9e5ada3ff7e44cb718fa55bb948cb52fb3e39eb9b5c64a3ea0a16dbde')
check('all_75_actual_effects_allowed_applied_sequential',len(actual)==75 and [r['sequence'] for r in actual]==list(range(1,76)) and all(r['outcome']=='applied' and (r['scope'],r['path']) in plans and r['effect'] in plans[(r['scope'],r['path'])]['allowed_effects'] for r in actual))
check('effect_namespace_bounded',all(r['scope']=='repo' and (r['path'] in ['task','task/route-map.json','.IMPLEMENTAUDIT'] or r['path'].startswith(ctx['run_root']) or r['path'].startswith('.IMPLEMENTAUDIT/.r36-locks')) for r in actual))
tx=P/'actual-run-root/mutation-transactions'/result['transaction_id']; durable=j(tx/'result.json'); authority=j(tx/'authority.json')
check('durable_result_69_prefix_plus_six_live_publication_effects',all(durable[k]==result[k] for k in result if k!='actual_effect_set') and durable['actual_effect_set']==actual[:69] and [(r['effect'],r['path'].rsplit('/',1)[-1]) for r in actual[69:]]==[('create','result.tmp'),('write','result.tmp'),('fsync','result.tmp'),('replace','result.tmp'),('replace','result.json'),('fsync',result['transaction_id'])])
check('transaction_authority_exact_same_claim_grant_plan',authority['claim']['claim_id']==ctx['claim_id'] and authority['phase']['authority_binding_sha256']==result['authority_binding_sha256'] and authority['planned_effect_set']==plan and authority['planned_effect_set_sha256']==result['planned_effect_set_sha256'])
ret=j(S/'RETENTION.json'); fs={r['path']:r for r in ret['filesystem']}
check('survivor_no_unavailable_or_limit',len(ret['filesystem'])==34 and len(ret['git_observations'])==20 and len(ret['git_objects'])==14 and ret['unavailable']==[])
body_exact=[]
for r in ret['filesystem']:
    if r['kind']=='regular':
        b=(S/r['body_path']).read_bytes()
        body_exact.append(r['body_status']=='CAPTURED_STABLE_FILE' and r['complete_body_at_observation'] is True and len(b)==r['captured_bytes'] and h(b)==r['captured_sha256'] and all(r[k]==r['after'][k] for k in r['after']))
check('all_surviving_regular_files_stable_complete_exact',all(body_exact))
check('survivor_raw_subject_bodies_exact',all((S/fs['subject/'+path]['body_path']).read_bytes()==body for path,body in [('task/route-map.json',b'{"route":"green"}\n'),('input/candidate.json',b'{"route":"green"}\n'),('input/preimage.json',b'{"route":"blue"}\n')]))
run_body_prefix='subject/'+ctx['run_root']+'/'
check('both_run_root_populations_exact',all((S/fs[run_body_prefix+str(f.relative_to(P/'actual-run-root'))]['body_path']).read_bytes()==f.read_bytes() for f in (P/'actual-run-root').rglob('*') if f.is_file()))
check('active_locks_absent_and_only_namespace_gate_survives',fs['subject/.IMPLEMENTAUDIT/.r36-locks']['observed_child_count']==1 and [name for name in fs if name.startswith('subject/.IMPLEMENTAUDIT/.r36-locks/')]==['subject/.IMPLEMENTAUDIT/.r36-locks/namespace.gate'])
check('transaction_cleanup_exact_durable_receipts_only',set(f.name for f in tx.iterdir())=={'authority.json','result.json','released-locks'} and fs[run_body_prefix+'mutation-transactions/'+result['transaction_id']]['observed_child_count']==3 and len(list((tx/'released-locks').rglob('owner')))==2)
check('survivor_git_observations_all_returned_zero',all(r['returncode']==0 for r in ret['git_observations']))
obj={r['oid']:(r,(S/r['body_path']).read_bytes()) for r in ret['git_objects']}
check('all_14_git_objects_exact_type_size_sha1_sha256',all(r['status']=='CAPTURED_EXACT_OBJECT' and len(b)==r['captured_bytes']==r['declared_bytes'] and h(b)==r['captured_sha256'] and git_oid(r['type'],b)==oid for oid,(r,b) in obj.items()))
check('all_six_final_refs_and_old_invalidation_in_survivor',all(o['oid'] in obj and obj[o['oid']][1]==native_objects[o['oid']] for o in objects) and 'aaff78bf57829dd27ddb9cb496cf72bd4cdd0b6f' in obj)
check('same_subject_head_tree_in_survivor_and_final',out('author-reanchor-01')==out('final-receive-01')==(S/'captures/git-head.stdout').read_bytes()==(ctx['baseline']+'\n').encode() and out('author-reanchor-02')==out('final-receive-02')==(S/'captures/git-tree.stdout').read_bytes()==(ctx['baseline_tree']+'\n').encode())
check('only_declared_target_modified_no_untracked',out('final-receive-03')==b'task/route-map.json\n' and out('final-receive-04')==b'' and (S/'captures/git-status.stdout').read_bytes()==b' M task/route-map.json\n')
def tree_leaves(oid,prefix=''):
    kind,body=obj[oid]; assert kind['type']=='tree'
    result={}; pos=0
    while pos<len(body):
        end=body.index(b'\0',pos); mode,name=body[pos:end].split(b' ',1); child=body[end+1:end+21].hex(); pos=end+21
        path=prefix+name.decode()
        if mode==b'40000': result.update(tree_leaves(child,path+'/'))
        else: result[path]=(mode.decode(),child)
    return result
leaves=tree_leaves(ctx['baseline_tree']); index={}
for line in (S/'captures/git-tracked.stdout').read_text().splitlines():
    meta,name=line.split('\t'); mode,oid,stage=meta.split(); index[name]=(mode,oid); assert stage=='0'
check('survivor_index_exact_baseline_tree',index==leaves and set(leaves)=={'.gitignore','input/candidate.json','input/preimage.json','task/route-map.json'})

# Exact unchanged source repeated at the end, distinct from host additions.
bindings=j(P/'SOURCE_BINDINGS.json')
actual_source={r['argv'][-1].split(':',1)[1]:out(n).decode().strip() for n,r in records.items() if n.startswith('final-receive-') and r['argv'][-1].startswith(bindings['source_commit']+':')}
check('all_23_final_source_blobs_exact',len(actual_source)==23 and all(actual_source[r['path']]==r['git_blob'] for r in bindings['files']))
check('final_source_tree_workflow_clean_four_additions',out('final-receive-29').decode().strip()==ctx['workflow_commit'] and out('final-receive-30').decode().strip()==bindings['source_tree']=='b08dc4ecf4028beeedb579a312eccae23cb5d863' and out('final-receive-32')==b'' and out('final-receive-31').splitlines()==[b'A\t.github/workflows/dg17-p04-original-host.yml',b'A\thandoff/dg17-p04-original-20261120/ROOT_AUTHORIZATION.json',b'A\thandoff/dg17-p04-original-20261120/SOURCE_BINDINGS.json',b'A\thandoff/dg17-p04-original-20261120/operate.py'])
check('retained_mutation_source_exact_original_blob',git_oid('blob',(SOURCE/'skills/implementaudit/scripts/apply-observed-mutation.sh').read_bytes())=='a5f6c6c754abd8d884968d4eaa8f08744925d925')
details['current_receipt_fields']=g2
details['job_steps']=job['steps']
details['effect_counts']={'planned_paths':len(plan),'live_applied_effects':len(actual),'durable_checkpoint_completed_effects':len(durable['actual_effect_set']),'live_publication_suffix':actual[69:]}
details['survivor_summary']={k:ret[k] for k in ['authority','atomic_snapshot','quiescence','historical_effect_outcome','unavailable','retained_body_bytes','retention_limits','started_at','completed_at']}
details['same_subject']={k:ctx[k] for k in ['controller','claim_id','run_root','baseline','baseline_tree','workflow_commit','run_id','run_attempt']}
record={'schema':'dg17.p04.independent-actual-final-receiving.v1','reviewer':'/root/dg17_p04_independent_review','recorded_at':datetime.now(timezone.utc).isoformat(),'authority':'NONE','reviewer_original_commands_executed':False,'reviewer_provider_actions':False,'original_case_award_issued':False,'checks':checks,'all_checks_pass':all(checks.values()),'details':details}
(OUT/'FINAL_RECEIVING.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps({'checks':len(checks),'passed':sum(checks.values()),'failed':[k for k,v in checks.items() if not v],'record_sha256':h((OUT/'FINAL_RECEIVING.json').read_bytes()),'native_captures':len(records),'survivor_regular_bodies':len(body_exact),'hold':details['hold']},indent=2))
