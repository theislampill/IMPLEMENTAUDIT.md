"""Read-only source controls; never call probe.main or any native capture."""
import hashlib
import importlib.util
from pathlib import Path
import sys
import unittest

SOURCE=Path(sys.argv.pop(1)).resolve()
RECEIPT=Path('/workspace/scratch/530bc07ea12b/g132-native-capture-probe/one-time-output/PROBE_RESULT.json')
PIN={'bytes':3979,'sha256':'3bb4677e69543163727a2130e40286d8650eb9f9739f57735e3e3f024759de1b'}
spec=importlib.util.spec_from_file_location('source_only_receipt_role',SOURCE)
M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)


class ReceiptRole(unittest.TestCase):
    def read_prior(self,digest):
        # This is exactly the old production prior-seal call when the successor
        # routing function is absent. It never enters main/capture.
        if hasattr(M,'read_prior_seal'):return M.read_prior_seal(str(RECEIPT),digest)
        return M.read_bound(str(RECEIPT),{'sha256':digest})

    def test_exact_public0600_receipt_is_received_without_mode_change(self):
        before=RECEIPT.stat();observed=None
        try:
            raw,row=self.read_prior(PIN['sha256'])
            observed=(len(raw),hashlib.sha256(raw).hexdigest())
        except ValueError as exc:observed=('REFUSED',str(exc))
        self.assertEqual(observed,(3979,PIN['sha256']))
        self.assertEqual(RECEIPT.stat(),before)

    def test_generic_source_reader_still_refuses0600(self):
        with self.assertRaisesRegex(ValueError,'PROBE_SOURCE_MODE'):
            M.read_bound(RECEIPT,PIN)

    def test_wrong_historical_digest_is_refused(self):
        with self.assertRaises(ValueError):self.read_prior('0'*64)


if __name__=='__main__':unittest.main(verbosity=2)
