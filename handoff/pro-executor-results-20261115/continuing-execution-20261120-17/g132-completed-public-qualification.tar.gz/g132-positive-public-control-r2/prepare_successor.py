"""Pure source-packet generation; never invokes probe.main or native capture."""
import ast
import copy
import difflib
import hashlib
import json
import os
from pathlib import Path
import shlex

HERE = Path(__file__).resolve().parent
OLD = Path('/workspace/scratch/530bc07ea12b/g132-original-operation-readiness/positive-public-control')
ACTUAL = Path('/workspace/scratch/530bc07ea12b/g132-positive-public-actual')
REVIEW = Path('/workspace/scratch/530bc07ea12b/g132-positive-independent-review/actual-refusal/MANIFEST.json')


def pin(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def write_new(name, raw):
    with (HERE / name).open('xb') as f:
        f.write(raw)


def json_new(name, obj):
    write_new(name, (json.dumps(obj, indent=2, sort_keys=True) + '\n').encode())


old_raw = (OLD / 'probe.py').read_bytes()
assert pin(old_raw) == {'bytes': 26159, 'sha256': 'c66e70e7b1c04041b01a85c5ca3ba479d15f476abd0d6fea5d501d3736d3c1ca'}
new_raw = (HERE / 'probe.py').read_bytes()
old_ast = ast.parse(old_raw)
new_ast = ast.parse(new_raw)
old_functions = {n.name: n for n in old_ast.body if isinstance(n, ast.FunctionDef)}
new_functions = {n.name: n for n in new_ast.body if isinstance(n, ast.FunctionDef)}
assert set(new_functions) - set(old_functions) == {'read_historical_public_receipt', 'read_prior_seal'}
unchanged = sorted(set(old_functions) - {'expected_selection', 'main'})
for name in unchanged:
    assert ast.get_source_segment(old_raw.decode(), old_functions[name]) == ast.get_source_segment(new_raw.decode(), new_functions[name]), name


class RestorePriorReader(ast.NodeTransformer):
    def visit_Call(self, node):
        self.generic_visit(node)
        if isinstance(node.func, ast.Name) and node.func.id == 'read_prior_seal':
            assert len(node.args) == 2 and not node.keywords
            node.func.id = 'read_bound'
            node.args[1] = ast.Dict(keys=[ast.Constant(value='sha256')], values=[node.args[1]])
        return node


normalized_main = RestorePriorReader().visit(copy.deepcopy(new_functions['main']))
assert ast.dump(normalized_main) == ast.dump(old_functions['main'])
namespace = {'__name__': 'g132_positive_r2_preparation_only', '__file__': str(HERE / 'probe.py')}
exec(compile(new_raw, str(HERE / 'probe.py'), 'exec'), namespace)
source_pin = pin(new_raw)
selection = namespace['expected_selection'](source_pin)
json_new('PREPARED_SELECTION.json', selection)
selection_pin = pin((HERE / 'PREPARED_SELECTION.json').read_bytes())

old_invocation = json.loads((OLD / 'INVOCATION.json').read_bytes())
invocation = copy.deepcopy(old_invocation)
bootstrap = old_invocation['argv'][-1]
changes = [
    (str(OLD / 'probe.py'), str(HERE / 'probe.py'), 2),
    ("{'bytes': 26159, 'sha256': 'c66e70e7b1c04041b01a85c5ca3ba479d15f476abd0d6fea5d501d3736d3c1ca'}", repr(source_pin), 1),
    ('498516da3dbfae8c118057d30e841dab587c24e59f259986ba19f56c28f60697', selection_pin['sha256'], 1),
]
for before, after, count in changes:
    assert bootstrap.count(before) == count, (before, count)
    bootstrap = bootstrap.replace(before, after)
compile(bootstrap, 'prepared-r2-bootstrap', 'exec')
invocation['argv'][-1] = bootstrap
invocation['bootstrap'] = pin(bootstrap.encode())
invocation['shell_command'] = shlex.join(invocation['argv'])
invocation['source'] = dict(path=str(HERE / 'probe.py'), **source_pin)
invocation['selection'] = dict(path=str(HERE / 'PREPARED_SELECTION.json'), **selection_pin)
invocation['working_directory'] = str(HERE)
invocation['output_directory'] = str(namespace['OUTPUT'])
invocation['distinct_from_refused_positive_attempt'] = True
invocation['root_native_invocation_issued'] = False
invocation['predecessor_attempt'] = {
    'identity': 'cd895e/1',
    'state': 'ENTRY_REFUSED_OR_PARTIAL_RECONCILE_OUTPUT_NO_RETRY',
    'actual_tool_return': dict(path=str(ACTUAL / 'ACTUAL_INVOCATION_TOOL_RETURN.json'), **pin((ACTUAL / 'ACTUAL_INVOCATION_TOOL_RETURN.json').read_bytes())),
    'consumed_root_selection': dict(path=str(ACTUAL / 'ROOT_SELECTION.json'), **pin((ACTUAL / 'ROOT_SELECTION.json').read_bytes())),
    'independent_correction_manifest': dict(path=str(REVIEW), **pin(REVIEW.read_bytes())),
    'selection_is_current_authority': False,
}
json_new('INVOCATION.json', invocation)
write_new('PUBLIC_CERTIFICATE.pem', namespace['PUBLIC_CERTIFICATE'])
write_new('PREDECESSOR_ACTUAL_TOOL_RETURN.json', (ACTUAL / 'ACTUAL_INVOCATION_TOOL_RETURN.json').read_bytes())
write_new('SOURCE_DIFF.patch', ''.join(difflib.unified_diff(old_raw.decode().splitlines(True), new_raw.decode().splitlines(True), fromfile=str(OLD / 'probe.py'), tofile=str(HERE / 'probe.py'))).encode())
json_new('DERIVATION.json', {
    'schema': 'g132.public-positive-receipt-mode-successor-derivation.v1',
    'authority': 'NONE',
    'old_source': dict(path=str(OLD / 'probe.py'), **pin(old_raw)),
    'source': dict(path=str(HERE / 'probe.py'), **source_pin),
    'historical_receipt_reader': namespace['HISTORICAL_PUBLIC_RECEIPTS'],
    'unchanged_function_source_segments': unchanged,
    'main_ast_identical_after_reversing_only_two_prior_reader_calls': True,
    'bootstrap_algorithm_unchanged_after_exact_path_descriptor_selection_substitution': True,
    'predecessor_attempt': invocation['predecessor_attempt'],
    'output_directory': str(namespace['OUTPUT']),
    'output_absent_at_generation': not namespace['OUTPUT'].exists(),
    'original_awards': [],
    'native_capture_calls': 0,
    'private_original_inputs_read': False,
    'state': 'SOURCE_PREPARED_UNEXECUTED_REQUIRES_INDEPENDENT_REVIEW_AND_FRESH_ROOT_SELECTION',
})
os.chmod(HERE / 'probe.py', 0o444)
os.chmod(HERE / 'PREPARED_SELECTION.json', 0o444)
print(json.dumps({'state': 'PREPARED_UNEXECUTED', 'source': source_pin, 'selection': selection_pin, 'invocation': pin((HERE / 'INVOCATION.json').read_bytes()), 'unchanged_functions': unchanged, 'main_normalized_ast_equal': True, 'output_absent': not namespace['OUTPUT'].exists(), 'native_capture_calls': 0}, sort_keys=True))
