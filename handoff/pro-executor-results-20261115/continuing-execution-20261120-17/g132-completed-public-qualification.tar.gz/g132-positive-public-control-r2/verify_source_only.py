"""Read-only packet check. Does not call main, loader.load, capture, or a provider."""
import ast
import hashlib
import json
from pathlib import Path
import shlex
import stat

HERE = Path(__file__).resolve().parent
OLD = Path('/workspace/scratch/530bc07ea12b/g132-original-operation-readiness/positive-public-control')


def pin(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


source = (HERE / 'probe.py').read_bytes()
namespace = {'__name__': 'g132_positive_r2_verification_only', '__file__': str(HERE / 'probe.py')}
exec(compile(source, str(HERE / 'probe.py'), 'exec'), namespace)
assert stat.S_IMODE((HERE / 'probe.py').stat().st_mode) == 0o444
assert stat.S_IMODE((HERE / 'PREPARED_SELECTION.json').stat().st_mode) == 0o444
selection_raw = (HERE / 'PREPARED_SELECTION.json').read_bytes()
assert json.loads(selection_raw) == namespace['expected_selection'](pin(source))
invocation_raw = (HERE / 'INVOCATION.json').read_bytes()
invocation = json.loads(invocation_raw)
assert invocation['source'] == dict(path=str(HERE / 'probe.py'), **pin(source))
assert invocation['selection'] == dict(path=str(HERE / 'PREPARED_SELECTION.json'), **pin(selection_raw))
assert invocation['bootstrap'] == pin(invocation['argv'][-1].encode())
assert invocation['argv'] == shlex.split(invocation['shell_command'])
assert invocation['root_native_invocation_issued'] is False
assert invocation['predecessor_attempt']['selection_is_current_authority'] is False
compile(invocation['argv'][-1], 'prepared-r2-bootstrap-only', 'exec')

old_manifest_raw = (OLD / 'MANIFEST.json').read_bytes()
assert pin(old_manifest_raw) == {'bytes': 1193, 'sha256': 'f3c8c55c3d26e745705c1ec7ae38d79cf6233d5d44d15a7e2dc7461e375cbd42'}
old_rows = json.loads(old_manifest_raw)['files']
old_received = []
for row in old_rows:
    raw = (OLD / row['path']).read_bytes()
    assert pin(raw) == {k: row[k] for k in ('bytes', 'sha256')}
    old_received.append(dict(row, mode=oct(stat.S_IMODE((OLD / row['path']).stat().st_mode))))

old_ast = ast.parse((OLD / 'probe.py').read_bytes())
new_ast = ast.parse(source)
old_reader = next(node for node in old_ast.body if isinstance(node, ast.FunctionDef) and node.name == 'read_bound')
new_reader = next(node for node in new_ast.body if isinstance(node, ast.FunctionDef) and node.name == 'read_bound')
assert ast.get_source_segment((OLD / 'probe.py').read_text(), old_reader) == ast.get_source_segment(source.decode(), new_reader)
seals = {}
for path, digest in namespace['PRIOR_SEALS'].items():
    body, opening = namespace['read_prior_seal'](path, digest)
    closing_body, closing = namespace['read_prior_seal'](path, digest)
    assert closing_body == body and closing == opening
    seals[path] = opening
historical_path = next(iter(namespace['HISTORICAL_PUBLIC_RECEIPTS']))
try:
    namespace['read_bound'](historical_path, namespace['HISTORICAL_PUBLIC_RECEIPTS'][historical_path])
except ValueError as exc:
    assert str(exc) == 'PROBE_SOURCE_MODE'
else:
    raise AssertionError('Generic source reader admitted historical0600 evidence')
assert pin((HERE / 'PREDECESSOR_ACTUAL_TOOL_RETURN.json').read_bytes()) == {'bytes': 745, 'sha256': '368192c0e2a7a8802248cb83e9098f4c4d17d68c23a8e901e8c4e656b87d04bd'}
assert (HERE / 'PUBLIC_CERTIFICATE.pem').read_bytes() == namespace['PUBLIC_CERTIFICATE'] == (OLD / 'PUBLIC_CERTIFICATE.pem').read_bytes()
assert not namespace['OUTPUT'].exists() and not namespace['OUTPUT'].is_symlink()
assert not (OLD / 'one-time-output').exists() and not (OLD / 'one-time-output').is_symlink()
print(json.dumps({
    'schema': 'g132.public-positive-r2-source-only-verification.v1',
    'state': 'SOURCE_ONLY_CHECKS_PASS_UNEXECUTED_NOT_INDEPENDENT_ACCEPTANCE',
    'source': pin(source), 'selection': pin(selection_raw), 'invocation': pin(invocation_raw),
    'generic_reader_source_identical': True,
    'generic_reader_still_refuses_historical0600': True,
    'old_six_file_seal_unchanged': old_received,
    'prior_seals_opening_and_closing_equal': seals,
    'prior_seal_count': len(seals),
    'historical_receipt_mode': oct(stat.S_IMODE(Path(historical_path).stat().st_mode)),
    'old_and_new_output_paths_absent': True,
    'old_failed_attempt_exactly_preserved': True,
    'root_current_selection_issued': False,
    'native_capture_calls': 0, 'original_private_inputs_read': False,
    'original_awards': [], 'authority': 'NONE',
}, indent=2, sort_keys=True))
