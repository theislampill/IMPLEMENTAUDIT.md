"""Prepared TEST_ONLY public positive-encryption capture; no import-time effects.

Only the exact reviewed invocation may activate this entry.  An existing output
directory refuses reuse.  A missing terminal record means reconcile, never retry.
This entry cannot award original G1/G3, invoke a sender, decrypt, or publish to a provider.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import stat
import sys
import time
import types


BASE = Path('/workspace/scratch/530bc07ea12b/g132-positive-public-control-r2')
SOURCE = BASE / 'probe.py'
SELECTION = BASE / 'PREPARED_SELECTION.json'
OUTPUT = BASE / 'one-time-output'
INSTALLATION = Path('/workspace/scratch/2678f1e431c3/g132-actual-candidate-source-received-20261119/dependencies/installation')
CARRIER = INSTALLATION / 'phase/tree/qualification/dg16-r5-g1-hosted-episode/carrier'
LOADER_PIN = {'bytes': 4677, 'sha256': '57bad8d72d987f90a88c96520ff83f1a6a3fa3c79eebf524b93ed0f2abb55e0d'}
INDEX_PIN = {'bytes': 23998, 'sha256': '58a831b74aec61df5f159ca72cc5c54bc2d50c13f0aea78651bdfe48f0d8e983'}
MAINTAINED_PINS = {
    'QUALIFIER.py': {'bytes': 268686, 'sha256': '79e3250a654abff1c5c326908875da1fea575686bdfb0c1a291c73bc525ed33b'},
    'COMPILER.py': {'bytes': 262144, 'sha256': '0aa4572a03c7270c538b954d435569b882be59674c9d8275b002402cf9f8d78d'},
}
OWNER_AST = 'ef5d9af63757b3fcda8d76f90567c66e9d61bba32a7251ccd8873acc1b16be1f'
TOOL_PINS = {
    '/usr/bin/env': {'bytes': 56144, 'sha256': 'eb1c64bbc9908afcdf8cb48524f17112d8dd76a249f80dee2f01da14747b3b6e'},
    '/usr/bin/openssl': {'bytes': 1103304, 'sha256': 'acc10176d038aeb7b2a77d9ec972ac2985857a7191f7aecb7c54ef0e2c7e9549'},
}
PRIOR_SEALS = {
    '/workspace/scratch/530bc07ea12b/g132-positive-public-actual/ACTUAL_INVOCATION_TOOL_RETURN.json': '368192c0e2a7a8802248cb83e9098f4c4d17d68c23a8e901e8c4e656b87d04bd',
    '/workspace/scratch/530bc07ea12b/g132-positive-public-actual/ROOT_SELECTION.json': '133011df499ef47f095dd6f4144264dd8f063e42ae1301be09f4a7eeed0843ec',
    '/workspace/scratch/530bc07ea12b/g132-positive-independent-review/actual-refusal/MANIFEST.json': 'feaec34fdbf4af932a2acd10b458a0383186113995e75c8bcc76c6d67fff8707',
    '/workspace/scratch/530bc07ea12b/g132-native-capture-probe/one-time-output/PROBE_RESULT.json': '3bb4677e69543163727a2130e40286d8650eb9f9739f57735e3e3f024759de1b',
    '/workspace/scratch/530bc07ea12b/g132-native-probe-actual-independent-review/MANIFEST.json': '5980960cb84bdd00ac44e85fbc0b5b3838a5ed135067ed18d8b99c9a7cd2a524',
    '/workspace/scratch/530bc07ea12b/g132-execution-readiness/MANIFEST.json': '763fda7d083bf075cb5f5288e38808b79c235ad4b01201d80414bf183879a581',
    '/workspace/scratch/530bc07ea12b/g132-execution-readiness/followup-native-probe/MANIFEST.json': 'e4e66a6f84a6079f303a29bf55f92e739708f6dc5d936f20b5b8e904386c3652',
    '/workspace/scratch/530bc07ea12b/g132-execution-readiness/followup-native-probe/NATIVE_PROBE_DESIGN.json': 'bcb1ea8207c51ae7bac05ad428220ec3498363c50cbfbf4ee7fe81ad5efd7d6b',
}
HISTORICAL_PUBLIC_RECEIPTS = {
    '/workspace/scratch/530bc07ea12b/g132-native-capture-probe/one-time-output/PROBE_RESULT.json': {
        'bytes': 3979,
        'sha256': '3bb4677e69543163727a2130e40286d8650eb9f9739f57735e3e3f024759de1b',
    },
}
PUBLIC_PLAIN = b'PUBLIC_TEST_ONLY_G132_POSITIVE_CAPTURE\n'
PUBLIC_CERTIFICATE = b'-----BEGIN CERTIFICATE-----\nMIIFazCCA1OgAwIBAgIRAIIQz7DSQONZRGPgu2OCiwAwDQYJKoZIhvcNAQELBQAw\nTzELMAkGA1UEBhMCVVMxKTAnBgNVBAoTIEludGVybmV0IFNlY3VyaXR5IFJlc2Vh\ncmNoIEdyb3VwMRUwEwYDVQQDEwxJU1JHIFJvb3QgWDEwHhcNMTUwNjA0MTEwNDM4\nWhcNMzUwNjA0MTEwNDM4WjBPMQswCQYDVQQGEwJVUzEpMCcGA1UEChMgSW50ZXJu\nZXQgU2VjdXJpdHkgUmVzZWFyY2ggR3JvdXAxFTATBgNVBAMTDElTUkcgUm9vdCBY\nMTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAK3oJHP0FDfzm54rVygc\nh77ct984kIxuPOZXoHj3dcKi/vVqbvYATyjb3miGbESTtrFj/RQSa78f0uoxmyF+\n0TM8ukj13Xnfs7j/EvEhmkvBioZxaUpmZmyPfjxwv60pIgbz5MDmgK7iS4+3mX6U\nA5/TR5d8mUgjU+g4rk8Kb4Mu0UlXjIB0ttov0DiNewNwIRt18jA8+o+u3dpjq+sW\nT8KOEUt+zwvo/7V3LvSye0rgTBIlDHCNAymg4VMk7BPZ7hm/ELNKjD+Jo2FR3qyH\nB5T0Y3HsLuJvW5iB4YlcNHlsdu87kGJ55tukmi8mxdAQ4Q7e2RCOFvu396j3x+UC\nB5iPNgiV5+I3lg02dZ77DnKxHZu8A/lJBdiB3QW0KtZB6awBdpUKD9jf1b0SHzUv\nKBds0pjBqAlkd25HN7rOrFleaJ1/ctaJxQZBKT5ZPt0m9STJEadao0xAH0ahmbWn\nOlFuhjuefXKnEgV4We0+UXgVCwOPjdAvBbI+e0ocS3MFEvzG6uBQE3xDk3SzynTn\njh8BCNAw1FtxNrQHusEwMFxIt4I7mKZ9YIqioymCzLq9gwQbooMDQaHWBfEbwrbw\nqHyGO0aoSCqI3Haadr8faqU9GY/rOPNk3sgrDQoo//fb4hVC1CLQJ13hef4Y53CI\nrU7m2Ys6xt0nUW7/vGT1M0NPAgMBAAGjQjBAMA4GA1UdDwEB/wQEAwIBBjAPBgNV\nHRMBAf8EBTADAQH/MB0GA1UdDgQWBBR5tFnme7bl5AFzgAiIyBpY9umbbjANBgkq\nhkiG9w0BAQsFAAOCAgEAVR9YqbyyqFDQDLHYGmkgJykIrGF1XIpu+ILlaS/V9lZL\nubhzEFnTIZd+50xx+7LSYK05qAvqFyFWhfFQDlnrzuBZ6brJFe+GnY+EgPbk6ZGQ\n3BebYhtF8GaV0nxvwuo77x/Py9auJ/GpsMiu/X1+mvoiBOv/2X/qkSsisRcOj/KK\nNFtY2PwByVS5uCbMiogziUwthDyC3+6WVwW6LLv3xLfHTjuCvjHIInNzktHCgKQ5\nORAzI4JMPJ+GslWYHb4phowim57iaztXOoJwTdwJx4nLCgdNbOhdjsnvzqvHu7Ur\nTkXWStAmzOVyyghqpZXjFaH3pO3JLF+l+/+sKAIuvtd7u+Nxe5AW0wdeRlN8NwdC\njNPElpzVmbUq4JUagEiuTDkHzsxHpFKVK7q4+63SM1N95R1NbdWhscdCb+ZAJzVc\noyi3B43njTOQ5yOf+1CceWxG1bQVs5ZufpsMljq4Ui0/1lvh+wjChP4kqKOJ2qxq\n4RgqsahDYVvTH9w7jXbyLeiNdd8XM2w9U/t7y0Ff/9yi0GE44Za4rF2LN9d11TPA\nmRGunUHBcnWEvgJBQl9nJEiU0Zsnvgc/ubhPgXRR4Xq37Z0j4r7g1SgEEzwxA57d\nemyPxgcYxn/eR44/KJ4EBs+lVDR3veyJm+kXQ99b21/+jh5Xos1AnX5iItreGCc=\n-----END CERTIFICATE-----\n'
CONTROL_IDS = ('PC01', 'PC02', 'PC03', 'PC04', 'PC05', 'PC06')


def need(ok, code):
    if not ok:
        raise ValueError(code)


def descriptor(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def stamp(s):
    return [s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_size,
            s.st_mtime_ns, s.st_ctime_ns, s.st_uid, s.st_gid]


def ancestry(path):
    rows = []
    for parent in reversed(path.parents):
        s = parent.lstat()
        need(stat.S_ISDIR(s.st_mode) and not parent.is_symlink(), 'PROBE_PARENT_ALIAS')
        rows.append([str(parent), s.st_dev, s.st_ino, s.st_mode, s.st_uid, s.st_gid])
    return rows


def read_bound(path, pin, executable=False):
    """Finite, no-follow, closing-identity read; tools keep original mode gates."""
    path = Path(path)
    need(path.is_absolute(), 'PROBE_ABSOLUTE_SOURCE_REQUIRED')
    parents = ancestry(path)
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
         and 0 < before.st_size <= 2 * 1024**2, 'PROBE_SOURCE_SHAPE')
    mode = stat.S_IMODE(before.st_mode)
    need((not mode & 0o022 and bool(mode & 0o111) and os.access(path, os.X_OK))
         if executable else mode in (0o400, 0o444, 0o644), 'PROBE_SOURCE_MODE')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        need(stamp(os.fstat(fd)) == stamp(before) and not os.listxattr(fd), 'PROBE_SOURCE_OPEN_CHANGED')
        raw = os.pread(fd, 2 * 1024**2 + 1, 0)
        need(len(raw) == before.st_size and stamp(os.fstat(fd)) == stamp(before)
             and stamp(path.lstat()) == stamp(before) and ancestry(path) == parents,
             'PROBE_SOURCE_CLOSING_CHANGED')
    finally:
        os.close(fd)
    actual = descriptor(raw)
    need(actual['sha256'] == pin['sha256']
         and ('bytes' not in pin or actual['bytes'] == pin['bytes']), 'PROBE_BODY_PIN')
    return raw, dict(actual, identity=stamp(before), ancestors=parents)


def expected_selection(source_pin):
    return {
        'schema': 'g132.public-native-probe-prepared-selection.v1',
        'authority': 'NONE', 'state': 'PREPARED_FOR_INDEPENDENT_REVIEW_UNEXECUTED',
        'classification': 'TEST_ONLY_PUBLIC_POSITIVE_COMMAND_CAPTURE',
        'source': dict(path=str(SOURCE), **source_pin),
        'selection_path': str(SELECTION), 'output_directory': str(OUTPUT),
        'output_rule': 'MUST_BE_ABSENT_CREATE_ONCE_RETAIN_ALL_PARTIALS_NO_AUTOMATIC_RETRY',
        'installation': str(INSTALLATION), 'installation_index': INDEX_PIN,
        'carrier_loader': LOADER_PIN, 'maintained_sources': MAINTAINED_PINS,
        'maintained_owner_ast_sha256': OWNER_AST, 'tools': TOOL_PINS,
        'prior_seals': PRIOR_SEALS,
        'historical_public_receipt_readers': HISTORICAL_PUBLIC_RECEIPTS,
        'predecessor_attempt': 'cd895e/1_ENTRY_REFUSAL_PRESERVED_NOT_REPLAYED',
        'public_inputs': {'bundle.plain': descriptor(PUBLIC_PLAIN),
                          'recipient.pem': descriptor(PUBLIC_CERTIFICATE)},
        'output_maxima': {'bundle.plain': 128, 'recipient.pem': 4096, 'INPUTS.cms': 4096},
        'command_profile': 'MAINTAINED_OWNER_THREE_FD_ENCRYPTION_V1',
        'command_seconds': 10, 'enclosing_seconds': 15, 'capture_calls': 1,
        'expected_command_result': 'ZERO_EXIT_AUTH_ENVELOPED_CIPHER_COMPLETE_NATIVE_CLOSURE',
        'controls': {name: 'UNEXECUTED' for name in CONTROL_IDS},
        'root_pre_execution_review_required': True, 'original_awards': [],
        'positive_crypto_claim': False, 'original_sender_claim': False,
        'provider_calls': 0, 'network_calls': 0, 'private_original_inputs': False,
    }


def read_historical_public_receipt(path, pin):
    """Exact owned0600 observation bytes; never relax the source/tool reader."""
    name = str(path)
    path = Path(name)
    need(str(path) == name and name in HISTORICAL_PUBLIC_RECEIPTS
         and pin == HISTORICAL_PUBLIC_RECEIPTS[name], 'EXACT_HISTORICAL_PUBLIC_RECEIPT')
    parents = ancestry(path)
    before = path.lstat()
    need(os.getuid() == os.geteuid() > 0 and os.getgid() == os.getegid()
         and stat.S_ISREG(before.st_mode) and before.st_nlink == 1
         and before.st_uid == os.geteuid() and before.st_gid == os.getegid()
         and stat.S_IMODE(before.st_mode) == 0o600 and before.st_size == pin['bytes'],
         'HISTORICAL_RECEIPT_CUSTODY')
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        need(stamp(os.fstat(fd)) == stamp(before) and not os.listxattr(fd),
             'HISTORICAL_RECEIPT_OPEN_CHANGED')
        raw = os.pread(fd, pin['bytes'] + 1, 0)
        need(len(raw) == pin['bytes'] and stamp(os.fstat(fd)) == stamp(before)
             and stamp(path.lstat()) == stamp(before) and ancestry(path) == parents,
             'HISTORICAL_RECEIPT_CLOSING_CHANGED')
    finally:
        os.close(fd)
    need(descriptor(raw) == pin, 'HISTORICAL_RECEIPT_PIN')
    return raw, dict(pin, identity=stamp(before), ancestors=parents,
                     read_class='EXACT_OWNED0600_HISTORICAL_PUBLIC_OBSERVATION_NOT_SOURCE')


def read_prior_seal(path, digest):
    if path in HISTORICAL_PUBLIC_RECEIPTS:
        pin = HISTORICAL_PUBLIC_RECEIPTS[path]
        need(digest == pin['sha256'], 'HISTORICAL_RECEIPT_SELECTED_DIGEST')
        return read_historical_public_receipt(path, pin)
    return read_bound(path, {'sha256': digest})


def exception_fact(exc):
    text = str(exc)
    return {'type': type(exc).__name__, 'errno': getattr(exc, 'errno', None),
            'code': text if re.fullmatch(r'[A-Z0-9_]{1,128}', text) else None,
            'message': text[:1024], 'message_truncated': len(text) > 1024,
            'message_descriptor': descriptor(text.encode('utf-8', errors='replace'))}


def handler_fact(handler):
    return int(handler) if isinstance(handler, int) else {
        'module': getattr(handler, '__module__', None),
        'name': getattr(handler, '__qualname__', type(handler).__name__),
    }


def main():
    need(sys.flags.isolated == 1 and sys.dont_write_bytecode is True, 'PROBE_ISOLATED_ENTRY_REQUIRED')
    need(len(sys.argv) == 4 and sys.argv[0] == str(SOURCE) and sys.argv[1:3]
         == ['--execute', '--selection-sha256'] and re.fullmatch(r'[0-9a-f]{64}', sys.argv[3]),
         'PROBE_EXACT_INVOCATION_REQUIRED')
    selection_raw, selection_record = read_bound(SELECTION, {'sha256': sys.argv[3]})
    selection = json.loads(selection_raw)
    source_raw, source_record = read_bound(SOURCE, selection['source'])
    need(selection == expected_selection(descriptor(source_raw)), 'PROBE_SELECTION_CHANGED')
    need(os.getuid() == os.geteuid() != 0 and os.getgid() == os.getegid(), 'PROBE_NONROOT_IDENTITY')
    index_raw, index_record = read_bound(INSTALLATION / 'SOURCE_INDEX.json', INDEX_PIN)
    index = json.loads(index_raw)['files']
    loader_path = CARRIER / 'carrier_loader.py'
    loader_raw, loader_record = read_bound(loader_path, LOADER_PIN)
    loader = types.ModuleType('g132_public_probe_carrier_loader')
    loader.__file__ = str(loader_path)
    exec(compile(loader_raw, str(loader_path), 'exec'), loader.__dict__)
    selected_pins = {'carrier_loader.py': LOADER_PIN}
    selected_pins.update({name + '.py': pin for name, pin in loader.MODULE_PINS.items()})
    selected_pins.update({'maintained/' + name: pin for name, pin in MAINTAINED_PINS.items()})
    for name, pin in selected_pins.items():
        need(index[str((CARRIER / name).relative_to(INSTALLATION))] == pin, 'PROBE_INDEX_SOURCE_JOIN')
    loaded = loader.load()
    F, P, SC = loaded.files, loaded.policy, loaded.sender_capture
    need(SC.QUALIFIER == MAINTAINED_PINS['QUALIFIER.py']
         and SC.COMPILER == MAINTAINED_PINS['COMPILER.py'] and SC.OWNER_AST_SHA256 == OWNER_AST,
         'PROBE_MAINTAINED_OWNER_JOIN')
    tools = {name: read_bound(name, pin, True)[1] for name, pin in TOOL_PINS.items()}
    seal_records = {name: read_prior_seal(name, digest)[1] for name, digest in PRIOR_SEALS.items()}
    before_fds = SC.descriptor_snapshot()
    before_mask = signal.pthread_sigmask(signal.SIG_BLOCK, set())
    signal_names = (signal.SIGCHLD, signal.SIGINT, signal.SIGTERM)
    before_handlers = {n: signal.getsignal(n) for n in signal_names}
    proc = dict(line.split(':', 1) for line in Path('/proc/self/status').read_text().splitlines() if ':' in line)
    identity = {'pid': os.getpid(), 'uid': os.getuid(), 'euid': os.geteuid(),
                'gid': os.getgid(), 'egid': os.getegid(), 'python': sys.version,
                'interpreter': sys.executable, 'proc_stat_pid': Path('/proc/self/stat').read_text().split(' ', 1)[0],
                'proc_fields': {key: proc.get(key, '').split() for key in ('NSpid', 'NStgid', 'Threads')},
                'tasks': sorted(os.listdir('/proc/self/task'))}
    budget = F.Budget(P.MAX_PRIVATE_BYTES, P.MAX_PRIVATE_ENTRIES)
    budget.reserve(0, 1)
    root_fd, root_identity = F.private_directory(OUTPUT)  # O_EXCL-equivalent single-use reservation.
    objects, inputs, records, active_flags, retention_errors = [], {}, [], [], []
    session = None
    captured = None
    entered_capture = False
    closed = False
    final_current = False
    after_fds = None
    cleanup = []
    result = {'schema': 'g132.public-native-probe-observation.v1', 'authority': 'NONE',
              'classification': 'TEST_ONLY_PUBLIC_POSITIVE_COMMAND_CAPTURE',
              'state': 'PARTIAL', 'original_awards': [], 'positive_crypto_claim': False,
              'original_sender_claim': False, 'automatic_retry': False,
              'selection': descriptor(selection_raw), 'source': descriptor(source_raw),
              'output_directory': str(OUTPUT), 'output_identity': root_identity,
              'controls': {name: 'UNEXECUTED' for name in CONTROL_IDS},
              'failures': [], 'retention_errors': retention_errors}

    def root_current():
        need(F.directory_id(OUTPUT.lstat()) == root_identity and not OUTPUT.is_symlink()
             and not os.listxattr(OUTPUT), 'PROBE_OUTPUT_DIRECTORY_CHANGED')

    def current():
        loader.current()
        for path, pin, opening in (
            (SOURCE, selection['source'], source_record),
            (SELECTION, descriptor(selection_raw), selection_record),
            (INSTALLATION / 'SOURCE_INDEX.json', INDEX_PIN, index_record),
            (loader_path, LOADER_PIN, loader_record),
        ):
            need(read_bound(path, pin)[1] == opening, 'PROBE_SOURCE_CHANGED')
        for path, pin in TOOL_PINS.items():
            need(read_bound(path, pin, True)[1] == tools[path], 'PROBE_TOOL_CHANGED')
        for path, digest in PRIOR_SEALS.items():
            need(read_prior_seal(path, digest)[1] == seal_records[path], 'PROBE_PRIOR_SEAL_CHANGED')
        root_current()
        for obj in objects:
            obj.current()
            if obj.name in inputs:
                need(obj.read() == inputs[obj.name]['body']
                     and F.stamp(obj.current()) == inputs[obj.name]['identity'], 'PROBE_PUBLIC_INPUT_CHANGED')
        if session is not None and session.owner is not None and session.owner.active:
            value = session.owner._get_flag()
            active_flags.append({'previous': session.owner.previous_flag, 'active_readback': value})
            need(value == 1, 'PROBE_ACTIVE_SUBREAPER_READBACK')

    def persist(name, raw, maximum):
        try:
            root_current()
            budget.reserve(maximum, 1)
            row = F.write_once(OUTPUT / name, raw, maximum)
            fd = os.open(OUTPUT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
            try:
                need(F.directory_id(os.fstat(fd)) == root_identity, 'PROBE_OUTPUT_SYNC_CHANGED')
                os.fsync(fd)
            finally:
                os.close(fd)
            return row
        except BaseException as exc:
            retention_errors.append({'file': name, 'error': exception_fact(exc), 'effect': 'UNCONFIRMED_NO_RETRY'})
            return None

    def persist_json(name, value, maximum=262144):
        return persist(name, P.encode(value), maximum)

    try:
        intent = {'schema': 'g132.public-native-probe-intent.v1', 'authority': 'NONE',
                  'state': 'RESERVED_BEFORE_PUBLIC_INPUTS_AND_CAPTURE', 'classification': result['classification'],
                  'selection': selection_record, 'source': source_record, 'loader': loader_record,
                  'installation_index': index_record, 'tools': tools, 'prior_seals': seal_records,
                  'output_identity': root_identity, 'identity': identity, 'before_descriptors': before_fds,
                  'before_mask': sorted(int(n) for n in before_mask),
                  'before_handlers': {str(int(n)): handler_fact(h) for n, h in before_handlers.items()},
                  'original_awards': [], 'automatic_retry': False}
        need(persist_json('PROBE_INTENT.json', intent) is not None, 'PROBE_INTENT_UNRECEIVED')
        current()
        result['controls']['PC01'] = 'PASS'
        for name, raw, maximum in (('bundle.plain', PUBLIC_PLAIN, 128),
                                   ('recipient.pem', PUBLIC_CERTIFICATE, 4096), ('INPUTS.cms', None, 4096)):
            obj = F.OutputFile(OUTPUT, name, maximum, budget)
            objects.append(obj)
            if raw is not None:
                obj.write(raw)
                inputs[name] = {'body': raw, 'identity': F.stamp(obj.current())}
            else:
                need(obj.read() == b'', 'PROBE_CIPHER_NOT_INITIALLY_EMPTY')
        plain, certificate, cipher = objects
        fds = (plain.fd, certificate.fd, cipher.fd)
        argv = ['/usr/bin/env', '-i', 'PATH=/usr/bin:/bin', 'LC_ALL=C', 'OPENSSL_CONF=/dev/null',
                '/usr/bin/openssl', 'cms', '-encrypt', '-binary', '-aes-256-gcm',
                '-in', plain.proc_path, '-outform', 'DER', '-out', cipher.proc_path,
                '-recip', certificate.proc_path, '-keyopt', 'rsa_padding_mode:oaep',
                '-keyopt', 'rsa_oaep_md:sha256', '-keyopt', 'rsa_mgf1_md:sha256']
        SC.validate_command('carrier-encrypt', argv, fds)
        session = SC.CaptureSession(OUTPUT, budget, current)
        current()
        need(persist_json('CAPTURE_INTENT.json', {
            'schema': 'g132.public-native-capture-intent.v1', 'authority': 'NONE',
            'classification': result['classification'], 'argv': argv, 'held_fds': list(fds),
            'held': {o.name: {'fd': o.fd, 'identity': F.stamp(o.current()),
                              'body': descriptor(o.read())} for o in objects},
            'maintained_source_opening': session.source_opening, 'expected_returncode': 0,
            'command_seconds': 10, 'enclosing_seconds': 15, 'original_awards': [],
            'automatic_retry': False}) is not None, 'PROBE_CAPTURE_INTENT_UNRECEIVED')
        entered_capture = True
        try:
            rc, stdout, stderr = session.capture('carrier-encrypt', argv, records,
                time.monotonic() + 15, seconds=10, fds=fds)
            captured = {'returncode': rc, 'stdout': stdout, 'stderr': stderr, 'streams_complete': True}
        except BaseException as exc:
            captured = getattr(exc, 'captured', None)
            result['failures'].append({'stage': 'capture', 'error': exception_fact(exc)})
        result['active_subreaper_observations'] = active_flags
        if session.owner is not None:
            result['subreaper_previous'] = session.owner.previous_flag
            result['subreaper_final_readback'] = session.owner._get_flag()
        result['public_input_readback'] = {o.name: descriptor(o.read()) for o in (plain, certificate)}
        current()
        cipher_raw = cipher.read()
        result['cipher_readback'] = descriptor(cipher_raw)
        result['auth_enveloped_type_received'] = False
        if cipher_raw:
            need(persist('PUBLIC_CIPHER.bin', cipher_raw, 4096) is not None, 'PUBLIC_CIPHER_RETENTION_REQUIRED')
            result['auth_enveloped_type_received'] = loaded.carrier.require_auth_enveloped(cipher_raw)
    except BaseException as exc:
        result['failures'].append({'stage': 'prepare_or_receive', 'error': exception_fact(exc)})
    finally:
        # Observe original closure even after a partial capture/readback failure;
        # its currentness checks still see the three held files when available.
        if session is not None and entered_capture:
            closed = session.closed()
        result['capture_closed_before_held_cleanup'] = closed
        result['capture_calls'] = session.calls if session is not None else 0
        result['capture_records'] = records
        result['entered_capture'] = entered_capture
        result['captured'] = None if captured is None else {
            'returncode': captured.get('returncode'), 'streams_complete': captured.get('streams_complete'),
            'stdout': None, 'stderr': None}
        if captured is not None:
            for stream in ('stdout', 'stderr'):
                raw = captured.get(stream)
                if type(raw) is bytes:
                    result['captured'][stream] = {'body': descriptor(raw),
                        'retained': persist(stream.upper() + '.bin', raw, SC.STREAM_MAX)}
                elif raw is not None:
                    result['failures'].append({'stage': stream, 'error': {'code': 'PROBE_STREAM_TYPE'}})
        persist_json('CAPTURE_RETURN.json', {
            'classification': result['classification'], 'entered_capture': entered_capture,
            'capture_calls': result['capture_calls'], 'capture_records': records,
            'captured': result['captured'], 'active_subreaper_observations': active_flags,
            'capture_closed_before_held_cleanup': closed, 'failures': result['failures'],
            'original_awards': [], 'automatic_retry': False})
        for obj in reversed(objects):
            try:
                cleanup.append(obj.cleanup())
            except BaseException as exc:
                cleanup.append({'name': obj.name, 'complete': False, 'error': exception_fact(exc)})
        objects.clear()
        try:
            os.close(root_fd)
            result['output_directory_descriptor_closed'] = True
        except BaseException as exc:
            result['failures'].append({'stage': 'output_descriptor_close', 'error': exception_fact(exc)})
        try:
            current()
            SC.source_current(session.source_opening) if session is not None else None
            final_current = True
            after_fds = SC.descriptor_snapshot()
            result['closing'] = {'echild': SC.kernel_echild(), 'descriptors_restored': after_fds == before_fds,
                'mask_restored': signal.pthread_sigmask(signal.SIG_BLOCK, set()) == before_mask,
                'handlers_restored': all(signal.getsignal(n) is old or signal.getsignal(n) == old
                                         for n, old in before_handlers.items())}
        except BaseException as exc:
            result['failures'].append({'stage': 'closing_observation', 'error': exception_fact(exc)})
    result['final_source_current'] = final_current
    result['after_descriptors'] = after_fds
    result['owned_file_cleanup'] = cleanup
    row = records[0] if len(records) == 1 else {}
    restoration = session.last['restoration'] if session is not None and session.last is not None else {}
    command_ok = (captured is not None and type(captured.get('returncode')) is int
                  and captured['returncode'] == 0 and captured.get('streams_complete') is True)
    streams_join = (captured is not None and all(type(captured.get(k)) is bytes
        and descriptor(captured[k]) == {'bytes': row.get(k + '_bytes'), 'sha256': row.get(k + '_sha256')}
        and result['captured'][k] is not None and result['captured'][k]['retained'] is not None
        for k in ('stdout', 'stderr')))
    capture_ok = (result['capture_calls'] == 1 and row.get('process_started') is True
                  and row.get('pidfd_acquired') is True and row.get('streams_complete') is True
                  and row.get('internal_failure') is None and row.get('timeout') is False
                  and row.get('output_bound_exceeded') is False and command_ok and streams_join
                  and row.get('returncode') == captured.get('returncode'))
    flags_ok = (bool(active_flags) and all(x['active_readback'] == 1 for x in active_flags)
                and result.get('subreaper_previous') in (0, 1)
                and result.get('subreaper_final_readback') == result.get('subreaper_previous')
                and restoration.get('subreaper_restored') is True)
    inputs_ok = result.get('public_input_readback') == {
        'bundle.plain': descriptor(PUBLIC_PLAIN), 'recipient.pem': descriptor(PUBLIC_CERTIFICATE)}
    cleanup_ok = (len(cleanup) == 3 and all(all(r.get(k) is True for k in
        ('unlinked', 'descriptor_closed', 'identity_confirmed')) for r in cleanup))
    outcomes = {'PC02': flags_ok, 'PC03': capture_ok,
        'PC04': inputs_ok and restoration.get('descriptors_restored') is True
                and restoration.get('owned_descriptors_closed') is True,
        'PC05': command_ok and result.get('auth_enveloped_type_received') is True
                and 0 < result.get('cipher_readback', {}).get('bytes', 0) <= 4096
                and captured.get('stdout') == b'' and captured.get('stderr') == b'',
        'PC06': closed and cleanup_ok and final_current and SC.restoration_ok(restoration)
                and all(result.get('closing', {}).get(k) is True for k in
                        ('echild', 'descriptors_restored', 'mask_restored', 'handlers_restored'))}
    for key, passed in outcomes.items():
        result['controls'][key] = ('PASS' if passed else 'UNVERIFIED') if entered_capture else 'UNEXECUTED'
    qualified = all(v == 'PASS' for v in result['controls'].values()) and not result['failures'] and not retention_errors
    result['positive_crypto_claim'] = qualified
    result['positive_crypto_scope'] = 'PUBLIC_FIXTURE_ENCRYPTION_AND_OUTER_DER_TYPE_ONLY_NO_DECRYPTION'
    result['state'] = 'TEST_ONLY_POSITIVE_CAPTURE_CONTROL_QUALIFIED' if qualified else 'TEST_ONLY_NOT_QUALIFIED_NO_RETRY'
    final = persist_json('PROBE_RESULT.json', result)
    if final is None:
        qualified = False
    print(json.dumps({'schema': 'g132.public-native-probe-terminal.v1', 'authority': 'NONE',
        'state': result['state'] if final is not None else 'RESULT_RETENTION_UNCONFIRMED_NO_RETRY',
        'output_directory': str(OUTPUT), 'result': None if final is None else {k: final[k] for k in ('bytes', 'sha256')},
        'entered_capture': entered_capture, 'capture_calls': result['capture_calls'],
        'controls': result['controls'], 'original_awards': [], 'positive_crypto_claim': qualified,
        'original_sender_claim': False, 'automatic_retry': False}, sort_keys=True))
    return 0 if qualified else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(json.dumps({'schema': 'g132.public-native-probe-entry-refusal.v1', 'authority': 'NONE',
            'state': 'ENTRY_REFUSED_OR_PARTIAL_RECONCILE_OUTPUT_NO_RETRY',
            'output_directory': str(OUTPUT), 'error': exception_fact(exc),
            'original_awards': [], 'automatic_retry': False}, sort_keys=True))
        raise SystemExit(1)
