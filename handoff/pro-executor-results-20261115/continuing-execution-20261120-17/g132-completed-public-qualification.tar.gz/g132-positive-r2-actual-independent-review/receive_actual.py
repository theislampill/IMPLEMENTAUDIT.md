"""Receive the completed public control. No target imports or native calls."""
import ast
import hashlib
import json
import os
from pathlib import Path
import shlex
import stat
import sys

ROOT=Path('/workspace/scratch/530bc07ea12b')
BASE=ROOT/'g132-positive-public-control-r2'
ACTUAL=ROOT/'g132-positive-r2-actual'
OUTPUT=BASE/'one-time-output'
PRIOR_REVIEW=ROOT/'g132-positive-r2-independent-review'
OUT=ROOT/'g132-positive-r2-actual-independent-review'
records=[]


def desc(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def stamp(s):return [s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_uid,s.st_gid]
def directory_id(s):return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid]
def ancestry(path):
    rows=[]
    for p in reversed(path.parents):
        s=p.lstat();assert stat.S_ISDIR(s.st_mode) and not p.is_symlink()
        rows.append([str(p),s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid])
    return rows


def read(path,pin=None,kind='review',maximum=64*1024**2):
    p=Path(path);assert p.is_absolute();parents=ancestry(p);before=p.lstat();mode=stat.S_IMODE(before.st_mode)
    assert stat.S_ISREG(before.st_mode) and before.st_nlink==1 and 0<=before.st_size<=maximum
    if kind=='private':assert mode==0o600 and before.st_uid==os.geteuid() and before.st_gid==os.getegid()
    if kind=='source':assert mode in (0o400,0o444,0o644) and 0<before.st_size<=2*1024**2
    if kind=='executable':assert not mode&0o022 and mode&0o111 and os.access(p,os.X_OK)
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK)
    try:
        assert stamp(os.fstat(fd))==stamp(before) and not os.listxattr(fd)
        raw=os.pread(fd,before.st_size+1,0)
        assert len(raw)==before.st_size and stamp(os.fstat(fd))==stamp(before)==stamp(p.lstat()) and ancestry(p)==parents
    finally:os.close(fd)
    d=desc(raw)
    if pin is not None:assert all(d[k]==v for k,v in pin.items() if k in d),str(p)
    record=dict(d,identity=stamp(before),ancestors=parents)
    records.append(dict(path=str(p),reader=kind,**record))
    return raw,record


def parse(raw):
    def pairs(items):
        result={}
        for k,v in items:assert k not in result;result[k]=v
        return result
    return json.loads(raw,object_pairs_hook=pairs)


def manifest(base,digest):
    m=parse(read(base/'MANIFEST.json',{'sha256':digest})[0]);assert len(m['files'])==m['count']
    assert len({r['path'] for r in m['files']})==m['count'] and sum(r['bytes'] for r in m['files'])==m['bytes']
    for r in m['files']:
        assert not Path(r['path']).is_absolute() and '..' not in Path(r['path']).parts
        read(base/r['path'],r)
    return m


def constants(raw,names):
    out={}
    for n in ast.parse(raw).body:
        if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in names:
            v=n.value
            if isinstance(v,ast.Call):
                assert isinstance(v.func,ast.Name) and v.func.id=='dict' and not v.args
                out[n.targets[0].id]={k.arg:ast.literal_eval(k.value) for k in v.keywords}
            else:out[n.targets[0].id]=ast.literal_eval(v)
    assert set(out)==set(names)
    return out


source_manifest=manifest(BASE,'e6ee948052d92766383baf8a8c7893a3f473b95ab4caf6f1f32378fc79438445')
review_manifest=manifest(PRIOR_REVIEW,'a0765769b981eb93923acf1a995a93906e3ec91cce78bc2a054e6c9d685d19b8')
root_selection_raw,_=read(ACTUAL/'ROOT_SELECTION.json',{'sha256':'cd7d33ca9d99260373de616ec07a6388d7e4854902bbf509810b7094f85446e3'})
root_selection=parse(root_selection_raw)
call_raw,_=read(ACTUAL/'ACTUAL_INVOCATION_TOOL_CALL.json',{'sha256':'4d540c45f44930455b56f36e20cb64d5a2c8e7a75c7bd511120dd7df89e8307f'})
call=parse(call_raw)
preflight=parse(read(ACTUAL/'ACTUAL_PREFLIGHT_TOOL_RETURN.json',{'sha256':'d4238b03a727d606d4e16ea85853da1a0b59ed5da40647a532ffc6046b044316'})[0])
gate=parse(read(ACTUAL/'ACTUAL_CURRENTNESS_TOOL_RETURN.json',{'sha256':'640caebd68c0f570f27819772f72dc5ac7125d2daa018029e203c87e4da0c00a'})[0])
invocation_raw,_=read(BASE/'INVOCATION.json',{'sha256':'b603bf9523bb4809d98946d24d7f324000dc5355a4bcace1d284dc3e069a012f'})
invocation=parse(invocation_raw)
assert root_selection['invocation']==invocation==parse(preflight['output'])['invocation']
assert root_selection['independent_review_manifest_sha256']=='a0765769b981eb93923acf1a995a93906e3ec91cce78bc2a054e6c9d685d19b8'
assert root_selection['mandatory_projection_correction_sha256']==desc(read(PRIOR_REVIEW/'PROJECTION_CORRECTION.json')[0])['sha256']
assert root_selection['one_shot'] is True and root_selection['automatic_retry'] is False
assert root_selection['original_awards']==[] and root_selection['protected_effect'] is False
assert root_selection['operation']=='PUBLIC_FIXTURE_ENCRYPTION_AND_OUTER_DER_TYPE_ONLY_NO_DECRYPTION'
assert preflight['chunk_id']==root_selection['preflight_chunk']=='52b607' and preflight['exit_code']==0
assert parse(preflight['output'])['source_members_verified']==16 and parse(preflight['output'])['output_absent']==str(OUTPUT)
assert gate['chunk_id']=='ba3ef3' and gate['exit_code']==0 and gate['output'].strip()==root_selection['continuity_receipt']
assert call['tool']=='exec_command' and call['arguments']['cmd']==invocation['shell_command']
assert shlex.split(call['arguments']['cmd'])==invocation['argv']
assert call['arguments']['workdir']==invocation['working_directory']==str(BASE)
actual=call['actual_return'];assert actual['chunk_id']=='0d52a8' and actual['exit_code']==0 and 'session_id' not in actual
terminal=parse(actual['output'])
assert terminal['schema']=='g132.public-native-probe-terminal.v1' and terminal['state']=='TEST_ONLY_POSITIVE_CAPTURE_CONTROL_QUALIFIED'
expected_names={'PROBE_INTENT.json','CAPTURE_INTENT.json','SENDER_CAPTURE_OWNER.json','PUBLIC_CIPHER.bin','STDOUT.bin','STDERR.bin','CAPTURE_RETURN.json','PROBE_RESULT.json'}
assert {p.name for p in OUTPUT.iterdir()}==expected_names
output_stat=OUTPUT.lstat();assert stat.S_ISDIR(output_stat.st_mode) and stat.S_IMODE(output_stat.st_mode)==0o700
assert output_stat.st_uid==output_stat.st_gid==1000 and not os.listxattr(OUTPUT)
bodies={};output_records={}
for name in sorted(expected_names):bodies[name],output_records[name]=read(OUTPUT/name,kind='private',maximum=262144)
assert sum(map(len,bodies.values()))==28244
assert desc(bodies['PROBE_RESULT.json'])=={'bytes':4145,'sha256':'365287532d1562b64b99b70af43eff80460024b7f8fa302d4f9ddeedb38fe974'}==terminal['result']
result=parse(bodies['PROBE_RESULT.json']);intent=parse(bodies['PROBE_INTENT.json'])
capture_intent=parse(bodies['CAPTURE_INTENT.json']);capture_return=parse(bodies['CAPTURE_RETURN.json']);owner=parse(bodies['SENDER_CAPTURE_OWNER.json'])
assert result['output_directory']==terminal['output_directory']==str(OUTPUT)
assert result['output_identity']==intent['output_identity']==directory_id(output_stat)
controls={f'PC{i:02d}':'PASS' for i in range(1,7)}
assert result['controls']==terminal['controls']==controls
assert result['state']==terminal['state'] and result['positive_crypto_claim'] is terminal['positive_crypto_claim'] is True
assert result['positive_crypto_scope']==root_selection['operation']
assert result['capture_calls']==terminal['capture_calls']==capture_return['capture_calls']==1
assert result['entered_capture'] is terminal['entered_capture'] is capture_return['entered_capture'] is True
assert result['failures']==result['retention_errors']==capture_return['failures']==[]
for obj in (result,terminal,intent,capture_intent,capture_return,owner):
    assert obj['original_awards']==[]
    if 'authority' in obj:assert obj['authority']=='NONE'
    if 'automatic_retry' in obj:assert obj['automatic_retry'] is False
assert result['original_sender_claim'] is terminal['original_sender_claim'] is False
assert len(result['capture_records'])==1 and result['capture_records']==capture_return['capture_records']
row=result['capture_records'][0]
assert row['owner_evidence']==desc(bodies['SENDER_CAPTURE_OWNER.json'])
assert row['name']=='carrier-encrypt' and row['returncode']==result['captured']['returncode']==owner['primary_returncode']==0
assert result['captured']==capture_return['captured']
assert row['process_started'] is owner['process_started'] is True and row['pidfd_acquired'] is owner['pidfd_acquired'] is True
assert row['streams_complete'] is result['captured']['streams_complete'] is True
assert row['timeout'] is row['output_bound_exceeded'] is False and row['internal_failure'] is None
assert owner['failure'] is owner['close_error'] is owner['exec_errno'] is None
assert owner['natural_quiescence'] is True and 0<owner['elapsed_ns']<10*10**9
assert owner['maintained_close_seconds']==3.0 and 7.9<owner['enclosing_deadline']-owner['command_deadline']<8.1
for stream in ('stdout','stderr'):
    raw=bodies[stream.upper()+'.bin'];assert raw==b''
    assert desc(raw)==owner[stream]==result['captured'][stream]['body']
    assert desc(raw)=={'bytes':row[stream+'_bytes'],'sha256':row[stream+'_sha256']}
    assert output_records[stream.upper()+'.bin']==result['captured'][stream]['retained']
assert all(owner['restoration'][k] is True for k in ('echild','mask_restored','handlers_restored','subreaper_restored','descriptors_restored','owned_descriptors_closed'))
assert all(result['closing'][k] is True for k in ('echild','descriptors_restored','mask_restored','handlers_restored'))
assert row['cleanup']=={'echild':True,'restoration_complete':True}
assert owner['before_descriptors']==owner['after_descriptors']
assert result['after_descriptors']==intent['before_descriptors'] and [r[0] for r in result['after_descriptors']]==[0,1,2]
assert owner['original_mask']==intent['before_mask']==[] and intent['before_handlers']['17']==0
identity=intent['identity'];assert identity['uid']==identity['euid']==identity['gid']==identity['egid']==1000
assert identity['pid']==2 and identity['proc_stat_pid']=='2' and identity['tasks']==['2']
assert identity['proc_fields']=={'NSpid':['2'],'NStgid':['2'],'Threads':['1']}
assert identity['interpreter']==invocation['interpreter']['path'] and identity['python'].startswith('3.12.14 ')
before_close,after_close=owner['before_close'],owner['after_close']
assert before_close['flag_restored'] is False and after_close['flag_restored'] is True
assert {k:v for k,v in before_close.items() if k!='flag_restored'}=={k:v for k,v in after_close.items() if k!='flag_restored'}
assert after_close['owner_pid']==identity['pid'] and after_close['primary_pid']==5 and after_close['primary_exit']==0
assert after_close['quiescence']=='ECHILD_ALL_CHILDREN' and after_close['live_children_refused'] is False
assert after_close['other_child_exits']==[] and after_close['owned_pidfd_signals']==0
assert result['active_subreaper_observations']==capture_return['active_subreaper_observations']==[{'previous':0,'active_readback':1}]*2
assert result['subreaper_previous']==result['subreaper_final_readback']==after_close['previous_subreaper']==0
assert result['capture_closed_before_held_cleanup'] is capture_return['capture_closed_before_held_cleanup'] is True
assert result['output_directory_descriptor_closed'] is result['final_source_current'] is True
assert {r['name'] for r in result['owned_file_cleanup']}=={'bundle.plain','recipient.pem','INPUTS.cms'}
assert len(result['owned_file_cleanup'])==3
for r in result['owned_file_cleanup']:
    assert all(r[k] is True for k in ('identity_confirmed','unlinked','descriptor_closed'))
    assert not os.path.lexists(OUTPUT/r['name'])
assert capture_intent['held_fds']==[5,7,9] and set(capture_intent['held'])=={'bundle.plain','recipient.pem','INPUTS.cms'}
assert capture_intent['command_seconds']==10 and capture_intent['enclosing_seconds']==15 and capture_intent['expected_returncode']==0
argv=['/usr/bin/env','-i','PATH=/usr/bin:/bin','LC_ALL=C','OPENSSL_CONF=/dev/null','/usr/bin/openssl','cms','-encrypt','-binary','-aes-256-gcm','-in','/proc/self/fd/5','-outform','DER','-out','/proc/self/fd/9','-recip','/proc/self/fd/7','-keyopt','rsa_padding_mode:oaep','-keyopt','rsa_oaep_md:sha256','-keyopt','rsa_mgf1_md:sha256']
assert capture_intent['argv']==argv
fd_rows={r[0]:r for r in owner['before_descriptors']}
for name,held in capture_intent['held'].items():
    i=held['identity'];f=fd_rows[held['fd']]
    assert stat.S_ISREG(i[2]) and stat.S_IMODE(i[2])==0o600 and i[3]==1 and i[7]==i[8]==1000
    assert f[:6]==[held['fd'],i[0],i[1],i[2],i[7],i[8]]
assert capture_intent['held']['INPUTS.cms']['body']==desc(b'')
source,source_record=read(BASE/'probe.py',invocation['source'],'source')
selection_raw,selection_record=read(BASE/'PREPARED_SELECTION.json',invocation['selection'],'source');selection=parse(selection_raw)
assert intent['source']==source_record and intent['selection']==selection_record
assert result['source']==desc(source) and result['selection']==desc(selection_raw)
assert root_selection['source_sha256']==desc(source)['sha256'] and root_selection['selection_sha256']==desc(selection_raw)['sha256']
c=constants(source,('LOADER_PIN','INDEX_PIN','MAINTAINED_PINS','OWNER_AST','TOOL_PINS','PRIOR_SEALS','HISTORICAL_PUBLIC_RECEIPTS','PUBLIC_PLAIN','PUBLIC_CERTIFICATE'))
assert result['public_input_readback']==selection['public_inputs']=={'bundle.plain':desc(c['PUBLIC_PLAIN']),'recipient.pem':desc(c['PUBLIC_CERTIFICATE'])}
for name in ('bundle.plain','recipient.pem'):assert capture_intent['held'][name]['body']==result['public_input_readback'][name]
assert read(BASE/'PUBLIC_CERTIFICATE.pem')[0]==c['PUBLIC_CERTIFICATE'] and b'PRIVATE KEY' not in c['PUBLIC_CERTIFICATE']
installation=Path(selection['installation']);carrier=installation/'phase/tree/qualification/dg16-r5-g1-hosted-episode/carrier'
index_raw,index_record=read(installation/'SOURCE_INDEX.json',c['INDEX_PIN'],'source');index=parse(index_raw)['files']
loader,loader_record=read(carrier/'carrier_loader.py',c['LOADER_PIN'],'source')
assert intent['installation_index']==index_record and intent['loader']==loader_record
modules=constants(loader,('MODULE_PINS',))['MODULE_PINS']
for name,pin in modules.items():
    p=carrier/(name+'.py');read(p,pin,'source',maximum=1024**2);assert index[str(p.relative_to(installation))]==pin
assert owner['source_opening']==capture_intent['maintained_source_opening']
for name,pin in c['MAINTAINED_PINS'].items():
    raw,record=read(carrier/'maintained'/name,pin,maximum=1024**2)
    assert record==owner['source_opening'][name] and index[str((carrier/'maintained'/name).relative_to(installation))]==pin
    if name=='QUALIFIER.py':
        cls=next(n for n in ast.parse(raw).body if isinstance(n,ast.ClassDef) and n.name=='_CaptureChildren')
        assert hashlib.sha256(ast.dump(cls,include_attributes=False).encode()).hexdigest()==c['OWNER_AST']
assert owner['qualifier']==c['MAINTAINED_PINS']['QUALIFIER.py'] and owner['compiler']==c['MAINTAINED_PINS']['COMPILER.py']
assert owner['owner_ast_sha256']==c['OWNER_AST'] and owner['profile']==row['sender_profile']=='MAINTAINED_OWNER_THREE_FD_ENCRYPTION_V1'
for p,pin in c['TOOL_PINS'].items():assert read(p,pin,'executable',maximum=2*1024**2)[1]==intent['tools'][p]
assert set(intent['prior_seals'])==set(c['PRIOR_SEALS'])
for p,digest in c['PRIOR_SEALS'].items():
    historical=p in c['HISTORICAL_PUBLIC_RECEIPTS'];pin=c['HISTORICAL_PUBLIC_RECEIPTS'][p] if historical else {'sha256':digest}
    _,record=read(p,pin,'private' if historical else 'source',maximum=2*1024**2)
    if historical:record['read_class']='EXACT_OWNED0600_HISTORICAL_PUBLIC_OBSERVATION_NOT_SOURCE'
    assert record==intent['prior_seals'][p]
assert sys.version_info[:3]==(3,12,14)
exe=Path(invocation['interpreter']['path']).resolve();assert str(exe)==invocation['interpreter']['resolved_path']
read(exe,invocation['interpreter'],'executable')
cipher=bodies['PUBLIC_CIPHER.bin'];assert desc(cipher)==result['cipher_readback'] and 0<len(cipher)<=4096
def tlv(pos,tag):
    assert pos+2<=len(cipher) and cipher[pos]==tag
    length=cipher[pos+1];start=pos+2
    if length&128:
        count=length&127;assert 1<=count<=4 and start+count<=len(cipher) and cipher[start]!=0
        length=int.from_bytes(cipher[start:start+count],'big');start+=count;assert length>=128
    end=start+length;assert end<=len(cipher)
    return start,end
start,end=tlv(0,0x30);assert end==len(cipher)
oid_start,oid_end=tlv(start,0x06);assert cipher[oid_start:oid_end]==bytes.fromhex('2a864886f70d0109100117')
explicit_start,explicit_end=tlv(oid_end,0xa0);inner_start,inner_end=tlv(explicit_start,0x30)
assert explicit_end==end and inner_end==explicit_end and inner_start<inner_end
assert result['auth_enveloped_type_received'] is True
assert {p.name for p in OUTPUT.iterdir()}==expected_names and directory_id(OUTPUT.lstat())==directory_id(output_stat)
verification=dict(schema='g132.public-positive-r2-actual-independent-receiving.v1',authority='NONE',
    disposition='PC01_PC06_PASS_AT_ACTUAL_PUBLIC_POSITIVE_CONTROL_SCOPE',actual_tool='0d52a8',actual_exit_code=0,
    actual_command_arguments_join=True,root_selection=desc(root_selection_raw),actual_tool_call=desc(call_raw),
    source=desc(source),selection=desc(selection_raw),result=desc(bodies['PROBE_RESULT.json']),
    output_population={n:desc(raw) for n,raw in sorted(bodies.items())},output_count=8,output_bytes=28244,
    controls=controls,capture_calls=1,command_exit=0,cipher=desc(cipher),
    outer_der_type='1.2.840.113549.1.9.16.1.23 AuthEnvelopedData',
    scope='PUBLIC_FIXTURE_ENCRYPTION_AND_OUTER_DER_TYPE_ONLY_NO_DECRYPTION',
    decryption_performed=False,aead_tag_verification_claimed=False,original_sender_claim=False,
    streams_empty_and_exact=True,owner_pid=2,primary_pid=5,subreaper_readbacks=[0,1,1,0],
    original_restoration=owner['restoration'],native_natural_quiescence=True,forced_pidfd_signals=0,
    held_files_cleanup=result['owned_file_cleanup'],held_paths_absent=True,
    source_currentness_received_and_freshly_joined=True,integer_safe_json_parsing=True,
    target_source_imported_or_executed_by_reviewer=False,reviewer_native_crypto_provider_calls=0,
    prior_failures_and_corrections_preserved=True,original_awards=[],records=records)
raw=(json.dumps(verification,indent=2,sort_keys=True)+'\n').encode();p=OUT/'VERIFICATION.json'
fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_CLOEXEC,0o444)
try:assert os.write(fd,raw)==len(raw);os.fsync(fd)
finally:os.close(fd)
assert p.read_bytes()==raw
print(json.dumps(dict(state=verification['disposition'],authority='NONE',verification=dict(path=str(p),**desc(raw)),
    output_count=8,output_bytes=28244,cipher=desc(cipher),actual_tool='0d52a8',capture_calls=1,
    reviewer_native_crypto_provider_calls=0,original_awards=[])))
