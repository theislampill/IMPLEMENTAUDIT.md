# Positive public control r2: independent actual receiving

**Technical disposition: PC01–PC06 PASS at the actual public positive-control scope. Authority NONE.** The received exact Root call completed one original native capture, command exit0,819 retained cipher bytes with the required outer AuthEnvelopedData type, empty complete streams, and full original restoration/currentness. This is public fixture encryption and outer DER-type receiving only. No decryption, AEAD-tag verification, authentic original sender, original G1/G3 award or whole-path qualification is established.

Reviewer: `/root/g132_positive_independent_review`. This review received an already completed operation. It did not import/execute target source, repeat capture/encryption, decrypt, load private inputs, invoke a sender/provider, operate Root continuity or issue any grant.

## Exact actual operation and Root binding

Actual Root tool `0d52a8` returned exit0 in0.41248659 seconds, without a running session. The terminal state is `TEST_ONLY_POSITIVE_CAPTURE_CONTROL_QUALIFIED`, with one entered capture and six PASS controls.

The current Root selection is7,295 bytes/SHA-256 `cd7d33ca9d99260373de616ec07a6388d7e4854902bbf509810b7094f85446e3`. It binds source-review seal `a0765769b981eb93923acf1a995a93906e3ec91cce78bc2a054e6c9d685d19b8`, its mandatory integer-projection correction, source seal `e6ee9480…`, and exact invocation `b603bf9523bb4809d98946d24d7f324000dc5355a4bcace1d284dc3e069a012f`.

`ACTUAL_INVOCATION_TOOL_CALL.json` is2,699 bytes/SHA-256 `4d540c45f44930455b56f36e20cb64d5a2c8e7a75c7bd511120dd7df89e8307f`. It retains the actual tool arguments and returned object together. The command equals the selected shell command, parsed argv equals the selected argv, and working directory is exact. Root preflight `52b607/0` joins that invocation and records16 source members received plus output absence. Currentness `ba3ef3/0` joins the selection's G0011 receipt; no controller operation was performed by this reviewer.

Fresh independent receiving `0971f2`, exit0, produced `VERIFICATION.json`:107,726 bytes/SHA-256 `99aae43fa3e8023fd0b935b5e8c4c694d61eb003e69cb446462da0c527f0c93d`. Its exact command and complete tool return are retained. JSON was parsed directly in Python with exact integers and duplicate-key rejection. No rounded derivative was substituted for actual inode or nanosecond evidence.

## Complete retained output population

The owned0700 output directory is `/workspace/scratch/530bc07ea12b/g132-positive-public-control-r2/one-time-output`. It contains exactly eight regular one-link owned0600 evidence files,28,244 bytes total, without xattrs or unexpected members. Every file was received through a stable no-follow read; all retained identity joins and descriptors are in the verification.

| Output | Bytes | SHA-256 |
|---|---:|---|
| `PROBE_INTENT.json` |9,935| `5d5cada8ffea56156fb8dce697b7677c2913289dc878c1b4194e6e42fdfb2678` |
| `CAPTURE_INTENT.json` |4,851| `62ead4e99d2ca55a614ba4a6ae1cebcacf908999e0a0232a3b051bf0fdde5202` |
| `SENDER_CAPTURE_OWNER.json` |6,113| `b0c79dad93e5cb8f1193de334ba0bce7f399be03e5081eacc309e05a7336cf71` |
| `PUBLIC_CIPHER.bin` |819| `1abfcc81cc12cd72a1408c7fd80ce6f533da04805bb3b5f888bb4cc34d12b1f8` |
| `STDOUT.bin` |0| `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `STDERR.bin` |0| `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `CAPTURE_RETURN.json` |2,381| `127bbf8f416b36b7122864a33087ef131743494df8c44f36750e1aa4b1633969` |
| `PROBE_RESULT.json` |4,145| `365287532d1562b64b99b70af43eff80460024b7f8fa302d4f9ddeedb38fe974` |

The terminal's exact result descriptor matches the durable result bytes. The result's cipher descriptor matches the retained cipher. The captured stream descriptors, original owner descriptors, capture row and both retained stream files agree. Empty streams are actual retained files, not reconstructed placeholders.

## Independent control findings

| Predicate | Finding | Actual joined evidence |
|---|---|---|
| PC01 — dedicated identity and source | PASS | UID/EUID/GID/EGID1000; owner PID2 matches proc-stat, NSpid/NStgid, one task/thread; SIGCHLD default. Actual Python3.12.14 and interpreter path join the exact executable. Source, selection, installation index, loader, nine modules, maintained bodies, tools and eight history pins are exact. |
| PC02 — active subreaper and restoration | PASS | Previous flag0, two active readbacks1, final readback0. The original owner's flag-restored state changes false→true and its subreaper restoration flag is true. This is tied to the unchanged original constructor/close source, not a GET-only standalone capability check. |
| PC03 — one native capture and complete streams | PASS | One capture; primary PID5; process-started and pidfd-acquired true; command exit0; exec errno/internal failure/close error absent. No timeout or output overflow; complete joined stdout/stderr. Natural quiescence and all-child ECHILD are recorded. |
| PC04 — original three-FD/input custody | PASS | Exact held FDs5/7/9 for public plaintext/certificate/cipher. Each is an original owned regular one-link0600 file whose identity joins the owner's descriptor snapshots. The fixed command uses those paths only; literal39-byte plaintext and1,939-byte public certificate match initial and final input descriptors. Cipher starts empty. |
| PC05 — public positive command/cipher | PASS | Command exit0, actual empty streams, nonempty819-byte retained cipher, and independent exact outer DER ContentInfo/container checks for OID1.2.840.113549.1.9.16.1.23. The cipher hash joins the actual terminal-bound result. |
| PC06 — original closure, file cleanup and currentness | PASS | Original `closed()` true before held-file cleanup; all six owner restoration fields true. All three held files have identity-confirmed unlink and descriptor-close records and are now absent. Final descriptors equal initial descriptors0/1/2; masks/handlers restored, ECHILD true, output-directory descriptor closed and final source-currentness true. |

The PID/FD values are actual local observations from the retained operation, not provider identifiers. Owner elapsed capture time is53,659,213 ns; selected command/enclosing limits remain10/15 seconds with the original three-second closing reservation. The retained operation terminated naturally and used zero forced pidfd signals; this control does not exercise a live-descendant forced-cleanup refusal.

## Source, history and integer closure

The actual opening records for source, selection, index, loader, tools, maintained source and all eight history dependencies equal fresh independent records, including their exact large-integer identities and ancestor identities. The maintained owner AST remains `ef5d9af63757b3fcda8d76f90567c66e9d61bba32a7251ccd8873acc1b16be1f`; the current executable remains30,894,944 bytes/SHA `fa674435…`, Python3.12.14.

The original historical public result remains0600 under its explicit evidence-reader class. Actual failed positive return `cd895e/1`, its consumed selection, the independent source-readiness correction, and prior failed-invalid-certificate evidence are preserved. The source-review integer-projection correction remains bound by the new Root selection. The successful r2 operation does not rewrite either earlier failure or restore the earlier erroneous source-ready conclusion for its predecessor.

## Qualification boundary

This receiving supports one actual public fixture encryption and the outer AuthEnvelopedData DER type with the stated native/file/source closure. The DER parser does not verify decrypted plaintext, recipient private-key possession, or the AEAD tag; no such operation was performed. The evidence is the exact selected tool call plus source-generated original-owner records and current file joins; no independent kernel audit trace or provider attestation is claimed.

Original private sender admission/execution, original one-encryption/18-read population, G1, G3, both original Root decisions, JOIN/recomputation, full original receiving and the fresh protected safeguard remain separate. All original awards stay empty. Protected301/625f UNKNOWN_NO_REPLAY history is unchanged. No retry, cleanup, mode change or provider/controller effect was made by this reviewer.
