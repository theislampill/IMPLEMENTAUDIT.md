# Installer I1 successor: independent receiving

**Technical disposition: I1_CORRECTION_RECEIVED_AT_PUBLIC_FILESYSTEM_SOURCE_SCOPE. Authority NONE.** The received r2 source and retained controls address the specific episode/receipt identity gap. No remaining I1 blocker was found within this bounded source/control scope. This is not an original installation, audit verdict, Root issuance, original G1/G3 award, or whole-path qualification.

## Exact packet and receiving

The source seal is `/workspace/scratch/530bc07ea12b/g132-late-installer-custody-r2/MANIFEST.json`, SHA-256 `f74e296836aa0c849f5b1431bcc67b335caddd4b8e7054503460d01b05980ade`: 160 files, 129,597 bytes. Every member, descriptor and exact file population was independently received using stable no-follow reads. The source is 18,469 bytes, SHA-256 `d7b87577b2e32ef797a5f2abab565b201603290e8c30d62a2837d25aca6dd16a`.

Fresh receiving `e77f9f`, exit 0, produced `VERIFICATION.json`: 79,546 bytes, SHA-256 `e97b61618ff3f6a0f2580f0b714d0a4546b76f677ee933a01fc177f41d74467f`. The command and complete returned object are retained in `RECEIVING_TOOL_RETURN.json`. This reviewer parsed sources as data and did not import or execute the installer, original Runtime, private assembler, sender, native capture, or provider.

## Correction and unchanged boundary

The old15,073-byte source52a497c8 remains exact. Recomputing its unified diff against r2 reproduces `SOURCE_PATCH.patch` byte-for-byte. All old functions except `install_tree` and `install_selected` remain AST-identical. `install_tree` changes only by returning its original episode identity. The `install_selected` prefix through `receipt['interface']` remains identical, including the received Root configuration, real recipient joins, five late bodies, eleven pinned private-input selections, original assembly call, deadlines, source currentness and the preassembly `lexists` refusal. The module imports, constants, CLI and source-loading predicates remain unchanged.

Three new helpers complete the custody join. `receipt_episode_current` compares the held descriptor and owned canonical pathname with the original episode identity. `receive_installed_tree` opens the assembled tree through that descriptor, joins every received directory identity, complete file body/mode/identity and exact population, and repeats closing path/descriptor checks. `write_received_receipt` holds the episode descriptor across exclusive receipt creation, receipt readback and fsync, then repeats complete tree receiving, receipt identity readback, deadline and final episode identity checks before returning success. Every acquired descriptor closes through a finally block, including refusal paths. Partial receipts remain for reconciliation.

The actual pinned `current_interfaces.py` source remains19,976 bytes/SHA2f5fdf50, and its existing load-runtime reader predicates are satisfied by current owned, no-alias, one-link, mode0444 custody. No original runtime was loaded to make that observation.

## Retained controls reconciled with surviving files

| Control | Actual retained result | Independently received surviving state |
|---|---|---|
| Old source, episode replacement | `1dafe0/1`, expected RED | Incorrect success and a receipt in the replacement; selected assembled tree absent, original tree retained under the moved directory. |
| r2, episode replacement | `07496d/0` | `RECEIPT_EPISODE_IDENTITY_CHANGED`; no receipt in the replacement; moved original tree retained. |
| r2, assembled-tree replacement | `595cd2/0` | `FileNotFoundError` opening missing `packet`; no receipt. This is preserved as the actual early refusal, not relabeled an identity-code outcome. |
| r2, rename during receipt write | `5ee8f7/0` | Closing `RECEIPT_EPISODE_IDENTITY_CHANGED`; no selected-path receipt, partial receipt retained only in the moved original. Its episode and complete tree identities join that original directory. |
| r2, unchanged path | `bb4a87/0` | Successful local receipt; selected episode, assembled tree, every recorded member identity/body/mode, directory population and receipt descriptor all join. |
| Existing eight controls | `35095c/0` | Eight passing retained filesystem tests; unchanged test source SHA7ff53328. No rerun by this reviewer. |

All five control result JSONs join their retained tool terminal fields, exact tested source descriptors and complete retained-file inventories. Every retained descriptor and all receipt/tree identity joins were checked. The eleven bodies per test are explicit public literals `PUBLIC_TEST_ONLY:0` through10, not original private inputs.

The discriminator executes the real installer `install_selected` path and real filesystem operations under an explicitly declared public fixture. Metadata, source admissibility, recipient reception and original assembly are substituted with public-data facades. Replacement points are deterministic hooks in that fixture, including a wrapper around receipt writing; they perform actual directory moves. This validates the bounded filesystem counterexamples and corrective behavior. It does not authenticate a real recipient, Root selection, private assembly, or arbitrary concurrent schedules. Retained tool results are received as the commissioned execution evidence; they are not independent backend attestations.

## Handoff limits

I1 is addressed in this exact successor. Its new source identity and closing checks still require Root receiving for any actual original installation. No private body, sender, crypto/native operation, provider, controller or grant was used by this reviewer. No source/evidence mode or historical packet was changed. The positive-control mode failure and its successor remain separate. Original awards remain empty and the larger finalizer remains outside this review.
