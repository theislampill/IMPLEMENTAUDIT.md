"""Read-only independent receiving of the public I1 successor packet."""
import ast
import difflib
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat

ROOT = Path('/workspace/scratch/530bc07ea12b')
BASE = ROOT / 'g132-late-installer-custody-r2'
OUT = ROOT / 'g132-installer-r2-independent-review'
records = []


def desc(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def stamp(s):
    return [s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns]


def directory_stamp(s):
    return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid]


def read(path, pin=None):
    path = Path(path)
    assert path.is_absolute() and path.resolve(strict=True) == path
    assert not any(p.is_symlink() for p in path.parents)
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    fd = os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK)
    try:
        assert stamp(os.fstat(fd)) == stamp(before) and not os.listxattr(fd)
        raw = os.pread(fd,before.st_size+1,0)
        assert len(raw) == before.st_size
        assert stamp(os.fstat(fd)) == stamp(before) == stamp(path.lstat())
    finally:
        os.close(fd)
    if pin is not None:
        assert all(desc(raw)[k] == v for k,v in pin.items() if k in ('bytes','sha256')), str(path)
    records.append(dict(path=str(path),**desc(raw),identity=stamp(before),mode=oct(stat.S_IMODE(before.st_mode))))
    return raw


manifest = json.loads(read(BASE/'MANIFEST.json',{'sha256':'f74e296836aa0c849f5b1431bcc67b335caddd4b8e7054503460d01b05980ade'}))
assert manifest['count'] == 160 and manifest['bytes'] == 129597
names = {r['path'] for r in manifest['files']}
assert len(names) == 160 and sum(r['bytes'] for r in manifest['files']) == 129597
bodies = {}
for row in manifest['files']:
    p = PurePosixPath(row['path'])
    assert str(p) == row['path'] and not p.is_absolute() and '..' not in p.parts
    bodies[row['path']] = read(BASE/row['path'],row)
all_paths = list(BASE.rglob('*'))
assert not any(p.is_symlink() for p in all_paths)
assert {str(p.relative_to(BASE)) for p in all_paths if p.is_file()} == names | {'MANIFEST.json'}
identities = json.loads(bodies['SOURCE_IDENTITIES.json'])
old = read(identities['input_source']['path'],identities['input_source'])
source = bodies['late_sender_install.py']
assert desc(source) == identities['new_source'] == {'bytes':18469,'sha256':'d7b87577b2e32ef797a5f2abab565b201603290e8c30d62a2837d25aca6dd16a'}
review = read(identities['review']['path'],identities['review'])
patch = ''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),source.decode().splitlines(keepends=True),
    fromfile='received-v1/late_sender_install.py',tofile='custody-r2/late_sender_install.py'))
assert patch.encode() == bodies['SOURCE_PATCH.patch']
old_ast, new_ast = ast.parse(old), ast.parse(source)
old_defs = {n.name:n for n in old_ast.body if isinstance(n,ast.FunctionDef)}
new_defs = {n.name:n for n in new_ast.body if isinstance(n,ast.FunctionDef)}
assert set(new_defs)-set(old_defs) == {'receipt_episode_current','receive_installed_tree','write_received_receipt'}
unchanged=[]
for name in old_defs:
    if name not in ('install_tree','install_selected'):
        assert ast.dump(old_defs[name],include_attributes=False) == ast.dump(new_defs[name],include_attributes=False)
        unchanged.append(name)
for module in (old_ast,new_ast):
    assert not any(isinstance(n,(ast.ClassDef,ast.AsyncFunctionDef)) for n in module.body)
old_nonfunc = [n for n in old_ast.body if not isinstance(n,ast.FunctionDef)]
new_nonfunc = [n for n in new_ast.body if not isinstance(n,ast.FunctionDef)]
assert ast.dump(ast.Module(body=old_nonfunc,type_ignores=[]),include_attributes=False) == ast.dump(ast.Module(body=new_nonfunc,type_ignores=[]),include_attributes=False)
for n in ast.walk(new_defs['install_tree']):
    if isinstance(n,ast.Return):
        assert isinstance(n.value,ast.Call)
        n.value.keywords=[k for k in n.value.keywords if k.arg!='episode_identity']
assert ast.dump(old_defs['install_tree'],include_attributes=False) == ast.dump(new_defs['install_tree'],include_attributes=False)
def selected_prefix(n):
    index=next(i for i,x in enumerate(n.body) if isinstance(x,ast.Assign) and ast.unparse(x.targets[0])=="receipt['interface']")
    return ast.dump(ast.Module(body=n.body[:index+1],type_ignores=[]),include_attributes=False)
assert selected_prefix(old_defs['install_selected']) == selected_prefix(new_defs['install_selected'])
interface = Path('/workspace/scratch/530bc07ea12b/g132-execution-readiness/current_interfaces.py')
read(interface,{'bytes':19976,'sha256':'2f5fdf5021df1db83320d286828898cfdbaaebe13e41acc7716329306f1fbe06'})
s=interface.lstat();assert s.st_uid==os.geteuid() and stat.S_IMODE(s.st_mode) in (0o400,0o444)

cases = [
    ('red_episode_replacement','RED_TOOL_RETURN.json','1dafe0',1,True,True,False),
    ('green_episode_before_receipt','episode_before_receipt_TOOL_RETURN.json','07496d',0,False,False,False),
    ('green_tree_before_receipt','tree_before_receipt_TOOL_RETURN.json','595cd2',0,False,False,False),
    ('green_episode_during_receipt','episode_during_receipt_TOOL_RETURN.json','5ee8f7',0,False,False,True),
    ('green_no_replacement','no_replacement_TOOL_RETURN.json','bb4a87',0,True,True,False)]
outcomes=[]
for name,tool_name,chunk,exit_code,success,selected_receipt,moved_receipt in cases:
    base=BASE/name;result=json.loads(bodies[name+'/RESULT.json']);tool=json.loads(bodies[tool_name])
    assert tool['chunk_id']==chunk and tool['exit_code']==exit_code
    terminal=json.loads(tool['output'])
    assert all(result[k]==v for k,v in terminal.items())
    assert result['returned_success'] is success
    assert result['selected_episode_receipt_exists'] is selected_receipt
    assert result['moved_original_receipt_exists'] is moved_receipt
    assert result['source']==dict(path=identities['input_source']['path'],**desc(old)) if name.startswith('red_') else result['source']==dict(path=str(BASE/'late_sender_install.py'),**desc(source))
    selected=base/'episode';moved=base/'moved_original_episode'
    assert os.path.lexists(selected/'SOURCE_INSTALL_RECEIPT.json') is selected_receipt
    assert os.path.lexists(moved/'SOURCE_INSTALL_RECEIPT.json') is moved_receipt
    assert (selected/'assembled').is_dir() is result['selected_assembled_exists']
    retained={r['path']:r for r in result['retained_files']}
    assert len(retained)==len(result['retained_files'])
    actual={str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
    assert actual==set(retained)|{'RESULT.json'}
    for n,row in retained.items():assert desc(bodies[name+'/'+n])=={k:row[k] for k in ('bytes','sha256')}
    config=json.loads(bodies[name+'/PUBLIC_TEST_ONLY_CONFIG.json'])
    assert config['context']=={'TEST_ONLY':True} and len(config['private_inputs'])==11
    for i in range(11):
        n=f'PUBLIC_INPUT_{i:02d}.json';ref=config['private_inputs'][n]
        assert ref['path']==str(base/'PUBLIC_TEST_ONLY_ELEVEN_INPUTS'/n)
        raw=bodies[name+'/PUBLIC_TEST_ONLY_ELEVEN_INPUTS/'+n]
        assert json.loads(raw)=={'PUBLIC_TEST_ONLY':i} and desc(raw)=={k:ref[k] for k in ('bytes','sha256')}
    for k in ('original_runtime_loaded','original_assembler_called','original_private_inputs_read'):assert result[k] is False
    assert result['native_capture_calls']==result['provider_calls']==0 and result['original_awards']==[]
    if selected_receipt or moved_receipt:
        rp=(selected if selected_receipt else moved)/'SOURCE_INSTALL_RECEIPT.json'
        receipt=json.loads(bodies[str(rp.relative_to(BASE))])
        tree=(moved/'assembled') if name in ('red_episode_replacement','green_episode_during_receipt') else selected/'assembled'
        if success:assert result['result']['receipt']==dict(path=str(rp),**desc(bodies[str(rp.relative_to(BASE))]))
        assert {str(p.relative_to(tree)) for p in tree.rglob('*') if p.is_file()}==set(receipt['members'])
        for member,record in receipt['members'].items():
            p=tree/member;raw=bodies[str(p.relative_to(BASE))];st=p.lstat()
            assert desc(raw)=={k:record[k] for k in ('bytes','sha256')}
            assert record['identity']==stamp(st) and record['mode']==stat.S_IMODE(st.st_mode)
        for d,identity in receipt['directories'].items():assert directory_stamp((tree/d).lstat())==identity
        if 'episode_identity' in receipt:
            assert receipt['episode_identity']==directory_stamp((selected if selected_receipt else moved).lstat())
        if name=='red_episode_replacement':assert not (selected/'assembled').exists() and 'episode_identity' not in receipt
        if name=='green_episode_during_receipt':assert receipt['episode_identity']!=directory_stamp(selected.lstat())
    outcomes.append(dict(case=name,actual_tool=chunk,exit_code=exit_code,returned_success=success,
        selected_receipt=selected_receipt,moved_receipt=moved_receipt,exception=result['exception'],retained_files=len(retained)))
regression=json.loads(bodies['REGRESSION_TOOL_RETURN.json'])
assert regression['chunk_id']=='35095c' and regression['exit_code']==0
assert 'Ran 8 tests' in regression['output'] and regression['output'].count(' ... ok\n')==8
assert desc(bodies['test_late_sender_install.py'])['sha256']=='7ff53328f500963b4580532dc6686bfcb83725d0e76960f7767e1f9390ecadc1'
result=dict(schema='g132.installer-i1-r2-independent-receiving.v1',authority='NONE',
    technical_disposition='I1_CORRECTION_RECEIVED_AT_PUBLIC_FILESYSTEM_SOURCE_SCOPE',
    source=desc(source),manifest=desc((BASE/'MANIFEST.json').read_bytes()),
    exact_manifest_population=160,exact_source_diff=True,unchanged_functions=unchanged,
    original_input_and_admission_prefix_unchanged=True,interface_runtime_reader_predicates_met=True,
    retained_controls=outcomes,retained_regression_count=8,
    target_source_imported_or_executed=False,private_original_bodies_read=0,
    native_capture_calls=0,encryption_calls=0,provider_calls=0,original_awards=[],records=records)
raw=(json.dumps(result,indent=2,sort_keys=True)+'\n').encode();p=OUT/'VERIFICATION.json'
fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_CLOEXEC,0o444)
try:assert os.write(fd,raw)==len(raw);os.fsync(fd)
finally:os.close(fd)
assert p.read_bytes()==raw
print(json.dumps(dict(state=result['technical_disposition'],authority='NONE',verification=dict(path=str(p),**desc(raw)),
    manifest_members=160,received_controls=5,received_regressions=8,target_source_imported_or_executed=False,original_awards=[])))
