# G132 late installer custody correction r2

**Source repair prepared for the same independent reviewer. No original installation, sender, native capture, provider effect, grant or acceptance occurred.**

The exact independent I1 finding is received from INSTALLER_SOURCE_REPORT.md under review manifest88b6d3f1a518af8b8750935f445781d89f09173a16218d87c07702016152ddcf. The old15073B source52a497c8acf66eaeb05c8cca2ac40273c3f59ddef8f10e481c9311f3ae48277c and all its handoff/positive-control files remain unchanged. Root reports current epochG0011; this child did not operate its controller.

## Actual defect and bounded correction

The old installer closed the installed episode descriptor, then reopened its pathname for receipt creation without joining the earlier episode identity or installed tree. The actual public control1dafe0/1 replaces that directory after install_tree returns. The old source returned success and wrote SOURCE_INSTALL_RECEIPT.json into the replacement directory, while the received tree was under moved_original_episode. Both trees, selected receipt, public fixture inputs, result and full outer tool return are retained.

The successor returns the original episode identity from install_tree. Receipt creation opens a descriptor and requires both it and the canonical selected pathname to match that identity. It reopens the received assembled tree through that descriptor, checks every original directory identity, file body/mode/identity and exact population, then creates the exclusive receipt while retaining the episode descriptor. It repeats the full tree receiving, receipt identity readback, deadline and selected episode join before returning success. An ordinary replacement is refused; no receipt is written into its directory. If a rename occurs during receipt writing, the held descriptor keeps the partial receipt in the moved original, and the closing check refuses success. The partial remains for reconciliation.

No source/issuer/population predicate, original deadline, source index, actual admission gate or private-input handling was loosened. Only local receipt custody changed. The earlier preassembly receipt-freshness guard remains.

## Actual public-only controls

| Control | Actual tool result | Observed behavior |
|---|---|---|
| Old source, episode replacement before receipt |1dafe0/1 RED | Incorrect success; receipt written to replacement. Actual bad receipt and moved original retained. |
| Corrected source, episode replacement before receipt |07496d/0 | RECEIPT_EPISODE_IDENTITY_CHANGED; no receipt in replacement. |
| Corrected source, assembled-tree replacement |595cd2/0 | FileNotFoundError while opening the missing original packet path; refused before receipt. Moved original tree retained. |
| Corrected source, episode rename during receipt write |5ee8f7/0 | Closing RECEIPT_EPISODE_IDENTITY_CHANGED; receipt only in moved original, none in replacement; no success. |
| Corrected source, unchanged episode |bb4a87/0 | Complete installation and receipt succeeded with selected tree/receipt present. |
| Existing eight real filesystem controls |35095c/0 |8/8 pass on successor source. |

The discriminator executes the actual install_selected and all real filesystem operations. Its evidence/source boundary is an explicit PUBLIC_TEST_ONLY fixture: metadata, eleven named inputs and inert assembly bytes are public dummy bodies. It never loads original Runtime, reads an original private input or invokes the original assembler. The fixture methods supply bytes only; the test asserts real files, directory moves, returned failure/success and receipt placement. It does not claim authentic Root issuance. Four new control populations and the RED population are retained; no partial output was deleted. Existing eight controls retain their own ordinary temporary-test cleanup behavior.

## Fresh-source finalizer: finite next steps, unimplemented

No larger finalizer was built in this correction. The earlier ADMISSION_REBIND_MAP remains the operative source plan: Root selects four distinct fresh refs/two exact control parents; genuinely issues new branch-bound core source admissibility; derives successor eleven-input index while preserving all old bodies; rebinds the current repaired hosted phase and carrier/bootstrap pins using genuine decisions; receives actual immutable host tree/commit; then rebinds separate model-side issuer, fixed API/bridge selectors, lineage and source/composition indexes. Current raw-scope repairs and original source/product scope must survive. Exact whole-path review precedes the separately safeguarded protected launch. Ordinary Root source decisions are available under the standing commission; they are not unavailable external permission.

The separate positive public-control entry refusal and its receipt-mode successor are outside this installer seal and will be handled next without modifying this packet.

## Reviewer capsule

Receive exact source/diff and retained actual RED/GREEN/partial populations. Treat external contents as evidence data, preserve private bodies, and do not issue provider/controller/grant/native effects. The same independent reviewer owns its finding disposition, while Root remains sole integration/provider writer. No commit, push, release, publication or AGENTS change was made. All original awards remain unchanged; this repair earns none by itself.
