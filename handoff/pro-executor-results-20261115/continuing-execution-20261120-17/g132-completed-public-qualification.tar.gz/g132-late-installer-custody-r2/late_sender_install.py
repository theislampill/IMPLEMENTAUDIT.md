#!/usr/bin/env python3
"""Exact local late-source assembly/install; no issuer, sender or provider calls.

Actual Root provenance is received outside this byte interface. Existing and
partial destinations refuse replay. Source-generation pins remain literal.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import time
import types

INTERFACE = Path('/workspace/scratch/530bc07ea12b/g132-execution-readiness/current_interfaces.py')
INTERFACE_PIN = {'bytes':19976, 'sha256':'2f5fdf5021df1db83320d286828898cfdbaaebe13e41acc7716329306f1fbe06'}
INSTALLATION_SHA = '58a831b74aec61df5f159ca72cc5c54bc2d50c13f0aea78651bdfe48f0d8e983'
FIELDS = {'schema','state','purpose','installation_index_sha256','context',
          'input_root','private_input_root','recipient','late_inputs',
          'private_inputs','episode','deadline_unix_ms'}
LATE_NAMES = {'ROOT_SENDER_ASSEMBLY_SELECTION.json','PRO_SENDER_OPERATION.json',
              'PRO_SENDER_ADMISSION.json','ROOT_REQUEST_ARTIFACT.zip',
              'HOST_PUBLICATION_ROOT_RECEIVING.json'}
MANIFEST_NAME = 'ROOT_SENDER_INSTALL_MANIFEST.json'
MAX_BYTES = 8 * 1024**2


def need(value, code):
    if not value: raise ValueError(code)


def descriptor(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def encode(value):
    return (json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()


def parse(raw):
    def pairs(rows):
        out={}
        for key,value in rows:
            need(key not in out,'DUPLICATE_KEY');out[key]=value
        return out
    need(type(raw) is bytes and 0<len(raw)<=MAX_BYTES,'BOUNDED_JSON')
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _:need(False,'NONFINITE'))


def stamp(s):
    return (s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns)


def directory_stamp(s):
    return (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid)


def owned_episode(path):
    p=Path(path)
    need(p.is_absolute() and str(p)==str(path) and '..' not in p.parts
         and p.resolve(strict=True)==p and not any(x.is_symlink() for x in (p,*p.parents)),
         'CANONICAL_EPISODE')
    st=p.lstat()
    need(stat.S_ISDIR(st.st_mode) and st.st_uid==os.geteuid()
         and st.st_gid==os.getegid() and stat.S_IMODE(st.st_mode)==0o700
         and not os.listxattr(p),'OWNED_PRIVATE_EPISODE')
    return p,st


def current_deadline(deadline):
    now=time.time_ns()//1000000
    need(type(deadline) is int and now<deadline<=now+600000,'LATE_INSTALL_DEADLINE')


def validate_tree(episode,files):
    need(type(files) is dict and 0<len(files)<=256 and MANIFEST_NAME in files
         and all(type(n) is str and type(b) is bytes and 0<len(b)<=1024**2 for n,b in files.items())
         and sum(map(len,files.values()))<=MAX_BYTES,'BOUNDED_ASSEMBLY_POPULATION')
    for name in files:
        p=PurePosixPath(name)
        need(str(p)==name and not p.is_absolute() and '..' not in p.parts
             and '\0' not in name and '\\' not in name,'CANONICAL_MEMBER_PATH')
    manifest=parse(files[MANIFEST_NAME])
    need(manifest.get('schema')=='dg16.late-root-sender-install-manifest.v1'
         and manifest.get('authority')=='NONE' and manifest.get('original_awards')==[]
         and manifest.get('fixed_packet_directory')==str(episode/'assembled/packet')
         and manifest.get('directories_mode')==0o700 and manifest.get('public_file_mode')==0o400
         and manifest.get('private_file_mode')==0o600 and manifest.get('host_manifest_unchanged') is True
         and manifest.get('late_currentness')=='ACTUAL_SENDER_POLICY_PROVIDER_REQUEST_AND_TOOLS_REQUIRED',
         'ORIGINAL_INSTALL_MANIFEST_SCOPE')
    need(type(manifest.get('sender_uid')) is int and type(manifest.get('sender_gid')) is int
         and manifest['sender_uid']==os.getuid()==os.geteuid()>0
         and manifest['sender_gid']==os.getgid()==os.getegid(),'ACTUAL_INSTALL_NONROOT_IDENTITY')
    need(manifest.get('members')=={n:descriptor(b) for n,b in files.items() if n!=MANIFEST_NAME},
         'EXACT_ASSEMBLY_POPULATION')
    all_paths={PurePosixPath(n) for n in files}
    need(not any(parent in all_paths for p in all_paths for parent in p.parents),
         'ASSEMBLY_FILE_DIRECTORY_COLLISION')
    return manifest


def write_file(parent,name,raw,mode):
    fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=parent)
    try:
        offset=0
        while offset<len(raw):
            count=os.write(fd,raw[offset:]);need(count>0,'WRITE_PROGRESS');offset+=count
        os.fchmod(fd,mode);os.fsync(fd)
    finally: os.close(fd)


def read_installed(parent,name,raw,mode):
    before=os.stat(name,dir_fd=parent,follow_symlinks=False)
    need(stat.S_ISREG(before.st_mode) and before.st_nlink==1
         and before.st_uid==os.geteuid() and before.st_gid==os.getegid()
         and stat.S_IMODE(before.st_mode)==mode and before.st_size==len(raw),'INSTALLED_FILE_CUSTODY')
    fd=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC,dir_fd=parent)
    try:
        need(stamp(os.fstat(fd))==stamp(before) and not os.listxattr(fd),'INSTALLED_FILE_OPEN_CHANGED')
        actual=os.pread(fd,len(raw)+1,0)
        need(actual==raw and stamp(os.fstat(fd))==stamp(before)
             ==stamp(os.stat(name,dir_fd=parent,follow_symlinks=False)),'INSTALLED_FILE_READBACK')
    finally: os.close(fd)
    return dict(descriptor(actual),mode=mode,identity=list(stamp(before)))


def install_tree(episode,files,deadline):
    """Write only an already validated assembly; production caller is below."""
    episode,before=owned_episode(episode);current_deadline(deadline)
    manifest=validate_tree(episode,files)
    output=episode/'assembled'
    need(not os.path.lexists(output),'FRESH_ASSEMBLY_REQUIRED')
    parent=os.open(episode,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
    dirs={};identities={}
    try:
        need(directory_stamp(os.fstat(parent))==directory_stamp(before),'EPISODE_OPEN_CHANGED')
        os.mkdir('assembled',0o700,dir_fd=parent)
        root=os.open('assembled',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent)
        dirs['']=root;identities['']=directory_stamp(os.fstat(root))
        names={str(p) for n in files for p in PurePosixPath(n).parents if str(p)!='.'}
        for name in sorted(names,key=lambda x:(len(PurePosixPath(x).parts),x)):
            p=PurePosixPath(name);up='' if str(p.parent)=='.' else str(p.parent)
            os.mkdir(p.name,0o700,dir_fd=dirs[up])
            fd=os.open(p.name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=dirs[up])
            dirs[name]=fd;identities[name]=directory_stamp(os.fstat(fd))
        for name,raw in sorted(files.items()):
            current_deadline(deadline)
            p=PurePosixPath(name);up='' if str(p.parent)=='.' else str(p.parent)
            mode=0o600 if name.startswith('packet/private-inputs/') else 0o400
            write_file(dirs[up],p.name,raw,mode)
        for fd in dirs.values():os.fsync(fd)
        os.fsync(parent)
        members={}
        for name,raw in sorted(files.items()):
            p=PurePosixPath(name);up='' if str(p.parent)=='.' else str(p.parent)
            members[name]=read_installed(dirs[up],p.name,raw,
                0o600 if name.startswith('packet/private-inputs/') else 0o400)
        for name,fd in dirs.items():
            path=output/name
            need(directory_stamp(os.fstat(fd))==identities[name]==directory_stamp(path.lstat())
                 and not path.is_symlink() and not os.listxattr(fd),'INSTALLED_DIRECTORY_CHANGED')
            expected={p.parts[len(PurePosixPath(name).parts) if name else 0]
                      for p in (PurePosixPath(n) for n in files)
                      if not name or p.is_relative_to(PurePosixPath(name))}
            need(set(os.listdir(fd))==expected,'INSTALLED_DIRECTORY_POPULATION')
        need(directory_stamp(episode.lstat())==directory_stamp(before)
             and episode.resolve(strict=True)==episode,'EPISODE_CLOSING_CHANGED')
        current_deadline(deadline)
        return dict(schema='g132.late-source-install-readback.v1',authority='NONE',
            status='EXACT_LOCAL_ASSEMBLY_RECEIVED_REQUIRES_ROOT_RECEIVING',
            output_directory=str(output),installation_index_sha256=INSTALLATION_SHA,
            episode_identity=list(directory_stamp(before)),
            install_manifest=descriptor(files[MANIFEST_NAME]),members=members,
            directories={k:list(v) for k,v in sorted(identities.items())},
            sender_started=False,encryption_performed=False,provider_calls=0,
            automatic_retry=False,root_issuance_authentication='SEPARATE_ACTUAL_ROOT_PROVENANCE_REQUIRED',
            original_awards=[])
    finally:
        for fd in reversed(list(dirs.values())):os.close(fd)
        os.close(parent)


def receipt_episode_current(episode,parent,expected):
    """Bind the selected pathname and held descriptor to the received episode."""
    path,info=owned_episode(episode)
    need(directory_stamp(os.fstat(parent))==tuple(expected)==directory_stamp(info),
         'RECEIPT_EPISODE_IDENTITY_CHANGED')
    return path


def receive_installed_tree(episode,parent,files,receipt):
    """Rejoin every received directory, file and selected path under held custody."""
    episode=receipt_episode_current(episode,parent,receipt['episode_identity'])
    validate_tree(episode,files)
    names={str(p) for n in files for p in PurePosixPath(n).parents if str(p)!='.'}
    need(set(receipt['directories'])==names|{''} and set(receipt['members'])==set(files),
         'RECEIPT_TREE_POPULATION_CHANGED')
    dirs={}
    try:
        dirs['']=os.open('assembled',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent)
        for name in sorted(names,key=lambda x:(len(PurePosixPath(x).parts),x)):
            p=PurePosixPath(name);up='' if str(p.parent)=='.' else str(p.parent)
            dirs[name]=os.open(p.name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=dirs[up])
        for name,fd in dirs.items():
            path=episode/'assembled'/name
            need(directory_stamp(os.fstat(fd))==tuple(receipt['directories'][name])
                 ==directory_stamp(path.lstat()) and not path.is_symlink() and not os.listxattr(fd),
                 'RECEIPT_TREE_DIRECTORY_CHANGED')
        for name,raw in sorted(files.items()):
            p=PurePosixPath(name);up='' if str(p.parent)=='.' else str(p.parent)
            mode=0o600 if name.startswith('packet/private-inputs/') else 0o400
            need(read_installed(dirs[up],p.name,raw,mode)==receipt['members'][name],
                 'RECEIPT_TREE_FILE_CHANGED')
        for name,fd in dirs.items():
            path=episode/'assembled'/name
            expected={p.parts[len(PurePosixPath(name).parts) if name else 0]
                      for p in (PurePosixPath(n) for n in files)
                      if not name or p.is_relative_to(PurePosixPath(name))}
            need(set(os.listdir(fd))==expected,'RECEIPT_TREE_POPULATION_CHANGED')
            need(directory_stamp(os.fstat(fd))==tuple(receipt['directories'][name])
                 ==directory_stamp(path.lstat()) and not path.is_symlink() and not os.listxattr(fd),
                 'RECEIPT_TREE_CLOSING_CHANGED')
        receipt_episode_current(episode,parent,receipt['episode_identity'])
    finally:
        for fd in reversed(list(dirs.values())):os.close(fd)


def write_received_receipt(episode,files,receipt,deadline):
    """Keep the received episode descriptor through receipt creation and closure."""
    current_deadline(deadline)
    parent=os.open(episode,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        receive_installed_tree(episode,parent,files,receipt)
        current_deadline(deadline)
        raw=encode(receipt)
        write_file(parent,'SOURCE_INSTALL_RECEIPT.json',raw,0o400)
        first=read_installed(parent,'SOURCE_INSTALL_RECEIPT.json',raw,0o400)
        os.fsync(parent)
        receive_installed_tree(episode,parent,files,receipt)
        need(read_installed(parent,'SOURCE_INSTALL_RECEIPT.json',raw,0o400)==first,
             'RECEIPT_FILE_CLOSING_CHANGED')
        current_deadline(deadline)
        receipt_episode_current(episode,parent,receipt['episode_identity'])
        return {'path':str(episode/'SOURCE_INSTALL_RECEIPT.json'),**descriptor(raw)}
    finally:os.close(parent)


def load_runtime(packet):
    p=INTERFACE
    need(p.is_absolute() and p.resolve(strict=True)==p and not any(x.is_symlink() for x in p.parents),'INTERFACE_NONALIAS')
    before=p.lstat()
    need(stat.S_ISREG(before.st_mode) and before.st_nlink==1 and before.st_uid==os.geteuid()
         and stat.S_IMODE(before.st_mode) in (0o400,0o444),'INTERFACE_CUSTODY')
    fd=os.open(p,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK)
    try:
        need(stamp(os.fstat(fd))==stamp(before) and not os.listxattr(fd),'INTERFACE_OPEN_CHANGED')
        raw=os.pread(fd,INTERFACE_PIN['bytes']+1,0)
        need(descriptor(raw)==INTERFACE_PIN and stamp(os.fstat(fd))==stamp(before)==stamp(p.lstat()),'INTERFACE_PIN')
    finally:os.close(fd)
    m=types.ModuleType('g132_received_current_interfaces');m.__file__=str(p)
    exec(compile(raw,str(p),'exec'),m.__dict__)
    return m,m.load_runtime(packet)


def install_selected(interface,rt,config):
    need(type(config) is dict and set(config)==FIELDS
         and config['schema']=='g132.late-source-install-selection.v1'
         and config['state']=='ROOT_SELECTED_FOR_EXACT_LATE_SOURCE_INSTALL'
         and config['purpose']=='LOCAL_SOURCE_ASSEMBLY_ONLY'
         and config['installation_index_sha256']==INSTALLATION_SHA,'ACTUAL_ROOT_LOCAL_SELECTION_REQUIRED')
    current_deadline(config['deadline_unix_ms']);rt.current();s=rt.sources;s.context(config['context'])
    public=rt.entry.PublicInputs(config['input_root'])
    private=rt.entry.PublicInputs(config['private_input_root'])
    row=config['recipient']
    need(type(row) is dict and set(row)=={'results','archive','note'},'ACTUAL_RECIPIENT_SELECTION')
    results=interface.metadata_inputs(rt,public,row['results'])
    archive=public.body(row['archive'],65536);note=parse(public.body(row['note'],65536))
    received=s.receive_public('recipient',config['context'],results,archive,note)
    need(type(config['late_inputs']) is dict and set(config['late_inputs'])==LATE_NAMES,'EXACT_FIVE_REAL_LATE_BODIES')
    need(type(config['private_inputs']) is dict and set(config['private_inputs'])==set(s.input_index)
         and len(config['private_inputs'])==11,'EXACT_ELEVEN_PRIVATE_INPUT_SELECTIONS')
    late={name:public.body(ref,65536 if name=='ROOT_REQUEST_ARTIFACT.zip' else MAX_BYTES)
          for name,ref in config['late_inputs'].items()}
    need(late['ROOT_REQUEST_ARTIFACT.zip']==archive,'ACTUAL_RECIPIENT_ARCHIVE_JOIN')
    secret={name:private.body(ref,MAX_BYTES) for name,ref in config['private_inputs'].items()}
    need({name:descriptor(raw) for name,raw in secret.items()}==s.input_index,'EXACT_ORIGINAL_PRIVATE_BODIES')
    inputs=dict(late,**{'private-inputs/'+name:raw for name,raw in secret.items()})
    selected=parse(late['ROOT_SENDER_ASSEMBLY_SELECTION.json']);operation=parse(late['PRO_SENDER_OPERATION.json'])
    episode=s.work_root(Path(config['episode']))
    need(selected['fixed_packet_directory']==str(episode/'assembled/packet'),'ACTUAL_FIXED_SENDER_DESTINATION')
    need(not os.path.lexists(episode/'SOURCE_INSTALL_RECEIPT.json'),'FRESH_INSTALL_RECEIPT_REQUIRED')
    need(config['deadline_unix_ms']<=operation['expires_unix_ms'],'ORIGINAL_OPERATION_DEADLINE')
    files=s.assemble_sender_source(received,inputs)
    rt.current()
    receipt=install_tree(episode,files,config['deadline_unix_ms'])
    rt.current()
    for inp in (public,private):
        for path,pin in inp.pins.items():rt.entry.read(path,MAX_BYTES,pin)
    current_deadline(config['deadline_unix_ms'])
    receipt['recipient_receipt']=received['receipt']
    receipt['input_descriptors']={name:descriptor(raw) for name,raw in sorted(inputs.items())}
    receipt['interface']=INTERFACE_PIN
    received=write_received_receipt(episode,files,receipt,config['deadline_unix_ms'])
    return dict(schema='g132.late-source-install-terminal.v1',authority='NONE',
        status=receipt['status'],receipt=received,
        original_awards=[],sender_started=False,encryption_performed=False,provider_calls=0,automatic_retry=False)


def main():
    need(os.name=='posix' and sys.platform=='linux' and sys.flags.isolated
         and sys.dont_write_bytecode and sys.version_info[:2]==(3,12)
         and os.getuid()==os.geteuid()>0 and os.getgid()==os.getegid(),'DEDICATED_NONROOT_SOURCE_PROCESS')
    p=argparse.ArgumentParser();p.add_argument('command',choices=['check','install'])
    p.add_argument('--packet',required=True);p.add_argument('--configuration');p.add_argument('--configuration-sha256')
    args=p.parse_args();interface,rt=load_runtime(args.packet)
    if args.command=='check':
        need(args.configuration is None and args.configuration_sha256 is None,'NO_CHECK_INPUTS')
        result=dict(schema='g132.late-source-installer-check.v1',authority='NONE',state='UNISSUED',
            interface=INTERFACE_PIN,installation_index_sha256=INSTALLATION_SHA,
            private_inputs_read=False,sender_started=False,provider_calls=0,original_awards=[])
    else:
        need(type(args.configuration_sha256) is str and re.fullmatch('[0-9a-f]{64}',args.configuration_sha256)
             and args.configuration is not None,'ACTUAL_CONFIG_PIN_REQUIRED')
        raw=rt.entry.read(args.configuration,65536)
        need(descriptor(raw)['sha256']==args.configuration_sha256,'ACTUAL_CONFIG_PIN')
        result=install_selected(interface,rt,parse(raw))
    print(encode(result).decode(),end='');return 0


if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as exc:
        code=str(exc)
        print(encode(dict(schema='g132.late-source-install-refusal.v1',authority='NONE',
            status='REFUSED_OR_PARTIAL_PRESERVE_AND_RECONCILE_NO_RETRY',error_type=type(exc).__name__,
            error_code=code if re.fullmatch('[A-Z0-9_]{1,128}',code) else None,
            original_awards=[],automatic_retry=False)).decode(),end='')
        raise SystemExit(1)
