"""Only public TEST_ONLY files; no original private inputs or sender execution."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import tempfile
import time
import unittest

BASE = Path(__file__).resolve().parent


class InstallationTests(unittest.TestCase):
    def setUp(self):
        path = BASE / 'late_sender_install.py'
        self.assertTrue(path.is_file(), 'the missing ordinary late-source installer must exist')
        spec = importlib.util.spec_from_file_location('late_install_test', path)
        self.subject = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.subject)
        self.temp = tempfile.TemporaryDirectory(prefix='public-install-test-', dir=BASE)
        self.addCleanup(self.temp.cleanup)
        self.episode = Path(self.temp.name)
        self.episode.chmod(0o700)

    def packet(self):
        s = self.subject
        data = {'root_sender_entry.py': b'# PUBLIC TEST_ONLY inert source\n',
                'packet/carrier/PRO_SENDER_OPERATION.json': b'{"TEST_ONLY":true}\n',
                'packet/private-inputs/PUBLIC.json': b'{"PUBLIC_TEST_ONLY":true}\n'}
        manifest = dict(schema='dg16.late-root-sender-install-manifest.v1',
            authority='NONE', fixed_packet_directory=str(self.episode / 'assembled/packet'),
            sender_uid=os.geteuid(), sender_gid=os.getegid(), directories_mode=0o700,
            public_file_mode=0o400, private_file_mode=0o600,
            host_manifest_sha256='a' * 64, host_manifest_unchanged=True,
            late_currentness='ACTUAL_SENDER_POLICY_PROVIDER_REQUEST_AND_TOOLS_REQUIRED',
            members={n:s.descriptor(b) for n,b in data.items()}, original_awards=[])
        data['ROOT_SENDER_INSTALL_MANIFEST.json'] = s.encode(manifest)
        return data

    def install(self, data, **extra):
        return self.subject.install_tree(self.episode, data,
            time.time_ns() // 1000000 + 30000, **extra)

    def test_full_population_bytes_and_modes_are_received(self):
        data = self.packet()
        result = self.install(data)
        self.assertEqual(result['authority'], 'NONE')
        self.assertEqual(result['original_awards'], [])
        self.assertEqual(set(result['members']), set(data))
        for name, raw in data.items():
            p = self.episode / 'assembled' / name
            self.assertEqual(p.read_bytes(), raw)
            expected = 0o600 if name.startswith('packet/private-inputs/') else 0o400
            self.assertEqual(stat.S_IMODE(p.stat().st_mode), expected)
        for p in (self.episode / 'assembled').rglob('*'):
            if p.is_dir(): self.assertEqual(stat.S_IMODE(p.stat().st_mode), 0o700)

    def test_existing_destination_refuses_without_changing_original(self):
        data = self.packet()
        self.install(data)
        before = (self.episode / 'assembled/root_sender_entry.py').read_bytes()
        with self.assertRaisesRegex(ValueError, 'FRESH_ASSEMBLY_REQUIRED'):
            self.install(data)
        self.assertEqual((self.episode / 'assembled/root_sender_entry.py').read_bytes(), before)

    def test_manifest_mismatch_refuses_before_destination_creation(self):
        data = self.packet(); data['root_sender_entry.py'] += b'changed'
        with self.assertRaisesRegex(ValueError, 'EXACT_ASSEMBLY_POPULATION'):
            self.install(data)
        self.assertFalse((self.episode / 'assembled').exists())

    def test_path_escape_refuses_before_destination_creation(self):
        data = self.packet()
        manifest = self.subject.parse(data['ROOT_SENDER_INSTALL_MANIFEST.json'])
        data['../outside'] = b'PUBLIC TEST_ONLY'
        manifest['members']['../outside'] = self.subject.descriptor(data['../outside'])
        data['ROOT_SENDER_INSTALL_MANIFEST.json'] = self.subject.encode(manifest)
        with self.assertRaisesRegex(ValueError, 'CANONICAL_MEMBER_PATH'):
            self.install(data)
        self.assertFalse((self.episode / 'assembled').exists())

    def test_noncanonical_alias_refuses_before_destination_creation(self):
        data = self.packet(); manifest = self.subject.parse(data['ROOT_SENDER_INSTALL_MANIFEST.json'])
        data['packet//extra'] = b'PUBLIC TEST_ONLY'
        manifest['members']['packet//extra'] = self.subject.descriptor(data['packet//extra'])
        data['ROOT_SENDER_INSTALL_MANIFEST.json'] = self.subject.encode(manifest)
        with self.assertRaisesRegex(ValueError, 'CANONICAL_MEMBER_PATH'):
            self.install(data)
        self.assertFalse((self.episode / 'assembled').exists())

    def test_expired_operation_refuses_before_destination_creation(self):
        with self.assertRaisesRegex(ValueError, 'LATE_INSTALL_DEADLINE'):
            self.subject.install_tree(self.episode, self.packet(), time.time_ns() // 1000000 - 1)
        self.assertFalse((self.episode / 'assembled').exists())

    def test_wrong_nonroot_owner_refuses_before_destination_creation(self):
        data=self.packet(); m=self.subject.parse(data['ROOT_SENDER_INSTALL_MANIFEST.json'])
        m['sender_uid'] = 0
        data['ROOT_SENDER_INSTALL_MANIFEST.json']=self.subject.encode(m)
        with self.assertRaisesRegex(ValueError, 'ACTUAL_INSTALL_NONROOT_IDENTITY'):
            self.install(data)
        self.assertFalse((self.episode / 'assembled').exists())

    def test_symlinked_episode_is_rejected(self):
        alias=self.episode/'alias'; real=self.episode/'real'; real.mkdir(mode=0o700)
        alias.symlink_to(real, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, 'CANONICAL_EPISODE'):
            self.subject.install_tree(alias, self.packet(), time.time_ns()//1000000+30000)
        self.assertFalse((real/'assembled').exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)
