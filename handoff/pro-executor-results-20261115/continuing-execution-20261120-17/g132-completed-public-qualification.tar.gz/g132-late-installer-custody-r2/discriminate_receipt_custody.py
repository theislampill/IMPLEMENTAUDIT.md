"""Public TEST_ONLY boundary fixture; real installer file operations only.

No original runtime, private input, original assembler, sender, native capture,
provider, controller or grant is invoked. Source-admission facades supply public
inert bytes solely to enter the real install_selected filesystem sequence.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import time
import types


def desc(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def encode(v):return (json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode()
def save(p,b):
    with p.open('xb') as f:f.write(b)
    p.chmod(0o600)


def run(source,base,case):
    assert case in ('episode_before_receipt','tree_before_receipt','episode_during_receipt','no_replacement')
    base.mkdir(mode=0o700)
    episode=base/'episode';episode.mkdir(mode=0o700)
    public=base/'PUBLIC_TEST_ONLY_METADATA';public.mkdir(mode=0o700)
    private=base/'PUBLIC_TEST_ONLY_ELEVEN_INPUTS';private.mkdir(mode=0o700)
    source_raw=source.read_bytes()
    spec=importlib.util.spec_from_file_location('actual_installer_under_public_test',source)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    deadline=time.time_ns()//1000000+60000
    def ref(root,name,raw):
        p=root/name;save(p,raw);return {'path':str(p),**desc(raw)}
    metadata={k:ref(public,k+'.json',encode({'TEST_ONLY':True,'kind':k}))
              for k in ('run','attempt','jobs','artifact','artifacts','workflow')}
    artifact=ref(public,'ARTIFACT_NOT_REAL.zip',b'PUBLIC TEST_ONLY NOT AN ORIGINAL ARCHIVE\n')
    note=ref(public,'PUBLIC_NOTE.json',encode({'TEST_ONLY':True}))
    late={
      'ROOT_SENDER_ASSEMBLY_SELECTION.json':ref(public,'ROOT_SENDER_ASSEMBLY_SELECTION.json',
          encode({'TEST_ONLY_AUTHORITY_NONE':True,'fixed_packet_directory':str(episode/'assembled/packet')})),
      'PRO_SENDER_OPERATION.json':ref(public,'PRO_SENDER_OPERATION.json',
          encode({'TEST_ONLY_AUTHORITY_NONE':True,'expires_unix_ms':deadline})),
      'PRO_SENDER_ADMISSION.json':ref(public,'PRO_SENDER_ADMISSION.json',encode({'TEST_ONLY_NOT_AN_ADMISSION':True})),
      'ROOT_REQUEST_ARTIFACT.zip':artifact,
      'HOST_PUBLICATION_ROOT_RECEIVING.json':ref(public,'HOST_PUBLICATION_ROOT_RECEIVING.json',encode({'TEST_ONLY_NOT_A_RECEIVING':True}))}
    private_refs={f'PUBLIC_INPUT_{i:02d}.json':ref(private,f'PUBLIC_INPUT_{i:02d}.json',encode({'PUBLIC_TEST_ONLY':i})) for i in range(11)}
    data={'root_sender_entry.py':b'# PUBLIC TEST_ONLY INERT TEXT\n',
          'packet/carrier/PRO_SENDER_OPERATION.json':encode({'TEST_ONLY':True}),
          'packet/private-inputs/PUBLIC_FIXTURE.json':encode({'PUBLIC_TEST_ONLY_NO_PRIVATE_INPUT':True})}
    manifest=dict(schema='dg16.late-root-sender-install-manifest.v1',authority='NONE',
        fixed_packet_directory=str(episode/'assembled/packet'),sender_uid=os.geteuid(),sender_gid=os.getegid(),
        directories_mode=0o700,public_file_mode=0o400,private_file_mode=0o600,
        host_manifest_sha256='a'*64,host_manifest_unchanged=True,
        late_currentness='ACTUAL_SENDER_POLICY_PROVIDER_REQUEST_AND_TOOLS_REQUIRED',
        members={n:desc(b) for n,b in data.items()},original_awards=[])
    data['ROOT_SENDER_INSTALL_MANIFEST.json']=encode(manifest)
    observed={'source':{'path':str(source),**desc(source_raw)},'classification':'PUBLIC_TEST_ONLY_INSTALLER_CUSTODY_CONTROL',
              'case':case,'attack_performed':False,'original_runtime_loaded':False,'original_assembler_called':False,
              'original_private_inputs_read':False,'native_capture_calls':0,'provider_calls':0,'original_awards':[]}

    class Inputs:
        def __init__(self,root):self.root=Path(root);self.pins={}
        def body(self,r,maximum=4*1024**2):
            p=Path(r['path']);assert p.is_relative_to(self.root) and p.resolve()==p
            raw=p.read_bytes();assert len(raw)<=maximum and desc(raw)=={k:r[k] for k in ('bytes','sha256')}
            self.pins[str(p)]=desc(raw);return raw

    class Sources:
        input_index={n:{k:r[k] for k in ('bytes','sha256')} for n,r in private_refs.items()}
        def context(self,c):assert c=={'TEST_ONLY':True}
        def receive_public(self,*args):return {'receipt':{'TEST_ONLY_NO_ORIGINAL_RECEIVING':True}}
        def work_root(self,p):assert p==episode;return p
        def assemble_sender_source(self,*args):
            observed['public_fixture_bytes_supplied']=True
            return dict(data)

    def read(path,maximum,pin):
        raw=Path(path).read_bytes();assert len(raw)<=maximum and desc(raw)==pin;return raw

    def replace_episode():
        episode.rename(base/'moved_original_episode');episode.mkdir(mode=0o700)
        observed['attack_performed']=True

    class Runtime:
        sources=Sources()
        entry=types.SimpleNamespace(PublicInputs=Inputs,read=read)
        calls=0
        def current(self):
            self.calls+=1
            if self.calls==3:
                if case=='episode_before_receipt':replace_episode()
                elif case=='tree_before_receipt':
                    (episode/'assembled').rename(episode/'moved_original_assembled')
                    (episode/'assembled').mkdir(mode=0o700);observed['attack_performed']=True

    interface=types.SimpleNamespace(metadata_inputs=lambda rt,inputs,refs:{k:inputs.body(v) for k,v in refs.items()})
    config=dict(schema='g132.late-source-install-selection.v1',state='ROOT_SELECTED_FOR_EXACT_LATE_SOURCE_INSTALL',
        purpose='LOCAL_SOURCE_ASSEMBLY_ONLY',installation_index_sha256=m.INSTALLATION_SHA,context={'TEST_ONLY':True},
        input_root=str(public),private_input_root=str(private),recipient={'results':metadata,'archive':artifact,'note':note},
        late_inputs=late,private_inputs=private_refs,episode=str(episode),deadline_unix_ms=deadline)
    save(base/'PUBLIC_TEST_ONLY_CONFIG.json',encode(config))
    if case=='episode_during_receipt':
        original_write=m.write_file
        def interrupted_write(parent,name,raw,mode):
            if name=='SOURCE_INSTALL_RECEIPT.json':replace_episode()
            return original_write(parent,name,raw,mode)
        m.write_file=interrupted_write
    try:
        result=m.install_selected(interface,Runtime(),config)
        observed.update(returned_success=True,result=result,exception=None)
    except Exception as exc:
        observed.update(returned_success=False,result=None,exception={'type':type(exc).__name__,'code':str(exc)})
    observed['selected_episode_receipt_exists']=(episode/'SOURCE_INSTALL_RECEIPT.json').exists()
    observed['selected_assembled_exists']=(episode/'assembled').is_dir()
    observed['moved_original_receipt_exists']=(base/'moved_original_episode/SOURCE_INSTALL_RECEIPT.json').exists()
    observed['retained_files']=[{'path':str(p.relative_to(base)),**desc(p.read_bytes())}
                              for p in sorted(base.rglob('*')) if p.is_file()]
    if case=='no_replacement':
        passed=observed['returned_success'] and observed['selected_episode_receipt_exists'] and observed['selected_assembled_exists']
    else:
        passed=observed['attack_performed'] and not observed['returned_success'] and not observed['selected_episode_receipt_exists']
    observed['expected_custody_behavior_observed']=passed
    save(base/'RESULT.json',encode(observed))
    return observed


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--case',required=True)
    a=p.parse_args();v=run(a.source,a.output,a.case)
    print(json.dumps({k:v[k] for k in ('classification','case','attack_performed','returned_success','exception',
        'selected_episode_receipt_exists','moved_original_receipt_exists','expected_custody_behavior_observed','original_awards')},sort_keys=True))
    raise SystemExit(0 if v['expected_custody_behavior_observed'] else 1)
