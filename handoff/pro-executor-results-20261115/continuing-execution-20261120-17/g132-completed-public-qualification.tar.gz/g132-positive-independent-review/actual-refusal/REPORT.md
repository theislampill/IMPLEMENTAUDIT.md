# Actual positive-control entry refusal and source-review correction

**Disposition: ACTUAL_ENTRY_REFUSAL_RECEIVED_SOURCE_GAP. Authority NONE.** The exact selected attempt returned `PROBE_SOURCE_MODE`. The earlier positive-source `SOURCE_READY_FOR_ROOT_SELECTION` conclusion is superseded by `GAP_PRIOR_EVIDENCE_CUSTODY_MODE`. Its sealed files remain unchanged.

## Actual attempt and custody

Root's actual return is `cd895e`, exit 1, elapsed 0.039929044 seconds, without a running session. `ACTUAL_INVOCATION_TOOL_RETURN.json` has SHA-256 `368192c0e2a7a8802248cb83e9098f4c4d17d68c23a8e901e8c4e656b87d04bd`. The terminal is `ENTRY_REFUSED_OR_PARTIAL_RECONCILE_OUTPUT_NO_RETRY`, with error code/message `PROBE_SOURCE_MODE`, authority NONE and no awards.

The retained Root selection has SHA-256 `133011df499ef47f095dd6f4144264dd8f063e42ae1301be09f4a7eeed0843ec`. It and actual preflight `cf2111/0` contain the same exact invocation `cf8cde6f69bc37d0be2e1fd0b377623ea29658a07705fbe574878381d62fdef9`. Currentness return `aa5e9b/0` joins the selection's G0011 receipt. These are received as evidence; this reviewer neither invokes nor mutates Root continuity.

Root's commission declares the selected invocation was issued once. The retained actual return file contains the tool result, rather than its command arguments. This review joins the retained selection/preflight and actual outcome without inventing a command-argument record or claiming independent provider authentication.

## Exact source defect

The first insertion in source `PRIOR_SEALS` is `/workspace/scratch/530bc07ea12b/g132-native-capture-probe/one-time-output/PROBE_RESULT.json`: 3,979 bytes, SHA-256 `3bb4677e69543163727a2130e40286d8650eb9f9739f57735e3e3f024759de1b`, owned by UID/GID1000 and mode0600.

At source line165, `seal_records` calls `read_bound(name, {'sha256': digest})`, leaving `executable=False`. The mode gate at lines80–81 permits only0400/0444/0644 for such a call. The original0600 result therefore raises `PROBE_SOURCE_MODE`. This exact path retains the same identity, bytes, mode, mtime and ctime recorded in the earlier source review. No evidence mode has been changed.

The actual output directory remains absent, and the positive source directory retains exactly its six sealed members plus its manifest. Absence alone is not used to infer no capture. The exact pinned control flow places the failing prior-evidence read before output reservation at line178, before CaptureSession creation and before the capture call at line284. Thus this attempt stops before those source effect boundaries; it establishes no positive encryption. Source/bootstrap and loader reads/imports can have occurred before refusal, so this is not represented as an invocation with no activity of any kind.

## Correction to my earlier review

My prior receiver recorded the result's0600 identity but did not apply the target reader's mode predicate to that newly added dependency. The earlier readiness conclusion was wrong. `SOURCE_REVIEW_CORRECTION.json` explicitly supersedes that claim in positive-source manifest `32cfd47fab35ce85f6a917f92679272f270ac1edf8846954239ab979c215f0f9` and combined review manifest `88b6d3f1a518af8b8750935f445781d89f09173a16218d87c07702016152ddcf`. Their byte/pin observations and the separate installer finding remain historical evidence; no old file is rewritten.

Fresh read-only receiving `e1416b/0` retains the actual-return joins, exact mode conflict, same historical identity, source line ordering and surviving output/source population. It imports/executes no target source and performs no native capture, encryption, original sender, private input read, provider call, retry or mode change.

## Finite successor direction

Use an explicit reader for the exact historical observation's owned0600 custody while preserving the original source/tool reader. The unchanged `carrier_io.read_file(path, 3979, private=True)` is one existing bounded primitive: it requires owned0600, regular one-link custody, no-follow opening, no xattrs, bounded bytes, and closing identity/ancestor checks. A successor must additionally enforce this exact descriptor and recheck the same evidence record during currentness. This is a distinct evidence class, not a generic relaxation of source modes.

Preserve the old result, failed positive source/invocation, actual return, and this correction. Any successor needs a distinct source, selection, invocation and output directory, fresh receiving that tests every dependency's actual reader predicate, and Root's separate actual decision. This report authorizes no retry or successor execution. The exact locator and corrective direction were sent directly to `/root/g132_path_readiness` as commissioned.

Original G1/G3 awards remain empty, original protected625f/301 remains UNKNOWN_NO_REPLAY, and no fresh protected grant or whole-path readiness is established.
