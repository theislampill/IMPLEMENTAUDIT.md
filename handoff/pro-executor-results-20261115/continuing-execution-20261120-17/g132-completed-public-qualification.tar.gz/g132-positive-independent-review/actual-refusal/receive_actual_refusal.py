"""Receive the actual entry refusal; never imports or executes target source."""
import ast
import hashlib
import json
import os
from pathlib import Path
import stat

ROOT = Path('/workspace/scratch/530bc07ea12b')
REVIEW = ROOT / 'g132-positive-independent-review'
ACTUAL = ROOT / 'g132-positive-public-actual'
BASE = ROOT / 'g132-original-operation-readiness/positive-public-control'
OUT = REVIEW / 'actual-refusal'
rows = []


def desc(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def stamp(s):
    return [s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_size,
            s.st_mtime_ns, s.st_ctime_ns, s.st_uid, s.st_gid]


def read(path, digest=None):
    p = Path(path)
    before = p.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    fd = os.open(p, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        assert stamp(os.fstat(fd)) == stamp(before) and not os.listxattr(fd)
        raw = os.pread(fd, before.st_size + 1, 0)
        assert len(raw) == before.st_size
        assert stamp(os.fstat(fd)) == stamp(before) == stamp(p.lstat())
    finally:
        os.close(fd)
    if digest is not None:
        assert desc(raw)['sha256'] == digest
    rows.append(dict(path=str(p), **desc(raw), identity=stamp(before),
                     mode=oct(stat.S_IMODE(before.st_mode))))
    return raw


actual = json.loads(read(ACTUAL / 'ACTUAL_INVOCATION_TOOL_RETURN.json',
    '368192c0e2a7a8802248cb83e9098f4c4d17d68c23a8e901e8c4e656b87d04bd'))
assert actual['chunk_id'] == 'cd895e' and actual['exit_code'] == 1 and 'session_id' not in actual
terminal = json.loads(actual['output'])
assert terminal['error']['code'] == terminal['error']['message'] == 'PROBE_SOURCE_MODE'
assert terminal['error']['message_descriptor'] == desc(b'PROBE_SOURCE_MODE')
assert terminal['schema'] == 'g132.public-native-probe-entry-refusal.v1'
assert terminal['state'] == 'ENTRY_REFUSED_OR_PARTIAL_RECONCILE_OUTPUT_NO_RETRY'
assert terminal['authority'] == 'NONE' and terminal['original_awards'] == []
selection = json.loads(read(ACTUAL / 'ROOT_SELECTION.json',
    '133011df499ef47f095dd6f4144264dd8f063e42ae1301be09f4a7eeed0843ec'))
preflight = json.loads(read(ACTUAL / 'ACTUAL_PREFLIGHT_TOOL_RETURN.json'))
currentness = json.loads(read(ACTUAL / 'ACTUAL_CURRENTNESS_TOOL_RETURN.json'))
assert preflight['exit_code'] == currentness['exit_code'] == 0
preflight_output = json.loads(preflight['output'])
assert preflight_output['root_selection_sha256'] == '133011df499ef47f095dd6f4144264dd8f063e42ae1301be09f4a7eeed0843ec'
invocation = json.loads(read(BASE / 'INVOCATION.json',
    'cf8cde6f69bc37d0be2e1fd0b377623ea29658a07705fbe574878381d62fdef9'))
assert selection['invocation'] == preflight_output['invocation'] == invocation
assert currentness['output'].strip() == selection['continuity_receipt']
source = read(BASE / 'probe.py',
    'c66e70e7b1c04041b01a85c5ca3ba479d15f476abd0d6fea5d501d3736d3c1ca')
module = ast.parse(source)
prior = next(ast.literal_eval(n.value) for n in module.body if isinstance(n, ast.Assign)
    and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'PRIOR_SEALS')
first = next(iter(prior))
assert first == str(ROOT / 'g132-native-capture-probe/one-time-output/PROBE_RESULT.json')
old_result = read(first, prior[first])
old_result_row = rows[-1]
assert len(old_result) == 3979 and old_result_row['mode'] == '0o600'
read_bound = next(n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == 'read_bound')
mode_check = next(n for n in read_bound.body if isinstance(n, ast.Expr)
    and isinstance(n.value, ast.Call) and any(isinstance(a, ast.Constant)
        and a.value == 'PROBE_SOURCE_MODE' for a in n.value.args))
assert ast.unparse(mode_check.value.args[0].orelse) == 'mode in (256, 292, 420)'
main = next(n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
seal_statement = next(n for n in main.body if isinstance(n, ast.Assign)
    and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'seal_records')
call = seal_statement.value.value.value
assert ast.unparse(call) == "read_bound(name, {'sha256': digest})"
output_call = next(n for n in ast.walk(main) if isinstance(n, ast.Call)
    and ast.unparse(n.func) == 'F.private_directory')
capture_call = next(n for n in ast.walk(main) if isinstance(n, ast.Call)
    and ast.unparse(n.func) == 'session.capture')
assert seal_statement.lineno < output_call.lineno < capture_call.lineno
previous = json.loads(read(REVIEW / 'POSITIVE_SOURCE_VERIFICATION.json',
    'efd0fb7cc47c1212fb643e25b5c9cf7c82b52195d845801c76f1ca382bab57d0'))
past = [r for r in previous['records'] if r['path'] == first]
assert len(past) == 1 and past[0]['identity'] == old_result_row['identity']
read(REVIEW / 'POSITIVE_SOURCE_MANIFEST.json',
    '32cfd47fab35ce85f6a917f92679272f270ac1edf8846954239ab979c215f0f9')
read(REVIEW / 'MANIFEST.json',
    '88b6d3f1a518af8b8750935f445781d89f09173a16218d87c07702016152ddcf')
prepared = json.loads(read(BASE / 'PREPARED_SELECTION.json',
    '498516da3dbfae8c118057d30e841dab587c24e59f259986ba19f56c28f60697'))
source_manifest = json.loads(read(BASE / 'MANIFEST.json',
    'f3c8c55c3d26e745705c1ec7ae38d79cf6233d5d44d15a7e2dc7461e375cbd42'))
assert {p.name for p in BASE.iterdir()} == {'MANIFEST.json'} | {r['path'] for r in source_manifest['files']}
output = Path(prepared['output_directory'])
assert str(output) == selection['output_directory'] == terminal['output_directory']
assert not os.path.lexists(output)
result = dict(schema='g132.public-positive-actual-entry-refusal-receiving.v1', authority='NONE',
    disposition='ACTUAL_ENTRY_REFUSAL_RECEIVED_SOURCE_GAP', actual_tool='cd895e', actual_exit=1,
    failure='PROBE_SOURCE_MODE', failed_dependency=old_result_row,
    source_locations=dict(mode_check=mode_check.lineno, prior_seals_read=seal_statement.lineno,
        output_reservation=output_call.lineno, capture=capture_call.lineno),
    original_reader_allowed_modes=['0o400','0o444','0o644'], historical_mode_identity_unchanged=True,
    output_directory_absent=True, source_directory_population_unchanged=True,
    effect_boundary='Pinned source control flow refuses before output reservation, CaptureSession, or capture; absence alone is not the basis.',
    actual_argument_custody='Root commission declares exact invocation. Retained selection and preflight bind it; actual return file contains the tool result, not command arguments.',
    source_imported_or_executed_by_reviewer=False, native_capture_calls_by_reviewer=0,
    encryption_calls_by_reviewer=0, source_or_evidence_modes_changed=False,
    automatic_retry=False, positive_crypto_established=False, original_awards=[], records=rows)
correction = dict(schema='g132.public-positive-independent-review-correction.v1', authority='NONE',
    supersedes_only=[{'manifest_sha256':'32cfd47fab35ce85f6a917f92679272f270ac1edf8846954239ab979c215f0f9',
        'claim':'SOURCE_READY_FOR_ROOT_SELECTION'},
        {'manifest_sha256':'88b6d3f1a518af8b8750935f445781d89f09173a16218d87c07702016152ddcf',
        'claim':'positive_source_disposition SOURCE_READY_FOR_ROOT_SELECTION'}],
    replacement='GAP_PRIOR_EVIDENCE_CUSTODY_MODE', old_files_unchanged=True,
    reviewer_error='The previous receiver recorded mode0600 but did not apply the target read_bound source-mode predicate to the added prior-result dependency.',
    installer_finding_unchanged=True, actual_refusal_return_sha256='368192c0e2a7a8802248cb83e9098f4c4d17d68c23a8e901e8c4e656b87d04bd',
    original_awards=[], replay_authorized=False)
OUT.mkdir(mode=0o700, exist_ok=False)
for name, value in [('ACTUAL_REFUSAL_VERIFICATION.json',result),('SOURCE_REVIEW_CORRECTION.json',correction)]:
    raw=(json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
    fd=os.open(OUT/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_CLOEXEC,0o444)
    try:assert os.write(fd,raw)==len(raw);os.fsync(fd)
    finally:os.close(fd)
    assert (OUT/name).read_bytes()==raw
print(json.dumps(dict(state='ACTUAL_ENTRY_REFUSAL_RECEIVED_SOURCE_GAP',authority='NONE',
    verification=desc((OUT/'ACTUAL_REFUSAL_VERIFICATION.json').read_bytes()),
    correction=desc((OUT/'SOURCE_REVIEW_CORRECTION.json').read_bytes()),
    output_directory_absent=True,native_capture_or_encryption_by_reviewer=False,original_awards=[])))
