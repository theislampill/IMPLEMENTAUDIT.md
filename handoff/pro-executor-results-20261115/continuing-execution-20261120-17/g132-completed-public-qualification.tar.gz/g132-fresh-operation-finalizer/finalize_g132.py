"""Finite G132 source generation; no issuer, provider, native or sender effects."""
import argparse
import ast
import copy
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys

BASE = Path('/workspace/scratch/2678f1e431c3/g132-actual-candidate-source-received-20261119')
INTERFACE = Path('/workspace/scratch/530bc07ea12b/g132-execution-readiness/current_interfaces.py')
INSTALLER = Path('/workspace/scratch/530bc07ea12b/g132-late-installer-custody-r2/late_sender_install.py')
COMPOSITION_SHA = '6d6f561278bcf5516bb05098dfc484eeca3094942dc6041bec508231584eec86'
INSTALLATION_SHA = '58a831b74aec61df5f159ca72cc5c54bc2d50c13f0aea78651bdfe48f0d8e983'
INTERFACE_PIN = {'bytes':19976,'sha256':'2f5fdf5021df1db83320d286828898cfdbaaebe13e41acc7716329306f1fbe06'}
INSTALLER_PIN = {'bytes':18469,'sha256':'d7b87577b2e32ef797a5f2abab565b201603290e8c30d62a2837d25aca6dd16a'}
ISSUER_PIN = {'bytes':8932,'sha256':'15f88402a807fa905591d97b9f02633c205b6bd90ce71096cb092f309a44de68'}
CONFIG_PIN = {'bytes':641,'sha256':'2c6cadc80a50464927316116b026e78f238a935f8e63cb23dc79e27ecb325014'}
SOURCE = 'e76a07b2bae7c945e5a9d529ed8cf9069f4c9064'
TREE = 'ff9fc6793892147aecc59bdfc4ddb82fc37f9eb7'
REPOSITORY = 'theislampill/IMPLEMENTAUDIT.md'
ROOT_ISSUER = 'R5_ROOT_GOVERNOR'
ROOT_STATE = 'ROOT_SELECTED_SOURCE_GENERATION_ONLY'
SUCCESSOR = 'PRO-EXECUTOR-01, designated by owner'
WORKFLOW = '.github/workflows/dg16-r5-g1-hosted-episode.yml'
CORE = 'qualification/dg16-r5-g1-hosted-episode/'
ENTRY = 'qualification/dg16-r5-g1-hosted-entry/'
CARRIER = CORE + 'carrier/'
PROPOSED_REFS = {'host':'pro/dg16-g132-original-20261120-01',
    'g3':'pro/dg16-g132-g3-control-20261120-01','cipher':'pro/dg16-g132-cipher-20261120-01',
    'tools':'pro/dg16-g132-tools-control-20261120-01'}
ROLES = {'root_admission':'COMPOSITION_ROOT_ADMISSION.json',
    'placement_receiving':'COMPOSITION_PLACEMENT_RECEIVING.json',
    'placement_evidence_index':'COMPOSITION_PLACEMENT_EVIDENCE_INDEX.json',
    'native_applicability_adoption':'COMPOSITION_NATIVE_APPLICABILITY_ADOPTION.json'}
WRAPPERS = ('core_prepare_entry.py','host_receive_entry.py','host_request_entry.py',
            'host_tool_adopt_entry.py','host_tool_observe_entry.py')
MAX_SOURCE = 2 * 1024**2
MAX_STAGE = 16 * 1024**2
SEAL = 'FINALIZER_STAGE.json'
PROTECTED_SOURCE_ROOTS = (
    BASE, INTERFACE.parent, INSTALLER.parent, Path(__file__).resolve().parent,
    Path('/workspace/scratch/530bc07ea12b/g132-original-operation-readiness'),
    Path('/workspace/scratch/530bc07ea12b/g132-positive-public-control-r2'),
    Path('/workspace/scratch/530bc07ea12b/g132-positive-public-actual'),
    Path('/workspace/scratch/2678f1e431c3/g132-private-recovered-inputs-20261119'),
)

def need(value,code):
    if not value:raise ValueError(code)

def desc(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def encode(value):return (json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode()

def parse(raw):
    need(type(raw) is bytes and 0<len(raw)<=MAX_STAGE,'BOUNDED_JSON_BYTES')
    def pairs(rows):
        out={}
        for key,value in rows:
            need(key not in out,'DUPLICATE_JSON_KEY');out[key]=value
        return out
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _:need(False,'NONFINITE_JSON'))

def oid(kind,raw):return hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def digest40(value):need(type(value) is str and re.fullmatch('[0-9a-f]{40}',value),'EXACT_GIT_ID')

def canonical_member(name):
    need(type(name) is str,'MEMBER_STRING')
    p=PurePosixPath(name)
    need(str(p)==name and not p.is_absolute() and name not in ('','.','..') and '..' not in p.parts
         and '\\' not in name and '\0' not in name,'CANONICAL_MEMBER')
    return p

def separate_output(path,other_roots=()):
    path=Path(path)
    need(all(path!=root and root not in path.parents and path not in root.parents
             for root in (*PROTECTED_SOURCE_ROOTS,*(Path(p) for p in other_roots))),
         'OUTPUT_MUST_NOT_MODIFY_EXISTING_SOURCE_OR_INPUT_TREE')

def stamp(s):return (s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def directory_stamp(s):return (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid)

def ancestry(path):
    out=[]
    for p in reversed(path.parents):
        s=p.lstat();need(stat.S_ISDIR(s.st_mode) and not p.is_symlink(),'ANCESTOR_ALIAS')
        out.append((str(p),directory_stamp(s)))
    return out

class Reads:
    """Exact owned reads and closing identities, including closed populations."""
    def __init__(self):self.files={};self.populations={}

    def body(self,path,pin=None,role='source',maximum=MAX_SOURCE):
        p=Path(path)
        need(p.is_absolute() and str(p)==str(path) and p.resolve(strict=True)==p,'CANONICAL_INPUT_PATH')
        parents=ancestry(p);s=p.lstat()
        modes={'source':(0o400,0o444),'public':(0o400,0o444,0o644),'core_admission':(0o600,)}
        need(role in modes and stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_uid==os.geteuid()
             and s.st_gid==os.getegid() and stat.S_IMODE(s.st_mode) in modes[role]
             and 0<s.st_size<=maximum,'INPUT_CUSTODY')
        fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK)
        try:
            need(stamp(os.fstat(fd))==stamp(s) and not os.listxattr(fd),'INPUT_OPEN_CHANGED')
            raw=os.pread(fd,maximum+1,0)
            need(len(raw)==s.st_size and stamp(os.fstat(fd))==stamp(s)==stamp(p.lstat())
                 and ancestry(p)==parents,'INPUT_CLOSING_CHANGED')
        finally:os.close(fd)
        need(pin is None or all(desc(raw).get(k)==v for k,v in pin.items()),'INPUT_PIN_CHANGED')
        record=(stamp(s),parents,desc(raw),role,maximum)
        # A baseline Git object may also be selected as public operation data.
        # Both role gates already ran; retain the original strict closing role.
        if str(p) in self.files:
            need(self.files[str(p)][:3]==record[:3],'INPUT_RESELECTED_OR_CHANGED')
        else:self.files[str(p)]=record
        return raw

    def population(self,root,names):
        root=Path(root);s=root.lstat()
        need(root.is_absolute() and root.resolve(strict=True)==root and stat.S_ISDIR(s.st_mode)
             and s.st_uid==os.geteuid() and not s.st_mode & 0o022,'SOURCE_DIRECTORY_CUSTODY')
        paths=list(root.rglob('*'));need(not any(p.is_symlink() for p in paths),'SOURCE_POPULATION_ALIAS')
        actual={p.relative_to(root).as_posix() for p in paths if p.is_file()}
        need(actual==set(names),'CLOSED_SOURCE_POPULATION')
        directories={'.':directory_stamp(s)}
        for p in paths:
            if p.is_dir():directories[p.relative_to(root).as_posix()]=directory_stamp(p.lstat())
            else:need(p.is_file(),'SPECIAL_SOURCE_ENTRY')
        self.populations[str(root)]=(set(names),directories)

    def current(self):
        for name,record in list(self.files.items()):self.body(name,record[2],record[3],record[4])
        for root,(names,opening) in list(self.populations.items()):
            self.population(root,names);need(self.populations[root][1]==opening,'SOURCE_DIRECTORY_CHANGED')

def receive_baseline(reads=None):
    reads=reads or Reads();install=BASE/'dependencies/installation'
    index_raw=reads.body(install/'SOURCE_INDEX.json',{'sha256':INSTALLATION_SHA});index=parse(index_raw)
    need(len(index['files'])==157 and index['state']=='UNISSUED' and index['authority']=='NONE','EXACT_BASE_INSTALLATION')
    reads.population(install,set(index['files'])|{'SOURCE_INDEX.json'})
    bodies={name:reads.body(install/name,pin) for name,pin in index['files'].items()}
    composition_raw=reads.body(BASE/'COMPOSITION_SOURCE_INDEX.json',{'sha256':COMPOSITION_SHA});composition=parse(composition_raw)
    need(len(composition['files'])==12 and composition['installation_index_sha256']==INSTALLATION_SHA,'EXACT_BASE_RUNTIME')
    reads.population(BASE/'source',composition['files'])
    runtime={name:reads.body(BASE/'source'/name,pin) for name,pin in composition['files'].items()}
    phase=parse(bodies['phase/PHASE.json'])
    host={name.removeprefix('phase/tree/'):raw for name,raw in bodies.items() if name.startswith('phase/tree/')}
    need(len(host)==53 and phase['members']=={'tree/'+name:desc(raw) for name,raw in host.items()},'EXACT_REPAIRED53')
    scope=parse(host[CORE+'ORIGINAL_SCOPE.json'])
    need(scope['current_subject']=={'commit':SOURCE,'tree':TREE}
         and scope['original_population']=={'DG16':48,'DG17':95,'DG18':14,'total':157},'ORIGINAL_SCOPE_DENOMINATOR')
    repair=parse(bodies['SCOPE_REPAIR_SOURCE_DELTA.json'])
    for name,row in repair['changes'].items():need(desc(host[name])==row['new'],'CURRENT_SCOPE_REPAIR_BODY')
    result={'installation':bodies,'index':index,'index_raw':index_raw,'runtime':runtime,
        'composition':composition,'composition_raw':composition_raw,'host':host,
        'issuer':reads.body(BASE/'complete-sources/issuer.py',ISSUER_PIN),
        'interface':reads.body(INTERFACE,INTERFACE_PIN),
        # The sealed installer is an exact0644 byte derivation input, never imported.
        'installer':reads.body(INSTALLER,INSTALLER_PIN,'public'),
        'unissued_config':reads.body(BASE/'ROOT_CONTROL_CONFIG_UNISSUED.json',CONFIG_PIN),
        'private_original_inputs_read':False}
    reads.current();return result

def assignment_node(raw,name,scope=None):
    nodes=ast.parse(raw).body
    if scope:
        for part in scope.split('.'):
            found=[n for n in nodes if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name==part]
            need(len(found)==1,'UNIQUE_BINDING_SCOPE');nodes=found[0].body
    hits=[n for n in nodes if isinstance(n,ast.Assign) and len(n.targets)==1
          and isinstance(n.targets[0],ast.Name) and n.targets[0].id==name]
    need(len(hits)==1,'UNIQUE_BINDING_'+name);return hits[0]

def literal(raw,name,scope=None):return ast.literal_eval(assignment_node(raw,name,scope).value)

def splice(raw,name,before,after,scope=None):
    n=assignment_node(raw,name,scope).value;need(ast.literal_eval(n)==before,'OLD_LITERAL_CHANGED_'+name)
    lines=raw.splitlines(keepends=True);start=sum(map(len,lines[:n.lineno-1]))+n.col_offset
    end=sum(map(len,lines[:n.end_lineno-1]))+n.end_col_offset
    out=raw[:start]+repr(after).encode()+raw[end:]
    need(literal(out,name,scope)==after,'LITERAL_REBIND_READBACK');compile(out,'<source-only-literal-rebind>','exec');return out

def bind(raw,values):
    for name,value in values.items():raw=splice(raw,name,literal(raw,name),value)
    return raw

def exact_replace(raw,before,after,count):
    need(type(before) is bytes and raw.count(before)==count,'EXACT_REPLACEMENT_COUNT');return raw.replace(before,after)

def select(b,selection):
    fields={'schema','issuer','state','operation_id','repository','source_commit','source_tree','refs','control_parents',
            'publication_parent','publication_lineage','public_git_inputs','generation_directory','effect_grant','original_awards'}
    need(type(selection) is dict and set(selection)==fields,'ROOT_SELECTION_FIELDS')
    need(selection['schema']=='g132.fresh-operation-source-selection.v1' and selection['issuer']==ROOT_ISSUER
         and selection['state']==ROOT_STATE and selection['repository']==REPOSITORY and selection['source_commit']==SOURCE
         and selection['source_tree']==TREE and selection['effect_grant'] is False and selection['original_awards']==[],
         'GENUINE_ROOT_SOURCE_SELECTION_REQUIRED')
    need(selection['operation_id']=='G132_ORIGINAL_20261120_01' and selection['refs']==PROPOSED_REFS
         and len(set(selection['refs'].values()))==4,'EXACT_FRESH_OPERATION_REFS')
    parents=selection['control_parents']
    need(type(parents) is dict and set(parents)=={'cipher','tools'} and len(set(parents.values()))==2,'DISTINCT_SELECTED_SEED_PARENTS')
    for value in [selection['publication_parent'],*parents.values()]:digest40(value)
    chain=selection['publication_lineage']
    need(type(chain) is list and 1<=len(chain)<=32 and len(chain)==len(set(chain))
         and chain[0]==selection['publication_parent'] and chain[-1]==SOURCE,'EXACT_SELECTED_PUBLIC_LINEAGE')
    for value in chain:digest40(value)
    public=selection['public_git_inputs']
    need(type(public) is dict and set(public)=={'commits','trees'} and set(public['commits'])==set(chain)
         and 1<=len(public['trees'])<=8,'EXACT_PUBLIC_GIT_INPUT_POPULATION')
    for values in public.values():
        for key,ref in values.items():
            digest40(key);need(type(ref) is dict and set(ref)=={'path','bytes','sha256'},'EXACT_PUBLIC_OBJECT_DESCRIPTOR')
            need(type(ref['bytes']) is int and 0<ref['bytes']<=MAX_SOURCE and type(ref['sha256']) is str
                 and re.fullmatch('[0-9a-f]{64}',ref['sha256']) and type(ref['path']) is str
                 and Path(ref['path']).is_absolute(),'EXACT_PUBLIC_OBJECT_DESCRIPTOR_TYPES')
    path=Path(selection['generation_directory'])
    need(path.is_absolute() and str(path)==selection['generation_directory'] and '..' not in path.parts
         and path not in (BASE,INTERFACE.parent,INSTALLER.parent),'FRESH_MODEL_DIRECTORY_REQUIRED')
    separate_output(path)
    return copy.deepcopy(selection)

def stage(name,b,selection,members=None,expected=None,consumed=None):
    return {'schema':'g132.finite-fresh-source-stage.v1','stage':name,'authority':'NONE','selection':selection,
        'baseline_installation_sha256':INSTALLATION_SHA,'baseline_composition_sha256':COMPOSITION_SHA,
        'expected_admission':expected,'consumed_admissions':consumed or {},'members':members or {},
        'original_awards':[],'protected_grant':False,'private_original_inputs_read':False}

def core_requirements(b,selection):
    s=select(b,selection);index=parse(b['host'][CARRIER+'INPUT_INDEX.json'])
    need(len(index)==11 and sum(v['bytes'] for v in index.values())==647343,'HISTORICAL_ELEVEN_INPUT_INDEX')
    expected=dict(schema='dg16.current-core-host-root-admission.v1',issuer=ROOT_ISSUER,successor=SUCCESSOR,
        source_commit=SOURCE,source_tree=TREE,workflow_branch=s['refs']['host'],run_attempt=1,automatic_retry=False,
        original_awards=[],prospective_operation='ONE_ORIGINAL_G1_PAIR_AND_TWO_STAGE_CORE_G3_L04_SEPARATE',
        component_scope='CORE_G1_Q06_NATURAL_L04_SEPARATE',
        input_sha256={role:index[name]['sha256'] for role,name in ROLES.items() if role!='root_admission'})
    return stage('CORE_REQUIREMENTS',b,s,expected=expected)

def receive_admission(prior,raw,wanted):
    need(prior['stage']==wanted,'EXACT_PREDECESSOR_STAGE');expected=prior['expected_admission']
    need(type(raw) is bytes and raw==encode(expected) and parse(raw)==expected and expected['issuer']==ROOT_ISSUER
         and type(expected['run_attempt']) is int,'ACTUAL_EXACT_ROOT_ADMISSION_REQUIRED')

def host_core(b,prior,raw):
    receive_admission(prior,raw,'CORE_REQUIREMENTS');s=select(b,prior['selection'])
    host=dict(b['host']);index=parse(host[CARRIER+'INPUT_INDEX.json']);index[ROLES['root_admission']]=desc(raw)
    comp=parse(host[CORE+'HOST_COMPOSITION.json']);old_host=comp['workflow_branch']
    comp['workflow_branch']=s['refs']['host'];comp['root_admission']=dict(path='private-inputs/'+ROLES['root_admission'],**desc(raw))
    host[CORE+'HOST_COMPOSITION.json']=encode(comp)
    host[CORE+'host_composition.py']=bind(host[CORE+'host_composition.py'],{'BINDING_SHA256':desc(host[CORE+'HOST_COMPOSITION.json'])['sha256']})
    host[CORE+'g3_receiving.py']=bind(host[CORE+'g3_receiving.py'],{'JOB_BRANCH':s['refs']['host'],'CONTROL_BRANCH':s['refs']['g3']})
    proof=parse(host[CORE+'INDEPENDENT_PROOF_PINS.json'])
    proof.update(scope_module_sha256=desc(host[CORE+'g3_receiving.py'])['sha256'],initial_control_branch=s['refs']['g3'])
    host[CORE+'INDEPENDENT_PROOF_PINS.json']=encode(proof)
    run=host[CORE+'run.py'];modules=literal(run,'MODULE_PINS');data=literal(run,'G3_DATA_PINS')
    host[CORE+'run.py']=bind(run,{'BRANCH':s['refs']['host'],
        'MODULE_PINS':{name:desc(host[CORE+name+'.py'])['sha256'] for name in modules},
        'G3_DATA_PINS':{name:desc(host[CORE+name])['sha256'] for name in data}})
    flow=exact_replace(host[WORKFLOW],old_host.encode(),s['refs']['host'].encode(),2)
    flow=exact_replace(flow,b'G132 host32 after sender readiness correction from 625f310 (${{ github.sha }})',
                       b'G132 original 20261120-01 (${{ github.sha }})',1)
    flow_value=parse(flow)
    need(flow_value['jobs']['qualify']['runs-on']=='ubuntu-24.04'
         and flow_value['jobs']['qualify']['timeout-minutes']==75,'ORIGINAL_HOST_SELECTOR_AND_BUDGET')
    host[WORKFLOW]=flow;host[CARRIER+'INPUT_INDEX.json']=encode(index)
    binding=parse(host[CARRIER+'CARRIER_COMPOSITION.json']);tools=copy.deepcopy(binding['host_tools'])
    tools.update(control_branch=s['refs']['tools'],control_parent=s['control_parents']['tools'])
    expected=dict(schema='dg16.core-private-carrier-root-admission.v2',issuer=ROOT_ISSUER,successor=SUCCESSOR,
        operation='ONE_FIXED_TOOL_BOOTSTRAP_ONE_FRESH_RECIPIENT_ONE_PRIVATE_TRANSFER',source_commit=SOURCE,source_tree=TREE,
        workflow_branch=s['refs']['host'],workflow_path=WORKFLOW,workflow_sha256=desc(flow)['sha256'],
        control_branch=s['refs']['cipher'],control_parent=s['control_parents']['cipher'],
        input_index_sha256=desc(encode(index))['sha256'],limits=binding['limits'],host_tool_bootstrap=tools,
        run_attempt=1,automatic_retry=False,core_or_native_effect_grant=False,original_awards=[])
    need(len(index)==11 and all(index[n]==v for n,v in parse(b['host'][CARRIER+'INPUT_INDEX.json']).items()
                              if n!=ROLES['root_admission']),'TEN_HISTORICAL_DESCRIPTORS_UNCHANGED')
    return stage('CARRIER_REQUIREMENTS',b,s,host,expected,{'core':desc(raw)})

def host_carrier(b,prior,raw):
    receive_admission(prior,raw,'CARRIER_REQUIREMENTS');s=select(b,prior['selection']);host=dict(prior['members'])
    binding=parse(host[CARRIER+'CARRIER_COMPOSITION.json'])
    binding.update(state='REVIEWED_EXACT_CARRIER_COMPOSITION',branch=s['refs']['host'],workflow_sha256=desc(host[WORKFLOW])['sha256'],
        control_branch=s['refs']['cipher'],control_parent=s['control_parents']['cipher'],carrier_admission=desc(raw),
        input_index=desc(host[CARRIER+'INPUT_INDEX.json']),host_tools=copy.deepcopy(prior['expected_admission']['host_tool_bootstrap']),
        core_bodies={name:desc(host[CORE+name]) for name in binding['core_bodies']})
    host[CARRIER+'CARRIER_ADMISSION.json']=raw;host[CARRIER+'CARRIER_COMPOSITION.json']=encode(binding)
    host[CARRIER+'carrier_policy.py']=bind(host[CARRIER+'carrier_policy.py'],{'BINDING_SHA256':desc(host[CARRIER+'CARRIER_COMPOSITION.json'])['sha256']})
    loader=host[CARRIER+'carrier_loader.py'];pins=literal(loader,'MODULE_PINS')
    host[CARRIER+'carrier_loader.py']=bind(loader,{'MODULE_PINS':{name:desc(host[CARRIER+name+'.py']) for name in pins}})
    members={name.removeprefix(CORE):dict(**desc(body),mode=0o400) for name,body in host.items() if name.startswith(CORE)}
    manifest=encode({'schema':'dg16.fixed-root-public-manifest.v1','members':members});host[ENTRY+'PUBLIC_PACKET_MANIFEST.json']=manifest
    expected=dict(schema='dg16.fixed-root-bootstrap-admission.v1',issuer=ROOT_ISSUER,successor=SUCCESSOR,
        operation='CREATE_EXCLUSIVE_ROOT_ISLAND_AND_EXACT_PUBLIC_PACKET_ONLY',source_commit=SOURCE,source_tree=TREE,
        workflow_branch=s['refs']['host'],run_attempt=1,automatic_retry=False,original_awards=[],manifest_sha256=desc(manifest)['sha256'])
    return stage('BOOTSTRAP_REQUIREMENTS',b,s,host,expected,dict(prior['consumed_admissions'],carrier=desc(raw)))

def host_finish(b,prior,raw):
    receive_admission(prior,raw,'BOOTSTRAP_REQUIREMENTS');s=select(b,prior['selection']);host=dict(prior['members'])
    host[ENTRY+'BOOTSTRAP_ADMISSION.json']=raw;manifest_sha=desc(host[ENTRY+'PUBLIC_PACKET_MANIFEST.json'])['sha256']
    host[ENTRY+'entry_common.py']=bind(host[ENTRY+'entry_common.py'],{
        'ENTRY_STATE':'REVIEWED_EXACT_EXTERNAL_CARRIER_ENTRY','CARRIER_LOADER_DESCRIPTOR':desc(host[CARRIER+'carrier_loader.py']),
        'EXPECTED_PUBLIC_MANIFEST_SHA256':manifest_sha,'EXPECTED_BOOTSTRAP_ADMISSION_SHA256':desc(raw)['sha256']})
    common=desc(host[ENTRY+'entry_common.py'])['sha256']
    for name in WRAPPERS:host[ENTRY+name]=bind(host[ENTRY+name],{'COMMON_SHA256':common})
    host[ENTRY+'bootstrap_entry.py']=bind(host[ENTRY+'bootstrap_entry.py'],{
        'BRANCH':s['refs']['host'],'MANIFEST_SHA256':manifest_sha,'ADMISSION_SHA256':desc(raw)['sha256']})
    host[ENTRY+'public_export.py']=bind(host[ENTRY+'public_export.py'],{
        'BRANCH':s['refs']['host'],'CORE_RUN_SHA256':desc(host[CORE+'run.py'])['sha256']})
    need(set(host)==set(b['host']) and len(host)==53,'CLOSED_FINISHED53')
    for name in ('ORIGINAL_SCOPE.json','SOURCE_MANIFEST.json','NATIVE_SOURCE_APPLICABILITY.json','ADVERSE_APPLICABILITY.json'):
        need(host[CORE+name]==b['host'][CORE+name],'ORIGINAL_SCOPE_AND_APPLICABILITY_UNCHANGED')
    for name,body in b['host'].items():
        if name.startswith(CORE+'retained-m4/'):need(host[name]==body,'RETAINED_M4_UNCHANGED')
    return stage('HOST_COMPLETE_REQUIRES_ACTUAL_PROVIDER_OBJECT_RECEIVING',b,s,host,None,
                 dict(prior['consumed_admissions'],bootstrap=desc(raw)))

def commit_shape(raw,expected=None):
    if expected is not None:need(oid('commit',raw)==expected,'COMMIT_OBJECT_ID')
    headers=raw.split(b'\n\n',1)[0].splitlines()
    trees=[line[5:].decode('ascii') for line in headers if line.startswith(b'tree ')]
    parents=[line[7:].decode('ascii') for line in headers if line.startswith(b'parent ')]
    need(len(trees)==1,'EXACT_COMMIT_TREE_HEADER');digest40(trees[0])
    for p in parents:digest40(p)
    return trees[0],parents

def parse_tree(raw):
    out={};offset=0
    while offset<len(raw):
        stop=raw.find(b'\0',offset);need(stop>offset and stop+21<=len(raw),'GIT_TREE_FRAME')
        head=raw[offset:stop];need(b' ' in head,'GIT_TREE_HEADER');mode,name=head.split(b' ',1)
        need(mode in (b'40000',b'100644',b'100755',b'120000',b'160000') and name not in (b'',b'.',b'..')
             and b'/' not in name and b'\0' not in name,'GIT_TREE_ENTRY')
        label=name.decode('utf-8');need(label not in out,'GIT_TREE_DUPLICATE')
        out[label]=(mode.decode(),raw[stop+1:stop+21].hex());offset=stop+21
    need(serialize_tree(out)==raw,'CANONICAL_GIT_TREE');return out

def serialize_tree(rows):
    order=sorted(rows,key=lambda name:name.encode()+(b'/' if rows[name][0]=='40000' else b''))
    return b''.join(rows[name][0].encode()+b' '+name.encode()+b'\0'+bytes.fromhex(rows[name][1]) for name in order)

def selected_public_git(selection,reads):
    chosen=selection['public_git_inputs'];out={kind:{} for kind in chosen}
    for kind,values in chosen.items():
        for expected,ref in values.items():
            raw=reads.body(ref['path'],{k:ref[k] for k in ('bytes','sha256')},role='public')
            need(oid('commit' if kind=='commits' else 'tree',raw)==expected,'SELECTED_PUBLIC_OBJECT_ID');out[kind][expected]=raw
    chain=selection['publication_lineage']
    for number,commit in enumerate(chain):
        _,parents=commit_shape(out['commits'][commit],commit)
        if number+1<len(chain):need(parents==[chain[number+1]],'SELECTED_PUBLIC_LINEAGE_JOIN')
    need(chain[-1]==SOURCE and commit_shape(out['commits'][SOURCE],SOURCE)[0]==TREE,'ORIGINAL_SOURCE_LINEAGE_ANCHOR')
    return out

def publication_tree(host,selection,public):
    """Replace two complete host subtrees and one workflow; retain other entries."""
    parent=selection['publication_parent'];parent_tree,_=commit_shape(public['commits'][parent],parent);used=set()
    def existing(tree):
        need(tree in public['trees'],'SELECTED_BASE_TREE_BODY_REQUIRED');used.add(tree)
        raw=public['trees'][tree];need(oid('tree',raw)==tree,'BASE_TREE_ID');return parse_tree(raw)
    root=existing(parent_tree)
    def sub(rows,name):
        need(name in rows and rows[name][0]=='40000','FIXED_PUBLICATION_ANCESTOR_TREE');return existing(rows[name][1])
    github=sub(root,'.github');workflows=sub(github,'workflows');qualification=sub(root,'qualification')
    need(used==set(public['trees']),'CLOSED_BASE_TREE_INPUTS');generated={}
    def put(rows):
        raw=serialize_tree(rows);key=oid('tree',raw);generated[key]=raw;return key
    def subtree(bodies):
        rows={};children={}
        for path,body in bodies.items():
            head,sep,tail=path.partition('/')
            if sep:children.setdefault(head,{})[tail]=body
            else:need(head not in rows,'HOST_TREE_COLLISION');rows[head]=('100644',oid('blob',body))
        for name,members in children.items():
            need(name not in rows,'HOST_TREE_DIRECTORY_COLLISION');rows[name]=('40000',subtree(members))
        return put(rows)
    qualification[CORE.rstrip('/').split('/')[-1]]=('40000',subtree({n.removeprefix(CORE):v for n,v in host.items() if n.startswith(CORE)}))
    qualification[ENTRY.rstrip('/').split('/')[-1]]=('40000',subtree({n.removeprefix(ENTRY):v for n,v in host.items() if n.startswith(ENTRY)}))
    workflows[WORKFLOW.split('/')[-1]]=('100644',oid('blob',host[WORKFLOW]))
    github['workflows']=('40000',put(workflows));root['.github']=('40000',put(github));root['qualification']=('40000',put(qualification))
    return {'tree':put(root),'trees':generated,'parent':parent,'parent_tree':parent_tree,
        'replacement_paths':[WORKFLOW,CORE.rstrip('/'),ENTRY.rstrip('/')],'unchanged_outside_replacement_paths':True,
        'host_blobs':{name:dict(**desc(body),git_blob_sha=oid('blob',body)) for name,body in host.items()}}

def complete_host(b,prior,admission_raw,public):
    finished=host_finish(b,prior,admission_raw);plan=publication_tree(finished['members'],finished['selection'],public)
    finished['publication']={k:v for k,v in plan.items() if k!='trees'}
    finished['git_trees']=plan['trees'];finished['lineage_bodies']=dict(public['commits']);return finished

def adapted_g3(full):
    return exact_replace(full,b"read_file(Path(__file__).with_name('ORIGINAL_SCOPE.json'), 8192)",b'current_original_scope_body()',1)

def update_projection(installation,name,old_full,new_full,values):
    plan=parse(installation['PURE_SOURCE_PLAN.json']);row=plan[name]
    need(desc(old_full)=={'bytes':row['source_bytes'],'sha256':row['source_sha256']},'EXACT_FULL_PROJECTION_SOURCE_'+name)
    projection=installation['pure/'+name+'.py']
    need(desc(projection)=={'bytes':row['projection_bytes'],'sha256':row['projection_sha256']},'OLD_PROJECTION_PIN')
    for key,value in values.items():
        if key in row['declarations']:projection=splice(projection,key,literal(old_full,key),value)
    old_nodes={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(old_full).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    new_nodes={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(new_full).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    need(old_nodes==new_nodes,'PROJECTION_FUNCTION_BEHAVIOR_UNCHANGED');installation['pure/'+name+'.py']=projection
    row.update(source_bytes=len(new_full),source_sha256=desc(new_full)['sha256'],projection_bytes=len(projection),projection_sha256=desc(projection)['sha256'])
    installation['PURE_SOURCE_PLAN.json']=encode(plan)

def host_receiving_requirement(host,commit_raw):
    s=host['selection'];selected=host['publication'];commit=oid('commit',commit_raw)
    actual_tree,actual_parents=commit_shape(commit_raw,commit)
    need(actual_tree==selected['tree'] and actual_parents==[s['publication_parent']],'ACTUAL_HOST_TREE_PARENT_JOIN')
    return dict(schema='g132.fresh-host-object-root-receiving.v1',issuer=ROOT_ISSUER,
        state='ACTUAL_UNREFERENCED_PROVIDER_COMMIT_OBJECT_RECEIVED',repository=REPOSITORY,
        operation_id=s['operation_id'],host_branch=s['refs']['host'],source_commit=SOURCE,source_tree=TREE,
        host_members_sha256=desc(encode({n:desc(v) for n,v in host['members'].items()}))['sha256'],
        commit=commit,tree=actual_tree,parent=s['publication_parent'],commit_body=desc(commit_raw),
        tree_bodies={key:desc(raw) for key,raw in host['git_trees'].items()},reference_publication_observed=False,
        host_launch_observed=False,effect_grant=False,original_awards=[])

def model_generation(b,host,receiving,commit_raw):
    need(host['stage']=='HOST_COMPLETE_REQUIRES_ACTUAL_PROVIDER_OBJECT_RECEIVING'
         and 'publication' in host and 'git_trees' in host,'COMPLETE_HOST_OBJECT_REQUIREMENTS')
    s=select(b,host['selection']);selected=host['publication'];expected=host_receiving_requirement(host,commit_raw)
    commit=expected['commit'];actual_tree=expected['tree']
    need(type(receiving) is dict and set(receiving)==set(expected)|{'actual_provider_receiving'}
         and {k:v for k,v in receiving.items() if k!='actual_provider_receiving'}==expected,
         'GENUINE_ROOT_ACTUAL_PROVIDER_RECEIVING_REQUIRED')
    evidence=receiving['actual_provider_receiving']
    need(type(evidence) is dict and set(evidence)=={'path','bytes','sha256'} and type(evidence['bytes']) is int
         and evidence['bytes']>0,'ACTUAL_PROVIDER_EVIDENCE_REFERENCE')
    installation=dict(b['installation']);runtime=dict(b['runtime']);new_host=host['members']
    for name in list(installation):
        if name.startswith(('phase/tree/','git-candidate/','git-lineage/')):del installation[name]
    installation.update({'phase/tree/'+name:raw for name,raw in new_host.items()})
    phase=parse(b['installation']['phase/PHASE.json']);phase['members']={'tree/'+n:desc(v) for n,v in new_host.items()}
    installation['phase/PHASE.json']=encode(phase)
    installation.update({'git-candidate/'+key+'.tree':raw for key,raw in host['git_trees'].items()})
    installation['git-candidate/'+commit+'.commit']=commit_raw
    lineage=host['lineage_bodies'];need(set(lineage)==set(s['publication_lineage']),'MODEL_EXACT_LINEAGE_POPULATION')
    installation.update({'git-lineage/'+key+'.commit':raw for key,raw in lineage.items()})
    identity=parse(b['installation']['HOST_IDENTITY_UNISSUED.json'])
    identity.update(branch=s['refs']['host'],commit=commit,tree=actual_tree,parent=s['publication_parent'],
        baseline_tree=selected['parent_tree'],workflow_sha256=desc(new_host[WORKFLOW])['sha256'],
        historical_candidate_identity=identity['commit'],actual_candidate_receiving_sha256=desc(encode(receiving))['sha256'])
    need(identity['authority']=='NONE' and identity['state']=='UNISSUED' and identity['source_adoption_issued'] is False
         and identity['host_launch_observed'] is False,'NO_IMPLICIT_SOURCE_ADOPTION')
    installation['HOST_IDENTITY_UNISSUED.json']=encode(identity)
    issuer=bind(b['issuer'],{'HOST_COMMIT':commit,'HOST_TREE':actual_tree})
    update_projection(installation,'issuer',b['issuer'],issuer,{'HOST_COMMIT':commit,'HOST_TREE':actual_tree})
    old_g3=adapted_g3(b['host'][CORE+'g3_receiving.py']);new_g3=adapted_g3(new_host[CORE+'g3_receiving.py'])
    update_projection(installation,'g3',old_g3,new_g3,{'JOB_BRANCH':s['refs']['host'],'CONTROL_BRANCH':s['refs']['g3']})
    update_projection(installation,'run',b['host'][CORE+'run.py'],new_host[CORE+'run.py'],{})
    update_projection(installation,'policy',b['host'][CARRIER+'carrier_policy.py'],new_host[CARRIER+'carrier_policy.py'],{})
    index=copy.deepcopy(b['index']);index['files']={n:desc(v) for n,v in installation.items()}
    index['host_identity']=desc(installation['HOST_IDENTITY_UNISSUED.json']);index['phase']=desc(installation['phase/PHASE.json'])
    index['pure_plan']=desc(installation['PURE_SOURCE_PLAN.json']);installation_raw=encode(index);installation_sha=desc(installation_raw)['sha256']
    runtime['current_pro_interfaces.py']=bind(runtime['current_pro_interfaces.py'],{'INDEX_SHA256':installation_sha})
    old_chain=literal(runtime['current_pro_interfaces.py'],'chain','CurrentSources._check_git_identity')
    runtime['current_pro_interfaces.py']=splice(runtime['current_pro_interfaces.py'],'chain',old_chain,s['publication_lineage'],'CurrentSources._check_git_identity')
    runtime['current_root_entry.py']=bind(runtime['current_root_entry.py'],{'INDEX':installation_sha})
    runtime['current_control_api.py']=bind(runtime['current_control_api.py'],{'BRANCH':s['refs']['g3']})
    runtime['current_tools_control_api.py']=bind(runtime['current_tools_control_api.py'],{'BRANCH':s['refs']['tools'],'PARENT':s['control_parents']['tools']})
    old_binding=parse(b['host'][CARRIER+'CARRIER_COMPOSITION.json'])
    substitutions=[(old_binding['branch'],s['refs']['host']),
        (old_binding['host_tools']['control_branch'],s['refs']['tools']),
        (old_binding['host_tools']['control_parent'],s['control_parents']['tools']),
        (literal(b['host'][CORE+'g3_receiving.py'],'CONTROL_BRANCH'),s['refs']['g3'])]
    bridge=runtime['g132_operator_bridge.js']
    for before,after in substitutions:bridge=exact_replace(bridge,("'"+before+"'").encode(),("'"+after+"'").encode(),1)
    runtime['g132_operator_bridge.js']=bridge
    composition=copy.deepcopy(b['composition']);composition['installation_index_sha256']=installation_sha
    composition['files']={n:desc(v) for n,v in runtime.items()};composition_raw=encode(composition);composition_sha=desc(composition_raw)['sha256']
    interface=bind(b['interface'],{'COMPOSITION_SHA':composition_sha,'INSTALLATION_SHA':installation_sha})
    destination=Path(s['generation_directory'])
    installer=exact_replace(b['installer'],str(INTERFACE).encode(),str(destination/'current_interfaces.py').encode(),1)
    installer=bind(installer,{'INTERFACE_PIN':desc(interface),'INSTALLATION_SHA':installation_sha})
    unissued=parse(b['unissued_config']);unissued['installation']={
        'path':str(destination/'packet/dependencies/installation'),'index_sha256':installation_sha}
    need(unissued['state']=='UNISSUED','CONFIG_REMAINS_UNISSUED')
    members={'packet/dependencies/installation/'+n:v for n,v in installation.items()}
    members['packet/dependencies/installation/SOURCE_INDEX.json']=installation_raw
    members.update({'packet/source/'+n:v for n,v in runtime.items()})
    members.update({'packet/COMPOSITION_SOURCE_INDEX.json':composition_raw,'packet/ROOT_CONTROL_CONFIG_UNISSUED.json':encode(unissued),
        'complete-sources/issuer.py':issuer,'current_interfaces.py':interface,'late_sender_install.py':installer,
        'HOST_OBJECT_ROOT_RECEIVING.json':encode(receiving)})
    out=stage('MODEL_COMPLETE_UNISSUED_REQUIRES_INDEPENDENT_REVIEW',b,s,members,None,host['consumed_admissions'])
    out['host_identity']=identity;out['installation_index']=desc(installation_raw);out['composition_index']=desc(composition_raw)
    out['installation_members']=len(index['files']);out['runtime_members']=len(runtime)
    out['historical_scope_repair_unchanged']=desc(installation['SCOPE_REPAIR_SOURCE_DELTA.json']);out['operation_adoption_issued']=False
    return out

def output_payload(value):
    metadata={k:v for k,v in value.items() if k not in ('members','git_trees','lineage_bodies')}
    files=dict(value['members']);groups={'members':{name:name for name in files}}
    for group,prefix,suffix in (('git_trees','publication-trees/','.tree'),('lineage_bodies','publication-lineage/','.commit')):
        if group in value:
            groups[group]={}
            for key,raw in value[group].items():
                name=prefix+key+suffix;need(name not in files,'OUTPUT_GROUP_COLLISION')
                groups[group][key]=name;files[name]=raw
    need(SEAL not in files and len(files)<=256 and sum(map(len,files.values()))<=MAX_STAGE,'BOUNDED_STAGE_POPULATION')
    for name,raw in files.items():
        canonical_member(name);need(type(raw) is bytes and 0<len(raw)<=MAX_SOURCE,'BOUNDED_STAGE_BODY')
    paths={PurePosixPath(n) for n in files}
    need(not any(p in paths for path in paths for p in path.parents),'OUTPUT_PATH_COLLISION')
    return metadata,files,groups

def _write_member(parent,name,raw):
    fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=parent)
    try:
        offset=0
        while offset<len(raw):
            count=os.write(fd,raw[offset:]);need(count>0,'OUTPUT_WRITE_PROGRESS');offset+=count
        os.fchmod(fd,0o444);os.fsync(fd)
    finally:os.close(fd)

def write_stage(path,value,dependencies=(),reads=None):
    """One exclusive owned directory; retain all partials, never retry or delete."""
    path=Path(path);metadata,files,groups=output_payload(value)
    separate_output(path,reads.populations if reads else ())
    need(path.is_absolute() and str(path)==str(path.absolute()) and path.parent.resolve(strict=True)==path.parent
         and '..' not in path.parts and not path.exists() and not path.is_symlink(),'FRESH_CANONICAL_OUTPUT')
    parent=path.parent.lstat();parents=ancestry(path)
    need(parent.st_uid==os.geteuid() and not parent.st_mode & 0o022,'OWNED_OUTPUT_PARENT')
    if reads:reads.current()
    path.mkdir(mode=0o700);fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
    opening=directory_stamp(os.fstat(fd));fds={'.':fd};directories={'.':opening}
    def root_current():
        need(directory_stamp(path.lstat())==opening==directory_stamp(os.fstat(fd))
             and not path.is_symlink() and ancestry(path)==parents,'OUTPUT_SELECTED_DIRECTORY_CHANGED')
    def current_tree(expected):
        root_current();actual=[]
        for p in path.rglob('*'):
            need(not p.is_symlink(),'OUTPUT_ALIAS')
            name=p.relative_to(path).as_posix()
            if p.is_dir():
                need(name in directories and directory_stamp(p.lstat())==directories[name],'OUTPUT_CHILD_DIRECTORY_CHANGED')
            else:actual.append(name)
        need(set(actual)==set(expected),'CLOSED_OUTPUT_POPULATION')
        check=Reads()
        for name,body in expected.items():need(check.body(path/name,desc(body))==body,'OUTPUT_BYTE_READBACK')
        root_current()
    try:
        dirs=sorted({str(p) for n in files for p in PurePosixPath(n).parents if str(p)!='.'},key=lambda n:(len(PurePosixPath(n).parts),n))
        for name in dirs:
            p=PurePosixPath(name);parent_fd=fds[str(p.parent)];root_current()
            os.mkdir(p.name,0o700,dir_fd=parent_fd)
            child=os.open(p.name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=parent_fd)
            fds[name]=child;directories[name]=directory_stamp(os.fstat(child))
        for name,body in sorted(files.items()):
            root_current();p=PurePosixPath(name);_write_member(fds[str(p.parent)],p.name,body)
        for child in fds.values():os.fsync(child)
        current_tree(files)
        if reads:reads.current()
        seal=encode({'schema':'g132.finite-source-stage-custody.v1','authority':'NONE','metadata':metadata,
            'groups':groups,'files':{name:desc(raw) for name,raw in files.items()},'dependencies':list(dependencies),
            'original_awards':[],'native_calls':0,'provider_calls':0,'automatic_retry':False})
        root_current();_write_member(fd,SEAL,seal);os.fsync(fd)
        current_tree(dict(files,**{SEAL:seal}))
        if reads:reads.current()
        root_current();return desc(seal)
    finally:
        for child in reversed(list(fds.values())):os.close(child)

def read_stage(path,sha,reads):
    path=Path(path);raw=reads.body(path/SEAL,{'sha256':sha},maximum=MAX_STAGE);sealed=parse(raw)
    need(sealed['schema']=='g132.finite-source-stage-custody.v1' and sealed['authority']=='NONE'
         and sealed['original_awards']==[] and sealed['automatic_retry'] is False,'EXACT_SOURCE_STAGE_CUSTODY')
    reads.population(path,set(sealed['files'])|{SEAL})
    files={name:reads.body(path/name,pin) for name,pin in sealed['files'].items()}
    metadata=sealed['metadata'];need(metadata['baseline_installation_sha256']==INSTALLATION_SHA
        and metadata['baseline_composition_sha256']==COMPOSITION_SHA and metadata['protected_grant'] is False,
        'EXACT_CURRENT_BASELINE_STAGE')
    used=[];value=dict(metadata)
    for group,rows in sealed['groups'].items():
        need(group in ('members','git_trees','lineage_bodies'),'EXACT_STAGE_GROUP')
        value[group]={key:files[name] for key,name in rows.items()};used.extend(rows.values())
    need(len(used)==len(set(used)) and set(used)==set(files),'CLOSED_STAGE_GROUPS')
    for dep in sealed['dependencies']:
        need(set(dep)=={'path','bytes','sha256','role'},'EXACT_STAGE_DEPENDENCY')
        reads.body(dep['path'],{k:dep[k] for k in ('bytes','sha256')},dep['role'])
    return value,sealed['dependencies']

def data_input(reads,path,sha,role='public'):
    need(path is not None and sha is not None and re.fullmatch('[0-9a-f]{64}',sha),'EXACT_INPUT_ARGUMENTS')
    raw=reads.body(path,{'sha256':sha},role)
    return raw,dict(path=path,role=role,**desc(raw))

def main():
    need(os.getuid()==os.geteuid()>0 and os.getgid()==os.getegid(),'NONROOT_SOURCE_PROCESS')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=('core-requirements','core','carrier','host','object-requirements','model'))
    for name in ('selection','selection-sha256','stage','stage-sha256','admission','admission-sha256',
                 'receiving','receiving-sha256','commit','commit-sha256'):
        p.add_argument('--'+name)
    p.add_argument('--output',required=True);args=p.parse_args();reads=Reads();b=receive_baseline(reads)
    if args.command=='core-requirements':
        need(args.stage is None and args.admission is None and args.receiving is None and args.commit is None,'CORE_REQUIREMENTS_INPUTS_ONLY')
        raw,dep=data_input(reads,args.selection,args.selection_sha256);selection=parse(raw)
        need(raw==encode(selection),'CANONICAL_ROOT_SELECTION_BYTES')
        result=core_requirements(b,selection);selected_public_git(selection,reads);dependencies=[dep]
    else:
        need(args.selection is None and args.selection_sha256 is None and args.stage is not None
             and args.stage_sha256 is not None,'EXACT_PREDECESSOR_ARGUMENTS')
        prior,dependencies=read_stage(args.stage,args.stage_sha256,reads);select(b,prior['selection'])
        if args.command in ('core','carrier','host'):
            need(args.receiving is None and args.commit is None,'ADMISSION_STAGE_INPUTS_ONLY')
            role='core_admission' if args.command=='core' else 'public'
            raw,dep=data_input(reads,args.admission,args.admission_sha256,role);dependencies=[*dependencies,dep]
            if args.command=='core':result=host_core(b,prior,raw)
            elif args.command=='carrier':result=host_carrier(b,prior,raw)
            else:result=complete_host(b,prior,raw,selected_public_git(prior['selection'],reads))
        elif args.command=='object-requirements':
            need(args.admission is None and args.receiving is None,'OBJECT_REQUIREMENTS_INPUTS_ONLY')
            need(prior['stage']=='HOST_COMPLETE_REQUIRES_ACTUAL_PROVIDER_OBJECT_RECEIVING','FINISHED_HOST_REQUIRED')
            commit,dep=data_input(reads,args.commit,args.commit_sha256);dependencies=[*dependencies,dep]
            result=stage('HOST_OBJECT_RECEIVING_REQUIREMENTS_NOT_AN_ADMISSION',b,prior['selection'],consumed=prior['consumed_admissions'])
            result['required_host_object_root_receiving']=host_receiving_requirement(prior,commit)
            result['required_additional_root_field']='actual_provider_receiving: exact path/bytes/sha256 of independently received actual provider object evidence'
            result['host_stage_sha256']=args.stage_sha256
            result['actual_root_receiving_issued']=False
            result['provider_object_observed_by_finalizer']=False
        else:
            need(args.admission is None and args.admission_sha256 is None,'MODEL_RECEIVING_INPUTS_ONLY')
            raw,dep=data_input(reads,args.receiving,args.receiving_sha256);receiving=parse(raw)
            need(raw==encode(receiving),'CANONICAL_ROOT_RECEIVING_BYTES')
            commit,commit_dep=data_input(reads,args.commit,args.commit_sha256)
            evidence=receiving['actual_provider_receiving']
            reads.body(evidence['path'],{k:evidence[k] for k in ('bytes','sha256')},'public')
            dependencies=[*dependencies,dep,commit_dep,dict(evidence,role='public')]
            result=model_generation(b,prior,receiving,commit)
            need(args.output==prior['selection']['generation_directory'],'EXACT_SELECTED_MODEL_DESTINATION')
    pinned={row['path']:row for row in dependencies}
    need(len(pinned)==len(dependencies),'NO_RESELECTED_STAGE_DEPENDENCY')
    seal=write_stage(args.output,result,dependencies,reads)
    print(encode({'state':result['stage'],'output':args.output,'seal':seal,'authority':'NONE',
                  'original_awards':[],'protected_grant':False,'provider_calls':0,'native_calls':0}).decode(),end='')

if __name__=='__main__':main()
