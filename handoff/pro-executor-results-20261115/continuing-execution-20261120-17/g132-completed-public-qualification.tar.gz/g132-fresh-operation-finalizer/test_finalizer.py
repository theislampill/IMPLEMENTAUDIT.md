"""Public-only source controls. TEST_ONLY bodies cannot enter production entry.

No historical private input, original assembly, issuer derive, provider, native
capture, sender, encryption, hosted controller, or ref call is made.
"""
import argparse
import ast
import copy
from contextlib import contextmanager
import importlib.util
import json
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
import finalize_g132 as F

CONTROL_ROOT=None

@contextmanager
def fixture_scope():
    # Only this in-memory test module changes; no production source flag exists.
    with patch.object(F,'ROOT_ISSUER','TEST_ONLY_NOT_ROOT'),patch.object(F,'ROOT_STATE','TEST_ONLY_SOURCE_CONTROL'):
        yield

class FiniteFinalizer(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.b=F.receive_baseline();b=cls.b;install=F.BASE/'dependencies/installation'
        identity=F.parse(b['installation']['HOST_IDENTITY_UNISSUED.json']);parent=identity['commit']
        chain=[parent]+F.literal(b['runtime']['current_pro_interfaces.py'],'chain','CurrentSources._check_git_identity')
        commits={key:b['installation'][('git-candidate/' if key==parent else 'git-lineage/')+key+'.commit'] for key in chain}
        all_trees={name.split('/')[-1][:-5]:raw for name,raw in b['installation'].items() if name.startswith('git-candidate/') and name.endswith('.tree')}
        root_id=identity['tree'];root=F.parse_tree(all_trees[root_id]);github_id=root['.github'][1]
        github=F.parse_tree(all_trees[github_id]);tree_ids={root_id,github_id,github['workflows'][1],root['qualification'][1]}
        trees={key:all_trees[key] for key in tree_ids};cls.public={'commits':commits,'trees':trees}
        binding=F.parse(b['host'][F.CARRIER+'CARRIER_COMPOSITION.json'])
        cls.selection={'schema':'g132.fresh-operation-source-selection.v1','issuer':'TEST_ONLY_NOT_ROOT',
            'state':'TEST_ONLY_SOURCE_CONTROL','operation_id':'G132_ORIGINAL_20261120_01','repository':F.REPOSITORY,
            'source_commit':F.SOURCE,'source_tree':F.TREE,'refs':copy.deepcopy(F.PROPOSED_REFS),
            'control_parents':{'cipher':binding['control_parent'],'tools':binding['host_tools']['control_parent']},
            'publication_parent':parent,'publication_lineage':chain,
            'public_git_inputs':{
                'commits':{key:dict(path=str(install/('git-candidate/' if key==parent else 'git-lineage/')/(key+'.commit')),**F.desc(raw)) for key,raw in commits.items()},
                'trees':{key:dict(path=str(install/'git-candidate'/(key+'.tree')),**F.desc(raw)) for key,raw in trees.items()}},
            'generation_directory':str(CONTROL_ROOT/'TEST_ONLY_model'),'effect_grant':False,'original_awards':[]}
        with fixture_scope():
            cls.s0=F.core_requirements(b,cls.selection)
            cls.core_raw=F.encode(cls.s0['expected_admission']);cls.s1=F.host_core(b,cls.s0,cls.core_raw)
            cls.carrier_raw=F.encode(cls.s1['expected_admission']);cls.s2=F.host_carrier(b,cls.s1,cls.carrier_raw)
            cls.bootstrap_raw=F.encode(cls.s2['expected_admission'])
            cls.host=F.complete_host(b,cls.s2,cls.bootstrap_raw,cls.public)
            cls.commit_raw=('tree '+cls.host['publication']['tree']+'\nparent '+parent+
                '\nauthor TEST_ONLY <fixture.invalid> 0 +0000\ncommitter TEST_ONLY <fixture.invalid> 0 +0000\n\nTEST_ONLY_NO_PROVIDER_OBJECT\n').encode()
            cls.receiving=F.host_receiving_requirement(cls.host,cls.commit_raw)
            cls.evidence=F.encode({'classification':'TEST_ONLY_LOCAL_SOURCE_CONTROL','actual_provider_calls':0,'authority':'NONE'})
            evidence_path=CONTROL_ROOT/'TEST_ONLY_PROVIDER_EVIDENCE.json';evidence_path.write_bytes(cls.evidence);evidence_path.chmod(0o444)
            cls.receiving['actual_provider_receiving']=dict(path=str(evidence_path),**F.desc(cls.evidence))
            cls.model=F.model_generation(b,cls.host,cls.receiving,cls.commit_raw)
        (CONTROL_ROOT/'TEST_ONLY_ADMISSIONS.json').write_bytes(F.encode({'classification':'TEST_ONLY_NEVER_CURRENT',
            'selection':cls.selection,'core':F.parse(cls.core_raw),'carrier':F.parse(cls.carrier_raw),
            'bootstrap':F.parse(cls.bootstrap_raw),'provider_receiving':cls.receiving,'actual_root_admissions':False}))

    def test_received_exact_source_and_historical_private_index(self):
        self.assertEqual(len(self.b['host']),53);self.assertFalse(self.b['private_original_inputs_read'])
        old=F.parse(self.b['host'][F.CARRIER+'INPUT_INDEX.json']);new=F.parse(self.host['members'][F.CARRIER+'INPUT_INDEX.json'])
        self.assertEqual(len(old),11);self.assertEqual(len(new),11)
        self.assertEqual({n for n in old if old[n]!=new[n]}, {'COMPOSITION_ROOT_ADMISSION.json'})

    def test_test_only_selection_and_receiving_refused_by_production(self):
        with self.assertRaisesRegex(ValueError,'GENUINE_ROOT_SOURCE_SELECTION_REQUIRED'):
            F.core_requirements(self.b,self.selection)
        with self.assertRaisesRegex(ValueError,'GENUINE_ROOT_SOURCE_SELECTION_REQUIRED'):
            F.model_generation(self.b,self.host,self.receiving,self.commit_raw)

    def test_source_tree_cannot_be_output_destination(self):
        for path in (F.BASE/'fresh',F.INSTALLER.parent/'fresh',Path(F.__file__).parent/'fresh'):
            with self.assertRaisesRegex(ValueError,'OUTPUT_MUST_NOT_MODIFY'):
                F.write_stage(path,self.s0)

    def test_historical_branch_core_admission_refused(self):
        bad=F.parse(self.core_raw);bad['workflow_branch']='pro/dg16-g1-original-g3-32-20261114'
        with fixture_scope(),self.assertRaisesRegex(ValueError,'ACTUAL_EXACT_ROOT_ADMISSION_REQUIRED'):
            F.host_core(self.b,self.s0,F.encode(bad))

    def test_admission_stale_pin_and_boolean_attempt_refused(self):
        bad=F.parse(self.carrier_raw);bad['input_index_sha256']='0'*64
        with fixture_scope(),self.assertRaisesRegex(ValueError,'ACTUAL_EXACT_ROOT_ADMISSION_REQUIRED'):
            F.host_carrier(self.b,self.s1,F.encode(bad))
        bad=F.parse(self.core_raw);bad['run_attempt']=True
        with fixture_scope(),self.assertRaisesRegex(ValueError,'ACTUAL_EXACT_ROOT_ADMISSION_REQUIRED'):
            F.host_core(self.b,self.s0,F.encode(bad))

    def test_bootstrap_wrong_manifest_refused(self):
        bad=F.parse(self.bootstrap_raw);bad['manifest_sha256']='0'*64
        with fixture_scope(),self.assertRaisesRegex(ValueError,'ACTUAL_EXACT_ROOT_ADMISSION_REQUIRED'):
            F.host_finish(self.b,self.s2,F.encode(bad))

    def test_wrong_commit_tree_and_parent_refused(self):
        for before,after in [(self.host['publication']['tree'],'0'*40),(self.selection['publication_parent'],'1'*40)]:
            bad=self.commit_raw.replace(before.encode(),after.encode(),1)
            with fixture_scope(),self.assertRaisesRegex(ValueError,'ACTUAL_HOST_TREE_PARENT_JOIN'):
                F.model_generation(self.b,self.host,self.receiving,bad)

    def test_missing_actual_receiving_and_extra_base_tree_refused(self):
        bad=copy.deepcopy(self.receiving);bad.pop('actual_provider_receiving')
        with fixture_scope(),self.assertRaisesRegex(ValueError,'GENUINE_ROOT_ACTUAL_PROVIDER_RECEIVING_REQUIRED'):
            F.model_generation(self.b,self.host,bad,self.commit_raw)
        bad=copy.deepcopy(self.public);extra=next((n.split('/')[-1][:-5],v) for n,v in self.b['installation'].items()
            if n.startswith('git-candidate/') and n.endswith('.tree') and n.split('/')[-1][:-5] not in bad['trees'])
        bad['trees'][extra[0]]=extra[1]
        with self.assertRaisesRegex(ValueError,'CLOSED_BASE_TREE_INPUTS'):
            F.publication_tree(self.host['members'],self.selection,bad)

    def test_scope_repair_m4_and_function_bodies_preserved(self):
        for name,body in self.b['host'].items():
            new=self.host['members'][name]
            if name.endswith('.py'):
                functions=lambda raw:{n.name:ast.dump(n,include_attributes=False) for n in ast.parse(raw).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
                self.assertEqual(functions(body),functions(new),name)
            if '/retained-m4/' in name or name.endswith(('ORIGINAL_SCOPE.json','SOURCE_MANIFEST.json','ADVERSE_APPLICABILITY.json','NATIVE_SOURCE_APPLICABILITY.json')):
                self.assertEqual(body,new,name)
        key='packet/dependencies/installation/SCOPE_REPAIR_SOURCE_DELTA.json'
        self.assertEqual(self.model['members'][key],self.b['installation']['SCOPE_REPAIR_SOURCE_DELTA.json'])

    def test_generated_peer_pins_close(self):
        host=self.host['members'];binding=F.parse(host[F.CARRIER+'CARRIER_COMPOSITION.json'])
        for name,pin in binding['core_bodies'].items():self.assertEqual(F.desc(host[F.CORE+name]),pin)
        for name,pin in F.literal(host[F.CARRIER+'carrier_loader.py'],'MODULE_PINS').items():
            self.assertEqual(F.desc(host[F.CARRIER+name+'.py']),pin)
        manifest=F.parse(host[F.ENTRY+'PUBLIC_PACKET_MANIFEST.json'])
        self.assertEqual(manifest['members'],{n.removeprefix(F.CORE):dict(**F.desc(v),mode=0o400) for n,v in host.items() if n.startswith(F.CORE)})
        for name,pin in F.literal(host[F.CORE+'run.py'],'MODULE_PINS').items():
            self.assertEqual(F.desc(host[F.CORE+name+'.py'])['sha256'],pin)
        self.assertEqual(F.literal(host[F.ENTRY+'entry_common.py'],'CARRIER_LOADER_DESCRIPTOR'),F.desc(host[F.CARRIER+'carrier_loader.py']))

    def test_public_tree_retains_unselected_entries(self):
        before=F.parse_tree(self.public['trees'][self.host['publication']['parent_tree']])
        after=F.parse_tree(self.host['git_trees'][self.host['publication']['tree']])
        self.assertEqual({n:v for n,v in before.items() if n not in ('.github','qualification')},
                         {n:v for n,v in after.items() if n not in ('.github','qualification')})
        for ancestor,changed in [('qualification',{F.CORE.rstrip('/').split('/')[-1],F.ENTRY.rstrip('/').split('/')[-1]}),('.github',{'workflows'})]:
            old=F.parse_tree(self.public['trees'][before[ancestor][1]])
            new=F.parse_tree(self.host['git_trees'][after[ancestor][1]])
            self.assertEqual({n:v for n,v in old.items() if n not in changed},{n:v for n,v in new.items() if n not in changed})

    def test_exact_replacement_count_and_changed_literal_refuse(self):
        with self.assertRaisesRegex(ValueError,'EXACT_REPLACEMENT_COUNT'):
            F.exact_replace(b'abc abc',b'abc',b'def',1)
        with self.assertRaisesRegex(ValueError,'OLD_LITERAL_CHANGED'):
            F.splice(b'VALUE = 1\n','VALUE',2,3)

    def test_public_git_input_receiving(self):
        reads=F.Reads();actual=F.selected_public_git(self.selection,reads);reads.current()
        self.assertEqual(actual,self.public)

    def test_source_currentness_rejects_body_and_population_change(self):
        root=CONTROL_ROOT/'TEST_ONLY_currentness';root.mkdir(mode=0o700);p=root/'body.txt';p.write_bytes(b'public source\n');p.chmod(0o444)
        reads=F.Reads();reads.body(p,F.desc(p.read_bytes()));reads.population(root,{'body.txt'})
        (root/'extra.txt').write_bytes(b'public extra\n')
        with self.assertRaisesRegex(ValueError,'CLOSED_SOURCE_POPULATION'):reads.current()
        p.chmod(0o644);p.write_bytes(b'changed source\n');p.chmod(0o444)
        with self.assertRaisesRegex(ValueError,'INPUT_PIN_CHANGED|INPUT_RESELECTED_OR_CHANGED'):reads.current()

    def test_stage_round_trip_replay_and_extra_member_refusal(self):
        path=CONTROL_ROOT/'TEST_ONLY_stage';seal=F.write_stage(path,self.s0)
        received,deps=F.read_stage(path,seal['sha256'],F.Reads());self.assertEqual(received,self.s0);self.assertEqual(deps,[])
        with self.assertRaisesRegex(ValueError,'FRESH_CANONICAL_OUTPUT'):F.write_stage(path,self.s0)
        (path/'extra.txt').write_bytes(b'public extra\n')
        with self.assertRaisesRegex(ValueError,'CLOSED_SOURCE_POPULATION'):F.read_stage(path,seal['sha256'],F.Reads())

    def test_stage_directory_replacement_during_seal_does_not_receive_success(self):
        path=CONTROL_ROOT/'TEST_ONLY_rebind';moved=CONTROL_ROOT/'TEST_ONLY_original_moved';original=F._write_member
        def replacing(parent,name,raw):
            if name==F.SEAL:
                path.rename(moved);path.mkdir(mode=0o700)
            return original(parent,name,raw)
        with patch.object(F,'_write_member',replacing),self.assertRaisesRegex(ValueError,'OUTPUT_SELECTED_DIRECTORY_CHANGED'):
            F.write_stage(path,self.s0)
        self.assertFalse((path/F.SEAL).exists());self.assertTrue((moved/F.SEAL).exists())

    def test_generated_runtime_source_only_load(self):
        path=Path(self.selection['generation_directory']);seal=F.write_stage(path,self.model)
        source=path/'current_interfaces.py';spec=importlib.util.spec_from_file_location('g132_TEST_ONLY_current_interface',source)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        runtime=module.load_runtime(path/'packet');runtime.current()
        self.assertEqual(runtime.sources.identity['commit'],F.oid('commit',self.commit_raw))
        self.assertEqual(len(runtime.sources.phase['members']),53)
        self.assertEqual(runtime.sources.G.CONTROL_BRANCH,self.selection['refs']['g3'])
        self.assertEqual(runtime.sources.issuer.HOST_TREE,self.host['publication']['tree'])
        (CONTROL_ROOT/'TEST_ONLY_RUNTIME_SOURCE_CHECK.json').write_bytes(F.encode({'classification':'TEST_ONLY_SOURCE_CHECK',
            'seal':seal,'host_commit_is_fixture':True,'source_only_loaded':True,'original_awards':[],
            'native_capture_calls':0,'private_original_inputs_read':False,'provider_calls':0}))

    def test_z_all_staged_command_entries(self):
        """Actual local CLI dispatch, fresh paths, TEST_ONLY declarations only."""
        root=CONTROL_ROOT/'TEST_ONLY_cli';root.mkdir(mode=0o700)
        selection=copy.deepcopy(self.selection);selection['generation_directory']=str(root/'model')
        def put(name,raw,private=False):
            path=root/name;path.write_bytes(raw);path.chmod(0o600 if private else 0o444)
            return str(path),F.desc(raw)['sha256']
        selected,selected_sha=put('TEST_ONLY_SELECTION.json',F.encode(selection))
        def command(name,arguments,out):
            with fixture_scope(),patch.object(sys,'argv',['finalize_g132.py',name,*arguments,'--output',str(out)]):
                F.main()
            return F.desc((out/F.SEAL).read_bytes())['sha256']
        p0=root/'core_requirements';h0=command('core-requirements',['--selection',selected,'--selection-sha256',selected_sha],p0)
        def advance(command_name,previous,previous_sha,out):
            value,_=F.read_stage(previous,previous_sha,F.Reads())
            name='TEST_ONLY_'+command_name+'_ADMISSION.json'
            path,digest=put(name,F.encode(value['expected_admission']),command_name=='core')
            return command(command_name,['--stage',str(previous),'--stage-sha256',previous_sha,
                           '--admission',path,'--admission-sha256',digest],out)
        p1=root/'core';h1=advance('core',p0,h0,p1)
        p2=root/'carrier';h2=advance('carrier',p1,h1,p2)
        p3=root/'host';h3=advance('host',p2,h2,p3)
        host,_=F.read_stage(p3,h3,F.Reads())
        commit=('tree '+host['publication']['tree']+'\nparent '+selection['publication_parent']+
            '\nauthor TEST_ONLY <fixture.invalid> 0 +0000\ncommitter TEST_ONLY <fixture.invalid> 0 +0000\n\nTEST_ONLY_CLI_NO_PROVIDER\n').encode()
        commit_path,commit_sha=put('TEST_ONLY_LOCAL_COMMIT.raw',commit)
        object_req=root/'object_requirements'
        h4=command('object-requirements',['--stage',str(p3),'--stage-sha256',h3,'--commit',commit_path,'--commit-sha256',commit_sha],object_req)
        request,_=F.read_stage(object_req,h4,F.Reads());receiving=request['required_host_object_root_receiving']
        self.assertFalse(request['actual_root_receiving_issued']);self.assertFalse(request['provider_object_observed_by_finalizer'])
        evidence,evidence_sha=put('TEST_ONLY_PROVIDER_RECEIVING.json',self.evidence)
        receiving['actual_provider_receiving']=dict(path=evidence,**F.desc(self.evidence))
        receipt,receipt_sha=put('TEST_ONLY_ROOT_RECEIVING.json',F.encode(receiving))
        final=root/'model'
        last=command('model',['--stage',str(p3),'--stage-sha256',h3,'--commit',commit_path,'--commit-sha256',commit_sha,
                            '--receiving',receipt,'--receiving-sha256',receipt_sha],final)
        model,_=F.read_stage(final,last,F.Reads())
        self.assertEqual(model['stage'],'MODEL_COMPLETE_UNISSUED_REQUIRES_INDEPENDENT_REVIEW')
        self.assertEqual(model['runtime_members'],12);self.assertFalse(model['protected_grant'])
        (CONTROL_ROOT/'TEST_ONLY_CLI_ROUTE.json').write_bytes(F.encode({'classification':'TEST_ONLY_ALL_STAGED_COMMANDS',
            'stages':{'core-requirements':h0,'core':h1,'carrier':h2,'host':h3,'object-requirements':h4,'model':last},
            'actual_root_admissions':False,'original_awards':[],'provider_calls':0,'native_capture_calls':0}))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--control-root',required=True);args,remaining=parser.parse_known_args()
    CONTROL_ROOT=Path(args.control_root).absolute();CONTROL_ROOT.mkdir(mode=0o700,parents=False)
    unittest.main(argv=[__file__,*remaining],verbosity=2)
