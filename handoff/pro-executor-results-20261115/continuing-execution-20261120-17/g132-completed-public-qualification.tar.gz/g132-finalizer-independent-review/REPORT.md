# Finite G132 finalizer: independent source and control receiving

**Technical disposition: SOURCE_READY_FOR_GENUINE_ROOT_STAGED_SELECTION_AND_RECEIVING. Authority NONE.** No remaining source blocker was found in the exact finite finalizer and retained public controls reviewed here. This disposition supports Root considering the six source-generation stages with genuinely issued, digest-selected inputs. It does not issue any selection or admission, authenticate a provider result, adopt the generated model, grant a protected operation, or award original G1/G3 acceptance.

## Exact scope and fresh receiving

The reviewed packet is `/workspace/scratch/530bc07ea12b/g132-fresh-operation-finalizer/MANIFEST.json`, SHA-256 `1681e5f13dbedd554f3f178c37802e9adb1de45fbabd8b3b6fb6cd8061276b1b`: 15 selected files, 111,132 bytes. Its exact source is 45,265 bytes/SHA-256 `e9285e1898865d281022030c8c576bc7cf01f8c22af1f8e21e2999d8871510be`; tests are 17,583 bytes/SHA-256 `d5847611ae5ce9305ea36921ea6e9072d3fc0f2e07773df91068fefc25619aa1`. The selected top-level population and all manifest modes/digests were received. The explicitly excluded local TEST_ONLY subtree is separately inventoried as control evidence.

Fresh receiving `6fdeed/0` passed 41 independent checks over 1,094 exact files. `VERIFICATION.json` is 625,801 bytes/SHA-256 `9bb96bf8511863c3128da6c7dc3aee78da2d0f759d13e403851763170012df95`. It records complete file identity tuples using Python exact integers, parent identities, three complete control censuses, source and stage pins, and closing rereads. No target source was imported or executed by this reviewer. The receiver reads public source/evidence as data and performs independent AST, byte, JSON, Git-object and population comparisons.

The interpreter is the explicit primary-runtime Python3 path and reports Python3.12.14 (`11ebc6/0`). It is separate from the preserved original hosted Python3.12.3 selector. All reviewed source inputs satisfy the actual finalizer reader predicates: owned regular one-link files, no symlink aliases/xattrs, canonical paths, allowed mode and bounded exact body, with opening/closing identity and parent joins. The corrected installer is received as the specific pinned0644 public derivation body; it is never imported by the finalizer. The new core-admission input uses the distinct0600 role. Retained fixture dependencies were checked using those actual role predicates rather than a generic permissive read.

## Prerequisites remain separate and exact

The installer r2 independent seal `78dc6ce4bd18c04de90f45a59d241667af90a2921a2f281990e2b9c0dac714eb` and all four members were rereceived. Its bounded I1 correction is unchanged: original episode identity is carried through complete tree receiving and receipt writing, followed by closing path/descriptor/tree/receipt joins. This finalizer changes only that installer's interface location and exact interface/installation pins. Its correction functions remain unchanged.

The public-positive actual independent seal `0155fe959e311b66afb57a1c23edeef2e0526038214172df065e048be32afeba` and all four members were rereceived. It qualifies only the one public fixture encryption and outer AuthEnvelopedData DER type observed in `0d52a8/0`, with PC01–PC06 received. It supplies no decryption, AEAD, original-sender or original G1/G3 result. The old entry refusal, superseded readiness finding, integer-projection correction and historical unknowns remain unchanged. No encryption, native capture or retry was performed here.

## Staged dependency chain and authority boundary

| Stage | Independently checked behavior | Actual authority still needed |
| --- | --- | --- |
| Core requirements | Exact fixed source/tree, four distinct selected refs, distinct seed parents, bounded ordered lineage, public object descriptors and separate generation destination | Genuine Root selection; requirements are not an admission |
| Core | Exact canonical core admission; only its descriptor changes among eleven private-input descriptors; ten historical descriptors remain byte-equivalent | Genuine new Root core admission, selected0600 body |
| Carrier | Updated workflow/index/seed bindings; complete core-body pins, carrier policy/loader and public manifest | Genuine canonical carrier admission |
| Host | Bootstrap binds the public manifest; entry/common/wrapper pins close; exactly53 hosted bodies and independently recomputed nine tree objects | Genuine canonical bootstrap admission |
| Object requirements | Exact received commit bytes must name the selected tree and sole selected publication parent | Actual Root provider-object receiving remains unissued by requirements |
| Model | Exact host-object receiving fields, exact commit body, bound provider-evidence body descriptor, selected destination, complete host/model/interface/installer bindings | Root's genuine receiving and subsequent independent whole-model/source adoption |

There is no admission/hash cycle. The core admission binds three other input hashes, not its own descriptor. Its new descriptor feeds the input index and carrier requirements. Carrier admission binds workflow/index/seeds; the carrier composition then binds that admission. The public manifest covers the core subtree; bootstrap admission lives in the separate entry subtree and binds the manifest. The completed host determines its tree and actual commit; the model-side receiving and issuer constants are bound after that object is received, outside the hosted source population.

The finalizer mechanically validates canonical bodies, exact fields and pins. A matching `issuer` string or an arbitrary pinned evidence file does not independently authenticate Root or prove a provider call happened. Genuine issuance and actual provider provenance remain Root's external receiving responsibility, as the input contract states. The source does not silently promote a requirement or local Git hash into that evidence.

## Scope, projections, populations and bindings

All hosted Python function/class bodies remain AST-identical to the repaired baseline. The independent comparison permits only the enumerated constant assignments. Every module/data/manifest/bootstrap pin was recomputed from the actual retained bodies. The workflow differs only in the selected branch occurrences and run label; its original Ubuntu24.04 selector and75-minute budget remain intact. Unchanged executable bodies preserve their other clocks, limits and security predicates.

Original source scope `e76a07b2bae7c945e5a9d529ed8cf9069f4c9064` / `ff9fc6793892147aecc59bdfc4ddb82fc37f9eb7` is not changed by this work. `ORIGINAL_SCOPE.json`, source manifest, native/adverse applicability, all four retained M4 bodies and `SCOPE_REPAIR_SOURCE_DELTA.json` remain byte-identical. The original obligation census remains DG16=48, DG17=95, DG18=14, total157.

| Population | Baseline | Received control successor | Interpretation |
| --- | ---: | ---: | --- |
| Installation indexed members |157|150|New exact source census; historical packet untouched |
| Candidate Git members |10|10|Nine trees plus one candidate commit |
| Lineage Git members |14|7|Selected exact seven-commit lineage replaces old raw-object set |
| Hosted phase bodies |53|53|Same complete member set |
| Runtime source bodies |12|12|Same complete member set |
| Sender-author indexed subset |46|46|Every body unchanged; its separate index is also retained |
| Pure projection members |17|17|Same member set and validator behavior |

The150 count is the exact received control generation using the seven selected lineage commits; it does not replace the157 original obligations. Production closes the generated index and actual member population. Root's proposed seven-commit lineage has the same census shape. Across file names, the control has16 removed Git names and9 added Git names; the underlying historical157-member packet remains intact.

The G3 model projection's existing adapter replaces one original-scope file-read expression with `current_original_scope_body()`. Its full-source body is exactly35 bytes shorter than the hosted source. Both old and new full-source descriptors, projection descriptors, preserved validator functions and changed branch constants were independently joined. Other projection rows remain unchanged. No validator was weakened to obtain a passing source load.

The model contains the exact received53 hosted bodies, all nine independently recomputed trees, the exact candidate commit and all seven selected lineage commits. Runtime installation/composition hashes, strict literal lineage, G3/tools branches and tools parent, four bridge literals, issuer commit/tree, interface pins and corrected installer bindings close. The unissued Root config remains unissued. The model does not adopt its own source or issue operation authority.

## Publication and filesystem guards

The independent receiver rebuilt all generated Git tree bytes from the53 actual host bodies and the four required ancestor tree bodies. All nine results match the stage's exact raw bytes and Git object IDs. Entries outside the two complete fixed host subtrees and one workflow path are retained from the selected parent tree. The exact seven-commit public lineage joins the selected publication parent to the original source/tree. The synthetic test commit has exactly the expected tree and one selected parent; it is visibly TEST_ONLY and is not an actual provider object.

The source opens inputs without following symlinks, checks ownership/modes/link count/xattrs and complete closing identity, and rereceives dependencies/current source at stage boundaries. The staged writer uses a fresh owned0700 destination, held directory descriptors, exclusive member creation,0444 body readback, complete file population, expected child-directory identities, fsync and closing selected-root/ancestor joins. It refuses existing destinations and source/predecessor nesting, retains partials, and contains no deletion or automatic retry path.

The retained replacement control moved the selected output immediately before seal writing: the selected replacement has no seal, while the partial seal remains in the moved original. Changed-body and added-member controls remain retained. The controls cover these deterministic substitutions; they do not prove every possible concurrent schedule. The source's input population receiver closes files and snapshots directory identities; preexisting empty directories are not separately rejected merely for lacking index entries. Generated output directories are checked against the writer's derived directory set. This has no observed source-binding effect in the exact received populations.

## Retained controls and authenticity limits

`ad8742/0` retains18 passing tests and six successful staged CLI entry returns. These are six actual calls through `main()` inside one isolated test process with patched `sys.argv`; they are not six genuine Root subprocess invocations. Only that test process patches the issuer/state constants to `TEST_ONLY_NOT_ROOT` / `TEST_ONLY_SOURCE_CONTROL`. Production has no test flag, and its ordinary selection guard rejects these fixtures. The hosted consumers retain their original literal Root-issuer predicates.

The six stdout rows join all six retained stage seals and complete populations. The source-only generated runtime load is retained as a public control; no original assembly or sender was executed. Provider evidence is explicitly classified as local TEST_ONLY data with zero provider calls. This review receives the commissioned tool-return records and surviving artifacts; it does not claim a separate backend attestation of the historical test invocation.

All three control populations join the author's census digests exactly. The preimage is a path-sorted list of `{path, bytes, sha256, mode}` records, octal-string modes, compact sorted-key JSON and one final LF. The populations are178 files/4,892,437 bytes;179/4,896,915; and536/16,466,330. The exact format join is retained separately because the author index did not state its serialization formula. The original index is unchanged.

Earlier failures remain retained: missing-finalizer RED `38ef0d/1`, the preparation patch refusal, source-role mode refusal `e44c44/1`, and actual staged reader-role bookkeeping failure `8b0028/1` with17/18 passing. The final reader checks both requested role gates, requires identical file/ancestor/body records, and retains the first strict closing role. No historical mode was changed. The independent review's preliminary census script also had a SyntaxError before any execution; its exact return is retained. The actual independent receiver subsequently passed without a target execution or control rerun.

## Proposed fresh seed arrangement

The proposed cipher seed `e48ef76a986d1ce949661fd658cdcbe66f292788` and a distinct newly received empty-tree tools anchor are compatible with the retained source rules when Root selects and consistently binds their exact identities. `host_tools.declaration` requires a distinct tools parent, not the historical54821 object or a particular seed tree/ancestry. The tools consumer waits while the tools ref equals that exact parent, then requires a fresh sole-parent child with the one-leaf adoption tree. The model tools API and bridge preserve PRESENT-at-exact-parent guards. The cipher reader similarly treats equality to its own selected parent as waiting.

A fresh tools anchor with the cipher seed as its sole parent therefore fits the source predicates. Its actual object identity/tree/parent, currentness, later fresh-ref creation and any protected safeguard still require Root's separate actual receiving. This reviewer created no anchor, selection, admission, commit, ref, provider request or effect grant.

## Handoff boundary

The finite finalizer is source-ready within the exact reviewed scope. Genuine Root inputs, actual unreferenced host-object receiving, independent whole-generated-model receiving and adoption remain ahead. Fresh protected authorization, authentic hosted custody and late sender, original private-input materialization, native G1, both real G3 decisions, actual consumer/JOIN/recomputation and final cold receiving remain distinct obligations. Historical protected301/625f remains `UNKNOWN_NO_REPLAY`; absent stores do not establish absent effects or missing generation returns. Original awards remain empty.
