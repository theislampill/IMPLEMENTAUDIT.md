"""Independent byte/source receiving only; never imports or runs target sources."""
import ast
import copy
import hashlib
import json
import os
from pathlib import Path
import stat

HERE = Path('/workspace/scratch/530bc07ea12b/g132-finalizer-independent-review')
PACKET = HERE.parent/'g132-fresh-operation-finalizer'
BASE = Path('/workspace/scratch/2678f1e431c3/g132-actual-candidate-source-received-20261119')
CONTROL = HERE.parent/'g132-finalizer-TEST_ONLY_attempt_0003/TEST_ONLY_cli'
CORE = 'qualification/dg16-r5-g1-hosted-episode/'
ENTRY = 'qualification/dg16-r5-g1-hosted-entry/'
CARRIER = CORE+'carrier/'
WORKFLOW = '.github/workflows/dg16-r5-g1-hosted-episode.yml'
INSTALLATION_SHA = '58a831b74aec61df5f159ca72cc5c54bc2d50c13f0aea78651bdfe48f0d8e983'
COMPOSITION_SHA = '6d6f561278bcf5516bb05098dfc484eeca3094942dc6041bec508231584eec86'
records = {}
bodies = {}
parents_seen = {}
checks = []

def require(ok, name):
    if not ok:
        raise AssertionError(name)
    checks.append(name)

def descriptor(raw):
    return {'bytes':len(raw), 'sha256':hashlib.sha256(raw).hexdigest()}

def canonical(obj):
    return (json.dumps(obj, sort_keys=True, separators=(',',':'), ensure_ascii=True, allow_nan=False)+'\n').encode()

def parse(raw):
    def unique(rows):
        result = {}
        for key,value in rows:
            if key in result: raise AssertionError('duplicate JSON key')
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=unique, parse_constant=lambda _: (_ for _ in ()).throw(AssertionError('nonfinite JSON')))

def stamp(s):
    return [s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns]

def dir_stamp(s):
    return [s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid]

def read(path, pin=None, modes=(0o400,0o444,0o600,0o644), maximum=20*1024*1024):
    path = Path(path)
    assert path.is_absolute() and path.resolve(strict=True)==path
    ancestry = {}
    for parent in reversed(path.parents):
        s = parent.lstat()
        assert stat.S_ISDIR(s.st_mode) and not parent.is_symlink()
        ancestry[str(parent)] = dir_stamp(s)
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink==1
    assert before.st_uid==os.geteuid() and before.st_gid==os.getegid()
    assert stat.S_IMODE(before.st_mode) in modes and 0<=before.st_size<=maximum
    fd = os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK)
    try:
        assert stamp(os.fstat(fd))==stamp(before) and not os.listxattr(fd)
        raw = os.pread(fd,maximum+1,0)
        assert len(raw)==before.st_size
        assert stamp(os.fstat(fd))==stamp(before)==stamp(path.lstat())
    finally:
        os.close(fd)
    assert all(dir_stamp(Path(p).lstat())==value for p,value in ancestry.items())
    result = descriptor(raw)
    if pin:
        assert all(result[key]==value for key,value in pin.items())
    row = dict(result,stamp=stamp(before),mode=oct(stat.S_IMODE(before.st_mode)))
    key = str(path)
    if key in records:
        assert records[key]==row and bodies[key]==raw
    else:
        records[key]=row;bodies[key]=raw
    for name,value in ancestry.items():
        if name in parents_seen: assert parents_seen[name]==value
        else: parents_seen[name]=value
    return raw

def population(root):
    root=Path(root)
    assert root.resolve(strict=True)==root and stat.S_ISDIR(root.lstat().st_mode)
    rows={};directories={'.':dir_stamp(root.lstat())}
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink()
        name=path.relative_to(root).as_posix()
        if path.is_dir(): directories[name]=dir_stamp(path.lstat())
        else:
            raw=read(path);rows[name]=dict(descriptor(raw),mode=oct(stat.S_IMODE(path.lstat().st_mode)))
    return rows,directories

def sealed_packet(root, digest, expected_count=None):
    root=Path(root);manifest=parse(read(root/'MANIFEST.json',{'sha256':digest}))
    if expected_count is not None: assert manifest['count']==expected_count
    for row in manifest['files']:
        read(root/row['path'],{k:row[k] for k in ('bytes','sha256')})
        assert records[str(root/row['path'])]['mode']==row['mode']
    assert sum(x['bytes'] for x in manifest['files'])==manifest['bytes']
    assert len(manifest['files'])==manifest['count']
    return manifest

def assignments(raw):
    result={}
    for n in ast.parse(raw).body:
        if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
            try:result[n.targets[0].id]=ast.literal_eval(n.value)
            except (ValueError,TypeError):pass
    return result

def function_map(raw):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(raw).body
            if isinstance(n,(ast.FunctionDef,ast.ClassDef))}

def ast_only_assignments(old,new,names):
    a=ast.parse(old);b=ast.parse(new)
    def locate(tree):
        return {n.targets[0].id:n for n in tree.body if isinstance(n,ast.Assign)
                and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
    old_rows=locate(a);new_rows=locate(b)
    for name in names:
        old_rows[name].value=copy.deepcopy(new_rows[name].value)
    assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)

def git_id(kind,raw):
    return hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()

def tree_encode(rows):
    names=sorted(rows,key=lambda n:n.encode()+(b'/' if rows[n][0]=='40000' else b''))
    return b''.join(rows[n][0].encode()+b' '+n.encode()+b'\0'+bytes.fromhex(rows[n][1]) for n in names)

def tree_parse(raw):
    result={};offset=0
    while offset<len(raw):
        end=raw.index(b'\0',offset);mode,name=raw[offset:end].split(b' ',1)
        assert len(raw)>=end+21 and name.decode() not in result
        result[name.decode()]=(mode.decode(),raw[end+1:end+21].hex());offset=end+21
    assert tree_encode(result)==raw
    return result

def commit_shape(raw):
    rows=raw.split(b'\n\n',1)[0].splitlines()
    tree=[r[5:].decode() for r in rows if r.startswith(b'tree ')]
    parents=[r[7:].decode() for r in rows if r.startswith(b'parent ')]
    assert len(tree)==1
    return tree[0],parents

def stage(name):
    root=CONTROL/name;raw=read(root/'FINALIZER_STAGE.json',modes=(0o444,));value=parse(raw)
    census,_=population(root)
    assert set(census)==set(value['files'])|{'FINALIZER_STAGE.json'}
    assert value['authority']=='NONE' and value['original_awards']==[] and not value['automatic_retry']
    data={n:read(root/n,pin,modes=(0o444,)) for n,pin in value['files'].items()}
    groups={group:{k:data[n] for k,n in mapping.items()} for group,mapping in value['groups'].items()}
    assert set(data)=={n for mapping in value['groups'].values() for n in mapping.values()}
    for dep in value['dependencies']:
        modes=(0o600,) if dep['role']=='core_admission' else (0o400,0o444,0o644)
        read(dep['path'],{k:dep[k] for k in ('bytes','sha256')},modes=modes)
    return value,groups,descriptor(raw)

manifest=sealed_packet(PACKET,'1681e5f13dbedd554f3f178c37802e9adb1de45fbabd8b3b6fb6cd8061276b1b',15)
require(manifest['bytes']==111132,'exact finalizer source/evidence seal')
expected_top={r['path'] for r in manifest['files']}|{'MANIFEST.json'}|set(manifest['declared_unpublished_local_control_subtrees'])
require({p.name for p in PACKET.iterdir()}==expected_top,'closed selected packet top-level population')
source=read(PACKET/'finalize_g132.py',{'bytes':45265,'sha256':'e9285e1898865d281022030c8c576bc7cf01f8c22af1f8e21e2999d8871510be'},modes=(0o444,))
test_source=read(PACKET/'test_finalizer.py',{'bytes':17583,'sha256':'d5847611ae5ce9305ea36921ea6e9072d3fc0f2e07773df91068fefc25619aa1'},modes=(0o444,))
source_values=assignments(source)
require(source_values['ROOT_ISSUER']=='R5_ROOT_GOVERNOR' and source_values['ROOT_STATE']=='ROOT_SELECTED_SOURCE_GENERATION_ONLY','production issuer/state constants remain genuine Root selectors')
require(b"patch.object(F,'ROOT_ISSUER','TEST_ONLY_NOT_ROOT')" in test_source and b"patch.object(F,'ROOT_STATE','TEST_ONLY_SOURCE_CONTROL')" in test_source,'fixture issuer/state patches occur in test source only')
require(b'TEST_ONLY' not in source,'no production TEST_ONLY flag or fixture issuer')
require({n.name for n in ast.walk(ast.parse(test_source)) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}.__len__()==18,'exact eighteen retained test definitions')
prerequisites={
    'installer':sealed_packet(HERE.parent/'g132-installer-r2-independent-review','78dc6ce4bd18c04de90f45a59d241667af90a2921a2f281990e2b9c0dac714eb',4),
    'public_positive_actual':sealed_packet(HERE.parent/'g132-positive-r2-actual-independent-review','0155fe959e311b66afb57a1c23edeef2e0526038214172df065e048be32afeba',4),
}
require(all(p['authority']=='NONE' and p['original_awards']==[] for p in prerequisites.values()),'separate prerequsite reviews remain authority NONE with no original awards')

install=BASE/'dependencies/installation';index=parse(read(install/'SOURCE_INDEX.json',{'sha256':INSTALLATION_SHA},modes=(0o400,0o444)))
old={n:read(install/n,pin,modes=(0o400,0o444),maximum=2*1024*1024) for n,pin in index['files'].items()}
old_pop,_=population(install)
require(len(old)==157 and set(old_pop)==set(old)|{'SOURCE_INDEX.json'},'exact old 157-member installation retained')
composition=parse(read(BASE/'COMPOSITION_SOURCE_INDEX.json',{'sha256':COMPOSITION_SHA},modes=(0o400,0o444)))
runtime={n:read(BASE/'source'/n,pin,modes=(0o400,0o444)) for n,pin in composition['files'].items()}
runtime_pop,_=population(BASE/'source')
require(len(runtime)==12 and set(runtime_pop)==set(runtime),'exact twelve baseline runtime bodies')
baseline={n.removeprefix('phase/tree/'):v for n,v in old.items() if n.startswith('phase/tree/')}
require(len(baseline)==53 and parse(old['phase/PHASE.json'])['members']=={'tree/'+n:descriptor(v) for n,v in baseline.items()},'all repaired 53 baseline hosted bodies join phase index')
scope=parse(baseline[CORE+'ORIGINAL_SCOPE.json'])
require(scope['current_subject']=={'commit':source_values['SOURCE'],'tree':source_values['TREE']} and scope['original_population']=={'DG16':48,'DG17':95,'DG18':14,'total':157},'original source scope and 157 obligations preserved')
for n,row in parse(old['SCOPE_REPAIR_SOURCE_DELTA.json'])['changes'].items():
    assert descriptor(baseline[n])==row['new']
issuer=read(BASE/'complete-sources/issuer.py',source_values['ISSUER_PIN'],modes=(0o400,0o444))
interface_path=HERE.parent/'g132-execution-readiness/current_interfaces.py'
interface=read(interface_path,source_values['INTERFACE_PIN'],modes=(0o400,0o444))
installer=read(HERE.parent/'g132-late-installer-custody-r2/late_sender_install.py',source_values['INSTALLER_PIN'],modes=(0o400,0o444,0o644))
config=read(BASE/'ROOT_CONTROL_CONFIG_UNISSUED.json',source_values['CONFIG_PIN'],modes=(0o400,0o444))

control_index=parse(read(PACKET/'CONTROL_OUTPUT_INDEX.json'))
control_censuses={}
for control in control_index['controls']:
    census,directories=population(control['directory'])
    assert len(census)==control['files'] and sum(r['bytes'] for r in census.values())==control['total_bytes']
    for receipt in control['key_receipts_and_stage_seals'].values():
        read(receipt['path'],{k:receipt[k] for k in ('bytes','sha256')})
    control_censuses[control['directory']]={'files':census,'directories':directories,
        'independent_canonical_census':descriptor(canonical(census)),
        'author_population_canonical_sha256':control['population_canonical_sha256']}
require(len(control_censuses)==3,'all three retained public control populations and key seals received')
terminal=parse(read(PACKET/'CONTROLS_03_TOOL_RETURN.json'))
require(terminal['chunk_id']=='ad8742' and terminal['exit_code']==0 and 'Ran 18 tests' in terminal['output'] and '\nOK\n' in terminal['output'],'actual final eighteen-test terminal return retained')
stdout=[parse(line.encode()) for line in terminal['output'].splitlines() if line.startswith('{')]
require(len(stdout)==6,'six actual in-process CLI dispatch return rows')
old_failure=parse(read(PACKET/'CONTROLS_02_TOOL_RETURN.json'))
require(old_failure['chunk_id']=='8b0028' and old_failure['exit_code']==1 and 'INPUT_RESELECTED_OR_CHANGED' in old_failure['output'],'actual prior 17/18 failure preserved')

names=('core_requirements','core','carrier','host','object_requirements','model')
stages={name:stage(name) for name in names}
for name,row in zip(names,stdout):
    seal,groups,pin=stages[name]
    assert row['output']==str(CONTROL/name) and row['seal']==pin and row['state']==seal['metadata']['stage']
    assert row['authority']=='NONE' and row['native_calls']==row['provider_calls']==0
    assert row['original_awards']==[] and row['protected_grant'] is False
    assert seal['metadata']['baseline_installation_sha256']==INSTALLATION_SHA
    assert seal['metadata']['baseline_composition_sha256']==COMPOSITION_SHA
selection=stages['host'][0]['metadata']['selection']
require(selection['issuer']=='TEST_ONLY_NOT_ROOT' and selection['state']=='TEST_ONLY_SOURCE_CONTROL','all selected control stages remain conspicuously TEST_ONLY')
require(all(s[0]['metadata']['selection']==selection for name,s in stages.items()),'one exact selection across six retained stage seals')
core_raw=read(CONTROL/'TEST_ONLY_core_ADMISSION.json',modes=(0o600,))
carrier_raw=read(CONTROL/'TEST_ONLY_carrier_ADMISSION.json',modes=(0o444,))
bootstrap_raw=read(CONTROL/'TEST_ONLY_host_ADMISSION.json',modes=(0o444,))
for before,body,role,after in [('core_requirements',core_raw,'core','core'),('core',carrier_raw,'carrier','carrier'),('carrier',bootstrap_raw,'bootstrap','host')]:
    assert canonical(stages[before][0]['metadata']['expected_admission'])==body
    assert stages[after][0]['metadata']['consumed_admissions'][role]==descriptor(body)
    assert parse(body)['issuer']=='TEST_ONLY_NOT_ROOT' and parse(body)['original_awards']==[]
require(True,'three exact canonical fixture admissions join their preceding requirements and successor digests')
host=stages['host'][1]['members']
require(set(host)==set(baseline) and len(host)==53,'finished hosted population remains exact 53')
old_input=parse(baseline[CARRIER+'INPUT_INDEX.json']);new_input=parse(host[CARRIER+'INPUT_INDEX.json'])
require(len(old_input)==len(new_input)==11 and sum(x['bytes'] for x in old_input.values())==647343,'old and successor eleven-descriptor input censuses')
require({n for n in old_input if old_input[n]!=new_input[n]}=={'COMPOSITION_ROOT_ADMISSION.json'} and new_input['COMPOSITION_ROOT_ADMISSION.json']==descriptor(core_raw),'only newly issued core admission descriptor changes; other ten remain exact')
require(core_raw not in host.values(),'new core admission private fixture body is not copied into public host')
preserved=[n for n in baseline if '/retained-m4/' in n or n in {CORE+k for k in ('ORIGINAL_SCOPE.json','SOURCE_MANIFEST.json','ADVERSE_APPLICABILITY.json','NATIVE_SOURCE_APPLICABILITY.json')}]
require(all(host[n]==baseline[n] for n in preserved),'scope applicability and all four retained M4 bodies byte-identical')

allowed={CORE+'host_composition.py':['BINDING_SHA256'],CORE+'g3_receiving.py':['JOB_BRANCH','CONTROL_BRANCH'],
 CORE+'run.py':['BRANCH','MODULE_PINS','G3_DATA_PINS'],CARRIER+'carrier_policy.py':['BINDING_SHA256'],
 CARRIER+'carrier_loader.py':['MODULE_PINS'],ENTRY+'entry_common.py':['ENTRY_STATE','CARRIER_LOADER_DESCRIPTOR','EXPECTED_PUBLIC_MANIFEST_SHA256','EXPECTED_BOOTSTRAP_ADMISSION_SHA256'],
 ENTRY+'bootstrap_entry.py':['BRANCH','MANIFEST_SHA256','ADMISSION_SHA256'],ENTRY+'public_export.py':['BRANCH','CORE_RUN_SHA256']}
for n in source_values['WRAPPERS']:allowed[ENTRY+n]=['COMMON_SHA256']
for n in host:
    if n.endswith('.py'):
        ast_only_assignments(baseline[n],host[n],allowed.get(n,[]))
        assert function_map(baseline[n])==function_map(host[n])
require(True,'all hosted function/class bodies unchanged; only enumerated assignments differ')
old_binding=parse(baseline[CARRIER+'CARRIER_COMPOSITION.json']);binding=parse(host[CARRIER+'CARRIER_COMPOSITION.json'])
for n,pin in binding['core_bodies'].items():assert descriptor(host[CORE+n])==pin
assert assignments(host[CORE+'host_composition.py'])['BINDING_SHA256']==descriptor(host[CORE+'HOST_COMPOSITION.json'])['sha256']
assert assignments(host[CARRIER+'carrier_policy.py'])['BINDING_SHA256']==descriptor(host[CARRIER+'CARRIER_COMPOSITION.json'])['sha256']
for n,pin in assignments(host[CARRIER+'carrier_loader.py'])['MODULE_PINS'].items():assert descriptor(host[CARRIER+n+'.py'])==pin
for n,pin in assignments(host[CORE+'run.py'])['MODULE_PINS'].items():assert descriptor(host[CORE+n+'.py'])['sha256']==pin
for n,pin in assignments(host[CORE+'run.py'])['G3_DATA_PINS'].items():assert descriptor(host[CORE+n])['sha256']==pin
public_manifest=parse(host[ENTRY+'PUBLIC_PACKET_MANIFEST.json'])
assert public_manifest['members']=={n.removeprefix(CORE):dict(descriptor(v),mode=0o400) for n,v in host.items() if n.startswith(CORE)}
assert binding['carrier_admission']==descriptor(carrier_raw) and binding['input_index']==descriptor(host[CARRIER+'INPUT_INDEX.json'])
assert host[CARRIER+'CARRIER_ADMISSION.json']==carrier_raw and host[ENTRY+'BOOTSTRAP_ADMISSION.json']==bootstrap_raw
assert parse(bootstrap_raw)['manifest_sha256']==descriptor(host[ENTRY+'PUBLIC_PACKET_MANIFEST.json'])['sha256']
common=assignments(host[ENTRY+'entry_common.py']);bootstrap=assignments(host[ENTRY+'bootstrap_entry.py'])
assert common['CARRIER_LOADER_DESCRIPTOR']==descriptor(host[CARRIER+'carrier_loader.py'])
assert common['EXPECTED_PUBLIC_MANIFEST_SHA256']==bootstrap['MANIFEST_SHA256']==descriptor(host[ENTRY+'PUBLIC_PACKET_MANIFEST.json'])['sha256']
assert common['EXPECTED_BOOTSTRAP_ADMISSION_SHA256']==bootstrap['ADMISSION_SHA256']==descriptor(bootstrap_raw)['sha256']
for name in source_values['WRAPPERS']:assert assignments(host[ENTRY+name])['COMMON_SHA256']==descriptor(host[ENTRY+'entry_common.py'])['sha256']
assert assignments(host[ENTRY+'public_export.py'])['CORE_RUN_SHA256']==descriptor(host[CORE+'run.py'])['sha256']
require(True,'entire hosted module/data/manifest/bootstrap peer-pin chain closes')
expected_flow=baseline[WORKFLOW].replace(old_binding['branch'].encode(),selection['refs']['host'].encode())
expected_flow=expected_flow.replace(b'G132 host32 after sender readiness correction from 625f310 (${{ github.sha }})',b'G132 original 20261120-01 (${{ github.sha }})')
require(host[WORKFLOW]==expected_flow and parse(expected_flow)['jobs']['qualify']['runs-on']=='ubuntu-24.04' and parse(expected_flow)['jobs']['qualify']['timeout-minutes']==75,'workflow changed only branch/run label; selector and budget preserved')

public={kind:{oid:read(ref['path'],{k:ref[k] for k in ('bytes','sha256')},modes=(0o400,0o444,0o644)) for oid,ref in refs.items()} for kind,refs in selection['public_git_inputs'].items()}
for kind,objects in public.items():
    for oid,raw in objects.items():assert git_id('commit' if kind=='commits' else 'tree',raw)==oid
chain=selection['publication_lineage']
assert set(public['commits'])==set(chain) and len(chain)==7 and chain[0]==selection['publication_parent']
for a,b in zip(chain,chain[1:]):assert commit_shape(public['commits'][a])[1]==[b]
assert chain[-1]==source_values['SOURCE'] and commit_shape(public['commits'][chain[-1]])[0]==source_values['TREE']
root_tree=commit_shape(public['commits'][chain[0]])[0];root=tree_parse(public['trees'][root_tree])
github=tree_parse(public['trees'][root['.github'][1]]);workflows=tree_parse(public['trees'][github['workflows'][1]])
qualification=tree_parse(public['trees'][root['qualification'][1]])
assert set(public['trees'])=={root_tree,root['.github'][1],github['workflows'][1],root['qualification'][1]}
generated={}
def put(rows):
    raw=tree_encode(rows);oid=git_id('tree',raw);generated[oid]=raw;return oid
def subtree(items):
    files={};children={}
    for name,body in items.items():
        first,sep,rest=name.partition('/')
        if sep:children.setdefault(first,{})[rest]=body
        else:files[first]=('100644',git_id('blob',body))
    for name,items in children.items():files[name]=('40000',subtree(items))
    return put(files)
qualification[CORE.rstrip('/').split('/')[-1]]=('40000',subtree({n.removeprefix(CORE):v for n,v in host.items() if n.startswith(CORE)}))
qualification[ENTRY.rstrip('/').split('/')[-1]]=('40000',subtree({n.removeprefix(ENTRY):v for n,v in host.items() if n.startswith(ENTRY)}))
workflows[WORKFLOW.split('/')[-1]]=('100644',git_id('blob',host[WORKFLOW]))
github['workflows']=('40000',put(workflows));root['.github']=('40000',put(github));root['qualification']=('40000',put(qualification));expected_tree=put(root)
require(generated==stages['host'][1]['git_trees'] and len(generated)==9 and stages['host'][0]['metadata']['publication']['tree']==expected_tree,'all nine host tree bodies independently recomputed; other entries preserved')
commit=read(CONTROL/'TEST_ONLY_LOCAL_COMMIT.raw');commit_id=git_id('commit',commit)
require(commit_shape(commit)==(expected_tree,[selection['publication_parent']]),'fixture commit exact tree and sole selected parent join')
object_req=stages['object_requirements'][0]['metadata'];receiving=parse(read(CONTROL/'TEST_ONLY_ROOT_RECEIVING.json'))
assert {k:v for k,v in receiving.items() if k!='actual_provider_receiving'}==object_req['required_host_object_root_receiving']
assert receiving['commit']==commit_id and receiving['commit_body']==descriptor(commit) and receiving['tree_bodies']=={k:descriptor(v) for k,v in generated.items()}
assert object_req['actual_root_receiving_issued'] is False and object_req['provider_object_observed_by_finalizer'] is False
evidence=receiving['actual_provider_receiving'];actual_evidence=parse(read(evidence['path'],{k:evidence[k] for k in ('bytes','sha256')}))
require(actual_evidence['classification']=='TEST_ONLY_LOCAL_SOURCE_CONTROL' and actual_evidence['actual_provider_calls']==0,'retained object receiving is explicitly fixture evidence, not actual provider proof')

model=stages['model'][1]['members'];prefix='packet/dependencies/installation/'
new_index=parse(model[prefix+'SOURCE_INDEX.json']);new={n:model[prefix+n] for n in new_index['files']}
for n,pin in new_index['files'].items():assert descriptor(new[n])==pin
require(len(new)==150 and new_index['state']=='UNISSUED' and new_index['authority']=='NONE' and new_index['runtime_adoption_issued'] is False,'strict new 150-member installation remains unissued')
require({n.removeprefix('phase/tree/'):v for n,v in new.items() if n.startswith('phase/tree/')}==host,'model hosted bodies identical to exact received host stage')
require({n.removeprefix('git-candidate/')[:-5]:v for n,v in new.items() if n.startswith('git-candidate/') and n.endswith('.tree')}==generated,'model contains exact nine generated tree objects')
require(new['git-candidate/'+commit_id+'.commit']==commit and {n.removeprefix('git-lineage/')[:-7]:v for n,v in new.items() if n.startswith('git-lineage/')}==public['commits'],'model candidate and seven exact lineage commits received')
allowed_other={'HOST_IDENTITY_UNISSUED.json','PURE_SOURCE_PLAN.json','phase/PHASE.json','pure/issuer.py','pure/g3.py','pure/run.py','pure/policy.py'}
for n,v in old.items():
    if not n.startswith(('phase/tree/','git-candidate/','git-lineage/')) and n not in allowed_other:assert new[n]==v
author=parse(new['sender-author/AUTHOR_SOURCE_INDEX.json'])['members']
require(len(author)==46 and all(new['sender-author/'+n]==old['sender-author/'+n] for n in author),'all 46 original sender-author bodies byte-identical')
require(new['SCOPE_REPAIR_SOURCE_DELTA.json']==old['SCOPE_REPAIR_SOURCE_DELTA.json'],'historical scope repair source delta unchanged')
identity=parse(new['HOST_IDENTITY_UNISSUED.json'])
assert identity['commit']==commit_id and identity['tree']==expected_tree and identity['parent']==selection['publication_parent']
assert identity['historical_candidate_identity']==parse(old['HOST_IDENTITY_UNISSUED.json'])['commit']
assert identity['authority']=='NONE' and identity['state']=='UNISSUED' and identity['source_adoption_issued'] is False
assert identity['actual_candidate_receiving_sha256']==descriptor(canonical(receiving))['sha256']
require(True,'host identity binds exact fixture receiving without source adoption')
old_plan=parse(old['PURE_SOURCE_PLAN.json']);new_plan=parse(new['PURE_SOURCE_PLAN.json'])
adapter=b"read_file(Path(__file__).with_name('ORIGINAL_SCOPE.json'), 8192)"
assert baseline[CORE+'g3_receiving.py'].count(adapter)==host[CORE+'g3_receiving.py'].count(adapter)==1
adapted_old=baseline[CORE+'g3_receiving.py'].replace(adapter,b'current_original_scope_body()')
adapted_new=host[CORE+'g3_receiving.py'].replace(adapter,b'current_original_scope_body()')
assert len(baseline[CORE+'g3_receiving.py'])-len(adapted_old)==35
new_issuer=model['complete-sources/issuer.py'];ast_only_assignments(issuer,new_issuer,['HOST_COMMIT','HOST_TREE'])
for name,before,after in [('issuer',issuer,new_issuer),('g3',adapted_old,adapted_new),('run',baseline[CORE+'run.py'],host[CORE+'run.py']),('policy',baseline[CARRIER+'carrier_policy.py'],host[CARRIER+'carrier_policy.py'])]:
    assert descriptor(before)=={'bytes':old_plan[name]['source_bytes'],'sha256':old_plan[name]['source_sha256']}
    assert descriptor(after)=={'bytes':new_plan[name]['source_bytes'],'sha256':new_plan[name]['source_sha256']}
    assert descriptor(new['pure/'+name+'.py'])=={'bytes':new_plan[name]['projection_bytes'],'sha256':new_plan[name]['projection_sha256']}
    assert function_map(before)==function_map(after)
for name in set(old_plan)-{'issuer','g3','run','policy'}:assert new_plan[name]==old_plan[name]
ast_only_assignments(old['pure/issuer.py'],new['pure/issuer.py'],['HOST_COMMIT','HOST_TREE'])
ast_only_assignments(old['pure/g3.py'],new['pure/g3.py'],[n for n in ('JOB_BRANCH','CONTROL_BRANCH') if n in old_plan['g3']['declarations']])
assert old['pure/run.py']==new['pure/run.py'] and old['pure/policy.py']==new['pure/policy.py']
require(True,'exact 35-byte G3 adapter recipe and all projection validator functions preserved')

new_comp=parse(model['packet/COMPOSITION_SOURCE_INDEX.json']);new_runtime={n:model['packet/source/'+n] for n in new_comp['files']}
assert set(new_runtime)==set(runtime) and len(new_runtime)==12
for n,pin in new_comp['files'].items():assert descriptor(new_runtime[n])==pin
new_index_sha=descriptor(model[prefix+'SOURCE_INDEX.json'])['sha256'];new_comp_sha=descriptor(model['packet/COMPOSITION_SOURCE_INDEX.json'])['sha256']
assert new_comp['installation_index_sha256']==new_index_sha
for n,keys in [('current_root_entry.py',['INDEX']),('current_control_api.py',['BRANCH']),('current_tools_control_api.py',['BRANCH','PARENT'])]:ast_only_assignments(runtime[n],new_runtime[n],keys)
a=ast.parse(runtime['current_pro_interfaces.py']);b=ast.parse(new_runtime['current_pro_interfaces.py'])
for tree in (a,b):
    for node in ast.walk(tree):
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in ('INDEX_SHA256','chain'):node.value=ast.Constant('RECEIVED_CHANGED_LITERAL')
assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
assert assignments(new_runtime['current_pro_interfaces.py'])['INDEX_SHA256']==assignments(new_runtime['current_root_entry.py'])['INDEX']==new_index_sha
chain_nodes=[n for n in ast.walk(ast.parse(new_runtime['current_pro_interfaces.py'])) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='chain']
assert len(chain_nodes)==1 and ast.literal_eval(chain_nodes[0].value)==chain
assert assignments(new_runtime['current_tools_control_api.py'])['BRANCH']==binding['host_tools']['control_branch']==selection['refs']['tools']
assert assignments(new_runtime['current_tools_control_api.py'])['PARENT']==binding['host_tools']['control_parent']==selection['control_parents']['tools']
assert assignments(new_runtime['current_control_api.py'])['BRANCH']==selection['refs']['g3']
bridge=runtime['g132_operator_bridge.js']
for before,after in [(old_binding['branch'],selection['refs']['host']),(old_binding['host_tools']['control_branch'],selection['refs']['tools']),(old_binding['host_tools']['control_parent'],selection['control_parents']['tools']),(assignments(baseline[CORE+'g3_receiving.py'])['CONTROL_BRANCH'],selection['refs']['g3'])]:
    old_literal=("'"+before+"'").encode();new_literal=("'"+after+"'").encode()
    assert bridge.count(old_literal)==1;bridge=bridge.replace(old_literal,new_literal)
assert bridge==new_runtime['g132_operator_bridge.js']
for n in set(runtime)-{'current_pro_interfaces.py','current_root_entry.py','current_control_api.py','current_tools_control_api.py','g132_operator_bridge.js'}:assert runtime[n]==new_runtime[n]
new_interface=model['current_interfaces.py'];ast_only_assignments(interface,new_interface,['COMPOSITION_SHA','INSTALLATION_SHA'])
assert assignments(new_interface)['COMPOSITION_SHA']==new_comp_sha and assignments(new_interface)['INSTALLATION_SHA']==new_index_sha
assert installer.count(str(interface_path).encode())==1
installer_path_changed=installer.replace(str(interface_path).encode(),str(Path(selection['generation_directory'])/'current_interfaces.py').encode())
new_installer=model['late_sender_install.py'];ast_only_assignments(installer_path_changed,new_installer,['INTERFACE_PIN','INSTALLATION_SHA'])
assert assignments(new_installer)['INTERFACE_PIN']==descriptor(new_interface) and assignments(new_installer)['INSTALLATION_SHA']==new_index_sha
expected_config=parse(config);expected_config['installation']={'path':str(Path(selection['generation_directory'])/'packet/dependencies/installation'),'index_sha256':new_index_sha}
assert parse(model['packet/ROOT_CONTROL_CONFIG_UNISSUED.json'])==expected_config and expected_config['state']=='UNISSUED'
require(True,'runtime indexes, strict lineage, four bridge literals, interface and corrected installer bindings all close')

partial_root=Path(control_index['controls'][2]['directory'])
require(not (partial_root/'TEST_ONLY_rebind/FINALIZER_STAGE.json').exists() and (partial_root/'TEST_ONLY_original_moved/FINALIZER_STAGE.json').exists(),'directory replacement partial seal retained only in moved original')
require((partial_root/'TEST_ONLY_stage/extra.txt').exists() and read(partial_root/'TEST_ONLY_currentness/body.txt')==b'changed source\n','body/population mutation fixtures remain retained')
opening=dict(records)
for path,row in list(opening.items()):read(path,{k:row[k] for k in ('bytes','sha256')})
for path,record in control_censuses.items():
    census,directories=population(path)
    assert census==record['files'] and directories==record['directories']
require(records==opening,'all source, evidence, dependency and control identities current on closing reread')

result={'schema':'g132.finalizer-independent-byte-and-source-receiving.v1','authority':'NONE','original_awards':[],
 'target_source_imported_or_executed':False,'reviewer_native_provider_sender_controller_calls':0,
 'source_manifest':descriptor(read(PACKET/'MANIFEST.json')),'source':descriptor(source),'tests':descriptor(test_source),
 'integer_safe_json':True,'checks':checks,'recorded_file_count':len(records),'files':records,'ancestor_identities':parents_seen,
 'control_censuses':control_censuses,'stage_seals':{n:stages[n][2] for n in names},
 'prerequisite_dispositions':{n:p['technical_disposition'] for n,p in prerequisites.items()},
 'old_installation_members':157,'new_installation_members':150,'host_members':53,'runtime_members':12,'author_members':46,
 'generated_git_trees':9,'selected_lineage_commits':7,'exact_control_return':'ad8742/0',
 'source_reader_predicates_applied_to_actual_dependencies':True,
 'fixed_seed_rule_assessment':'Distinct fresh tools anchor is compatible when exact parent is compiled into all bindings and tools ref is PRESENT there; anchor/tree/ref actuality remains Root receiving.',
 'scope':'SOURCE_AND_RETAINED_TEST_ONLY_CONTROLS_ONLY_NOT_ORIGINAL_ACCEPTANCE'}
raw=canonical(result);destination=HERE/'VERIFICATION.json'
fd=os.open(destination,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
try:
    with os.fdopen(fd,'wb',closefd=False) as stream:stream.write(raw);stream.flush()
    os.fchmod(fd,0o444);os.fsync(fd)
finally:os.close(fd)
print(json.dumps({'result':descriptor(raw),'file_count':len(records),'checks':len(checks),'authority':'NONE','target_execution':False,'original_awards':[]},sort_keys=True))
