"""Independent static receiving with each actual file-reader predicate applied.

No target source import, target helper call, main, loader execution, capture,
encryption, or provider operation is performed.
"""
import ast
import copy
import difflib
import hashlib
import json
import os
from pathlib import Path
import shlex
import stat
import sys

ROOT=Path('/workspace/scratch/530bc07ea12b')
BASE=ROOT/'g132-positive-public-control-r2'
OLD=ROOT/'g132-original-operation-readiness/positive-public-control'
OUT=ROOT/'g132-positive-r2-independent-review'
records=[]


def desc(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def stamp(s):return [s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_uid,s.st_gid]


def ancestry(path):
    answer=[]
    for p in reversed(path.parents):
        s=p.lstat();assert stat.S_ISDIR(s.st_mode) and not p.is_symlink()
        answer.append([str(p),s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid])
    return answer


def receive(path,pin=None,reader='review',maximum=64*1024**2):
    p=Path(path);assert p.is_absolute()
    ancestors=ancestry(p);before=p.lstat();mode=stat.S_IMODE(before.st_mode)
    assert stat.S_ISREG(before.st_mode) and before.st_nlink==1
    assert 0<=before.st_size<=maximum
    if reader in ('read_bound_source','read_bound_executable'):
        assert 0<before.st_size<=2*1024**2
        if reader=='read_bound_source':assert mode in (0o400,0o444,0o644),(str(p),mode)
        else:assert not mode&0o022 and bool(mode&0o111) and os.access(p,os.X_OK)
    elif reader=='historical_owned0600':
        assert str(p)==str(path) and str(p) in HISTORICAL and pin==HISTORICAL[str(p)]
        assert os.getuid()==os.geteuid()>0 and os.getgid()==os.getegid()
        assert before.st_uid==os.geteuid() and before.st_gid==os.getegid()
        assert mode==0o600 and before.st_size==pin['bytes']
    elif reader=='bootstrap_source':assert mode==0o444 and before.st_size==pin['bytes']
    elif reader=='loader_module':assert 0<before.st_size<=1024**2 and mode in (0o400,0o444,0o644)
    elif reader=='maintained_read_file':assert 0<=before.st_size<=1024**2
    elif reader=='interpreter':assert mode==0o755 and os.access(p,os.X_OK)
    else:assert reader=='review'
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK)
    try:
        assert stamp(os.fstat(fd))==stamp(before) and not os.listxattr(fd)
        raw=os.pread(fd,before.st_size+1,0)
        assert len(raw)==before.st_size
        assert stamp(os.fstat(fd))==stamp(before)==stamp(p.lstat()) and ancestry(p)==ancestors
    finally:os.close(fd)
    d=desc(raw)
    if pin is not None:assert all(d[k]==v for k,v in pin.items() if k in d),str(p)
    source_record=dict(d,identity=stamp(before),ancestors=ancestors)
    if reader=='historical_owned0600':source_record['read_class']='EXACT_OWNED0600_HISTORICAL_PUBLIC_OBSERVATION_NOT_SOURCE'
    records.append(dict(path=str(p),reader=reader,all_reader_predicates_met=True,mode=oct(mode),**source_record))
    return raw,source_record


def constants(raw,names):
    answer={}
    for n in ast.parse(raw).body:
        if not (isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in names):continue
        v=n.value
        if isinstance(v,ast.Call):
            assert isinstance(v.func,ast.Name) and v.func.id=='dict' and not v.args
            assert all(k.arg is not None for k in v.keywords)
            answer[n.targets[0].id]={k.arg:ast.literal_eval(k.value) for k in v.keywords}
        else:answer[n.targets[0].id]=ast.literal_eval(v)
    assert set(answer)==set(names)
    return answer


def packet(base,digest,count,total):
    raw,_=receive(base/'MANIFEST.json',{'sha256':digest})
    manifest=json.loads(raw);assert manifest['count']==count and manifest['bytes']==total
    assert len({r['path'] for r in manifest['files']})==count
    assert sum(r['bytes'] for r in manifest['files'])==total
    bodies={}
    for r in manifest['files']:
        p=Path(r['path']);assert not p.is_absolute() and '..' not in p.parts and str(p)==r['path']
        bodies[r['path']]=receive(base/p,r)[0]
        if 'mode' in r:assert oct(stat.S_IMODE((base/p).lstat().st_mode))==r['mode']
    return manifest,bodies


manifest,bodies=packet(BASE,'e6ee948052d92766383baf8a8c7893a3f473b95ab4caf6f1f32378fc79438445',16,98803)
assert {p.name for p in BASE.iterdir()}==set(bodies)|{'MANIFEST.json'}
old_manifest,old_bodies=packet(OLD,'f3c8c55c3d26e745705c1ec7ae38d79cf6233d5d44d15a7e2dc7461e375cbd42',6,55819)
assert all(stat.S_IMODE((OLD/r['path']).lstat().st_mode)==0o444 for r in old_manifest['files'])
source=bodies['probe.py'];old_source=old_bodies['probe.py']
assert desc(source)=={'bytes':28783,'sha256':'348d77795951133141ddcab06510fc915fc6718e0e0787a335827c0c8bc4ed44'}
assert desc(old_source)=={'bytes':26159,'sha256':'c66e70e7b1c04041b01a85c5ca3ba479d15f476abd0d6fea5d501d3736d3c1ca'}
patch=''.join(difflib.unified_diff(old_source.decode().splitlines(keepends=True),source.decode().splitlines(keepends=True),fromfile=str(OLD/'probe.py'),tofile=str(BASE/'probe.py')))
assert patch.encode()==bodies['SOURCE_DIFF.patch']
old_ast,new_ast=ast.parse(old_source),ast.parse(source)
of={n.name:n for n in old_ast.body if isinstance(n,ast.FunctionDef)}
nf={n.name:n for n in new_ast.body if isinstance(n,ast.FunctionDef)}
assert set(nf)-set(of)=={'read_historical_public_receipt','read_prior_seal'}
unchanged=[]
for name in of:
    if name not in ('expected_selection','main'):
        assert ast.get_source_segment(old_source.decode(),of[name])==ast.get_source_segment(source.decode(),nf[name])
        unchanged.append(name)
class Normalize(ast.NodeTransformer):
    changes=0
    def visit_Call(self,node):
        self.generic_visit(node)
        if isinstance(node.func,ast.Name) and node.func.id=='read_prior_seal':
            assert len(node.args)==2 and not node.keywords
            node.func.id='read_bound';node.args[1]=ast.Dict(keys=[ast.Constant(value='sha256')],values=[node.args[1]])
            self.changes+=1
        return node
normalizer=Normalize();normalized=normalizer.visit(copy.deepcopy(nf['main']))
assert normalizer.changes==2 and ast.dump(normalized,include_attributes=False)==ast.dump(of['main'],include_attributes=False)
selected=copy.deepcopy(nf['expected_selection']);removed=[]
outer=next(n.value for n in selected.body if isinstance(n,ast.Return))
kept=[]
for key,val in zip(outer.keys,outer.values):
    if isinstance(key,ast.Constant) and key.value in ('historical_public_receipt_readers','predecessor_attempt'):removed.append(key.value)
    else:kept.append((key,val))
outer.keys=[k for k,v in kept];outer.values=[v for k,v in kept]
assert set(removed)=={'historical_public_receipt_readers','predecessor_attempt'}
assert ast.dump(selected,include_attributes=False)==ast.dump(of['expected_selection'],include_attributes=False)
c=constants(source,('LOADER_PIN','INDEX_PIN','MAINTAINED_PINS','OWNER_AST','TOOL_PINS','PRIOR_SEALS','HISTORICAL_PUBLIC_RECEIPTS','PUBLIC_PLAIN','PUBLIC_CERTIFICATE','CONTROL_IDS'))
HISTORICAL=c['HISTORICAL_PUBLIC_RECEIPTS']
historical_path=str(ROOT/'g132-native-capture-probe/one-time-output/PROBE_RESULT.json')
assert HISTORICAL=={historical_path:{'bytes':3979,'sha256':'3bb4677e69543163727a2130e40286d8650eb9f9739f57735e3e3f024759de1b'}}
assert len(c['PRIOR_SEALS'])==8
selection=json.loads(bodies['PREPARED_SELECTION.json']);old_selection=json.loads(old_bodies['PREPARED_SELECTION.json'])
expected=copy.deepcopy(old_selection)
expected.update(source=dict(path=str(BASE/'probe.py'),**desc(source)),selection_path=str(BASE/'PREPARED_SELECTION.json'),
    output_directory=str(BASE/'one-time-output'),prior_seals=c['PRIOR_SEALS'],
    historical_public_receipt_readers=HISTORICAL,predecessor_attempt='cd895e/1_ENTRY_REFUSAL_PRESERVED_NOT_REPLAYED')
assert selection==expected
assert selection['installation_index']==c['INDEX_PIN'] and selection['carrier_loader']==c['LOADER_PIN']
assert selection['maintained_sources']==c['MAINTAINED_PINS'] and selection['tools']==c['TOOL_PINS']
assert selection['public_inputs']=={'bundle.plain':desc(c['PUBLIC_PLAIN']),'recipient.pem':desc(c['PUBLIC_CERTIFICATE'])}
assert selection['controls']=={n:'UNEXECUTED' for n in c['CONTROL_IDS']}
invocation=json.loads(bodies['INVOCATION.json']);old_invocation=json.loads(old_bodies['INVOCATION.json'])
assert desc(bodies['INVOCATION.json'])['sha256']=='b603bf9523bb4809d98946d24d7f324000dc5355a4bcace1d284dc3e069a012f'
assert desc(bodies['PREPARED_SELECTION.json'])['sha256']=='f2c0a4d351ddc81654525a8001f7f7b65b9c53a548351e1730795845a70436c4'
assert invocation['source']==selection['source']
assert invocation['selection']==dict(path=str(BASE/'PREPARED_SELECTION.json'),**desc(bodies['PREPARED_SELECTION.json']))
assert invocation['argv']==shlex.split(invocation['shell_command'])
assert invocation['argv'][:4]==[invocation['interpreter']['path'],'-I','-B','-c']
assert invocation['bootstrap']==desc(invocation['argv'][-1].encode())
boot=old_invocation['argv'][-1]
for before,after,count in [(str(OLD/'probe.py'),str(BASE/'probe.py'),2),(repr(desc(old_source)),repr(desc(source)),1),
    (desc(old_bodies['PREPARED_SELECTION.json'])['sha256'],desc(bodies['PREPARED_SELECTION.json'])['sha256'],1)]:
    assert boot.count(before)==count;boot=boot.replace(before,after)
assert boot==invocation['argv'][-1]
assert invocation['working_directory']==str(BASE) and invocation['output_directory']==str(BASE/'one-time-output')
assert invocation['root_native_invocation_issued'] is False and invocation['predecessor_attempt']['selection_is_current_authority'] is False
assert invocation['interpreter']==old_invocation['interpreter']
assert sys.flags.isolated==1 and sys.dont_write_bytecode and sys.version_info[:3]==(3,12,14)
assert sys.executable==invocation['interpreter']['path']
exe=Path(sys.executable).resolve();assert str(exe)==invocation['interpreter']['resolved_path']
receive(exe,invocation['interpreter'],'interpreter')
receive(BASE/'probe.py',desc(source),'bootstrap_source')
receive(BASE/'PREPARED_SELECTION.json',desc(bodies['PREPARED_SELECTION.json']),'read_bound_source')
receive(BASE/'probe.py',desc(source),'read_bound_source')
installation=Path(selection['installation']);carrier=installation/'phase/tree/qualification/dg16-r5-g1-hosted-episode/carrier'
index=json.loads(receive(installation/'SOURCE_INDEX.json',c['INDEX_PIN'],'read_bound_source')[0])['files']
loader=receive(carrier/'carrier_loader.py',c['LOADER_PIN'],'read_bound_source')[0]
modules=constants(loader,('MODULE_PINS',))['MODULE_PINS']
for name,pin in modules.items():
    p=carrier/(name+'.py');receive(p,pin,'loader_module');assert index[str(p.relative_to(installation))]==pin
assert index[str((carrier/'carrier_loader.py').relative_to(installation))]==c['LOADER_PIN']
maintained={}
for name,pin in c['MAINTAINED_PINS'].items():
    p=carrier/'maintained'/name;maintained[name]=receive(p,pin,'maintained_read_file')[0]
    assert index[str(p.relative_to(installation))]==pin
owner=next(n for n in ast.parse(maintained['QUALIFIER.py']).body if isinstance(n,ast.ClassDef) and n.name=='_CaptureChildren')
assert hashlib.sha256(ast.dump(owner,include_attributes=False).encode()).hexdigest()==c['OWNER_AST']
capture=receive(carrier/'sender_capture.py',modules['sender_capture'],'loader_module')[0]
sc=constants(capture,('QUALIFIER','COMPILER','OWNER_AST_SHA256'))
assert sc=={'QUALIFIER':c['MAINTAINED_PINS']['QUALIFIER.py'],'COMPILER':c['MAINTAINED_PINS']['COMPILER.py'],'OWNER_AST_SHA256':c['OWNER_AST']}
for p,pin in c['TOOL_PINS'].items():receive(p,pin,'read_bound_executable')
opening={}
for p,digest in c['PRIOR_SEALS'].items():
    pin=HISTORICAL.get(p,{'sha256':digest});assert pin['sha256']==digest
    opening[p]=receive(p,pin,'historical_owned0600' if p in HISTORICAL else 'read_bound_source')[1]
closing={}
for p,digest in c['PRIOR_SEALS'].items():
    pin=HISTORICAL.get(p,{'sha256':digest})
    closing[p]=receive(p,pin,'historical_owned0600' if p in HISTORICAL else 'read_bound_source')[1]
assert opening==closing
assert stat.S_IMODE(Path(historical_path).lstat().st_mode) not in (0o400,0o444,0o644)
author_receiving=json.loads(bodies['SOURCE_ONLY_RECEIVING.json'])
assert author_receiving['prior_seals_opening_and_closing_equal']==opening
tool=json.loads(bodies['SOURCE_ONLY_TOOL_RETURN.json'])
assert tool['chunk_id']=='75df58' and tool['exit_code']==0 and json.loads(tool['output'])==author_receiving
red=json.loads(bodies['RED_TOOL_RETURN.json']);green=json.loads(bodies['GREEN_TOOL_RETURN.json'])
assert red['chunk_id']=='ee9a9e' and red['exit_code']==1 and 'FAILED (failures=1)' in red['output'] and 'PROBE_SOURCE_MODE' in red['output']
assert green['chunk_id']=='ce8227' and green['exit_code']==0 and green['output'].count(' ... ok\n')==3
assert bodies['PREDECESSOR_ACTUAL_TOOL_RETURN.json']==receive(ROOT/'g132-positive-public-actual/ACTUAL_INVOCATION_TOOL_RETURN.json',{'sha256':'368192c0e2a7a8802248cb83e9098f4c4d17d68c23a8e901e8c4e656b87d04bd'})[0]
assert bodies['PUBLIC_CERTIFICATE.pem']==c['PUBLIC_CERTIFICATE']==old_bodies['PUBLIC_CERTIFICATE.pem']
assert c['PUBLIC_CERTIFICATE']==receive('/usr/share/ca-certificates/mozilla/ISRG_Root_X1.crt',desc(c['PUBLIC_CERTIFICATE']))[0]
assert b'PRIVATE KEY' not in c['PUBLIC_CERTIFICATE']
assert not os.path.lexists(BASE/'one-time-output') and not os.path.lexists(OLD/'one-time-output')
result=dict(schema='g132.public-positive-r2-independent-source-receiving.v1',authority='NONE',
    technical_disposition='SOURCE_READY_FOR_ROOT_SELECTION_R2',source=desc(source),selection=desc(bodies['PREPARED_SELECTION.json']),
    invocation=desc(bodies['INVOCATION.json']),manifest_population=16,manifest_population_bytes=98803,
    exact_diff=True,unchanged_helper_segments=unchanged,main_ast_equal_except_two_prior_reader_routes=True,
    complete_selection_equal=True,bootstrap_algorithm_equal_after_exact_substitutions=True,
    every_actual_file_reader_predicate_applied=True,history_reader_count=8,history_opening_closing_equal=True,
    history_records=opening,owned0600_specific_reader_only=True,generic_reader_remains_incompatible_with0600=True,
    historical_source_ready_supersession_preserved=True,old_and_new_output_paths_absent=True,
    interpreter_version=sys.version.split()[0],owner_ast_match=True,
    target_source_imported_or_executed=False,native_capture_calls=0,encryption_calls=0,provider_calls=0,
    private_original_bodies_read=0,original_awards=[],records=records)
raw=(json.dumps(result,indent=2,sort_keys=True)+'\n').encode();p=OUT/'VERIFICATION.json'
fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_CLOEXEC,0o444)
try:assert os.write(fd,raw)==len(raw);os.fsync(fd)
finally:os.close(fd)
assert p.read_bytes()==raw
print(json.dumps(dict(state=result['technical_disposition'],authority='NONE',verification=dict(path=str(p),**desc(raw)),
    reader_observations=len(records),history_reader_count=8,target_source_imported_or_executed=False,native_crypto_provider_calls=0,original_awards=[])))
