# Positive public control r2: independent source receiving

**Technical disposition: SOURCE_READY_FOR_ROOT_SELECTION_R2, authority NONE.** No source blocker was found for the distinct exact r2 public-control selection after applying each source/evidence reader's actual custody predicates. The packet's derived receiving JSON has a separate integer-precision defect; the exact retained tool-output text and fresh independent observations resolve that evidence question without changing the frozen source packet.

This is bounded independent engineering evidence, not an execution grant, audit verdict, positive encryption result, original G1/G3 award or whole-path qualification. Root alone owns the fresh actual selection and execution.

## Exact object and fresh receiving

The commissioned source manifest is `e6ee948052d92766383baf8a8c7893a3f473b95ab4caf6f1f32378fc79438445`: 16 files, 98,803 bytes. Every member matches its descriptor and declared0444 mode. The exact source is28,783 bytes/SHA-256 `348d77795951133141ddcab06510fc915fc6718e0e0787a335827c0c8bc4ed44`; selection is4,482 bytes/`f2c0a4d351ddc81654525a8001f7f7b65b9c53a548351e1730795845a70436c4`; invocation is5,765 bytes/`b603bf9523bb4809d98946d24d7f324000dc5355a4bcace1d284dc3e069a012f`.

Fresh independent receiving `38000f`, exit0, produced `VERIFICATION.json`:121,896 bytes/SHA-256 `8dc04cba1c34ea4b6b96b8bcfcafbbd30689f9e79660fce0a2766a838b685dcf`. It retains62 no-follow, identity-stable file observations, including the actual reader-class predicates applied to each execution dependency. The exact command and full returned object are retained. No target source or helper was imported/executed by this reviewer.

## The finite custody correction

The old source remains `c66e70e7…`; its six-member seal and modes are unchanged. Recomputed diff bytes equal `SOURCE_DIFF.patch`. The generic `read_bound` and all other unchanged helpers are byte-identical. The normalized main AST equals its predecessor after reversing exactly two prior-reader route substitutions; the selection builder differs only by the two declared history fields. The capture, fixed three-FD command, public plaintext/certificate, output/time limits, PC01–PC06 predicates, parser and cleanup logic remain unchanged.

`read_historical_public_receipt` accepts only one literal canonical path and its full exact3979-byte/hash descriptor. It requires matching nonroot real/effective identity, file UID/GID matching that identity, regular one-link0600 custody, no xattrs, no-follow opening, bounded exact-length bytes, closing descriptor/path identity and ancestry, and exact hash. `read_prior_seal` routes only that path and refuses a mismatched selected digest. The resulting complete record participates in the same initial/currentness equality checks as every other prior record.

The generic reader still excludes0600. No old file was chmodded or rewritten, and the old consumed Root selection remains explicitly historical rather than current authority. The source binds the actual `cd895e/1` refusal and the independent `feaec34f…` correction; the earlier source-ready claim remains superseded for that old source.

## Actual dependency predicates

The following current modes were independently evaluated against the reader actually selected by r2; byte hashes, one-link regular shape, no-follow/no-xattr custody and closing identities were checked in the same reads.

| Dependency class | Observed mode | Applied receiving rule |
|---|---|---|
| r2 bootstrap source |0444 | Exact source bytes/hash, regular one-link0444, stable descriptor/path |
| Selection, source, installation index, carrier loader |0444 | Original nonexecutable `read_bound`:0400/0444/0644, size bound, ancestry and full closing identity |
| Nine loader modules |0444 | Original loader's mode and1MiB shape/pin constraints |
| Maintained QUALIFIER/COMPILER |0444 | Original bounded `read_file` custody, exact pins/index joins and owner AST |
| `/usr/bin/env`, `/usr/bin/openssl` |0755 | Original executable mode/access predicate plus exact binary pins |
| Actual failed invocation return |0644 | Unchanged generic source/evidence reader |
| Consumed Root selection |0644 | Unchanged generic source/evidence reader; history only |
| Independent refusal-correction manifest |0444 | Unchanged generic source/evidence reader |
| Historical failed-public `PROBE_RESULT.json` |0600 | Exact one-path owned historical-observation reader |
| Prior actual-review manifest, readiness manifest, followup manifest and design |0444 | Unchanged generic source/evidence reader |

All eight history records were read twice; exact opening and closing records agree. The retained exact author-tool stdout's identity/ancestor records also equal those fresh records. The3979-byte historical observation retains its original0600 custody.

The selected interpreter remains the exact30,894,944-byte Python3.12.14 executable `fa674435…`, mode0755. The owner AST recomputed under that interpreter is `ef5d9af6…`. Invocation shell/argv/bootstrap joins and the complete selection object are exact; the bootstrap differs only by the declared source path/descriptor and selection digest substitutions. Native owner/environment checks remain live predicates for any later actual call.

## Retained controls and integer-safe evidence correction

The retained old-source test `ee9a9e/1` preserves its one expected receipt-read failure, `PROBE_SOURCE_MODE`. The successor test `ce8227/0` preserves all three passing controls: exact0600 receipt reception, continued generic-reader rejection, and wrong-digest rejection. Source-only receiving `75df58/0` retains the exact output text for all eight prior reads. These are the author's source-only controls; no test or native operation was replayed by this reviewer.

Initial independent receiving `9f5360/1` stopped at exact comparison with `SOURCE_ONLY_RECEIVING.json`. Diagnosis `1315b9/0` found24 rounded large-integer values in that derived file: nanosecond timestamps and the large `/workspace` inode. For example, exact inode9223372036854776314 became9223372036854776000. All differences are integer values with identical binary64 projections; the precise reserialization mechanism was not independently observed.

The retained `SOURCE_ONLY_TOOL_RETURN.json` output string preserves the original exact decimal integers. Parsing that string with Python's integer-safe JSON parser reproduces all current identity/ancestor rows exactly. The frozen derivative is preserved, and `PROJECTION_CORRECTION.json` supersedes only its claim to exact integer identity evidence. `AUTHOR_SOURCE_ONLY_STDOUT.json` preserves the exact retained output text bytes; it is not reconstructed from the rounded derivative. Keep those raw bytes or parse integers without binary64 coercion when receiving them.

The failed independent check, its exact initial verifier, the diagnosis and the corrected successful verifier are retained. The correction changes only which retained evidence is authoritative for integer equality; no target guard, source byte, source mode or prior evidence was changed. The author's context-boundary/generation assertions remain identified by its `BOUNDARY_RECONCILIATION.json`; this review invents no missing preparation tool return.

## Remaining actual observation

Both the refused predecessor output and distinct r2 output paths were absent at receiving. Create-once reservation and no automatic retry remain unchanged. This is not a replay of `cd895e/1` or the earlier failed-invalid-certificate capture.

Any future qualification still requires the actual exact Root call, complete terminal/result join, retained cipher and streams, original owner receipt, source currentness and full native/file closure. Positive scope remains public fixture encryption plus outer AuthEnvelopedData DER type, without decryption or AEAD verification. All native/crypto outcomes remain unobserved by this reviewer. No original private body, sender, provider, controller, protected grant or original award is involved; old protected301/625f history remains UNKNOWN_NO_REPLAY.
