# DG18 criterion 10 — exact current integration receiving

Report state: FINAL source-and-population receiving; independent original-criterion adjudication pending.

This packet asks an independent reviewer to adjudicate **criterion 10 of the original 14**, at product `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7`, tree `9c3913ceaa95f3f36b0377fe2dba4a302afcba89`. It does not ask for whole DG18, criterion 11, native, OR, C02, occurrence, installation, merge or release acceptance. No original award is issued by this author packet.

## Original obligation and exact inputs

Original #215 criterion 10 requires an exact-source integration census covering continuity, claim-run, STATE/ROADMAP, governor re-entry instructions, the validation registry, generated/package inventory and public claims, with a baseline failure preserved before source change. It does not make a successful runtime rerun the substitute for that census. Criterion 11 separately governs isolated package/install and current-consumer evidence when shipping bytes change.

The actual GitHub issue body is 35,566 bytes, SHA-256 `40dbebcc34083f49a49af13e5c6ab50ffe6fbf5a99395d9594926e4668fd09f1`. The binding amendment comment 5638756120 is 4,943 bytes, SHA-256 `3774677f6aa3ad2676d8afbded7dce277f5e561a8bf492200418a0495393caaf`. Both actual tool returns and exact bodies are retained. They match the authoritative historical hashes. Earlier lane copies have one additional terminal LF; the first exact-copy assertion failed and that preparation failure is retained. Their historical bytes are not rewritten, and no semantic contract change is inferred.

The actual historical validator body was obtained from immutable accepted commit `6b353b48b2fc8a6de0c6223f48d341c484c98191`. It is exactly 123,131 bytes, SHA-256 `0ee6698ea185d9c27f2df10d43022af9ad2ef3c5641e348e03403f0bf94eff7d`, Git blob `b4a5924b44dd1061e9b3ab58e363e5e812892f88`. This resolves only the earlier local-body availability gap; it does not alter the earlier receipt.

## Completed receiving

Actual command `dfc0dc/0` completed the read-only census. `A10_CURRENT_SOURCE_AND_PACKAGES.json` is 116,251 bytes, SHA-256 `cde52ef0310e91e798ed25136836d32014286c0e29980635601bec1bf366ad83`.

| Original census category | Exact receiving |
|---|---|
| Continuity and claim-run | Current source bodies, Git blobs/modes and SHA-256 values for the canonical continuity, rotation, custody, input, reader, shell/companion and validator owners. All 27 previously named owners are byte-identical to the retained 14ed census. Against accepted 6b, 23 are identical and four differ. |
| STATE/ROADMAP and governor re-entry | Both canonical templates, governor SKILL.md, continuity and canonical-state-rotation references are physically received at exact current Git identities. The package source population also includes all current shared references. |
| Validation registry | The current registry body and its ten canonical-state-rotation require/execute registrations are received, with all 29 canonical fixture paths and body hashes. |
| Integration changes | All 16 actual parent-to-current source/history changes are enumerated, including whether each ships in the package. No old or new path is omitted from the delta. |
| Generated/package inventory | All 70 canonical package source paths are body-hashed. The already-built clean current canonical archive has 75 members and the standalone archive has 72. Every inventory member's body, size, digest and archive mode is checked, the complete physical/member sets agree, and both inventories bind exact head/tree/clean state. Every non-inventory payload agrees with the existing canonical source projection. This reads existing artifacts; it is not a new build or installation. |
| Public claims | README and all three host/marketplace manifests plus the integration document are directly body-bound. A complete Git path census of R0039/canonical-rotation references across README, CHANGELOG, docs and workflows contains 65 paths, classified as current integration documents, public documents, research/work-order evidence or retained audit history. README's package/authority boundary passages are retained. Current integration prose expressly withholds original issue acceptance and preserves all original denominators and native/OR/C02 limitations. |
| Baseline before source change | Full terminal failure from run 44641197003/A1, job 135972383182, exact parent14ed, completed 00:30:59 UTC. The original 229,426-byte log SHA `342e0572654dce775dd9f6899e39e26eb7498c36748cc8c54cd7bd198326a954` is hash-verified and remains unchanged. Source51416 was subsequently committed at its actual Git timestamp; the independent correction review is bound separately. |

The accepted6b-to-current validator diff is exactly removal of `exec` before its strict claim-check Python invocation. The succeeding validator stages can then execute. This is a control-flow change and is **not** asserted to be whole runtime equivalence. The old companion's changed module-level admission/validator bindings likewise retain their previous explicit non-equivalence limits. Canonical reader non-docstring AST equality remains applicable because the exact current body is unchanged from the already inspected 14ed body.

## Evidence ceiling and review question

The script records no original award. The independent reviewer must decide whether the seven exact census categories and real before-change baseline complete original criterion 10 at this current source, or identify a concrete missing category/input. It must not require invented OR or C02 inputs for this independent criterion, and it must not promote generated inventory checks to criterion 11's installation/current-consumer obligation.

CI44655969487/A1 remains pending in the source preparation. Its later outcome belongs in a separate actual observation. Historical W-FULL, criterion 11, A7 and occurrence/cold scopes remain at their exact original identities. N1 is still mandatory LOST/UNKNOWN without an exception. No new occurrence, issuer lease, native event, controller operation, protected effect, merge or closure occurred.

## Preparation history

The first local transport command was refused by the exec server before process creation because its shell argument exceeded the argument-size limit. The completed tool payload was subsequently transferred in eight checked local chunks; all returned exit0. The first exact-copy assertion then exposed the extra LF in prior issue/amendment files. Actual provider bodies were preserved separately at their authoritative hashes. These are receiving preparation failures, not original product failures. The census itself completed once with exit0. No source mutation or original execution was repeated.

Author: `/root`. Authority: no acceptance by authorship. Independent receiving remains pending.
