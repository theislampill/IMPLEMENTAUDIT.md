"""Read the exact current A10 source and already-built package populations.

This is a receiving script outside product source. It performs no source,
controller, runtime, provider, installation or acceptance mutation.
"""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/530bc07ea12b/implementaudit')
PRIOR = Path('/workspace/scratch/530bc07ea12b/dg18-original-frontier-continuation')
BUILD = Path('/workspace/scratch/530bc07ea12b/g2-profile-integration-publication')
HEAD = '51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
TREE = '9c3913ceaa95f3f36b0377fe2dba4a302afcba89'
PARENT = '14ed4c7179d477d90882ebf5c5031692056e5491'
ACCEPTED = '6b353b48b2fc8a6de0c6223f48d341c484c98191'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1')


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], env=ENV)


def sha(body):
    return hashlib.sha256(body).hexdigest()


def descriptor(body):
    return {'bytes': len(body), 'sha256': sha(body)}


def write(name, value):
    target = HERE / name
    target.open('x').write(json.dumps(value, indent=2, sort_keys=True) + '\n')
    return descriptor(target.read_bytes())


def tree(ref):
    rows = {}
    for line in git('ls-tree', '-rz', ref).split(b'\0'):
        if not line:
            continue
        meta, path = line.split(b'\t', 1)
        mode, kind, oid = meta.decode().split()
        rows[path.decode()] = {'mode': mode, 'type': kind, 'git_blob': oid}
    return rows


def blob(meta):
    body = git('cat-file', 'blob', meta['git_blob'])
    assert hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest() == meta['git_blob']
    return body


assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE
assert git('show', '-s', '--format=%P', HEAD).decode().strip() == PARENT
assert not git('status', '--porcelain', '--untracked-files=all')
current, previous = tree(HEAD), tree(PARENT)
old = json.loads((PRIOR / 'evidence/A10_EXACT_SOURCE_CENSUS.json').read_text())
assert old['candidate_source'] == PARENT and old['accepted_source'] == ACCEPTED
owners = []
for item in old['owners']:
    path = item['path']
    meta = current[path]
    body = blob(meta)
    assert meta == {k: item['current'][k] for k in ('git_blob', 'type', 'mode')}
    assert descriptor(body) == {k: item['current'][k] for k in ('bytes', 'sha256')}
    accepted = dict(item['accepted'])
    if path.endswith('/validate-run-root.sh'):
        historical = (HERE / 'accepted-6b-validate-run-root.sh').read_bytes()
        assert hashlib.sha1(b'blob ' + str(len(historical)).encode() + b'\0' + historical).hexdigest() == accepted['git_blob']
        accepted = {k: accepted[k] for k in ('git_blob', 'mode', 'type')}
        accepted.update(descriptor(historical))
    owners.append({'path': path, 'current': dict(meta, **descriptor(body)),
                   'accepted': accepted, 'byte_identical': accepted['git_blob'] == meta['git_blob'],
                   'unchanged_since_retained_14ed_census': True})

package_paths = sorted(p for p in current if p.startswith('skills/implementaudit/') or re.fullmatch(r'skills/audit-(?:state|assess|implement|andon)/SKILL\.md', p))
assert package_paths == sorted(v['path'] for v in old['declared_package_source_population'])
declared = [{'path': p, **current[p], **descriptor(blob(current[p]))} for p in package_paths]
fixture_paths = sorted(p for p in current if p.startswith('fixtures/canonical-state-rotation/'))
assert fixture_paths == sorted(v['path'] for v in old['fixture_population'])
fixtures = [{'path': p, **current[p], **descriptor(blob(current[p]))} for p in fixture_paths]

changed = []
for p in sorted(set(current) | set(previous)):
    if current.get(p) == previous.get(p):
        continue
    changed.append({'path': p, 'before': previous.get(p), 'after': current.get(p),
                    'current_body': descriptor(blob(current[p])) if p in current else None,
                    'packaged': p in package_paths})
assert len(changed) == 16

spec = importlib.util.spec_from_file_location('a10_package_contract', ROOT / 'scripts/package-contract.py')
builder = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = builder
spec.loader.exec_module(builder)
contract = json.loads(blob(current['package/implementaudit-package.json']))
packages = []
for role, declaration in contract['generated_projections'].items():
    artifact = BUILD / 'clean-package-output' / declaration['artifact']
    body = artifact.read_bytes()
    expected = {p: (b, m) for p, b, m in builder.artifact_payload_entries(ROOT, role, contract)}
    with zipfile.ZipFile(artifact) as archive:
        assert len(archive.namelist()) == len(set(archive.namelist()))
        assert set(archive.namelist()) == set(expected) | {'IMPLEMENTAUDIT_INVENTORY.json'}
        inventory_body = archive.read('IMPLEMENTAUDIT_INVENTORY.json')
        inventory = json.loads(inventory_body)
        assert inventory['source'] == {'commit': HEAD, 'tree': TREE, 'worktree_state': 'clean'}
        assert inventory['artifact_role'] == role
        assert [m['path'] for m in inventory['members']] == sorted(expected)
        received = []
        for member in inventory['members']:
            p = member['path']
            b = archive.read(p)
            assert descriptor(b) == {k: member[k] for k in ('bytes', 'sha256')}
            assert b == expected[p][0], p
            mode = (archive.getinfo(p).external_attr >> 16) & 0o777
            assert mode == expected[p][1], p
            received.append(dict(member, mode=oct(mode)))
        packages.append({'path': str(artifact), 'role': role, **descriptor(body),
                         'inventory': descriptor(inventory_body), 'source': inventory['source'],
                         'members_including_inventory': len(archive.namelist()), 'members': received,
                         'matches_existing_source_projection': True,
                         'scope': 'READ_ONLY_GENERATED_POPULATION_AND_SOURCE_BINDING_NOT_INSTALL_OR_NATIVE_ACTIVATION'})

registry_body = blob(current['scripts/verify-package.sh']).decode()
registry = [{'line': n, 'text': line} for n, line in enumerate(registry_body.splitlines(), 1)
            if 'canonical-state-rotation' in line]
assert registry == old['registry_entries']
public_result = subprocess.run(['git', '-C', str(ROOT), 'grep', '-l', '-I', '-E',
                               'R0039|canonical.state.rotation|rotation.{0,20}canonical', HEAD,
                               '--', 'README.md', 'CHANGELOG.md', 'docs', '.github'],
                              env=ENV, capture_output=True, check=False)
assert public_result.returncode in (0, 1)
public_paths = sorted(line.decode().split(':', 1)[1] for line in public_result.stdout.splitlines())
public = [{'path': p, **current[p], 'category':
           'retained_audit_history' if '/archive/' in p else
           'research_or_work_order_evidence' if p.startswith('docs/research/') else
           'current_integration_document' if p.startswith('docs/integration/') else 'public_document'} for p in public_paths]
direct_public_paths = ['README.md', '.codex-plugin/plugin.json', '.claude-plugin/plugin.json',
                       '.claude-plugin/marketplace.json', 'docs/integration/active-rlgwo-composite-20261025.md']
direct_public = [{'path': p, **current[p], **descriptor(blob(current[p]))} for p in direct_public_paths]
readme = blob(current['README.md']).decode().splitlines()
excerpts = []
for first, last in [(890, 965), (1336, 1358)]:
    excerpts.append({'path': 'README.md', 'first_line': first, 'last_line': last,
                     'body': '\n'.join(readme[first - 1:last]) + '\n'})

historical_log = PRIOR / 'evidence/CI44641197003_JOB135972383182.log'
assert descriptor(historical_log.read_bytes()) == {'bytes': 229426, 'sha256': '342e0572654dce775dd9f6899e39e26eb7498c36748cc8c54cd7bd198326a954'}
issue_bytes = (HERE / 'ISSUE215_CURRENT_BODY.md').read_bytes()
amend_bytes = (HERE / 'COMMENT_5638756120_CURRENT.md').read_bytes()
assert sha(issue_bytes) == '40dbebcc34083f49a49af13e5c6ab50ffe6fbf5a99395d9594926e4668fd09f1'
assert sha(amend_bytes) == '3774677f6aa3ad2676d8afbded7dce277f5e561a8bf492200418a0495393caaf'
result = {
    'schema': 'dg18.a10-exact-integration-census.v2', 'author': '/root', 'authority': 'NONE_BY_CENSUS',
    'observed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_commit': HEAD, 'source_tree': TREE, 'source_parent': PARENT, 'source_dirty_state': 'clean',
    'original_criterion': 'A10 / criterion 10 of 14', 'independent_receiving': 'PENDING',
    'original_awards': [], 'issue': descriptor(issue_bytes), 'amendment': descriptor(amend_bytes),
    'owners': owners, 'declared_package_source_population': declared, 'fixture_population': fixtures,
    'new_integration_changes': changed, 'generated_packages': packages, 'registry_entries': registry,
    'same_27_owners_as_14ed': True, 'prior_static_python_comparison_remains_exact_body_applicable': old['python_semantics'],
    'validator_change': 'Only removal of exec before the strict claim Python check; subsequent validator stages can now run. Not whole semantic equivalence.',
    'public_claim_path_census': public, 'direct_public_claim_owners': direct_public, 'public_claim_excerpts': excerpts,
    'baseline_failure': {'run_id': 44641197003, 'attempt': 1, 'source_commit': PARENT,
                         'job_id': 135972383182, 'terminal': 'failure', 'completed_at': '2026-11-20T00:30:59Z',
                         'full_log': {'path': str(historical_log), **descriptor(historical_log.read_bytes())},
                         'new_source_committed_at': git('show', '-s', '--format=%cI', HEAD).decode().strip(),
                         'source_repair_independent_review_manifest': '039a1a581ef511df7e3397ca8ba52225149df220d6673977e0c7093836885598'},
    'boundaries': {'A11_is_separate': True, 'install_or_runtime_requalification_performed': False,
                   'old_runtime_awards_transferred': False, 'N1': 'LOST_UNKNOWN_UNCHANGED',
                   'OR_C02_occurrence_observation_created': False, 'whole_DG18_acceptance': False,
                   'merge_release_or_closure': False}
}
receipt = write('A10_CURRENT_SOURCE_AND_PACKAGES.json', result)
print(json.dumps({'result': receipt, 'owners': len(owners), 'unchanged_versus_6b': sum(x['byte_identical'] for x in owners),
                  'declared_package_sources': len(declared), 'fixtures': len(fixtures), 'integration_changes': len(changed),
                  'generated_member_counts': {p['role']: p['members_including_inventory'] for p in packages},
                  'public_claim_paths': len(public), 'original_awards': [], 'independent_receiving': 'PENDING'}))
