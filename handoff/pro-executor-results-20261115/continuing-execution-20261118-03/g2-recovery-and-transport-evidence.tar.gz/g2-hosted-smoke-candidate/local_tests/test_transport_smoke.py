"""Local isolated authoring checks; no hosted/network operation or qualification."""
import importlib.util
import contextlib
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'qualification/dg16-r5-full-g2/transport_smoke.py'
REPAIRED = Path('/workspace/scratch/2678f1e431c3/g2-repair-repo/qualification/dg16-r5-full-g2/live_control.py')
COMMIT = '0fc8b8a0343925e72b24f4f98daad8ba988bd045'
HEAD = (COMMIT + '\trefs/heads/pro/dg16-g2-reviewed-control-20261118-01\n').encode()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


class FixtureCapture:
    """Replace only the external process boundary; real hold and adapter execute."""
    class Refusal(ValueError):
        pass

    def __init__(self, *, head=HEAD, fetch_code=0, cleanup_failure=False):
        self.head, self.fetch_code, self.cleanup_failure = head, fetch_code, cleanup_failure
        self.commands = []

    def capture(self, label, argv, records, deadline, seconds):
        self.commands.append(argv)
        index = len(self.commands)
        code = self.fetch_code if index == 3 else 0
        out = self.head if index == 2 else b''
        records.append({'name': label, 'returncode': code, 'fixture': True})
        if index == 3 and self.cleanup_failure:
            raise self.Refusal('CHILD_CLEANUP_UNCERTAIN')
        return code, out, b''


class SmokeTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue(SCRIPT.is_file(), 'Prospective smoke implementation is missing')
        self.smoke = load(SCRIPT, 'smoke')
        self.control = load(REPAIRED, 'control')
        self.temp = tempfile.TemporaryDirectory(dir=ROOT, prefix='g2-smoke-local-check-')
        self.addCleanup(self.temp.cleanup)
        self.work = Path(self.temp.name)

    def observe(self, fixture):
        return self.smoke.observe(self.work, self.control, fixture, time.monotonic() + 180)

    def test_fetch_success_stops_before_parent_payload_and_reservation(self):
        fixture = FixtureCapture()
        result = self.observe(fixture)
        self.assertEqual(result['status'], 'TRANSPORT_OBSERVED')
        self.assertEqual(len(fixture.commands), 3)
        self.assertEqual(fixture.commands[-1][-2:], ['https://github.com/theislampill/IMPLEMENTAUDIT.md.git', COMMIT])
        self.assertTrue(all(result['forbidden_files_absent'].values()))
        self.assertTrue((self.work / 'CONTROL_READS.json').is_file())
        self.assertFalse(result['original_acceptance_awarded'])
        self.assertFalse(result['full_G2_awarded'])
        self.assertFalse(result['G132_awarded'])

    def test_wrong_head_prevents_fetch(self):
        fixture = FixtureCapture(head=b'1' * 40 + HEAD[40:])
        result = self.observe(fixture)
        self.assertEqual(result['status'], 'REFUSED')
        self.assertEqual(result['code'], 'CONTROL_HEAD_CHANGED')
        self.assertEqual(len(fixture.commands), 2)

    def test_fetch_nonzero_preserves_failure_evidence(self):
        result = self.observe(FixtureCapture(fetch_code=128))
        self.assertEqual(result['status'], 'REFUSED')
        self.assertEqual(result['code'], 'CAPTURE_NONZERO')
        self.assertEqual(len(result['commands']), 3)
        self.assertFalse(result['fetch_completed'])

    def test_cleanup_refusal_never_becomes_success(self):
        result = self.observe(FixtureCapture(cleanup_failure=True))
        self.assertEqual(result['status'], 'REFUSED')
        self.assertEqual(result['code'], 'CHILD_CLEANUP_UNCERTAIN')
        self.assertFalse(result['fetch_completed'])

    def test_changed_source_is_refused_before_import(self):
        changed = self.work / 'source.py'
        changed.write_text("raise AssertionError('MUST_NOT_EXECUTE')\n")
        with self.assertRaisesRegex(self.smoke.Refusal, '^SOURCE_DIGEST_REFUSED$'):
            self.smoke.load_pinned(changed, '0' * 64)

    def test_existing_reservation_is_detected_without_capture(self):
        (self.work / 'CONSUMPTION_RESERVED.json').write_bytes(b'{}\n')
        fixture = FixtureCapture()
        result = self.observe(fixture)
        self.assertEqual(result['status'], 'REFUSED')
        self.assertEqual(result['code'], 'FORBIDDEN_OUTPUT_PRESENT')
        self.assertEqual(fixture.commands, [])
        self.assertFalse(result['forbidden_files_absent']['CONSUMPTION_RESERVED.json'])

    def test_source_pin_failure_still_writes_structured_nonacceptance_evidence(self):
        source = self.work / 'source'
        source.mkdir()
        (source / 'live_control.py').write_bytes(b'raise RuntimeError("MUST_NOT_RUN")\n')
        output = self.work / 'g2-production-transport-smoke-123-1'
        env = {'RUNNER_TEMP': str(self.work), 'GITHUB_RUN_ID': '123', 'GITHUB_ACTIONS': 'true',
               'RUNNER_ENVIRONMENT': 'github-hosted', 'GITHUB_REPOSITORY': 'theislampill/IMPLEMENTAUDIT.md',
               'GITHUB_EVENT_NAME': 'push', 'GITHUB_REF': 'refs/heads/engineering/g2-production-transport-smoke-20261118-01',
               'GITHUB_RUN_ATTEMPT': '1', 'GITHUB_SHA': '1' * 40}
        with mock.patch.dict(os.environ, env, clear=True), mock.patch.object(self.smoke, 'HERE', source), \
             mock.patch.object(sys, 'argv', ['smoke', '--output', str(output)]), contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(self.smoke.main(), 1)
        evidence = json.loads((output / 'RESULT.json').read_bytes())
        self.assertEqual(evidence['code'], 'SOURCE_DIGEST_REFUSED')
        self.assertEqual(evidence['commands'], [])
        self.assertFalse(evidence['original_acceptance_awarded'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
