# G2 Production Transport Smoke Implementation Plan

**Goal:** Prepare one prospective hosted transport observation without qualification or acceptance effects.

**Architecture:** Load the exact repaired `live_control.py` and unchanged production `host_utility.py`. A strict adapter delegates precisely init, HTTPS discovery, and HTTPS fetch to production `capture`, checks the fixed remote head, and stops after fetch before the next `hold` operation.

**Files:** Publishable `qualification/dg16-r5-full-g2/transport_smoke.py` and `.github/workflows/g2-production-transport-smoke.yml`; local validation and handoff material remain outside the repository.

**Constraints:** Authoring only; no repository edits, publication, hosted execution, pair, decision, or reservation. Fixed repository/control branch/control commit; 180-second operation and five-minute job; new branch creation, attempt 1, exact source parent; only pinned existing actions.

- [x] Write local behavior checks for stopping after fetch, wrong-head refusal, fetch/cleanup refusal, source-pin refusal, and forbidden-output detection; observe initial missing-feature failure.
- [x] Implement the bounded script and creation-only workflow; include structured failure evidence.
- [x] Run local isolated checks without network or hosted execution; inspect workflow structure and source hashes.
- [x] Freeze exact hashes and report limitations for cold review; no integration or publishing.

**Review focus:** A mismatched head must prevent fetch; a cleanup refusal must never become transport success; no command after fetch may run; source-pin failure must precede import; output publication must never imply original awards. Local fixtures do not prove hosted transport.
