# FINAL — Prospective hosted transport smoke authoring handoff

Author: `/root/g2_transport_repair_review`. This is a new AUTHORING task after the separately frozen two-file source review. I am not an independent reviewer of this smoke candidate. Authority is NONE; root alone integrates and publishes. No formal audit route or award is claimed.

## Publishable files and exact hashes

| Target path relative to repository | SHA-256 |
| --- | --- |
| `qualification/dg16-r5-full-g2/transport_smoke.py` | `baa97ec17871541cafdbf7a0f118d45c3704bf5a9389cc4c86c508dea192471b` |
| `.github/workflows/g2-production-transport-smoke.yml` | `7beac6d601cff224540f64b71c72d722cd3ff73e4765fedcec24c85d6966de23` |

Both are new files rooted at `/workspace/scratch/2678f1e431c3/g2-hosted-smoke-candidate`. The workflow pins the exact script hash above. `AUTHORING_PLAN.md`, `AUTHORING_HANDOFF.md`, and `local_tests/` are local authoring material, not proposed workflow inputs.

## Behavior and boundaries

The script checks and loads the exact repaired `live_control.py` hash `cd8262defc85c2541632fe00e51bc78c804b13a3a8a4501e39300b4269f866ff` and unchanged production `host_utility.py` hash `02a15dc96ecce23e14a3a84bca880aa536d79fffc4f6d6160835cb4ba97a19b5`. It enables and reads back the same Linux subreaper precondition used by the production caller.

The only synthetic request fields are repository, control branch, run ID `TRANSPORT_SMOKE_NON_ACCEPTANCE`, and its synthetic control path. There is no real request, proof, reviewer, workflow-commit request field, expiry, or root decision data.

The script invokes repaired `hold` through a strict capture adapter allowing exactly these three commands, in order:

1. Bare init of a new private scratch cache.
2. HTTPS `ls-remote` for the fixed public repository and control branch, with the repaired per-command protocol setting. Output must be exactly commit `0fc8b8a0343925e72b24f4f98daad8ba988bd045` and that branch.
3. HTTPS fetch of that exact commit, using the repaired command and the same private cache.

Every allowed command delegates unchanged to the real production `utility.capture`; the adapter does not alter its environment, custody, watchdog, stream, or cleanup behavior. Missing head, changed head, nonzero Git exit, cleanup refusal, unexpected command, and deadline expiration fail closed without retry.

After real capture returns fetch success with successful custody cleanup, the adapter raises its private stop signal. It never returns fetch success into `hold`, so parent inspection, payload inspection, validation, final acceptance reread, and reservation logic are not reached. The script checks that the reservation and all three decision filenames are absent. Final structured evidence contains at most three production command records with stream digests and custody observations, with a 65,536-byte cap. It never prints raw command streams or environment contents.

The workflow is a single `ubuntu-26.04` job with a five-minute limit. Script operation time is fixed at 180 seconds, with production per-command limits retained; the smoke step has a four-minute outer limit to leave room for evidence handling. Its trigger is only push to fresh `engineering/g2-production-transport-smoke-20261118-01`; the job guards creation, non-deletion, non-force, zero-before SHA, repository, exact ref, and attempt 1. Before script execution it checks that HEAD has the sole source parent `9a349423b6ca3dda18115a07ed41b63970bc8b77` and verifies the script hash.

Permissions are `contents: read`. Checkout and upload use the existing pinned action commits, with no persisted checkout credentials, submodules, or LFS. There is no manual dispatch trigger. Only `RESULT.json` is uploaded. An always-run evidence step produces a bounded refusal record if earlier steps did not produce one. Explicit original acceptance, full G2, G132, full-pair execution, control replay, original consumption, branch writing, and retry fields are all false.

## Local verification actually performed

- Initial missing-implementation run: six expected assertion failures, no errors; tool chunk `2259d9`.
- Final isolated behavior suite: seven tests passed, exit 0, 0.043 seconds; tool chunk `0f3b0e`. It executes the actual repaired `hold` and new adapter with a local fixture replacing only external capture. Cases cover successful stop before parent/payload/reservation, changed head before fetch, nonzero fetch, cleanup refusal, source digest refusal before import, existing reservation rejection, and structured output after source-pin failure.
- Python AST and YAML parsing, both workflow shell blocks through `bash -n`, workflow bounds/pin structure, and execution of the actual failure-fallback block in an isolated temporary directory all passed; tool chunk `c12551`.
- Frozen source, regression test, and utility hashes were rechecked, with no repository modifications by this authoring task; tool chunk `5f7d41`.

The local fixture results are not real hosted transport observations. No smoke network operation, hosted operation, full pair, original consumption, commit, branch creation/update, push, workflow invocation, or repository edit was performed.

## Scope gaps for cold review and root decision

1. Independent cold review of this newly authored script/workflow is outstanding. The earlier source review does not cover them.
2. GitHub Actions execution, action availability, runner behavior, DNS/TLS, and successful fixed-remote fetch remain unobserved. No hosted success is claimed.
3. The fixed control head is checked at discovery only; there is deliberately no post-fetch head reread, because the smoke stops at fetch. This is no evidence of live acceptance currentness or unchanged private inputs.
4. Hard cancellation, runner loss, or exhaustion of the entire job limit can prevent an always-run step or artifact upload; the fallback handles ordinary preceding-step failures and missing script evidence.
5. The integration commit must be a sole child of the fixed base. Existing source and decision/workflow acceptance pins must remain unrepointed. The original full-pair candidate remains separate.
6. At the inspected base, `pages.yml` and `validate.yml` push triggers are main-only, and the full-pair workflow names another exact branch. Creating this smoke branch alone therefore does not match those push triggers. This relies on root preserving those workflow bytes during integration.

Prepared for review only. Root owns all subsequent integration and publication decisions.
