#!/usr/bin/env python3
"""Independent LOCAL checks. No network, hosted launch, candidate edit, or award.

The real production capture is exercised only against local git init and owned
Python subprocesses. A controlled capture fixture reaches the transport stop.
"""
import ast
import contextlib
import ctypes
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
REVIEW = HERE.parent
ROOT = Path('/workspace/scratch/2678f1e431c3')
CANDIDATE = ROOT / 'g2-hosted-smoke-candidate'
REPO = ROOT / 'g2-repair-repo'
DEPS = REPO / 'qualification/dg16-r5-full-g2'
SCRIPT = CANDIDATE / 'qualification/dg16-r5-full-g2/transport_smoke.py'
WORKFLOW = CANDIDATE / '.github/workflows/g2-production-transport-smoke.yml'
PINS = {
    SCRIPT: 'baa97ec17871541cafdbf7a0f118d45c3704bf5a9389cc4c86c508dea192471b',
    WORKFLOW: '7beac6d601cff224540f64b71c72d722cd3ff73e4765fedcec24c85d6966de23',
    DEPS / 'live_control.py': 'cd8262defc85c2541632fe00e51bc78c804b13a3a8a4501e39300b4269f866ff',
    DEPS / 'host_utility.py': '02a15dc96ecce23e14a3a84bca880aa536d79fffc4f6d6160835cb4ba97a19b5',
}
BASE = '9a349423b6ca3dda18115a07ed41b63970bc8b77'
PROC_CENSUS_AVAILABLE = (Path('/proc/self/task') / str(os.getpid()) / 'children').is_file()


def load(path, name):
    module = type(sys)(name)
    module.__file__ = str(path)
    exec(compile(path.read_bytes(), str(path), 'exec'), module.__dict__)
    return module


SMOKE = load(SCRIPT, 'independent_smoke')
CONTROL = SMOKE.load_pinned(DEPS / 'live_control.py', PINS[DEPS / 'live_control.py'])
UTILITY = SMOKE.load_pinned(DEPS / 'host_utility.py', PINS[DEPS / 'host_utility.py'])
HEAD = (SMOKE.CONTROL_COMMIT + '\trefs/heads/' + SMOKE.CONTROL_BRANCH + '\n').encode()


class Fixture:
    """Synthetic local boundary: never starts any external process."""
    def __init__(self, outcomes=None, fail=None, records_delta=1):
        self.calls = []
        self.outcomes = outcomes or [(0, b'', b''), (0, HEAD, b''), (0, b'', b'')]
        self.fail = fail
        self.records_delta = records_delta

    def capture(self, label, argv, records, deadline, seconds):
        index = len(self.calls)
        self.calls.append((label, list(argv), deadline, seconds))
        for _ in range(self.records_delta):
            records.append({'fixture': 'LOCAL_NON_ACCEPTANCE', 'returncode': self.outcomes[index][0]})
        if self.fail and index == self.fail[0]:
            raise self.fail[1]
        return self.outcomes[index]


class Isolated(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='independent-', dir=REVIEW)
        self.addCleanup(self.temp.cleanup)
        self.work = Path(self.temp.name)

    def observe(self, fixture):
        return SMOKE.observe(self.work, CONTROL, fixture, time.monotonic() + 5)

    def assert_refused(self, result, code):
        self.assertEqual(result['status'], 'REFUSED')
        self.assertEqual(result['code'], code)
        self.assertIs(result['fetch_completed'], False)


class BoundaryChecks(Isolated):
    def test_exact_pins_and_inert_parsing(self):
        for path, pin in PINS.items():
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), pin)
            if path.suffix == '.py':
                ast.parse(path.read_bytes())

    def test_success_only_three_commands_no_validator_or_original_request(self):
        fixture = Fixture()
        with mock.patch.object(CONTROL, 'validate', side_effect=AssertionError('VALIDATOR_REACHED')) as validator:
            result = self.observe(fixture)
        validator.assert_not_called()
        self.assertEqual(result['status'], 'TRANSPORT_OBSERVED')
        self.assertEqual(result['code'], 'FETCH_COMPLETED_STOPPED_BEFORE_PARENT')
        self.assertEqual(result['attempted_operations'], ['init', 'ls-remote', 'fetch'])
        self.assertEqual([x[1] for x in fixture.calls], SMOKE.CaptureGate(self.work, fixture, 1).allowed)
        self.assertEqual({p.name for p in self.work.iterdir()}, {'CONTROL_READS.json'})
        self.assertTrue(all(result['forbidden_files_absent'].values()))
        for field in ('original_acceptance_awarded', 'full_G2_awarded', 'G132_awarded',
                      'full_pair_executed', 'control_replayed', 'original_consumption',
                      'branch_written', 'automatic_retry'):
            self.assertIs(result[field], False)
        self.assertLess(len(json.dumps(result).encode()), 65536)

    def test_changed_or_malformed_heads_never_fetch(self):
        for raw in (b'', b'1' * 40 + HEAD[40:], HEAD + b'\n', HEAD.rstrip(b'\n'),
                    HEAD.replace(b'\t', b' '), HEAD + HEAD):
            with self.subTest(raw_shape=hashlib.sha256(raw).hexdigest()):
                fixture = Fixture([(0, b'', b''), (0, raw, b'')])
                self.assert_refused(self.observe(fixture), 'CONTROL_HEAD_CHANGED')
                self.assertEqual(len(fixture.calls), 2)
                (self.work / 'CONTROL_READS.json').unlink()

    def test_missing_ref_fails_immediately_without_poll_retry(self):
        fixture = Fixture([(0, b'', b''), (2, b'', b'')])
        with mock.patch.object(CONTROL.time, 'sleep', side_effect=AssertionError('RETRY_REACHED')):
            self.assert_refused(self.observe(fixture), 'CAPTURE_NONZERO')
        self.assertEqual(len(fixture.calls), 2)

    def test_nonzero_init_and_fetch_cannot_succeed(self):
        for index in (0, 2):
            outcomes = [(0, b'', b''), (0, HEAD, b''), (0, b'', b'')]
            outcomes[index] = (128, b'', b'SYNTHETIC_PRIVATE_DETAIL')
            fixture = Fixture(outcomes)
            result = self.observe(fixture)
            self.assert_refused(result, 'CAPTURE_NONZERO')
            self.assertEqual(len(fixture.calls), index + 1)
            self.assertNotIn('SYNTHETIC_PRIVATE_DETAIL', json.dumps(result))
            if (self.work / 'CONTROL_READS.json').exists():
                (self.work / 'CONTROL_READS.json').unlink()

    def test_cleanup_and_unexpected_refusals_are_closed_and_sanitized(self):
        for exc, code in ((UTILITY.Refusal('CHILD_CLEANUP_UNCERTAIN'), 'CHILD_CLEANUP_UNCERTAIN'),
                          (ValueError('SYNTHETIC_PRIVATE_DETAIL'), 'SMOKE_OPERATION_REFUSED')):
            fixture = Fixture(fail=(2, exc))
            result = self.observe(fixture)
            self.assert_refused(result, code)
            self.assertNotIn('SYNTHETIC_PRIVATE_DETAIL', json.dumps(result))
            (self.work / 'CONTROL_READS.json').unlink()

    def test_any_extra_or_altered_command_is_rejected_before_capture(self):
        for variant in ('remote', 'commit', 'extra_flag', 'parent', 'sequence'):
            with self.subTest(variant=variant):
                fixture = Fixture()
                deadline = time.monotonic() + 5
                gate = SMOKE.CaptureGate(self.work, fixture, deadline)
                records = []
                if variant in ('remote', 'extra_flag'):
                    gate.capture('bounded-read-only-control', gate.allowed[0], records, deadline, 2)
                    argv = list(gate.allowed[1])
                    if variant == 'remote': argv[-2] = 'https://example.invalid/refused.git'
                    else: argv.insert(1, '--no-replace-objects')
                elif variant == 'commit':
                    for argv in gate.allowed[:2]:
                        gate.capture('bounded-read-only-control', argv, records, deadline, 2)
                    argv = gate.allowed[2][:-1] + ['1' * 40]
                elif variant == 'parent':
                    for argv in gate.allowed[:2]:
                        gate.capture('bounded-read-only-control', argv, records, deadline, 2)
                    with self.assertRaises(SMOKE.FetchComplete):
                        gate.capture('bounded-read-only-control', gate.allowed[2], records, deadline, 2)
                    argv = ['/usr/bin/git', '--git-dir', str(self.work / 'control.git'), 'cat-file', '-p', SMOKE.CONTROL_COMMIT]
                else:
                    argv = gate.allowed[1]
                count = len(fixture.calls)
                with self.assertRaisesRegex(SMOKE.Refusal, '^COMMAND_OUTSIDE_TRANSPORT_SCOPE$'):
                    gate.capture('bounded-read-only-control', argv, records, deadline, 2)
                self.assertEqual(len(fixture.calls), count)

    def test_capture_input_bounds_and_record_identity(self):
        for label, seconds, delta, expired in (('other', 1, 0, False),
                                               ('bounded-read-only-control', 0, 0, False),
                                               ('bounded-read-only-control', 21, 0, False),
                                               ('bounded-read-only-control', 1, 1, False),
                                               ('bounded-read-only-control', 1, 0, True)):
            fixture = Fixture()
            deadline = time.monotonic() + (-1 if expired else 5)
            gate = SMOKE.CaptureGate(self.work, fixture, deadline)
            with self.assertRaisesRegex(SMOKE.Refusal, '^CAPTURE_BOUND_REFUSED$'):
                gate.capture(label, gate.allowed[0], [], deadline + delta, seconds)
            self.assertEqual(fixture.calls, [])
        fixture = Fixture()
        deadline = time.monotonic() + 5
        gate = SMOKE.CaptureGate(self.work, fixture, deadline)
        records = []
        gate.capture('bounded-read-only-control', gate.allowed[0], records, deadline, 2)
        with self.assertRaisesRegex(SMOKE.Refusal, '^CAPTURE_RECORDS_CHANGED$'):
            gate.capture('bounded-read-only-control', gate.allowed[1], list(records), deadline, 2)
        self.assertEqual(len(fixture.calls), 1)

    def test_production_record_and_stream_bounds_are_rechecked(self):
        for fixture in (Fixture(records_delta=0), Fixture(records_delta=2),
                        Fixture([(0, b'x' * 32769, b'')])):
            result = self.observe(fixture)
            self.assert_refused(result, 'CAPTURE_RECORDS_CHANGED')
            self.assertEqual(len(fixture.calls), 1)

    def test_forbidden_dangling_path_cannot_be_reported_absent(self):
        (self.work / 'CONTROL.json').symlink_to(self.work / 'SYNTHETIC_MISSING_TARGET')
        result = self.observe(Fixture())
        self.assert_refused(result, 'FORBIDDEN_OUTPUT_PRESENT')
        self.assertIs(result['forbidden_files_absent']['CONTROL.json'], False)

    def test_digest_and_symlink_rejection_precedes_code_execution(self):
        path = self.work / 'synthetic.py'
        path.write_text('raise AssertionError("MUST_NOT_EXECUTE")\n')
        with self.assertRaisesRegex(SMOKE.Refusal, '^SOURCE_DIGEST_REFUSED$'):
            SMOKE.load_pinned(path, '0' * 64)
        link = self.work / 'link.py'
        link.symlink_to(path)
        with self.assertRaisesRegex(SMOKE.Refusal, '^SOURCE_FILE_REFUSED$'):
            SMOKE.load_pinned(link, hashlib.sha256(path.read_bytes()).hexdigest())

    def test_main_rejects_invalid_context_before_dependency_load(self):
        original = {'RUNNER_TEMP': str(self.work), 'GITHUB_RUN_ID': '123', 'GITHUB_ACTIONS': 'true',
                    'RUNNER_ENVIRONMENT': 'github-hosted', 'GITHUB_REPOSITORY': SMOKE.REPOSITORY,
                    'GITHUB_EVENT_NAME': 'push', 'GITHUB_REF': 'refs/heads/' + SMOKE.BRANCH,
                    'GITHUB_RUN_ATTEMPT': '1', 'GITHUB_SHA': '1' * 40}
        for key, wrong in (('GITHUB_RUN_ATTEMPT', '2'), ('GITHUB_ACTIONS', 'false'),
                           ('RUNNER_ENVIRONMENT', 'self-hosted'), ('GITHUB_REPOSITORY', 'other/repo'),
                           ('GITHUB_EVENT_NAME', 'workflow_dispatch'), ('GITHUB_REF', 'refs/heads/main'),
                           ('GITHUB_SHA', 'INVALID')):
            env = {**original, key: wrong}
            output = self.work / 'g2-production-transport-smoke-123-1'
            with mock.patch.dict(os.environ, env, clear=True), \
                 mock.patch.object(sys, 'argv', ['smoke', '--output', str(output)]), \
                 mock.patch.object(SMOKE, 'load_pinned', side_effect=AssertionError('LOAD_REACHED')) as loader, \
                 contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(SMOKE.main(), 1)
            loader.assert_not_called()
            evidence = json.loads((output / 'RESULT.json').read_bytes())
            self.assert_refused(evidence, 'HOST_CONTEXT_REFUSED')
            (output / 'RESULT.json').unlink()
            output.rmdir()


class RealCaptureChecks(Isolated):
    @classmethod
    def setUpClass(cls):
        # This check process is a dedicated owner of only its own test children.
        libc = ctypes.CDLL(None, use_errno=True)
        actual = ctypes.c_int()
        if libc.prctl(36, 1, 0, 0, 0) != 0 or libc.prctl(37, ctypes.byref(actual), 0, 0, 0) != 0 or actual.value != 1:
            raise AssertionError('LOCAL_SUBREAPER_NOT_ESTABLISHED')

    def tearDown(self):
        # ECHILD is meaningful even where this executor omits the procfs census.
        with self.assertRaises(ChildProcessError):
            os.waitpid(-1, os.WNOHANG | 0x40000000)

    def test_gate_delegates_real_local_init_with_pidfd_and_echild(self):
        deadline = time.monotonic() + 5
        gate = SMOKE.CaptureGate(self.work, UTILITY, deadline)
        records = []
        code, out, err = gate.capture('bounded-read-only-control', gate.allowed[0], records, deadline, 2)
        self.assertEqual((code, out, err), (0, b'', b''))
        self.assertEqual(len(records), 1)
        row = records[0]
        self.assertTrue(row['pidfd_acquired'] and row['streams_complete'] and row['cleanup']['echild'])
        self.assertTrue((self.work / 'control.git' / 'HEAD').is_file())
        self.assertNotIn('argv', row)
        self.assertNotIn('environment', row)

    def test_real_capture_closed_environment_excludes_parent_secrets(self):
        records = []
        command = ['/usr/bin/python3', '-I', '-S', '-B', '-c', 'import json,os;print(json.dumps(dict(os.environ),sort_keys=True))']
        with mock.patch.dict(os.environ, {'SYNTHETIC_PRIVATE_SECRET': 'DO_NOT_PUBLISH', 'GIT_CONFIG_COUNT': '99'}):
            code, out, err = UTILITY.capture('local-closed-env-check', command, records, time.monotonic() + 5, seconds=2)
        self.assertEqual(code, 0)
        self.assertEqual(json.loads(out), UTILITY.safe_environment())
        self.assertNotIn('DO_NOT_PUBLISH', json.dumps(records))
        self.assertTrue(records[0]['cleanup']['echild'])

    @unittest.skipUnless(PROC_CENSUS_AVAILABLE, 'GAP: executor lacks production procfs child-census interface')
    def test_real_capture_adopted_orphan_is_killed_and_reaped(self):
        records = []
        code = ('import os,time\n'
                'pid=os.fork()\n'
                'if pid==0:\n'
                ' for fd in (0,1,2): os.close(fd)\n'
                ' time.sleep(30)\n'
                ' os._exit(0)\n'
                'os.write(1,b"LOCAL_ONLY\\n")\n'
                'os._exit(0)\n')
        rc, out, err = UTILITY.capture('local-adoption-check', ['/usr/bin/python3', '-I', '-S', '-B', '-c', code],
                                       records, time.monotonic() + 5, seconds=2)
        self.assertEqual((rc, out, err), (0, b'LOCAL_ONLY\n', b''))
        self.assertTrue(records[0]['pidfd_acquired'] and records[0]['streams_complete'])
        cleanup = records[0]['cleanup']
        self.assertTrue(cleanup['echild'])
        self.assertGreaterEqual(cleanup['pidfd_signals'], 1)
        self.assertTrue(any(row['returncode'] == -signal.SIGKILL for row in cleanup['reaped_statuses']))

    @unittest.skipUnless(PROC_CENSUS_AVAILABLE, 'GAP: executor lacks production procfs child-census interface')
    def test_real_capture_timeout_refuses_and_reaps(self):
        records = []
        with self.assertRaisesRegex(UTILITY.Refusal, '^CAPTURE_BOUND_REFUSED$'):
            UTILITY.capture('local-timeout-check', ['/usr/bin/python3', '-I', '-S', '-B', '-c', 'import time;time.sleep(30)'],
                            records, time.monotonic() + 5, seconds=0.05)
        self.assertTrue(records[0]['timeout'] and records[0]['cleanup']['echild'])
        self.assertFalse(records[0]['streams_complete'])


def run_author_suite():
    # The author test module's temporary directory is moved only in memory so
    # candidate bytes and directory contents remain unchanged during the review.
    author = load(CANDIDATE / 'local_tests/test_transport_smoke.py', 'author_checks')
    author.ROOT = REVIEW
    suite = unittest.defaultTestLoader.loadTestsFromModule(author)
    with (REVIEW / 'author_suite.log').open('w') as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    return {'tests_run': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
            'success': result.wasSuccessful(), 'adaptation': 'Temporary directory root relocated in memory; candidate untouched.'}


if __name__ == '__main__':
    summary = {'scope': 'LOCAL_INDEPENDENT_ORDINARY_ENGINEERING_REVIEW', 'authority': 'NONE',
               'network_operations': 0, 'hosted_operations': 0, 'candidate_mutations': 0,
               'pins': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in PINS},
               'author_suite': run_author_suite()}
    suite = unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    with (REVIEW / 'independent_suite.log').open('w') as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    summary['independent_suite'] = {'tests_run': result.testsRun, 'failures': len(result.failures),
                                    'errors': len(result.errors), 'success': result.wasSuccessful(),
                                    'skipped': [{'test': str(test), 'reason': reason} for test, reason in result.skipped]}
    summary['local_cleanup_gap'] = not PROC_CENSUS_AVAILABLE
    summary['initial_experiment_preserved'] = ['initial_independent_suite.log', 'initial_behavior_results.json',
                                              'checks/initial_independent_checks.py', 'proc_census_observation.json']
    (REVIEW / 'behavior_results.json').write_text(json.dumps(summary, sort_keys=True, indent=2) + '\n')
    print(json.dumps(summary, sort_keys=True, indent=2))
    raise SystemExit(0 if result.wasSuccessful() and summary['author_suite']['success'] else 1)
