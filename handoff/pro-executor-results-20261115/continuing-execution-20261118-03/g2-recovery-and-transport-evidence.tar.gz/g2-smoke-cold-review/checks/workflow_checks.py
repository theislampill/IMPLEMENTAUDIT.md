#!/usr/bin/env python3
"""Offline workflow checks and synthetic evidence-step execution only."""
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
from unittest import mock

import yaml

ROOT = Path('/workspace/scratch/2678f1e431c3')
REVIEW = ROOT / 'g2-smoke-cold-review'
REPO = ROOT / 'g2-repair-repo'
CANDIDATE = ROOT / 'g2-hosted-smoke-candidate'
WORKFLOW = CANDIDATE / '.github/workflows/g2-production-transport-smoke.yml'
BASE = '9a349423b6ca3dda18115a07ed41b63970bc8b77'
BRANCH = 'engineering/g2-production-transport-smoke-20261118-01'
SMOKE_SHA = 'baa97ec17871541cafdbf7a0f118d45c3704bf5a9389cc4c86c508dea192471b'
PINS = {'actions/checkout': '11d5960a326750d5838078e36cf38b85af677262',
        'actions/upload-artifact': 'ea165f8d65b6e75b540449e92b4886f43607fa02'}
results = []


def checked(name, condition, detail=None):
    assert condition, name
    results.append({'check': name, 'status': 'PASS', 'detail': detail})


def git(*args):
    return subprocess.run(['/usr/bin/git', '-C', str(REPO), *args], check=True,
                          capture_output=True, timeout=5).stdout


raw = WORKFLOW.read_bytes()
workflow = yaml.load(raw, Loader=yaml.BaseLoader)
checked('exact_workflow_hash', hashlib.sha256(raw).hexdigest() == '7beac6d601cff224540f64b71c72d722cd3ff73e4765fedcec24c85d6966de23')
checked('only_scoped_push_trigger', set(workflow['on']) == {'push'} and workflow['on']['push']['branches'] == [BRANCH])
checked('path_filters_closed', workflow['on']['push']['paths'] == [
    '.github/workflows/g2-production-transport-smoke.yml',
    'qualification/dg16-r5-full-g2/transport_smoke.py',
    'qualification/dg16-r5-full-g2/live_control.py'])
checked('read_only_permissions', workflow['permissions'] == {'contents': 'read'})
checked('no_cancellation_of_other_jobs', workflow['concurrency'] == {'group': 'g2-production-transport-smoke-20261118-01', 'cancel-in-progress': 'false'})
checked('only_transport_job', set(workflow['jobs']) == {'transport-only'})
job = workflow['jobs']['transport-only']
expected_guards = ["github.repository == 'theislampill/IMPLEMENTAUDIT.md'",
                   "github.event_name == 'push'", "github.ref == 'refs/heads/" + BRANCH + "'",
                   'github.event.created == true', 'github.event.deleted == false', 'github.event.forced == false',
                   "github.event.before == '" + '0' * 40 + "'", "github.run_attempt == '1'"]
actual_guards = [x.strip() for x in job['if'].split('&&')]
checked('exact_creation_attempt1_guard', actual_guards == expected_guards)
checked('hosted_runner_and_five_minute_limit', job['runs-on'] == 'ubuntu-26.04' and job['timeout-minutes'] == '5')
steps = job['steps']
checked('exact_four_step_population', len(steps) == 4 and [x.get('id') for x in steps] == ['checkout', 'smoke', 'evidence', None])
actions = dict(x['uses'].split('@') for x in steps if 'uses' in x)
checked('both_actions_fully_pinned_to_existing_base', actions == PINS)
base_full = git('show', BASE + ':.github/workflows/dg16-r5-full-g2.yml').decode()
checked('pins_equal_base_workflow_actions', all(name + '@' + pin in base_full for name, pin in PINS.items()))
checked('checkout_exact_sha_no_persisted_credentials', steps[0]['with'] == {
    'ref': '${{ github.sha }}', 'path': 'packet', 'fetch-depth': '2', 'persist-credentials': 'false',
    'set-safe-directory': 'false', 'submodules': 'false', 'lfs': 'false'})
smoke = steps[1]
checked('four_minute_outer_smoke_limit', smoke['timeout-minutes'] == '4')
expected_parent_line = '[[ "$(/usr/bin/git -C "$GITHUB_WORKSPACE/packet" rev-list --parents -n 1 HEAD)" == "$GITHUB_SHA ' + BASE + '" ]] || exit 1'
checked('sole_source_parent_guard', expected_parent_line in smoke['run'])
checked('smoke_digest_and_isolated_python_guard', "[[ \"$actual\" == '" + SMOKE_SHA + "' ]] || exit 1" in smoke['run'] and '/usr/bin/python3 -I -S -B "$smoke"' in smoke['run'])
checked('no_dynamic_secret_expression_or_package_install', not re.search(r'secrets\.|sudo|apt-get|pip install|workflow_dispatch|repository_dispatch|pull_request_target', raw.decode()))
for index, step in enumerate(steps):
    if 'run' in step:
        process = subprocess.run(['/bin/bash', '-n'], input=step['run'].encode(), capture_output=True, timeout=5)
        checked('shell_syntax_step_' + str(index), process.returncode == 0)
checked('failure_evidence_always_runs', steps[2]['if'] == 'always()')
checked('upload_requires_evidence_success', steps[3]['if'] == "always() && steps.evidence.outcome == 'success' && steps.evidence.outputs.eligible == 'true'")
checked('artifact_contains_only_result', steps[3]['with']['path'] == '${{ runner.temp }}/g2-production-transport-smoke-${{ github.run_id }}-1/RESULT.json'
        and steps[3]['with']['include-hidden-files'] == 'false'
        and steps[3]['with']['if-no-files-found'] == 'error'
        and steps[3]['with']['retention-days'] == '7')

existing = git('ls-tree', '-r', '--name-only', BASE, '.github/workflows').decode().splitlines()
checked('base_workflow_population_exact', existing == ['.github/workflows/dg16-r5-full-g2.yml', '.github/workflows/pages.yml', '.github/workflows/validate.yml'])
trigger_review = []
for path in existing:
    content = git('show', BASE + ':' + path)
    value = yaml.load(content, Loader=yaml.BaseLoader)
    branches = value['on']['push']['branches']
    checked('push_noninterference_' + Path(path).stem, BRANCH not in branches and not any('*' in b or '?' in b or '[' in b for b in branches))
    trigger_review.append({'path': path, 'sha256': hashlib.sha256(content).hexdigest(),
                           'push_branches': branches, 'other_events': [x for x in value['on'] if x != 'push']})

code = steps[2]['run'].split("<<'PY'\n", 1)[1].rsplit('\nPY\n', 1)[0]
compile(code, '<exact-workflow-evidence-step>', 'exec')
for mode in ('missing', 'existing-refusal', 'existing-success', 'reject-true-award'):
    with tempfile.TemporaryDirectory(prefix='workflow-', dir=REVIEW) as temporary:
        output = Path(temporary) / 'g2-production-transport-smoke-123-1'
        if mode != 'missing':
            output.mkdir()
            result = {'schema': 'dg16.production-transport-smoke.v1', 'scope': 'TRANSPORT_SMOKE_NON_ACCEPTANCE',
                      'status': 'REFUSED', 'code': 'SYNTHETIC_LOCAL_FIXTURE', 'fetch_completed': False, 'commands': [],
                      **dict.fromkeys(('original_acceptance_awarded', 'full_G2_awarded', 'G132_awarded',
                                       'full_pair_executed', 'control_replayed', 'original_consumption',
                                       'branch_written', 'automatic_retry'), False)}
            if mode == 'existing-success':
                result.update(status='TRANSPORT_OBSERVED', fetch_completed=True, source_hashes_verified=True,
                              subreaper_enabled_and_read_back=True, attempted_operations=['init', 'ls-remote', 'fetch'],
                              commands=[{'LOCAL_FIXTURE': True}] * 3,
                              forbidden_files_absent={'CONSUMPTION_RESERVED.json': True, 'CONTROL.json': True,
                                                      'INDEPENDENT_REVIEW.json': True, 'ROOT_CONSUMPTION.json': True})
            if mode == 'reject-true-award':
                result['full_G2_awarded'] = True
            (output / 'RESULT.json').write_text(json.dumps(result) + '\n')
        env = {'RUNNER_TEMP': temporary, 'GITHUB_RUN_ID': '123', 'CHECKOUT_OUTCOME': 'failure', 'SMOKE_OUTCOME': 'skipped'}
        printed = io.StringIO()
        rejected = False
        with mock.patch.dict(os.environ, env, clear=True), contextlib.redirect_stdout(printed):
            try:
                exec(compile(code, '<exact-workflow-evidence-step>', 'exec'), {})
            except AssertionError:
                rejected = True
        if mode == 'reject-true-award':
            checked('evidence_rejects_award_' + mode, rejected and printed.getvalue() == '')
        else:
            checked('evidence_accepts_' + mode, not rejected and printed.getvalue().startswith('DG16_TRANSPORT_SMOKE_FINAL '))
            result = json.loads((output / 'RESULT.json').read_bytes())
            if mode == 'missing':
                checked('fallback_is_refusal_without_capture', result['status'] == 'REFUSED' and result['commands'] == []
                        and result['code'] == 'SMOKE_RESULT_UNAVAILABLE' and result['fetch_completed'] is False
                        and result['checkout_outcome'] == 'failure' and result['smoke_outcome'] == 'skipped')

report = {'scope': 'OFFLINE_WORKFLOW_AND_SYNTHETIC_EVIDENCE_REVIEW', 'authority': 'NONE', 'status': 'PASS',
          'checks_passed': len(results), 'checks': results, 'base_workflows': trigger_review,
          'limitations': ['No action commit availability, hosted runner behavior, event delivery, TLS, or remote fetch was observed.',
                          'Noninterference assumes integration preserves all three base workflow files and creates no PR.',
                          'One branch creation remains an integration obligation; these guards do not prevent later deletion and recreation.']}
(REVIEW / 'workflow_results.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(report, sort_keys=True, indent=2))
