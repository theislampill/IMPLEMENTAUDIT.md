#!/usr/bin/env python3
"""Offline verification of independently reacquired provider evidence only."""
from pathlib import Path
import base64
import datetime
import hashlib
import json
import re
import zipfile

HERE = Path(__file__).resolve().parent
PROVIDER = HERE / 'provider'
FROZEN = HERE.parent
ROOT_PACKET = Path('/workspace/scratch/2678f1e431c3/g2-smoke-publication/hosted')
REPO = 'theislampill/IMPLEMENTAUDIT.md'
COMMIT = '3fcf7146ec2ff086323d20170f995137ca4be9eb'
PARENT = '9a349423b6ca3dda18115a07ed41b63970bc8b77'
TREE = 'fd5a2c73cf08f207b27ed2e139708461b57938b9'
BRANCH = 'engineering/g2-production-transport-smoke-20261118-01'
RUN, JOB, ARTIFACT = 44267730042, 134676323610, 14410149163
ZIP_SHA = 'a2def234f35eb93821e541432d234c364df6c50618a975d40775b24c2887a47e'
RESULT_SHA = 'e954aa82bc50f58de306424846f16693051e38e8fe66fe56d2eef26840966f00'
PREFIX = 'qualification/dg16-r5-full-g2/'
PINS = {
    PREFIX+'transport_smoke.py': 'baa97ec17871541cafdbf7a0f118d45c3704bf5a9389cc4c86c508dea192471b',
    '.github/workflows/g2-production-transport-smoke.yml': '7beac6d601cff224540f64b71c72d722cd3ff73e4765fedcec24c85d6966de23',
    PREFIX+'live_control.py': 'cd8262defc85c2541632fe00e51bc78c804b13a3a8a4501e39300b4269f866ff',
    PREFIX+'host_utility.py': '02a15dc96ecce23e14a3a84bca880aa536d79fffc4f6d6160835cb4ba97a19b5',
    PREFIX+'test_live_control_transport.py': '963b21c7527e3d163c327dc42c9af35b2f79ff3f5c15737703dac35cb4980e2f'}
checks = []

def sha(raw): return hashlib.sha256(raw).hexdigest()
def need(test, name):
    assert test, name
    checks.append({'check': name, 'status': 'PASS'})
def read(name): return json.loads((PROVIDER/name).read_bytes())
def pairs(items):
    answer = {}
    for key, value in items:
        assert key not in answer, 'DUPLICATE_JSON_KEY'
        answer[key] = value
    return answer
def canonical(value): return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True, allow_nan=False)+'\n').encode('ascii')

run, jobs, artifacts, ref, commit = [read(n+'.json') for n in ('run','jobs','artifacts','ref','commit')]
need(run['id']==RUN and run['run_attempt']==1 and run['run_number']==1, 'actual_run_attempt1')
need(run['head_sha']==COMMIT and run['head_branch']==BRANCH and run['event']=='push', 'run_exact_source_and_push_branch')
need(run['repository']['full_name']==REPO and run['path']=='.github/workflows/g2-production-transport-smoke.yml', 'run_exact_repository_workflow')
need(run['status']=='completed' and run['conclusion']=='success' and run['previous_attempt_url'] is None, 'run_success_no_previous_attempt')
need(run['pull_requests']==[], 'run_not_a_pull_request')
need(ref['ref']=='refs/heads/'+BRANCH and ref['object']['sha']==COMMIT and ref['object']['type']=='commit', 'current_remote_ref_exact_commit')
collection = read('run_collection.json')
need(collection['total_count']==1 and [x['id'] for x in collection['workflow_runs']]==[RUN], 'only_one_provider_workflow_run_for_integration_commit')
need(len(jobs['jobs'])==1 and jobs['jobs'][0]['id']==JOB, 'sole_transport_job')
job = jobs['jobs'][0]
need(job['name']=='transport-only' and job['run_id']==RUN and job['status']=='completed' and job['conclusion']=='success', 'job_success_binding')
need(all(x['status']=='completed' and x['conclusion']=='success' for x in job['steps']), 'every_reported_job_step_success')
need([x['name'] for x in job['steps']]==['Set up job','Check out only the prospective smoke packet',
    'Observe production HTTPS discovery and fetch only','Retain bounded evidence even when an earlier step failed',
    'Upload only the bounded non-acceptance result','Post Check out only the prospective smoke packet','Complete job'], 'job_step_population_matches_reviewed_workflow')
need(commit['sha']==COMMIT and [x['sha'] for x in commit['parents']]==[PARENT] and commit['commit']['tree']['sha']==TREE, 'commit_sole_parent_and_tree')
expected_delta={'.github/workflows/g2-production-transport-smoke.yml':'added',PREFIX+'transport_smoke.py':'added',
                PREFIX+'live_control.py':'modified',PREFIX+'test_live_control_transport.py':'added'}
need({x['filename']:x['status'] for x in commit['files']}==expected_delta and len(commit['files'])==4, 'exact_four_file_delta_existing_workflows_and_acceptance_pins_unchanged')
files=read('files.json')
for path,pin in PINS.items():
    data=files[path]
    need(data['encoding']=='base64', 'provider_file_encoding_'+path)
    raw=base64.b64decode(data['content'])
    need(sha(raw)==pin, 'remote_exact_sha256_'+path)
    blob_sha=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    need(blob_sha==data['sha'], 'remote_git_blob_integrity_'+path)
    if path in expected_delta:
        need(next(x['sha'] for x in commit['files'] if x['filename']==path)==blob_sha, 'commit_delta_blob_binding_'+path)

need(len(artifacts['artifacts'])==1, 'sole_artifact')
artifact=artifacts['artifacts'][0]
need(artifact['id']==ARTIFACT and artifact['name']=='g2-production-transport-smoke-44267730042-1', 'artifact_identity')
need(artifact['digest']=='sha256:'+ZIP_SHA and artifact['size_in_bytes']==1470 and artifact['expired'] is False, 'provider_artifact_digest_size_not_expired')
need(artifact['workflow_run']['id']==RUN and artifact['workflow_run']['head_sha']==COMMIT and artifact['workflow_run']['head_branch']==BRANCH, 'artifact_run_commit_binding')
raw_zip=(PROVIDER/'artifact.zip').read_bytes()
need(len(raw_zip)==1470 and sha(raw_zip)==ZIP_SHA, 'independently_downloaded_zip_digest')
with zipfile.ZipFile(PROVIDER/'artifact.zip') as z:
    need(z.namelist()==['RESULT.json'] and z.testzip() is None, 'zip_exact_one_member_and_crc')
    raw=z.read('RESULT.json')
need(len(raw)==4248 and sha(raw)==RESULT_SHA, 'artifact_result_digest_and_size')
need(raw==(PROVIDER/'RESULT.json').read_bytes()==(ROOT_PACKET/'RESULT.json').read_bytes(), 'independent_extraction_equals_root_result_bytes')
result=json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _: (_ for _ in ()).throw(ValueError('NONFINITE')))
need(result['schema']=='dg16.production-transport-smoke.v1' and result['scope']=='TRANSPORT_SMOKE_NON_ACCEPTANCE', 'result_schema_scope')
need(result['status']=='TRANSPORT_OBSERVED' and result['code']=='FETCH_COMPLETED_STOPPED_BEFORE_PARENT' and result['fetch_completed'] is True, 'result_transport_success_stop_boundary')
need(result['run_id']==str(RUN) and type(result['run_attempt']) is int and result['run_attempt']==1 and result['workflow_commit']==COMMIT, 'result_run_commit_binding')
need(result['repository']==REPO and result['control_branch']=='pro/dg16-g2-reviewed-control-20261118-01' and result['expected_control_commit']=='0fc8b8a0343925e72b24f4f98daad8ba988bd045', 'result_fixed_remote_control_commit')
need(result['source_parent_expected']==PARENT and result['source_hashes_verified'] is True and result['smoke_sha256']==PINS[PREFIX+'transport_smoke.py'], 'result_source_verification')
need(result['expected_source_sha256']=={name:PINS[PREFIX+name] for name in ('host_utility.py','live_control.py')}, 'result_dependency_pins')
need(result['operation_limit_seconds']==180 and result['subreaper_enabled_and_read_back'] is True, 'bound_and_subreaper_readback')
need(result['attempted_operations']==['init','ls-remote','fetch'] and len(result['commands'])==3, 'exact_three_operations')
for name in ('original_acceptance_awarded','full_G2_awarded','G132_awarded','full_pair_executed','control_replayed','original_consumption','branch_written','automatic_retry'):
    need(result[name] is False, 'no_award_replay_or_consumption_'+name)
need(result['forbidden_files_absent']==dict.fromkeys(('CONSUMPTION_RESERVED.json','CONTROL.json','INDEPENDENT_REVIEW.json','ROOT_CONSUMPTION.json'),True), 'all_forbidden_control_outputs_absent')
discovery=(result['expected_control_commit']+'\trefs/heads/'+result['control_branch']+'\n').encode()
for index,record in enumerate(result['commands']):
    label=result['attempted_operations'][index]
    need(record['name']=='bounded-read-only-control' and record['process_started'] is True and type(record['returncode']) is int and record['returncode']==0, label+'_actual_zero_exit')
    need(record['pidfd_acquired'] is True and record['internal_failure'] is None and record['streams_complete'] is True and record['timeout'] is False and record['output_bound_exceeded'] is False, label+'_pidfd_complete_bounded')
    need(record['stream_digest_scope']=='CAPTURED_BYTES_ONLY' and record['reason_code']=='EXIT_ZERO_NO_STDERR' and record['stderr_bytes']==0 and record['stderr_sha256']==sha(b''), label+'_empty_stderr_digest')
    stdout=discovery if index==1 else b''
    need(record['stdout_bytes']==len(stdout) and record['stdout_sha256']==sha(stdout), label+'_exact_expected_stdout_digest')
    cleanup=record['cleanup']
    need(cleanup['echild'] is True and cleanup['pidfd_signals']==0 and cleanup['reaped_statuses_truncated'] is False, label+'_echild_cleanup')
    rows=cleanup['reaped_statuses']
    need(cleanup['retained_status_count']==len(rows) and cleanup['retained_statuses_sha256']==sha(canonical(rows)), label+'_retained_cleanup_digest')
    need(len(rows)==(1 if index==2 else 0), label+'_retained_child_count')
    if index==2:
        need(rows==[{'pid':2510,'returncode':0}], 'fetch_additional_child_reaped_exit_zero')

log=(PROVIDER/'log.log').read_text()
for prefix in ('DG16_TRANSPORT_SMOKE ', 'DG16_TRANSPORT_SMOKE_FINAL '):
    rows=[line.split('Z ',1)[1][len(prefix):] for line in log.splitlines() if 'Z '+prefix in line and line.split('Z ',1)[1].startswith(prefix)]
    need(len(rows)==1 and json.loads(rows[0])==result, 'artifact_equals_actual_log_record_'+prefix.strip())
need('Image: ubuntu-26.04' in log and 'Contents: read' in log, 'logged_host_image_and_read_permission')
need('SHA256 digest of uploaded artifact zip is '+ZIP_SHA in log and 'Artifact ID '+str(ARTIFACT) in log, 'log_upload_digest_artifact_binding')
need('##[error]' not in log, 'no_job_error_marker')
elapsed=(datetime.datetime.fromisoformat(run['updated_at'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(run['run_started_at'].replace('Z','+00:00'))).total_seconds()
need(0<=elapsed<180, 'entire_run_metadata_interval_below_script_bound')
for relative,entry in json.loads((FROZEN/'EVIDENCE_MANIFEST.json').read_bytes()).items():
    need(sha((FROZEN/relative).read_bytes())==entry['sha256'], 'previous_source_review_unchanged_'+relative)

report={'schema':'independent-hosted-transport-receiving-checks.v1','reviewer':'/root/g2_smoke_cold_review','authority':'NONE',
        'decision':'PASS_TRANSPORT_ONLY','checks_passed':len(checks),'checks':checks,
        'run_id':RUN,'run_attempt':1,'job_id':JOB,'artifact_id':ARTIFACT,
        'commit':COMMIT,'tree':TREE,'sole_parent':PARENT,'run_metadata_interval_seconds':elapsed,
        'zip_sha256':ZIP_SHA,'result_sha256':RESULT_SHA,'exact_source_sha256':PINS,
        'discovery_bytes':len(discovery),'discovery_sha256':sha(discovery),
        'cleanup_reaped_counts':[len(x['cleanup']['reaped_statuses']) for x in result['commands']],
        'limitation':'This establishes only the completed fixed read-only transport and cleanup observation. No parent/payload validation, post-fetch currentness, full pair, replay, original acceptance, full G2, or G132 is awarded.',
        'original_acceptance_awarded':False,'full_G2_awarded':False,'G132_awarded':False,'control_replayed':False}
(HERE/'checks.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('decision','checks_passed','run_id','job_id','artifact_id','run_metadata_interval_seconds','discovery_bytes','discovery_sha256','cleanup_reaped_counts')},sort_keys=True,indent=2))
