#!/usr/bin/env python3
"""Read-only receiving of preserved terminal evidence; never executes hold or product."""
import ast
import datetime
import hashlib
import json
from pathlib import Path
import re
import stat
import time
import zipfile

ROOT = Path('/workspace/scratch/2678f1e431c3/g2-live')
OUT = ROOT / 'terminal/independent'
NAMES = {'RESULT.json','HOST.json','SOURCE.json','PROBE.json','CLEANUP.json','FAILURE.json','ARTIFACT_MANIFEST.json'}
WORKFLOW = '9a349423b6ca3dda18115a07ed41b63970bc8b77'
CONTROL = '0fc8b8a0343925e72b24f4f98daad8ba988bd045'
SOURCE = 'e91df00685c55c193d288ccdb0f8ffe1e16a9957'
TREE = 'df8008fd3d25b1d32f75ec80fa45da22e3fc68ca'
CHECKS = []

def sha(raw): return hashlib.sha256(raw).hexdigest()
def desc(raw): return {'bytes':len(raw),'sha256':sha(raw)}
def gitblob(raw): return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def canonical(v): return (json.dumps(v,sort_keys=True,indent=2,ensure_ascii=True,allow_nan=False)+'\n').encode('ascii')
def check(name, condition):
    CHECKS.append({'check':name,'verified':bool(condition)})
    if not condition: raise AssertionError(name)
def pairs(items):
    result={}
    for k,v in items:
        if k in result: raise ValueError('DUPLICATE_JSON_KEY')
        result[k]=v
    return result
def parse(raw):
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda x: (_ for _ in ()).throw(ValueError('NONFINITE_JSON')))
def pure_symbols(path, sha256, symbols, constants=()):
    raw=path.read_bytes()
    check('exact source digest '+path.name,sha(raw)==sha256)
    module=ast.parse(raw)
    selected=[]
    for node in module.body:
        if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name in symbols:
            selected.append(node)
        elif isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in constants for t in node.targets):
            ast.literal_eval(node.value)
            selected.append(node)
    ns={'json':json,'hashlib':hashlib,'re':re}
    exec(compile(ast.Module(body=selected,type_ignores=[]),str(path),'exec'),ns)
    check('pure symbols present '+path.name,all(x in ns for x in symbols+tuple(constants)))
    return ns

origins=parse((OUT/'PROVIDER_ORIGINS.json').read_bytes())
run=origins['run']
check('provider run identity',run['id']==44239735578 and run['run_attempt']==1 and run['head_sha']==WORKFLOW and run['head_branch']=='pro/dg16-g2-reviewed-20261118-01')
check('provider terminal failure',run['status']=='completed' and run['conclusion']=='failure')
jobs=origins['attempt_jobs']['jobs']
check('exact sole job',len(jobs)==1 and jobs[0]['id']==134584393061 and jobs[0]['run_id']==44239735578 and jobs[0]['run_attempt']==1 and jobs[0]['head_sha']==WORKFLOW)
job=jobs[0]
steps={x['number']:x for x in job['steps']}
check('provider exact terminal step results',all(steps[n]['conclusion']=='success' for n in (16,17,18,19,20,23,24)) and all(steps[n]['conclusion']=='failure' for n in (21,22)))
artifacts=origins['artifacts']['artifacts']
artifact=next(x for x in artifacts if x['id']==14408238863)
preview_artifact=next(x for x in artifacts if x['id']==14404939820)
check('terminal artifact provider origin',artifact['name']=='dg16-full-registry-44239735578-1' and artifact['workflow_run']['id']==44239735578 and artifact['workflow_run']['head_sha']==WORKFLOW and not artifact['expired'])
zip_raw=(ROOT/'terminal/terminal.zip').read_bytes()
check('terminal archive exact provider descriptor',len(zip_raw)==artifact['size_in_bytes']==15875 and 'sha256:'+sha(zip_raw)==artifact['digest']=='sha256:cd7d50f07d9b7b550fefc31b9bffee31f4a36ae8c9c4f3a19a38c39cf43763ff')
preview_raw=(ROOT/'review.zip').read_bytes()
check('preview archive exact provider descriptor',preview_artifact['workflow_run']['id']==44239735578 and preview_artifact['workflow_run']['head_sha']==WORKFLOW and len(preview_raw)==preview_artifact['size_in_bytes']==18151 and 'sha256:'+sha(preview_raw)==preview_artifact['digest'])
check('selected source tree is immutable',bool(origins['selected_source_blobs']))
source_descriptors={}
for item in origins['selected_source_blobs']:
    name=Path(item['path']).name
    raw=(ROOT/'source'/name).read_bytes()
    check('selected Git blob '+name,gitblob(raw)==item['sha'] and len(raw)==item['size'] and item['mode']=='100644')
    source_descriptors[name]={**desc(raw),'git_blob':item['sha'],'repository_path':item['path']}
codec=pure_symbols(ROOT/'source/host_utility.py','02a15dc96ecce23e14a3a84bca880aa536d79fffc4f6d6160835cb4ba97a19b5',('public_codec',))['public_codec']
wire={}
member_metadata={}
with zipfile.ZipFile(ROOT/'terminal/terminal.zip') as archive:
    infos=archive.infolist()
    check('terminal ZIP exact unique safe population',len(infos)==7 and {i.filename for i in infos}==NAMES)
    check('terminal ZIP ordinary unencrypted files',all(not i.is_dir() and not i.flag_bits&1 and stat.S_IFMT(i.external_attr>>16)==stat.S_IFREG for i in infos))
    check('terminal ZIP CRC',archive.testzip() is None)
    for item in infos:
        raw=archive.read(item.filename)
        check('terminal extracted bytes '+item.filename,raw==(ROOT/'terminal/packet'/item.filename).read_bytes() and len(raw)==item.file_size)
        wire[item.filename]=raw
        member_metadata[item.filename]={**desc(raw),'crc32':format(item.CRC,'08x'),'zip_mode':oct(item.external_attr>>16),'compressed_bytes':item.compress_size}
docs={}
for name,raw in wire.items():
    value=codec(name,raw,True)
    check('exact codec roundtrip '+name,codec(name,value)==raw)
    check('independent decode matches supplied copy '+name,value==parse((ROOT/'terminal/decoded'/name).read_bytes()))
    docs[name]=value
manifest=docs['ARTIFACT_MANIFEST.json']
check('manifest exact six descriptor population',manifest['schema']=='dg16.linux-host-artifacts.v1' and len(manifest['members'])==6 and {r['name'] for r in manifest['members']}==NAMES-{'ARTIFACT_MANIFEST.json'})
for row in manifest['members']:
    check('manifest descriptor '+row['name'],row=={'name':row['name'],**desc(wire[row['name']])})
preview_wire={}
with zipfile.ZipFile(ROOT/'review.zip') as archive:
    infos=archive.infolist()
    expected={'REQUEST.json','PROOF.json',*('public/'+name for name in NAMES)}
    check('preview ZIP exact nine unique members',len(infos)==9 and {i.filename for i in infos}==expected and archive.testzip() is None)
    for item in infos:
        raw=archive.read(item.filename)
        check('preview retained member '+item.filename,raw==(ROOT/'packet'/item.filename).read_bytes())
        preview_wire[item.filename]=raw
preview_docs={name:codec(name,preview_wire['public/'+name],True) for name in NAMES}
request_raw=preview_wire['REQUEST.json']
proof_raw=preview_wire['PROOF.json']
request=parse(request_raw)
proof=parse(proof_raw)
check('request/proof exact identities',sha(request_raw)=='2be276e22405eefb1e307d5acc3dbfe59ea205efe4688d552a5c2e2d61641a74' and desc(proof_raw)==request['proof']=={'bytes':4131,'sha256':'4804335ed79ef819086fe2d71715d4a1395e4b096bf93c2c6db97c317cdacf8d'})
check('request exact episode',request['run_id']=='44239735578' and request['run_attempt']==1 and request['workflow_commit']==WORKFLOW and request['source_commit']==SOURCE and request['source_tree']==TREE and request['hold_seconds']==3600 and request['expires_utc_epoch']==1794988782)
probe=docs['PROBE.json']
result=docs['RESULT.json']
cleanup=docs['CLEANUP.json']
failure=docs['FAILURE.json']
source=docs['SOURCE.json']
check('terminal retained exact proof',probe['result']['full_correspondence']==proof==preview_docs['PROBE.json']['result']['full_correspondence'] and canonical(proof)==proof_raw)
full=pure_symbols(ROOT/'source/full_relation.py','9e079d7656c513fe32dcf21088cf14405eba599a7d184831566d56d6595e557e',('Refusal','demand','sha','encode','validate_stderr_location','validate_public_proof'),('SCOPES','REGISTRY_SHA','COMMAND_SHA','REPORT_PROFILE_SHA'))
full['validate_public_proof'](proof,policy_sha=request['policy_sha256'],inputs_sha=request['receiver_inputs_sha256'],source_commit=SOURCE,source_tree=TREE)
check('selected original public proof validator',True)
check('five relations and both normalized streams equal',proof['all_declared_relations_equal'] and all(x['equal'] and x['difference_count']==0 and x['witnesses']==[] and x['witnesses_complete'] for x in [*proof['relations'].values(),*proof['normalized_streams'].values()]))
check('terminal evidence preclosing result unchanged',probe['result']==preview_docs['PROBE.json']['result'])
check('same receiving result digest',sha(canonical(probe['result']))==probe['receiving']['result_sha256'])
policy=parse((ROOT/'source/POLICY.json').read_bytes())
pg=pure_symbols(ROOT/'source/policy_control.py','ca2f7984da02f319ce2ab9ca58f180e62e1b4fd38786d2276322dd377d28c172',('Refusal','need','sha','parse','digest','independent','validate'),('CURRENT_AUTHORS','DECISION_FILES'))
bindings={'source_commit':SOURCE,'source_tree':TREE,'policy_sha256':request['policy_sha256'],'receiver_inputs_sha256':request['receiver_inputs_sha256'],'adapter_sha256':source_descriptors['run.py']['sha256'],'pair_driver_sha256':result['pair_driver_sha256']}
policy_payload={name:(ROOT/'source'/name).read_bytes() for name in pg['DECISION_FILES']}
policy_result=pg['validate'](policy_payload,bindings,policy)
check('actual policy gate unchanged',policy_result==probe['policy_adoption'] and policy_result['adoption_sha256']==request['policy_adoption_sha256'])
check('same terminal source identity and bookends',source['commit']==SOURCE and source['tree']==TREE and source['before']==source['after'] and source['before']['all_members_match'] and not source['tracked_source_mutations'])
records=probe['result']['records']
check('actual two successful ordered operations',probe['result']['subject_verifier_attempts']==2 and [x['mode'] for x in records]==['legacy','dag'] and all(x['exit']==0 and x['registration_complete'] for x in records))
check('DAG actual terminals',len(records[1]['nodes'])==119 and all(x['status']=='PASS' and x['terminal'] and x['ordinal']==i for i,x in enumerate(records[1]['nodes'])))
check('legacy trace not fabricated',records[0]['legacy_node_trace']=='UNAVAILABLE_WHOLE_PROCESS_ONLY' and all(x['status']=='UNSETTLED' and x['terminal'] is False for x in records[0]['nodes']))
check('original raw receiving retained',probe['receiving']['status']=='RECEIVED_COMPLETE_RAW_PAIR' and probe['receiving']['while_same_checkout_current'] and probe['result']['receiving_status']=='RECEIVED_COMPLETE_RAW_PAIR')
native=probe['native_prerequisite']
check('native current-host nine-case evidence retained',native['qualified_for_pair_at_receiving'] and native['receiving']['actual_case_count']==9 and native['result']['tests_run']==9 and len(native['result']['rows'])==9 and all(x['outcome']=='PASS' for x in native['result']['rows']))
check('reported actual terminal failure',result['status']=='UNQUALIFIED_OR_INCOMPLETE' and failure['present'] and [(x['operation'],x['code']) for x in failure['failures']]==[('hold','ACTUAL_REVIEW_WINDOW_EXPIRED'),('finalize','EPISODE_INCOMPLETE')])
check('hold absent from completed operation steps',result['completed_steps'][-1]=='prepare-review' and 'hold' not in result['completed_steps'])
live=probe['live_review']
check('terminal live-review remains unconsumed',live['status']=='ACTUAL_REVIEW_REQUIRED' and live['request_sha256']==sha(request_raw) and live['proof_sha256']==sha(proof_raw) and not any(k in live for k in ['control_commit','review','root_consumption','closing_readback','closing_currentness_sha256','verified_before_teardown']))
check('mandatory native post-review closing absent',native['closing_currentness_verified_before_teardown'] is False)
check('cleanup true but no receiving closing flag',cleanup['source_unchanged'] and cleanup['runtime_unchanged_after_initialization'] and cleanup['all_step_children_reaped'] and not probe['receiving'].get('verified_before_teardown',False))
check('original awards remain withheld',all(result[k] is False for k in ['original_acceptance','full_G2','G1','G3','C5','audit_closure']) and proof['original_acceptance'] is False and proof['full_G2'] is False)
check('control remote ref unchanged',origins['control_ref']['object']['sha']==CONTROL)
check('control sole workflow parent',origins['control_commit']['sha']==CONTROL and [x['sha'] for x in origins['control_commit']['parents']]==[WORKFLOW])
prefix='qualification/dg16-full-g2-control/44239735578-1/'
control_names={'CONTROL.json','INDEPENDENT_REVIEW.json','ROOT_CONSUMPTION.json'}
compare=origins['control_compare']
check('control exact three additions',compare['ahead_by']==1 and compare['behind_by']==0 and len(compare['files'])==3 and {x['filename'] for x in compare['files']}=={prefix+n for n in control_names} and all(x['status']=='added' and x['deletions']==0 for x in compare['files']))
entries=[x for x in origins['control_tree']['entries'] if x['type']=='blob']
check('control exact regular blob population',origins['control_tree']['truncated'] is False and len(entries)==3 and {x['path'] for x in entries}=={prefix+n for n in control_names} and all(x['mode']=='100644' for x in entries))
payload={}
control_descriptors={}
for x in entries:
    name=Path(x['path']).name
    raw=(ROOT/'control-bundle'/name).read_bytes()
    check('published exact control blob '+name,gitblob(raw)==x['sha'] and len(raw)==x['size'])
    payload[name]=raw
    control_descriptors[name]={**desc(raw),'git_blob':x['sha']}
check('actual authored review bytes preserved',payload['INDEPENDENT_REVIEW.json']==(ROOT/'independent/INDEPENDENT_REVIEW.json').read_bytes() and sha(payload['INDEPENDENT_REVIEW.json'])=='58970a2f210907e6207fbefdcc10e3a0a1775c45398ce4eabe77a015d4918b1d')
root_receipt=parse((ROOT/'ROOT_CONTROL_RECEIVING.json').read_bytes())
observed=datetime.datetime.fromisoformat(root_receipt['branch_readback_observed_utc'].replace('Z','+00:00')).timestamp()
check('contemporaneous Root publication receipt before expiry',root_receipt['commit']==CONTROL and observed<request['expires_utc_epoch'])
lc=pure_symbols(ROOT/'source/live_control.py','05918b2d5c2f791a92c52fd72cf795a870f24ddedc1c6867fbbf358218cb400a',('Refusal','need','sha','descriptor','parse','validate'),('REPOSITORY','CURRENT_AUTHORS','NAMES'))
historical_control_validation=lc['validate'](payload,request_raw,now=observed)
check('offline historical control schema verification only',historical_control_validation['decision']=='CONSUME')
expired_code=None
try: lc['validate'](payload,request_raw,now=time.time())
except lc['Refusal'] as exc: expired_code=str(exc)
check('actual current time cannot consume expired request',expired_code=='ACTUAL_REVIEW_WINDOW_EXPIRED')
check('frozen live review report preserved',sha((ROOT/'independent/REPORT.md').read_bytes())==root_receipt['independent_review_report_sha256']=='6d1f644f611c887e67fb3d21dfffdc93fb30c201ec8a7bc7caed0ae27e37a970')
addendum=parse((ROOT/'independent/ADDENDUM-20261118-LIVE-CONTROL-TRANSPORT.json').read_bytes())
check('reviewer downstream failure addendum preserved',addendum['frozen_review_sha256']==sha(payload['INDEPENDENT_REVIEW.json']) and addendum['original_proof_judgment_falsified'] is False and addendum['mandatory_closing_satisfied'] is False)
review_bytes=sum(len(x) for x in preview_wire.values())
terminal_bytes=sum(len(x) for x in wire.values())
semantic_bytes=sum(len((json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode()) for v in [*docs.values(),*preview_docs.values()])+len(request_raw)+len(proof_raw)
check('original cumulative public byte limits',all(len(x)<=65536 for x in wire.values()) and review_bytes+terminal_bytes<=262144 and semantic_bytes<=262144)
summary={
 'schema':'dg16.independent-terminal-receiving-checks.v1','reviewer':'/root/g2_delivery_checks','authority':'NONE',
 'scope':'ACTUAL_TERMINAL_PUBLIC_EVIDENCE_AND_ORIGINAL_M2_PREDICATES',
 'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'evidence_integrity':'VERIFIED','M2_disposition':'NOT_SATISFIED_FOR_THIS_EPISODE',
 'M2_awarded':False,'full_G2_awarded':False,'original_acceptance':False,'audit_closure':False,
 'run_id':44239735578,'run_attempt':1,'job_id':job['id'],'workflow_commit':WORKFLOW,
 'provider_terminal':{'status':run['status'],'conclusion':run['conclusion'],'run_updated_at':run['updated_at'],'job_completed_at':job['completed_at'],'steps':[{k:steps[n][k] for k in ('number','name','conclusion','completed_at')} for n in (16,17,18,19,20,21,22,23,24)]},
 'terminal_artifact':{'id':artifact['id'],'name':artifact['name'],**desc(zip_raw)},'review_artifact':{'id':preview_artifact['id'],**desc(preview_raw)},
 'source_commit':SOURCE,'source_tree':TREE,'source_descriptors':source_descriptors,'terminal_members':member_metadata,
 'public_payload_bytes':{'review':review_bytes,'terminal':terminal_bytes,'cumulative':review_bytes+terminal_bytes,'semantic_cumulative':semantic_bytes,'maximum':262144},
 'proof':desc(proof_raw),'request':desc(request_raw),'private_observations_descriptor_only':proof['private_observations'],
 'retained_comparison':{'five_declared_relations_equal':True,'normalized_streams_equal':True,'raw_observables_equal':probe['result']['raw_relation']['raw_observables_equal'],'raw_differing_predicates':[k for k,v in probe['result']['raw_relation']['checks'].items() if not v],'mapped_nodes':119,'registered_tests':91,'actual_report_slots':proof['actual_report_slots'],'static_selected_tests':proof['static_selected_tests'],'actual_report_skips':proof['actual_report_skips'],'method_execution_count_inferred':False,'route_exits':{x['mode']:x['exit'] for x in records},'route_elapsed_ms':{x['mode']:x['elapsed_ms'] for x in records}},
 'terminal_status':result['status'],'terminal_failures':failure['failures'],'completed_steps':result['completed_steps'],'live_review':live,
 'cleanup':cleanup,'source_bookends_equal':source['before']==source['after'],'native_qualified_at_receiving':native['qualified_for_pair_at_receiving'],'native_closing_currentness_verified_before_teardown':native['closing_currentness_verified_before_teardown'],
 'successful_hosted_reservation_established':False,'mandatory_postreview_closing_established':False,'hosted_private_git_stderr_observed':False,
 'control_publication':{'commit':CONTROL,'sole_parent':WORKFLOW,'tree':origins['control_commit']['tree']['sha'],'files':control_descriptors,'reported_contemporaneous_Root_observed_utc':root_receipt['branch_readback_observed_utc'],'current_remote_ref_matches':True,'historical_schema_validation':'OFFLINE_RECEIPT_CHECK_ONLY_NOT_RESERVATION','new_live_control_authored':False,'current_time_validation_refusal':expired_code},
 'preserved_review':{'reviewer':parse(payload['INDEPENDENT_REVIEW.json'])['reviewer'],'review':desc(payload['INDEPENDENT_REVIEW.json']),'report':desc((ROOT/'independent/REPORT.md').read_bytes()),'downstream_addendum':desc((ROOT/'independent/ADDENDUM-20261118-LIVE-CONTROL-TRANSPORT.json').read_bytes())},
 'limits':['Original private captures were not acquired or recomputed by this receiver.','Hosted hold/finalize failure codes are observed; HTTPS transport cause is a separately bounded source/local diagnosis.','True cleanup/source/runtime bookends do not establish missing post-review closure.','No late hold, reservation, rerun, relaunch, source change or publication was performed.'],
 'checks':CHECKS
}
(OUT/'DECODED_PUBLIC.json').write_bytes(canonical(docs))
(OUT/'CHECKS.json').write_bytes(canonical(summary))
print(json.dumps({'evidence_integrity':summary['evidence_integrity'],'verified_checks':len(CHECKS),'M2_disposition':summary['M2_disposition'],'terminal_status':result['status'],'observed_failures':[(x['operation'],x['code']) for x in failure['failures']],'public_payload_bytes':summary['public_payload_bytes'],'checks_sha256':sha((OUT/'CHECKS.json').read_bytes())},indent=2))
