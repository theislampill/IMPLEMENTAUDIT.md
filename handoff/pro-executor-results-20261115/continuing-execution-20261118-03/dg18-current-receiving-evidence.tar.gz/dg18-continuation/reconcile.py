"""Read-only evidence reconciliation; no runtime owner, controller or award authority."""
from pathlib import Path
import datetime
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
SOURCE = "6b353b48b2fc8a6de0c6223f48d341c484c98191"
CHECKS = []


def digest(value):
    return hashlib.sha256(value).hexdigest()


def read(relative):
    return json.loads((ROOT / relative).read_bytes())


def check(name, condition):
    CHECKS.append({"check": name, "verified": bool(condition)})
    if not condition:
        raise ValueError(name)


def descriptor(relative):
    data = (ROOT / relative).read_bytes()
    return {"path": relative, "bytes": len(data), "sha256": digest(data)}


issue = (ROOT / "live/ISSUE215.md").read_bytes()
amendment = (ROOT / "live/COMMENT_5638756120.md").read_bytes()
provider = read("live/ISSUE215_PROVIDER.json")
check("live issue exact original body", digest(issue) == "40dbebcc34083f49a49af13e5c6ab50ffe6fbf5a99395d9594926e4668fd09f1")
check("live sole amendment exact original body", digest(amendment) == "3774677f6aa3ad2676d8afbded7dce277f5e561a8bf492200418a0495393caaf")
check("provider issue and complete comment population", provider["issue"]["body"].encode() == issue and provider["issue"]["state"] == "open" and len(provider["comments"]) == 1 and provider["comments"][0]["id"] == 5638756120 and provider["comments"][0]["body"].encode() == amendment)

retained_manifest = read("retained/MANIFEST.json")
for item in retained_manifest["files"]:
    data = (ROOT / "retained" / item["saved_name"]).read_bytes()
    check("retained exact bytes: " + item["saved_name"], len(data) == item["bytes"] and digest(data) == item["sha256"] and hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() == item["git_blob"])
    if "immutable_matches" in item:
        check("retained immutable checkpoint: " + item["saved_name"], any(x["commit"] == "afda760d6de5cac08a27ad86da4c2be981749354" and x["bytes_equal"] for x in item["immutable_matches"]))

old = read("retained/DG18_ORIGINAL14_CURRENT_DISPOSITION.json")
section = issue.decode().split("## Acceptance\n", 1)[1].split("### Complete original R0039 acceptance", 1)[0]
predicates = re.findall(r"(?ms)^\s*(\d+)\.\s+(.*?)(?=^\s*\d+\.\s+|\Z)", section)
check("original fourteen exact numbered population", [int(n) for n, _ in predicates] == list(range(1, 15)))
prior_rows = {x["id"]: x for x in old["original_fourteen_criterion_delta"]}
check("retained original fourteen exact population", sorted(prior_rows, key=lambda x: int(x[1:])) == [f"A{i}" for i in range(1, 15)])
for number, text in predicates:
    check("original criterion equality A" + number, " ".join(text.split()) == " ".join(prior_rows["A" + number]["original_predicate"].split()))

source_manifest = read("source-6b/MANIFEST.json")
check("selected exact source and tree", source_manifest["source_commit"] == SOURCE and source_manifest["source_tree"] == "92da6bf5f9d2d8d7ea723b56f2e99c838a9d984b")
for item in source_manifest["files"]:
    data = (ROOT / "source-6b" / Path(item["path"]).name).read_bytes()
    check("immutable source bytes: " + item["path"], len(data) == item["bytes"] and digest(data) == item["sha256"] and hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() == item["git_blob"])
defaults = [x for f in source_manifest["files"] for x in f.get("selected_source_capability_defaults", [])]
check("native and C02 selectors unprovisioned in exact source", {x["name"] for x in defaults} == {"_NATIVE_PRIVATE_PROFILE_V1", "_C02_ADMITTED_OWNER_SELECTION_V1"} and all(x["value_is_none"] for x in defaults))

a7 = read("retained/CURRENT_A7_INDEPENDENT_RECEIVING.json")
check("later actual A7 receipt supersedes stale pending rows", a7["decision"] == "PASS_AT_EXACT_CURRENT_6B_BYTES_ONLY_CLI_NOT_TRIGGERED_SCOPE" and a7["actual_result"]["status"] == "NOT_TRIGGERED" and a7["source"]["runtime_commit"] == SOURCE and old["current_continuation"]["receipt"]["sha256"] == digest((ROOT / "retained/CURRENT_A7_INDEPENDENT_RECEIVING.json").read_bytes()))
by_path = {item["path"]: item for item in source_manifest["files"]}
for item in a7["source"]["members"]:
    current = by_path[item["source_path"]]
    check("accepted A7 exact current owner: " + item["path"], all(item[k] == current[k] for k in ("bytes", "sha256", "git_blob")))
check("A7 unchanged authority observations retained", a7["unchanged_observation"]["before_after_full_equality"] is True and a7["unchanged_observation"]["no_canonical_generation_or_archive_file_or_ref_created"] is True)

wfull = read("retained/ROOT_SCOPED_RECEIVING.json")
check("accepted W-FULL exact operation retained", wfull["actual_run"] == "43795345593" and wfull["actual_job"] == "133062794217" and wfull["operation_sha256"] == "8f76c756d7288bfb89f6e1b38d328d5db76ded21989e62fe5b34df1d06ded3b3" and wfull["runtime_commit"] == SOURCE and wfull["root_decision"] == "ACCEPT_AT_EXACT_DECLARED_WINDOWS_OPERATION_SCOPE" and wfull["whole_cell_accepted"] is False)
ab = read("retained/ACCEPTANCE_DELTA.json")
c11 = ab["B"]
check("accepted C11 current installed scope retained", c11["run_id"] == 43855749471 and c11["job_id"] == 133259441293 and c11["runtime"] == SOURCE and c11["received_member_count"] == 289 and c11["received_member_bytes"] == 579705 and c11["actual_successful_command_captures"] == 78 and c11["whole_DG18_accepted"] is False)
check("original C11 independent report bound", ab["independent_receiving"]["sha256"] == digest((ROOT / "retained/INDEPENDENT_TERMINAL_RECEIVING.json").read_bytes()))
h0 = read("retained/H0_ORIGINAL_COLD_RECEIVING.json")
composition = read("retained/H0_COLD_COMPOSITION_ADMISSION.json")
check("accepted authentic H0 cold conjunct retained without full award", h0["decision"] == "ACCEPTED_ORIGINAL_H0_COLD_PRESERVATION_CONJUNCT_AT_EXACT_DECLARED_SCOPE" and h0["original_full_AC05_award"] is False and h0["whole_DG18_acceptance"] is False and h0["GO_replayed"] == 0 and h0["native_operations"] == 0)
n1 = h0["five_fields"]["obligations"]["second_occurrence"]
check("original N1 pending duty and limits retained", n1["boundary_id"] == "boundary-162f88f4b5482b1970418ee6b35c4f0f2e05420c7449b4e390fac781e1de1648" and n1["cutoff"] == 109411 and n1["audit_state_required"] is True and n1["consumption"] == "PENDING; witness=null; covered_boundary_ids=[]" and n1["currentness"] == "UNRESOLVED; epoch=null")

subject = read("live/CURRENT_SUBJECT_METADATA.json")
check("actual commissioned Root receipt found exactly", subject["requested_root_receipt_oid"] == "6841b1e7e8d574e1b55cb406ea8360b4782f57f7" and len(subject["matched_refs"]) == 1)
current = subject["matched_refs"][0]
check("actual Root subject is legacy v2 without migrated tuple", current["schema"] == "implementaudit.continuity-receipt.v2" and current["tsv_fields"] == 12 and not any("/current-generations/" in x or "/current-generation-migrations/" in x for x in current["associated_refs"]))
capabilities = read("live/EXPOSED_CAPABILITY_CENSUS.json")
check("bounded exposed capability query found no matching contract", capabilities["tool_count"] == 329 and capabilities["matching_metadata"] == [])

rows = []
for number, text in predicates:
    row = prior_rows["A" + number]
    current_status = row["retained_status"]
    note = row["this_continuation_delta"]
    if number == "7":
        current_status = "RETAIN_ACCEPTED_CURRENT6B_BYTE_ONLY_NOT_TRIGGERED_SCOPE_FULL_OR_OPEN"
        note = "The later exact actual A7 receipt supersedes the older pending row; no rerun is needed. Authentic token/context-health OR admission remains absent."
    elif number == "12":
        note = "Retain the original ordering/mutation/v2 controls and later received current6b v2 no-trigger scope; do not retain the obsolete pending wording or expand the result to the full transition matrix."
    rows.append({"id": row["id"], "original_predicate": " ".join(text.split()), "retained_status": current_status, "current_receiving_note": note, "new_acceptance_delta": 0})

frontier = {
    "schema": "dg18.original14.current-reconciliation.v1", "report_state": "FINAL",
    "reviewer": "/root/g2_delivery_checks", "authority": "NONE", "scope": "ORDINARY_READ_ONLY_SOURCE_AND_RETAINED_EVIDENCE_RECEIVING",
    "observed_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "repository": "theislampill/IMPLEMENTAUDIT.md", "source_commit": SOURCE,
    "source_tree": source_manifest["source_tree"], "original_issue": descriptor("live/ISSUE215.md"),
    "binding_amendment": descriptor("live/COMMENT_5638756120.md"),
    "original_fourteen": rows, "new_awards": [], "whole_DG18_accepted": False,
    "complete_original_frontier": {
        "OR": "OPEN: authentic producer/issuer applicability, original observation/window/cutoff, live freshness and exclusive custody are not supplied by the exposed interfaces.",
        "H0_occurrence_discrimination": "Retain accepted separate H002 canonical and H005 selected-prior/retry composition at original source/episode scopes. No new authentic selected occurrence has been supplied.",
        "full_cold_receiving": "OPEN: accepted original H0 cold-preservation conjunct retained; complete amended population is not awarded. N1 remains mandatory, pending/uncovered, LOST/UNKNOWN, with absent witness and no exception.",
        "C02": "OPEN: actual erroneous migrated subject, applicable issuer/grant, exact expected-old tuple and complete actual later-boundary/prior-adjudication interval are absent. The actual commissioned Root subject is v2 without pointer/marker.",
        "TC06_TC11": "Retain supported-old reader/marker/archive/acceptance duties and original historical validity; withhold only unsupported affected current use. No invented retirement, revocation or native replay is required."
    },
    "accepted_receipt_identities": [descriptor("retained/" + n) for n in ["ROOT_SCOPED_RECEIVING.json", "ACCEPTANCE_DELTA.json", "INDEPENDENT_TERMINAL_RECEIVING.json", "CURRENT_A7_INDEPENDENT_RECEIVING.json", "H0_COLD_COMPOSITION_ADMISSION.json", "H0_ORIGINAL_COLD_RECEIVING.json"]],
    "current_subject_snapshot": descriptor("live/CURRENT_SUBJECT_METADATA.json"),
    "capability_query": descriptor("live/EXPOSED_CAPABILITY_CENSUS.json"),
    "selected_source_manifest": descriptor("source-6b/MANIFEST.json"),
    "retained_manifest": descriptor("retained/MANIFEST.json"),
    "execution_decision": "Completed actual read-only provider/source/receipt/subject reconciliation. No new authentic operation has sufficient prerequisites; accepted operations are not repeated.",
    "source_change_set": [], "runtime_defect_demonstrated": False, "native_operations": 0,
    "qualification_reruns": 0, "new_controller": False, "grant_created": False,
    "N1_search_or_reconstruction": False, "historical_exception_applied": False,
    "publication": False, "protected_effect": False,
    "limits": ["Current subject metadata is a bounded observation, not exclusive native custody or an issuer grant.", "Retained receipts preserve historical accepted scopes; original hosted operations and private observations were not rerun or reacquired.", "No new source defect was established; no speculative source patch or replacement producer is created."]
}
(ROOT / "CURRENT_FRONTIER.json").write_text(json.dumps(frontier, indent=2, sort_keys=True) + "\n")
checks = {"schema": "dg18.current-reconciliation-checks.v1", "authority": "NONE", "reviewer": "/root/g2_delivery_checks", "checks": CHECKS, "all_verified": all(x["verified"] for x in CHECKS), "result": "EXACT_ORIGINAL14_AND_RETAINED_SCOPES_RECONCILED_NO_NEW_AWARD", "frontier": descriptor("CURRENT_FRONTIER.json")}
(ROOT / "CHECKS.json").write_text(json.dumps(checks, indent=2, sort_keys=True) + "\n")
print(json.dumps({"checks": len(CHECKS), "all_verified": checks["all_verified"], "frontier": checks["frontier"], "source_changes": 0, "qualification_reruns": 0, "native_operations": 0}, sort_keys=True))
