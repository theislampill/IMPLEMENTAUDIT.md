# Independent G132 R2 ordinary-operation receipt

**Disposition: RECOMMEND that Root admit the single bounded ordinary observation in the exact rebound packet below.**

The operation can produce independently useful current host facts despite its known NSS residual. It does not receive complete-cleanup qualification, protected readiness or original acceptance. The expected nonzero input result must remain adverse evidence. This is an independent advisory recommendation; Root retains admission, publication, launch and receiving authority.

## Exact binding

| Subject | Reviewed identity |
| --- | --- |
| Root rebound packet | `/workspace/scratch/75de74f83f5c/recovery/root/g132-ordinary-operation-01/PACKET.json` |
| Packet | 2,086 bytes; SHA-256 `60435b151083b46d88f0d05963ce6eb36fe53afa169c33aa6909e238edbafcbf` |
| Operation | `G132_HOST_PROFILE_SUCCESSOR_20261122_01` |
| Published source | `4ddd6403b70835339b6f55aeff9478b6d061247b` |
| Source tree / sole parent | `969df99854f9ca87fda54f21585864d7a0d61a38` / `760aaff5c478ff7354d36da186d62daba983aa49` |
| Prospective host tree | `7a46936aaf4212e193e603f6ff9e0a07969f9c50` |
| Prospective host sole parent | Published source `4ddd6403b70835339b6f55aeff9478b6d061247b` |
| Host branch / attempt | `pro/dg16-g132-host-profile-successor-20261122-01` / 1 |
| Operator | 10,595 bytes; SHA-256 `f636fca21f30850b03adef11e9b854549789a7d5ffb213efc40077bde314c40f` |
| Workflow | 10,976 bytes; SHA-256 `22a2af4e364339a54e4df99ed81d68653ca9b0a4c534d05d346acdc16afbc925` |

The operator/workflow are the two exact files under the Root packet's `content/` directory, with mode 100644. Their sole changes from the reviewed author packet are operator `SOURCE_COMMIT` and the workflow's exact operator hash.

The published source commit/tree/parent and all eight source bytes/modes were independently read from Git objects already fetched by Root, with lazy fetching disabled. They agree with Root's `g132-source-publication-r2/REMOTE_READBACK.json` and the previously reviewed R2 source. The expected host tree was independently recomputed from the published source tree plus the two exact additions, without writing Git objects.

No prospective host commit, run, job or artifact is invented by this review. Root must bind their actual provider identities and verify the expected host tree/parent when performing the admitted publication/observation.

## Why the bounded observation is useful and admissible

The retained operation05 evidence did not establish this new finite profile, actual files-only NSS validation, restored-original snapshot and pinned launcher/policy/namespace conjunction on one boot. The proposed observation can supply those facts through existing owners.

The finite sequence receives fresh public selected source, provisions the unchanged pinned launcher and scoped AppArmor policy, observes the intentionally absent target through the existing namespace owner, then inspects actual selected host inputs while the R2 NSS lease is active. The unchanged provider validator receives real files; reported NSS data is not edited to force a match. The separate full-startup check remains its own result, including any refusal.

The operation has no private input acquisition, provider-input session construction, original C5 session construction or original19/protected target invocation. Its allowed acquisitions are public selected repository source and the existing exact pinned launcher archive. The operator calls only its seven finite phases. No broader command or source selection is introduced.

No additional unmet admission prerequisite was established for this expressly bounded diagnostic purpose. A fresh image mismatch, source/launcher/policy refusal or unsupported NSS layout is an actual observation/refusal, not permission to broaden the profile or retry automatically.

## Known residual and unchanged oracle

If NSS preparation allocates a replacement, R2 restores the original target where it can verify that snapshot and retains replacement material. It records:

- `RESTORED_REPLACEMENT_RETAINED`
- `cleanup_complete=false`
- `backup_removed=false`
- `nss_cleanup_admission=UNQUALIFIED_RETAINED_RESIDUAL`

The complete-cleanup discriminator remains closed. The selected-gate result stays `REFUSED`, and the input phase returns nonzero. The workflow records and returns that exit status. Its `always()` finalizer, collector and artifact upload preserve complete or partial evidence rather than convert the failure into success.

The original-target closing snapshot and retained material are distinct facts. Neither anticipated VM disposal, a name snapshot, an advisory lock nor successful target restoration alone proves complete cleanup. The local already-files-only/no-allocation control does not establish that the actual hosted image will take that path.

This known residual does not erase separately supported pin, validator, launcher, policy or namespace observations. It does prevent promotion to a complete ordinary qualification, protected readiness or original award.

## Effect, resource and receiving boundaries

The reviewed workflow fixes one push branch, job `qualify`, GitHub-hosted ubuntu-24.04 with exact image ubuntu24 / 20261116.376.1, and attempt 1. It uses pinned checkout/upload actions, read-only contents permission, no persisted checkout credentials and no automatic rerun. Earlier prerequisite failure skips later normal steps; finalizer/collection/upload remain always-attempted.

Existing resource bounds are unchanged: 1,610,612,736 address bytes, 120 CPU seconds, 268,435,456 file bytes, 256 descriptors, 240-second ordinary wall bound and 2,097,152 report bytes; the job ceiling is eight minutes. Existing launcher/namespace owners impose their smaller limits in separate processes. NSS configuration/receipt bounds remain 65,536/16,384 bytes.

The source, namespace and input records join exact source, provider run and boot identity. The operator collects only four named public receipts and finite phase stdout/stderr/status files, retaining original empty or partial bytes. It does not export original NSS contents, the complete source tree, private archives or credentials.

The scoped policy finalizer only observes retained state. NSS residuals, launcher and policy remain for disposable-host teardown; this is not a cleanup proof. Timeout, forced process/host loss, partial receipt or failed closing checks remain unqualified. There is no review-authorized retry or stronger claim.

Independent receiving must use actual provider identities, exact carrier bytes and phase outcomes. Preserve the nonzero input status and each supported fact at its own scope; the aggregate Actions conclusion is not the oracle. Full startup is separately recorded and cannot substitute for original execution.

## Independent verification

The author packet was independently verified: manifest SHA-256 `47065e5cda2b094ec2f7a2594297ca664232d3854e6bb01a361f2bc8da6128e0`, 35 payloads / 512,782 bytes; archive 161,518 bytes, SHA-256 `8300fff9cbbcecd8722e4e9d2222f7d6b274ce8de5ed4d658606c404aca1e1f8`.

**124 inert integrity/static/shell-syntax assertions passed.** These covered exact payload/archive readback, source equality, finite phases, pins, permissions/trigger, adverse-status preservation and collection. They did not execute the operation or its effectful owners.

**20 final rebind assertions passed**, including exact Root packet, published source objects, two file bytes/modes/blob IDs, rebind-only changes and independently computed host tree. The unchanged R2 source behavior remains covered by `g132-successor-r2-review.md`; no original or historical diagnostic was repeated.

Evidence directory: `/workspace/scratch/75de74f83f5c/recovery/lanes/g132-successor-r2-operation-review-evidence/`.

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `static-review.json` | 13,296 | `8a94cb55774da714a01042fb62f661b2026afac26ece8fbea30619eeb3ac45bf` |
| `rebind-review.json` | 3,618 | `3f23b51f769212b8771266b4131df2727f68f5f4d5ba8c821cd2ce1d47b11ece` |

Exact verifiers are retained alongside as `verify_static.py` and `verify_rebind.py`.

The first failure/witness remains intact. `44888568054` remains SPENT_NO_RETRY; historical `301…` and A4-07 remain UNKNOWN_NO_REPLAY; queued `43098152901` remains separate and untouched. No system NSS, source/controller, model, host or remote effect was performed by this reviewer; no original acceptance is conveyed.
