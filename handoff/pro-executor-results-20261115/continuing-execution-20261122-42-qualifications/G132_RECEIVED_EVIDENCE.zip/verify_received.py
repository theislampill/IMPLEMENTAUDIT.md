#!/usr/bin/env python3
"""Read and hash retained public data only; never imports or executes target source."""
from pathlib import Path
import hashlib
import json
import re
import stat
import zipfile

ROOT = Path(__file__).resolve().parent
SOURCE = '4ddd6403b70835339b6f55aeff9478b6d061247b'
TREE = '969df99854f9ca87fda54f21585864d7a0d61a38'
BASE = '760aaff5c478ff7354d36da186d62daba983aa49'
HOST = 'aceeb806b4f468987b6544c41cc517a4d78777db'
HOST_TREE = '7a46936aaf4212e193e603f6ff9e0a07969f9c50'
RUN = 44979910098
JOB = 137077930746
ARTIFACT = 14737605409
OPERATION = 'G132_HOST_PROFILE_SUCCESSOR_20261122_01'
BRANCH = 'pro/dg16-g132-host-profile-successor-20261122-01'
ZIP_SHA = '5925192fb07509ff33c317d357a33d7164306b4275cb433bdeb56e18c05a1a5b'
PHASES = ('prepare', 'launcher', 'policy', 'namespace', 'inputs', 'finalize')
LIMITS = dict(address_bytes=1610612736, cpu_seconds=120, descriptors=256,
              file_bytes=268435456, report_bytes=2097152, wall_seconds=240)
SHA = lambda b: hashlib.sha256(b).hexdigest()
READ = lambda p: (ROOT / p).read_bytes()
JSON = lambda p: json.loads(READ(p))
checks = []

def check(name, condition, detail=None):
    checks.append(dict(id=name, status='PASS' if condition else 'GAP', detail=detail))

packet = JSON('operation/PACKET.json')
admit = JSON('operation/ROOT_ADMISSION.json')
run = JSON('provider/run.json')
jobs = JSON('provider/attempt-1-jobs.json')
artifacts = JSON('provider/run-artifacts.json')
commit = JSON('provider/host-commit.json')
download = JSON('provider/artifact-download-receipt.json')
check('exact_packet', SHA(READ('operation/PACKET.json')) == '60435b151083b46d88f0d05963ce6eb36fe53afa169c33aa6909e238edbafcbf')
check('exact_root_admission', SHA(READ('operation/ROOT_ADMISSION.json')) == '7412894e5879d3ff4149cc3b9e82690349eb84d77ac93e7c167ef494ff926829')
check('exact_independent_preflight', SHA(READ('operation/INDEPENDENT_PREFLIGHT.md')) == 'b8398091876798533f37c8f4944ddff6808142627069cec7a4cfcd9beda2380b')
check('single_bounded_admission', admit['operation'] == OPERATION and admit['attempt'] == 1 and admit['decision'] == 'ADMIT_ONE_BOUNDED_ORDINARY_HOST_OBSERVATION' and admit['packet_sha256'] == SHA(READ('operation/PACKET.json')) and all(admit[k] is False for k in ('protected_operation','private_input_acquisition','original_execution','release')) and admit['original_awards'] == [])
check('host_provider_commit_tree_sole_parent', commit['sha'] == HOST and commit['tree']['sha'] == HOST_TREE and [x['sha'] for x in commit['parents']] == [SOURCE])
for f in packet['files']:
    raw = READ('source/host/' + f['path'])
    blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    check('host_file_' + f['path'], len(raw) == f['bytes'] and SHA(raw) == f['sha256'] and blob == f['git_blob_sha'])
check('actual_run_identity_terminal_attempt1', run['id'] == RUN and run['head_sha'] == HOST and run['head_branch'] == BRANCH and run['run_attempt'] == 1 and run['event'] == 'push' and run['path'] == '.github/workflows/dg16-g132-host-profile-successor.yml' and run['status'] == 'completed' and run['conclusion'] == 'failure')
check('actual_one_job_identity_terminal', jobs['total_count'] == 1 and len(jobs['jobs']) == 1 and jobs['jobs'][0]['id'] == JOB and jobs['jobs'][0]['run_id'] == RUN and jobs['jobs'][0]['head_sha'] == HOST and jobs['jobs'][0]['run_attempt'] == 1 and jobs['jobs'][0]['name'] == 'qualify' and jobs['jobs'][0]['status'] == 'completed' and jobs['jobs'][0]['conclusion'] == 'failure')
job = jobs['jobs'][0]
check('step_outcomes_preserve_input_failure_and_always_receiving', all(x['status'] == 'completed' and x['conclusion'] == ('failure' if x['number'] == 8 else 'success') for x in job['steps']))
artifact = artifacts['artifacts'][0]
check('actual_unique_artifact_identity', artifacts['total_count'] == 1 and len(artifacts['artifacts']) == 1 and artifact['id'] == ARTIFACT and artifact['name'] == 'g132-host-profile-successor-44979910098-1' and artifact['size_in_bytes'] == 17345 and artifact['digest'] == 'sha256:' + ZIP_SHA and artifact['expired'] is False and artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == HOST)
rawzip = READ('provider/artifact14737605409.zip')
check('provider_zip_size_digest_http', len(rawzip) == 17345 and SHA(rawzip) == ZIP_SHA and download['http_status'] == 200 and download['provider_digest_match'] is True)
expected = {f'{p}.{s}' for p in PHASES for s in ('stdout','stderr','status')} | {'preparation.json','namespace.json','inputs.json','nss.json','manifest.json'}
with zipfile.ZipFile(ROOT / 'provider/artifact14737605409.zip') as z:
    infos = z.infolist()
    check('zip_crc', z.testzip() is None)
    check('exact_safe_23_member_population', len(infos) == len(expected) == 23 and set(z.namelist()) == expected and len(set(z.namelist())) == len(infos) and all('/' not in x.filename and '\\' not in x.filename and not x.is_dir() and not stat.S_ISLNK(x.external_attr >> 16) and x.file_size <= LIMITS['report_bytes'] for x in infos))
    check('zip_extracted_bytes_exact', all(z.read(x) == READ('received/' + x.filename) for x in infos))
    check('zip_total_with_manifest_within_report_bound', sum(x.file_size for x in infos) <= LIMITS['report_bytes'], sum(x.file_size for x in infos))
delivery = JSON('received/manifest.json')
payload = delivery['files']
check('public_manifest_exact_22_member_population', len(payload) == 22 and {x['name'] for x in payload} == expected - {'manifest.json'} and all(x['present'] is True for x in payload))
check('public_manifest_all_lengths_and_digests', all(len(READ('received/' + x['name'])) == x['bytes'] and SHA(READ('received/' + x['name'])) == x['sha256'] for x in payload))
check('public_manifest_aggregate', delivery['aggregate_bytes'] == sum(x['bytes'] for x in payload) == 85532)
check('four_receipts_marked_exact_copy', all(x.get('exact_source_bytes_retained') is True for x in payload if x['name'] in ('preparation.json','namespace.json','inputs.json','nss.json')))
preparation = JSON('received/preparation.json')
namespace = JSON('received/namespace.json')
inputs = JSON('received/inputs.json')
nss = JSON('received/nss.json')
ctx = preparation['context']
expected_context = dict(GITHUB_ACTIONS='true',GITHUB_EVENT_NAME='push',GITHUB_JOB='qualify',GITHUB_REF='refs/heads/'+BRANCH,GITHUB_REPOSITORY='theislampill/IMPLEMENTAUDIT.md',GITHUB_RUN_ATTEMPT='1',ImageOS='ubuntu24',ImageVersion='20261116.376.1',RUNNER_ENVIRONMENT='github-hosted',run_id=str(RUN),host_commit=HOST,workflow_ref='theislampill/IMPLEMENTAUDIT.md/.github/workflows/dg16-g132-host-profile-successor.yml@refs/heads/'+BRANCH)
check('exact_provider_workflow_image_context', all(ctx.get(k) == v for k,v in expected_context.items()) and set(ctx) == set(expected_context) | {'boot_id'} and bool(re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', ctx['boot_id'])))
check('same_actual_boot_context_all_four_receipts', all(x['context'] == ctx for x in (namespace,inputs,delivery)), ctx['boot_id'])
check('log_corrob_image_and_artifact', all(x in READ('provider/job-137077930746.log').decode() for x in ('Version: 20261116.376.1', '5925192fb07509ff33c317d357a33d7164306b4275cb433bdeb56e18c05a1a5b', 'Artifact ID 14737605409', 'Final size is 17345 bytes', 'Process completed with exit code 2.')))
check('source_identity_all_receipts', all(x['source_commit'] == SOURCE and x['source_tree'] == TREE for x in (preparation,namespace,inputs,delivery)))
check('source_preparation_completed_exact_parent_clean_complete', preparation['complete'] is True and preparation['source_parent'] == BASE and preparation['credential_source'] == 'NONE' and preparation['source']['source_commit'] == SOURCE and preparation['source']['source_tree'] == TREE and preparation['source']['ordered_parents'] == [BASE] and preparation['source']['clean'] is True and preparation['source']['complete_objects'] is True and preparation['source']['loose_head_present'] is True and preparation['source']['child_fetch_unpack_limit'] == 64)
check('source_preparation_command_copies_equal', preparation['source_commands'] == preparation['source']['commands'])
for label, row, count in (('prepare',preparation,10),('namespace',namespace,4),('inputs',inputs,8)):
    commands = row['source_commands']
    check('source_commands_' + label, len(commands) == count and all(c['command_received'] is True and c['returncode'] == 0 and c['exception'] is None and c['cleanup_errors'] == [] and c['wait_reaped'] is True and c['owned_group_absent'] is True and c['descriptor_restoration'] is True and c['timed_out'] is False and c['output_overflow'] is False and c['eof'] == {'stdout':True,'stderr':True} for c in commands), count)
for label,row in (('namespace',namespace),('inputs',inputs)):
    check('finite_limits_'+label, row['limits'] == LIMITS)
    check('authority_boundaries_'+label, row['operation'] == OPERATION and row['authority'] == 'NONE' and row['overall_admission'] == 'UNQUALIFIED' and all(row[k] is False for k in ('original_execution','private_inputs_selected','provider_acquired','session_constructed','native_admission')) and 'failure' not in row)
    check('descriptor_restore_'+label, row['descriptor_restoration'] is True)
phase_status = {p: int(READ('received/' + p + '.status')) for p in PHASES}
check('exact_phase_statuses', phase_status == dict(prepare=0,launcher=0,policy=0,namespace=0,inputs=2,finalize=0), phase_status)
check('all_six_phase_stderr_empty', all(READ('received/' + p + '.stderr') == b'' for p in PHASES))
ns = namespace['namespace']
launcher = JSON('received/launcher.stdout')
policy = JSON('received/policy.stdout')
finalize = JSON('received/finalize.stdout')
check('launcher_pinned_exclusive_provision', launcher['scope'] == 'LINUX_LAUNCHER_PROVISION_ONLY_NO_C5_OR_NATIVE_ACCEPTANCE' and launcher['target'] == '/usr/bin/bwrap' and launcher['launcher']['bytes'] == 72160 and launcher['launcher']['sha256'] == '52231e1caf55bcbc667b269f49c63599a6f7db4767ae6a039580d0ff853db712' and launcher['launcher']['exclusive_creation'] is True and launcher['launcher']['mode'] == '0755' and launcher['launcher']['opening'] == launcher['launcher']['closing'])
check('launcher_pinned_package', launcher['package']['bytes'] == 50178 and launcher['package']['sha256'] == '1b506492bd9c7fd0cdb4f02ac822f1d3e336b0aead5113c1239baf8db5db562a')
check('policy_scoped_loaded', policy['scope'] == 'EPHEMERAL_CI_BWRAP_POLICY_ONLY_NO_NATIVE_ACCEPTANCE' and policy['global_state_unchanged'] is True and policy['parser'] == {'exit_code':0,'stderr':'','stdout':''} and set(policy['loaded']) == {'implementaudit-c5-bwrap-v1','implementaudit-c5-unpriv-bwrap-v1'} and all(x['mode'] == 'enforce' and x['sha256'] == policy['compiled_profiles'][k] for k,x in policy['loaded'].items()))
check('policy_retention_finalizer_not_cleanup_claim', finalize['status'] == 'ACTIVE_POLICY_AND_RECEIPT_RETAINED' and finalize['loaded'] == policy['loaded'] and finalize['profile_sha256'] == policy['profile_sha256'] and finalize['kernel_policy_unloaded'] is False and finalize['receipt_unlinked'] is False and finalize['retained_until'] == 'EPHEMERAL_VM_DISPOSAL' and finalize['observation_limit'] == 'SNAPSHOT_ONLY_NOT_LAUNCH_EXCLUSION')
check('namespace_expected_absent_target_success', namespace['namespace_return_code'] == 0 and namespace['selected_gate_observation'] == 'OBSERVED_SELECTED_GATE_PASS' and ns['classification'] == 'SETUP_REACHED_ABSENT_TARGET' and ns['exit_code'] == 1 and ns['raw_wait_status'] == 256 and ns['stderr'] == 'bwrap: execvp /__c5_proc_setup_intentionally_absent_target__: No such file or directory\n' and ns['stdout'] == '')
check('namespace_complete_child_custody', all(ns[k] is True for k in ('complete_custody','descriptor_restoration','owned_group_absent','wait4_reaped')) and ns['eof'] == {'stdout':True,'stderr':True} and all(ns[k] is False for k in ('original19_started','provider_acquired','native_admission','overflow','timed_out')))
check('namespace_parent_snapshot_unchanged', ns['parent_opening'] == ns['parent_closing'])
check('namespace_same_pinned_launcher', ns['launcher']['current'] is True and ns['launcher']['opening'] == ns['launcher']['closing'] == launcher['launcher']['closing'] and ns['launcher']['bytes'] == launcher['launcher']['bytes'] and ns['launcher']['sha256'] == launcher['launcher']['sha256'])
check('input_joins_exact_namespace_bytes', inputs['namespace_receipt'] == dict(bytes=len(READ('received/namespace.json')),sha256=SHA(READ('received/namespace.json'))))
host = inputs['host_inputs']
fixture = JSON('source/selected/fixtures/work-graph-c5-inputs/package-g132-host-profile-20261122-v1.json')
pin_spec = dict(fixture['startup_pins'], **fixture['native_pins'])
check('exact_twelve_pin_population_from_selected_fixture', len(host['pins']) == len(pin_spec) == 12 and {x['path'] for x in host['pins']} == set(pin_spec) and all(x['expected'] == pin_spec[x['path']] for x in host['pins']))
check('twelve_pins_observed_match_fields', all(x['match'] is True and x['observed']['kind'] == 'FILE' and all(x['observed'].get(k) == v for k,v in x['expected'].items()) for x in host['pins']))
check('exact_four_system_python_aliases', len(host['system_aliases']) == 4 and {x['path'] for x in host['system_aliases']} == {'/usr/bin/python','/usr/bin/python3','/bin/python','/bin/python3'} and all(x['match'] is True and x['observed']['kind'] == 'FILE' and all(x['observed'].get(k) == v for k,v in x['expected'].items()) for x in host['system_aliases']))
check('actual_root_identity_and_nss_owner_validation', host['identity'] == host['nss']['result']['identity'] == dict(uid=0,euid=0,gid=0,egid=0) and host['nss']['result']['match'] is True)
check('hosted_selected_bookends_equal', host['selected_bookends_equal'] is True)
check('hosted_absence_observations', len(host['absent']) == 16 and all(x['kind'] == 'MISSING' for x in host['absent'].values()))
check('hosted_no_provider_acquisition_or_native_admission', host['provider_acquired'] is False and host['provider_imports'] == 0 and host['native_admission'] is False and host['overall_admission'] == 'UNQUALIFIED')
check('full_startup_separate_adverse_discriminator', host['unchanged_owner_full_startup'] == {'match':False,'reason':"[Errno 2] No such file or directory: '/usr/lib/implementaudit-c5-r5-hosted-python312-05-v1/bin/python'"})
check('actual_nss_receipt_exactly_joined', inputs['nss_cleanup'] == nss)
check('nss_expected_retention_refusal', nss['schema'] == 'g132.hosted-files-only-nss.v2' and nss['state'] == 'RESTORED_REPLACEMENT_RETAINED' and nss['cleanup_complete'] is False and nss['backup_removed'] is False and nss['replacement_deletion_attempted'] is False and inputs['nss_cleanup_admission'] == 'UNQUALIFIED_RETAINED_RESIDUAL' and inputs['selected_gate_observation'] == 'REFUSED')
check('nss_closing_original_bytes_inode_restored_only', nss['restoration_verified'] is True and nss['original_inode_restored'] is True and nss['opening']['bytes'] == nss['closing']['bytes'] == 526 and nss['opening']['sha256'] == nss['closing']['sha256'] == 'b953df1d0016f515fc052ca6bb0ccd092b8d13c8789c51c4eaef2b0461574e57' and nss['opening']['identity']['ino'] == nss['closing']['identity']['ino'] and nss['opening']['identity']['dev'] == nss['closing']['identity']['dev'] and nss['restoration_scope'] == 'CLOSING_ORIGINAL_TARGET_SNAPSHOT_ONLY' and nss['ctime_restoration_claim'] is False)
check('nss_active_selected_replacement_pin', nss['prepared'] == dict(bytes=518,sha256='5cde76a7763cef05fea9a086f5db0025459d489ee658a8369602e415e47beff7') and all(host['nss']['observation']['files']['/etc/nsswitch.conf'][k] == v for k,v in nss['prepared'].items()))
check('nss_retained_residual_no_name_exclusion_claim', nss['replacement_cleanup']['disposition'] == 'NO_DELETION_VM_DISPOSAL_REQUIRED' and nss['replacement_cleanup']['name_matches_held_snapshot'] is True and nss['replacement_cleanup']['name_exclusion_proven'] is False and nss['replacement_cleanup']['remaining_namespace_qualified'] is False and nss['original_bytes_exported'] is False and nss['original_execution'] is False)
sources = JSON('source/SELECTED_SOURCE_MANIFEST.json')
check('nine_exact_retained_owner_sources', len(sources['files']) == 9 and sources['source_commit'] == SOURCE and sources['source_tree'] == TREE and all(len(READ('source/selected/' + x['path'])) == x['bytes'] and SHA(READ('source/selected/' + x['path'])) == x['sha256'] and hashlib.sha1(b'blob ' + str(x['bytes']).encode() + b'\0' + READ('source/selected/' + x['path'])).hexdigest() == x['git_blob'] for x in sources['files']))
source_by_path = {x['path']:x for x in sources['files']}
for k,p in (('setup_pin','scripts/qualify-work-graph-c5-setup.py'),('nss_pin','scripts/hosted-files-only-nss.py')):
    expected_pin = {q:source_by_path[p][q] for q in ('bytes','sha256')}
    check('exact_executed_source_'+k, namespace[k] == inputs[k] == expected_pin)
public = [p for p in ROOT.rglob('*') if p.is_file() and p.name not in ('CHECKS.json','CARRIER_MANIFEST.json','EVIDENCE_CARRIER.zip','CARRIER_RECEIPT.json')]
check('public_payload_no_signed_urls_or_credential_values', all(not re.search(rb'[?&](?:sig|signature|token|credential|x-amz-signature)=',p.read_bytes(),re.I) and not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})',p.read_bytes()) for p in public))
result = dict(schema='g132.independent.ordinary-receiving-checks.v1',operation=OPERATION,run_id=RUN,attempt=1,job_id=JOB,artifact_id=ARTIFACT,packet_sha256=SHA(READ('operation/PACKET.json')),checks=checks,total=len(checks),passed=sum(x['status']=='PASS' for x in checks),gaps=sum(x['status']=='GAP' for x in checks),recommendation='RECEIVE_BOUNDED_MIXED_OUTCOME' if all(x['status']=='PASS' for x in checks) else 'GAP_REVISE_RECEIVING',original_awards=[],authority='NONE',original_execution=False,target_source_executed_by_receiver=False)
(ROOT/'CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
for x in checks:
    if x['status']!='PASS': print(json.dumps(x))
raise SystemExit(0 if result['gaps']==0 else 1)
