#!/usr/bin/env python3
"""Freeze and receive this inert publication staging. Does not execute evidence."""
from pathlib import Path
import hashlib
import io
import json
import stat
import zipfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
RECOVERY = ROOT.parent
EXCLUDED = {'ASSEMBLY_MANIFEST.json', 'EVIDENCE_CARRIER.zip', 'FINAL_READBACK.json'}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

assertions = []
def check(name, result):
    assertions.append({'check': name, 'ok': bool(result)})
    if not result:
        raise RuntimeError(name)

assembly = json.loads((ROOT / 'ASSEMBLY_READBACK.json').read_text())
copied = {e['path']: e for e in assembly['evidence']}
check('assembly all copy checks passed', assembly['all_checks_passed'] is True and all(e['ok'] for e in assembly['checks']))
for rel, e in copied.items():
    data = (ROOT / rel).read_bytes()
    check('copy source still exact: ' + rel, data == (RECOVERY / e['source_path']).read_bytes() and len(data) == e['bytes'] and sha(data) == e['sha256'] and blob(data) == e['git_blob'])

members = []
for p in sorted(ROOT.rglob('*')):
    if not p.is_file() or p.name in EXCLUDED:
        continue
    rel = p.relative_to(ROOT).as_posix()
    check('ordinary regular staged member: ' + rel, not p.is_symlink())
    check('no database/auth store member: ' + rel, not any(s in p.name.lower() for s in ['.sqlite', '.db-wal', '.db-shm']) and p.name not in ['auth.json', 'config.toml'])
    data = p.read_bytes()
    source = copied.get(rel)
    members.append({'path': rel, 'bytes': len(data), 'sha256': sha(data), 'git_blob': blob(data),
                    'staged_mode': '100755' if stat.S_IMODE(p.stat().st_mode) & 0o111 else '100644',
                    'kind': 'EXACT_COPIED_EVIDENCE' if source else 'NEW_DERIVED_ASSEMBLY_RECORD_OR_SCRIPT',
                    'source_path': source['source_path'] if source else None})

pending = json.loads((ROOT / 'PENDING.json').read_text())
remote = json.loads((ROOT / 'evidence/g132-ordinary-operation/REMOTE_READBACK.json').read_text())
check('actual host launch binding', pending['ordinary_host']['host_commit'] == remote['host_commit'] and pending['ordinary_host']['run_id'] == remote['run_id'] and pending['ordinary_host']['attempt'] == remote['attempt'])
check('host outcome not fabricated', pending['ordinary_host']['terminal_outcome'] is None and pending['ordinary_host']['independent_receiving'] is None and pending['ordinary_host']['root_outcome_adjudication'] is None)
check('boot NSS identity not fabricated', pending['new_boot_scoped_nss_engineering']['source_commit'] is None and pending['new_boot_scoped_nss_engineering']['frozen_packet_sha256'] is None)
subset = json.loads((ROOT / 'evidence/dg18-original-diagnostic/PUBLICATION_SUBSET.json').read_text())
check('DG18 exact thirteen/four partition', subset['exact_staged_payload_count'] == 13 and len(subset['members']) == 17 and len([e for e in subset['members'] if not e['staged']]) == 4)
check('DG18 carrier/private omitted', not (ROOT / 'evidence/dg18-original-diagnostic/A4_ACTUAL_RECEIVING_AND_ROOT_PACKET.json').exists() and all(not (ROOT / 'evidence/dg18-original-diagnostic/received-payloads' / e['path']).exists() for e in subset['members'] if not e['staged']))

manifest = {'schema': 'implementaudit.results42.staging-manifest.v1',
            'status': 'ROOT_REVIEW_REQUIRED_NOT_PUBLISHED', 'authority': 'NONE',
            'base_results_commit': 'aa4b6dd82de308d703dc11664c2ab97ac75be1ce',
            'base_results_tree': '41fbe720063eb24071c0c02766e5b6f4af248d37',
            'continuity_at_assembly': 'refs/implementaudit/continuity-receipts/dg16-dg18-successor-20261122/G0004@75d25ce849b3712fbb8e639cf1a26985a49636ed',
            'frozen_at': datetime.now(timezone.utc).isoformat(),
            'payload_files': len(members), 'payload_bytes': sum(e['bytes'] for e in members),
            'exact_copied_files': len(copied), 'exact_copied_bytes': sum(e['bytes'] for e in copied.values()),
            'original_awards_created': [], 'host_outcome_received_by_assembler': False,
            'files': members,
            'self_reference_rule': 'Manifest excludes itself, EVIDENCE_CARRIER.zip and FINAL_READBACK.json. Carrier contains every manifest payload plus this exact manifest; external final readback binds carrier and manifest.'}
mraw = (json.dumps(manifest, indent=2) + '\n').encode()
(ROOT / 'ASSEMBLY_MANIFEST.json').write_bytes(mraw)
archive = ROOT / 'EVIDENCE_CARRIER.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for e in members + [{'path': 'ASSEMBLY_MANIFEST.json', 'staged_mode': '100644'}]:
        info = zipfile.ZipInfo('results42-staging/' + e['path'], date_time=(2026, 11, 22, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | (0o755 if e['staged_mode'] == '100755' else 0o644)) << 16
        z.writestr(info, (ROOT / e['path']).read_bytes())

with zipfile.ZipFile(archive) as z:
    names = z.namelist()
    prefix = 'results42-staging/'
    check('carrier exact member set', len(names) == len(set(names)) == len(members) + 1 and set(names) == {prefix + e['path'] for e in members} | {prefix + 'ASSEMBLY_MANIFEST.json'})
    check('carrier complete CRC receiving', z.testzip() is None)
    check('carrier exact manifest', z.read(prefix + 'ASSEMBLY_MANIFEST.json') == mraw)
    for e in members:
        data = z.read(prefix + e['path'])
        check('carrier exact body: ' + e['path'], len(data) == e['bytes'] and sha(data) == e['sha256'] and blob(data) == e['git_blob'] and data == (ROOT / e['path']).read_bytes())
        check('carrier mode: ' + e['path'], stat.S_IMODE(z.getinfo(prefix + e['path']).external_attr >> 16) == (0o755 if e['staged_mode'] == '100755' else 0o644))

araw = archive.read_bytes()
receipt = {'schema': 'implementaudit.results42.staging-final-readback.v1',
           'status': 'ROOT_REVIEW_REQUIRED_NOT_PUBLISHED', 'authority': 'NONE',
           'verified_at': datetime.now(timezone.utc).isoformat(),
           'carrier': {'path': 'EVIDENCE_CARRIER.zip', 'bytes': len(araw), 'sha256': sha(araw), 'git_blob': blob(araw), 'members': len(members) + 1},
           'manifest': {'path': 'ASSEMBLY_MANIFEST.json', 'bytes': len(mraw), 'sha256': sha(mraw), 'git_blob': blob(mraw)},
           'payload_files': len(members), 'payload_bytes': sum(e['bytes'] for e in members),
           'exact_copied_files': len(copied), 'exact_copied_bytes': sum(e['bytes'] for e in copied.values()),
           'copy_and_nested_archive_checks': len(assembly['checks']), 'final_checks': len(assertions),
           'all_checks_passed': all(e['ok'] for e in assertions),
           'checks': assertions,
           'new_original_awards': [], 'new_host_launches': 0, 'remote_mutations': 0,
           'requires_root_finalization': True}
(ROOT / 'FINAL_READBACK.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: receipt[k] for k in ['status', 'carrier', 'manifest', 'payload_files', 'payload_bytes', 'exact_copied_files', 'exact_copied_bytes', 'copy_and_nested_archive_checks', 'final_checks', 'all_checks_passed']}, indent=2))
