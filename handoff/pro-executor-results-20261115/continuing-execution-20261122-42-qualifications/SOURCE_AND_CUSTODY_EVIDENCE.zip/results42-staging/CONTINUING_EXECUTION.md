# Results42 staging — continuing source and evidence custody

**Draft for Root inspection; not a publication, new award or closure.** This additive packet follows results41 `aa4b6dd82de308d703dc11664c2ab97ac75be1ce` and preserves results40 `54af46f70ad020e0bd97ff60902f12c8402a1859`. It carries completed source engineering, independent review, publication/readback and read-only custody work. It does not replace results41 or recover the missing original M04 award body. Whole-DG acceptance remains **0/3**.

## Original scope and prior awards stay intact

| Programme | Binding original scope and preserved frontier |
| --- | --- |
| DG16 | M1–M6 / 48 rows. Accepted M2/M4 and valid M5 scopes remain. M1/M3/M6 and complete protected readiness remain unfinished. |
| DG17 | 36 cases / 14 mutation families / 17 terminal clauses; applicable additive native Stop requirements remain binding. Every prior individual acceptance remains valid, including historical M02/M05/M07/M08/M13/M14, M09/M12, the reported issued M04 decision, and accepted P04/B02/N01 scopes. These examples are not a replacement award census. |
| DG18 | 14 numbered criteria with applicable binding requirements; 12/14 issued Root awards remain. Complete A4/A5 remain open. The historical exact-award-file accounting remains 10/14; issued A2/A7 decisions stay valid despite unrecovered original bodies. |

Integration remains the previously verified `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7` / tree `9c3913ceaa95f3f36b0377fe2dba4a302afcba89`; this assembly performs no integration, merge, release or issue closure. G132 run44888568054 stays **SPENT_NO_RETRY**; historical301 and A4-07 stay **UNKNOWN_NO_REPLAY**; queued43098152901 stays separate and untouched.

## G132: first failure, corrected source and one ordinary launch

The first immutable candidate `2afdfc7c180dc82f5af1bfbe7272e2a14d6794df` / tree `7add9fc1c05944bb6694fd284ce214ddab2d7a3d` remains **GAP-REVISE / publication HOLD**. The independent temporary-filesystem witness actually deleted a foreign pathname between the final name check and unlink, left owned replacement material behind, and obtained a false successful cleanup receipt. The exact failed source packet, reproduction code, observations and independent review remain in `evidence/g132-r1/`; no historical result was overwritten.

The corrected local candidate `31907d6ecab2d80983fdb14f64fc1b3ca9e6615e` has tree `969df99854f9ca87fda54f21585864d7a0d61a38`, sole parent retained R3 `760aaff5c478ff7354d36da186d62daba983aa49`. It removes name deletion and records replacement/partial material retention separately from the closing original-target snapshot. **Complete cleanup remains false when replacement material was allocated.** The author packet records 14 source controls, five operator controls and 143 static assertions. Independent delta review retains both boundary witnesses, six relevant supplied controls and 38 integrity assertions, with explicit false-success rejection. These are source controls, not original executions.

Root published the same reviewed tree/parent as provider commit `4ddd6403b70835339b6f55aeff9478b6d061247b`. The exact eight files, source admission and remote readback are in `evidence/g132-source-publication/`. Source-only publication does not establish full cleanup or protected readiness.

Root separately admitted the exact rebound ordinary packet `60435b151083b46d88f0d05963ce6eb36fe53afa169c33aa6909e238edbafcbf`. Its host commit is `aceeb806b4f468987b6544c41cc517a4d78777db`, tree `7a46936aaf4212e193e603f6ff9e0a07969f9c50`, sole parent published source4ddd6403. Run44979910098 was launched once, attempt1. The last included Root readback at 2026-11-22T03:17:18.817878+00:00 says `in_progress` and closes the branch-publication pending record. **No terminal host result, independent receiving or Root outcome adjudication is included here.** The unchanged oracle must preserve an adverse NSS cleanup result; no retry or reinterpretation follows from this packet. Exact operator/workflow, review, admission and publication bytes are in `evidence/g132-ordinary-operation/`.

The original NSS owner independently establishes configured-until-VM-disposal provisioning. `evidence/g132-nss-boundary/` preserves those exact original source bodies and the bounded interpretation. This is distinct from the current temporary lease's incomplete cleanup; it does not change that frozen result or prove VM disposal. New boot-scoped NSS engineering is pending outside this packet.

## DG17: actual owner and native prerequisites

`evidence/dg17-m03/` identifies the real governor/phase Smoke A/B obligations and the remaining E1 original-owner and H2 complete-operation cleanup gaps. The disabled duplicate adapter stays disabled and earns no original credit. Actual phase/mission binding and effective provenance remain unqualified.

`evidence/native-metadata/` preserves static CLI capability evidence and sanitized actual startup receipts. Installed Codex0.172.0-alpha.2 exited before initialization completed; no configuration/skill response, thread, model turn or effective identity was obtained. The supported process-local SQLite-location attempt also failed; its startup cause beyond the retained safe errors remains unqualified. These facts are separate from the selected Stop path's Windows custody requirement. Database contents, private configuration and credentials are excluded.

`evidence/dg17-p08/` preserves only stopped prospective input custody. Root's correction decision settled that diagnostic before a complete neutral mission/control/evaluator packet or actor admission existed. Status remains **UNEXECUTED_NO_CURRENT_DECISION_VALUE**, with no original P08 credit.

## DG18: exact source and diagnostic custody recovered

`evidence/dg18-source-recovery/` contains the exact historical capture, retained R2 capture, four integration test modules, three previously received product dependencies, and the literal 28-method / 52-source index. This is source custody; it does not supply every original runtime body or the missing frozen R01–R09 receiving contract. The three results41-derived product bodies are dependencies, not repeated results41 awards or new qualification.

Root additionally recovered the authentic operation06 diagnostic carrier: 391,755 bytes, SHA-256 `f4c5ef565e82c38870f0169447030b65801fd35059fc22286e4854c513cf0d1c`. All 17 payloads / 357,862 bytes were byte/hash/blob checked. Publication staging includes 13 exact safe payloads, the complete 17-member readback and a four-body exclusion inventory; the full carrier embeds private transport locators and stays in recovery custody. No excluded body was rewritten and labelled original.

That historical decision preserves run44826546712/A1's 24 successes, one exact optional skip and three errors, with 342 native samples locating the lifetime-peak crossing around method14 setup. It is a diagnostic decision, **not an A4 award**. The original packet itself records the R01–R09 contract unavailable. Current metadata confirms the separate raw ZIP reference at 1,957,965 bytes; this successor has not materialized or hashed those raw ZIP bytes through this route. It is neither claimed lost nor claimed newly received.

The genuine next gates remain the authentic R01–R09 body for full A4 receiving and actual admitted OR/C02/occurrence/N1 owner inputs for full A5. The accepted results41 compiler diagnostic, prior 893-file cold consumer and all earlier bounded awards remain unchanged. No original run or accepted family was repeated during this assembly.

## Packet handling

`ASSEMBLY_READBACK.json` binds the exact copied bytes and both original author archives. `EXCLUSIONS.md` and `PUBLICATION_SUBSET.json` identify omitted private bodies. `PENDING.json` reserves the actual host receiving/adjudication and prospective boot-NSS slots without inventing identities. Root must inspect and finalize before any results publication; this assembler grants no award or admission.
