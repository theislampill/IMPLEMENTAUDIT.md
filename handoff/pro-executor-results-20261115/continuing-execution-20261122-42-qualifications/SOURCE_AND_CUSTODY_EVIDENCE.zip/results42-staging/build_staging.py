#!/usr/bin/env python3
"""Copy an explicit evidence allowlist and receive its bytes. No source execution."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import shutil
import stat
import zipfile
from datetime import datetime, timezone

RECOVERY = Path('/workspace/scratch/75de74f83f5c/recovery')
STAGE = RECOVERY / 'results42-staging'
rows = []
checks = []
privacy = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def check(name, condition):
    checks.append({'check': name, 'ok': bool(condition)})
    if not condition:
        raise RuntimeError(name)

PATTERNS = {
    'signed_url_query': r'https?://[^\s"<>]+[?&](?:sig|signature|token|access_token|X-Amz-[^=]+)=',
    'private_key': r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
    'live_credential_shape': r'(?<![a-zA-Z0-9])(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{30,}|sk-[A-Za-z0-9_-]{30,})',
    'bearer_value': r'(?i)bearer [A-Za-z0-9+/._-]{20,}',
    'private_library_locator': r'library-file:',
    'private_page_locator': r'https://chatgpt\.com/(?:space|s)/',
    'private_download_file_id': r'file_[0-9a-f]{24,}',
}

def inspect_text(label, data):
    try:
        text = data.decode('utf-8')
    except UnicodeDecodeError:
        return
    hits = {name: len(re.findall(pattern, text)) for name, pattern in PATTERNS.items() if re.search(pattern, text)}
    if hits:
        privacy.append({'path': label, 'categories': hits})
        raise RuntimeError('Explicit sensitive pattern: ' + label + ' ' + ','.join(hits))

def add(src_rel, dst_rel, category, *, git_mode=None):
    src = RECOVERY / src_rel
    dst = STAGE / dst_rel
    check('regular source: ' + src_rel, src.is_file() and not src.is_symlink())
    data = src.read_bytes()
    if src.suffix != '.zip':
        inspect_text(src_rel, data)
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        check('existing stage exact: ' + dst_rel, dst.read_bytes() == data)
    else:
        dst.write_bytes(data)
    dst.chmod(0o755 if git_mode == '100755' else 0o644)
    check('copy readback: ' + dst_rel, dst.read_bytes() == data)
    rows.append({'path': dst_rel, 'source_path': src_rel, 'category': category,
                 'bytes': len(data), 'sha256': sha(data), 'git_blob': blob(data),
                 'copy': 'EXACT_ORIGINAL_BYTES', 'git_mode_when_bound': git_mode})

def folder(src_rel, dst_rel, category):
    for p in sorted((RECOVERY / src_rel).rglob('*')):
        if p.is_file():
            rel = p.relative_to(RECOVERY / src_rel).as_posix()
            add(src_rel + '/' + rel, dst_rel + '/' + rel, category)

archive_readback = []
for label, packet, archive, expected in [
    ('g132-r1', 'g132-successor', 'g132-host-profile-successor-source-only.zip', 'ddbde148faf3130548b5e0f1c9420ac5ae1fb752ada2311cd2cd1427b41933bf'),
    ('g132-r2', 'g132-successor-r2', 'g132-host-profile-successor-r2-source-only.zip', '8300fff9cbbcecd8722e4e9d2222f7d6b274ce8de5ed4d658606c404aca1e1f8'),
]:
    raw = (RECOVERY / archive).read_bytes()
    mraw = (RECOVERY / packet / 'PACKET_MANIFEST.json').read_bytes()
    manifest = json.loads(mraw)
    check(label + ': archive SHA', sha(raw) == expected)
    with zipfile.ZipFile(RECOVERY / archive) as z:
        names = z.namelist()
        prefix = packet + '/'
        expected_names = {prefix + e['path'] for e in manifest['files']} | {prefix + 'PACKET_MANIFEST.json'}
        check(label + ': exact ZIP members', len(names) == len(set(names)) and set(names) == expected_names)
        check(label + ': CRC complete', z.testzip() is None)
        check(label + ': manifest byte equality', z.read(prefix + 'PACKET_MANIFEST.json') == mraw)
        total = 0
        for e in manifest['files']:
            p = PurePosixPath(e['path'])
            check(label + ': safe member ' + e['path'], not p.is_absolute() and '..' not in p.parts)
            data = z.read(prefix + e['path'])
            check(label + ': payload exact ' + e['path'], len(data) == e['bytes'] and sha(data) == e['sha256'] and data == (RECOVERY / packet / e['path']).read_bytes())
            if e['path'] != 'candidate.bundle':
                inspect_text(label + '!/' + e['path'], data)
            total += len(data)
        check(label + ': total population', len(manifest['files']) == manifest['total_files'] and total == manifest['total_bytes'])
    archive_readback.append({'archive': archive, 'archive_bytes': len(raw), 'archive_sha256': sha(raw),
                             'manifest_sha256': sha(mraw), 'payload_files': len(manifest['files']),
                             'payload_bytes': total, 'zip_members': len(names), 'crc': 'PASS',
                             'all_member_bytes_and_declared_hashes': True})
    add(archive, 'evidence/' + label + '/AUTHOR_PACKET.zip', label + ': complete exact frozen author packet')
    for f in ['PACKET_MANIFEST.json', 'FINAL_RECEIPT.json']:
        add(packet + '/' + f, 'evidence/' + label + '/' + f, label + ': original author identity/receipt')

add('root/g132-source-publication/PACKET.json', 'evidence/g132-r1/SOURCE_PUBLICATION_PACKET_HOLD.json', 'g132-r1: held original source publication proposal')
for label, report, evidence in [
    ('g132-r1', 'g132-successor-review.md', 'g132-successor-review-evidence'),
    ('g132-r2', 'g132-successor-r2-review.md', 'g132-successor-r2-review-evidence'),
    ('g132-ordinary-operation', 'g132-successor-r2-operation-review.md', 'g132-successor-r2-operation-review-evidence'),
]:
    add('lanes/' + report, 'evidence/' + label + '/INDEPENDENT_REVIEW.md', label + ': exact ordinary independent advisory')
    folder('lanes/' + evidence, 'evidence/' + label + '/independent-evidence', label + ': exact independent observations/source verification')

for srcdir, destdir, extras in [
    ('root/g132-source-publication-r2', 'g132-source-publication', ['provider-commit-readback.json', 'ref-readback.json', 'branch-create-result.json', 'commit-result.json', 'tree-result.json']),
    ('root/g132-ordinary-operation-01', 'g132-ordinary-operation', ['provider-branch.json', 'provider-commit.json', 'provider-tree.json']),
]:
    for name in ['PACKET.json', 'ROOT_ADMISSION.json', 'REMOTE_READBACK.json'] + extras:
        add(srcdir + '/' + name, 'evidence/' + destdir + '/' + name, destdir + ': exact Root/provider publication evidence')
    readback = json.loads((RECOVERY / srcdir / 'REMOTE_READBACK.json').read_text())
    for e in readback['files']:
        rel = e['path']
        raw = (RECOVERY / srcdir / 'content' / rel).read_bytes()
        check(destdir + ': Root bound content ' + rel, len(raw) == e['bytes'] and sha(raw) == e['sha256'] and blob(raw) == e['git_blob_sha'] and e['remote_exact'] is True)
        add(srcdir + '/content/' + rel, 'evidence/' + destdir + '/content/' + rel, destdir + ': exact source/host byte body', git_mode=e['mode'])
    check(destdir + ': final pending closed', readback['pending_terminal'] is None)

add('lanes/g132-nss-original-boundary.md', 'evidence/g132-nss-boundary/REPORT.md', 'original NSS owner lifecycle: new read-only analysis')
folder('g132-nss-boundary', 'evidence/g132-nss-boundary/source', 'original NSS owner lifecycle: exact retained/provider source bytes')
add('lanes/m03-owner-feasibility.md', 'evidence/dg17-m03/OWNER_FEASIBILITY.md', 'M03: new original-owner feasibility, no execution')

for f in ['NATIVE_HOST_DISPOSITION.md', 'LIVE_METADATA.json', 'LIVE_METADATA_DIAG2.json', 'LIVE_METADATA_STATE_OVERRIDE.json',
          'NATIVE_STARTUP_ERROR.json', 'NATIVE_STATE_OVERRIDE_ERROR.json', 'NATIVE_READONLY_PATHS.json',
          'read-live-metadata.py', 'read-live-metadata-state.py', 'RECONNAISSANCE.md', 'CAPABILITY_MANIFEST.json', 'RECON_COMMANDS.json']:
    add('native-stop/' + f, 'evidence/native-metadata/' + f, 'native: exact allowlisted report, sanitized receipt, static capability or client source')

add('lanes/dg17-p08-preparation.md', 'evidence/dg17-p08/STOPPED_PREPARATION.md', 'P08: stopped input custody only; no current decision value, no actor packet')
folder('dg17-p08', 'evidence/dg17-p08/input-custody', 'P08: exact stopped preparation inputs; no invocation')

add('lanes/dg18-next-original.md', 'evidence/dg18-source-recovery/REPORT.md', 'DG18: new source custody and exact missing prerequisites')
folder('dg18-next', 'evidence/dg18-source-recovery/source', 'DG18: exact source bodies and 28-method/52-source index; no execution')

carrier_path = RECOVERY / 'dg18-original-custody/A4_ACTUAL_RECEIVING_AND_ROOT_PACKET.json'
carrier_raw = carrier_path.read_bytes()
carrier = json.loads(carrier_raw)
check('DG18 original carrier exact', len(carrier_raw) == 391755 and sha(carrier_raw) == 'f4c5ef565e82c38870f0169447030b65801fd35059fc22286e4854c513cf0d1c')
omitted = {
    'RAW_DURABLE_REFERENCE.json': 'explicit private Library locator',
    'independent-receiving/ORIGINAL_DOWNLOAD_RECEIPT.json': 'private download file identifier',
    'independent-receiving/REPORT.md': 'explicit private Library and Page locators',
    'independent-receiving/SEAL.json': 'explicit private Library and Page locators',
}
original_members = []
for e in carrier['files']:
    raw = e['utf8'].encode('utf-8')
    received = RECOVERY / 'dg18-original-custody/received-payloads' / e['path']
    check('DG18 original exact member ' + e['path'], raw == received.read_bytes() and len(raw) == e['bytes'] and sha(raw) == e['sha256'] and blob(raw) == e['git_blob'])
    original_members.append({k: e[k] for k in ['path', 'bytes', 'sha256', 'git_blob', 'git_mode']} | {'staged': e['path'] not in omitted, 'exclusion_reason': omitted.get(e['path'])})
    if e['path'] not in omitted:
        add('dg18-original-custody/received-payloads/' + e['path'], 'evidence/dg18-original-diagnostic/received-payloads/' + e['path'], 'DG18: exact recovered historical operation06 diagnostic payload', git_mode=e['git_mode'])
check('DG18 original full 17 population', len(original_members) == 17 and sum(e['bytes'] for e in original_members) == 357862)
check('DG18 privacy subset exactly 13', sum(e['staged'] for e in original_members) == 13)
for f in ['PAYLOAD_READBACK.json', 'RECOVERY.md']:
    add('dg18-original-custody/' + f, 'evidence/dg18-original-diagnostic/' + f, 'DG18: exact successor recovery/readback, not original raw archive receiving')

derived = {
    'schema': 'implementaudit.results42.diagnostic-carrier-publication-subset.v1',
    'record_kind': 'NEW_DERIVED_PRIVACY_SUBSET_BINDING_NOT_ORIGINAL_DECISION',
    'authority': 'NONE',
    'original_carrier': {'bytes': len(carrier_raw), 'sha256': sha(carrier_raw), 'git_blob': blob(carrier_raw), 'included': False,
                         'reason': 'Full authentic carrier embeds four explicit private locator bodies; retained in recovery custody, not rewritten.'},
    'original_payload_count': 17, 'original_payload_bytes': 357862,
    'exact_staged_payload_count': 13, 'exact_staged_payload_bytes': sum(e['bytes'] for e in original_members if e['staged']),
    'members': original_members,
    'raw_original_native_archive': {'expected_bytes': 1957965, 'expected_sha256': carrier['raw_artifact_sha256'],
                                    'successor_materialized_bytes': False, 'successor_hashed_bytes': False,
                                    'current_metadata_confirmed_by_root': True, 'metadata_is_not_byte_receiving': True},
    'R01_R09_contract_recovered': False, 'new_original_awards': []
}
(STAGE / 'evidence/dg18-original-diagnostic/PUBLICATION_SUBSET.json').write_text(json.dumps(derived, indent=2) + '\n')

record = {'schema': 'implementaudit.results42.assembly-copy-receiving.v1', 'assembler': '/root/m04_custody', 'authority': 'NONE',
          'assembled_at': datetime.now(timezone.utc).isoformat(),
          'scope': 'Inert source reads, exact byte copies, archive CRC/member/hash receiving and allowlist privacy inspection only',
          'source_executions': 0, 'model_or_original_executions': 0, 'host_launches': 0, 'remote_mutations': 0,
          'copied_files': len(rows), 'copied_bytes': sum(e['bytes'] for e in rows),
          'checks': checks, 'all_checks_passed': all(e['ok'] for e in checks),
          'author_archive_readback': archive_readback, 'sensitive_pattern_hits_in_included_text': privacy,
          'evidence': rows,
          'limitation': 'Pattern inspection is supplementary. Explicit allowlisting and omission of private runtime stores/locator bodies control publication scope. This receipt is new assembly evidence, not an original award or new hosted receiving.'}
(STAGE / 'ASSEMBLY_READBACK.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: record[k] for k in ['assembled_at', 'copied_files', 'copied_bytes', 'all_checks_passed', 'author_archive_readback']}, indent=2))
