# Results42 staging index

The packet is an inert additive assembly for Root inspection. Exact copied evidence and newly derived assembly records are distinguished in the manifest. Nothing here executes a source file or grants acceptance.

| Directory | Evidence and claim ceiling |
| --- | --- |
| `evidence/g132-r1/` | Original 33-payload author archive/manifest/receipt, held source-publication packet, independent GAP-REVISE review and real race witness. First failure stays intact. |
| `evidence/g132-r2/` | Original 35-payload author archive/manifest/receipt, independent delta review and controls. Retention is truthful incomplete cleanup; source qualification only. |
| `evidence/g132-source-publication/` | Exact eight source bodies/modes, immutable Root packet, source-only admission and authentic provider/remote readback. Provider source identity4ddd6403 has the reviewed R2 tree. |
| `evidence/g132-ordinary-operation/` | Exact two rebound host files, packet, independent review/checks, Root admission and exact host publication/readback. Launch completed once; no terminal result included. |
| `evidence/g132-nss-boundary/` | Exact original NSS/run sources and new read-only interpretation of configured-until-disposal lifecycle. No copied old host proof or new grant. |
| `evidence/dg17-m03/` | Actual owner/phase feasibility and named missing original E1/H2 prerequisites. No disabled-adapter qualification. |
| `evidence/native-metadata/` | Safe actual startup failure receipts, exact client source, earlier static reconnaissance. No thread/model/effective identity; no private stores. |
| `evidence/dg17-p08/` | Exact stopped input preparation and no-current-decision-value disposition. No complete actor/control packet or actor invocation. |
| `evidence/dg18-source-recovery/` | Exact recovered capture/test/product bodies, literal 28-method order and 52-member source census. No R01–R09 body or original rerun. |
| `evidence/dg18-original-diagnostic/` | Thirteen exact safe original op06 diagnostic payloads, complete17-member readback, recovery note and explicit four-body privacy exclusion. Historical failure/diagnostic decision only. |

`CONTINUING_EXECUTION.md` is a new draft synthesis. `PENDING.json` is a new assembly frontier, not a Root decision. `ASSEMBLY_READBACK.json` is a new copy/hash/archive receipt; it preserves source locators relative to the delegated recovery root. `EXCLUSIONS.md` defines exactly what was omitted. The final manifest and carrier readback cover their resulting bytes.

The archived author operators remain their original locally bound proposals. The later authoritative rebound operator/workflow are the separate exact bodies under `evidence/g132-ordinary-operation/content/`. R1/R2 archives are preserved unchanged; no remote commit identity is retroactively written into them.
