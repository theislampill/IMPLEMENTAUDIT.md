# Publication exclusions and evidence limits

This is a new assembly policy record, not an original decision. Only the explicit allowlist in `build_staging.py` was copied. Original evidence bodies included in this packet are byte-exact; no sanitization silently changes an original body.

## Private runtime material excluded

- Native app-server SQLite state, queues, memories, goals and logs, including all database, WAL and SHM files. No database content was read for this assembly.
- Real-home configuration/authentication bodies, raw credentials, unselected configuration values and private native logs. The packet includes only already sanitized selected errors, stream digests, empty protocol-response receipts and exact metadata-client source.
- Signed download URLs, bearer tokens, unrelated private conversation history and the M04 recovery transport metadata.
- Candidate Git index files, bytecode caches, source worktree control directories, mutable process state and unselected schema bulk. Static capability summaries are not a full re-publication of the generated CLI schema tree.

The preserved safe startup error names a relevant configuration path and ignored key; it includes no configuration value or credential body. The two stderr records with different digests are distinct original observations, not merged or normalised into a fabricated single stream. The current `read-live-metadata.py` belongs to the diagnostic follow-up output; it is not claimed as an exact unrecovered first-client revision.

## Exact original A4 carrier kept out of public staging

The authentic `A4_ACTUAL_RECEIVING_AND_ROOT_PACKET.json` is 391,755 bytes, SHA-256 `f4c5ef565e82c38870f0169447030b65801fd35059fc22286e4854c513cf0d1c`. It is retained in recovery custody but not copied into this publication packet because it embeds four bodies with explicit private transport locators:

| Original member | Exclusion reason |
| --- | --- |
| `RAW_DURABLE_REFERENCE.json` | Private Library locator |
| `independent-receiving/ORIGINAL_DOWNLOAD_RECEIPT.json` | Private download-file identifier |
| `independent-receiving/REPORT.md` | Private Library and Page locators |
| `independent-receiving/SEAL.json` | Private Library and Page locators |

`evidence/dg18-original-diagnostic/PUBLICATION_SUBSET.json` records all 17 original member sizes/hashes/blob identities, the exact 13-member included subset and the four explicit omissions. `PAYLOAD_READBACK.json` is Root's exact full-population readback. The safe issued diagnostic decision, native observations, receiver, provider observations and causal findings remain exact original bytes. An original reference to an excluded member is preserved as a reference; it is not a claim that the excluded body is present.

The separate 1,957,965-byte raw native ZIP is not included. Root checked current exact-reference metadata only; this successor did not newly materialize or hash its bytes. The expected original digest remains as recorded by the authentic historical packet.

## Deliberate scope exclusions

- The already published results41 packet and its A4 R3 carrier/award are not republished. Three exact integration product bodies previously received from that carrier appear only as dependencies of the new DG18 source-custody report/index.
- Historical M03 R2 disabled-adapter material and original award censuses remain at their existing results locators. The new M03 owner-feasibility report is included; the adapter is not enabled or qualified.
- M04 original complete-family evidence/award body remains unrecovered. No replacement decision body, reconstruction or rerun is included.
- The pending G132 ordinary host outcome, independent receiving, Root outcome adjudication and new boot-scoped NSS engineering are not fabricated or inferred from launch/source success.
- No new original award, protected grant, merge, release, issue closure or complete-DG claim is created.

Text pattern inspection found no signed URL, credential-shaped token, private key or explicit private transport locator in included evidence text, including text members of the two original author archives. This is supplementary to the explicit allowlist and manual privacy review; it is not a claim to prove the absence of every possible secret in arbitrary data.
