# Independent G132 R2 source-only delta receipt

**Disposition: RECOMMEND BOUNDED SOURCE-ONLY PUBLICATION of Root's exact packet below.**

R2 removes the destructive pathname deletions and false complete-cleanup result reproduced in the first candidate. Replacement and partial material remain explicit residuals and cannot satisfy complete cleanup. **Hosted operation, complete cleanup, protected readiness and original acceptance remain HOLD/unqualified.** Root owns publication and all acceptance authority.

## Exact binding

| Subject | Identity |
| --- | --- |
| R2 local commit | `31907d6ecab2d80983fdb14f64fc1b3ca9e6615e` |
| Reviewed tree | `969df99854f9ca87fda54f21585864d7a0d61a38` |
| Sole parent | `760aaff5c478ff7354d36da186d62daba983aa49` |
| Root packet | `/workspace/scratch/75de74f83f5c/recovery/root/g132-source-publication-r2/PACKET.json` |
| Packet identity | 3,145 bytes; SHA-256 `0c7fba6fb68be15a31cfb9faf0b3328c84590641acd286625583615354b465c0` |
| Packet operation | `G132_SOURCE_SUCCESSOR_R2_PUBLICATION_20261122_01` |
| Prospective source branch | `pro/dg16-g132-host-profile-source-20261122-01` |

All eight packet files, modes, sizes, SHA-256 values and Git blob IDs match actual immutable Git objects and working bytes. Only the NSS helper, qualifier and focused controls differ from first candidate `2afdfc7c180dc82f5af1bfbe7272e2a14d6794df`. The five other source members, profiles/origins, existing owners and limits are unchanged. Refer to the preserved R1 report for their coverage; it is not repeated here.

The author's larger R2 archive/operator packet has not been consumed and is not a prerequisite for this narrower publication. No recommendation applies to that unreviewed packet or any hosted operation.

## Independent witness and oracle results

The reviewer loaded exact R2 Git bytes and performed actual filesystem interleavings only in disposable review-owned directories.

| Control | Observed result |
| --- | --- |
| Former normal check/unlink boundary | After a successful name observation, the owned replacement was moved and foreign content created at the old name. Both files survived; original target identity/bytes were restored. Receipt: `RESTORED_REPLACEMENT_RETAINED`; cleanup refused. |
| Former partial-write cleanup boundary | A two-byte write then owned error was followed by name replacement after the last successful snapshot. Foreign and owned partial files survived; original target remained intact; write error propagated. Receipt: `REFUSED_ORIGINAL_TARGET_PRESENT_REPLACEMENT_RETAINED`; cleanup refused. |
| Ordinary exchange without name race | Original target restored; replacement retained; cleanup refused. |
| Genuine files-only/no-allocation path | No replacement allocated; local complete-cleanup control passed. |
| Three adverse receiving controls | Old false-success shape, actual retained record with a false complete flag, and retained record relabelled as closed were all refused. |

For both boundary witnesses, `cleanup_complete`, `backup_removed` and `replacement_deletion_attempted` remained false. The residual record reports that the created name no longer matches the held inode; it does not claim name exclusion or qualified namespace custody. Fixture teardown later removes only review-owned test directories.

## Source correction and remaining boundary

At R2 `scripts/hosted-files-only-nss.py` lines 78–84, schema v2 separates original-target restoration from complete cleanup. Lines 206–239 remove both deletion paths. Lines 241–258 record held residual material and the limited closing snapshot. Independent AST inspection found no deletion operation in the helper.

The qualifier's `nss_cleanup_complete` at lines 57–64 accepts only the v2, already-files-only, `NONE_ALLOCATED` result with the required true/false fields. Input-stage success at lines 222–230 requires that discriminator. Its new NSS pin matches the actual 16,301-byte helper, SHA-256 `5552e26ab04987cfe288533e973697776b1c5b7df18e521bb6c27e9c0c2316ab`.

**Every replacement-allocating path still lacks complete cleanup.** The revised tests qualify nondestructive containment and truthful refusal; they do not weaken the original cleanup oracle or turn VM disposal into cleanup proof. The no-allocation positive control supplies no evidence that the future hosted image is already files-only.

## Verification

After source inspection, six relevant changed controls ran once against the exact R2 worktree: both name-race controls, false-success/retained-oracle rejection, callback failure, partial-write retention, and genuine files-only/no-allocation. **Exit 0; six tests passed in 0.018 seconds.** Exact argv/output are retained below.

**Thirty-eight independent integrity assertions passed**, covering exact source/publication identities, the three-file delta, no helper deletion calls, dependent pin, unchanged owners/limits, preservation of all first-review/witness hashes, and clean R2 worktree. The R3-to-R2 diff check also exited 0. No broad suite, historical diagnostic, canonical/original/mutant operation or model was repeated.

## Publication disposition

Recommend only the eight-file source publication identified by packet SHA-256 `0c7fba6fb68be15a31cfb9faf0b3328c84590641acd286625583615354b465c0`, carrying its explicit retained-residual scope.

The tracked workflows are unchanged and their push triggers remain restricted to main; the proposed source branch does not match. The packet includes no operation workflow, PR or dispatch effect.

Root may receive a provider-issued commit identity different from the local engineering commit only after verifying the same tree `969df99854f9ca87fda54f21585864d7a0d61a38` and exact sole parent `760aaff5c478ff7354d36da186d62daba983aa49`. Record both identities distinctly. No remote commit has been observed or invented by this review.

The first candidate and its failed witness remain preserved. A later operation needs its own exact source/operator/workflow binding and independent review; this receipt grants no launch, complete cleanup, protected readiness, integration or original credit. Historical `44888568054` remains SPENT_NO_RETRY; historical `301…` and A4-07 remain UNKNOWN_NO_REPLAY; queued `43098152901` remains separate and untouched.

## Retained evidence

Directory: `/workspace/scratch/75de74f83f5c/recovery/lanes/g132-successor-r2-review-evidence/`.

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `independent-nss-controls.json` | 12,849 | `242b825efc599d12ef223d135a256826d4313c3e695955f1ef55220fac108806` |
| `source-integrity.json` | 5,353 | `28c3eb3b3836e579439d3372df0b82cb03168b461a6ae24a00ba20c5bd9ec803` |
| `focused-invocation.json` | 2,284 | `729aa18a62c72a6c2faaf25ee7156837f214246779a0d0e24e562d058922a96b` |

Exact reproduction/verifier code is retained alongside those files as `independent_nss_controls.py` and `verify_integrity.py`.

Preserved R1 report: `/workspace/scratch/75de74f83f5c/recovery/lanes/g132-successor-review.md`, SHA-256 `5152b41ea3eba40ca9cb5b81e07612e9fd1518b63cb729a8da88f7c42c08d5d6`. Its GAP-REVISE result and evidence are unchanged.

Independent advisory reviewer; not an author of either candidate. No source/controller/system NSS/model/host/remote mutation or original execution occurred.
