import ast,hashlib,json,pathlib,subprocess
BASE=pathlib.Path('/workspace/scratch/75de74f83f5c');REPO=BASE/'engineering/g132-host-profile-successor-r2'
COMMIT='31907d6ecab2d80983fdb14f64fc1b3ca9e6615e';FIRST='2afdfc7c180dc82f5af1bfbe7272e2a14d6794df';PARENT='760aaff5c478ff7354d36da186d62daba983aa49';TREE='969df99854f9ca87fda54f21585864d7a0d61a38'
OUT=BASE/'recovery/lanes/g132-successor-r2-review-evidence'
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
def source(f,commit=COMMIT):return git('show',commit+':'+f)
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
checks=[]
def check(name,ok,**detail):
    checks.append(dict(check=name,pass_=bool(ok),**detail))
    if not ok:raise AssertionError(name)
check('exact R2 identity',git('show','-s','--format=%H%n%T%n%P',COMMIT).decode().splitlines()==[COMMIT,TREE,PARENT])
pubpath=BASE/'recovery/root/g132-source-publication-r2/PACKET.json';pubraw=pubpath.read_bytes();pub=json.loads(pubraw)
check('exact R2 publication digest',pin(pubraw)['sha256']=='0c7fba6fb68be15a31cfb9faf0b3328c84590641acd286625583615354b465c0',**pin(pubraw))
check('publication source identities',pub['local_engineering_commit']==COMMIT and pub['source_tree']==TREE and pub['sole_parent']==PARENT and pub['hosted_operation'] is False and pub['original_operation'] is False and pub['allow_tree_equal_provider_commit'] is True)
check('publication explicit residual',pub['cleanup_residual']=='NSS replacement retained; complete-cleanup and protected-readiness admission remain closed')
delta=git('diff','--name-only',FIRST,COMMIT).decode().splitlines()
expected={'scripts/hosted-files-only-nss.py','test-support/g132-host-profile-successor/ordinary_qualifier.py','test-support/g132-host-profile-successor/test_successor.py'}
check('only commissioned three-file delta',len(delta)==3 and set(delta)==expected,paths=delta)
changed=git('diff-tree','--no-commit-id','--name-only','-r',COMMIT).decode().splitlines()
check('eight exact source publication files',len(changed)==8 and set(changed)=={r['path'] for r in pub['files']})
for row in pub['files']:
    raw=source(row['path']);entry=git('ls-tree',COMMIT,row['path']).decode().strip().split()
    check('exact commit/publication/worktree '+row['path'],pin(raw)=={k:row[k] for k in ('bytes','sha256')} and entry[0]==row['mode'] and entry[2]==row['git_blob_sha'] and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['git_blob_sha'] and (REPO/row['path']).read_bytes()==raw)
nss=ast.parse(source('scripts/hosted-files-only-nss.py'))
deletions=[{'function':n.func.attr,'line':n.lineno} for n in ast.walk(nss) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ('unlink','remove','rmdir','removedirs','rmtree')]
check('NSS helper contains no deletion operation',deletions==[],observed=deletions)
for name in ['scripts/load-work-graph-c5-executor.py','scripts/qualify-work-graph-c5-setup.py','fixtures/work-graph-c5-inputs/execution-g132-host-profile-20261122-v1.json','fixtures/work-graph-c5-inputs/genuine-g132-host-profile-20261122-v1.json','fixtures/work-graph-c5-inputs/package-g132-host-profile-20261122-v1.json','.github/workflows/pages.yml','.github/workflows/validate.yml']:
    check('unchanged from reviewed first source '+name,source(name)==source(name,FIRST))
qual='test-support/g132-host-profile-successor/ordinary_qualifier.py'
def assign(commit):
    a=ast.parse(source(qual,commit))
    return {n.targets[0].id:n.value for n in a.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
a=assign(COMMIT);old=assign(FIRST)
for field in ['BASE_COMMIT','OPERATION','REF','SETUP_PIN','LAUNCHER_PIN']:
    check('unchanged qualifier binding '+field,ast.literal_eval(a[field])==ast.literal_eval(old[field]))
check('exact new NSS pin',ast.literal_eval(a['NSS_PIN'])==pin(source('scripts/hosted-files-only-nss.py')))
check('unchanged ordinary limits',ast.dump(a['LIMITS'])==ast.dump(old['LIMITS']))
check('qualifier success uses complete cleanup discriminator',b'and nss_cleanup_complete(lease.record))' in source(qual))
old_files={
'recovery/lanes/g132-successor-review.md':'5152b41ea3eba40ca9cb5b81e07612e9fd1518b63cb729a8da88f7c42c08d5d6',
'recovery/lanes/g132-successor-review-evidence/independent_nss_controls.py':'c7711550feb973e2245a854cd6c0e348c9159b9f9d89b6b1ee3febd207a5d32b',
'recovery/lanes/g132-successor-review-evidence/independent-nss-controls.json':'a5653cb7a05f5dfeec26cac846194a744ec52158c87eb43bd82f7cd81d148b5f',
'recovery/lanes/g132-successor-review-evidence/source-integrity.json':'ca978fe50fa7bed976dc0d2ac5ab899c1afe29a128c413e3742bf48b2e754c87',
'recovery/lanes/g132-successor-review-evidence/focused-invocation.json':'8126497dbe80fc1a90313e193862682355e25dc57108fff9f549f9f55f5a8445',
'recovery/lanes/g132-successor-review-evidence/verify_integrity.py':'f77879d75a034be01630120c44fa3764839819f58a648593ba83d6a2d37f2300',
'recovery/g132-successor/PACKET_MANIFEST.json':'c95401c3d1dd75d192c1c1b6d4304e8a729274c10c4083bb2bf47e5b33419ce6'}
for name,sha in old_files.items():check('preserved first evidence '+name,pin((BASE/name).read_bytes())['sha256']==sha)
check('R2 worktree remains clean',git('status','--porcelain=v1','--untracked-files=all')==b'')
result={'schema':'g132.r2-independent-source-integrity.v1','authority':'NONE','source_commit':COMMIT,'source_tree':TREE,'sole_parent':PARENT,'first_candidate':FIRST,'publication_packet':pin(pubraw),'checks':checks,'complete_cleanup_admission':False,'hosted_operation_admission':False,'original_award':False}
p=OUT/'source-integrity.json';p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks_passed':len(checks),'evidence':str(p),**pin(p.read_bytes())},indent=2))
