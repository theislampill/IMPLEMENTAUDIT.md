import hashlib,json,os,pathlib,subprocess,tempfile,types
from unittest.mock import patch
BASE=pathlib.Path('/workspace/scratch/75de74f83f5c')
REPO=BASE/'engineering/g132-host-profile-successor-r2'
COMMIT='31907d6ecab2d80983fdb14f64fc1b3ca9e6615e'
OUT=BASE/'recovery/lanes/g132-successor-r2-review-evidence'
OUT.mkdir(exist_ok=True)
def load(path,name):
    raw=subprocess.check_output(['git','-C',str(REPO),'show',COMMIT+':'+path])
    m=types.ModuleType(name);m.__file__=str(REPO/path)
    exec(compile(raw,m.__file__,'exec'),m.__dict__)
    return m,{'path':path,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
nss,nss_pin=load('scripts/hosted-files-only-nss.py','r2_independent_nss')
driver,driver_pin=load('test-support/g132-host-profile-successor/ordinary_qualifier.py','r2_independent_qualifier')
rows=[]
def target_state(p):
    s=p.stat();raw=p.read_bytes()
    return {'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def fixture(td,only=False):
    etc=pathlib.Path(td)/'etc';etc.mkdir(mode=0o700)
    p=etc/'nsswitch.conf';p.write_bytes(b'passwd: files\ngroup: files\n' if only else b'passwd: files systemd\ngroup: files\n');p.chmod(0o644)
    return etc,p,pathlib.Path(td)/'receipt.json'
def substitute(lease):
    name=lease.backup_name
    os.rename(name,name+'.review-owned-retained',src_dir_fd=lease.parent,dst_dir_fd=lease.parent)
    fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o644,dir_fd=lease.parent)
    try:os.write(fd,b'independent foreign file\n')
    finally:os.close(fd)
def assert_receipt(record):
    assert record['schema']=='g132.hosted-files-only-nss.v2'
    assert record['cleanup_complete'] is False
    assert record['backup_removed'] is False
    assert record['replacement_deletion_attempted'] is False
    assert record['replacement_cleanup']['name_exclusion_proven'] is False
    assert record['replacement_cleanup']['remaining_namespace_qualified'] is False
    assert driver.nss_cleanup_complete(record) is False
for partial in (False,True):
    with tempfile.TemporaryDirectory(prefix='r2-partial-' if partial else 'r2-restore-',dir=OUT) as td:
        etc,target,receipt=fixture(td);opening=target_state(target)
        lease=nss.FilesOnlyNSSLease(etc,receipt,expected_uid=os.getuid(),expected_gid=os.getgid())
        real_named=lease._named;real_fstat=os.fstat;real_pwrite=os.pwrite
        injected=[];armed=[];writes=[]
        def named(name,fd):
            observed=real_named(name,fd)
            if observed and fd==lease.replacement and name==lease.backup_name and real_named('nsswitch.conf',lease.original):
                if partial and real_fstat(fd).st_size==2 and not lease.entered:
                    armed.append(True)
                elif not partial and lease.entered and not injected:
                    substitute(lease);injected.append('after_closing_name_observation_before_removed_unlink')
            return observed
        lease._named=named
        def fstat(fd):
            observed=real_fstat(fd)
            if partial and fd==lease.replacement and armed and not injected:
                substitute(lease);injected.append('after_final_partial_snapshot_before_removed_unlink')
            return observed
        def pwrite(fd,raw,offset):
            if partial and fd==lease.replacement:
                writes.append(True)
                if len(writes)==1:return real_pwrite(fd,raw[:2],offset)
                raise OSError('independent partial replacement failure')
            return real_pwrite(fd,raw,offset)
        error=None
        with patch.object(nss.os,'fstat',fstat),patch.object(nss.os,'pwrite',pwrite):
            try:
                with lease:pass
            except OSError as exc:error={'type':type(exc).__name__,'message':str(exc)}
        record=json.loads(receipt.read_bytes())
        foreign=etc/lease.backup_name;owned=etc/(lease.backup_name+'.review-owned-retained')
        assert len(injected)==1
        assert target_state(target)==opening
        assert foreign.read_bytes()==b'independent foreign file\n'
        assert owned.read_bytes()==(b'pa' if partial else b'passwd: files\ngroup: files\n')
        assert_receipt(record)
        assert record['replacement_cleanup']['name_matches_held_snapshot'] is False
        assert (error is not None)==partial
        rows.append({'case':'partial_write_name_boundary' if partial else 'closing_name_unlink_boundary','source_interleaving':injected[0],
          'original_target_restored':True,'foreign_named_file_survives':True,'owned_material_retained':True,'error':error,'receipt':record,'complete_cleanup_admitted':False})
for only in (False,True):
    with tempfile.TemporaryDirectory(prefix='r2-noop-' if only else 'r2-owned-',dir=OUT) as td:
        etc,target,receipt=fixture(td,only);opening=target_state(target)
        with nss.FilesOnlyNSSLease(etc,receipt,expected_uid=os.getuid(),expected_gid=os.getgid()):pass
        record=json.loads(receipt.read_bytes())
        assert target_state(target)==opening
        admitted=driver.nss_cleanup_complete(record)
        if only:
            assert admitted is True and record['replacement_cleanup']=={'disposition':'NONE_ALLOCATED'}
            assert sorted(p.name for p in etc.iterdir())==['nsswitch.conf']
        else:
            assert_receipt(record)
            assert (etc/record['backup_name']).exists()
        rows.append({'case':'genuine_files_only_noop' if only else 'ordinary_exchange_retains_residual','original_target_restored':True,'receipt':record,'complete_cleanup_admitted':admitted})
false_success={'schema':'g132.hosted-files-only-nss.v1','state':'RESTORED','restoration_verified':True,'backup_removed':True}
retained_record=rows[2]['receipt']
controls=[('old_false_success_shape',false_success),
 ('retained_record_false_complete_flag',dict(retained_record,cleanup_complete=True)),
 ('retained_record_false_closed_state',dict(retained_record,state='UNCHANGED_FILES_ONLY_CLOSED',cleanup_complete=True))]
for label,row in controls:
    admitted=driver.nss_cleanup_complete(row);assert admitted is False
    rows.append({'case':label,'constructed_adverse_receipt':True,'complete_cleanup_admitted':admitted})
result={'schema':'g132.r2-independent-inert-controls.v1','source_commit':COMMIT,'source_tree':'969df99854f9ca87fda54f21585864d7a0d61a38','authority':'NONE',
 'source_inputs':[nss_pin,driver_pin],'system_NSS_touched':False,'source_changed':False,'original_execution':False,'rows':rows}
p=OUT/'independent-nss-controls.json';p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'evidence':str(p),'bytes':len(p.read_bytes()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
 'observations':[{'case':r['case'],'complete_cleanup_admitted':r['complete_cleanup_admitted'],'state':r.get('receipt',{}).get('state')} for r in rows]},indent=2))
