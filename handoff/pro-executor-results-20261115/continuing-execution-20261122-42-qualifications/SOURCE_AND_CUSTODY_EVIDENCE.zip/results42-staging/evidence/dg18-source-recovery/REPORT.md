# DG18 next original step — bounded source and custody recovery

**Disposition: PARTIAL SOURCE CUSTODY RECOVERED; NO NEW ORIGINAL EXECUTION READY.** The exact 28-method capture source, historical operation06 workflow, four current integration test modules and their 52-member Git source selection can be identified without reconstructing a harness. The separate frozen A4 R01–R09 receiving contract is still unavailable. No preserved failure supports changing the product memory guard, changing the original process lifetime, or repairing an A5 accepting owner by inventing its missing inputs.

This is an ordinary read-only advisory report by `/root/g132_r4`. It carries no controller, admission, original-award or closure authority. Root rebound this delegated lane after its child-only host compaction to `refs/implementaudit/continuity-receipts/dg16-dg18-successor-20261122/G0003@3125f393780652263c6efece9ef2c1b96623dd2a`; this child read current STATE and ROADMAP separately and did not mutate the controller.

## 1. Exact scope and anchors

| Object | Identity |
| --- | --- |
| Current published results | `aa4b6dd82de308d703dc11664c2ab97ac75be1ce`, tree `41fbe720063eb24071c0c02766e5b6f4af248d37` — supplied and remotely received by Root |
| Preserved results40 parent | `54af46f70ad020e0bd97ff60902f12c8402a1859`, tree `d7d85b4fd61947479bfe7e16b63246ea5ffa7dea` |
| Integration / original product source | `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7`, tree `9c3913ceaa95f3f36b0377fe2dba4a302afcba89` |
| [Original #215](https://github.com/theislampill/IMPLEMENTAUDIT.md/issues/215) | 35,566 bytes; SHA-256 `40dbebcc34083f49a49af13e5c6ab50ffe6fbf5a99395d9594926e4668fd09f1`; updated 2026-10-23T07:25:46Z |
| [Sole normative amendment](https://github.com/theislampill/IMPLEMENTAUDIT.md/issues/215#issuecomment-5638756120) | Comment `5638756120`; 4,943 bytes; SHA-256 `3774677f6aa3ad2676d8afbded7dce277f5e561a8bf492200418a0495393caaf` |

The issue and sole comment were received through the GitHub plugin before the child boundary and their retained exact bodies were read afterward. Source reads use the exact integration or named historical host commits. The results branch contains two older product bodies: its claim and projection files are not byte-equal to integration51416. For the conclusions below, the exact integration bodies were therefore received from the already verified results41 A4 carrier, not substituted with the results checkout's product files.

No source, test, workflow, model, native measurement, original operation or diagnostic was executed. Python was used only to parse source as data, inspect ZIP members, hash bytes and write this lane's cache/report. No repository, provider or controller mutation occurred.

## 2. What the named Git artifacts actually recover

### Exact source bodies

All seven bodies below were freshly read through the GitHub plugin, saved under `recovery/dg18-next/`, and checked by recomputing their Git blob identity. The R2 body additionally matches its retained results36 byte/SHA-256 pin. These are received bytes, not recreated code.

| Body / exact locator | Bytes | SHA-256 | Git blob |
| --- | ---: | --- | --- |
| Historical operation06 capture, `f0d76746a7abbcf92888a82827ba8a8c71a4074f:handoff/pro-executor-results-20261115/dg18-a4-current-capture/capture.py` | 46,464 | `c16fd3a8d8adef7ab87a5916d45cf62d66deb89e90fe3e1031e0d1945c53e656` | `24fbfb2301a6a4d0f6a5de78a6add50f5f61712e` |
| Same host's `.github/workflows/dg18-a4-current-capture.yml` | 4,677 | `472e27306ad968087a80682285dbebdb2bbcda8b52d8252bf000145bb42f9b49` | `90be577adc1e19b14401eb167755faf5805449eb` |
| Retained R2 candidate capture, direct named Git blob | 54,727 | `821d32feeb3565650e33bb6bc2d356ca6127d91f7921857af6612bd35026bac7` | `4f3656eabb06dd611bd047813c9345a6fedc5a3c` |
| `51416b2:fixtures/canonical-state-rotation/windows_custody_test.py` | 17,370 | `9dd670dc98f55a7527d8202aab306743a6c8b2f15396d83b0c409211e2918f4b` | `2f019fa5c35a70109f79d3b10d8a4ce21e05d853` |
| Same integration: `ref_group_test.py` | 6,229 | `6bcde45ba1a086031ccec3461bb099fe684fbb4f9b3c87f0698fe393cdc5beda` | `cf57bc9b17928d4a34d423b932f92e7e9f97844f` |
| Same integration: `archive_v2_test.py` | 28,326 | `32c6a9cabac472adc98e58c59f40fb15b3c3f07c147ac6728d0e46eea16e427b` | `3b4d52c7f998b28e5e7376a875d6ff97b1235567` |
| Same integration: `claim_transaction_test.py` | 103,466 | `f489cde6280ece2636be5157644d83423b293f9cf5ab399e8e170583de7e9abd` | `ce6e41cd79b57747416080a8dd3cc373249d87b2` |

The retained R2 locator comes from results36 `EVIDENCE_CARRIER.zip!a4-native-receiving/INPUT_EVIDENCE_INDEX.json` and `!a4-source/SOURCE_PINS.json`. The results36 carrier manifest binds archive SHA-256 `2b4af66c2118da9b36c98f1e0596880c00b25f98e36fd21c8e69b9649c50122f`. The named R2 body is not directly included as a carrier member; its actual Git blob is now received separately. It embeds the historical `...20261120-07` branch identity. Receiving the immutable blob does **not** reconcile, cancel, authorize or replay A4-07.

Data-only AST parsing established that operation06 and retained R2 have exactly the same literal 28-method order, and that every method exists in its named integration module. The order comprises 11 WindowsCustody, 7 GitObjectCustody, 7 RefGroup, 2 ArchiveQualification and 1 CompleteOwnerDiscriminators methods. The complete literal order is preserved in `RECOVERED_28_SOURCE_INDEX.json`, not replaced by a new selector.

That same index applies the capture's exact source-census selection to the integration Git tree and records all **52** selected paths, modes and blob IDs. This recovers the original declared source population. It is a tree-membership inventory: this lane did not claim to have independently materialized and received all 52 physical bodies, the actual host executables, all original runtime streams, or the missing normative contract.

### Frozen historical invocation and oracle

The recovered operation06 workflow is first-creation push only, exact branch `pro/dg18-a4-current-51416-20261120-06`, attempt1, Windows2022, physical CPython3.12.10 x64. Its capture hash is fixed in the workflow. It checks out the exact integration product commit and its sole-parent host packet separately. This is historical source custody, not a reusable current grant.

The source-defined worker vector is:

```text
C:\hostedtoolcache\windows\Python\3.12.10\x64\python.exe
-I -B <exact capture.py> --step worker --source <exact qualified-source> --output <run-bound output>
```

The actual absolute host path arguments belong to the original EXECUTE_INTENT; the workflow and source alone are not a replacement for that executed record. `worker` imports the four modules in first-occurrence order, constructs one unittest suite in the literal 28-method order, and runs it in **one worker interpreter**. Each test's original setup, assertions and teardown/cleanup are delegated. For the final method, `CompleteOwnerDiscriminators.setUp` aliases `RealHelperIntegration.setUp`, which constructs the actual fixture, imports its claim owner, enters its directory and establishes its original receipt; it is not an empty setup.

`receive_outcomes` requires complete, nonduplicated method population and success except the one exact short-alias skip reason, which earns no alias attack credit. Failed subtests, errors, changed source/tool census, remaining processes and unexpected fixture residue are retained/refused. The Job receiver requires suspended start, assignment before resume, completion-port accounting, positive reconciled total/create/exit population, selected image identity and terminal zero with no breakaway. It does not impose a universal one-process population.

The workflow's 20-minute host timeout and capture's 600-second diagnostic timeout are observation/containment limits. They are not the original full-operation performance oracle. Issue215 retains the prospective **60,000 ms / 201,326,592-byte aggregate Job committed-memory** envelope where applicable, zero subtraction and all original security/test deadlines. The product's **67,108,864-byte process-lifetime peak** guard is a separate unchanged check. Fresh per-method interpreters would change that measured lifetime and shared import/cache/audit-hook state; identical test names do not establish equivalence.

### What is still not recovered

1. **Frozen R01–R09:** original body, exact row wording, mode, byte length, SHA-256 and authentic custody/source locator remain unavailable. Results25's `A4_CONTRACT_RECOVERY_RESULT.json`, results35's `A4_FROZEN_CONTRACT_RECOVERY.md`, results40 and results41 all preserve this missing-body boundary. The retained R2 source itself says the frozen contract is unavailable. The 28 test methods are not the R01–R09 receiving rules.
2. **Full original runtime evidence in this lane:** results25 preserves the actual operation06 raw artifact identity: 1,957,965 bytes, SHA-256 `d1e6fe87bed955906d6a79736de2fcd1bd69cca9063ccf70bb60b5ade38ea133`, calculated Git blob `0b1908e9f57cb909e33254e3bc6b9714fb43dc83`. One exact GitHub Git-blob GET returned **404**. This does not prove loss elsewhere. `RAW_DURABLE_REFERENCE.json` provides a named existing Library/Page locator; `COMPLETE_RECEIVING_PACKET_REFERENCE.json` separately names the 391,755-byte complete receiving/Root packet, SHA-256 `f4c5ef565e82c38870f0169447030b65801fd35059fc22286e4854c513cf0d1c`. This lane did not browse private history or repeat the prior full receiving operation.
3. **Issue215 October22 originals:** the unchanged issue names `R0039_OCT22_OWNER_RETURN.md` / `486266effef8dac8a76cbac52cde417e1238226aaea8ef79fff3af420aff48b5`, `R0039_OCT22_MANIFEST.json` / `ae7936326961dc4a5571392e4f0e9fa8f757a1289ef9f0ffb40654bfe64008a1`, and `R0039_OCT22_EVIDENCE.zip` / `664dddca0433bab9dba941a12001f940bc80eb83cfaa0d76d7c7645dc84f943a`. The previously received four-named-tree/default-index search found no bodies or new locator. This lane did not repeat that exhausted search or treat those hashes as recovered contents.

**Answer to the custody question:** authentic source and invocation for the 28-method operation are recoverable from the named Git artifacts, and the key bodies are now in this lane's cache. A complete frozen original A4 acceptance packet has not been recovered. Neither the R01–R09 contract nor all original runtime evidence is supplied merely by recovering the capture source.

## 3. Preserved failing evidence and the remaining discriminator

Results25's independent receiving and Root diagnostic decision preserve run `44826546712`, attempt1, job `136600491721`, host `f0d76746a7abbcf92888a82827ba8a8c71a4074f`, worker8168: 24 SUCCESS, one exact optional SKIP, three ERROR. The first observed lifetime-peak crossing was around **method14, GitObjectCustody.test_wrong_type_and_size_are_refused._callSetUp**, between samples144 and145: 65,744,896 → 67,588,096 bytes. Later archive/owner methods correctly refused the already-exceeded guard. Maximum sampled current working set was 58,462,208 bytes, a different metric.

The exact setup creates its temporary repository, freshly loads `claim-run-rotation.py` and `canonical_custody.py`, selects Git/environment and runs `git init -q`. The claim owner re-compiles its held physical source in `_capture_claim_load_identity_v1` and compares that code with the actually executing module. That check protects source-instance identity; substituting a disk hash or caching module state would change its meaning.

The exact integration claim body is 291,693 bytes, SHA-256 `9eebc5d5e57b47b0e4b4a2a846de1c0b55407713e14008a6de4d01e7a8c5e19e`; projection is 129,959 bytes, SHA-256 `86a9a2a8501aea60f1e333c421e25b19d4e9758a121296fedfa881185de0a5fd`. These were recovered from results41's already independently received carrier. The 64 MiB lifetime guard remains in `rotate-canonical-state.py::_check_memory_budget`, reading `canonical_custody.py::peak_process_memory` on Windows.

Current results41 accepts run `44969346074`/attempt1 at host `d258984cb3dad509b07623e797a1669ff4136f00` only as a bounded authentic compiler diagnostic. Its last retained working-set peaks were native44,703,744 and reuse44,855,296 bytes: reuse was151,552 higher. Its worker Job committed-memory values are another metric and exclude the coordinator. It compiled exact bodies without executing product or original tests; it did not invoke the original guard or measure the complete 28-method population. The public carrier is 612,532 bytes, SHA-256 `de853a8cb8c315f5b1ea0c6c7718b2c18685ec48de0798cb8473b685153a1eb2`.

**No concrete product-owner repair is presently justified by these observations.** The demonstrated fact is the correct refusal of an exceeded lifetime peak. The unresolved causal discriminator is the allocation producing the peak inside the actual method14 setup, including its accumulated interpreter state and observation overhead. The compiler-only R3 result does not identify that allocation and does not prove a memory reduction for the original workload. Its functional compiler/audit controls must remain accepted at their bounded scope; another unchanged compile-only run or original rerun is not a new answer.

If Root later has an admitted new causal observation, its question must be this precise unresolved setup allocation/equivalence issue, with exact original source, lifecycle and guards preserved. This report does not admit or commission that execution, a replacement harness, a process split, GC, case reorder, threshold increase or baseline subtraction.

## 4. Full A5: actual owners and exact missing inputs

The results28 `A5_CURRENT_COLD_AND_N01_RESULT.json` preserves the accepted **current51416 read-only consumer and fresh complete cold-preservation scope**: 893 frozen input files /24,822,358 bytes, including782 historical payloads /21,227,415 bytes. Root's exact decision SHA-256 is `983586be7e52d6f7ab601e755a3d9d97b61716249a4c632c756adc73e391e21a`. Full A5 is explicitly false. CE026 is the declared immutable captured-pending consumer; CE058 is current-run-turn source/nonterminal preservation, not a present native governor yield. These accepting scopes should not be rerun.

| Requirement | Existing owner / accepting source | Input still absent or unqualified |
| --- | --- | --- |
| Authentic OR: bytes, tokens, context health | `rotate-canonical-state.py::check_rotation_observation_v1`, `rotation_trigger_v1`, `rotation_payoff_v1`; fixed `canonical_rotation_inputs.py::_resolve_existing_owner_v1` → claim `_resolve_native_input_state_v1`; existing connection/source owner and claim publisher | Actual admitted issuer/grant, exact producer and semantic contract, effective host/config/model, exact source population, tokenizer/version/encoding, original live observation and source cutoff/freshness, quiescent/exclusive stream custody and accepted source/grant revision. Parsing retained JSON, current UI estimates, pure OR controls or emulated-canary labels do not supply them. |
| Cost/payoff | Existing calibration/input owner and COST_CONSUMER; accepting rotation route | Applicable authenticated token measurement and minimum payoff plus complete native whole-operation cost. The issue requires all OR boundaries/nontriggers and unauthenticated/foreign/unknown/stale/future refusal. A lower compiler peak is not payoff or W-FULL evidence. |
| C02 append-only correction | CONTINUITY_ADJUDICATION_OWNER; existing selected census/source owner; claim sole writer. Exact claim `_resolve_c02_materializer_capabilities_v1`, `_resolve_c02_source_owner_v1`, accepting append/fresh-transition paths | Actual eligible erroneous event, complete ordered later-boundary census, entitled issuer/decision and exact grants, expected-old pointer/receipt/permanent-marker, claim/run tuple, source/issuer revisions and compatible accepting adapter. Default `_C02_ADMITTED_OWNER_SELECTION_V1 = None` and absent selected capability remain deliberate refusal, not a defect to bypass. |
| Occurrence/current/prior/retry | Existing entitled R0033/continuity source-version consumers, including pending `operate` JOIN and `apply_covered_versions` | Actual original/current/prior/retry physical/source/cutoff/reservation/result/accepted-consumption facts and actual fixed selection. A later installed copy or matching copied command cannot be admitted as the original occurrence. |
| Complete amended cold meaning | R0039 deterministic projection/pair readers plus independent nonauthoring cold receiver | Preserve all actual pending/unknown/failed/reserved/uncovered duties, mandatory completed-compaction audit execution despite unresolved currentness or null epoch, and distinguish TC06 continuing duties from TC11 historical validity. The accepted893-file scope is retained; it does not mint missing native/owner facts. |
| Historical N1 | Existing continuity/R0033 custodian and original pending/occurrence owner | Historical mandatory LOST/UNKNOWN remains. The complete recovered descriptor is not the actual native file, fixed accepting selection, assignment-bearing pending-store body or consumption witness. No replay, invented compaction or new pending store is eligible. |

The exact integration `canonical_rotation_inputs.py` blob is `f027992d84097e8e58552e3467c5fe4c8e88a7a1`, 27,916 bytes, SHA-256 `dc95d31e4a1fabb922013fe4b1da051ba5ec6194f12a5ca0eb02a6eef1637d76`. Its parser explicitly separates exact raw usage from authentication. The claim's durable receiver preserves source/grant heads, original clocks, reservation and CLAIMED state; it does not restamp an old observation into freshness. The C02 materializer explicitly requires a complete ordered native interval and scoped issuer lease. `propose_c02_correction_v1` remains pure and confers no effect authority.

The original-owner recovery report already recovered the historical H0 receipt (25,187 bytes, SHA-256 `7a52b919750f303b5c46e281691a4186262ed17e21f2941012ba52ab00cc5580`) and its separate H002/H005 cold-preservation award. It leaves full AC05 false. N1's surviving second boundary is `boundary-162f88f4b5482b1970418ee6b35c4f0f2e05420c7449b4e390fac781e1de1648`, scope `45de02cb680f2bcfdd8e0de243c9f95df28a3f598b48de478f3c7a66f5f72180`, cutoff109411, physical descriptor `native/H0-rollout.jsonl` /offset86181 /ordinal61 /length10918, recordSHA-256 `9eb28c3c0ad0056bb024a4e66b8f31915951ef524880cca79565c983993f2b90`. Its reservation/result/consumption were RESERVED/PENDING/PENDING, accepted witness null, covered boundaries empty, currentness unresolved and epoch null. This is a literal preserved descriptor, not a reconstructed accepting record.

That same report preserves C02 startup run42329568359's authentic `ADAPTER / WORKFLOW_ARGUMENTS / UNEXPECTED_EXCEPTION`, native NOT_DISPATCHED and consumed preparation-only grant. That failure supplies no C02 append entitlement and is not a candidate for replay. None of this lane's reads establishes a newly eligible live OR or C02 subject.

## 5. Smallest next action for Root

**Use the recovered source inventory now; do not dispatch another original or generic diagnostic run.** This lane completed the useful available source-custody recovery rather than asking someone to recreate a 28-method harness.

The next original-A4 readiness dependency is one precise custody delivery: the **pre-existing frozen R01–R09 contract body and its authentic original locator/hash/mode** from a genuinely new retained source. After receiving it, Root can compare its actual requirements with the recovered source, lifecycle, invocation, oracle and evidence gaps. The original raw operation06 artifact has an exact existing durable locator if complete old receiving bytes are needed; retrieving that named object would be evidence recovery, not a rerun, but it still would not supply R01–R09 unless the authentic body is actually present.

The next full-A5 work is likewise an actual-owner input delivery or admission, chosen by a concrete newly available owner record: authentic OR source/issuer/current observation, or a genuine entitled C02 event plus complete census. No such new record was found here. Re-running the accepted893-file cold consumer, changing a fixed selection to caller data, synthesizing an issuer/grant, or replaying N1 cannot advance the original requirement.

**Source / results / readiness / award stay separate:** source bodies and exact method population are recovered; preserved results and bounded R3 receiving remain accepted at their existing scopes; complete new original readiness is absent; original A4/A5 and whole-DG18 acceptance remain withheld. DG18 remains the preserved12/14 numbered Root awards, with10/14 exact original award-file bodies at the historical accounting scope; A2/A7 issued decisions remain preserved despite unrecovered original bodies. No new award follows from this report.

## Evidence locators and local outputs

All repository references above are under `/workspace/scratch/75de74f83f5c/implementaudit/handoff/pro-executor-results-20261115/`:

- `original-acceptance/dg18/ACTUAL_RECEIVING.md` — original-owner recovery, bounded searches, H0/N1/C02 supplements.
- `continuing-execution-20261120-25/A4_CONTRACT_RECOVERY_RESULT.json`, `causal-finding/REPORT.md`, `DG18_A4_ROOT_DIAGNOSTIC_DECISION.json`, `RAW_DURABLE_REFERENCE.json`, `COMPLETE_RECEIVING_PACKET_REFERENCE.json`.
- `continuing-execution-20261121-28/A5_CURRENT_COLD_AND_N01_RESULT.json`.
- `continuing-execution-20261121-35/A4_FROZEN_CONTRACT_RECOVERY.md`.
- `continuing-execution-20261121-36/A4_NATIVE_FAILURE_RECEIVING.md` and named carrier source/index members.
- `continuing-execution-20261121-39/OWNER_TECHNICAL_INPUT_ASSESSMENT.md`.
- `continuing-execution-20261121-40/CONTINUING_EXECUTION.md` and `OWNER_TECHNICAL_INPUT_ASSESSMENT.md`.
- `continuing-execution-20261122-41-succession/A4_R3_ROOT_ADJUDICATION.json`, `A4_R3_INDEPENDENT_RECEIVING.md`, `A4_R3_RECEIVED_EVIDENCE.zip`, `CONTINUING_EXECUTION.md`.

New lane cache: `/workspace/scratch/75de74f83f5c/recovery/dg18-next/`: seven fresh source bodies, three exact product bodies received from results41, `SOURCE_LOCATORS.json`, `RECOVERED_28_SOURCE_INDEX.json`, and `READ_ONLY_RECOVERY_MANIFEST.json`. No files in the candidate/source/results repository were changed. No automatic or manual replay was issued; A4-07 remains UNKNOWN_NO_REPLAY.
