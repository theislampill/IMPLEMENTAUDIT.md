# G132 NSS: original obligation versus ordinary setup cleanup

**Conclusion: the R2 lease's complete-cleanup discriminator is an ordinary preparation contract, not an additional original G132 acceptance obligation.** The retained replacement is a real, separately scoped host-setup residual. It must remain visible and must continue to fail the present lease's complete-cleanup claim. It need not be promoted into a requirement that every original G132 host preparation remove all administrative state before VM disposal.

There is direct original NSS-owner evidence for a boot-scoped lifecycle, not merely an analogy to AppArmor. A separately reviewed prospective NSS provisioning lifecycle can therefore be eligible ordinary engineering under Root's existing commission while preserving the original predicate and custody obligations. This report neither admits that implementation nor approves any hosted/protected execution.

## Decisive original evidence

The previously reviewed protected request at results22 binds host `b393a9057c249335e6cdf4ccbb898d192b0830b8`, operation `G132_ORIGINAL_20261120_01`, and the unchanged original episode. Its Root adjudication `ROOT_REQUEST_READY_ADJUDICATION.json` says no unresolved preparation defect remained at that historical cutoff, with future live premises and a separate owner grant still mandatory. The later actual failure decision preserves the operation as spent and expressly authorizes ordinary diagnosis/source repair at a separate scope. Those records do not grant this successor a protected launch.

Fresh GitHub reads at that **exact historical host commit** supplied:

| Original source | Bytes | SHA-256 / Git blob |
| --- | ---: | --- |
| [qualification/dg16-r5-g1-hosted-episode/nss_configuration.py](https://github.com/theislampill/IMPLEMENTAUDIT.md/blob/b393a9057c249335e6cdf4ccbb898d192b0830b8/qualification/dg16-r5-g1-hosted-episode/nss_configuration.py) | 14,718 | `7243b9a13f9597059d57f22e1cfd4b344a7fd0cee930e9f9d032eee6e9e42270` / `67fd80bfdec2478f73f11452ffe38cd60fa30b96` |
| [qualification/dg16-r5-g1-hosted-episode/run.py](https://github.com/theislampill/IMPLEMENTAUDIT.md/blob/b393a9057c249335e6cdf4ccbb898d192b0830b8/qualification/dg16-r5-g1-hosted-episode/run.py) | 162,161 | `255a88d346f9286c27cffb7ad2de4ba8e4e9972eb188a6ade286bc7dfa68a7cd` / `0bc1e960dd40c32f90dac8ffd6d6b528cdfb5a36` |

The NSS body is byte-for-byte identical to the original retained in results15's `archives/g132-current-public-source.tar.xz`, member `g132-actual-candidate-source-received-20261119/dependencies/installation/phase/tree/qualification/dg16-r5-g1-hosted-episode/nss_configuration.py`. These reads execute no historical operation.

The exact owner clauses establish:

- `nss_configuration.prepare` declares `EXACT_EPHEMERAL_G1_VM_CONFIGURATION_BEFORE_CONTROLLER` and `RETAIN_CONFIGURED_FILE_UNTIL_VM_DISPOSAL`. It preserves the original preimage privately, permits only its exact pinned passwd-row transformation, journals uncertain replacement and refuses replay.
- `verify_configured` requires the actual current target to equal the configured postimage and original physical binding. Its returned disposition remains `RETAIN_CONFIGURED_FILE_UNTIL_VM_DISPOSAL`.
- `public_state` requires that disposition as part of its exact schema. A successful configuration requires `temporary_created=true` and `temporary_removed=false`; it is not a restoration receipt.
- Original `run.py::configure_actual_nss` requires no run root, no receipt and no previous attempt. `check_actual_nss` checks the same durable journal and current configured target.
- Original finalization stops owned children and requires their closing custody, then verifies the **configured** NSS state. Its `NSS.json` retains the configured-until-disposal disposition. Its separate `CLEANUP.json` reports child reaping, policy observation, source/runtime identity and private-output limits. It does not impose original NSS rollback or deletion of every host-setup artifact.

These are original selected-source lifecycle semantics. They do not prove that the spent run reached NSS preparation; its retained early host refusal remains unchanged.

## Classification of the obligations

| Predicate or claim | Correct scope |
| --- | --- |
| Actual passwd NSS must be files-only, with supported file custody and account/NSCD observations | **Original product/provider requirement.** `work-graph-c5-provider-inputs.py::_validate_nss` requires exactly one passwd service list equal to `['files']`, along with its other unchanged checks. |
| Original preparation occurs before controller/G1 acquisition; exact journal/postimage remains current through final readback | **Original selected host-operation requirement.** The original owner retains configured NSS until VM disposal. |
| R2 lease restores its original target and has no allocated replacement remaining | **New ordinary temporary-preparation promise.** The current qualifier may truthfully refuse this complete-cleanup scope. |
| R2 retains a replacement after a closing original-target snapshot | **Real host-setup residual.** It is not deletion, proved namespace exclusion, complete cleanup or observed VM disposal. |
| Owned children, channels, descriptors, retained inputs, source/runtime guards and uncertainty are correctly finalized | **Original custody/cleanup obligations remain.** VM disposal cannot substitute for the required live child/reaping/descriptor evidence. |
| A later whole-VM disposal removes retained administrative state | **Lifecycle endpoint requiring its own evidence if claimed.** A configured disposition is not proof that disposal occurred. |

The newly strict check is traceable to the successor itself. At local R2 commit `31907d6ecab2d80983fdb14f64fc1b3ca9e6615e`, tree `969df99854f9ca87fda54f21585864d7a0d61a38`:

- `scripts/hosted-files-only-nss.py`, 16,301 bytes, SHA-256 `5552e26ab04987cfe288533e973697776b1c5b7df18e521bb6c27e9c0c2316ab`, separates `CLOSING_ORIGINAL_TARGET_SNAPSHOT_ONLY` from cleanup and records `NO_DELETION_VM_DISPOSAL_REQUIRED`.
- `test-support/g132-host-profile-successor/ordinary_qualifier.py::nss_cleanup_complete`, in a 14,021-byte file with SHA-256 `e316224f5492241b529161d37b4dbce5c63f6cfc038d0c750db82aae3de13a8e`, accepts only the already-files-only `NONE_ALLOCATED` path. The first candidate had no such function; it required restoration and its old closing states.

Thus this specific all-or-nothing discriminator is not inherited unchanged from the original G132 acceptance packet. It is nevertheless binding on the **current R2 qualifier's advertised complete result** and must not be silently bypassed or relabelled.

## Comparison with existing setup ownership

The established setup owner `qualify-work-graph-c5-setup.py::finalize_hosted_bwrap_policy` is explicitly read/record only: no label unload or receipt unlink, with disposal as the job-local policy's teardown boundary. Results33's `G132_CONTAINMENT_ROOT_RESULT.json` accepts the actual retained-policy observation while explicitly recording **VM disposal NOT_OBSERVED** and separately accepting child cleanup/descriptor restoration. Launcher provisioning likewise leaves the exclusively created pinned launcher in place; it closes its owned descriptors rather than uninstalling the binary.

This supports a general separation of provisioning lifetime and process cleanup. The original NSS owner above supplies the decisive NSS-specific evidence.

[Original #209](https://github.com/theislampill/IMPLEMENTAUDIT.md/issues/209), exact body SHA-256 `6605343572b2a3ad62c4b0392703ccfdea2b1280f50a669348734a6dca60d097`, requires each lane's cleanup/resource identity and excludes unresolved acceptance, authority, reversibility or custody boundaries from READY. It does not define cleanup as global host reversion. Its equivalence amendment and retained original request preserve exact original population, inputs, source, observations and acceptance. A new helper's stricter local promise cannot add an original denominator obligation by implication.

My earlier recovery report's recommendation to qualify rollback, cleanup and closing readback described the proposed temporary-preparation design. It did not establish a new original requirement. Likewise, source-review references to the “old complete-cleanup requirement” preserve the candidate's failed claim; they are not evidence that original G132 required NSS rollback and removal of every replacement.

## What Root may consider next

**Eligible ordinary engineering:** separately define and independently review an exact boot-scoped NSS provisioning/receiving lifecycle through the existing setup owner, with truthful retained-state reporting. The original selected host already uses that lifecycle. Doing so does not, by itself, amend the original G132 acceptance obligation.

Eligibility is not present implementation readiness. The old owner pins a 526-byte preimage and 518-byte postimage; those facts cannot be assumed for today's image. Its implementation is lifecycle evidence, not blanket safety approval or permission to copy its name-based cleanup code. A prospective source must receive actual finite inputs, preserve supported custody/unknown-effect refusal, establish its declared lifecycle and keep retained state visible. It must not pretend the current R2 lease's incomplete cleanup became complete.

An **owner-only contract decision** would be needed to waive or reinterpret an original predicate, lower its evidence burden, accept unproved custody as complete, move an original cleanup duty to VM disposal, or change the protected operation/permission boundary. The narrower choice of an independently reviewed administrative lifetime already present in original NSS source does not require inventing such an amendment. Root still owns exact scope/source admission; any future protected operation still needs complete fresh readiness and the separately explicit grant.

No namespace/harness redesign, source edit, test, workflow, host setup, protected action or replay was performed here. This report grants no authority or readiness. Run44888568054 remains SPENT_NO_RETRY; historical301 and A4-07 remain UNKNOWN_NO_REPLAY; queued43098152901 remains untouched. Root's supplied G0003 binding is unchanged.

## Retained decision references

All relative paths below are under `handoff/pro-executor-results-20261115/` in the current results checkout:

- `continuing-execution-20261120-22/ROOT_REQUEST_READY_ADJUDICATION.json` and `PROTECTED_OPERATION_REQUEST_UNISSUED.json`.
- `continuing-execution-20261121-29/G132_ORIGINAL_20261120_01_ROOT_RESULT.json`: genuine spent failure; complete native cleanup unestablished for that operation; separate ordinary source repair remains allowed.
- `continuing-execution-20261121-33/G132_CONTAINMENT_ROOT_RESULT.json`: actual policy retention, child cleanup and unobserved disposal remain distinct.
- `continuing-execution-20261121-40/G132_ROOT_ADJUDICATION.json`: bounded selected-source qualification only; NSS/launcher/native/private/sender prerequisites remain unqualified.
- Current R2 source-only review: `/workspace/scratch/75de74f83f5c/recovery/lanes/g132-successor-r2-review.md`.

Exact original NSS/run source cache: `/workspace/scratch/75de74f83f5c/recovery/g132-nss-boundary/`. Source bodies were read as data only. The source interpretation above does not transfer old host proof to a new boot or revise any historical result.
