# Independent G132 successor source review

**Disposition: GAP-REVISE. Source publication and hosted-operation recommendation remain HOLD.**

One independently reproduced source defect prevents cleanup qualification: the NSS helper can delete a foreign replacement of its backup pathname and still report successful restoration and backup removal. The source and publication packets otherwise match their frozen identities. This review is ordinary independent advisory receiving, not an internal `audit-assess` route and not an authority, original award or execution grant.

## 1. Reviewed identities and limits

| Subject | Exact identity |
| --- | --- |
| Immutable engineering commit | `2afdfc7c180dc82f5af1bfbe7272e2a14d6794df` |
| Source tree | `7add9fc1c05944bb6694fd284ce214ddab2d7a3d` |
| Sole parent | Retained R3 `760aaff5c478ff7354d36da186d62daba983aa49` |
| Parent tree | `f85b199c89e9f6938382ec5f7b2005f54acc8536` |
| Reviewed worktree | `/workspace/scratch/75de74f83f5c/engineering/g132-host-profile-successor` |
| Author packet manifest | `recovery/g132-successor/PACKET_MANIFEST.json`; 5,989 bytes; SHA-256 `c95401c3d1dd75d192c1c1b6d4304e8a729274c10c4083bb2bf47e5b33419ce6` |
| Author archive | `recovery/g132-host-profile-successor-source-only.zip`; 148,352 bytes; SHA-256 `ddbde148faf3130548b5e0f1c9420ac5ae1fb752ada2311cd2cd1427b41933bf` |
| Root source-publication packet | `recovery/root/g132-source-publication/PACKET.json`; 2,879 bytes; SHA-256 `ead2059cad28b00300cf4d39e47c71291f2c66c7d5cd98d2ec6ea37fab05d518` |

All relative paths in this report are under `/workspace/scratch/75de74f83f5c`. Source line anchors refer to the immutable commit above, even if the author later changes the worktree.

The review read actual Git commit bytes and the eight-file delta. It did not use the author's PASS claims as proof. It independently checked the exact manifest payloads, archive contents, source origins, preservation properties and focused execution described below.

No source, controller, real NSS, system package, launcher, AppArmor policy, model, hosted workflow, private input, original session or remote ref was changed or invoked. Review writes are confined to this report and `recovery/lanes/g132-successor-review-evidence/`.

Historical `44888568054` remains **SPENT_NO_RETRY**; historical `301…` and A4-07 remain **UNKNOWN_NO_REPLAY**; queued `43098152901` remains separately identified and untouched.

## 2. Blocking finding R1 — unowned deletion followed by false cleanup success

**Owner:** `scripts/hosted-files-only-nss.py`, primarily lines 232–242. The earlier pre-exchange partial cleanup at lines 204–220 also uses a check followed by pathname unlink and deserves the same corrected ownership discriminator.

**Problem.** The normal restore path checks that the backup name resolves to the held replacement inode, then calls `os.unlink(self.backup_name, dir_fd=self.parent)`. The check and unlink are separate filesystem operations. Holding the inode descriptor and an advisory flock on the original NSS file does not make a pathname unlink conditional on the checked inode.

After the unlink, the success path validates the restored original NSS file. It does not verify that the held replacement was actually unlinked. It derives `backup_removed` solely from whether `backup_name` was assigned.

**Independent discriminator.** In a disposable review-owned directory, the exact candidate helper performed its genuine exchange and restore. At the boundary after both closing `_named` checks and before the actual unlink, a deterministic test interleaving:

1. Renamed the owned replacement from the backup name to another name in that disposable directory.
2. Created a different file at the original backup name.
3. Allowed the candidate's real `os.unlink` call to proceed.

The foreign file was deleted. The original owned replacement remained under its moved name. The helper returned normally and recorded all of:

```json
{
  "state": "RESTORED",
  "restoration_verified": true,
  "backup_removed": true
}
```

The original `nsswitch.conf` was restored; that correct sub-result does not establish complete cleanup or authorize deleting the foreign file. This is a concrete source discriminator using actual temporary filesystem operations, not a claim that a foreign writer was observed on the hosted image.

**Impact.** The proposed ordinary receiving oracle requires verified restoration and actual removal of the owned temporary backup. This witness satisfies the helper's success record while violating that requirement and the helper's stated foreign-drift protection. The existing active-content-drift test does not cover a name replacement at the check/use boundary.

**Required correction.** Keep the original restoration and no-unowned-deletion obligations. Make the name-custody/removal operation safe under the explicitly supported ownership model, and prove the held owned replacement was actually removed before recording cleanup success. Repeating the last pathname check or changing the witness to accept a successful record with a retained owned backup does not resolve the defect. Any change to the supported custody model must be explicit and independently reviewed; this review does not authorize a new supervisor or broader architecture.

The author should preserve this first witness and add a discriminator for both the normal restore deletion and partial-replacement cleanup path. The corrected source, helper pins, qualifier pins, operation pins and all dependent packet identities require a new freeze.

## 3. Other NSS observations and their scope

The source was inspected for original-file opening, bounded reads, parent custody, file kind/mode/uid/gid/link count, metadata, finite transformation, exclusive replacement, atomic exchange, restoration and exception handling.

The existing positive design is narrow: only one ASCII `passwd` row with `files` or `files systemd` is supported. Unsupported action lists, duplicate rows, NUL/CR input, symlinks and hardlinks refuse. Only the passwd service list changes; unrelated bytes remain. Rename ctime changes are expressly excluded from a restoration claim. The production entry fixes `/etc`, root IDs, the repository, hosted runner, attempt 1 and exact image identity.

Independent additional observations:

| Control | Actual result | Review implication |
| --- | --- | --- |
| Real SIGTERM delivered inside the temporary lease's callback, with the test process's raising signal handler | Original file dev/inode/mode/mtime/bytes restored; only the original filename remained; receipt `RESTORED` | The ordinary callback signal-unwind path works for this control |
| Injected EIO at `_store('RESTORE_INTENT')` | NSS remained files-only, original backup remained, exception propagated, receipt `RESTORATION_REFUSED_RETAIN_FOR_VM_DISPOSAL`, restoration false | Truthful failure, not a false PASS; restoration depends on receipt intent writing |
| Retained original backup content changed during the lease | Foreign backup bytes preserved; restoration refused and marked false | The directly observed original-content drift path fails closed |
| Backup name replaced immediately before closing unlink | Foreign named file deleted; owned replacement retained; successful cleanup receipt | Blocking R1 above |

The receipt-write failure is not an additional independently established false-success defect. Its current behavior requires the ordinary operation and receiving layer to preserve failure, forbid subsequent useful consumption of the prepared NSS state, and treat VM disposal as the unresolved teardown boundary. Do not describe that path as successful rollback.

A single SIGTERM control is not proof of recovery from every signal point, repeated signals, SIGKILL, machine loss or filesystem failure. The proposed packet already treats missing verified closing evidence as failure. No unsupported host-recovery claim is made here.

## 4. Finite profile, origin and loader findings

The three additive profile files are exact successors; historical selections remain present and unchanged.

Independent comparison against the actual retained native observation found only the intended native pin changes:

| Native path | Observed new bytes | Observed new SHA-256 |
| --- | ---: | --- |
| `/etc/ld.so.cache` | 38,396 | `347fdaed89f5b040c24b9d44f4b0700e8de4ef0585eb7e3d1ec6d3bdf664cd84` |
| `/lib/x86_64-linux-gnu/libc.so.6` | 2,129,424 | `755a371e86cc9f564ab54f66140747700fb0a103f698f659f2060f707897e09a` |
| `/lib64/ld-linux-x86-64.so.2` | 236,616 | `5fc0940888e9d2e1a00e66d6b1a559c36364ee867683652e1074fa576952cc3f` |
| `/lib/x86_64-linux-gnu/libpthread.so.0` | 14,408 | `cd34f895c9d2aa669d5d2654bed6b71210fc9003c3a1e96bb5311a40feb86039` |

Provenance is the actual retained `recovery/g132-r4/retained/g132-operation05-native/raw/OBSERVATION.json`: 106,646 bytes, SHA-256 `66361525c581cdb4ffa3167c50aa4fccb901f55dfd0c611f73dccb49423bf8ad`, run 44967587571, exact image ubuntu24 / 20261116.376.1 and source R3. The six profile-row occurrences correspond to four native paths. All pin fields, including unchanged modes, aliases/resolved paths and symlink text, agree with that actual observation. All other base/provider fixture fields remain equal to their predecessors.

The new genuine-execution selection changes only the two actual-member origins and prospective source/observation metadata. Original command, Git-directory selection, producer/provider requirements and resource fields are unchanged.

The loader adds one finite source revision, preserves its profile discriminator, binds exact new member hashes, selects the existing Git08ca executor, and retains the Git-directory validation. The setup owner accepts only the exact new loader byte/hash tuple and dispatches the corresponding finite revision. The independent focused invocation confirmed that the two actual loading routes yield equal source maps, a wrong profile refuses, pin drift refuses, and a wrong origin refuses.

These are source/data observations. They do not authenticate a future hosted image or imply actual runtime startup success.

## 5. Existing owners, limits and operation composition

Independent function-source comparison found that `scripts/qualify-work-graph-c5-setup.py` changes only `hosted_current_owner` among its functions/classes. The selected source-preparation, retained-child cleanup, launcher provisioner, AppArmor provisioner/finalizer, namespace observer and selected-input receiver remain unchanged.

The new qualifier keeps namespace and input observation in separate processes because the existing namespace observer lowers hard limits. It preserves the same-boot/source/provider join and requires the actual absent-target namespace classification, not merely the setup function's zero return. It calls the existing selected-input and full-startup owners while the NSS lease is active, retains the distinct full-startup outcome, and continues to state overall admission unqualified.

The new ordinary limits exactly equal the retained operation05 caps:

| Limit | Value |
| --- | ---: |
| Address space | 1,610,612,736 bytes |
| CPU | 120 seconds |
| File size | 268,435,456 bytes |
| Descriptors | 256 |
| Wall | 240 seconds |
| Report | 2,097,152 bytes |

The original producer/runtime programs and original command population were not changed by the eight-file delta. Existing namespace limits, launcher pin, seccomp and argument template are preserved. No original protected result is obtained by this ordinary source or profile work.

A bounded read of the separately frozen operator/workflow found no second independently established correction beyond R1:

- The workflow does not continue to the input step after a failing namespace phase.
- Finalizer and collection are always attempted; the finalizer remains the existing observational owner.
- The receiving oracle requires actual phase statuses, exact complete bytes, namespace/boot/source binding and NSS restoration/cleanup. Receipt-write failure, missing receipt, retained backup or incomplete finalizer/collection cannot earn the proposed ordinary result.
- The operator is explicitly bound to the local engineering identity and labelled `LOCAL_IDENTITY_REQUIRES_VERIFIED_REMOTE_REBIND_AND_FINAL_REVIEW`.

This is not a final operation review. Source correction and an independently verified provider commit will change dependent source/operator/workflow hashes. Root must freeze that final exact operation and its publication/launch bounds before a launch recommendation.

## 6. Independent verification performed

### Focused candidate controls

Executed once after source inspection:

```text
cwd: /workspace/scratch/75de74f83f5c/engineering/g132-host-profile-successor
argv: python3 -I -B test-support/g132-host-profile-successor/test_successor.py
exit: 0
result: 11 tests passed in 0.436 seconds
```

The tests were inspected first. They load source/data, use disposable temporary filesystem fixtures, and refuse the production entry under a cleared environment. They do not invoke the qualifier main, a model, real NSS, launcher, namespace or original operation.

Actual tool output is retained in `focused-invocation.json`; it is not copied from an author PASS log.

### Additional controls

The review's `independent_nss_controls.py` reads the NSS helper from immutable Git commit bytes before execution. It performs only the four temporary-file controls described above and preserves raw structured observations. The first witness is retained without rewriting or replacing the candidate source.

### Integrity and preservation

The independent `verify_integrity.py` completed 106 bounded integrity assertions. These include every manifest payload's size/hash, the archive's exact 34-member population and CRC/readback, all eight publication blob IDs/modes, worktree/source-copy equality to Git bytes, raw observation identity, finite pin provenance, unchanged other profile fields, exact helper/setup pins and preservation of the existing setup functions and ordinary resource caps.

The 106 assertions are integrity checks, not new original tests or original awards. No broad historical diagnostic corpus, package suite or protected execution was repeated.

## 7. Source-publication packet disposition

The Root publication packet is mechanically consistent with the reviewed commit:

- Eight exact source files and modes produce tree `7add9fc1c05944bb6694fd284ce214ddab2d7a3d`.
- Sole parent is retained R3 `760aaff5c478ff7354d36da186d62daba983aa49`.
- Prospective source branch is `pro/dg16-g132-host-profile-source-20261122-01`.
- It permits a provider-issued commit identity only if exact reviewed tree and sole parent are verified.
- The reviewed tree contains only `pages.yml` and `validate.yml` as workflows. Their push triggers are restricted to main; the prospective source branch does not match them. No PR or workflow-dispatch effect is part of this source packet.

These integrity and tracked-trigger facts do not cure R1. **Recommendation remains HOLD on this packet as a qualified source-publication step.** Root has received the witness and commissioned an owner-local correction. This report grants no remote action. An archival publication of an explicitly rejected candidate would be a separate Root decision, not a positive source review.

The unchanged local commit must remain the identity of this failed witness. A corrected candidate cannot inherit the old test or review identity. After correction, receive the new exact bytes and repeat only the checks needed for the changed risk and dependent pins.

## 8. Retained review evidence

All evidence is under:

`/workspace/scratch/75de74f83f5c/recovery/lanes/g132-successor-review-evidence/`

| File | Role | Bytes | SHA-256 |
| --- | --- | ---: | --- |
| `independent-nss-controls.json` | Four raw independent source-control observations, including R1 | 1,668 | `a5653cb7a05f5dfeec26cac846194a744ec52158c87eb43bd82f7cd81d148b5f` |
| `source-integrity.json` | 106 exact packet/source/preservation assertions and profile delta | 17,568 | `ca978fe50fa7bed976dc0d2ac5ab899c1afe29a128c413e3742bf48b2e754c87` |
| `focused-invocation.json` | Actual independent focused-test command/output | 2,338 | `8126497dbe80fc1a90313e193862682355e25dc57108fff9f549f9f55f5a8445` |
| `independent_nss_controls.py` | Exact reproducible source witness | 5,409 | `c7711550feb973e2245a854cd6c0e348c9159b9f9d89b6b1ee3febd207a5d32b` |
| `verify_integrity.py` | Independent integrity verifier | 7,879 | `f77879d75a034be01630120c44fa3764839819f58a648593ba83d6a2d37f2300` |

The NSS check/unlink abnormality is fresh and distinct from the accepted historical direct-diagnosis episode. It may be suitable evidence for a separately frozen P08 cognition packet if Root selects a still-decision-changing diagnostic question and the original neutral controls. This source review is not that model execution and earns no P08 credit.

Prepared by an independent advisory lane that did not author the candidate. Root retains correction selection, source/publication decisions, operation admission and every original acceptance decision.
