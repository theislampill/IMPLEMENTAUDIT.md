import errno, hashlib, json, os, pathlib, signal, subprocess, sys, tempfile, types
from unittest.mock import patch
BASE=pathlib.Path('/workspace/scratch/75de74f83f5c')
REPO=BASE/'engineering/g132-host-profile-successor'
COMMIT='2afdfc7c180dc82f5af1bfbe7272e2a14d6794df'
SOURCE='scripts/hosted-files-only-nss.py'
raw=subprocess.check_output(['git','-C',str(REPO),'show',COMMIT+':'+SOURCE])
module=types.ModuleType('independent_nss_review');module.__file__=str(REPO/SOURCE)
exec(compile(raw,module.__file__,'exec'),module.__dict__)
EVIDENCE=BASE/'recovery/lanes/g132-successor-review-evidence'
EVIDENCE.mkdir(exist_ok=True)
rows=[]
def fixture(td):
    etc=pathlib.Path(td)/'etc';etc.mkdir(mode=0o700)
    target=etc/'nsswitch.conf';target.write_bytes(b'passwd: files systemd\ngroup: files\n');target.chmod(0o644)
    return etc,target,pathlib.Path(td)/'receipt.json'
def snapshot(target):
    s=target.stat()
    return {'dev':s.st_dev,'ino':s.st_ino,'mode':s.st_mode,'mtime_ns':s.st_mtime_ns,'bytes':len(target.read_bytes()),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
class SignalProbe(BaseException):pass
with tempfile.TemporaryDirectory(prefix='nss-signal-',dir=EVIDENCE) as td:
    etc,target,receipt=fixture(td);opening=snapshot(target)
    old=signal.signal(signal.SIGTERM,lambda *_: (_ for _ in ()).throw(SignalProbe('review SIGTERM')))
    try:
        try:
            with module.FilesOnlyNSSLease(etc,receipt,expected_uid=os.getuid(),expected_gid=os.getgid()):
                signal.raise_signal(signal.SIGTERM)
        except SignalProbe:pass
    finally:signal.signal(signal.SIGTERM,old)
    row=json.loads(receipt.read_bytes())
    rows.append({'case':'actual_SIGTERM_in_callback','restored_original':snapshot(target)==opening,'receipt_state':row['state'],'restoration_verified':row['restoration_verified'],'remaining_names':sorted(p.name for p in etc.iterdir())})
with tempfile.TemporaryDirectory(prefix='nss-restore-receipt-',dir=EVIDENCE) as td:
    etc,target,receipt=fixture(td);opening=snapshot(target)
    lease=module.FilesOnlyNSSLease(etc,receipt,expected_uid=os.getuid(),expected_gid=os.getgid())
    real=lease._store
    def fail_intent(state):
        if state=='RESTORE_INTENT':raise OSError(errno.EIO,'independent injected receipt failure')
        return real(state)
    lease._store=fail_intent
    error=None
    try:
        with lease:pass
    except OSError as e:error={'type':type(e).__name__,'errno':e.errno}
    row=json.loads(receipt.read_bytes())
    rows.append({'case':'RESTORE_INTENT_receipt_failure','error':error,'restored_original':snapshot(target)==opening,'target_is_prepared_files_only':target.read_bytes()==b'passwd: files\ngroup: files\n','receipt_state':row['state'],'restoration_verified':row['restoration_verified'],'backup_present':(etc/row['backup_name']).exists()})
with tempfile.TemporaryDirectory(prefix='nss-backup-drift-',dir=EVIDENCE) as td:
    etc,target,receipt=fixture(td)
    lease=module.FilesOnlyNSSLease(etc,receipt,expected_uid=os.getuid(),expected_gid=os.getgid())
    error=None
    try:
        with lease:
            backup=etc/lease.backup_name;backup.write_bytes(b'passwd: changed-original\n')
    except ValueError as e:error=str(e)
    row=json.loads(receipt.read_bytes())
    rows.append({'case':'retained_original_bytes_drift','error':error,'foreign_backup_preserved':backup.read_bytes()==b'passwd: changed-original\n','receipt_state':row['state'],'restoration_verified':row['restoration_verified']})
with tempfile.TemporaryDirectory(prefix='nss-name-race-',dir=EVIDENCE) as td:
    etc,target,receipt=fixture(td);opening=snapshot(target)
    lease=module.FilesOnlyNSSLease(etc,receipt,expected_uid=os.getuid(),expected_gid=os.getgid())
    real_unlink=os.unlink;injected=False
    def interleave_unlink(name,*args,**kwargs):
        global injected
        if name==lease.backup_name and kwargs.get('dir_fd')==lease.parent and not injected:
            injected=True
            os.rename(name,name+'.owned-retained',src_dir_fd=lease.parent,dst_dir_fd=lease.parent)
            fd=os.open(name,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o644,dir_fd=lease.parent)
            try:os.write(fd,b'foreign concurrently named file\n')
            finally:os.close(fd)
        return real_unlink(name,*args,**kwargs)
    with patch.object(module.os,'unlink',interleave_unlink):
        with lease:pass
    row=json.loads(receipt.read_bytes())
    rows.append({'case':'foreign_name_replacement_at_unlink_boundary','interleaving':'after both _named checks, before os.unlink; actual temporary filesystem operations','injected':injected,'restored_original':snapshot(target)==opening,'foreign_named_file_deleted':not (etc/lease.backup_name).exists(),'owned_replacement_still_present':(etc/(lease.backup_name+'.owned-retained')).exists(),'receipt_state':row['state'],'restoration_verified':row['restoration_verified'],'receipt_backup_removed':row['backup_removed']})
out={'schema':'g132.independent-inert-source-controls.v1','authority':'NONE','source_commit':COMMIT,'source_path':SOURCE,'source_sha256':hashlib.sha256(raw).hexdigest(),'system_NSS_touched':False,'source_changed':False,'original_execution':False,'rows':rows}
p=EVIDENCE/'independent-nss-controls.json';p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
print('EVIDENCE',str(p),len(p.read_bytes()),hashlib.sha256(p.read_bytes()).hexdigest())
