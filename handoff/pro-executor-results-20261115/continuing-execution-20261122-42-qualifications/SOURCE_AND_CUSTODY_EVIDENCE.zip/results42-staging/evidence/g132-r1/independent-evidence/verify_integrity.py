import ast, hashlib, json, pathlib, stat, subprocess, zipfile
BASE=pathlib.Path('/workspace/scratch/75de74f83f5c'); REPO=BASE/'engineering/g132-host-profile-successor'
COMMIT='2afdfc7c180dc82f5af1bfbe7272e2a14d6794df'; PARENT='760aaff5c478ff7354d36da186d62daba983aa49'
TREE='7add9fc1c05944bb6694fd284ce214ddab2d7a3d'; PACK=BASE/'recovery/g132-successor'
OUT=BASE/'recovery/lanes/g132-successor-review-evidence'
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
def source(path,commit=COMMIT):return git('show',commit+':'+path)
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
checks=[]
def check(name,condition,**evidence):
    checks.append({'check':name,'pass':bool(condition),**evidence})
    if not condition:raise AssertionError(name)
check('exact commit tree sole parent',git('show','-s','--format=%H%n%T%n%P',COMMIT).decode().splitlines()==[COMMIT,TREE,PARENT])
publication_path=BASE/'recovery/root/g132-source-publication/PACKET.json';publication_raw=publication_path.read_bytes();pub=json.loads(publication_raw)
check('root publication packet digest',pin(publication_raw)['sha256']=='ead2059cad28b00300cf4d39e47c71291f2c66c7d5cd98d2ec6ea37fab05d518',**pin(publication_raw))
changed=git('diff-tree','--no-commit-id','--name-only','-r',COMMIT).decode().splitlines()
check('exact eight publication members',len(changed)==8 and set(changed)=={f['path'] for f in pub['files']},paths=changed)
for row in pub['files']:
    raw=source(row['path']);entry=git('ls-tree',COMMIT,row['path']).decode().strip().split()
    check('publication Git member '+row['path'], pin(raw)=={k:row[k] for k in ('bytes','sha256')} and entry[0]==row['mode'] and entry[2]==row['git_blob_sha'] and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['git_blob_sha'])
    check('worktree and packet source equal commit '+row['path'], (REPO/row['path']).read_bytes()==raw and (PACK/'source'/row['path']).read_bytes()==raw)
manifest_raw=(PACK/'PACKET_MANIFEST.json').read_bytes();manifest=json.loads(manifest_raw)
check('author packet manifest digest',pin(manifest_raw)['sha256']=='c95401c3d1dd75d192c1c1b6d4304e8a729274c10c4083bb2bf47e5b33419ce6',**pin(manifest_raw))
check('manifest population',len(manifest['files'])==manifest['total_files']==33 and sum(row['bytes'] for row in manifest['files'])==manifest['total_bytes']==467889 and len({r['path'] for r in manifest['files']})==33)
for row in manifest['files']:
    p=pathlib.PurePosixPath(row['path']);check('payload '+str(p),not p.is_absolute() and '..' not in p.parts and pin((PACK/p).read_bytes())=={k:row[k] for k in ('bytes','sha256')})
archive=BASE/'recovery/g132-host-profile-successor-source-only.zip';archive_raw=archive.read_bytes()
check('archive digest',pin(archive_raw)=={'bytes':148352,'sha256':'ddbde148faf3130548b5e0f1c9420ac5ae1fb752ada2311cd2cd1427b41933bf'})
with zipfile.ZipFile(archive) as z:
    names={'g132-successor/'+row['path'] for row in manifest['files']}|{'g132-successor/PACKET_MANIFEST.json'}
    check('archive complete exact names and CRC',set(z.namelist())==names and len(z.namelist())==34 and z.testzip() is None)
    for row in manifest['files']:check('archive payload '+row['path'],pin(z.read('g132-successor/'+row['path']))=={k:row[k] for k in ('bytes','sha256')})
    check('archive exact manifest',z.read('g132-successor/PACKET_MANIFEST.json')==manifest_raw)
obsraw=(BASE/'recovery/g132-r4/retained/g132-operation05-native/raw/OBSERVATION.json').read_bytes();obs=json.loads(obsraw)
check('retained raw observation digest',pin(obsraw)=={'bytes':106646,'sha256':'66361525c581cdb4ffa3167c50aa4fccb901f55dfd0c611f73dccb49423bf8ad'})
check('retained observation image and run',obs['context']['GITHUB_RUN_ID']=='44967587571' and obs['context']['ImageOS']=='ubuntu24' and obs['context']['ImageVersion']=='20261116.376.1' and obs['source_commit']==PARENT)
observed={x['path']:x['observed'] for x in obs['selected_host_input_observation']['pins']}
native={'/etc/ld.so.cache','/lib/x86_64-linux-gnu/libc.so.6','/lib64/ld-linux-x86-64.so.2','/lib/x86_64-linux-gnu/libpthread.so.0'}
profile_deltas={}
pairs=[('execution-r5-hosted-ubuntu24-python312.json','execution-g132-host-profile-20261122-v1.json'),('package-r5-hosted-single-copy-python312.json','package-g132-host-profile-20261122-v1.json'),('genuine-r5-hosted-ubuntu24-git-08ca-execution-profile.json','genuine-g132-host-profile-20261122-v1.json')]
def delta(a,b,path='$'):
    if type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
    if isinstance(a,dict):
        rows=[]
        for k in sorted(set(a)|set(b)):
            if k not in a:rows.append({'path':path+'.'+k,'added':b[k]})
            elif k not in b:rows.append({'path':path+'.'+k,'removed':a[k]})
            else:rows+=delta(a[k],b[k],path+'.'+k)
        return rows
    return [] if a==b else [{'path':path,'before':a,'after':b}]
for old,new in pairs:
    a=json.loads(source('fixtures/work-graph-c5-inputs/'+old,PARENT));b=json.loads(source('fixtures/work-graph-c5-inputs/'+new))
    profile_deltas[new]=delta(a,b)
    if new.startswith('genuine-'):
        check('genuine selection changes only exact origins and prospective metadata',all(row['path'] in ('$.authoring_observation','$.selection_origins.base_actual_member','$.selection_origins.provider_actual_member','$.source_identity') for row in profile_deltas[new]))
    else:
        for group in ('runtime_pins','startup_pins','native_pins'):
            for name,p in b.get(group,{}).items():
                if p!=a[group][name]:
                    check('new pin matches retained raw observation '+new+' '+name,name in native and all(observed[name][k]==v for k,v in p.items()),pin=p)
                    b[group][name]=a[group][name]
        check('all other profile fields unchanged '+new,a==b)
def functions(path,commit):
    raw=source(path,commit).decode();a=ast.parse(raw);lines=raw.splitlines(keepends=True)
    return {n.name:''.join(lines[n.lineno-1:n.end_lineno]) for n in a.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
path='scripts/qualify-work-graph-c5-setup.py';a=functions(path,PARENT);b=functions(path,COMMIT)
changed_owners=sorted(k for k in set(a)|set(b) if a.get(k)!=b.get(k))
check('existing setup owners unchanged except exact current loader selector',changed_owners==['hosted_current_owner'],changed_owners=changed_owners)
qualifier=ast.parse(source('test-support/g132-host-profile-successor/ordinary_qualifier.py'))
assignments={n.targets[0].id:n.value for n in qualifier.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
for key,path in [('SETUP_PIN','scripts/qualify-work-graph-c5-setup.py'),('NSS_PIN','scripts/hosted-files-only-nss.py')]:
    check('qualifier exact '+key,ast.literal_eval(assignments[key])==pin(source(path)))
limits=assignments['LIMITS'];actual_limits={x.arg:ast.literal_eval(x.value) for x in limits.keywords}
check('ordinary observer limits equal retained operation05 caps',actual_limits==obs['resource_caps'],limits=actual_limits,retained=obs['resource_caps'])
check('source worktree remains clean',git('status','--porcelain=v1','--untracked-files=all')==b'')
out={'schema':'g132.independent-source-integrity.v1','source_commit':COMMIT,'source_tree':TREE,'sole_parent':PARENT,'authority':'NONE','original_execution':False,'source_publication_packet':pin(publication_raw),'author_packet_manifest':pin(manifest_raw),'archive':pin(archive_raw),'checks':checks,'profile_deltas':profile_deltas,'review_scope':'integrity and source preservation only; no hosted operation recommendation'}
p=OUT/'source-integrity.json';p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'checks_passed':len(checks),'evidence':str(p),**pin(p.read_bytes()),'changed_setup_owners':changed_owners,'ordinary_limits':actual_limits},indent=2))
