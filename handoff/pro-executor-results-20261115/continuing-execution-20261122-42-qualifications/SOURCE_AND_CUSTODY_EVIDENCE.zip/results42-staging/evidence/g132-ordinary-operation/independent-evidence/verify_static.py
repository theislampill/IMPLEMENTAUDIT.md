import ast,hashlib,json,pathlib,subprocess,zipfile
BASE=pathlib.Path('/workspace/scratch/75de74f83f5c')
PACK=BASE/'recovery/g132-successor-r2'
REPO=BASE/'engineering/g132-host-profile-successor-r2'
COMMIT='31907d6ecab2d80983fdb14f64fc1b3ca9e6615e'
OUT=BASE/'recovery/lanes/g132-successor-r2-operation-review-evidence'
OUT.mkdir(exist_ok=True)
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
checks=[]
def check(name,ok,**evidence):
    checks.append({'check':name,'pass':bool(ok),**evidence})
    if not ok:raise AssertionError(name)
raw=(PACK/'PACKET_MANIFEST.json').read_bytes();manifest=json.loads(raw)
check('exact author R2 manifest',pin(raw)=={'bytes':6821,'sha256':'47065e5cda2b094ec2f7a2594297ca664232d3854e6bb01a361f2bc8da6128e0'})
check('exact 35 payload population',len(manifest['files'])==manifest['total_files']==35 and len({r['path'] for r in manifest['files']})==35 and sum(r['bytes'] for r in manifest['files'])==manifest['total_bytes']==512782)
for row in manifest['files']:
    path=pathlib.PurePosixPath(row['path'])
    check('payload '+str(path),not path.is_absolute() and '..' not in path.parts and pin((PACK/path).read_bytes())=={k:row[k] for k in ('bytes','sha256')})
archive=BASE/'recovery/g132-host-profile-successor-r2-source-only.zip'
check('exact author archive',pin(archive.read_bytes())=={'bytes':161518,'sha256':'8300fff9cbbcecd8722e4e9d2222f7d6b274ce8de5ed4d658606c404aca1e1f8'})
with zipfile.ZipFile(archive) as z:
    prefix='g132-successor-r2/'
    expected={prefix+r['path'] for r in manifest['files']}|{prefix+'PACKET_MANIFEST.json'}
    check('archive exact population CRC and manifest',set(z.namelist())==expected and len(z.namelist())==36 and z.testzip() is None and z.read(prefix+'PACKET_MANIFEST.json')==raw)
    for row in manifest['files']:check('archive payload '+row['path'],pin(z.read(prefix+row['path']))=={k:row[k] for k in ('bytes','sha256')})
for row in manifest['files']:
    if row['path'].startswith('source/'):
        path=row['path'][7:];actual=subprocess.check_output(['git','-C',str(REPO),'show',COMMIT+':'+path])
        check('source payload equals reviewed R2 Git '+path,actual==(PACK/row['path']).read_bytes())
operator=(PACK/'operation/run-owned.py').read_bytes();workflow_raw=(PACK/'operation/dg16-g132-host-profile-successor.yml').read_bytes();workflow=json.loads(workflow_raw)
tree=ast.parse(operator);constants={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
check('operator exact source identity',constants['SOURCE_COMMIT']==COMMIT and constants['SOURCE_TREE']=='969df99854f9ca87fda54f21585864d7a0d61a38' and constants['BASE_COMMIT']=='760aaff5c478ff7354d36da186d62daba983aa49')
driver=(PACK/'source'/constants['DRIVER']).read_bytes()
check('operator exact R2 driver pin',constants['DRIVER_PIN']==pin(driver))
check('finite seven operator phases',constants['PHASES']==('prepare','launcher','policy','namespace','inputs','finalize','collect'))
check('only finite branch trigger',workflow['on']=={'push':{'branches':['pro/dg16-g132-host-profile-successor-20261122-01']}})
check('read-only contents and no concurrency cancellation',workflow['permissions']=={'contents':'read'} and workflow['concurrency']=={'group':'g132-host-profile-successor-20261122-01','cancel-in-progress':False})
job=workflow['jobs']['qualify'];steps=job['steps']
check('single bounded hosted job',set(workflow['jobs'])=={'qualify'} and job['runs-on']=='ubuntu-24.04' and job['timeout-minutes']==8)
check('exact checkout with no persisted credentials',steps[0]['uses']=='actions/checkout@11d5960a326750d5838078e36cf38b85af677262' and steps[0]['with']=={'ref':'${{ github.sha }}','fetch-depth':1,'persist-credentials':False,'set-safe-directory':False,'submodules':False,'lfs':False})
check('workflow initial hash binds operator',pin(operator)['sha256'] in steps[1]['run'])
phase_steps={}
for step in steps:
    command=step.get('run')
    if command:
        syntax=subprocess.run(['bash','-n'],input=command.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        check('inert shell syntax '+step['name'],syntax.returncode==0,stderr=syntax.stderr.decode())
        for phase in constants['PHASES']:
            if 'run-owned.py\" '+phase in command:phase_steps[phase]=step
check('every finite phase bound once',set(phase_steps)==set(constants['PHASES']))
for phase,step in phase_steps.items():
    command=step['run']
    check('phase allowlisted environment and isolated Python '+phase,'sudo -n /usr/bin/env -i PATH=/usr/bin:/bin LANG=C LC_ALL=C TZ=UTC' in command and '/usr/bin/python3.12 -I -S -B ' in command and 'test \"$GITHUB_RUN_ATTEMPT\" = 1' in command)
    if phase in ('finalize','collect'):
        check('adverse preservation always '+phase,step.get('if')=='always()')
    else:
        check('prerequisite success gates '+phase,'if' not in step and step.get('continue-on-error',False) is False)
    if phase!='collect':
        check('phase nonzero retained and returned '+phase,'phase_status=$?' in command and 'exit \"$phase_status\"' in command and phase+'.status' in command)
upload=steps[-1]
check('upload complete or adverse bytes',upload['if']=='always()' and upload['uses']=='actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02' and upload['with']['overwrite'] is False and upload['with']['include-hidden-files'] is False and upload['with']['retention-days']==3 and upload['with']['if-no-files-found']=='error')
functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
check('operator reads rather than reconstructs receipt payloads',b'raw = exact_payload(driver, path)' in operator and b'copy_exact(driver, out / name, raw)' in operator)
check('collector exact four names',b"('namespace.json', 'inputs.json', 'nss.json')" in operator and b"('preparation.json', prepared / 'preparation.json')" in operator)
check('full cleanup discriminator still in success path',b'and nss_cleanup_complete(lease.record))' in driver and b"else 'UNQUALIFIED_RETAINED_RESIDUAL'" in driver)
first_operator=(BASE/'recovery/g132-successor/operation/run-owned.py').read_bytes()
normalized=operator.replace(COMMIT.encode(),b'2afdfc7c180dc82f5af1bfbe7272e2a14d6794df').replace(b'969df99854f9ca87fda54f21585864d7a0d61a38',b'7add9fc1c05944bb6694fd284ce214ddab2d7a3d').replace(b"'bytes': 14021, 'sha256': 'e316224f5492241b529161d37b4dbce5c63f6cfc038d0c750db82aae3de13a8e'",b"'bytes': 13346, 'sha256': '16b7fc0bea766f2d7e689267316d7715223e5968471efdb4d41faac7bed2eb1a'")
check('operator functions unchanged from first inspected proposal',normalized==first_operator)
result={'schema':'g132.r2-ordinary-operation-semantic-review.v1','authority':'NONE','author_manifest':pin(raw),'author_archive':pin(archive.read_bytes()),'operator':pin(operator),'workflow':pin(workflow_raw),'checks':checks,'reviewed_local_source_commit':COMMIT,'reviewed_source_tree':'969df99854f9ca87fda54f21585864d7a0d61a38','remote_binding':'PENDING','execution_performed':False,'cleanup_admission':False,'original_award':False}
p=OUT/'static-review.json';p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks_passed':len(checks),'path':str(p),**pin(p.read_bytes()),'operator':pin(operator),'workflow':pin(workflow_raw)},indent=2))
