import hashlib,json,os,pathlib,subprocess
BASE=pathlib.Path('/workspace/scratch/75de74f83f5c');REPO=BASE/'implementaudit'
ROOT=BASE/'recovery/root/g132-ordinary-operation-01';AUTHOR=BASE/'recovery/g132-successor-r2'
OUT=BASE/'recovery/lanes/g132-successor-r2-operation-review-evidence'
env=dict(os.environ);env['GIT_NO_LAZY_FETCH']='1'
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args],env=env)
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def githash(kind,raw):return hashlib.sha1(kind+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
checks=[]
def check(name,ok,**detail):
    checks.append({'check':name,'pass':bool(ok),**detail})
    if not ok:raise AssertionError(name)
packet_raw=(ROOT/'PACKET.json').read_bytes();packet=json.loads(packet_raw)
check('exact rebound operation packet',pin(packet_raw)['sha256']=='60435b151083b46d88f0d05963ce6eb36fe53afa169c33aa6909e238edbafcbf',**pin(packet_raw))
source=packet['published_source_commit'];tree=packet['published_source_tree'];parent=packet['source_sole_parent']
check('exact provider source tuple',git('show','-s','--format=%H%n%T%n%P',source).decode().splitlines()==['4ddd6403b70835339b6f55aeff9478b6d061247b','969df99854f9ca87fda54f21585864d7a0d61a38','760aaff5c478ff7354d36da186d62daba983aa49'])
receipt_raw=(BASE/'recovery/root/g132-source-publication-r2/REMOTE_READBACK.json').read_bytes();receipt=json.loads(receipt_raw)
check('Root provider readback binds source tuple',receipt['provider_source_commit']==source and receipt['tree']==tree and receipt['sole_parent']==parent)
for row in receipt['files']:
    raw=git('show',source+':'+row['path']);entry=git('ls-tree',source,row['path']).decode().strip().split()
    check('provider object equals reviewed source '+row['path'],pin(raw)=={k:row[k] for k in ('bytes','sha256')} and entry[0]==row['mode'] and entry[2]==row['git_blob_sha'] and raw==(AUTHOR/'source'/row['path']).read_bytes())
new={}
for row in packet['files']:
    raw=(ROOT/'content'/row['path']).read_bytes();new[row['path']]=raw
    check('exact rebound file '+row['path'],pin(raw)=={k:row[k] for k in ('bytes','sha256')} and githash(b'blob',raw)==row['git_blob_sha'] and row['mode']=='100644')
old_operator=(AUTHOR/'operation/run-owned.py').read_bytes()
operator=new['engineering/g132-host-profile-operation/run-owned.py']
expected=old_operator.replace(b"SOURCE_COMMIT = '31907d6ecab2d80983fdb14f64fc1b3ca9e6615e'",b"SOURCE_COMMIT = '4ddd6403b70835339b6f55aeff9478b6d061247b'")
check('operator rebind only one SOURCE_COMMIT',old_operator.count(b"SOURCE_COMMIT = '31907d6ecab2d80983fdb14f64fc1b3ca9e6615e'")==1 and operator==expected)
old_workflow=(AUTHOR/'operation/dg16-g132-host-profile-successor.yml').read_bytes()
workflow=new['.github/workflows/dg16-g132-host-profile-successor.yml']
check('workflow rebind only exact operator hash',workflow==old_workflow.replace(pin(old_operator)['sha256'].encode(),pin(operator)['sha256'].encode()) and old_workflow.count(pin(old_operator)['sha256'].encode())==1)
check('actual bound source and finite attempt scope',packet['prospective_host_sole_parent']==source and packet['branch']=='pro/dg16-g132-host-profile-successor-20261122-01' and packet['attempt']==1 and packet['protected_operation'] is False and packet['original_execution'] is False and packet['private_input_acquisition'] is False)
def read_tree_flat():
    rows={}
    for entry in git('ls-tree','-rz','-r','--full-tree',source).split(b'\0'):
        if not entry:continue
        header,name=entry.split(b'\t',1);mode,kind,oid=header.split()
        rows[name]=(mode,oid)
    return rows
flat=read_tree_flat()
def tree_hash(rows):
    root={}
    for path,value in rows.items():
        node=root
        parts=path.split(b'/')
        for part in parts[:-1]:node=node.setdefault(part,{})
        node[parts[-1]]=value
    def digest(node):
        entries=[]
        for name,value in node.items():
            directory=isinstance(value,dict)
            mode,oid=(b'40000',digest(value).encode()) if directory else value
            entries.append((name+(b'/' if directory else b''),mode+b' '+name+b'\0'+bytes.fromhex(oid.decode())))
        raw=b''.join(raw for _,raw in sorted(entries))
        return githash(b'tree',raw)
    return digest(root)
check('independent tree hash agrees with provider base',tree_hash(flat)==tree,base_paths=len(flat))
for row in packet['files']:
    key=row['path'].encode()
    check('operation file is a new addition '+row['path'],key not in flat)
    flat[key]=(row['mode'].encode(),row['git_blob_sha'].encode())
calculated=tree_hash(flat)
check('independently computed exact prospective host tree',calculated==packet['prospective_host_tree']=='7a46936aaf4212e193e603f6ff9e0a07969f9c50',calculated_tree=calculated)
result={'schema':'g132.r2-independent-operation-rebind.v1','authority':'NONE','packet':pin(packet_raw),'provider_source_commit':source,'provider_source_tree':tree,'provider_source_parent':parent,'remote_readback':pin(receipt_raw),'operator':pin(operator),'workflow':pin(workflow),'prospective_host_tree':calculated,'prospective_host_parent':source,'checks':checks,'execution_performed':False,'original_award':False}
p=OUT/'rebind-review.json';p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks_passed':len(checks),'evidence':str(p),**pin(p.read_bytes()),'packet':pin(packet_raw),'source_commit':source,'host_tree':calculated},indent=2))
