# Exact retained A4 diagnostic custody recovered

Root recovered the original operation06 receiving/root packet through the exact retained file reference recorded in results25. This is a custody recovery, not a new original execution, new receiving of the raw native archive, or new A4 award.

## Exact bytes

The returned source body and local readback are 391,755 bytes, SHA-256 `f4c5ef565e82c38870f0169447030b65801fd35059fc22286e4854c513cf0d1c`, exactly matching the original published reference. All 17 embedded UTF-8 payloads, totaling 357,862 bytes, match their original declared byte lengths, SHA-256 values and Git blob identities. `PAYLOAD_READBACK.json` records the closed population. No payload was recreated from a description.

The packet preserves the independent diagnostic report, its receiver, seal and provider observations, the issued Root diagnostic decision, the actual 342-sample memory observations and the bounded causal findings. Root read the complete independent report and issued diagnostic decision after exact extraction.

## What it establishes

This restores available exact diagnostic custody for run44826546712 attempt1, hostf0d76746a7abbcf92888a82827ba8a8c71a4074f, job136600491721. Its historical decision accepted authentic diagnostic evidence and preserved 24 successes, one exact optional skip and three original errors. That decision remains historical; the successor does not reissue it or award A4.

The complete recovered report, receiving JSON and seal explicitly record that the frozen original R01-R09 receiving contract was unavailable at that cutoff. This recovered carrier does not contain that contract. The 28-method order, source identities and diagnostic receiver cannot substitute for it.

The separate original ZIP reference still returns current metadata identifying an application/zip of 1,957,965 bytes. This successor has not materialized or hashed that ZIP through this route. Metadata is not byte receiving. The expected original SHA-256 remains `d1e6fe87bed955906d6a79736de2fcd1bd69cca9063ccf70bb60b5ade38ea133`, as bound by the original packet. An exact-title search returned no result, which does not establish loss; current reference metadata supports continued availability at that limited scope.

## Unchanged boundary

No original or diagnostic operation was rerun. Historical A4-07 remains UNKNOWN_NO_REPLAY. No guard, method order, source or acceptance denominator changed. The recovered packet's exact bytes strengthen custody; they supply neither the missing original contract nor a successful original outcome. A4 R3's later bounded compiler diagnostic adjudication in results41 remains separate.

Original private file references are kept in local transport records and the authentic carrier; publication must preserve prior public evidence while avoiding unnecessary new private locator exposure. No bearer tokens or authenticated download URLs are included in this recovery note.
