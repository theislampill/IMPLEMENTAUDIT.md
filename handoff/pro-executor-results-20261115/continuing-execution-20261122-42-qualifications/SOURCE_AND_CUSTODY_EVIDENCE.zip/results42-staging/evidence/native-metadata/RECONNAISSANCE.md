# Native Codex Stop capability reconnaissance

Disposition: **CURRENT_HOST_PRODUCT_ROUTE_UNAVAILABLE**. Read-only preparation completed. No authentic session was launched and no source, hook trust, authentication, real-home configuration, controller, lifecycle state, or original evidence was changed.

## 1. Decision

Do not launch a positive original Stop qualification on this unchanged Linux/product tuple. The selected opt-in product path explicitly refuses non-Windows execution before calling its lifecycle validator:

- Source commit: `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7`.
- Source tree: `9c3913ceaa95f3f36b0377fe2dba4a302afcba89`.
- Host: Linux x86_64, Python 3.12.14, `os.name=posix`.
- Codex: `/opt/codex/bin/codex`, `codex-cli 0.172.0-alpha.2`.
- Exact refusal: `skills/implementaudit/scripts/host-stop-interlock.py`, lines 478–479: `if os.name != "nt"` followed by `InterlockUnavailable("selected native qualification requires the Windows custody owner")`.

The alternative ordinary entrypoint intentionally offers only attribution/unsupported-host behavior. Once a selection is bound, it raises `UNSUPPORTED_HOST_EFFECT_AUTHENTICATION` (lines 381–388). It does not invoke the lifecycle disposition owner. Therefore neither existing path supplies valid native yield, handoff, or closure on this host without an independently admitted source/platform change.

This is a product-route/platform finding, **not a finding that Codex lacks hooks**. Do not broaden platform scope, add an adapter, weaken custody, replace the harness, or probe authentic sessions against this known refusal merely to collect a failure.

## 2. Host interface evidence, with its limits

The installed CLI's help advertises plugin management and the app-server tooling. Static schema generation completed with exit code 0:

```bash
/opt/codex/bin/codex app-server generate-json-schema --experimental --out /workspace/scratch/75de74f83f5c/recovery/native-stop/codex-schema
```

No app server, thread, model turn, login, plugin installation, or hook trust operation was started by that command.

The generated schema declares:

| Interface | Declared fields / meaning |
| --- | --- |
| `hooks/list` | Inspection of hooks for exact cwds or a loaded `threadId` |
| `HookEventName` | Includes `sessionStart`, `sessionEnd`, `stop`, `interrupt`, and subagent events |
| `HookMetadata` | `enabled`, `currentHash`, `trustStatus`, `sourcePath`, `pluginId`, `eventName`, `timeoutSec`, owning environment |
| Hook trust | `managed`, `untrusted`, `trusted`, `modified` |
| `hook/started`, `hook/completed` | Host notifications with hook-run ID, thread/turn IDs, event name, source path, status, start/completion/duration and output entries |
| `config/read`, `configRequirements/read` | Effective configuration/layers and managed constraints; requirements include `allowManagedHooksOnly` |
| Initialization response | `userAgent`, `platformFamily`, `platformOs`, `codexHome` |
| Thread-start response | Server-returned model/provider, reasoning effort, service tier, cwd, permissions/approval policy, thread, instruction sources |
| `model/rerouted` | Actual host notification carrying from/to model and thread/turn identity |

These are **declared local protocol capabilities**, not observed registration, enabled/trusted status, a callback, hook-input compatibility, host acceptance of a Stop response, or a genuine lifecycle result. No live `hooks/list` or effective-config request was made.

The hook schema exposes trust metadata but no hook-trust mutation method was found among the generated client requests. This does not establish that the host has no supported UI trust workflow. The CLI's dangerous hook-trust bypass was neither used nor proposed.

Source anchors: generated `ClientRequest.json`, `ServerNotification.json`, `v2/HooksListResponse.json`, `v2/HookStartedNotification.json`, `v2/HookCompletedNotification.json`, `v1/InitializeResponse.json`, `v2/ThreadStartResponse.json`, `v2/ConfigRequirementsReadResponse.json`.

## 3. Selected package and activation boundary

The exact `.codex-plugin/plugin.json` is version `0.4.0` and declares `skills: "./skills/"`; it has no hook registration. The source reference `skills/implementaudit/references/host-session-binding.md`, lines 298–314, explicitly says canonical hook registration is absent and donor calls do not establish a supported host route.

The generic Stop path additionally requires isolated Python flags, a physical plugin-cache topology, and matching `PLUGIN_ROOT`/`PLUGIN_DATA` ownership (Stop script lines 157–200). Copying a source helper into an arbitrary directory does not meet that route. The standalone projection cannot claim automatic native actuation.

The opt-in `--codex-stop-policy <policy> <sha256>` route is task-selected and requires actual host trust of the exact command/policy. It records its own receipts with `host_execution_authenticated: false`; independent host callback and continuation receiving remains required (lines 417–424, 517–524). Its historical note describes finite **Windows** receiving, including false-completion refusals and a valid nonterminal yield, while expressly withholding broader R0037/handoff acceptance. Historical success is not current Linux admission.

A session ID supplied to the binding core is only attributed data. The portable core reports native activation/enforcement unproved. It consumes controller/currentness receipts supplied by the actual owners; it does not authenticate them or create native principal authority. See binding reference lines 36–46 and 77–80.

## 4. Disposition selection and failed activation

### Initially-yield policy

The v1 policy always selects `NONTERMINAL_YIELD` and forbids a `disposition` member (Stop script lines 392–397). A truthful closure or handoff cannot be silently downgraded to yield.

The exact source also supports v2 explicit `TERMINAL_CLOSURE` or `AUDITED_HANDOFF`, requiring a record inside the selected run plus its exact SHA-256 (lines 398–414). That is a static record selection, not an automatic transition from an immutable v1 policy. A future legitimate transition would need the already entitled owner to select the real terminal/handoff record, freeze a new exact policy/command, and receive the host's actual trust/currentness transition. No host-supported in-session policy/trust transition was observed in this lane. Do not count independent v2 fixtures as proof that an initially-yield session can make that transition.

Both v1 and v2 remain behind the Windows-only custody gate here.

### Never-bound activation versus lost binding

The portable binding core distinguishes:

- Never activated, no binding/index/attempt: `UNBOUND`, immediate read-only path.
- Admitted bind attempt with retained marker but no complete pair: `UNAVAILABLE`, unresolved activation.
- Invalid invocation or unsafe custody before marker admission: immediate refusal must be propagated by the caller; later marker-free lookup cannot authenticate that failed activation.
- An established pair that becomes partial, stale, foreign, malformed, or tombstoned: refusal/currentness residual; no ordinary-session reinterpretation.

Evidence: `host-session-binding.py` lines 691–730 and 763–783; binding reference lines 82–117.

The task-selected Stop path collapses every lookup that is not exact `BOUND` into “selected Stop has no active exact binding” (Stop script lines 466–471), then block output. This supports the prior component concern but does **not** prove native reachability of a failed governed activation. No real activation attempt occurred in this lane, so it creates no new original acceptance or native RED.

Normative owner: cached `recovery/root/comments211.md`, comment `5343276081`, especially lines 174–193, 275–315 and 392–441. Failed first activation must truthfully surface unavailable enforcement/fallback; previously established missing/stale/foreign binding remains blocking.

## 5. Minimum evidence requirements for a future admitted operation

This is a preparation checklist for the existing owner on a separately qualified tuple, **not an executable current-host operation or permission to launch one**.

1. **Source and isolated installation identity.** Freeze source commit/tree, package/inventory hashes, selected helper bytes, physical installed location, policy/command digest, lifecycle owner, binding owner and external binding-store custody. Use an isolated package root with the supported installation route. Prove actual loaded package identity; a staged-copy check alone is insufficient. Do not copy credentials or alter real-home trust/auth to manufacture isolation.
2. **Actual host/config/actor provenance.** Retain CLI binary/version/hash and initialization response; capture only allowlisted effective configuration, requirement constraints, instruction-source paths/digests and server-returned model/provider/effort/service tier. Keep requested settings separate from observed server selections and model-rerouting notifications. Preserve thread/turn IDs and any actual child identity/role/independence records. Do not call a model slug a verified hidden model revision.
3. **Supported trust and callback registration.** Obtain the host's normal exact-command trust review. Read back `hooks/list` for the actual thread and freeze hook source, currentHash, enabled/trust status and timeout. If disabled, modified, unmanaged under managed-only policy, or unavailable, remain at truthful fallback. No trust bypass, direct fake stdin, or self-authenticated callback.
4. **Genuine governed activation before Stop.** A real host session must enter the selected governor. Its actual controller, claim, current run and continuity evidence must be validated by their owners before binding. Preserve the native session-to-activation event and the exact resulting binding. No singleton/newest/cwd guess or manufactured original fixture.
5. **Real lifecycle evidence.** Use an ordinary task with real work, checks and obligations. Capture its initial truthful yield; only afterward qualify a genuine closure or audited-handoff record and its allowed policy/trust transition. Yield/handoff/closure are separate dispositions. Include authentic never-bound failure and established-binding loss only under independently frozen safe conditions; no inference from component tests.
6. **Independent receiving.** Correlate native hook-start/completion notifications, raw bounded host ingress, the immutable policy, exact bindings, validator observations, actual host refusal/continuation or turn completion, and subsequent current state. The hook's own JSON explicitly cannot authenticate the host. Valid closure/handoff requires the original owner predicates, not a fabricated DONE row.
7. **Cleanup/timing/resource scope.** Freeze per-hook timeout and whole-operation bounds before launch. On the selected Windows route, retain its kill-on-close Job/descendant-empty and temporary-directory cleanup evidence; no POSIX substitute is admitted by this source. Capture actual process/resource observations and any owner timeout as unfinished owner work, never as a refused lifecycle record. An operation timeout/forced host exit cannot grant closure/handoff. Do not use retry-count escape.
8. **Coverage ceiling.** One observed yield is a bounded native result only. Comment `5343276081` also requires valid closure/handoff, TY-1–TY-5, TY-6 refusal, ordinary cheap path, exact read-only binding, stale/ambiguous/foreign refusals, fallback, child/target-authority exclusions and install/source/release parity. Keep earned scopes separate.

No frozen positive operation can honestly be admitted for the present unchanged Linux tuple because requirement 1 already fails the selected product platform gate. Root's next decision is the exact capability disposition, not another session probe.

## 6. Saved evidence and boundaries

- `CAPABILITY_MANIFEST.json`: observed host/CLI identity, extracted declared interfaces and 15 hashed source/schema/runtime inputs.
- `codex-schema/`: static protocol output generated by the installed CLI.
- `RECON_COMMANDS.json`: bounded help/read-only identity command outputs.
- `RECONNAISSANCE.md`: this report.

No credentials, raw authentication/config values, signed URLs, native-session transcripts, forged lifecycle fixtures or original award claims are included. No source adapter or publication was created.
