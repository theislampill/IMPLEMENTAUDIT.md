# Native host provenance — actual startup boundary

Status: **BLOCKED before native protocol initialization**. No thread, model turn, original case or native Stop episode was created.

The installed Codex CLI is `0.172.0-alpha.2`. Static protocol schemas declare configuration, skill discovery and host-returned model/thread/turn provenance. Those declarations remain capability descriptions, not observed effective identity or loaded-source proof.

The metadata-only client attempted `initialize`, `config/read` and `skills/list` using the existing configured host and authentication in place. The app server exited with code 1 before any protocol response. The exact sanitized first error reports SQLite state creation failure at the read-only Codex home; `NATIVE_STARTUP_ERROR.json` binds 377 stderr bytes by SHA-256 `8138561ae85666e124e28d2dec7606ac68e7ec871db777508e72f0f00443f928`.

Official configuration documentation and the installed binary identify a supported `sqlite_home` setting. A process-local override selected a new owned state directory under this recovery area. It changed no real-home configuration and copied no credential. The expected SQLite files were created there, but the app server still exited before initialization with `Read-only file system (os error 30)`. The same output reports an ignored pre-existing `features.experimental_use_rmcp_client` setting; that warning is not established as the cause of the fatal error. The exact sanitized output is retained in `NATIVE_STATE_OVERRIDE_ERROR.json`.

One attempted file-syscall trace exited 1 without establishing a usable native trace. `NATIVE_READONLY_PATHS.json` retains that limited outcome; its empty failure-path list is not evidence that no filesystem failure occurred. No escalation, permission change, alternate credential custody, policy removal or home-directory workaround was attempted. The remaining startup write location/cause is unqualified.

Configuration references:

- https://learn.chatgpt.com/docs/config-file/environment-variables
- https://github.com/openai/codex/blob/main/codex-rs/config/src/config_toml.rs

Requested/default settings, actual returned host settings, hidden backend version and source loading remain distinct. No actual thread response or model-reroute record exists. This result cannot repair historical actor provenance or satisfy original P08/M03/native Stop obligations. The separate selected product Stop path still requires Windows custody; this Linux metadata attempt did not alter that path.

The P08 preparation around the independently found NSS cleanup defect was stopped before any actor mission/control bank was created, because Root selected the correction before original admission and that diagnostic question no longer had current decision value. Its stopped preparation remains explicit and earns no original credit.

Raw SQLite state/log databases and unselected private configuration/log values are excluded from evidence publication. The retained JSON records state the exact limited attempted requests, process outcome, selected safe errors and stream digests.
