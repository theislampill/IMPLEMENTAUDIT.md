#!/usr/bin/env python3
"""Read native Codex metadata only; no thread, turn, config write or auth copy."""
import hashlib
import json
import os
import re
from pathlib import Path
import selectors
import subprocess
import time

ROOT = Path('/workspace/scratch/75de74f83f5c/integration-source')
OUT = Path('/workspace/scratch/75de74f83f5c/recovery/native-stop/LIVE_METADATA_STATE_OVERRIDE.json')
CONFIG_KEYS = ('model', 'model_provider', 'model_reasoning_effort', 'model_reasoning_summary',
               'model_verbosity', 'service_tier', 'approval_policy', 'sandbox_mode')
record = {'schema': 'dg17.native-host-read-only-metadata.v1', 'authority': 'NONE',
          'command': ['/opt/codex/bin/codex', 'app-server', '--stdio', '-c', 'sqlite_home="/workspace/scratch/75de74f83f5c/recovery/native-stop/app-server-state-01"'], 'cwd': str(ROOT),
          'thread_created': False, 'model_turns': 0, 'config_mutation': False,
          'credential_files_read_or_copied_by_client': False, 'responses': [],
          'notifications': [], 'unexpected_server_requests_refused': []}
proc = None
selector = selectors.DefaultSelector()
buffers = {'stdout': b'', 'stderr': b''}
stream_hashes = {k: hashlib.sha256() for k in buffers}
stream_bytes = dict.fromkeys(buffers, 0)
deadline = time.monotonic() + 45
pending = {}
stderr_categories = set()
ERROR_WORDS = ('configuration', 'config', 'requirements', 'startup', 'auth', 'token refresh',
               'error sending request', 'response', 'connection refused', 'connect', 'network',
               'timed out', 'permission denied', 'no such file', 'operation not permitted',
               'invalid type', 'missing field', 'unsupported', 'unrecognized', 'certificate',
               'tls', 'unauthorized', 'forbidden', 'access denied', 'disabled', 'parse', 'toml',
               'json', 'variant', 'socket', 'dns', 'unexpected eof', 'failed to load',
               'expected', 'decode', 'not found', 'key', 'string', 'integer', 'boolean')

def send(value):
    proc.stdin.write((json.dumps(value, separators=(',', ':')) + '\n').encode())
    proc.stdin.flush()

def receive(wanted):
    while time.monotonic() < deadline:
        if wanted in pending:
            return pending.pop(wanted)
        for key, _ in selector.select(min(1, max(0, deadline - time.monotonic()))):
            raw = os.read(key.fd, 65536)
            name = key.data
            if not raw:
                selector.unregister(key.fileobj)
                continue
            stream_hashes[name].update(raw)
            stream_bytes[name] += len(raw)
            if stream_bytes[name] > 4194304:
                raise RuntimeError('native metadata stream bound exceeded')
            if name == 'stderr':
                lower = raw.decode('utf-8', 'replace').lower()
                stderr_categories.update(word for word in ERROR_WORDS if word in lower)
                stderr_categories.update('HTTP_' + code for code in re.findall(r'\b(401|403|404|429|500|502|503)\b', lower))
                continue  # Hash and count only; do not retain potentially private log text.
            buffers[name] += raw
            while b'\n' in buffers[name]:
                line, buffers[name] = buffers[name].split(b'\n', 1)
                if not line:
                    continue
                obj = json.loads(line)
                digest = hashlib.sha256(line).hexdigest()
                if 'method' in obj:
                    method = obj['method']
                    if 'id' in obj:
                        record['unexpected_server_requests_refused'].append(method)
                        send({'id': obj['id'], 'error': {'code': -32601, 'message': 'metadata-only client'}})
                    else:
                        record['notifications'].append({'method': method, 'sha256': digest, 'bytes': len(line)})
                elif 'id' in obj:
                    pending[obj['id']] = (obj, digest, len(line))
        if proc.poll() is not None and not selector.get_map():
            raise RuntimeError('native server exited before required response')
    raise TimeoutError('native metadata deadline')

def request(number, method, params):
    req = {'id': number, 'method': method, 'params': params}
    send(req)
    obj, digest, size = receive(number)
    row = {'request': req, 'response_sha256': digest, 'response_bytes': size,
           'error_code': obj.get('error', {}).get('code')}
    value = obj.get('result', {})
    if method == 'initialize':
        row['selected_result'] = {k: value[k] for k in ('userAgent', 'platformFamily', 'platformOs') if k in value}
    elif method == 'config/read':
        cfg = value.get('config', {})
        row['selected_result'] = {k: cfg.get(k) for k in CONFIG_KEYS}
        row['config_fields_retained'] = list(CONFIG_KEYS)
        row['unselected_config_values_retained'] = False
    elif method == 'skills/list':
        row['selected_result'] = []
        for entry in value.get('data', []):
            relevant = [{k: s.get(k) for k in ('name', 'path', 'enabled', 'scope', 'pluginId')}
                        for s in entry.get('skills', []) if s.get('name') in ('audit-andon', 'implementaudit')]
            row['selected_result'].append({'cwd': entry.get('cwd'), 'skill_count': len(entry.get('skills', [])),
                                           'error_count': len(entry.get('errors', [])), 'relevant_skills': relevant})
    record['responses'].append(row)
    if 'error' in obj:
        raise RuntimeError('native metadata response error ' + str(obj['error'].get('code')))

record['client_source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
record['sqlite_location_override'] = 'supported process-local configuration; auth/config home unchanged'
record['configuration_source'] = 'https://learn.chatgpt.com/docs/config-file/environment-variables'
Path('/workspace/scratch/75de74f83f5c/recovery/native-stop/app-server-state-01').mkdir(mode=0o700)
started = time.monotonic()
try:
    proc = subprocess.Popen(record['command'], cwd=ROOT, stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    record['server_pid'] = proc.pid
    selector.register(proc.stdout, selectors.EVENT_READ, 'stdout')
    selector.register(proc.stderr, selectors.EVENT_READ, 'stderr')
    request(1, 'initialize', {'clientInfo': {'name': 'implementaudit-metadata-receiver', 'version': '1'},
                              'capabilities': {'experimentalApi': True, 'explicitGatewayOauth': True}})
    send({'method': 'initialized'})
    request(2, 'config/read', {'cwd': str(ROOT), 'includeLayers': False})
    request(3, 'skills/list', {'cwds': [str(ROOT)], 'forceReload': False})
    record['metadata_reads_complete'] = True
except BaseException as error:
    record['metadata_reads_complete'] = False
    record['failure'] = {'type': type(error).__name__, 'message': str(error)[:160]}
finally:
    if proc is not None:
        proc.stdin.close()
        try:
            proc.wait(timeout=8)
            record['shutdown'] = 'stdin_eof_native_exit'
        except subprocess.TimeoutExpired:
            proc.terminate()
            try:
                proc.wait(timeout=3)
                record['shutdown'] = 'owned_server_SIGTERM'
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=3)
                record['shutdown'] = 'owned_server_SIGKILL'
        record['server_exit_code'] = proc.returncode
        for stream in (proc.stdout, proc.stderr):
            stream.close()
    selector.close()
    record['observed_streams'] = {k: {'bytes': stream_bytes[k], 'sha256': stream_hashes[k].hexdigest()}
                                  for k in stream_bytes}
    record['elapsed_seconds'] = round(time.monotonic() - started, 3)
    record['stderr_allowlisted_categories'] = sorted(stderr_categories)
    record['purpose'] = 'Read native metadata with isolated SQLite state; no original operation or model turn'
    OUT.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record, indent=2))
