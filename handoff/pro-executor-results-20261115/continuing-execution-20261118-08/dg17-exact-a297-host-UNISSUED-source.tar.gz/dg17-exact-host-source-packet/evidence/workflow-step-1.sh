set -euo pipefail
/usr/bin/python3 -I -B handoff/dg17-exact-host-substrate/run.py prepare
