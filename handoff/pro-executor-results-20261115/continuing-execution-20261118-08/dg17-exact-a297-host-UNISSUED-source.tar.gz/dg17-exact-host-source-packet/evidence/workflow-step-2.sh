set -euo pipefail
/usr/bin/python3 -I -B "/opt/dg17-exact-a297-${GITHUB_RUN_ID}-${GITHUB_RUN_ATTEMPT}/driver/run.py" exercise
