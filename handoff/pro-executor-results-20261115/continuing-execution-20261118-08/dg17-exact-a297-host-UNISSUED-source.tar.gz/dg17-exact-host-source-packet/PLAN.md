# DG17 exact-target host source preparation

Report state: FINAL

Owner: /root/exact_dg17_host_source; Root is the sole integration and acceptance owner.

Owned resource: this new preparation directory only. All existing repositories and refs are read-only inputs. Final additions are based on exact a297957be11feb494c0ec467235794a1e0c54751, per Root instruction; no commit or branch creation is authorized at source-author stage.

## Scope and acceptance

Prepare one prospective ordinary GitHub-hosted Linux job that verifies and installs unchanged exact-a297 claim-run and its required source companions into disposable UID0-owned hosted paths. Preserve a distinct disposable fixture HEAD and original audited source identity. Exercise only prospective helper substrate currentness, stale-receipt refusal, bounded manual re-anchor and deterministic no-child handling. Keep original P04/B02 model/governor conjunctions, native host activation and all original acceptance open.

Author-stage checks are source/data/syntax only. No exact helper, hosted job, model actor, native callback or controller is executed. Root obtains a genuine nonauthor exact-packet review before any launch.

## Implementation and evidence plan

1. Read original rows and exact source host/custody gates; derive source closure from owner dependencies.
2. Add one pinned exact-branch workflow, one ordinary runner, one exact-source manifest and one prospective operator guide in the candidate.
3. Statically verify YAML, Python and shell snippets, source hashes, dependency closure, immutable artifact path, gating and prohibited scope. No runtime behavioral test or broad suite.
4. Seal candidate additions and static evidence, report base/tree and explicit unproved conjuncts; return to Root.

Rollback: remove only this owned directory after receiving; no existing source or ref is modified. No AGENTS modification is warranted.
