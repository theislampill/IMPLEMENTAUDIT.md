# Context — real fresh task

Owner-provided objective: Receive the exact DG18 installed package through plugin-claude and establish its actual fresh task currentness before independent receiving.

Actual repository: /home/runner/work/_temp/dg18-installed-43855749471-1/plugin-claude/subject
Actual HEAD: 30da7cdec6ebcb5b35cc7f93c5187f625ee11fe3
Actual tree: ae32cddeb15f916b139bdb50dbea0e1361e621e0
Actual claim: e8b6d0e8f1fb5b69dae23ffc3b6c206a
Actual controller: dg18-installed-43855749471-1-plugin-claude

Executing claim helper SHA256: eb422f285c70f59abfc42edeef5daa9aac0fc6a87c58c23f7ece4a4219127902

No original controller continuity, hosted identity, independent review, publication, or acceptance is inferred.
