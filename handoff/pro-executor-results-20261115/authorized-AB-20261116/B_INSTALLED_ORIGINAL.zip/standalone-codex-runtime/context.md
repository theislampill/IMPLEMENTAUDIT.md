# Context — real fresh task

Owner-provided objective: Receive the exact DG18 installed package through standalone-codex and establish its actual fresh task currentness before independent receiving.

Actual repository: /home/runner/work/_temp/dg18-installed-43855749471-1/standalone-codex/subject
Actual HEAD: 927718ed7dabfb169ba9bf531b589890f24da554
Actual tree: af46f0e38b00ab0d028125702b9ca0d3b52d7b79
Actual claim: 108299ba0b0767edfe7713fd76e350ac
Actual controller: dg18-installed-43855749471-1-standalone-codex

Executing claim helper SHA256: eb422f285c70f59abfc42edeef5daa9aac0fc6a87c58c23f7ece4a4219127902

No original controller continuity, hosted identity, independent review, publication, or acceptance is inferred.
