# Context — real fresh task

Owner-provided objective: Receive the exact DG18 installed package through standalone-claude and establish its actual fresh task currentness before independent receiving.

Actual repository: /home/runner/work/_temp/dg18-installed-43855749471-1/standalone-claude/subject
Actual HEAD: 7051911b74ca09fc88117381d7d4e0fc6d37e39f
Actual tree: bf2e89b4bcdb3a859f4fe2def350adb4bb794af7
Actual claim: 4cad48e708788d24c1f1c8129f351772
Actual controller: dg18-installed-43855749471-1-standalone-claude

Executing claim helper SHA256: eb422f285c70f59abfc42edeef5daa9aac0fc6a87c58c23f7ece4a4219127902

No original controller continuity, hosted identity, independent review, publication, or acceptance is inferred.
