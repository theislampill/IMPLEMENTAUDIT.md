# Restored original NSS R2 — source and fresh evidence receipt

**Source recovery and fresh focused qualification completed; immutable local candidate returned for Root's independent review.** This is author evidence, with no admission, original award, dispatch readiness or closure authority. Final packet identities are bound by the new `FINAL_RECEIPT.json` in `recovery/restored/original-nss-r2`.

## Current lineage

| Item | Exact identity |
|---|---|
| New local commit | `cec25d5b49c7fe3c31a61b6d815fc6870250a97b` |
| New tree | `2620fc045df51783bf3b681e6383d9e0ee54bd41` |
| Sole parent | Authentic published `b393a9057c249335e6cdf4ccbb898d192b0830b8` |
| Engineering worktree | `/workspace/scratch/75de74f83f5c/engineering/g132-original-nss`; clean after commit |
| Current controller | `dg16-dg18-restored-20261122`, G0002 `9eb19af26c4fe90a35422856c79d5d03ee59ee47` |

Separate STATE and ROADMAP reads and read-only currentness verification preceded continuation. Fresh controls completed under restored G0001; sealing uses verified G0002. No Root epoch/controller state was written.

This commit has a newly issued local identity and parentage. Historical commits `1f5960105146a4a021ef4e6118f977a4cad5251c` and `201d6fc6a97cbb1c8505e94598bc977f50495ba4` are references only. Their raw commit objects were not recovered or recreated. Exact `git cat-file` lookups automatically triggered this partial clone's promisor reads for those two IDs; both were refused as not our ref/invalid object. No old object or remote write resulted, and the lookups were not repeated. Their actual errors are retained in `RECOVERY_INVENTORY.json`.

## Exact recovery inventory

Eight files, totaling **84,477 bytes**, were derived from retained complete source/tool-output text, with authentic unchanged baseline bytes and Root's retained exact REFUSALS tail where applicable. Every length and SHA-256 matches the pre-outage record. Classification for each is **DERIVED_EXACT_BYTES_MATCH_RECORDED_DIGEST**; this establishes byte equality without claiming restoration of the lost physical custody or Git lineage.

| Recovered file | Bytes | SHA-256 |
|---|---:|---|
| R2 NSS owner | 15,818 | `d3a07500f65be7706cd22beeb02c71a04b7521ac000cb1c3039a7fad742b818c` |
| R2 test source | 18,767 | `27b252dd82a4fea631997d64c93e0d64d1cea3d89ff4f2eeba3e40eba652ec8c` |
| R1 NSS source only | 15,806 | `952b9e83e46f085dab6ca333f08a91454cd8b5e96b78446b23be235fc95af5cf` |
| R1 test source only | 16,205 | `d9c46541819e1eec989af8237a19cf7a8e8c6abf94cad92cc7774d1288843385` |
| Old README | 3,346 | `4f41f2d6a8497e8c0b92925618746dc485c8715c97ea68f6b3db935142ed6d8c` |
| Pre-outage R2 author report | 7,454 | `5306854efe8b160613d838b6664585e5559b13cf7be0b7805656bf87c239ad03` |
| Independent first-fstat witness | 5,822 | `6d71c27bcb53c5a5b0032298736279aafeb2d6a58e0b0ff7d5b7fd407b6f702c` |
| Historical Root R2 scope | 1,259 | `024bed5bef6afaf4d6b002c29b457e9c29f903004c09b41b886ba5f4582e21f6` |

These exact copies live under `recovered/`. The old report contains anticipatory frozen/readback wording written before the interrupted sealing call; its recovered text does **not** prove that old sealing completed. The old scope is a historical decision body, not current authority transfer. The current source README was separately corrected to state the restored evidence limits; its 3,693 bytes/SHA-256 `b7614c9b5db4445b64ff99471f5872eea04c34b678dc35106af303fe1dceb771` are new documentation, not purported exact old bytes.

Unavailable in this recovery are the full pre-outage R1/R2 test JSON banks, raw logs and invocation records; the full R1 30-payload packet/31-member archive; old raw Git commit objects; and any interrupted R2 manifest/archive/readback/final receipt. No absent historical log, timestamp, inode record, seal or commit metadata was invented. Known historical hashes remain references only. This bounded recovery made no broad history search.

## Fresh qualification in this workspace

The digest-matched 13-control source ran once against the authentic 14,718-byte b393 NSS baseline, before worktree adoption, and once against the recovered R2 owner. Both invocations used `python -I -B`, actual disposable files/descriptors, and the existing explicit TEST_ONLY path, uid/gid and finite-image adapter. They did not access actual system NSS or original private inputs. Raw stdout/stderr, full JSON observations, exact commands, source/test hashes, timings and exit codes are under `fresh-observations/`, explicitly classified **FRESH_RESTORED_WORKSPACE_OBSERVATION**.

| Observation | Fresh b393 baseline | Fresh R2 |
|---|---:|---:|
| Controls | 13 | 13 |
| Failures / errors | 10 / 0 | 0 / 0 |
| Test-process exit | 1 | 0 |
| First-fstat owner fds left open | 1 | 0 |
| Test utility's subsequent fd rescue | 1 | 0 |
| Fixture parent empty afterward | yes | yes |

The new baseline differs from the pre-outage R1 comparison, so its ten failures are not relabeled as the historical one-failure result. They are control failures, not ten original cases or ten separately awarded defects; two check the newly required exchange-availability/refusal behavior. All candidate observations show zero owner-open descriptors. Positive exchange uses real disposable-file `renameat2`, while race/error/interruption inputs remain explicit test injections rather than actual host episodes.

The first-fstat control preserves the allocated zero-byte temporary and unchanged original target, refuses configuration before any exchange/unlink, and records `replacement=NOT_STARTED`, `configured=false`, `temporary_created=false`, `temporary_removed=false`. The public no-durable-observation/no-absence-proof meaning remains truthful. The baseline fd is explicitly rescued by the test utility only after the failing assertion; that disposal cannot count as owner success.

The remaining controls cover name cleanup, late target/source replacement, same-byte inode changes, partial writes, post-exchange interruption, unavailable/refused exchange without destructive fallback, positive final readback/no replay, final drift and forged success. No broader suite or original execution was run.

## Source and remaining cutpoint

The NSS owner and test source are exact pre-outage R2 bytes. Against authentic b393, production changes are limited to the prior nondestructive retention/exchange repair and the fd-closing first-fstat correction. Static comparison preserves `need`, `sha`, `encode`, `identity`, `transform`, `verify_configured` and `public_state`; only `read_target` and `prepare` change, with `exchange_entries` added. All finite pins and phases remain. The exact R1-to-R2 source difference remains the three initialization statements moved inside the existing closing try.

The original 526/518-byte transformation, before-controller boundary, once-only journal, VM retention and separate process/descriptor obligations remain. The 53 host/12 runtime/46 author/17 projection populations, original denominators and awards are unchanged. No writer exclusion, inode-conditional exchange, complete cleanup, VM disposal or actual declared-host capability is claimed.

`run.py` and `PUBLIC_PACKET_MANIFEST.json` are byte-identical to b393 and still admit only the original NSS SHA-256 `7243b9a13f9597059d57f22e1cfd4b344a7fd0cee930e9f9d032eee6e9e42270`/14,718 bytes. They deliberately refuse this changed owner. `PIN_PROPAGATION_UNISSUED.json` names the genuine author/template, module/carrier/public/entry and phase/index/projection joins that Root must separately commission after review. No active pins, historical admissions, protected identities/grants or original request were generated.

**Cutpoint:** exact source and selected historical text are recovered; fresh focused evidence and the new b393-parent commit are frozen for independent source review. Full historical banks/old seals remain unavailable. Genuine pin generation, complete protected readiness and any publication remain unissued. No real NSS, original/model/hosted operation, private acquisition, provider/capability construction or recovered finalizer execution occurred; no remote write was made.
