# Independent disposition of the R3 propagation amendment

**PASS at evidence-amendment scope.** R3 resolves the remaining inventory finding in the frozen R2 review of candidate `d0e5fc660d0b3b9bd11ad6004b1497477cb85755`, tree `ac1348edf280408ee82e0df9cd0c6563ffdea9b7`.

The six-member ZIP and all five manifest-listed payloads match the frozen packet. The ordered graph is identical to the independent correction for all 220 edges across 172 holders. Its canonical encoding is 63,377 bytes, SHA-256 `b4adaca755542e3146f142ef0aa5c1df70bd5f1765059cf328c9022b9c8cfac2`. The four additions are the two runtime owners’ references to the installation index and the composition index’s references back to those two owners. All twelve runtime descriptors match the independent readback.

The reviewer exercised the amended indexed-file reader in isolation. It verified the physical bodies of 157 installation, 46 author and 12 runtime entries at their declared locations. The composition index binds the installation-index digest. The same reader rejected a missing runtime member and a one-byte change at unchanged length in a disposable copy.

The amendment records three NSS refusal codes for future joint derivation alongside the 24 maintained-source codes. These are prospective requirements and all generated bindings remain UNISSUED. The R2 production commit and tree were clean, its packet digest matched, and its prior source verdict stands. The 18 production tests were not repeated. This review created only the two additive files in this directory and made no source or external change.
