# Independent review of the original G132 host and source owner revision

**The four R1 source findings are resolved. The R2 source passes review at local source-engineering scope. The frozen propagation inventory needs one evidence amendment before joint derivation.** The independent supplement records the corrected 220 edges and all 172 source holders. Root can adopt this supplement separately from the unchanged source candidate. Issuance remains outstanding.

## Reviewed identity

| Item | Verified value |
|---|---|
| R2 candidate | `d0e5fc660d0b3b9bd11ad6004b1497477cb85755` |
| Tree | `ac1348edf280408ee82e0df9cd0c6563ffdea9b7` |
| Sole parent | `b393a9057c249335e6cdf4ccbb898d192b0830b8` |
| Frozen review ZIP | 439,514 bytes, 18 members, SHA-256 `b177e255940e6fcc384ec0cb6b47304be3ed0877a3a8fc0bd5dfbc4ba535cb48` |
| Frozen manifest | 3,137 bytes, SHA-256 `ea23cfa6e6bb3cc1c387cafff1749ef22029b5bf4639f4ccba68a7bb8a118d24` |
| Author report | 8,030 bytes, SHA-256 `e6cb511d6fa5fcf546bf801081358f4a397aa0135dc2daa421f22050c7e1610e` |
| Recovered R1 tree | `4de924373a3988b9c04e30cb4e6252cccf4e7ea4` |
| Restored continuity | `dg16-dg18-restored-20261122/G0002@9eb19af26c4fe90a35422856c79d5d03ee59ee47` |

All 17 manifest-listed payloads and the manifest matched the ZIP and their on-disk counterparts. Both source archives matched their respective trees, including member modes and contents. All three full-index patches matched independently generated Git diffs. The separately held raw R2 commit matched its Git object. R2 changes four production modules and adds one regression file relative to exact R1. The candidate worktree was clean. This review has a distinct identity. The earlier independent Markdown was never written and the earlier independent readback was absent at its named restored path.

## Receiving of the four source corrections

| Prior finding | Independent conclusion |
|---|---|
| F1. Independent proof census | The real `proof_consumer.validate_first` and `bounded_g1_facts` enforce 1,778 files and 167,283,667 bytes at the lower bounds and 4,096 files and 256 MiB at the upper bounds. The targeted group exercised each validator at its boundaries and neighboring rejected values. The public selected-source labels and actual-census checks agree. |
| F2. Current staging versus historical v4 | The original `run.stage_received_inputs` calls `g3.scope_input_bodies`. Its independently pinned scope requires the maintained subject. After checking all four wires against that scope, the new gate requires v5 and joins the wire commit/tree to that very subject before dispatch. Reviewer controls observed zero dispatcher calls both for the authentic historical v4 wire and for a v5 wire with the wrong tree in a maintained scope. The original direct v4 dispatcher still received the exact historical relation. The direct v5 validator received a synthetic current record with its exact historical evidence. |
| F3. Composer-readable operation loader | The singleton `LOADER_SHA256` declaration passes the original sender’s `ast.literal_eval` contract. `operation.load_selected` compares actual bytes, the literal and the maintained engine tuple before compiling the loader. A targeted disposable test confirmed a mismatch refuses before evaluation. |
| F4. Source diagnostics | Each of the 24 maintained refusal codes survived the actual G3 diagnostic checkpoint, its readback validator, `run.record_failure`, and the bounded public failure projection. The genuine unknown-code control remained `UNCLASSIFIED_EXCEPTION`. |

The reviewer ran three focused regression groups for F1, F3 and F4 and added the F2 checks above. For F2, only the authentic historical acquisition body was accessed from private custody, in memory. The three unrelated historical package inputs were represented by synthetic in-memory placeholders for the two early-refusal checks. The complete positive original-ingress test using the three authentic accompanying records is author evidence in the verified 18-test GREEN. The historical R1 defect run and its outputs in this packet are fresh post-restoration captures. The 18-test suite was not repeated by this reviewer.

## Source identity and historical boundaries

The selected commit is `c53ed7de85de22ce313233472c8d8f02ad8e9d02`, tree `d60733459425a059d961b6adc2aae9811bbb761c`, sole parent `760aaff5c478ff7354d36da186d62daba983aa49`. The pinned e76 manifest and complete e76, M5 and c53 path/mode/blob maps, plus fresh reads of changed Git blobs, reproduced all 1,778 current rows and their canonical digest `86ff7d68f62683b8c624914540816923962a35585ac3fd81649bf95b4e6454fc`. The review checked all 16 cumulative M5 changes and 14 e76 changes, all 74 canonical inputs, all four build owners and all 89 native-source identities. The maintained tuple matches across operation, G3 and proof, including the 108,100-byte Git-successor executor with SHA-256 `b0f936d93e88b63be10d6e739cb8520ed85faaada2bb80406e7f454b6f4acf8d`. The fourth literal image joins the three preserved historical host policy entries.

All five declared semantic owner deltas matched the actual function and declaration ASTs. The retained phase G3 function bodies match b393. Its `JOB_BRANCH` and `CONTROL_BRANCH` declarations differ. The historical pure supplier’s single replacement with `current_original_scope_body()` reproduces exactly 161,682 bytes and SHA-256 `22b822e4aca7957b9ed378b11bd76fa2b59ca147115afeeda7d6186479c05f57`. Phase run’s function bodies likewise match b393 and its `BRANCH`, `MODULE_PINS`, and `G3_DATA_PINS` declarations differ. All 17 projection definitions, roots, supplied names, source descriptors and physical projection bodies match the retained plan.

The versioned composer handoff names the old subject and population rewrites, the two historical package preimages with zero additions, v4 top-level publication fields, v5 nested subject and 16/14 package deltas, the literal loader, and the separate offline assembled ingress. Those are required semantic changes for later joint work. The existing AST equality guard remains in place. The original populations remain 53 hosted, 12 runtime, 46 author, 157 installation, 17 projections and 157 original obligations including 48 DG16.

## Finding P1. The author inventory skips all 12 runtime source bodies

`verify_and_map.py` resolves runtime index members relative to the carrier root and conditionally reads only existing files. The carrier actually stores these 12 members in `source/`. The file-count assertion counts index entries and succeeds even when the resolver skips their bytes. All 12 physical runtime files exist under the correct directory and individually match their declared lengths and SHA-256 values.

Within the author’s exact 160-body scan, all 216 listed edges reproduce. Including the 12 runtime bodies yields 172 holders and 220 edges with the same seed set and recursive literal-pin rule. Four edges were absent.

| Holder | Omitted old pin | Subject |
|---|---|---|
| `source/current_pro_interfaces.py`, line 27 | `58a831b74aec61df5f159ca72cc5c54bc2d50c13f0aea78651bdfe48f0d8e983` | Installation source index |
| `source/current_root_entry.py`, line 21 | `58a831b74aec61df5f159ca72cc5c54bc2d50c13f0aea78651bdfe48f0d8e983` | Installation source index |
| `COMPOSITION_SOURCE_INDEX.json` | `fd415a1ddf82c54962151dbb2713701f68bb012dcdd60bb8a2a53bc9b852ec02` | Runtime `current_pro_interfaces.py` |
| `COMPOSITION_SOURCE_INDEX.json` | `dbb4a94b6957f2334eb67eeea02f5ec371f0ead186b61ab0ffc43c0d1fac7a7a` | Runtime `current_root_entry.py` |

A changed installation index requires both runtime owners to carry its successor digest and the composition index then needs their new identities. The supplied `REVERSE_PINS.json` records all 220 old edges and the physical identities of the 12 runtime files. The author’s original packet should retain its frozen identity. The amended scanner should resolve runtime files from `source/` and require a verified physical body for each indexed member. The corrected inventory can accompany the source commit without rerunning the 18 source controls.

## Disposition and evidence

**Source specification and source quality pass for the four corrections. The original frozen evidence inventory requires amendment.** The independently corrected supplemental inventory satisfies this review’s propagation measurement for Root’s adjudication. Generated manifests, physical placement, host adoption, provider/native outcomes, actual current Root applicability and any protected admission remain unissued. Static source and synthetic fixture success grant no original award.

The review wrote only the files in this review directory. Temporary fixture directories were disposed, bytecode caches were disabled, and the candidate source, index and HEAD were untouched. No historical finalizer, actual selected loader, capability evaluation, hosted/original operation, remote action or private-body export occurred.
