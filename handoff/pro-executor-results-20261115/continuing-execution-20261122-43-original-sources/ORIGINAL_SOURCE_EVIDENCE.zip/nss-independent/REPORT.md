# Independent review — restored original NSS R2

Report state: FINAL

**Recommendation: PASS for this inactive source qualification.** The recovered first-fstat finding is addressed by the exact R2 source. Specification and implementation quality pass at the bounded custody, journal and descriptor scope reviewed here. No new source defect remains open in this review. Dispatch and pin generation remain **UNISSUED**; this report grants no original acceptance, protected readiness, operation, publication or closure authority.

## Reviewer attestation

Reviewer: `/root/g132_r4`; author: `/root/m04_custody`. I did not author or alter the NSS candidate, its tests, its restored packet or its author observations. I am the prior independent R1 reviewer and authored the original first-fstat witness. This is an independently performed successor review by that same reviewer, not a new independent actor or fresh-context formal audit-assess invocation. Prior findings, Root's historical scope and the author's report were visible. Model identity is requested/actual `gpt-6-astra-pro`, self-report only; it is not native host provenance.

Separate completed STATE and ROADMAP reads at the restored run root preceded read-only `--require-current-continuity`, which returned `refs/implementaudit/continuity-receipts/dg16-dg18-restored-20261122/G0002@9eb19af26c4fe90a35422856c79d5d03ee59ee47`. No Root epoch/controller state was changed. Ordinary delegated review authority comes from Root's current assignment; recovered historical scope does not transfer authority.

All reviewer writes and the single disposable fixture were confined to `/workspace/scratch/75de74f83f5c/recovery/restored/original-nss-r2-independent-review`. No source, input packet, provider, private input, original host, model, workflow, capability owner or finalizer was mutated or invoked. The sole source execution was the explicitly authorized TEST_ONLY scoped R2 discriminator described below.

## Exact subject and receiving

Input packet root: `/workspace/scratch/75de74f83f5c/recovery/restored/original-nss-r2`.

| Binding | Exact value |
|---|---|
| Manifest | 9,520 bytes; SHA-256 `184962cb43b6a27135fc02fb0964fdef6ca2d777547df89a9f6713ea87913688` |
| Archive | 79,311 bytes; SHA-256 `22341ed87914964493dde99aae9191a999067653d719719e6c7b2d41f04ef206` |
| Population | 32 payloads / 282,040 bytes; 33 ZIP members including identical manifest |
| New source commit | `cec25d5b49c7fe3c31a61b6d815fc6870250a97b` |
| Tree / sole parent | `2620fc045df51783bf3b681e6383d9e0ee54bd41` / `b393a9057c249335e6cdf4ccbb898d192b0830b8` |
| NSS source | 15,818 bytes; SHA-256 `d3a07500f65be7706cd22beeb02c71a04b7521ac000cb1c3039a7fad742b818c` |
| Focused test source | 18,767 bytes; SHA-256 `27b252dd82a4fea631997d64c93e0d64d1cea3d89ff4f2eeba3e40eba652ec8c` |
| Author report | 8,158 bytes; SHA-256 `ee428b663ea930f76ce78abeef9605b940e63f7d0d800db61bcb3801d28e692e` |

I verified every payload's length, SHA-256, Git blob identity, regular-file/0444 mode, ZIP bytes and ZIP mode; ZIP CRCs, uniqueness and exact member population also pass. The raw commit and parent, all three changed source files and clean worktree agree with the packet. The patch equals the actual default Git diff. Its abbreviated index hashes explain the difference from a full-index rendering; there is no source delta mismatch. Closing readback again found all 32 payloads exact and the source worktree clean. Evidence: `PACKET_READBACK.json` and `FINAL_READBACK.json`.

The eight recovered files match the declared historical digests. They establish exact byte recovery, not restoration of old physical custody, historical commit objects or seals. The old report's anticipatory sealing prose is explicitly superseded by the restored report. Full historical R1/R2 banks, old invocation logs, old complete seal and raw commit objects remain unavailable; I do not reconstruct or rely on them as fresh evidence. The new b393-parent commit is correctly distinguished from historical 1f596010 and 201d6fc6.

## Findings and source assessment

### F1 — first temporary fstat descriptor ownership: countermeasure supported

The exact retained witness is 5,822 bytes, SHA-256 `6d71c27bcb53c5a5b0032298736279aafeb2d6a58e0b0ff7d5b7fd407b6f702c`. It records one owner-open descriptor after successful temporary open followed by injected EIO at the first fstat. Root's recovered historical scope has SHA-256 `024bed5bef6afaf4d6b002c29b457e9c29f903004c09b41b886ba5f4582e21f6`.

The R1-to-R2 production diff consists only of moving the first fstat/identity and two creation-state assignments inside the existing `try` whose `finally` closes that fd. No exchange, unlink, transformation, refusal-code, journal, public-state or caller logic changes in that scoped correction. All pre-existing test methods remain AST-identical; one focused method is added. See `R1_TO_R2_SOURCE.diff` and `SOURCE_AND_EVIDENCE_READBACK.json`.

I ran **one new scoped R2 discriminator**, using the exact retained R1 fixture adapter and the same first-fstat EIO mechanism. R1 and the complete test suite were not rerun. All ten receiving predicates passed: the injected error was observed; the actual temporary fd returned EBADF; the owner descriptor set was empty; no test-utility fd rescue was required; target bytes and inode stayed unchanged; the allocated zero-byte temporary remained; no exchange or unlink occurred; `replacement=NOT_STARTED`, `configured=false`, `temporary_created=false` and `temporary_removed=false` remained truthful; the public no-observation/no-absence-proof meaning remained; `verify_configured` refused. The fixture was disposed and its declared parent is empty. This fresh R2 observation is compared with the retained R1 witness, not relabeled as a recovered historical run. Evidence: `INDEPENDENT_FIRST_FSTAT.json`, `FOCUSED_CONTROL.py`, `FOCUSED_CONTROL_INVOCATION.json`, `FOCUSED_CONTROL_CLEANUP.json` and `OWNED_RESOURCES.json`.

### Retention/exchange specification and quality: PASS at stated scope

Full candidate source inspection supports nondestructive retention. Cleanup no longer checks then unlinks a potentially substituted name. Exchange preserves both entries at the syscall boundary; unsupported or refused exchange has no destructive fallback. Actual displaced preimage and installed postimage are read back and compared with retained bytes and physical identity, allowing only exchange-related ctime change. Late target, same-byte different-inode, or temporary replacement is refused. After exchange has started, failure or interruption remains outcome-unknown and non-replayable. No rollback by name is attempted.

The fresh author evidence contains actual commands, source/test digests, exits, raw stderr and observations: authentic b393 baseline **13 controls / 10 failures / 0 errors**, restored R2 **13 / 0 / 0**. These are fresh restored-workspace observations, not the historical R1 13/1 comparison or original acceptance cases. I inspected their case observations and test source without repeating the bank. R2 retains partial/allocated material, original/foreign inodes, reports the expected refusal states, performs the positive exchange on real disposable files, and ends each observed case with zero owner-open descriptors. Test uid/gid, path mapping and finite-image substitutions are honestly labeled and prove no production host identity or finite-image qualification.

`transform`, `verify_configured`, `public_state`, `need`, `sha`, `encode` and `identity` remain AST-identical to b393. The original 526/518-byte pins, passwd-only transform, six phases, before-controller placement, once-only journal and VM-retention disposition remain. The caller at `run.py`'s `configure_actual_nss` still records attempted preparation before calling, retains the guarded journal, requires configured success and rechecks actual NSS. Public validation accepts finite module refusals and preserves unknown versus false. This source does not claim compare-and-swap, writer exclusion, future namespace stability, complete cleanup or observed VM disposal. These are truthful limits, not newly invented source blockers.

## Genuine generation map remains unissued

`PIN_GENERATION_MAP.json` records actual retained owner locators and hashes. The authentic host population is 53 paths, comprising more than the 42-path episode subtree. All 53 names remain present in the new commit; only NSS differs, and the other 52 entries are exact. Two added test-support files are outside that population. The retained indexes still enumerate 12 runtime bodies, 46 author members and 17 pure projections. Their unchanged counts are source custody facts, not fresh functional qualification; the original 157 functional / 48 DG16 obligations are unchanged.

An initial reviewer check incorrectly equated the episode subtree with all 53 host paths and stopped. The corrected check uses the authentic phase/index 53-path population. This was a reviewer receiving error, not a candidate defect; it caused no candidate mutation or extra test execution and is recorded in `SOURCE_AND_EVIDENCE_READBACK.json`.

| Actual owner / join | Remaining separately commissioned work |
|---|---|
| `sender-author/templates/core/nss_configuration.py`, `inputs/TEMPLATE_INDEX.json`, `AUTHOR_SOURCE_INDEX.json` | Adopt this reviewed semantic delta in the genuine original template/author chain and derive new descriptors. The retained template still has the original 7243 body. |
| Hosted/template `run.py` | Recompute `MODULE_PINS`. Carry the three new NSS refusals into the reviewed closed known-code population: `NSS_CONFIGURATION_EXCHANGE_UNAVAILABLE`, `NSS_CONFIGURATION_EXCHANGE_REFUSED`, `NSS_CONFIGURATION_DISPLACED_PREIMAGE_CHANGED`. The existing dispatcher exception record at line 710 otherwise records these as unclassified, although its NSS public validator dynamically accepts module refusals. |
| Finite finalizer `host_core`, `host_carrier`, `host_finish` | Through a reviewed new successor sequence and genuine new Root admissions, derive run/core bindings, carrier composition/policy/loader, public manifest, bootstrap, common entry/wrappers and public export bindings. Do not run the unchanged historical finalizer, which hardbinds the spent operation. |
| `update_projection` and `model_generation` | Preserve the complete function/class AST-equality guard. A semantic run change needs a separately reviewed new full owner/projection basis. Recompute PHASE, installation index, affected projections/source descriptors, runtime/composition/current-interface/installer joins through their owning sequence; actual host object receiving precedes model generation. No guard is disabled by this recommendation. |

I read these finalizer functions as data only. The genuine future work remains distinct from this reviewed source body. `run.py` is unchanged at 162,161 bytes/SHA-256 `255a88d346f9286c27cffb7ad2de4ba8e4e9972eb188a6ade286bc7dfa68a7cd`; `PUBLIC_PACKET_MANIFEST.json` is unchanged at 5,448 bytes/SHA-256 `bf5d26d26ed5d435d9ee71f1bcd1da292dca248314e6f716db4b3dd08eab4021`. Both still admit only the original NSS 14,718-byte SHA-256 `7243b9a13f9597059d57f22e1cfd4b344a7fd0cee930e9f9d032eee6e9e42270`. They correctly refuse R2 now. The three-code propagation item is future composition work, not a reason to misstate this inactive source as dispatchable or to expand this review into source authoring.

## Terminal scope

Root can adjudicate this inactive source repair using the exact packet and returned evidence. Genuine owner generation, new source applicability/admissions, actual declared-host exchange capability and all original input/currentness/actor/permission requirements remain separate. No old admission is rewritten or inherited, and spent/unknown/queued operations are unchanged. No original credit or new archive/installation/host award is issued here.

Reviewer output files are bound by the sibling `REVIEW_RECEIPT.json`. No further tests are needed for this bounded source disposition.

PASS
