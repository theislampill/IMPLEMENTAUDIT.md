"""New scoped R2 corroboration of retained first-fstat F1 witness; not old logs."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
import errno, hashlib, importlib.util, json, os, time
BASE = Path('/workspace/scratch/75de74f83f5c')
PACKET = BASE/'recovery/restored/original-nss-r2'
OUT = BASE/'recovery/restored/original-nss-r2-independent-review'
FIXTURES = OUT/'fixtures'
SOURCE = PACKET/'recovered/nss_configuration.py'
ADAPTER = PACKET/'recovered/R1_test_nss.py'
WITNESS = PACKET/'recovered/R1_INDEPENDENT_FIRST_FSTAT_WITNESS.json'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(SOURCE) == 'd3a07500f65be7706cd22beeb02c71a04b7521ac000cb1c3039a7fad742b818c'
assert sha(ADAPTER) == 'd9c46541819e1eec989af8237a19cf7a8e8c6abf94cad92cc7774d1288843385'
assert sha(WITNESS) == '6d71c27bcb53c5a5b0032298736279aafeb2d6a58e0b0ff7d5b7fd407b6f702c'
assert json.loads((OUT/'OWNED_RESOURCES.json').read_bytes())['status'] == 'DECLARED_NOT_ACQUIRED'
FIXTURES.mkdir()
spec = importlib.util.spec_from_file_location('independent_retained_fixture', ADAPTER)
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)
fixture.SOURCE, fixture.FIXTURE_PARENT = SOURCE, FIXTURES
case = fixture.Case('positive')
opened, fstat = case.proxy.open, case.proxy.fstat
temporary_fd, injected = None, False
checks, observation = {}, None

def observe_open(path, flags, mode=0o777, **kw):
    global temporary_fd
    fd = opened(path, flags, mode, **kw)
    if path == case.temp.name and flags & os.O_WRONLY:
        temporary_fd = fd
    return fd

def fail_first_temporary_fstat(fd):
    global injected
    if fd == temporary_fd and not injected:
        injected = True
        raise OSError(errno.EIO, 'TEST_ONLY first temporary fstat failure')
    return fstat(fd)

case.proxy.open, case.proxy.fstat = observe_open, fail_first_temporary_fstat
start = time.time_ns()
try:
    case.run()
    checks['injection_executed'] = injected
    checks['expected_eio'] = case.error == 'OSError: [Errno 5] TEST_ONLY first temporary fstat failure'
    checks['target_bytes_and_inode_unchanged'] = case.target.read_bytes() == fixture.BEFORE and case.target.stat().st_ino == case.before_inode
    checks['zero_byte_temporary_retained'] = case.temp.exists() and case.temp.read_bytes() == b''
    checks['no_exchange_or_unlink'] = case.boundary_calls == 0 and case.unlink_calls == 0
    checks['conservative_private_facts'] = case.journal['replacement'] == 'NOT_STARTED' and case.journal['configured'] is False and case.journal['temporary_created'] is False and case.journal['temporary_removed'] is False
    checks['truthful_public_facts'] = case.public['temporary_false_meaning'] == 'NO_DURABLE_COMPLETION_OBSERVATION_NOT_PROOF_OF_ABSENCE' and case.public['temporary_creation_recorded'] is False and case.public['temporary_removal_recorded'] is False
    checks['owner_descriptor_set_empty'] = not case.proxy.opened
    try:
        os.fstat(temporary_fd)
        checks['actual_temporary_fd_closed_EBADF'] = False
    except OSError as e:
        checks['actual_temporary_fd_closed_EBADF'] = e.errno == errno.EBADF
    try:
        case.module.verify_configured(case.journal)
        checks['verify_configured_refuses'] = False
    except ValueError as e:
        checks['verify_configured_refuses'] = str(e) == 'NSS_CONFIGURATION_NOT_COMPLETED'
    observation = {'schema':'g132.restored-r2-independent-first-fstat.v1','classification':'FRESH_SCOPED_R2_CORROBORATION_NOT_HISTORICAL_REPRODUCTION','reviewer':'/root/g132_r4','authority':'NONE','source_sha256':sha(SOURCE),'retained_fixture_sha256':sha(ADAPTER),'historical_r1_witness_sha256':sha(WITNESS),'historical_r1_owner_open_descriptors':json.loads(WITNESS.read_bytes())['owner_open_descriptor_count'],'r2_owner_open_descriptors':len(case.proxy.opened),'independent_injection_executed':injected,'fixture_record_injection_flag_note':'Old Case positive flag is unchanged; the independent wrapper records injection separately, as in the retained witness.','fixture_observation':fixture.OBSERVATIONS[-1],'checks':checks,'start_ns':start,'system_nss_access':False,'original_host_execution':False,'full_suite_execution':False,'r1_reexecution':False,'owned_fixture_root':str(case.root)}
finally:
    rescued = tuple(case.proxy.opened)
    for fd in rescued:
        case.proxy.close(fd)
    case.close()
    cleanup = {'authority':'INDEPENDENT_TEST_FIXTURE_ONLY','explicitly_closed_owner_left_open_count':len(rescued),'remaining_owner_descriptors':len(case.proxy.opened),'fixture_root_absent':not case.root.exists(),'fixture_parent_empty':not list(FIXTURES.iterdir())}
    (OUT/'FOCUSED_CONTROL_CLEANUP.json').write_text(json.dumps(cleanup,indent=2,sort_keys=True)+'\n')
    if observation is not None:
        observation['test_utility_disposal'] = cleanup
        observation['end_ns'] = time.time_ns()
        (OUT/'INDEPENDENT_FIRST_FSTAT.json').write_text(json.dumps(observation,indent=2,sort_keys=True)+'\n')
assert observation is not None and all(checks.values()), checks
assert cleanup['explicitly_closed_owner_left_open_count'] == 0 and cleanup['fixture_parent_empty']
print(json.dumps({'checks':checks,'historical_r1_owner_open_descriptors':1,'fresh_r2_owner_open_descriptors':0,'cleanup':cleanup},sort_keys=True))
