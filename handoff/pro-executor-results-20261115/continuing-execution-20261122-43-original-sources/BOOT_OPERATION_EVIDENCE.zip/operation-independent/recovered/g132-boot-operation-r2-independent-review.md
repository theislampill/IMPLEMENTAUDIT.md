# G132 boot operation R2 independent review

Report state: FINAL

Reviewer `/root/boot_nss_review`, requested/actual model `gpt-6-astra-pro` / `gpt-6-astra-pro` (self-report). Ordinary independent advisory review; no candidate authoring, controller, publication, launch or acceptance authority.

## Binding and scope

The child read STATE and ROADMAP in separate completed actions and ran only the read-only currentness helper, which returned `refs/implementaudit/continuity-receipts/dg16-dg18-successor-20261122/G0007@226d25a02b51da777845f6bb79e8776baf077563`. No Root epoch was invalidated, resumed or minted.

Review subject: `recovery/g132-boot-operation-r2/PACKET.json`, 2,006 bytes, SHA-256 `657f16269dee97a55a063f03df46c4a6ae8f21bd20429db80674b1c4a1ba76c6`. Manifest: 4,675 bytes, SHA-256 `633e495fd6c2fcb66d85d9136fb5f050b9fcc5b4615d14df57aa3cc7c7226277`. Both were independently read and hashed. Source/sole host parent is published `c53ed7de85de22ce313233472c8d8f02ad8e9d02`, source tree `d60733459425a059d961b6adc2aae9811bbb761c`; expected host tree `09880fc9837d571f6daa9f9b0a529f78a9e4732d`.

The packet records its author's earlier G0006 receipt. It is immutable author evidence; this review binds its exact bytes to live G0007 and does not treat the embedded receipt as current authority.

Only operation-delivery receiving, source inspection and meaningful disposable delivery controls are authorized. No published source tests, hosted phase, system NSS, provider, protected execution, remote mutation or upload is permitted. Root alone admits publication/launch and receives actual outcomes.

## Owned evidence and resources

Write set: this report plus `/workspace/scratch/75de74f83f5c/recovery/lanes/g132-boot-operation-r2-review-evidence/`. Disposable controls used descendants of that evidence root under `tmp/`; no real operator entry point or effect owner was invoked. Resource state: all eight disposable roots are absent, the common temporary directory is empty, and every control restored the starting descriptor population. Candidate, source, earlier packets and earlier review reports remain immutable.

## Advisory disposition

**PASS for this exact ordinary-operation R2 packet at the reviewed source and disposable-control scope.** Both rejected R1 delivery failures have concrete countermeasures demonstrated independently with real disposable files. No remaining defect was established in the delivery-only delta. Root may consider its separately authorized ordinary publication/launch after its own currentness, collision and scope checks; this report grants none of that authority and assigns no original award or whole-cell closure.

The immutable rejected R1 packet and GAP report remain preserved. This PASS applies to R2 packet `657f16269dee97a55a063f03df46c4a6ae8f21bd20429db80674b1c4a1ba76c6`; it does not retroactively qualify R1.

## Exact received carrier and host identities

| Item | Independently received identity |
| --- | --- |
| Packet | 2,006 bytes; SHA-256 `657f16269dee97a55a063f03df46c4a6ae8f21bd20429db80674b1c4a1ba76c6` |
| Manifest | 4,675 bytes; SHA-256 `633e495fd6c2fcb66d85d9136fb5f050b9fcc5b4615d14df57aa3cc7c7226277` |
| Archive | 46,938 bytes; SHA-256 `b31ca488e6c808b4ee8ce15c9c80eca2918e6caa5484fd50acd1383721a5fee4` |
| Payload population | All 26 manifest payloads, 143,061 bytes, exactly matched their local files and archive members; the archive contains those 26 plus the exact manifest, 27 unique members total; CRCs passed; no extraction was needed |
| Source / sole host parent | Published `c53ed7de85de22ce313233472c8d8f02ad8e9d02` |
| Source tree / source parent | `d60733459425a059d961b6adc2aae9811bbb761c` / `760aaff5c478ff7354d36da186d62daba983aa49` |
| Derived host tree | `09880fc9837d571f6daa9f9b0a529f78a9e4732d`, independently reproduced with pure Git tree encoding over the actual received source tree and exactly two additions; no Git object, ref or index was written |
| Operation / branch | `G132_BOOT_NSS_20261122_01` / `pro/dg16-g132-boot-nss-20261122-01` |

| Host addition | Bytes | SHA-256 | Git blob |
| --- | ---: | --- | --- |
| `engineering/g132-boot-nss-operation/run-owned.py` | 16,257 | `b4f2ba7707580e528895269e0f9f02867b2983908673fe59936bc0b4d514a873` | `0b65e11df13b2c98cdf1e1f8096ab1987d483a06` |
| `.github/workflows/dg16-g132-boot-nss.yml` | 15,904 | `68d65ab04421f28dfbb44c645ab5e72a113613e157c415cfd0271656e7fd4c20` | `268d5f683eb174970c62c42b65df67c73c3424c4` |

Both additions are mode 100644. The archive and manifest remain unchanged at the closing read. Actual remote host publication, provider host commit, workflow run and artifact are prospective and were not observed in this review.

## Independent findings

| Finding | Disposition and evidence |
| --- | --- |
| R1 O-D1: collector refusal still selected an oversized upload directory | **PASS — countermeasure demonstrated.** R2 receives the bounded named inputs into memory, constructs the manifest, and checks the complete byte total before creating any export directory (operator lines 187–219). The exact R1 2,098,176-byte witness now refuses with no export directory or selected upload files. The original input bytes remain unchanged. |
| R1 O-D2: successful manifest omitted a file selected by directory upload | **PASS — countermeasure demonstrated.** R2 exports only the received finite named population into a fresh separate directory; raw logs are not the upload source. The workflow lists thirty literal filenames, with no directory input or wildcard. An unexpected raw-log member remains locally intact and is neither copied nor selected. A later unlisted export basename is also outside the explicit selection. |
| Manifest-inclusive bound | **PASS.** `report_bound_includes_manifest=true` has executable meaning: the manifest is built before the second aggregate check, and the final verifier counts it again. A 2,097,151-byte payload, which alone would fit, is refused before directory creation because its mandatory manifest would exceed the 2,097,152-byte total. A successful adverse-evidence export independently totaled 2,069 bytes including the manifest. |
| Export receiving and late drift | **PASS.** The fresh export is created exclusively through a held parent; members are written through its directory descriptor, set to 0444, and read back with exact physical identity. The directory is set to 0555. `verify_export` requires the exact population, holds all member descriptors through later reads, rechecks earlier bytes/identities and enforces the total again. An injected unexpected member and actual earlier-file drift during the later manifest read both refuse. |
| Collection and verification failure gate | **PASS.** Collection retains `if: always()` and now has `id: collect`; the upload condition is exactly `always() && steps.collect.outcome == 'success'`, with no `continue-on-error`. Successful export verification is inside collection and must be followed by normal collection completion. A real parent-fsync error injected after successful verification leaves the files retained but makes collection fail; the exact upload gate is then false. Failure, cancellation and skipped collection also do not qualify that condition. |
| Partial, adverse, empty and missing evidence | **PASS.** A malformed partial preparation receipt, zero-byte stderr and `inputs.status` containing the actual adverse value `2\n` were preserved byte for byte. Missing members remain explicitly marked absent in the 29-row manifest. The manifest remains `authority=NONE`, `admission=UNQUALIFIED`, and `original_execution=false`. Successful collection of adverse evidence does not assert successful observation phases. |
| Failed partial export and collision custody | **PASS.** A real partial destination write followed by error retains the partial export, leaves its source intact and does not enable upload. A preexisting export causes exclusive-creation refusal, remains byte exact and is neither reused nor deleted. |
| Non-delivery regression boundary | **PASS.** Independently parsed ASTs prove all operator code except `copy_exact`, new `verify_export`, `collect` and the descriptive module docstring is unchanged from actual Root R1. Exact configuration comparison proves all non-delivery workflow settings and phases remain unchanged, apart from the derived operator hash. Every Bash block passes syntax checking; Python compilation passes. |

These are advisory findings at exact packet scope. Root retains ledger classification and closure authority.

## Nine independent real-file controls

The reviewer wrote a separate control program against pinned R2 operator and unchanged driver bytes; the author's test suite was read for coverage but was not rerun or substituted for these controls.

| Control | Actual observed behavior |
| --- | --- |
| Original R1 aggregate witness | Two individually permissible 1,049,088-byte inputs refuse before export creation; original files remain unchanged; upload eligibility is false. |
| Original R1 unlisted member plus adverse evidence | Unexpected raw-log file stays untouched; only the partial preparation, empty stderr, adverse status and manifest are selected; missing evidence remains recorded. |
| Unlisted name added after successful collection | The added disposable basename remains present but is absent from all thirty literal upload paths. This does not claim exclusion of a privileged writer replacing an allowed filename. |
| Manifest-overhead overflow | The 2,097,151-byte payload refuses once manifest bytes are included, with no export created. |
| Actual partial destination write | Seven bytes are written before injected error; retained partial output is not upload-eligible and the original input is unchanged. |
| Actual failure after successful verification | Export verification finishes, then a real parent `fsync` is followed by an injected error. Despite complete retained files, collection fails and the upload gate is false. |
| Export collision | Existing foreign export manifest remains exact; no overwrite, reuse or deletion occurs; collection refuses. |
| Unexpected export member during copying | Closing population verification refuses; the unexpected disposable member remains intact and upload is disabled. |
| Earlier member changes during later read | A real mutation while the manifest is opened is caught by the held-member closing check; collection refuses and upload is disabled. |

All nine controls passed in one execution. Gate outcomes were derived from the exact checked workflow expression and real collector outcomes; no GitHub workflow or action was run. The condition's static outcome table is success=true, failure=false, cancelled=false, skipped=false. This is configuration evidence, not native workflow outcome proof.

## Preserved operational boundaries

The source selection, exact driver pin, fresh public Git source preparation, source/parent joins, launcher and scoped policy owners, boot NSS lifecycle, separate namespace process and finite-input observations are unchanged. The workflow still requires attempt one and the same exact image/version context, read-only repository permission, pinned actions, clean root invocation and original resource limits. The separate always-run NSS and policy finalizers remain observational; they do not retry provisioning, restore NSS, unload policy or repair predecessor process custody.

The new export limit covers selected **uncompressed file bytes including the manifest**. Provider ZIP overhead and actual upload behavior remain unobserved here. The operator's reads are closing snapshots. File/directory permissions and literal selection do not establish exclusion of arbitrary later privileged replacement of an allowed member. Actual receiving must still bind the produced ZIP population, bytes, hashes, manifest, phase statuses, provider run/attempt/boot and exact host/source identities. A complete artifact or later readback cannot erase a nonzero or unknown required producer exit.

When collection itself refuses, the workflow intentionally does not upload an unchecked export. Partial source logs and failed export material remain local; later VM disposal may remove them and is not observed. This is truthful failure containment, not proof that all operation evidence was successfully delivered. There is no fallback directory sweep or automatic retry.

The original R2 temporary-lease cleanup refusal, the distinct original configured-until-VM-disposal lifecycle, and the unperformed copied-provider runtime premise remain separate. No original denominator, source requirement, private-input requirement or native admission is relaxed. Run `44888568054` remains `SPENT_NO_RETRY`; historical `301aeecd…` and A4-07 remain `UNKNOWN_NO_REPLAY`; queued `43098152901` is outside this work.

## Retained review evidence

All paths below are under `recovery/lanes/g132-boot-operation-r2-review-evidence/`.

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `PACKET_RECEIVING.json` | 1,582 | `35e21d68e24ec427c99cca2829bc1bfbbc4d960249eac723f7b1d9749cf1ffb7` |
| `receive_r2.py` | 7,809 | `fcc2b0153a26cc8cc57d182a3f012e4a5e1a4dc4905addda9c8312f24f084d1b` |
| `DELIVERY_CONTROLS.json` | 4,877 | `eab7bc081bedcc684e79c5ac835491cf61d4ace2cbc53b9613837b697e58d446` |
| `delivery_controls.py` | 12,380 | `942514799fc095db2b02ba5c2176725f194cc00f63f1d581a9d4e921d7ad4e5d` |

`CLOSING_INVENTORY.json` records those exact files, clean source, empty temporary directory, unchanged packet/manifest/archive and zero hosted, upload, remote or controller mutations. The source controls were not rerun. Previous source and R1 operation reports remain frozen.

## Remaining Root work

Root must independently decide whether to admit the exact ordinary operation, verify current source/branch/collision premises, publish only the reviewed host tree with the exact source parent if admitted, and receive actual outcomes at their genuine scope. Any unexpected actual state or changed packet requires reconciliation before effects. Future protected work still requires complete original readiness and a fresh exact owner grant. This report supplies evidence for that bounded ordinary decision; it creates no readiness, launch, publication or original acceptance authority.

PASS
