#!/usr/bin/env python3
"""Fresh read-only byte/identity join after recovery; no historical tests rerun."""
import ast
import hashlib
import json
from pathlib import Path
import stat
import subprocess

HERE = Path(__file__).resolve().parent
CODE = Path('/workspace/scratch/75de74f83f5c/recovery/restored/boot-operation-r2')
REPO = Path('/workspace/scratch/75de74f83f5c/implementaudit')
EXPECTED = {
    'recovered/g132-boot-operation-r2-independent-review.md': (14315,'cdcb4aea519202e5961af2e6bfa9835b44a40ea37148de0a4227176736937c70'),
    'recovered/DELIVERY_CONTROLS.json': (4877,'eab7bc081bedcc684e79c5ac835491cf61d4ace2cbc53b9613837b697e58d446'),
}
recovered=[]
for name,(size,digest) in EXPECTED.items():
    path=HERE/name
    assert stat.S_ISREG(path.lstat().st_mode)
    raw=path.read_bytes()
    assert len(raw)==size and hashlib.sha256(raw).hexdigest()==digest
    recovered.append(dict(path=name,bytes=size,sha256=digest,exact_historical_bytes=True))
raw=(CODE/'PACKET.json').read_bytes()
packet_sha=hashlib.sha256(raw).hexdigest()
assert len(raw)==2006 and packet_sha=='657f16269dee97a55a063f03df46c4a6ae8f21bd20429db80674b1c4a1ba76c6'
packet=json.loads(raw)
controls=json.loads((HERE/'recovered/DELIVERY_CONTROLS.json').read_bytes())
assert controls['packet_sha256']==packet_sha and controls['control_count']==len(controls['controls'])==9
assert all(row['result']=='PASS' for row in controls['controls'])
assert controls['gate_table']==dict(success=True,failure=False,cancelled=False,skipped=False)
host_files=[]
for row in packet['host_files']:
    path=CODE/'content'/row['path']
    assert path.resolve().is_relative_to(CODE) and stat.S_ISREG(path.lstat().st_mode)
    body=path.read_bytes()
    assert len(body)==row['bytes'] and hashlib.sha256(body).hexdigest()==row['sha256']
    assert hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()==row['git_blob']
    assert row['mode']=='100644'
    host_files.append(row)
operator=(CODE/'content/engineering/g132-boot-nss-operation/run-owned.py').read_bytes()
constants={n.targets[0].id:ast.literal_eval(n.value) for n in ast.parse(operator).body
           if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)
           and n.targets[0].id in ('SOURCE_COMMIT','SOURCE_TREE','BASE_COMMIT','DRIVER','DRIVER_PIN')}
source='c53ed7de85de22ce313233472c8d8f02ad8e9d02'
assert constants['SOURCE_COMMIT']==packet['source_commit']==packet['host_parent']==source
assert constants['SOURCE_TREE']==packet['source_tree']=='d60733459425a059d961b6adc2aae9811bbb761c'
assert constants['BASE_COMMIT']==packet['source_sole_parent']=='760aaff5c478ff7354d36da186d62daba983aa49'
workflow=json.loads((CODE/'content/.github/workflows/dg16-g132-boot-nss.yml').read_bytes())
collect,upload=workflow['jobs']['qualify']['steps'][-2:]
assert collect['id']=='collect' and collect['if']=='always()' and 'continue-on-error' not in collect
assert upload['if']=="always() && steps.collect.outcome == 'success'"
phases=['prepare','launcher','policy','boot-nss','namespace','inputs','nss-finalize','finalize']
names=['preparation.json','boot-nss.json','namespace.json','inputs.json','nss-finalize.json']
names += [phase+'.'+suffix for phase in phases for suffix in ('stdout','stderr','status')]
names += ['manifest.json']
prefix='${{ runner.temp }}/g132-boot-nss-export-${{ github.run_id }}-1/'
assert upload['with']['path'].splitlines()==[prefix+name for name in names]
assert packet['report_bound_including_manifest']==2097152
def git(*args):
    return subprocess.check_output(['git','-C',str(REPO),*args])
assert git('show','-s','--format=%H%n%T%n%P',source).decode().splitlines()==[source,packet['source_tree'],packet['source_sole_parent']]
driver=git('show',source+':'+constants['DRIVER'])
assert dict(bytes=len(driver),sha256=hashlib.sha256(driver).hexdigest())==constants['DRIVER_PIN']
flat={}
for row in git('ls-tree','-rz',source).split(b'\0'):
    if not row: continue
    meta,name=row.split(b'\t',1)
    mode,kind,blob=meta.decode().split()
    flat[name.decode()]=(mode,blob)
def tree_hash(entries):
    root={}
    for path,value in entries.items():
        parts=path.split('/');node=root
        for part in parts[:-1]: node=node.setdefault(part,{})
        node[parts[-1]]=value
    def digest(node):
        raw=b''
        for name,value in sorted(node.items(),key=lambda item:(item[0]+('/' if isinstance(item[1],dict) else '')).encode()):
            mode,blob=('40000',digest(value)) if isinstance(value,dict) else value
            raw+=mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(blob)
        return hashlib.sha1(b'tree '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    return digest(root)
assert tree_hash(flat)==packet['source_tree']
for row in host_files:
    assert row['path'] not in flat
    flat[row['path']]=(row['mode'],row['git_blob'])
assert tree_hash(flat)==packet['expected_host_tree']=='09880fc9837d571f6daa9f9b0a529f78a9e4732d'
result=dict(schema='g132.boot-r2.restored-independent-receiving.v1',authority='NONE',
    continuity_receipt='refs/implementaudit/continuity-receipts/dg16-dg18-restored-20261122/G0002@9eb19af26c4fe90a35422856c79d5d03ee59ee47',
    recovery_method='Exact complete retained report-authoring patches and complete canonical control-output bytes; original lengths and SHA256 verified',
    recovered_historical_artifacts=recovered,packet_bytes=2006,packet_sha256=packet_sha,
    exact_recovered_host_files=host_files,source_commit=source,source_tree=packet['source_tree'],
    source_parent=packet['source_sole_parent'],derived_host_tree=tree_hash(flat),
    published_driver_pin_exact=True,upload_names=names,collect_success_gate_exact=True,
    preserved_historical_control_count=9,historical_controls_reexecuted=False,
    fresh_receiving_only=True,old_archive_restored=False,old_manifest_restored=False,
    git_objects_written=False,controller_mutations=0,remote_mutations=0,hosted_executions=0,
    upload_executions=0,original_tests_rerun=False)
(HERE/'FRESH_RECEIVING.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,indent=2,sort_keys=True))
