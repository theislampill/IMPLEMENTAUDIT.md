# Frozen boot operation R2 byte recovery

Status: COMPLETE FOR THE THREE IDENTIFIED OPERATION FILES; historical evidence
carrier remains partially unavailable. This is a new recovery record, not a
restored historical report.

The delegated owner is Root under controller `dg16-dg18-restored-20261122`.
Separate STATE and ROADMAP reads followed by read-only currentness returned
`refs/implementaudit/continuity-receipts/dg16-dg18-restored-20261122/G0001@8700a9894d82529a28b164135ea91bb5fdce2198`.

Scope: restore frozen operator, workflow and packet bytes from retained code and
published inputs, then compare exact length, SHA-256 and Git object identities.
New derivation scripts are labelled as recovery artifacts. Historical logs,
test outputs, manifest and archive are unavailable unless their exact original
bytes can be recovered. No test, operator, hosted step or original operation is
executed in this recovery. No source, controller, Git object, ref or remote
mutation is authorized in this child lane.

Acceptance is exact equality to Root's recorded digests. A mismatch remains
unrecovered. No new result substitutes for old execution evidence. Rollback, if
needed, is retention of these separately owned recovery artifacts; nothing in
the original source or earlier packets is changed.

## Recovered exact original bytes

| Artifact under this directory | Bytes | SHA-256 |
|---|---:|---|
| `content/engineering/g132-boot-nss-operation/run-owned.py` | 16,257 | `b4f2ba7707580e528895269e0f9f02867b2983908673fe59936bc0b4d514a873` |
| `content/.github/workflows/dg16-g132-boot-nss.yml` | 15,904 | `68d65ab04421f28dfbb44c645ab5e72a113613e157c415cfd0271656e7fd4c20` |
| `PACKET.json` | 2,006 | `657f16269dee97a55a063f03df46c4a6ae8f21bd20429db80674b1c4a1ba76c6` |

The operator Git blob is `0b65e11df13b2c98cdf1e1f8096ab1987d483a06`;
the workflow blob is `268d5f683eb174970c62c42b65df67c73c3424c4`.
Both proposed host entries are mode `100644`.

Pure in-memory Git tree encoding, starting from the read existing source tree
`d60733459425a059d961b6adc2aae9811bbb761c`, gives the exact expected host tree
`09880fc9837d571f6daa9f9b0a529f78a9e4732d`. The proposed host parent remains
`c53ed7de85de22ce313233472c8d8f02ad8e9d02`; its sole source parent is
`760aaff5c478ff7354d36da186d62daba983aa49`. This calculation creates no Git object
or host commit. It proves content identity, not remote availability or admission.

## Recovery route and new records

The data input is the exact published results42 commit
`5a64b89d5a4c9d855b2364f2adb5c607baf6ea5b` and its
`handoff/pro-executor-results-20261115/continuing-execution-20261122-42-qualifications/G132_RECEIVED_EVIDENCE.zip`:
205,280 bytes, SHA-256
`a6fd8265c468c1c2b7ed68e9013e803581ea8c02af46dc32ce9a6a91ff44f4e2`.
Only its public host operator and workflow members were extracted into
`published-inputs/`. Those match 10,595 bytes / `f636fca21f30850b03adef11e9b854549789a7d5ffb213efc40077bde314c40f`
and 10,976 bytes / `22a2af4e364339a54e4df99ed81d68653ca9b0a4c534d05d346acdc16afbc925`.

`derive_r1.py` is a newly written recovery derivation using those published
bytes and retained original transformations. It recovered both R1 baselines
exactly: operator 10,903 bytes / `567c9861d13593397e8e9a065f70d24a6a3d9176abb3741c8896adfb180b6321`
and workflow 13,479 bytes / `925176d4cfcfbe6dc52c3312373debb1757c7df3e0f425e653d91b0182d48adc`.
`R1_RECOVERY_CHECK.json` records that comparison.

`generate_operation.py` and the two `generator/*.pyfrag` files were
retranscribed from retained generation text. Their output matched both frozen
R2 digests above on the first generation. The generator text itself has no
independently retained old digest here; its recovered output does.
`verify_recovery.py` is new recovery code. It derived the packet from retained
original values and verified its old digest, both host blob identities, the
existing source identity and the proposed host tree.
`RECOVERY_VERIFICATION.json` contains the new byte/object checks and exact
read-only Git command list. `RECOVERY_INVENTORY.json` inventories the current
recovery files and their measured hashes; it is not the old packet manifest.

## Unrecovered historical evidence

| Historical item | Recorded bytes | Recorded SHA-256 | Current disposition |
|---|---:|---|---|
| Frozen operation R2 manifest | 4,675 | `633e495fd6c2fcb66d85d9136fb5f050b9fcc5b4615d14df57aa3cc7c7226277` | Exact body unavailable in this lane |
| Frozen operation R2 ZIP | 46,938 | `b31ca488e6c808b4ee8ce15c9c80eca2918e6caa5484fd50acd1383721a5fee4` | Exact archive unavailable in this lane |
| Historical RED/GREEN and 26-check outputs | Unavailable | Unavailable | Not reconstructed or rerun |
| Independent R2 review, recorded prefix `cdcb4aea` | Separate owner | Separate owner | Root/reviewer recovery; not claimed here |

No substitute historical log, manifest or archive was generated. Earlier test
claims remain reported history until their authentic evidence is recovered by
the responsible lane. No delivery control, source test, operator, hosted step,
system NSS action, private provider preparation or original execution occurred.

The old G0006 receipt inside exact `PACKET.json` is deliberately preserved as
historical bytes. Recovery began under restored G0001 above and closed after a separate STATE/ROADMAP/currentness rebind to restored G0002: `refs/implementaudit/continuity-receipts/dg16-dg18-restored-20261122/G0002@9eb19af26c4fe90a35422856c79d5d03ee59ee47`. Neither the
old packet nor this child report transfers authority. Root retains all review,
admission, publication and launch decisions.
