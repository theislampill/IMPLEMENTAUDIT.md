#!/usr/bin/env python3
"""NEW recovery-only byte/object verification; never executes recovered code.

PACKET.json is derived from retained original values. Its old continuity receipt
is retained as historical packet data, not asserted as current authority.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/75de74f83f5c/implementaudit')
SOURCE = 'c53ed7de85de22ce313233472c8d8f02ad8e9d02'
TREE = 'd60733459425a059d961b6adc2aae9811bbb761c'
PARENT = '760aaff5c478ff7354d36da186d62daba983aa49'
EXPECTED_HOST_TREE = '09880fc9837d571f6daa9f9b0a529f78a9e4732d'
CURRENT_RECEIPT = 'refs/implementaudit/continuity-receipts/dg16-dg18-restored-20261122/G0001@8700a9894d82529a28b164135ea91bb5fdce2198'
host_files = [
    dict(path='engineering/g132-boot-nss-operation/run-owned.py', mode='100644',
         git_blob='0b65e11df13b2c98cdf1e1f8096ab1987d483a06', bytes=16257,
         sha256='b4f2ba7707580e528895269e0f9f02867b2983908673fe59936bc0b4d514a873'),
    dict(path='.github/workflows/dg16-g132-boot-nss.yml', mode='100644',
         git_blob='268d5f683eb174970c62c42b65df67c73c3424c4', bytes=15904,
         sha256='68d65ab04421f28dfbb44c645ab5e72a113613e157c415cfd0271656e7fd4c20')
]
packet = dict(
    schema='g132.boot-nss.operation-r2-proposal.v1', authority='NONE', revision='DELIVERY_R2',
    status='FROZEN_AWAITING_INDEPENDENT_REVIEW_AND_ROOT_ADMISSION',
    operation='G132_BOOT_NSS_20261122_01', branch='pro/dg16-g132-boot-nss-20261122-01',
    workflow_attempt=1, automatic_retry=False, source_commit=SOURCE, source_tree=TREE,
    source_sole_parent=PARENT, host_parent=SOURCE, expected_host_tree=EXPECTED_HOST_TREE,
    host_files=host_files,
    prior_Root_packet_sha256='9b44b6e29e55a69a6e62b0d82ca11dc19925ef607d15c90a81ea24fff720adec',
    prior_author_packet_manifest_sha256='10c69285e60dcd84ccf515b5bc860f8c2f7cf5238dcb742a2306ed7c45bc3460',
    correction_scope='Public artifact collection and upload boundary only',
    report_bound_including_manifest=2097152, delivery_schema='g132.boot-nss-ordinary-delivery.v2',
    currentness_receipt='refs/implementaudit/continuity-receipts/dg16-dg18-successor-20261122/G0006@4d63894a6bac6df33e0c42aec3a5c55269e201ea',
    source_changes=False, hosted_execution=False, upload_execution=False, remote_mutation=False,
    original_execution=False, original_awards=[], protected_readiness=False,
    provider_acquisition=False, copied_runtime_preparation=False
)
packet_raw = (json.dumps(packet, sort_keys=True, indent=2) + '\n').encode()
packet_observed = dict(bytes=len(packet_raw), sha256=hashlib.sha256(packet_raw).hexdigest())
packet_expected = dict(bytes=2006, sha256='657f16269dee97a55a063f03df46c4a6ae8f21bd20429db80674b1c4a1ba76c6')
assert packet_observed == packet_expected, packet_observed
(HERE / 'PACKET.json').write_bytes(packet_raw)

def object_id(kind, raw):
    return hashlib.sha1(kind + b' ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

actual_files = []
for expected in host_files:
    raw = (HERE / 'content' / expected['path']).read_bytes()
    actual = dict(path=expected['path'], mode='100644', git_blob=object_id(b'blob', raw),
                  bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    assert actual == expected, actual
    actual_files.append(actual)

git_environment = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_NO_REPLACE_OBJECTS='1', GIT_OPTIONAL_LOCKS='0')
git_commands = []
def git(*args):
    command = ['git', '-c', 'protocol.allow=never', *args]
    git_commands.append(command)
    return subprocess.check_output(command, cwd=REPO, env=git_environment)

source_raw = git('cat-file', 'commit', SOURCE)
assert object_id(b'commit', source_raw) == SOURCE
source_headers = source_raw.split(b'\n\n', 1)[0].splitlines()
assert [line[5:].decode() for line in source_headers if line.startswith(b'tree ')] == [TREE]
assert [line[7:].decode() for line in source_headers if line.startswith(b'parent ')] == [PARENT]

cache = {}
def encode_tree(entries):
    result = []
    for name in sorted(entries, key=lambda name: name + (b'/' if entries[name][1] == b'tree' else b'')):
        mode, kind, oid = entries[name]
        result.append(mode + b' ' + name + b'\0' + bytes.fromhex(oid))
    return b''.join(result)

def load_tree(oid):
    if oid is None:
        return {}
    if oid not in cache:
        entries = {}
        for row in git('ls-tree', '-z', oid).split(b'\0'):
            if not row:
                continue
            metadata, name = row.split(b'\t', 1)
            mode, kind, child = metadata.split(b' ')
            entries[name] = (mode.lstrip(b'0'), kind, child.decode())
        assert object_id(b'tree', encode_tree(entries)) == oid
        cache[oid] = entries
    return dict(cache[oid])

def replace(oid, parts, blob):
    entries = load_tree(oid)
    name = parts[0]
    if len(parts) == 1:
        entries[name] = (b'100644', b'blob', blob)
    else:
        current = entries.get(name)
        assert current is None or current[1] == b'tree'
        child = replace(current[2] if current else None, parts[1:], blob)
        entries[name] = (b'40000', b'tree', child)
    new_id = object_id(b'tree', encode_tree(entries))
    cache[new_id] = entries
    return new_id

host_tree = TREE
for row in actual_files:
    host_tree = replace(host_tree, row['path'].encode().split(b'/'), row['git_blob'])
assert host_tree == EXPECTED_HOST_TREE, host_tree

record = dict(
    schema='g132.boot-operation-r2.recovery-verification.v1', authority='NONE',
    current_receipt=CURRENT_RECEIPT,
    packet=dict(path='PACKET.json', **packet_observed, exact_original_bytes=True,
                historical_receipt_retained_as_data=True),
    host_files=actual_files, all_host_files_exact_original_bytes=True,
    source_commit=SOURCE, source_tree=TREE, source_sole_parent=PARENT,
    expected_host_tree=EXPECTED_HOST_TREE, calculated_host_tree=host_tree,
    tree_calculation='Pure in-memory Git tree encoding; read existing Git objects only',
    git_commands=git_commands,
    recovered_from='Published results42 carrier bytes and retained generator/transformations',
    execution_scope='Recovery generator, byte hashes and read-only object calculation only',
    tests_executed=False, operator_executed=False, hosted_execution=False,
    original_execution=False, source_changes=False, git_object_writes=False,
    ref_changes=False, remote_effects=False,
    historical_evidence_unavailable=[
        dict(name='frozen operation R2 manifest', expected_bytes=4675,
             expected_sha256='633e495fd6c2fcb66d85d9136fb5f050b9fcc5b4615d14df57aa3cc7c7226277',
             status='UNRECOVERED_EXACT_BYTES'),
        dict(name='frozen operation R2 ZIP', expected_bytes=46938,
             expected_sha256='b31ca488e6c808b4ee8ce15c9c80eca2918e6caa5484fd50acd1383721a5fee4',
             status='UNRECOVERED_EXACT_BYTES'),
        dict(name='historical delivery-control RED/GREEN outputs and 26-check output',
             status='UNRECOVERED_EXACT_BYTES_NOT_REEXECUTED'),
        dict(name='historical independent R2 review cdcb4aea…',
             status='SEPARATE_ROOT_REVIEWER_RECOVERY_NOT_CLAIMED_HERE')
    ])
(HERE / 'RECOVERY_VERIFICATION.json').write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
print(json.dumps(dict(packet=packet_observed, host_files=actual_files, host_tree=host_tree,
                     historical_manifest_and_zip='UNRECOVERED', tests_executed=False), indent=2))
