#!/usr/bin/env python3
"""Generate the operation-only R2 from exact provider-bound R1 bytes."""
import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
OPERATOR = 'engineering/g132-boot-nss-operation/run-owned.py'
WORKFLOW = '.github/workflows/dg16-g132-boot-nss.yml'
old = (HERE / 'baseline' / OPERATOR).read_bytes()
workflow_raw = (HERE / 'baseline' / WORKFLOW).read_bytes()
assert hashlib.sha256(old).hexdigest() == '567c9861d13593397e8e9a065f70d24a6a3d9176abb3741c8896adfb180b6321'
assert hashlib.sha256(workflow_raw).hexdigest() == '925176d4cfcfbe6dc52c3312373debb1757c7df3e0f425e653d91b0182d48adc'
source = old.decode()
start, end = source.index('def copy_exact('), source.index('@contextmanager\ndef prepared_binding(')
source = source[:start] + (HERE / 'generator/copy_export.pyfrag').read_text() + '\n\n\n' + source[end:]
start, end = source.index('def collect('), source.index('def main():')
source = source[:start] + (HERE / 'generator/collect.pyfrag').read_text() + '\n\n\n' + source[end:]
source = source.replace('Frozen distinct boot NSS operator proposal; local source identity requires Root rebind/review.',
                        'Provider-bound ordinary boot NSS operator; R2 releases only a bounded verified public export.')
ast.parse(source)
operator_hash = hashlib.sha256(source.encode()).hexdigest()
workflow = json.loads(workflow_raw)
steps = workflow['jobs']['qualify']['steps']
collect = next(step for step in steps if 'run-owned.py" collect\n' in step.get('run', ''))
collect['id'] = 'collect'
collect['name'] = 'Collect and verify a fresh bounded export of exact complete or partial public bytes'
upload = steps[-1]
upload['if'] = "always() && steps.collect.outcome == 'success'"
public_names = ['preparation.json', 'boot-nss.json', 'namespace.json', 'inputs.json', 'nss-finalize.json']
phases = ['prepare', 'launcher', 'policy', 'boot-nss', 'namespace', 'inputs', 'nss-finalize', 'finalize']
public_names += [phase + '.' + suffix for phase in phases for suffix in ('stdout', 'stderr', 'status')]
public_names += ['manifest.json']
assert len(public_names) == len(set(public_names)) == 30
upload['with']['path'] = '\n'.join('${{ runner.temp }}/g132-boot-nss-export-${{ github.run_id }}-1/' + name for name in public_names)
for step in steps:
    if 'run' in step:
        step['run'] = step['run'].replace('567c9861d13593397e8e9a065f70d24a6a3d9176abb3741c8896adfb180b6321', operator_hash)
for name, raw in [(OPERATOR, source.encode()), (WORKFLOW, (json.dumps(workflow, indent=2) + '\n').encode())]:
    target = HERE / 'content' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    print(json.dumps(dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()), sort_keys=True))
