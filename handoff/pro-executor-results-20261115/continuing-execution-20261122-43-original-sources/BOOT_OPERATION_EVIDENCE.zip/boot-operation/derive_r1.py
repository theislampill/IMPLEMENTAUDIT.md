#!/usr/bin/env python3
"""NEW recovery derivation from published results42 plus retained transformations.

This file is not asserted to be the former generator. It never executes any
operator or test; it restores candidate bytes and checks recorded old digests.
"""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile
import io

HERE = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/75de74f83f5c/implementaudit')
RESULTS = '5a64b89d5a4c9d855b2364f2adb5c607baf6ea5b'
CARRIER = 'handoff/pro-executor-results-20261115/continuing-execution-20261122-42-qualifications/G132_RECEIVED_EVIDENCE.zip'
carrier_raw = subprocess.check_output(['git', 'show', RESULTS + ':' + CARRIER], cwd=REPO)
assert len(carrier_raw) == 205280
assert hashlib.sha256(carrier_raw).hexdigest() == 'a6fd8265c468c1c2b7ed68e9013e803581ea8c02af46dc32ce9a6a91ff44f4e2'
with zipfile.ZipFile(io.BytesIO(carrier_raw)) as archive:
    profile_operator = archive.read('source/host/engineering/g132-host-profile-operation/run-owned.py')
    profile_workflow = archive.read('source/host/.github/workflows/dg16-g132-host-profile-successor.yml')
assert len(profile_operator) == 10595
assert hashlib.sha256(profile_operator).hexdigest() == 'f636fca21f30850b03adef11e9b854549789a7d5ffb213efc40077bde314c40f'
assert len(profile_workflow) == 10976
assert hashlib.sha256(profile_workflow).hexdigest() == '22a2af4e364339a54e4df99ed81d68653ca9b0a4c534d05d346acdc16afbc925'
for name, raw in [('host-profile-operator.py', profile_operator), ('host-profile-workflow.json', profile_workflow)]:
    target = HERE / 'published-inputs' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)

source = profile_operator.decode()
replacements = [
    ('Frozen prospective ordinary operator; not executed by candidate preparation.',
     'Frozen distinct boot NSS operator proposal; local source identity requires Root rebind/review.'),
    ("SOURCE_COMMIT = '4ddd6403b70835339b6f55aeff9478b6d061247b'", "SOURCE_COMMIT = 'c53ed7de85de22ce313233472c8d8f02ad8e9d02'"),
    ("SOURCE_TREE = '969df99854f9ca87fda54f21585864d7a0d61a38'", "SOURCE_TREE = 'd60733459425a059d961b6adc2aae9811bbb761c'"),
    ('test-support/g132-host-profile-successor/ordinary_qualifier.py', 'test-support/g132-boot-nss/ordinary_qualifier.py'),
    ("DRIVER_PIN = {'bytes': 14021, 'sha256': 'e316224f5492241b529161d37b4dbce5c63f6cfc038d0c750db82aae3de13a8e'}", "DRIVER_PIN = {'bytes': 14658, 'sha256': '5eea85cd1dc76c4edc2e24141da8c76ead9167231bee7a6b85743dcd4cd7e382'}"),
    ("PHASES = ('prepare', 'launcher', 'policy', 'namespace', 'inputs', 'finalize', 'collect')", "PHASES = ('prepare', 'launcher', 'policy', 'boot-nss', 'namespace', 'inputs', 'nss-finalize', 'finalize', 'collect')"),
    ('g132.host-profile-preparation.v1', 'g132.boot-nss-source-preparation.v1'),
    ('g132-host-profile-logs-', 'g132-boot-nss-logs-'),
    ('g132-host-profile-successor-', 'g132-boot-nss-observation-'),
    ("('namespace.json', 'inputs.json', 'nss.json')", "('boot-nss.json', 'namespace.json', 'inputs.json', 'nss-finalize.json')"),
    ('g132.host-profile-ordinary-delivery.v1', 'g132.boot-nss-ordinary-delivery.v1'),
    ('g132-host-profile-preparation-', 'g132-boot-nss-source-preparation-'),
    ("        with prepared_binding(driver, context, prepared):\n            if phase in ('namespace', 'inputs'):",
     "        if phase == 'nss-finalize':\n            # Read-only receipt/journal observation cannot recover failed prior custody.\n            return driver.main(['--step', phase, '--source-commit', SOURCE_COMMIT, '--source-tree', SOURCE_TREE])\n        with prepared_binding(driver, context, prepared):\n            if phase in ('boot-nss', 'namespace', 'inputs'):")
]
for before, after in replacements:
    assert before in source, before
    source = source.replace(before, after)

workflow = json.loads(profile_workflow)
workflow['name'] = 'Ordinary finite G132 boot-scoped NSS observation'
workflow['on']['push']['branches'] = ['pro/dg16-g132-boot-nss-20261122-01']
workflow['concurrency']['group'] = 'g132-boot-nss-20261122-01'
steps = workflow['jobs']['qualify']['steps']
for step in steps:
    if 'run' in step:
        for before, after in [
            ('g132-host-profile-logs-', 'g132-boot-nss-logs-'),
            ('pro/dg16-g132-host-profile-successor-20261122-01', 'pro/dg16-g132-boot-nss-20261122-01'),
            ('engineering/g132-host-profile-operation/', 'engineering/g132-boot-nss-operation/'),
            ('f636fca21f30850b03adef11e9b854549789a7d5ffb213efc40077bde314c40f', '567c9861d13593397e8e9a065f70d24a6a3d9176abb3741c8896adfb180b6321')
        ]:
            step['run'] = step['run'].replace(before, after)
    if step['name'] == 'Observe finite native pins and scoped files-only NSS with restoration':
        step['name'] = 'Observe finite native pins and actual boot-configured NSS; retain separate startup result'
upload = steps[-1]
upload['with']['name'] = 'g132-boot-nss-${{ github.run_id }}-${{ github.run_attempt }}'
upload['with']['path'] = '${{ runner.temp }}/g132-boot-nss-logs-${{ github.run_id }}-1/'
inputs = next(step for step in steps if ' inputs > ' in step.get('run', ''))
def phase_step(phase, name, always=False):
    result = copy.deepcopy(inputs)
    result['name'] = name
    result['timeout-minutes'] = 1
    result['run'] = result['run'].replace(' inputs > ', ' ' + phase + ' > ').replace('/inputs.', '/' + phase + '.')
    if always:
        result['if'] = 'always()'
    return result
namespace_index = next(i for i, step in enumerate(steps) if ' namespace > ' in step.get('run', ''))
steps.insert(namespace_index, phase_step('boot-nss', 'Provision exact boot-scoped NSS with durable no-replay state'))
finalize_index = next(i for i, step in enumerate(steps) if ' finalize > ' in step.get('run', ''))
steps.insert(finalize_index, phase_step('nss-finalize', 'Observe current boot NSS and retained administrative state without restoration', True))

records = []
for name, raw, size, digest in [
    ('engineering/g132-boot-nss-operation/run-owned.py', source.encode(), 10903, '567c9861d13593397e8e9a065f70d24a6a3d9176abb3741c8896adfb180b6321'),
    ('.github/workflows/dg16-g132-boot-nss.yml', (json.dumps(workflow, indent=2) + '\n').encode(), 13479, '925176d4cfcfbe6dc52c3312373debb1757c7df3e0f425e653d91b0182d48adc')
]:
    record = dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(), expected_bytes=size, expected_sha256=digest)
    record['exact'] = record['bytes'] == size and record['sha256'] == digest
    records.append(record)
    target = HERE / ('baseline' if record['exact'] else 'unmatched-derivation') / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
print(json.dumps(records, indent=2))
(HERE / 'R1_RECOVERY_CHECK.json').write_text(json.dumps(records, indent=2) + '\n')
assert all(row['exact'] for row in records), 'Retained derivation does not exactly recover R1; no final generation admitted'
