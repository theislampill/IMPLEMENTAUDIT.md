#!/usr/bin/env python3
"""Read-only Git/provider receiving; write evidence only in this owned directory."""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
UPSTREAM = OUT.parent / 'boot-operation-r2'
REPO = Path('/workspace/scratch/75de74f83f5c/implementaudit')
HOST = 'f3c7d3601da75f10525436889b5051bb86f0e630'
HOST_TREE = '09880fc9837d571f6daa9f9b0a529f78a9e4732d'
SOURCE = 'c53ed7de85de22ce313233472c8d8f02ad8e9d02'
SOURCE_TREE = 'd60733459425a059d961b6adc2aae9811bbb761c'
BRANCH = 'pro/dg16-g132-boot-nss-20261122-01'
RUN = 44998068134
JOB = 137133314258


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def ident(s):
    return [s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_size,
            s.st_uid, s.st_gid, s.st_mtime_ns, s.st_ctime_ns]


def stable_read(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        initial = os.fstat(fd)
        assert stat.S_ISREG(initial.st_mode) and initial.st_nlink == 1
        assert initial.st_size <= 1_048_576
        raw = os.pread(fd, initial.st_size + 1, 0)
        assert len(raw) == initial.st_size
        assert ident(initial) == ident(os.fstat(fd)) == ident(path.lstat())
        return raw, ident(initial)
    finally:
        os.close(fd)


def save(name, raw):
    target = OUT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(raw)
    assert target.read_bytes() == raw
    return dict(path=name, bytes=len(raw), sha256=digest(raw))


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


expected = {
    'PACKET.json': (2006, '657f16269dee97a55a063f03df46c4a6ae8f21bd20429db80674b1c4a1ba76c6'),
    'ROOT_OPERATION_ADMISSION_G0002.json': (None, '9668ee8dbea76e50e6bdee05c25cb2e5d324cc018eacf55704600b5c0c440acf'),
    'REMOTE_HOST_READBACK_G0002.json': (None, None),
    'REF_READBACK.json': (None, None),
    'RUNS_AFTER_CREATE.json': (None, None),
    'RUN_44998068134_JOBS.json': (None, None),
    'RUN_44998068134_ARTIFACTS.json': (None, None),
    'RUN_44998068134_JOB_137133314258.log': (20560, '115fa6e22ee0eaddc3ccc184395d78a7b61408844274a6c26aa5729d3135aa7c'),
}
records, raw_inputs, opening = [], {}, {}
for name, (size, sha) in expected.items():
    raw, identity = stable_read(UPSTREAM / name)
    assert size is None or len(raw) == size
    assert sha is None or digest(raw) == sha
    records.append(save('evidence/' + name, raw))
    raw_inputs[name] = raw
    opening[name] = identity

admission = json.loads(raw_inputs['ROOT_OPERATION_ADMISSION_G0002.json'])
remote = json.loads(raw_inputs['REMOTE_HOST_READBACK_G0002.json'])
ref = json.loads(raw_inputs['REF_READBACK.json'])
runs = json.loads(raw_inputs['RUNS_AFTER_CREATE.json'])
jobs = json.loads(raw_inputs['RUN_44998068134_JOBS.json'])
artifacts = json.loads(raw_inputs['RUN_44998068134_ARTIFACTS.json'])
assert admission['status'] == 'ADMIT_EXACT_ORDINARY_ONCE'
assert admission['exact_host_tree'] == HOST_TREE and admission['sole_host_parent'] == SOURCE
assert admission['attempt'] == 1 and admission['automatic_retry'] is False
assert remote['commit'] == HOST and remote['tree'] == HOST_TREE and remote['parents'] == [SOURCE]
assert ref['ref'] == 'refs/heads/' + BRANCH and ref['object']['sha'] == HOST
assert runs['total_count'] == 1 and len(runs['workflow_runs']) == 1
run = runs['workflow_runs'][0]
assert run['id'] == RUN and run['run_attempt'] == 1 and run['head_sha'] == HOST
assert run['head_branch'] == BRANCH and run['head_commit']['tree_id'] == HOST_TREE
assert run['status'] == 'completed' and run['conclusion'] == 'failure' and run['event'] == 'push'
assert jobs['total_count'] == 1 and len(jobs['jobs']) == 1
job = jobs['jobs'][0]
assert job['id'] == JOB and job['run_id'] == RUN and job['run_attempt'] == 1
assert job['head_sha'] == HOST and job['head_branch'] == BRANCH
assert job['status'] == 'completed' and job['conclusion'] == 'failure'
assert artifacts == {'total_count': 0, 'artifacts': []}

host_commit = git('cat-file', 'commit', HOST)
source_commit = git('cat-file', 'commit', SOURCE)
assert host_commit.startswith(('tree ' + HOST_TREE + '\nparent ' + SOURCE + '\n').encode())
assert sum(x.startswith(b'parent ') for x in host_commit.split(b'\n\n', 1)[0].splitlines()) == 1
assert source_commit.startswith(('tree ' + SOURCE_TREE + '\nparent 760aaff5c478ff7354d36da186d62daba983aa49\n').encode())
records.append(save('evidence/host.commit', host_commit))
records.append(save('evidence/source.commit', source_commit))


def entries(commit):
    raw = git('ls-tree', '-r', '-z', commit)
    result = {}
    for record in raw.rstrip(b'\0').split(b'\0'):
        meta, path = record.split(b'\t', 1)
        result[path.decode()] = meta.decode()
    return result, digest(raw)


base, base_listing_sha = entries(SOURCE)
head, host_listing_sha = entries(HOST)
files = {
    'engineering/g132-boot-nss-operation/run-owned.py':
        ('operator.py', 16257, 'b4f2ba7707580e528895269e0f9f02867b2983908673fe59936bc0b4d514a873',
         '100644 blob 0b65e11df13b2c98cdf1e1f8096ab1987d483a06'),
    '.github/workflows/dg16-g132-boot-nss.yml':
        ('workflow.json', 15904, '68d65ab04421f28dfbb44c645ab5e72a113613e157c415cfd0271656e7fd4c20',
         '100644 blob 268d5f683eb174970c62c42b65df67c73c3424c4'),
}
assert len(base) == 1778 and len(head) == 1780
assert all(head.get(path) == value for path, value in base.items())
assert set(head) - set(base) == set(files)
code = {}
for path, (name, size, sha, entry) in files.items():
    raw = git('show', HOST + ':' + path)
    assert head[path] == entry and len(raw) == size and digest(raw) == sha
    restored, _ = stable_read(UPSTREAM / 'content' / path)
    assert restored == raw
    records.append(save('evidence/' + name, raw))
    code[name] = raw
driver = git('show', HOST + ':test-support/g132-boot-nss/ordinary_qualifier.py')
assert digest(driver) == '5eea85cd1dc76c4edc2e24141da8c76ead9167231bee7a6b85743dcd4cd7e382'
records.append(save('evidence/ordinary_qualifier.py', driver))

workflow = json.loads(code['workflow.json'])
steps = workflow['jobs']['qualify']['steps']
bind = steps[1]['run']
assert bind.index('test "$ImageVersion" = 20261116.376.1') < bind.index('mkdir -- "$out"')
assert steps[-2]['id'] == 'collect' and steps[-2]['if'] == 'always()'
assert steps[-1]['if'] == "always() && steps.collect.outcome == 'success'"
assert b"ImageOS='ubuntu24', ImageVersion='20261116.376.1'" in driver
assert code['operator.py'].index(b'context = driver.hosted_context()') < code['operator.py'].index(b'        limits(driver)')
phase_rows = [{k: s[k] for k in ('number', 'name', 'status', 'conclusion', 'started_at', 'completed_at')}
              for s in job['steps']]
status = {s['number']: s['conclusion'] for s in phase_rows}
assert status[1] == status[2] == 'success' and status[3] == 'failure'
assert all(status[n] == 'skipped' for n in range(4, 10))
assert all(status[n] == 'failure' for n in (10, 11, 12)) and status[13] == 'skipped'
log = raw_inputs['RUN_44998068134_JOB_137133314258.log'].decode('utf-8-sig').splitlines()
assert len(log) == 237
assert 'Image: ubuntu-24.04' in log[16] and 'Version: 20261116.133.1' in log[17]
assert any(HOST in line for line in log)
assert 'nss-finalize.stdout: No such file or directory' in log[167]
assert 'finalize.stdout: No such file or directory' in log[192]
assert 'context = driver.hosted_context()' in log[218]
assert 'ValueError: boot ordinary provider context differs' in log[224]

closing = {}
for name, raw in raw_inputs.items():
    reread, identity = stable_read(UPSTREAM / name)
    assert identity == opening[name] and reread == raw
    closing[name] = dict(opening_stat=opening[name], closing_stat=identity,
                         complete_bytes_equal=True, still_producing=False,
                         liveness='terminal-local-snapshot')

receipt = dict(
    schema='g132.boot-r2-independent-terminal-receiving.v1',
    received_at_utc=datetime.now(timezone.utc).isoformat(),
    receiver='/root/boot_nss_review', authority='NONE',
    currentness='refs/implementaudit/continuity-receipts/dg16-dg18-restored-20261122/G0002@9eb19af26c4fe90a35422856c79d5d03ee59ee47',
    operation='G132_BOOT_NSS_20261122_01',
    provider_transport='Root-saved exact provider responses and decoded job log; no duplicate fetch',
    run={k: run[k] for k in ('id','run_attempt','head_sha','head_branch','event','status','conclusion','created_at','updated_at','html_url')},
    job={k: job[k] for k in ('id','run_id','run_attempt','head_sha','status','conclusion','started_at','completed_at','labels','html_url')},
    source_join=dict(host_commit=HOST, host_tree=HOST_TREE, source_commit=SOURCE,
                     source_tree=SOURCE_TREE, sole_host_parent=SOURCE, unchanged_source_entries=1778,
                     host_entries=1780, exact_added_files=list(files),
                     source_ls_tree_z_sha256=base_listing_sha, host_ls_tree_z_sha256=host_listing_sha),
    first_demonstrated_failed_premise=dict(name='selected runner image binding', actual_image='ubuntu-24.04',
        actual_version='20261116.133.1', required_version='20261116.376.1', log_lines=[17,18,139,140,141,145],
        calibration='Shell has no per-command xtrace. Image mismatch independently falsifies the exact premise; metadata and secondary failures agree. No exhaustive alternate-shell-fault claim.'),
    collect=dict(outcome='failure', context_refused=True, collector_body_reached=False,
                 export_verification_produced=False, upload_step='skipped', artifact_total=0),
    phases=phase_rows,
    log_annotations=[dict(line=n, text=line) for n, line in enumerate(log,1) if '##[error]' in line or '##[warning]' in line],
    annotations_limit='Log command annotations received. No independent check-run annotations body; unsupported generic check-suite route not retried.',
    observations=dict(source_preparation='SKIPPED', launcher='SKIPPED', apparmor_policy='SKIPPED',
                      boot_nss='SKIPPED', namespace='SKIPPED', selected_native_inputs='SKIPPED',
                      full_startup='NOT_OBSERVED', boot_identity='NOT_PRODUCED',
                      nss_finalizer='SHELL_REDIRECTION_FAILED_BEFORE_OPERATOR',
                      policy_finalizer='SHELL_REDIRECTION_FAILED_BEFORE_OPERATOR',
                      copied_provider_creation='NOT_ATTEMPTED', protected_execution=False, original_awards=[]),
    input_closure=closing, evidence=records,
    review_effects='Only local evidence/report writes inside owned receiving directory; no candidate execution, source mutation, controller mutation, remote effect, retry or host action.')
raw = (json.dumps(receipt, indent=2, sort_keys=True) + '\n').encode()
row = save('RECEIVING.json', raw)
print(json.dumps(dict(receiving=row, evidence_files=len(records), run=RUN, attempt=1,
                     outcome='FAILURE_BEFORE_NORMAL_PHASES', actual_image_version='20261116.133.1',
                     required_image_version='20261116.376.1', artifacts=0), indent=2))
