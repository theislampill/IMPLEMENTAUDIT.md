# Boot-operation R2 actual host receiving

Report state: FINAL

Independent receiver: `/root/boot_nss_review`; ordinary advisory evidence only. Root remains the sole controller, external writer and adjudicator.

The receiver reread STATE and ROADMAP separately and verified the read-only currentness receipt `refs/implementaudit/continuity-receipts/dg16-dg18-restored-20261122/G0002@9eb19af26c4fe90a35422856c79d5d03ee59ee47`. Runtime files retain earlier frontier text; Root's exact later publication/run records bind the new event. No controller epoch change is authorized or performed.

Subject: ordinary operation `G132_BOOT_NSS_20261122_01`, run `44998068134`, attempt 1, provider host `f3c7d3601da75f10525436889b5051bb86f0e630`, expected tree `09880fc9837d571f6daa9f9b0a529f78a9e4732d`, sole parent/source `c53ed7de85de22ce313233472c8d8f02ad8e9d02`.

Scope: independently receive the authentic completed run/job/log/artifact metadata supplied from the provider, establish the failure origin and only the outcomes actually produced. No retry, cancellation, new operation, source repair, host/NSS/provider action, upload or remote mutation is authorized. Root is already fetching provider records; this receiver will use those exact raw responses without duplicate fetches or unsupported endpoint probing.

Owned write set: `/workspace/scratch/75de74f83f5c/recovery/restored/boot-r2-host-receiving/`. Only owned receiving/report evidence will be written. No disposable execution resource or background process is required.

## Terminal disposition

**RECEIVED_TERMINAL_FAILURE — the selected runner image did not satisfy the reviewed image binding. The six normal operation phases were skipped. No operation artifact was delivered and no new source, boot NSS, namespace, selected-input or full-startup qualification was produced.**

This is ordinary advisory receiving of the actual failed run. It makes no readiness decision, admission, original award or whole-cell closure. The exact operation is retained as its completed attempt-one event; this report does not authorize a retry, a changed pin or a new run.

## Exact subject and evidence join

| Item | Exact identity / outcome |
|---|---|
| Operation | `G132_BOOT_NSS_20261122_01` |
| Ref | `refs/heads/pro/dg16-g132-boot-nss-20261122-01` |
| Provider host commit | `f3c7d3601da75f10525436889b5051bb86f0e630` |
| Host tree | `09880fc9837d571f6daa9f9b0a529f78a9e4732d` |
| Sole host parent / selected source | `c53ed7de85de22ce313233472c8d8f02ad8e9d02` |
| Source tree / sole source parent | `d60733459425a059d961b6adc2aae9811bbb761c` / `760aaff5c478ff7354d36da186d62daba983aa49` |
| Source preservation | All 1,778 inherited entries exact; host has 1,780 entries with exactly the reviewed operator and workflow added at mode `100644` |
| Workflow | `.github/workflows/dg16-g132-boot-nss.yml`; ordinary push trigger, one `qualify` job |
| Run | `44998068134`, attempt `1`, event `push`, status `completed`, conclusion `failure` |
| Run times | Created `2026-11-22T07:24:08Z`; updated `2026-11-22T07:24:19Z` |
| Job | `137133314258`, `qualify`, status `completed`, conclusion `failure` |
| Job times | Started `2026-11-22T07:24:10Z`; completed `2026-11-22T07:24:19Z` |
| Requested runner label | `ubuntu-24.04` |
| Actual logged image | `ubuntu-24.04`, version **`20261116.133.1`** |
| Exact reviewed image predicate | `ImageOS=ubuntu24`, `ImageVersion=`**`20261116.376.1`** |
| Artifacts | `total_count: 0`, empty artifact list |

The independent receiver joined the saved provider ref, run, job and artifact bodies, the decoded job log, the fresh Root admission and Root remote readback. The receiver also read the actual host/source Git objects already fetched by Root: sole parent, trees, all inherited entries, both added blob contents/modes and the source driver pin match. This is a fresh local verification of the provider objects Root fetched, not a second network acquisition. No index, ref, Git object or candidate file was written by this receiver. See `RECEIVING.json` and its thirteen exact evidence snapshots.

The earlier `REMOTE_HOST_READBACK_G0002.json` correctly says branch creation/run had not yet occurred at its observation time. The subsequent exact ref and completed run/job bodies establish those later events; no pre-publication absence claim is reused as post-run evidence.

Provider links: [run](https://github.com/theislampill/IMPLEMENTAUDIT.md/actions/runs/44998068134), [job](https://github.com/theislampill/IMPLEMENTAUDIT.md/actions/runs/44998068134/job/137133314258).

## First demonstrated failed premise

The exact job log reports the selected image at lines 16–21: `Image: ubuntu-24.04`, `Version: 20261116.133.1`. The exact workflow body echoed at lines 131–144 requires `ImageVersion=20261116.376.1`. That predicate is before `mkdir -- "$out"` and before the operator checksum command. The bind step completes with exit code 1 at line 145.

The first established false prerequisite is therefore the image identity binding. The run/head/ref/attempt agree with the reviewed operation. The log contains the script body rather than `set -x` traces, so it does not expose the exit status of every individual preceding shell command. The image mismatch is independently sufficient to refuse this script; the absent delivery directory and the later driver context refusal corroborate that diagnosis. This report does not claim an exhaustive exclusion of unlogged shell/environment faults.

The collector produces a second direct observation of the same failed context boundary. It invokes the exact operator, reaches `main()` at `run-owned.py:265`, then calls `driver.hosted_context()`. The source driver at `ordinary_qualifier.py:94` raises `ValueError: boot ordinary provider context differs` (log lines 214–226). Its expected context includes the same exact image version. The refusal precedes operator resource-limit setup, the collector body, any export creation and any collector verification. This is a context refusal, not a passed collection result.

The evidence establishes image identity divergence. It does **not** establish that any of the twelve selected native file pins, four alias targets, NSS preimage, account data, NSCD assumptions, launcher or policy capabilities actually differ on this image. Those measurements did not run. The previous image-bound qualification remains historical and is neither extended to this image nor retroactively revoked by its different label/version.

## Actual phase outcomes

| Provider step | Actual conclusion | Supported meaning |
|---|---|---|
| Set up job | Success | Provider runner setup completed |
| Checkout exact ordinary host | Success | The logged checkout is the exact host commit above |
| Bind operation and fresh delivery directory | Failure, exit 1 | Exact image prerequisite not met; no delivery directory created |
| Receive fresh selected source | Skipped | No source preparation receipt or new boot/source context produced |
| Provision launcher | Skipped | No launcher provisioning observation |
| Provision AppArmor policy | Skipped | No policy provisioning observation |
| Provision boot NSS | Skipped | No NSS exchange, journal, receipt or configured-state observation from this phase |
| Observe namespace | Skipped | No namespace gate result |
| Observe finite inputs / separate startup | Skipped | No twelve-pin, four-alias, NSS-validation or full-startup result |
| NSS finalizer | Failure, exit 1 | Shell output and status redirections fail on missing directory; finalizer operator is not invoked |
| Policy finalizer | Failure, exit 1 | Same shell redirection failure; finalizer operator is not invoked |
| Collect and verify bounded export | Failure, exit 1 | Operator launched and refused provider context before collector body |
| Upload bounded evidence | Skipped | The `steps.collect.outcome == 'success'` gate is false |
| Post-checkout / complete job | Success | Provider post-job completion; no qualification award follows |

The two always-finalizers report missing `nss-finalize.stdout` / `nss-finalize.status` and `finalize.stdout` / `finalize.status` paths (log lines 168–170 and 193–195). Bash attempts these output redirections before launching the command. Their failures supply no NSS, policy-retention, restoration, cleanup or VM-disposal proof. In this execution the corresponding provisioning steps were skipped; there is no operation-created NSS/policy state for this receipt to certify.

The literal upload condition is `always() && steps.collect.outcome == 'success'`. The actual failed collection, skipped upload and provider `total_count: 0` corroborate non-delivery on this path. No artifact archive, manifest, journal, selected-source receipt, phase status file or copied-runtime observation was received. The provider job log is the received diagnostic evidence; it is not the reviewed operation's export artifact. The two R1 delivery gaps remain covered by the prior independent R2 controls, but the present execution did not reach those collector branches and cannot add positive behavioral coverage for them.

There are four `##[error]` process-exit annotations in the decoded log and one Node 20 deprecation/forced-Node-24 warning. Checkout succeeded, so that warning is not the demonstrated cause of this run's bind failure. These are log command annotations. No independent check-run annotation response was received. Root reported that a generic check-suite route was unsupported; this receiver did not retry or substitute another route. The known failure origin does not depend on an unavailable annotation body.

## Findings and smallest warranted next prerequisite

| ID | Disposition | Finding / next action |
|---|---|---|
| H01 | PASS, bounded identity join | Exact reviewed packet, host/source relationship, ref, run, attempt and job agree. This is identity receiving, not operation success. |
| H02 | GAP — fresh image qualification required | The selected image version differs from the exact source/workflow premise. Preserve this refusal. Before deriving another ordinary candidate, acquire a separately reviewed bounded observation of the actual selected image and the finite host-dependent inputs required by the retained owner. |
| H03 | RECEIVED ADVERSE DELIVERY | Collector context refusal, upload skipped, artifacts zero. No unexpected export is evidenced; no export completeness claim is available. |
| H04 | UNVERIFIED / SKIPPED | Source preparation, launcher/policy provisioning, boot NSS custody, namespace, native inputs and startup have no new result. Retain these as unperformed in this run. |
| H05 | PRESERVED SCOPE | Original/protected execution, private inputs, copied-provider creation and original awards were outside this operation and were not supplied by its failure. Root alone decides any later source adoption/publication/launch. |

The smallest decision-changing next source work is an **observation-only ordinary image qualification prerequisite**, with its own exact reviewed code, operation identity, resource/report bounds and fresh Root admission. It should record the actual image identity and measure the existing finite dependency set already relied on by the owner: the twelve file pins, four aliases, original NSS preimage and the retained NSS/account/NSCD assumptions. Read and compare the relevant existing launcher/policy host assumptions only as needed to determine candidate compatibility. Report individual matches, mismatches and unavailable observations honestly. It should not configure system NSS, provision the copied provider or start protected/native/model work merely to discover those bytes.

The new source decision should follow those measurements. If a fresh hosted allocation selects a different version again, its own version and measurements must be bound; a previously observed label is not a same-run guarantee. Any resulting new ordinary candidate must carry all relevant exact context/source/operator/workflow bindings consistently and undergo its own independent operation receiving. Do not replace only `20261116.376.1` with `20261116.133.1`, broaden the predicate, remove it, retry attempt 1, or reuse this operation identity on the basis of the present log. No broader canonical test rerun is justified by this specific evidence gap.

The shell diagnostic cascade also identifies an observability limit: failed preflight has no operation artifact because the delivery directory is created after its guards and the collector enforces the same context. That behavior retained a useful provider log and closed upload. Changing the diagnostic design is not necessary to establish this failure, and this report does not prescribe a new workflow repair or assert that finalizers succeeded.

## Evidence identities and custody

All paths below are under this report's owned `evidence/` directory. They are exact snapshots; the complete inventory is in `RECEIVING.json`.

| Evidence | Bytes | SHA-256 |
|---|---:|---|
| `PACKET.json` | 2,006 | `657f16269dee97a55a063f03df46c4a6ae8f21bd20429db80674b1c4a1ba76c6` |
| `ROOT_OPERATION_ADMISSION_G0002.json` | 3,711 | `9668ee8dbea76e50e6bdee05c25cb2e5d324cc018eacf55704600b5c0c440acf` |
| `REMOTE_HOST_READBACK_G0002.json` | 1,235 | `4e4332b8942af74bab21422e7a34326ed677bc35a0c940c2bd5086d769c744e2` |
| `REF_READBACK.json` | 462 | `6f83f322331868938e395147cb084b2dfa008792a07b3db24e66207c7e14bfeb` |
| `RUNS_AFTER_CREATE.json` | 13,842 | `6545562c1696ccc6c290b2d47ab20cc35d9ce1c23b1fa1477161678be488916a` |
| `RUN_44998068134_JOBS.json` | 3,905 | `c6342ef40b5d696a28263a0bc177386000d8f82caeeb78186043d59d5b1a2ab5` |
| `RUN_44998068134_ARTIFACTS.json` | 33 | `d3ad979d01443a9d7342e7fbe39064b41ebdb340029293f1b099bcfb6c493c42` |
| `RUN_44998068134_JOB_137133314258.log` | 20,560 | `115fa6e22ee0eaddc3ccc184395d78a7b61408844274a6c26aa5729d3135aa7c` |
| `operator.py` | 16,257 | `b4f2ba7707580e528895269e0f9f02867b2983908673fe59936bc0b4d514a873` |
| `workflow.json` | 15,904 | `68d65ab04421f28dfbb44c645ab5e72a113613e157c415cfd0271656e7fd4c20` |
| `ordinary_qualifier.py` | 14,658 | `5eea85cd1dc76c4edc2e24141da8c76ead9167231bee7a6b85743dcd4cd7e382` |

`RECEIVING.json` is 14,748 bytes, SHA-256 `678aeb2ffdd17a6f8153a2064dca007ecd3a55c512587c49c17ecf48f3da0035`. It also binds raw host/source commit bytes, the complete tree-comparison digests, exact step conclusions, relevant log annotations and opening/closing local file identities. All eight Root-supplied metadata/log/packet inputs were reread at closure; full bytes and stat identity matched their opening read. They are terminal local snapshots of the reported completed attempt. This bookend does not claim exclusion of arbitrary privileged writers or a perpetual remote snapshot.

`receive_terminal.py` performed one bounded local receiving pass. It executed no candidate module, source test, NSS/provider command or host operation. Final evidence files and the final report are sealed by the sibling `MANIFEST.json`; its own SHA-256 is sent to Root outside the manifest. No historical test log was regenerated or represented as new hosted evidence.

## Original boundary and review limits

The historical selected-input observations from ordinary run `44979910098` are not overwritten. The previously missing copied-runtime Python path is not re-observed here: inputs/startup were skipped. The full copied-provider construction remains separate original owner work. Boot identity, configured NSS state, namespace behavior, native-input validation, original architecture/resource compliance and native/provider/model provenance cannot be awarded from this run.

`G132_ORIGINAL_20261120_01` / run `44888568054` remains `SPENT_NO_RETRY`; historical `301aeecd…` and A4-07 remain `UNKNOWN_NO_REPLAY`; queued `43098152901` remains separate and untouched. Original denominators, NSS lifecycle requirements, authority boundaries and fresh exact protected-grant requirements are unchanged. This receiver performed no controller mutation, remote mutation, retry, cancellation, source repair or hosted execution, and grants no authority for one.

Advisory disposition: **RECEIVED_TERMINAL_FAILURE / GAP_FRESH_IMAGE_QUALIFICATION**.
