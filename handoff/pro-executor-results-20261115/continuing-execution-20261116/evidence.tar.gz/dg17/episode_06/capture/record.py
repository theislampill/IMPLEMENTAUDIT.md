#!/usr/bin/env python3
"""Capture one direct command and the assigned workspace's observable files."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent.parent
WORK = BASE / "subject"
OUT = BASE / "capture"

def snapshot():
    rows = []
    for path in sorted(WORK.rglob("*")):
        if ".git" in path.relative_to(WORK).parts:
            continue
        if path.is_symlink():
            rows.append({"path": str(path.relative_to(WORK)), "kind": "symlink"})
        elif path.is_file():
            value = path.read_bytes()
            rows.append({"path": str(path.relative_to(WORK)), "kind": "file",
                         "bytes": len(value), "sha256": hashlib.sha256(value).hexdigest(),
                         "mtime_ns": path.stat().st_mtime_ns, "inode": path.stat().st_ino})
    return rows

if len(sys.argv) < 2:
    raise SystemExit("usage: record.py PROGRAM [ARG ...]")
index = 1
while True:
    target = OUT / ("command-%03d" % index)
    try:
        target.mkdir()
        break
    except FileExistsError:
        index += 1
before = snapshot()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
result = subprocess.run(sys.argv[1:], cwd=WORK, stdin=subprocess.DEVNULL,
                        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
(target / "stdout.bin").write_bytes(result.stdout)
(target / "stderr.bin").write_bytes(result.stderr)
record = {"schema": "bounded-task.command-capture.v1", "argv": sys.argv[1:],
          "cwd": str(WORK), "started_at_utc": started,
          "elapsed_seconds": round(time.monotonic() - clock, 6),
          "exit_code": result.returncode, "before": before, "after": snapshot(),
          "stdout": {"bytes": len(result.stdout), "sha256": hashlib.sha256(result.stdout).hexdigest()},
          "stderr": {"bytes": len(result.stderr), "sha256": hashlib.sha256(result.stderr).hexdigest()}}
(target / "record.json").write_text(json.dumps(record, indent=2) + "\n")
sys.stdout.buffer.write(result.stdout)
sys.stderr.buffer.write(result.stderr)
raise SystemExit(result.returncode)
