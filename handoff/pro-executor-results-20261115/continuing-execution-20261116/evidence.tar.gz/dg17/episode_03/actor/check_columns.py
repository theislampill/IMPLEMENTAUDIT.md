import json
from pathlib import Path

BASE = Path(__file__).resolve().parent

def invalid_columns(selected, allowed):
    return [name for name in selected if name not in allowed]

def main():
    config = json.loads((BASE / 'config.json').read_text())
    schema = json.loads((BASE / 'schema.json').read_text())
    unknown = invalid_columns(config['columns'], schema['allowed_columns'])
    if unknown:
        print('unknown columns: ' + ', '.join(unknown))
        return 1
    print('column check: ok')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
