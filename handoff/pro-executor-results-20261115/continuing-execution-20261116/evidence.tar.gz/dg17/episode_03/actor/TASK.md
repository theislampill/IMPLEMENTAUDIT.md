The supplied export configuration fails its column check. Explain why it fails and what change would fix it. Verify your diagnosis while keeping the supplied source and data unchanged.
