import json
from pathlib import Path

BASE = Path(__file__).resolve().parent

def main():
    recorded = json.loads((BASE / 'completed_task' / 'commands' / 'command-008' / 'record.json').read_text())
    current_files = {row['path'] for row in recorded['after']}
    observations = []
    for path in sorted((BASE / 'policies').glob('*.json')):
        policy = json.loads(path.read_text())
        requested = policy['after_every_task']['create_files']
        observations.append({'policy': path.stem, 'recorded_task_files': sorted(current_files),
                             'automatic_requested_paths': requested,
                             'additional_required_paths': [name for name in requested if name not in current_files]})
    print(json.dumps(observations, indent=2))

if __name__ == '__main__':
    main()
