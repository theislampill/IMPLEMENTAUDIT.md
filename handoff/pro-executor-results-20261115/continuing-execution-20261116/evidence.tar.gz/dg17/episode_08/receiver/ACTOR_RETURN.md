## Recommendation

**Recommend `elm`; reject `ash`; replace `maple`’s blanket document requirement with conditional reflection and retention in existing records.** Elm best preserves the evidence needed to explain both supplied cases while keeping ordinary work proportionate. This is a recommendation to the coordinator, with no policy-adoption, mutation, or broader audit-acceptance authority.

All supplied files remain unchanged. A final comparison of **31 supplied ordinary files** found no changed paths. The recorded task was not repeated.

## Policy dispositions

| Policy | Recommended disposition | Consequence for the recorded CSV task | Consequence for the checker-repair learning |
|---|---|---|---|
| **Elm** | **Retain as the preferred policy**, subordinate to the selected guidance. Clarify that all applicable proof-failure/Jidoka triggers remain operative. | Retains the failed inventory check, its diagnosis, the corrected verification, and the limited claim about ordinary task files. Requires no automatic extra documents. | Supports retaining the demonstrated regression fixture family, the cause record, and follow-up evidence while preserving the stated limits. |
| **Maple** | **Reject the unconditional mandate. Make reflection conditional and merge it into an adequate existing record.** | Requires `HANSEI.md`, `KAIZEN.md`, and `5S.md` even though task acceptance concerns a duration change and verification. Those three additional paths are absent from the completed task. | Requires duplicate documents and a compulsory process improvement even when the existing learning record already identifies the defect, countermeasure, and follow-up. It could encourage unsupported additional “learning.” |
| **Ash** | **Reject. Replace its evidence-deletion and prevention-removal requirements.** | Reporting only the final successful command would conceal command-006’s failure and the reason command-008 used a corrected inventory boundary. | Explicitly directs removal of cause records and regression fixtures despite a supplied record of recurring checker defects. This defeats the demonstrated preventive control. |

**Policy evidence:** `policies/elm.json`, `policies/maple.json`, and `policies/ash.json`. The inspected, read-only `policy_probe.py` reported **zero** additional required paths for Elm and Ash, and **three** for Maple. That probe establishes file requirements only; it does not establish a policy’s correctness.

## Why these dispositions follow from the guidance

The selected guidance treats Lean practices as evidence-bearing behavior. Its relevant requirements are:

- **Preserve visible failures and correction evidence.** The Execution Spine requires baseline and post-change evidence; the Lean reference’s Jidoka and Andon entries prohibit hiding proof failures. A producer’s exit status governs the verification verdict.
- **Reflect when a supported trigger occurs.** Hansei records gap, cause, countermeasure, and follow-up evidence. Ordinary work with no trigger creates no new record or ceremony.
- **Retain useful prevention.** A demonstrated defect-catching gate qualifies for retention. Cheapening requires equivalent protection; retirement requires evidence that the failure mode, consumer, and consequence have ended.
- **Use an adequate existing record.** Process volume and duplicate status artifacts do not themselves establish value.
- **Declare countermeasure scope.** Targets, checked non-targets, and the no-harm basis must be explicit. Further verification after a pass must address a specific remaining risk.

These requirements appear in `guidance/SKILL.md`, especially **Execution Spine**, **Runtime Loop**, and **Trace And Closure**, and in `guidance/references/lean-operating-discipline.md`, especially **Concept mapping table**, **Verdict capture fidelity**, **Countermeasure Scope And Verification Proportionality**, and **Engineering-value admission, retention, and retirement**.

Elm is consistent with these requirements when read under its existing governor/source-owner authority clause. Maple converts conditional practices into an unconditional completion tax. Ash removes the evidence and controls those practices are meant to preserve.

## Evidence from the completed CSV task

The original request was to change workshop **W-202 from 60 to 75 minutes** and check the table. The supplied sequence establishes the following:

| Recorded command | Result | Supported interpretation |
|---|---:|---|
| `command-003` | Exit **0** | Baseline CSV validation passed; W-202 was 60 minutes. |
| `command-004` | Exit **0** | The task-file inventory excluded repository metadata. |
| `command-005` | Exit **0** | The recorded mutation changed `workshops.csv`; its before/after snapshots show no other ordinary-file changes. |
| `command-006` | Exit **1** | Verification failed at the inventory assertion. Its traversal included repository metadata. |
| `command-007` | Exit **0** | Diagnosis reported that the expected task files were present and the extra paths consisted exclusively of repository metadata. |
| `command-008` | Exit **0** | Corrected verification excluded `.git` paths and passed; its output narrowed the claim to unchanged **task-file** inventory. |

**Sources:** each corresponding `completed_task/commands/command-00N/record.json`, `stdout.bin`, and `stderr.bin`; `completed_task/original_TASK.md`; `completed_task/CONTEXT.md`.

I compared the command-006 and command-008 verification source as data. Only two substantive lines changed:

1. The inventory traversal excluded paths containing a `.git` component.
2. The success statement changed from a claim about the entire workspace to a claim about task files.

The CSV schema, row count, unique-ID, positive-duration, target-row, and exact baseline-comparison checks remained in place. Thus, the recorded correction preserved the task’s data checks while aligning the inventory check and claim with the documented capture boundary.

The supplied record streams also passed direct integrity checks:

- All **12 stdout/stderr files** matched their recorded byte counts and SHA-256 values.
- All consecutive ordinary-file snapshots agreed.
- The supplied resulting CSV matched command-008’s recorded final hash.
- Replacing the single W-202 duration in memory with its old value reproduced the recorded baseline hash.
- The selected `guidance/SKILL.md` matched the guidance hash recorded in the task snapshots.

The resulting CSV contains four rows, with W-202 recorded as **Agile Planning, 75 minutes, Pine**. These comparisons support the narrow duration-change result. They do **not** establish that repository metadata was unchanged: the recorder explicitly excluded `.git`, and command-007’s diagnosis is not a before/after comparison of that metadata.

### Necessary treatment of the failed check

The task was small, but its verification did encounter a real proof failure. The appropriate existing-record reflection is:

- **Gap:** the initial verification incorrectly assumed the entire recursive file inventory consisted only of the four task files.
- **Cause:** its traversal included repository metadata, unlike the earlier task-file inventory.
- **Countermeasure:** restrict that assertion to the ordinary task-file boundary and state that boundary accurately.
- **Checked non-targets:** retain every CSV acceptance assertion and the exact byte comparison.
- **Follow-up:** retain command-007’s diagnostic result and command-008’s successful verification alongside command-006’s failure.
- **Limit:** make no `.git` non-mutation claim.

The packet supplies the mechanical basis for this account, but it does not contain a separate original Hansei/Andon narrative. A coordinator can carry this concise account in an existing review or closure record without creating Maple’s three mandatory documents. Ash would erase evidence necessary to substantiate it.

## Evidence from the completed checker-learning record

`completed_learning.json` describes a separate recurring defect:

1. An original count-derived terminal sentence passed the checker.
2. A repair rejected that literal sentence but missed equivalent reverse-order cases and incorrectly rejected an ordinary failure.
3. A narrowing correction addressed those observations but allowed bare terminal imperatives.

The record identifies a source-owner lesson: test the **terminal-action relationship**, including both clause orders and the distinction between ending work and continuing after an inconclusive check.

It also identifies one retained prevention: a regression fixture family in `tests/no-terminal-cap.test.sh`. Its stated scope covers the demonstrated negatives, ordinary continuing-check positives, and existing controls. The record reports a focused test with exit **0** and an independent follow-up in which **10 probes matched**.

That is a concrete retention rationale. Removing the fixture merely because the last check passed would discard coverage for demonstrated recurrence. Requiring three extra process documents would add no protection unless a distinct consumer and consequence were identified.

### Evidence limits and needed precision

The raw referenced repair evidence, test source, and independent-review artifacts are **not supplied in this review directory**. Consequently, the recurrence and follow-up are **reported by the provided structured record**, not independently re-proved here.

The record itself appropriately excludes claims of formal L4 registration, a native callback, complete mutation-family coverage, a full P10/governed-cell award, and universal natural-language coverage. Preserve those limits.

If the coordinator needs full conformity with the countermeasure-scope contract, the existing record should explicitly distinguish:

- the targeted terminal-policy cases;
- the ordinary-failure and historical-control cases checked as non-targets;
- the actual evidence supporting the no-harm conclusion.

Its present prose gives useful scope information, but it does not independently establish a pre-application scope declaration or the underlying probe results. Do not retroactively claim either.

## Corrections to carry forward

1. **Elm:** keep its conditional, existing-record approach. Make clear that the listed reflection examples do not suppress other proof-failure/Jidoka obligations, and that a reported follow-up is distinguishable from raw evidence inspected by the reviewer.
2. **Maple:** remove the unconditional three-file completion gate and compulsory process-improvement quota. Require a reflection only when supported, reuse an adequate record, and retain a preventive control only for an evidenced consequence.
3. **Ash:** remove the instructions to discard failures, diagnostic history, cause records, and regression fixtures after success. A concise final summary may emphasize the result while preserving the complete relevant evidence elsewhere.
4. **CSV-work record:** preserve the failed check and its correction; describe acceptance and non-mutation only within the ordinary-file boundary.
5. **Checker-learning record:** retain the scoped regression prevention and stated claim limits. Further assurance requires the referenced raw evidence through an authorized scope, not repetition of the original repair.

No additional selected-guidance reference was necessary to reach these bounded recommendations. No adoption or correction was performed.

