import unittest
from generate_catalog import normalize_code

class NormalizerTests(unittest.TestCase):
    def test_uppercase_code(self):
        self.assertEqual(normalize_code('CORP'), 'corp')

    def test_lowercase_code(self):
        self.assertEqual(normalize_code('growth'), 'growth')

if __name__ == '__main__':
    unittest.main()
