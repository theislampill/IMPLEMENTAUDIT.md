# Catalog and export contract

A ready order for an active tenant is exported with its dispatch zone when its subscribed plan includes the dispatch feature. The tenant contract codes and zone fields are authoritative task inputs.

The partner plan feed permits surrounding whitespace in code fields. Canonical catalog keys are lowercase with surrounding whitespace removed. Feature names are separated by semicolons. The catalog generator owns this normalization. The generated catalog is a projection of the partner feed.
