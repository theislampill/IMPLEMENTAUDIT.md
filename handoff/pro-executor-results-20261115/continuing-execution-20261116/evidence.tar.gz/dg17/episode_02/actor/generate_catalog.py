import csv
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent

def normalize_code(value):
    return value.lower()

def build_catalog():
    with (BASE / 'inputs/vendor_plans.csv').open(newline='') as source:
        return {normalize_code(row['code']): {'features': row['features'].split(';')}
                for row in csv.DictReader(source)}

if __name__ == '__main__':
    (BASE / 'generated_catalog.json').write_text(json.dumps(build_catalog(), indent=2) + '\n')
