from permissions import permitted_tenant_ids

def dispatch_table(tenants):
    permitted = permitted_tenant_ids(tenants)
    return {tenant['tenant_id']: tenant['zone'] for tenant in tenants
            if tenant['tenant_id'] in permitted}
