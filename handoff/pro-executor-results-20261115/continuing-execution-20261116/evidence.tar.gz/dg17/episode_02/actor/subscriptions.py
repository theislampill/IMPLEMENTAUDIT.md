from catalog import load_catalog

GUEST = {'features': ['read']}

def resolve_subscription(tenant):
    key = tenant['contract_code'].strip().lower()
    return load_catalog().get(key, GUEST)
