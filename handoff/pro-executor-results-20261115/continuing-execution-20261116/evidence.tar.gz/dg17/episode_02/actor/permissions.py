from entitlements import has_dispatch_entitlement

def permitted_tenant_ids(tenants):
    return {tenant['tenant_id'] for tenant in tenants
            if tenant['state'] == 'active' and has_dispatch_entitlement(tenant)}
