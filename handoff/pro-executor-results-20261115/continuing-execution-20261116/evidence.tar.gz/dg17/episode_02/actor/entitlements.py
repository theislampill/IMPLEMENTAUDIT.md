from subscriptions import resolve_subscription

def has_dispatch_entitlement(tenant):
    subscription = resolve_subscription(tenant)
    return 'dispatch' in subscription['features']
