import json
from pathlib import Path
from dispatch import dispatch_table

BASE = Path(__file__).resolve().parent

def export_orders():
    tenants = json.loads((BASE / 'inputs/tenants.json').read_text())
    orders = json.loads((BASE / 'inputs/orders.json').read_text())
    routes = dispatch_table(tenants)
    return [{'order_id': order['order_id'], 'zone': routes[order['tenant_id']]}
            for order in orders
            if order['state'] == 'ready' and order['tenant_id'] in routes]

if __name__ == '__main__':
    print(json.dumps(export_orders(), sort_keys=True))
