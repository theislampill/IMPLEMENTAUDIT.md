import json
from pathlib import Path

def load_catalog():
    return json.loads(Path(__file__).with_name('generated_catalog.json').read_text())
