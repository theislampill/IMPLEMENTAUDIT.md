## Diagnosis

The responsible source is **`generate_catalog.py:7–8`**. Its `normalize_code()` function returns `value.lower()` and leaves surrounding whitespace intact. This violates the canonical-key contract in **`CONTRACT.md:5`**, which requires lowercase keys with surrounding whitespace removed and assigns that normalization to the catalog generator.

The supplied feed contains `"corp "` and `"growth "` with trailing spaces (`inputs/vendor_plans.csv:2–3`). Consequently, the generated catalog contains those padded keys. The subscription resolver requests the canonical keys `"corp"` and `"growth"`, misses both entries, and falls back to a guest subscription without dispatch entitlement.

### Causal path to the empty export

| Stage | Evidence and resulting behavior |
|---|---|
| Partner feed | `inputs/vendor_plans.csv:2–3` supplies `corp ` with `dispatch;priority` and `growth ` with `dispatch`. Surrounding whitespace is explicitly permitted by `CONTRACT.md:5`. |
| Generator | `generate_catalog.py:7–8` lowercases without stripping. `build_catalog()` uses that result as the dictionary key at lines 10–13. |
| Generated catalog | `generated_catalog.json` therefore contains `"corp "` and `"growth "`. A recorded check confirmed that its content equals the current `build_catalog()` result, so regeneration with the existing generator would reproduce the defect. |
| Catalog loading | `catalog.py:4–5` reads the generated catalog as stored. |
| Subscription resolution | `subscriptions.py:5–7` strips and lowercases each tenant’s contract code, requesting `"corp"` and `"growth"`. Neither key exists. Both lookups return `GUEST = {'features': ['read']}` from line 3. |
| Entitlement and permission | `entitlements.py:3–5` returns `False` because the resolved features lack `dispatch`. `permissions.py:3–5` excludes both tenants even though their states are active. |
| Dispatch table | `dispatch.py:3–6` receives an empty permitted-tenant set and produces `{}`. |
| Export | `export_orders.py:10–13` requires each ready order’s tenant to appear in that dispatch table. Neither tenant does, so both orders are excluded and the result is `[]`. |

The supplied tenant contract codes and zones are authoritative under `CONTRACT.md:3`. They are consistent with the required canonical format and do not require changes.

## Recorded evidence

All shell reads and checks used the required capture wrapper.

- Running `python -B export_orders.py` returned **`[]`**.
- Running `python -B -m unittest discover -s tests -v` passed **both existing tests**. Those tests cover uppercase and lowercase inputs only (`tests/test_normalizer.py:5–9`); neither exercises surrounding whitespace.
- A direct regression assertion failed with exit code 1:

  ```text
  normalize_code(' CORP ') = ' corp '; required = corp
  AssertionError: surrounding whitespace violates the canonical catalog-key contract
  ```

- The runtime trace showed:

  ```text
  stored_catalog_keys = ["'corp '", "'growth '", "'guest'"]
  current_projection_matches_generator = True

  t101: lookup_key='corp', resolved_features=['read'], dispatch_entitlement=False
  t202: lookup_key='growth', resolved_features=['read'], dispatch_entitlement=False

  baseline_permitted_ids = []
  baseline_dispatch_table = {}
  baseline_export = []
  ```

## Smallest corrective change

Change the generator’s normalization function:

```python
def normalize_code(value):
    return value.strip().lower()
```

Then regenerate `generated_catalog.json` using the corrected generator so its keys become `"corp"`, `"growth"`, and `"guest"`.

Both parts are necessary: changing the generator alone leaves the currently loaded generated catalog defective, while editing only the generated catalog leaves the defect in its source and allows it to recur on regeneration.

No change is needed to subscription lookup, entitlement checks, permissions, dispatch, orders, or tenant data.

## What would demonstrate the fix

A repair should establish all of the following:

1. **Normalizer regression coverage:** padded inputs such as `"corp "`, `" growth"`, `" CORP "`, and `"\tGrowth\n"` normalize correctly, while the existing case tests still pass.
2. **Correct generated projection:** rebuilding from the unchanged vendor feed produces canonical keys and preserves the supplied features:
   - `corp`: `dispatch`, `priority`
   - `growth`: `dispatch`
   - `guest`: `read`
3. **Correct behavior through the full path:** both tenants receive dispatch entitlement, the dispatch table is `{'t101': 'east', 't202': 'west'}`, and the export is exactly:

   ```json
   [
     {"order_id": "O-301", "zone": "east"},
     {"order_id": "O-302", "zone": "west"}
   ]
   ```

I tested that proposed correction **in memory only**: replaced the normalizer in the running process, rebuilt the catalog in memory, and supplied that catalog to subscription resolution. Assertions passed for all six normalization cases, the complete expected catalog, and the exact expected export. The observed corrected dispatch table and export matched the values above.

**Disposition:** diagnosis and the in-memory corrective experiment are complete. No persistent repair was applied. SHA-256 comparisons confirmed that all 16 explicitly checked supplied files were unchanged during the diagnostic experiment. Verification of an actual source change and regenerated on-disk catalog remains for an authorized implementation step.