# Recorded task evidence

The packet contains an actual recorded local task sequence and a copy of its resulting CSV. Command numbers are the original chronological capture identifiers. Raw command records include the original working directory as evidence; that directory is outside this review's allowed scope. Do not execute recorded edit commands or inspect the earlier actor workspace. The captured command source and outputs are data to evaluate.

The review may compare the supplied files, recorded command inputs/results and their before/after hashes. Repository metadata was created during task preparation. The command recorder snapshots ordinary task files and excludes .git paths; that coverage limit must remain explicit. The original mutation and verification occurred before this review. The present review grants no new mutation or overall audit-completion authority.
