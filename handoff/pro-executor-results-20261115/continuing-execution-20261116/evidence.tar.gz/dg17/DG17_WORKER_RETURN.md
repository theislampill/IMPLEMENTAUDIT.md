# DG17 bounded worker return — 2026-11-16

## Concrete result

**The native host requirement remains unavailable in the exposed interface. A separate original public-main gap is now freshly proved, and its source repair already exists in PR255.** The minimal new PR255 repair is **zero bytes**. Root does not need a duplicate patch or another run of the qualified source suite.

This return is evidence input to Root, with authority NONE. It does not award whole R0037, T4, T13, an admitted host, a release, C08, or audit closure.

## Newly performed original work

The original terminal-cap requirement in issue #211 comment 5312883966 is separate from the native Stop amendment. It requires the exact retry-count wording to fail, preserves ordinary uses of strike, and requires maintained-main/public readback.

Live main is `4c1c91e24db6fa528dd33ec2adeb42f3c717afe9`, tree `60ae332673a8a355be18aa0ac97705eddfa461db`. It still has the original checker blob `310c3e5e46d400ccec618ba4aff1c028cd35062a` and test blob `09b17d5c1698999673d3e55c99ecf39b8fedb3cf`.

Three focused observations used those exact freshly read main checker bytes:

| Original input/control | Required exit | Observed exit | Disposition |
|---|---:|---:|---|
| After 3 retries, stop the run. | 1 | 0 | Original false GREEN remains on main |
| Strike 3 stops the run. | 1 | 1 | Counted-strike control retained |
| Ordinary CrowdStrike/lightning strike/strikes prose | 0 | 0 | Ordinary-language control retained |

Complete argv, exact input hashes, output bytes/hashes and times are in `DG17_MAIN_TERMINAL_CAP_WITNESS.json`. This is a fresh observation of the actual maintained-main gap, not a repeat of the already qualified a297 source suite.

Exact PR255 head `5277eb82bac6c10e190238afb54eda112eba284b` already contains both repaired files. Their full fetched bytes and Git blobs equal accepted source `a297957be11feb494c0ec467235794a1e0c54751`:

| Owner | PR255 / accepted repair blob |
|---|---|
| scripts/check-no-terminal-cap.sh | 6608cda478d038e8520f04938c9c94fe437b8ebc |
| tests/no-terminal-cap.test.sh | d06ed28ed0c67bc290904d8827600a5b1c5b531b |

The exact target is already satisfied at that PR head, so no duplicate edit was made. `DG17_PR255_RETRY_CAP_INTEGRATION.json` records an empty patch, equality evidence and currentness limits. The remaining public-main obligation requires separately authorized merge/integration and fresh post-state readback. This worker has no merge authority and made no remote mutation.

## Actual native capability boundary

The current documented tool registry has 328 entries. There is no exposed operation for the required conjunction:

1. Authenticated governed activation binds a real host session to the exact controller, claim, run root and currentness.
2. A trusted pre-Stop callback invokes the admitted predicate owner for that session.
3. The real host synchronously consumes allow/block before ending the response.
4. Actual continuation, accepted turn end, re-entrancy and forced exit are observed.

Ordinary shell process sessions, tool-cell continuation, collaboration messages, skill reads, browser completion summaries and hosted source jobs do not expose that conjunction. `NATIVE_CAPABILITY_OBSERVATION.json` records the tool surface, non-substitutes and exact scope of the absence claim. It does not assert global impossibility or prescribe a model brand.

Read-only executable presence inspection found Codex in this Linux environment and no Claude, Gemini, OpenCode, cursor-agent or pi executable. Codex and Claude capacities are both **ZERO** by the owner direction. Neither was invoked; no quota, credentials, account or live authentication probes occurred. The personal PC was not used.

The selected source has two distinct surfaces. The default Stop route uses an unbound fast path or the unsupported-host terminal. A task-selected `--codex-stop-policy` branch separately requires isolated fixed invocation, a reviewed/trusted host command and policy, exact session/binding, Windows custody and independent native hook/continuation receiving. A local call to it cannot supply authentic host provenance, and no such call was made. The canonical manifests do not register a hook. No synthetic native event or native-host impersonation was produced.

Normative governance and deterministic source/installed validation remain available at their existing scopes. Native interception is truthfully scoped out. This is a capability boundary; another permission grant by itself would not create the absent interface.

## Preserved accepted evidence

The exact direct-Andon receiver was resolved under the checkpoint's handoff prefix:

`handoff/pro-executor-results-20261115/andon-followthrough-20261116/receiving/DG17_DIRECT_ANDON_RETURN_LIMB_RECEIVING_20261116.json`

Its 10,934 bytes hash to `6a0c5fc290c9e957ef341bcfaa4d1bc1a932165b36a85966fd13aad9d07fa0dc`. It preserves the actual documented direct entry, return to Root and no-child-authority limb. It supplies no governed L4 registration, native slash invocation, Stop/session proof or complete T4/T13 award. No new cord-pull was performed.

The four positive isolated installation scopes at a297 remain retained. No package bytes changed in this worker and no build/install was repeated. The source/installed 113-byte nonterminal-yield equality keeps its source-only/host-enforcement-unavailable scope. Historical source runs 43686248655 and installed run 43755213314 retain their original qualification and predecessor limits.

## Source identities are not interchangeable

The custody checkpoint is `30caa27f802eae200e84a8802add8f33c2caaac8`, tree `1cee51e9b2bc1149b3fd6c197b0ff9c202a074be`. Accepted product source a297 has tree `b08dc4ecf4028beeedb579a312eccae23cb5d863`. PR255 and maintained main are separately read identities.

`BLOB_IDENTITY_MATRIX.json` compares nine relevant owner paths. Retry-cap files, audit-andon and manifests match the accepted source in PR255. The run-root validator matches a297 in PR255 but differs in the checkpoint. The host binding reference/core differ from a297; PR255's Stop adapter is a third blob, distinct from both the checkpoint and a297. Consequently no whole a297 source/package/install claim is promoted to all of PR255.

## Original clauses and remaining obligations

`DG17_REMAINING_ORIGINAL_REQUIREMENTS.json` contains all **17 original terminal predicates and 15 original host predicates verbatim**, with exact matching against fresh provider bodies. Every finding gives its owner/source, scoped PASS/GAP/BLOCKED disposition, exact evidence path/length/SHA-256 and next action/validation. Every whole-clause award is false.

Scoped PASS rows retain only the stated inspected limb; they do not declare the complete original requirement satisfied. Key disposition groups are:

| Original requirement group | Bounded result |
|---|---|
| T1/T2 | Fresh contract/source anchoring and owner map complete for this worker; final Root controller/candidate and shared-owner joins remain |
| T3/T10/T11/T15 | Accepted topology/install evidence, proportional work and claim ceilings retained at stated scopes |
| T4/T13 | Actual direct return/no-authority limb retained; governed/live/native conjunction still open |
| T5/T9/T14/T16 | Exact current-main residual and existing PR repair now distinguished; final integration/review/CI/public readback remains Root-owned |
| T6/T12 and native-dependent Y rows | Blocked by the exact absent interface, without manufacturing source RED |
| T7/T8 | Original pure behavioral/model/mutation remainder remains GAP; it is not all explained by native-host absence |
| Y9/Y12 | Truthful unsupported/direct-session fallback stated at the observed interface scope |
| T17 | Issue remains open; no closure authority or C08 supplied |

The original populations remain 36 nested cases, 14 mutation families, 17 terminal criteria, 15 host conditions, six TY cases and seven binding fixtures. The 14 custody UNKNOWN differences remain UNKNOWN.

Some semantic cases can in principle use a fresh unprimed actor without native Stop. This worker has read the original expectations and was explicitly prohibited from dispatching another agent because slots are reserved. It therefore cannot manufacture independent actor evidence. Root can assign the existing original frozen missing cases when a fresh actor/reviewer is available. No substitute bank, new framework or ceremonial source suite was created.

## Final checks and authority return

Final read-only checks again observed main `4c1c91e…`, PR255 `5277eb82…` OPEN, and #211 OPEN with four comments and unchanged body. `FINAL_HEAD_READBACK.json` records this receiving boundary. The authoritative issue body remains 64,795 bytes / `ca62f4899a45544549f623a0312c16121bb99f432ccb87a87b7361974ceb94c4`; the host amendment remains 19,189 bytes / `7f39828c5f76683d74531bd49c2ec9a6a2c84bc4d59e52ba8d7a07c251c8c38e`.

There were zero product edits, commits, pushes, tags, merges, releases, source-suite replays, new builds, new installs, native events, protected operations, G132 operations, model CLI invocations or additional agent dispatches. Three main-side focused checks and read-only provider/source inspections supply the new work. All report paths are within the delegated scratch directory.

Root remains the sole continuing executor, integrator, protected/publication owner and acceptance decision maker.
