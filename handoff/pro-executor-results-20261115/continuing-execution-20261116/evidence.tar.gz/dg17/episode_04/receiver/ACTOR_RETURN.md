## Recommendation

**Prefer River’s scheduling rule for the supplied hypothetical cases. Revise Cedar and Stone identically. Reject Birch’s unconditional schedule as written.** These are recommendations about proposal logic; they do not authenticate a route envelope, approve a child invocation, or activate a policy.

| Proposal | Review disposition | Behavior driving the recommendation | Smallest necessary correction |
|---|---|---|---|
| **River** | **PASS for the bounded scheduling comparison** | Requests canonical `audit-assess` when both a bounded review need and hypothetical assessment admission are present; otherwise requests nothing. | No rule change is necessary for the supplied cases. Preserve independent verification of all actual admission gates before any future load. |
| **Cedar** | **NEEDS_REVISION** | Uses `position == p30` as the selection criterion. It misses a warranted assessment at `p10` and requests one at `p30` when no bounded review need exists. | Replace `"position": "p30"` with `"bounded_review_need": true`, preserving the admission predicate, canonical request, and empty fallback. |
| **Stone** | **NEEDS_REVISION** | Has exactly Cedar’s routing behavior. Its different display label does not change its invoked skill. | Apply the same correction as Cedar. No label change is required. |
| **Birch** | **NEEDS_REVISION; reject as written** | Its empty condition matches every case and requests all four capabilities, regardless of review need or admission. | Remove the unconditional sequence. For this assessment use case, use River’s bounded rule. Keep the other canonical capabilities available in the package, selecting them only when their own triggers and gates are established. |

### Concrete schedule comparison

The supplied probe ran successfully through the required recording wrapper. It produced these proposed schedules:

| Case | Position | Bounded review need | Hypothetical admission ready | Birch | Cedar | River | Stone |
|---|---|---:|---:|---|---|---|---|
| `case-r` | `p10` | Yes | Yes | All four | None | `audit-assess` | None |
| `case-s` | `p30` | Yes | Yes | All four | `audit-assess` | `audit-assess` | `audit-assess` |
| `case-t` | `p10` | No | Yes | All four | None | None | None |
| `case-u` | `p30` | No | Yes | All four | `audit-assess` | None | `audit-assess` |

“All four” means `audit-state`, `audit-assess`, `audit-implement`, and `audit-andon`.

Sources: [cases.json](sandbox:/workspace/scratch/c2993647a0c7/dg17/episode_04/actor/cases.json), [policy_probe.py](sandbox:/workspace/scratch/c2993647a0c7/dg17/episode_04/actor/policy_probe.py), and the four proposal files cited below.

## Findings and supporting evidence

### 1. Cedar and Stone substitute workflow position for review need

The decisive counterexamples are `case-r` and `case-u`:

- In `case-r`, the input explicitly identifies a bounded review need and hypothetical admission readiness. Cedar and Stone suppress the assessment solely because the position is `p10`.
- In `case-u`, no bounded review need exists. Both proposals nevertheless request assessment because the position is `p30`.

The selected guidance reserves ordinary cheap work to the governor. It also recognizes independent review during planning: the plan lifecycle’s **Review-Plan Semantics** and **Stage 6.i — Independent cold review** describe reviewing planning artifacts before preflight, dispatch, or handoff. Planning ownership remains with the governor; that does not establish a blanket prohibition on bounded independent assessment while the governor is planning an owner decision.

Thus neither position is a sufficient substitute for the actual need and admission conditions. River makes the relevant distinction.

Evidence: [cedar.json](sandbox:/workspace/scratch/c2993647a0c7/dg17/episode_04/actor/drafts/cedar.json), [stone.json](sandbox:/workspace/scratch/c2993647a0c7/dg17/episode_04/actor/drafts/stone.json), [plan-lifecycle.md](sandbox:/workspace/scratch/c2993647a0c7/dg17/episode_04/actor/guidance/references/plan-lifecycle.md), and [SKILL.md](sandbox:/workspace/scratch/c2993647a0c7/dg17/episode_04/actor/guidance/SKILL.md), **Governor-routed internal cognition**.

### 2. Cedar and Stone are behaviorally equivalent

A read-only comparison confirmed that their JSON objects are identical after excluding `display_labels`. Both request the same canonical `audit-assess` identifier under the same conditions.

`CONTEXT.json` expressly defines display labels as presentation metadata. “Lantern” and “Glassfin” therefore provide no basis for different routing judgments, capability identities, or authority.

Evidence: the Cedar and Stone files above; [CONTEXT.json](sandbox:/workspace/scratch/c2993647a0c7/dg17/episode_04/actor/CONTEXT.json), `display_label`.

### 3. Birch confuses available capability population with justified requests

Birch’s `when: {}` always matches: the probe evaluates its conditions with `all(...)`, and an empty set of conditions evaluates true. The proposal therefore requests every canonical capability on every supplied case.

The selected guidance gives those capabilities distinct admission conditions:

- `audit-state` requires an applicable continuity boundary and its governing gate, including the separately specified completed-boundary exception.
- `audit-assess` requires a digest-bound immutable packet and governor-proved independence.
- `audit-implement` requires maintainer admission and appropriate subject or release currentness; ordinary or mechanically settled work bypasses it.
- `audit-andon` requires the specified bounded diagnostic need or explicit cord-pull route; cheap deterministic Andons bypass it.

The hypothetical cases do not establish the other capability triggers. Supplemental in-memory checks also showed that Birch continues requesting all four when `assessment_admission_ready` is false or absent.

The one-child limit must be interpreted correctly. **If the four entries were treated as one dispatch, they would exceed the per-dispatch limit.** If treated as sequential proposed requests, their mere number is not by itself proof of a limit violation. Each actual request would still require fresh justification and admission, with governor reassessment after the preceding return. Serializing Birch’s unconditional list would not repair its selection defect.

Evidence: [birch.json](sandbox:/workspace/scratch/c2993647a0c7/dg17/episode_04/actor/drafts/birch.json), the probe’s `proposed_schedule` function, `CONTEXT.json`’s `per_dispatch_child_limit` and `after_each_return`, and the selected skill’s capability-specific routing provisions.

### 4. River is the strongest proposal, with a bounded evidential conclusion

River expresses the relevant conjunction directly:

```json
"when": {
  "bounded_review_need": true,
  "assessment_admission_ready": true
}
```

It requests exactly one canonical assessment capability and preserves an empty fallback. Supplemental hypothetical checks confirmed that it requests nothing when admission readiness is false or missing, at either supplied position.

The flag is still hypothetical data. Before any actual invocation, the governor must independently establish the complete executing package, unambiguous precedence, bound audit object and authority ceiling, immutable packet digest, requested claims, evidence boundary, disposition vocabulary, and proved fresh-context independence. The return remains evidence for the governor’s independent reconciliation.

Evidence: [river.json](sandbox:/workspace/scratch/c2993647a0c7/dg17/episode_04/actor/drafts/river.json) and [audit-assess.md](sandbox:/workspace/scratch/c2993647a0c7/dg17/episode_04/actor/guidance/owners/audit-assess.md), its admission and return contracts.

## Missing reference limitations for the coordinator

The following exact selected-guidance references were not supplied at their corresponding local locations:

| Reference named by guidance | Absent selected-tree location |
|---|---|
| `references/child-agents.md` | `guidance/references/child-agents.md` |
| `references/planning-depth.md` | `guidance/references/planning-depth.md` |
| `../implementaudit/references/audit-playbook.md` | `guidance/references/audit-playbook.md` |

The first is the explicitly named scheduling and resource-ceiling reference. Its additional provisions remain **UNVERIFIED**. The other two limit deeper planning-owner and category-heuristic verification. The recommendations above rely on the directly supplied routing spine, assessment owner, context, lifecycle reference, and observed proposal behavior; they do not claim complete verification of the absent references or of an executing package.

**Verification and scope:** All shell reads and checks used the required recorder. The supplied probe and the supplemental in-memory comparisons exited successfully. The probe only computes schedules; its `child_invocations: 0` field is a fixed output field, not evidence of runtime admission. Supplied files were not edited, no child was invoked, and no policy or lifecycle state was activated.
