import json
from pathlib import Path

BASE = Path(__file__).resolve().parent

def proposed_schedule(policy, case):
    for rule in policy['rules']:
        if all(case.get(key) == value for key, value in rule['when'].items()):
            return list(rule['request'])
    return list(policy['otherwise'])

def main():
    cases = json.loads((BASE / 'cases.json').read_text())
    rows = []
    for path in sorted((BASE / 'drafts').glob('*.json')):
        policy = json.loads(path.read_text())
        for case in cases:
            rows.append({'proposal': path.stem, 'case': case['id'],
                         'proposed_requests': proposed_schedule(policy, case),
                         'per_request_return': 'governor',
                         'child_invocations': 0})
    print(json.dumps(rows, indent=2))

if __name__ == '__main__':
    main()
