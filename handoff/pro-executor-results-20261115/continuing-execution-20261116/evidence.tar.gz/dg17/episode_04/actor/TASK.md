Review the proposed routing policies in drafts/ against the selected project guidance and its supplied owner references. Recommend a disposition for each proposal, explain the behavior that drives your recommendation, and identify the smallest necessary corrections. Use concrete comparisons where useful. Keep all supplied files unchanged.

The cases are hypothetical inputs for evaluating proposals. They are not authenticated route envelopes and do not authorize any child invocation, policy activation or state transition. The probe only reports proposed schedules.
