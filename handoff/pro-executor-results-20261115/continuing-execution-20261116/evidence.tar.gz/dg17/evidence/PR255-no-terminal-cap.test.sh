#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_root"

tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT

# 1. A source-backed proper noun containing "strike" is not a strike-counter
#    contract and must remain valid public documentation.
mkdir -p "$tmp/good-proper-noun/docs/portal/pages"
cat >"$tmp/good-proper-noun/docs/portal/pages/reliability.html" <<'EOF'
The CrowdStrike post-incident report documents a correlated update failure.
A lightning strike can interrupt service; recovery follows observed evidence.
A single strike damaged the unprotected sensor.
The first strike damaged the transformer; the second hit an isolated feeder.
Strike the stale observation from the record only after independent readback.
Hansei may follow any strike, regression, or evidence mismatch.
EOF
bash scripts/check-no-terminal-cap.sh --scan-root "$tmp/good-proper-noun"

# 2. The live repo must pass the gate.
bash scripts/check-no-terminal-cap.sh

# 3. Terminal-cap wording in a shipped runtime doc must fail.
mkdir -p "$tmp/bad-strike/skills/implementaudit/references"
cat >"$tmp/bad-strike/skills/implementaudit/references/transcript-contract.md" <<'EOF'
The three-strike sequence stops the run on Strike 3.
EOF

if bash scripts/check-no-terminal-cap.sh --scan-root "$tmp/bad-strike" >/dev/null 2>&1; then
  printf 'no-terminal-cap.test: expected strike wording to fail\n' >&2
  exit 1
fi

# 3. Capped audit-round wording must fail.
mkdir -p "$tmp/bad-rounds/skills/implementaudit/templates"
cat >"$tmp/bad-rounds/skills/implementaudit/templates/PROTOCOL.md" <<'EOF'
The final audit may run up to 3 rounds.
EOF

if bash scripts/check-no-terminal-cap.sh --scan-root "$tmp/bad-rounds" >/dev/null 2>&1; then
  printf 'no-terminal-cap.test: expected round-cap wording to fail\n' >&2
  exit 1
fi

# 3b. Counted/capped strike semantics must fail without banning ordinary uses.
strike_case=0
while IFS= read -r wording; do
  strike_case=$((strike_case + 1))
  dir="$tmp/bad-counted-strike-$strike_case"
  mkdir -p "$dir/skills/implementaudit/templates"
  printf '%s\n' "$wording" >"$dir/skills/implementaudit/templates/PROTOCOL.md"
  if bash scripts/check-no-terminal-cap.sh --scan-root "$dir" >/dev/null 2>&1; then
    printf 'no-terminal-cap.test: expected counted strike wording to fail: %s\n' "$wording" >&2
    exit 1
  fi
done <<'EOF'
The double-strike policy stops work.
The triple-strike rule hands off the run.
The quad-strike attack count terminates the run.
An N-strike attack count blocks closure.
A strike counter terminates at its limit.
The strike count is capped at four.
The strike limit hands off the run.
After 4 strikes, stop and hand off.
After three strikes, stop and hand off.
Strike 3 stops the run.
EOF

# 3c. Counted/capped retry semantics must fail without banning ordinary retry prose.
retry_case=0
while IFS= read -r wording; do
  retry_case=$((retry_case + 1))
  dir="$tmp/bad-counted-retry-$retry_case"
  mkdir -p "$dir/skills/implementaudit/templates"
  printf '%s\n' "$wording" >"$dir/skills/implementaudit/templates/PROTOCOL.md"
  if bash scripts/check-no-terminal-cap.sh --scan-root "$dir" >/dev/null 2>&1; then
    printf 'no-terminal-cap.test: expected counted retry wording to fail: %s\n' "$wording" >&2
    exit 1
  fi
done <<'EOF'
After 3 retries, stop the run.
After three retries, hand off the run.
EOF

# Ordinary retry guidance remains valid when it does not impose a finite
# terminal stop or handoff policy.
mkdir -p "$tmp/good-retry/skills/implementaudit/templates"
cat >"$tmp/good-retry/skills/implementaudit/templates/PROTOCOL.md" <<'EOF'
Retry after a transient evidence mismatch and continue until the evidence resolves.
Repeated retries remain available while the currentness check is inconclusive.
EOF
bash scripts/check-no-terminal-cap.sh --scan-root "$tmp/good-retry"

# 4. Run-stopping wording and legacy marker spellings must fail.
mkdir -p "$tmp/bad-legacy/skills/implementaudit/references"
cat >"$tmp/bad-legacy/skills/implementaudit/references/transcript-contract.md" <<'EOF'
FAILURE_HANDOFF: run stops. No subsequent phases execute.
EOF

if bash scripts/check-no-terminal-cap.sh --scan-root "$tmp/bad-legacy" >/dev/null 2>&1; then
  printf 'no-terminal-cap.test: expected legacy marker wording to fail\n' >&2
  exit 1
fi

# 5. Cap synonyms must fail when they teach runtime behavior.
for term in "max retries" "retry limit" "revision limit" "round limit" "capped rounds" "attempt cap" "max-2 revision" "max-3 audit"; do
  dir="$tmp/bad-synonym-${term// /-}"
  mkdir -p "$dir/skills/implementaudit/references"
  printf 'Escalate after the %s is reached.\n' "$term" >"$dir/skills/implementaudit/references/transcript-contract.md"
  if bash scripts/check-no-terminal-cap.sh --scan-root "$dir" >/dev/null 2>&1; then
    printf 'no-terminal-cap.test: expected synonym wording to fail: %s\n' "$term" >&2
    exit 1
  fi
done

# 6. Explicit denials of caps must remain valid runtime wording.
mkdir -p "$tmp/good-denial/skills/implementaudit/templates"
cat >"$tmp/good-denial/skills/implementaudit/templates/PROTOCOL.md" <<'EOF'
There is no arbitrary retry cap, revision limit, round limit, or attempt cap.
Do not use a first/second/third failure ladder.
EOF
bash scripts/check-no-terminal-cap.sh --scan-root "$tmp/good-denial"

# 7. Legacy history surfaces are exempt: the same wording outside the scanned
#    runtime surfaces must pass.
mkdir -p "$tmp/exempt/docs/audits" "$tmp/exempt/skills/implementaudit"
cat >"$tmp/exempt/docs/audits/old-ledger.md" <<'EOF'
v0.2.6.0 added exact 3-strike failure recovery (FAILURE_PROBE).
EOF
cat >"$tmp/exempt/CHANGELOG.md" <<'EOF'
- Added exact 3-strike failure recovery with FAILURE_HANDOFF.
EOF
cat >"$tmp/exempt/skills/implementaudit/SKILL.md" <<'EOF'
Andon escalation uses ANDON_PROBE, ANDON_ESCALATE, ANDON_HANDOFF.
EOF

bash scripts/check-no-terminal-cap.sh --scan-root "$tmp/exempt"

printf 'no-terminal-cap.test: ok\n'
