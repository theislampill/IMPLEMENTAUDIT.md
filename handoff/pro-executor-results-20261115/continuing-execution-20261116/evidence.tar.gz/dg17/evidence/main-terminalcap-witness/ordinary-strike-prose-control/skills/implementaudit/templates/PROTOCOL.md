The CrowdStrike report discusses a lightning strike. Ordinary strikes do not imply a counter.
