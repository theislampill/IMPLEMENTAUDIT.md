Strike 3 stops the run.
