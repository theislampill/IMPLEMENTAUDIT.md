TEST_ONLY schema fixture. Not a review or an issued act.
