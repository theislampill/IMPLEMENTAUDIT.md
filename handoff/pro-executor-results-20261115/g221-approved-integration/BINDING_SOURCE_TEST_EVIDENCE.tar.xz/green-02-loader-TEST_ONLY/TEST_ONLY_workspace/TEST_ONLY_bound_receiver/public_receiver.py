"""Bounded full-G2 data receiver; never reviews, consumes, grants or awards.

Acquisition is outside this program. A live preview has no terminal log copy.
The exact bound packet is preparation only and carries no launch readiness.
"""
from pathlib import Path
import argparse,hashlib,io,json,os,re,stat,sys,time,types,zipfile

HERE=Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/0269e6626329/g221-integration/.IMPLEMENTAUDIT/g221-binding-tests/green-02-loader-TEST_ONLY/TEST_ONLY_workspace')
RUNTIME_BINDING_SHA = '7f926c6d814b82a14e34de91ec98bf611ae81aeff466627e6647146b3045b438'
MAINTAINED_SOURCE_ROOTS = tuple(Path(p) for p in ('/workspace/scratch/6746ee3422fa/source', '/workspace/scratch/6746ee3422fa/source-codex-home', '/workspace/scratch/6746ee3422fa/source-3e', '/workspace/scratch/6746ee3422fa/source-8ee4', '/workspace/scratch/6746ee3422fa/source-ea61', '/workspace/scratch/6746ee3422fa/source-current', '/workspace/scratch/0269e6626329/g221-integration/.IMPLEMENTAUDIT/g221-binding-tests/green-02-loader-TEST_ONLY/TEST_ONLY_maintained_source', '/workspace/scratch/0269e6626329/g221-integration/.IMPLEMENTAUDIT/g221-binding-tests/green-02-loader-TEST_ONLY/TEST_ONLY_workspace/source', '/workspace/scratch/0269e6626329/g221-integration/.IMPLEMENTAUDIT/g221-binding-tests/green-02-loader-TEST_ONLY/TEST_ONLY_workspace/source-codex-home', '/workspace/scratch/0269e6626329/g221-integration/.IMPLEMENTAUDIT/g221-binding-tests/green-02-loader-TEST_ONLY/TEST_ONLY_workspace/source-3e', '/workspace/scratch/0269e6626329/g221-integration/.IMPLEMENTAUDIT/g221-binding-tests/green-02-loader-TEST_ONLY/TEST_ONLY_workspace/source-8ee4', '/workspace/scratch/0269e6626329/g221-integration/.IMPLEMENTAUDIT/g221-binding-tests/green-02-loader-TEST_ONLY/TEST_ONLY_workspace/source-ea61', '/workspace/scratch/0269e6626329/g221-integration/.IMPLEMENTAUDIT/g221-binding-tests/green-02-loader-TEST_ONLY/TEST_ONLY_workspace/source-current', '/workspace/scratch/0269e6626329/g221-integration/.IMPLEMENTAUDIT/g221-binding-tests/green-02-loader-TEST_ONLY/source', '/workspace/scratch/0269e6626329/g221-integration/.IMPLEMENTAUDIT/g221-binding-tests/green-02-loader-TEST_ONLY/source-codex-home', '/workspace/scratch/0269e6626329/g221-integration/.IMPLEMENTAUDIT/g221-binding-tests/green-02-loader-TEST_ONLY/source-3e', '/workspace/scratch/0269e6626329/g221-integration/.IMPLEMENTAUDIT/g221-binding-tests/green-02-loader-TEST_ONLY/source-8ee4', '/workspace/scratch/0269e6626329/g221-integration/.IMPLEMENTAUDIT/g221-binding-tests/green-02-loader-TEST_ONLY/source-ea61', '/workspace/scratch/0269e6626329/g221-integration/.IMPLEMENTAUDIT/g221-binding-tests/green-02-loader-TEST_ONLY/source-current'))
RECEIVER_OUT = Path('/workspace/scratch/0269e6626329/g221-integration/.IMPLEMENTAUDIT/g221-binding-tests/green-02-loader-TEST_ONLY/TEST_ONLY_workspace/TEST_ONLY_public_acquisition')
BINDING_SHA = '996ed6319821c4fb67ed4107b8823e633e7f4e6cff81585d63f477d540f2406b'
NAMES=('RESULT.json','HOST.json','SOURCE.json','PROBE.json','CLEANUP.json','FAILURE.json','ARTIFACT_MANIFEST.json')
def need(value,code):
    if not value:raise ValueError(code)
def audit(event,args):
    if event in ('subprocess.Popen','os.system','os.fork','os.posix_spawn','socket.__new__'):raise ValueError('RECEIVER_PROCESS_OR_NETWORK_FORBIDDEN')
    if event=='exec' and args and type(args[0]) is types.CodeType:
        need(not any(args[0].co_filename.startswith(str(root)+'/') for root in MAINTAINED_SOURCE_ROOTS),'RECEIVER_MAINTAINED_EXECUTION_FORBIDDEN')
sys.addaudithook(audit)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def desc(raw):return {'bytes':len(raw),'sha256':sha(raw)}
def encode(value):return (json.dumps(value,sort_keys=True,indent=2,ensure_ascii=True,allow_nan=False)+'\n').encode('ascii')

def public_codec(name, subject, decode=False):
    """Bounded public wire only; private/admission/proof encodings are untouched."""
    names = ('RESULT.json', 'HOST.json', 'SOURCE.json', 'PROBE.json', 'CLEANUP.json', 'FAILURE.json', 'ARTIFACT_MANIFEST.json')
    schema = 'dg16.public-document-wire.v1'
    fields = ('current_host_request', 'current_host_qualification', 'expected_tests', 'expected_predicates', 'result', 'requirement', 'historical_bank', 'receiving')
    columns = ('diagnostic_bytes', 'diagnostic_sha256', 'outcome', 'test', 'tests_run')
    earned = tuple('after_currentness_sha256 authority before_currentness_sha256 boot_identity_sha256 capture_sha256 continuity_receipt_sha256 controller credentials_sha256 current_port_rows_sha256 current_port_tests custody_sha256 historical_receipt_transfer host_sha256 original_awards raw_bank_result request_admission_sha256 request_sha256 runtime_sha256 schema scope source_closure_sha256 source_commit source_custody_sha256 source_tree status test_population tests_run workflow_context_sha256'.split())

    def demand(ok, code):
        if not ok:
            raise ValueError('PUBLIC_WIRE_' + code)

    def compact(value):
        return (json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False) + '\n').encode('ascii')

    def string_size(value):
        total = 2
        for char in value:
            number = ord(char)
            total += 2 if char in '"\\\x08\x0c\n\r\t' else 6 if number < 32 or 126 < number <= 65535 else 12 if number > 65535 else 1
        return total

    def bounded(value, pool=None, unshare=False):
        remaining, nodes, active = ([81920], [0], set())

        def charge(count):
            demand(type(count) is int and 0 <= count <= remaining[0], 'EXPANSION_BOUND')
            remaining[0] -= count

        def token(index):
            demand(type(index) is int and 0 <= index < len(pool), 'REFERENCE')
            return pool[index]

        def walk(item, depth=0, path=()):
            demand(depth <= 32 and nodes[0] < 32768, 'DEPTH_OR_NODE_BOUND')
            nodes[0] += 1
            shared = unshare and (path[:1] in (('native_admission',), ('policy_adoption',)) or (len(path) >= 2 and path[0] == 'native_prerequisite' and (path[1] in fields)))
            if shared and type(item) is dict and ('$' in item):
                demand(set(item) == {'$'}, 'REFERENCE_SHAPE')
                value = token(item['$'])
                charge(string_size(value))
                return value
            if type(item) is str:
                charge(string_size(item))
                return item
            if item is None or type(item) in (bool, int, float):
                demand(type(item) is not int or item.bit_length() <= 32768, 'INTEGER_BOUND')
                charge(len(json.dumps(item, allow_nan=False)))
                return item
            demand(type(item) in (dict, list) and id(item) not in active, 'TYPE_OR_CYCLE')
            active.add(id(item))
            try:
                charge(2 + max(0, len(item) - 1))
                if type(item) is list:
                    return [walk(value, depth + 1, path + (index,)) for index, value in enumerate(item)]
                out = {}
                for key, value in item.items():
                    demand(type(key) is str, 'KEY_TYPE')
                    if shared and key.startswith('@'):
                        tail = key[1:]
                        demand(tail.isascii() and tail.isdecimal() and (len(tail) <= 3), 'KEY_REFERENCE')
                        index = int(tail)
                        demand(str(index) == tail, 'KEY_REFERENCE_CANONICAL')
                        key = token(index)
                    demand(key not in out, 'KEY_ALIAS')
                    charge(string_size(key) + 1)
                    out[key] = walk(value, depth + 1, path + (key,))
                return out
            finally:
                active.remove(id(item))
        return walk(value)

    def eligible(doc):
        native = doc.get('native_prerequisite')
        if name != 'PROBE.json' or type(native) is not dict:
            return False
        qualification = native.get('current_host_qualification')
        return type(qualification) is dict and qualification.get('schema') == 'dg16.earned-current-host-native-qualification.v1' and (qualification.get('status') == 'RECEIVED_FRESH_NINE_CASE_CURRENT_HOST')

    def roots(doc):
        native = doc['native_prerequisite']
        demand(all((key in native for key in fields)), 'NATIVE_FIELDS')
        return [doc['native_admission'], doc['policy_adoption']] + [native[key] for key in fields]

    def encode(doc):
        doc = bounded(doc)
        demand(type(doc) is dict, 'DOCUMENT')
        shared = eligible(doc)
        pool = []
        if shared:
            demand(len(compact(roots(doc))) <= 16384, 'IMMUTABLE_PREFIX_BOUND')
            native = doc['native_prerequisite']
            qualification = native['current_host_qualification']
            demand(set(qualification) == set(earned), 'EARNED_FIELDS')
            native['current_host_qualification'] = [qualification[key] for key in earned]
            rows = native['result']['rows']
            demand(type(rows) is list and len(rows) == 9 and all((type(row) is dict and set(row) == set(columns) for row in rows)), 'ROW_SHAPE')
            native['result']['rows'] = [[row[key] for key in columns] for row in rows]
            values, keys = ({}, {})

            def collect(item):
                if type(item) is str:
                    values[item] = values.get(item, 0) + 1
                elif type(item) is list:
                    for child in item:
                        collect(child)
                elif type(item) is dict:
                    for key, child in item.items():
                        demand(key != '$' and (not key.startswith('@')), 'RESERVED_KEY')
                        keys[key] = keys.get(key, 0) + 1
                        collect(child)
            for item in roots(doc):
                collect(item)
            pool = sorted((text for text in set(values) | set(keys) if values.get(text, 0) * (string_size(text) - 11) + keys.get(text, 0) * (string_size(text) - 6) > string_size(text) + 1))
            demand(len(pool) <= 256 and all((string_size(text) <= 4096 for text in pool)), 'POOL_BOUND')
            index = {text: ordinal for ordinal, text in enumerate(pool)}

            def pack(item):
                if type(item) is str and item in index:
                    return {'$': index[item]}
                if type(item) is list:
                    return [pack(child) for child in item]
                if type(item) is dict:
                    return {'@' + str(index[key]) if key in index else key: pack(child) for key, child in item.items()}
                return item
            for key in ('native_admission', 'policy_adoption'):
                doc[key] = pack(doc[key])
            for key in fields:
                native[key] = pack(native[key])
        raw = compact(dict(schema=schema, name=name, shared=shared, strings=pool, document=doc))
        demand(len(raw) <= 65536, 'FILE_BOUND')
        return raw
    demand(name in names and type(decode) is bool, 'API')
    if not decode:
        return encode(subject)
    demand(type(subject) is bytes and 0 < len(subject) <= 65536, 'FILE_BOUND')
    depth, quoted, escaped = (0, False, False)
    for byte in subject:
        if quoted:
            if escaped:
                escaped = False
            elif byte == 92:
                escaped = True
            elif byte == 34:
                quoted = False
        elif byte == 34:
            quoted = True
        elif byte in (91, 123):
            depth += 1
            demand(depth <= 32, 'DEPTH_OR_NODE_BOUND')
        elif byte in (93, 125):
            depth -= 1
            demand(depth >= 0, 'DEPTH_OR_NODE_BOUND')

    def pairs(items):
        out = {}
        for key, value in items:
            demand(key not in out, 'DUPLICATE_KEY')
            out[key] = value
        return out

    def nonfinite(_):
        demand(False, 'NONFINITE')
    value = json.loads(subject, object_pairs_hook=pairs, parse_constant=nonfinite)
    if type(value) is not dict or value.get('schema') != schema:
        demand(not (type(value) is dict and type(value.get('schema')) is str and value['schema'].startswith('dg16.public-document-wire.')), 'VERSION')
        legacy = (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode('ascii')
        demand(legacy == subject, 'LEGACY_CANONICAL')
        return bounded(value)
    demand(set(value) == {'schema', 'name', 'shared', 'strings', 'document'} and value['name'] == name and (type(value['shared']) is bool), 'ENVELOPE')
    pool = value['strings']
    demand(type(pool) is list and len(pool) <= 256 and all((type(text) is str and string_size(text) <= 4096 for text in pool)) and (pool == sorted(set(pool))), 'POOL_BOUND_OR_ORDER')
    doc = value['document']
    demand(type(doc) is dict, 'DOCUMENT')
    if value['shared']:
        demand(name == 'PROBE.json', 'SHARING_SCOPE')
        native = doc.get('native_prerequisite')
        demand(type(native) is dict and all((key in native for key in fields)), 'NATIVE_FIELDS')
        doc = bounded(doc, pool, True)
        native = doc['native_prerequisite']
        qualification = native['current_host_qualification']
        demand(type(qualification) is list and len(qualification) == len(earned), 'EARNED_FIELDS')
        rows = native['result']['rows']
        demand(type(rows) is list and len(rows) == 9 and all((type(row) is list and len(row) == len(columns) for row in rows)), 'ROW_SHAPE')
        restored_keys = sum((string_size(key) + 1 for key in earned)) + 9 * sum((string_size(key) + 1 for key in columns))
        demand(len(compact(doc)) + restored_keys <= 81920, 'EXPANSION_BOUND')
        native['current_host_qualification'] = dict(zip(earned, qualification))
        native['result']['rows'] = [dict(zip(columns, row)) for row in rows]
        demand(eligible(doc) and len(compact(roots(doc))) <= 16384, 'IMMUTABLE_PREFIX_BOUND')
    else:
        demand(not pool, 'UNUSED_POOL')
    doc = bounded(doc)
    demand(encode(doc) == subject, 'NONCANONICAL_OR_UNUSED_REFERENCE')
    return doc

def strict(raw):
    def pairs(items):
        result={}
        for key,value in items:
            need(key not in result,'DUPLICATE_JSON_KEY');result[key]=value
        return result
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('NONFINITE_JSON')))
def acquire(path,limit):
    before=path.lstat();need(stat.S_ISREG(before.st_mode) and before.st_nlink==1 and 0<=before.st_size<=limit,'INPUT_FILE_SHAPE')
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        with os.fdopen(fd,'rb',closefd=False) as stream:raw=stream.read(limit+1)
        after=os.fstat(fd)
        stamp=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
        need(stamp(before)==stamp(after)==stamp(path.lstat()) and len(raw)==before.st_size,'INPUT_CHANGED')
        return raw
    finally:os.close(fd)
def verify_seal(path,wanted):
    raw=acquire(path/'SEAL.json',65536);need(sha(raw)==wanted,'DEPENDENCY_SEAL_CHANGED');value=strict(raw)
    rows=value['members'];need(type(rows) is list and len(rows)==value['member_count'] and len({r['path'] for r in rows})==len(rows),'DEPENDENCY_MEMBER_POPULATION')
    for row in rows:
        name=Path(row['path']);need(not name.is_absolute() and '..' not in name.parts,'DEPENDENCY_PATH')
        need(desc(acquire(path/name,8*1024**2))=={k:row[k] for k in ('bytes','sha256')},'DEPENDENCY_MEMBER_CHANGED')
    return value
def verified():
    need(type(RUNTIME_BINDING_SHA) is str,'SUCCESSOR_RUNTIME_BINDING_REQUIRED')
    runtime_raw=acquire(HERE/'SUCCESSOR_RUNTIME_BINDING.json',16384)
    need(sha(runtime_raw)==RUNTIME_BINDING_SHA,'SUCCESSOR_RUNTIME_BINDING_CHANGED')
    raw=acquire(HERE/'BINDING.json',16384);need(sha(raw)==BINDING_SHA,'RECEIVER_BINDING_CHANGED');b=strict(raw)
    lane=Path(b['candidate_path']);compose=Path(b['composition_path']);code=lane/'candidate/public/qualification/dg16-r5-full-g2'
    verify_seal(lane,b['candidate_seal_sha256']);verify_seal(compose,b['composition_seal_sha256'])
    c_raw=acquire(compose/'COMPOSITION.json',16384);g_raw=acquire(compose/'POLICY_GATE_READBACK.json',16384)
    need(sha(c_raw)==b['composition_sha256'] and sha(g_raw)==b['policy_gate_sha256'],'COMPOSITION_RECORD_CHANGED')
    composition,gate=strict(c_raw),strict(g_raw)
    for field in ('source_commit','source_tree','final_tree','branch','control_branch','candidate_seal_sha256'):
        need(composition[field]==b[field],'COMPOSITION_BINDING')
    need(composition['independent_review_seal_sha256']==b['code_review_seal_sha256'] and
         gate['review_sha256']==b['public_review_sha256'] and gate['adoption_sha256']==b['public_adoption_sha256'],'DECISION_BINDING')
    acquired={n:acquire(code/n,1024**2) for n in b['modules']}
    need(all(desc(raw)==b['modules'][n] for n,raw in acquired.items()),'VALIDATOR_PIN_CHANGED')
    modules={}
    for n in ('host_utility.py','full_relation.py','live_control.py','run.py','capture_evidence.py'):
        m=types.ModuleType('receiver_bound_'+n[:-3]);m.__file__=str(code/n)
        exec(compile(acquired[n],str(code/n),'exec',dont_inherit=True,optimize=0),m.__dict__);modules[n]=m
    native_raw=acquire(HERE/'native_public.py',65536)
    need(desc(native_raw)==b['native_public_validator'],'NATIVE_PUBLIC_VALIDATOR_PIN')
    native=types.ModuleType('receiver_current_native_public');native.__file__=str(HERE/'native_public.py')
    exec(compile(native_raw,native.__file__,'exec',dont_inherit=True,optimize=0),native.__dict__)
    modules['native_public.py']=native
    modules['native_integration.py']=modules['run.py'].load_native(modules['host_utility.py'])
    native_gate_raw=acquire(compose/'NATIVE_GATE_READBACK.json',16384)
    need(sha(native_gate_raw)==b['native_gate_sha256'],'NATIVE_GATE_RECORD_CHANGED')
    integration=modules['native_integration.py']
    decisions=compose/'public/qualification/dg16-r5-full-g2-decisions'
    payload={name:acquire(decisions/name,65536) for name in integration.A.FILES}
    native.validate_admission(payload,integration=integration,gate=strict(native_gate_raw),
        binding=b,composition=composition)
    return b,composition,gate,modules,strict(acquired['CAPTURE_DIAGNOSTIC_CATALOG.json']),strict(acquired['SOURCE_MANIFEST.json'])

def expected_names(kind):
    need(kind in ('live','terminal'),'ARTIFACT_KIND')
    return set(NAMES) if kind=='terminal' else {'REQUEST.json','PROOF.json'}|{'public/'+n for n in NAMES}
def decode_zip(raw,kind):
    need(type(raw) is bytes and 0<len(raw)<=400000,'ARCHIVE_COMPRESSED_BOUND');expected=expected_names(kind)
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        infos=archive.infolist();need(len(infos)==len(expected) and {i.filename for i in infos}==expected,'ARCHIVE_POPULATION')
        need(sum(i.file_size for i in infos)<=262144,'ARCHIVE_TOTAL_BOUND');files={};semantic=0
        for entry in infos:
            limit=4096 if entry.filename=='REQUEST.json' else 16384 if entry.filename=='PROOF.json' else 65536
            need(entry.filename not in files and not entry.is_dir() and not entry.flag_bits&1 and
                 entry.compress_type in (zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED) and
                 stat.S_IFMT(entry.external_attr>>16) in (0,stat.S_IFREG) and 0<entry.file_size<=limit,'ARCHIVE_ENTRY')
            with archive.open(entry) as stream:data=stream.read(limit+1)
            need(len(data)==entry.file_size,'ARCHIVE_MEMBER_LENGTH')
            if entry.filename in ('REQUEST.json','PROOF.json'):
                need(encode(strict(data))==data,'ARCHIVE_MEMBER_CANONICAL');semantic+=len(data)
            else:
                name=entry.filename.removeprefix('public/')
                value=public_codec(name,data,True)
                semantic+=len((json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode('ascii'))
            need(semantic<=262144,'ARCHIVE_SEMANTIC_TOTAL_BOUND')
            files[entry.filename]=data
    return files

def metadata_bindings(metadata,kind,run_id,workflow_commit,archive,b):
    need(type(metadata) is dict and set(metadata)=={'run','commit','artifact'},'METADATA_POPULATION')
    run,commit,artifact=(metadata[n] for n in ('run','commit','artifact'))
    need(type(run_id) is str and re.fullmatch('[1-9][0-9]{0,19}',run_id) and re.fullmatch('[0-9a-f]{40}',workflow_commit),'EXPECTED_ACTUAL_IDENTITY')
    need(type(run['id']) is int and str(run['id'])==run_id and type(run['run_attempt']) is int and run['run_attempt']==1 and
         run['head_sha']==workflow_commit and run['head_branch']==b['branch'] and run['event']=='push' and
         run['repository']['full_name']==b['repository'],'ACTUAL_RUN_BINDING')
    need(run['status']==('in_progress' if kind=='live' else 'completed'),'ACTUAL_RUN_PHASE')
    need(commit['sha']==workflow_commit and commit['tree']['sha']==b['final_tree'] and
         [p['sha'] for p in commit['parents']]==[b['source_commit']],'ACTUAL_COMMIT_TREE_PARENT')
    name=('dg16-full-correspondence-review-' if kind=='live' else 'dg16-full-registry-')+run_id+'-1'
    need(type(artifact['id']) is int and artifact['id']>0 and artifact['name']==name and artifact['expired'] is False and
         artifact['size_in_bytes']==archive['bytes'] and artifact['digest']=='sha256:'+archive['sha256'] and
         artifact['workflow_run']['id']==run['id'] and artifact['workflow_run']['head_sha']==workflow_commit and
         artifact['workflow_run']['head_branch']==b['branch'],'ACTUAL_ARTIFACT_BINDING')
    return {'run_id':run_id,'run_attempt':1,'workflow_commit':workflow_commit,'artifact_id':artifact['id'],
            'metadata_sha256':{n:sha(encode(metadata[n])) for n in metadata},'archive':archive,
            'scope':'PROVIDED_METADATA_BINDINGS; acquisition authenticity is independently received'}

def public_bindings(public,kind,run_id,workflow_commit,b,modules,catalog,manifest):
    utility,parent,evidence=(modules[n] for n in ('host_utility.py','run.py','capture_evidence.py'))
    transport=utility.transport_lines(public)
    docs={n:public_codec(n,raw,True) for n,raw in public.items()}
    result,probe,source,failure,cleanup=(docs[n] for n in ('RESULT.json','PROBE.json','SOURCE.json','FAILURE.json','CLEANUP.json'))
    fixed={'schema':'dg16.full-registry-episode-result.v1','repository':b['repository'],'branch':b['branch'],
           'run_id':run_id,'run_attempt':1,'workflow_commit':workflow_commit}
    need(all(type(result.get(k)) is type(v) and result[k]==v for k,v in fixed.items()),'PUBLIC_RESULT_IDENTITY')
    for key,name in {'adapter_sha256':'run.py','utility_sha256':'host_utility.py','pair_driver_sha256':'pair_driver.py',
                     'source_manifest_sha256':'SOURCE_MANIFEST.json','policy_sha256':'POLICY.json','receiver_inputs_sha256':'RELATION_INPUTS.json'}.items():
        expected=parent.PAIR_DRIVER_SHA if name=='pair_driver.py' else b['modules'][name]['sha256']
        need(result.get(key)==expected,'PUBLIC_CODE_BINDING')
    need(all(result.get(k) is False for k in ('G1','C5','full_G2','G3','full_T14','original_acceptance','audit_closure','independent_assessment','automatic_retry')),'PUBLIC_NO_AWARDS')
    need(source['schema']=='dg16.full-registry-episode-source.v1' and source['commit']==b['source_commit'] and
         source['tree']==b['source_tree'] and source['tracked_source_mutations'] is False,'PUBLIC_SOURCE_BINDING')
    need(set(failure)=={'schema','present','failures','capture_observation','protected_streams'} and
         failure['schema']=='dg16.full-registry-episode-failure.v1' and type(failure['present']) is bool and
         type(failure['failures']) is list,'PUBLIC_FAILURE_SHAPE')
    need(failure['present'] is bool(failure['failures']),'PUBLIC_FAILURE_CONSISTENCY')
    observation=failure['capture_observation']
    need(observation is None or failure['present'] is True,'PUBLIC_SUPPLEMENT_REQUIRES_FAILURE')
    if observation is not None:
        keys={'schema','authority','mode','selection_file','reserved_modes','observation','scope','original_acceptance','Q02'}
        need(type(observation) is dict and set(observation)==keys and
             observation['schema']=='dg16.full-pair-failed-leg-observation.v1' and observation['authority']=='NONE' and
             observation['mode'] in ('legacy','dag') and observation['scope']=='SUPPLEMENTARY_FAILURE_DATA_NOT_FULL_PAIR_RECEIVING' and
             observation['original_acceptance'] is False and observation['Q02'] is False,'PUBLIC_SUPPLEMENT_SCOPE')
        evidence.descriptor(observation['selection_file'],4096)
        projection=evidence.validate_projection(observation['observation'],catalog);record=projection['record']
        need(record['mode']==observation['mode'] and record['attempts']==1 and record['owner_return']!=0 and
             observation['reserved_modes']==(['legacy'] if record['mode']=='legacy' else ['legacy','dag']) and
             projection['diagnostic_complete'] is False and len(encode(observation))<=32768,'PUBLIC_SUPPLEMENT_BINDING')
    ctx=dict(repository=b['repository'],branch=b['branch'],run_id=run_id,run_attempt=1,workflow_commit=workflow_commit,
      source_commit=b['source_commit'],source_tree=b['source_tree'],workflow_path='.github/workflows/dg16-r5-full-g2.yml',job_name='full-registry-raw-pair')
    need('protected_capability' in probe,'PROTECTED_CAPABILITY_FIELD_REQUIRED')
    protected=parent.load_protected(utility).validate_public(probe,failure,ctx,utility)
    native_projection=probe['native_prerequisite']
    native_host=None if native_projection is None or native_projection['requirement'] is None else {k:docs['HOST.json'][k] for k in modules['native_public.py'].HOST_KEYS}
    projection_failure=any(type(row) is dict and row.get('operation') in
        {step+'-native-projection' for step in (*parent.STEPS,'finalize')} for row in failure['failures'])
    native_observation=modules['native_public.py'].validate(native_projection,kind=kind,host=native_host,
        integration=modules['native_integration.py'],projection_failure=projection_failure,episode_context=ctx)
    capture_observation=modules['native_public.py'].capture_records(docs['HOST.json']['commands'],
        positive=kind=='live' or result['status']=='FULL_CORRESPONDENCE_REVIEWED_AND_ROOT_CONSUMED_NO_AUTOMATIC_ACCEPTANCE')
    if probe['result'] is not None:parent.validate_pair_summary(probe['result'])
    if kind=='live':
        need(failure=={'schema':'dg16.full-registry-episode-failure.v1','present':False,'failures':[],'capture_observation':None,'protected_streams':None},'LIVE_FAILURE_PRESENT')
        need(cleanup['all_step_children_reaped'] is True and cleanup['private_outputs_uploaded'] is False,'LIVE_CHILD_CUSTODY')
        expected={'all_members_match':True,'file_count':manifest['file_count'],'manifest_sha256':b['modules']['SOURCE_MANIFEST.json']['sha256'],'total_bytes':manifest['total_bytes']}
        need(source['before']==expected and source['after'] is None,'LIVE_SOURCE_BOOKEND_STAGE')
        need(result['completed_steps']==list(parent.STEPS[:-2]) and probe['started'] is True and
             probe['currentness_before_pair'] is True and probe['currentness_after_pair'] is True and
             probe['result_disposition']=='RECEIVED_COMPLETE_RAW_PAIR','LIVE_STAGE_OR_PAIR_BINDING')
        summary=probe['result'];need(summary['receiving_status']=='RECEIVED_COMPLETE_RAW_PAIR','LIVE_COMPLETE_RAW_PAIR')
        need(summary['mapping']['mapped_nodes']==b['registry_population']['nodes'] and summary['mapping']['registered_tests']==b['registry_population']['registered_entries'] and
             summary['mapping']['command_stream']['sha256']==modules['full_relation.py'].COMMAND_SHA and
             all(r['registry_sha256']==modules['full_relation.py'].REGISTRY_SHA for r in summary['records']) and
             all(r['status']=='PASS' and r['terminal'] is True for r in summary['records'][1]['nodes']),'LIVE_FULL_POPULATION')
        need(probe['receiving'].get('status')==summary['receiving_status']==probe['result_disposition']=='RECEIVED_COMPLETE_RAW_PAIR' and
             probe['receiving']['result_sha256']==sha(encode(summary)) and
             probe['receiving']['while_same_checkout_current'] is True and probe['receiving']['receipt_transfer_authority'] is False,'LIVE_RAW_SUMMARY_RECEIVING_JOIN')
    return docs,{'transport_lines':len(transport),'public_bytes':sum(map(len,public.values())),
                 'terminal_status':result['status'],'failure_present':failure['present'],
                 'supplement_present':observation is not None,'native':native_observation,'captures':capture_observation,'protected':protected}

def inspect(files,kind,*,run_id,workflow_commit,metadata,archive,now=None):
    need(set(files)==expected_names(kind),'ARTIFACT_POPULATION')
    b,composition,gate,modules,catalog,manifest=verified()
    meta=metadata_bindings(metadata,kind,run_id,workflow_commit,archive,b)
    public={n:files[n if kind=='terminal' else 'public/'+n] for n in NAMES}
    docs,summary=public_bindings(public,kind,run_id,workflow_commit,b,modules,catalog,manifest)
    result={'schema':'dg16.current-full-g2.data-only-receiving-observation.v1','authority':'NONE',
            'status':'FORMAT_AND_BINDINGS_CHECKED_REQUIRES_ACTUAL_INDEPENDENT_ASSESSMENT','kind':kind,
            'binding_sha256':BINDING_SHA,'composition_seal_sha256':b['composition_seal_sha256'],
            'files':{n:desc(v) for n,v in sorted(files.items())},'metadata':meta,'public':summary,
            'review_issued':False,'root_consumption_issued':False,'launch_readiness':False,'original_acceptance':False}
    if kind=='terminal':
        result['terminal_log_join']='NOT_SUPPLIED_YET';return result
    request,proof,probe=strict(files['REQUEST.json']),strict(files['PROOF.json']),docs['PROBE.json']
    full,live=modules['full_relation.py'],modules['live_control.py']
    fixed={'schema':'dg16.full-correspondence-live-review-request.v1','authority':'NONE','repository':b['repository'],
        'branch':b['branch'],'run_id':run_id,'run_attempt':1,'workflow_commit':workflow_commit,'source_commit':b['source_commit'],
        'source_tree':b['source_tree'],'policy_sha256':b['modules']['POLICY.json']['sha256'],'policy_adoption_sha256':gate['adoption_sha256'],
        'receiver_inputs_sha256':b['modules']['RELATION_INPUTS.json']['sha256'],'full_receiver_sha256':b['modules']['full_relation.py']['sha256'],
        'proof':desc(files['PROOF.json']),'private_observations':proof['private_observations'],'hold_seconds':300,
        'control_branch':b['control_branch'],'control_path':'qualification/dg16-full-g2-control/'+run_id+'-1',
        'private_inputs_retained_while_live':True,'same_job_closing_readback_required':True,'all_declared_relations_equal':True,
        'original_acceptance':False,'automatic_full_G2_award':False}
    need(set(request)==set(fixed)|{'created_utc_epoch','expires_utc_epoch','same_job_currentness_sha256'} and
         all(type(request[k]) is type(v) and request[k]==v for k,v in fixed.items()),'LIVE_REQUEST_BINDINGS')
    need(type(request['created_utc_epoch']) is int and type(request['expires_utc_epoch']) is int and
         request['expires_utc_epoch']==request['created_utc_epoch']+300 and
         type(request['same_job_currentness_sha256']) is str and re.fullmatch('[0-9a-f]{64}',request['same_job_currentness_sha256']),'LIVE_REQUEST_TIME_SHAPE')
    current=time.time() if now is None else now
    need(request['created_utc_epoch']<=current<request['expires_utc_epoch'],'LIVE_REQUEST_EXPIRED_OR_FUTURE')
    full.validate_public_proof(proof,policy_sha=fixed['policy_sha256'],inputs_sha=fixed['receiver_inputs_sha256'],
        source_commit=b['source_commit'],source_tree=b['source_tree'])
    need(proof['all_declared_relations_equal'] is True and probe['result']['full_correspondence']==proof and
         probe['live_review']['status']=='ACTUAL_REVIEW_REQUIRED' and
         probe['live_review']['request_sha256']==sha(files['REQUEST.json']) and
         probe['live_review']['proof_sha256']==sha(files['PROOF.json']),'LIVE_PROOF_PUBLIC_JOIN')
    closing_now=time.time() if now is None else now
    need(request['created_utc_epoch']<=closing_now<request['expires_utc_epoch'],'LIVE_REQUEST_EXPIRED_DURING_VALIDATION')
    result.update(request_sha256=sha(files['REQUEST.json']),proof_sha256=sha(files['PROOF.json']),
        expires_utc_epoch=request['expires_utc_epoch'],seconds_remaining=request['expires_utc_epoch']-closing_now,
        private_observations=proof['private_observations'],raw_receive_record=probe['result']['receive_record'],
        live_log_join='NOT_APPLICABLE_WORKFLOW_DOES_NOT_EMIT_NINE_FILE_PREVIEW',
        outstanding_actual_assessment=['Actual host/native applicability and currentness records','Actual source/full raw and proof relations',
            'Actual job still live and enough fixed time remains','Genuine independent review then separate root consumption',
            'Later closing same-private-census/source/runtime/currentness and terminal artifact/log receipt'])
    return result

def match_terminal_log(files,raw):
    need(set(files)==set(NAMES) and type(raw) is bytes and len(raw)<=16*1024**2,'TERMINAL_LOG_INPUT_BOUND')
    _,_,_,modules,_,_=verified();utility=modules['host_utility.py'];expected=utility.transport_lines(files)
    found={};rows=[];encoded=[]
    for number,line in enumerate(raw.decode('utf-8-sig').splitlines(),1):
        match=re.fullmatch(r'(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d+Z) (DG16_LINUX_HOST_JSON .*)',line)
        if not match:continue
        envelope=strict(match.group(2)[len(utility.PREFIX):]);name=envelope.get('name')
        need(set(envelope)=={'name','bytes','sha256','utf8_json'} and name in NAMES and name not in found,'TERMINAL_LOG_POPULATION')
        value=envelope['utf8_json'].encode();need(value==files[name] and desc(value)=={k:envelope[k] for k in ('bytes','sha256')},'TERMINAL_ARTIFACT_LOG_MISMATCH')
        canonical=utility.PREFIX+json.dumps(envelope,ensure_ascii=True,separators=(',',':'))
        need(match.group(2)==canonical and canonical in expected,'TERMINAL_ENVELOPE_ENCODING')
        found[name]=value;encoded.append(len(canonical.encode())+2);rows.append({'name':name,'log_line':number,'timestamp':match.group(1),**desc(value)})
    need(set(found)==set(NAMES) and max(encoded)<=262144 and sum(encoded)<=1048576,'TERMINAL_COMPLETE_LOG_REQUIRED')
    return {'schema':'dg16.terminal-artifact-log-byte-join.v1','authority':'NONE','log':desc(raw),'members':rows,
            'all_seven_exact':True,'encoded_bytes_including_CRLF':sum(encoded),'currentness_or_award':False}

def diagnostic_request(files,result):
    # Public validation runs in this fenced process. Only this data object
    # crosses into a separately admitted private decrypt process later.
    need(result['kind']=='terminal' and type(result['terminal_log_join']) is dict
      and result['terminal_log_join'].get('all_seven_exact') is True,'PRIVATE_REQUEST_REQUIRES_COMPLETE_PUBLIC_LOG_JOIN')
    b,_,_,modules,_,_=verified();docs={name:strict(files[name]) for name in NAMES}
    failure=docs['FAILURE.json'];need(failure['present'] is True,'PRIVATE_REQUEST_REQUIRES_FAILURE')
    ctx={k:docs['RESULT.json'][k] for k in ('repository','branch','run_id','run_attempt','workflow_commit')}
    ctx.update(source_commit=b['source_commit'],source_tree=b['source_tree'],
      workflow_path='.github/workflows/dg16-r5-full-g2.yml',job_name='full-registry-raw-pair')
    parent,u=modules['run.py'],modules['host_utility.py']
    protected=parent.load_protected(u).validate_public(docs['PROBE.json'],failure,ctx,u)
    need(protected['retention'] is not None and protected['retention']['status']=='ENCRYPTED_LOCAL_NOT_PROVIDER_RECEIVED',
      'PRIVATE_REQUEST_ENCRYPTED_COPY_NOT_READY')
    value=dict(schema='dg16.protected-full-private-diagnostic-request.v1',authority='NONE',context=ctx,
      public_receiver_binding_sha256=BINDING_SHA,public_archive=result['metadata']['archive'],
      public_receiving=desc(encode(result)),terminal_log_join=result['terminal_log_join'],
      failure_projection=failure['capture_observation'],protected_receipt=failure['protected_streams'],
      protected_capability=docs['PROBE.json']['protected_capability'],private_key_or_body_present=False,original_acceptance=False)
    need(len(encode(value))<=65536,'PRIVATE_REQUEST_BOUND');return value

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--archive',type=Path,required=True);parser.add_argument('--kind',choices=['live','terminal'],required=True)
    parser.add_argument('--run-id',required=True);parser.add_argument('--workflow-commit',required=True);parser.add_argument('--metadata',type=Path,required=True)
    parser.add_argument('--terminal-log',type=Path);parser.add_argument('--prepared',type=Path);parser.add_argument('--private-diagnostic-request',type=Path);args=parser.parse_args()
    raw=acquire(args.archive,400000);files=decode_zip(raw,args.kind)
    metadata=strict(acquire(args.metadata,262144));result=inspect(files,args.kind,run_id=args.run_id,workflow_commit=args.workflow_commit,metadata=metadata,archive=desc(raw))
    if args.terminal_log:
        need(args.kind=='terminal','NO_LIVE_LOG_SUBSTITUTION');result['terminal_log_join']=match_terminal_log(files,acquire(args.terminal_log,16*1024**2))
    if args.prepared:
        target=args.prepared.absolute();need(target.parent.resolve(strict=True)==target.parent and
            target.is_relative_to(RECEIVER_OUT) and not os.path.lexists(target),'PREPARED_OUTPUT_SCOPE')
        target.mkdir(mode=0o700)
        for name,body in files.items():
            path=target/name;path.parent.mkdir(mode=0o700,exist_ok=True);path.write_bytes(body)
    if args.private_diagnostic_request:
        target=args.private_diagnostic_request.absolute()
        need(target.name=='PRIVATE_DIAGNOSTIC_REQUEST.json' and target.parent.resolve(strict=True)==target.parent
          and target.is_relative_to(RECEIVER_OUT) and not os.path.lexists(target),'PRIVATE_REQUEST_OUTPUT_SCOPE')
        body=encode(diagnostic_request(files,result))
        with os.fdopen(os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600),'wb') as stream:
            stream.write(body);stream.flush();os.fsync(stream.fileno())
        need(acquire(target,65536)==body,'PRIVATE_REQUEST_READBACK')
    print(encode(result).decode(),end='')
if __name__=='__main__':main()
