# Bounded public source-provenance recovery addendum

## Result

**PARTIAL_EXACT_PROVENANCE_RECOVERED.** Two of the eight requested byte-recovery predicates are now satisfied: the complete `pipeline` source body and the outer manifest. Six complete source bodies remain unmatched within the published evidence searched. The addendum's data verifier completed **432 checks with zero failures**; passing those checks does not mean the six negative recovery predicates became positive.

The prior public-probe receiving packet remains unchanged. This is a separate data-provenance addendum in a new sibling directory. No source body was regenerated, reconstructed from a projection, edited to fit a digest, imported, or executed. No original or private input, sender, control, consumer, protected operation, or hosted rerun was invoked. Authority is **NONE**; Root remains the sole integration and acceptance writer.

## Exact recovered bytes

| Recovered target | Bytes | SHA-256 |
|---|---:|---|
| Complete `pipeline` source | 15,948 | `b69dbb0fe4ce1ed846d9cde9b1fc0f1d01c4d72dfc26363976640a147b7f936a` |
| Outer `REVIEW_MANIFEST.json` | 39,999 | `d157fa4d4c548ae4e01bbc16ce25eec3aad2ed269525787c9da55ac35a227e8d` |

The pipeline's descriptor is the exact `pipeline.source_bytes` / `pipeline.source_sha256` pair in the published `PURE_SOURCE_PLAN.json`. Its thirteen selected function ASTs match the retained projection and the plan's function digests. Selecting those thirteen declarations from the actual full source also reproduces the complete projection AST, in order. No source generation was needed to establish this correspondence.

Two public locations independently supply the same pipeline bytes:

1. Checkpoint 06 archive member `g132-root-path/outer-binding-v1/review-packet-outer-binding-v1/source-inputs/interface-baseline/root-final-operators-01/root_pipeline_inputs_v2.py`.
2. Public operator commit `d76c1e9c22fd816fbc6ddcac0080625b8f087d23`, path `handoff/fable-local-support-20261115/dg16-g132-owner-local/public-operator/root-final-operators-01/root_pipeline_inputs_v2.py`, Git blob `8aa79af4ab031f192906a1c9c91f7e42570a73f5`.

The recovered full pipeline retains a literal historical `BASE` directory. Recovery does not make that old installation current or authorize executing this complete original module. The published current interface instead selects the bounded pipeline projection and explicitly supplies its current work-root binding.

The outer manifest was recovered from checkpoint 06 member `g132-root-path/outer-binding-v1/review-packet-outer-binding-v1/REVIEW_MANIFEST.json`. Its exact digest is the `outer_manifest_sha256` reference in the published `SOURCE_INDEX.json`. That index did not advertise a byte count; the independently pinned public archive manifest supplies the exact **39,999-byte** count, which matches the recovered body. Its 166-member source-review inventory is a distinct historical object, not the current probe's 166-file Git addition set and not the unavailable 607-member packet.

The outer manifest explicitly retains `authority: NONE`, `source_adopted: false`, `runtime_admission_issued: false`, `original_acceptance: false`, and `old_G132: UNKNOWN_NO_REPLAY`. Recovering it does not adopt its historical review claims or revive an operation.

## Publication and archive provenance

The source archive was reconstructed from eight exact published parts under `handoff/pro-executor-results-20261115/continuing-execution-20261118-06/` at commit `6d9e145e2f2df5a0a8a150c85a4f3e2afd918d27`, tree `9b80db50562b54091c5c65414f55c9cb55981c97`.

The reconstructed `g132-reviewed-outer-source-and-receiving.zip` is **2,940,346 bytes**, SHA-256 `2ad1bb517438f2287bd0c9c85e12ea227cd0ab7da94c4229b6ffa97c197dd332`, with **304 ZIP members**: 303 manifested members and its public archive manifest. Every part's length, SHA-256, Git blob identity, and path binding was checked. The exact recovered members were read from those actual bytes with CRC verification. The three supporting references retained in this addendum also match both the public archive manifest and the recovered outer manifest.

Fresh connected GitHub readback confirmed the results-base commit/tree and original operator commit/tree. The latter has tree `b2c3237e05ff76207218ec6ecd7df85591232efa` and parent `95f03a3fe90e7d7cf45bff19049aac1183994aba`. The addendum retains fifteen raw Git objects binding thirteen exact published paths. GitHub reports the commits as unsigned; these are verified Git identities and provider readbacks, not signed-commit attestations.

The relevant public locations are the [checkpoint 06 directory](https://github.com/theislampill/IMPLEMENTAUDIT.md/tree/6d9e145e2f2df5a0a8a150c85a4f3e2afd918d27/handoff/pro-executor-results-20261115/continuing-execution-20261118-06) and [original operator commit](https://github.com/theislampill/IMPLEMENTAUDIT.md/commit/d76c1e9c22fd816fbc6ddcac0080625b8f087d23). Detailed acquisition, member, path, and digest records are retained locally in the addendum.

## Six unresolved exact descriptors

The exact descriptor owner is the published `g132-current-pro-public-probe-v1/bundle/installation/PURE_SOURCE_PLAN.json`; an exact copy is retained at `reference/PURE_SOURCE_PLAN.json`. The plan advertises each complete source's byte count and SHA-256, but **does not advertise a complete-source filename**. The JSON pointers below identify the descriptor precisely. No missing filename is invented.

| Descriptor pointer | Advertised complete-body bytes | Advertised complete-body SHA-256 | Retained projection path |
|---|---:|---|---|
| `/g3` | 161,682 | `22b822e4aca7957b9ed378b11bd76fa2b59ca147115afeeda7d6186479c05f57` | `reference/pure/g3.py` |
| `/host_tools` | 30,636 | `217bb744b5f814cfd8f9b986f707ce68f94fc68ddcbd9fc9fd950d970bdb7858` | `reference/pure/host_tools.py` |
| `/issuer` | 8,932 | `609b0ec3b77a0e1d07bc105d20675518cc07f653b222c78e045c61ca547634cf` | `reference/pure/issuer.py` |
| `/late` | 10,458 | `107e4f5ee9a9e298b790560097844ea244f7aee3f87a90cc5c54417a63f350f5` | `reference/pure/late.py` |
| `/provider` | 19,450 | `94568ba26edb256fd2cbca5aa925e3f0dc53aab6b6825a81e21071824548996c` | `reference/pure/provider.py` |
| `/receiver` | 71,725 | `2ff45c81d701449a12229c839fab72ca249363d7222a56b1d7bf74e22a2fbe3d` | `reference/pure/receiver.py` |

### Bounded negative-search evidence

The search inspected the published checkpoint 04, 05, and 06 archive manifests, their source member metadata, and actual public Python source candidates at the exact target byte counts. It also inspected the public Git file census at results base `6d9e145…` and original operator commit `d76c1e9…`, reading only matching-size Python source candidates outside private/input-body paths. The preceding sealed receiving had already identified the seven absent full bodies within the current probe's 166 additions.

| Search surface | Exact source archive identity or scope | Result |
|---|---|---|
| Checkpoint 04 | 128,490 bytes; SHA-256 `a97e37cf3eab5ab43e4564343ea3fd286f316f2de9b75a2cbb71b595a359637b`; 48 archive members | No complete target-body match |
| Checkpoint 05 | 1,855,031 bytes; SHA-256 `8ebd8d002a6d6191c422fee115e1efeddcf3ec3cc033bd09552fa5bbe54fbd19`; 242 archive members | No complete target-body match |
| Checkpoint 06 | 2,940,346 bytes; SHA-256 `2ad1bb517438f2287bd0c9c85e12ea227cd0ab7da94c4229b6ffa97c197dd332`; 304 members | Exact pipeline and outer-manifest matches; no other target match |
| Results-base Git tree | `6d9e145…`; 3,500 file entries | No matching-size direct Python source candidates |
| Original operator Git tree | `d76c1e9…`; 2,249 file entries | Exact pipeline; same-size, digest-mismatched issuer |

These are bounded negative results for the named publications and selection criteria, not a universal assertion that the other six bodies do not exist elsewhere. No blind search was expanded beyond those relevant public sources, and no private or original-input body was read.

### The issuer near match is not a recovered target

The original operator's `root-recipient-issuer-01/issue_recipient_inputs.py` is **8,932 bytes**, but its actual SHA-256 is `d9e417170ee95fd124fcf27074c8850b4b49dcecae5a429a5189d0fc819af80a`, not the target `609b0ec3…`. It is retained under `reference/nonmatching_d76_issue_recipient_inputs.py` solely as an explicitly identified nonmatching reference.

Its three selected function ASTs—`require`, `publication_join`, and `derive`—match the published issuer projection. That is a positive function-correspondence result only. It does not replace the missing complete-body identity. In particular, the projection's selected host constants identify prospective commit `3f6003cce29d077ad66497c30788a38af081976b` and tree `bc3f8f1a10cbea041a6bf066acda113f3252360b`; the historical source has different host constants. No transformed complete body was emitted or treated as recovered evidence.

## Meaning for executable dependencies

**For the published `CurrentSources` route, all six missing complete bodies limit independent derivation provenance; none is a direct missing-file dependency of that route.** This classification is derived from the actual published runtime source, not inferred from the existence of hashes alone.

`CurrentSources.module()` reads `installation/pure/<name>.py` and validates `projection_bytes` and `projection_sha256`. It does not read the plan's `source_bytes` or `source_sha256`. The six full-body digests occur only in the plan within the inspected textual public additions. The exact projection bodies are retained and their function digests verify. They are therefore available to the loader even while independent comparison to their advertised complete source remains unavailable.

| Missing full body | Published current execution dependency | Consequence of this particular absence |
|---|---|---|
| `g3` | `self.G` loads `pure/g3.py`; its supplied `current_original_scope_body` callback reads exact retained scope bytes | Complete-source derivation comparison is unavailable. The missing body itself is not read by the route; the earlier public probe already used the retained scope/M4 projection. |
| `host_tools` | `self.H` loads `pure/host_tools.py`, with `P`, `V`, `_profile_policy`, and `local_artifact_chronology` supplied by the runtime | Complete-source derivation comparison is unavailable. Actual observation/adoption receiving separately requires the correct current public evidence and context. |
| `issuer` | The retained projection performs `publication_join` and unissued sender-requirements derivation | The full-body target is unreceived, although three function correspondences are independently available. Actual provider publication/context joins remain separate runtime requirements. |
| `late` | `pure/late.py` supplies transported public host views and late assembly, with `current_dispatcher_derive` supplied explicitly | Complete-source derivation comparison is unavailable. Complete late assembly additionally needs selected input bodies and current admissions; it was not invoked here. |
| `provider` | `self.V` loads `pure/provider.py`, with policy and chronology callbacks | Complete-source derivation comparison is unavailable. Actual complete model-side tool-return bytes remain a caller dependency. |
| `receiver` | `self.receiver` loads `pure/receiver.py`; public receive/requirements/control methods use the current source object and receiving state | Complete-source derivation comparison is unavailable. Exact phase/context/previous-receiving joins are still enforced by the retained code. |

This is not a declaration that any original operator is presently executable or admissible. A requirement for complete derivation evidence may still prevent review or source adoption; this receiver cannot waive that requirement. The distinction is that these six absent complete files are not the files read by the published projection loader.

Separate concrete prerequisites for further ordinary G132 interface work remain:

- An actual current installation with the canonical paths, owner/mode/no-alias checks, exact source population, and source-index hash required by `CurrentSources`. The recovered files are source evidence, not a newly admitted installation. The historical complete pipeline's old directory is not a valid substitute.
- A coherent actual provider/context binding for the selected operation. The currently selected prospective `3f6003…` identity remains `UNISSUED` and is explicitly recorded as not provider-published/adopted. The successful public probe's `6d8e604…` context is deliberately refused by the original-context gate.
- Explicit live model-side tool objects and Root callbacks for adapter paths. The published JavaScript adapters require actual capabilities such as process tools, admission/currentness, and no-replay checks. Source possession does not create those capabilities or make GitHub tools callable from Python.
- Fresh review of the exact ordinary interface selection where required. Recovery of this historical 166-member outer manifest does not recover the unavailable later 607-member review packet.
- For any later original late assembly or sender stage, the separately required original input bodies, actual sender custody/identity, issuer decisions, current deadlines, and receiving joins. None was read or supplied in this task, and none is an appropriate substitute target for ordinary public provenance recovery.

The current retained receiver source visibly passes the four retained M4 bodies into the final request, decision, and independent-receipt joins and constructs the v3 final-decision schema. That is a source observation, not a new execution or acceptance of the final path. The four Pro adapter source files likewise remain source evidence; this addendum executes no adapter or sender.

## Historical I01–I06 recovered from exact published bytes

The outer manifest pins `INTERFACE_REQUIREMENTS.json` at **5,637 bytes**, SHA-256 `994f52d463839818d377764023987d4201e435118e72d8ab9b21eb32208ae6b6`, and pins the accompanying `DEPENDENCY_REPORT.md`. The census supplies the I01–I06 IDs and exact owners. It has no separate `title` field; the matching numbered subsection titles below are quoted **verbatim** from that same manifest-bound dependency report.

| ID | Numbered dependency-report title, verbatim | Historical owner described by the census |
|---|---|---|
| I01 | “Installation binding.” | Original pipeline, recipient issuer, and event-helper installation paths |
| I02 | “A statically contradictory historical host binding.” | Issuer host commit/tree and receiver expected-tree conjunction |
| I03 | “Receiver phase and loading.” | Historical receiver/phase pins and full-module loading |
| I04 | “Actual final M4 call sites.” | Receiver final request/decision/receipt calls and decision schema |
| I05 | “Sender transport.” | Original Windows/WSL dispatcher and the Pro Linux adaptation seam |
| I06 | “Live boundaries after source work.” | Actual recipient, tool adoption, sender, provider, and stage-specific control prerequisites |

`DEPENDENCY_CLASSIFICATION.json` additionally retains the exact census fact, owner, and required-source-work text for each item. These are historical findings recovered from their identified publication. Their recovery does not determine current item closure. The earlier sealed report's lack-of-mapping statement was scoped to the 166 public-probe additions; this newly examined archive now supplies the mapping without changing that earlier packet.

## Verification, immutability, and handoff

`verify_addendum.py` verifies the eight target descriptors, exact recovered bodies, projection hashes, pipeline AST reproduction, issuer negative/full-body distinction, published Git path proof, actual checkpoint archive bytes, historical census joins, and runtime dependency classification. It parses source as data only. It does not import any received source and does not rerun the prior 898-check receiver or any original test/operation.

The three checkpoint archives and the new bare Git acquisition store are retained as acquisition inputs outside the small addendum ZIP. To rerun verification after relocation, provide the archive directory with `--archives`; the exact expected filenames and hashes are recorded. The delivery includes the recovered exact bodies, supporting public reference bytes, hash/path/AST records, report, result, verifier, manifest, and seal.

The prior receiving seal remains SHA-256 `b738759e89a6f1ac185396d78f061334ced1724ca2605a59fc950fb1b628de97`; its ZIP remains SHA-256 `c7074f699f714eabe39331b24fdbd15260dafc1ca80e3872ba5051e74aedd8f2`. An explicit final readback records their unchanged identities.

The original operations at `625f310d04cb5b5a1f02901cfdcf3c3815730a5e` and `301aeecde08ba6f169bc3cd837eae6f6ad068219` remain **UNKNOWN_NO_REPLAY**. Original G1/G3 awards, original M2, native model identity, issuer/admission grants, protected execution, and audit closure remain outside this result. Root may receive the two exact byte-recovery results and the narrower six-body provenance classification into its current audit state; no acceptance or lifecycle transition is made by this receiver.
