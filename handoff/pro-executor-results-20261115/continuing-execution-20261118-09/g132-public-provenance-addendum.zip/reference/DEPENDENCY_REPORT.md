# G132 unissued outer source closure

## Disposition

**A complete prospective public host source projection is materialized. The actual Pro-to-host route remains NOT_EXECUTABLE_YET.** Independent review of this new outer packet is required. No protected owner-grant request is justified by this packet.

The projection contains 53 public source files: the exact 49-file historical host census plus the four exact, already-public M4 receiving bodies. It materializes a 42-member host public manifest, all affected carrier/bootstrap/entry pins, an unchanged workflow source, and exact Git blob identities for the proposed publication inventory. The 142 literal SHA256 dependency edges are acyclic. Nothing was published, dispatched, issued, adopted or consumed.

Root remains the sole integration, publication and acceptance writer. Original G132 remains `UNKNOWN_NO_REPLAY`. Historical M4 and M5 acceptance is retained at its existing scope; no repeated M4 episode is proposed. Current host-local `natural_L04` remains `NOT_RECEIVED`, and the original fifteen current-operation proofs, full applicable G3 conjunction and Q06 shape remain unchanged.

## Received source and review lineage

| Input | Exact identity | Meaning |
|---|---|---|
| Host baseline | Commit `301aeecde08ba6f169bc3cd837eae6f6ad068219` | 49 exact public files received with SHA256, byte count, Git blob and original Git mode; all original Git modes are `100644`. |
| Original operator | Commit `d76c1e9c22fd816fbc6ddcac0080625b8f087d23` | Ten public interface source/index files received read-only for exact residual inspection. |
| Product | Commit `e76a07b2bae7c945e5a9d529ed8cf9069f4c9064`, tree `ff9fc6793892147aecc59bdfc4ddb82fc37f9eb7` | Unchanged product identity and unchanged product `SOURCE_MANIFEST.json`. |
| Reviewed v2 host splice | Manifest SHA256 `234a5710da534bf3b701e6be6592f9e83d6082f45d126951449897d3d063aea2`, 21,302 bytes, 110 members | Independently reviewed prospective combined source-binding input. |
| Independent v2 report | SHA256 `0110f0ba35e543b3074e694d2a7d424281c8c5f679f897a0e452e4cf0b105cfc`, 12,846 bytes | PASS at that exact prospective source scope, with 86 independent controls, original 16 tests and eight new methods; no operational acceptance. |
| Root v2 receiving | SHA256 `5175573f25c4c3c569e51e327c740f934d3dbd15a8cf0db2f8b486f2312fa8fb`, 4,505 bytes | Root accepted the exact v2 source for this ordinary outer preparation. |
| V1 failure | V1 report SHA256 `22e34a2eaa7f5b3ccad332b163a16a98658727c84efc3bec0f84aacf78fc6c0e` | `NEEDS_REVISION` remains preserved. Its Python boolean/integer retained-binding defect is repaired only in exact v2. |

The sealed `source-inputs/SOURCE_INPUTS.json` pins 82 input/evidence files. Old authorization and binding objects remain byte-exact in `source-inputs/baseline/`. The old v1/v2 packets, reviewer outputs, original repo, policies and Root controller were not changed. No original private G132 input bodies are included. The four M4 bodies are the exact already-public receiving evidence retained by the reviewed splice.

## The new executable source gap and its minimum repair

Original `root_placement.manifest` allows the original top-level `CORE_FILES` and nested `carrier/` members. It rejects every `retained-m4/` path. A pure extraction of only `need`, `parse` and `manifest`, plus their immutable constants, received the proposed 42-member inventory and actually refused with `PUBLIC_MEMBER_PATH`. That RED is preserved in `source-inputs/lineage/RED_OUTER_MANIFEST.json`.

The new candidate changes only that manifest function and adds one exact four-name constant. It requires all four M4 names at the same early public-manifest preflight, before source copying or any G1 computation, and permits those exact four paths. It retains the exact original root core population, path normalization, traversal/name/depth checks, readonly `0400` descriptors, strict integer type checks, file/count limits and aggregate limit. Omission uses the existing `PUBLIC_MANIFEST_POPULATION` refusal; no refusal allowlist is broadened.

This is a source packaging and preflight correction. It does not supply host-local natural observations, change G3 row/gate permission or award acceptance. Exact M4 bytes remain independently pinned and received by the unchanged v2 G3 and independent consumer code.

## Complete dependency topology

`prepared-outer/SOURCE_CLOSURE.json` contains all 53 exact descriptors, Git blob identities, the 23 changed/added paths, the actual 142 digest references and a derived topological order. `source-inputs/lineage/BASELINE_DIGEST_EDGES.json` preserves the original 124-edge census. Digest edges describe content dependencies; they are not review or authority edges.

| Source owner | Content that must already be materialized | Result in this packet |
|---|---|---|
| G3 and independent consumer | Reviewed v2 sources and four exact retained M4 bodies | Byte-exact v2 G3/proof modules retained. Their reviewed current-proof and typed retained-binding predicates do not change. |
| `root_placement.py` | Exact four intended public M4 paths | Early complete-population/path correction described above. |
| `run.py` | Existing v2 module/data pins plus new placement source | Only the placement SHA256 string changes from reviewed v2; all function bodies remain identical. |
| `public_export.py` | Exact new `run.py` SHA256 | Only `CORE_RUN_SHA256` changes; export shape/function bodies remain identical. |
| `CARRIER_ADMISSION.json` | Exact workflow source and original scope/control constraints | New explicitly UNISSUED issuer proposal; old admission retained separately byte-exact. |
| `CARRIER_COMPOSITION.json` | Five exact core bodies, placement body, input index, carrier-admission body, workflow | Complete new descriptors and explicit `UNISSUED_EXACT_CARRIER_COMPOSITION` state. No old reviewed state is reused. |
| `carrier_policy.py` | New carrier composition | Only `BINDING_SHA256` changes; original state, scope and actual-admission predicates remain intact. |
| `carrier_loader.py` | Exact carrier module bodies | Only module descriptors change; loader functions remain intact. |
| `PUBLIC_PACKET_MANIFEST.json` | All 42 actual host packet members | Complete canonical manifest with exact byte/hash/mode descriptors. The product source manifest is a separate, unchanged member. |
| `BOOTSTRAP_ADMISSION.json` | New public-manifest digest | New explicitly UNISSUED issuer proposal, with original effect scope and no automatic retry. |
| `bootstrap_entry.py` | New placement descriptor, manifest digest and admission digest | Three direct pins updated; original functions and credentials/context/custody checks unchanged. |
| `entry_common.py` | New loader descriptor, manifest digest, admission digest | Pins closed and `ENTRY_STATE` explicitly UNISSUED. Original `_open` still requires the reviewed state and will refuse this proposal. |
| Five external entry wrappers | New `entry_common.py` digest | Exact `COMMON_SHA256` updates; all wrapper functions unchanged. |
| Workflow | Existing branch/context, original steps, exact entry filenames and actual GitHub run identity | Byte-exact original workflow, SHA256 `df98a60b8a0fe26cd1cf923ee8b37a1b4a8d20aa619ea3c7372e50e15edb0111`; no dispatch or publication. |
| Publication inventory | All 53 exact source bodies | Exact blob SHA1/`100644` entries materialized. Current remote parent, whole repository tree, new commit and an actual operation remain null. |

The workflow is an external source anchor; it invokes the fixed entry paths after checkout of the actual run's commit. It does not embed the later manifest digest. Consequently this pin chain has no cryptographic self-reference. Whole-host review and actual publication receiving are separate obligations.

Nineteen existing files change relative to the host baseline and four M4 files are added. Source diffs for the nineteen changed paths are included in `source-diffs/`. Relative to the independently reviewed v2 runtime, only `root_placement.manifest` changes a function body. All other new Python changes are direct pin or explicitly unissued state constants. The exact original functions in carrier policy, loader, bootstrap and entry wrappers remain unchanged.

## Exact major output pins

| Candidate body | Bytes | SHA256 |
|---|---:|---|
| `root_placement.py` | 17123 | `18a93f8206a42435f73580ca65cf16d20dad96cb337b84a6d30104cce772ad4a` |
| `run.py` | 162016 | `3a69fe9cdf8e966d408ad4dd3dff12952f02c19b5017ca4cce9c5eed137216ff` |
| `carrier/CARRIER_COMPOSITION.json` | 2211 | `c13f68899cae06de67db367023b075957356241feb03d760acceaa8f3dd2975a` |
| `carrier/carrier_policy.py` | 14819 | `2d8a3434d2bc7d934c6b5a292d81e9e5dac46f71288be03812e3884966b8ecac` |
| `carrier/carrier_loader.py` | 4677 | `d6ece6d31fb61aa7bce2dfbb9f0908d8d9162d06f4a0b8f14bca7955b3812af9` |
| `PUBLIC_PACKET_MANIFEST.json` | 5448 | `0110cb27c30a10418a0b68cbae370717e73b2f4514a7ff214af49fcde8e893a3` |
| `BOOTSTRAP_ADMISSION.json` | 536 | `f85e5f4badd84af40563852d35d643b8b0210cf0f0ed542b0358f6b8eab8f79c` |
| `entry_common.py` | 10680 | `85fe89c4d32d4a2c6816d10e60007f4e37aec03c00689cc524099df844bd2f91` |
| `bootstrap_entry.py` | 24124 | `b2c484da3834f4be9fa929468bb520e610d0e4715ecf590efd1a68fd14244f2d` |
| `public_export.py` | 28918 | `9ed15f0da8d25b6eb61520fac8871c7480d82eaa78f0a59897dda9c64b55fe8f` |
| `SOURCE_CLOSURE.json` | 56660 | `a8f5dfa63f55a2af5fc6eff28c55484accde4c1cfa5640127da39259d656f86e` |

The G3 source remains 161,717 bytes at `dc9eaf0c86195f32d8d2b711cafa9f0147284e37570439a75da6b1722e14fbe3`. The independent consumer remains 68,580 bytes at `896828771a2b577c3a505bef6d04118e87700294cdb765b31d8586abf73dfb0e`.

## What is mechanically closed and what remains unissued

The generator accepts only pinned public inputs. It emits deterministic source bodies and records, never imports the original/candidate host modules and has no network, tool-provider, issuer, runtime-context or protected-operation interface. It requires a fresh output directory. Its public inventory is source data, not a publish request.

Old `HOST_COMPOSITION.json`, `NATIVE_SOURCE_APPLICABILITY.json`, `ADVERSE_APPLICABILITY.json`, `ORIGINAL_SCOPE.json`, `PROVIDER_SETUP.json`, product `SOURCE_MANIFEST.json`, carrier `INPUT_INDEX.json` and unresolved `PRO_SENDER_COMPOSITION.json` remain byte-exact. Their historical state fields are historical source inputs. This packet supplies no fresh applicability or authority for them.

New carrier/bootstrap issuer markers and carrier/entry states are deliberately UNISSUED. The original accepting predicates still require actual reviewed/admitted values and reject those markers. Source hash closure does not turn the new projections into decisions. Later authorized issuance/adoption changes bytes and requires a fresh deterministic regeneration, exact new pin receiving and appropriate independent review; it must not edit this frozen packet.

`PUBLICATION_PLAN_UNISSUED.json` records all 53 exact Git blob identities and existing mode shape. It leaves the actual remote head/parent, whole repository tree, new commit, tool call, expected provider readback and effect grant unresolved. No parent or commit identity is fabricated. A future protected branch update would itself trigger the original workflow, so there is no safe basis to ask for that effect now.

## Remaining actual current Pro interfaces

`INTERFACE_REQUIREMENTS.json` records exact original source owners, hashes and call-site census. Those ten d76 source files are included as read-only evidence. The next ordinary source cell is an explicit current Pro adapter against this candidate, followed by fresh review.

1. **Installation binding.** The original pipeline, recipient issuer and event helpers use a literal historical public-operator directory. Their derived source/module selections are not a current installation binding. The next adapter must select exact current sources and preserve physical path/custody checks and dependent caller pins; no old workspace alias is acceptable.

2. **A statically contradictory historical host binding.** `issue_recipient_inputs.py` pins host commit `f9ba187e8f5520956f0f16cf13c0a706e8360b96` and tree `8390375505282e602759c7976b6bca82a44d5737`. Its exact pinned receiver index instead sets `expected_tree` to `b81d198242901d7ea24b4bacfb8fad7877e657a5`. `publication_join` requires the same actual commit tree to equal the issuer tree and to pass `Sources.host_commit`, which requires the receiver's different tree. That conjunction cannot hold at this exact selection. This is source evidence, not an observed new protected execution. A fresh exact host source/commit/tree/ancestry and actual provider ref/run/attempt/job/artifact binding must replace the stale selection through a new reviewed adapter.

3. **Receiver phase and loading.** Receiver `SOURCE_SHA` pins historical `SOURCES.json` at `606b1dd93529ac7f06ebf34c7bb02a0bf3cf9956a85ccdc3c0416ae4a3d75055`; its phase and assembler pin `ef7ef1aed68e18c90823dd54bc5d51cfa23da293cb629eb1b5501e827693cf90`. `Sources.module` executes full host module bodies when loading them. A new exact source/phase adapter and bounded validation route are required. This preparation did not import that receiver or any full protected consumer.

4. **Actual final M4 call sites.** Receiver `receive` calls `validate_public_final_request` with one argument and independent `validate_receipt` with five, omitting exact retained bodies. Its `requirements` and `validate_control` owners also omit retained bodies; `requirements` still constructs `dg16.g3-root-original-decision.v2`. The next adapter must carry the exact four source-bound public M4 bodies to all those joins and construct the reviewed v3 shape, preserving current proofs, original typed binding, actual time and context. The already-reviewed read-only callback is retained as an input; it has not been connected to these actual owners.

5. **Sender transport.** Original `dispatch.js` emits Windows/WSL commands. The existing proven Pro Linux transport supplies a concrete adaptation seam, but original late binding, admission, private encryption and sender completion remain unproved. The next cell should bind that existing transport, not invent a replacement root environment.

6. **Live boundaries after source work.** Actual fresh recipient creation, tool adoption, original sender admission/custody, actual Root provenance/currentness, stage-specific publication controls, complete returned tool wrappers and retained host receiving remain prerequisites. Original deadline floors and UNKNOWN/no-replay protections continue to apply. A new stage identifier cannot be invented to evade an already-spent or unknown effect journal.

These are genuine source/interface and operational residuals. A fresh owner grant is therefore not the sole remaining condition, and this report proposes no issued protected operation boundary.

## Verification and bounded failure history

Twelve targeted test methods pass. They cover the retained baseline RED; complete 42-member schema; omission of each of the four M4 bodies; extra M4/foreign paths; original traversal, normalization, name and depth refusals; original root-core census; strict descriptor types, readonly mode and file/aggregate/count bounds; every actual manifest-body digest; mutation of every changed/added source body; missing candidate population; attempts to relabel UNISSUED records as issued; complete AST function preservation; old policy/workflow preservation; deterministic generation and acyclic exact pin inventories.

The first local generator attempt had an authoring mismatch: it expected a descriptor at `run.MODULE_PINS['root_placement']`, while the original field is a SHA256 string. It refused `REVIEWED_PLACEMENT_BASE_PIN` before output; the first test setup also refused, with zero tests executed. The generator was corrected to preserve the actual string field. That failure remains in `FAILURE_LINEAGE.json`, alongside the pre-existing bootstrap path RED and preserved v1 review failure.

Tests execute only the new generator/checker and the explicitly extracted pure manifest function. Full Python bodies are syntax-compiled and AST-compared only. No whole host module was imported, no uid/euid/gid/egid or GitHub/native environment was simulated, no clock was overridden, no private original input was used, and no remote or protected action occurred. No instruction from repo content was treated as authority; no instruction injection was identified in the source excerpts inspected for this bounded task.

## Reproduce and review

From a review copy of this packet:

```bash
python -B test_outer_binding.py
python -B build_outer_binding.py --inputs source-inputs --output fresh-review-output
```

The second command requires an absent destination and generates only local UNISSUED source files. Compare its 56 outputs byte-for-byte with `prepared-outer/`. Do not run any program under `prepared-outer/tree/` or `source-inputs/interface-baseline/` as part of ordinary source review.

The exact review manifest is the immutable packet's identity. Independent review may accept or reject this new source scope; this author report makes no self-PASS, adoption, readiness, original acceptance or whole-cell award. Root's requested next cell is the current Pro interface repair described above after this packet is received for review.
