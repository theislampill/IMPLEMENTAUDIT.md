"""Bounded data-only provenance verifier; never executes recovered source.

The published checkpoint archives are acquisition inputs, excluded from the
small delivery ZIP. Supply their retained acquisition directory with --archives
when verifying a relocated copy. No network or original operator is invoked.
"""
from pathlib import Path, PurePosixPath
import argparse
import ast
import datetime
import hashlib
import json
import re
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parent
checks = []


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def desc(raw):
    return {'bytes': len(raw), 'sha256': sha(raw)}


def oid(kind, raw):
    return hashlib.sha1(kind.encode() + b' ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def read_json(path):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('duplicate JSON key')
            result[key] = value
        return result
    return json.loads(path.read_bytes(), object_pairs_hook=pairs)


def need(value, name, detail=None):
    checks.append({'check': name, 'verified': bool(value), 'detail': detail})
    if not value:
        raise ValueError(name)


def functions(raw):
    return {n.name: n for n in ast.parse(raw).body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}


def tree_rows(raw):
    pos = 0
    result = {}
    while pos < len(raw):
        space = raw.index(b' ', pos)
        zero = raw.index(b'\0', space)
        name = raw[space + 1:zero].decode()
        object_id = raw[zero + 1:zero + 21]
        if name in result or len(object_id) != 20 or '/' in name:
            raise ValueError('invalid Git tree')
        result[name] = {'mode': raw[pos:space].decode(), 'oid': object_id.hex()}
        pos = zero + 21
    return result


def run(archives):
    targets = read_json(ROOT / 'TARGETS.json')
    plan_raw = (ROOT / 'reference/PURE_SOURCE_PLAN.json').read_bytes()
    plan = read_json(ROOT / 'reference/PURE_SOURCE_PLAN.json')
    index = read_json(ROOT / 'reference/SOURCE_INDEX.json')
    need(desc(plan_raw) == {'bytes': targets['pure_plan_bytes'], 'sha256': targets['pure_plan_sha256']}, 'fixed advertised plan')
    need(index['outer_manifest_sha256'] == targets['outer_manifest_sha256'], 'outer manifest descriptor owner')
    for name, target in targets['targets'].items():
        need(target['bytes'] == plan[name]['source_bytes'] and target['sha256'] == plan[name]['source_sha256'],
             'complete-source descriptor ' + name)
        projection = (ROOT / 'reference/pure' / (name + '.py')).read_bytes()
        need(desc(projection) == {'bytes': plan[name]['projection_bytes'], 'sha256': plan[name]['projection_sha256']},
             'retained projection descriptor ' + name)
        fn = functions(projection)
        need(set(fn) == set(plan[name]['functions'])
             and all(sha(ast.dump(fn[n], include_attributes=False).encode()) == h for n, h in plan[name]['functions'].items()),
             'projection function digests ' + name)

    proof = read_json(ROOT / 'PUBLISHED_GIT_PATH_PROOF.json')
    objects = {}
    for item in proof['objects']:
        body = (ROOT / item['path']).read_bytes()
        need(desc(body) == {'bytes': item['bytes'], 'sha256': item['sha256']}
             and oid(item['kind'], body) == item['oid'], 'public Git object ' + item['oid'])
        objects[item['oid']] = (item['kind'], body)
    for filename in ['PROVIDER_RESULTS_BASE_COMMIT.json', 'PROVIDER_ORIGINAL_OPERATOR_COMMIT.json']:
        provider = read_json(ROOT / filename)
        raw = objects[provider['sha']][1]
        need(raw.splitlines()[0] == ('tree ' + provider['tree']['sha']).encode()
             and [l[7:].decode() for l in raw.split(b'\n\n', 1)[0].splitlines() if l.startswith(b'parent ')]
             == [p['sha'] for p in provider['parents']], 'provider commit/tree/parent join ' + filename)
    provider_tree = read_json(ROOT / 'PROVIDER_RESULTS_BASE_TREE.json')
    need(tree_rows(objects[provider_tree['sha']][1])
         == {e['path']: {'mode': e['mode'].lstrip('0'), 'oid': e['sha']} for e in provider_tree['tree']}
         and provider_tree['truncated'] is False, 'provider results root tree')
    for item in proof['paths']:
        current = item['tree']
        for part in PurePosixPath(item['path']).parts:
            current = tree_rows(objects[current][1])[part]['oid']
        need(current == item['git_blob'], 'published path binding ' + item['path'])

    cp6 = read_json(ROOT / 'CHECKPOINT06_ARCHIVE_PROVENANCE.json')
    arc_path = archives / 'checkpoint06-g132-reviewed-outer-source-and-receiving.zip'
    arc_raw = arc_path.read_bytes()
    need(desc(arc_raw) == cp6['archive'] == {'bytes': 2940346, 'sha256': '2ad1bb517438f2287bd0c9c85e12ea227cd0ab7da94c4229b6ffa97c197dd332'},
         'actual checkpoint06 archive bytes')
    offset = 0
    for part in cp6['parts']:
        body = arc_raw[offset:offset + part['bytes']]
        offset += part['bytes']
        need(desc(body) == {'bytes': part['bytes'], 'sha256': part['sha256']}
             and oid('blob', body) == part['oid'], 'checkpoint06 published part ' + Path(part['path']).name)
        need(any(p['path'] == part['path'] and p['git_blob'] == part['oid'] for p in proof['paths']),
             'checkpoint06 part tree join ' + Path(part['path']).name)
    need(offset == len(arc_raw), 'checkpoint06 complete concatenation')
    archive_manifest = read_json(ROOT / 'CHECKPOINT06_PUBLIC_ARCHIVE_MANIFEST.json')
    prefix = 'g132-root-path/outer-binding-v1/review-packet-outer-binding-v1/'
    positives = {}
    with zipfile.ZipFile(arc_path) as archive:
        need(len(archive.infolist()) == 304 and len(archive.namelist()) == len(set(archive.namelist())), 'checkpoint06 catalog uniqueness')
        need(archive.read('PUBLIC_ARCHIVE_MANIFEST.json') == (ROOT / 'CHECKPOINT06_PUBLIC_ARCHIVE_MANIFEST.json').read_bytes(),
             'checkpoint06 exact published archive manifest')
        need(set(archive.namelist()) == set(archive_manifest['members']) | {'PUBLIC_ARCHIVE_MANIFEST.json'},
             'checkpoint06 archive/manifest name equality')
        for name, pin in archive_manifest['members'].items():
            need(archive.getinfo(name).file_size == pin['bytes'], 'checkpoint06 advertised member size ' + name)
        for target, member in [
            ('pipeline', prefix + 'source-inputs/interface-baseline/root-final-operators-01/root_pipeline_inputs_v2.py'),
            ('outer_manifest', prefix + 'REVIEW_MANIFEST.json')]:
            raw = archive.read(member)
            expected = archive_manifest['members'][member]
            extension = '.json' if target == 'outer_manifest' else '.py'
            need(raw == (ROOT / 'recovered' / (target + extension)).read_bytes()
                 and desc(raw) == {'bytes': expected['bytes'], 'sha256': expected['sha256']}, 'exact recovered checkpoint06 body ' + target)
            target_sha = targets['outer_manifest_sha256'] if target == 'outer_manifest' else targets['targets'][target]['sha256']
            need(sha(raw) == target_sha and len(raw) == (39999 if target == 'outer_manifest' else targets['targets'][target]['bytes']),
                 'exact advertised target match ' + target)
            positives[target] = {'archive_member': member, **desc(raw)}
        reference_provenance = read_json(ROOT / 'REFERENCE_SOURCE_PROVENANCE.json')
        outer = read_json(ROOT / 'recovered/outer_manifest.json')
        outer_pins = {p['path']: p for p in outer['files']}
        need(len(outer_pins) == outer['member_count'] == 166 and outer['authority'] == 'NONE'
             and outer['old_G132'] == 'UNKNOWN_NO_REPLAY' and outer['original_acceptance'] is False
             and outer['runtime_admission_issued'] is False and outer['source_adopted'] is False,
             'recovered outer manifest retains bounded unissued scope')
        for item in reference_provenance['references']:
            raw = archive.read(item['archive_member'])
            pin = outer_pins[item['outer_manifest_path']]
            need(raw == (ROOT / item['saved_path']).read_bytes()
                 and desc(raw) == item['actual'] == {'bytes': pin['bytes'], 'sha256': pin['sha256']},
                 'outer-manifest-bound reference ' + item['saved_path'])

    pipeline_raw = (ROOT / 'recovered/pipeline.py').read_bytes()
    fn = functions(pipeline_raw)
    projected_fn = functions((ROOT / 'reference/pure/pipeline.py').read_bytes())
    need(all(ast.dump(fn[n], include_attributes=False) == ast.dump(projected_fn[n], include_attributes=False)
             and sha(ast.dump(fn[n], include_attributes=False).encode()) == digest
             for n, digest in plan['pipeline']['functions'].items()), 'pipeline 13 selected function AST correspondence')
    selected = [n for n in ast.parse(pipeline_raw).body if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name in plan['pipeline']['declarations']]
    need(ast.dump(ast.Module(body=selected, type_ignores=[]), include_attributes=False)
         == ast.dump(ast.parse((ROOT / 'reference/pure/pipeline.py').read_bytes()), include_attributes=False),
         'pipeline complete selected declaration AST reproduces projection')
    pipeline_paths = [p for p in proof['paths'] if p['path'].endswith('/root_pipeline_inputs_v2.py')]
    need(len(pipeline_paths) == 1 and oid('blob', pipeline_raw) == pipeline_paths[0]['git_blob'],
         'pipeline independent direct d76 Git blob join')

    issuer_raw = (ROOT / 'reference/nonmatching_d76_issue_recipient_inputs.py').read_bytes()
    need(len(issuer_raw) == targets['targets']['issuer']['bytes'] == 8932
         and sha(issuer_raw) == 'd9e417170ee95fd124fcf27074c8850b4b49dcecae5a429a5189d0fc819af80a'
         and sha(issuer_raw) != targets['targets']['issuer']['sha256'], 'issuer same-size source is a negative full-body match')
    old_fn, new_fn = functions(issuer_raw), functions((ROOT / 'reference/pure/issuer.py').read_bytes())
    need(all(ast.dump(old_fn[n], include_attributes=False) == ast.dump(node, include_attributes=False) for n, node in new_fn.items()),
         'issuer 3 selected function AST correspondences only')
    issuer_paths = [p for p in proof['paths'] if p['path'].endswith('/issue_recipient_inputs.py')]
    need(len(issuer_paths) == 1 and oid('blob', issuer_raw) == issuer_paths[0]['git_blob'], 'negative issuer direct d76 Git blob join')

    bounded = read_json(ROOT / 'BOUNDED_SOURCE_SEARCH.json')
    for record in read_json(ROOT / 'EARLIER_ARCHIVE_PROVENANCE.json'):
        path = archives / Path(record['archive']['path']).name
        raw = path.read_bytes()
        need(desc(raw) == {k: record['archive'][k] for k in ('bytes', 'sha256')}
             and oid('blob', raw) == record['git_blob'], 'actual earlier published archive ' + record['checkpoint'])
        need(any(p['path'] == record['git_path'] and p['git_blob'] == record['git_blob'] for p in proof['paths']),
             'earlier archive Git path join ' + record['checkpoint'])
        retained = (ROOT / (record['checkpoint'].upper() + '_PUBLIC_ARCHIVE_MANIFEST.json')).read_bytes()
        if path.name.endswith('.zip'):
            with zipfile.ZipFile(path) as archive:
                need(archive.read('PUBLIC_ARCHIVE_MANIFEST.json') == retained, 'earlier ZIP manifest ' + record['checkpoint'])
        else:
            with tarfile.open(path, 'r:gz') as archive:
                need(archive.extractfile('PUBLIC_ARCHIVE_MANIFEST.json').read() == retained, 'earlier TAR manifest ' + record['checkpoint'])
    manifest_hashes = {}
    for label in ['CHECKPOINT04', 'CHECKPOINT05', 'CHECKPOINT06']:
        manifest = read_json(ROOT / (label + '_PUBLIC_ARCHIVE_MANIFEST.json'))
        rows = manifest['members']
        manifest_hashes[label] = {v['sha256'] for v in rows.values()}
    unresolved = [n for n in targets['targets'] if n != 'pipeline']
    for name in unresolved:
        expected = targets['targets'][name]
        need(all(expected['sha256'] not in hashes for hashes in manifest_hashes.values()), 'bounded checkpoint metadata negative ' + name)
        need(all(name not in item.get('exact_targets', []) for record in bounded for item in record['candidates']),
             'bounded exact-size public source scan negative ' + name)
        need(not (ROOT / 'recovered' / (name + '.py')).exists(), 'no substituted or regenerated target body ' + name)

    dependency = read_json(ROOT / 'DEPENDENCY_CLASSIFICATION.json')
    runtime_raw = (ROOT / dependency['runtime_source']['path']).read_bytes()
    need(desc(runtime_raw) == {k: dependency['runtime_source'][k] for k in ('bytes', 'sha256')}, 'current runtime source descriptor')
    runtime = ast.parse(runtime_raw)
    cls = next(n for n in runtime.body if isinstance(n, ast.ClassDef) and n.name == 'CurrentSources')
    loader = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == 'module')
    keys = {n.slice.value for n in ast.walk(loader) if isinstance(n, ast.Subscript) and isinstance(n.slice, ast.Constant) and isinstance(n.slice.value, str)}
    need({'projection_bytes', 'projection_sha256'} <= keys and not {'source_bytes', 'source_sha256'} & keys,
         'runtime loader consumes projection descriptors, not complete-source descriptors')
    loader_text = ast.get_source_segment(runtime_raw.decode(), loader)
    need("self.file('pure/'+name+'.py')" in loader_text, 'current runtime reads retained projection path')
    for row in dependency['dependency_rows']:
        need(row['module'] in unresolved and row['direct_runtime_read_of_complete_source_descriptor'] is False
             and row['expected_complete_body'] == {k: targets['targets'][row['module']][k] for k in ('bytes', 'sha256')},
             'bounded dependency classification ' + row['module'])
    census = read_json(ROOT / 'reference/INTERFACE_REQUIREMENTS.json')
    report = (ROOT / 'reference/DEPENDENCY_REPORT.md').read_text()
    section = report.split('## Remaining actual current Pro interfaces', 1)[1].split('## Verification', 1)[0]
    titles = re.findall(r'^\d+\. \*\*(.*?)\*\*', section, re.M)
    need(len(titles) == len(census['findings']) == 6, 'historical six-item census population')
    for item, title, recovered in zip(census['findings'], titles, dependency['historical_census']):
        need(recovered['id'] == item['id'] and recovered['fact_verbatim'] == item['fact']
             and recovered['owner_verbatim'] == item['owner']
             and recovered['numbered_dependency_report_title_verbatim'] == title,
             'verbatim historical title and census join ' + item['id'])
    return {
        'schema': 'g132.bounded-public-provenance-addendum.v1',
        'status': 'PARTIAL_EXACT_PROVENANCE_RECOVERED', 'authority': 'NONE',
        'recovered_exact_targets': positives,
        'unresolved_complete_source_descriptors': [{
            'name': n, 'descriptor_path': 'reference/PURE_SOURCE_PLAN.json#/' + n,
            'complete_source_filename_advertised': None,
            'projection_path': 'reference/pure/' + n + '.py',
            **{k: targets['targets'][n][k] for k in ('bytes', 'sha256')},
            'meaning': 'independent full-source-to-projection derivation provenance gap; no direct missing-file dependency in the published CurrentSources route'
        } for n in unresolved],
        'search_scope': 'checkpoint04/05/06 manifests and exact-size public Python source members; direct public Python source at results base6d9 and original operator d76; earlier sealed receiving already bounded the 166 public-probe additions',
        'negative_results_are_universal_absence_claims': False,
        'reconstructed_source_bodies': False, 'received_source_executed': False,
        'protected_G132': 'UNKNOWN_NO_REPLAY', 'original_awards': [],
        'original_or_private_execution': False, 'grants_or_acceptance': False,
        'historical_I01_I06': dependency['historical_census'],
        'check_count': len(checks), 'failed_checks': sum(not c['verified'] for c in checks), 'checks': checks,
        'verified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'prior_receiver_seal_sha256': targets['prior_seal_sha256'], 'prior_receiver_zip_sha256': targets['prior_zip_sha256']
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archives', type=Path, default=ROOT / 'acquisition')
    args = parser.parse_args()
    try:
        result = run(args.archives)
    except Exception as error:
        result = {'status': 'DATA_VERIFICATION_FAILED', 'authority': 'NONE',
                  'error_type': type(error).__name__, 'error': str(error), 'checks': checks,
                  'check_count': len(checks), 'failed_checks': sum(not c['verified'] for c in checks)}
        (ROOT / 'ADDENDUM_RESULT.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
        print(json.dumps({k: v for k, v in result.items() if k != 'checks'}))
        raise SystemExit(1)
    (ROOT / 'ADDENDUM_RESULT.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': result['status'], 'checks': result['check_count'], 'failed_checks': result['failed_checks'],
                      'recovered': list(result['recovered_exact_targets']),
                      'unresolved': [v['name'] for v in result['unresolved_complete_source_descriptors']]}))
