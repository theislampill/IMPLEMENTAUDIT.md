"""Reviewer-owned static finalization; does not import or execute subject code."""
from pathlib import Path,PurePosixPath
import datetime,gzip,hashlib,io,json,tarfile
ROOT=Path('/workspace/scratch/2678f1e431c3')
OUT=ROOT/'dg17-n10-prospective-review-v2'
V2=ROOT/'dg17-n10-recovered-prospective-v2'
V1R=ROOT/'dg17-n10-prospective-review'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def identity(p):return {'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}
expected=[
(V2/'DG17_N10_PROSPECTIVE_PACKET_V2.tar.gz','61334e07430020d1d434e35df22f6b3d9ced58dc2a1187cf8f66a41bf3dbb504'),
(V2/'SEALED_PACKET.json','a907904285a9f5a2b45ba3fe5910519a484645b0600c9339ea193360b3716c14'),
(V2/'EXECUTION_NOTES.md','a9fd58069676b79430bb5192ff1c4c551100be61b3272bcc5861aca2f61d1aef'),
(V2/'CHILD_ROUTE_ENVELOPE_TEMPLATE.json','dc4d41bf33dc7cde8e89074c6efbda87b0a37bb04df2aff42fa4715cc387377c'),
(V2/'neutral-stage/missions/IDENTITY_RESERVATION.txt','36086ae8921184f33c1aa5a01bb7de68fe20e8043d03cd9e816e703f732cff1a'),
(V1R/'REPORT.md','5bc441c00ded40083961b455b1ecb38bf2a40a263888ff8187416b4920b2be7a'),
(V1R/'FINDINGS.json','0fe2ab01dfc9330c7cf113daf918f2839aa4573881f18ab13c8a7f91da54ff82'),
(V1R/'SEALED_REVIEW.json','7413d0f30fec7285186e0bc235972d3d72b274965768e42f4b2d8cf260bf57f8')]
checks=[{'path':str(p),'sha256':sha(p),'pass':sha(p)==h} for p,h in expected]
readback={'schema':'dg17.PR01.review-final-readback.v1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'failures':[x for x in checks if not x['pass']],'protected_file_comparison':'105 unchanged byte/mode identities recorded in DELTA_READBACK.json; not behavior tests','helper_substantive_review_consumed':False}
(OUT/'FINAL_READBACK.json').write_text(json.dumps(readback,indent=2)+'\n')
if readback['failures']:raise RuntimeError('Final identity readback failed')
for name in ['DELTA_READBACK.json','BOUND_DELTA_CHECKS.json']:
    if json.loads((OUT/name).read_text())['failures']:raise RuntimeError('Preserved recheck failures in '+name)
excludes={'MANIFEST.json','SEALED_REVIEW.json','DG17_N10_PROSPECTIVE_REVIEW_V2.tar.gz'}
files=sorted(p for p in OUT.iterdir() if p.is_file() and p.name not in excludes)
manifest={'schema':'dg17.PR01.review-manifest.v1','member_count':len(files),'members':[identity(p) for p in files],'excludes':sorted(excludes),'scope':'Only bounded PR-01 correction recheck evidence'}
(OUT/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=OUT/'DG17_N10_PROSPECTIVE_REVIEW_V2.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w') as tar:
            for p in sorted([*files,OUT/'MANIFEST.json']):
                b=p.read_bytes();i=tarfile.TarInfo('dg17-n10-prospective-review-v2/'+p.name)
                i.size=len(b);i.mode=0o644;i.mtime=0;i.uid=i.gid=0;i.uname=i.gname=''
                tar.addfile(i,io.BytesIO(b))
verified=0
with tarfile.open(archive,'r:gz') as tar:
    for i in tar.getmembers():
        b=tar.extractfile(i).read();p=OUT/PurePosixPath(i.name).name
        if b!=p.read_bytes():raise RuntimeError('Reviewer archive mismatch: '+i.name)
        verified+=1
seal={'schema':'dg17.PR01.bounded-correction-review-seal.v1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/dg17_n10_prospective_reviewer','disposition':'PASS','scope':'PR-01 prospective protocol correction only','finding_status':'CORRECTED_PROSPECTIVELY','archive':identity(archive),'archive_members_verified':verified,'manifest':identity(OUT/'MANIFEST.json'),'report':identity(OUT/'REPORT.md'),'findings':identity(OUT/'FINDINGS.json'),'final_readback':identity(OUT/'FINAL_READBACK.json'),'v1_review_unchanged':True,'interruption_preserved':True,'helper_payload_read_or_extracted':False,'substantive_helper_reviews':0,'original_N10_award':False,'formal_stage6i_attestation':False,'authority':'Review evidence only; actual admission/route/host gates remain Root-owned','seal_meaning':'Local byte seal, not signature, trusted timestamp or provider/host provenance','actual_seal_command':'python /workspace/scratch/2678f1e431c3/dg17-n10-prospective-review-v2/seal_review.py'}
(OUT/'SEALED_REVIEW.json').write_text(json.dumps(seal,indent=2)+'\n')
print(json.dumps({'disposition':'PASS','scope':seal['scope'],'archive':seal['archive'],'manifest':seal['manifest'],'report':seal['report'],'findings':seal['findings'],'seal':identity(OUT/'SEALED_REVIEW.json'),'final_identity_failures':readback['failures'],'helper_review_consumed':False},indent=2))
