"""Reviewer-owned static/data verification; no subject code is imported or executed."""
from pathlib import Path, PurePosixPath
import ast
import datetime
import hashlib
import json
import stat
import tarfile

ROOT = Path('/workspace/scratch/2678f1e431c3/dg17-n10-recovered-prospective')
OUT = Path('/workspace/scratch/2678f1e431c3/dg17-n10-prospective-review')
checks = []
def record(name, passed, evidence):
    checks.append({'name': name, 'pass': bool(passed), 'evidence': evidence})
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def safe(name):
    p = PurePosixPath(name)
    return not p.is_absolute() and '..' not in p.parts and '\\' not in name and bool(name)
def entry(p):
    return {'bytes': p.stat().st_size, 'sha256': digest(p), 'mode': oct(stat.S_IMODE(p.stat().st_mode))}
def tree_sha(root):
    entries = []
    for p in root.iterdir():
        if p.is_dir():
            entries.append((p.name + '/', b'40000 ' + p.name.encode() + b'\0' + bytes.fromhex(tree_sha(p))))
        elif p.is_file() and not p.is_symlink():
            data = p.read_bytes()
            blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).digest()
            mode = b'100755' if p.stat().st_mode & 0o111 else b'100644'
            entries.append((p.name, mode + b' ' + p.name.encode() + b'\0' + blob))
        else:
            raise ValueError('Unsupported source member: ' + str(p))
    data = b''.join(v for _, v in sorted(entries, key=lambda item: item[0].encode()))
    return hashlib.sha1(b'tree ' + str(len(data)).encode() + b'\0' + data).hexdigest()

expected = {
    'DG17_N10_PROSPECTIVE_PACKET.tar.gz': ('003ff8ab41bf6f5757916bf65c8444c3d1ad9bccff44d38f89d9491478e91752', 1038860),
    'MANIFEST.json': ('5dc8eb95477fccc96fd4c98da1a0580a1b8d17233e520177c985821eee5fb957', 27026),
    'SEALED_PACKET.json': ('bf46829f4abf2dcb1fe888ccd304f4ab31daf6f7804efc0d0c34e245b527558d', 1808),
}
for name, (h, size) in expected.items():
    a = entry(ROOT / name)
    record('commissioned seal identity: ' + name, a['sha256'] == h and a['bytes'] == size, a)
commission = OUT / 'COMMISSION.json'
record('commission digest', digest(commission) == '16fd90a4d1a300c36bf21a430ee5b9a40563215eb9d2c64f367ce8a52b276d35', entry(commission))

manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
for name, base in [('MANIFEST.json', ROOT), ('NEUTRAL_STAGE_MANIFEST.json', ROOT / 'neutral-stage')]:
    d = json.loads((ROOT / name).read_text())
    seen = set()
    for m in d['members']:
        p = base / m['path']
        a = entry(p)
        record(name + ': ' + m['path'], safe(m['path']) and m['path'] not in seen and not p.is_symlink() and a == {k: m[k] for k in a}, a)
        seen.add(m['path'])
    actual = {str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
    actual_dirs = {str(p.relative_to(base)) for p in base.rglob('*') if p.is_dir()}
    record(name + ': exact member population', actual - set(d.get('excludes', [])) == seen and len(seen) == d['member_count'], {'actual_file_count': len(actual), 'manifest_count': len(seen), 'excludes': d.get('excludes', []), 'unlisted': sorted(actual - seen - set(d.get('excludes', []))), 'missing': sorted(seen - actual)})
    record(name + ': exact directory population', actual_dirs == set(d['directories']), {'actual_count': len(actual_dirs), 'declared_count': len(d['directories'])})

source = json.loads((ROOT / 'SOURCE_IDENTITY.json').read_text())
source_root = ROOT / 'neutral-stage/source-layout'
record('SOURCE_IDENTITY copies identical', (ROOT / 'SOURCE_IDENTITY.json').read_bytes() == (ROOT / 'neutral-stage/SOURCE_IDENTITY.json').read_bytes(), {'sha256': digest(ROOT / 'SOURCE_IDENTITY.json')})
record('PRECEDENCE copies identical', (ROOT / 'PRECEDENCE.json').read_bytes() == (ROOT / 'neutral-stage/PRECEDENCE.json').read_bytes(), {'sha256': digest(ROOT / 'PRECEDENCE.json')})
for m in source['members']:
    p = source_root / m['path']
    b = p.read_bytes()
    a = entry(p)
    blob = hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
    record('source byte/blob/mode: ' + m['path'], a['bytes'] == m['bytes'] and a['sha256'] == m['sha256'] and blob == m['git_blob_sha1'] and int(m['copy_mode'], 8) == stat.S_IMODE(p.stat().st_mode) == int(m['original_git_mode'], 8) & 0o777, dict(a, git_blob_sha1=blob))
source_population = {str(p.relative_to(source_root)) for p in source_root.rglob('*') if p.is_file()}
record('source exact member population', source_population == {m['path'] for m in source['members']} and len(source_population) == 81, {'count': len(source_population)})
skills_population = {str(p.relative_to(source_root)) for p in (source_root / 'skills').rglob('*') if p.is_file()}
skills_tree = tree_sha(source_root / 'skills')
record('reconstructed complete skills Git tree', len(skills_population) == 70 and skills_tree == source['skills_tree'] == '39ed21bf0ceb5b4496ee91c8266a14bd166db3bf', {'files': len(skills_population), 'git_tree_sha1': skills_tree})
record('canonical five-skill population', sorted(p.parent.name for p in (source_root / 'skills').glob('*/SKILL.md')) == ['audit-andon', 'audit-assess', 'audit-implement', 'audit-state', 'implementaudit'], {'skills': sorted(p.parent.name for p in (source_root / 'skills').glob('*/SKILL.md'))})

contracts = json.loads((ROOT / 'reviewer-private/ORIGINAL_CONTRACT_IDENTITIES.json').read_text())
for key in ['acceptance', 'issue']:
    m = contracts[key]
    p = ROOT / 'reviewer-private' / m['path']
    a = entry(p)
    ok = a['bytes'] == m['bytes'] and a['sha256'] == m['sha256']
    if 'git_blob_sha1' in m:
        b = p.read_bytes()
        a['git_blob_sha1'] = hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
        ok = ok and a['git_blob_sha1'] == m['git_blob_sha1']
    record('retained owner identity: ' + key, ok, a)

helper = ROOT / 'neutral-stage/review-input/helper-source-packet.tar.gz'
record('helper opaque archive hash/size', helper.stat().st_size == 310326 and digest(helper) == 'c73b6fb499a57c5e4127d549916c19518af9d8a8a4e64faadbe5d9918e7fcb04', entry(helper))
with tarfile.open(helper, 'r:gz') as archive:
    members = archive.getmembers()
    meta = [{'path': m.name, 'size': m.size, 'mode': oct(m.mode), 'type': 'regular' if m.isfile() else str(m.type)} for m in members]
    names = [m.name for m in members]
    record('helper TAR metadata safe and bound', len(members) == 46 and len(set(names)) == len(names) and len({n.casefold() for n in names}) == len(names) and all(m.isfile() and safe(m.name) for m in members) and meta == json.loads((ROOT / 'REVIEW_TARGET_BINDING.json').read_text())['archive_safe_metadata']['members'], {'member_count': len(members), 'total_member_payload_bytes': sum(m.size for m in members), 'members': meta, 'payloads_read_or_extracted': False})

with tarfile.open(ROOT / 'DG17_N10_PROSPECTIVE_PACKET.tar.gz', 'r:gz') as archive:
    members = archive.getmembers()
    names = [m.name for m in members]
    record('outer TAR safety', len(set(names)) == len(names) and len({n.casefold() for n in names}) == len(names) and all((m.isfile() or m.isdir()) and safe(m.name) for m in members), {'member_count': len(members), 'first_names': names[:3], 'regular_files': sum(m.isfile() for m in members)})
    file_checks = []
    for m in members:
        if not m.isfile():
            continue
        parts = PurePosixPath(m.name).parts
        rel = str(PurePosixPath(*parts[1:])) if not (ROOT / m.name).is_file() else m.name
        p = ROOT / rel
        payload_hash = hashlib.sha256(archive.extractfile(m).read()).hexdigest()
        file_checks.append({'path': rel, 'sha256': payload_hash, 'pass': p.is_file() and p.stat().st_size == m.size and digest(p) == payload_hash and stat.S_IMODE(p.stat().st_mode) == m.mode})
    record('outer TAR members match disk exactly', all(x['pass'] for x in file_checks), {'checked_regular_files': len(file_checks), 'failures': [x for x in file_checks if not x['pass']]})

controls = json.loads((ROOT / 'reviewer-private/MODEL_CONTROLS.json').read_text())
initial = (ROOT / 'neutral-stage/missions/STAGE1_ADMISSION.txt').read_text()
found = [s for s in controls['forbidden_initial_mission_phrases'] if s.casefold() in initial.casefold()]
record('declared forbidden mission phrases absent', not found, {'matched': found, 'scope': 'lexical data check only, not semantic neutrality proof'})
for key, p in [('initial_mission_sha256', 'neutral-stage/missions/STAGE1_ADMISSION.txt'), ('notice_mission_sha256', 'neutral-stage/missions/STAGE2_NOTICE.txt'), ('review_continuation_sha256', 'neutral-stage/missions/STAGE3_REVIEW_CONTINUATION.txt'), ('review_target_binding_sha256', 'REVIEW_TARGET_BINDING.json'), ('source_identity_sha256', 'SOURCE_IDENTITY.json')]:
    record('control binding: ' + key, digest(ROOT / p) == controls['input_bindings'][key], {'path': p, 'sha256': digest(ROOT / p)})
checker = ROOT / 'neutral-stage/support/check_notice.py'
ast.parse(checker.read_text(), filename=str(checker))
record('notice checker syntax parses without executing', True, {'sha256': digest(checker), 'executed': False})
notice = (ROOT / 'neutral-stage/work/notice.txt').read_bytes()
approved = (ROOT / 'neutral-stage/work/approved-notice.txt').read_bytes()
record('notice deterministic initial mismatch', notice.replace(b'pendng.', b'pending.') == approved and notice != approved and notice.count(b'\n') == approved.count(b'\n') == 2, {'initial_bytes': len(notice), 'approved_bytes': len(approved), 'observed_checker_RED': False})

result = {'schema': 'dg17.ordinary-prospective-review.static-verification.v1', 'reviewer': '/root/dg17_n10_prospective_reviewer', 'time_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'operation_class': 'stdlib read/hash/TAR metadata/AST parsing only; no subject code execution', 'check_count': len(checks), 'failed_count': sum(not c['pass'] for c in checks), 'failures': [c for c in checks if not c['pass']], 'checks': checks, 'limits': ['Helper TAR payloads were not read or extracted; the outer TAR comparison hashed its nested helper archive opaquely.', 'Original full root commit/tree linkage not independently fetched by this script.', 'No actor, child, source/checker/controller/host/native/protected operation executed.']}
(OUT / 'STATIC_VERIFICATION.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['schema', 'reviewer', 'operation_class', 'check_count', 'failed_count', 'failures', 'limits']}, indent=2))
raise SystemExit(1 if result['failed_count'] else 0)
