"""Seal only reviewer-owned evidence after a fresh static unchanged-subject readback."""
from pathlib import Path, PurePosixPath
import datetime, gzip, hashlib, io, json, stat, tarfile
OUT=Path('/workspace/scratch/2678f1e431c3/dg17-n10-prospective-review')
SUBJECT=Path('/workspace/scratch/2678f1e431c3/dg17-n10-recovered-prospective')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def identity(p): return {'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}
m=json.loads((SUBJECT/'MANIFEST.json').read_text())
checks=[]
for entry in m['members']:
    p=SUBJECT/entry['path']
    checks.append({'path':entry['path'],'pass':p.is_file() and not p.is_symlink() and p.stat().st_size==entry['bytes'] and sha(p)==entry['sha256'] and oct(stat.S_IMODE(p.stat().st_mode))==entry['mode']})
for name,h in [('MANIFEST.json','5dc8eb95477fccc96fd4c98da1a0580a1b8d17233e520177c985821eee5fb957'),('SEALED_PACKET.json','bf46829f4abf2dcb1fe888ccd304f4ab31daf6f7804efc0d0c34e245b527558d'),('DG17_N10_PROSPECTIVE_PACKET.tar.gz','003ff8ab41bf6f5757916bf65c8444c3d1ad9bccff44d38f89d9491478e91752')]:
    checks.append({'path':name,'pass':sha(SUBJECT/name)==h})
with tarfile.open(SUBJECT/'DG17_N10_PROSPECTIVE_PACKET.tar.gz','r:gz') as tar:
    names=[]
    for member in tar.getmembers():
        if not member.isfile(): continue
        parts=PurePosixPath(member.name).parts
        rel=str(PurePosixPath(*parts[1:])) if not (SUBJECT/member.name).is_file() else member.name
        names.append(rel)
expected={e['path'] for e in m['members']}|{'MANIFEST.json'}
archive_census={'pass':set(names)==expected and len(names)==len(expected),'actual':len(names),'expected':len(expected),'missing':sorted(expected-set(names)),'extra':sorted(set(names)-expected)}
readback={'schema':'dg17.ordinary-prospective-review.final-readback.v1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'operation':'static hashing and outer TAR member-name census only','subject_files_checked':len(checks),'subject_failures':[c for c in checks if not c['pass']],'outer_archive_population':archive_census,'report':identity(OUT/'REPORT.md'),'findings':identity(OUT/'FINDINGS.json'),'helper_review_consumed':False}
(OUT/'FINAL_READBACK.json').write_text(json.dumps(readback,indent=2)+'\n')
if readback['subject_failures'] or not archive_census['pass']:
    print(json.dumps(readback,indent=2))
    raise SystemExit(1)
excluded={'MANIFEST.json','SEALED_REVIEW.json','DG17_N10_PROSPECTIVE_REVIEW.tar.gz'}
files=sorted(p for p in OUT.iterdir() if p.is_file() and p.name not in excluded)
manifest={'schema':'dg17.ordinary-prospective-review.manifest.v1','reviewer':'/root/dg17_n10_prospective_reviewer','member_count':len(files),'members':[identity(p) for p in files],'excluded':sorted(excluded),'authority':'No behavioral award, formal Stage6.i readiness, source mutation, host/native proof, publication or closure'}
(OUT/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive_path=OUT/'DG17_N10_PROSPECTIVE_REVIEW.tar.gz'
with archive_path.open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w') as tar:
            for p in sorted([*files,OUT/'MANIFEST.json']):
                data=p.read_bytes()
                info=tarfile.TarInfo('dg17-n10-prospective-review/'+p.name)
                info.size=len(data); info.mode=0o644; info.mtime=0; info.uid=info.gid=0; info.uname=info.gname=''
                tar.addfile(info,io.BytesIO(data))
archive_checks=[]
with tarfile.open(archive_path,'r:gz') as tar:
    for member in tar.getmembers():
        p=OUT/PurePosixPath(member.name).name
        data=tar.extractfile(member).read()
        archive_checks.append(hashlib.sha256(data).hexdigest()==sha(p) and len(data)==p.stat().st_size)
if not all(archive_checks):
    raise RuntimeError('Reviewer archive readback failed')
seal={'schema':'dg17.ordinary-prospective-review.seal.v1','sealed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/dg17_n10_prospective_reviewer','disposition':'GAP-REVISE','finding_ids':['PR-01'],'admission_only_observation':'SUFFICIENT_AND_SAFE_WITH_EXISTING_EFFECT_BOUNDARY','archive':identity(archive_path),'archive_readback_files':len(archive_checks),'archive_readback_all_match':all(archive_checks),'manifest':identity(OUT/'MANIFEST.json'),'report':identity(OUT/'REPORT.md'),'findings':identity(OUT/'FINDINGS.json'),'final_readback':identity(OUT/'FINAL_READBACK.json'),'subject_unchanged':True,'helper_substantive_review_consumed':False,'formal_assess_or_stage6i':False,'original_case_award':False,'authority':'Reviewer evidence only; Root receives and owns next decisions','seal_meaning':'Local byte custody only, not signature, trusted timestamp, provider provenance or host proof','actual_seal_command':'python /workspace/scratch/2678f1e431c3/dg17-n10-prospective-review/seal_review.py'}
(OUT/'SEALED_REVIEW.json').write_text(json.dumps(seal,indent=2)+'\n')
print(json.dumps({'disposition':seal['disposition'],'archive':seal['archive'],'manifest':seal['manifest'],'report':seal['report'],'findings':seal['findings'],'seal':identity(OUT/'SEALED_REVIEW.json'),'subject_files_rechecked':len(checks),'outer_archive_population':archive_census,'helper_payload_reviewed':False},indent=2))
