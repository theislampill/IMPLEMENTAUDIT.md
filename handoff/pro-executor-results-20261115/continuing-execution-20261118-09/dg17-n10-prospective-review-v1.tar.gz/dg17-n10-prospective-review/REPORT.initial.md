# Prospective protocol review

Report state: PARTIAL

Root commissioned a fresh independent ordinary protocol review. No disposition exists yet.
