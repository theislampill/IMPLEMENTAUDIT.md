"""Bounded independent F1 rereview; only inspected AST-selected pure logic.

No full original/candidate module imports, controller, consumer, or effects.
Writes are confined to this v2 review directory; public body fixtures disposable.
"""
import ast
import copy
import hashlib
import json
from pathlib import Path
import stat
import tempfile
import types
import unittest

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/2678f1e431c3/g132-root-path')
V1 = ROOT / 'review-packet-m4-join-v1'
V2 = ROOT / 'review-packet-m4-join-v2'
FROZEN = Path('/workspace/scratch/095d3235c921/evidence/g132-portability/upstream-approved/g3_receiving.py')
V1_SHA = '4476231306669f0358bb5f861c074b20b79c28ed47e2bffddc8e3002b16ad64a'
V2_SHA = '102bba7f73733ddd6891a3d7c0466fa473e810dfda214f286d7b3a3bd0bb324f'
FROZEN_SHA = 'b85cca1550ff8e7c1c89778180e53a5c70f306f0c8725ba60ef3ccd4bbc3a6ad'
CONSTANTS = ('ORIGINAL_IDS', 'ORIGINAL_SCOPES', 'DISPOSITIONS', 'RESIDUALS', 'FINAL_PROOF_KEYS')
NEW_TESTS = ('test_partial_l04_named_retained_evidence_requires_bodies',
             'test_not_received_l04_named_retained_evidence_requires_bodies')

def desc(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def verify_packet(directory, expected_bytes, expected_sha):
    raw = (directory / 'REVIEW_MANIFEST.json').read_bytes()
    assert desc(raw) == {'bytes': expected_bytes, 'sha256': expected_sha}
    manifest = json.loads(raw)
    for item in manifest['files']:
        path = directory / item['path']
        assert desc(path.read_bytes()) == {k: item[k] for k in ('bytes', 'sha256')}
        assert stat.S_IMODE(path.stat().st_mode) == 0o400
    return manifest

m1 = verify_packet(V1, 2726, V1_SHA)
m2 = verify_packet(V2, 3844, V2_SHA)
raw1 = (V1 / 'retained_m4_join_candidate.py').read_bytes()
raw2 = (V2 / 'retained_m4_join_candidate.py').read_bytes()
tests1 = (V1 / 'test_retained_m4_join.py').read_bytes()
tests2 = (V2 / 'test_retained_m4_join.py').read_bytes()
anchor = b"        if name == 'R35-L04':\n"
added = (b"            if 'retained_m4_receiving' in row['evidence']:\n"
         b"                need(retained is not None, 'EXACT_RETAINED_M4_REQUIRED')\n")
assert raw1.count(anchor) == 1 and raw2 == raw1.replace(anchor, anchor + added)
t1 = ast.parse(tests1)
t2 = ast.parse(tests2)
candidate_tests = next(n for n in t2.body if isinstance(n, ast.ClassDef) and n.name == 'CandidateTests')
assert len([n for n in candidate_tests.body if isinstance(n, ast.FunctionDef) and n.name in NEW_TESTS]) == 2
t2_comparison = copy.deepcopy(t2)
comparison_class = next(n for n in t2_comparison.body if isinstance(n, ast.ClassDef) and n.name == 'CandidateTests')
comparison_class.body = [n for n in comparison_class.body if not isinstance(n, ast.FunctionDef) or n.name not in NEW_TESTS]
assert ast.dump(t1, include_attributes=False) == ast.dump(t2_comparison, include_attributes=False)

# Confirm all five original constants and select only reviewed pure declarations.
frozen_raw = FROZEN.read_bytes()
assert desc(frozen_raw) == {'bytes': 153706, 'sha256': FROZEN_SHA}
def select(raw, constants, functions, extra):
    selected = []
    names = set()
    for n in ast.parse(raw).body:
        if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id in constants for t in n.targets):
            ast.literal_eval(n.value)
            selected.append(n)
            names.update(t.id for t in n.targets)
        elif isinstance(n, ast.ClassDef) and n.name == 'Refusal':
            assert not n.decorator_list and len(n.body) == 1 and isinstance(n.body[0], ast.Pass)
            selected.append(n)
            names.add(n.name)
        elif isinstance(n, ast.FunctionDef) and n.name in functions:
            assert not n.decorator_list
            selected.append(n)
            names.add(n.name)
    assert names == set(constants) | set(functions) | {'Refusal'}
    ns = dict(extra)
    exec(compile(ast.Module(body=selected, type_ignores=[]), '<reviewed-pure-ast>', 'exec'), ns)
    return ns

old = select(frozen_raw, CONSTANTS, ('need', 'exact', 'validate_row_decisions'), {})
constants = CONSTANTS + ('FROZEN_G3_SHA256', 'M4_PINS', 'ORIGINAL_L04_TEXT', 'ORIGINAL_L04_BINDING', 'M4_DECISION')
ns = select(raw2, constants, ('need', 'exact', 'descriptor', 'parse', 'receive_exact_m4', 'validate_candidate_rows'),
            {'hashlib': hashlib, 'json': json})
candidate = types.SimpleNamespace(**{k: v for k, v in ns.items() if k != '__builtins__'})
assert all(getattr(candidate, name) == old[name] for name in CONSTANTS)
test_nodes = [n for n in t2.body if
              (isinstance(n, ast.FunctionDef) and n.name == 'case') or
              (isinstance(n, ast.ClassDef) and n.name == 'CandidateTests')]
selected_test_names = NEW_TESTS + (
    'test_no_retained_bodies_refuses_l04_acceptance',
    'test_l04_evidence_must_name_exact_retained_join',
    'test_exact_join_enables_only_prospective_l04_row_validation',
    'test_original_partial_path_remains_valid_without_join',
    'test_retained_join_is_not_evidence_for_q06_or_other_rows',
    'test_l07_reserved_obligations_unchanged',
    'test_incomplete_other_row_still_blocks_complete_g3',
)
with tempfile.TemporaryDirectory(prefix='controlled-public-bodies-', dir=OUT) as temp:
    here = Path(temp)
    public = here / 'retained-public-m4'
    public.mkdir(mode=0o700)
    for name, pin in candidate.M4_PINS.items():
        raw = (V2 / 'retained-public-m4' / name).read_bytes()
        assert desc(raw) == pin
        path = public / name
        path.write_bytes(raw)
        path.chmod(0o400)
    tns = {'__name__': 'focused_v2_review_tests', 'HERE': here, 'Path': Path, 'copy': copy,
           'unittest': unittest, 'CONSTANTS': CONSTANTS, 'frozen_row_validator': lambda: old}
    exec(compile(ast.Module(body=test_nodes, type_ignores=[]), '<reviewed-test-declarations>', 'exec'), tns)
    cls = tns['CandidateTests']
    cls.adapter = lambda self: candidate
    suite = unittest.TestSuite(cls(name) for name in selected_test_names)
    with (OUT / 'FOCUSED_TESTS.txt').open('w') as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    # The new requirement must allow existing nonaccepted declarations when an
    # actual exact retained body set accompanies the newly named proof.
    positive_nonaccepted = []
    bodies = {name: (public / name).read_bytes() for name in candidate.M4_PINS}
    for disposition in ('PARTIAL_SCOPE_ONLY', 'NOT_RECEIVED'):
        rows, gates = tns['case'](False, False)
        rows[4]['disposition'] = disposition
        rows[4]['evidence'] = ['retained_m4_receiving']
        value = candidate.validate_candidate_rows(rows, gates, retained_bodies=bodies)
        assert value['retained_m4'] is not None and value['new_awards'] == []
        assert value['live_g1_or_g3_proven'] is False
        positive_nonaccepted.append({'disposition': disposition, 'exact_bodies_supplied': True,
                                     'outcome': 'VALIDATED', 'new_awards': [], 'live_g1_or_g3_proven': False})

assert m1 == verify_packet(V1, 2726, V1_SHA)
assert m2 == verify_packet(V2, 3844, V2_SHA)
assert FROZEN.read_bytes() == frozen_raw
assert (V2 / 'prior-review' / 'REPORT.md').read_bytes() == (OUT.parent / 'REPORT.md').read_bytes()
assert (V2 / 'prior-review' / 'RESULT.json').read_bytes() == (OUT.parent / 'RESULT.json').read_bytes()
verification = {
    'schema': 'g132.independent-focused-m4-join-rereview.v2', 'authority': 'NONE',
    'candidate': desc(raw2), 'tests': desc(tests2), 'manifest': {'bytes': 3844, 'sha256': V2_SHA},
    'v2_members_exact_before_and_after': len(m2['files']),
    'v1_members_exact_before_and_after': len(m1['files']),
    'v1_gap_report_and_result_preserved_byte_exact': True,
    'candidate_delta_exactly_two_added_guard_lines': True,
    'tests_delta_exactly_two_new_methods_original_ast_unchanged': True,
    'five_original_constants_unchanged': True,
    'global_proof_allowlist_expanded': False,
    'focused_test_names': list(selected_test_names),
    'focused_tests_run': result.testsRun, 'failures': len(result.failures),
    'errors': len(result.errors), 'skipped': len(result.skipped), 'tests_successful': result.wasSuccessful(),
    'two_valid_body_nonaccepted_controls': positive_nonaccepted,
    'full_author_18_test_suite_rerun': False,
    'original_module_imported': False, 'original_consumer_executed': False,
    'only_original_execution': 'AST-selected pure row validator in unchanged legacy-path control',
    'candidate_main_or_filesystem_reader_executed': False,
    'hosted_action': False, 'controller_or_effect_operation': False,
    'historical_m4_reopened_or_replayed': False, 'new_awards': [],
    'writes_confined_to': str(OUT), 'hosted_integration': 'NOT_IMPLEMENTED_OR_PROVEN',
}
(OUT / 'VERIFICATION.json').write_text(json.dumps(verification, indent=2, sort_keys=True) + '\n')
print(json.dumps(verification, indent=2, sort_keys=True))
raise SystemExit(0 if result.wasSuccessful() else 1)
