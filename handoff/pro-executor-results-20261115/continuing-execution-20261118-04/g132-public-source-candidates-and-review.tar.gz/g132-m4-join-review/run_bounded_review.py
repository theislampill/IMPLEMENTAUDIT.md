"""Independent bounded review harness: exact source, AST-selected logic only.

No original module import, context, consumer, network, controller, or effect.
All test filesystem writes are confined to this review directory.
"""
import ast
import copy
import hashlib
import json
from pathlib import Path
import os
import stat
import tempfile
import types
import unittest

REVIEW = Path(__file__).resolve().parent
PACKET = Path('/workspace/scratch/2678f1e431c3/g132-root-path/review-packet-m4-join-v1')
FROZEN = Path('/workspace/scratch/095d3235c921/evidence/g132-portability/upstream-approved/g3_receiving.py')
MANIFEST_SHA = '4476231306669f0358bb5f861c074b20b79c28ed47e2bffddc8e3002b16ad64a'
FROZEN_SHA = 'b85cca1550ff8e7c1c89778180e53a5c70f306f0c8725ba60ef3ccd4bbc3a6ad'
CONSTANTS = ('ORIGINAL_IDS', 'ORIGINAL_SCOPES', 'DISPOSITIONS', 'RESIDUALS', 'FINAL_PROOF_KEYS')

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def exact_packet():
    manifest_raw = (PACKET / 'REVIEW_MANIFEST.json').read_bytes()
    assert len(manifest_raw) == 2726 and digest(manifest_raw) == MANIFEST_SHA
    manifest = json.loads(manifest_raw)
    for item in manifest['files']:
        path = PACKET / item['path']
        raw = path.read_bytes()
        assert len(raw) == item['bytes'] and digest(raw) == item['sha256'], item['path']
        assert stat.S_IMODE(path.stat().st_mode) == 0o400, item['path']
    raw = FROZEN.read_bytes()
    assert len(raw) == 153706 and digest(raw) == FROZEN_SHA
    return manifest, raw

manifest, frozen_raw = exact_packet()
candidate_raw = (PACKET / 'retained_m4_join_candidate.py').read_bytes()
test_raw = (PACKET / 'test_retained_m4_join.py').read_bytes()

def selected_namespace(raw, constants, functions, extra):
    tree = ast.parse(raw)
    selected = []
    names = []
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id in constants for t in node.targets):
            ast.literal_eval(node.value)
            selected.append(node)
            names.extend(t.id for t in node.targets)
        elif isinstance(node, ast.ClassDef) and node.name == 'Refusal':
            assert not node.decorator_list and len(node.body) == 1 and isinstance(node.body[0], ast.Pass)
            assert len(node.bases) == 1 and isinstance(node.bases[0], ast.Name) and node.bases[0].id in ('Exception', 'ValueError')
            selected.append(node)
            names.append(node.name)
        elif isinstance(node, ast.FunctionDef) and node.name in functions:
            assert not node.decorator_list
            selected.append(node)
            names.append(node.name)
    assert set(constants) | set(functions) | {'Refusal'} == set(names)
    namespace = dict(extra)
    exec(compile(ast.Module(body=selected, type_ignores=[]), '<reviewed-ast-selected-logic>', 'exec'), namespace)
    return namespace, names

frozen, frozen_names = selected_namespace(frozen_raw, CONSTANTS, ('need', 'exact', 'validate_row_decisions'), {})
candidate_functions = ('need', 'exact', 'descriptor', 'parse', 'receive_exact_m4', 'read_m4_bodies', 'validate_candidate_rows')
candidate_constants = CONSTANTS + ('FROZEN_G3_SHA256', 'M4_PINS', 'ORIGINAL_L04_TEXT', 'ORIGINAL_L04_BINDING', 'M4_DECISION')
candidate_ns, candidate_names = selected_namespace(candidate_raw, candidate_constants, candidate_functions,
    {'hashlib': hashlib, 'json': json, 'os': os, 'Path': Path, 'stat': stat})
candidate = types.SimpleNamespace(**{k: v for k, v in candidate_ns.items() if k != '__builtins__'})

# The reviewed supplied tests are loaded as declarations; no packet module or
# original consumer is imported. The adapter is replaced with the selected AST.
test_tree = ast.parse(test_raw)
test_nodes = [node for node in test_tree.body if
    (isinstance(node, ast.FunctionDef) and node.name == 'case') or
    (isinstance(node, ast.ClassDef) and node.name == 'CandidateTests')]
assert len(test_nodes) == 2
tempfile.tempdir = str(REVIEW)
with tempfile.TemporaryDirectory(prefix='controlled-public-inputs-', dir=REVIEW) as fixture:
    here = Path(fixture)
    public = here / 'retained-public-m4'
    public.mkdir(mode=0o700)
    for name, pin in candidate.M4_PINS.items():
        raw = (PACKET / 'retained-public-m4' / name).read_bytes()
        assert len(raw) == pin['bytes'] and digest(raw) == pin['sha256']
        path = public / name
        path.write_bytes(raw)
        path.chmod(0o400)
    test_ns = {'__name__': 'bounded_review_tests', 'HERE': here, 'Path': Path,
               'copy': copy, 'unittest': unittest, 'tempfile': tempfile,
               'CONSTANTS': CONSTANTS, 'frozen_row_validator': lambda: frozen}
    exec(compile(ast.Module(body=test_nodes, type_ignores=[]), '<reviewed-supplied-test-declarations>', 'exec'), test_ns)
    test_class = test_ns['CandidateTests']
    test_class.adapter = lambda self: candidate
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(test_class)
    with (REVIEW / 'SUPPLIED_TESTS.txt').open('w') as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    make_case = test_ns['case']
    bodies = {name: (public / name).read_bytes() for name in candidate.M4_PINS}
    probes = []
    def probe(label, rows, gates, retained_bodies=None):
        try:
            value = candidate.validate_candidate_rows(rows, gates, retained_bodies=retained_bodies)
            probes.append({'case': label, 'outcome': 'VALIDATED', 'retained_m4_present': value['retained_m4'] is not None,
                           'live_g1_or_g3_proven': value['live_g1_or_g3_proven'], 'new_awards': value['new_awards']})
        except candidate.Refusal as exc:
            probes.append({'case': label, 'outcome': 'REFUSED', 'code': str(exc)})
    rows, gates = make_case(False, False)
    rows[4]['evidence'] = ['retained_m4_receiving']
    probe('partial_l04_dangling_retained_evidence_without_bodies', rows, gates)
    rows, gates = make_case(False, False)
    rows[4]['disposition'] = 'NOT_RECEIVED'
    rows[4]['evidence'] = ['retained_m4_receiving']
    probe('not_received_l04_dangling_retained_evidence_without_bodies', rows, gates)
    for gate in ('G1', 'G3'):
        rows, gates = make_case()
        gates[gate]['evidence'] = ['retained_m4_receiving']
        probe('retained_m4_cannot_substitute_' + gate + '_gate_proof', rows, gates, bodies)
    rows, gates = make_case()
    rows[0]['disposition'] = 'NOT_RECEIVED'
    rows[0]['residuals'] = ['ORIGINAL_CONJUNCTION_NOT_ESTABLISHED']
    probe('unreceived_q06_still_blocks_complete_g3', rows, gates, bodies)

post_manifest, post_frozen = exact_packet()
assert manifest == post_manifest and frozen_raw == post_frozen
verification = {
    'schema': 'ordinary-independent-cold-source-review-verification.v1',
    'authority': 'NONE', 'manifest_sha256': MANIFEST_SHA,
    'candidate_sha256': digest(candidate_raw), 'tests_sha256': digest(test_raw),
    'frozen_sha256': FROZEN_SHA, 'frozen_bytes': len(frozen_raw),
    'packet_members': len(manifest['files']), 'all_packet_members_exact_before_and_after': True,
    'frozen_selected_names': frozen_names, 'candidate_selected_names': candidate_names,
    'supplied_tests_run': result.testsRun, 'supplied_test_failures': len(result.failures),
    'supplied_test_errors': len(result.errors), 'supplied_test_skips': len(result.skipped),
    'supplied_tests_successful': result.wasSuccessful(),
    'controlled_extra_probes': probes,
    'original_module_imported': False, 'original_consumer_executed': False,
    'historical_m4_replayed': False, 'hosted_action': False, 'grant_or_controller_operation': False,
    'protected_operation': False, 'new_awards': [], 'currentness_transferred': False,
    'test_writes_scope': str(REVIEW),
    'test_input_scope': 'Disposable exact copies of four already-public retained M4 bodies',
}
(REVIEW / 'VERIFICATION.json').write_text(json.dumps(verification, indent=2, sort_keys=True) + '\n')
print(json.dumps(verification, indent=2, sort_keys=True))
raise SystemExit(0 if result.wasSuccessful() else 1)
