"""Pure candidate tests. No original consumer, host setup, or effect is invoked."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
FROZEN = Path('/workspace/scratch/095d3235c921/evidence/g132-portability/upstream-approved/g3_receiving.py')
FROZEN_SHA = 'b85cca1550ff8e7c1c89778180e53a5c70f306f0c8725ba60ef3ccd4bbc3a6ad'
CONSTANTS = ('ORIGINAL_IDS', 'ORIGINAL_SCOPES', 'DISPOSITIONS', 'RESIDUALS', 'FINAL_PROOF_KEYS')


def frozen_row_validator():
    raw = FROZEN.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == FROZEN_SHA
    tree = ast.parse(raw)
    selected = []
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id in CONSTANTS for t in node.targets):
            ast.literal_eval(node.value)
            selected.append(node)
        elif isinstance(node, ast.ClassDef) and node.name == 'Refusal':
            selected.append(node)
        elif isinstance(node, ast.FunctionDef) and node.name in ('need', 'exact', 'validate_row_decisions'):
            selected.append(node)
    namespace = {}
    exec(compile(ast.Module(body=selected, type_ignores=[]), '<frozen-pure-row-validator>', 'exec'), namespace)
    return namespace


def case(accepted_l04=True, accepted_g3=True):
    old = frozen_row_validator()
    rows = []
    for name, scope in zip(old['ORIGINAL_IDS'], old['ORIGINAL_SCOPES']):
        row = {'id': name, 'scope': scope, 'disposition': 'ACCEPTED_AT_DECLARED_SCOPE',
               'evidence': ['module'], 'residuals': ['NONE_AT_DECLARED_SCOPE']}
        if name == 'R35-L04':
            row['evidence'] = ['retained_m4_receiving'] if accepted_l04 else ['module']
            if not accepted_l04:
                row['disposition'] = 'PARTIAL_SCOPE_ONLY'
                row['residuals'] = ['NATURAL_RLGWO_PREREQUISITE_UNRECEIVED']
        if name == 'R35-L07':
            row['residuals'] = ['GLOBAL_LIVENESS_UNPROVED', 'RETIREMENT_OR_TRANSFER_UNPERFORMED']
        rows.append(row)
    gates = {
        'G1': {'scope': 'PROSPECTIVE_GENUINE_ORIGINAL19_SHARED_IMAGE_PAIR',
               'disposition': 'ACCEPTED_AT_DECLARED_SCOPE', 'evidence': ['g1_receiving']},
        'G3': {'scope': 'EXACT_Q06_AND_L01_TO_L07_DECLARED_SCOPES',
               'disposition': 'ACCEPTED_AT_DECLARED_SCOPE' if accepted_g3 else 'PARTIAL_SCOPE_ONLY',
               'evidence': ['module']}}
    return rows, gates


class CandidateTests(unittest.TestCase):
    def adapter(self):
        path = HERE / 'retained_m4_join_candidate.py'
        self.assertTrue(path.is_file(), 'MISSING_PROSPECTIVE_RETAINED_M4_JOIN')
        spec = importlib.util.spec_from_file_location('retained_m4_join_candidate', path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def bodies(self):
        names = ('M4_ROOT_RECEIVING.json', 'M4_INDEPENDENT_REPORT.md',
                 'M4_INDEPENDENT_RESULT.json', 'M4_FINAL_CHECK.json')
        return {name: (HERE / 'retained-public-m4' / name).read_bytes() for name in names}

    def test_original_frozen_policy_rejects_accepted_l04(self):
        owner = frozen_row_validator()
        rows, gates = case()
        rows[4]['evidence'] = ['module']
        with self.assertRaisesRegex(owner['Refusal'], 'NATURAL_RLGWO_SCOPE_NOT_ESTABLISHED'):
            owner['validate_row_decisions'](rows, gates)

    def test_exact_prior_acceptance_is_input_only(self):
        value = self.adapter().receive_exact_m4(self.bodies())
        self.assertEqual(value['prior_accepted_run'], '44076469956')
        self.assertEqual(value['authority'], 'NONE')
        self.assertFalse(value['new_acceptance'])
        self.assertFalse(value['currentness_transfer'])
        self.assertFalse(value['required_m4_rerun'])
        self.assertEqual(value['g132'], 'UNKNOWN_NO_REPLAY')

    def test_original_contract_constants_unchanged(self):
        candidate = self.adapter()
        owner = frozen_row_validator()
        for name in CONSTANTS:
            self.assertEqual(getattr(candidate, name), owner[name])

    def test_exact_join_enables_only_prospective_l04_row_validation(self):
        candidate = self.adapter()
        rows, gates = case()
        result = candidate.validate_candidate_rows(rows, gates, retained_bodies=self.bodies())
        self.assertEqual(result['status'], 'PROSPECTIVE_ROW_FORMAT_AND_RETAINED_JOIN_VALIDATED')
        self.assertFalse(result['original_consumer_executed'])
        self.assertFalse(result['live_g1_or_g3_proven'])
        self.assertEqual(result['new_awards'], [])

    def test_no_retained_bodies_refuses_l04_acceptance(self):
        candidate = self.adapter()
        rows, gates = case()
        with self.assertRaisesRegex(candidate.Refusal, 'EXACT_RETAINED_M4_REQUIRED'):
            candidate.validate_candidate_rows(rows, gates)

    def test_partial_l04_named_retained_evidence_requires_bodies(self):
        candidate = self.adapter()
        rows, gates = case(accepted_l04=False, accepted_g3=False)
        rows[4]['evidence'] = ['retained_m4_receiving']
        with self.assertRaisesRegex(candidate.Refusal, 'EXACT_RETAINED_M4_REQUIRED'):
            candidate.validate_candidate_rows(rows, gates)

    def test_not_received_l04_named_retained_evidence_requires_bodies(self):
        candidate = self.adapter()
        rows, gates = case(accepted_l04=False, accepted_g3=False)
        rows[4]['disposition'] = 'NOT_RECEIVED'
        rows[4]['evidence'] = ['retained_m4_receiving']
        with self.assertRaisesRegex(candidate.Refusal, 'EXACT_RETAINED_M4_REQUIRED'):
            candidate.validate_candidate_rows(rows, gates)

    def test_missing_or_extra_evidence_body_refused(self):
        candidate = self.adapter()
        for mutation in ('missing', 'extra'):
            bodies = self.bodies()
            if mutation == 'missing':
                del bodies['M4_FINAL_CHECK.json']
            else:
                bodies['NEW_ADMISSION.json'] = b'{}'
            with self.subTest(mutation=mutation), self.assertRaisesRegex(candidate.Refusal, 'M4_EXACT_BODY_POPULATION'):
                candidate.receive_exact_m4(bodies)

    def test_changed_root_decision_and_each_support_body_refused(self):
        candidate = self.adapter()
        for name in self.bodies():
            bodies = self.bodies()
            bodies[name] += b'\n'
            with self.subTest(name=name), self.assertRaisesRegex(candidate.Refusal, 'M4_BODY_PIN'):
                candidate.receive_exact_m4(bodies)

    def test_hash_summary_cannot_replace_body(self):
        candidate = self.adapter()
        bodies = self.bodies()
        bodies['M4_ROOT_RECEIVING.json'] = {'sha256': candidate.M4_PINS['M4_ROOT_RECEIVING.json']['sha256']}
        with self.assertRaisesRegex(candidate.Refusal, 'M4_BODY_TYPE'):
            candidate.receive_exact_m4(bodies)

    def test_l04_evidence_must_name_exact_retained_join(self):
        candidate = self.adapter()
        rows, gates = case()
        rows[4]['evidence'] = ['module']
        with self.assertRaisesRegex(candidate.Refusal, 'M4_EXPLICIT_EVIDENCE_REQUIRED'):
            candidate.validate_candidate_rows(rows, gates, retained_bodies=self.bodies())

    def test_retained_join_is_not_evidence_for_q06_or_other_rows(self):
        candidate = self.adapter()
        for i in (0, 1, 2, 3, 5, 6, 7):
            rows, gates = case()
            rows[i]['evidence'] = ['retained_m4_receiving']
            with self.subTest(row=i), self.assertRaisesRegex(candidate.Refusal, 'FINAL_ORIGINAL_ROW_SCOPE'):
                candidate.validate_candidate_rows(rows, gates, retained_bodies=self.bodies())

    def test_old_missing_natural_residual_cannot_accompany_accepted_l04(self):
        candidate = self.adapter()
        rows, gates = case()
        rows[4]['residuals'] = ['NATURAL_RLGWO_PREREQUISITE_UNRECEIVED']
        with self.assertRaisesRegex(candidate.Refusal, 'M4_ACCEPTED_EPISODE_RESIDUAL_CONTRADICTION'):
            candidate.validate_candidate_rows(rows, gates, retained_bodies=self.bodies())

    def test_original_partial_path_remains_valid_without_join(self):
        candidate = self.adapter()
        rows, gates = case(accepted_l04=False, accepted_g3=False)
        frozen_row_validator()['validate_row_decisions'](rows, gates)
        candidate.validate_candidate_rows(rows, gates)

    def test_incomplete_other_row_still_blocks_complete_g3(self):
        candidate = self.adapter()
        for i in (0, 1, 2, 3, 5, 6, 7):
            rows, gates = case()
            rows[i]['disposition'] = 'PARTIAL_SCOPE_ONLY'
            with self.subTest(row=i), self.assertRaisesRegex(candidate.Refusal, 'PARTIAL_ROWS_CANNOT_GRANT_COMPLETE_G3_SCOPE'):
                candidate.validate_candidate_rows(rows, gates, retained_bodies=self.bodies())

    def test_l07_reserved_obligations_unchanged(self):
        candidate = self.adapter()
        rows, gates = case()
        rows[7]['residuals'] = ['NONE_AT_DECLARED_SCOPE']
        with self.assertRaisesRegex(candidate.Refusal, 'L07_STRONGER_CLAIM_MUST_REMAIN_SEPARATE'):
            candidate.validate_candidate_rows(rows, gates, retained_bodies=self.bodies())

    def test_wrong_scope_or_extra_gate_refused(self):
        candidate = self.adapter()
        rows, gates = case()
        rows[4]['scope'] = 'WHOLE_DG16'
        with self.assertRaisesRegex(candidate.Refusal, 'FINAL_ORIGINAL_ROW_SCOPE'):
            candidate.validate_candidate_rows(rows, gates, retained_bodies=self.bodies())
        rows, gates = case()
        gates['DG16'] = copy.deepcopy(gates['G3'])
        with self.assertRaisesRegex(candidate.Refusal, 'CLOSED_SCHEMA_REFUSED'):
            candidate.validate_candidate_rows(rows, gates, retained_bodies=self.bodies())

    def test_actual_owned_readback_and_symlink_refusal(self):
        candidate = self.adapter()
        result = candidate.read_m4_bodies(HERE / 'retained-public-m4')
        self.assertEqual(result, self.bodies())
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            for name, data in self.bodies().items():
                p = base / name
                p.write_bytes(data)
                p.chmod(0o400)
            (base / 'M4_FINAL_CHECK.json').unlink()
            (base / 'M4_FINAL_CHECK.json').symlink_to(HERE / 'retained-public-m4' / 'M4_FINAL_CHECK.json')
            with self.assertRaisesRegex(candidate.Refusal, 'M4_ORDINARY_OWNED_FILE'):
                candidate.read_m4_bodies(base)


if __name__ == '__main__':
    unittest.main(verbosity=2)
