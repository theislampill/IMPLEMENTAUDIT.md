#!/usr/bin/env python3
"""Prospective, read-only join of already accepted original M4/L04 evidence.

This is a candidate for one G3 receiving interface, not an approved consumer.
It never imports or invokes the original G1/G3 consumers, creates a decision,
authenticates an issuer, changes currentness, or performs a protected effect.
The frozen b85c module and its original operation remain untouched.

The five original row-contract constants are copied exactly from b85c and
checked against its byte-pinned AST by the companion tests. Only the L04
accepted-row evidence branch is prospective. Full hosted integration requires
independent review, applicability, source/pin binding, live Root decision and
the original effect/custody gates. This module grants none of those.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat

FROZEN_G3_SHA256 = 'b85cca1550ff8e7c1c89778180e53a5c70f306f0c8725ba60ef3ccd4bbc3a6ad'
ORIGINAL_IDS = ('R35-Q06', 'R35-L01', 'R35-L02', 'R35-L03', 'R35-L04', 'R35-L05', 'R35-L06', 'R35-L07')
ORIGINAL_SCOPES = (
    'NATIVE_BOUNDED_FRESH_GOVERNED_EPISODE', 'MATERIAL_RETURN_ANCESTRY_CURRENT_NATIVE_CAMPAIGN',
    'PREPARATION_SELECTION_WITH_BLOCKED_ADMISSION_EFFECT', 'FOUR_DIRECTIONS_PARTIAL_JOIN_RECONSIDERATION',
    'ACTUAL_NATURAL_TRANSITION_AND_CONSUMED_USEFUL_PREPARATION',
    'HELD_OUT_INERT_NEGATIVES_WITH_EXACT_SOURCE_APPLICABILITY',
    'NATIVE_CURRENTNESS_AND_BOUNDED_SELECTION_BLOCKS', 'SCOPED_TRIAD_GUARDS_WITH_STRONGER_CLAIMS_SEPARATE')
DISPOSITIONS = ('ACCEPTED_AT_DECLARED_SCOPE', 'PARTIAL_SCOPE_ONLY', 'NOT_RECEIVED')
RESIDUALS = ('NONE_AT_DECLARED_SCOPE', 'ORIGINAL_CONJUNCTION_NOT_ESTABLISHED',
    'INDEPENDENT_REVIEW_APPLICABILITY_NOT_ESTABLISHED', 'GLOBAL_LIVENESS_UNPROVED',
    'RETIREMENT_OR_TRANSFER_UNPERFORMED', 'AUTHORITATIVE_V041_ADMISSION_PENDING',
    'NATURAL_RLGWO_PREREQUISITE_UNRECEIVED')
FINAL_PROOF_KEYS = ('g1_receiving', 'g1_preboundary_inputs', 'scope_receiving', 'initial_native', 'dispatch', 'transition', 'join',
    'root_consumption', 'recursive_records', 'final_native', 'final_transition', 'stale_return',
    'missing_return', 'negative_applicability', 'module')

M4_PINS = {
    'M4_ROOT_RECEIVING.json': {'bytes': 33448, 'sha256': '2915fe9d6723ad9c745906d763d1de5818de7f4ae79db3bba196b5d8d678d0db'},
    'M4_INDEPENDENT_REPORT.md': {'bytes': 11997, 'sha256': '8e9b1b2e565019dc72f7e64f8e59386c9b364b0dbd009941d188f9e41c6e6417'},
    'M4_INDEPENDENT_RESULT.json': {'bytes': 78141, 'sha256': '23de2fa62d080ba20e79bb8599211ffdf7f6d479d76e4d701260938e27bc4da0'},
    'M4_FINAL_CHECK.json': {'bytes': 1201, 'sha256': 'eb070f91d6c0923bd51604132dc2763ed00a08eb495aa5ddde293082a67e1689'},
}
ORIGINAL_L04_TEXT = ('Held-out positive has completed comparison inputs, genuinely blocked admission/effect, '
    'independent useful preparation with met actual prerequisites, and an ancestor future qualification/JOIN '
    'prerequisite. Show actual selected bounded work and a consumed decision-changing return while the blocked effect remains blocked.')
ORIGINAL_L04_BINDING = 'P simulated/portable test consumer can qualify its declared scope; NATIVE remains for one natural material campaign transition. [L, E]'
M4_DECISION = 'ACCEPT_ORIGINAL_M4_L04_NATIVE_NATURAL_TRANSITION_AT_DECLARED_EPISODE'


class Refusal(ValueError):
    pass


def need(ok, code):
    if not ok:
        raise Refusal(code)


def exact(value, fields):
    need(type(value) is dict and set(value) == set(fields), 'CLOSED_SCHEMA_REFUSED')


def descriptor(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def parse(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, 'DUPLICATE_JSON_KEY')
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda _: need(False, 'NONFINITE_JSON'))


def receive_exact_m4(bodies):
    """Receive an immutable accepted historical fact. No new acceptance follows."""
    need(type(bodies) is dict and set(bodies) == set(M4_PINS), 'M4_EXACT_BODY_POPULATION')
    for name, pin in M4_PINS.items():
        raw = bodies[name]
        need(type(raw) is bytes, 'M4_BODY_TYPE')
        need(descriptor(raw) == pin, 'M4_BODY_PIN')
    root = parse(bodies['M4_ROOT_RECEIVING.json'])
    need(root['schema'] == 'implementaudit.Root-original-scope-receiving.v1'
         and root['decision'] == M4_DECISION and root['receiver'] == '/root'
         and root['operation'] == 'M4' and root['criterion'] == 'R35-L04'
         and type(root['actual_run']) is int and root['actual_run'] == 44076469956
         and root['launch_commit'] == '5d8bd6aa60b7490788b1905e2dec14701fdcef35'
         and root['root_consumption_commit'] == '1fa59671a71f3c3f22c70aa2918d02125ab98bd7',
         'M4_ORIGINAL_ACCEPTED_SUBJECT')
    need(root['original_text'] == ORIGINAL_L04_TEXT and root['original_scope_and_binding'] == ORIGINAL_L04_BINDING
         and root['missing_original_M4_predicates_at_episode'] == [] and root['required_M4_rerun'] is False,
         'M4_ORIGINAL_REQUIREMENT_CHANGED')
    need(root['G132'] == 'UNKNOWN_NO_REPLAY' and root['ancestor_JOIN'] == 'BLOCKED'
         and root['Q06_whole_award'] is False and root['audit_complete'] is False
         and root['native_Stop_acceptance'] is False and root['other_operation_awards'] == [],
         'M4_RESERVED_SCOPE_CHANGED')
    for key, name in (('review', 'M4_INDEPENDENT_REPORT.md'), ('result', 'M4_INDEPENDENT_RESULT.json'),
                      ('final_check', 'M4_FINAL_CHECK.json')):
        need({k: root[key][k] for k in ('bytes', 'sha256')} == M4_PINS[name], 'M4_ROOT_SUPPORT_JOIN')
    return {
        'schema': 'g132.prospective-retained-m4-input-receiving.v1', 'authority': 'NONE',
        'criterion': 'R35-L04', 'original_scope': ORIGINAL_SCOPES[4], 'prior_accepted_run': '44076469956',
        'prior_root_decision': M4_DECISION, 'bodies': {k: dict(v) for k, v in M4_PINS.items()},
        'missing_predicates_at_prior_episode': [], 'required_m4_rerun': False,
        'currentness_transfer': False, 'new_acceptance': False, 'g132': 'UNKNOWN_NO_REPLAY',
        'source_applicability_and_live_root_decision_required_for_new_consumer': True,
    }


def read_m4_bodies(directory):
    """Read exact public bytes with actual current ownership and stable files."""
    directory = Path(directory)
    need(directory.is_absolute() and directory.resolve(strict=True) == directory, 'M4_CANONICAL_DIRECTORY')
    start = directory.lstat()
    need(stat.S_ISDIR(start.st_mode) and start.st_uid == os.geteuid()
         and not start.st_mode & 0o022, 'M4_OWNED_DIRECTORY')
    mark = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_uid, s.st_gid,
                      s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    bodies = {}
    for name, pin in M4_PINS.items():
        path = directory / name
        before = path.lstat()
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_uid == os.geteuid()
             and stat.S_IMODE(before.st_mode) in (0o400, 0o444) and before.st_size == pin['bytes'],
             'M4_ORDINARY_OWNED_FILE')
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
        try:
            need(mark(os.fstat(fd)) == mark(before) and not os.listxattr(fd), 'M4_OPEN_CHANGED')
            raw = os.pread(fd, pin['bytes'] + 1, 0)
            need(mark(before) == mark(os.fstat(fd)) == mark(path.lstat())
                 and path.resolve(strict=True) == path, 'M4_CLOSING_CHANGED')
        finally:
            os.close(fd)
        need(descriptor(raw) == pin, 'M4_BODY_PIN')
        bodies[name] = raw
    need(mark(start) == mark(directory.lstat()), 'M4_DIRECTORY_CHANGED')
    return bodies


def validate_candidate_rows(rows, gates, *, retained_bodies=None):
    """Prospective source rule only; caller still needs the actual final consumer.

    All original scopes and the full-G3 conjunction remain exact. A retained M4
    input qualifies only the L04 evidence branch, never Q06 or current G1/G3.
    """
    retained = receive_exact_m4(retained_bodies) if retained_bodies is not None else None
    need(type(rows) is list and len(rows) == len(ORIGINAL_IDS), 'FINAL_ORIGINAL_ROW_POPULATION')
    for row, name, scope in zip(rows, ORIGINAL_IDS, ORIGINAL_SCOPES):
        exact(row, ('id', 'scope', 'disposition', 'evidence', 'residuals'))
        permitted_proofs = FINAL_PROOF_KEYS + (('retained_m4_receiving',) if name == 'R35-L04' else ())
        need(row['id'] == name and row['scope'] == scope and row['disposition'] in DISPOSITIONS
             and type(row['evidence']) is list and 1 <= len(row['evidence']) <= len(permitted_proofs)
             and len(row['evidence']) == len(set(row['evidence']))
             and all(k in permitted_proofs for k in row['evidence'])
             and type(row['residuals']) is list and 1 <= len(row['residuals']) <= len(RESIDUALS)
             and len(row['residuals']) == len(set(row['residuals']))
             and all(k in RESIDUALS for k in row['residuals']), 'FINAL_ORIGINAL_ROW_SCOPE')
        need(row['disposition'] != 'NOT_RECEIVED' or 'NONE_AT_DECLARED_SCOPE' not in row['residuals'],
             'FINAL_UNRECEIVED_RESIDUAL')
        if name == 'R35-L04':
            if 'retained_m4_receiving' in row['evidence']:
                need(retained is not None, 'EXACT_RETAINED_M4_REQUIRED')
            if row['disposition'] == 'ACCEPTED_AT_DECLARED_SCOPE':
                need(retained is not None, 'EXACT_RETAINED_M4_REQUIRED')
                need('retained_m4_receiving' in row['evidence'], 'M4_EXPLICIT_EVIDENCE_REQUIRED')
                need(row['residuals'] == ['NONE_AT_DECLARED_SCOPE'], 'M4_ACCEPTED_EPISODE_RESIDUAL_CONTRADICTION')
            else:
                need('NATURAL_RLGWO_PREREQUISITE_UNRECEIVED' in row['residuals'], 'NATURAL_RLGWO_SCOPE_NOT_ESTABLISHED')
        if name == 'R35-L07':
            need('GLOBAL_LIVENESS_UNPROVED' in row['residuals'] and 'RETIREMENT_OR_TRANSFER_UNPERFORMED' in row['residuals'],
                 'L07_STRONGER_CLAIM_MUST_REMAIN_SEPARATE')
    exact(gates, ('G1', 'G3'))
    for name, scope in (('G1', 'PROSPECTIVE_GENUINE_ORIGINAL19_SHARED_IMAGE_PAIR'),
                        ('G3', 'EXACT_Q06_AND_L01_TO_L07_DECLARED_SCOPES')):
        row = gates[name]
        exact(row, ('scope', 'disposition', 'evidence'))
        need(row['scope'] == scope and row['disposition'] in DISPOSITIONS and type(row['evidence']) is list
             and 1 <= len(row['evidence']) <= len(FINAL_PROOF_KEYS)
             and len(set(row['evidence'])) == len(row['evidence'])
             and all(k in FINAL_PROOF_KEYS for k in row['evidence']), 'FINAL_GATE_DECISION_SCOPE')
    if gates['G3']['disposition'] == 'ACCEPTED_AT_DECLARED_SCOPE':
        need(all(row['disposition'] == 'ACCEPTED_AT_DECLARED_SCOPE' for row in rows),
             'PARTIAL_ROWS_CANNOT_GRANT_COMPLETE_G3_SCOPE')
    return {'schema': 'g132.prospective-final-row-validation.v1', 'authority': 'NONE',
            'status': 'PROSPECTIVE_ROW_FORMAT_AND_RETAINED_JOIN_VALIDATED',
            'retained_m4': retained, 'original_consumer_executed': False, 'live_g1_or_g3_proven': False,
            'new_awards': [], 'hosted_integration_review_and_fresh_binding_required': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence-directory', required=True, type=Path)
    args = parser.parse_args()
    value = receive_exact_m4(read_m4_bodies(args.evidence_directory))
    print(json.dumps(value, sort_keys=True, separators=(',', ':')))


if __name__ == '__main__':
    try:
        main()
    except Refusal as exc:
        print(json.dumps({'status': 'REFUSED', 'code': str(exc), 'authority': 'NONE', 'original_effect': False}))
        raise SystemExit(1)
