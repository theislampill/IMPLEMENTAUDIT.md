"""Synthetic public documents only; no host, consumer, or root environment."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import time
import unittest

HERE = Path(__file__).resolve().parent
FROZEN = Path('/workspace/scratch/095d3235c921/evidence/g132-portability/upstream-approved/g3_receiving.py')
RUN = '999999991'
DIGEST = 'b' * 64


def encoded(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()


def component():
    now = time.time_ns() // 1000000 - 1000
    request = {
        'schema': 'dg16.g3-root-consumption-request.v2', 'authority': 'NONE',
        'source_commit': 'e76a07b2bae7c945e5a9d529ed8cf9069f4c9064',
        'source_tree': 'ff9fc6793892147aecc59bdfc4ddb82fc37f9eb7',
        'source_parent': '8c393aa0d415e3bb4f25d333316b3abaf498e5af',
        'run_id': RUN, 'attempt': 1, 'nonce': 'a' * 32,
        'control_branch': 'pro/dg16-g1-g3-control-32-20261114',
        'control_path': 'qualification/dg16-r5-g3/ROOT_DECISION.json', 'root': 'R5_ROOT', 'join': 'DG16_COMPONENT_JOIN',
        'original_scope_sha256': '8c08f2aecd34f582f3662b5bc83b3d3a27cee33d2f17711ced868a1d7b11c96a',
        **{k: DIGEST for k in ('graph_sha256', 'dispatch_sha256', 'transition_sha256', 'join_sha256',
                               'scope_return_sha256', 'g1_return_sha256', 'complete_input_key')},
        'returned_nodes': ['G1_ORIGINAL_PAIR', 'HOST_SCOPE_RECEIVING'], 'issued_unix_ms': now,
        'expires_unix_ms': now + 300000, 'hold_seconds': 300,
        'shared_expires_unix_ms': now + 600000, 'shared_window_seconds': 600,
        'decision_before': 'WAITING_FOR_G1_AND_HOST_SCOPE',
        'decision_after': 'SCOPED_RETURNS_RETAINED_ORIGINAL_CELL_OPEN',
        'original_total': 157, 'original_awards': 0,
        'full_g2': 'NOT_DISPATCHED_OR_CONSUMED_IN_THIS_HOST', 'status': 'ROOT_REQUEST_READY'}
    decision = {
        'schema': 'dg16.g3-root-consumption-decision.v2', 'issuer': 'R5_ROOT_GOVERNOR',
        'successor': 'PRO-EXECUTOR-01, designated by owner', 'action': 'CONSUME_COMPONENT_RETURNS_ONLY',
        'request_sha256': hashlib.sha256(encoded(request)).hexdigest(),
        **{k: request[k] for k in ('run_id', 'attempt', 'nonce', 'source_commit', 'source_tree', 'graph_sha256',
                                  'dispatch_sha256', 'join_sha256', 'decision_before', 'decision_after', 'full_g2', 'expires_unix_ms')},
        'outputs': {'G1_ORIGINAL_PAIR': DIGEST, 'HOST_SCOPE_RECEIVING': DIGEST},
        'consumed_nodes': ['G1_ORIGINAL_PAIR', 'HOST_SCOPE_RECEIVING'],
        'owner_arrangement': 'SELECTIVE_PARALLEL_EXISTING_OWNERS_DG16_SOLE_SHARED_WRITER',
        'original_awards': 0, 'issued_unix_ms': now + 500}
    return request, decision


def final_documents(owner):
    initial, _ = component()
    now = initial['issued_unix_ms']
    facts = {'schema': 'dg16.g3-g1-actual-facts.v2', 'source_commit': initial['source_commit'], 'source_tree': initial['source_tree'],
        'native_prerequisite_profile': 'DG16_8EE4_LINUX_CHANGED_NATIVE_BINDING_V1',
        'native_prerequisite_receiving_sha256': DIGEST, 'native_predicates': ['fixed_receiver_identity', 'wrong_receiver_refusal',
        'current_native_intake', 'later_invalidation_refusal', 'host_and_diagnosed_intake'],
        'native_prerequisite_scope': 'ACTUALLY_CONSUMED_G0001_PREDICATES', 'raw_receiving_sha256': DIGEST,
        'actual_dispatches': 2, 'validated_actual_events': 38, 'retained_artifacts': 12,
        'original_children_exit_codes': [0, 0], 'producer_closing_sha256': DIGEST, 'maintained_elapsed_ns': 1000,
        'enclosing_elapsed_ns': 2000, 'zero_subtracted_ns': 0, 'producer_watchdog_seconds': 120,
        'per_process_cpu_seconds': 90, 'watchdog_events': 0, 'cleanup_errors': 0, 'wait4_reaped': True,
        'process_group_absent': True, 'measured_outer_wait4_max_rss_kib': 100,
        'max_rss_scope': 'ACTUAL_OUTER_WAIT4_OBSERVATION_NOT_WINDOWS_WHOLE_JOB',
        'runtime_mounted_bytes': 1000, 'runtime_unique_bytes': 1000, 'runtime_logical_bytes': 1000,
        'actual_source_files': 1766, 'actual_source_bytes': 167022772,
        'runtime_physical_limit_bytes': 134217728, 'source_acquisition_limit_bytes': 268435456,
        'image_readback': 'COMPLETE_CAPTURED_SOURCE_RUNTIME_BYTES_MODES_ALIASES',
        'operation_scope': 'PROSPECTIVE_GENUINE_ORIGINAL19_SHARED_IMAGE_PAIR',
        'producer_original48_qualification': False, 'whole_DG16_awarded': False}
    request = {'schema': 'dg16.g3-original-receiving-request.v2', 'authority': 'NONE',
        **{k: initial[k] for k in ('source_commit', 'source_tree', 'source_parent', 'run_id', 'attempt', 'nonce',
                                  'control_branch', 'original_scope_sha256')},
        'control_path': 'qualification/dg16-r5-g3/ORIGINAL_DECISION.json',
        'initial_request_sha256': hashlib.sha256(encoded(initial)).hexdigest(),
        'proofs': {k: DIGEST for k in owner['FINAL_PROOF_KEYS']},
        'initial_graph_sha256': DIGEST, 'final_graph_sha256': DIGEST, 'continuity_generation': 'G0002',
        'current_receipt_sha256': DIGEST, 'component_return_nodes': ['G1_ORIGINAL_PAIR', 'HOST_SCOPE_RECEIVING'],
        'consumed_join': 'DG16_COMPONENT_JOIN', 'root': 'R5_ROOT', 'actual_stale_result': 'RECOMPUTE_REQUIRED',
        'final_selected': [], 'original_ids': list(owner['ORIGINAL_IDS']),
        'original_scopes': dict(zip(owner['ORIGINAL_IDS'], owner['ORIGINAL_SCOPES'])), 'g1_facts': facts,
        'retained_original_total': 157, 'g1_input_scope': 'ACTUALLY_CONSUMED_G0001_COMPLETE_SOURCE_GIT_HIDDEN_AND_RUNTIME',
        'g1_complete_input_key': DIGEST, 'g3_current_scope': 'CURRENT_G0002_AFTER_SUPPORTED_ROOT_CONSUMPTION_AND_REDERIVATION',
        'input_change_reason': 'ACTUAL_CAPTURE_INCLUDES_CANONICAL_FILES_CHANGED_BY_ROOT_JOIN_AND_OWNER_GENERATION',
        'actual_original_awards': 'ROOT_DECISION_PENDING',
        'original_scope': 'EXACT_ORIGINAL_ID_AND_GATE_DECISIONS_REQUIRE_ROOT_AND_INDEPENDENT_APPLICABILITY',
        'v041_admission': 'PENDING_NOT_GRANTED_BY_THIS_EPISODE', 'global_liveness': 'NOT_ESTABLISHED',
        'retirement_or_transfer': 'NOT_PERFORMED', 'full_g2': 'NOT_DISPATCHED_OR_CONSUMED_IN_THIS_HOST',
        'whole_DG16_awarded': False, 'shared_window_started_unix_ms': now, 'issued_unix_ms': now,
        'expires_unix_ms': now + 600000, 'shared_window_seconds': 600,
        'status': 'FINAL_ROOT_DECISION_REQUIRED_WHILE_CURRENT'}
    rows = [{'id': n, 'scope': s, 'disposition': 'PARTIAL_SCOPE_ONLY', 'evidence': ['module'],
             'residuals': ['NATURAL_RLGWO_PREREQUISITE_UNRECEIVED'] if n == 'R35-L04' else
             ['GLOBAL_LIVENESS_UNPROVED', 'RETIREMENT_OR_TRANSFER_UNPERFORMED'] if n == 'R35-L07' else
             ['ORIGINAL_CONJUNCTION_NOT_ESTABLISHED']}
            for n, s in zip(owner['ORIGINAL_IDS'], owner['ORIGINAL_SCOPES'])]
    decision = {'schema': 'dg16.g3-root-original-decision.v2', 'issuer': 'R5_ROOT_GOVERNOR',
        'successor': 'PRO-EXECUTOR-01, designated by owner', 'action': 'RECEIVE_EXACT_ORIGINAL_IDS_AND_GATES',
        'request_sha256': hashlib.sha256(encoded(request)).hexdigest(),
        **{k: request[k] for k in ('run_id', 'attempt', 'nonce', 'source_commit', 'source_tree', 'final_graph_sha256',
                                  'current_receipt_sha256', 'proofs', 'whole_DG16_awarded', 'full_g2', 'v041_admission',
                                  'global_liveness', 'retirement_or_transfer', 'expires_unix_ms')},
        'independent_review_sha256': DIGEST, 'source_applicability_review_sha256': DIGEST,
        'original_rows': rows,
        'gate_decisions': {n: {'scope': s, 'disposition': 'PARTIAL_SCOPE_ONLY', 'evidence': ['module']} for n, s in
                          [('G1', 'PROSPECTIVE_GENUINE_ORIGINAL19_SHARED_IMAGE_PAIR'), ('G3', 'EXACT_Q06_AND_L01_TO_L07_DECLARED_SCOPES')]},
        'issued_unix_ms': now + 500}
    return request, decision


class HostedValidateTests(unittest.TestCase):
    def adapter(self):
        path = HERE / 'g132_hosted_validate.py'
        self.assertTrue(path.is_file(), 'MISSING_READ_ONLY_HOSTED_VALIDATOR')
        spec = importlib.util.spec_from_file_location('g132_hosted_validate', path)
        mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        return mod

    def test_current_component_request_is_schema_only(self):
        mod = self.adapter(); request, _ = component()
        value = mod.validate_bytes(FROZEN.read_bytes(), 'components', RUN, encoded(request))
        self.assertEqual(value['request_sha256'], hashlib.sha256(encoded(request)).hexdigest())
        self.assertEqual(value['authority'], 'NONE')
        self.assertFalse(value['native_history_authenticated'])
        self.assertFalse(value['original_consumer_invoked'])
        self.assertFalse(value['original_acceptance'])
        self.assertNotIn('raw', value)

    def test_exact_component_decision_join(self):
        mod = self.adapter(); request, decision = component()
        value = mod.validate_bytes(FROZEN.read_bytes(), 'components', RUN, encoded(request), encoded(decision))
        self.assertEqual(value['decision_sha256'], hashlib.sha256(encoded(decision)).hexdigest())

    def test_exact_final_request_and_decision(self):
        mod = self.adapter(); request, decision = final_documents(mod.pure_owner(FROZEN.read_bytes()))
        value = mod.validate_bytes(FROZEN.read_bytes(), 'original-final', RUN, encoded(request), encoded(decision))
        self.assertEqual(value['stage'], 'original-final')
        self.assertFalse(value['original_acceptance'])

    def test_wrong_run_is_refused_even_when_schema_is_valid(self):
        mod = self.adapter(); request, _ = component()
        with self.assertRaisesRegex(mod.Refusal, 'SELECTED_RUN_MISMATCH'):
            mod.validate_bytes(FROZEN.read_bytes(), 'components', '999999992', encoded(request))

    def test_expired_request_is_not_rebased(self):
        mod = self.adapter(); request, _ = component()
        for name in ('issued_unix_ms', 'expires_unix_ms', 'shared_expires_unix_ms'):
            request[name] -= 700000
        with self.assertRaisesRegex(mod.Refusal, 'ORIGINAL_REQUEST_NOT_CURRENT'):
            mod.validate_bytes(FROZEN.read_bytes(), 'components', RUN, encoded(request))

    def test_wrong_stage_and_unknown_stage_refused(self):
        mod = self.adapter(); request, _ = component()
        for stage in ('original-final', 'consume'):
            with self.subTest(stage=stage), self.assertRaises(Exception):
                mod.validate_bytes(FROZEN.read_bytes(), stage, RUN, encoded(request))

    def test_decision_nonce_cannot_differ(self):
        mod = self.adapter(); request, decision = component(); decision['nonce'] = 'c' * 32
        with self.assertRaisesRegex(Exception, 'ROOT_DECISION_BINDING'):
            mod.validate_bytes(FROZEN.read_bytes(), 'components', RUN, encoded(request), encoded(decision))

    def test_changed_source_not_imported_or_executed(self):
        mod = self.adapter(); request, _ = component()
        with self.assertRaisesRegex(mod.Refusal, 'EXACT_FROZEN_G3_SOURCE_REQUIRED'):
            mod.validate_bytes(FROZEN.read_bytes() + b'\nraise RuntimeError("must not execute")\n', 'components', RUN, encoded(request))

    def test_pure_namespace_has_no_original_consumer_or_host_context(self):
        mod = self.adapter(); owner = mod.pure_owner(FROZEN.read_bytes())
        self.assertNotIn('consume', owner); self.assertNotIn('decide', owner); self.assertNotIn('context', owner)
        self.assertNotIn('os', owner); self.assertNotIn('urllib', owner)

    def test_noncanonical_request_and_duplicate_key_refused(self):
        mod = self.adapter(); request, _ = component(); raw = encoded(request)
        for malformed in (raw.rstrip(b'\n'), b'{"schema":"other",' + raw[1:]):
            with self.subTest(case=malformed[:20]), self.assertRaises(Exception):
                mod.validate_bytes(FROZEN.read_bytes(), 'components', RUN, malformed)

    def test_readback_requires_body_pin_and_refuses_symlink(self):
        mod = self.adapter(); request, _ = component(); raw = encoded(request)
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / 'request.json'; p.write_bytes(raw); p.chmod(0o600)
            self.assertEqual(mod.read_pinned(p, hashlib.sha256(raw).hexdigest(), 16384), raw)
            with self.assertRaisesRegex(mod.Refusal, 'SELECTED_BODY_PIN'):
                mod.read_pinned(p, 'a' * 64, 16384)
            alias = Path(tmp) / 'alias.json'; alias.symlink_to(p)
            with self.assertRaisesRegex(mod.Refusal, 'CANONICAL_BODY_PATH'):
                mod.read_pinned(alias, hashlib.sha256(raw).hexdigest(), 16384)


if __name__ == '__main__':
    unittest.main(verbosity=2)
