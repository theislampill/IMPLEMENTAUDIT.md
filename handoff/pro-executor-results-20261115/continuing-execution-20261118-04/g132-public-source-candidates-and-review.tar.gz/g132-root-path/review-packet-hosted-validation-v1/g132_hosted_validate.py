#!/usr/bin/env python3
"""Read-only Pro callback shim for actual received public G3 documents.

Only byte-pinned original pure validator definitions are compiled. No original
module import, consumer, context function, main entry, decorator, process or
network API is loaded. This checks public schema/bytes/time/run joins only.
Actual provider authentication, current Root authority, cross-session replay
state, publication, protected-host execution and acceptance remain separate.
"""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import time

SOURCE_BYTES = 153706
SOURCE_SHA256 = 'b85cca1550ff8e7c1c89778180e53a5c70f306f0c8725ba60ef3ccd4bbc3a6ad'
PURE_FUNCTIONS = frozenset(('need', 'sha', 'encode', 'parse', 'exact', 'digest', 'integer',
    'validate_g1_facts', 'validate_public_request', 'validate_decision', 'validate_public_final_request',
    'validate_row_decisions', 'validate_final_decision'))
PURE_CONSTANTS = frozenset(('SOURCE_COMMIT', 'SOURCE_TREE', 'SOURCE_PARENT', 'SOURCE_FILES', 'SOURCE_BYTES',
    'SCOPE_SHA', 'CONTROL_BRANCH', 'CONTROL_PATH', 'FINAL_CONTROL_PATH', 'ROOT', 'JOIN', 'PAIR', 'SCOPE',
    'SELECTED', 'OWNER_ARRANGEMENT', 'BEFORE', 'AFTER', 'ORIGINAL_IDS', 'ORIGINAL_SCOPES',
    'DISPOSITIONS', 'RESIDUALS', 'FINAL_PROOF_KEYS', 'NATIVE_PREREQUISITE_PROFILE', 'NATIVE_PREDICATES',
    'FILE_LIMIT', 'REQUEST_LIMIT', 'DECISION_LIMIT', 'HOLD_SECONDS'))


class Refusal(ValueError):
    pass


def need(ok, code):
    if not ok:
        raise Refusal(code)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def pure_owner(raw):
    """Compile only the exact original public-schema validator dependency set."""
    need(type(raw) is bytes and len(raw) == SOURCE_BYTES and sha(raw) == SOURCE_SHA256,
         'EXACT_FROZEN_G3_SOURCE_REQUIRED')
    tree = ast.parse(raw)
    selected = []
    seen_functions = set()
    seen_constants = set()
    for node in tree.body:
        if isinstance(node, ast.Assign):
            names = {part.id for target in node.targets for part in ast.walk(target) if isinstance(part, ast.Name)}
            if names & PURE_CONSTANTS:
                need(not any(isinstance(part, (ast.Call, ast.Attribute, ast.Subscript, ast.Lambda))
                             for part in ast.walk(node.value)), 'PURE_CONSTANT_EXPRESSION_ONLY')
                selected.append(node)
                seen_constants.update(names & PURE_CONSTANTS)
        elif isinstance(node, ast.ClassDef) and node.name == 'Refusal':
            need(not node.decorator_list and len(node.body) == 1 and isinstance(node.body[0], ast.Pass),
                 'PURE_REFUSAL_CLASS_ONLY')
            selected.append(node)
        elif isinstance(node, ast.FunctionDef) and node.name in PURE_FUNCTIONS:
            need(not node.decorator_list, 'PURE_VALIDATOR_NO_DECORATOR')
            selected.append(node)
            seen_functions.add(node.name)
    need(seen_functions == PURE_FUNCTIONS and seen_constants == PURE_CONSTANTS, 'PURE_VALIDATOR_POPULATION')
    namespace = {'hashlib': hashlib, 'json': json, 're': re}
    exec(compile(ast.Module(body=selected, type_ignores=[]), '<byte-pinned-original-public-validators>', 'exec'), namespace)
    return namespace


def validate_bytes(source_raw, stage, selected_run_id, request_raw, decision_raw=None):
    need(stage in ('components', 'original-final'), 'EXACT_PUBLIC_G3_STAGE')
    need(type(selected_run_id) is str and re.fullmatch('[1-9][0-9]{5,19}', selected_run_id), 'SELECTED_RUN_SHAPE')
    owner = pure_owner(source_raw)
    request = owner['validate_public_request' if stage == 'components' else 'validate_public_final_request'](request_raw)
    need(request['run_id'] == selected_run_id and request['attempt'] == 1, 'SELECTED_RUN_MISMATCH')
    now = time.time_ns() // 1000000
    need(request['issued_unix_ms'] <= now < request['expires_unix_ms'], 'ORIGINAL_REQUEST_NOT_CURRENT')
    request_sha = sha(request_raw)
    value = {'schema': 'g132.exact-original-public-g3-validation.v1', 'authority': 'NONE',
        'stage': stage, 'run_id': selected_run_id, 'attempt': 1,
        'request_sha256': request_sha, 'request_bytes': len(request_raw),
        'source': {'bytes': SOURCE_BYTES, 'sha256': SOURCE_SHA256},
        'expires_unix_ms': request['expires_unix_ms'],
        'qualification': 'STRICT_ORIGINAL_PUBLIC_SCHEMA_BYTES_TIME_AND_SELECTED_RUN_ONLY',
        'native_history_authenticated': False, 'provider_metadata_authentication': 'SEPARATE_ORIGINAL_RECEIVER_REQUIRED',
        'original_consumer_invoked': False, 'original_acceptance': False, 'new_awards': []}
    if decision_raw is not None:
        owner['validate_decision' if stage == 'components' else 'validate_final_decision'](
            decision_raw, request, request_sha, time.time_ns() // 1000000)
        value['decision_sha256'] = sha(decision_raw)
        value['decision_bytes'] = len(decision_raw)
    need(time.time_ns() // 1000000 < request['expires_unix_ms'], 'ORIGINAL_REQUEST_NOT_CURRENT')
    return value


def read_pinned(path, expected_sha256, maximum):
    need(type(expected_sha256) is str and re.fullmatch('[0-9a-f]{64}', expected_sha256), 'BODY_PIN_SHAPE')
    path = Path(path)
    need(path.is_absolute() and path.resolve(strict=True) == path, 'CANONICAL_BODY_PATH')
    info = path.lstat()
    need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_uid == os.geteuid()
         and not info.st_mode & 0o022 and 0 < info.st_size <= maximum, 'ORDINARY_OWNED_BOUNDED_BODY')
    mark = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_uid, s.st_gid,
                      s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        need(mark(os.fstat(fd)) == mark(info) and not os.listxattr(fd), 'BODY_OPEN_CHANGED')
        raw = os.pread(fd, maximum + 1, 0)
        need(len(raw) == info.st_size and mark(info) == mark(os.fstat(fd)) == mark(path.lstat())
             and path.resolve(strict=True) == path, 'BODY_CLOSING_CHANGED')
    finally:
        os.close(fd)
    need(sha(raw) == expected_sha256, 'SELECTED_BODY_PIN')
    return raw


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--stage', required=True, choices=('components', 'original-final'))
    parser.add_argument('--run-id', required=True)
    parser.add_argument('--request', required=True, type=Path)
    parser.add_argument('--request-sha256', required=True)
    parser.add_argument('--decision', type=Path)
    parser.add_argument('--decision-sha256')
    args = parser.parse_args()
    need((args.decision is None) == (args.decision_sha256 is None), 'DECISION_PATH_AND_PIN_TOGETHER')
    source = read_pinned(args.source, SOURCE_SHA256, SOURCE_BYTES)
    request = read_pinned(args.request, args.request_sha256, 16384)
    decision = read_pinned(args.decision, args.decision_sha256, 16384) if args.decision is not None else None
    value = validate_bytes(source, args.stage, args.run_id, request, decision)
    print(json.dumps(value, sort_keys=True, separators=(',', ':')))


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        code = str(exc) if re.fullmatch('[A-Z][A-Z0-9_]{0,127}', str(exc)) else 'READ_OR_VALIDATION_REFUSED'
        print(json.dumps({'status': 'REFUSED', 'code': code, 'authority': 'NONE', 'original_consumer_invoked': False}))
        raise SystemExit(1)
