# Independent DG17 continuation: receiving and executable frontier

**Disposition:** prior accepted evidence and identities are preserved; two concrete model-policy work cells are now ready for the next appropriate owner. The causal-stop comparison is independently received for Root's baseline-first dispatch. A new no-lift comparison has passed bounded fixture/interface checks and is ready for a separate nonauthor's pre-dispatch review. **No new original case, mutation-family, terminal-clause or whole-DG17 acceptance is awarded by this worker.**

Report state: FINAL for this bounded continuation. Subsequent actor outcomes require a separate receiving record; this report is not a prediction of them.

Reviewer/worker: `/root/g2_live_independent_20261118`. Runtime-declared model: GPT-6 Astra Pro. Role: ordinary independent engineering/receiving under Root's continuing commission, not a governor-routed `audit-assess` invocation. Authority: NONE. Root remains the sole integration writer, publisher, dispatcher and original-acceptance owner.

## 1. Exact published and recovered identities

The isolated checkout is at published results commit **afda760d6de5cac08a27ad86da4c2be981749354**, tree **9b08a90f437eaedbee331ad3b922f6fe791929e4**, detached from `engineering/pro-executor-original-completion-20261115`. Its complete 50-file checkpoint manifest was independently checked against local bytes, SHA-256 and Git blob identity. The checkout remains clean.

The accepted DG17 source remains separately bound to **a297957be11feb494c0ec467235794a1e0c54751**, tree **b08dc4ecf4028beeedb579a312eccae23cb5d863**. The results checkout is not substituted for that source. Exact source objects were fetched into the isolated clone, and the causal-stop owner was also obtained through the connected GitHub file tool at that exact ref. The exact source skill population is the governor plus `audit-andon`, `audit-assess`, `audit-implement` and `audit-state`.

The connected GitHub issue readback still reports #211 open. Its body is 64,795 UTF-8 bytes, SHA-256 **ca62f4899a45544549f623a0312c16121bb99f432ccb87a87b7361974ceb94c4**. All four current comment bodies exactly match the retained identities: the terminal-cap amendment, native turn-exit amendment, shared receiving amendment and prospective durable cross-retention undertaking. No denominator or acceptance text changed.

Root then identified the old workspace at `/workspace/scratch/095d3235c921`. It contains the unpushed `continuing-execution-20261118-02` checkpoint and later raw DG17 work. This worker treated that workspace as read-only and received its originals before executing anything new. Publication of those recovered bytes remains a separate Root action.

The DG17 checkpoint archive is **1,198,729 bytes**, SHA-256 **1fcaf0721503c956d2ae647ecc7768b43ce4159832d453d7edcc5eb43772ab5f**. All **783 pinned files**, plus the archive manifest, were checked without extracting files to disk. The 480 declared source/link omissions remain explicit. Archive metadata is packaging data, not historical physical-custody proof. [Checkpoint receiving](receiving/CHECKPOINT_RECEIVING.json) and [archive receiving](receiving/ARCHIVE_RECEIVING.json) retain the checks.

## 2. Retained acceptance was received, not replayed

[Retained receiving](receiving/RETAINED_RECEIVING.json) independently recomputed **1,212 pin checks over 1,060 unique paths** and **238 exact-Git source comparisons over 91 distinct bodies**. Historical owners, actors and successful episodes were not rerun. All checked prior Root decisions, independent reviews, raw-source inventories and binding hashes matched.

| Prior decision or predicate | Retained supported scope | Boundary preserved |
| --- | --- | --- |
| N11 / M13 | Actual canonical JOIN-owner refusal; single-guard mutant discrimination | Structural source consumer; no native/model activation award |
| B05 | Initial N11 fixture confound preserved; independent Root repair justification precedes the corrected pair | The failure and oracle remain visible; no manufactured product runtime RED |
| H04 | Actual omitted required JOIN blocked the downstream consumer and its explicitly projected L5 required claim | Projection remains constructed; no automatic graph-to-L5 bridge claim |
| N12 | Actual terminal record consumer rejected false-green closure with the authentic failed predicate retained | Record-consumer scope; no native/current lifecycle transfer |
| B03 | Exact delivered unchanged reminder, actual read-only check, twelve unchanged file identities/inodes/mtimes | Bounded commission; no unrestricted scheduler generalization |
| M02 | Actual CompletionContract selectively invalidated/recomputed the affected dependency while preserving two unaffected results | No automatic whole P02/B04/H05 phase/currentness conjunction |
| M05 | Actual required-claim predicate refused unresolved closure; sole-guard mutant admitted the forbidden result | No authentic lifecycle closure or complete L5 award |
| M04, M12, M14, N02 | Exact-candidate guard, supplied-authority guard, selector flag/mode and historical-PASS non-substitution conjuncts | Each remains narrower than the complete original family/case |

The original N11 and M04 confounds and the separate before-rerun repair justifications are retained. Earlier accepted H02/P06 and other valid historical scopes are preserved unchanged. P07's prior successful operational routing/return/rederivation evidence remains historical evidence; this worker did not turn it into a fresh model or native witness.

Actual reviewer identities remain distinguishable. The N11/B05 and H04 receiving reports identify `/root/g2_independent/g132_bridge_review`; the later mutation/retained-eligibility reports identify `/root/dg18_execution`; the original ordinary author is `/root/dg17_execution`; the acceptance decisions identify `/root`. This worker read those reports as prior evidence and makes no claim of blindness to their findings.

## 3. New independent receiving of the N07 caller discriminator

The previously unreceived N07 episode was examined without rerunning it. The review checked all 82 manifest members, seven exact-a297 source objects, twenty raw streams, the frozen preimage/driver, actual effect bytes, and ordering after the execution seal.

| Actual retained arm | Original checker exit | Caller exit | Continuation effect | Caller-visible abnormality |
| --- | ---: | ---: | --- | --- |
| Valid-input control | 0 | 0 | Present | No failure to signal |
| Stop and expose | 1 | 1 | Absent | Present |
| Expose and continue | 1 | 0 | Present | Present |
| Stop and hide | 1 | 0 | Absent | Absent |

This is a real behavioral discriminator: one caller propagated despite a visible failed check; another stopped but hid the failure. The hidden arm's separately retained forensic output is not counted as a caller-visible signal. The same actual original checker supplied the refusal in all negative arms.

**Receivable scope:** actual constructed-caller propagation/visibility discrimination. No artifact correction is needed at that scope. The canonical governor does not itself select those constructed caller policies, and this packet does not show it enforcing the correct one. That is the exact remaining control binding for broader N07/M06 qualification. This review imposes no blanket native/model prerequisite on an otherwise structural predicate, but it also does not turn a same-author comparison wrapper into canonical governor behavior. [N07 receiving](receiving/N07_RECEIVING.json) records the result and limits.

## 4. Causal-stop comparison: ready for Root dispatch

The recovered source-policy packet was genuinely unexecuted. Its first independent review found a concrete observation defect: count-based capture numbering could collide if calls overlapped, while the prompts did not require sequential calls. The separately retained amendment adds identical sequential-await and stop-on-incomplete-capture instructions to both prompts. Facts, expected outcomes, source mutation and thresholds are unchanged.

This worker independently checked all sixteen original packet members; exact original governor and progressive causal-owner bytes against a297; the single complete exit-rule substitution; all three acyclic evidence chains; required versus no-payoff record boundaries; mission neutrality; prompt equality apart from the actor path; exact amendment insertion; and absence of actor live directories at receiving.

The old workspace is read-only, so the packet was copied byte-for-byte into this worker's directory. New dispatch prompts change only five absolute actor-path prefixes per arm. Every original member and original seal remains unchanged in the copy. The successor seal binds those preserved originals and the new prompts. This path-only prompt authorship is disclosed; Root must inspect the delta and retain the exact delivered scalar.

The three cases test a complete short actionable cause, an eight-link maintained-cause investigation, and an unavailable-evidence/no-payoff boundary. They are constructed incidents, not recreated production history. The oracle evaluates actual requested observations, supported diagnoses and justified recommendations; counts and different prose alone are insufficient.

Use the exact prompts under `causal-observation-20261118/dispatch-successor/`, starting with cobalt. A correct original arm is required before any mutant discrimination can be claimed. The unchanged governor's broader evidence discipline may override the copied fixed-count rule; that outcome would be a surviving mutant, not permission to adapt the oracle.

[Independent receiving](receiving/CAUSAL_PACKET_RECEIVING.json) and [successor seal](causal-observation-20261118/SUCCESSOR_SEAL.json) are final for this prospective state. Root owns fresh `fork_turns=none` dispatch, actual exposed model/configuration identity, raw returns and original adjudication. No actor outcome has been authored or inferred here.

## 5. New no-lift comparison: executable preparation completed

The retained V4 frontier named M08 as the next designable model-policy cell. This worker implemented that bounded preparation rather than stopping at an inventory.

The actual owner is the lesson-lift section of `skills/implementaudit/templates/PROTOCOL.md` at a297. Its original full file has 74,155 bytes and SHA-256 **24b5079e1cacdbb8d195d94d48e82f5683e915424aaf3fb8514a282dd3396c5c**. The selected 2,006-byte original excerpt includes the complete trigger/no-trigger rule, canonical record fields, authority limits, current-check requirements and future-prevention boundary. The sole semantic mutation removes the no-trigger exemption by treating every correction as a qualifying lesson; the remaining record requirements are unchanged. Full original/mutant files and the exact diff are retained.

Two fresh disposable projects supply concrete task behavior. One is a low-consequence spelling correction with an existing adequate check. The other converts decimal durations into hundredths; its float truncation actually fails on 1.15 and 2.30 while existing integer-only checks pass. Those two function observations occur within one captured pre-dispatch check, not two independent historical production incidents. The concrete checker omission supplies the qualifying lesson premise.

Five actual fixture-preflight subprocesses established that the original notice check fails, the corrected reference passes, existing converter checks pass, fractional witnesses fail, and a separate corrected converter reference passes the unchanged six-value oracle. These are fixture controls, not a canonical product RED and not actor outcomes.

Twelve focused observations on separate workbench copies then checked complete guidance/list/read results, real failing/passing checks, actual edits, full conversion verification, immutable-input refusal, outside-path refusal and refusal after a deliberately incomplete prior capture. All checks passed. Candidate actor directories remained unexecuted and unchanged.

The model observation interface records every operation, complete output and before/after file identities. Its read/write boundaries are declared task containment, not a native OS security guarantee. Immutable unrelated inputs cannot serve as M09 model-policy proof; this experiment claims no such credit. The two tasks share each actor context and are not independent replications.

The fixed oracle requires correct work in both projects, no unnecessary notice lift record/artifact, and one truthful reasoned record for the qualifying task. A reasoned no-lift decision remains legal; the oracle does not force gratuitous persistent files. An active checker claim requires a real observed pass; later prevention remains unavailable.

This worker authored the new packet and **cannot be its independent pre-dispatch reviewer**. A separate nonauthor must receive it. Then Root may dispatch willow first and retain all baseline/non-verdict/mutant outcomes without hidden retries. The packet is [sealed](maintenance-observation-20261118/PACKET_SEAL.json); its [README](maintenance-observation-20261118/README.md), [design](M08_DESIGN.md), [fixture preflight](maintenance-observation-20261118/PREFLIGHT.json) and [workbench checks](maintenance-workbench-checks/RESULT.json) provide the complete review surface.

## 6. Original population and exact remaining frontier

[CURRENT_FRONTIER.json](CURRENT_FRONTIER.json) retains the exact **17 terminal clauses, 36 original cases and 14 mutation families**, the live original body identity, the unchanged V4 history and the bounded updates made here. It neither edits nor replaces the old census.

The five original rows explicitly accepted by the recovered current Root projection are N11, B05, H04, N12 and B03, with their exact stated layers. Its three accepted mutation predicates are M13, M02 and M05. Other valid earlier history remains usable at its original scopes; these numbers are not a claim that all other historical work is invalid or absent.

| Frontier | Exact next action or missing discriminator |
| --- | --- |
| P09/N08/M07 | Root dispatches the independently received original causal-policy arm, then decides whether the mutant arm is warranted; independent outcome receiving follows |
| M08, related N09 limb | Separate nonauthor receives the new maintenance packet before Root dispatch; no current model verdict |
| N07/M06 | Newly received actual caller discriminator is usable; canonical selection/enforcement remains open |
| P10 and reached-owner P04/B02 | Prior literal evidence remains available for Root's bounded adjudication; exact-a297 P04 host interpreter admission remains separately refused |
| P02/B04/H05 | Selective dependency consumer predicate is accepted; complete formal phase/currentness/re-entry conjunction remains distinct |
| P01/P05/P06/P07/P08/H01/H02/B01/H06 | Preserve operational observations and failures; original complete model-control/input-recording qualification remains open at the exact documented gaps |
| P03 | Historical terminal Andon recording defect cannot be repaired retrospectively |
| N01/N02 | Required-claim and historic-PASS non-substitution evidence does not supply every original phase/current-review predicate |
| N03/N04/N05 | Actual warranted maintainer admission or actual adversarial child/caller return and containment remain unsupplied; no synthetic route/return is substituted |
| N06/M01/M03 | Exact interrupt or Smoke transition owner variants and actual same-predicate consumers remain necessary; generic label wrappers do not qualify |
| N10/H03 | A real semantic fixed-loop/renamed-child consumer comparison remains to be isolated and qualified |
| B06/H08 | Actual complete same-candidate lower-layer premises and the specific unresolved required obligation/leg must be bound; pass flags are insufficient |
| H07/M10/M11 | Missing distinct-caller raw returns/decisions and child-return/rederivation ownership evidence remain concrete gaps |
| M04/M12/M14 | Received guard/selector conjuncts remain narrower than full repair/reaudit, no-chain/authority and downstream cheap-path families |
| M09 | A prospective exact-source unrelated-work policy comparison remains designable; this worker's workbench permission guard does not qualify it |

No new whole terminal clause is awarded. T1/T2 still require the actual final candidate/custody and complete owner/JOIN binding; T3's population evidence remains structural; T4/T6/T7/T8/T9/T13 retain their unproved composed behavior; T5 remains an evidence-backed Root delta decision; T10/T11 are not enlarged by evidence-only additions; T12's applicable native discovery/routing remains unproved; T14 requires fresh final-candidate review/applicable CI; and T15/T16/T17 preserve evidence ceilings, exact authorized publication/readback and manual closure dependencies. The frontier file carries each literal clause and its individual boundary.

Native turn-exit/session conditions, currentness, historical private custody and full original acceptance were not manufactured. Unknown historical effects stay unknown. G2's frozen original review/addendum were not changed, and this DG17 work makes no G2/M2 award.

## 7. Boundary, effects and handoff

A host compaction occurred during this ordinary worker assignment. The supplied controller lookup first found no Git repository at the scratch root, then no controller in the isolated clone. Root explicitly reissued ordinary-worker continuation, directed reconciliation of the old workspace, and forbade inventing a child receipt or invalidating Root custody. The pre-boundary clone was waited on and observed completed before new work. No controller, invalidation or currentness receipt was fabricated.

All authored files are under `/workspace/scratch/2678f1e431c3/dg17-continuation`. The old workspace, shared repository, canonical product source, protected subjects and frozen G2 artifacts were not mutated. No commits, pushes, tags, releases, issue changes, grants, hosted full-pair runs or original terminal awards were performed. Final file and seal verification is retained separately.

The next decision is concrete: consume the causal-packet receiving record and dispatch its baseline, and appoint a separate reviewer for the new no-lift packet. This worker can later receive causal outcomes without having authored its original fixtures/oracle; a different reviewer must receive the newly authored maintenance packet and its outcomes.
