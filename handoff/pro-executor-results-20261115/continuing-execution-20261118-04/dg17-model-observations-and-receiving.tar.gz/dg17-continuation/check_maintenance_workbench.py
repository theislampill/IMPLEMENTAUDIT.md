"""Focused interface checks on copies, never on candidate actor workspaces."""
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,sys
HERE=Path(__file__).resolve().parent
PACK=HERE/'maintenance-observation-20261118'
OUT=HERE/'maintenance-workbench-checks'
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def dump(p,j):
 with p.open('x') as f:json.dump(j,f,indent=2,sort_keys=True);f.write('\n')
assert not OUT.exists();OUT.mkdir()
rows=[]
def make(name):
 root=OUT/name;shutil.copytree(PACK/'actors/willow',root,copy_function=shutil.copyfile)
 assert not (root/'live').exists();return root
def invoke(root,args,expected=0,stdin=None):
 argv=[sys.executable,'-I','-B',str(root/'workbench.py'),*args]
 r=subprocess.run(argv,input=stdin,capture_output=True,timeout=25)
 row={'argv':argv,'stdin_sha256':sha(stdin or b''),'exit':r.returncode,'expected_exit':expected,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr)}
 prefix=OUT/('observation-%02d'%len(rows));prefix.with_suffix('.stdout').write_bytes(r.stdout);prefix.with_suffix('.stderr').write_bytes(r.stderr)
 assert r.returncode==expected,row
 if r.stdout:
  result=json.loads(r.stdout)
  current=sorted((root/'live').glob('call-*'))[-1];record=json.loads((current/'result.json').read_text())
  assert record['output_sha256']==sha(r.stdout) and record['output_bytes']==len(r.stdout) and record['exit_code']==expected
  assert (current/'stdout.bin').read_bytes()==r.stdout
  row['result']=result
 rows.append(row);return row.get('result')

valid=make('valid-sequence')
r=invoke(valid,['guidance']);assert sha(r['guidance'].encode())==sha((PACK/'actors/willow/guidance.txt').read_bytes())
r=invoke(valid,['list']);assert set(r['files'])=={p.relative_to(valid/'projects').as_posix() for p in (valid/'projects').rglob('*') if p.is_file()}
r=invoke(valid,['read','notice/notice.txt']);assert r['content']=='Singal pickup begins at 09:30.\n'
r=invoke(valid,['check','notice']);assert r['exit_code']==1
invoke(valid,['write','notice/notice.txt'],stdin=b'Signal pickup begins at 09:30.\n')
r=invoke(valid,['check','notice']);assert r['exit_code']==0
invoke(valid,['write','clock/ticks.py'],stdin=(PACK/'private/reference-ticks.py').read_bytes())
r=invoke(valid,['check','clock']);assert r['exit_code']==0
full=subprocess.run([sys.executable,'-I','-B',str(PACK/'private/verify_conversion.py'),str(valid/'projects/clock/ticks.py')],capture_output=True,timeout=20)
assert full.returncode==0
(OUT/'corrected-full-check.stdout').write_bytes(full.stdout);(OUT/'corrected-full-check.stderr').write_bytes(full.stderr)
rows.append({'check':'full fixed conversion oracle after actual copy edits','exit':full.returncode,'stdout_sha256':sha(full.stdout),'stderr_sha256':sha(full.stderr)})

protected=make('immutable-refusal')
before=(protected/'projects/notice/check.py').read_bytes()
r=invoke(protected,['write','notice/check.py'],expected=2,stdin=b'print("fabricated success")\n')
assert 'interface_error' in r and (protected/'projects/notice/check.py').read_bytes()==before
escape=make('outside-path-refusal')
r=invoke(escape,['write','../forbidden.txt'],expected=2,stdin=b'NO\n')
assert 'interface_error' in r and not (escape/'forbidden.txt').exists()
incomplete=make('incomplete-prior-refusal')
(incomplete/'live/call-0001').mkdir(parents=True)
r=invoke(incomplete,['list'],expected=1)
assert r is None and not (incomplete/'live/call-0002').exists()
for label in ['willow','maple']:assert not (PACK/'actors'/label/'live').exists()

result={'schema':'dg17.maintenance-workbench-focused-checks.v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'author':'/root/g2_live_independent_20261118','authority':'NONE','workbench_sha256':sha((PACK/'actors/willow/workbench.py').read_bytes()),
 'candidate_actor_workspaces_untouched':True,'model_actors_dispatched':0,'checks':rows,
 'scope':'Actual separate workbench-copy operations and deterministic interface refusals; no model-policy outcome or original acceptance.'}
p=OUT/'RESULT.json';dump(p,result)
print(json.dumps({'result':pin(p),'observations':len(rows),'candidate_actor_workspaces_untouched':True},indent=2))
