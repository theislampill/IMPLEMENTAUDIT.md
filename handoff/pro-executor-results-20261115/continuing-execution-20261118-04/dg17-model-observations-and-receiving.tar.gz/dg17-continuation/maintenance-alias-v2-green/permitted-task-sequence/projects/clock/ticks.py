from decimal import Decimal

def to_ticks(value):
    return int(Decimal(value) * 100)
