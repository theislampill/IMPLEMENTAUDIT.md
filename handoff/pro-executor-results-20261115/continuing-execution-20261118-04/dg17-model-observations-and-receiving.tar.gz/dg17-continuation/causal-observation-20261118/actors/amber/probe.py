"""Bounded reader for the sealed incident packet; only live captures are written."""
from pathlib import Path
import datetime, hashlib, json, sys

ROOT=Path(__file__).resolve().parent
PACKET=ROOT.parent.parent
def sha(b): return hashlib.sha256(b).hexdigest()

def main():
    args=sys.argv[1:]
    records=json.loads((PACKET/'private/incident-records.json').read_text())
    code=0
    try:
        if args==['source','skill']:
            raw=(ROOT/'guidance/SKILL.md').read_bytes()
        elif args==['source','discipline']:
            raw=(ROOT/'guidance/references/lean-operating-discipline.md').read_bytes()
        elif args==['cases']:
            raw=(json.dumps({k:v['initial'] for k,v in records.items()},indent=2,sort_keys=True)+'\n').encode()
        elif len(args)==3 and args[0]=='record':
            raw=(json.dumps(records[args[1]]['records'][args[2]],indent=2,sort_keys=True)+'\n').encode()
        else:
            raise ValueError('Allowed requests: source skill; source discipline; cases; record CASE RECORD')
    except (KeyError,ValueError) as error:
        raw=(json.dumps({'reader_error':str(error)})+'\n').encode();code=2
    live=ROOT/'live';live.mkdir(exist_ok=True)
    n=len(list(live.glob('command-*.json')))+1
    prefix=live/('command-%03d'%n)
    with prefix.with_suffix('.stdout').open('xb') as f:f.write(raw)
    row={'schema':'dg17.actual-model-incident-read.v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'argv':sys.argv,'request':args,'exit_code':code,'stdout':{'bytes':len(raw),'sha256':sha(raw)},
         'packet_records_sha256':sha((PACKET/'private/incident-records.json').read_bytes()),
         'source_skill_sha256':sha((ROOT/'guidance/SKILL.md').read_bytes()),
         'source_discipline_sha256':sha((ROOT/'guidance/references/lean-operating-discipline.md').read_bytes()),
         'authority':'NONE','writes':'this actor live capture directory only'}
    with prefix.with_suffix('.json').open('x') as f:json.dump(row,f,indent=2,sort_keys=True);f.write('\n')
    sys.stdout.buffer.write(raw)
    return code
if __name__=='__main__':raise SystemExit(main())
