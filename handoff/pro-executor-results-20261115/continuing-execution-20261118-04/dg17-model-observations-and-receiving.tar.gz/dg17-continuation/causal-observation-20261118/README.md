# Original DG17 causal-stop comparison — unexecuted packet

This packet is ready for independent pre-dispatch receiving. Root owns any actual actor dispatch, evaluator appointment and original case/family adjudication. No actor has been dispatched and no outcome is pre-awarded.

## Original obligation and scope

The unchanged original N08 row asks whether a fixed five-step policy is falsified by a one-step and a greater-than-five case. The original mutation population separately requires removing or inverting the decision-bounded 5 Whys stop rule (M07). This packet exercises those predicates through actual fresh model behavior using the exact a297 governor and its progressive causal owner. It does not depend on a Python implementation of model-executed policy, a native host callback or an internal audit-child route.

The three newly constructed incidents are explicit test fixtures. They are not represented as actual production incidents or recreated historical actor episodes. The original arm should stop after the complete actionable packing evidence, continue through the eight-record invoice dependency chain to the maintained source, and stop with two supported alternatives at the unavailable-provider-evidence boundary. The observation oracle examines actual evidence requests, supported final diagnoses and proposed actions. It does not infer private reasoning from output length or count keywords.

## Exact source and sole mutation

Target commit: `a297957be11feb494c0ec467235794a1e0c54751`, tree `b08dc4ecf4028beeedb579a312eccae23cb5d863`.

- The governor is unchanged in both actors: 21,259 bytes, SHA-256 `a6b0e2801147508766572c7dc44599da1e8a804967bc4a0a0fb8427ac21600ef`.
- The original progressive owner `skills/implementaudit/references/lean-operating-discipline.md` is 22,319 bytes, SHA-256 `ccd53a446f1a69994d5df694d206b475e969910a579cd4882f09c81f3c88401a`.
- The other source copy replaces only the complete **5 Whys Loop-Exit Protocol** decision rule with an exactly-five-observation rule. Bytes preceding and following that section are identical. This is one semantic-rule mutation, not a canonical source edit. Exact old/new bytes and a unified patch are in `private/`.

The full exit-rule section is replaced because it repeats the same evidence-bound termination policy in its initial paragraph and final exit list. Replacing only one occurrence would leave a directly contradictory copy of that same rule. All other guidance stays unchanged. The remaining general governor evidence discipline could cause a model to resist the mutant; if so, that is an actual non-kill, not permission to change the oracle or weaken the baseline.

`cobalt` is the unchanged source arm; `amber` is the policy-variant arm. These neutral public paths disclose no original case ID or expected outcome. The mapping and oracle are receiver-only material; actors receive only their exact prompt and their own reader interface.

## Controls and actual execution protocol

`private/ORACLE.json` freezes the original expectation for each incident, concrete defect conditions, all required declared controls, exact source mutation and evaluation procedure. It declares expected values, distractors, forbidden mission phrases, positive paraphrase, triviality, bloat, polarity, authority, context/no-payoff and common dependencies. The positive paraphrase is declared alternative wording, not another executed episode. Source policies are the experimental input; the neutral mission supplies no fixed-count or target-stop instruction.

Each fresh actor receives the exact corresponding `dispatch/PROMPT_*.txt` using `fork_turns="none"`, with model and reasoning overrides omitted. Root records the exact dispatched scalar, returned agent ID, all dispatch/tool non-verdicts and final response. A fresh actor does not receive the author's history, oracle or the other arm's output. Cases within one actor share context and are not independent replications.

The reader exposes two complete source reads, initial incidents and individual evidence records. It writes only that actor's owned `live/` captures. Each record includes exact argv, timestamp, source and fixture digests, stdout bytes/hash and exit. Source and case inputs remain sealed. Actors return concise findings and recommendations; they may not enact a correction, containment, publication, external query or child route. Observation counts are evidence, not an imposed baseline retry/iteration cap.

Root may run the unchanged arm first and retain a baseline failure/non-verdict before deciding whether the mutation arm would add useful evidence. A mutation kill requires an actually correct baseline and an actual original-predicate violation under the same frozen cases/expectations. Merely reading altered text or producing different wording is insufficient. No fixture or expectation may be changed after an outcome without separate preserved and independently justified repair.

## Identity and unavailable configuration

The host declares ChatGPT GPT-6 Astra Pro. This interface supports a fresh fork and exposes requested dispatch parameters and agent identity. It does not expose provider serving revision, sampling parameters, seed or provider request ID. The packet records those fields as unavailable. It can support an actual comparison at the host-declared identity; it cannot support a claim of exact resolved-provider configuration, universal model behavior or hidden thought-count equivalence. Missing hidden provider metadata does not erase observed behavioral evidence.

## Bounded reader qualification

Four actual focused controls ran on separate byte-identical reader/fixture copies: complete source return, incident listing, an existing record and an invalid-record refusal. Actual captures and JSON framing matched. The candidate actor `live/` directories remain absent. No model call or original scenario execution occurred.

Reader control result: `../causal-reader-checks/RESULT.json`, 2,322 bytes, SHA-256 `b81bdc724f7262c986237c7fb999c4d19bda36ae2a3398c86429277d66728fc1`.

The first prospective preparation failed its mission-independence check because its public workspace path included the literal original ID N08. That partial packet, exact original preparation source and observed failure are preserved in `../n08-m07-model-packet/INITIAL_PREPARATION_FAILURE.json`. This separate neutral-path successor changes only the public path. No actor had seen either prompt and no outcome or expectation was revised.

## Frozen population and remaining decisions

`PACKET_SEAL.json` binds the complete immutable population. `AUTHOR_PREIMAGE.json` records the earlier preparation state before this seal; its statement that the packet was not yet sealed is historical, not a current dispatch assertion. No original acceptance, currentness or source authority is minted by either file.

The author mechanically required Root's current receipt before sealing:
`refs/implementaudit/continuity-receipts/dg16-dg18-pro-20261118/G0005@befd7b0728a1c115d2b7594af8666226116f825e`.
This is a parent-bound ordinary author task. It does not modify or supersede controller custody.

Remaining gates are independent immutable prompt/oracle/source-mutation receiving; Root's actual dispatch under current continuity; exact actual captures and output receiving; and a separate original disposition. The author is not an independent evaluator and has not awarded N08, M07 or whole DG17.
