"""Recorded bounded maintenance interface; not an OS security boundary."""
from pathlib import Path
import datetime,fcntl,hashlib,json,os,signal,subprocess,sys
ROOT=Path(__file__).resolve().parent
PROJECTS=ROOT/'projects'
READ_ONLY={'notice/request.md','notice/check.py','clock/request.md','clock/observations.json','clock/local-notes.txt'}
def sha(b):return hashlib.sha256(b).hexdigest()
def snapshot():
 return {p.relative_to(PROJECTS).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(PROJECTS.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
def resolve(name):
 p=PROJECTS/name
 if not p.resolve().is_relative_to(PROJECTS.resolve()) or Path(name).is_absolute() or '..' in Path(name).parts:
  raise ValueError('path outside owned projects')
 return p
def check(name):
 if name not in {'notice','clock'}:raise ValueError('unknown project')
 cmd=[sys.executable,'-I','-B',str(PROJECTS/name/'check.py')]
 proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 try:out,err=proc.communicate(timeout=20)
 except subprocess.TimeoutExpired:
  os.killpg(proc.pid,signal.SIGKILL);out,err=proc.communicate(timeout=5)
  raise RuntimeError('check timeout; owned group terminated')
 return {'argv':cmd,'exit_code':proc.returncode,'stdout':out.decode(),'stderr':err.decode(),'stdout_sha256':sha(out),'stderr_sha256':sha(err)}
def main():
 args=sys.argv[1:];stdin=sys.stdin.read() if args and args[0]=='write' else ''
 live=ROOT/'live';live.mkdir(exist_ok=True)
 with (live/'writer.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  existing=sorted(live.glob('call-*'))
  if any(not (p/'result.json').is_file() for p in existing):raise RuntimeError('prior incomplete call; return to caller without retry')
  current=live/('call-%04d'%(len(existing)+1));current.mkdir()
  before=snapshot();start=datetime.datetime.now(datetime.timezone.utc).isoformat()
  request={'at':start,'argv':sys.argv,'stdin':stdin,'before':before,'guidance_sha256':sha((ROOT/'guidance.txt').read_bytes())}
  (current/'request.json').write_text(json.dumps(request,indent=2,sort_keys=True)+'\n')
  code=0
  try:
   if args==['guidance']:result={'guidance':(ROOT/'guidance.txt').read_text(),'sha256':sha((ROOT/'guidance.txt').read_bytes())}
   elif args==['list']:result={'files':snapshot()}
   elif len(args)==2 and args[0]=='read':
    p=resolve(args[1]);result={'path':args[1],'content':p.read_text(),'sha256':sha(p.read_bytes())}
   elif len(args)==2 and args[0]=='write':
    p=resolve(args[1])
    if args[1] in READ_ONLY:raise ValueError('input is immutable')
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(stdin)
    result={'written':args[1],'bytes':len(p.read_bytes()),'sha256':sha(p.read_bytes())}
   elif len(args)==2 and args[0]=='check':result=check(args[1])
   else:raise ValueError('allowed: guidance; list; read RELATIVE_PATH; write RELATIVE_PATH (text on stdin); check notice|clock')
  except Exception as e:result={'interface_error':type(e).__name__+': '+str(e)};code=2
  raw=(json.dumps(result,indent=2,sort_keys=True)+'\n').encode()
  (current/'stdout.bin').write_bytes(raw)
  record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'output_bytes':len(raw),'output_sha256':sha(raw),'after':snapshot(),'authority':'NONE','result':result}
  (current/'result.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
  sys.stdout.buffer.write(raw)
  return code
if __name__=='__main__':raise SystemExit(main())
