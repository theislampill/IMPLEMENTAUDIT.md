def to_ticks(value):
    return int(float(value) * 100)
