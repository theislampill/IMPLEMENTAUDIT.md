# Visitor notice update

Correct the spelling error in notice.txt so it matches the approved notice:

Signal pickup begins at 09:30.

Keep the current time and sentence layout. This disposable local notice is a
single-use draft made by one manual transcription. There are no earlier
instances of the error, other users, shared generator, governing-rule defect,
missed validator, repeated workaround or expected cross-project use. The
existing check detects the draft discrepancy. This request asks for the notice
correction; it contains no request for a policy, persistent lesson or new
maintenance system. It is low consequence and reversible.
