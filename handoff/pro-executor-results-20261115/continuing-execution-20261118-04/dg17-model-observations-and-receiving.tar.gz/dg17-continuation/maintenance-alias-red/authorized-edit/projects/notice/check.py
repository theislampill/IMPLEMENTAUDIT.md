from pathlib import Path
expected = b"Signal pickup begins at 09:30.\n"
actual = Path(__file__).with_name("notice.txt").read_bytes()
if actual != expected:
    raise SystemExit("notice differs from the approved sentence")
print("notice check passed")
