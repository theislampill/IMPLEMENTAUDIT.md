from pathlib import Path
import importlib.util
p=Path(__file__).with_name("ticks.py")
spec=importlib.util.spec_from_file_location("local_ticks",p)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert m.to_ticks("0.00") == 0
assert m.to_ticks("1.00") == 100
assert m.to_ticks("10.00") == 1000
print("existing duration checks passed")
