import base64,hashlib,json,pathlib,sys
p=pathlib.Path(__file__).with_suffix('.state.json')
def out(v): print(json.dumps(v,separators=(',',':')))
def save(v):p.write_text(json.dumps(v))
def d(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
cfg=json.loads(pathlib.Path(__file__).with_suffix('.config.json').read_text());a=sys.argv[1:];op=a[0]
if op=='initialize':
 assert not p.exists();save({'ordinal':0,'body':''});out({'status':'INITIALIZED'})
else:
 s=json.loads(p.read_text());i=int(a[1]) if len(a)>1 else 18
 if op=='ready':assert i==s['ordinal'];out({'status':'READY'})
 elif op=='reserve':
  assert i==s['ordinal'] and not s.get('reserved');s['reserved']=True;save(s)
  tails=['/actions/runs/'+cfg['run_id'],'/actions/runs/'+cfg['run_id']+'/attempts/1','/actions/runs/'+cfg['run_id']+'/attempts/1/jobs?per_page=100&page=1','/actions/runs/'+cfg['run_id']+'/artifacts?per_page=100','/actions/runs/'+cfg['run_id']+'/artifacts?per_page=100','/contents/'+cfg['workflow_path']+'?ref='+cfg['workflow_commit']]
  url='https://api.github.com/repos/theislampill/IMPLEMENTAUDIT.md'+tails[i%6]
  if cfg.get('bad_url'):url+='-foreign'
  out({'status':'RESERVED_ONCE','remaining_ms':500000,'logical_tool_call_ref':'fixture-'+str(i),'plan':{'ordinal':i,'tool':'mcp__codex_apps__github_fetch','arguments':{'url':url},'intent_sha256':'e'*64}})
 elif op=='chunk':
  old=base64.b64decode(s['body']);assert int(a[2])==len(old);b=old+base64.b64decode(a[3]);s['body']=base64.b64encode(b).decode();save(s);out({'status':'CHUNK_RETAINED',**d(b)})
 elif op=='complete':
  b=base64.b64decode(s['body']);assert len(b)==int(a[2]) and d(b)['sha256']==a[3] and a[4]=='e'*64 and b.endswith(b'\n');assert type(json.loads(b)['isError']) is bool
  out({'status':'ACTUAL_FULL_RESULT_RETAINED','receipt':{'logical_tool_call_ref':'fixture-'+str(i)}})
 elif op=='publish':
  s={'ordinal':i+1,'body':''};save(s);out({'status':'PUBLISHED','ordinal':i,'broker_status':'RECEIVED','fetch_permitted':False})
 elif op=='finish':assert s['ordinal']==18;out({'status':'DISPATCH_18_COMPLETE_SENDER_TERMINAL_SEPARATE','fixture_only':True})
 else:raise AssertionError('unknown fixture operation')
