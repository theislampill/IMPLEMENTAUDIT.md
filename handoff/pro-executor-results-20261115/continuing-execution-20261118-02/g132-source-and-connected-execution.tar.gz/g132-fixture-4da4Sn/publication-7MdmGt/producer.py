import hashlib,json,os,pathlib,select,sys,termios,time
root=pathlib.Path(sys.argv[1]);cfg=json.loads((root/'config.json').read_text());repo='theislampill/IMPLEMENTAUDIT.md'
def enc(v):return (json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode()
def d(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def emit(v):print(enc(v).decode(),end='',flush=True)
def frame():
 attr=termios.tcgetattr(0);attr[3]&=~(termios.ECHO|termios.ICANON);attr[6][termios.VMIN]=1;attr[6][termios.VTIME]=0;termios.tcsetattr(0,termios.TCSANOW,attr)
 print('READY_FOR_EPHEMERAL_DOWNLOAD_RESULT_LENGTH_FRAME',flush=True)
 end=time.monotonic()+5;header=b''
 while not header.endswith(b'\n'):
  assert time.monotonic()<end
  if select.select([0],[],[],.1)[0]:header+=os.read(0,1)
 n=int(header);assert 0<n<=4194304;b=b''
 while len(b)<n:
  assert time.monotonic()<end
  if select.select([0],[],[],.1)[0]:b+=os.read(0,n-len(b))
 return b
calls=[('create_blob',{'repository_full_name':repo,'content':'SYNTHETIC_CONTROL','encoding':'utf-8'}),('create_blob',{'repository_full_name':repo,'content':'U1lOVEhFVElDX05PX0NSWVBUTw==','encoding':'base64'}),('create_tree',{'repository_full_name':repo,'tree_elements':[{'path':'CONTROL.json','mode':'100644','type':'blob','sha':'1'*40},{'path':'INPUTS.cms','mode':'100644','type':'blob','sha':'1'*40}]}),('create_commit',{'repository_full_name':repo,'tree_sha':'3'*40,'parent_sha':'5'*40,'message':'FIXTURE_ONLY'}),('update_ref',{'repository_full_name':repo,'branch_name':cfg['branch'],'sha':'4'*40,'expected_sha':('6' if cfg.get('bad_parent') else '5')*40,'force':False})]
api='https://api.github.com/repos/'+repo
if cfg.get('control'):
 calls=calls[2:];calls[0][1]['tree_elements']=[{'path':name,'mode':'100644','type':'blob','content':'FIXTURE_ONLY'} for name in ['CONTROL.json','INPUTS.cms']]
calls.extend([('fetch',{'url':api+'/git/ref/heads/'+cfg['branch']}),('fetch',{'url':api+'/git/commits/'+'4'*40}),('fetch',{'url':api+'/git/trees/'+'3'*40+('?recursive=1' if cfg.get('control') else '')}),('fetch_file',{'repository_full_name':repo,'path':'CONTROL.json','ref':'4'*40,'encoding':'base64'}),('fetch_file',{'repository_full_name':repo,'path':'INPUTS.cms','ref':'4'*40,'encoding':'base64'}),('fetch',{'url':api+'/git/ref/heads/'+cfg['branch']})])
if cfg.get('extra_read'):calls.append(calls[-1])
for n,(tool,args) in enumerate(calls):
 kind='CALL'+str(n);body=enc(args);ap=root/(('OTHER' if cfg.get('relocated_argument') else kind)+'.ARGUMENTS.json');ap.write_bytes(body);ap.chmod(cfg.get('argument_mode',0o600));now=int(time.time()*1000)
 intent={'schema':'dg16.binary-publication-exclusive-intent.v1','authority':'NONE','kind':kind,'tool':'mcp__codex_apps__github_'+tool,'arguments':d(body),'arguments_path':str(ap),'expires_unix_ms':cfg['deadline'],'frame_started_unix_ms':now,'frame_deadline_unix_ms':min(now+45000,cfg['deadline']),'automatic_retry':False}
 if cfg.get('expired_origin'):intent['frame_started_unix_ms']=now-50000;intent['frame_deadline_unix_ms']=now+20000
 if cfg.get('control'):intent={'schema':'dg16.root-control-exclusive-'+('call' if n<3 else 'read')+'-intent.v1','authority':'NONE','kind':kind,'ordinal':n,'call':{'tool':'mcp__codex_apps__github_'+tool,'arguments':args},'deadline_unix_ms':cfg['deadline'],'frame_deadline_unix_ms':min(now+45000,cfg['deadline']),'automatic_retry':False,'actual_native_history_required':True}
 iraw=enc(intent);ip=root/(kind+'.INTENT.json');ip.write_bytes(iraw);ip.chmod(0o600)
 emit({'event':'intent','intent':intent,'intent_sha256':d(iraw)['sha256'],'intent_path':str(ip)})
 raw=frame();assert isinstance(json.loads(raw)['isError'],bool);emit({'event':'retained','kind':kind,'actual_result':d(raw)})
emit({'event':'complete','receipt':{'authority':'NONE','fixture_only':True,'original_awards':[],'root_tool_history_authentication_required':True}})
