import fs from 'node:fs';
import vm from 'node:vm';
import {spawnSync} from 'node:child_process';
const source='/workspace/scratch/095d3235c921/evidence/g132-portability/upstream/dispatcher-templates-02/dispatch.js';
const original=fs.readFileSync(source,'utf8');
const command=vm.runInNewContext(original.replace('await dispatch();','')+
  '\nwslCommand("/usr/bin/python3","pass","/tmp/g132-baseline-public-helper.py","a".repeat(64),"initialize");');
const actual=spawnSync('/bin/bash',['-c',command],{encoding:'utf8',timeout:3000});
if(actual.status===0) throw Error('Expected historical WSL command to fail in this Linux shell');
const old=vm.runInNewContext(fs.readFileSync('/workspace/scratch/095d3235c921/implementaudit/handoff/dg16-pro-executor-20261115/operator_session.js','utf8'));
const report={schema:'g132.portability-baseline.v1',scope:'READ_ONLY_PUBLIC_SOURCE_AND_DISPOSABLE_COMMAND_ONLY',
 source_commit:'d76c1e9c22fd816fbc6ddcac0080625b8f087d23',
 historical_wsl_on_current_linux:{expected_failure:true,exit_code:actual.status,stdout:actual.stdout,stderr:actual.stderr},
 existing_public_acquirer:{type:typeof old,sender_reads:typeof old.senderReads,publication:typeof old.publish,g3_consumption:typeof old.consumeG3},
 original_sender_runs:0,private_body_operations:0,protected_effects:0,original_acceptance:false};
fs.writeFileSync('/workspace/scratch/095d3235c921/evidence/g132-portability/BASELINE_RED.json',JSON.stringify(report,null,2)+'\n');
process.stdout.write(JSON.stringify(report,null,2)+'\n');
