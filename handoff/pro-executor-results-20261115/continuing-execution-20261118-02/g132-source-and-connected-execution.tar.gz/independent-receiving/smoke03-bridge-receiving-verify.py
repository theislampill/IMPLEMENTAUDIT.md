#!/usr/bin/env python3
"""Read existing smoke03 evidence only; write reviewer-owned join artifacts.

No reviewed source is imported or executed. No subprocess or network is used.
This script is an evidence consistency check, not an authority or award gate.
"""
import base64
import collections
import hashlib
import json
from pathlib import Path

BASE = Path('/workspace/scratch/095d3235c921')
ROOT = BASE / 'evidence/g132-portability/root-connected-03'
OUT = BASE / 'evidence/g132-independent-review'
SCOPE = 'SYNTHETIC_TRANSPORT_ONLY_NO_ORIGINAL_INPUTS'
FETCH = 'mcp__codex_apps__github_fetch'
FILE = 'mcp__codex_apps__github_fetch_file'
API = 'https://api.github.com/repos/theislampill/IMPLEMENTAUDIT.md'
REPO = 'theislampill/IMPLEMENTAUDIT.md'
BRANCH = 'engineering/g132-portability-smoke-20261118-03'
COMMIT = '30c5258ab47281dc9a2f221a5035bc0b538efe53'
PARENT = '1c2bc9a077c4ac41823efad76dde15a6e296fec4'
TREE = 'af44e8cd90fc8638e562cd76412af20d72371a8e'
INPUTS = {}
CHECKS = []
CALLS = []


def desc(b):
    return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


def raw(p):
    p = Path(p)
    b = p.read_bytes()
    d = desc(b)
    if str(p) in INPUTS:
        assert INPUTS[str(p)] == d, 'input changed during review: ' + str(p)
    INPUTS[str(p)] = d
    return b


def parse(b):
    def pairs(rows):
        out = {}
        for k, v in rows:
            assert k not in out, 'duplicate JSON key'
            out[k] = v
        return out
    return json.loads(b, object_pairs_hook=pairs,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))


def read(p):
    return parse(raw(p))


def compact(v, sort=True):
    return json.dumps(v, sort_keys=sort, ensure_ascii=False,
                      separators=(',', ':'), allow_nan=False).encode()


def check(value, label):
    assert value, label
    CHECKS.append(label)


def git(kind, b):
    return hashlib.sha1(kind.encode() + b' ' + str(len(b)).encode() + b'\0' + b).hexdigest()


def unwrap(value, url):
    check(value['isError'] is False, 'read isError false: ' + url)
    sc = value['structuredContent']
    check(sc['url'] == sc['display_url'] == url, 'read endpoint: ' + url)
    if 'structuredContent' in sc:
        nested = sc['structuredContent']
        check(nested['content'] == sc['content'] and nested['display_url'] == url,
              'nested read endpoint/content: ' + url)
    return parse(sc['content'])


def body(value, path):
    sc = value['structuredContent']
    check(value['isError'] is False and sc['encoding'] == 'base64', 'file encoding: ' + path)
    check(sc['display_url'] == 'https://github.com/' + REPO + '/blob/' + COMMIT + '/' + path,
          'file exact commit/path: ' + path)
    b = base64.b64decode(''.join(sc['content'].split()), validate=True)
    check(sc['sha'] == git('blob', b), 'file Git blob: ' + path)
    return b


PINS = {
    ROOT / 'ROOT_CONNECTED_RESULT.json': (15456, 'af2969f2037c10be84224d6b87a8cdc18be1fdcdb6ad7a28e72dd78e00d061eb'),
    ROOT / 'ROOT_HOST_DIAGNOSTICS.json': (336062, 'a46396992e1ac7811556b26a9a989f4c6c2fede150cc890faa67d3c7e36abcac'),
    ROOT.parent / 'ROOT_CONNECTED_CAPABILITIES_03.js': (13293, '4a8b243275ab1a2e07178bb4b64f29d8e7ac29aac0ef82dbf04331d6b299e75f'),
    BASE / 'implementaudit/handoff/dg16-pro-executor-20261118/g132_source_manifest.json':
        (5234, 'd2ef2aa1554dfd4535f227fddb08c0df9db5db599b4f875e2ea153d4f7bb07f9'),
}
for p, (n, h) in PINS.items():
    check(desc(raw(p)) == {'bytes': n, 'sha256': h}, 'assigned pin: ' + str(p))
manifest = read(next(p for p in PINS if p.name == 'g132_source_manifest.json'))
for row in manifest['files']:
    check(desc(raw(row['path'])) == {k: row[k] for k in ('bytes', 'sha256')},
          'frozen manifest member: ' + row['repository_path'])
codec = manifest['upstream']['codec']
check(desc(raw(codec['path'])) == {k: codec[k] for k in ('bytes', 'sha256')}, 'codec pin')
setup = read(ROOT / 'LOCAL_SETUP.json')
cfg = read(ROOT / 'SMOKE_CONFIGURATION.json')
check(setup['configuration']['raw'].encode() == raw(ROOT / 'SMOKE_CONFIGURATION.json'), 'configuration exact raw')
for row in setup['source_receiving']:
    check(desc(raw(row['received_path'])) == {k: row[k] for k in ('bytes', 'sha256')},
          'received owner source: ' + row['path'])
check(desc(raw(setup['sender_fixture']['path'])) == setup['sender_fixture']['descriptor'], 'received sender fixture pin')
result = read(ROOT / 'ROOT_CONNECTED_RESULT.json')
check(result['fixture_scope'] == SCOPE and result['original_acceptance'] is False
      and result['native_history_authenticated'] is False and result['original_awards'] == []
      and result['protected_operation'] == 'UNCHANGED_UNKNOWN_NO_REPLAY', 'literal top-level scope restrictions')

lanes = {}
lane_counts = {}
for key in ('public_read', 'sender_mechanics', 'branch', 'publication', 'g3'):
    r = result[key]
    folder = ROOT / 'operator-journal' / r['subject_key']
    start = read(folder / 'START.json')
    intents = [read(p) for p in sorted(folder.glob('*.INTENT.json'))]
    returns = [read(p) for p in sorted(folder.glob('*.RESULT.json'))]
    finish = read(folder / 'FINISH.json')
    check(not (folder / 'UNKNOWN.json').exists(), 'no UNKNOWN member in completed lane: ' + key)
    check(len(intents) == len(returns) == r['steps'] == r['actual_callbacks_or_tools'] == finish['index'],
          'complete outer ordinal count: ' + key)
    check([x['index'] for x in intents] == list(range(len(intents))) == [x['index'] for x in returns],
          'contiguous outer ordinals: ' + key)
    check(start['key'] == finish['key'] == r['subject_key'], 'outer subject binding: ' + key)
    check(finish['result'] == desc(compact(r['result'])), 'outer FINISH result binding: ' + key)
    for i, (intent, returned) in enumerate(zip(intents, returns)):
        check(returned['intent'] == desc(raw(folder / f'{i:03}.INTENT.json')),
              'outer result to durable intent: ' + key + '/' + str(i))
        check(returned['key'] == intent['key'] == r['subject_key'], 'outer key: ' + key + '/' + str(i))
    lanes[key] = (folder, intents, returns)
    lane_counts[key] = {'outer_steps': len(intents), 'kinds': dict(collections.Counter(i['kind'] for i in intents))}


def outer(key, ordinal, request, tool, arguments, mutation, source_result=None, source_files=None):
    folder, intents, returns = lanes[key]
    i, r = intents[ordinal], returns[ordinal]
    check(i['request'] == desc(compact(request)), 'outer exact request: ' + key + '/' + str(ordinal))
    if source_result is not None:
        check(r['result'] == desc(source_result), 'outer full returned bytes: ' + key + '/' + str(ordinal))
    CALLS.append({'lane': key, 'outer_ordinal': ordinal, 'kind': i['kind'], 'tool': tool,
                  'arguments': arguments, 'mutation': mutation, 'outer_intent': str(folder / f'{ordinal:03}.INTENT.json'),
                  'outer_result': str(folder / f'{ordinal:03}.RESULT.json'),
                  'returned_descriptor': r['result'], 'full_result_retained_in_source': source_result is not None,
                  'source_files': source_files or []})


public = result['public_read']['result']
outer('public_read', 0, {'tool': public['tool'], 'arguments': public['arguments']},
      public['tool'], public['arguments'], False)
check(public['actual_result'] == lanes['public_read'][2][0]['result'], 'public observation returned descriptor')
sj = ROOT / 'sender-fixture/dispatcher-journal'
ss = read(sj / 'START.json')
end = read(sj / 'END.json')
expected_names = {'START.json'} | {f'{i:02}_{suffix}' for i in range(18)
                                  for suffix in ('INTENT.json', 'RESULT_READY.json', 'RESULT.raw', 'PUBLISH_INTENT.json', 'PUBLISHED.json')}
check(set(end['prefix']) == expected_names, 'dispatcher END complete 91-member prefix')
check({p.name for p in sj.iterdir()} == expected_names | {'END.json'}, 'dispatcher exact 92-member journal')
for name, d in end['prefix'].items():
    check(desc(raw(sj / name)) == d, 'dispatcher END prefix hash: ' + name)
check(end['reads'] == 18 and end['authority'] == 'NONE' and end['original_awards'] == [], 'dispatcher END literal bounds')
urls = [API + '/actions/runs/43853354399', API + '/actions/runs/43853354399/attempts/1',
        API + '/actions/runs/43853354399/attempts/1/jobs?per_page=100&page=1',
        API + '/actions/runs/43853354399/artifacts?per_page=100',
        API + '/actions/runs/43853354399/artifacts?per_page=100',
        API + '/contents/.github/workflows/dg16-r5-g1-hosted-episode.yml?ref=625f310d04cb5b5a1f02901cfdcf3c3815730a5e']
sender_desc = {}
for n in range(18):
    names = [sj / f'{n:02}_{s}' for s in ('INTENT.json', 'RESULT_READY.json', 'PUBLISH_INTENT.json', 'PUBLISHED.json')]
    intent, ready, publish_intent, published = [read(p) for p in names]
    b = raw(sj / f'{n:02}_RESULT.raw')
    check(b.endswith(b'\n') and not b.endswith(b'\n\n'), 'sender added one terminal newline: ' + str(n))
    parsed = parse(b)
    check(parsed['isError'] is False and isinstance(parsed['structuredContent'], dict), 'complete returned sender wrapper: ' + str(n))
    check(intent['ordinal'] == ready['ordinal'] == published['ordinal'] == n, 'sender source ordinal: ' + str(n))
    check(intent['tool'] == FETCH and intent['arguments'] == {'url': urls[n % 6]}, 'sender fixed public endpoint: ' + str(n))
    check(ready['tool_result'] == desc(b) and ready['external_intent_sha256'] == desc(raw(names[0]))['sha256'],
          'sender source retained result join: ' + str(n))
    check(ready['native_tool_call_id_available'] is False and ready['actual_tool_history_required'] is True,
          'sender native history limit explicit: ' + str(n))
    bh = desc(compact({'fixture_scope': SCOPE, 'ordinal': n, 'nonce': ss['nonce']}) + b'\n')['sha256']
    check(ready['broker_intent_sha256'] == bh, 'synthetic broker commitment: ' + str(n))
    check(publish_intent['result_ready_sha256'] == published['result_ready_sha256'] == desc(raw(names[1]))['sha256'],
          'sender publish to ready binding: ' + str(n))
    reply = published['broker_result']['reply']
    check(published['status'] == 'PUBLISHED' and published['broker_status'] == 'RECEIVED'
          and published['broker_result']['fetch_permitted'] is False
          and reply['tool_result'] == desc(b) and reply['intent_sha256'] == bh
          and reply['ordinal'] == n and reply['nonce'] == ss['nonce']
          and reply['tool_call_ref'] == ready['logical_tool_call_ref'] == intent['logical_tool_call_ref']
          and reply['original_provider_policy_exercised'] is False and reply['fixture_scope'] == SCOPE,
          'sender synthetic broker publication join: ' + str(n))
    outer('sender_mechanics', n + 1,
          {'ordinal': n, 'tool': FETCH, 'arguments': intent['arguments'], 'original_intent_sha256': bh},
          FETCH, intent['arguments'], False, b[:-1], [str(p) for p in names] + [str(sj / f'{n:02}_RESULT.raw')])
    sender_desc[str(n)] = desc(b)
terminal = result['sender_mechanics']['result']['terminal']
check(terminal['actual_tool_result_descriptors'] == sender_desc, 'sender terminal all 18 source raw descriptors')
check(terminal['owner_source_sha256'] == '6841057bd780588688f193e7959a1dda60dca42bbe5ef5995bca14147cb79f73'
      and all(terminal[k] is False for k in ('original_binding_gate_passed', 'original_sender_invoked',
                                          'encryption_performed', 'original_admission_created'))
      and terminal['original_awards'] == [], 'sender terminal exact source and nonqualifications')
check(lanes['sender_mechanics'][2][19]['result'] == desc(compact(terminal, sort=False)), 'sender terminal callback retained descriptor')

branch = result['branch']['result']
marker = compact({'schema': 'dg16.g132-public-portability-smoke.v1', 'authority': 'NONE',
                  'original_acceptance': False, 'private_inputs': False,
                  'controller': cfg['spec']['actor']['controller'], 'run_id': '43853354399'}) + b'\n'
branch_args = [
    ('mcp__codex_apps__github_create_tree', {'repository_full_name': REPO, 'tree_elements': [
        {'path': 'G132_PORTABILITY_SMOKE.json', 'mode': '100644', 'type': 'blob', 'content': marker.decode()}]}),
    ('mcp__codex_apps__github_create_commit', {'repository_full_name': REPO, 'tree_sha': branch['data_only_tree'],
        'parent_sha': branch['base_parent'], 'message': 'G132 public portability smoke; synthetic data only'}),
    ('mcp__codex_apps__github_create_branch', {'repository_full_name': REPO, 'branch_name': BRANCH, 'sha': PARENT}),
    (FETCH, {'url': API + '/git/ref/heads/' + BRANCH}),
]
for i, (tool, args) in enumerate(branch_args):
    outer('branch', i, {'tool': tool, 'arguments': args}, tool, args, i < 3)

pj = ROOT / 'source-publication-journal'
plan = read(pj / 'PLAN.json')
receipt = read(pj / 'RECEIVING.json')
check(receipt == result['publication']['result']['source_receipt']['exact_owner_receipt'], 'publication exact source RECEIVING to outer terminal')
keys = ['ref', 'commit', 'tree', 'blob-control', 'blob-cipher', 'closing_ref']
labels = ['WRITE' + str(i) for i in range(5)] + ['READ_' + k.upper() for k in keys]
check({p.name for p in pj.iterdir()} == {'PLAN.json', 'RECEIVING.json'} | {
      label + '.' + suffix + '.json' for label in labels for suffix in ('ARGUMENTS', 'INTENT', 'RESULT', 'RETURNED')},
      'publication exact 46-member journal, no UNKNOWN/rejected/extra calls')
pub_results = {}
pub_args = {}
for n, label in enumerate(labels):
    paths = [pj / (label + '.' + suffix + '.json') for suffix in ('ARGUMENTS', 'INTENT', 'RESULT', 'RETURNED')]
    args, intent, returned = read(paths[0]), read(paths[1]), read(paths[3])
    b = raw(paths[2])
    check(intent['arguments_path'] == str(paths[0]) and intent['arguments'] == desc(raw(paths[0])),
          'publication source arguments byte binding: ' + label)
    check(returned['actual_result'] == desc(b) and returned['source_acceptance'] is False,
          'publication source returned full bytes before acceptance: ' + label)
    check(parse(b)['isError'] is False and intent['automatic_retry'] is False and intent['authority'] == 'NONE',
          'publication call/result scope: ' + label)
    request = {'ordinal': n, 'tool': intent['tool'], 'arguments': args,
               'source_intent_sha256': desc(compact(intent))['sha256']}
    outer('publication', n + 1, request, intent['tool'], args, n < 5, b, [str(p) for p in paths])
    pub_results[label] = parse(b)
    pub_args[label] = args
    if n >= 5:
        key = keys[n - 5]
        check(receipt['readbacks'][key] == desc(b)
              and receipt['actual_read_calls'][key] == {'tool': intent['tool'], 'arguments': args},
              'publication exact receipt readback: ' + key)

ref = unwrap(pub_results['READ_REF'], API + '/git/ref/heads/' + BRANCH)
closing = unwrap(pub_results['READ_CLOSING_REF'], API + '/git/ref/heads/' + BRANCH)
commit = unwrap(pub_results['READ_COMMIT'], API + '/git/commits/' + COMMIT)
tree = unwrap(pub_results['READ_TREE'], API + '/git/trees/' + TREE)
check(ref == closing and ref['ref'] == 'refs/heads/' + BRANCH
      and ref['object']['type'] == 'commit' and ref['object']['sha'] == COMMIT, 'publication opening/closing exact ref')
check(commit['sha'] == COMMIT and [p['sha'] for p in commit['parents']] == [PARENT]
      and commit['tree']['sha'] == TREE, 'publication exact commit and sole parent')
files = {'CONTROL.json': body(pub_results['READ_BLOB-CONTROL'], 'CONTROL.json'),
         'INPUTS.cms': body(pub_results['READ_BLOB-CIPHER'], 'INPUTS.cms')}
file_desc = {n: {**desc(b), 'git_blob': git('blob', b)} for n, b in files.items()}
check(file_desc == plan['files'] == receipt['files'], 'publication actual file bytes to plan and receiving')
calculated_tree = git('tree', b''.join(b'100644 ' + n.encode() + b'\0' + bytes.fromhex(git('blob', files[n])) for n in sorted(files)))
check(calculated_tree == tree['sha'] == receipt['tree'] == plan['expected_tree'] == TREE
      and tree['truncated'] is False and len(tree['tree']) == 2, 'independent exact two-file Git tree calculation')
for row in tree['tree']:
    check(row['path'] in files and (row['mode'], row['type'], row['sha'], row['size']) ==
          ('100644', 'blob', file_desc[row['path']]['git_blob'], len(files[row['path']])),
          'exact complete tree entry: ' + row['path'])
check(files['INPUTS.cms'] == b'G132 PORTABILITY FIXTURE ONLY. NOT CMS. NO PRIVATE INPUT. NO ENCRYPTION.\n',
      'published INPUTS.cms literal synthetic bytes')
check(parse(files['CONTROL.json'])['fixture_scope'] == SCOPE
      and parse(files['CONTROL.json'])['authority'] == 'NONE'
      and parse(files['CONTROL.json'])['original_awards'] == [], 'published CONTROL literal synthetic scope')
check(pub_args['WRITE0']['content'].encode() == files['CONTROL.json']
      and pub_args['WRITE0']['encoding'] == 'utf-8'
      and base64.b64decode(pub_args['WRITE1']['content'], validate=True) == files['INPUTS.cms']
      and pub_args['WRITE1']['encoding'] == 'base64', 'exact two publication blob write bodies')
check(pub_args['WRITE2'] == {'repository_full_name': REPO, 'tree_elements': [
      {'path': n, 'mode': '100644', 'type': 'blob', 'sha': file_desc[n]['git_blob']} for n in sorted(files)]},
      'publication tree write exact paths with no base tree')
check(pub_args['WRITE3'] == {'repository_full_name': REPO, 'tree_sha': TREE, 'parent_sha': PARENT,
      'message': 'DG16 exact encrypted input control run 43853354399'}, 'publication exact one-parent commit request')
check(pub_args['WRITE4'] == {'repository_full_name': REPO, 'branch_name': BRANCH, 'sha': COMMIT,
      'expected_sha': PARENT, 'force': False}, 'publication exact expected-old nonforce smoke-only ref request')
for i, h in enumerate([file_desc['CONTROL.json']['git_blob'], file_desc['INPUTS.cms']['git_blob'], TREE, COMMIT]):
    check(pub_results['WRITE' + str(i)]['structuredContent']['sha'] == h, 'publication exact created object return: ' + str(i))

ind = read(OUT / 'smoke03-bridge-receiving-readbacks.json')
mapping = {'opening-ref': 'READ_REF', 'commit': 'READ_COMMIT', 'tree': 'READ_TREE',
           'control-file': 'READ_BLOB-CONTROL', 'inputs-file': 'READ_BLOB-CIPHER', 'closing-ref': 'READ_CLOSING_REF'}
check(len(ind['records']) == 6 and ind['reviewer_mutation_calls'] == 0, 'six independent reviewer reads and no mutation')
reviewer_reads = []
for row in ind['records']:
    label = mapping[row['name']]
    check(row['arguments'] == pub_args[label], 'independent request matches original readback: ' + row['name'])
    check(row['result'] == pub_results[label], 'independent full wrapper equals original source result: ' + row['name'])
    reviewer_reads.append({'name': row['name'], 'arguments': row['arguments'], 'started_utc': row['started_utc'],
                           'received_utc': row['received_utc'], 'result': desc(compact(row['result'], sort=False))})
additional = read(OUT / 'smoke03-bridge-receiving-branch-readbacks.json')
check(len(additional['records']) == 2 and additional['reviewer_mutation_calls'] == 0, 'two additional immutable branch setup object reads')
by_name = {r['name']: r for r in additional['records']}
bc = unwrap(by_name['branch-setup-commit']['result'], API + '/git/commits/' + PARENT)
bt = unwrap(by_name['branch-setup-tree']['result'], API + '/git/trees/' + branch['data_only_tree'])
check(bc['sha'] == PARENT and [p['sha'] for p in bc['parents']] == [branch['base_parent']]
      and bc['tree']['sha'] == bt['sha'] == branch['data_only_tree'], 'independent branch setup sole parent and tree')
check(bt['truncated'] is False and len(bt['tree']) == 1 and bt['tree'][0]['path'] == 'G132_PORTABILITY_SMOKE.json'
      and (bt['tree'][0]['sha'], bt['tree'][0]['size'], bt['tree'][0]['mode'], bt['tree'][0]['type']) ==
      (git('blob', marker), len(marker), '100644', 'blob'), 'initial smoke tree contains exact single synthetic marker')
check(git('tree', b'100644 G132_PORTABILITY_SMOKE.json\0' + bytes.fromhex(git('blob', marker))) == branch['data_only_tree'],
      'independent initial smoke Git tree calculation')
check(len(CALLS) == 34 and sum(r['mutation'] for r in CALLS) == 8, 'joined recorded GitHub invocation counts 34 total / 8 mutation')
check(sum(r['full_result_retained_in_source'] for r in CALLS) == 29, '29 full source result wrappers / 5 descriptor-only or derived returns')
check(lane_counts['g3']['kinds'] == {'g3-actual-request': 1, 'live-root-decision': 1, 'actual-g3-consumption': 1},
      'G3 outer callbacks excluded from GitHub count')
check(sum(v['outer_steps'] for v in lane_counts.values()) == 40, '40 recorded outer invocations = 34 provider + 6 local callbacks')

# Re-read every captured input before producing review outputs. No reviewed file is written.
for p, d in list(INPUTS.items()):
    check(desc(Path(p).read_bytes()) == d, 'closing input unchanged: ' + p)
summary = {
    'schema': 'g132.smoke03.independent-bridge-journal-joins.v1',
    'reviewer': '/root/g2_independent/g132_bridge_review', 'authoring_context_reuse': 'no',
    'model_disclosure': 'Developer self-description: ChatGPT, GPT-6 Astra Pro; no independent provider model identifier observed.',
    'status': 'BOUNDED_RECORDED_EVIDENCE_JOINS_MATCH', 'authority': 'NONE', 'original_awards': [],
    'reviewed_source_executed': False, 'actual_smoke_rerun': False, 'protected_operation': 'UNCHANGED_UNKNOWN_NO_REPLAY',
    'recorded_root_github_calls': 34, 'recorded_root_smoke_mutations': 8,
    'full_source_result_wrappers': 29, 'descriptor_only_or_derived_root_call_returns': 5,
    'reviewer_connected_read_calls': 8, 'reviewer_connected_mutation_calls': 0,
    'native_history_authenticated': False, 'lane_counts': lane_counts,
    'publication': {'branch': BRANCH, 'commit': COMMIT, 'sole_parent': PARENT, 'tree': TREE, 'files': file_desc},
    'sender': {'source_dispatch_steps': 18, 'source_prefix_files': 91, 'source_total_files': 92,
               'actual_tool_result_descriptors': sender_desc, 'original_sender_invoked': False,
               'original_binding_gate_passed': False, 'original_provider_policy_exercised': False, 'encryption_performed': False},
    'independent_publication_readbacks': reviewer_reads,
    'checks_completed': len(CHECKS), 'checks': CHECKS, 'recorded_calls': CALLS,
    'limitations': [
        '34/8 is the joined recorded invocation count; no independently authenticated native provider audit history or exclusive global-call census was supplied.',
        'Only sender 18 and publication 11 retain complete source result wrappers. Public observation and branch setup four preserve outer descriptors and derived receipts.',
        'Independent reviewer reads confirm current returned Git objects and file bytes, not historical issuer identity, invocation timing or absence of out-of-band calls.',
        'Original sender admission/binding, private provider/content policy, encryption, original sender terminal, protected G132 operation, and original awards remain unqualified.',
        'Root decisions, G3 receiving, physical identity and clock/currentness receiving belong to the separate parent review.',
    ],
}
for name, value in [('smoke03-bridge-receiving-joins.json', summary),
                    ('smoke03-bridge-receiving-input-digests.json', {'schema': 'g132.smoke03.independent-input-digests.v1',
                     'input_count': len(INPUTS), 'inputs': INPUTS})]:
    p = OUT / name
    b = json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False).encode() + b'\n'
    with p.open('xb') as f:
        f.write(b)
    print(json.dumps({'path': str(p), **desc(b)}))
print(json.dumps({'checks_completed': len(CHECKS), 'inputs_bound': len(INPUTS), 'recorded_calls': len(CALLS),
                  'recorded_mutations': sum(r['mutation'] for r in CALLS), 'reviewer_mutations': 0}))
