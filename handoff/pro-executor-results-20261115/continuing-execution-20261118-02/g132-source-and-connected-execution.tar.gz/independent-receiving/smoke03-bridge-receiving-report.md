# G132 smoke03 — independent sender and publication receiving

## Judgment and scope

**No material inconsistency or blocker was found within this ordinary, bounded sender/publication receiving review.** The retained evidence supports 18 connected public-metadata dispatch steps through the received original dispatcher functions with an explicit fixture broker, followed by the received binary-publication functions completing five synthetic-data writes and six exact readbacks. Independent read-only retrieval confirms the published branch, commit, sole parent, complete tree and both file bodies.

The joined outer journals record **34 GitHub invocations: 26 reads and 8 mutation-typed calls**. This is a statement about the recorded invocation sequence and its corroborated remote results. It is **not** an independently authenticated native provider audit census. Twenty-nine calls retain full returned wrappers in the source journals; the public observation and four branch-setup calls retain outer descriptors and derived receipts. That distinction remains material to the maximum claim.

This report grants no authority, readiness, acceptance, closure or original award. It does not alter any old `UNKNOWN` boundary, authorize replay, or qualify the original protected G132 operation. Root/G3, physical identity, clock and currentness receiving are the separate parent review's scope.

- Reviewer: `/root/g2_independent/g132_bridge_review`.
- `authoring_context_reuse: no`. The reviewer authored neither the frozen adapter nor Root driver03. The assignment began with minimal immutable context and `fork_turns=none`; prior independent source-review context was available for this receiving task, without authoring-context reuse.
- Model disclosure: the developer describes this agent as **ChatGPT, GPT-6 Astra Pro**. No independently observed provider model identifier or native issuer authentication is asserted.
- Route: ordinary independent evidence review; no internal `audit-assess` route or reviewer controller.
- Supplied Root receipt, treated as a packet reference rather than reviewer authority: `refs/implementaudit/continuity-receipts/dg16-dg18-pro-20261118/G0004@2a1379feb07e0c39a196c3b4275f56ae5092660a`.
- Reviewer actions: existing-file reads and hashing, eight connected read-only GitHub requests, and creation of reviewer-owned reports. No reviewed source execution, actual smoke rerun, source edit, callback execution, protected process, remote mutation or controller mutation occurred.

## Exact packet and method

All paths below are absolute. Packet root **P** is `/workspace/scratch/095d3235c921/evidence/g132-portability/root-connected-03`; frozen adapter directory **A** is `/workspace/scratch/095d3235c921/implementaudit/handoff/dg16-pro-executor-20261118`. These aliases in tables are path abbreviations, not alternate objects.

| Input | Bytes | Verified SHA256 |
|---|---:|---|
| P/ROOT_CONNECTED_RESULT.json | 15,456 | `af2969f2037c10be84224d6b87a8cdc18be1fdcdb6ad7a28e72dd78e00d061eb` |
| P/ROOT_HOST_DIAGNOSTICS.json | 336,062 | `a46396992e1ac7811556b26a9a989f4c6c2fede150cc890faa67d3c7e36abcac` |
| A/g132_source_manifest.json | 5,234 | `d2ef2aa1554dfd4535f227fddb08c0df9db5db599b4f875e2ea153d4f7bb07f9` |
| /workspace/scratch/095d3235c921/evidence/g132-portability/ROOT_CONNECTED_CAPABILITIES_03.js | 13,293 | `4a8b243275ab1a2e07178bb4b64f29d8e7ac29aac0ef82dbf04331d6b299e75f` |
| P/sender-fixture/dispatcher-journal/END.json | 10,160 | `4de43fa5cc14f8dfdcefe382365eab7f6658f01c42e4049384cb8a8dabd40550` |
| P/source-publication-journal/RECEIVING.json | 2,994 | `d0d788de42f439d33530202d91c52810ff3288982ec27f2f49777f45f0030d6e` |

The read-only verifier completed 812 consistency assertions over 256 digest-bound inputs. These are mechanical evidence checks, including closing input hashes, not 812 independent tests or acceptance cases. It imports or executes none of the reviewed source. It reconstructs exact request descriptors from source arguments, checks all source/outer result byte joins, verifies terminal descriptors, and independently calculates Git blob/tree hashes from returned file bodies. All ten frozen manifest members and received owner-source pins still match. Host diagnostics were hash-bound; their semantic receiving remains with the parent.

The full 34-call ledger, individual input digests, reviewer request arguments, complete tool-return captures and verifier source are saved beside this report. The accompanying seal binds these artifacts and this report.

## Recorded invocation population

| Lane | Outer journal subject | GitHub reads | Mutation calls | Local callbacks |
|---|---|---:|---:|---:|
| Public observation | `4933525c34a500e9314361f148a8314167d1c83a8d342287f9535e43330ca1d4` | 1 | 0 | 0 |
| Sender fixture | `15137791351af13a85c481e13ea26d50aae1e79d1d8b548f8c9681fa1e9968ac` | 18 | 0 | 2 |
| Smoke branch setup | `75f32671f2eeea3f25987d2d2da7f47ca84ff74eac8f2061457b07861a3bc3a4` | 1 | 3 | 0 |
| Publication | `edd859457b9684fdbee0aa83fd10101ffff5a0c73886d27309bc288b0748fe95` | 6 | 5 | 1 |
| G3 callback population only | `21b6ad67e1489f30799c429332d5d96d535176076ab0846c8c1ce6cebcd4ed05` | 0 | 0 | 3 |
| **Total** | | **26** | **8** | **6** |

Each lane has contiguous intent/result ordinals, an exact result-to-intent byte descriptor, a matching terminal `FINISH.json` descriptor, and no local `UNKNOWN.json`. The 40 outer invocations therefore decompose into 34 recorded GitHub calls and six local callbacks; local callbacks are not counted as provider calls. G3 was inspected only to exclude its three callback kinds from that census.

The three branch-setup mutations are tree creation, commit creation and fresh branch creation. The five publication mutations are two blob creations, tree creation, commit creation and one ref update. A mutation-typed call count is not a claim that eight distinct new Git objects were created; Git object identity is content based.

All reconstructed requests match the outer request descriptors. The branch setup has only `G132_PORTABILITY_SMOKE.json`; the publication tree has exactly `CONTROL.json` and `INPUTS.cms`, no base tree and no workflow path. The final update names only `engineering/g132-portability-smoke-20261118-03`, has `force:false`, and binds `expected_sha` to the prior smoke commit. This establishes the recorded request's restriction. It does not independently prove the provider's implementation of atomic compare-and-update or the absence of out-of-band calls. See A/g132_operator_bridge.js, lines 173–201 and 251–330; SHA256 `559343c8c2252f183fd396ccdcb2885d5c1c229b5a78727e8ec47a26d7a11884`.

## Sender: 18 source steps, explicitly bounded

The original received dispatcher is P/received-public-operator/dispatcher-templates-02/dispatcher_entry.py, SHA256 `6841057bd780588688f193e7959a1dda60dca42bbe5ef5995bca14147cb79f73`. Its actual `Journal`, `reserve`, `complete_result` and `publish` function bodies are loaded by the fixture. The relevant original source is lines 89–121 and 133–166. The fixture loader and direct calls are in A/g132_sender_fixture.py, lines 49–105 and 125–174; SHA256 `622013a7ed7ff9b9e27b39a91e85f135012812691532094b266b445149553257`.

For each ordinal 00–17, I verified:

1. The fixed public endpoint, ordinal and synthetic broker commitment match the outer `sender-read` request descriptor.
2. The source `RESULT.raw` contains the complete returned wrapper plus exactly one terminal newline. Removing that added newline gives the exact byte count and SHA256 retained by the outer `RESULT.json`.
3. `RESULT_READY.json` binds the raw result, external intent, broker commitment and logical call reference; both publication records bind that same ready record and result.
4. The fixture reply is `RECEIVED`, explicitly denies further fetch permission, and states `original_provider_policy_exercised:false`.
5. The terminal fixture receipt's 18 descriptors equal the retained raw results.

The dispatcher `END.json` binds the exact 91-member prefix, and the directory contains exactly 92 files including `END.json`. The outer sender lane contains start, 18 reads and the separate fixture-terminal callback. Its `FINISH.json` matches the complete returned sender result.

The six endpoint kinds repeat in `OPENING`, `PRE_ENCRYPTION` and `CLOSING`: the historical run, attempt, attempt jobs, artifacts twice, and the workflow file at the exact pinned workflow commit. **The phase name `PRE_ENCRYPTION` does not show that encryption occurred.** The received helper differs from the frozen fixture template only by replacing its configuration-pin placeholder with SHA256 `657d9fa13245110cfed1f8bcc760b7e4d9d9d59ea3ea40177d566d1153f21e34`; the derived helper's SHA256 is `404b92d5e24e8eb43456f5bbef5233df7f9e07e4c7d14c9e9a13d2708f3bd8a7`.

The fixture constructs the arguments and broker interface directly. It does not call the original `binding()` admission gate, start the original sender or exercise its original provider policy. The terminal is `EXACT_18_OWNER_DISPATCH_STEPS_WITH_FIXTURE_BROKER`, with original admission, original binding, original sender and encryption all false. The source result records also explicitly state `native_tool_call_id_available:false` and `actual_tool_history_required:true`. These are preserved limits, not missing fields silently treated as satisfied.

## Publication: actual source receiving and exact remote objects

The received binary-publication source is P/received-public-operator/root-final-operators-01/binary_publish_v3.py, SHA256 `e6277edd4f97bac470b1762be8cf80d1e4a21fe05f10ef168bc61e83d47599ef`. Its `write_call`, `read_plan`, `receive` and `run` implementations, lines 49–147, construct and receive the recorded five writes and six reads. The helper source `file_readback.py` is pinned to SHA256 `ab938a99ce3971caaa5e740bf4c079e3245cf0893ea358580c3661807104dcb1`.

For all 11 calls, the source argument-file bytes match the source intent; the source intent and arguments reconstruct the outer request descriptor; the complete source `RESULT.json` bytes match both the source `RETURNED.json` and outer result descriptor. The publication directory is exactly 46 members: plan, receiving, and four files per call, with no unknown/rejected/extra call record. Its original `RECEIVING.json` is exactly the nested owner receipt in the outer publication terminal; the outer `FINISH.json` binds that terminal body.

The six reads are, in order: exact branch ref, exact commit, nonrecursive exact tree, `CONTROL.json` at that commit, `INPUTS.cms` at that commit, and the closing exact branch ref. All six receipt descriptors and exact request mappings match the source files.

| Published object | Independently received value |
|---|---|
| Branch | `engineering/g132-portability-smoke-20261118-03` |
| Commit | `30c5258ab47281dc9a2f221a5035bc0b538efe53` |
| Sole parent | `1c2bc9a077c4ac41823efad76dde15a6e296fec4` |
| Complete tree | `af44e8cd90fc8638e562cd76412af20d72371a8e` |
| `CONTROL.json` | 214 bytes; Git blob `75f79bde8bbab70bc99d45fc0347f53f7b7f27c5`; SHA256 `6acd75ca5b3eacd9676321b40812e1baa8a50cfb28b1e52d88535da12e5671a4` |
| `INPUTS.cms` | 73 bytes; Git blob `13c2816b108aad0f7536f24fbad1f1341c9723c8`; SHA256 `c10251dd05f83637faeb27a4513eafdbbe3d689861bbfcfe67866dfe19982869` |

My six independent publication reads, observed from `2026-11-18T06:05:50.534Z` to `2026-11-18T06:06:05.044Z`, returned full wrappers whose JSON serialization exactly matches the original six source-returned byte descriptors. These times are reviewer observations, not separate clock certification. Two additional immutable-object reads confirm the initial smoke commit's sole base parent `afda760d6de5cac08a27ad86da4c2be981749354` and complete tree `2da014e9093117d1d6ae67ae8ff5d7fdcbb925d9`. That tree contains only the exact 182-byte synthetic marker blob `e885e07786ec601d8c3352da49c50d9e9895e2c0`. All eight reviewer reads are separate from the recorded Root 34-call count.

The published file named `INPUTS.cms` is the exact public fixture sentence stating it is not CMS, contains no private input and performs no encryption. The owner runtime supplies a `SyntheticContent` predicate and locally scoped journal constructor, then calls the original publication algorithm; it does not run the original private-content plan/admission path. See A/g132_owner_runtime.py, lines 152–208, SHA256 `8d09c09268c9ae95d27a6c6838955ac1c2badd25ea1321669aef1180eadb9268`. The preserved terminal explicitly says `original_content_policy_exercised:false`, `private_key_operation:false` and `original_acceptance:false`. The original receiving record requires `root_tool_history_authentication_required:true` and grants no effect.

## Maximum supported claim and remaining limits

This packet supports **connected public transport through 18 received dispatcher steps with an explicit fixture broker, followed by the received binary-publication mechanics completing and receiving a synthetic two-file publication**, with exact recorded request/result joins and independently corroborated Git objects and file bytes. It is stronger than a local fake-provider fixture run because current connected reads reproduce the published objects and source-returned readback wrappers.

It does not qualify the original sender admission or binding, private provider/content policy, encryption, original sender process or terminal, original protected G132 operation, native model/issuer history, Root/G3 acceptance, or an original award. The adapter's terminal path requires a complete source event and zero process exit (A/g132_operator_bridge.js, lines 392–455), but this review does not independently authenticate the original native process-session transcript. The source/outer journals and pinned execution path provide the bounded receiving evidence; parent receiving covers its separate live-host claims.

The five calls outside the source-retained 29 have exact outer descriptors and derived outcomes, not separate complete raw return bodies in this packet. Independent later reads establish the Git state that now corresponds to the recorded writes; they do not reconstruct an earlier branch-ref response, identify a historical native issuer, or prove that no unrecorded operation occurred. Preserving these limits is necessary to keep the result within its literal evidence.

## Reviewer artifacts

All artifacts are in `/workspace/scratch/095d3235c921/evidence/g132-independent-review/` and use the `smoke03-bridge-receiving-` prefix.

| Artifact | SHA256 |
|---|---|
| joins.json | `f3e2f0dbd5d827167515ed5a51daa3dbc0bcb595cf2387ef18a32b1586d880f3` |
| input-digests.json | `8529d1bbba10b63add3382cc6a3697d01361cdd1d212342aa75886a7d8d3a69c` |
| readbacks.json — six exact publication reviewer reads | `c749f936f0a5c5de94dc3caca11b43a26fd2c52e1624c9480022125f42942865` |
| branch-readbacks.json — two immutable setup-object reviewer reads | `61dabdff868b41ba0f40b0c3f8230c7d1229296841ae2f6d1b9349e41b3fc1eb` |
| verify.py — read-only consistency checker | `31c13c8e04b0e1c9aeb0a95cfb27314001f31fb862114cac89739fa8d59e3b38` |

No implementation changes or fixes were made. No original award is issued.
