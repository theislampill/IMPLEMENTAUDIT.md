# Bounded independent G132 bridge and smoke source review

## Scope, identity, and authority

- Review type: ordinary independent source review; no internal `audit-assess` routing, governance, launch, acceptance, or closure authority.
- Reviewer task: `/root/g2_independent/g132_bridge_review`.
- Assigned source author: `/root/dg18_execution`; this reviewer did not author or edit the reviewed source.
- `authoring_context_reuse: no`.
- Context: minimal immutable review assignment, dispatched with `fork_turns=none`; no authoring history or author test outcomes were used as verification evidence.
- Model label: the developer-provided label is **ChatGPT, GPT-6 Astra Pro**. This is a host/developer label, not an independently observed provider model ID or native provenance assertion.
- `authority: NONE`; `original_acceptance: false`; no readiness, launch approval, Root record, or audit PASS is issued by this report.
- Report time: `2026-11-18T05:10:17.275623+00:00`.

**Result:** No material defect was established in the frozen bridge and concrete smoke route within the source and synthetic execution scope below. This conclusion does not establish that live Root capabilities are authentic, that a connected smoke is authorized, or that the original sender/G1/G3 operation may run. The protected-operation boundary remains `UNKNOWN_NO_REPLAY`.

## Immutable source basis

The assignment manifest is `/workspace/scratch/095d3235c921/implementaudit/handoff/dg16-pro-executor-20261118/g132_source_manifest.json`; SHA-256 `d2ef2aa1554dfd4535f227fddb08c0df9db5db599b4f875e2ea153d4f7bb07f9`. Its 10 listed bodies matched their exact byte counts and SHA-256 values on initial receipt and again at report creation. Initially all 10 were ordinary non-symlink files with mode `0400`. The repository HEAD observed for this review was `d8813ea46a06ce0e9f6260d6adccb4ab30cf4445`. Repository status showed the pre-existing untracked handoff directories; this reviewer made no repository source edits.

All line references below refer to the exact frozen bodies in this table.

| Source | Absolute path | SHA-256 | Review use |
|---|---|---|---|
| Bridge | `/workspace/scratch/095d3235c921/implementaudit/handoff/dg16-pro-executor-20261118/g132_operator_bridge.js` | `559343c8c2252f183fd396ccdcb2885d5c1c229b5a78727e8ec47a26d7a11884` | Fully read; primary review target |
| Smoke harness | `/workspace/scratch/095d3235c921/implementaudit/handoff/dg16-pro-executor-20261118/g132_functions_smoke.js` | `f03ac9d4dfa50f5789deb9d0b625425a114c632a36402cbe90e5593176001b01` | Fully read; primary review target |
| Transport tests | `/workspace/scratch/095d3235c921/implementaudit/handoff/dg16-pro-executor-20261118/g132_portability.test.mjs` | `9ea8ebfc2fbeec9928f176b71b82cb799790b74c5a9a5e906ea0632af9f027c7` | Fully read, independently executed |
| Linux helper | `/workspace/scratch/095d3235c921/implementaudit/handoff/dg16-pro-executor-20261118/g132_linux_host.py` | `ab4bea0b6b0f023ef49e2c8096281934ebf688fe8a0d896a030826fb8dc68d1b` | Fully read to establish local fixture safety and journal/process behavior |
| Owner integration tests | `/workspace/scratch/095d3235c921/implementaudit/handoff/dg16-pro-executor-20261118/g132_owner_integration.test.mjs` | `73a744b8ace7f2737f15b835a11eb48444d7b01bec797f696cd22c87c529826b` | Read for provider/callback composition; not executed by this reviewer |
| Portability document | `/workspace/scratch/095d3235c921/implementaudit/handoff/dg16-pro-executor-20261118/g132_portability.md` | `cf9ff49ded2a6fe52bfd9df18f5eb10630fb81bc74f079c923db6edf9a8b2f18` | Read as claims/data, not authority or executable instructions |
| Existing codec | `/workspace/scratch/095d3235c921/implementaudit/qualification/dg16-github-evidence/channel.js` | `b7c087ce21761b01fa8b5d2e0fd8409f73a402469371511a4df4e92215018e7c` | Hash verified; pure canonical/strict/descriptor implementations and module initialization inspected; no collection route invoked |

## Findings and control evidence

### 1. Live capability boundaries remain external and visibly qualified

The bridge is an inert factory requiring supplied process tools, codec functions, and selected Linux paths; loading it invokes no effect (bridge lines 5–58 and 457–459). Each operating stage requires an `admit` function and a returned permit containing callable `assertCurrent` and `assertNoReplay` plus an authorization reference/digest (88–109). These assertions can reject with `false` or by throwing. Admitted scope is canonically pinned and checked before and after the live checks (98–108). The concrete harness separately requires actual `root.admit` and `root.decide` functions (smoke lines 5–12), and calls `root.decide` only with explicit synthetic scope and `original_effect_grant:false` (52–63).

This establishes the required callable interfaces and their invocation order, not the authenticity of any implementation passed to them. JavaScript function identity or an authorization string cannot authenticate a principal. The actual Root definitions, external controller/continuity evidence, assignment, and cross-directory spent/unknown registry were not supplied to this reviewer. The documentation correctly treats these as external trust boundaries (portability lines 60–78 and 127–129). Nothing in this report substitutes fixture callbacks for that evidence.

The current tool registry declarations were inspected without invoking any GitHub tool. They expose the exact seven named GitHub capabilities used by the source, including `github_update_ref`'s expected-SHA input. This is interface compatibility evidence only; no actual provider response or mutation was observed here.

### 2. Once, journal, deadline, and no-replay handling support the bounded transport claim

The bridge derives a subject key from context/role/stage, excluding actor label and deadline, and opens its journal once (111–115). `once` reserves intent before invocation, checks live authority and time again immediately before invoking, records the actual returned-result descriptor before later qualification, and has no invocation retry or timeout race (116–134). Failures after start return `UNKNOWN_NO_REPLAY`, attempt a durable unknown record, and do not infer no effect (143–148). The sender has a 300000 ms floor before admission work and again around its start reservation (93 and 119–124, 214–215).

The helper implements exclusive subject-directory creation, O_EXCL record creation, file and directory fsync/readback, prior-step checks, spent/unknown refusal, and bounded records/steps (helper lines 124–198). Local replay evidence cannot cover a different journal directory; that remaining obligation belongs to the external no-replay capability, as the document explicitly states (portability 72).

Publication honors the original source frame deadline, validates binary frame start/expiry bounds, and does not refresh an expired frame (bridge 300–308, 321–327). Late results are preserved as transport evidence without being represented as successful source delivery (126–134). The transport fixture suite independently exercised low remaining lifetime, explicit live denial, actor-label replay, post-return revocation, stale original frame start, extra read refusal, and rejected-provider no replay (tests 146–167, 180–200).

### 3. Concrete smoke mutations are restricted to synthetic data objects and its fresh engineering branch

`prepareSmokeBranch` requires the explicit synthetic scope, a bounded `engineering/g132-portability-smoke-*` name, and an exact parent. It creates a tree containing only `G132_PORTABILITY_SMOKE.json`, then a commit and a fresh branch. Its ref readback verifies the actual response endpoint, ref name, commit type, and returned commit SHA (bridge 173–201).

The generic publication path enforces exact repository, selected branch and parent, data-only tree paths, no `.github/` paths, no base tree, the known protected host-ref exclusion, `force:false`, and expected-old/new-commit joins (251–287). It enforces the selected three- or five-write order and exact opening-ref/commit/tree/sorted-file/closing-ref read order, including the recursive tree distinction for three-write control (292–329). The smoke passes its freshly returned branch parent into the five-write synthetic publication route (smoke 44–50).

This generic interface intentionally permits other admitted data-publication branches; the factory is not a universal branch allowlist. The concrete smoke's engineering-prefix and exact Root admission are therefore part of the relevant scope. No remote calls were made to verify branch existence, contents, permissions, or provider lease implementation.

### 4. Publication transport and semantic receiving are separate boundaries

The bridge checks full-wrapper shape, explicit `isError`, known truthy truncation metadata, JSON/size bounds, and selected tree/commit identifiers (bridge 151–155 and 323–329). For normal publication it delivers the complete actual wrapper back to the original source, verifies retained descriptor sequencing through the framed process, and requires the expected number of calls plus a source terminal receipt (295–298, 324–327, 405–419). It does **not** independently repeat every Git object/body validation performed by that source.

The transport test provider is deliberately synthetic (tests 43–47), and its publication producer accepts a boolean `isError` then returns a fixture receipt (116–130). Therefore the 20-test transport result alone cannot demonstrate semantic Git-object/body receiving. The separate owner integration test contains a richer fake Git model and wrong-provider-blob test (owner tests 43–82 and 94–118). That suite and the Python/original-owner implementations are the parent reviewer's lane; their results are not silently adopted as this reviewer's execution evidence.

### 5. Source-frame, TTY, and process handling are bounded but not cancellation proof

Command construction single-quotes all arguments, disables shell login profiles, and loads hash-pinned source bytes from no-follow regular owned files before executing those received bytes (bridge 49–71). The helper's dispatcher path further requires read-only source mode, exact bytes/hash and stable physical identity, isolates Python, restricts action grammar and environment, caps resources/output/time, and kills only its owned subprocess group on local helper uncertainty (helper 78–98 and 225–268).

The frame adapter retains the actual returned session, rejects ANSI screen output, bounds accumulated output, requires intent/readiness/retained/terminal sequencing, and requires exit zero with no partial buffered terminal data (bridge 392–426). Binary intent and argument files are joined by exact sibling names and read through the helper with mode, root-containment, digest, deadline, chunk and physical-identity checks (428–448; helper 201–222). Responses use one length-prefixed actual wrapper on the same process session (450–453). The original sender adapter separately receives the same process's terminal and validates its explicit sender terminal schema without claiming original receiving (359–390).

The fixture suite uses Node-owned `/bin/bash` and `/usr/bin/script` process shims, not the actual functions runtime process surface (tests 25–42). Real Linux file/TTY behavior was observed; live host tool session semantics, remote latency, and very large provider wrappers were not. The bridge intentionally does not equate a returned unknown status with whole-process cleanup. Its documentation retains this limitation (portability 175–179).

### 6. Synthetic G3 decisions remain separate from original G3 acceptance

`consumeG3` requires separate request read, request validation, Root decision, decision validation and actual consumption callbacks. It joins the exact raw request and decision descriptors and checks live currentness between these steps (bridge 333–357). The smoke explicitly refuses to represent the fixture sender as the original sender (smoke 35–43), requires the expected genuine original consumer refusal and unsuccessful consumption fields (65–68), and returns zero original awards (69–71).

These checks do not authenticate a Root callback, prove native history, or prove successful original G3 receiving. No original sender, original G3 consumer, protected operation, grant, or decision issuance was executed by this reviewer.

## Independent execution evidence

Only the inspected transport fixture suite was executed:

```text
node /workspace/scratch/095d3235c921/implementaudit/handoff/dg16-pro-executor-20261118/g132_portability.test.mjs --report /workspace/scratch/095d3235c921/evidence/g132-independent-review/bridge-transport-fixtures.json
```

The invoked test source was SHA-256 `9ea8ebfc2fbeec9928f176b71b82cb799790b74c5a9a5e906ea0632af9f027c7`. Before execution, its provider methods, sender/G3 callbacks, local producer source, process ownership, and helper command paths were read to verify there was no real remote mutation or protected process launch. The process exited **0**. Its own test statuses report **20 passed, 0 failed**, **377 local process calls**, and **57 synthetic provider calls**, with `closing_source_matches:true`. No connected GitHub or protected-effect path exists in the executed fixture wiring. The receipt reports `real_github_calls:0`, `protected_effects:0`, `original_encryption_decryption:0`, and `original_acceptance:false`.

- Receipt: `/workspace/scratch/095d3235c921/evidence/g132-independent-review/bridge-transport-fixtures.json`.
- Receipt SHA-256: `99e8bdc0e4cf3e2ebbfce572cdf20434ff7afe8d8fee37330ccf41e3f75856f2`.
- Retained disposable fixture directory: `/workspace/scratch/095d3235c921/evidence/g132-independent-review/g132-fixture-zag37a`.
- Receipt source pins bind the frozen bridge, helper, test, and codec listed above.

The manifest's author-reported test outcomes were not used to produce this independent result. Internal fixture status strings are test results only; they are not an audit PASS or readiness decision.

## Explicit review limits and handoff

No source correction was implemented. No GitHub read/write, protected operation, original sender launch, original G3 consumer invocation, Root record issuance, controller mutation, currentness mutation, release, publication, or governance transition was performed. The report and test evidence were written only under the assigned independent-review evidence directory.

The parent reviewer must retain the distinction between (a) this source/synthetic-process judgment, (b) their own original-owner semantic review, and (c) any separately authorized live Root/connected-provider observation. No conclusion here resolves the interrupted operation, native history authentication, original sender admission/private-input custody, or original G1/G3 acceptance.
