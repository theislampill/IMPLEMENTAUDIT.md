# Independent G132 Linux and model-side operator review

## Bounded result

**No blocking source finding was established for the concrete nonprotected connected-smoke route in the frozen packet.** The reviewed adapter provides a concrete Linux/model-side composition, and the independently executed local fixtures support its stated transport and exact-owner receiving mechanics. Root retains the decision to run the connected smoke and must supply actual live capabilities for that specific scope.

This is an ordinary independent source review. It grants no launch, publication, currentness, original sender, protected-operation or acceptance authority. The interrupted protected operation remains `UNKNOWN_NO_REPLAY`. The expected original G3 observation on this host remains a genuine credential refusal, not successful consumption.

The source manifest is `handoff/dg16-pro-executor-20261118/g132_source_manifest.json`, 5234 bytes, SHA256 `d2ef2aa1554dfd4535f227fddb08c0df9db5db599b4f875e2ea153d4f7bb07f9`. I independently verified all ten listed members and the manifest itself: eleven regular files, mode `0400`. The source hashes and modes still match after testing. No reviewed source was changed.

## Independence and evidence division

The primary reviewer is `/root/g2_independent`; the source author is `/root/dg18_execution`. `authoring_context_reuse: no`. I received the immutable assignment and source files, not the author's implementation transcript. I inspected the complete Python host, runtime, fixture producer, smoke preparation and owner integration test, the concrete JavaScript harness, the relevant original source functions, and the full portability document. Author test results were not treated as independent verification.

I assigned a separate minimal-context, `fork_turns=none` read-only review of the JavaScript bridge, harness and transport tests to `/root/g2_independent/g132_bridge_review`. I read its complete report before integrating it. That reviewer independently inspected and executed the transport fixtures; I independently inspected and executed the original-owner integration fixtures. Their evidence and my evidence are separately retained. Neither reviewer authored implementation changes or Root decisions.

Both reviewers report the host/developer label **GPT-6 Astra Pro**. This is a truthful host/developer label and self-report, not an independently observed provider deployment ID or native model-history assertion. No internal `audit-assess` route or formal audit disposition was invoked.

## Source and physical-host assessment

`g132_linux_host.py` (SHA256 `ab4bea0b6b0f023ef49e2c8096281934ebf688fe8a0d896a030826fb8dc68d1b`) implements local physical I/O and process support only. It observes actual credentials, interpreter/process identity and boot identity while explicitly reporting that native model identity was not observed. Inodes and nanosecond times cross the JavaScript boundary as decimal strings. Its reads enforce canonical paths, ordinary owned single-link files, no-follow descriptors, extended-attribute exclusion, exact source/data pins, and stable before/open/after file identity. Private exchange bodies require the specified mode and containment.

The journal uses exclusive creation, durable file and directory writes, a held lock, sequential settled predecessors, bounded populations and explicit spent/unknown refusal. A failed or uncertain step does not authorize a second call. This local mechanism does not establish cross-directory or cross-session no-replay by itself; that obligation belongs to Root's actual external capability and retained operation state.

Pinned dispatcher invocation uses isolated Python, a fixed action grammar, a minimal environment, resource/output/time bounds and the actual returned process. The bridge preserves frame deadlines and uses the same process session for framed results. A transport unknown result is not a cancellation or whole-process-cleanup proof. These limits are explicit in the source documentation and the bridge subreview.

## Actual Root capabilities and original sender boundary

The frozen bridge is `g132_operator_bridge.js`, SHA256 `559343c8c2252f183fd396ccdcb2885d5c1c229b5a78727e8ec47a26d7a11884`. Its exact callable boundaries, once handling, source frames, sender floor, publication order and path restrictions are detailed with source lines in `bridge-review.md`.

Root must supply real `admit`, `assertCurrent`, `assertNoReplay` and `decide` functions backed by its actual current assignment and continuity evidence. Function shape, a controller string or an authorization digest alone does not authenticate the principal. The connected smoke must use Root's current verified receipt; the reported G0003 continuation does not require rewriting the frozen source or reusing a historical actor's identity.

`g132_owner_runtime.py` (SHA256 `8d09c09268c9ae95d27a6c6838955ac1c2badd25ea1321669aef1180eadb9268`) calls the exact original binder for the original sender route. That route still requires the existing actual entry, operation, late receiving and dispatcher admission, validates current owner credentials and expiry, and installs a fresh pinned selection. Neither my tests nor the public smoke exercised that original admission gate or original private sender. The helper cannot supply the missing private prerequisites or resolve the interrupted effect.

The separate `g132_sender_fixture.py` (SHA256 `622013a7ed7ff9b9e27b39a91e85f135012812691532094b266b445149553257`) is explicitly a synthetic producer and broker. It invokes original dispatcher `Journal`, `reserve`, `complete_result` and `publish` functions for eighteen fixed public GETs. It creates no original operation body or admission and returns explicit false claims for original binding and original sender execution. I inspected the original endpoint function: the six repeated resource kinds refer only to the selected historical run, attempt, jobs, artifacts and exact workflow source.

## Publication and G3 assessment

I independently verified the original operator commit/tree `d76c1e9c22fd816fbc6ddcac0080625b8f087d23` / `b2c3237e05ff76207218ec6ecd7df85591232efa`, its exact operator index, and all six original source blobs selected by smoke preparation. The approved G3 source was independently read from commit `301aeecde08ba6f169bc3cd837eae6f6ad068219`, tree `b81d198242901d7ea24b4bacfb8fad7877e657a5`: 153706 bytes, SHA256 `b85cca1550ff8e7c1c89778180e53a5c70f306f0c8725ba60ef3ccd4bbc3a6ad`.

The concrete smoke creates a fresh `engineering/g132-portability-smoke-*` branch whose first tree has synthetic data only. Its original binary publication route makes five writes followed by six immutable readbacks, including semantic object/body receiving by the pinned original owner. The initial branch preparation and the publication are separate stages. The expected old parent, `force:false`, selected read order and data-only paths remain required. This is not a general authorization for every branch accepted by the generic adapter.

The runtime changes only the original publication journal constructor's fixed root selection; original journal methods and original binary receiving remain in use. The content predicate is openly synthetic. `INPUTS.cms` is literal public fixture text, not encrypted private inputs, and its acceptance cannot establish original content-policy or encryption receiving.

The approved G3 request and decision validators are actually invoked on synthetic bytes. The runtime proposal is explicitly unissued; the currently executing Root must make the real, separately scoped fixture decision through its callback. The subsequent probe invokes the approved decorated `consume(api)`. I inspected the original wrapper and consumer: `context(api)` checks real UID/EUID/GID/EGID zero before protected input reads, reservation or consumption. On this UID 1000 host the actual diagnostic reports `ACTUAL_ROOT_CUSTODY_REQUIRED`, with all seven effect states `NOT_STARTED`, no reservation and no Root consumption. No environment or credentials were forged to bypass this gate.

## Independent checks and receipts

The bridge reviewer independently ran the inspected transport suite: **20 passed, 0 failed**, exit 0, 377 local process calls and 57 synthetic provider calls. Its source closure remained unchanged. Receipt: `bridge-transport-fixtures.json`, SHA256 `99e8bdc0e4cf3e2ebbfce572cdf20434ff7afe8d8fee37330ccf41e3f75856f2`. Detailed subreview: `bridge-review.md`, SHA256 `e9ecad811d4cff0f30ab354f4cf310ccaf4bb3f1e2e7974675516b43df97fc6c`.

I independently ran the inspected owner integration suite: **2 passed, 0 failed**, exit 0, 424 local process calls. The positive case completed eighteen dispatcher reads, original binary publication receiving, strict G3 decision validation and the actual nonroot G3 refusal. The negative supplied a wrong provider blob identity: original receiving refused before G3, the bridge returned `UNKNOWN_NO_REPLAY`, and reentry made no additional provider call. Receipt: `owner-integration-receipt.json`, 1855 bytes, SHA256 `b6b91efd4f2ef9039bffb60ef04461695bd9f238fdb4f5fb6668d0cc82921d26`.

I separately read the actual positive/negative receipts and original diagnostic rather than accepting the test summary alone. Those checks are in `owner-receiving-checks.json`, 2341 bytes, SHA256 `cdecd680b6bad4121e0c8adfe7d32283f6586ade3b9c11c0bc6af4f0e2f0079d`. All fixture journals remain retained under this review directory. The executed provider and Root callbacks were synthetic; both test lanes made zero connected GitHub calls and zero protected effects. The owner integration's real original consumer invocation is specifically the observed credential refusal, not a successful original operation.

## Precise connected-smoke limits

The intended connected smoke makes 34 actual GitHub calls if it completes: one opening public read, eighteen sender-mechanics reads, four branch-preparation calls, and eleven original publication calls. Eight calls are mutations limited to new Git objects and the selected new synthetic engineering branch. Source review and local tests do not establish the live provider responses, actual tool provenance, actual Root capability authenticity, latency, or final remote byte readbacks. Root must receive those actual effects and preserve any uncertain result without automatic retry or cleanup reset.

The 590-second selected smoke interval, original 600-second upper bound, 300000 ms remaining sender-start floor and original per-frame deadlines remain real constraints. A slow or failed provider may cause the bounded smoke to refuse; the source does not promise completion or confer deadline-extension authority. Root's concrete callback implementation must recheck currentness and known spent/unknown state, and must issue only the explicit synthetic/no-original-grant decision.

A completed connected smoke would establish a bounded transport/publication observation plus a genuine current-host G3 refusal. It would still not establish the original sender admission, private bodies or recipient custody, native tool-history authenticity, authentic original same-job G1/G3 inputs, currentness/effect authority, resolution of `UNKNOWN_NO_REPLAY`, or original G132/G1/G3 acceptance. No original awards are added by this review.
