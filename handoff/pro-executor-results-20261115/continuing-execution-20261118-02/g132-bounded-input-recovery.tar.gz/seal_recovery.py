#!/usr/bin/env python3
"""Validate receipts and seal the safe, bounded recovery result."""
import datetime
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.umask(0o077)


def read(name):
    return json.loads((ROOT / name).read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


census = read("TRANSCRIPT_CENSUS.json")
primary = read("EXTRACTION_RECEIPT.json")
gap = read("EXTRACTION_GAP_CLOSURE.json")
capability = read("CAPABILITY_CENSUS.json")
assert not primary["matches"] and not gap["matches"] and not gap["new_bounds"]
assert len(primary["bounds"]) == len(gap["depth_gap_closures"]) == 2
assert all(x["approved_matches"] == 0 for x in gap["depth_gap_closures"])
index = (ROOT / "EXPECTED_INPUT_INDEX.json").read_bytes()
assert len(index) == 1397
assert sha(index) == "d069c3a7c66f54ffe7eae32ca89701743e96bdd2a0e221f52864150887390f15"
rows = []
for entry in read("query_receipts/03-approved-hash-candidate-find.json"):
    assert entry["status"] == "fulfilled"
    native = entry["value"]["structuredContent"]
    while "structuredContent" in native:
        native = native["structuredContent"]
    rows.extend(native["results"])
assert len(rows) == 10
assert all(row["total_match_count"] == 0 and not row["has_more"] for row in rows)
result = {
    "schema": "g132.bounded-input-recovery-result.v1",
    "status": "BOUNDED_CENSUS_COMPLETE_NO_APPROVED_INPUT_RECOVERED",
    "sealed_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "principal_root_continuity_reported": "G0004@2a1379feb07e0c39a196c3b4275f56ae5092660a",
    "approved_input_index": {
        "commit": "301aeecde08ba6f169bc3cd837eae6f6ad068219",
        "path": "qualification/dg16-r5-g1-hosted-episode/carrier/INPUT_INDEX.json",
        "bytes": len(index), "sha256": sha(index)},
    "input_results": {name: {**pin, "status": "EXACT_APPROVED_BODY_NOT_RECOVERED"}
                      for name, pin in primary["expected_inputs"].items()},
    "sources": census["files"],
    "total_transcript_bytes": sum(row["bytes"] for row in census["files"]),
    "primary_counts": primary["counts"],
    "depth_skips_resolved": 2,
    "standalone_literal_counts": gap["standalone_literals"],
    "standalone_scanner_counts": gap["scanner_counts"],
    "exact_hash_search_returned_candidates": 10,
    "exact_hash_find_matches_in_returned_candidates": 0,
    "library_wide_absence_proven": False,
    "tool_interface_observation_utc": capability["observed_utc"],
    "tool_interface_count": capability["available_tool_count"],
    "new_dg18_ready_original_cells": [],
    "preserved": ["DG18 exact6b accepted", "DG18 W-FULL accepted",
                  "DG18 criterion11 accepted", "DG18 A7 accepted",
                  "DG18 N1 LOST/UNKNOWN", "Interrupted protected operation UNKNOWN_NO_REPLAY",
                  "Frozen G132 adapter manifest d2ef2aa1554dfd4535f227fddb08c0df9db5db599b4f875e2ea153d4f7bb07f9"],
    "effects": {"transcript_code_executed": False, "protected_ref_updates": 0,
                "protected_launches": 0, "private_sender_operations": 0,
                "grant_issuances": 0, "native_proof_claims": 0,
                "github_writes_in_this_lane": 0, "original_acceptance_awards": 0,
                "frozen_adapter_edits": 0},
    "bounds": [
        "Only the three named transcripts were materialized and fully scanned by the declared decoders.",
        "Hash-based Library semantic search was bounded to its first ten returned candidates and established no exact match or Library-wide absence.",
        "Incomplete/nonliteral expressions were not evaluated, and missing runtime values were not inferred.",
        "Split/unspecified encodings and arbitrary compression are outside the declared decoders.",
        "Historical data would not confer fresh admission, original private custody, native events or replay authority."]}
(ROOT / "RECOVERY_RESULT.json").write_text(json.dumps(result, indent=2) + "\n")
files = ["RECOVERY_REPORT.md", "EXPECTED_INPUT_INDEX.json", "TRANSCRIPT_CENSUS.json",
         "TRANSCRIPT_01_CENSUS.json", "EXTRACTION_RECEIPT.json", "EXTRACTION_GAP_CLOSURE.json",
         "CAPABILITY_CENSUS.json", "RECOVERY_RESULT.json", "extract_exact_inputs.py",
         "close_extraction_gaps.py", "seal_recovery.py"]
files += [str(p.relative_to(ROOT)) for p in sorted((ROOT / "query_receipts").glob("*.json"))]
manifest = {"schema": "g132.input-recovery-manifest.v1", "files": [],
            "private_transcripts_copied_to_repository": False}
for name in files:
    path = ROOT / name
    data = path.read_bytes()
    manifest["files"].append({"path": name, "bytes": len(data), "sha256": sha(data)})
manifest_path = ROOT / "RECOVERY_MANIFEST.json"
manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
for name in files + [manifest_path.name]:
    (ROOT / name).chmod(0o400)
print(json.dumps({"status": result["status"], "files": len(files),
                  "manifest": {"path": str(manifest_path), "bytes": manifest_path.stat().st_size,
                               "sha256": sha(manifest_path.read_bytes())},
                  "report": {"bytes": (ROOT / "RECOVERY_REPORT.md").stat().st_size,
                             "sha256": sha((ROOT / "RECOVERY_REPORT.md").read_bytes())}}))
