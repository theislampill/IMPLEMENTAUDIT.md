#!/usr/bin/env python3
"""Data-only recovery. No transcript code is evaluated or executed.

Only bodies with the approved size AND SHA-256 are written. Parsing a complete
JSON/Python literal and serializing its existing data is recorded explicitly;
no missing field, grant, authority, historical effect or native input is inferred.
"""
import ast
import base64
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import time

ROOT = Path(__file__).resolve().parent
TARGET_NAMES = (
    "COMPOSITION_NATIVE_APPLICABILITY_ADOPTION.json",
    "COMPOSITION_PLACEMENT_RECEIVING.json",
    "COMPOSITION_ROOT_ADMISSION.json",
    "SOURCE_ACQUISITION.json",
)
INDEX = json.loads((ROOT / "EXPECTED_INPUT_INDEX.json").read_text())
TARGETS = {n: INDEX[n] for n in TARGET_NAMES}
BY_SIZE = {v["bytes"]: (n, v["sha256"]) for n, v in TARGETS.items()}
MAX_LITERAL = 2 * 1024 * 1024
MAX_DEPTH = 8
MAX_BLOBS = 50000
MAX_TOTAL_BLOB_BYTES = 512 * 1024 * 1024
COUNTS = collections.Counter()
MATCHES = []
BOUNDS = []
SEEN_BLOBS = set()
SEEN_OBJECTS = set()
SAME_NAME_REFS = []
BEGIN = time.monotonic()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def record_bound(row):
    COUNTS["bounded_skips"] += 1
    if len(BOUNDS) < 100:
        BOUNDS.append(row)


def reject_dupes(pairs):
    result = {}
    for k, v in pairs:
        if k in result:
            raise ValueError("duplicate-key")
        result[k] = v
    return result


DECODER = json.JSONDecoder(object_pairs_hook=reject_dupes)


def check_bytes(data, provenance):
    item = BY_SIZE.get(len(data))
    if item is None:
        return
    COUNTS["exact_size_candidates"] += 1
    name, wanted = item
    if digest(data) != wanted:
        return
    output = ROOT / "recovered_inputs" / name
    output.parent.mkdir(mode=0o700, exist_ok=True)
    if output.exists():
        assert output.read_bytes() == data
    else:
        fd = os.open(output, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(data)
    MATCHES.append({"name": name, "bytes": len(data), "sha256": wanted,
                    "path": str(output), "provenance": provenance,
                    "fresh_authority": False})


def complete_literal_end(text, start):
    """Locate one balanced literal, with bounded work; no source evaluation."""
    stack = []
    quote = None
    i = start
    end = min(len(text), start + MAX_LITERAL)
    while i < end:
        c = text[i]
        if quote:
            if c == "\\":
                i += 2
                continue
            if text.startswith(quote, i):
                i += len(quote)
                quote = None
                continue
        elif c in "\"'":
            quote = c * 3 if text.startswith(c * 3, i) else c
            i += len(quote)
            continue
        elif c in "{[(":
            stack.append({"{": "}", "[": "]", "(": ")"}[c])
            if len(stack) > 100:
                COUNTS["literal_nesting_rejected"] += 1
                return None
        elif c in "}])":
            if not stack or stack.pop() != c:
                return None
            if not stack:
                return i + 1
        i += 1
    COUNTS["incomplete_or_over_limit_literals"] += 1
    return None


def inspect_object(obj, provenance, depth):
    if not isinstance(obj, (dict, list, tuple, str, bytes)):
        return
    if isinstance(obj, bytes):
        scan_blob(obj, provenance + [{"transform": "literal-bytes"}], depth + 1)
        return
    if isinstance(obj, str):
        # Exact present string content; never execute it or expand variables.
        if len(obj) >= min(BY_SIZE):
            try:
                data = obj.encode("utf-8")
            except UnicodeError:
                COUNTS["non_utf8_string_rejected"] += 1
                return
            scan_blob(data, provenance + [{"transform": "literal-string-utf8"}], depth + 1)
        return
    try:
        canonical = json.dumps(obj, sort_keys=True, separators=(",", ":"),
                               ensure_ascii=True, allow_nan=False).encode()
    except (TypeError, ValueError, RecursionError):
        COUNTS["non_json_literal_rejected"] += 1
        for i, child in enumerate(obj.values() if isinstance(obj, dict) else obj):
            inspect_object(child, provenance + [{"transform": "existing-nonjson-child", "ordinal": i}], depth + 1)
        return
    key = digest(canonical)
    if key in SEEN_OBJECTS:
        COUNTS["duplicate_object"] += 1
        return
    SEEN_OBJECTS.add(key)
    COUNTS["unique_complete_objects"] += 1
    if isinstance(obj, dict):
        for name in TARGET_NAMES:
            if name in obj:
                value = obj[name]
                desc = {"name": name, "value_type": type(value).__name__,
                        "provenance": provenance}
                if isinstance(value, dict):
                    desc["keys"] = sorted(str(k) for k in value)
                    for k in ("bytes", "sha256"):
                        v = value.get(k)
                        if (k == "bytes" and isinstance(v, int)) or (k == "sha256" and isinstance(v, str) and re.fullmatch(r"[0-9a-f]{64}", v)):
                            desc[k] = v
                SAME_NAME_REFS.append(desc)
    # Serialization is attempted only for COMPLETE present data. The target
    # cryptographic pin, not structural similarity, decides recovery.
    for sort in (False, True):
        for ascii_only in (False, True):
            for indent, compact in ((None, False), (None, True), (2, False), (4, False)):
                options = {"sort_keys": sort, "ensure_ascii": ascii_only,
                           "indent": indent, "allow_nan": False}
                if compact:
                    options["separators"] = (",", ":")
                value = json.dumps(obj, **options)
                for crlf in (False, True):
                    encoded = (value.replace("\n", "\r\n") if crlf else value).encode("utf-8")
                    for ending in (b"", b"\r\n" if crlf else b"\n"):
                        check_bytes(encoded + ending, provenance + [{
                            "transform": "serialize-complete-existing-data",
                            "sort_keys": sort, "ensure_ascii": ascii_only,
                            "indent": indent, "compact": compact, "crlf": crlf,
                            "trailing_newline": bool(ending)}])
    for i, child in enumerate(obj.values() if isinstance(obj, dict) else obj):
        inspect_object(child, provenance + [{"transform": "existing-child", "ordinal": i}], depth + 1)


def scan_blob(data, provenance, depth=0):
    check_bytes(data, provenance)
    if depth > MAX_DEPTH:
        record_bound({"kind": "depth", "bytes": len(data), "provenance": provenance})
        return
    key = digest(data)
    if key in SEEN_BLOBS:
        COUNTS["duplicate_blob"] += 1
        return
    if len(SEEN_BLOBS) >= MAX_BLOBS or COUNTS["blob_bytes"] + len(data) > MAX_TOTAL_BLOB_BYTES:
        record_bound({"kind": "aggregate", "bytes": len(data), "provenance": provenance})
        return
    SEEN_BLOBS.add(key)
    COUNTS["blobs"] += 1
    COUNTS["blob_bytes"] += len(data)
    # Exact contiguous bodies beginning with JSON object openers. Whitespace
    # before a body is considered up to eight bytes and recorded, never inferred.
    for m in re.finditer(rb'\{\s*"', data):
        starts = [m.start()]
        pos = m.start()
        while pos and m.start() - pos < 8 and data[pos - 1:pos] in (b" ", b"\t", b"\r", b"\n"):
            pos -= 1
            starts.append(pos)
        for start in starts:
            for length in BY_SIZE:
                if start + length <= len(data):
                    COUNTS["raw_windows"] += 1
                    check_bytes(data[start:start + length], provenance + [{"transform": "exact-contiguous-window", "byte_offset": start, "bytes": length}])
    # Maximal base64 tokens only; this is transport decoding, not decryption.
    for m in re.finditer(rb"(?<![A-Za-z0-9+/])[A-Za-z0-9+/]{568,}={0,2}(?![A-Za-z0-9+/=])", data):
        if len(m.group()) > MAX_LITERAL * 2:
            record_bound({"kind": "base64-token", "bytes": len(m.group()), "provenance": provenance})
            continue
        try:
            decoded = base64.b64decode(m.group(), validate=True)
        except ValueError:
            COUNTS["invalid_base64"] += 1
            continue
        COUNTS["decoded_base64"] += 1
        scan_blob(decoded, provenance + [{"transform": "strict-base64", "byte_offset": m.start(), "encoded_bytes": len(m.group())}], depth + 1)
    try:
        text = data.decode("utf-8")
    except UnicodeError:
        COUNTS["non_utf8_blob"] += 1
        return
    for m in re.finditer(r"\{\s*['\"]", text):
        start = m.start()
        end = complete_literal_end(text, start)
        if end is None:
            continue
        source = text[start:end]
        if len(source) < 2:
            continue
        try:
            obj = DECODER.decode(source)
            method = "strict-json"
        except (ValueError, RecursionError):
            try:
                obj = ast.literal_eval(source)
                method = "python-literal-eval-data-only"
            except (ValueError, SyntaxError, RecursionError, MemoryError, TypeError):
                COUNTS["nonliteral_object_rejected"] += 1
                continue
        COUNTS["parsed_complete_objects"] += 1
        inspect_object(obj, provenance + [{"transform": method, "character_offset": start, "source_characters": end - start}], depth + 1)


def main():
    os.umask(0o077)
    census = json.loads((ROOT / "TRANSCRIPT_CENSUS.json").read_text())
    for row in census["files"]:
        data = Path(row["path"]).read_bytes()
        assert len(data) == row["bytes"] and digest(data) == row["sha256"]
        assert os.getxattr(row["path"], "user.library-file-id").decode() == row["library_file_id"]
        scan_blob(data, [{"library_file_id": row["library_file_id"], "source_path": row["path"], "source_bytes": len(data), "source_sha256": digest(data)}])
        print(json.dumps({"finished_library_file_id": row["library_file_id"], "counts": dict(COUNTS), "exact_matches": len(MATCHES), "bounds": len(BOUNDS)}), flush=True)
    report = {"schema": "g132.exact-input-extraction.v1", "status": "COMPLETE_WITH_DOCUMENTED_BOUNDS" if BOUNDS else "COMPLETE_FOR_DECLARED_DECODERS", "expected_inputs": TARGETS,
              "inputs": census["files"], "counts": dict(COUNTS), "matches": MATCHES,
              "same_name_references": SAME_NAME_REFS, "bounds": BOUNDS,
              "limits": {"max_literal_bytes": MAX_LITERAL, "max_depth": MAX_DEPTH,
                         "max_blobs": MAX_BLOBS, "max_total_blob_bytes": MAX_TOTAL_BLOB_BYTES},
              "duration_seconds": round(time.monotonic() - BEGIN, 3),
              "code_execution_from_transcripts": False, "grants_issued": 0,
              "protected_effects": 0, "original_acceptance": False}
    output = ROOT / "EXTRACTION_RECEIPT.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"receipt": str(output), "bytes": output.stat().st_size, "sha256": digest(output.read_bytes()), "recovered_unique_inputs": sorted({m["name"] for m in MATCHES})}), flush=True)


if __name__ == "__main__":
    main()
