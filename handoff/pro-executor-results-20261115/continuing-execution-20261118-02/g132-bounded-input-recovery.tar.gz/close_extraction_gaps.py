#!/usr/bin/env python3
"""Focused data-only checks for reported depth skips and standalone literals."""
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("exact_scanner", ROOT / "extract_exact_inputs.py")
scanner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scanner)
os.umask(0o077)
primary = json.loads((ROOT / "EXTRACTION_RECEIPT.json").read_text())
closures = []

# Replay transformations of already present DATA only, never operations from a
# transcript. These two depth skips are independently bounded small strings.
for bound in primary["bounds"]:
    assert bound["kind"] == "depth"
    chain = bound["provenance"]
    value = Path(chain[0]["source_path"]).read_bytes()
    assert hashlib.sha256(value).hexdigest() == chain[0]["source_sha256"]
    for step in chain[1:]:
        transform = step["transform"]
        if transform == "strict-json":
            if isinstance(value, bytes):
                value = value.decode("utf-8")
            start, length = step["character_offset"], step["source_characters"]
            value = scanner.DECODER.decode(value[start:start + length])
        elif transform == "existing-child":
            value = list(value.values())[step["ordinal"]] if isinstance(value, dict) else value[step["ordinal"]]
        elif transform == "literal-string-utf8":
            value = value.encode("utf-8")
        else:
            raise AssertionError("unrecognized recorded transform")
    assert isinstance(value, bytes) and len(value) == bound["bytes"]
    before = len(scanner.MATCHES)
    scanner.scan_blob(value, chain + [{"transform": "focused-depth-gap-check"}], 0)
    closures.append({"source_bytes": len(value), "source_sha256": hashlib.sha256(value).hexdigest(),
                     "approved_matches": len(scanner.MATCHES) - before,
                     "provenance": chain})

literal_candidates = 0
literal_complete = 0
literal_rejected = 0
literal_over_limit = 0
literal_duplicate = 0
seen = set()
pattern = re.compile(r'''(?<![\w])(?:[rRuUbB]{0,2})?(?P<quote>\x27\x27\x27|"""|\x27|")(?=(?:\\[rn]|[ \t\r\n]){0,8}[{\[])''')
for row in primary["inputs"]:
    raw = Path(row["path"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == row["sha256"]
    text = raw.decode("utf-8")
    provenance = [{"library_file_id": row["library_file_id"], "source_path": row["path"],
                   "source_bytes": len(raw), "source_sha256": row["sha256"]}]
    for m in pattern.finditer(text):
        literal_candidates += 1
        quote = m.group("quote")
        i = m.end()
        limit = min(len(text), m.start() + scanner.MAX_LITERAL)
        end = None
        while i < limit:
            if text[i] == "\\":
                i += 2
                continue
            if text.startswith(quote, i):
                end = i + len(quote)
                break
            i += 1
        if end is None:
            literal_over_limit += 1
            continue
        source = text[m.start():end]
        try:
            value = ast.literal_eval(source)
            assert isinstance(value, (str, bytes))
        except (SyntaxError, ValueError, AssertionError, MemoryError, RecursionError):
            literal_rejected += 1
            continue
        literal_complete += 1
        data = value.encode("utf-8") if isinstance(value, str) else value
        digest = hashlib.sha256(data).hexdigest()
        if digest in seen:
            literal_duplicate += 1
            continue
        seen.add(digest)
        scanner.scan_blob(data, provenance + [{"transform": "standalone-complete-python-string-data-only",
                          "character_offset": m.start(), "source_characters": end - m.start()}], 0)

result = {"schema": "g132.exact-input-gap-closure.v1", "status": "COMPLETE_FOR_DECLARED_DECODERS",
          "primary_receipt_sha256": hashlib.sha256((ROOT / "EXTRACTION_RECEIPT.json").read_bytes()).hexdigest(),
          "depth_gap_closures": closures,
          "standalone_literals": {"candidates": literal_candidates, "complete": literal_complete,
                                  "nonliteral_rejected": literal_rejected, "over_limit_or_incomplete": literal_over_limit,
                                  "duplicates": literal_duplicate, "unique_complete": len(seen)},
          "scanner_counts": dict(scanner.COUNTS), "new_bounds": scanner.BOUNDS,
          "matches": scanner.MATCHES,
          "protected_effects": 0, "code_execution_from_transcripts": False,
          "grants_issued": 0, "original_acceptance": False}
path = ROOT / "EXTRACTION_GAP_CLOSURE.json"
path.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"receipt": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                  "literal_counts": result["standalone_literals"], "new_bounds": len(scanner.BOUNDS),
                  "approved_matches": len(scanner.MATCHES)}))
