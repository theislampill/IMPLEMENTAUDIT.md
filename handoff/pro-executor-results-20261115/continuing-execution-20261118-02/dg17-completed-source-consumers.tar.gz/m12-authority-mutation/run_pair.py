import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
PRE = json.loads((ROOT / "PREIMAGE.json").read_text())


def ident(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def run(variant):
    argv = [sys.executable, "-I", "-B", str(ROOT / "frozen_oracle.py"),
            "--variant", variant, "--source", str(ROOT / variant / "validator.py"),
            "--out", str(ROOT / variant / "work")]
    at = datetime.datetime.now(datetime.timezone.utc).isoformat()
    start = time.monotonic()
    p = subprocess.run(argv, capture_output=True, timeout=30)
    (ROOT / variant / "oracle.stdout").write_bytes(p.stdout)
    (ROOT / variant / "oracle.stderr").write_bytes(p.stderr)
    r = dict(argv=argv, exit=p.returncode, started_at=at, elapsed_seconds=time.monotonic()-start,
             stdout=ident(ROOT / variant / "oracle.stdout"), stderr=ident(ROOT / variant / "oracle.stderr"))
    (ROOT / variant / "oracle.receipt.json").write_text(json.dumps(r,indent=2,sort_keys=True)+"\n")
    return r


assert ident(Path(__file__)) == PRE["driver"]
baseline = run("baseline")
assert baseline["exit"] == 0, "baseline failed; mutant not created"
data = (ROOT / "baseline/validator.py").read_bytes()
old, new = (PRE["mutation"][k].encode() for k in ("old", "new"))
assert data.count(old) == 1
(ROOT / "mutant").mkdir()
(ROOT / "mutant/validator.py").write_bytes(data.replace(old, new))
mutant = run("mutant")
obs = json.loads((ROOT / "mutant/work/observations.json").read_text())
caught = (mutant["exit"] == 1 and obs["captures"][1]["output"]["status"] == "VALID" and
          b"AssertionError: authority-shaped supplied child value was admitted" in (ROOT / "mutant/oracle.stderr").read_bytes())
result = dict(schema="dg17.M12.no-authority-source-copy-result.v1", baseline=baseline, mutant=mutant,
              mutation=PRE["mutation"], original_mutation_family="child no-authority/no-chain fence",
              established_limb="supplied child result.authority value guard only",
              actual_mutant_forbidden_value_admission=obs["captures"][1]["output"],
              mutation_caught_at_original_predicate=caught, no_chain_conjunction=False,
              actual_maintainer_route=False, whole_family_award=False, author_award=False,
              model_calls=0, native_admission=False, canonical_source_changed=False,
              input_or_oracle_repairs=[], original_expectations_unchanged=True)
(ROOT / "RESULT.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
print(json.dumps(result,sort_keys=True))
assert caught, "preserve outcome and diagnose before any changed fixture"
