"""Frozen no-authority supplied-value oracle, with no real child invocation."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time


def ident(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--variant", choices=("baseline", "mutant"), required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    pre = json.loads((root / "PREIMAGE.json").read_text())
    assert ident(Path(__file__)) == pre["oracle"]
    assert ident(args.source) == pre["source_variants"][args.variant]
    inputs = root / "inputs"
    before = {p.name: ident(p) for p in inputs.iterdir() if p.is_file()}
    assert before == pre["inputs"]
    args.out.mkdir()
    rows = []
    for name in ("valid", "authority"):
        argv = [sys.executable, "-I", "-B", str(args.source),
                "--envelope", str(inputs / "envelope.json"),
                "--current-envelope", str(inputs / "current-envelope.json"),
                "--result", str(inputs / ("return-" + name + ".json"))]
        start = time.monotonic()
        at = datetime.datetime.now(datetime.timezone.utc).isoformat()
        process = subprocess.run(argv, cwd=args.out, capture_output=True, timeout=10)
        (args.out / (name + ".stdout")).write_bytes(process.stdout)
        (args.out / (name + ".stderr")).write_bytes(process.stderr)
        row = dict(arm=name, argv=argv, exit=process.returncode, started_at=at,
                   elapsed_seconds=time.monotonic()-start, output=json.loads(process.stdout),
                   stdout=ident(args.out / (name + ".stdout")),
                   stderr=ident(args.out / (name + ".stderr")))
        rows.append(row)
    unchanged = before == {p.name: ident(p) for p in inputs.iterdir() if p.is_file()}
    source_unchanged = ident(args.source) == pre["source_variants"][args.variant]
    report = dict(schema="dg17.M12.no-authority-value-observations.v1", captures=rows,
                  inputs_unchanged=unchanged, source_unchanged=source_unchanged,
                  value_fixture=True, actual_model_calls=0, native_admission=False,
                  actual_currentness_or_maintainer_authority=False)
    (args.out / "observations.json").write_text(json.dumps(report, indent=2, sort_keys=True)+"\n")
    assert unchanged and source_unchanged
    assert rows[0]["exit"] == 0 and rows[0]["output"]["status"] == "VALID"
    for row in rows:
        assert row["output"]["validation"] == "VALUE_VALIDATION"
        assert row["output"]["authority"] == "NONE"
        assert "does not authenticate" in row["output"]["proof_limit"]
        assert row["stderr"]["bytes"] == 0
    assert rows[1]["exit"] == 2 and rows[1]["output"]["status"] == "INVALID", "authority-shaped supplied child value was admitted"
    assert rows[1]["output"]["error"] == "result.authority has an unsupported value"
    print(json.dumps(dict(original_oracle="PASS", variant=args.variant, authority="NONE")))


if __name__ == "__main__":
    main()
