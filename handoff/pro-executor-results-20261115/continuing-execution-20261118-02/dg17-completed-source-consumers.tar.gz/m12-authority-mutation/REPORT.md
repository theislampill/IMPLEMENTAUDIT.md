# M12 supplied-value no-authority guard

The exact a297 audit-implement return validator was invoked with the original canonical test fixture's RELEASE envelope and supported return. These are explicitly supplied test values; its VERIFIED fields, example identities and repeated hexadecimal strings authenticate no currentness, package, release, maintainer or host fact. No child was loaded or invoked.

Only the adversarial return's authority value changes from NONE to RELEASE. The baseline accepts the original return and rejects the authority-shaped value with exit 2 and `result.authority has an unsupported value`. The source-copy mutation permits RELEASE in that single allowed-value guard. It admits the same adversarial return as VALID, and the frozen original oracle fails on that actual admission.

| Source | NONE return | RELEASE value | Frozen oracle |
|---|---|---|---|
| Exact a297 | VALID, exit 0 | INVALID, exit 2 | pass |
| One allowed-value guard mutant | VALID, exit 0 | VALID, exit 0 | fails |

Four actual read-only value-consumer invocations completed. All raw JSON outputs keep VALUE_VALIDATION, output authority NONE, and the owner's explicit proof limit: supplied values do not authenticate currentness, authority, evidence, semantic sufficiency or native admission. Inputs, oracle, driver and both source variants were reverified unchanged. No fixture repair occurred.

This establishes the specific supplied `result.authority` limb. It does not establish an authentic maintainer route, an actual model authority attempt, the no-chain conjunction, N03, or the whole original no-authority/no-chain mutation family. The executing installed governor's real admission gate is unchanged. No target NON_RELEASE value support was used as route authority.
