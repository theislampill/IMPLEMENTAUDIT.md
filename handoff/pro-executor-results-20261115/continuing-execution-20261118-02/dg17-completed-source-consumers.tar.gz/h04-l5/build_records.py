#!/usr/bin/env python3
"""Explicit structural projection of retained JOIN checkpoints to L5 records.

This is test input construction, not an automatic product bridge or a native
governor claim. The unchanged original record owner supplies the decision.
"""
import ast
import hashlib
import json
from pathlib import Path
import shutil
import subprocess


BASE = Path(__file__).resolve().parent
SOURCE = BASE / "source"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    evidence_bytes = (BASE / "retained-join-episode.json").read_bytes()
    assert digest(evidence_bytes) == "e6020765ca479aaae03b41bf0117a4ea3674035341ae14a46f9bb3f2f596966c"
    evidence = json.loads(evidence_bytes)
    head = subprocess.check_output(["git", "-C", str(SOURCE), "rev-parse", "HEAD"], text=True).strip()
    assert head == evidence["source"]["commit"]
    fixture_owner = SOURCE / "tests/nonterminal-yield-cases.py"
    text = fixture_owner.read_text()
    tree = ast.parse(text)
    definitions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "write_case"]
    assert len(definitions) == 1
    namespace = {"ROOT": SOURCE, "shutil": shutil}
    exec(compile(ast.Module(body=definitions, type_ignores=[]), str(fixture_owner), "exec"), namespace)
    snapshots = {
        "completed": evidence["snapshots"]["after_actual_consumer"],
        "omitted": evidence["snapshots"]["lane_received_join_omitted"],
    }
    manifest = []
    for name, snapshot in snapshots.items():
        root = BASE / "records" / name
        namespace["write_case"](root, {"Status": "DONE", "Audit object state": "terminal verified closure"})
        state = root / "STATE.md"
        state.write_text(state.read_text() + "\n## Final closure checker inputs\n\n"
                         "| Input | Value |\n|---|---|\n| Superseded plans | none |\n"
                         "| Cycle-accounted plans | none |\n| Steer directory | " + str(root) + " |\n")
        roadmap = root / "ROADMAP.md"
        roadmap.write_text(roadmap.read_text().replace("| pending |", "| done |"))
        phase = root / "phases/phase-1.md"
        phase.write_text(phase.read_text().replace("- [ ]", "- [x]").replace("Status recorded here.", "Status: done"))
        checkpoint = (BASE / (name + "-checkpoint.json")).read_bytes()
        assert json.loads(checkpoint) == snapshot
        (root / "checkpoint.json").write_bytes(checkpoint)
        join_records = [record for event in snapshot.get("completion_events", []) if event["kind"] == "JOIN"
                        for record in event["records"] if record["node"] == "RETURN_REDUCER"]
        settled = (snapshot["states"]["RETURN_REDUCER"] == "DONE" and len(join_records) == 1
                   and join_records[0]["digest"] == evidence["governor_join"]["completion_digest"]
                   and evidence["governor_join"]["all_required_settled"] is True)
        status = "verified" if settled else "unverified"
        assert settled == (name == "completed")
        closure = ("AUDIT_START\nRound: 1\nAUDIT_START_ANCHOR: " + head + "\n"
                   "AUDIT_VERIFY\nAUDIT_VERIFY_ANCHOR: " + head + "\n"
                   "REANCHOR_DISPOSITION: unchanged\nREANCHOR_EVIDENCE: none\n"
                   "equivalent_config_attempts: 1/1\nstochasticity_budget: none\n"
                   "terminal_qualification: QUALIFIED\n"
                   "re_verified / (re_verified + trust_prior) = 1 / (1 + 0) = 1\n"
                   "claim: JOIN-RETURN_REDUCER | surface: source | status: " + status + " | evidence-surface: source\n"
                   "record-file: checkpoint.json\n"
                   "checkpoint-sha256: " + digest(checkpoint) + "\n"
                   "checkpoint-history: " + snapshot["history_digest"] + "\n"
                   "AUDIT_COMPLETE\nIMPLEMENTAUDIT_RUN_COMPLETE\n")
        (root / "closure.md").write_text(closure)
        manifest.append({"arm": name, "claim_status": status, "canonical_JOIN_record_present": settled,
                         "checkpoint_sha256": digest(checkpoint), "history_digest": snapshot["history_digest"],
                         "files": [{"path": str(p.relative_to(root)), "bytes": p.stat().st_size,
                                    "sha256": digest(p.read_bytes())} for p in sorted(root.rglob("*")) if p.is_file()]})
    result = {"schema": "dg17.H04-L5-projected-records.v1", "arms": manifest,
              "builder_sha256": digest(Path(__file__).read_bytes()),
              "fixture_source_sha256": digest(fixture_owner.read_bytes()),
              "projection_is_test_input_only": True, "automatic_product_bridge": False,
              "native_or_acceptance_authority": "NONE"}
    (BASE / "RECORDS.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"arms": [{"arm": x["arm"], "claim_status": x["claim_status"]} for x in manifest],
                      "automatic_product_bridge": False}, indent=2))


if __name__ == "__main__":
    main()
