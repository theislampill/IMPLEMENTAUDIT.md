# Roadmap — exemplar run root

| # | Phase | Depends on | Status |
|---|---|---|---|
| 1 | Fix greeting casing | none | done |

Thinking file: `<run-root>/THINKING.md`
