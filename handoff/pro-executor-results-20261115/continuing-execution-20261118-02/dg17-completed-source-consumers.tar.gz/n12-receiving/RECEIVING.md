# N12 source-semantic receiving packet

The unchanged selected a297 record consumer refused a deliberately false terminal claim because its required acceptance criterion remained unverified. The exact same authentic failed command capture was preserved in both compared records; the truthful blocked-record control was accepted. This establishes the source-semantic discriminator only. Independent receiving remains pending.

## Exact observation

- False-green `--turn-disposition TERMINAL_CLOSURE`: exit 1, empty stdout, stderr `validate-run-root: RECORD_REFUSED: phase has unverified required criterion; no disposition`.
- Truthful-open `--turn-disposition NONTERMINAL_YIELD`: exit 0, empty stderr, result explicitly reports `authority: NONE`, `effect_authority: false`, `native_enforcement: false`, and constructed-record scope.
- Both source-consumer invocations completed without timeout and left their input records unchanged. The original report failure was not rerun.

The retained failure is actual hosted run 44006227023, artifact 14294043950, command 042: exit 1; stdout 266 bytes / SHA256 8b1b08cef34ced774fb20cb696a79a51b1a76e6f2adc953a084e8d751691bf0a; empty stderr. Each record contains exact copies of its structured command record, stdout, stderr, and admitted subject binding.

## Source and limits

The invoked owner is `skills/implementaudit/scripts/validate-run-root.sh` from commit a297957be11feb494c0ec467235794a1e0c54751, tree b08dc4ecf4028beeedb579a312eccae23cb5d863. All 78 current package members match their exact Git objects; SOURCE_READBACK.json binds each. The operating cwd is the existing d76c1e9 repository, distinct from the bound historical hosted subject commit 2f182c7a64775451f6ef095aa29cdae4044941ef.

The false-green input is explicitly constructed and was not issued by the actual P07 governor. These input directories have no live claim or controller. The consumer itself disclaims authentic lifecycle acceptance and native enforcement. This does not establish native Stop, actual phase exhaustion, final lifecycle closure, whole N12, whole original36, or a terminal R0037 award.

## Preserved setup failure

The first terminal record was refused on its nonconcrete STOP sentence before the target failed-criterion guard. That observation has no N12 credit. Original files and observations remain in initial_snapshot/ and observations/. The only correction named the exact capture path and frozen byte/hash predicate in both STOP lines; FROZEN_INPUTS.corrected.json records the delta. The corrected commands were then executed once each.

RESULT.json contains exact argv/cwd, raw observation identities, complete packet member hashes, initial and corrected freezes, source identity, and the explicit evidence ceiling. No target/package code or live controller was changed.
