AUDIT_START
Round: 1
AUDIT_START_ANCHOR: d76c1e9c22fd816fbc6ddcac0080625b8f087d23
AUDIT_VERIFY
AUDIT_VERIFY_ANCHOR: d76c1e9c22fd816fbc6ddcac0080625b8f087d23
REANCHOR_DISPOSITION: unchanged
REANCHOR_EVIDENCE: none
equivalent_config_attempts: 1/1
stochasticity_budget: none
terminal_qualification: QUALIFIED
re_verified / (re_verified + trust_prior) = 1 / (1 + 0) = 1
claim: report-equality | surface: source | status: verified | evidence-surface: source
AUDIT_COMPLETE
IMPLEMENTAUDIT_RUN_COMPLETE
