# M05 unresolved-obligation closure refusal

The original required mutation family is now observed at the actual structural source-consumer layer. The baseline oracle passes. Removing only the required closure-claim status guard causes the same omitted-obligation record to receive `TERMINAL_CLOSURE`; the unchanged oracle fails on that forbidden acceptance.

| Source | Completed required JOIN | Omitted required JOIN | Frozen original oracle |
|---|---|---|---|
| Exact a297 baseline | exit 0, terminal record disposition | exit 1, unclosed required closure claim | exit 0 |
| Single status-guard removal copy | exit 0, terminal record disposition | exit 0, terminal record disposition | exit 1, unresolved required closure obligation was accepted |

Inputs are byte-identical accepted H04 records. The original completed and omitted checkpoints and explicit test/governor projection remain unchanged. This does not assert automatic graph-to-L5 integration. The preimage binds all 77 baseline source files, the sole planned source difference, all record bytes and both executable scripts before execution. The baseline executes before the mutant source copy is created. Four bounded actual owner invocations completed. Raw stdout/stderr, argv, cwd, PIDs, timestamps and exit codes are retained under baseline/work and mutant/work.

The changed owner is `skills/implementaudit/scripts/validate-run-root.sh` from a297957be11feb494c0ec467235794a1e0c54751. Its original SHA256 is 7787569b4bceb541c33ee3287f0a8297882caff5478687e84fc534077e4c28ad. The copied mutant SHA256 is ed2ddcb212e5c48bf1536fc96bde6f1db992d2a63bc3c578c8e22341f4a89587. Only the `any(... status ... not verified/not-applicable ...)` branch is removed; nonempty claim population and all other guards remain. The common `check-closure-surface.sh` supports unverified claim rows as data; the terminal record consumer owns the stronger unresolved-obligation refusal.

The actual mutant output explicitly retains `authority: NONE`, `effect_authority: false`, and `native_enforcement: false`. This is a deliberately relaxed source copy caught by an original behavioral oracle, not a product-source runtime failure, native closure or author acceptance award. No model, public operation, protected effect, source repair or input repair occurred. Root retains independent receiving and original-family qualification.
