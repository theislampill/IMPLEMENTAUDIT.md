"""Execute the frozen baseline first, then the declared one-guard source copy."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
PREIMAGE = json.loads((ROOT / "PREIMAGE.json").read_text())


def ident(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def invoke(variant):
    argv = [sys.executable, "-I", "-B", str(ROOT / "frozen_oracle.py"),
            "--variant", variant, "--source", str(ROOT / variant / "source"),
            "--out", str(ROOT / variant / "work")]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    start = time.monotonic()
    proc = subprocess.run(argv, capture_output=True, timeout=80)
    (ROOT / variant / "oracle.stdout").write_bytes(proc.stdout)
    (ROOT / variant / "oracle.stderr").write_bytes(proc.stderr)
    receipt = {"argv": argv, "exit": proc.returncode, "started_at": started,
               "elapsed_seconds": time.monotonic() - start,
               "stdout": ident(ROOT / variant / "oracle.stdout"),
               "stderr": ident(ROOT / variant / "oracle.stderr")}
    (ROOT / variant / "oracle.receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    return receipt


assert ident(Path(__file__)) == PREIMAGE["driver"]
assert ident(ROOT / "frozen_oracle.py") == PREIMAGE["frozen_oracle"]
baseline = invoke("baseline")
assert baseline["exit"] == 0, "baseline failed; no mutant is created or executed"
shutil.copytree(ROOT / "baseline/source", ROOT / "mutant/source")
owner = ROOT / "mutant/source" / PREIMAGE["owner"]
old = PREIMAGE["mutation"]["old_line"].encode()
new = PREIMAGE["mutation"]["new_line"].encode()
original = owner.read_bytes()
assert original.count(old) == 1
owner.write_bytes(original.replace(old, new))
assert ident(owner) == PREIMAGE["sources"]["mutant"][PREIMAGE["owner"]]
mutant = invoke("mutant")
observed = json.loads((ROOT / "mutant/work/observations.json").read_text())
omitted = observed["captures"][1]
actual = json.loads((ROOT / "mutant/work/omitted/stdout").read_text()) if omitted["exit"] == 0 else None
caught = (mutant["exit"] == 1 and
          b"AssertionError: unresolved required closure obligation was accepted" in
          (ROOT / "mutant/oracle.stderr").read_bytes() and
          actual is not None and actual["record_disposition"] == "TERMINAL_CLOSURE")
result = {"schema": "dg17.M05.source-copy-mutation-result.v1", "baseline": baseline,
          "mutant": mutant, "original_mutation_family": "unresolved-obligation closure refusal",
          "mutation_caught_at_original_predicate": caught,
          "actual_mutant_forbidden_disposition": actual,
          "source_mutation": PREIMAGE["mutation"], "input_changes": [],
          "frozen_oracle_changed": False, "canonical_source_changed": False,
          "source_and_records_unchanged_during_consumption": all(observed[k] for k in
              ("source_unchanged", "records_unchanged", "git_context_unchanged")),
          "model_invocations": 0, "native_enforcement": False,
          "effect_authority": False, "author_award": False}
(ROOT / "RESULT.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps(result, sort_keys=True))
assert caught, "mutant did not qualify; retain outcome and diagnose before any change"
