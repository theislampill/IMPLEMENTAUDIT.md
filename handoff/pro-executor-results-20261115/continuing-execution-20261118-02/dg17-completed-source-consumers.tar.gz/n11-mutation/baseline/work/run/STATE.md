```implementaudit-work-graph
{"campaign":"dg17-owned-join-source-20261118","context":{"host_capacity":1,"operator_ceiling":null,"outstanding_deliveries":[],"reserve":0,"route_facts":[]},"event":{"id":"constructed-document-input","kind":"RETURN","subject":"ORCHID_INDEX"},"nodes":["OWNED_OBJECT","ORCHID_INDEX","RETURN_REDUCER","ACTUAL_READER","FINAL_REDUCER"],"original_scope":"Original N11 H04 structural authority facts only","root":"OWNED_OBJECT","schema":"implementaudit.native-state.v1"}
```
