#!/usr/bin/env python3
"""Root-justified single-edge input correction; frozen oracle is unchanged."""
import hashlib
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ORACLE_SHA = "c6bef7cbe1bc487877f778609db554a67b652c76d4d5f5267edd1d400ffa5cb4"
JUSTIFICATION_SHA = "a55ba047ece2fcccfe2b26364dc19eddbb1f99fa15287d3c5409e236c8c72e9c"


def main():
    oracle_path = ROOT / "frozen_oracle.py"
    assert hashlib.sha256(oracle_path.read_bytes()).hexdigest() == ORACLE_SHA
    justification = ROOT / "ROOT_FIXTURE_REPAIR_JUSTIFICATION.json"
    assert hashlib.sha256(justification.read_bytes()).hexdigest() == JUSTIFICATION_SHA
    specification = importlib.util.spec_from_file_location("frozen_N11_oracle", oracle_path)
    oracle = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(oracle)
    original_node = oracle.node
    amended = []

    def node(name, *args, **kwargs):
        if name == "FINAL_REDUCER":
            assert kwargs["requires"] == ["ACTUAL_READER"]
            assert not amended
            kwargs = dict(kwargs, requires=["ACTUAL_READER", "RETURN_REDUCER"])
            amended.append(name)
        return original_node(name, *args, **kwargs)

    oracle.node = node
    try:
        oracle.main()
    finally:
        assert amended == ["FINAL_REDUCER"]
        assert hashlib.sha256(oracle_path.read_bytes()).hexdigest() == ORACLE_SHA


if __name__ == "__main__":
    main()
