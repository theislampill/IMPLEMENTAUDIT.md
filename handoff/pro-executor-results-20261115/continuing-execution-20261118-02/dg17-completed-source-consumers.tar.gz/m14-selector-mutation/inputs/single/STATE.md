```implementaudit-work-graph
{"campaign":"dg17-cheap-selector-single-20261118","context":{"host_capacity":3,"operator_ceiling":null,"outstanding_deliveries":[],"reserve":0,"route_facts":[]},"event":{"id":"constructed-census-input","kind":"RETURN","subject":"ONE_OWNER_READ"},"nodes":["OWNED_OBJECT","ONE_OWNER_READ"],"original_scope":"Actual canonical selector nonactivation flag; constructed input, no model or native activation","root":"OWNED_OBJECT","schema":"implementaudit.native-state.v1"}
```
