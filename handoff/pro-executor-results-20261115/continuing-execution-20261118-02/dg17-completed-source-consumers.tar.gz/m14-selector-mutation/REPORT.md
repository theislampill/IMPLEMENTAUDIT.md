# M14 cheap-path selector limb

The exact a297 compiler observed two constructed graph inputs and ran its canonical frontier selector. A single read-only task under one owner selected exactly that task and produced CHEAP_SERIAL with graph_required=false. Three independent ready read-only tasks with capacity three selected the exact three-task population and produced GRAPH_CANDIDATE with graph_required=true. Both outputs retain authority NONE.

The source-copy mutant changes only the census-based graph_required expression to true. It leaves task selection, population, capacity, source identity and authority checks unchanged. The same single-task input then actually produces GRAPH_CANDIDATE/true, and the unchanged oracle fails with `single-owner work activated the graph selector`. The multi-task positive control remains valid.

PREIMAGE.json freezes both graph document sets and their actual retained checkpoint data, all three source members, the planned sole delta, and both scripts before execution. Four canonical selector calls completed across baseline and mutant. All source/input/oracle/driver bytes were reverified unchanged; no fixture repair, model call, native operation or public effect occurred.

The established original-family limb is canonical selector mode/required-flag discrimination. This is not proof of downstream graph creation, a model's full ceremony-free execution, a child route, or the complete cheap-path nonactivation family. Existing actual B01/H06 episodes remain separately retained; they are not replayed or silently combined into a new whole-case award.
