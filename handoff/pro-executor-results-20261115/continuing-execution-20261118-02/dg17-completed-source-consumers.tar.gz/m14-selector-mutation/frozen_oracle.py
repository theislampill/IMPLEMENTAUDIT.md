"""Original cheap-path selector limb; no model behavior or native activation."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path


def ident(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def inventory(root):
    return {p.relative_to(root).as_posix(): ident(p) for p in root.rglob("*") if p.is_file()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--variant", choices=("baseline", "mutant"), required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    pre = json.loads((root / "PREIMAGE.json").read_text())
    assert ident(Path(__file__)) == pre["oracle"]
    assert inventory(args.source) == pre["sources"][args.variant]
    inputs = root / "inputs"
    assert inventory(inputs) == pre["inputs"]
    args.out.mkdir()
    owner = args.source / pre["owner"]
    spec = importlib.util.spec_from_file_location("dg17_cheap_selector", owner)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    outputs = {}
    for name in ("single", "multiple"):
        with module.observe_native_run_v1(inputs / name) as data:
            graph = module.decode_strict_json_bytes(data, "constructed cheap-path input")
            frontier = module.select_native_frontier_v1(graph)
        outputs[name] = {"graph": graph, "frontier": frontier}
    unchanged = inventory(inputs) == pre["inputs"] and inventory(args.source) == pre["sources"][args.variant]
    result = dict(schema="dg17.M14.actual-selector-observations.v1", variant=args.variant,
                  outputs=outputs, inputs_and_source_unchanged=unchanged,
                  scope="Actual canonical declared-graph selector only; no downstream ceremony or child route is asserted",
                  model_calls=0, native_activation=False, authority="NONE")
    (args.out / "observations.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
    assert unchanged
    single, multiple = (outputs[k]["frontier"] for k in ("single", "multiple"))
    assert single["selected"] == ["ONE_OWNER_READ"]
    assert multiple["selected"] == ["ALPHA_READ", "BETA_READ", "GAMMA_READ"]
    assert multiple["graph_required"] is True and multiple["mode"] == "GRAPH_CANDIDATE"
    assert single["graph_required"] is False and single["mode"] == "CHEAP_SERIAL", "single-owner work activated the graph selector"
    assert single["authority"] == multiple["authority"] == "NONE"
    print(json.dumps(dict(original_oracle="PASS",variant=args.variant,authority="NONE")))


if __name__ == "__main__":
    main()
