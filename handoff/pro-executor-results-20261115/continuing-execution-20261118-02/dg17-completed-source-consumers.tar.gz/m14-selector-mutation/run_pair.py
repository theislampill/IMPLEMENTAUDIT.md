import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PRE = json.loads((ROOT / "PREIMAGE.json").read_text())


def ident(path):
    data=path.read_bytes()
    return {"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()}


def run(variant):
    argv=[sys.executable,"-I","-B",str(ROOT/"frozen_oracle.py"),"--variant",variant,
          "--source",str(ROOT/variant/"source"),"--out",str(ROOT/variant/"work")]
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    p=subprocess.run(argv,capture_output=True,timeout=20)
    (ROOT/variant/"oracle.stdout").write_bytes(p.stdout)
    (ROOT/variant/"oracle.stderr").write_bytes(p.stderr)
    r=dict(argv=argv,started_at=started,exit=p.returncode,
           stdout=ident(ROOT/variant/"oracle.stdout"),stderr=ident(ROOT/variant/"oracle.stderr"))
    (ROOT/variant/"oracle.receipt.json").write_text(json.dumps(r,indent=2,sort_keys=True)+"\n")
    return r


assert ident(Path(__file__)) == PRE["driver"]
baseline=run("baseline")
assert baseline["exit"]==0,"baseline failed; mutant not created"
shutil.copytree(ROOT/"baseline/source",ROOT/"mutant/source")
owner=ROOT/"mutant/source"/PRE["owner"]
old,new=(PRE["mutation"][k].encode() for k in ("old","new"))
data=owner.read_bytes();assert data.count(old)==1
owner.write_bytes(data.replace(old,new))
mutant=run("mutant")
observed=json.loads((ROOT/"mutant/work/observations.json").read_text())
single=observed["outputs"]["single"]["frontier"]
caught=(mutant["exit"]==1 and single["graph_required"] is True and
        b"AssertionError: single-owner work activated the graph selector" in (ROOT/"mutant/oracle.stderr").read_bytes())
result=dict(schema="dg17.M14.selector-mutation-result.v1",baseline=baseline,mutant=mutant,
            mutation=PRE["mutation"],original_mutation_family="cheap-path non-activation",
            established_limb="actual graph selector mode/required flag for single-owner census",
            actual_mutant_single_frontier=single,mutation_caught_at_original_predicate=caught,
            model_calls=0,native_activation=False,whole_family_award=False,
            whole_cheap_task_behavior=False,author_award=False,canonical_source_changed=False,
            input_or_oracle_repairs=[],original_expectations_unchanged=True)
(ROOT/"RESULT.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
print(json.dumps(result,sort_keys=True))
assert caught,"retain evidence and diagnose before any fixture change"
