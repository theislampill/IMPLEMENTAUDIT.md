#!/usr/bin/env python3
"""Read-only independent receiving; never runs an archived task or owner test."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import tarfile

BASE = Path('/workspace/scratch/095d3235c921')
REPO = BASE / 'implementaudit'
PACKET = BASE / 'evidence/dg17-next-20261118/eligibility-20261118'
OUT = BASE / 'evidence/dg17-next-independent-review'
PREFIX = 'retained-eligibility-'
ISSUE = BASE / 'evidence/dg17-next-20261118/inputs/original-issue211-body.md'
ISSUE_API = OUT / 'mutation-batch02-issue211-live.json'
COMMIT = 'a297957be11feb494c0ec467235794a1e0c54751'
GUIDE = 'skills/implementaudit/SKILL.md'
ARCHIVE_REL = 'handoff/pro-executor-results-20261115/continuing-execution-20261116/evidence.tar.gz'
ARCHIVE = REPO / ARCHIVE_REL
received = {}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    path = Path(path)
    data = path.read_bytes()
    received[str(path)] = {'path': str(path), 'bytes': len(data), 'sha256': digest(data)}
    return data


def load(path):
    return json.loads(read(path))


def check(data, pin):
    assert len(data) == pin['bytes'], pin
    assert digest(data) == pin['sha256'], pin


def snapshot(rows):
    answer = {row['path']: row for row in rows}
    assert len(answer) == len(rows)
    return answer


def changed(left, right):
    a, b = snapshot(left), snapshot(right)
    return sorted(p for p in a.keys() | b.keys() if a.get(p) != b.get(p))


def identity(row):
    return {k: row[k] for k in ('path', 'bytes', 'sha256')}


report_pin = {'bytes': 11817, 'sha256': 'f145cdae806514a9a4ae4ed0c9c8a06e33b811a63dbd519e248ffe4884d25fc1'}
readback_pin = {'bytes': 110100, 'sha256': '78e16ef668bf676cce7d3d8684b0d3a5c5d8172e7083791463295b38e52c9207'}
check(read(PACKET / 'REPORT.md'), report_pin)
check(read(PACKET / 'READBACK.json'), readback_pin)
issue = read(ISSUE)
assert len(issue) == 64795 and digest(issue) == 'ca62f4899a45544549f623a0312c16121bb99f432ccb87a87b7361974ceb94c4'
assert load(ISSUE_API)['issue']['body'].encode() == issue
archive = read(ARCHIVE)
assert len(archive) == 1716404 and digest(archive) == '7d59b34c0a859ec81dfc78b2b7ba870aae7ed860136bb9d8b415065348ca83fb'
published_archive = subprocess.check_output(['git', '-C', str(REPO), 'show', 'd8813ea46a06ce0e9f6260d6adccb4ab30cf4445:' + ARCHIVE_REL])
assert archive == published_archive
guide = subprocess.check_output(['git', '-C', str(REPO), 'show', COMMIT + ':' + GUIDE])
assert len(guide) == 21259 and digest(guide) == 'a6b0e2801147508766572c7dc44599da1e8a804967bc4a0a0fb8427ac21600ef'
source_blob = subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', COMMIT + ':' + GUIDE], text=True).strip()
source_tree = subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', COMMIT + '^{tree}'], text=True).strip()
assert source_blob == '50887995b25898d75b4716517dc0b97602688e57'

extra_members = [
    'dg17/DG17_B01_SHARED_H06_RECEIVING.json',
    'completion/DG17_B01_ROOT_RECEIVING.json',
    'completion/DG17_H06_ROOT_RECEIVING.json',
    'completion/DG17_SELECTIVE_REMINDER_ROOT_RECEIVING.json',
]
member_pins = []
with tarfile.open(ARCHIVE, 'r:gz') as tar:
    for member in tar.getmembers():
        if not member.isfile():
            continue
        if member.name.startswith(('dg17/episode_01/', 'dg17/episode_05/')) or member.name in extra_members:
            archived = tar.extractfile(member).read()
            local = PACKET / '20261116' / member.name
            assert read(local) == archived, member.name
            member_pins.append({'archive_member': member.name, 'bytes': len(archived), 'sha256': digest(archived), 'local_path': str(local)})
    accounting_member = 'dg17/PROMPT_PROVENANCE_ACCOUNTING.json'
    accounting_bytes = tar.extractfile(accounting_member).read()
    check(accounting_bytes, {'bytes': 6076, 'sha256': 'cb779112244e2391f679436e8b3fa598f149268d9df2825148441967b5058848'})
    accounting_copy = OUT / (PREFIX + 'prompt-provenance-accounting.json')
    accounting_copy.write_bytes(accounting_bytes)
    read(accounting_copy)
    accounting = json.loads(accounting_bytes)

episodes = {}
records = {}
for ep, count in [('episode_01', 9), ('episode_05', 16)]:
    root = PACKET / '20261116/dg17' / ep
    receiver = root / 'receiver'
    assert read(root / 'actor/guidance/SKILL.md') == guide
    freeze = load(receiver / 'FREEZE.json')
    frozen_time = datetime.datetime.fromisoformat(freeze['frozen_at_utc'])
    rows = []
    previous = None
    intercommand = []
    commands = []
    for i in range(1, count + 1):
        command = f'command-{i:03d}'
        capture = root / 'capture' / command
        row = load(capture / 'record.json')
        assert datetime.datetime.fromisoformat(row['started_at_utc']) > frozen_time
        for stream in ('stdout', 'stderr'):
            check(read(capture / (stream + '.bin')), row[stream])
        if previous is not None:
            delta = changed(previous['after'], row['before'])
            if delta:
                intercommand.append({'before_command': command, 'paths': delta})
        for state in ('before', 'after'):
            assert snapshot(row[state])['guidance/SKILL.md']['sha256'] == digest(guide)
        commands.append({'command': command, 'argv': row['argv'], 'exit_code': row['exit_code'], 'changed': changed(row['before'], row['after']), 'record': received[str(capture / 'record.json')]})
        rows.append(row)
        previous = row
    records[ep] = rows
    initial = snapshot(rows[0]['before'])
    final = snapshot(rows[-1]['after'])
    frozen_checks = 0
    for pin in freeze['files']:
        relative = pin['path']
        if relative.startswith('actor/') and relative.removeprefix('actor/') in initial:
            entry = initial[relative.removeprefix('actor/')]
            assert entry['bytes'] == pin['bytes'] and entry['sha256'] == pin['sha256']
        else:
            check(read(root / relative), pin)
        frozen_checks += 1
    for name, pin in final.items():
        check(read(root / 'actor' / name), pin)
    executed = load(receiver / 'EXECUTED_MANIFEST.json')['files']
    for pin in executed:
        p = root / pin['path'] if ep == 'episode_01' else root.parent / pin['path']
        check(read(p), pin)
    rubric = load(receiver / 'RUBRIC.json')
    controls = rubric.get('original_model_facing_controls', rubric.get('model_facing_controls'))
    assert all(k in controls for k in ('plausible_distractors', 'forbidden_mission_phrases', 'positive_paraphrase', 'triviality', 'bloat', 'polarity', 'authority', 'context_no_payoff'))
    prompt_names = ['ACTOR_PROMPT.txt'] if ep == 'episode_01' else ['DELIVERED_ACTOR_PROMPT.txt', 'DELIVERED_REMINDER_PROMPT.txt']
    mission = b'\n'.join(read(receiver / n) for n in prompt_names).decode() + '\n' + read(root / 'actor/AGENTS.md').decode() + '\n' + read(root / 'actor/TASK.md').decode()
    assert not [s for s in controls['forbidden_mission_phrases'] if s in mission]
    assert read(root / 'capture/command-001/stdout.bin') == read(root / 'actor/AGENTS.md') + read(root / 'actor/TASK.md')
    episodes[ep] = {'command_count': count, 'raw_streams_verified': count * 2, 'frozen_input_checks': frozen_checks, 'executed_manifest_files_verified': len(executed), 'all_commands_after_freeze': True, 'between_command_changes': intercommand, 'commands': commands, 'preserved_nonzero_commands': [r['command'] for r in commands if r['exit_code'] != 0], 'control_categories_declared': sorted(controls), 'forbidden_mission_phrases_absent_in_retained_mission': True}

e1 = PACKET / '20261116/dg17/episode_01'
raw_csv = read(e1 / 'capture/command-002/stdout.bin')[len(guide):]
assert read(e1 / 'capture/command-002/stdout.bin').startswith(guide)
assert digest(raw_csv) == '4d0f5a528c178def3163652b64825b1a03c8d5953a347f797333a68866698716'
final_csv = read(e1 / 'actor/workshops.csv')
assert raw_csv.replace(b'W-202,Agile Planning,60,Pine', b'W-202,Agile Planning,75,Pine', 1) == final_csv
assert episodes['episode_01']['between_command_changes'] == []
assert [(r['command'], r['changed']) for r in episodes['episode_01']['commands'] if r['changed']] == [('command-005', ['workshops.csv'])]
assert episodes['episode_01']['preserved_nonzero_commands'] == ['command-006']
assert all(len(r['before']) == len(r['after']) == 4 for r in records['episode_01'])
old_check = records['episode_01'][5]['argv'][2]
new_check = records['episode_01'][7]['argv'][2]
assert old_check.replace('if p.is_file())', 'if p.is_file() and ".git" not in p.parts)').replace('Workspace inventory unchanged; no additional files created.', 'Task file inventory unchanged; no additional task files created.') == new_check
episode01_accounting = next(r for r in accounting['rows'] if r['episode'] == 'episode_01')
assert episode01_accounting['delivered_message_scalar_identity'] == 'UNKNOWN_AT_CURRENT_WORKER_CONTEXT'
assert episode01_accounting['final_LF_transport_difference'] == 'NOT_ASSERTED'
episodes['episode_01']['exact_retained_csv_delta'] = 'W-202 minutes 60 -> 75; all other bytes identical'
episodes['episode_01']['verification_correction_only_inventory_scope_and_description'] = True
episodes['episode_01']['delivered_scalar_identity'] = episode01_accounting['delivered_message_scalar_identity']
episodes['episode_01']['final_LF_transport_difference'] = 'NOT_ASSERTED'

e5 = PACKET / '20261116/dg17/episode_05'
stage_a = load(e5 / 'receiver/STAGE_A_BOUNDARY.json')
stage_b = load(e5 / 'receiver/STAGE_B_BOUNDARY.json')
assert stage_a['last_command'] == 'command-010' and stage_b['last_command'] == 'command-011'
assert stage_a['snapshot'] == stage_b['snapshot']
reminder = records['episode_05'][10]
assert reminder['before'] == reminder['after'] == records['episode_05'][9]['after']
assert [{k:v for k,v in r.items() if k != 'kind'} for r in reminder['after']] == stage_b['snapshot']
assert reminder['argv'] == ['python', '-B', 'check_outputs.py'] and reminder['exit_code'] == 0
assert read(e5 / 'capture/command-011/stdout.bin') == b'getting-started: ok\nshortcuts: ok\ncontacts: ok\n'
assert episodes['episode_05']['between_command_changes'] == [{'before_command': 'command-012', 'paths': ['sources/contacts.json']}]
assert [(r['command'], r['changed']) for r in episodes['episode_05']['commands'] if r['changed']] == [('command-006', ['output/getting-started.txt']), ('command-007', ['output/shortcuts.txt']), ('command-008', ['output/contacts.txt']), ('command-014', ['output/contacts.txt'])]
assert episodes['episode_05']['preserved_nonzero_commands'] == ['command-004', 'command-013']
rubric5 = load(e5 / 'receiver/RUBRIC.json')
for stage, state in [('A', records['episode_05'][9]['after']), ('C', records['episode_05'][-1]['after'])]:
    by_path = snapshot(state)
    for name, value in rubric5['expected_outputs_' + stage].items():
        pin = by_path['output/' + name + '.txt']
        check(value.encode(), pin)
transport = []
for name in ['ACTOR_PROMPT.txt', 'REMINDER_PROMPT.txt']:
    frozen = read(e5 / 'receiver' / name)
    delivered_path = e5 / 'receiver' / ('DELIVERED_' + name)
    delivered = read(delivered_path)
    assert frozen == delivered + b'\n'
    transport.append({'frozen': received[str(e5 / 'receiver' / name)], 'delivered': received[str(delivered_path)], 'only_delta': 'one final LF omitted'})
assert b'Do not dispatch additional agents.' in read(e5 / 'receiver/DELIVERED_ACTOR_PROMPT.txt')
episodes['episode_05']['reminder_stage_all_12_files_including_mtime_inode_unchanged'] = True
episodes['episode_05']['delivered_prompt_identities'] = transport
episodes['episode_05']['initial_commission_prohibits_additional_agents'] = True

result = {'schema': 'dg17.retained-b01-h06-b03-independent-read-only-receiving.v1', 'reviewer': '/root/dg18_execution', 'recorded_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'authority': 'NONE', 'original_case_awards': [], 'owner_or_actor_commands_rerun': 0, 'new_model_actor_routes': 0, 'published_archive_identity_verified_against_git': {'commit': 'd8813ea46a06ce0e9f6260d6adccb4ab30cf4445', **received[str(ARCHIVE)]}, 'source': {'commit': COMMIT, 'tree': source_tree, 'path': GUIDE, 'git_blob': source_blob, 'bytes': len(guide), 'sha256': digest(guide)}, 'original_issue': received[str(ISSUE)], 'archive_members_verified': len(member_pins), 'prompt_accounting': {'archive_member': accounting_member, **received[str(accounting_copy)]}, 'episodes': episodes, 'received_file_count': len(received)}
(OUT / (PREFIX + 'verification.json')).write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
(OUT / (PREFIX + 'received-files.json')).write_text(json.dumps({'schema': 'dg17.retained-eligibility-received-inputs.v1', 'files': sorted(received.values(), key=lambda r: r['path']), 'archive_members': member_pins}, indent=2, sort_keys=True) + '\n')
print(json.dumps({'status': 'READ_ONLY_CHECKS_VERIFIED', 'archive_members': len(member_pins), 'received_files': len(received), 'commands_inspected': 25, 'raw_streams_verified': 50, 'archived_commands_executed': 0, 'episode01_actual_prompt': 'UNKNOWN_NOT_RECONSTRUCTED', 'episode05_reminder_snapshot': 'UNCHANGED_ALL_12_FILES'}, sort_keys=True))
