# H04 structural L5 limb: independent addendum

## Bounded assessment

**The new evidence supplies the previously unreviewed L5 record-consumer limb of the original H04 structural case. Combined with the retained actual L2 blocked-successor observation and the corrected N11 no-supplied-JOIN discriminator, it supports the named H04 structural composition. No material missing conjunct was established within that explicitly constructed structural scope.** This is an independent evidence judgment, not an H04 award, readiness decision, lifecycle acceptance, or full-DG17 conclusion.

The projection from JOIN evidence to a required closure claim is explicit **test/governor input construction**. The actual shipped validator consumes that claim. The demonstration does not establish an existing automatic graph-to-L5 bridge, native governor activation, native Stop, model judgment, or live audit closure. Those stronger claims are not silently substituted for the original structural clause.

Reviewer: `/root/g2_independent/g132_bridge_review`; report time `2026-11-18T05:23:29.371097+00:00`. `authority: NONE`; `authoring_context_reuse: no`. This addendum followed Root's separate bounded assignment after the frozen N11/B05 report. It retains the same developer-provided model label, **ChatGPT, GPT-6 Astra Pro**, with no independently observed provider/model identity. Work was read-only inspection and independent hash/data calculations; no worker test was replayed, and no worker source/evidence or controller state was changed.

The earlier report remains at SHA-256 `ee285979998e6f07d516bcfeb99d0ddd5c21e2dbe4015e8bc905b34fa4ffb49d`. Its H04 limits described evidence then within that report's scope. This separate addendum reviews the newly supplied L5 limb.

## Exact evidence and source identity

H04 artifact root: `/workspace/scratch/095d3235c921/evidence/dg17-next-20261118/h04-l5`. The complete reviewed-input descriptor snapshot is `/workspace/scratch/095d3235c921/evidence/dg17-next-independent-review/h04-l5-input-digests.json`, SHA-256 `966d9f21857b6f2ef848f76632040ad1d5127e68016efe344fa29d12d23fb270` (128 files). It also binds the original episode's underlying history/process streams and the prior N11/B05 review.

| Artifact or canonical source | SHA-256 |
|---|---|
| `PREIMAGE.json` | `8ab91243cbb8fc48a921923a48228f72ea13504476ccd339198b3d8567b9d480` |
| `build_records.py` | `6de56c09bddfcead3a4f9933ab43d5f39600eaddb949af0d27a70b04b90de3bf` |
| `RECORDS.json` | `6bc68789c16647f0e35894790d265630798bd746091a0f4ae419e951ea4eca74` |
| `RESULT.json` | `1266eb458b5a88407bd1c1915287eac9ca0af33816e762c7650bd7683fe06c43` |
| `EXECUTION_SEAL.json` | `74f43fcaa20ac2f5fbfd9ed9ad3aec33e94c94d0dfe0d554bbfca3bbd0df09e9` |
| `SOURCE_IDENTITY.json` | `1a8b3a863964204cf91b01d4a8fa3127767e93509624ccea801d051e99040fad` |
| `retained-join-episode.json` | `e6020765ca479aaae03b41bf0117a4ea3674035341ae14a46f9bb3f2f596966c` |
| `source/skills/implementaudit/scripts/validate-run-root.sh` | `7787569b4bceb541c33ee3287f0a8297882caff5478687e84fc534077e4c28ad` |
| `source/skills/implementaudit/scripts/check-closure-surface.sh` | `ba994fed1fb6c5d4688627bd31a577e7ce6fec5f6214fa3cc1093c9b70337ed7` |

All 77 materialized source files matched their recorded byte/hash descriptors and local canonical Git bodies at `a297957be11feb494c0ec467235794a1e0c54751`; the isolated source HEAD matches that commit and its read-only status observation was clean. The retained sparse-checkout warning concerns an unrelated absent workflow object and was not discarded or classified as source RED. Exact consumed source bodies are present. Git checks disabled optional locks and lazy fetching; no remote retrieval was used.

All seal entries, both record-file populations, both result receipts, saved exits, and raw stdout/stderr match their descriptors. The execution seal records 05:14:37.715430 UTC; the two captured consumer starts are 05:14:51.541850 and 05:14:52.799112 UTC. These are preserved record timestamps, not independently authenticated native history.

## Mapping from actual JOIN evidence

Original issue 211, at `/workspace/scratch/095d3235c921/evidence/dg17-next-20261118/inputs/original-issue211-body.md`, SHA-256 `ca62f4899a45544549f623a0312c16121bb99f432ccb87a87b7361974ceb94c4`, names H04 at line 580: an unfamiliar valid DAG lane with JOIN omitted, for which L2/L5 cannot consume and cognition cannot fill JOIN. Lines 541–545 explicitly permit structural topology and authority fixtures while limiting native/model claims.

The builder pins the retained episode bytes (24–28), requires each checkpoint to equal its exact retained snapshot (52–54), and computes the required claim from four facts (55–60):

1. `RETURN_REDUCER` has state `DONE`.
2. Exactly one canonical `JOIN` completion record identifies that node.
3. Its record digest equals the original shared reducer's completion digest.
4. The shared reducer returned `all_required_settled:true`.

Only then is `JOIN-RETURN_REDUCER` marked `verified`; otherwise it is `unverified`. This is a real computed predicate over received evidence, with the same rule applied to both arms. The arm-name assertion on line 61 checks the expected pairing after the predicate is computed; it does not set the status.

The completed checkpoint (`c42293f6f3dba04381f271ed73016de31ddf5ea407105c06d82eb8630b605386`) exactly equals `snapshots.after_actual_consumer`. The omitted checkpoint (`9887ca5cf9a26320ae3bf23640cb7228312c26e6846b65af63b2a41beb0c7bdc`) exactly equals `snapshots.lane_received_join_omitted`. I independently reproduced `settled=true` and `settled=false` from those bytes.

The retained episode also exactly matches the original artifact at `/workspace/scratch/095d3235c921/evidence/dg17-join-20261118/evidence.json`. I checked its original journal (`431ecfe1d95cc31805106c1fe9dd7501a8d1a0311831e6bccf65b60a91b49277`), chained event/record hashes, the omitted checkpoint's first-event history digest, the completed checkpoint's full-history digest, canonical JOIN record identity, and saved process stream descriptors. Thus the two inputs bind actual preserved source-consumer observations, not newly invented graph snapshots.

Across the two L5 record directories, `STATE.md` differs only in each record root's physical path. All other unrelated records are identical. Substantive differences are `checkpoint.json` and the derived claim status plus checkpoint hash/history references in `closure.md`. Both arms deliberately present otherwise complete phase/terminal-shaped records, so the missing required JOIN claim must defeat success-shaped closure input.

## Actual L5 owner receiving

The exact a297 `validate-run-root.sh --turn-disposition TERMINAL_CLOSURE ... --closure-record ...` checks terminal state and final audit markers/identity/coverage (294–310), rejects any required claim without `verified` or `not-applicable` status (311–312), and checks contained record dependencies (316). A successful terminal branch additionally invokes the canonical lesson-lift and closure-surface owners (377–381). It emits an explicit constructed-record/no-authentic-lifecycle qualifier (415).

The original protocol connects these checks to final auditing: `source/skills/implementaudit/templates/PROTOCOL.md` lines 1122–1150 require the final checker, no blocking gaps, and evidence on the required success surface. This is the existing L5 record boundary being exercised.

| Arm | Saved exit | Actual retained observation |
|---|---:|---|
| Completed JOIN | 0 | `record_disposition: TERMINAL_CLOSURE`, authority `NONE`, native enforcement false, authentic lifecycle acceptance not established |
| Omitted JOIN | 1 | `validate-run-root: RECORD_REFUSED: unclosed required closure claim; no disposition` |

Positive stdout SHA-256: `6948091e28c4023b8aab2551a793d8c210dc1ef8f15260d53e907fb8414f7573`; positive stderr is empty. Negative stderr SHA-256: `9c0222655f01dba7700229dfa8ca828e164c09bccd617393d4aa732692b6d24f`; negative stdout is empty. Neither recorded run timed out. The negative is a specific semantic refusal at the required-claim guard, not a setup, missing-source, transport, or generic exit failure.

**Boundary:** the shipped validator checks the declared required claim status. It does not itself recompute JOIN semantics or authenticate the custom checkpoint hash/history fields. That computation belongs to the explicit, pinned projection, whose inputs and output this review checked. The evidence therefore demonstrates the composed structural input mapping plus real consumer refusal; it does not prove arbitrary false `verified` declarations would be detected or that the product automatically performs this mapping.

## Combined H04 structural conclusion

| H04 element | Evidence at the allowed structural layer |
|---|---|
| Valid unfamiliar lane | Actual `ORCHID_INDEX` source inventory process and canonical TASK receiving in the retained source-consumer episode |
| L2 cannot advance while required JOIN is omitted | `ACTUAL_READER` remains BLOCKED, only `RETURN_REDUCER` is selected, and the actual consumer starts after shared reduction |
| L5 cannot close the selected required JOIN obligation | The computed unverified JOIN claim reaches the unchanged terminal owner and is refused; the completed-JOIN positive passes |
| Cognition/lane return cannot supply JOIN | The corrected N11 pair preserves rejection/no append under canonical source and catches the one-guard mutant's actual forbidden JOIN-as-BATCH record; shared reduction owns valid JOIN |

Under the original expressly permitted structural topology/authority layer, these are the named H04 conjuncts. A universal native/model requirement or an existing automatic converter is not stated in that structural clause, so I do not add one as a new acceptance condition. The result remains a declared structural composition over immutable inputs, with actual local owner behavior.

Root may independently decide case accounting. This report grants no award and establishes no full DG17 closure, general L5 convergence, native lifecycle/Stop, model quality, live currentness, or authentic terminal acceptance. No worker artifact was edited, and all input-snapshot hashes still matched at report completion.
