#!/usr/bin/env python3
"""Independent read-only receiving. Does not execute any supplied test/owner."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

EVIDENCE = Path('/workspace/scratch/095d3235c921/evidence/dg17-next-20261118')
REVIEW = EVIDENCE.parent / 'dg17-next-independent-review'
REPO = EVIDENCE.parent.parent / 'implementaudit'
BASE = 'a297957be11feb494c0ec467235794a1e0c54751'
TREE = 'b08dc4ecf4028beeedb579a312eccae23cb5d863'
CASES = ['m02-mutation', 'm05-mutation', 'm12-authority-mutation',
         'm14-selector-mutation', 'm04-identity-mutation/corrected']
RECEIVED = {}
SOURCE_CACHE = {}
COUNTS = {'pin_checks': 0, 'raw_stream_checks': 0, 'git_source_checks': 0}


def ident_data(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def data(path):
    path = Path(path)
    assert not path.is_symlink(), str(path)
    value = path.read_bytes()
    received = ident_data(value)
    previous = RECEIVED.setdefault(str(path), received)
    assert previous == received, 'changed during review: ' + str(path)
    return value


def obj(path):
    return json.loads(data(path))


def pin(path, expected):
    found = ident_data(data(path))
    assert found == {k: expected[k] for k in ('bytes', 'sha256')}, 'pin mismatch: ' + str(path)
    COUNTS['pin_checks'] += 1
    return found


def inventory(root):
    result = {}
    for p in sorted(Path(root).rglob('*')):
        assert not p.is_symlink(), str(p)
        if p.is_file():
            result[p.relative_to(root).as_posix()] = ident_data(data(p))
    return result


def git(*args, cwd=REPO):
    return subprocess.run(['git', *args], cwd=cwd, capture_output=True, check=True).stdout


def original(path):
    if path not in SOURCE_CACHE:
        SOURCE_CACHE[path] = git('show', BASE + ':' + path)
    return SOURCE_CACHE[path]


def stamp(value):
    return datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))


def streams(directory, prefix, receipt):
    for which in ('stdout', 'stderr'):
        path = directory / (prefix + which)
        pin(path, receipt[which])
        COUNTS['raw_stream_checks'] += 1


os.umask(0o077)
assert git('rev-parse', BASE + '^{tree}').decode().strip() == TREE
live = obj(REVIEW / 'mutation-batch02-issue211-live.json')['issue']
live_body = live['body'].encode()
original_body = data(EVIDENCE / 'inputs/original-issue211-body.md')
assert live_body == original_body
assert ident_data(live_body) == {'bytes': 64795, 'sha256': 'ca62f4899a45544549f623a0312c16121bb99f432ccb87a87b7361974ceb94c4'}
predicates = ['L2 selective invalidation/recompute;', 'L5 exact-candidate re-audit;',
              'unresolved-obligation closure refusal;', 'child no-authority/no-chain fence;',
              'cheap-path non-activation.']
assert all(value in live['body'] for value in predicates)
reviews = []
for case in CASES:
    root = EVIDENCE / case
    pre = obj(root / 'PREIMAGE.json')
    result = obj(root / 'RESULT.json')
    readback = obj(root / 'READBACK.json')
    assert pre['base_commit'] == BASE and pre['base_tree'] == TREE
    pin(root / 'run_pair.py', pre['driver'])
    pin(root / 'frozen_oracle.py', pre.get('oracle', pre.get('frozen_oracle')))
    mutation = pre['mutation']
    rel = mutation['path']
    old = mutation.get('old', mutation.get('old_line')).encode()
    new = mutation.get('new', mutation.get('new_line')).encode()
    if case == 'm12-authority-mutation':
        sources = {variant: {rel: pin(root / variant / 'validator.py', pre['source_variants'][variant])}
                   for variant in ('baseline', 'mutant')}
        before = data(root / 'baseline/validator.py')
        after = data(root / 'mutant/validator.py')
        assert before == original(rel)
        COUNTS['git_source_checks'] += 1
        pin(root / 'original_fixture_source.py', pre['original_fixture'])
        assert data(root / 'original_fixture_source.py') == original(pre['original_fixture']['path'])
        COUNTS['git_source_checks'] += 1
    else:
        sources = {}
        for variant in ('baseline', 'mutant'):
            sources[variant] = inventory(root / variant / 'source')
            assert sources[variant] == pre['sources'][variant], case + ': source population/pins'
        for path in sources['baseline']:
            assert data(root / 'baseline/source' / path) == original(path), case + ': nonoriginal baseline ' + path
            COUNTS['git_source_checks'] += 1
        before = data(root / 'baseline/source' / rel)
        after = data(root / 'mutant/source' / rel)
    assert before.count(old) == 1
    assert after == before.replace(old, new), case + ': mutation not sole declared substitution'
    assert set(sources['baseline']) == set(sources['mutant'])
    delta = [path for path in sources['baseline'] if sources['baseline'][path] != sources['mutant'][path]]
    assert delta == [rel]
    if 'records' in pre:
        assert inventory(Path(pre['records_root'])) == pre['records']
    else:
        assert inventory(root / 'inputs') == pre['inputs']
    assert stamp(pre['at']) < stamp(result['baseline']['started_at']) < stamp(result['mutant']['started_at']) < stamp(readback['at'])
    if 'elapsed_seconds' in result['baseline']:
        end = stamp(result['baseline']['started_at']) + datetime.timedelta(seconds=result['baseline']['elapsed_seconds'])
        assert end <= stamp(result['mutant']['started_at'])
    observations = {}
    for variant in ('baseline', 'mutant'):
        work = root / variant / 'work'
        receipt = obj(root / variant / 'oracle.receipt.json')
        assert receipt == result[variant]
        assert receipt['exit'] == (0 if variant == 'baseline' else 1)
        assert receipt['argv'][1:3] == ['-I', '-B']
        assert receipt['argv'][3] == str(root / 'frozen_oracle.py')
        assert '--variant' in receipt['argv'] and variant in receipt['argv']
        streams(root / variant, 'oracle.', receipt)
        obs = obj(work / 'observations.json')
        observations[variant] = obs
        for capture in obs.get('captures', []):
            if case == 'm02-mutation':
                prefix = capture['sequence'] + '-' + capture['node'] + '.'
                folder = work / 'captures'
                assert obj(folder / (prefix + 'receipt.json')) == capture
                streams(folder, prefix, capture)
                assert json.loads(data(folder / (prefix + 'stdout'))) == capture['input']
                assert capture['exit'] == 0 and capture['timed_out'] is False
                assert isinstance(capture['pid'], int)
                assert capture['argv'][1:3] == ['-I', '-B']
            elif case == 'm12-authority-mutation':
                streams(work, capture['arm'] + '.', capture)
                assert json.loads(data(work / (capture['arm'] + '.stdout'))) == capture['output']
                assert capture['argv'][3] == str(root / variant / 'validator.py')
                assert capture['output']['authority'] == 'NONE'
                assert capture['output']['validation'] == 'VALUE_VALIDATION'
                assert 'does not authenticate' in capture['output']['proof_limit']
            else:
                folder = work / capture['arm']
                assert obj(folder / 'receipt.json') == capture
                streams(folder, '', capture)
                assert capture['argv'][0:4] == ['bash', str(root / variant / 'source' / pre['owner']), '--turn-disposition', 'TERMINAL_CLOSURE']
                assert capture['argv'][4] == str(Path(pre['records_root']) / capture['arm'])
                assert capture['timed_out'] is False
                assert capture['cwd'] == pre['git_context']
                assert isinstance(capture['pid'], int)
    baseline, mutant = (observations[k] for k in ('baseline', 'mutant'))
    stderr = data(root / 'mutant/oracle.stderr').decode()
    if case == 'm02-mutation':
        changed = baseline['snapshots']['after_dependency_change']
        failed = mutant['snapshots']['after_dependency_change']
        assert changed['selected'] == ['INPUT_VARIANT']
        assert set(changed['invalidated']) == {'INPUT_VARIANT', 'FINAL_REDUCER'}
        assert changed['states']['INPUT_VARIANT'] == 'READY' and changed['states']['FINAL_REDUCER'] == 'BLOCKED'
        assert all(changed['states'][name] == 'DONE' for name in pre['preserved'])
        assert failed['selected'] == [] and failed['states']['INPUT_VARIANT'] == 'DONE'
        assert 'AssertionError: affected completed result survived changed dependency' in stderr
        assert [x['node'] for x in baseline['captures']] == pre['initial_order'] + ['INPUT_VARIANT']
        assert [x['node'] for x in mutant['captures']] == pre['initial_order']
        assert baseline['preserved_outputs_before'] == baseline['preserved_outputs_after']
        before_events = baseline['snapshots']['before_dependency_change']['completion_events']
        after_events = baseline['snapshots']['after_selective_recompute']['completion_events']
        def digests(events):
            return {r['node']: r['digest'] for e in events for r in e['records'] if r['node'] in pre['preserved']}
        assert digests(before_events) == digests(after_events) == baseline['preserved_completion_digests_before']
        for name, oldstat in baseline['preserved_outputs_after'].items():
            file = root / 'baseline/work/captures' / ('initial-' + name + '.stdout')
            stat = file.stat()
            assert {'identity': ident_data(data(file)), 'inode': stat.st_ino, 'mtime_ns': stat.st_mtime_ns} == oldstat
        assert baseline['journal_unchanged_by_reobservation'] and baseline['selective_recompute_completed']
        pin(root / 'baseline/work/journal/history.json', baseline['journal_final'])
        assert len(obj(root / 'baseline/work/journal/history.json')['events']) == 6
        assert len(obj(root / 'mutant/work/journal/history.json')['events']) == 4
        pin(Path(pre['fixture_constructor']['path']), pre['fixture_constructor'])
        for source in pre['input_provenance']:
            pin(Path(source['actual_origin']), source)
            assert data(Path(source['actual_origin'])) == data(root / 'inputs' / source['input'])
        cleanup = obj(root / 'TRANSIENT_CACHE_CLEANUP.json')
        assert cleanup['removed_exact_cache'] and not Path(cleanup['exact_path']).exists()
        scope = 'Selective dependency/result invalidation and recomputation in the actual CompletionContract with seven real digest-producer subprocesses; no formal L3 phases, native lifecycle or whole L2 re-entry claim.'
    elif case == 'm05-mutation' or case.startswith('m04-'):
        assert [x['exit'] for x in baseline['captures']] == [0, 1]
        assert [x['exit'] for x in mutant['captures']] == [0, 0]
        arm = 'omitted' if case == 'm05-mutation' else 'stale'
        actual = obj(root / 'mutant/work' / arm / 'stdout')
        assert actual['record_disposition'] == 'TERMINAL_CLOSURE' and actual['authority'] == 'NONE'
        assert actual['effect_authority'] is False and actual['native_enforcement'] is False
        error = data(root / 'baseline/work' / arm / 'stderr').decode()
        assert data(root / 'baseline/work' / arm / 'stdout') == b''
        if case == 'm05-mutation':
            assert error == 'validate-run-root: RECORD_REFUSED: unclosed required closure claim; no disposition\n'
            assert 'AssertionError: unresolved required closure obligation was accepted' in stderr
            scope = 'Required-claim status refusal by the actual terminal record consumer on unchanged H04 constructed records; no authentic lifecycle closure or automatic graph-to-L5 integration.'
        else:
            assert 'AUDIT_VERIFY_ANCHOR must equal current HEAD' in error
            assert 'AssertionError: stale candidate closure was accepted' in stderr
            scope = 'Current-candidate identity guard in the actual terminal/closure source consumer; no real repair/re-audit cycle, native closure or whole M04 family.'
        assert git('rev-parse', 'HEAD', cwd=Path(pre['git_context'])).decode().strip() == BASE
        assert git('status', '--porcelain', cwd=Path(pre['git_context'])) == b''
    elif case == 'm12-authority-mutation':
        good = obj(root / 'inputs/return-valid.json')
        bad = obj(root / 'inputs/return-authority.json')
        assert [key for key in good if good[key] != bad[key]] == ['authority']
        assert good['authority'] == 'NONE' and bad['authority'] == 'RELEASE'
        assert [x['exit'] for x in baseline['captures']] == [0, 2]
        assert [x['exit'] for x in mutant['captures']] == [0, 0]
        assert baseline['captures'][1]['output']['error'] == 'result.authority has an unsupported value'
        assert mutant['captures'][1]['output']['status'] == 'VALID'
        assert 'AssertionError: authority-shaped supplied child value was admitted' in stderr
        scope = 'Supplied result.authority allowed-value guard only, from four actual validator subprocesses; no actual child, maintainer route, authenticated currentness or no-chain conjunction.'
    else:
        one = baseline['outputs']['single']['frontier']
        many = baseline['outputs']['multiple']['frontier']
        bad = mutant['outputs']['single']['frontier']
        assert one['selected'] == ['ONE_OWNER_READ'] and one['mode'] == 'CHEAP_SERIAL' and one['graph_required'] is False
        assert many['selected'] == ['ALPHA_READ', 'BETA_READ', 'GAMMA_READ']
        assert many['mode'] == 'GRAPH_CANDIDATE' and many['graph_required'] is True
        assert one['authority'] == many['authority'] == bad['authority'] == 'NONE'
        assert bad == {**one, 'mode': 'GRAPH_CANDIDATE', 'graph_required': True}
        assert mutant['outputs']['multiple'] == baseline['outputs']['multiple']
        assert 'AssertionError: single-owner work activated the graph selector' in stderr
        scope = 'Canonical selector mode/graph_required discrimination for constructed single/multiple-owner graphs, four function calls in two oracle processes; no downstream graph creation or full ceremony-free/native behavior.'
    reviews.append({'case': case, 'result': ident_data(data(root / 'RESULT.json')),
                    'readback': ident_data(data(root / 'READBACK.json')),
                    'preimage': ident_data(data(root / 'PREIMAGE.json')),
                    'baseline_source_members': len(sources['baseline']),
                    'sole_source_delta': rel, 'baseline_oracle_exit': 0,
                    'mutant_oracle_exit': 1, 'maximum_literal_scope': scope,
                    'review_disposition': 'RECEIVABLE_ONLY_WITH_STATED_SCOPE',
                    'original_row_awarded': False})

# M04: independently verify the retained confound and pre-execution, two-field repair.
initial = EVIDENCE / 'm04-identity-mutation'
corrected = initial / 'corrected'
old_pre = obj(initial / 'PREIMAGE.json')
new_pre = obj(corrected / 'PREIMAGE.json')
justification = obj(initial / 'ROOT_FIXTURE_REPAIR_JUSTIFICATION.json')
assert ident_data(data(initial / 'ROOT_FIXTURE_REPAIR_JUSTIFICATION.json')) == {'bytes': 2544, 'sha256': 'b12757736c3d070242f8eaa81e3ac457250a6391455eb9a953960750954014d8'}
assert ident_data(data(corrected / 'RESULT.json'))['sha256'] == '5bbf6ff3ef0e99bc84f66c6999bd2f3d2e146acfad69a5c8dac608772b32a358'
assert ident_data(data(corrected / 'READBACK.json'))['sha256'] == 'b5d479ac81ed04b873c393bafb10faaaf1067c485f6d5d79c55f82cc12efd5e3'
pin(initial / 'PREIMAGE.json', justification['initial_preimage'])
pin(initial / 'INITIAL_CONFOUND.json', justification['initial_confound'])
initial_obs = obj(initial / 'baseline/work/observations.json')
assert [x['exit'] for x in initial_obs['captures']] == [1, 1]
for capture in initial_obs['captures']:
    directory = initial / 'baseline/work' / capture['arm']
    streams(directory, '', capture)
    assert b'closure steer inventory does not select this run root' in data(directory / 'stderr')
assert not (initial / 'mutant').exists()
assert inventory(Path(old_pre['records_root'])) == old_pre['records']
assert inventory(initial / 'baseline/source') == old_pre['sources']['baseline']
assert data(initial / 'frozen_oracle.py') == data(corrected / 'frozen_oracle.py')
assert data(initial / 'run_pair.py') == data(corrected / 'run_pair.py')
assert old_pre['original_expected'] == new_pre['original_expected']
delta = []
for path in old_pre['records']:
    before = data(Path(old_pre['records_root']) / path)
    after = data(Path(new_pre['records_root']) / path)
    if before != after:
        delta.append(path)
        old, new = (justification['allowed_delta'][key].encode() for key in ('old_line', 'new_line'))
        assert before.count(old) == 1 and after == before.replace(old, new)
assert delta == ['current/STATE.md', 'stale/STATE.md']
assert stamp(justification['at']) < stamp(new_pre['at']) < stamp(obj(corrected / 'FIXTURE_DELTA_READBACK.json')['at']) < stamp(obj(corrected / 'RESULT.json')['baseline']['started_at'])
predecessor = git('rev-parse', BASE + '^').decode().strip()
assert predecessor == new_pre['actual_retained_predecessor'] == 'c2faca3a5bccf26b4571fddbece4d420385c86b5'
current_root, stale_root = (Path(new_pre['records_root']) / key for key in ('current', 'stale'))
current_inv, stale_inv = inventory(current_root), inventory(stale_root)
assert set(current_inv) == set(stale_inv)
assert [p for p in current_inv if current_inv[p] != stale_inv[p]] == ['closure.md']
current, stale = data(current_root / 'closure.md'), data(stale_root / 'closure.md')
assert current.count(BASE.encode()) == 2 and stale == current.replace(BASE.encode(), predecessor.encode())
assert b"inventory_fields.get('Steer directory') not in {str(root),'<run-root>'}" in original('skills/implementaudit/scripts/validate-run-root.sh')
assert b'[ "$verify_anchor" = "$current_head" ]' in original('skills/implementaudit/scripts/check-closure-surface.sh')

for path, received in list(RECEIVED.items()):
    assert ident_data(Path(path).read_bytes()) == received, 'changed at final readback: ' + path
report = {'schema': 'dg17.independent-mutation-batch02-receiving.v1',
          'reviewer': '/root/dg18_execution', 'author_of_reviewed_cells': '/root/dg17_execution',
          'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'source_commit': BASE, 'source_tree': TREE,
          'live_issue': {'url': live['url'], 'updated_at': live['updated_at'],
                         'body': ident_data(live_body), 'matches_frozen_original': True},
          'checks': COUNTS, 'unique_original_git_source_bodies': len(SOURCE_CACHE),
          'cases': reviews, 'M04_repair': {'allowed_delta': delta, 'oracle_driver_expectations_unchanged': True,
                                          'initial_confound_preserved': True, 'chronology_verified': True,
                                          'current_commit': BASE, 'stale_existing_predecessor': predecessor},
          'tests_or_owners_reexecuted': 0, 'rows_awarded': 0, 'source_mutations_by_reviewer': 0,
          'findings_requiring_correction': [],
          'disposition': 'RECEIVABLE_WITH_LITERAL_SCOPE_LIMITS_ROOT_DECISION_REQUIRED'}
out = REVIEW / 'mutation-batch02-verification.json'
out.write_text(json.dumps(report, indent=2) + '\n')
manifest = REVIEW / 'mutation-batch02-received-files.json'
manifest.write_text(json.dumps({'schema': 'dg17.independent-mutation-batch02-input-manifest.v1',
                                'files': RECEIVED}, indent=2) + '\n')
print(json.dumps({'status': report['disposition'], 'received_files': len(RECEIVED), 'checks': COUNTS,
                  'cases': [{'case': x['case'], 'source_members': x['baseline_source_members'], 'disposition': x['review_disposition']} for x in reviews],
                  'verification': ident_data(out.read_bytes()), 'received_manifest': ident_data(manifest.read_bytes())}))
