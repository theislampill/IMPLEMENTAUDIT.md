# DG17 N11 mutation and B05 fixture-repair evidence review

## Independent scope and result

**The preserved evidence supports the exact N11 structural source-consumer discriminator and the one-guard DAG JOIN ownership mutation. The repair sequence also supports the literal B05 fixture-abstraction case at this engineering evidence layer. No material blocker was established for these bounded conclusions.** Case credit, acceptance, readiness, and closure remain Root decisions; this report issues none.

- Reviewer: `/root/g2_independent/g132_bridge_review`, assigned directly by `/root` after completing a separate G132 review.
- `authoring_context_reuse: no`. This reviewer did not create the N11 oracle, mutant, repaired fixture, execution receipts, or Root justification. Context includes the unrelated completed G132 review and the bounded N11 assignment; it is not described as a newly forked fresh session.
- Model label: developer-provided **ChatGPT, GPT-6 Astra Pro**. Native/provider model identity was not independently observed.
- `authority: NONE`; no internal `audit-assess` route, source mutation, worker-evidence edit, test replay, controller/currentness operation, Root record, award, or acceptance was performed.
- Assignment continuity reference, treated as supplied context: `refs/implementaudit/continuity-receipts/dg16-dg18-pro-20261118/G0003@dd8488e9bbb2e541e332997dfe69f67fe83714ca`. This reviewer did not mutate or independently authenticate that controller receipt.
- Review time: `2026-11-18T05:19:27.212314+00:00`.

This was a read-only evidence review. I read the original issue predicates, frozen oracle, input adapter, preserved failure/repair/result records, relevant canonical consumer code, and actual saved streams and journals. Independent calculations verified hashes, Git source identity, the exact source and input deltas, journal/event/record integrity, graph ordering, stream descriptors, and before/after journal bindings. I did not execute the worker oracle or reproduce its claimed historical process session.

## Digest binding

All relative source paths in this report resolve under the exact absolute root:

`/workspace/scratch/095d3235c921/evidence/dg17-next-20261118`

The complete input snapshot is `/workspace/scratch/095d3235c921/evidence/dg17-next-independent-review/n11-b05-input-digests.json` (SHA-256 `571cfd1b11fb8ceee4319f4c6884416623801fe14a1c5be5275978200b14c418`), containing `123` file descriptors. It binds the initial and corrected work products, diagnostic preservation, streams, graph documents, source copies, oracle, adapter, and original issue body. It is an ordinary evidence snapshot, not a provenance credential. Core assigned record hashes were rechecked before this report was written.

| Input path relative to source root | SHA-256 |
|---|---|
| `inputs/original-issue211-body.md` | `ca62f4899a45544549f623a0312c16121bb99f432ccb87a87b7361974ceb94c4` |
| `n11-mutation/frozen_oracle.py` | `c6bef7cbe1bc487877f778609db554a67b652c76d4d5f5267edd1d400ffa5cb4` |
| `n11-mutation/corrected_fixture_adapter.py` | `abd8ab70fa68680898544cc2c61b7abc6587ed3176be7e7a932cd76035227619` |
| `n11-mutation/mutation.patch` | `aa0e6bae028fa035c1d0c00d5bdaa0096db38bcd4431454260fbf21c85ae6f61` |
| `n11-mutation/PREIMAGE.json` | `b1f9a4cc30dc1feab88bdfd952fd2491dd0b4716808414b1528be7325cc1d00e` |
| `n11-mutation/INITIAL_RESULT.json` | `3f984b2d08b0af948809f12988c9e009029fca62221f6742c60b20cc10bb0095` |
| `n11-mutation/INITIAL_CONFOUND.json` | `4e13e64fcef024acde5c0faecc6f3f676ac3da0697fe122dd7a534081cce2220` |
| `n11-mutation/ROOT_FIXTURE_REPAIR_JUSTIFICATION.json` | `a55ba047ece2fcccfe2b26364dc19eddbb1f99fa15287d3c5409e236c8c72e9c` |
| `n11-mutation/CORRECTED_PREIMAGE.json` | `c50f70ea4ffbcfb4af4b870f80f9a515940e02437f0228ca5527f13da233f0f6` |
| `n11-mutation/CORRECTED_RESULT.json` | `3b98a4f67001f8b65638959d1411409c76839c2c0f46109cc5e74665a1f91cd3` |

The original issue body is 64,795 bytes. Both Root-provided required pins match: repair justification `a55ba047ece2fcccfe2b26364dc19eddbb1f99fa15287d3c5409e236c8c72e9c` and corrected result `3b98a4f67001f8b65638959d1411409c76839c2c0f46109cc5e74665a1f91cd3`.

## 1. Original requirement and the exact tested predicate

The original issue's N11 row (line 569) names **DAG JOIN attributed to child/lane result**, with the expected ownership **governor/DAG-owned**. Line 613 separately requires a DAG JOIN ownership mutation. Lines 541–545 expressly permit structural fixtures for topology, identity, population, marker and authority facts while excluding model-judgment and real-host-activation claims. This review applies those original predicates; it does not derive a weaker replacement from the reported outcome.

The relevant semantic owner is `n11-mutation/baseline/source/scripts/work-graph-completion.py`, SHA-256 `70137df6459caa3eecbf847580a34968d13aa1991eae6208e37ea84e60f556eb`. Its `CompletionContract.accept` requires an issued, unchanged frontier and current history identity (414–423), a selected contributor (433–435), a **TASK** result rather than a supplied JOIN (436), and a contributor belonging to the named consumer with a compatible declared future consumer (425–426, 455–457). A result accepted through this entry point is appended as `BATCH` (474–490).

The separate canonical `join` method derives its result from required/optional contributor records and the shared JOIN predicate, then appends a `JOIN` event (493–525). It explicitly keeps portable declared-result scope and `native_dispatch_authorized:false` (505–506). The mutation target is therefore an actual ownership boundary in the consumer, not a marker search or a simulated expected message.

The frozen oracle (152–181) constructs a lane-shaped result envelope for `RETURN_REDUCER`, whose graph kind is `JOIN`, from actual inventory bytes. It supplies that envelope to `accept(..., "FINAL_REDUCER")`; it requires the exact ownership refusal and unchanged journal. On success, the same oracle calls the actual shared `join` method, then executes the dependent read-only consumer and retains its bytes (185–201). The forbidden envelope is explicitly constructed; it is not represented as an authentic native child event.

## 2. Exact canonical source and one-guard mutation

I compared each baseline source copy byte-for-byte to its local Git object at commit `a297957be11feb494c0ec467235794a1e0c54751`. All three matched, including declared modes and byte/hash descriptors:

| Source member | Baseline SHA-256 | Canonical Git blob |
|---|---|---|
| `scripts/work-graph-completion.py` | `70137df6459caa3eecbf847580a34968d13aa1991eae6208e37ea84e60f556eb` | `be996a63c82e97325b25f07315b852fe7f7e5d48` |
| `scripts/operational-evidence.py` | `7d013db025d2579b6ed521b33d3b9307256d8d327aada3cca3d06e4290d45c7d` | `7298ff8ab404762f930797c5f838380167edc4b3` |
| `skills/implementaudit/scripts/compile-work-graph.py` | `226f4897a5e8edd0ffe460426a9b2995cd5f2bcfb169b68978ae727d065f685b` | `951137a63e8f96f13d0cfd598be0249abca31bad` |

The sole mutant change is consumer line 436:

```python
# Canonical
_require(nodes[name]['kind'] == 'TASK', 'JOIN completion requires the shared JOIN reducer')
# Mutant
_require(nodes[name]['kind'] in ('TASK', 'JOIN'), 'JOIN completion requires the shared JOIN reducer')
```

The mutant owner SHA-256 is `7c7122511dd0a8be30130f4a8e7e0b9cec7b34c94ef1917b7d62bd46201864da`. An independently computed unified diff exactly matched the preserved `mutation.patch` (`aa0e6bae028fa035c1d0c00d5bdaa0096db38bcd4431454260fbf21c85ae6f61`). The other two source members are unchanged. The mutant manifest explicitly describes its commit/tree values as base identities and its executable identity as the per-member hashes; it does not claim that altered bytes are the canonical Git commit.

Both initial and corrected runs point to these same baseline/mutant source directories, and each arm's initial and corrected source manifests are byte-identical. No canonical-source regression or runtime RED is established by this deliberately relaxed mutant.

## 3. The initial failure is preserved and nonqualifying

The initial baseline exit is 0. The initial mutant exit is 1, but its retained traceback reaches **frozen oracle line 180**, the comparison of the actual refusal to the expected ownership-refusal text. It does not reach the designated line-179 assertion that a supplied child/lane JOIN was accepted.

`INITIAL_CONFOUND.json` preserves the actual `foreign consumer scope` diagnostic at owner line 456. This agrees with the unchanged code and graph: `RETURN_REDUCER.future_consumer` names `FINAL_REDUCER`, but the initial `FINAL_REDUCER.requires` contains only `ACTUAL_READER` (oracle 83–92). After relaxing the TASK-only guard, the unrelated contributor-membership predicate still rejects the envelope. The initial mutant journal contains only the `ORCHID_INDEX` TASK `BATCH`; it contains no accepted `RETURN_REDUCER` JOIN attribution. I verified its event/record chain and its file hash `b31809895b8c024ffa5f9aba5afcddd771cef4df628e3f3f78403ce0e655128e`.

`INITIAL_RESULT.json` correctly calls this confounded and grants no mutation-family credit. The initial oracle, source copies, graph input, streams, result, diagnostic work and initial receipts remain present and digest-bound. The prior `ROOT_N11_ACCEPTANCE.json` remains unchanged at `d87141326a78be4618b1de65aba523dab08528c51d3a2ce5a74083282b73832b`; it is historical decision data, not this reviewer's authority. The new repair justification expressly holds prior award reliance pending new qualification.

## 4. The single-edge repair removes the confound without changing assertions or order

The Root justification authorizes only this input change:

```text
FINAL_REDUCER.requires:
  [ACTUAL_READER]
  -> [ACTUAL_READER, RETURN_REDUCER]
```

The adapter pins the original oracle and exact Root justification before executing `oracle.main` (adapter lines 13–19 and 33). It wraps only the `node` constructor, requires the original `FINAL_REDUCER` value, changes it once, and checks both the single amendment and unchanged oracle hash afterward (23–36). The negative assertion at oracle line 179, exact refusal expectation at 180, no-append condition at 181, positive reduction/consumer assertions and claim limits remain byte-identical.

I compared all constructed input files for each arm. In **both** arms, only `tasks/FINAL_REDUCER.md` changes, and its only changed node field is `requires`. The original file is 607 bytes, SHA-256 `3c15acc1adf92bb5e14ef70bf74bb1295b17da9130c48ae100d1a2d741a19860`; the corrected file is 624 bytes, SHA-256 `63d74d4f228d8961179b5f045c9052a88db2e5c584c509dbbe6d7a6645d898a9`.

Independently computed dependency reachability is identical before and after repair, and both graphs are acyclic. `RETURN_REDUCER` already precedes `FINAL_REDUCER` through `ACTUAL_READER`; the new direct edge declares the consumer relationship required by the scope guard without changing the partial task order. It removes an independent rejection condition from the adversarial case, requiring the unmodified implementation to discriminate on JOIN ownership itself. This is a legitimate fixture correction, not weakened refusal expectations or a source alteration made to match the desired result.

## 5. Corrected baseline and mutant demonstrate the intended discrimination

All four saved per-arm receipts exactly match the corresponding rows in `INITIAL_RESULT.json` or `CORRECTED_RESULT.json`; saved exit-code files and stdout/stderr hashes agree. The corrected baseline exits **0** and the corrected mutant exits **1**.

| Arm under `n11-mutation/` | Exit | stdout SHA-256 | stderr SHA-256 |
|---|---:|---|---|
| `baseline` | 0 | `bfbaa3020db31dd57afdcdfcc912cf244a265782d6ddadd13bfa488bbbe5e34f` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `mutant` | 1 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` | `3292a43b5baa0a304bdae97c1ac7dbf7c12d61edbff64933c24456de018fecf9` |
| `corrected/baseline` | 0 | `37e798dbc4e7f3c5e81a56d535f206a82659aaa5c4dc836b27a267a548ad63ca` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `corrected/mutant` | 1 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` | `0ed1abf5b9b028cde7d4c079b355ba565cef1c6773dddc79f95992c7ac49af76` |

The corrected baseline retains evidence `corrected/baseline/work/evidence.json`, SHA-256 `bff754fcc01811e5e58c884c37f593c407a657c2188d92044815060be584d068` (40,971 bytes), matching its stdout descriptor. Its journal (`e0208e7107f454c5cd01a3d7266b3c8dc389fbda1f27f306fb08721d5b0a09b7`) contains this sequence:

1. TASK `ORCHID_INDEX` accepted as `BATCH`.
2. `RETURN_REDUCER` completed through a canonical `JOIN` event.
3. TASK `ACTUAL_READER` accepted as `BATCH` after consuming the inventory.
4. `FINAL_REDUCER` completed through a canonical `JOIN` event.

I reconstructed the one-event journal prefix preceding the rejected forged JOIN. Its bytes hash `51ffeb0c35eaadbdfa75ea2931de135f38ac42f5106035b7cebe207d8b6618e7` matches both recorded before/after-refusal descriptors; its canonical digest matches the recorded unchanged history digest. The recorded successor remains blocked after the forged result and becomes selected only after canonical reduction. The final root state is **READY**, not DONE, with authority `NONE` and native dispatch false.

The corrected mutant journal is `corrected/mutant/work/journal/history.json`, SHA-256 `a345479d2d04ce5f31163f3512f0648c9a54ed7aa16934f7b1f1ae00c58f1f1e`. Its second event is the forbidden attribution:

- Event kind: `BATCH`.
- Event digest: `a891d035e37c66ab66010a4bb5f9f0f6041ce090c046ad31c69b2e8201afb2f7`.
- Record node and actual source-graph kind: `RETURN_REDUCER`, `JOIN`.
- Consumer: `FINAL_REDUCER`.
- Result status: `PASS`, with lane-style independence key `actual-process-RETURN_REDUCER` and the actual inventory evidence digest.
- Record digest: `3d63f024d12342b4d6937bbeb5f8c09050794211d1233efa97ee08797a5840fc`.

I recomputed every event's chained digest and every result record's digest in all four journals. The corrected mutant then fails at **frozen oracle line 179** with `AssertionError: supplied child/lane JOIN was accepted`, exactly the designated frozen negative. It never proceeds to the dependent `consume` process. Thus the mutant failure is backed by a retained prohibited state transition, not just exit 1 or a changed diagnostic string.

The saved producer bodies match the frozen oracle's literal producer. Every process stream descriptor in initial, diagnostic and corrected observation files matches its saved stdin/stdout/stderr. Inventories match the actual three-source bytes. Both baseline consumer stdin files equal the corresponding inventory stdout; recorded producers/consumers exit 0 without timeout and report their owned process groups absent. These are consistent preserved local process records, not an independently authenticated native session transcript.

## 6. Literal B05 mapping and before-rerun justification

Original B05 (issue line 575) requires a spurious fixture-abstraction gap with the witness kept and the oracle repaired/justified before rerun. The broader instrument rule (509–511) explicitly includes changed **fixtures** and forbids weakening a negative; the STOP condition repeats this preservation/independent-justification requirement (849–850).

The saved sequence meets those narrow facts:

| Recorded step | UTC time |
|---|---|
| Initial oracle/mutation preimage frozen | 05:03:17.070055 |
| Initial baseline started | 05:03:38.922817 |
| Initial mutant started | 05:03:39.512007 |
| Root's independent repair justification issued | 05:11:17.296489 |
| Corrected preimage frozen | 05:12:21.767539 |
| Corrected baseline started | 05:12:40.619542 |
| Corrected mutant started | 05:12:41.238395 |

The failure and diagnostic are real retained predecessors, the Root justification identifies the actual source guard interaction, and the same correction is applied to both arms. The exact justification is a prerequisite enforced by the adapter before invoking the frozen oracle, in addition to this recorded chronology. The unchanged negative becomes discriminating after removing the fixture's contradictory contributor declaration.

**Independent assessment:** the evidence supports Root mapping this preserved repair episode to the literal B05 no-evidence-gaming boundary. This statement is a bounded source/evidence judgment, not a B05 award or authenticity proof for the named issuer. This reviewer received the exact Root justification through the Root assignment; there is no separate native timestamp or issuer-history authentication here.

## Claim ceiling and unresolved scope

The corrected evidence supports the original **N11 structural topology/authority predicate** and its **DAG JOIN ownership one-guard mutation**. The test exercises the actual portable consumer over constructed graph/result inputs and saved read-only process bytes. It does not establish every possible DAG path or a native child/host dispatch.

No H04 whole-case or actual L5 omitted-JOIN consumer arm is shown. A blocked ordinary successor and the labels `N11/H04` in the oracle/evidence are insufficient to establish H04's full L2/L5/cognition conjunction. The evidence explicitly retains `whole_case_award:false`, `native_session:false`, `native_Stop:false`, `model_control:false`, `audit_closure:false`, and authority `NONE`; the prior Root record also expressly leaves H04's L5 arm unproved. The internal `PASS` field of the mutant's accepted result is the prohibited graph attribution being tested, not a governance verdict.

No model-judgment, native activation, native Stop, L5 convergence, full DG17, hosted/public, release, terminal-clause, or closure credit follows. Initial confounded results remain nonqualifying. The deliberately relaxed mutant is not a canonical source runtime RED. All worker evidence and source remained untouched by this reviewer, and no worker process was replayed.
