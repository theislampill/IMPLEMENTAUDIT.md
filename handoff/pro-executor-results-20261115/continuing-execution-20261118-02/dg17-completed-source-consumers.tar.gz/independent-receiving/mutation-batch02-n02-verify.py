#!/usr/bin/env python3
"""Read-only N02 receiving; no owner, historical route or fixture execution."""
import base64
import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile

E = Path('/workspace/scratch/095d3235c921/evidence/dg17-next-20261118')
R = E.parent / 'dg17-next-independent-review'
REPO = E.parent.parent / 'implementaudit'
CELL = E / 'n02-l5-consumer'
RETAINED = E / 'n02-retained-inputs'
BASE = 'a297957be11feb494c0ec467235794a1e0c54751'
PUBLISHED = 'd8813ea46a06ce0e9f6260d6adccb4ab30cf4445'
PREFIX = 'handoff/pro-executor-results-20261115/continuing-execution-20261117/received-execution-evidence/'
RECEIVED = {}


def ident(b):
    return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


def blob_id(b):
    return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()


def read(path):
    path = Path(path)
    assert not path.is_symlink()
    b = path.read_bytes()
    prior = RECEIVED.setdefault(str(path), ident(b))
    assert prior == ident(b), 'changed during receiving'
    return b


def obj(path):
    return json.loads(read(path))


def pinned(path, value):
    b = read(path)
    assert ident(b) == {k: value[k] for k in ('bytes', 'sha256')}, str(path)
    if 'git_blob' in value:
        assert blob_id(b) == value['git_blob']
    return b


def git(*args, cwd=REPO):
    return subprocess.run(['git', *args], cwd=cwd, capture_output=True, check=True).stdout


def inventory(root):
    return {p.relative_to(root).as_posix(): ident(read(p)) for p in sorted(Path(root).rglob('*')) if p.is_file()}


os.umask(0o077)
pre = obj(CELL / 'PREIMAGE.json')
result = obj(CELL / 'RESULT.json')
assert ident(read(CELL / 'PREIMAGE.json'))['sha256'] == 'ac43944aa651eda4faa213ef00799c3984074e546925684574fda9898636b680'
assert ident(read(CELL / 'RESULT.json')) == {'bytes': 7167, 'sha256': 'da75dce31caa17949cb00df65092daef63b8cbc29041d371c0ebfdb1ed10660a'}
assert ident(read(CELL / 'REPORT.md')) == {'bytes': 2994, 'sha256': 'ddac6ac7ba856fcb7328684831c7f6b77a20f63c60d2e06b4d7299a45e3c564d'}
assert pre['base_commit'] == BASE
assert git('rev-parse', BASE + '^{tree}').decode().strip() == pre['base_tree']
pinned(CELL / 'frozen_oracle.py', pre['frozen_oracle'])
source = Path(pre['source_root'])
assert inventory(source) == pre['sources']['baseline']
for name in pre['sources']['baseline']:
    assert read(source / name) == git('show', BASE + ':' + name)
assert len(pre['sources']['baseline']) == 77

# Reconstruct the published archive strictly from immutable ordered part pins.
contents_path = REPO / PREFIX / 'RECEIVING_EVIDENCE_CONTENTS.json'
contents_bytes = read(contents_path)
assert contents_bytes == git('show', PUBLISHED + ':' + PREFIX + contents_path.name)
contents = json.loads(contents_bytes)
encoded = []
for part in contents['parts']:
    b = pinned(REPO / PREFIX / part['path'], part)
    assert b == git('show', PUBLISHED + ':' + PREFIX + part['path'])
    assert b.endswith(b'\n') and b'\n' not in b[:-1]
    encoded.append(b[:-1])
archive = base64.b64decode(b''.join(encoded), validate=True)
assert ident(archive) == {k: contents['archive'][k] for k in ('bytes', 'sha256')}
assert blob_id(archive) == contents['archive']['git_blob']
assert archive == pinned(RETAINED / 'retained-receiving.tar.gz', contents['archive'])
rows = {}
for member_file in contents['member_files']:
    b = pinned(REPO / PREFIX / member_file['path'], member_file)
    assert b == git('show', PUBLISHED + ':' + PREFIX + member_file['path'])
    for row in json.loads(b)['rows']:
        assert row['path'] not in rows
        rows[row['path']] = row
extraction = obj(RETAINED / 'EXTRACTION.json')
assert extraction['archive'] == contents['archive'] and extraction['replay'] is False
with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tf:
    members = tf.getmembers()
    assert len(members) == contents['member_count'] == len(rows) == 123
    for selected in extraction['selected']:
        assert selected == rows[selected['path']]
        member = tf.getmember(selected['path'])
        assert member.isfile() and member.size == selected['bytes'] < 100000
        b = tf.extractfile(member).read()
        assert b == pinned(RETAINED / selected['path'], selected)
        assert ident(b) == {k: selected[k] for k in ('bytes', 'sha256')}

historical = pre['authentic_return']
report = pinned(historical['report']['path'], historical['report'])
past_result = json.loads(pinned(historical['result']['path'], historical['result']))
past_root = json.loads(pinned(historical['separate_historical_Root_receiving']['path'], historical['separate_historical_Root_receiving']))
assert past_result['reviewer'] == '/root/dg17_live_candidate_receiver'
assert past_result['role'] == 'audit-assess' and past_result['disposition'] == 'PASS'
assert past_result['binding'] == historical['actual_historical_binding'] == past_root['binding']
assert past_root['review_report_sha256'] == ident(report)['sha256']
assert past_root['review_result_sha256'] == historical['result']['sha256']
assert past_root['decision'] == 'COMPLETE_EXACT_PHASE_2_AND_REQUEST_ACTUAL_REAUDIT'
assert past_root['original_acceptance'] == 'NONVERDICT pending actual re-audit and terminal receiving'
assert b'no currentness, phase-completion, mutation, acceptance, release, or closure authority' in report
assert b'The corrective phase is not yet complete' in report

# Preserve all old H04 record bytes, except prospective relocation and the same
# explicit historical-data insertion in both closure bodies.
records = Path(pre['records_root'])
assert inventory(records) == pre['records']
inserts = []
marker = b'AUDIT_COMPLETE\nIMPLEMENTAUDIT_RUN_COMPLETE\n'
for arm in ('completed', 'omitted'):
    oldroot = E / 'h04-l5/records' / arm
    newroot = records / arm
    oldfiles = inventory(oldroot)
    newfiles = inventory(newroot)
    assert set(newfiles) - set(oldfiles) == {'historical-assess/REPORT.md', 'historical-assess/RESULT.json'}
    assert read(newroot / 'historical-assess/REPORT.md') == report
    assert read(newroot / 'historical-assess/RESULT.json') == read(historical['result']['path'])
    for name in oldfiles:
        old, new = read(oldroot / name), read(newroot / name)
        if name == 'STATE.md':
            oldline = ('| Steer directory | ' + str(oldroot) + ' |').encode()
            assert old.count(oldline) == 1 and new == old.replace(oldline, b'| Steer directory | <run-root> |')
        elif name == 'closure.md':
            assert old.endswith(marker) and new.endswith(marker)
            prefix = old[:-len(marker)]
            assert new.startswith(prefix) and new.count(report) == 1
            insertion = new[len(prefix):-len(marker)]
            assert insertion.count(report) == 1
            assert insertion.startswith(b'\n## Historical audit-assess input; no current authority\n')
            assert b'not current candidate evidence' in insertion
            inserts.append(insertion)
        else:
            assert old == new
assert inserts[0] == inserts[1]

oracle = obj(CELL / 'oracle.receipt.json')
assert oracle['exit'] == 0 and oracle['argv'][1:3] == ['-I', '-B']
assert oracle['argv'][3] == str(CELL / 'frozen_oracle.py')
assert oracle['argv'][7] == str(source)
assert datetime.datetime.fromisoformat(pre['at']) < datetime.datetime.fromisoformat(oracle['started_at']) < datetime.datetime.fromisoformat(result['at'])
for stream in ('stdout', 'stderr'):
    pinned(CELL / ('oracle.' + stream), oracle[stream])
obs = obj(CELL / 'work/observations.json')
assert obs['captures'] == result['receipts']
assert obs['source_unchanged'] and obs['records_unchanged'] and obs['git_context_unchanged']
assert len(obs['captures']) == 2
for index, capture in enumerate(obs['captures']):
    assert capture['arm'] == ('completed' if index == 0 else 'omitted')
    assert capture['exit'] == index and capture['timed_out'] is False
    assert capture['argv'][1] == str(source / pre['owner'])
    assert capture['argv'][4] == str(records / capture['arm'])
    assert capture['argv'][-1] == str(records / capture['arm'] / 'closure.md')
    directory = CELL / 'work' / capture['arm']
    assert obj(directory / 'receipt.json') == capture
    for stream in ('stdout', 'stderr'):
        pinned(directory / stream, capture[stream])
assert obj(CELL / 'work/completed/stdout') == result['positive_disposition']
assert result['positive_disposition']['authority'] == 'NONE'
assert result['positive_disposition']['effect_authority'] is False
assert result['positive_disposition']['native_enforcement'] is False
assert read(CELL / 'work/omitted/stdout') == b''
assert read(CELL / 'work/omitted/stderr') == b'validate-run-root: RECORD_REFUSED: unclosed required closure claim; no disposition\n'
assert git('rev-parse', 'HEAD', cwd=Path(pre['git_context'])).decode().strip() == BASE
assert git('status', '--porcelain', cwd=Path(pre['git_context'])) == b''
issue = obj(R / 'mutation-batch02-issue211-live.json')['issue']['body']
assert '| N02 | Negative | `audit-assess` returns PASS-shaped prose | Findings only; deterministic current evidence still required | Child cannot replace L5 |' in issue
for path, pin in RECEIVED.items():
    assert ident(Path(path).read_bytes()) == pin
verification = {
    'schema': 'dg17.N02.independent-structural-addendum-receiving.v1',
    'reviewer': '/root/dg18_execution', 'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'disposition': 'RECEIVABLE_CURRENT_RECORD_NO_SUBSTITUTION_CONJUNCT_ONLY',
    'source_commit': BASE, 'source_tree': pre['base_tree'], 'source_members_verified': 77,
    'publication_commit': PUBLISHED, 'archive': contents['archive'],
    'ordered_parts_verified': len(contents['parts']), 'archive_members_bound': len(rows),
    'retained_members_verified': len(extraction['selected']),
    'historical_report': historical['report'], 'historical_result': historical['result'],
    'separate_historical_root': historical['separate_historical_Root_receiving'],
    'historical_subject_commit': past_result['binding']['task_commit'],
    'historical_binding_remains_historical': True,
    'same_verbatim_insertion_bytes': len(inserts[0]), 'report_bytes_in_each_consumed_closure': len(report),
    'exact_report_occurrences_each': 1, 'current_owner_calls': 2,
    'owner_exits': [0, 1], 'oracle_exit': 0,
    'current_child_invoked': False, 'current_child_review_or_currentness_authenticated': False,
    'claim_limit': 'Actual terminal record owner reads closure bytes containing identical authentic historical child PASS prose and still refuses a declared unverified required claim. It does not authenticate this historical report as a current child return or validate complete L5/native/model behavior.',
    'suite_or_owner_reruns_by_reviewer': 0, 'new_mutation_credit': False,
    'source_mutations_by_reviewer': 0, 'original_case_awards': 0,
    'findings_requiring_correction': []}
output = R / 'mutation-batch02-n02-verification.json'
output.write_text(json.dumps(verification, indent=2) + '\n')
manifest = R / 'mutation-batch02-n02-received-files.json'
manifest.write_text(json.dumps({'schema': 'dg17.N02.independent-input-manifest.v1', 'files': RECEIVED}, indent=2) + '\n')
print(json.dumps({'disposition': verification['disposition'], 'files_received': len(RECEIVED),
                  'verification': ident(output.read_bytes()), 'manifest': ident(manifest.read_bytes()),
                  'parts_verified': len(contents['parts']), 'selected_members_verified': len(extraction['selected'])}))
