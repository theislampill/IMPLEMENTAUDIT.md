"""Receive preserved data only; never invoke an archived task command."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import tarfile

BASE = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/095d3235c921/implementaudit')
TARGET = 'a297957be11feb494c0ec467235794a1e0c54751'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=sha(raw))


def read(name):
    return json.loads((BASE / name).read_text())


def check(path, expected):
    actual = pin(path)
    assert (actual['bytes'], actual['sha256']) == (expected['bytes'], expected['sha256']), str(path)
    return actual


inputs = []
for manifest_name, key in [('EXTRACTION.json', 'selected_members'), ('EXTRACTION_ADDENDUM.json', 'members')]:
    for row in read(manifest_name)[key]:
        inputs.append(check(Path(row['local_path']), row))
assert len(inputs) == 236

sources = []
for path in ['skills/implementaudit/SKILL.md', 'skills/audit-andon/SKILL.md',
             'skills/implementaudit/scripts/claim-run.sh', 'skills/implementaudit/scripts/validate-run-root.sh']:
    raw = subprocess.check_output(['git', 'show', TARGET + ':' + path], cwd=REPO)
    sources.append(dict(commit=TARGET, path=path, bytes=len(raw), sha256=sha(raw)))
guidance = sources[0]
for ep in ['episode_01', 'episode_05']:
    check(BASE / '20261116/dg17' / ep / 'actor/guidance/SKILL.md', guidance)
assert sources[1]['sha256'] == 'd774154be7940f88e6402b9d7299f36792e0a636c9023f68fe88b062e2604ff9'

episodes = {}
for ep, count in [('episode_01', 9), ('episode_05', 16)]:
    root = BASE / '20261116/dg17' / ep
    records = sorted((root / 'capture').glob('command-*/record.json'))
    assert len(records) == count
    commands = []
    previous = None
    boundaries = []
    for record in records:
        d = json.loads(record.read_text())
        for stream in ['stdout', 'stderr']:
            check(record.parent / (stream + '.bin'), d[stream])
        before = {x['path']: x for x in d['before']}
        after = {x['path']: x for x in d['after']}
        delta = [n for n in sorted(set(before) | set(after)) if before.get(n) != after.get(n)]
        if previous is not None and previous != before:
            boundaries.append(dict(command=record.parent.name,
                                   changed=[n for n in sorted(set(previous) | set(before))
                                            if previous.get(n) != before.get(n)]))
        previous = after
        commands.append(dict(record=pin(record), argv=d['argv'], exit_code=d['exit_code'], changed=delta,
                             stdout=pin(record.parent/'stdout.bin'), stderr=pin(record.parent/'stderr.bin')))
    for row in previous.values():
        if row['kind'] == 'file':
            check(root / 'actor' / row['path'], row)
    episodes[ep] = dict(commands=commands, between_command_deltas=boundaries,
                       raw_streams_verified=count * 2,
                       failures=[r['record']['path'] for r in commands if r['exit_code']])

b01 = episodes['episode_01']
assert [(Path(r['record']['path']).parent.name, r['changed']) for r in b01['commands'] if r['changed']] == [('command-005', ['workshops.csv'])]
assert not b01['between_command_deltas']
assert [r['exit_code'] for r in b01['commands']] == [0,0,0,0,0,1,0,0,0]
rubric01 = read('20261116/dg17/episode_01/receiver/RUBRIC.json')
csv_bytes = (BASE/'20261116/dg17/episode_01/actor/workshops.csv').read_bytes()
assert csv_bytes == rubric01['expected_task']['expected_bytes'].encode()

b03 = episodes['episode_05']
stage_a = read('20261116/dg17/episode_05/receiver/STAGE_A_BOUNDARY.json')
stage_b = read('20261116/dg17/episode_05/receiver/STAGE_B_BOUNDARY.json')
assert stage_a['snapshot'] == stage_b['snapshot']
reminder = b03['commands'][10]
assert reminder['argv'] == ['python', '-B', 'check_outputs.py']
assert reminder['exit_code'] == 0 and reminder['changed'] == []
assert b03['between_command_deltas'] == [dict(command='command-012', changed=['sources/contacts.json'])]
assert [r['exit_code'] for r in b03['commands']] == [0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0]
assert [(Path(r['record']['path']).parent.name,r['changed']) for r in b03['commands'] if r['changed']] == [
    ('command-006',['output/getting-started.txt']),('command-007',['output/shortcuts.txt']),
    ('command-008',['output/contacts.txt']),('command-014',['output/contacts.txt'])]

p04base = BASE/'20261117/evidence/dg17_p04'
assert (p04base/'BEFORE.json').read_bytes() == (p04base/'AFTER.json').read_bytes()
p04_commands = []
for name, expected_exit in [('STALE',1),('CURRENT',0),('REQUIRE',0)]:
    d=json.loads((p04base/(name+'.json')).read_text())
    assert d['exit_code'] == expected_exit and d['affected_mutation_executed'] is False
    for stream in ['stdout','stderr']:
        assert (p04base/(name+'.'+stream)).read_bytes() == d[stream].encode()
    p04_commands.append(dict(record=pin(p04base/(name+'.json')), argv=d['argv'], exit_code=d['exit_code']))
p04 = read('20261117/evidence/dg17_p04/INDEPENDENT_RECEIVING.json')['P04']
before = read('20261117/evidence/dg17_p04/BEFORE.json')
assert p04['receipt_objects']['G000A']['state_sha256'] == before['pair']['STATE.md']['sha256']
assert p04['receipt_objects']['G0009']['state_sha256'] != before['pair']['STATE.md']['sha256']
for name in ['STATE','ROADMAP']:
    assert sha((p04base/('REANCHORED_'+name+'.md')).read_bytes()) == p04['receipt_objects']['G000B'][name.lower()+'_sha256']

p08 = read('20261116/dg17/evidence/DG17_DIRECT_ANDON_RETURN_LIMB_RECEIVING_20261116.json')
check(BASE/'p08-direct/AUDIT_ANDON_DIRECT_RETURN.json',p08['actual_return']['record'])

p10 = read('20261116/dg17/DG17_P10_SOURCE_LEARNING_FINAL_RECEIVING.json')
for row in p10['evidence'] + [p10['actual_owner_learning_record'],p10['final_cold_receiving'],p10['final_independent_probes']]:
    check(BASE/'20261116'/row['path'],row)
p10_commands=[]
for name, code in [('RED',1),('GREEN',0),('REVIEW_RED',1),('REVIEW_GREEN',0),('IMPERATIVE_RED',1),('FINAL_GREEN',0)]:
    d=read('20261116/main_repair_evidence/'+name+'.json')
    assert d['exit_code']==code
    for stream in ['stdout','stderr']:
        raw=(BASE/'20261116/main_repair_evidence'/(name+'.'+stream)).read_bytes()
        assert raw==d['actual_'+stream].encode() and sha(raw)==d[stream+'_sha256']
    p10_commands.append(dict(record=pin(BASE/'20261116/main_repair_evidence'/(name+'.json')),exit_code=code))
final=read('20261116/main_repair_evidence/FINAL_CANDIDATE.json')
for row in final['changed_paths']:
    raw=subprocess.check_output(['git','show',final['candidate_tree']+':'+row['path']],cwd=REPO)
    assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
    sources.append(dict(tree=final['candidate_tree'],**row))

b02 = read('20261117/evidence/dg17_b02/transport-event.json')
assert b02['selected_child_count']==0 and b02['child_skill_route'] is None
archivebase=REPO/'handoff/pro-executor-results-20261115/continuing-execution-20261116'
manifest=json.loads((archivebase/'EVIDENCE_MANIFEST.json').read_text())
check(archivebase/'evidence.tar.gz',manifest['archive'])
with tarfile.open(archivebase/'evidence.tar.gz') as archive:
    members=[m for m in archive.getmembers() if m.isfile()]
    assert [m.name for m in members] == [r['path'] for r in manifest['members']]
    total=0
    for member,row in zip(members,manifest['members']):
        raw=archive.extractfile(member).read()
        assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
        total+=len(raw)
assert len(members)==739 and total==7365677

result=dict(schema='dg17.six-retained-eligibility-mechanical-receiving.v1',
            recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            author='/root/dg17_execution',authority='NONE',original_award=False,
            selected_inputs_verified=len(inputs),inputs=inputs,target_sources=sources,
            episodes=episodes,p04_commands=p04_commands,p04_exact_before_after=True,
            p04_g000a_matches_before=True,p04_old_g0009_mismatch_preserved=True,
            p04_g000b_reanchors_exact_pair=True,p08_exact_return_verified=True,
            p10_commands=p10_commands,p10_final_source_git_bytes_verified=True,
            b02_archive_members_verified=739,b02_archive_member_bytes=total,
            archived_task_commands_replayed=0,new_model_invocations=0,
            interpretation='Retained actual evidence and original expectations only. Fresh hash/record verification is not replay, current adoption, native telemetry or an original-case award.')
with (BASE/'READBACK.json').open('x') as stream:
    json.dump(result,stream,indent=2,sort_keys=True);stream.write('\n')
print(json.dumps(dict(result=pin(BASE/'READBACK.json'),input_files=len(inputs),
                     actual_historic_capture_records=34,raw_streams=68,
                     archived_task_commands_replayed=0,new_model_invocations=0)))
