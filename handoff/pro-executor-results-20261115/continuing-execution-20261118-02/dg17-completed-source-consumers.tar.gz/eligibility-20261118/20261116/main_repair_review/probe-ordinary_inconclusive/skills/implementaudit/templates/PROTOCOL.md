After 3 retries, the currentness check may still fail; continue collecting independent evidence.
