After 3 retries, continue collecting independent evidence.
