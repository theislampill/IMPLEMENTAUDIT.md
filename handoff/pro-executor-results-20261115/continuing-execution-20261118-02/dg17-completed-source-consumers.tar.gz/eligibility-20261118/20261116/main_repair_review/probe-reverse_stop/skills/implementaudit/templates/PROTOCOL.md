Stop the run after 3 retries.
