Hand off the run after three retries.
