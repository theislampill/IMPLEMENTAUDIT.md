The currentness check may still fail after 3 retries; continue collecting independent evidence.
