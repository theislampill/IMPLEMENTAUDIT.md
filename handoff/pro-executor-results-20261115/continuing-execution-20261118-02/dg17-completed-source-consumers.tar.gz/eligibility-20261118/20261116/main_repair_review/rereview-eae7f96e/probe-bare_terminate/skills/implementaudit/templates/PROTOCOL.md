After 3 retries, terminate.
