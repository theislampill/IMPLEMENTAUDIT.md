After 3 retries, stop.
