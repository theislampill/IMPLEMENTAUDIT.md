Stop the diagnostic trace after 3 retries; continue the run.
