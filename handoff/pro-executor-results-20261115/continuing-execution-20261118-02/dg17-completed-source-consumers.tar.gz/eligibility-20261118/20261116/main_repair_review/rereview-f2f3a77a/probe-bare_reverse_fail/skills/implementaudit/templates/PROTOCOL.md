Fail after 3 retries.
