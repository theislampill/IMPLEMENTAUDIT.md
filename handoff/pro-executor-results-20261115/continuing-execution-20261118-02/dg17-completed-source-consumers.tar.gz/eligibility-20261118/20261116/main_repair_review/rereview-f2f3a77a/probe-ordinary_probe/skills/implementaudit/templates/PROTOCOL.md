After 3 retries, fail the stale probe and continue collecting independent evidence.
