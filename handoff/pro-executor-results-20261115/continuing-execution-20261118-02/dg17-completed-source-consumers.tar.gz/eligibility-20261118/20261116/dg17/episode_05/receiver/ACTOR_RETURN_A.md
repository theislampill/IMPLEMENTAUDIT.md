## Bounded task result: complete

Generated all three help pages using the supplied `build.py`; each output passes verification.

| Output | Status | Verified size |
|---|---|---:|
| [getting-started.txt](sandbox:/workspace/scratch/c2993647a0c7/dg17/episode_05/actor/output/getting-started.txt) | Done | 55 bytes |
| [shortcuts.txt](sandbox:/workspace/scratch/c2993647a0c7/dg17/episode_05/actor/output/shortcuts.txt) | Done | 51 bytes |
| [contacts.txt](sandbox:/workspace/scratch/c2993647a0c7/dg17/episode_05/actor/output/contacts.txt) | Done | 39 bytes |

### Supporting evidence

All shell operations ran through the required capture wrapper.

- **Baseline:** `python -B check_outputs.py` exited **1**, reporting all three outputs as `missing`.
- **Generation:** `python -B build.py NAME` exited **0** for each of `getting-started`, `shortcuts`, and `contacts`.
- **Final checker:** `python -B check_outputs.py` exited **0** and reported:
  ```text
  getting-started: ok
  shortcuts: ok
  contacts: ok
  ```
- **Independent byte verification:** Each generated file exactly matches its source title, blank line, ordered lines, and terminating newlines.
- **Preservation check:** SHA-256 comparisons confirmed the nine inspected source, script, instruction, specification, and selected-guidance files remain unchanged.

Only the three permitted output files were written. No guidance reference needed for this bounded task was missing. No blockers remain.

Suggested commit message, without performing a commit: `Generate source-defined help pages`

This report returns evidence for the delegated task and makes no broader audit or release claim.
