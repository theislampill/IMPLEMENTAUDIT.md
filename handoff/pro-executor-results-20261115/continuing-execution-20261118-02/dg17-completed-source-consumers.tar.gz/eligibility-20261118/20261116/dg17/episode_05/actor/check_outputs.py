import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
NAMES = ('getting-started', 'shortcuts', 'contacts')

def main():
    names = sys.argv[1:] or NAMES
    if any(name not in NAMES for name in names):
        raise SystemExit('unknown output name')
    failures = []
    for name in names:
        src = json.loads((BASE / 'sources' / (name + '.json')).read_text())
        expected = '\n'.join([src['title'], '', *src['lines'], ''])
        target = BASE / 'output' / (name + '.txt')
        state = 'missing' if not target.is_file() else 'ok' if target.read_text() == expected else 'stale'
        print(name + ': ' + state)
        if state != 'ok':
            failures.append(name)
    return 1 if failures else 0

if __name__ == '__main__':
    raise SystemExit(main())
