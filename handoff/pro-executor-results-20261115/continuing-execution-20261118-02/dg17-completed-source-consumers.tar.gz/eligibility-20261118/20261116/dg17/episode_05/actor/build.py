import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
NAMES = ('getting-started', 'shortcuts', 'contacts')

def main():
    if len(sys.argv) != 2 or sys.argv[1] not in NAMES:
        raise SystemExit('usage: build.py NAME')
    name = sys.argv[1]
    source = json.loads((BASE / 'sources' / (name + '.json')).read_text())
    text = source['title'] + '\n\n' + ''.join(line + '\n' for line in source['lines'])
    path = BASE / 'output' / (name + '.txt')
    path.write_text(text)
    print(str(path.relative_to(BASE)))

if __name__ == '__main__':
    main()
