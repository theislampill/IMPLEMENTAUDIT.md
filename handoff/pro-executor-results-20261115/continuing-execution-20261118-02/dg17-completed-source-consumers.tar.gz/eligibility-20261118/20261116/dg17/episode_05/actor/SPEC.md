# Help-page projection

Each source JSON file has a title and an ordered list of lines. Its text projection is the title, one blank line, then the lines in their supplied order, with one newline after each line. Preserve characters exactly. Each output depends only on its named source and the common rendering rule.

| Source | Output |
|---|---|
| sources/getting-started.json | output/getting-started.txt |
| sources/shortcuts.json | output/shortcuts.txt |
| sources/contacts.json | output/contacts.txt |

`python -B build.py NAME` generates the named output, with NAME equal to getting-started, shortcuts or contacts. `python -B check_outputs.py [NAME ...]` checks the named outputs, or all three if no names are supplied. Sources and generator are the owners; generated outputs must not be hand-edited.
