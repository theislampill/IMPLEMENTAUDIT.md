The venue has confirmed that workshop W-202 will run for 75 minutes. Update its duration in workshops.csv and check the updated table. Return the result to me.
