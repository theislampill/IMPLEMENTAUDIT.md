# M04 exact-candidate identity limb

The corrected exact-source baseline accepts the current-a297 audit record and rejects the same positive record carrying its actual retained predecessor commit as both audit anchors. The rejection names `AUDIT_VERIFY_ANCHOR must equal current HEAD`. The source-copy mutant removes only that equality check, retaining the nonempty/40-hex/local-commit and unchanged-anchor checks. It actually accepts the stale audit record as TERMINAL_CLOSURE; the byte-identical frozen oracle catches that admission.

| Source | Current a297 anchors | Actual predecessor anchors | Frozen oracle |
|---|---|---|---|
| Exact a297 | exit 0, terminal record disposition | exit 1, current-HEAD identity refusal | pass |
| One identity-guard mutant | exit 0 | exit 0, terminal record disposition | fails: stale candidate closure was accepted |

The actual predecessor is c2faca3a5bccf26b4571fddbece4d420385c86b5; it was resolved from the exact original a297 commit. The executing Git context remains a297957be11feb494c0ec467235794a1e0c54751, clean and unchanged. The changed source is check-closure-surface.sh; the outer validate-run-root.sh and every other source member remain unchanged.

## Preserved initial failure and independently justified relocation

The initial baseline refused both relocated records because their STATE closure inventory still named the old H04 record directory. No mutant was created or executed in that failed pair. INITIAL_CONFOUND.json, the original PREIMAGE, records, source and captures remain unchanged. Root independently read the exact original validator and issued ROOT_FIXTURE_REPAIR_JUSTIFICATION.json at 05:44:46Z before any corrected record was made.

Only one Steer directory field in each separately copied current/stale STATE changes to the original owner's accepted literal `<run-root>`. FIXTURE_DELTA_READBACK.json verifies exactly those two substitutions and no other record changes. The stale/current anchor difference remains unchanged. Both frozen executable scripts remain byte-identical to the initial pair. Corrected PREIMAGE was frozen before the four corrected consumer calls began at 05:45:31Z. No further fault or fixture repair occurred.

The corrected RESULT `input_changes: []` means the same corrected inputs were used for baseline and mutant; it does not erase or deny the earlier two-field relocation. Corrected READBACK explicitly records that distinction.

This establishes the exact-candidate identity structural limb. It does not establish a real repair/re-audit cycle, whole M04 family, authentic lifecycle closure, native enforcement, model behavior or author acceptance. Root retains independent receiving and qualification. Actual consumer JSON continues to report authority NONE, effect_authority=false and native_enforcement=false.
