"""Frozen exact-candidate identity oracle for the original L5 re-audit mutation limb.

This is a structural source-consumer qualification. It grants no lifecycle,
native, mutation, publication, or acceptance authority.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


def identity(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def inventory(root):
    result = {}
    for path in sorted(root.rglob("*")):
        assert not path.is_symlink(), str(path)
        if path.is_file():
            result[path.relative_to(root).as_posix()] = identity(path)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--variant", choices=("baseline", "mutant"), required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    home = Path(__file__).resolve().parent
    preimage = json.loads((home / "PREIMAGE.json").read_text())
    assert identity(Path(__file__)) == preimage["frozen_oracle"]
    args.out.mkdir()
    source_before = inventory(args.source)
    assert source_before == preimage["sources"][args.variant]
    records = Path(preimage["records_root"])
    records_before = inventory(records)
    assert records_before == preimage["records"]
    cwd = Path(preimage["git_context"])
    before_git = subprocess.check_output(["git", "status", "--porcelain"], cwd=cwd)
    assert before_git == b""
    assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=cwd).strip().decode() == preimage["base_commit"]
    captures = []
    for arm in ("current", "stale"):
        directory = args.out / arm
        directory.mkdir()
        temporary = directory / "tmp"
        temporary.mkdir()
        env = dict(os.environ, TMPDIR=str(temporary), PYTHONDONTWRITEBYTECODE="1")
        record = records / arm
        argv = ["bash", str(args.source / preimage["owner"]),
                "--turn-disposition", "TERMINAL_CLOSURE", str(record),
                "--closure-record", str(record / "closure.md")]
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        start = time.monotonic()
        process = subprocess.Popen(argv, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        timed_out = False
        try:
            stdout, stderr = process.communicate(timeout=30)
        except subprocess.TimeoutExpired:
            timed_out = True
            process.kill()
            stdout, stderr = process.communicate()
        (directory / "stdout").write_bytes(stdout)
        (directory / "stderr").write_bytes(stderr)
        receipt = {"arm": arm, "argv": argv, "cwd": str(cwd), "pid": process.pid,
                   "started_at": started, "elapsed_seconds": time.monotonic() - start,
                   "exit": process.returncode, "timed_out": timed_out,
                   "stdout": identity(directory / "stdout"), "stderr": identity(directory / "stderr")}
        (directory / "receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
        captures.append(receipt)
    source_unchanged = inventory(args.source) == source_before
    records_unchanged = inventory(records) == records_before
    git_unchanged = subprocess.check_output(["git", "status", "--porcelain"], cwd=cwd) == before_git
    observed = {"schema": "dg17.M04.frozen-oracle-observations.v1", "variant": args.variant,
                "captures": captures, "source_unchanged": source_unchanged,
                "records_unchanged": records_unchanged, "git_context_unchanged": git_unchanged,
                "original_expectations_unchanged": True, "authority": "NONE"}
    (args.out / "observations.json").write_text(json.dumps(observed, indent=2, sort_keys=True) + "\n")
    assert source_unchanged and records_unchanged and git_unchanged
    assert not any(row["timed_out"] for row in captures)
    assert captures[0]["exit"] == 0, "current candidate closure failed its positive control"
    positive = json.loads((args.out / "current/stdout").read_text())
    assert positive["record_disposition"] == "TERMINAL_CLOSURE" and positive["authority"] == "NONE"
    assert captures[1]["exit"] == 1, "stale candidate closure was accepted"
    assert "AUDIT_VERIFY_ANCHOR must equal current HEAD" in (args.out / "stale/stderr").read_text()
    assert (args.out / "stale/stdout").read_bytes() == b""
    print(json.dumps({"original_oracle": "PASS", "variant": args.variant, "authority": "NONE"}))


if __name__ == "__main__":
    main()
