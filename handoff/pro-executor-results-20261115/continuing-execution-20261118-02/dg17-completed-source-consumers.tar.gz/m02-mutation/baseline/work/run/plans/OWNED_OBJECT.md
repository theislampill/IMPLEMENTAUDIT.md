```implementaudit-work-graph
{"nodes":[{"acceptance":[],"authority":[],"authorization":"PERMITTED","context":{"child_cost":2,"governor_cost":1,"locality":"GOVERNOR","return_cost":1,"useful_value":5},"done_evidence":null,"effect":"READ_ONLY","future_consumer":null,"id":"OWNED_OBJECT","independence":"KNOWN","independent_results":false,"invalidators":[],"kind":"PLAN","logical_delivery":null,"optional":[],"parent":null,"rank":0,"reads":[],"requires":["FINAL_REDUCER"],"resource_demand":1,"resources":[],"route_scopes":[],"state":"OPEN","writes":[]}],"schema":"implementaudit.native-spec.v1"}
```
