```implementaudit-work-graph
{"campaign":"dg17-selective-source-consumer-20261118","context":{"host_capacity":1,"operator_ceiling":null,"outstanding_deliveries":[],"reserve":0,"route_facts":[]},"event":{"id":"constructed-source-comparison","kind":"RETURN","subject":"SOURCE_RULES"},"nodes":["OWNED_OBJECT","SOURCE_RULES","ROOT_DECISION","INPUT_VARIANT","FINAL_REDUCER"],"original_scope":"Original selective invalidation/recompute structural source consumer; no formal L3 or native claim","root":"OWNED_OBJECT","schema":"implementaudit.native-state.v1"}
```
