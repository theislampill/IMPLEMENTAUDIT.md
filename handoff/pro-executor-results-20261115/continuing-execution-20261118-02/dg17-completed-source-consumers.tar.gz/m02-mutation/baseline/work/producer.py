import hashlib,json,pathlib,sys
d=pathlib.Path(sys.argv[1]).read_bytes()
print(json.dumps({"bytes":len(d),"sha256":hashlib.sha256(d).hexdigest()},sort_keys=True))
