"""Original selective invalidation/recompute oracle over actual graph consumers.

Constructed graph inputs, actual read-only producer processes, exact owner source.
No native lifecycle, model result, formal L3 phase or acceptance award is asserted.
"""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


def raw(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def digest(value):
    return hashlib.sha256(value).hexdigest()


def ident(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": digest(data)}


def inventory(root):
    return {p.relative_to(root).as_posix(): ident(p) for p in sorted(root.rglob("*")) if p.is_file()}


def snapshot_file(path):
    s = path.stat()
    return dict(identity=ident(path), inode=s.st_ino, mtime_ns=s.st_mtime_ns)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--work", type=Path, required=True)
    parser.add_argument("--variant", choices=("baseline", "mutant"), required=True)
    args = parser.parse_args()
    home = Path(__file__).resolve().parent
    pre = json.loads((home / "PREIMAGE.json").read_text())
    assert ident(Path(__file__)) == pre["oracle"]
    assert inventory(args.source) == pre["sources"][args.variant]
    frozen = home / "inputs"
    assert inventory(frozen) == pre["inputs"]
    args.work.mkdir()
    run = args.work / "run"
    run.mkdir()
    (run / "inputs").mkdir()
    for name, value in pre["graph_documents"].items():
        path = run / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"```implementaudit-work-graph\n" + raw(value) + b"\n```\n")
    for dest, origin in pre["initial_inputs"].items():
        (run / "inputs" / dest).write_bytes((frozen / origin).read_bytes())
    original_graph = inventory(run)
    (args.work / "captures").mkdir()
    producer = args.work / "producer.py"
    producer.write_bytes((frozen / "producer.py").read_bytes())
    captured = []
    snapshots = {}
    notes = {"schema": "dg17.M02.actual-selective-graph-observations.v1",
             "variant": args.variant, "source": pre["sources"][args.variant],
             "captures": captured, "snapshots": snapshots,
             "authority": "NONE", "native_dispatch": False, "model_calls": 0,
             "formal_L3_phase_claim": False}

    def save():
        (args.work / "observations.json").write_text(json.dumps(notes, indent=2, sort_keys=True) + "\n")

    def execute(name, sequence):
        file = run / pre["task_input_paths"][name]
        command = [sys.executable, "-I", "-B", str(producer), str(file)]
        prefix = args.work / "captures" / (sequence + "-" + name)
        start = time.monotonic()
        process = subprocess.Popen(command, cwd=args.work, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, start_new_session=True)
        pgid = os.getpgid(process.pid)
        timeout = False
        try:
            stdout, stderr = process.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            timeout = True
            os.killpg(pgid, signal.SIGKILL)
            stdout, stderr = process.communicate(timeout=5)
        (prefix.with_suffix(".stdout")).write_bytes(stdout)
        (prefix.with_suffix(".stderr")).write_bytes(stderr)
        row = dict(node=name, sequence=sequence, argv=command, cwd=str(args.work), pid=process.pid,
                   exit=process.returncode, timed_out=timeout, elapsed_seconds=time.monotonic()-start,
                   stdout=ident(prefix.with_suffix(".stdout")), stderr=ident(prefix.with_suffix(".stderr")),
                   input=ident(file))
        captured.append(row)
        prefix.with_suffix(".receipt.json").write_text(json.dumps(row, indent=2, sort_keys=True) + "\n")
        assert not timeout and process.returncode == 0 and not stderr
        assert json.loads(stdout) == ident(file)
        return stdout

    spec = importlib.util.spec_from_file_location("dg17_m02_exact_completion", args.source / "scripts/work-graph-completion.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    compiler_sha = pre["sources"][args.variant]["skills/implementaudit/scripts/compile-work-graph.py"]["sha256"]
    journal = args.work / "journal"

    def returned(frontier, name, output):
        return dict(schema="implementaudit.work-result.v1", node=name, dispatch_id=frontier["dispatch_id"],
                    graph_digest=frontier["graph_digest"], input_digest=frontier["inputs"][name],
                    status="PASS", terminal=True, exit_code=0, evidence_digest=digest(output),
                    independence_key="actual-process-" + name, scope=[name])

    with module.CompletionContract(run, journal, compiler_sha256=compiler_sha) as consumer:
        accepted = {}
        for number, name in enumerate(pre["initial_order"], 1):
            frontier = consumer.frontier()
            assert frontier["selected"] == [name]
            output = execute(name, "initial")
            event = consumer.accept(frontier, [returned(frontier, name, output)], "FINAL_REDUCER",
                                    expected_old=consumer.history_digest)
            accepted[name] = event
            snapshots["after_" + name] = consumer.frontier()
        consumer.join("FINAL_REDUCER", expected_old=consumer.history_digest)
        before = consumer.transition()
        snapshots["before_dependency_change"] = before
        assert all(before["states"][name] == "DONE" for name in pre["initial_order"])
        preserved_outputs = {name: snapshot_file(args.work / "captures" / ("initial-" + name + ".stdout"))
                             for name in pre["preserved"]}
        preserved_records = {r["node"]: r["digest"] for e in before["completion_events"]
                             for r in e["records"] if r["node"] in pre["preserved"]}
        before_journal = (journal / "history.json").read_bytes()
        target = run / pre["task_input_paths"][pre["affected"]]
        target.write_bytes((frozen / "completed-checkpoint.json").read_bytes())
        changed_graph = inventory(run)
        notes["changed_input_paths"] = [p for p in original_graph if original_graph[p] != changed_graph[p]]
        assert notes["changed_input_paths"] == [pre["task_input_paths"][pre["affected"]]]
        changed = consumer.frontier()
        snapshots["after_dependency_change"] = changed
        notes["journal_unchanged_by_reobservation"] = (journal / "history.json").read_bytes() == before_journal
        notes["preserved_outputs_before"] = preserved_outputs
        notes["preserved_completion_digests_before"] = preserved_records
        save()
        assert changed["states"][pre["affected"]] == "READY", "affected completed result survived changed dependency"
        assert changed["selected"] == [pre["affected"]], "recompute frontier includes unaffected work"
        assert set(changed["invalidated"]) == {pre["affected"], "FINAL_REDUCER"}
        assert all(changed["states"][name] == "DONE" for name in pre["preserved"])
        assert changed["states"]["FINAL_REDUCER"] == "BLOCKED"
        assert notes["journal_unchanged_by_reobservation"]
        output = execute(pre["affected"], "recomputed")
        consumer.accept(changed, [returned(changed, pre["affected"], output)], "FINAL_REDUCER",
                        expected_old=consumer.history_digest)
        consumer.join("FINAL_REDUCER", expected_old=consumer.history_digest)
        after = consumer.transition()
        snapshots["after_selective_recompute"] = after
        after_records = {r["node"]: r["digest"] for e in after["completion_events"]
                         for r in e["records"] if r["node"] in pre["preserved"]}
        assert after_records == preserved_records
        notes["preserved_outputs_after"] = {name: snapshot_file(args.work / "captures" / ("initial-" + name + ".stdout")) for name in pre["preserved"]}
        assert notes["preserved_outputs_after"] == preserved_outputs
        assert [row["node"] for row in captured] == pre["initial_order"] + [pre["affected"]]
        assert all(after["states"][name] == "DONE" for name in pre["initial_order"])
        assert after["authority"] == "NONE" and after["native_dispatch_authorized"] is False
        notes["selective_recompute_completed"] = True
        notes["journal_final"] = ident(journal / "history.json")
    assert inventory(args.source) == pre["sources"][args.variant]
    assert inventory(frozen) == pre["inputs"]
    notes["source_and_frozen_inputs_unchanged"] = True
    save()
    print(json.dumps({"oracle": "PASS", "variant": args.variant, "actual_producers": len(captured), "authority": "NONE"}))


if __name__ == "__main__":
    main()
