import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
PRE = json.loads((ROOT / "PREIMAGE.json").read_text())


def ident(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def invoke(variant):
    args = [sys.executable, "-I", "-B", str(ROOT / "frozen_oracle.py"),
            "--variant", variant, "--source", str(ROOT / variant / "source"),
            "--work", str(ROOT / variant / "work")]
    start = time.monotonic()
    at = datetime.datetime.now(datetime.timezone.utc).isoformat()
    p = subprocess.run(args, capture_output=True, timeout=70)
    (ROOT / variant / "oracle.stdout").write_bytes(p.stdout)
    (ROOT / variant / "oracle.stderr").write_bytes(p.stderr)
    receipt = dict(argv=args, exit=p.returncode, started_at=at, elapsed_seconds=time.monotonic()-start,
                   stdout=ident(ROOT / variant / "oracle.stdout"), stderr=ident(ROOT / variant / "oracle.stderr"))
    (ROOT / variant / "oracle.receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True)+"\n")
    return receipt


assert ident(Path(__file__)) == PRE["driver"]
baseline = invoke("baseline")
assert baseline["exit"] == 0, "baseline failed; no mutant created or executed"
shutil.copytree(ROOT / "baseline/source", ROOT / "mutant/source")
owner = ROOT / "mutant/source" / PRE["mutation"]["path"]
old, new = (PRE["mutation"][key].encode() for key in ("old", "new"))
data = owner.read_bytes()
assert data.count(old) == 1
owner.write_bytes(data.replace(old, new))
mutant = invoke("mutant")
observed = json.loads((ROOT / "mutant/work/observations.json").read_text())
state = observed["snapshots"]["after_dependency_change"]
caught = (mutant["exit"] == 1 and state["states"][PRE["affected"]] == "DONE" and
          b"AssertionError: affected completed result survived changed dependency" in (ROOT / "mutant/oracle.stderr").read_bytes())
result = dict(schema="dg17.M02.source-copy-mutation-result.v1", baseline=baseline, mutant=mutant,
              original_mutation_family="L2 selective invalidation/recompute",
              actual_mutant_stale_result_retained=state["states"][PRE["affected"]],
              actual_mutant_selected=state["selected"], mutation_caught_at_original_predicate=caught,
              mutation=PRE["mutation"], original_expectations_unchanged=True,
              canonical_source_changed=False, fixture_repairs=[], author_award=False,
              authority="NONE", native_lifecycle=False, model_calls=0,
              formal_L3_phase_claim=False)
(ROOT / "RESULT.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
print(json.dumps(result,sort_keys=True))
assert caught, "retain outcome and diagnose before any fixture or oracle change"
