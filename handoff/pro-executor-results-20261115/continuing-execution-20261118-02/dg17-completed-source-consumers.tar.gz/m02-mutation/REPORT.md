# M02 selective invalidation and recomputation

The exact a297 CompletionContract completed three real read-only producer processes, received their declared outputs and reduced their common JOIN. A subsequent change to one actual input invalidated only INPUT_VARIANT and FINAL_REDUCER. SOURCE_RULES and ROOT_DECISION kept their exact accepted completion digests, output bytes, inode and mtime. The actual selected frontier contained only INPUT_VARIANT; only that producer ran again before the canonical JOIN was recomputed.

The supplied data is independently retained evidence: original #211 body, the actual Root N11/B05/H04 decision, and the omitted/completed snapshots from the earlier real canonical JOIN episode. These are data inputs to an explicitly constructed graph. They are not fabricated current controller state, model returns or formal L3 phase results.

The source-copy mutation removes only `name not in delta['invalidated']` from CompletionContract._applicable. All existence, predecessor, journal, source-custody and other guards remain. The mutant actually retained the changed-input result as DONE and selected no work. The frozen oracle failed specifically with `affected completed result survived changed dependency`. This is a behavioral stale-result witness, not a diagnostic-text-only failure.

| Variant | Actual producer processes | After changed input | Oracle |
|---|---:|---|---|
| Exact a297 | 4: three initial, affected one again | affected READY; two unaffected DONE; JOIN BLOCKED; selected affected only | pass |
| One-guard source copy | 3 initial; assertion blocks recompute | affected incorrectly DONE; selected empty | fails at original selective predicate |

PREIMAGE.json was frozen before baseline execution and before the mutant copy was created. Original expectations and all frozen inputs remained unchanged; no fixture repair occurred. The baseline and mutant copies each retain the exact other two source files. Full graph snapshots, accepted-event identities, producer stdout/stderr/receipts and journals survive under baseline/work and mutant/work. READBACK.json reverified source variants and expected observations.

This is an actual structural source-consumer limb of the original L2 selective invalidation/recompute mutation. It also adds concrete selective-frontier evidence adjacent to P02/B04/H05. It does not relabel tasks as completed formal L3 phases, assert native dispatch, model judgment or award any case/family. Root retains independent receiving and qualification. A newly generated incidental Python bytecode cache from importing the old pure fixture constructor was removed by exact path/hash; TRANSIENT_CACHE_CLEANUP.json preserves that housekeeping record, and the original helper/evidence bytes were unchanged.
