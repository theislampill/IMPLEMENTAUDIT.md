#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import base64,hashlib,io,json,re,tarfile,zipfile,zlib
P=Path('/workspace/scratch/530bc07ea12b/results20-original-outcomes/publish-stage')
O=Path('/workspace/scratch/530bc07ea12b/results20-independent-publication-review')
rows=[];encoded=[];seen=set();containers=0
def leaf(b,where):
 try:t=b.decode()
 except UnicodeDecodeError:
  kind='PUBLIC_CONSTRUCTED_GIT_TREE' if where.endswith('#git-tree') else 'TEST_ONLY_BINARY_STREAM' if '/TEST_ONLY_RECORDER_PROBES' in where and where.endswith(('/stdin.bin','/stdout.bin','/stderr.bin')) else 'UNCLASSIFIED_BINARY'
  rows.append({'location':where,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'classification':kind,'bytes_echoed':False});return
 h=hashlib.sha256(b).hexdigest()
 if h in seen:return
 seen.add(h)
 if not t.lstrip().startswith(('{','[')):return
 try:o=json.loads(t)
 except ValueError:return
 def walk(v,ptr):
  if isinstance(v,str) and len(v)>80:leaf(v.encode(),where+'#json'+ptr)
  elif isinstance(v,list):
   for i,x in enumerate(v):walk(x,ptr+'/'+str(i))
  elif isinstance(v,dict):
   if v.get('encoding')=='base64' and isinstance(v.get('content'),str):
    try:d=base64.b64decode(v['content'],validate=True)
    except ValueError:pass
    else:
     encoded.append({'location':where+'#json'+ptr,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest(),'zip_body':d.startswith(b'PK\x03\x04')})
     if d.startswith(b'PK\x03\x04'):container(d,where+'#decoded-base64')
     else:leaf(d,where+'#decoded-base64')
   for k,x in v.items():walk(x,ptr+'/'+k)
 walk(o,'')
def container(b,label,tar=False):
 global containers
 containers+=1
 if tar:
  with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as a:members=[(x.name,a.extractfile(x).read()) for x in a.getmembers() if x.isfile()]
 else:
  with zipfile.ZipFile(io.BytesIO(b)) as a:members=[(x.filename,a.read(x)) for x in a.infolist() if not x.is_dir()]
 for name,data in members:
  where=label+'!'+name
  if name.endswith('.zip') and data.startswith(b'PK\x03\x04'):container(data,where)
  elif re.search(r'(?:^|/)\.git/objects/[0-9a-f]{2}/[0-9a-f]{38}$',name):
   raw=zlib.decompress(data);head,body=raw.split(b'\0',1);kind=head.decode().split()[0];leaf(body,where+'#git-'+kind)
  else:leaf(data,where)
m=json.loads((P/'MANIFEST.json').read_text())
for a in m['binary_archive_assemblies']:
 p=P/a['manifest'];pm=json.loads(p.read_text());b=b''.join((p.parent/x['path']).read_bytes() for x in pm['ordered_parts']);container(b,str(PurePosixPath(a['manifest']).parent/a['original_name']))
container((P/'dg18-a6/dg18-a6-accepted-evidence.tar.gz').read_bytes(),'dg18-a6/dg18-a6-accepted-evidence.tar.gz',True)
unclassified=[x for x in rows if x['classification']=='UNCLASSIFIED_BINARY']
raw_hashes={'d32b40eb901670e6dd19b23825ed8cbdd86a54ae094e55c5ceb16f78764983ff','add6132695dfd7d5c327a387dad57759a3fe66332f26624cc03047da74764d96','e7f1c33c5d25dbee54cae22e9b9728a84a758a133fab9f52f5d1404cc9c00e9f'}
assert not any(x['sha256'] in raw_hashes for x in encoded), 'encoded duplicate raw original'
r={'schema':'independent.publication.nontext-privacy-receiving.v1','authority':'NONE','status':'PASS' if not unclassified else 'REQUIRES_BINARY_CLASSIFICATION','archive_containers_received':containers,'non_utf8_leaves':rows,'explicit_base64_contents':encoded,'unclassified_binary_leaves':len(unclassified),'encoded_original_zip_duplicates':0,'private_input_bodies_opened':False,'active_ledger_opened':False,'original_code_executed':False}
(O/'NON_TEXT_PRIVACY_RECEIVING.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':r['status'],'containers':containers,'non_utf8_leaves':len(rows),'git_trees':sum(x['classification']=='PUBLIC_CONSTRUCTED_GIT_TREE' for x in rows),'TEST_ONLY_binary_streams':sum(x['classification']=='TEST_ONLY_BINARY_STREAM' for x in rows),'unclassified':unclassified,'base64_contents':len(encoded),'encoded_original_zip_duplicates':0}))

