#!/usr/bin/env python3
from pathlib import Path
import hashlib,json
P=Path('/workspace/scratch/530bc07ea12b/results20-independent-publication-review')
def read(n):return json.loads((P/n).read_text())
def descriptor(n):
 b=(P/n).read_bytes();return {'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
b=read('BYTE_RECEIVING.json');a=read('ARCHIVE_RECEIVING.json');s=read('PRIVACY_CANDIDATES.json');c=read('INTERNAL_SEAL_CROSS_JOIN.json');n=read('NON_TEXT_CLASSIFICATION.json')
assert b['status']=='PASS_BYTE_TREE_AND_ARCHIVE_RECEIVING_PENDING_PRIVACY_AND_FINAL_CLAIM_ADJUDICATION'
assert s['candidates']==[] and n['privacy_blockers']==[] and c['status']=='PASS_NO_MISSING_EVIDENCE_BYTES'
assert len(a['assemblies'])==8 and len(a['containers'])==24 and len(a['internal_seals'])==29
assert b['tree']['expected_tree']=='513e0992dfc7334e044c5dba4c5a6238c429e754'
findings=[
 {'id':'R20-I01','severity':'INFORMATIONAL','blocking':False,'subject':'Historical A3 source-review input subset',
 'finding':'One historical received-source manifest has 13 members under its local received prefix. Its remaining 15 exact payloads are present under author-source in the same evidence archive; both full source manifest bodies are identical.',
 'resolution':'All 28 original payloads are received through INTERNAL_SEAL_CROSS_JOIN.json. No packet bytes, historical seal or publication file was changed.'},
 {'id':'R20-I02','severity':'EVIDENCE_SCOPE','blocking':False,'subject':'Original acceptance limits',
 'finding':'The four Root decisions remain exact at product51416. A8 primary branches remain first migration; its adverse controls retain full-source/current-CI scope. A6 current-CI artifact limits and A13 owner-guard/raw-transaction precision remain preserved.',
 'resolution':'No acceptance expansion is introduced by publication. A3 R1 failure and G132 readiness remain no-award scopes.'},
 {'id':'R20-I03','severity':'PROVENANCE_LIMIT','blocking':False,'subject':'Parent tree and live publication',
 'finding':'Pure data reconstruction proves the supplied exact parent census and additive expected tree. This reviewer did not perform a fresh remote ref/PR/currentness query or any provider action.',
 'resolution':'Root retains the live currentness, exact expected-head/nonforced publication and remote readback obligation. This content review issues no effect permission.'},
 {'id':'R20-I04','severity':'PRESERVED_REVIEWER_ERROR','blocking':False,'subject':'Read-only diagnostic path assumption',
 'finding':'After successfully writing the exact cross-packet join, inspector0f7354/1 attempted nonexistent root EPISODE.json in the A3 artifact. The original record is under stage-records/original-a3-full-conjunction.json.',
 'resolution':'The failed actual return is retained. Corrected actuald74094/0 follows the existing artifact paths and verifies the failed episode. No original/source/evidence mutation or replay occurred.'}]
result={
 'schema':'implementaudit.independent-results-publication-review.v1','disposition':'PASS_FROZEN_PUBLICATION_CONTENT_AND_ADDITIVE_TREE',
 'authority':'NONE','reviewer':'/root/dg17_p03_review','publication_author':'/root',
 'authoring_context_reuse':'no','prior_reviewer_context':'Continuing reviewer previously authored separate A8/A13 receiving, not this Root publication package. Those reviews are unchanged; this is not a new independent award review of their original predicates.',
 'requested_model':'inherited','actual_model_self_report':'GPT-6 Astra Pro (developer-exposed self-report)','provider_version_or_configuration_attested':False,
 'reviewed_directory':'/workspace/scratch/530bc07ea12b/results20-original-outcomes/publish-stage',
 'reviewed_manifest':{'bytes':20138,'sha256':'f3d6882f1c909e0b86ac7d0fa51829f9e941ad19eba81182bcb97079bb94ba5b'},
 'frozen_publication_files':65,'frozen_publication_bytes':6355949,'tree':b['tree'],
 'binary_assemblies':8,'top_level_containers':9,'nested_containers':15,'total_containers':24,
 'archive_member_observations':6503,'archive_uncompressed_bytes':25801188,'loose_git_objects_checked':299,
 'evidence_archive_members':559,'evidence_archive_member_bytes':7646541,'internal_seals_received':29,
 'internal_seals_complete_locally':28,'internal_seals_complete_with_exact_same_archive_cross_join':1,
 'raw_original_artifacts':b['raw_originals'],'raw_originals_preserved_once_each':True,'A8_exact_sibling_A9_raw_reference':True,
 'accepted_original_additions':['DG18_A6','DG18_A8','DG18_A9','DG18_A13'],
 'new_awards_by_this_review':[],'G132':'READY_FOR_OWNER_CONSIDERATION_ONLY; fresh grant/protected launch/live admissions UNISSUED; original awards []',
 'A3_R1':'FAILED_INCOMPLETE_NO_A3_AWARD; original failure and superseded v1 source readiness preserved',
 'original_denominators':{'DG16_milestones':6,'DG16_dispositions':48,'DG17_cases':36,'DG17_mutation_families':14,'DG17_terminal_clauses':17,'DG18_criteria':14,'whole_cells_accepted':0},
 'privacy':{'credential_or_signed_URL_candidates':0,'unique_UTF8_objects':8017,'unique_UTF8_bytes':22581764,'nontext_leaves':31,'constructed_Git_trees':14,'exact_public_TEST_ONLY_literal_bodies':17,'explicit_base64_contents':3,'encoded_original_zip_duplicates':0,'private_original_input_body_files_opened':False,'private_original_body_member_population_included':False,'active_ledger_or_rendezvous_opened':False,'GENESIS_copy':'Exact historical SOURCE_CUSTODY_ONLY_NO_PROTECTED_GRANT, never active custody'},
 'actuals':{'byte_tree_archive_privacy_receiving':'8f7c5b/0','cross_join_written_then_inspector_error':'0f7354/1','corrected_inspection_and_cross_join_confirmation':'d74094/0','nontext_candidates':'ef8aad/0','all_nontext_literal_classification':'4ecbfc/0'},
 'original_runtime_imports':0,'original_runtime_executions':0,'provider_calls':0,'controller_calls':0,'Git_calls':0,'Git_object_or_ref_writes':0,'original_downloads_or_extractions':0,'input_or_publication_mutations':0,
 'blocking_findings':[],'findings':findings,
 'evidence':{f:descriptor(f) for f in ['BYTE_RECEIVING.json','ARCHIVE_RECEIVING.json','PRIVACY_CANDIDATES.json','NON_TEXT_PRIVACY_RECEIVING.json','NON_TEXT_CLASSIFICATION.json','INTERNAL_SEAL_CROSS_JOIN.json','A3_FAILURE_CLAIM_RECEIVING.json','INPUT_BINDINGS.json']},
 'publication_boundary':'Review applies only to these exact65 files and manifest. Root alone owns publication. Preserve this later review through a separate additive successor if desired; do not silently alter the reviewed65-file commit.',
 'preserved_limits':['All old3717leaf identities','checkpoint12:104staged/101unavailable at historical cutoff','historical301 UNKNOWN_NO_REPLAY','N1 LOST_UNKNOWN_PENDING','P03 F3 model/version/configuration gap','N06 later actual premises and qualified actors','native Stop/session','authentic OR/C02','all prior failures/unknowns/survivors/awards','no release/merge/issue closure or contract amendment']}
(P/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
(P/'FINDINGS.json').write_text(json.dumps({'authority':'NONE','disposition':result['disposition'],'blocking_findings':[],'findings':findings},indent=2,sort_keys=True)+'\n')
report="""# Results20 — independent publication review

## Disposition

**PASS for the exact frozen publication content and additive tree. No blocking finding remains.** This review applies to the commissioned 65-file Results20 package with manifest SHA-256 f3d6882f1c909e0b86ac7d0fa51829f9e941ad19eba81182bcb97079bb94ba5b. Root remains the sole publisher and award owner. This report supplies findings only, with authority **NONE**; it performs and authorizes no provider or protected effect.

The package accurately carries Root's accepted original **DG18 A6, A8, A9 and A13** outcomes at product 51416b2f156b341c4a5f09029e2c6ceb5b30b1e7. It preserves **G132 readiness without an issued owner grant or original award**, and **the failed first A3 operation without an A3 award**. It introduces no new DG17 case, mutation-family or terminal-clause award.

Publication author: /root. Independent publication reviewer: /root/dg17_p03_review. Authoring context reuse: no. This continuing reviewer previously authored separate A8/A13 receiving; those exact packets are carried unchanged. This is a nonauthor review of Root's publication composition, not a new independent adjudication of my earlier original-case recommendations.

Requested model is inherited. Actual exposed self-report is GPT-6 Astra Pro. No provider version/configuration authentication or qualification amendment is claimed.

## Exact frozen subject and pure tree proof

| Binding | Independently received value |
|---|---|
| Frozen stage | /workspace/scratch/530bc07ea12b/results20-original-outcomes/publish-stage |
| Manifest bytes / SHA-256 | 20,138 / f3d6882f1c909e0b86ac7d0fa51829f9e941ad19eba81182bcb97079bb94ba5b |
| Entire proposed publication | 65 files / 6,355,949 bytes |
| Manifest-listed payloads | 64 files / 6,335,811 bytes |
| Expected parent | b488a78588a56604aeb3a6046cc025202ff9240b |
| Exact parent tree | 06d4062a9d345b4a33e0711e7651ba608d9108c6 |
| Computed complete successor tree | 513e0992dfc7334e044c5dba4c5a6238c429e754 |
| Prior leaves preserved | 3,717 |
| New leaves / complete leaf population | 65 / 3,782 |
| Publication prefix | handoff/pro-executor-results-20261115/continuing-execution-20261120-20 |

Every staged file was read completely and checked for exact byte length, SHA-256 and Git blob identity. The actual stage population matches the manifest plus the manifest itself, with no omitted or additional file. Every proposed leaf has mode 100644 and a new path under the one publication prefix.

The supplied [PARENT_LEAF_CENSUS.json](sandbox:/workspace/scratch/530bc07ea12b/results20-original-outcomes/receipts/PARENT_LEAF_CENSUS.json), 731,901 bytes, SHA-256 de964031e2862712a8c8535855ca4a686d3809c788c750051a49dc27ecbf0c2f, reconstructs the exact parent tree through ordinary Git tree serialization and hashing in memory. Adding the 65 exact new leaves independently produces the expected successor tree. No prior path, mode or blob identity changes. No Git program, object store or ref was accessed or modified for this proof.

This is a pure content/tree proof from the exact previously received parent census. It does not claim a new live remote-ref observation. Root retains the currentness, exact expected-head, nonforced publication and remote-readback checks at the action boundary. The retained PR255 open/draft/unmerged statements are assessed against the frozen Root receiving cutoff; this reviewer made no fresh provider query.

[BYTE_RECEIVING.json](sandbox:/workspace/scratch/530bc07ea12b/results20-independent-publication-review/BYTE_RECEIVING.json) records the full byte/tree result. [INPUT_BINDINGS.json](sandbox:/workspace/scratch/530bc07ea12b/results20-independent-publication-review/INPUT_BINDINGS.json) binds all 75 directly read source files, including the exact frozen stage, parent/proof receipts and original stage archive bytes.

## Binary assemblies and complete archive integrity

All **eight** ordered binary assemblies were independently concatenated in memory. Every part name, offset, byte length, SHA-256 and Git blob identity matches its assembly manifest. Every completed assembly matches its whole-original identity and the existing unsplit stage archive byte-for-byte. No archive was regenerated. The small A6 gzip/tar archive remains a single exact publication file.

All archive names are safe relative paths, with unique regular file members; ZIP CRCs and complete member bytes were checked. No extraction or original download was performed. The complete container population is **nine top-level archives plus fifteen nested archives**, totaling **24 containers**, **6,503 member observations** and **25,801,188 decompressed bytes**. All **299** encountered loose Git objects have correct decompressed headers, lengths and OIDs.

| Evidence archive | Indexed members | Full member bytes |
|---|---:|---:|
| G132 ready request | 135 | 1,070,855 |
| A6 accepted evidence | 17 | 376,171 |
| A8 complete conjunction | 47 | 1,672,045 |
| A9 original episode evidence | 92 | 1,367,325 |
| A13 original episode evidence | 117 | 1,686,380 |
| A3 first-failure evidence | 151 | 1,473,765 |
| **Total** | **559** | **7,646,541** |

Each complete archive-member population equals its published ARCHIVE_INDEX. Every indexed body matches its full descriptor. The archive index and visible independent report/Root decision copies are joined to the exact archived bodies.

| Original provider ZIP | Bytes | SHA-256 | Files |
|---|---:|---|---:|
| A9 | 1,614,730 | d32b40eb901670e6dd19b23825ed8cbdd86a54ae094e55c5ceb16f78764983ff | 713 |
| A13 | 1,926,743 | add6132695dfd7d5c327a387dad57759a3fe66332f26624cc03047da74764d96 | 4,079 |
| A3 first failure | 418,689 | e7f1c33c5d25dbee54cae22e9b9728a84a758a133fab9f52f5d1404cc9c00e9f | 99 |

The three original final manifests cover all remaining original payloads, with all full sizes, hashes and blob identities verified. Each complete original ZIP identity occurs **once** in the publication's assembled/container population. The separately examined explicit base64 fields contain no encoded duplicate. A8's external-original reference resolves to the exact sibling A9 assembly; it does not duplicate that ZIP.

[ARCHIVE_RECEIVING.json](sandbox:/workspace/scratch/530bc07ea12b/results20-independent-publication-review/ARCHIVE_RECEIVING.json) retains every assembly descriptor, complete per-container census digest, nested locator and seal result.

## Packet completeness and historical received subset

Twenty-nine internal manifests/seals were received. Twenty-eight resolve completely under their own archive prefixes. The remaining historical A3 source-review copy contains the original full source manifest but only thirteen local received input copies.

That is not missing publication evidence. The historical received manifest is byte-identical to author-source/MANIFEST.json in the same A3 evidence archive. Each of its remaining fifteen payloads exists under author-source with the exact declared byte length, SHA-256 and Git blob identity. All twenty-eight original source payloads are therefore received. The source review's historical local subset and seal are preserved; they are not rewritten to pretend it originally held more copies.

[INTERNAL_SEAL_CROSS_JOIN.json](sandbox:/workspace/scratch/530bc07ea12b/results20-independent-publication-review/INTERNAL_SEAL_CROSS_JOIN.json), SHA-256 8279a52f7cbf053197c9b7fe5ce092d89b50e530248d9e012303fa8c37722328, identifies all fifteen exact same-archive joins. This is a publication composition finding, not a repair to the source, evidence or frozen 65-file stage.

The full original G132 169-member model and previously published historical original archives are explicitly externally bound rather than fabricated or duplicated here. The package preserves that limitation. It does not claim to reconstruct the old lost model/source population.

## Claim accuracy and acceptance boundaries

| Published scope | Received finding |
|---|---|
| **A6 accepted** | Exact Root decision 3e49e3d46c843ba6e2f270576ca9862138374eddafd13970e91499556fdd2a54 and genuine independent report are preserved. The historical archive, current-source/current-consumer conjunction and current-CI artifact limitations remain explicit. |
| **A8 accepted** | Exact Root decision 6eff254cb600faf00f222c29a02b0c4c9404b2bbc58360ab3a4da24563b36b09 joins the unchanged complete independent review. All eight primary branches remain first migration; the three adverse controls retain their full-source/current-CI evidence layer and absence of separately received raw per-case archives. |
| **A9 accepted** | Exact Root decision 84144408af52353feaacc7db17279a0b95a35c81340588d6242cd177dc9637ba and genuine prior receiving remain intact. Eleven original controls, actual crash exits, initialization notes, complete retained evidence and bounded cleanup are not reduced to capture success alone. |
| **A13 accepted** | Exact Root decision 3e9c711e982c8214430b92f0fbeb8bbb5a4b7018faa01f8d30d95e60871f7bb6 preserves the eighty-row matrix, ancestor guard, accepted complete A6 dependency and current-consumer join. Owner-guard refusal is not relabeled as an unobserved raw Git publication transaction. |
| **G132 ready request** | Final exact request, complete independent final review, same-child/source preload and Root receiving agree. Fresh owner grant, protected launch and late live admissions remain UNISSUED. Original awards remain empty; source controls and preload are not original acceptance. |
| **A3 R1 failure** | Raw original RESULT reports FAILED_OR_INCOMPLETE_PRESERVED_NO_RETRY and unittest error. The actual KeyError for the nonexistent pointer archive_ref member remains in stderr. The stage record has only two setup checks, empty archives/semantic-command lists, method_completed false and one retained final snapshot. The three A3 discriminator limbs did not run. No A3 award is claimed. |

The A3 actual G0002 setup, original rotation and resolution are accurately described as completed partial behavior. All fifteen outer command returns are zero, but that does not erase the Python unittest error or award A3. Original cleanup completes, the bounded survivor list is empty, and source-before/after remain unchanged. Its earlier v1 source READY is explicitly historical and superseded for further v1 execution; repair and distinct execution remain separate work. [A3_FAILURE_CLAIM_RECEIVING.json](sandbox:/workspace/scratch/530bc07ea12b/results20-independent-publication-review/A3_FAILURE_CLAIM_RECEIVING.json) retains the precise publication-claim check.

The G132 request's preparation-time state remains unchanged, including its then-pending final receiving label. Later exact independent and Root receiving records establish readiness for owner consideration. They do not transform the request into an owner grant. Historical commit 301aeecde08ba6f169bc3cd837eae6f6ad068219 remains UNKNOWN_NO_REPLAY, without a new label or ordinary authority substituting for its safeguarded boundary.

## Complete publication privacy review

The scan received the complete staged and recursively assembled population, including JSON-decoded textual return bodies, explicit base64 contents, nested fixture archives and decompressed loose Git object bodies. It examined **8,017 distinct UTF-8 bodies / 22,581,764 bytes**. It found **zero credential-pattern or signed/credential-URL candidates**. No matched sensitive value is retained or reproduced by this review.

The non-text pass separately accounts for every binary leaf. Of **31** non-UTF-8 leaves, **14** are the constructed fixture Git tree objects. The remaining **17** exactly match byte literals in the preserved public TEST_ONLY recorder-control sources, including partial timeout streams and partial-finalization fixtures. Those source files were parsed as data; none was imported or executed. There is no unclassified binary leaf. Three explicit base64 contents were examined, with no encoded original-ZIP duplicate.

[PRIVACY_CANDIDATES.json](sandbox:/workspace/scratch/530bc07ea12b/results20-independent-publication-review/PRIVACY_CANDIDATES.json) records the complete text scan result. [NON_TEXT_CLASSIFICATION.json](sandbox:/workspace/scratch/530bc07ea12b/results20-independent-publication-review/NON_TEXT_CLASSIFICATION.json) binds each binary stream to the exact public source literal and its source-file hash. The initial eleven unclassified path candidates are retained in NON_TEXT_PRIVACY_RECEIVING.json; the final exact joins resolve them without changing any input.

The G132 archive's closed member population consists of selected public source, source-control records, inert preload returns, public custody metadata, independent reviews, final request/adoption and model metadata. It contains no private original-input body member population. Its eleven roles / 647,342-byte private-input selection appears only through metadata/descriptors and the exact index identity; private bodies are not added to the request. This reviewer did not open any original private-input body file.

The one 1,026-byte GENESIS_LEDGER_ARCHIVE_ONLY.jsonl is an exact **historical public source-custody record**, SHA-256 d4ef31c8c5013fdd2f3811fcea74b5d980b198e3ebc12d3cbc32cdc172592aa0. Its sole row is GENESIS with SOURCE_CUSTODY_ONLY_NO_PROTECTED_GRANT and no predecessor. The package and Root receiving explicitly prohibit treating it as active custody or recreating/resetting the active ledger. No active ledger, rendezvous, lock or live operation directory was opened by this reviewer.

## Original denominators and historical preservation

The new acceptance delta retains DG16 M1–M6 and **48 dispositions**; DG17 **36 cases, 14 mutation families and 17 terminal clauses**; and DG18 **fourteen criteria and binding amendments**. Whole cells accepted remain **0/3**. There is no release, merge, issue closure or acceptance-contract amendment.

All earlier leaf identities remain exact. The new summary also explicitly preserves prior awards, failed and survived controls, unknown effects and historical losses. Checkpoint12 remains **104 staged files / 101 unavailable at its historical recovery cutoff**. N1 remains LOST_UNKNOWN_PENDING. P03's exact model/version/configuration qualification gap, N06's remaining actual premises and qualified actors, genuine native Stop/session requirements, and authentic OR/C02 prerequisites remain open.

No original A1/A2/A3/A4/A12 or other criterion is credited from these four decisions. No source-only G132 readiness or public GENESIS record acquires original/native/actor authority through publication.

## Actual review records and preserved error

The main independent byte/tree/archive/text-privacy receiving completed under **8f7c5b/0**. It reports **147,801 local data assertions**, not original tests or new original episodes. The complete actual args and return are retained in ACTUAL_BYTE_RECEIVING_TOOL_RETURN.json.

A subsequent read-only inspector wrote the successful exact A3 cross-packet join, then returned **0f7354/1** because it attempted a nonexistent root EPISODE.json. The original stage record is under stage-records/original-a3-full-conjunction.json. The failed actual return is preserved. Corrected inspection **d74094/0** followed the actual retained paths, confirmed the cross-join and checked the failed episode. No source, original evidence or publication payload was changed.

The non-text population pass is **ef8aad/0**; it deliberately retained eleven unclassified candidates for review. The exact public-literal classification completed under **4ecbfc/0**, resolving every candidate. This is data inspection, not a new recorder or original fixture execution.

Original runtime imports/executions, provider calls, controller calls, Git calls, Git object/ref writes, downloads, extractions, active-custody access and input/publication mutations are all **zero**. All writes are confined to this new independent-review directory.

## Root handback

The exact 65-file package is ready for Root's guarded publication procedure, subject to Root's own live expected-parent/currentness checks and exact remote readback. This review grants no new effect permission and requires no original replay or source change.

A later publication-review envelope may preserve this exact sealed review through a separate additive successor. It must not silently change the already reviewed 65-file subject or its expected tree.

[RESULT.json](sandbox:/workspace/scratch/530bc07ea12b/results20-independent-publication-review/RESULT.json) contains the machine-readable disposition and exact scope. [FINDINGS.json](sandbox:/workspace/scratch/530bc07ea12b/results20-independent-publication-review/FINDINGS.json) records zero blocking findings and the preserved cross-packet, evidence-scope, live-publication and reviewer-error limits.
"""
(P/'REPORT.md').write_text(report)
print(json.dumps({'status':result['disposition'],'authority':'NONE','files':[descriptor(n) for n in ['REPORT.md','RESULT.json','FINDINGS.json']]}))

