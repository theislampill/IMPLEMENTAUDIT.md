#!/usr/bin/env python3
"""Read frozen Results20 data only. Never import product code or call Git/providers/controllers."""
from pathlib import Path,PurePosixPath
import base64,collections,hashlib,html,io,json,re,stat,tarfile,traceback,urllib.parse,zipfile,zlib
OUT=Path('/workspace/scratch/530bc07ea12b/results20-independent-publication-review')
BASE=Path('/workspace/scratch/530bc07ea12b/results20-original-outcomes');STAGE=BASE/'publish-stage'
MANIFEST_SHA='f3d6882f1c909e0b86ac7d0fa51829f9e941ad19eba81182bcb97079bb94ba5b'
PARENT='b488a78588a56604aeb3a6046cc025202ff9240b';BASE_TREE='06d4062a9d345b4a33e0711e7651ba608d9108c6';EXPECTED_TREE='513e0992dfc7334e044c5dba4c5a6238c429e754'
PREFIX='handoff/pro-executor-results-20261115/continuing-execution-20261120-20'
checks=0;inputs={};containers=[];seals=[];candidates=[];assemblies=[];unique_texts={};byte_identities=collections.defaultdict(list);stats=collections.Counter();all_packages={};result={'status':'PARTIAL','authority':'NONE'}
def need(x,s):
 global checks
 checks+=1
 if not x:raise AssertionError(s)
def sha(b):return hashlib.sha256(b).hexdigest()
def desc(b):return {'bytes':len(b),'sha256':sha(b),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def unique(items):
 o={}
 for k,v in items:
  need(k not in o,'duplicate JSON key');o[k]=v
 return o
def decode(b):return json.loads(b,object_pairs_hook=unique)
def read(p):
 p=Path(p);need(p.is_file() and not p.is_symlink(),'regular input '+str(p));b=p.read_bytes();inputs[str(p)]=desc(b);return b
def match(b,d,label):
 a=desc(b)
 for k in ['bytes','sha256','git_blob']:
  if k in d:need(a[k]==d[k],label+' '+k)
def safe(n):
 q=PurePosixPath(n);return bool(n) and not q.is_absolute() and '..' not in q.parts and '\\' not in n and '\0' not in n and q.as_posix()==n
def save(n,o):
 p=OUT/n;need(not p.exists(),'fresh output '+n);p.write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
def tree(leaves):
 root={}
 for path,(mode,oid) in leaves.items():
  need(safe(path) and re.fullmatch('[0-9a-f]{40}',oid) and mode in ['100644','100755','120000','160000'],'valid Git leaf')
  node=root;parts=path.split('/')
  for part in parts[:-1]:
   need(not isinstance(node.get(part),tuple),'leaf/directory collision')
   node=node.setdefault(part,{})
  need(parts[-1] not in node,'duplicate leaf');node[parts[-1]]=(mode,oid)
 count=0
 def rec(node):
  nonlocal count
  rows=[]
  for name,v in node.items():
   if isinstance(v,dict):mode='40000';oid=rec(v);sortkey=name.encode()+b'/'
   else:mode,oid=v;sortkey=name.encode()
   rows.append((sortkey,mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(oid)))
  b=b''.join(v for _,v in sorted(rows));count+=1
  return hashlib.sha1(b'tree '+str(len(b)).encode()+b'\0'+b).hexdigest()
 return rec(root),count
credential_patterns=[
 ('github_token',re.compile(r'\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})')),
 ('AWS_access_key',re.compile(r'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b')),
 ('private_key_PEM',re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH |DSA |ENCRYPTED )?PRIVATE KEY-----')),
 ('authorization_credential',re.compile(r'(?i)\bauthorization\s*[:=]\s*["\']?(?:bearer|basic)\s+[A-Za-z0-9_+/.=-]{20,}')),
 ('OpenAI_secret_key',re.compile(r'\bsk-(?:proj-)?[A-Za-z0-9_-]{32,}'))]
url_pattern=re.compile(r'https?://[^\s<>"\'\\]+')
sensitive_query={'sig','signature','x-amz-signature','x-amz-credential','x-goog-signature','x-goog-credential','awsaccesskeyid','jwt','access_token','token'}
def scan_text(b,location,depth=0):
 if depth>8:return
 h=sha(b)
 if h in unique_texts:
  stats['duplicate_text_objects']+=1;return
 try:t=b.decode('utf-8')
 except UnicodeDecodeError:
  stats['non_utf8_objects']+=1;return
 unique_texts[h]=location;stats['unique_utf8_objects']+=1;stats['unique_utf8_bytes']+=len(b)
 for kind,pattern in credential_patterns:
  for m in pattern.finditer(t):
   candidates.append({'kind':kind,'location':location,'line':t.count('\n',0,m.start())+1,'match_sha256':sha(m.group().encode()),'value_retained':False})
 for m in url_pattern.finditer(t):
  try:
   u=urllib.parse.urlsplit(html.unescape(m.group()));keys={k.lower() for k,v in urllib.parse.parse_qsl(u.query,keep_blank_values=True)}
   kinds=sorted(keys&sensitive_query)
   if u.username or u.password:kinds+=['URL_USERINFO']
   if kinds:candidates.append({'kind':'signed_or_credential_URL_candidate','location':location,'line':t.count('\n',0,m.start())+1,'hostname':u.hostname,'query_key_types':kinds,'match_sha256':sha(m.group().encode()),'value_retained':False})
  except ValueError:pass
 if t.lstrip().startswith(('{','[')):
  try:o=json.loads(t)
  except (ValueError,RecursionError):return
  def walk(v,p):
   if isinstance(v,str):
    if len(v)>80:scan_text(v.encode(),location+'#'+p,depth+1)
   elif isinstance(v,list):
    for i,x in enumerate(v):walk(x,p+'/'+str(i))
   elif isinstance(v,dict):
    if v.get('encoding')=='base64' and isinstance(v.get('content'),str):
     try:scan_text(base64.b64decode(v['content'],validate=True),location+'#'+p+'/decoded-base64-content',depth+1)
     except ValueError:pass
    for k,x in v.items():walk(x,p+'/'+k)
  walk(o,'')
def verify_local_seals(files,label):
 for n,b in files.items():
  if PurePosixPath(n).name not in ['MANIFEST.json','SEAL.json','FINAL_MANIFEST.json']:continue
  try:o=decode(b)
  except (ValueError,UnicodeDecodeError):continue
  rows=None
  for field in ['members','files','payloads']:
   v=o.get(field)
   if isinstance(v,list) and all(isinstance(x,dict) for x in v):rows=v;break
   if isinstance(v,dict):rows=[{'path':k,**x} for k,x in v.items() if isinstance(x,dict)];break
  if rows is None:continue
  base=str(PurePosixPath(n).parent);base='' if base=='.' else base+'/'
  checked=[];missing=[];external_rows=[]
  for row in rows:
   path=row.get('path',row.get('member',row.get('relative_path')))
   if not isinstance(path,str):continue
   if not safe(path):external_rows.append(path);continue
   full=base+path
   if full in files:match(files[full],row,'internal seal '+label+'!'+n+'!'+path);checked.append(path)
   else:missing.append(path)
  seals.append({'container':label,'manifest':n,'manifest_sha256':sha(b),'checked_members':len(checked),'missing_local_members':missing,'external_rows':external_rows})
def archive(b,label,depth=0,kind='zip'):
 need(depth<=8,'bounded archive depth');files={};modes={}
 if kind=='zip':
  with zipfile.ZipFile(io.BytesIO(b)) as z:
   need(z.testzip() is None,'complete ZIP CRC '+label)
   for i in z.infolist():
    name=i.filename;mode=(i.external_attr>>16)&65535
    if i.is_dir():
     need(safe(name.rstrip('/')) and not stat.S_ISLNK(mode),'safe ZIP directory');continue
    need(safe(name) and name not in files and not stat.S_ISLNK(mode),'safe unique ZIP member '+label)
    need(not(i.flag_bits&1),'no encrypted publication member')
    files[name]=z.read(i);modes[name]=stat.S_IMODE(mode)
 else:
  with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as z:
   for i in z.getmembers():
    if i.isdir():need(safe(i.name.rstrip('/')),'safe tar directory');continue
    need(i.isfile() and safe(i.name) and i.name not in files,'safe unique regular tar member')
    files[i.name]=z.extractfile(i).read();modes[i.name]=i.mode
 stats['archive_member_observations']+=len(files);stats['archive_uncompressed_bytes']+=sum(map(len,files.values()))
 need(stats['archive_member_observations']<100000 and stats['archive_uncompressed_bytes']<512*1024*1024,'bounded complete archive population')
 inv=[{'path':n,**desc(d)} for n,d in sorted(files.items())]
 containers.append({'container':label,'kind':kind,**desc(b),'member_count':len(files),'member_bytes':sum(map(len,files.values())),'complete_member_census_sha256':sha(canonical(inv)),'safe_regular_members':True,'full_content_received':True})
 verify_local_seals(files,label)
 for n,d in files.items():
  loc=label+'!'+n;byte_identities[sha(d)].append(loc)
  if d.startswith(b'PK\x03\x04') and n.endswith('.zip'):archive(d,loc,depth+1)
  elif n.endswith(('.tar.gz','.tgz')) and d.startswith(b'\x1f\x8b'):archive(d,loc,depth+1,'tar')
  elif re.search(r'(?:^|/)\.git/objects/[0-9a-f]{2}/[0-9a-f]{38}$',n):
   raw=zlib.decompress(d);head,body=raw.split(b'\0',1);typ,size=head.decode().split(' ')
   need(int(size)==len(body),'full loose object length')
   need(hashlib.sha1(raw).hexdigest()==''.join(n.split('/')[-2:]),'full loose object identity')
   stats['loose_objects_received']+=1;scan_text(body,loc+'#inflated-'+typ)
  else:scan_text(d,loc)
 return files
try:
 mb=read(STAGE/'MANIFEST.json');need(len(mb)==20138 and sha(mb)==MANIFEST_SHA,'exact commissioned frozen manifest')
 m=decode(mb);need(m['parent']==PARENT and m['base_tree']==BASE_TREE and m['prefix']==PREFIX,'exact prospective publication binding')
 files={'MANIFEST.json':mb}
 for x in m['files']:
  need(safe(x['path']) and x['path'] not in files and x['mode']=='100644','unique staged payload')
  b=read(STAGE/x['path']);match(b,x,'full staged bytes');files[x['path']]=b
 need(set(files)=={p.relative_to(STAGE).as_posix() for p in STAGE.rglob('*') if p.is_file()},'complete staged population')
 need(len(files)==65 and sum(map(len,files.values()))==6355949,'exact publication census')
 need(m['file_count_excluding_manifest']==64 and m['file_bytes_excluding_manifest']==6335811,'manifest payload denominator')
 for path,b in files.items():
  byte_identities[sha(b)].append('stage/'+path)
  if not re.search(r'\.part[0-9]+$',path):scan_text(b,'stage/'+path)
 proof=decode(read(BASE/'receipts/FROZEN_STAGE_PROOF.json'));parent=decode(read(BASE/'receipts/PARENT_LEAF_CENSUS.json'))
 need(parent['parent']==PARENT and parent['tree']==BASE_TREE and parent['leaf_count']==len(parent['leaves'])==3717,'exact parent census descriptor')
 old={x['path']:(x['mode'],x['sha']) for x in parent['leaves']};need(len(old)==3717,'unique prior leaves')
 computed_old,old_tree_count=tree(old);need(computed_old==BASE_TREE,'pure parent-tree reconstruction')
 new=dict(old)
 for path,b in files.items():
  full=PREFIX+'/'+path;need(full not in new,'additions only');new[full]=('100644',desc(b)['git_blob'])
 computed_new,new_tree_count=tree(new)
 need(computed_new==EXPECTED_TREE==proof['expected_tree'] and len(new)==3782,'pure complete successor tree')
 need(all(new[k]==v for k,v in old.items()),'all 3717 prior leaves untouched')
 result['tree']={'status':'PASS_PURE_DATA_TREE_PROOF','parent':PARENT,'base_tree':computed_old,'expected_tree':computed_new,'prior_leaves':len(old),'new_leaves':len(files),'complete_leaves':len(new),'parent_tree_nodes':old_tree_count,'successor_tree_nodes':new_tree_count,'git_object_or_ref_calls':0}
 assembled={}
 for a in m['binary_archive_assemblies']:
  manifest_path=a['manifest'];pm=decode(files[manifest_path]);folder=PurePosixPath(manifest_path).parent
  need(pm['schema']=='exact-binary-archive-assembly.v1' and pm['original_name']==a['original_name'],'assembly schema/name')
  offset=0;parts=[];part_paths=[]
  for i,part in enumerate(pm['ordered_parts']):
   need(safe(part['path']) and '/' not in part['path'],'local binary part path')
   path=(folder/part['path']).as_posix();need(part['offset']==offset and path not in part_paths,'ordered exact offset')
   need(part['path']==a['original_name']+'.part'+f'{i:03d}','canonical part numbering')
   b=files[path];match(b,part,'full part identity');parts.append(b);part_paths.append(path);offset+=len(b)
  b=b''.join(parts);match(b,pm['original'],'whole concatenated original');match(b,a,'manifest original binding')
  need(len(parts)==a['parts'],'part count');logical=(folder/a['original_name']).as_posix();need(logical not in files and logical not in assembled,'raw original replaced by parts only')
  source=read(BASE/'stage'/logical);need(source==b,'original stage bytes not regenerated')
  assembled[logical]=b;byte_identities[sha(b)].append('assembly/'+logical)
  assemblies.append({'manifest':manifest_path,'logical_path':logical,'parts':part_paths,**desc(b),'source_stage_bytes_identical':True})
 need(len(assembled)==8,'all eight binary assemblies')
 for logical,b in assembled.items():all_packages[logical]=archive(b,logical)
 tarpath='dg18-a6/dg18-a6-accepted-evidence.tar.gz';all_packages[tarpath]=archive(files[tarpath],tarpath,kind='tar')
 index_results=[]
 for directory in ['dg16-g132-ready-request','dg18-a6','dg18-a8','dg18-a9','dg18-a13','dg18-a3-first-failure']:
  idx=decode(files[directory+'/ARCHIVE_INDEX.json'])
  logical=directory+('/dg18-a6-accepted-evidence.tar.gz' if directory=='dg18-a6' else '/EVIDENCE.zip');inside=all_packages[logical]
  declared={}
  for row in idx['members']:
   name=row.get('member',row.get('path'));need(safe(name) and name not in declared,'unique complete index member');declared[name]=row
  need(set(declared)==set(inside),'archive index complete '+directory)
  for n,b in inside.items():match(b,declared[n],'complete archive index payload')
  if 'member_count' in idx:need(idx['member_count']==len(inside),'index member count')
  if 'member_bytes' in idx:need(idx['member_bytes']==sum(map(len,inside.values())),'index byte count')
  if directory=='dg18-a6':match(files[tarpath],{'bytes':idx['archive_bytes'],'sha256':idx['archive_sha256']},'A6 archive descriptor')
  else:match(assembled[logical],idx.get('archive',idx.get('evidence_archive')),'indexed archive descriptor')
  index_results.append({'directory':directory,'archive':logical,'index':desc(files[directory+'/ARCHIVE_INDEX.json']),'members':len(inside),'member_bytes':sum(map(len,inside.values())),'full_population_and_bytes_match':True})
 original={
  'dg18-a9':('d32b40eb901670e6dd19b23825ed8cbdd86a54ae094e55c5ceb16f78764983ff',1614730,713,2509196),
  'dg18-a13':('add6132695dfd7d5c327a387dad57759a3fe66332f26624cc03047da74764d96',1926743,4079,4487642),
  'dg18-a3-first-failure':('e7f1c33c5d25dbee54cae22e9b9728a84a758a133fab9f52f5d1404cc9c00e9f',418689,99,1403460)}
 raw_rows=[]
 for directory,(h,size,count,total) in original.items():
  logical=directory+'/ORIGINAL_ARTIFACT.zip';b=assembled[logical];inside=all_packages[logical]
  need(sha(b)==h and len(b)==size and len(inside)==count and sum(map(len,inside.values()))==total,'exact original raw artifact')
  need(byte_identities[h]==['assembly/'+logical],'one complete raw original identity only')
  fm=decode(inside['FINAL_MANIFEST.json']);need(len(fm['members'])==count-1,'raw final manifest count')
  need({r['path'] for r in fm['members']}==set(inside)-{'FINAL_MANIFEST.json'},'raw full payload census')
  for row in fm['members']:match(inside[row['path']],row,'all raw payload bytes')
  raw_rows.append({'directory':directory,'logical_path':logical,**desc(b),'files':count,'decompressed_bytes':total,'manifest_payloads':count-1,'copies':1,'final_manifest':desc(inside['FINAL_MANIFEST.json'])})
 a8=decode(files['dg18-a8/ARCHIVE_INDEX.json'])['external_original_zip']
 need(a8['copied_into_this_archive'] is False and a8['same_publication_directory']=='../dg18-a9' and a8['sha256']==original['dg18-a9'][0] and a8['assembly_manifest']=='ORIGINAL_ARTIFACT.zip.PARTS.json','A8 references exact sibling A9 raw')
 roots={'DG18_A6':('dg18-a6','3e49e3d46c843ba6e2f270576ca9862138374eddafd13970e91499556fdd2a54'),'DG18_A8':('dg18-a8','6eff254cb600faf00f222c29a02b0c4c9404b2bbc58360ab3a4da24563b36b09'),'DG18_A9':('dg18-a9','84144408af52353feaacc7db17279a0b95a35c81340588d6242cd177dc9637ba'),'DG18_A13':('dg18-a13','3e9c711e982c8214430b92f0fbeb8bbb5a4b7018faa01f8d30d95e60871f7bb6')}
 delta=decode(files['ACCEPTANCE_DELTA.json']);need({x['requirement'] for x in delta['new_complete_original_obligations']}==set(roots),'exact four accepted additions')
 decisions=[]
 for award,(directory,h) in roots.items():
  b=files[directory+'/ROOT_ADJUDICATION.json'];need(sha(b)==h,'exact genuine Root adjudication')
  o=decode(b);need(o['original_denominator']==14 and o.get('product_commit',o.get('source_commit'))=='51416b2f156b341c4a5f09029e2c6ceb5b30b1e7','unchanged original source/denominator')
  logical=directory+('/dg18-a6-accepted-evidence.tar.gz' if directory=='dg18-a6' else '/EVIDENCE.zip')
  need(all_packages[logical]['Root/ROOT_ADJUDICATION.json']==b,'exact archive/visible Root decision')
  row=next(x for x in delta['new_complete_original_obligations'] if x['requirement']==award)
  need(row['decision_sha256']==h and row['decision']==directory+'/ROOT_ADJUDICATION.json','delta bound to genuine decision')
  report_path='INDEPENDENT_RECEIVING_REPORT.md' if directory=='dg18-a6' else 'INDEPENDENT_REPORT.md'
  rb=files[directory+'/'+report_path]
  report_members=[n for n,v in all_packages[logical].items() if n.endswith('/REPORT.md') and v==rb]
  need(bool(report_members),'visible independent report exact archived body')
  decisions.append({'award':award,'root_decision':desc(b),'disposition':o['disposition'],'independent_report':desc(rb),'report_members':report_members})
 need(delta['original_denominators']=={'DG16_dispositions':48,'DG16_milestones':6,'DG17_cases':36,'DG17_mutation_families':14,'DG17_terminal_clauses':17,'DG18_criteria':14,'whole_cells_accepted':0},'all original denominators unchanged')
 need(delta['new_DG17_cases']==delta['new_mutation_families']==delta['new_terminal_clauses']==[] and delta['merge_release_issue_closure'] is False,'no other grant or completion transfer')
 g=all_packages['dg16-g132-ready-request/EVIDENCE.zip']
 request=decode(files['dg16-g132-ready-request/PROTECTED_OPERATION_REQUEST_UNISSUED.json']);root=decode(files['dg16-g132-ready-request/ROOT_RECEIVING.json']);gi=decode(files['dg16-g132-ready-request/ARCHIVE_INDEX.json'])
 need(request['owner_grant']=='UNISSUED' and root['owner_grant']==root['protected_launch']==root['late_live_admissions']=='UNISSUED','G132 remains unissued')
 need(request['original_awards']==root['original_awards']==gi['original_awards']==[] and request['automatic_retry'] is False and request['single_attempt'] is True,'G132 no award/replay')
 need(request['historical_unknown_effect'].startswith('UNKNOWN_NO_REPLAY') and root['historical301']=='UNKNOWN_NO_REPLAY','historical G132 uncertainty preserved')
 need(g['g132-final-protected-request-r2/PROTECTED_OPERATION_REQUEST_UNISSUED.json']==files['dg16-g132-ready-request/PROTECTED_OPERATION_REQUEST_UNISSUED.json'],'exact final owner request')
 need(g['g132-final-protected-request-r2-postseal/ROOT_FINAL_REQUEST_RECEIVING.json']==files['dg16-g132-ready-request/ROOT_RECEIVING.json'],'exact Root final receiving')
 need(g['g132-final-request-independent-review/REPORT.md']==files['dg16-g132-ready-request/INDEPENDENT_REPORT.md'],'exact G132 independent report')
 genesis_name='g132-source-custody-actual/GENESIS_LEDGER_ARCHIVE_ONLY.jsonl';genesis=g[genesis_name];lines=genesis.splitlines();need(len(lines)==1 and len(genesis)==1026,'one historical public genesis row')
 row=decode(lines[0]);need(row['record']['kind']=='GENESIS' and row['record']['authority']=='SOURCE_CUSTODY_ONLY_NO_PROTECTED_GRANT' and row['record']['previous'] is None,'GENESIS historical source custody only')
 need(row['sha256']=='b7c3bbb55ba4c4fceff094f6db2555329c3cf4fd6ed31e0c8e4069cbe8c40dba' and sha(genesis)=='d4ef31c8c5013fdd2f3811fcea74b5d980b198e3ebc12d3cbc32cdc172592aa0','exact historical genesis identity')
 need(gi['genesis_archive_is_historical_only_never_active_custody'] is True and gi['active_custody_not_copied_or_reinitialized'] is True and root['active_custody_reinitialized'] is False,'no active custody transfer')
 need(gi['private_original_input_bodies_included'] is False and request['fresh_inputs']['private_bodies_in_request'] is False and request['fresh_inputs']['roles']==11 and request['fresh_inputs']['bytes']==647342,'private body exclusion boundary')
 private_member_names=[n for n in g if re.search(r'(^|/)(private-inputs|private_original_inputs|private-bodies|input-bodies)(/|$)',n,re.I)]
 need(not private_member_names,'no private input body member population')
 failure=decode(files['dg18-a3-first-failure/ROOT_FAILURE_RECEIVING.json'])
 need(failure['terminal_disposition']=='FAILED_INCOMPLETE_NO_A3_AWARD' and failure['original_awards']==[] and failure['zip_sha256']==original['dg18-a3-first-failure'][0],'A3 first failure no award')
 a3raw=all_packages['dg18-a3-first-failure/ORIGINAL_ARTIFACT.zip'];a3result=decode(a3raw['RESULT.json'])
 need(b"KeyError: 'archive_ref'" in a3raw['SUITE.stderr'],'actual preserved A3 failure')
 result.update(status='PASS_BYTE_TREE_AND_ARCHIVE_RECEIVING_PENDING_PRIVACY_AND_FINAL_CLAIM_ADJUDICATION',publication={'files':65,'bytes':6355949,'manifest':desc(mb),'new_awards':sorted(roots),'raw_zip_duplication':False},archive_indexes=index_results,raw_originals=raw_rows,accepted_decisions=decisions,G132={'state':'READY_OWNER_CONSIDERATION_ONLY','owner_grant':'UNISSUED','protected_launch':'UNISSUED','original_awards':[],'historical301':'UNKNOWN_NO_REPLAY','genesis_member':genesis_name,'genesis':desc(genesis),'active_custody_opened':False,'private_input_bodies_opened':False},A3={'disposition':failure['terminal_disposition'],'run':failure['run'],'attempt':failure['attempt'],'original_awards':[],'actual_suite_error_retained':True})
except Exception as e:
 result.update(status='RECEIVING_ERROR',error={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()})
 raise
finally:
 result['data_assertions_before_output']=checks
 result['no_original_runtime_import_execution_or_provider_controller_git_calls']=True
 save('BYTE_RECEIVING.json',result)
 save('ARCHIVE_RECEIVING.json',{'assemblies':assemblies,'containers':containers,'internal_seals':seals,'statistics':dict(stats)})
 save('PRIVACY_CANDIDATES.json',{'statistics':dict(stats),'candidates':candidates,'candidate_values_retained':False,'raw_private_input_bodies_opened':False})
 save('INPUT_BINDINGS.json',{'files':[{'path':p,**d} for p,d in sorted(inputs.items())]})
print(json.dumps({'status':result['status'],'data_assertions':checks,'containers':len(containers),'archive_member_observations':stats['archive_member_observations'],'internal_seals':len(seals),'seals_with_missing_members':sum(bool(s['missing_local_members']) for s in seals),'privacy_candidates':len(candidates),'tree':result.get('tree')},sort_keys=True))

