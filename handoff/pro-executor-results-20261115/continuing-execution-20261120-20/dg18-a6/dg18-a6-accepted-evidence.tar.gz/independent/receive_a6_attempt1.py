#!/usr/bin/env python3
"""Receive original A6 retained data and actual current controls; execute no product.

TAR/ZIP and Git loose objects are decoded as data in memory. Source files are read
and AST-inspected, never imported. Only the retained local Git object store is
queried, with lazy fetching and all protocols disabled.
"""
import ast
import copy
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile
import zipfile
import zlib

BASE=Path('/workspace/scratch/530bc07ea12b')
OUT=BASE/'dg18-next-complete-criterion-receiving'
PRIOR=BASE/'dg18-next-original-execution'
CURRENT=BASE/'dg16-g2-current-profile-fix/checkout'
REPO=BASE/'implementaudit'
OLD='6b353b48b2fc8a6de0c6223f48d341c484c98191'
NEW='51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
CONTROLLER='dg18-w-full-43785700341-1'
RUN='.IMPLEMENTAUDIT/runs/fresh-windows-w-full-preparation-EjF48t'
PREFIX='refs/implementaudit/state-archives/'+CONTROLLER
POINTER='refs/implementaudit/current-generations/'+CONTROLLER
MARKER='refs/implementaudit/current-generation-migrations/'+CONTROLLER
RECEIPTS='refs/implementaudit/continuity-receipts/'+CONTROLLER
COUNTS={}


def need(ok,label,group='data'):
    if not ok:raise AssertionError(label)
    COUNTS[group]=COUNTS.get(group,0)+1


def sha(raw):return hashlib.sha256(raw).hexdigest()
def blob(raw):return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def ident(raw):return {'bytes':len(raw),'sha256':sha(raw),'git_blob':blob(raw)}
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()


def emit(name,value):
    path=OUT/name
    with path.open('xb') as handle:handle.write((json.dumps(value,indent=2,sort_keys=True)+'\n').encode())
    return {'path':name,**ident(path.read_bytes())}


def git(*args):
    env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
    env.update(GIT_NO_LAZY_FETCH='1',GIT_ALLOW_PROTOCOL='',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null')
    return subprocess.run(['git','-c','protocol.allow=never',*args],cwd=REPO,env=env,
        check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30).stdout


def immutable_tree(commit):
    return {row.split('\t',1)[1]:row.split()[2] for row in git('ls-tree','-r',commit).decode().splitlines()}


def receive_zip_tar(path,expected_zip,member,expected_tar):
    raw=path.read_bytes();need(ident(raw)==expected_zip,'Exact retained original ZIP '+str(path),'input')
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        need(archive.testzip() is None,'Original ZIP CRC','input')
        names=archive.namelist();need(len(names)==len(set(names)),'Original ZIP unique population','input')
        need(member in names,'Original subject TAR member present','input')
        tar=archive.read(member)
    need(sha(tar)==expected_tar,'Original TAR binds exact retained archive member','input')
    files,refs,objects,members={},{},{},[]
    with tarfile.open(fileobj=io.BytesIO(tar)) as archive:
        seen=set()
        for entry in archive:
            name=PurePosixPath(entry.name)
            need(not name.is_absolute() and '..' not in name.parts and entry.name not in seen,'Safe unique TAR member '+entry.name,'tar')
            seen.add(entry.name)
            need(entry.isdir() or entry.isfile(),'Only physical TAR directories/files '+entry.name,'tar')
            if entry.isdir():continue
            data=archive.extractfile(entry).read();need(len(data)==entry.size,'Exact TAR member size '+entry.name,'tar')
            files[entry.name]=data;members.append({'path':entry.name,**ident(data)})
            if entry.name.startswith('subject/.git/refs/'):
                oid=data.decode().strip();need(re.fullmatch('[0-9a-f]{40}',oid) is not None,'Actual direct ref '+entry.name,'git-data')
                refs[entry.name[len('subject/.git/'):]]=oid
            if re.fullmatch(r'subject/\.git/objects/[0-9a-f]{2}/[0-9a-f]{38}',entry.name):
                oid=''.join(entry.name.split('/')[-2:]);decoded=zlib.decompress(data)
                need(hashlib.sha1(decoded).hexdigest()==oid,'Actual loose Git object identity '+oid,'git-data')
                header,body=decoded.split(b'\0',1);kind,n=header.decode().split(' ')
                need(len(body)==int(n),'Actual loose object length '+oid,'git-data')
                objects[oid]={'type':kind,'raw':body}
    need(all(oid in objects for oid in refs.values()),'Complete retained ref/object population','git-data')
    return {'zip_path':str(path),'zip':ident(raw),'tar_member':member,'tar':ident(tar),
        'member_count':len(members),'member_bytes':sum(r['bytes'] for r in members),
        'members':members,'files':files,'refs':refs,'objects':objects}


def object_bytes(snapshot,oid):
    need(oid in snapshot['objects'] and snapshot['objects'][oid]['type']=='blob','Actual blob present '+oid,'git-data')
    return snapshot['objects'][oid]['raw']


def body(raw):
    need(raw.count(b'```json\n')==1,'One canonical body frame','typed-data')
    text=raw.split(b'```json\n',1)[1].split(b'\n```',1)[0]
    result=json.loads(text);need(canonical(result)==text,'Exact canonical JSON body','typed-data')
    return result


def expected_pointers(snapshot,manifest,archive_oid):
    entries={r['artifact_id']:r for r in manifest['entries']};whole=[];history=[]
    for role in ('STATE','ROADMAP'):
        row=entries[role];raw=object_bytes(snapshot,row['blob_oid']);parsed=body(raw)
        common={'source_role':role,'source_sha256':sha(raw),'source_bytes':len(raw),'blob_oid':blob(raw)}
        whole.append({**common,'role':role+'_PREIMAGE','source_pointer':'','record_id':role+'.md',
            'record_sha256':sha(raw),'owner':role+'.md'})
        for index,item in enumerate(parsed['history']):
            history.append({**common,'role':'HISTORY_RECORD','source_pointer':'/history/'+str(index),
                'record_id':item['record_id'],'record_sha256':sha(canonical(item)),'owner':item['owner']})
    return [{**row,'schema_version':'implementaudit.typed-archive-pointer.v2',
        'archive_ref':PREFIX+'/'+manifest['preparation_generation_id'],
        'archive_manifest_oid':archive_oid,'archive_manifest_sha256':sha(object_bytes(snapshot,archive_oid)),
        'preparation_generation_id':manifest['preparation_generation_id'],'authority':'ARCHIVED_ONLY_HISTORY'} for row in whole+history]


def receive_archive(snapshot,epoch):
    ref=PREFIX+'/'+epoch;oid=snapshot['refs'][ref];raw=object_bytes(snapshot,oid);manifest=json.loads(raw)
    need(raw==canonical(manifest),'Canonical original archive manifest '+epoch,'archive')
    need(manifest['schema']=='implementaudit.state-archive.v1' and manifest['controller']==CONTROLLER and manifest['run_root_identity']==RUN,'Archive exact typed identity '+epoch,'archive')
    need(manifest['preparation_generation_id']==epoch,'Archive exact preparation generation '+epoch,'archive')
    need(manifest['authority_ceiling']=='ARCHIVED_ONLY_HISTORY' and manifest['discovery']=='EXCLUDED_FROM_CURRENT_AND_RECURSIVE_POPULATIONS' and manifest['retention']=='NO_DELETE_WITHOUT_ACCEPTED_RETENTION_SUCCESSOR','Archive exact authority/discovery/retention '+epoch,'archive')
    entries=manifest['entries'];need(len(entries)==len({r['artifact_id'] for r in entries}),'No duplicate actual archive member '+epoch,'archive')
    indexed={r['artifact_id']:r for r in entries}
    need({'STATE','ROADMAP','OWNER_MAP'}.issubset(indexed),'Complete canonical preimage/owner population '+epoch,'archive')
    entry_receipts=[]
    for row in entries:
        data=object_bytes(snapshot,row['blob_oid'])
        need(sha(data)==row['sha256'] and len(data)==row['byte_length'] and blob(data)==row['blob_oid'],'Actual complete archived bytes '+epoch+'/'+row['artifact_id'],'archive')
        need(snapshot['refs'][PREFIX+'/objects/'+row['blob_oid']]==row['blob_oid'],'Permanent member retention ref '+epoch+'/'+row['artifact_id'],'archive')
        entry_receipts.append({'declaration':row,'received':ident(data)})
    declarations=[]
    for role in ('STATE','ROADMAP'):declarations.extend(body(object_bytes(snapshot,indexed[role]['blob_oid']))['artifact_refs'])
    need(set(indexed)=={'STATE','ROADMAP','OWNER_MAP'}|{r['artifact_id'] for r in declarations},'Archive denominator equals complete declared artifact population '+epoch,'archive')
    for declared in declarations:
        row=indexed[declared['artifact_id']]
        need(all(row[k]==declared[k] for k in ('owner','role')) and row['source_path']==declared['locator'],'Exact source artifact metadata '+epoch+'/'+declared['artifact_id'],'archive')
    need(snapshot['refs'][PREFIX+'/objects/'+oid]==oid,'Archive manifest permanent retention ref '+epoch,'archive')
    pointers=expected_pointers(snapshot,manifest,oid)
    return {'epoch':epoch,'archive_ref':ref,'archive_oid':oid,'archive':ident(raw),'manifest':manifest,
        'complete_entry_receiving':entry_receipts,'expected_complete_new_pointer_population':pointers}


def receive_generation(snapshot,epoch,archives,expected_count):
    root='subject/'+RUN+'/state-generations/'+epoch+'/'
    state=snapshot['files'][root+'STATE.md'];roadmap=snapshot['files'][root+'ROADMAP.md']
    pair={'STATE':body(state),'ROADMAP':body(roadmap)}
    pointers=pair['STATE']['archive_pointers']
    need(pointers==pair['ROADMAP']['archive_pointers'],'Paired archive populations agree '+epoch,'pointer')
    need(len(pointers)==expected_count and len({canonical(p) for p in pointers})==expected_count,'Exact unique complete pointer count '+epoch,'pointer')
    manifest=json.loads(snapshot['files'][root+'protected-state.json'])
    need(manifest['ARCHIVED_ONLY_HISTORY']==pointers,'Protected manifest complete archive population '+epoch,'pointer')
    need(pair['STATE']['history']==pair['ROADMAP']['history']==[],'Removed histories are represented only by typed archive pointers '+epoch,'pointer')
    rows=[]
    for pointer in pointers:
        archive=archives[pointer['preparation_generation_id']]
        need(pointer in archive['expected_complete_new_pointer_population'],'Exact historical pointer member '+epoch+'/'+pointer['record_id'],'pointer')
        need(pointer['archive_ref']==archive['archive_ref'] and pointer['archive_manifest_oid']==archive['archive_oid'] and pointer['archive_manifest_sha256']==archive['archive']['sha256'],'Pointer anchors exact actual archive '+epoch+'/'+pointer['record_id'],'pointer')
        need(pointer['authority']=='ARCHIVED_ONLY_HISTORY' and pointer['schema_version']=='implementaudit.typed-archive-pointer.v2','Pointer has no current authority '+epoch+'/'+pointer['record_id'],'pointer')
        raw=object_bytes(snapshot,pointer['blob_oid'])
        need(len(raw)==pointer['source_bytes'] and sha(raw)==pointer['source_sha256'],'Exact whole historical source '+epoch+'/'+pointer['record_id'],'pointer')
        history_facts=None
        if pointer['role']=='HISTORY_RECORD':
            need(re.fullmatch(r'/history/(0|[1-9][0-9]*)',pointer['source_pointer']) is not None,'Exact typed history offset '+epoch,'pointer')
            parsed=body(raw);record=parsed['history'][int(pointer['source_pointer'].rsplit('/',1)[1])]
            selected=canonical(record)
            need(record['record_id']==pointer['record_id'] and record['owner']==pointer['owner'],'Historical record identity and owner '+epoch,'pointer')
            history_facts={k:v for k,v in record.items() if k!='payload'}
            history_facts['payload']={k:(ident(v.encode()) if k=='text' else v) for k,v in record['payload'].items()}
        else:
            need(pointer['role']==pointer['source_role']+'_PREIMAGE' and pointer['source_pointer']=='','Typed whole preimage role '+epoch,'pointer')
            selected=raw
        need(sha(selected)==pointer['record_sha256'],'Selectively retrieved exact historical record '+epoch+'/'+pointer['record_id'],'pointer')
        rows.append({'pointer':pointer,'received_source':ident(raw),'received_selected_record':ident(selected),'history_facts':history_facts,
            'receiving_kind':'Independent data decoding of retained actual original; not a newly executed product retrieval'})
    receipt_oid=snapshot['refs'][RECEIPTS+'/'+epoch]
    receipt_raw=object_bytes(snapshot,receipt_oid);receipt=receipt_raw.decode().rstrip('\n').split('\t')
    need(len(receipt)==14 and receipt[0]=='implementaudit.continuity-receipt.v3','Original14 actual receipt '+epoch,'currentness')
    pointer_oid=receipt[7];live=json.loads(object_bytes(snapshot,pointer_oid))
    need(receipt[1:5]==[CONTROLLER,live['claim_id'],RUN,epoch],'Receipt owner and epoch '+epoch,'currentness')
    need(receipt[6]==POINTER and live['continuity_epoch']==epoch and live['projection_generation_id']==epoch,'Pointer uses current namespace and generation '+epoch,'currentness')
    need(sha(state)==receipt[8]==live['state_sha256'] and sha(roadmap)==receipt[9]==live['roadmap_sha256'],'Actual live pair receipt/pointer byte JOIN '+epoch,'currentness')
    need(sha(snapshot['files'][root+'protected-state.json'])==receipt[10]==live['protected_manifest_sha256'],'Actual protected manifest receipt/pointer JOIN '+epoch,'currentness')
    need(sha(snapshot['files'][root+'archive-manifest.json'])==receipt[11]==live['archive_manifest_sha256'],'Actual archive digest is a binding, not current pointer '+epoch,'currentness')
    need(all(pointer_oid!=a['archive_oid'] for a in archives.values()),'Live current pointer differs from archive manifests '+epoch,'currentness')
    need(snapshot['refs'][MARKER]=='47b38f763b036979437062464718f95bfea509f8','Actual original permanent marker preserved '+epoch,'currentness')
    return {'epoch':epoch,'live_pointer_oid':pointer_oid,'live_pointer':live,'receipt_oid':receipt_oid,'receipt_fields':receipt,
        'pair':{'STATE':ident(state),'ROADMAP':ident(roadmap)},'complete_pointer_population':rows,'pointer_count':len(rows),
        'current_pointer_ref_at_this_snapshot':snapshot['refs'][POINTER],
        'this_generation_selected_current_at_snapshot':snapshot['refs'][POINTER]==pointer_oid}


def source_body(path,selector):
    raw=(CURRENT/path).read_bytes();tree=ast.parse(raw);names=selector.split('.')
    nodes=tree.body
    for name in names:
        node=next(n for n in nodes if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==name)
        nodes=node.body
    text=ast.get_source_segment(raw.decode(),node)
    return {'path':path,'selector':selector,'source_file':ident(raw),'start_line':node.lineno,'end_line':node.end_lineno,
        'full_source_body':text,'source_body_sha256':sha(text.encode())}


def main():
    OUT.mkdir(exist_ok=True)
    need(not (OUT/'A6_RECEIVING.json').exists(),'No prior A6 receiver output overwritten','input')
    prior_raw=(PRIOR/'MANIFEST.json').read_bytes()
    need(len(prior_raw)==4085 and sha(prior_raw)=='a78c178110a63867f8b5055a0e7443f22e4c438523c77c6645314ce0fc8fe84b','Exact previously received A14 manifest','input')
    prior_manifest=json.loads(prior_raw)
    for row in prior_manifest['members']:
        raw=(PRIOR/row['path']).read_bytes()
        need(len(raw)==row['bytes'] and sha(raw)==row['sha256'],'Prior sealed member unchanged '+row['path'],'input')
    need(len(prior_manifest['members'])==15,'Entire prior fifteen-member selected packet received','input')
    ext=json.loads((PRIOR/'evidence/EXTERNAL_IMMUTABLE_BINDINGS.json').read_text())
    ziprows={row['local_path']:row for row in ext['selected_original_git_blobs']}
    def zip_ident(name):
        row=ziprows[name];return {k:row[k] for k in ('bytes','sha256','git_blob')}
    first=receive_zip_tar(PRIOR/'evidence/retained/first_migration_preparation/WFULL_PREPARATION_43785700341.zip',
        zip_ident('evidence/retained/first_migration_preparation/WFULL_PREPARATION_43785700341.zip'),'SUBJECT.tar',
        '00a78074048486262ad856b28ad6b2f94eb96a22188766ddd0165ce36bc05c65')
    last=receive_zip_tar(PRIOR/'evidence/retained/wfull/ARTIFACT.zip',zip_ident('evidence/retained/wfull/ARTIFACT.zip'),
        'dg18-w-full-continuation-43795345593-1/SUBJECT_AFTER.tar','6652196d5311dad32fe3c3ef8517ccda26aa71e7a7f057da1be3e64607ce74b4')
    first_archives={'G0002':receive_archive(first,'G0002')}
    last_archives={e:receive_archive(last,e) for e in ('G0002','G0003')}
    need(first_archives['G0002']==last_archives['G0002'],'Exact original G2 archive/entry population retained through actual G3','archive')
    g2=receive_generation(first,'G0002',first_archives,3)
    g3=receive_generation(last,'G0003',last_archives,5)
    need(g2['this_generation_selected_current_at_snapshot'] and g3['this_generation_selected_current_at_snapshot'],'Each actual snapshot has its exact separately received current pointer','currentness')
    need(last['refs'][POINTER]==g3['live_pointer_oid']!=g2['live_pointer_oid'],'Actual successor selects G3 only while prior G2 stays retained','currentness')
    need({canonical(r['pointer']) for r in g2['complete_pointer_population']}.issubset({canonical(r['pointer']) for r in g3['complete_pointer_population']}),'All original G2 history pointers survive unchanged in G3','pointer')
    need(last['refs'][RECEIPTS+'/G0002']==g2['receipt_oid'] and last['refs'][RECEIPTS+'/G0001']=='c6406b4e8da2c38d92f8cf59c742e9d2640ee71b','Historical v2 and v3 receipts retained without current selection','currentness')
    for role in ('STATE','ROADMAP'):
        path='subject/'+RUN+'/'+role+'.md'
        need(first['files'][path]==last['files'][path],'Root compatibility preimage retained unchanged '+role,'currentness')
        need(sha(last['files'][path])!=g3['pair'][role]['sha256'],'Retained root preimage is not selected current bytes '+role,'currentness')
    prior_data=json.loads((PRIOR/'evidence/ORIGINAL_A14_DATA_RECEIVING.json').read_text())
    need(prior_data['first_migration']['pointer_oid']==g2['live_pointer_oid'] and prior_data['later_original_transition']['pointer_oid']==g3['live_pointer_oid'],'Data independently agrees with original received pointer chain','input')
    original_commands=prior_data['original_commands']
    need(all(c['record']['exit_code']==0 for c in original_commands),'Original selected actual currentness commands all succeeded','currentness')
    by_stem={c['stem']:c for c in original_commands}
    need(by_stem['017-require-migrated']['streams']['stdout']['text'].strip()==RECEIPTS+'/G0002@'+g2['receipt_oid'],'Actual separate first-migration require selects G2','currentness')
    need(by_stem['require-current']['streams']['stdout']['text'].strip()==RECEIPTS+'/G0003@'+g3['receipt_oid'],'Actual separate W-FULL require selects G3','currentness')
    for role in ('STATE','ROADMAP'):
        stream=by_stem['current-'+role]['streams']['stdout']
        need(stream['sha256']==g3['pair'][role]['sha256'] and stream['bytes']==g3['pair'][role]['bytes'],'Actual separate current consumer received exact G3 '+role,'currentness')
    data={'schema':'dg18.a6.original-retained-data-receiving.v1','authority':'NONE',
        'original_criterion':6,'original_denominator':14,'original_predicate':'Selective historical retrieval resolves exact typed pointers/hashes and cannot promote archived history to current authority.',
        'first_migration_run':43785700341,'wfull_run':43795345593,'historical_runtime':OLD,
        'subject_inputs':[{k:s[k] for k in ('zip_path','zip','tar_member','tar','member_count','member_bytes')} for s in (first,last)],
        'first_migration':g2,'actual_successor':g3,'actual_archive_populations':list(last_archives.values()),
        'all_original_G2_pointers_preserved':True,'retained_history_never_received_as_current':True,
        'selected_original_commands':original_commands,
        'new_original_operations':0,'new_product_commands':0,'native_event_claim':False,
        'independent_receiving_scope':'Exact historical original data and prior actual currentness. No live restoration, private grant, historical event reconstruction or native producer authentication.'}
    output=[emit('A6_ORIGINAL_DATA.json',data)]
    oldtree,newtree=immutable_tree(OLD),immutable_tree(NEW)
    need(git('rev-parse',NEW+'^{tree}').decode().strip()=='9c3913ceaa95f3f36b0377fe2dba4a302afcba89','Exact current immutable tree','source')
    prior_source=json.loads((PRIOR/'evidence/CURRENT_A14_SOURCE_APPLICABILITY.json').read_text())
    runtime=[]
    for row in prior_source['original44_runtime']:
        path=row['path'];old=first['files']['subject/'+path];new=(CURRENT/path).read_bytes()
        need(ident(old)==row['historical'] and blob(old)==oldtree[path],'Exact historical runtime '+path,'source')
        need(ident(new)==row['current'] and blob(new)==newtree[path],'Exact current runtime '+path,'source')
        runtime.append(row)
    need(len(runtime)==44,'Complete original runtime closure received','source')
    required=['rotate-canonical-state.py','canonical_hot_projection.py','canonical_custody.py','canonical_rotation_inputs.py']
    need(all(next(r for r in runtime if r['path'].endswith('/'+name))['byte_identical'] for name in required),'All four direct archive/retrieval/projection/custody owners byte-identical','source')
    inspected=[('rotate-canonical-state.py',n) for n in ('resolve_typed_archive_pointer_v2','_verify_archive_one','_verify_retained_archives','verify_canonical_archive','_archive_preimage','_pointers','_scoped_git','_ref','_refs','_blob')]
    inspected += [('canonical_hot_projection.py',n) for n in ('_v2_history','_v2_archive_pointer','_v2_existing_archives','_v2_population','_v2_derive')]
    bodies=[source_body('skills/implementaudit/scripts/'+path,name) for path,name in inspected]
    selected_paths=['.github/workflows/validate.yml','scripts/verify-package.sh','tests/canonical-state-rotation.test.sh',
        'fixtures/canonical-state-rotation/archive_v2_test.py','fixtures/canonical-state-rotation/protected_projection_v2_test.py',
        'fixtures/canonical-state-rotation/canonical_reader_test.py','fixtures/canonical-state-rotation/v2/source.json',
        'fixtures/controller-initialization/author_checkpoint.py','skills/implementaudit/references/canonical-state-rotation.md']
    selection=[]
    for path in selected_paths:
        raw=(CURRENT/path).read_bytes();need(blob(raw)==newtree[path],'Exact current original executable control/source '+path,'source')
        selection.append({'path':path,**ident(raw)})
    need('bash tests/canonical-state-rotation.test.sh' in (CURRENT/'scripts/verify-package.sh').read_text(),'Real package gate invokes canonical suite','source')
    need('run: bash scripts/verify-package.sh' in (CURRENT/'.github/workflows/validate.yml').read_text(),'Real workflow invokes package gate','source')
    output.append(emit('A6_CURRENT_SOURCE_APPLICABILITY.json',{'schema':'dg18.a6.exact-current-source-applicability.v1','authority':'NONE',
        'historical_commit':OLD,'current_commit':NEW,'current_tree':'9c3913ceaa95f3f36b0377fe2dba4a302afcba89',
        'complete_original44_runtime':runtime,'complete_selected_control_source':selection,'inspected_archive_and_guard_bodies':bodies,
        'changed_owner_constants_preserved':prior_source['changed_owner_constants'],
        'scope':'A6 archive retrieval and historical/current authority separation only. Source differences in initialization/native admission do not establish whole-runtime or native producer equivalence; actual current controls are received separately.'}))
    CI=BASE/'g2-profile-integration-publication/ci-observations/G0011_SUCCESS'
    cm=json.loads((CI/'MANIFEST.json').read_text())
    def provider(name):
        raw=(CI/name).read_bytes();need(len(raw)==cm[name]['bytes'] and sha(raw)==cm[name]['sha256'],'Complete prior actual provider body '+name,'ci')
        return json.loads(json.loads(raw)['structuredContent']['content'])
    run=provider('ACTUAL_RUN_TOOL_RETURN.json');jobs=provider('ACTUAL_JOBS_TOOL_RETURN.json')
    need(run['id']==44655969487 and run['run_attempt']==1 and run['head_sha']==NEW and run['status']=='completed' and run['conclusion']=='success','Exact actual current CI run','ci')
    need(jobs['total_count']==len(jobs['jobs'])==1,'Complete actual CI job population','ci')
    job=jobs['jobs'][0]
    need(job['id']==136022135798 and job['head_sha']==NEW and job['conclusion']=='success','Exact actual current CI job','ci')
    need(any(s['name']=='Verify package contract' and s['conclusion']=='success' for s in job['steps']),'Actual full package gate succeeded','ci')
    log=(CI/'JOB136022135798.log').read_bytes()
    need(len(log)==569919 and sha(log)=='7d58c311832168a01e8dc12841d4b770bd16a1873e63a7063ecc0d64f962b893','Full exact actual current CI log','ci')
    cases=[('protected_projection_v2_test.py','ProjectionV2Qualification',n) for n in (
        'test_typed_history_has_complete_exact_retrieval_pointers','test_large_typed_history_reduces_with_complete_source_retrieval',
        'test_tc06_existing_archive_remains_when_followup_rotation_is_unavailable')]
    cases += [('archive_v2_test.py','ArchiveQualification',n) for n in (
        'test_actual_archive_gc_retention_typed_retrieval_and_no_current_authority',
        'test_rebound_archive_metadata_must_match_complete_source_population','test_typed_pointer_cannot_substitute_preparation_generation',
        'test_missing_retained_archive_refuses_before_new_archive_effects','test_real_retained_archive_chain_survives_gc_and_missing_ancestor_refuses',
        'test_immutable_reader_rejects_every_changed_pointer_binding')]
    cases += [('canonical_reader_test.py','CanonicalReaderTests',n) for n in (
        'test_TC06_retired_rotation_policy_keeps_old_readers_and_archives','test_real_generation_read_binds_exact_pair_and_never_changes_root',
        'test_actual_missing_pointer_after_migration_cannot_restore_root_authority','test_actual_missing_marker_after_migration_cannot_restore_root_authority')]
    observed=[]
    for filename,cls,name in cases:
        path='fixtures/canonical-state-rotation/'+filename
        row=source_body(path,cls+'.'+name)
        lines=[(i+1,line.decode()) for i,line in enumerate(log.splitlines()) if (' '+name+' (__main__.'+cls+'.'+name+') ... ok').encode() in line]
        need(len(lines)==1,'Actual exact successful original control '+name,'ci')
        need(('"${py[@]}" '+path) in (CURRENT/'tests/canonical-state-rotation.test.sh').read_text(),'Actual current suite selects exact file '+filename,'ci')
        row.update(actual_log_line_number=lines[0][0],actual_log_line=lines[0][1],
            scope='Existing exact-current executed behavioral control; not a new run or native event')
        observed.append(row)
    output.append(emit('A6_ACTUAL_CURRENT_CONTROLS.json',{'schema':'dg18.a6.actual-current-control-receiving.v1','authority':'NONE',
        'run':{k:run[k] for k in ('id','head_sha','run_attempt','status','conclusion','created_at','updated_at')},
        'job':{k:job[k] for k in ('id','head_sha','run_id','status','conclusion','steps')},
        'full_actual_log':{'path':str(CI/'JOB136022135798.log'),**ident(log)},
        'source_and_full_oracles_with_actual_observations':observed,'selected_actual_method_count':len(observed),
        'tests_rerun':False,'no_acceptance_from_name_or_CI_status_alone':True,
        'per_test_raw_fixture_output_limit':'The current CI has no retained per-test fixture artifacts. Its full logged executions and exact complete oracle bodies support the adverse/TC06 control leg; original retained first-migration/W-FULL subjects supply the concrete full data/currentness leg. This does not receive A9 per-stage evidence or an A13 complete matrix.'}))
    inputs={'schema':'dg18.a6.input-custody-and-external-bindings.v1','authority':'NONE',
        'prior_A14_manifest':{'path':str(PRIOR/'MANIFEST.json'),**ident(prior_raw),'all_selected_payloads_received':15},
        'original_zip_bindings':[ziprows[n] for n in ('evidence/retained/first_migration_preparation/WFULL_PREPARATION_43785700341.zip','evidence/retained/wfull/ARTIFACT.zip')],
        'durable_current_ci':ext['existing_results16_archive'],
        'contract':{'local_path':str(BASE/'dg18-a10-current-51416/ISSUE215_CURRENT_BODY.md'),**ident((BASE/'dg18-a10-current-51416/ISSUE215_CURRENT_BODY.md').read_bytes()),'archive_member':'source/ISSUE215_CURRENT_BODY.md'},
        'amendment':{'local_path':str(BASE/'dg18-a10-current-51416/COMMENT_5638756120_CURRENT.md'),**ident((BASE/'dg18-a10-current-51416/COMMENT_5638756120_CURRENT.md').read_bytes()),'archive_member':'source/COMMENT_5638756120_CURRENT.md'},
        'whole_old_archive_not_republished':True,'new_original_awards':0,'N1':'Historical LOST/UNKNOWN/PENDING unchanged; no search or reconstruction'}
    output.append(emit('INPUT_BINDINGS.json',inputs))
    receipt={'schema':'dg18.a6.complete-original-receiving.v1','authority':'NONE',
        'recommendation':'COMPLETE_ORIGINAL_A6_CONJUNCTION_SUPPORTED_AT_EXACT_51416_FOR_ROOT_ADJUDICATION',
        'original_criterion':6,'original_denominator':14,'data_checks':sum(COUNTS.values()),'check_groups':COUNTS,
        'actual_prior_and_successor_pointer_counts':[3,5],'unique_retained_pointer_count':5,'current_actual_control_methods':len(observed),
        'new_product_commands':0,'new_original_operations':0,'provider_reads':0,'provider_writes':0,'controller_actions':0,
        'native_events':0,'award':None,'whole_cell_accepted':False,'Root_currentness_and_adjudication_required':True,
        'scope':'Original A6 typed historical retrieval and nonpromotion; preserves exact prior evidence scopes and all original14 amendments. No A3/A9/A13/OR/C02/N1/native Stop or whole-cell transfer.',
        'evidence':output}
    output.append(emit('A6_RECEIVING.json',receipt))
    print(json.dumps({'recommendation':receipt['recommendation'],'checks':sum(COUNTS.values()),'groups':COUNTS,
        'actual_pointer_counts':[3,5],'current_actual_methods':len(observed),'outputs':output,
        'original_operations_replayed':0,'new_product_commands':0,'award':None},indent=2))


if __name__=='__main__':main()
