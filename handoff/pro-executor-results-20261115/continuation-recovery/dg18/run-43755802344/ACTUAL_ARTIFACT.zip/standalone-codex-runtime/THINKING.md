# Thinking — actual bounded task

Top objective: Receive the exact DG18 installed package through standalone-codex and establish its actual fresh task currentness before independent receiving.
Route: brownfield; owner/source: this fresh run and the actual target source 2204a5eb6e8940ccadcb582e0c6ef60b250b9477.
Top closure risks: incomplete initialization, stale source, copied receipt, or duplicated predecessor effect.
Countermeasure: exact pending token, retained input population, normal continuity, actual result readback.
Rollback: preserve incomplete evidence and stop; no original authority rollback.
Evidence strategy: structural validation is separate from normal continuity and task success.
Sidecars are optional and grant no authority.
