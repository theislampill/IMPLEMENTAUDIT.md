# Context — real fresh task

Owner-provided objective: Receive the exact DG18 installed package through standalone-codex and establish its actual fresh task currentness before independent receiving.

Actual repository: /home/runner/work/_temp/dg18-installed-43755802344-1/standalone-codex/subject
Actual HEAD: 2204a5eb6e8940ccadcb582e0c6ef60b250b9477
Actual tree: 9ab7ca487352f9c57404c4a1ce8d43f4c2086f70
Actual claim: ca82a02a4ce54068b0ec2c5b3a4c7a31
Actual controller: dg18-installed-43755802344-1-standalone-codex

Executing claim helper SHA256: 5700328182e86f2b0fc51cb4a693ac35f4fffd94e65a08654bf1f59e486edf9c

No original controller continuity, hosted identity, independent review, publication, or acceptance is inferred.
