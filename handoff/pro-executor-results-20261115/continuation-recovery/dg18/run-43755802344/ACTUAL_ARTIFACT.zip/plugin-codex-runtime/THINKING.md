# Thinking — actual bounded task

Top objective: Receive the exact DG18 installed package through plugin-codex and establish its actual fresh task currentness before independent receiving.
Route: brownfield; owner/source: this fresh run and the actual target source 746c6deba381baec6f09c286487cad3fa4afdc98.
Top closure risks: incomplete initialization, stale source, copied receipt, or duplicated predecessor effect.
Countermeasure: exact pending token, retained input population, normal continuity, actual result readback.
Rollback: preserve incomplete evidence and stop; no original authority rollback.
Evidence strategy: structural validation is separate from normal continuity and task success.
Sidecars are optional and grant no authority.
