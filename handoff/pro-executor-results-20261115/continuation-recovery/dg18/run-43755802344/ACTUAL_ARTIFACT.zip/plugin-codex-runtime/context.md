# Context — real fresh task

Owner-provided objective: Receive the exact DG18 installed package through plugin-codex and establish its actual fresh task currentness before independent receiving.

Actual repository: /home/runner/work/_temp/dg18-installed-43755802344-1/plugin-codex/subject
Actual HEAD: 746c6deba381baec6f09c286487cad3fa4afdc98
Actual tree: 50fb07bff01a4af1eb5cb6ad7054f2fe39824f3c
Actual claim: 13cb1a8ebf677d1f59a650cf5f9424c9
Actual controller: dg18-installed-43755802344-1-plugin-codex

Executing claim helper SHA256: 5700328182e86f2b0fc51cb4a693ac35f4fffd94e65a08654bf1f59e486edf9c

No original controller continuity, hosted identity, independent review, publication, or acceptance is inferred.
