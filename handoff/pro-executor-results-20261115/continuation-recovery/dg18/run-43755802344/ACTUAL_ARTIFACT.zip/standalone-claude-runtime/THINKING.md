# Thinking — actual bounded task

Top objective: Receive the exact DG18 installed package through standalone-claude and establish its actual fresh task currentness before independent receiving.
Route: brownfield; owner/source: this fresh run and the actual target source a06ab32ea4a4e401e81b9f3d37e635cb6fbe02d1.
Top closure risks: incomplete initialization, stale source, copied receipt, or duplicated predecessor effect.
Countermeasure: exact pending token, retained input population, normal continuity, actual result readback.
Rollback: preserve incomplete evidence and stop; no original authority rollback.
Evidence strategy: structural validation is separate from normal continuity and task success.
Sidecars are optional and grant no authority.
