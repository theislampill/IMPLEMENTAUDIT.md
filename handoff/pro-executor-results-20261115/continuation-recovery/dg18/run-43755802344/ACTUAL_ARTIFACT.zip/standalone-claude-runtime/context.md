# Context — real fresh task

Owner-provided objective: Receive the exact DG18 installed package through standalone-claude and establish its actual fresh task currentness before independent receiving.

Actual repository: /home/runner/work/_temp/dg18-installed-43755802344-1/standalone-claude/subject
Actual HEAD: a06ab32ea4a4e401e81b9f3d37e635cb6fbe02d1
Actual tree: 3e8baf8314369bbd0c9b550bf1128a364c09c3a3
Actual claim: 1673f8ead6abd770a469e332fe5b98c1
Actual controller: dg18-installed-43755802344-1-standalone-claude

Executing claim helper SHA256: 5700328182e86f2b0fc51cb4a693ac35f4fffd94e65a08654bf1f59e486edf9c

No original controller continuity, hosted identity, independent review, publication, or acceptance is inferred.
