# Phase 1 — Receive this bounded fresh task

IMPLEMENTAUDIT_PHASE_START
Task: Receive the exact DG18 installed package through standalone-claude and establish its actual fresh task currentness before independent receiving.
Type: brownfield
Run root: .IMPLEMENTAUDIT/runs/dg18-installed-current-consumer-RDZ4jF
Baseline ref: a06ab32ea4a4e401e81b9f3d37e635cb6fbe02d1
Owner/source: .IMPLEMENTAUDIT/runs/dg18-installed-current-consumer-RDZ4jF/STATE.md and the actual source at a06ab32ea4a4e401e81b9f3d37e635cb6fbe02d1
Audit object: the owner-authorized bounded initialization and receiving task
Depends on phases: none

## Work

Establish verified fresh execution custody, then perform the stated receiving task. Preserve predecessor evidence as history. No completed result is inferred from initialization.

## Implementation steps (ordered)

- Step 1: Receive the initialized root — target: .IMPLEMENTAUDIT/runs/dg18-installed-current-consumer-RDZ4jF; change: publish only after the initialization validator and expected-old guards pass; verify: run the public activation and normal continuity entry points; expected: exact real receipt verifies against this source and state.
- Step 2: Perform the authorized next action — target: the bounded task in STATE.md; change: Independently receive actual installed currentness and archive parity before any further operation; verify: capture the actual operation and final readback; expected: the specific receiving result is supported without a duplicate predecessor effect.

## Scope boundaries

In scope: this fresh run's initialization, normal continuity, and the explicitly stated receiving task.
Out of scope: original incident custody reconstruction, protected bodies, credentials, publication, product commits, installed-home changes, or acceptance awards.

## STOP conditions (plan-specific)

- Stop if this root's claim, controller token, source HEAD/tree or initializer source differs from the received binding.
- Stop if an existing partial file conflicts with the real author input; preserve both observations and do not replace the file automatically.

## Current state excerpts

- Actual target HEAD is a06ab32ea4a4e401e81b9f3d37e635cb6fbe02d1; tree is 3e8baf8314369bbd0c9b550bf1128a364c09c3a3.
- Actual claim ID is 1673f8ead6abd770a469e332fe5b98c1; controller is dg18-installed-43755802344-1-standalone-claude.
- No phase or effect is completed in this authored initial checkpoint.

## Acceptance criteria

- [ ] All seven real task files pass the existing structural validator under the authenticated pending context.
- [ ] Normal invalidate, resume, verify and require calls obtain and verify actual fresh continuity.
- [ ] The declared next action has its own real result and no duplicated predecessor effect.

## Mandatory commands

- bash /home/runner/work/IMPLEMENTAUDIT.md/IMPLEMENTAUDIT.md/qualified-source/skills/implementaudit/scripts/claim-run.sh --require-current-continuity dg18-installed-43755802344-1-standalone-claude > <run-root>/evidence/require-currentness.txt 2>&1 — property: behavioral; scope: this exact fresh controller; coverage: full; capture: <run-root>/evidence/require-currentness.txt; expected: exit 0 only after real receipt verification.

## Evidence required

- Actual CLI command captures, source/claim/ref readback, and the declared receiving result.
- Markdown fallback: yes; sidecars are not an authorization dependency for this task.

## Rollback / defer path

Retain incomplete custody and fail closed; remove only the explicitly owned disposable fixture after its selected evidence has been retained. Do not roll back an original controller or published effect.

## Maintenance notes

- Keep this phase bound to the actual task and source. It does not substitute for a reviewer or a continuity receipt.

IMPLEMENTAUDIT_PHASE_VERIFY
No verification passage is claimed in the initial checkpoint.

AGENTS_UPDATE_DECISION
No durable repository instruction change is requested by this receiving task.

CONTINUITY_DECISION
Preserve the actual fresh receipt only after the normal owner emits it.

IMPLEMENTAUDIT_PHASE_DONE
Status: open
