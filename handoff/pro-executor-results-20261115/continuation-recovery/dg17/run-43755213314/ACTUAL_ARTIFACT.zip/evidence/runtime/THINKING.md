# Thinking — actual bounded task

Top objective: Receive the exact DG17 installed package, establish one fresh governed task, and evaluate its real nonterminal continuation before independent Root receiving.
Route: brownfield; owner/source: this fresh run and the actual target source 1407d60e41ebacd60a6c1efac9071b318b1302c1.
Top closure risks: incomplete initialization, stale source, copied receipt, or duplicated predecessor effect.
Countermeasure: exact pending token, retained input population, normal continuity, actual result readback.
Rollback: preserve incomplete evidence and stop; no original authority rollback.
Evidence strategy: structural validation is separate from normal continuity and task success.
Sidecars are optional and grant no authority.
