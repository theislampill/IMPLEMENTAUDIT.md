# Tools

{
  "bash": "/usr/bin/bash",
  "git": "/usr/bin/git",
  "python": "/usr/bin/python3",
  "claim_owner": "/home/runner/work/_temp/dg17-installed-43755213314-1/isolated-host/plugins/implementaudit/skills/implementaudit/scripts/claim-run.sh"
}

Only the declared owner operations and bounded receiving task are authorized.
