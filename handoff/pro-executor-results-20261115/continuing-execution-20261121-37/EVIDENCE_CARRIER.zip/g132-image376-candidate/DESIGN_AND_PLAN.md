# Image 376 ordinary Engine/source observation — implementation plan

> For agentic workers: execute the bounded plan inline; independent receiving and source review precede Root's publication gate.

**Goal:** Qualify the existing R2 Engine/source observer on the actual image `20261116.376.1` observed by run `44957502944`, without replaying that diagnostic or any original operation.

**Architecture:** Create a distinct operation, `G132_ENGINE_SOURCE_OBSERVE_20261121_02_IMAGE376`, on branch `pro/dg16-g132-engine-source-observe-20261121-02`. Preserve the prior complete observer except the exact branch identity and finite image value. Keep the same three additive paths, sole parent `f75533f95f0d099c87e7a04beb11b0a25628acdc`, exact Engine map, Git08ca pin, resource caps, existing source acquisition/capture guards and all non-authority declarations.

**Tech stack:** Existing Python observer and GitHub Actions workflow; no product source change or new dependency.

**Evidence/spec:** The original owner commission and prior frozen packet manifest `75435d932de544b9bfdef13ba74387b64e95804757727ee6711dfe266ffdc1e8`; actual observation body `1172b77ed47780b38f981c6e4f6541a51de1ed07f540dc389400c270f63ec104` and exit 2 from run `44957502944`.

## Approaches and decision

Root selected a new, finitely bound ordinary observation because the actual hosted image has changed. Re-running the old operation would preserve the known mismatch. Accepting every image would remove the finite context guard. Neither is selected. The original failed diagnostic stays immutable; original G132 operation01 stays spent.

## Global constraints

- No original session, private input, sender, launcher provisioning or policy change.
- Git08ca and all actual Engine/source guards remain byte-equivalent.
- Native exit zero remains bounded source observation; overall admission stays UNQUALIFIED.
- Preserve the inherited cleanup limitation and possible packed-HEAD refusal.
- Root alone publishes after exact remote parent/tree/ref/file checks and independent review.

## Task 1 — create and qualify the distinct configuration

- [x] Preserve actual prior failure and local old-source control results.
- [x] Copy the three exact candidate files to this isolated directory; change only branch01 to branch02 and image133 to image376; update the workflow's observer digest.
- [x] Run the existing complete seven-control family with only its context fixture rebound to the new operation; add old-image/old-branch refusal cases within that existing control. Run actual local nonhost entry once and require context refusal, exit2 and zero Git children. These are data/local controls, not native-host emulation.
- [x] Parse workflow and Python; check every shell block with bash -n; derive the exact additive Git tree and diff. Freeze source, full validation evidence and source delta.
- [ ] Receive independent source review. Root may then admit the exact distinct ordinary operation once; no automatic retry.

## Review focus and rulings

Review the actual new-image evidence, preservation of all guards, operation identity separation, workflow/helper digest coupling and honest failure retention. Existing controls exercise context mismatch, nonroot identity, old Git refusal, incomplete source identity, non-authority output and nonzero native-return sealing. No broad product/original execution is required for this configuration-only diagnostic. Ruling: the existing native context refusal is the witnessed failure; the old guard was correct for its old finite identity and is not relabeled a product defect. Ruling: use the existing isolated candidate/publication-tree workflow; do not create a worktree or repair the incomplete historical object store. The owner's ordinary-engineering authorization covers this work and excludes routine permission pauses.

