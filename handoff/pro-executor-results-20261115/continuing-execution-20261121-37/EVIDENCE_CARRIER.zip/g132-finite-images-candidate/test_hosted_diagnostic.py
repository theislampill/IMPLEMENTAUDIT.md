"""Bounded safety controls. Removing a fixed refusal must fail these controls."""
import hashlib
import json
from pathlib import Path
import tempfile
import types
import unittest

BASE=Path(__file__).resolve().parent
OWNER=BASE/'candidate/engineering/g132-engine-source-diagnostic/observe.py'

class DiagnosticControls(unittest.TestCase):
    def setUp(self):
        self.assertTrue(OWNER.is_file(),'ordinary hosted diagnostic owner is not implemented')
        self.m=types.ModuleType('diagnostic_under_test')
        self.m.__file__=str(OWNER)
        exec(compile(OWNER.read_bytes(),str(OWNER),'exec'),self.m.__dict__)

    def context(self):
        return dict(GITHUB_ACTIONS='true',RUNNER_ENVIRONMENT='github-hosted',
            GITHUB_REPOSITORY='theislampill/IMPLEMENTAUDIT.md',GITHUB_EVENT_NAME='push',
            GITHUB_REF='refs/heads/pro/dg16-g132-engine-source-observe-20261121-03',
            GITHUB_RUN_ATTEMPT='1',GITHUB_RUN_ID='123',GITHUB_SHA='a'*40,
            GITHUB_WORKFLOW_SHA='a'*40,GITHUB_JOB='observe',
            GITHUB_WORKFLOW_REF='theislampill/IMPLEMENTAUDIT.md/.github/workflows/dg16-g132-engine-source-observe.yml@refs/heads/pro/dg16-g132-engine-source-observe-20261121-03',
            ImageOS='ubuntu24',ImageVersion='20261116.376.1')

    def test_exact_ordinary_context_is_data_accepted(self):
        for image in ('20261116.133.1','20261116.376.1'):
            context=self.context();context['ImageVersion']=image
            self.m.validate_context(context,(0,0,0,0))

    def test_replay_and_changed_host_are_refused(self):
        for key,value in [('GITHUB_RUN_ATTEMPT','2'),('ImageVersion','changed'),
                          ('GITHUB_REF','refs/heads/main'),('ImageVersion','20261116.133.2'),
                          ('ImageVersion','20261116.376.2'),('ImageVersion',''),('ImageOS','ubuntu22'),
                          ('GITHUB_REF','refs/heads/pro/dg16-g132-engine-source-observe-20261121-02'),
                          ('GITHUB_REF','refs/heads/pro/dg16-g132-engine-source-observe-20261121-01'),('GITHUB_REPOSITORY','other/repo'),
                          ('GITHUB_WORKFLOW_SHA','b'*40)]:
            context=self.context();context[key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):
                self.m.validate_context(context,(0,0,0,0))

    def test_nonroot_identity_is_refused(self):
        with self.assertRaises(ValueError):self.m.validate_context(self.context(),(1000,1000,1000,1000))

    def test_new_git_pin_cannot_accept_old_body(self):
        expected=dict(kind='FILE',bytes=4640384,sha256='08ca4d2ee4d8915e86f1faaa52603752507c57af1d16d451dec9992bc9b6d801',mode=493)
        self.m.validate_git_pin(expected)
        old=dict(expected,bytes=4640352,sha256='824d5b2fffef332ec7ba053e579659bb12f26a0b4747da6f9c6dc0e71d36f235')
        with self.assertRaises(ValueError):self.m.validate_git_pin(old)

    def test_source_tuple_and_completeness_are_required(self):
        expected=dict(source_commit='f75533f95f0d099c87e7a04beb11b0a25628acdc',
                      source_tree='9b9c2b3f1453b83b87b628b665fceff492bf5b1e',
                      ordered_parents=['e76a07b2bae7c945e5a9d529ed8cf9069f4c9064'],clean=True,complete_objects=True)
        self.m.validate_source(expected)
        for key,value in [('source_commit','b'*40),('source_tree','b'*40),
                          ('ordered_parents',[]),('clean',False),('complete_objects',False)]:
            with self.subTest(key=key),self.assertRaises(ValueError):self.m.validate_source(dict(expected,**{key:value}))

    def test_observation_declares_no_execution_or_native_admission(self):
        result=self.m.base_result()
        self.assertFalse(result['native_admission'])
        self.assertFalse(result['original_execution'])
        self.assertFalse(result['session_constructed'])
        self.assertFalse(result['provider_acquired'])
        self.assertEqual(result['original_awards'],[])
        self.assertEqual(result['overall_admission'],'UNQUALIFIED')

    def test_return_seal_retains_actual_nonzero_exit_and_streams(self):
        with tempfile.TemporaryDirectory(dir=BASE) as directory:
            root=Path(directory)
            (root/'OBSERVATION.json').write_bytes(b'{"status":"REFUSED"}\n')
            (root/'STDERR.raw').write_bytes(b'')
            (root/'NATIVE_EXIT_STATUS.raw').write_bytes(b'2\n')
            result=self.m.seal_return(root)
            self.assertEqual(result['native_exit_status'],2)
            self.assertEqual(result['members']['OBSERVATION.json']['sha256'],hashlib.sha256(b'{"status":"REFUSED"}\n').hexdigest())
            self.assertFalse(result['native_admission'])

if __name__=='__main__':unittest.main(verbosity=2)
