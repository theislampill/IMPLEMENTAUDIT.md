# Distinct G132 ordinary diagnostic — finite observed image set

Operation G132_ENGINE_SOURCE_OBSERVE_20261121_03_FINITE_IMAGES, proposed new branch pro/dg16-g132-engine-source-observe-20261121-03, sole parent f75533f95f0d099c87e7a04beb11b0a25628acdc. Root authored this candidate under ordinary engineering authority. Independent review and fresh Root publication gate are required. No protected grant is issued.

Actual operation01 run44957502944 admitted image133 but received376; actual operation02 run44959365296 admitted376 but received133. Both correct context refusals remain immutable failures before helper self-hash/audit/resource/Engine/Git. Their differing actual observations support a finite two-image observation context, not either image's complete native qualification.

The selected correction admits only exact image strings20261116.133.1 and20261116.376.1 in this ordinary observer, with unchanged exactUbuntu24/host/repository/workflow/attempt/UID checks. It binds a distinct branch/concurrencygroup and selfhash. All inherited physical product owners,13-membermap,Git08ca body pin, source tuple/completeness/namespace/producer/head guards, security/timing/resource controls and outputs remain unchanged. Authentic newer Git08ca is not transferred to the historical olderpin.

Source controls accept both finiteimage values as data and reject neighboring/missing/other values, both olderbranches,wrongUbuntuOS,attempt2,andallprior mismatch cases. ExistingGit/source/non-authority controls stay unchanged. Actual local nonhost entry must refuse beforeGitchildren. These are engineering controls; no fake native host is supplied.

This candidate does not provisionlauncher,selectprivateinputs,instantiateoriginalsession,changehostpolicy,modifyG132originalapproval,orawardM1/M3. Original01G132isSPENT,oldhistoricalunknownsandqueued43098152901remainunaffected. It may observe/refuseactualEngine/source. Inherited post-reapgroup,packedHEAD,captureandevidenceceilinglimitationsremainbinding. Root mustverify exactabsentnewbranch,sourceparent/tree/threefiles,andonlyoneinitialpublish; no automaticretry.
