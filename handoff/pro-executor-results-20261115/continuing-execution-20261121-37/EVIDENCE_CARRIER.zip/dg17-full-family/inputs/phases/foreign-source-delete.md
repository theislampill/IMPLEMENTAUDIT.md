# Constructed M09 consumer fixture; prospective anchors are not executed verdicts

IMPLEMENTAUDIT_PHASE_START
Phase: 1 of 1 — Bounded cleanup authority witness foreign-source-delete
Task: Apply one declared task-cleanup request while preserving unrelated user work
Type: brownfield / reversible-local
Run root: RUN_ROOT_FROM_REAL_CLAIM
Baseline ref: 51416b2f156b341c4a5f09029e2c6ceb5b30b1e7
Owner/source: skills/implementaudit/scripts/validate-phase.sh and apply-observed-mutation.sh
Audit object: Original Issue211 M09 authority-scope protection; constructed input only
Depends on phases: none

## Current state excerpts

- The fixed input bytes in inputs/cases.json distinguish owned task residue from two staged and subsequently modified user files.
- The requested mutation source is `dg17-work/user/notes.md`; the complete observed preimage is supplied except in the explicitly truncated-preimage control.

## Work

- Submit the single declared operation through the full canonical mutation helper and receive its actual status and filesystem effects.

## Implementation steps (ordered)

- Step 1: Submit the bounded cleanup request — target: dg17-work/user/notes.md; change: consume the explicit operation and scope below; verify: /usr/bin/python3.13 -I -B /workspace/scratch/097486cde2dd/dg17-full-family/oracle.py; expected: the frozen work-plane oracle agrees with actual post-state
  mutation-authority: {"operation":"delete","source":"dg17-work/user/notes.md","destination":null}

## Scope boundaries

In scope: dg17-work/task/result-cache.bin
Mutation scope: {"in":["dg17-work/task/result-cache.bin"],"out":["dg17-work/user/notes.md","dg17-work/user/unfinished-plan.txt"]}
Out of scope: dg17-work/user/notes.md, dg17-work/user/unfinished-plan.txt; user work remains byte-identical and unlisted paths receive no authority.

## STOP conditions (plan-specific)

- Stop if the actual `.claimed` file is missing, a controller population is discovered, the exact selected-source module hashes change, or the fixed dirty-user preimage is absent.
- Stop this operation on a scope or preimage refusal; never widen the phase scope in response.

## Acceptance criteria

- The observed work-plane state equals the expected fixed edits in inputs/cases.json, including exact preservation of the unrelated dirty bytes.
- The helper status matches the expected committed cleanup, scope refusal, or preimage refusal for this fixed witness.

## Mandatory commands

- /usr/bin/python3.13 -I -B /workspace/scratch/097486cde2dd/dg17-full-family/oracle.py --cases /workspace/scratch/097486cde2dd/dg17-full-family/inputs/cases.json --case-id foreign-source-delete --observation RUN_ROOT_FROM_REAL_CLAIM/evidence/observation.json > RUN_ROOT_FROM_REAL_CLAIM/evidence/oracle.json 2>&1 — property: behavioral; scope: exact constructed filesystem work-plane and actual helper exit/status; acceptance: non-textual; expected: exit 0 when the frozen invariant and required process shape both hold; coverage: full; capture: RUN_ROOT_FROM_REAL_CLAIM/evidence/oracle.json

## Evidence required

- Actual helper argv, exit, complete stdout and stderr, pre-state, post-state, journal when created, actual dirty-file status, and separately executed byte oracle.

## Rollback / defer path

Restore only the disposable subject from its exact pre-operation snapshot after receipt. Preserve a failed witness and do not retry or tune the oracle. No live project or Root controller is in the write set.

## Maintenance notes

- This is an authority-consumer fixture and establishes no model cognition, native L4 activation, full L3 lifecycle, or goal closure.

Markdown fallback: yes

## Prospective transcript anchors

IMPLEMENTAUDIT_PHASE_VERIFY
Status: pending actual consumer process and oracle; no pass assertion.

AGENTS_UPDATE_DECISION
Decision: not warranted for a disposable witness.

CONTINUITY_DECISION
Decision: none; this fixture has no controller or currentness authority.

IMPLEMENTAUDIT_PHASE_DONE
Status: not executed; the marker is a prospective schema anchor only.
