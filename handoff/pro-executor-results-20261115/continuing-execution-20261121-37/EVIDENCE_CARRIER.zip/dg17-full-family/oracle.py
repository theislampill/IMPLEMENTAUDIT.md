#!/usr/bin/env python3
"""Variant-blind M09 work-plane oracle; never imports the product or driver."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat


def workplane(root):
    result = {}
    for directory, dirs, files in os.walk(root, followlinks=False):
        relative = Path(directory).relative_to(root)
        if relative == Path('.'):
            dirs[:] = sorted(x for x in dirs if x not in {'.git', '.IMPLEMENTAUDIT'})
        else:
            dirs.sort()
        for name in sorted(files):
            path = Path(directory) / name
            key = path.relative_to(root).as_posix()
            info = path.lstat()
            if stat.S_ISREG(info.st_mode):
                body = path.read_bytes()
                result[key] = {'kind': 'regular', 'bytes': len(body),
                               'sha256': hashlib.sha256(body).hexdigest()}
            elif stat.S_ISLNK(info.st_mode):
                result[key] = {'kind': 'symlink', 'target': os.readlink(path)}
            else:
                result[key] = {'kind': 'unsupported'}
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--cases', required=True)
    parser.add_argument('--case-id', required=True)
    parser.add_argument('--observation', required=True)
    args = parser.parse_args()
    cases = json.loads(Path(args.cases).read_text())['witnesses']
    case = next(c for c in cases if c['id'] == args.case_id)
    observation = json.loads(Path(args.observation).read_text())
    root = Path(observation['subject_root'])
    actual = workplane(root)
    expected = dict(observation['before_workplane'])
    for path, new_hex in case['expected_workplane_edits'].items():
        if new_hex is None:
            expected.pop(path)
        else:
            data = bytes.fromhex(new_hex)
            expected[path] = {'kind': 'regular', 'bytes': len(data),
                              'sha256': hashlib.sha256(data).hexdigest()}
    paths = sorted(set(expected) | set(actual))
    differences = [{'path': p, 'expected': expected.get(p), 'actual': actual.get(p)}
                   for p in paths if expected.get(p) != actual.get(p)]
    protected_changes = [p for p in case['protected_paths']
                         if actual.get(p) != observation['before_workplane'].get(p)]
    capture_agrees = actual == observation['after_workplane']
    helper = observation['helper']
    decoded = observation['decoded_helper_result']
    kind = case['expected_process_kind']
    if kind == 'scope-refusal':
        shape = (helper['returncode'] == 64 and decoded is None
                 and observation['helper_stdout'] == ''
                 and 'authority paths are outside Mutation scope' in observation['helper_stderr'])
    elif kind == 'preimage-refusal':
        shape = (helper['returncode'] == 64 and isinstance(decoded, dict)
                 and decoded.get('status') == 'REJECTED_NO_MUTATION'
                 and decoded.get('reason_code') == 'PREIMAGE_DRIFT'
                 and decoded.get('actual_effect_set') == [])
    else:
        shape = (helper['returncode'] == 0 and isinstance(decoded, dict)
                 and decoded.get('schema') == 'implementaudit.observation_bound_mutation.v2'
                 and decoded.get('status') == 'COMMITTED'
                 and decoded.get('reason_code') == 'NONE'
                 and decoded.get('residue') == [])
    committed = (helper['returncode'] == 0 and isinstance(decoded, dict)
                 and decoded.get('status') == 'COMMITTED'
                 and decoded.get('source_path') == case['operation']['source']
                 and decoded.get('destination_path') == case['operation']['destination']
                 and decoded.get('operation') == case['operation']['operation']
                 and bool(decoded.get('actual_effect_set')))
    result = {
        'schema': 'dg17.m09.workplane-oracle.v1',
        'case_id': case['id'],
        'oracle_has_variant_input': False,
        'live_post_state_matches_capture': capture_agrees,
        'expected_workplane_match': not differences,
        'expected_process_shape_match': shape,
        'protected_path_changes': protected_changes,
        'differences': differences,
        'actual_out_of_scope_committed_effect': bool(differences and protected_changes and committed),
        'verdict': 'PASS' if capture_agrees and not differences and shape else 'FAIL',
    }
    print(json.dumps(result, sort_keys=True, indent=2))
    return 0 if result['verdict'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
