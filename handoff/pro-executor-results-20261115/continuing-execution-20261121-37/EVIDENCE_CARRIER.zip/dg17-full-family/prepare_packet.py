#!/usr/bin/env python3
"""Static, bounded readiness checks; never invokes an original M09 consumer."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b')
REF = '51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    checks = []
    processes = []
    def require(value, name):
        if not value:
            raise ValueError(name)
        checks.append(name)
    def run(argv, label):
        p = subprocess.run(argv, capture_output=True, timeout=30)
        processes.append({'label': label, 'argv': argv, 'returncode': p.returncode,
                          'stdout': p.stdout.decode(), 'stderr': p.stderr.decode()})
        require(p.returncode == 0, label)
        return p.stdout.decode().strip()
    manifest = json.loads((ROOT / 'AUTHENTICATED_SOURCE_TREE.json').read_text())
    files = []
    for row in manifest['selected_entries']:
        path = ROOT / 'source' / row['path']
        data = path.read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        require(blob == row['sha'] and len(data) == row['size'], 'authenticated full source: ' + row['path'])
        files.append({'path': 'source/' + row['path'], 'bytes': len(data), 'git_blob': blob,
                      'sha256': digest(data)})
    actual_tree = run(['/usr/bin/git', '-C', str(REPO), 'rev-parse', REF + '^{tree}'], 'immutable baseline object availability')
    require(actual_tree == manifest['source_tree'], 'exact source tree')
    versions = {}
    for name, path in [('python', '/usr/bin/python3.13'), ('bash', '/usr/bin/bash'), ('git', '/usr/bin/git')]:
        actual = Path(path).resolve()
        versions[name] = {'selected_path': path, 'physical_path': str(actual),
                          'sha256': digest(actual.read_bytes()),
                          'version_output': run([path, '--version'], name + ' executable available')}
    for relative in ['run_m09.py', 'oracle.py', 'prepare_packet.py']:
        ast.parse((ROOT / relative).read_text(), filename=relative)
        checks.append('syntax only: ' + relative)
    for relative in ['apply-observed-mutation.sh', 'validate-phase.sh', 'validate-run-root.sh',
                     'claim-run.sh', 'check-evidence-anchor.sh', 'check-authorization-binding.sh']:
        path = ROOT / 'source/skills/implementaudit/scripts' / relative
        run(['/usr/bin/bash', '-n', str(path)], 'full shell syntax only: ' + relative)
        text = path.read_text()
        for i, body in enumerate(re.findall(r"<<'PY'\n(.*?)^PY$", text, re.M | re.S)):
            ast.parse(body, filename=relative + ':embedded-' + str(i))
        checks.append('embedded Python syntax only: ' + relative)
    ast.parse((ROOT / 'source/skills/implementaudit/scripts/read-canonical-pair.py').read_text())
    checks.append('full canonical pair reader syntax only')
    original = (ROOT / 'source/skills/implementaudit/scripts/validate-phase.sh').read_bytes()
    mutation = json.loads((ROOT / 'MUTATION.json').read_text())
    removed = mutation['exact_removed_line'].encode() + b'\n'
    mutant = (ROOT / 'mutant/validate-phase.sh').read_bytes()
    require(original.count(removed) == 1, 'sole guard occurrence')
    require(mutant == original.replace(removed, b'# M09 isolated mutation: the sole authority path-membership refusal is removed.\n'),
            'one exact guard removal; otherwise byte-identical full module')
    require(digest(mutant) == mutation['mutant_sha256'], 'frozen mutant digest')
    run(['/usr/bin/bash', '-n', str(ROOT / 'mutant/validate-phase.sh')], 'full mutant shell syntax only')
    witnesses = json.loads((ROOT / 'inputs/cases.json').read_text())['witnesses']
    require(len(witnesses) == 8 and len({c['id'] for c in witnesses}) == 8, 'eight distinct local witnesses')
    require(sum(c['mutation_target'] for c in witnesses) == 5, 'five actual-effect discrimination witnesses')
    for case in witnesses:
        phase = (ROOT / 'inputs/phases' / (case['id'] + '.md')).read_text()
        require(phase.count('RUN_ROOT_FROM_REAL_CLAIM') == 4, 'fixed phase substitutions: ' + case['id'])
        require('  mutation-authority: ' + json.dumps(case['operation'], separators=(',', ':')) in phase,
                'exact operation frozen in phase: ' + case['id'])
        require('Mutation scope: ' + json.dumps(case['scope'], separators=(',', ':')) in phase,
                'exact scope frozen in phase: ' + case['id'])
        require(all(bytes.fromhex(case['files'][p]['index_hex']) != bytes.fromhex(case['files'][p]['current_hex'])
                    for p in case['dirty_protected_files']), 'dirty preimages differ from staged user input: ' + case['id'])
    issue = (ROOT / 'evidence/ORIGINAL_ISSUE211.md').read_bytes()
    require(digest(issue) == 'ca62f4899a45544549f623a0312c16121bb99f432ccb87a87b7361974ceb94c4', 'immutable original issue body')
    require(not (ROOT / 'execution-01').exists(), 'zero original execution directories')
    seal_paths = {
        '/workspace/scratch/097486cde2dd/dg17-next/SEAL.json': '6877730cdb5c6469edef073464f64f4a0537c7aaf635aaf7f65c0dba863eaa82',
        '/workspace/scratch/097486cde2dd/dg17-m11/SEAL.json': 'a95dd1137f5035b0c9ef0c276c889412fd21c98e97b7626f4b5beb6516b89f11',
    }
    for path, expected in seal_paths.items():
        require(digest(Path(path).read_bytes()) == expected, 'prior stopped packet seal preserved: ' + path)
    result = {'schema': 'dg17.m09.static-preparation.v1', 'at': datetime.now(timezone.utc).isoformat(),
              'status': 'READY_FOR_INDEPENDENT_ELIGIBILITY_REVIEW', 'checks': checks, 'check_count': len(checks),
              'processes': processes, 'executables': versions, 'full_source_files': files,
              'original_consumer_executions': 0, 'original_witness_executions': 0,
              'mutant_witness_executions': 0, 'model_actors': 0, 'root_controller_mutations': 0,
              'source_product_behavior_executed': False, 'original_awards': [],
              'original_denominators': {'cases': 36, 'mutation_families': 14, 'terminal_clauses': 17}}
    (ROOT / 'PREPARATION_RESULT.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'check_count': len(checks), 'source_files': len(files),
                      'source_bytes': sum(f['bytes'] for f in files), 'original_executions': 0}))


if __name__ == '__main__':
    main()
