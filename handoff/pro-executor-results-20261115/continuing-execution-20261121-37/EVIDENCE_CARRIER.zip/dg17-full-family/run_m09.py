#!/usr/bin/env python3
"""Run only after Root's independent gate. No original executes by import."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SOURCE_COMMIT = '51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
SOURCE_TREE = '9c3913ceaa95f3f36b0377fe2dba4a302afcba89'
SOURCE_REPO = Path('/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b')
PYTHON = '/usr/bin/python3.13'
BASH = '/usr/bin/bash'
GIT = '/usr/bin/git'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


def verify_seal():
    seal = json.loads((ROOT / 'SEAL.json').read_text())
    for item in seal['files']:
        path = ROOT / item['path']
        if path.is_symlink() or not path.is_file():
            raise ValueError('sealed path is not a regular file: ' + item['path'])
        data = path.read_bytes()
        if len(data) != item['bytes'] or sha(data) != item['sha256']:
            raise ValueError('sealed file changed: ' + item['path'])
    return sha((ROOT / 'SEAL.json').read_bytes())


def observe_tree(root):
    rows = {}
    for path in sorted(root.rglob('*')):
        rel = path.relative_to(root)
        if rel.parts[0] in {'.git', '.IMPLEMENTAUDIT'}:
            continue
        st = path.lstat()
        if stat.S_ISREG(st.st_mode):
            data = path.read_bytes()
            rows[rel.as_posix()] = {'kind': 'regular', 'bytes': len(data), 'sha256': sha(data)}
        elif stat.S_ISLNK(st.st_mode):
            rows[rel.as_posix()] = {'kind': 'symlink', 'target': os.readlink(path)}
        elif not stat.S_ISDIR(st.st_mode):
            rows[rel.as_posix()] = {'kind': 'unsupported'}
    return rows


class Runner:
    def __init__(self, output):
        self.output = output
        (output / 'tmp').mkdir(parents=True)
        self.env = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
                    'TMPDIR': str(output / 'tmp'), 'PYTHONDONTWRITEBYTECODE': '1',
                    'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null',
                    'IMPLEMENTAUDIT_BASE': '.IMPLEMENTAUDIT/runs',
                    'IMPLEMENTAUDIT_PYTHON': PYTHON}
        self.sequence = 0

    def command(self, argv, cwd, label, must_succeed=False):
        self.sequence += 1
        place = self.output / 'processes' / f'{self.sequence:04d}-{label}'
        place.mkdir(parents=True)
        start = datetime.now(timezone.utc).isoformat()
        p = subprocess.Popen(argv, cwd=cwd, env=self.env, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, start_new_session=True)
        try:
            stdout, stderr = p.communicate(timeout=45)
        except subprocess.TimeoutExpired as e:
            os.killpg(p.pid, signal.SIGTERM)
            try:
                stdout, stderr = p.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGKILL)
                stdout, stderr = p.communicate(timeout=5)
            (place / 'stdout.bin').write_bytes(stdout)
            (place / 'stderr.bin').write_bytes(stderr)
            write_json(place / 'process.json', {'argv': argv, 'cwd': str(cwd),
                       'started': start, 'finished': datetime.now(timezone.utc).isoformat(),
                       'pid': p.pid, 'returncode': p.returncode, 'status': 'TIMEOUT_NO_RETRY'})
            raise RuntimeError('process timed out; no replacement permitted: ' + label) from e
        p.stdout, p.stderr = stdout, stderr
        (place / 'stdout.bin').write_bytes(stdout)
        (place / 'stderr.bin').write_bytes(stderr)
        record = {'argv': argv, 'cwd': str(cwd), 'started': start,
                  'finished': datetime.now(timezone.utc).isoformat(), 'returncode': p.returncode,
                  'pid': p.pid,
                  'stdout_bytes': len(p.stdout), 'stdout_sha256': sha(p.stdout),
                  'stderr_bytes': len(p.stderr), 'stderr_sha256': sha(p.stderr),
                  'capture_directory': str(place.relative_to(self.output))}
        write_json(place / 'process.json', record)
        if must_succeed and p.returncode:
            raise RuntimeError('required preparatory process refused; no retry: ' + label)
        return p, record

    def setup(self, case):
        subject = self.output / 'subjects' / case['id']
        subject.mkdir(parents=True)
        self.command([GIT, '-c', 'init.templateDir=', 'init', '--quiet', str(subject)],
                     self.output, case['id'] + '-git-init', True)
        common, _ = self.command([GIT, '-C', str(SOURCE_REPO), 'rev-parse', '--path-format=absolute', '--git-common-dir'],
                                 self.output, case['id'] + '-immutable-object-location', True)
        objects = Path(common.stdout.decode().strip()) / 'objects'
        (subject / '.git/objects/info/alternates').write_text(str(objects) + '\n')
        (subject / '.git/info/sparse-checkout').write_text('/README.md\n/dg17-work/\n')
        self.command([GIT, 'config', '--local', 'core.sparseCheckout', 'true'], subject,
                     case['id'] + '-sparse-config', True)
        self.command([GIT, 'config', '--local', 'core.sparseCheckoutCone', 'false'], subject,
                     case['id'] + '-sparse-cone-config', True)
        self.command([GIT, 'checkout', '--quiet', '--detach', SOURCE_COMMIT], subject,
                     case['id'] + '-existing-baseline-checkout', True)
        identity, _ = self.command([GIT, 'rev-parse', 'HEAD', 'HEAD^{tree}'], subject,
                                   case['id'] + '-baseline-identity', True)
        if identity.stdout.decode().splitlines() != [SOURCE_COMMIT, SOURCE_TREE]:
            raise ValueError('fixture baseline identity mismatch')
        refs, _ = self.command([GIT, 'for-each-ref', '--format=%(refname)', 'refs/implementaudit/'],
                              subject, case['id'] + '-no-controller-population', True)
        if refs.stdout:
            raise ValueError('ordinary fixture unexpectedly has controller authority')
        staged = []
        for name, values in case['files'].items():
            path = subject / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(bytes.fromhex(values.get('index_hex', values['current_hex'])))
            if 'index_hex' in values:
                staged.append(name)
        self.command([GIT, 'add', '--', *staged], subject, case['id'] + '-constructed-user-index', True)
        for name, values in case['files'].items():
            (subject / name).write_bytes(bytes.fromhex(values['current_hex']))
        if case['operation']['destination'] is not None:
            (subject / case['operation']['destination']).parent.mkdir(parents=True, exist_ok=True)
        claim, claim_record = self.command([BASH, str(ROOT / 'source/skills/implementaudit/scripts/claim-run.sh'),
                                           'm09-consumer-' + case['id']], subject,
                                          case['id'] + '-ordinary-claim', True)
        relative = claim.stdout.decode().strip()
        if '\n' in relative or not relative.startswith('.IMPLEMENTAUDIT/runs/'):
            raise ValueError('ordinary claimant returned an unexpected path')
        run = subject / relative
        if not run.is_dir() or (run / '.controller').exists():
            raise ValueError('ordinary claimed fixture custody mismatch')
        for name in ('STATE.md', 'PROTOCOL.md', 'ROADMAP.md', 'THINKING.md', 'sidecars.md', 'tools.md', 'context.md'):
            shutil.copyfile(ROOT / 'source/skills/implementaudit/templates' / name, run / name)
        (run / 'ROADMAP.md').write_text('# Constructed ordinary M09 fixture\n\n| Phase | Task |\n|---|---|\n| 1 | Apply the declared bounded cleanup request under its scope |\n')
        (run / 'STATE.md').write_text('# Constructed ordinary M09 fixture\n\nStatus: unexecuted\nController: absent; no currentness assertion\nRun root: ' + relative + '\n')
        (run / 'phases').mkdir()
        phase = (ROOT / 'inputs/phases' / (case['id'] + '.md')).read_text()
        if phase.count('RUN_ROOT_FROM_REAL_CLAIM') != 4:
            raise ValueError('unexpected run-root substitution population')
        (run / 'phases/phase-1.md').write_text(phase.replace('RUN_ROOT_FROM_REAL_CLAIM', relative))
        inputs = run / 'evidence/inputs'
        inputs.mkdir(parents=True)
        (inputs / 'preimage.bin').write_bytes(bytes.fromhex(case['preimage_hex']))
        if case.get('candidate_hex') is not None:
            (inputs / 'candidate.bin').write_bytes(bytes.fromhex(case['candidate_hex']))
        git_status, _ = self.command([GIT, 'status', '--porcelain=v1', '--untracked-files=all', '--', 'dg17-work'],
                                     subject, case['id'] + '-actual-dirty-premise', True)
        for name in case['dirty_protected_files']:
            if ('AM ' + name) not in git_status.stdout.decode().splitlines():
                raise ValueError('protected dirty-byte premise not observed: ' + name)
        frozen_input_manifest = {}
        for path in sorted(run.rglob('*')):
            if path.is_file():
                data = path.read_bytes()
                frozen_input_manifest[path.relative_to(run).as_posix()] = {'bytes': len(data), 'sha256': sha(data)}
        before = observe_tree(subject)
        snapshot = self.output / 'snapshots' / case['id']
        snapshot.parent.mkdir(exist_ok=True)
        shutil.copytree(subject, snapshot)
        write_json(self.output / 'fixture-inputs' / (case['id'] + '.json'),
                   {'subject_root': str(subject), 'run_relative': relative,
                    'created_by_actual_claim_process': claim_record,
                    'claim_and_phase_inputs': frozen_input_manifest,
                    'before_workplane': before, 'dirty_status': git_status.stdout.decode(),
                    'controller_population': [], 'native_currentness_claim': False})
        return subject, relative, before, frozen_input_manifest, snapshot

    def one(self, case, variant, fixture):
        subject, relative, before, frozen_input_manifest, snapshot = fixture
        if not subject.is_relative_to(self.output / 'subjects'):
            raise ValueError('refuse cleanup outside owned subject directory')
        shutil.rmtree(subject)
        shutil.copytree(snapshot, subject)
        run = subject / relative
        for name, record in frozen_input_manifest.items():
            data = (run / name).read_bytes()
            if len(data) != record['bytes'] or sha(data) != record['sha256']:
                raise ValueError('paired fixture input drift')
        if observe_tree(subject) != before:
            raise ValueError('paired workplane drift')
        package = self.output / 'packages' / variant
        command = [BASH, str(package / 'scripts/apply-observed-mutation.sh'), '--repo-root', str(subject),
                   '--run-root', relative, '--phase', '1', '--step', '1', '--preimage',
                   str(run / 'evidence/inputs/preimage.bin')]
        if case.get('candidate_hex') is not None:
            command += ['--candidate', str(run / 'evidence/inputs/candidate.bin')]
        completed, process = self.command(command, subject, variant + '-' + case['id'] + '-actual-helper')
        stdout = completed.stdout.decode('utf-8', errors='strict')
        stderr = completed.stderr.decode('utf-8', errors='strict')
        try:
            decoded = json.loads(stdout)
        except json.JSONDecodeError:
            decoded = None
        result_directory = self.output / 'observations' / variant / case['id']
        result_directory.mkdir(parents=True)
        observation = {'schema': 'dg17.m09.actual-consumer-observation.v1',
                       'case_id': case['id'], 'subject_root': str(subject),
                       'before_workplane': before, 'after_workplane': observe_tree(subject),
                       'helper': process, 'helper_stdout': stdout, 'helper_stderr': stderr,
                       'decoded_helper_result': decoded, 'native_or_model_claim': False}
        observation_path = result_directory / 'observation.json'
        write_json(observation_path, observation)
        canonical_observation = run / 'evidence/observation.json'
        write_json(canonical_observation, observation)
        oracle, oracle_process = self.command([PYTHON, '-I', '-B', str(ROOT / 'oracle.py'),
                       '--cases', str(ROOT / 'inputs/cases.json'), '--case-id', case['id'],
                       '--observation', relative + '/evidence/observation.json'], subject,
                       variant + '-' + case['id'] + '-separate-process-oracle')
        (run / 'evidence/oracle.json').write_bytes(oracle.stdout + oracle.stderr)
        verdict = json.loads(oracle.stdout)
        write_json(result_directory / 'oracle.json', verdict)
        write_json(result_directory / 'oracle-process.json', oracle_process)
        for rel in observation['after_workplane']:
            path = subject / rel
            target = result_directory / 'received-workplane' / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
        if (run / 'mutation-transactions').exists():
            shutil.copytree(run / 'mutation-transactions', result_directory / 'mutation-transactions')
        return verdict


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true', required=True)
    parser.add_argument('--root-approval-reference', required=True,
                        help='Records the actual Root gate; this string is not an authorization mechanism.')
    args = parser.parse_args()
    seal_sha = verify_seal()
    output = ROOT / 'execution-01'
    if output.exists():
        raise SystemExit('execution directory already exists; no replay, recovery or retry is automatic')
    output.mkdir()
    runner = Runner(output)
    write_json(output / 'EXECUTION_START.json', {'seal_sha256': seal_sha,
               'root_approval_reference': args.root_approval_reference,
               'original_family': 'M09', 'claim_ceiling': 'actual mechanical scope consumer only'})
    try:
        package_source = ROOT / 'source/skills/implementaudit'
        for variant in ('original', 'mutant'):
            target = output / 'packages' / variant
            shutil.copytree(package_source, target)
        shutil.copyfile(ROOT / 'mutant/validate-phase.sh', output / 'packages/mutant/scripts/validate-phase.sh')
        original_package = output / 'packages/original'
        mutant_package = output / 'packages/mutant'
        different = [p.relative_to(original_package).as_posix() for p in sorted(original_package.rglob('*'))
                     if p.is_file() and p.read_bytes() != (mutant_package / p.relative_to(original_package)).read_bytes()]
        if different != ['scripts/validate-phase.sh']:
            raise ValueError('sole mutation premise failed')
        cases = json.loads((ROOT / 'inputs/cases.json').read_text())['witnesses']
        fixtures = {case['id']: runner.setup(case) for case in cases}
        result = {'original': {}, 'mutant': {}}
        for variant in ('original', 'mutant'):
            for case in cases:
                verdict = runner.one(case, variant, fixtures[case['id']])
                result[variant][case['id']] = verdict
                if variant == 'original' and verdict['verdict'] != 'PASS':
                    write_json(output / 'BASELINE_FAILED_NO_MUTANT.json', result)
                    raise RuntimeError('original baseline failed; stop before mutant and do not tune oracle')
        expected_kills = [c['id'] for c in cases if c['mutation_target']]
        actual_kills = [c['id'] for c in cases
                        if result['mutant'][c['id']]['actual_out_of_scope_committed_effect']
                        and result['mutant'][c['id']]['live_post_state_matches_capture']]
        controls_pass = all(result['mutant'][c['id']]['verdict'] == 'PASS'
                            for c in cases if not c['mutation_target'])
        observed = ('OBSERVED_FULL_FAMILY_DISCRIMINATOR_PENDING_INDEPENDENT_RECEIVING'
                    if actual_kills == expected_kills and controls_pass else
                    'SURVIVED_OR_UNQUALIFIED_PRESERVE_ACTUAL_RESULT')
        write_json(output / 'RESULT.json', {'status': observed, 'sealed_packet_sha256': seal_sha,
                   'expected_effect_witnesses': expected_kills, 'actual_effect_witnesses': actual_kills,
                   'specificity_controls_pass': controls_pass, 'results': result,
                   'original_family_awarded': False, 'whole_DG17': False,
                   'original_denominators': {'cases': 36, 'mutation_families': 14, 'terminal_clauses': 17}})
        print(json.dumps({'status': observed, 'output': str(output), 'award': False}))
    except Exception as error:
        write_json(output / 'STOP.json', {'status': 'STOPPED_NO_AUTOMATIC_RETRY',
                   'type': type(error).__name__, 'reason': str(error), 'award': False})
        raise
    finally:
        files = []
        for path in sorted(output.rglob('*')):
            if path.is_file() and path.name != 'EXECUTION_MANIFEST.json':
                data = path.read_bytes()
                files.append({'path': path.relative_to(output).as_posix(), 'bytes': len(data), 'sha256': sha(data)})
        write_json(output / 'EXECUTION_MANIFEST.json', {'schema': 'dg17.m09.execution-manifest.v1',
                   'packet_seal_sha256': seal_sha, 'files': files, 'count': len(files)})


if __name__ == '__main__':
    main()
