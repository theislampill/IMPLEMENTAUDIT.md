# M09 complete-family eligibility packet — independent gate required

**Disposition proposed to Root: READY FOR INDEPENDENT ELIGIBILITY REVIEW, before original execution.**

This packet proposes the original M09 mutation family, **“5S unrelated-work protection”**, at the expressly permitted mechanical authority layer. It contains zero executed original witnesses, zero model actors and zero product behavior results. Root alone decides whether the frozen contract is eligible and whether later actual evidence earns an original award.

## Exact source and current delegation

The selected source is `theislampill/IMPLEMENTAUDIT.md` commit `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7`, tree `9c3913ceaa95f3f36b0377fe2dba4a302afcba89`. `AUTHENTICATED_SOURCE_TREE.json` retains exact entries from the previously received authenticated connected GitHub tree. Every copied full source file is checked against its Git blob and size, then SHA256-bound in the preparation result and seal.

Root bound resumed ordinary child work to current receipt `refs/implementaudit/continuity-receipts/dg16-dg18-recovery-20261119-b/G0042@a0dee5abe9e4ee81866cdf91d7568d25d35039a0`, natively reverified `c16290/0`, Root HEAD `6d9e145e2f2df5a0a8a150c85a4f3e2afd918d27`. This is child provenance only. No Root controller authority is delegated or exercised.

## Why this is a full M09 proposal

The immutable original Issue211 body is included, SHA256 `ca62f4899a45544549f623a0312c16121bb99f432ccb87a87b7361974ceb94c4`. Its L3 definition says touched code/evidence/state becomes legible and reproducible without unrelated cleanup (lines334–337). The coverage map requires reproducible touched state, user-work protection, and “task residue vs unrelated dirty file” (line525). The original mutation clause is the single property “5S unrelated-work protection” (line609); the terminal property again pairs residue and dirty-file protection (line715). Lines540–545 permit structural fixtures for authority predicates; lines616–619 reject keyword-only evidence and require renamed/unfamiliar discrimination.

The returned M09 census is also included. It records the earlier selected Seiri inversion as **SURVIVED**, with no award, and its earlier missing predicate as an “actual source-owned cleanup/authority scope consumer with unrelated-work preimages.” This packet supplies that specific existing consumer. It neither reruns nor changes the earlier model experiment, its actors, source policy, oracle or result.

M09 is a single non-target-protection property. The proposed complete conjunction is: authorized task residue can be removed or placed in order; unrelated dirty work remains exactly intact; an operation cannot acquire target or destination authority outside the declared scope; the same predicate discriminates renamed/unfamiliar inputs; removing that predicate alone causes an actual unauthorized effect while unrelated preimage safeguards survive. All of those conjuncts have frozen positive, negative or specificity witnesses here. A data-record check alone is insufficient: the actual full helper must perform the decisive effects.

This proposal does not discharge the whole L3 Smoke A/B sequence, all five 5S pillars, any model selection judgment, native L4 activation, M01/M03/M04, or an original case row. The eight local witnesses are one M09 family operation, not eight additions to the original case census. Denominators stay **36 cases / 14 mutation families / 17 terminal clauses**.

## Actual consumer and sole mutation

The full, unmodified `apply-observed-mutation.sh` CLI calls the full `validate-run-root.sh --claim-only`, then the full `validate-phase.sh --mutation-authority`. The phase validator calls the full canonical-pair reader. In a genuinely ordinary disposable Git worktree with no controller hint and no controller refs, that reader returns its real supported no-controller disposition; it is not stubbed or monkeypatched.

`validate-phase.sh` line102 rejects a source or move destination absent from `Mutation scope.in` or present in `Mutation scope.out`. Its digest-bound projection is the mutation helper's actual operation/source/destination authority. The helper takes no caller-provided replacement target, reads actual preimages, and performs filesystem operations with a journal and truthful terminal status. The request cannot bypass this consumer through a fixture callback.

The sole product mutation removes exactly that one refusal line. `MUTATION.diff` and `MUTATION.json` bind the full original and full mutated shell modules. All other product files and all surrounding validator checks remain byte-identical. The two runtime packages are materialized from the same frozen full source, and the runner refuses any difference other than `scripts/validate-phase.sh`. There is no extracted replacement function, injected scope oracle, synthetic native adapter, or altered classifier.

## Frozen witnesses and oracle

| Local witness | Original expected behavior | Mutant expected observation |
|---|---|---|
| `owned-residue-delete` | Delete the actual owned residue; preserve two dirty user files and the remaining work plane | Same valid cleanup |
| `foreign-source-delete` | Scope refusal before effects; protected dirty file survives | Actual protected dirty file deletion |
| `heldout-name-looks-disposable` | A renamed file whose name resembles debris remains protected because explicit exclusion wins | Actual deletion despite explicit exclusion |
| `heldout-opaque-replace` | An unfamiliar path absent from the allowlist remains byte-identical | Actual unauthorized byte replacement |
| `foreign-move-destination` | Refuse a cleanup move into an unowned destination before changing its source | Actual move creates the unauthorized destination |
| `explicitly-excluded-destination` | Explicit exclusion of a destination wins even when also listed in scope | Actual move into the excluded destination |
| `owned-residue-relocate` | Place owned residue at an authorized destination and preserve user work | Same valid relocation |
| `truncated-preimage-control` | Preserve the source and return the unchanged real preimage refusal | Same preimage refusal; no effect |

`inputs/cases.json` freezes all operation requests, exact constructed file bytes, scope lists, preimages, candidate bytes, protected paths, and expected edits. A staged initial user file is changed again in the working tree; actual `git status` must demonstrate the dirty `AM` premise. This is constructed work, explicitly not a captured human's personal data. `inputs/phases/` contains concrete prospective specs. Only the real freshly claimed run path is substituted, identically for both variants. Prospective transcript anchor strings are fixture syntax, not performed phases or closure assertions.

The oracle is a separate process authored in this engineering lane; it is **not an independent receiving agent**. It imports no product or driver and receives no variant name. It independently enumerates the live filesystem work plane, compares it with the fixed expected edits and protected paths, and checks the real producer return/status. The mutation kill requires a real `COMMITTED` result together with a live unauthorized protected-path effect. A parser error, timeout, unrelated refusal, status-word difference, or capture mismatch cannot qualify the kill.

For each witness the driver creates one real ordinary claim and freezes the complete claim/phase/input bytes plus pre-operation subject snapshot. Original and mutant run at the same owned absolute subject path restored from that exact snapshot. Their claim, phase, input and before-workplane hashes must match before each invocation. Source-package selection is their sole behavioral input difference. After each invocation the driver receives complete stdout/stderr, actual PID/argv/exit/time, live post-state, preserved work-plane bytes, and the helper journal when present.

## Resource and authority boundary

Every write is beneath this packet's future `execution-01/`. Subject repositories are disposable sparse worktrees with the already existing exact source commit; no new Git commit is created. Their object alternates read the historical repository's immutable object store. The source repository, its index, refs, worktree, Root run and all providers are read-only. Ordinary fixture refs are required to contain no implementaudit controller population. The test creates no controller, native currentness receipt, release, provenance, publication or external operation.

The environment is an explicit local Bash/Git/CPython environment, with global/system Git configuration disabled. Runtime template and script dependencies are already received in full. The exact existing source commit/tree and installed executable hashes are checked during static preparation. The source modules are never imported or called by preparation; syntax checks do not execute them.

The frozen runtime path is:

```bash
/usr/bin/python3.13 -I -B /workspace/scratch/097486cde2dd/dg17-full-family/run_m09.py --execute --root-approval-reference '<actual Root independent-readiness disposition>'
```

The final argument records the actual Root disposition; it does not manufacture authority or serve as a substitute gate. Do not run this command before Root authorizes the frozen packet after independent review.

## Acceptance, containment and receiving

1. Verify this seal and the exact source/sole-mutation premise before launch. Confirm independent full-family eligibility and Root authorization.
2. Execute every original witness once. All eight must satisfy the fixed oracle, including both real authorized cleanup controls and the unchanged preimage refusal. Any original failure stops the operation before the mutant and remains visible.
3. Execute the mutant against the identical inputs. All five protection witnesses must exhibit their specific actual unauthorized committed effect. Both authorized cleanup controls and the preimage specificity control must still pass. Otherwise preserve SURVIVED or UNQUALIFIED; do not tune the oracle or restore another guard to force the result.
4. Independently receive full process captures, actual file states, journals, the frozen oracle, exact source hashes, and `EXECUTION_MANIFEST.json`. Root alone adjudicates the original family. The driver's success-shaped result expressly remains pending independent receiving and awards nothing.

A failed or hung process is retained and its owned process group is contained. No replacement, retry, outcome-driven fixture revision or accepted-operation replay occurs automatically. If `execution-01/` already exists, a new launch refuses. The exact pre-operation snapshots are rollback custody for these disposable subjects only; no shared project cleanup is allowed. M10, M11 and P02 remain stopped and unexecuted; all previously accepted scopes are preserved.

The readiness question is narrow and decisive: does the real selected-source scope consumer, exercised through actual cleanup effects with this complete invariant/control set, satisfy original M09 at its permitted authority layer? If the independent reviewer identifies an additional original M09 conjunct, stop before execution and name it; do not award a partial family by label.
