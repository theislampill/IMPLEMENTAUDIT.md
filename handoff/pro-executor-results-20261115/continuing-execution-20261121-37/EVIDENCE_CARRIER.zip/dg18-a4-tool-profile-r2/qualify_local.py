#!/usr/bin/env python3
"""Actual local refusal/metadata checks; never a modeled Windows host."""
import ast
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

HERE=Path(__file__).resolve().parent
def main():
    path=HERE/'tool_profile.py'
    if not path.is_file():
        print(json.dumps({'status':'EXPECTED_RED','reason':'profile implementation absent'}))
        return 1
    ast.parse(path.read_bytes(),filename=str(path))
    spec=importlib.util.spec_from_file_location('profile_source_controls',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    with tempfile.TemporaryDirectory(prefix='actual-local-',dir=HERE) as tmp:
        root=Path(tmp);output=root/'must-not-exist'
        for step in ('profile','finalize'):
            p=subprocess.run([sys.executable,'-I','-B',str(path),'--step',step,'--output',str(output)],capture_output=True)
            if p.returncode==0 or output.exists() or b'actual Windows' not in p.stderr:
                raise AssertionError('non-Windows entry point did not refuse before output: '+step)
        actual=root/'regular.bin';actual.write_bytes(b'actual local metadata\n');os.link(actual,root/'second-name.bin')
        row=module.stat_snapshot(actual)
        if row['regular'] is not True or row['symlink'] is not False or row['fields']['st_nlink']!=2:
            raise AssertionError('regular type and hardlink count were collapsed')
        missing=module.stat_snapshot(root/'missing')
        if missing['status']!='ERROR' or missing['error']['type']!='FileNotFoundError':
            raise AssertionError('missing input was not retained as a distinct error')
        link=root/'symbolic';link.symlink_to(actual)
        linked=module.stat_snapshot(link)
        if linked['symlink'] is not True or linked['regular'] is not False:
            raise AssertionError('lstat followed the actual symbolic link')
    print(json.dumps({'status':'PASS','checks':['actual-non-Windows-profile-and-finalize-refusal-before-output',
        'actual-regular-hardlinked-file-separate-fields','actual-missing-path-error','actual-symlink-not-followed'],
        'platform':sys.platform,'python':sys.version,'Windows_operations':0,'mocked_host':False,
        'Git_product_Job_original_executions':0,'provider_writes':0},sort_keys=True,indent=2))
    return 0
if __name__=='__main__':raise SystemExit(main())
