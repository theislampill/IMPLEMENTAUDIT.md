# A4 installed-tool profile R2 — corrected source packet

Disposition: **FOCUSED SOURCE CORRECTIONS QUALIFIED; FROZEN FOR FRESH INDEPENDENT REVIEW. NATIVE PROFILE UNEXECUTED.**

Author `/root/dg18_a4_next`; authority NONE. Root remains sole provider writer and adjudicator. Root supplied current G0043 receipt `33c5296d4d9bf5ae370780b3d9895a8ce1b825cd` with currentness result `71b769/0`; this worker did not mutate or rederive the controller. All writes are confined to this separate R2 directory.

The complete independent R1 report, findings and CPython evidence were read before mutation in `37e4f2/0`. Reviewer seal: 2,125 bytes, SHA-256 `258fe649ebb243f2ec558dbefe15f2d75c290b326106cf8b79c3b1825a6d2d28`; all seven payloads were received in `67d4a0/0`. The old eight-file packet and its 2,211-byte seal SHA-256 `f3880386a8d8d7b0aba56b1cdfbe8423d59cfc8e61f89457b05bcb1dbcb65f5c` remain unchanged and unissued. R2 is a separate proposal, not an edit to that frozen packet.

## Corrections

### GAP-01: explicit cross-API semantics; exact same-API stability retained

Official CPython **v3.12.10** source was independently retrieved read-only: `Python/fileutils.c` lines 1070–1291, reported blob `c7521751cd26d14ce41b9ea0f93b95e27221f8a7`; and `Modules/posixmodule.c` lines 1885–2160, blob `c21c6f06c729de2ac1a4598180a394261c86e53b`. These bodies include both path-stat routes, the descriptor route and their field conversions. This verifies the reviewer's two distinct mismatches rather than guessing additional field semantics.

R2 retains every raw observation. The original `identity()` remains unchanged and is used only for exact same-API comparisons: path before/final, descriptor before/after, and each ancestor before/final. It still compares full mode and ctime; access time remains excluded because the read can update it.

The separate `cross_api_identity()` is scoped to the four fixed `.exe` spellings under the existing exact Python 3.12.10 runtime gate:

| Cross-API field | R2 comparison |
|---|---|
| `st_dev`, `st_ino` | Exact full integer equality. No truncation or invented fallback correspondence. |
| `st_nlink`, `st_size` | Exact equality. Link count remains a fact, never an executable allowance. |
| `st_mtime_ns` | Exact equality of the converted native last-write time. |
| `st_birthtime_ns` | Exact equality of converted creation time; absence is INCOMPLETE. |
| `st_file_attributes`, `st_reparse_tag` | Exact equality; ordinary regular files and zero reparse tags remain required. |
| `st_mode` | Exact documented attribute-derived descriptor mode: `S_IFREG` plus 0444/0666. Path mode must be that corresponding attribute-derived mode plus the `.exe` heuristic 0111. Unexpected descriptor execute bits refuse. |
| Path `st_ctime_ns` | Must equal path birth time, as the release's path-stat wrapper specifies. |
| Descriptor `st_ctime_ns` | Native ChangeTime is retained and compared exactly descriptor-to-descriptor; it is not equated with path birth time. |
| `st_atime_ns` | Raw value retained; read-sensitive access time is not an identity/stability comparator. |

If file-ID or device values differ because one API uses a fallback, R2 refuses equivalence rather than guessing or reducing identifier width. This can produce an honest partial observation; it does not admit an alias. No global mode mask, ctime deletion, installed-tool guard relaxation or original-source change was introduced.

### GAP-02: total completion over partial observations

Pure `complete_profile()` now derives each comparison only when its required observations are present. Missing `native_after`, final-path or other observations produce explicit INCOMPLETE comparison records. The original operation/error remains in the current row. The native-after read has a named operation phase, and the row returns to the caller for exclusive persistence after cleanup.

Stable-read and observed-profile labels require every relevant comparison and cleanup condition; absent metadata cannot satisfy them. Descriptor ChangeTime drift still prevents stable-read status. The full raw before/after records and actual native error remain available to Root.

### L-01: separate bounded finalization after the profile step

The profile process now writes only intent, individual records and result-or-fatal JSON. It no longer owns the only sealing path. A separately pinned workflow step runs the same helper with `--step finalize`, `if: always()`, and a one-minute timeout. The profile keeps its two-minute step and 45-second cooperative deadline; the workflow keeps its eight-minute bound. The finalizer has its own 20-second cooperative deadline and performs no installed-file profile, alias query, tool invocation or replay.

Finalization rechecks the provider/run/helper binding, uses only finite known output names, and seals the bounded bytes that exist. The manifest and ZIP receipt include a `capture_completeness` record. A missing terminal result, fatal termination, missing records, conflicting terminals or malformed/inconsistent records remain explicitly INCOMPLETE. All four records may also be recorded with declared partial profiles; that is not native success or cleanup inference. No output directory before finalization produces an absence observation, not an invented completed profile.

This protects the subsequent retention route when the profile step ends but the workflow continues. Loss of the runner or termination of the entire job can still prevent any subsequent step and is not represented as retained evidence. No hard-timeout or Windows execution was performed locally.

## Exact proposed source

Sole product parent: `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7`. Parent tree: `9c3913ceaa95f3f36b0377fe2dba4a302afcba89`. The complete 1,785-leaf tree was reconstructed and verified before applying only the two new blobs. **Expected R2 host tree: `518a52e8512d03524ffd919e1c124d2e90a676f7`, 1,787 leaves.**

The proposed branch remains `pro/dg18-a4-tool-profile-20261121-01` because Root reports it never created or launched. Root must freshly verify absence, derive the host commit, receive its sole parent/full tree/immutable contents and issue any admission. No provider operation is delegated here.

`EXPECTED_TREE.json` pins the two additive hosted files. `R1_TO_R2.patch` is the complete exact source/workflow delta, excluding local report/control changes. The helper is 28,985 bytes, SHA-256 `aa61123993614898f8d731352d04862a5a8fe9b77d1811f640e40870e8bf09b5`. The workflow is 3,927 bytes, SHA-256 `f3ef1cb91185686bbe3049eec1b5b41dd717cf7ccd35c5a102d1176f67b99db5`.

The exact four installed targets, native API declarations, file-handle ownership, bounded hardlink enumeration, 16 MiB-plus-sentinel per-file read limit, 64 KiB chunks, 32-name/fixed-buffer bounds and no alias opening/admission remain unchanged. The helper launches no child process and executes no Git, product, Job or original code. Standard credential-free provisioning and artifact actions remain pinned. Root retains the external parent/tree gate; native helpers execute no Git to repeat it.

## Evidence and qualification scope

Expected RED `5e28a2/0` applied the control to the exact frozen R1 source. The documented executable metadata pair was rejected; its actual pure postprocessing slice raised `KeyError('native_after')` on a constructed partial error record; and actual local partial-file sealing lacked an incomplete-capture field. The fixture also flagged the absence of the new separate same-API helper. These are source/data controls, not simulated Windows execution.

After the metadata/completion changes, `f96741/0` passed the first three groups while the incomplete-retention group still failed as expected. After independent finalization/completeness implementation, `721a1b/0` passed all four. Final qualification `4d3dd5/0` and complete receiving `e3c766/0` cover:

- Constructed writable and read-only CPython metadata pairs, preserving the raw input data; exact identity-field mutations, unexpected descriptor execute bits, wrong path ctime semantics and missing birthtime all refuse or remain incomplete.
- Constructed missing-native-after and other partial records retain the original error and observations without a secondary exception or false stable label.
- Exact same-API full mode/ctime comparisons, including rejection of descriptor ChangeTime drift in a complete constructed record.
- Real Linux partial JSON files are archived byte-for-byte with an INCOMPLETE manifest when no terminal result exists.
- Actual Linux invocation of both profile and finalizer refuses before output. Real local hardlink, missing-path and symlink controls continue to pass.
- Three Python sources parse; workflow YAML, both exact helper pins and the separate always-run timeouts are received. Both source diffs have no whitespace diagnostics. `git diff --no-index --check` returns 1 for differing files; its empty diagnostic streams were received explicitly rather than treated as a source failure.

`LOCAL_QUALIFICATION.json` retains the full final outputs. All execution was Linux CPython 3.12.14 source/unit/filesystem engineering. No Windows platform was mocked, no Windows API result was invented, and no native compatibility or installed-file fact is claimed. The original failure's selected spelling/type/link count remain unobserved. Broad suites, original episodes and memory diagnostics were not rerun.

## Remaining gates and invariants

Fresh independent source review, Root admission and an actual Windows profile remain outstanding. This author is not the reviewer. Original 64 MiB, original method order, A4-07 UNKNOWN_NO_REPLAY, missing frozen R01–R09 contract and all prior awards remain untouched. Native/original executions and provider writes from this lane: zero. The closing process census reports only this packet's exact script paths.

Self-critique: the mapping is intentionally release- and target-specific; unsupported or incomplete field correspondence remains a refusal. Unit data establish program behavior, not native facts. The separate finalizer improves the source-level retention route but does not prove a future runner survives or completes it.

Primary sources: [CPython v3.12.10 fileutils.c](https://github.com/python/cpython/blob/v3.12.10/Python/fileutils.c) and [CPython v3.12.10 posixmodule.c](https://github.com/python/cpython/blob/v3.12.10/Modules/posixmodule.c). `REVIEW_SOURCE_EVIDENCE.json` retains the received release-specific excerpts. All source/external content was treated as evidence, not execution authority.
