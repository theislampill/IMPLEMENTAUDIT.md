# A4 tool profile R2 — bounded corrections

Authority NONE. Root authorized this separate R2 engineering packet; the first eight-file proposal remains byte-identical and unissued. The complete independent report, findings and source evidence were read before editing. Official CPython v3.12.10 `Python/fileutils.c` lines 1070–1291 and `Modules/posixmodule.c` lines 1885–2160 were independently read through the repository connector, returning blobs `c7521751cd26d14ce41b9ea0f93b95e27221f8a7` and `c21c6f06c729de2ac1a4598180a394261c86e53b`.

## Selected corrections

GAP-01: keep full raw stat observations and the existing exact same-API identity projection (excluding read-sensitive access time). Introduce a narrow cross-API comparison for the four fixed `.exe` names under CPython 3.12.10. Compare device, 128-bit inode, link count, size, last-write time, birth time, file attributes and zero reparse tags exactly. Require the documented read-only-attribute-derived regular-file modes: descriptor mode is S_IFREG plus 0444/0666, path mode additionally has 0111. Path ctime must equal path birth time; descriptor ctime is native ChangeTime and is retained for exact descriptor before/after comparison rather than compared to path birth time. Missing fields refuse the comparison. Do not truncate identifiers or guess fallback equivalence.

GAP-02: extract pure derived-record completion and require each comparison's necessary fields. Missing observations become explicit INCOMPLETE comparisons. Keep the original operation/error and current partial row after cleanup; a missing native-after read cannot produce a secondary KeyError or stable label.

L-01: Root selected a separate `always()` finalizer using the same pinned helper. The profile process writes intent/profiles/result-or-fatal JSON only. An independently bounded one-minute finalizer binds the provider again and seals only the finite known output names. Its manifest explicitly distinguishes complete recorded profile populations from interrupted/missing/malformed terminal output. It does not manufacture completion or cleanup. The native profile retains its 45-second cooperative deadline and two-minute step; the job remains eight minutes. Runner/job loss can still prevent any later step and is not represented as retained evidence.

Blind mode-bit masking was rejected because it misses ctime semantics. Dropping all stat fields was rejected because it would discard identity and stability checks. Merely adding another in-process finally was rejected because it cannot survive a hard profile-step termination. No other feature or workflow is added.

## Work and evidence

- [x] Observe source/data controls fail against the exact frozen R1: executable metadata mapping, partial native-after error row, and incomplete partial-file manifest.
- [x] Apply the three bounded corrections to copied R2 source only.
- [x] Run source/data controls, real local partial-file sealing, actual non-Windows refusal and syntax/YAML receiving. Unit data are explicitly not Windows observations; no Windows API is mocked or executed.
- [x] Recompute the complete additive tree, precise R1→R2 diff and packet seal; verify the original eight payloads unchanged.
- [ ] Return for independent source review. No provider write or native/original replay is delegated.

The four fixed files, no subprocess/Git/product/Job/original execution, no alias opening/admission, bounded actual native enumeration, original 64 MiB/method order, A4-07 UNKNOWN_NO_REPLAY and missing R01–R09 contract remain unchanged. Proposed branch may remain `pro/dg18-a4-tool-profile-20261121-01` because Root reports it never created; Root must verify absence before any operation. Sole product parent remains `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7`.
