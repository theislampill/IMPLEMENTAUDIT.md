#!/usr/bin/env python3
"""Unit engineering data/error-path controls. No native Windows observations."""
import ast
import copy
import importlib.util
import json
from pathlib import Path
import sys
import tempfile

HERE=Path(__file__).resolve().parent
def load(path):
    spec=importlib.util.spec_from_file_location('profile_engineering',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def snapshots(module):
    fields={'st_mode':0o100777,'st_ino':0x10000000000000000001,'st_dev':55,'st_nlink':3,'st_size':7,
     'st_atime_ns':300,'st_mtime_ns':200,'st_ctime_ns':100,'st_birthtime_ns':100,
     'st_file_attributes':0x20,'st_reparse_tag':0}
    path={'path':module.TARGETS[0],'status':'OBSERVED','fields':fields,'regular':True,'directory':False,'symlink':False,'reparse':False}
    fd=copy.deepcopy(path);fd.pop('path');fd['fields']['st_mode']=0o100666;fd['fields']['st_ctime_ns']=400
    return path,fd
def old_completion(module,path):
    tree=ast.parse(path.read_bytes());function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='profile_one')
    start=next(i for i,n in enumerate(function.body) if isinstance(n,ast.If) and ast.unparse(n.test)=="'ancestors_before' in row")
    f=ast.FunctionDef(name='source_slice',args=ast.arguments(posonlyargs=[],args=[ast.arg(arg='row')],kwonlyargs=[],kw_defaults=[],defaults=[]),body=function.body[start:],decorator_list=[])
    unit=ast.fix_missing_locations(ast.Module(body=[f],type_ignores=[]));scope={'identity':module.identity}
    exec(compile(unit,str(path)+':pure-postprocessing-slice','exec'),scope);return scope['source_slice']
def main():
    path=Path(sys.argv[1]) if len(sys.argv)>1 else HERE/'tool_profile.py';m=load(path);out=[]
    def check(name,fn):
        try:fn();out.append({'name':name,'status':'PASS'})
        except Exception as exc:out.append({'name':name,'status':'FAIL','error':type(exc).__name__,'text':str(exc)})
    def cross():
        p,f=snapshots(m);before=copy.deepcopy((p,f))
        if hasattr(m,'cross_api_identity'):matched=m.cross_api_identity(p,f)['equal']
        else:matched=m.identity(p)==m.identity(f)
        if matched is not True:raise AssertionError('documented exe mode and birth/change-time pair refused')
        if (p,f)!=before:raise AssertionError('raw observations changed')
        readonly_p=copy.deepcopy(p);readonly_f=copy.deepcopy(f)
        readonly_p['fields'].update(st_file_attributes=0x21,st_mode=0o100555)
        readonly_f['fields'].update(st_file_attributes=0x21,st_mode=0o100444)
        if m.cross_api_identity(readonly_p,readonly_f)['equal']is not True:raise AssertionError('documented read-only mode map refused')
        for key in ('st_ino','st_dev','st_nlink','st_size','st_mtime_ns','st_birthtime_ns','st_file_attributes','st_reparse_tag'):
            changed=copy.deepcopy(f);changed['fields'][key]+=1
            if m.cross_api_identity(p,changed)['equal']is not False:raise AssertionError('identity drift admitted: '+key)
        changed=copy.deepcopy(f);changed['fields']['st_mode']|=0o111
        if m.cross_api_identity(p,changed)['equal']is not False:raise AssertionError('unexpected descriptor execute bits admitted')
        changed=copy.deepcopy(p);changed['fields']['st_ctime_ns']+=1
        if m.cross_api_identity(changed,f)['equal']is not False:raise AssertionError('unreviewed path ctime semantics admitted')
        changed=copy.deepcopy(f);del changed['fields']['st_birthtime_ns']
        if m.cross_api_identity(p,changed)['status']!='INCOMPLETE':raise AssertionError('missing birthtime was inferred')
    check('unit-reviewed-cross-API-map-and-drift-refusals',cross)
    def partial():
        p,f=snapshots(m);record={'status':'PARTIAL_METADATA_REFUSAL','path_before':p,'path_final':copy.deepcopy(p),
         'held_before':f,'held_after':copy.deepcopy(f),'native_before':{'file_index':1,'access_filetime':5},
         'handle_closed':True,'errors':[{'operation':'native_after','type':'OSError','winerror':5,'message':'UNIT_DATA_ONLY'}]}
        saved=copy.deepcopy(record)
        complete=m.complete_profile if hasattr(m,'complete_profile') else old_completion(m,path)
        returned=complete(record)
        if returned['errors']!=saved['errors'] or returned['held_after']!=saved['held_after']:
            raise AssertionError('actual-error-shaped unit data or observations lost')
        if returned['status']!='PARTIAL_METADATA_REFUSAL' or returned['comparisons']['native_handle']['status']!='INCOMPLETE':
            raise AssertionError('partial observations promoted')
        for keys in ((),('path_before',),('held_after',),('native_after',)):
            subset={k:copy.deepcopy(saved[k]) for k in keys if k in saved}
            subset.update(errors=[{'type':'UNIT_DATA_ONLY'}],status='PARTIAL_METADATA_REFUSAL')
            if complete(subset)['status']!='PARTIAL_METADATA_REFUSAL':raise AssertionError('incomplete row promoted')
    check('unit-partial-native-after-error-row-retained',partial)
    def stability():
        if not hasattr(m,'same_api_comparison'):raise AssertionError('separate same-API comparison absent')
        p,f=snapshots(m)
        for row in (p,f):
            if m.same_api_comparison(row,copy.deepcopy(row))['equal']is not True:raise AssertionError('equal same-API data refused')
            for key in ('st_mode','st_ctime_ns'):
                changed=copy.deepcopy(row);changed['fields'][key]+=1
                if m.same_api_comparison(row,changed)['equal']is not False:raise AssertionError('same-API stability relaxed: '+key)
        native={'file_attributes':32,'reparse':False,'volume_serial':55,'file_index':1,'file_bytes':7,
         'number_of_links':3,'creation_filetime':100,'access_filetime':300,'write_filetime':200}
        ancestor=copy.deepcopy(p);ancestor.update(path='C:\\Program Files',regular=False,directory=True)
        ancestor['fields'].update(st_mode=0o40777,st_ino=2,st_nlink=2,st_size=4096,st_file_attributes=0x10)
        whole={'path_before':p,'path_final':copy.deepcopy(p),'held_before':f,'held_after':copy.deepcopy(f),
         'ancestors_before':[ancestor],'ancestors_final':[copy.deepcopy(ancestor)],
         'native_before':native,'native_after':copy.deepcopy(native),'native_final_path_before':{'status':'OBSERVED','value':'UNIT_DATA_ONLY'},
         'native_final_path_after':{'status':'OBSERVED','value':'UNIT_DATA_ONLY'},'errors':[],'handle_closed':True,
         'hash':{'status':'EOF_OBSERVED','matches_held_size':True},'hardlinks':{'status':'COMPLETE','close_succeeded':True,'recorded_names':3}}
        if m.complete_profile(copy.deepcopy(whole))['status']!='FACTUAL_PROFILE_OBSERVED_NO_ADMISSION':
            raise AssertionError('complete consistent unit record never receives observed label')
        whole['held_after']['fields']['st_ctime_ns']+=1
        if m.complete_profile(whole)['stable_read_observed']is not False:raise AssertionError('descriptor ChangeTime drift was ignored')
    check('unit-full-same-API-mode-and-ctime-stability',stability)
    def retention():
        with tempfile.TemporaryDirectory(dir=HERE,prefix='partial-unit-') as tmp:
            root=Path(tmp);raw=b'{"unit_data_only": true}\n';(root/'PROFILE-01-INTENT.json').write_bytes(raw)
            m.seal(root)
            manifest=json.loads((root/'MANIFEST.json').read_text())
            if manifest['capture_completeness']['status']!='INCOMPLETE_NO_TERMINAL_RESULT':
                raise AssertionError('partial filesystem capture not explicitly incomplete')
            import zipfile
            with zipfile.ZipFile(root/'PROFILE_EVIDENCE.zip') as archive:
                if archive.read('PROFILE-01-INTENT.json')!=raw:raise AssertionError('real partial bytes changed')
    check('actual-local-partial-files-sealed-as-incomplete',retention)
    result={'schema':'dg18.a4.tool-profile-r2-unit-engineering.v1','status':'PASS' if all(x['status']=='PASS' for x in out) else 'FAIL',
      'checks':out,'scope':'Constructed metadata/error records and actual Linux filesystem retention; never Windows API observations',
      'native_Windows_API_calls':0,'mocked_Windows_host':False,'provider_writes':0,'original_runs':0}
    print(json.dumps(result,sort_keys=True,indent=2));return 0 if result['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
