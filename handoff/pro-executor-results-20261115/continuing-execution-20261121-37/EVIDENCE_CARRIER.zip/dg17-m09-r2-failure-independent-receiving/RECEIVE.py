#!/usr/bin/env python3
"""Read-only receiving of the exact retained M09 R2 setup failure."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import stat

PACKET = Path('/workspace/scratch/097486cde2dd/dg17-full-family-r2')
RUN = PACKET / 'execution-01'
ROOT = PACKET.parent / 'dg17-m09-root'
OUT = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
def receive_file(path, expected_bytes=None, expected_sha=None):
    assert stat.S_ISREG(path.lstat().st_mode) and not path.is_symlink()
    raw = path.read_bytes()
    if expected_bytes is not None: assert len(raw) == expected_bytes
    if expected_sha is not None: assert sha(raw) == expected_sha
    return raw, {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}

admission_raw, admission_identity = receive_file(ROOT / 'ROOT_EXECUTION_ADMISSION.json', 65202,
    '4221d4c7f73a2b89c4bac9f4851f8d79c1949936ddc9b341b0bda0970cfc31ef')
admission = json.loads(admission_raw)['gate']
native_raw, native_identity = receive_file(ROOT / 'NATIVE_EXECUTION_INITIAL.json')
native = json.loads(native_raw)
assert native['chunk_id'] == '52733a' and native['exit_code'] == 1
assert 'line 118, in setup' in native['output'] and 'FileNotFoundError' in native['output']
packet_raw, packet_identity = receive_file(PACKET / 'SEAL.json', 11903,
    'ee8a88f3ed2826ad2df0ad3f35c3682bb1a175504ad9e6300f41ef2283b47aa8')
packet_seal = json.loads(packet_raw)
for item in packet_seal['files']:
    receive_file(PACKET / item['path'], item['bytes'], item['sha256'])
assert len(packet_seal['files']) == 66 and sum(x['bytes'] for x in packet_seal['files']) == 1543412
outside = {p.relative_to(PACKET).as_posix() for p in PACKET.rglob('*') if p.is_file() and not p.is_relative_to(RUN)}
assert outside == {x['path'] for x in packet_seal['files']} | {'SEAL.json'}
manifest_raw, manifest_identity = receive_file(RUN / 'EXECUTION_MANIFEST.json', 8631,
    '4ac883a973496e3c86b90c47a72197066fc15aed65d6df213e0d9e6e1bb1e93f')
manifest = json.loads(manifest_raw)
assert manifest['packet_seal_sha256'] == packet_identity['sha256']
assert manifest['count'] == len(manifest['files']) == 47
names = [x['path'] for x in manifest['files']]
assert len(names) == len(set(names))
for item in manifest['files']:
    p = Path(item['path']); assert not p.is_absolute() and '..' not in p.parts
    receive_file(RUN / p, item['bytes'], item['sha256'])
actual = {p.relative_to(RUN).as_posix() for p in RUN.rglob('*') if p.is_file()}
assert actual == set(names) | {'EXECUTION_MANIFEST.json'}
assert not any(p.is_symlink() for p in RUN.rglob('*'))

start = json.loads((RUN / 'EXECUTION_START.json').read_bytes())
stop = json.loads((RUN / 'STOP.json').read_bytes())
assert start['seal_sha256'] == packet_identity['sha256']
assert start['root_approval_reference'] == str(ROOT / 'ROOT_EXECUTION_ADMISSION.json') + '@' + admission_identity['sha256']
assert admission['packet_seal_sha256'] == packet_identity['sha256']
assert admission['independent_review_seal_sha256'] == '38ccf098e86538e8fff7814c8747a85811e8d269acce3903e9209158c66bdbe5'
subject = RUN / 'subjects/owned-residue-delete'
assert stop['type'] == 'FileNotFoundError' and stop['status'] == 'STOPPED_NO_AUTOMATIC_RETRY' and stop['award'] is False
assert stop['reason'] == "[Errno 2] No such file or directory: '" + str(subject / '.git/info/sparse-checkout') + "'"
expected_argv = [
    ['/usr/bin/git', '-c', 'init.templateDir=', 'init', '--quiet', str(subject)],
    ['/usr/bin/git', '-C', '/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b', 'rev-parse', '--path-format=absolute', '--git-common-dir']]
captures = sorted((RUN / 'processes').glob('*/process.json'))
assert len(captures) == 2
processes = []
for path, argv in zip(captures, expected_argv):
    process = json.loads(path.read_bytes())
    assert process['argv'] == argv and process['returncode'] == 0
    assert process['cwd'] == str(RUN) and process['capture_directory'] == str(path.parent.relative_to(RUN))
    for stream in ('stdout', 'stderr'):
        receive_file(path.parent / (stream + '.bin'), process[stream + '_bytes'], process[stream + '_sha256'])
    processes.append(process)
assert processes[0]['stdout_bytes'] == processes[0]['stderr_bytes'] == processes[1]['stderr_bytes'] == 0
common = (captures[1].parent / 'stdout.bin').read_bytes()
assert common == b'/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b/.git\n'
assert (subject / '.git/objects/info/alternates').read_bytes() == common.rstrip(b'\n') + b'/objects\n'
assert not (subject / '.git/info').exists()
assert (subject / '.git/HEAD').read_bytes() == b'ref: refs/heads/master\n'
assert not (subject / '.git/index').exists()
assert not any(p.is_file() for p in (subject / '.git/refs').rglob('*'))
assert sorted(p.name for p in (RUN / 'subjects').iterdir()) == ['owned-residue-delete']
for name in ('observations', 'fixture-inputs', 'snapshots', 'RESULT.json', 'BASELINE_FAILED_NO_MUTANT.json'):
    assert not (RUN / name).exists()
assert not list((RUN / 'subjects').rglob('.claimed'))
assert not (subject / 'dg17-work').exists()
assert not (subject / '.IMPLEMENTAUDIT').exists()

for variant in ('original', 'mutant'):
    package = RUN / 'packages' / variant
    expected = {p.relative_to(PACKET / 'source/skills/implementaudit').as_posix(): p
                for p in (PACKET / 'source/skills/implementaudit').rglob('*') if p.is_file()}
    actual_files = {p.relative_to(package).as_posix() for p in package.rglob('*') if p.is_file()}
    assert actual_files == set(expected)
    for name, source in expected.items():
        selected = PACKET / 'mutant/validate-phase.sh' if variant == 'mutant' and name == 'scripts/validate-phase.sh' else source
        assert (package / name).read_bytes() == selected.read_bytes()

result = {'schema': 'dg17.m09.r2.independent-failure-receiving.v1', 'at': datetime.now(timezone.utc).isoformat(),
    'reviewer': '/root/independent_review', 'authority': 'NONE',
    'receiving': 'PASS_AUTHENTIC_SETUP_FAILURE', 'operation_status': 'FAILED_BEFORE_ORIGINAL_OR_MUTANT_CONSUMER',
    'admission': admission_identity, 'admission_gate': admission, 'native_execution': native_identity,
    'native_receipt': '52733a/1', 'packet_seal': packet_identity, 'packet_members': 66, 'packet_bytes': 1543412,
    'execution_manifest': manifest_identity, 'execution_members': 47,
    'execution_member_bytes': sum(x['bytes'] for x in manifest['files']), 'manifest_full_receiving': True,
    'start': start, 'stop': stop, 'processes': processes,
    'subject_nodes': [{'path': p.relative_to(subject).as_posix(), 'kind': 'directory' if p.is_dir() else 'regular'} for p in sorted(subject.rglob('*'))],
    'source_and_mutant_packages_exact': True, 'git_init_and_object_location_only': True,
    'fixture_claims': 0, 'original_consumer_operations': 0, 'mutant_consumer_operations': 0, 'oracle_calls': 0,
    'zero_operation_basis': 'Retained terminal traceback at setup line 118, exact two-child census, source order before claim and original loops, absent claim/input/snapshot/observation/transaction state',
    'process_group_absence_claim': False, 'currentness_received_from_root': 'G0043@33c5296d4d9bf5ae370780b3d9895a8ce1b825cd; 72f182/0',
    'reviewer_product_or_git_invocations': 0, 'reviewer_source_mutations': 0,
    'provider_controller_or_ref_writes': 0, 'original_awards': [],
    'original_denominators': {'cases': 36, 'mutation_families': 14, 'terminal_clauses': 17}}
(OUT / 'MECHANICAL_RECEIVING.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps({'receiving': result['receiving'], 'execution_members': result['execution_members'],
    'execution_member_bytes': result['execution_member_bytes'], 'process_captures': len(processes),
    'original_consumer_operations': 0, 'mutant_consumer_operations': 0, 'source_packet_unchanged': True}))
