#!/usr/bin/env python3
"""Focused R2 receiving. No product, original, mutant, help or oracle invocation."""
import ast
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

R1 = Path('/workspace/scratch/097486cde2dd/dg17-full-family')
R2 = Path('/workspace/scratch/097486cde2dd/dg17-full-family-r2')
OUT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b')
COMMIT = '51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
TREE = '9c3913ceaa95f3f36b0377fe2dba4a302afcba89'
def sha(b): return hashlib.sha256(b).hexdigest()
def record(p):
    b = p.read_bytes()
    return {'bytes': len(b), 'sha256': sha(b)}
def receive(root, seal_sha, seal_bytes, count, total):
    b = (root / 'SEAL.json').read_bytes()
    assert len(b) == seal_bytes and sha(b) == seal_sha
    seal = json.loads(b)
    assert len(seal['files']) == count and sum(x['bytes'] for x in seal['files']) == total
    names = [x['path'] for x in seal['files']]
    assert len(names) == len(set(names))
    for row in seal['files']:
        rel = Path(row['path'])
        assert not rel.is_absolute() and '..' not in rel.parts
        p = root / rel
        assert not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)
        assert record(p) == {k: row[k] for k in ('bytes', 'sha256')}
    assert {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()} == set(names) | {'SEAL.json'}
    assert not (root / 'execution-01').exists()
    return seal

s1 = receive(R1, 'bae9f2bdf377f6c524e131be928858ce8d9f4d71fb8868357984254f70f71245', 8522, 47, 1274368)
s2 = receive(R2, 'ee8a88f3ed2826ad2df0ad3f35c3682bb1a175504ad9e6300f41ef2283b47aa8', 11903, 66, 1543412)
assert (R2 / 'evidence/R1_SEAL.json').read_bytes() == (R1 / 'SEAL.json').read_bytes()
prior_review = R1.parent / 'dg17-m09-independent-review'
assert sha((prior_review / 'SEAL.json').read_bytes()) == '3116a27362548fed1e9900f8ee4cb3b04d7116b91d00a9e3b358774796a3c860'
for name in ('REPORT.md', 'MECHANICAL_RECEIVING.json', 'RECEIVE.py', 'SEAL.json'):
    assert (prior_review / name).read_bytes() == (R2 / 'evidence' / ('R1_REVIEW_' + name)).read_bytes()
for row in s1['files']:
    if row['path'].startswith('source/') or row['path'] in ('inputs/cases.json', 'MUTATION.json', 'MUTATION.diff', 'mutant/validate-phase.sh'):
        assert (R1 / row['path']).read_bytes() == (R2 / row['path']).read_bytes()
for path in (R1 / 'inputs/phases').glob('*.md'):
    assert (R2 / 'inputs/phases' / path.name).read_text() == path.read_text().replace(str(R1) + '/', str(R2) + '/')
runner1 = (R1 / 'run_m09.py').read_text()
runner2 = (R2 / 'run_m09.py').read_text()
assert runner2 == runner1.replace("                       'case_id': case['id'], 'subject_root': str(subject),\n",
    "                       'case_id': case['id'], 'subject_root': str(subject),\n                       'run_relative': relative,\n")

delta = json.loads((R2 / 'REVISION_DELTA.json').read_bytes())
excluded = set(delta['excluded_derivatives'])
actual_changes = []
for row in s2['files']:
    name = row['path']
    if name in excluded: continue
    old, new = R1 / name, R2 / name
    if old.exists() and old.read_bytes() == new.read_bytes(): continue
    before = record(old) if old.exists() else {'bytes': None, 'sha256': None}
    after = record(new)
    actual_changes.append({'path': name, 'change': 'modified' if old.exists() else 'added',
        'before_bytes': before['bytes'], 'before_sha256': before['sha256'],
        'after_bytes': after['bytes'], 'after_sha256': after['sha256']})
assert sorted(actual_changes, key=lambda x: x['path']) == sorted(delta['changes'], key=lambda x: x['path'])
patch = (R2 / 'REVISION_DIFF.patch').read_text()
patch_paths = [line[len('+++ R2/'):] for line in patch.splitlines() if line.startswith('+++ R2/')]
assert len(patch_paths) == len(set(patch_paths)) == 14
expected_patch_paths = {'AUTHENTICATED_SOURCE_TREE.json', 'READINESS.md', 'oracle.py', 'run_m09.py', 'prepare_packet.py',
    'source/skills/implementaudit/scripts/canonical_custody.py'} | {p.relative_to(R1).as_posix() for p in (R1 / 'inputs/phases').glob('*.md')}
assert set(patch_paths) == expected_patch_paths
rebuilt = ''
for name in patch_paths:
    before = (R1 / name).read_text().splitlines(keepends=True) if (R1 / name).exists() else []
    after = (R2 / name).read_text().splitlines(keepends=True)
    rebuilt += ''.join(difflib.unified_diff(before, after, fromfile='R1/' + name, tofile='R2/' + name))
assert patch == rebuilt

manifest = json.loads((R2 / 'AUTHENTICATED_SOURCE_TREE.json').read_bytes())
sources = manifest['selected_entries']
assert len(sources) == 23 and sum(x['size'] for x in sources) == 983360
prior_sources = {x['path']: x for x in json.loads((R1 / 'AUTHENTICATED_SOURCE_TREE.json').read_bytes())['selected_entries']}
for row in sources:
    b = (R2 / 'source' / row['path']).read_bytes()
    assert len(b) == row['size'] and hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest() == row['sha']
    if row['path'] in prior_sources: assert row == prior_sources[row['path']]
env = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_ALLOW_PROTOCOL='')
git_receipts = []
def git(*args):
    p = subprocess.run(['/usr/bin/git', '-C', str(REPO), *args], env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    assert p.returncode == 0 and not p.stderr
    git_receipts.append({'argv': p.args, 'returncode': p.returncode, 'stdout_bytes': len(p.stdout), 'stdout_sha256': sha(p.stdout), 'stderr_bytes': len(p.stderr)})
    return p.stdout
assert git('rev-parse', COMMIT + '^{tree}').decode().strip() == TREE
dep = 'skills/implementaudit/scripts/canonical_custody.py'
dep_blob = '434f8cb1579d3dfff2ba8a6fad91849f32ef927e'
assert git('ls-tree', '-l', COMMIT, '--', dep).decode().split()[:4] == ['100755', 'blob', dep_blob, '36367']
assert git('cat-file', 'blob', dep_blob) == (R2 / 'source' / dep).read_bytes()
dependency_ast = ast.parse((R2 / 'source' / dep).read_text())
imports = sorted({name.name.split('.')[0] for node in ast.walk(dependency_ast) if isinstance(node, ast.Import) for name in node.names}
                 | {node.module.split('.')[0] for node in ast.walk(dependency_ast) if isinstance(node, ast.ImportFrom)})
assert imports == ['__future__', 'contextlib', 'contextvars', 'ctypes', 'hashlib', 'msvcrt', 'os', 'pathlib', 're', 'stat', 'subprocess', 'threading', 'time', 'types']

help_result = json.loads((R2 / 'qualification/PRODUCT_HELP_RESULT.json').read_bytes())
assert help_result['argv'] == ['/usr/bin/python3.13', '-I', '-B', str(R2 / 'source/skills/implementaudit/scripts/read-canonical-pair.py'), '--help']
assert help_result['exit_code'] == 0 and help_result['source_before'] == help_result['source_after']
for name, digest in help_result['source_after'].items(): assert sha((R2 / name).read_bytes()) == digest
for stream in ('STDOUT', 'STDERR'):
    r = record(R2 / 'qualification' / ('PRODUCT_HELP_' + stream + '.raw'))
    assert r == {'bytes': help_result[stream.lower() + '_bytes'], 'sha256': help_result[stream.lower() + '_sha256']}
qualification = json.loads((R2 / 'qualification/ORACLE_QUALIFICATION.json').read_bytes())
assert qualification['count'] == len(qualification['checks']) == 35 and qualification['counterfactual_data_only'] is True
for field, name in [('oracle_sha256', 'oracle.py'), ('cases_sha256', 'inputs/cases.json'), ('declarations_sha256', 'MUTANT_EFFECT_PREDICATES.json')]:
    assert qualification[field] == sha((R2 / name).read_bytes())
cases = {c['id']: c for c in json.loads((R2 / 'inputs/cases.json').read_bytes())['witnesses']}
declarations = json.loads((R2 / 'MUTANT_EFFECT_PREDICATES.json').read_bytes())['witnesses']
assert len(declarations) == 5 and {x['id'] for x in declarations} == {k for k, v in cases.items() if v['mutation_target']}
for decl in declarations:
    case = cases[decl['id']]; op = case['operation']
    absent = [op['source']] if op['operation'] in ('move', 'delete') else []
    exact = {op['source']: case['candidate_hex']} if op['operation'] == 'replace' else ({op['destination']: case['preimage_hex']} if op['operation'] == 'move' else {})
    assert decl['absent_paths'] == absent and decl['exact_bytes_hex'] == exact
prepared = json.loads((R2 / 'PREPARATION_RESULT.json').read_bytes())
assert prepared['check_count'] == len(prepared['checks']) == 175

result = {'schema': 'dg17.m09.r2.independent-receiving.v1', 'at': datetime.now(timezone.utc).isoformat(),
    'reviewer': '/root/independent_review', 'authority': 'NONE', 'mechanical_receiving': 'PASS',
    'R1': {'seal': record(R1 / 'SEAL.json'), 'members': 47, 'bytes': 1274368, 'execution_directory_absent': True},
    'R2': {'seal': record(R2 / 'SEAL.json'), 'members': 66, 'bytes': 1543412, 'execution_directory_absent': True},
    'source_commit': COMMIT, 'source_tree': TREE, 'source_files': 23, 'source_bytes': 983360,
    'inherited_22_sources_unchanged': True, 'cases_unchanged': record(R2 / 'inputs/cases.json'),
    'sole_mutant_unchanged': record(R2 / 'mutant/validate-phase.sh'),
    'phase_changes': 'Only absolute packet oracle/case locator rebinding in all eight phases',
    'runner_change': 'Only added run_relative to observation',
    'exact_revision_inventory': actual_changes, 'exact_revision_diff_sections': patch_paths,
    'dependency': {'path': dep, 'git_blob': dep_blob, **record(R2 / 'source' / dep), 'ast_imports': imports},
    'git_receipts': git_receipts, 'git_environment': {'GIT_NO_LAZY_FETCH': '1', 'GIT_ALLOW_PROTOCOL': ''},
    'retained_help_result': help_result, 'retained_oracle_qualification': qualification,
    'exact_effect_declarations': declarations, 'retained_preparation_check_count': 175,
    'new_qualification_runs': 0, 'reviewer_product_imports_or_invocations': 0, 'original_or_mutant_operations': 0,
    'source_mutations': 0, 'provider_or_controller_or_ref_writes': 0, 'original_awards': [],
    'received_root_currentness': 'G0043@33c5296d4d9bf5ae370780b3d9895a8ce1b825cd; 71b769/0'}
(OUT / 'MECHANICAL_RECEIVING.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps({'mechanical_receiving': 'PASS', 'R2_members': 66, 'R2_bytes': 1543412, 'R1_exact': True,
                  'source_files': 23, 'source_bytes': 983360, 'revision_changes': len(actual_changes),
                  'exact_diff_sections': len(patch_paths), 'original_or_mutant_operations': 0}))
