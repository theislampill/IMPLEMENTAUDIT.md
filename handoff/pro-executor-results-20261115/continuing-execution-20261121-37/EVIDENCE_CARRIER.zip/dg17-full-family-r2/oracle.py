#!/usr/bin/env python3
"""Variant-blind M09 work-plane oracle; never imports the product or driver."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat


def workplane(root):
    result = {}
    for directory, dirs, files in os.walk(root, followlinks=False):
        relative = Path(directory).relative_to(root)
        if relative == Path('.'):
            dirs[:] = sorted(x for x in dirs if x not in {'.git', '.IMPLEMENTAUDIT'})
        else:
            dirs.sort()
        for name in sorted(files):
            path = Path(directory) / name
            key = path.relative_to(root).as_posix()
            info = path.lstat()
            if stat.S_ISREG(info.st_mode):
                body = path.read_bytes()
                result[key] = {'kind': 'regular', 'bytes': len(body),
                               'sha256': hashlib.sha256(body).hexdigest()}
            elif stat.S_ISLNK(info.st_mode):
                result[key] = {'kind': 'symlink', 'target': os.readlink(path)}
            else:
                result[key] = {'kind': 'unsupported'}
    return result


def file_record(data):
    return {'kind': 'regular', 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def declared_operation_post_state(case, before):
    """Exact effect from frozen request/data, independent of variant or scope guard."""
    op = case['operation']
    source, destination = op['source'], op['destination']
    preimage = file_record(bytes.fromhex(case['preimage_hex']))
    if before.get(source) != preimage:
        return None
    expected = dict(before)
    if op['operation'] == 'delete' and destination is None:
        del expected[source]
    elif op['operation'] == 'replace' and destination is None and case['candidate_hex'] is not None:
        expected[source] = file_record(bytes.fromhex(case['candidate_hex']))
    elif op['operation'] == 'move' and destination is not None and destination not in before:
        del expected[source]
        expected[destination] = preimage
    else:
        return None
    return expected


def exact_discriminator(case, before, actual, capture_agrees, successful_commit):
    expected = declared_operation_post_state(case, before)
    return bool(case['mutation_target'] and capture_agrees and successful_commit
                and expected is not None and actual == expected)


def successful_result_checks(case, observation, actual, root):
    """Receive successful shape, target identities and durable result; no product imports."""
    decoded = observation['decoded_helper_result']
    op = case['operation']
    checks = {'exit_zero': observation['helper']['returncode'] == 0,
              'successful_shape': False, 'exact_operation_identity': False,
              'exact_live_post_identities': False, 'exact_target_effect_receipts': False,
              'durable_result_consistent': False, 'retained_journal_consistent': False}
    if not isinstance(decoded, dict):
        return checks
    checks['successful_shape'] = (decoded.get('schema') == 'implementaudit.observation_bound_mutation.v2'
        and decoded.get('status') == 'COMMITTED' and decoded.get('reason_code') == 'NONE'
        and decoded.get('residue') == [])
    checks['exact_operation_identity'] = (decoded.get('operation') == op['operation']
        and decoded.get('source_path') == op['source'] and decoded.get('destination_path') == op['destination'])
    paths = [op['source']] + ([] if op['destination'] is None else [op['destination']])
    def projection(identity):
        if not isinstance(identity, dict):
            return None
        if identity.get('kind') == 'absent':
            return None
        if identity.get('kind') == 'regular':
            return {'kind': 'regular', 'bytes': identity.get('byte_length'), 'sha256': identity.get('sha256')}
        return {'kind': identity.get('kind')}
    rows = decoded.get('post_identities')
    if (isinstance(rows, list) and len(rows) == len(paths) and all(isinstance(r, dict) for r in rows)
            and [r.get('path') for r in rows] == paths):
        consistent = True
        for row in rows:
            name, identity = row['path'], row.get('identity')
            consistent = consistent and projection(identity) == actual.get(name)
            if actual.get(name) is None:
                consistent = consistent and identity == {'kind': 'absent'}
            elif isinstance(identity, dict):
                info = (root / name).lstat()
                consistent = consistent and identity.get('device') == info.st_dev and identity.get('inode') == info.st_ino and identity.get('link_count') == info.st_nlink
        checks['exact_live_post_identities'] = consistent
    effects = decoded.get('actual_effect_set')
    if isinstance(effects, list) and effects and all(isinstance(e, dict) for e in effects):
        ordered = all(e.get('sequence') == n and e.get('scope') == 'repo' and e.get('outcome') == 'applied'
                      for n, e in enumerate(effects, 1))
        for name in paths:
            observed = [e['after'] for e in effects if e.get('path') == name and isinstance(e.get('after'), dict)]
            ordered = ordered and bool(observed) and projection(observed[-1]) == actual.get(name)
        checks['exact_target_effect_receipts'] = ordered
    transaction = decoded.get('transaction_id', '')
    run_relative = observation.get('run_relative', '')
    if (not isinstance(transaction, str) or not re.fullmatch(r'[0-9a-f]{32}-p1-s1', transaction)
            or not isinstance(run_relative, str) or not re.fullmatch(r'\.IMPLEMENTAUDIT/runs/[a-z0-9][a-z0-9-]*-[A-Za-z0-9]{6}', run_relative)):
        return checks
    transaction_root = root / run_relative / 'mutation-transactions' / transaction
    try:
        saved = json.loads((transaction_root / 'result.json').read_text())
        fields = ('schema', 'transaction_id', 'claim_id', 'phase', 'step', 'authority_binding_sha256',
                  'coordination_scope', 'operation', 'status', 'reason_code', 'source_path', 'destination_path',
                  'pre_identities', 'candidate_identities', 'post_identities', 'planned_effect_set',
                  'planned_effect_set_sha256', 'residue')
        saved_effects = saved.get('actual_effect_set')
        checks['durable_result_consistent'] = (all(saved.get(k) == decoded.get(k) for k in fields)
            and isinstance(saved_effects, list) and bool(saved_effects)
            and isinstance(effects, list) and effects[:len(saved_effects)] == saved_effects)
        journal_path = transaction_root / 'journal.json'
        if not journal_path.exists():
            checks['retained_journal_consistent'] = True  # ordinary successful finalization removes its journal
        else:
            journal = json.loads(journal_path.read_text())
            journal_effects = journal.get('actual_effect_set')
            checks['retained_journal_consistent'] = (journal.get('transaction_id') == transaction
                and journal.get('status') == 'COMMITTED' and journal.get('residue') == []
                and journal.get('current_identities') == decoded.get('post_identities')
                and journal.get('planned_effect_set_sha256') == decoded.get('planned_effect_set_sha256')
                and journal.get('authority_sha256') == hashlib.sha256((transaction_root / 'authority.json').read_bytes()).hexdigest()
                and isinstance(journal_effects, list) and effects[:len(journal_effects)] == journal_effects)
    except (OSError, ValueError, TypeError, AttributeError):
        pass
    return checks


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--cases', required=True)
    parser.add_argument('--case-id', required=True)
    parser.add_argument('--observation', required=True)
    args = parser.parse_args()
    cases = json.loads(Path(args.cases).read_text())['witnesses']
    case = next(c for c in cases if c['id'] == args.case_id)
    observation = json.loads(Path(args.observation).read_text())
    root = Path(observation['subject_root'])
    actual = workplane(root)
    expected = dict(observation['before_workplane'])
    for path, new_hex in case['expected_workplane_edits'].items():
        if new_hex is None:
            expected.pop(path)
        else:
            data = bytes.fromhex(new_hex)
            expected[path] = {'kind': 'regular', 'bytes': len(data),
                              'sha256': hashlib.sha256(data).hexdigest()}
    paths = sorted(set(expected) | set(actual))
    differences = [{'path': p, 'expected': expected.get(p), 'actual': actual.get(p)}
                   for p in paths if expected.get(p) != actual.get(p)]
    protected_changes = [p for p in case['protected_paths']
                         if actual.get(p) != observation['before_workplane'].get(p)]
    capture_agrees = actual == observation['after_workplane']
    helper = observation['helper']
    decoded = observation['decoded_helper_result']
    success_checks = successful_result_checks(case, observation, actual, root)
    committed = all(success_checks.values())
    kind = case['expected_process_kind']
    if kind == 'scope-refusal':
        shape = (helper['returncode'] == 64 and decoded is None
                 and observation['helper_stdout'] == ''
                 and 'authority paths are outside Mutation scope' in observation['helper_stderr'])
    elif kind == 'preimage-refusal':
        shape = (helper['returncode'] == 64 and isinstance(decoded, dict)
                 and decoded.get('status') == 'REJECTED_NO_MUTATION'
                 and decoded.get('reason_code') == 'PREIMAGE_DRIFT'
                 and decoded.get('actual_effect_set') == [])
    else:
        shape = committed
    operation_post_state = declared_operation_post_state(case, observation['before_workplane'])
    exact_effect = exact_discriminator(case, observation['before_workplane'], actual, capture_agrees, committed)
    result = {
        'schema': 'dg17.m09.workplane-oracle.v2',
        'case_id': case['id'],
        'oracle_has_variant_input': False,
        'live_post_state_matches_capture': capture_agrees,
        'expected_workplane_match': not differences,
        'expected_process_shape_match': shape,
        'protected_path_changes': protected_changes,
        'differences': differences,
        'successful_result_checks': success_checks,
        'declared_operation_post_state_match': operation_post_state is not None and actual == operation_post_state,
        'actual_out_of_scope_committed_effect': exact_effect,
        'verdict': 'PASS' if capture_agrees and not differences and shape else 'FAIL',
    }
    print(json.dumps(result, sort_keys=True, indent=2))
    return 0 if result['verdict'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
