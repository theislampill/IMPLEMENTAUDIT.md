# R2 dependency closure and permitted source-loading qualification

This resolves M09-SR-H1 without modifying the canonical reader or its platform guard. The existing complete source files remain byte-identical to exact commit `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7`. Added sibling `canonical_custody.py` is 36,367 bytes, Git blob `434f8cb1579d3dfff2ba8a6fad91849f32ef927e`, SHA256 `d52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389`.

## Selected ordinary path

| Entry | Required source dependency and branch |
|---|---|
| Ordinary `claim-run.sh <slug>` | Full Bash owner. No controller/rotation argument is supplied. `rotation_io` and `claim-run-rotation.py` are not reached on this ordinary claim path. Seven canonical template files are copied afterward by the fixture driver. |
| Full `apply-observed-mutation.sh` | Its complete embedded Python body uses standard-library imports. It calls the full sibling `validate-run-root.sh --claim-only` and full sibling `validate-phase.sh --mutation-authority`. |
| `validate-run-root.sh --claim-only` | The selected early branch uses standard-library Python and real Git custody reads, then exits. The later full-run/closure/controller branches are not entered. |
| `validate-phase.sh --mutation-authority` | First invokes its own complete ordinary phase validator, then the full sibling `read-canonical-pair.py`. No scarce-resource budget or rehearsal row is present, so the authorization-rehearsal path is not selected; that sibling is nevertheless already present. |
| `read-canonical-pair.py` module loading | Lines24–50 unconditionally read, verify, compile and execute sibling `canonical_custody.py`. This precedes POSIX selection. Both complete files are now present. |
| `canonical_custody.py` module loading | Complete AST import inventory contains only standard-library imports; there are no further source-sibling loads, dynamic imports or external compiled-buffer loads. Top-level effects define ctypes structure classes and functions and construct one ContextVar. Windows kernel acquisition and filesystem/Git operations are inside functions/classes, not executed at module loading. The nested `msvcrt` import is in the Windows-only operational path and is not a POSIX loading dependency. |
| Reader's ordinary selection | After loading, the frozen fixture has no controller hint and no implementaudit refs. The reader performs real discovery and returns its existing supported disposition3. No stub or platform bypass is inserted. Controller-bound calls to the full claim owner are outside the fixture and would fail the driver's no-controller premise. |
| Mutation helper's operation | The supplied ordinary call requests no generation fence or batch. Its verification-window census is empty in the fresh fixture. `check-evidence-anchor.sh` is present but the per-window call is untriggered. The full selected delete/replace/move paths and result persistence are unchanged. |

This is the required closure for the frozen POSIX ordinary input path, not a new qualification of every Windows, batch, controller or protected route in the full files. No missing sibling is concealed by stubbing or changing imports. Unexpected controller or input state is a stop condition.

## Authorized read-only actual loading

Root explicitly permitted a bounded product-help/source-loading qualification after this static trace. The full reader's `main()` constructs argparse and calls `parse_args()` before calling `materialize_pair`. With `--help`, argparse exits0 before any run-root, claim, canonical selection or output snapshot operation. Before that early exit, the reader genuinely loads and pins the custody sibling; the custody module's top-level declarations do not call its Windows or Git operations.

The exact permitted command is `/usr/bin/python3.13 -I -B source/skills/implementaudit/scripts/read-canonical-pair.py --help` from this R2 directory. Full stdout, stderr, actual direct-process PID/exit, command and source hashes are retained as `qualification/PRODUCT_HELP_*`. This is actual product code loading. It is not an original case, mutation-authority invocation, mutation-helper operation, native-currentness proof, or model event. The R2 report must not describe all product code as unexecuted.

Process evidence remains direct-child capture plus the implemented timeout signaling. Neither this smoke nor the original runner demonstrates universal process-group absence or descendant cleanup.
