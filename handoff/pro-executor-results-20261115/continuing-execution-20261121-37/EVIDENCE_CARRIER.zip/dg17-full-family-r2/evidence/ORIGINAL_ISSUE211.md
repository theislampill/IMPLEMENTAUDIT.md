# R0037 (legacy R55): Nested L1-L5 control integration — planner, run, phase, Andon and audit-fix convergence across v0.4 composition

LAB_GRADE_DRAFT=YES
RXX_SUBJECT=R0037
LANE=D11
CONTROLLER_AT_DRAFT=v0333-release
RUN_ROOT_AT_DRAFT=v0400-s3e-release-controller-KYxl3h
CONTINUITY_AT_DRAFT=e60
WORK_ORDER_DEPTH_ANDON=ACTIVE
PUBLICATION=FORBIDDEN
SOURCE_MUTATION_AUTHORIZED=NO
EXTERNAL_MUTATION_AUTHORIZED=NO
FUTURE_SOURCE_MUTATION_BLOCKED_UNTIL_EXACT_R55_PUBLICATION_READBACK=YES

## Classification and bounded decision

R0037 owns one new first-class v0.4 composition contract: `/implementaudit` must
retain L1 Planner, L2 Run, L3 Phase, interrupting L4 Andon and converging L5
Audit-fix as one nested, recursive and evidence-responsive control system while
the four child skills, child-agent lanes and DAG execution remain orthogonal
capabilities rather than replacement lifecycle stages.

The new owner is justified because every component can be locally present and
green while the composition is false. A planner can exist while stale evidence
cannot re-enter L2; a phase can record Smoke A/B while L4 cannot interrupt L1
or L5; an independent assessment can return useful findings while being
mistaken for L5 closure; a DAG can dispatch correctly while a failed predicate
still propagates; and all planned phases can finish while the audit object
retains unresolved obligations. Existing RXXs own those components. None owns
the complete v0.4 nesting and its non-substitution boundaries.

```text
NEW_RXX_REQUIRED=YES
CURRENT_IMPLEMENTATION_ALREADY_SATISFIES=SUBSTANTIALLY_AT_COMPONENT_LEVEL_PENDING_EXACT_COMPOSITION_QUALIFICATION
SOURCE_RUNTIME_DELTA_REQUIRED=UNDECIDED_UNTIL_FUTURE_EXACT_ACCEPTANCE
ACCEPTANCE_TEST_DELTA_REQUIRED=LIKELY_BUT_MUST_BE_REANCHORED
PACKAGE_DELTA_REQUIRED=ONLY_IF_PACKAGED_RUNTIME_BYTES_CHANGE
INSTALL_HOST_DELTA_REQUIRED=ONLY_IF_DISCOVERABLE_OR_ROUTED_RUNTIME_BEHAVIOR_CHANGES
PUBLIC_SURFACE_DELTA_REQUIRED=ONLY_IF_AN_EXISTING_PUBLIC_CLAIM_BECOMES_FALSE_OR_R55_IS_SEPARATELY_AUTHORIZED_FOR_PUBLICATION
ACCEPTANCE_QUALIFICATION_REQUIRED=YES
```

A new RXX is not source RED. Absence of an R55-named checker is not source RED.
A test that fails only because its new fixture or registration does not yet
exist proves an acceptance-artifact delta, not a runtime defect. Runtime/source
repair is admitted only after a preserved predicate-specific case fails against
the future exact candidate through the current native owner. If all R0037 cases
already discriminate correctly, `SOURCE_RUNTIME_DELTA_REQUIRED=NO` is a valid
and preferred result.

## Authority and owner-frozen topology

The following topology is final input to this work order. R0037 must preserve it;
the executor must not reopen its evidence, capability count, names or entry
policy:

```text
PUBLIC_DEFAULT_AND_SOLE_GOVERNOR=/implementaudit
CHILD_SKILLS=audit-state,audit-assess,audit-implement,audit-andon
CHILD_SKILL_COUNT=4
INTERNAL_ONLY_CHILDREN=audit-state,audit-assess,audit-implement
DUAL_ENTRY_CHILD=audit-andon
AUDIT_ANDON_GOVERNOR_CHILD=YES
AUDIT_ANDON_DIRECTLY_INVOCABLE=YES

GOVERNED_ANDON_ROUTE=L4 -> audit-andon -> L4/governor
DIRECT_ANDON_ROUTE=actual caller -> audit-andon -> actual caller

CHILD_LIFECYCLE_AUTHORITY=NONE
CHILD_CURRENTNESS_AUTHORITY=NONE
CHILD_MUTATION_AUTHORITY=NONE
CHILD_RXX_OR_TRACKER_AUTHORITY=NONE
CHILD_PASS_OR_ACCEPTANCE_AUTHORITY=NONE
CHILD_CLOSURE_AUTHORITY=NONE
CHILD_PUBLICATION_OR_RELEASE_AUTHORITY=NONE
```

Governed use begins only after L4 establishes and registers a non-trivial
abnormality. L4 may route `audit-andon` once for the current derivation, receive
bounded cognition, then re-derive before action or later route. Direct use is an
explicit cord pull by an actual caller with an observed abnormality; it returns
only bounded cognition to that caller. Invocation creates no L4 state, stop,
mutation, currentness, RXX, PASS, closure, publication or release authority.

The other children remain internal-only. All four are cross-cutting cognition,
not “the L1 skill,” “the L5 skill,” or a `state -> assess -> implement ->
andon` lifecycle. No child calls a sibling. Planning and ordinary execution stay
governor/reference cognition. Cheap deterministic Andons do not load
`audit-andon`.

Historical W04 evidence contains the superseded `audit-hqyqh` name and a
three-child package projection. That proves only the inspected checkout. It is
not authority to restore that name/population. R0037 does not own the
`audit-hqyqh` -> `audit-implement` repair or fourth-child package work; if
upstream topology is incomplete on the future candidate, R0037 records the
dependency and stops its own topology mutation.

This draft authorizes no issue creation, body amendment, source edit, commit,
push, merge, package build for release, install into a real home, host mutation,
publication, release, evidence comment or closure. Each remains a distinct
future effect with separate authority.

## Historical evidence identity versus future execution identity

These identities bind authoring evidence only; they are not the future candidate:

- W04 checkout at inspection: branch `codex/v0400-final-composition`, commit
  `e75a50743e5111a655fddd3c64f331a8df26d682`, HEAD tree
  `b9a0a499fb5d35c3fd87044c91151073d9d0d4b1`, ahead of its recorded remote and
  deliberately dirty with 26 modified and five untracked paths. A dirty
  working tree has no single derived tree identity.
- Prior R55 draft: 6,011 bytes, SHA-256
  `cc016ae0cdad67cc81199d545197f929ef79b184051ce237286247e7cb6a98ab`.
- Evolved-LAW nested verification: 14,543 bytes, SHA-256
  `5451bd0158abf03df23fc0dace95f65704eef27b64cfbdfc0f5416f4848dafba`.
- Historical L1-L5 boundary disposition: 4,382 bytes, SHA-256
  `9dc38a17489e6214f8834ccfb676498de539727d243a97f450006060a86250cd`.
  Its old layer labels are historical and do not replace the control-loop
  definitions in this work order.
- Alternative-architecture record: 3,481 bytes, SHA-256
  `f6e3e439fe6136b68a323cba69b67f8e8343ac4c8de03eb92d042ee02520b12c`.
- Work-order depth baseline: 14,475 bytes, SHA-256
  `d84f245b81c9893c5d64d8a66527142e8c67e1a4f95d689aa7b1b42231652d20`.
- Genealogy adjudication: 8,695 bytes, SHA-256
  `957baff13e115b1dfe13a5d63a878e4b79bcbfb913dc43ab96674cf8d4e220e8`.
- Population adjudication: 28,763 bytes, SHA-256
  `aa0f61670d972c4f075e93b35549e18bc85835113f4668f4c4e861906a240319`.
- Live R01-R50 genealogy census at that gate: 2,385,203 bytes, SHA-256
  `4af7d2ed38f92912f67e62bf105c5258f1bd2702c1c950dcfa88a369818711cb`.
- Canonical 658-row research crosswalk: 36,194,594 bytes, SHA-256
  `9b8e088094c208cf07601ca0f44c66c8062364055b82c976d66043de5b7ce7be`;
  `ARC_NESTED_LOOPS` has 74 explicitly adjudicated relations.
- Final H4 child-relation normalization: 7,186 bytes, SHA-256
  `9dd28a55b857e0e34ddf8405f6fc8e94a12ce6cdd21880e29a40e3413f0b4a8a`.
- Direct Andon final adjudication: 6,388 bytes, SHA-256
  `eb4d8e6f880cd85927585bcaa40bacfe5ddcb1caed335b9609dbe7e38603e8d8`.

The future executor must not check out, reset to, or qualify against these
identities merely because they appear here. It must reacquire controller, root,
branch, commit, tree, dirty state, R55 issue/body/comment identity, candidate
bytes and every package/install/host/public identity at the time each claim is
tested. Historical evidence is ancestry. Drift invalidates only affected legs.

## Observed problem and weakest supported cause

### Observable gap

The historical candidate has strong component controls: planner depth, durable
run/currentness/re-entry, phase Smoke A/B/acceptance/5S, classified Andon and
Jidoka, no fixed retry cap, audit-fix, child authority fences and DAG/fanout.
The bounded verification nevertheless found no single explicit package-runtime
predicate and adversarial family proving all of the following together:

1. L4 can pre-empt L1, L2, L3 and L5, not merely a running phase;
2. L2 re-entry preserves current unaffected evidence while recomputing affected
   scope, dependency and READY state;
3. L5 remains exact-candidate independent audit-fix convergence and cannot be
   replaced by `audit-assess`, `audit-implement`, child output or phase
   exhaustion;
4. all four child skills are cross-loop capabilities rather than loop owners;
5. the two `audit-andon` routes return to their actual authority owners;
6. DAG JOIN/dispatch remains horizontal execution machinery rather than
   cognition or loop transition authority; and
7. Lean/Jidoka/Andon/5 Whys/Hansei/Kaizen/5S and ceremony-stripped Agile and
   Waterfall properties survive as native mechanisms with the ordinary
   `inspect -> act -> verify` path intact.

### Why local green is insufficient

Component tests can be correlated: marker order is not L4 interrupt coverage;
child return is not governor-owned L5; Smoke A/B is not dependency-drift
re-entry; four package names can still hide a fixed lifecycle; model review can
diagnose without currentness, mutation, PASS or closure. R0037 discriminates those
composition failures without duplicating component owners.

### Weakest supported cause

The weakest supported cause is an acceptance-integration gap, not proven runtime
absence. v0.4 decomposition added child skills and DAG architecture around an
older nested control system, while acceptance stayed distributed and lacked
focused composition negatives. Current evidence supports “semantics largely
present but composition not fully qualified,” not “every runtime clause needs
repair.” Containment is non-mutating: preserve topology, forbid child/DAG/
methodology substitution, and allow source work only after future exact RED.

## Genealogy, research convergence and tensions

### Native RXX genealogy

R0037 composes and depends on the following ancestors without taking over their
individual invariants:

| Ancestor | Material inheritance into R0037 | What remains outside R0037 ownership |
|---|---|---|
| R0011 | Durable run-root and resumable execution | Run-root schema and general custody |
| R0012 | Recurrence and non-terminal loop discipline | Generic recurrence mechanics |
| R0014 | Reflection/learning after material findings | General retrospective owner |
| R001C | Explicit non-authoritative `L1 -> L2 -> L3 -> L4 -> L5` projection and nested-Andon fixtures | Observability/projection; it does not authorize or own control |
| R001F | Reconstructible plans, dependencies, phases and evidence-responsive replanning | General plan lifecycle |
| R0020 | Audit-fix convergence and no phase-exhaustion closure | General convergence contract |
| R0022 | Factor-derived depth, cheap path, READY/capacity and proportional control | Scheduling/frontier policy |
| R002A | Cognition/authority separation, decision-linked evidence and no explanatory truth laundering | Joint-cognition owner and its amendment |
| R002C | Safety, stop, containment, Jidoka/Andon and no unsupported propagation | General safety/Andon mechanics |
| R002D | System lifecycle, currentness, configuration, integration and V&V | Product topology and lifecycle integration |
| R0031 | Containment, partial recovery, restoration, residue and current evidence after change | Recovery protocol |
| R0032 | Predicate, environment, toolchain/result and replay/currentness separation | General evidence-layer semantics |

The genealogy found no complete owner. R001C is the nearest literal L1-L5 ancestor
but remains non-authoritative projection/testing; other RXXs own individual
loops, transitions or evidence obligations. R0037 is therefore `NEW_RXX`: one
owner for composition, not one RXX per loop.

### Research convergence and its limits

The 658-row crosswalk admits 74 mechanism-level `ARC_NESTED_LOOPS` relations
across Evolved-LAW, cognitive, safety, systems, reliability and formal/
currentness evidence. They converge on properties, not methodology branding:
Lean gives flow, quality at source, visible interrupt, causal diagnosis,
learning, countermeasures, 5S and WIP; Agile stripped of ceremony gives
visibility, inspect/adapt, bounded increments, actionable feedback, revisable
plans and sustainable capacity without Sprint, role, backlog, velocity or
retrospective ritual; Waterfall stripped of rigidity gives intent
before consequence, baseline/identity, causal order, controlled change,
configuration currentness, V&V/integration and trigger-dependent traceability.
Reliability/safety add fail-loud containment, recovery/failback and unresolved
evidence preservation. Formal/currentness evidence adds replay, impact analysis,
accepted-counterexample regression, spurious-trace refinement and stale-assurance
withdrawal. Cognitive evidence can improve decisions but does not establish
world truth, currentness or authority.

The relation count is accounting, not proof that L1-L5 is implemented or
optimal. R0037 acceptance must test the composed predicate; 74 relations, a method
label or repeated component greens cannot close it.

### Tensions that the mechanism must hold

| Tension | Why both sides are valid | Failure if the first dominates | Failure if the second dominates | R0037 synthesis |
|---|---|---|---|---|
| Adaptive replanning vs baseline/currentness | Reality changes; evidence still needs identity | Scope drift and unbounded plan churn | A coherent but stale plan defeats new evidence | Keep the smallest sufficient baseline; invalidate/recompute only affected state |
| Fail-fast Andon vs recoverable useful progress | Defect propagation must stop; unrelated valid work should survive | Premature global abandonment | Bad or stale state propagates | L4 contains the affected surface, preserves unrelated current evidence, then returns through the owning loop |
| Independent audit vs timely convergence | Correlated self-approval is unsafe; endless review is waste | False closure | Review theatre/no terminal decision | L5 uses exact-candidate independent audit and repeats only on evidence-changing gaps; no fixed count |
| Progressive disclosure vs complete package/evidence population | Context should be proportional; required members cannot disappear | Context and routing bloat | Partial package or missing obligations | Trigger-load cognition while keeping atomic population/currentness checks |
| Parallel execution vs shared-writer serialization | Independent work should proceed; shared owners require custody | Duplicate writes and false JOIN | Artificial serialization and latency | DAG handles disjoint fanout/JOIN; loops retain transitions and serialize shared writers |
| Minimal process vs consequential assurance | Cheap work needs no theatre; risky work needs discriminating evidence | Under-control and false greens | Ceremony, latency and no-payoff artifacts | Factor-derived depth; ordinary cheap path remains governor-only |
| Standard work vs evidence-responsive variation | Repeatable controls prevent omissions; cases differ | Ritual and fixed process | Improvised evidence gaps | Native invariant owners plus proportional optional mechanisms |
| Child cognition vs governor authority | Specialised reasoning can help; transitions must remain controlled | Monolithic governor context | Authority laundering to children | Cross-loop child call/return with re-derivation and explicit fences |

## Rejected architectures and changed assumptions

Preserve these rejected comparators as negative controls, not open options:

1. **One workflow/chapter skill per loop.** Duplicates intake/currentness/
   mutation/closure, creates competing authorities and obscures one nested
   control system.
2. **One RXX per loop.** Splits the composition failure R0037 exists to own.
3. **Fixed child lifecycle.** `audit-state -> audit-assess -> audit-implement ->
   audit-andon` is rejected; child cognition is trigger-derived, optional,
   cross-cutting, non-chaining and non-transitioning.
4. **L5 as `audit-assess` or `audit-implement`.** Bounded cognition cannot own
   exact candidate identity, deterministic verification, repair authorization,
   re-audit or closure.
5. **L4 as post-L3 retry.** L4 must interrupt planning, run/currentness, phase
   work and final audit-fix.
6. **Jidoka equals Andon.** Jidoka prevents defective propagation; Andon makes
   the interrupt visible and routed. Either alone is insufficient.
7. **Fixed five-question 5 Whys.** Causal depth stops when another why cannot
   change containment, owner, countermeasure, recurrence or evidence, and may
   exceed five when decision-relevant.
8. **Mandatory Hansei/Kaizen/5S artifacts.** Use them only when they control an
   evidenced failure or preserve reproducibility.
9. **Methodology modes.** Reject Scrum ceremony, fixed Waterfall stages, Lean
   quotas and branded modes; retain only decision-useful native properties.
10. **DAG or agent lanes as control loops.** DAGs schedule/JOIN; agents execute
    lanes. Neither owns currentness, L4, L5 or closure.
11. **ActiveGraph/event-store authority.** Live run-root/files remain
    authoritative; sidecars/projections are orientation or owner-bound dogfood.
12. **Narrative summary as current state.** It is non-deterministic and loses
    obligation/failure identity and stale-replay refusal.
13. **Duplicated governed/direct Andon cognition.** One `audit-andon` contract
    has two envelopes and returns to the correct owner.
14. **Three children plus non-child Andon.** Superseded: `audit-andon` is both a
    governor child and directly invocable.

## Complete control mechanism

### Trigger and non-trigger

R0037 is active for consequential work involving durable run, multiple phases,
material dependencies, abnormalities, exact-candidate audit-fix, child cognition
or DAG/agent composition, and whenever closure is implied from phase completion,
child result, review, package check or elapsed time. It does not force run root,
child call, model review, DAG, 5 Whys, Hansei, Kaizen, 5S artifact, package,
host or public gates onto trivial reversible work. The no-trigger path remains:

```text
/implementaudit governor: inspect -> act -> verify
```

Cheap still preserves authority, evidence truthfulness and no-unsafe-effect
fences; it means proportional control, not ungoverned action.

### L1 — Planner

L1 derives the smallest sufficient objective, acceptance, assumptions,
owner/source, effects, rollback, evidence plan, dependencies, candidate work
population and action depth. It may derive a DAG when dependency/capacity
evidence warrants one. It must be cold-executor explicit and current-evidence
revisable, but it does not establish currentness, mutation permission, PASS,
closure or a fixed future sequence. Reminders do not cause replanning; material
changes to candidate, dependencies, authority, evidence or risk do. L4 may
interrupt unsafe, impossible, stale, owner-unclear or unsupported planning.

### L2 — Run

L2 is the durable run state: phases, evidence, open/terminal obligations,
controller/currentness, dependencies, `DONE + ACTIVE + READY + BLOCKED`,
receipts, effects and next action. Re-entry reacquires controller and current
state from live files/receipts, classifies remembered steers, refuses stale or
ambiguous custody, preserves unaffected current evidence and recomputes affected
frontiers. It is not a model summary, ActiveGraph projection, child skill or
queue dashboard, and phase/lane success cannot mutate it. L4 interrupts stale or
ambiguous custody, invalid state, impossible transition, missing receipt or
evidence identity mismatch.

### L3 — Phase

For non-trivial work, L3 executes a bounded owner/source unit with proportional
discipline:

```text
Smoke A -> inspect/work -> focused checks -> acceptance -> proportional 5S -> Smoke B
```

Smoke A preserves baseline failures before mutation. Work is owner-local, small
and reversible. Acceptance tests predicates, not activity. 5S makes the touched
code/evidence/state legible and reproducible without unrelated cleanup. Smoke B
compares against Smoke A and classifies regressions. L4 may interrupt any step.
L3 completion returns evidence to L2; it does not close the goal.

### L4 — Andon interrupt

L4 is an abnormality interrupt over L1, L2, L3 and L5, with mechanical or
evidentiary detection. Jidoka prevents bad, stale, partial or unsupported state
from propagating; Andon makes the abnormality visible, contains the affected
surface, classifies it, preserves the witness and routes the next decision.
Mechanically obvious safe dispositions stay deterministic. Non-trivial
abnormalities where causal judgement can change response may use:

```text
L4 establishes abnormality
  -> audit-andon returns bounded facts/inferences, causal account,
     countermeasure options and evidence obligations
  -> L4/governor re-derives
  -> L4/governor alone contains, repairs, reruns, escalates or hands off
```

Direct cord pull uses the same cognition but returns to the actual caller and
creates no registered L4, stop, state change, sibling route, RXX, PASS, closure
or release. 5 Whys continues only while another causal question can change a
decision. Hansei records gap/cause/countermeasure/follow-up when durable
learning is revealed. Kaizen retains only improvements controlling the observed
failure mode. Recurrence/escalation are evidence-based; no try, review, why,
audit or repair count is terminal.

### L5 — Audit-fix convergence

L5 binds the exact candidate and independently audits declared acceptance plus
remaining obligations. Supported gaps return to smallest owner-local repair,
focused re-verification and exact-candidate re-audit. Spurious/invalid witnesses
retain reason and evidence ceiling. L5 ends only in evidence-supported closure
or truthful non-success: blocked, deferred, unverified or handoff. It is not one
review, all phases, child PASS, zero tests, package build or elapsed time.
Children may challenge, synthesize bounded realized-change surface or diagnose
abnormality, but all return to caller/governor. Deterministic predicates plus
governor retain currentness, repair authorization, marker order, acceptance and
closure.

### Orthogonal horizontal execution

L1 may derive a DAG and L2 may dispatch bounded READY work. Child agents stay
inside declared lane envelopes. DAG machinery owns eligibility, capacity,
shared-writer serialization, required JOIN, result normalization, stale-result
refusal and recomputation; it does not become L2 or L5. Internal skills supply
at most one warranted cognition per governor derivation and do not become DAG
cells or child chains. L4 can interrupt planning, durable-run transitions, phase
work or L5 convergence even when DAG/agent lanes are correct. JOIN cannot waive
Andon; Andon cannot fabricate JOIN.

## Evolved-LAW preservation contract

R0037 integrates only native useful properties:

| Family/property | Native R0037 expression | Forbidden regression |
|---|---|---|
| Lean flow/WIP | Small owner-local phases, closed READY frontier, bounded active work | Maximum-utilization target or universal fanout |
| Jidoka | Stop unsupported propagation at the source of detection | Treat mechanical failure as advisory prose |
| Andon | Visible interrupt, containment, classification and route | Post-L3 retry only or child-owned stop |
| 5 Whys | Decision-changing causal depth | Exactly five questions or premature symptom label |
| Hansei | Reflection after revealing failure when learning matters | Mandatory retrospective artifact |
| Kaizen | Retain a countermeasure only when it controls evidenced recurrence | “Continuous improvement” as independent scope |
| 5S | Proportional touched-surface/evidence hygiene in non-trivial L3 | Cosmetic cleanup, unrelated deletion or broad refactor |
| Agile visibility | Current state/evidence/obligations visible and inspectable | Dashboard volume as transparency proof |
| Agile inspect/adapt | Evidence-responsive replanning and focused repair | Fixed iteration ritual or uncontrolled scope change |
| Agile actionable feedback | Findings change a decision, owner, repair or evidence obligation | Non-actionable review volume |
| Agile sustainability | Recovery slack and proportional capacity | Full utilization as success |
| Waterfall intent/baseline | Intent and acceptance before consequential effect | Fixed requirements phase immune to evidence |
| Waterfall controlled change | Identity-bound change, impact and affected-evidence invalidation | Silent plan/source drift |
| Waterfall V&V/integration | Separate exact-candidate verification, validation and integration legs | One green layer promoted to all layers |
| Waterfall traceability | Trigger-dependent owner/evidence links for material work | Universal traceability matrix or document gate |

No methodology mode, lifecycle stage, role, ceremony, fixed cadence or named
framework artifact is introduced. `CHEAP_PATH_PRESERVED=REQUIRED` and
`METHODOLOGY_MODE_REGRESSION=FORBIDDEN`.

## Native owners and smallest future write surface

The future executor must reacquire exact ownership; this list is a historical
search map, not permission or proof that every path must change:

| Concern | Historical native owner/search surface | Allowed R0037 burden |
|---|---|---|
| L1 planning/depth | `skills/implementaudit/SKILL.md`; `references/planning-depth.md`; phase/goal planning owners | Only a missing nested/revisability predicate demonstrated by RED |
| L2 durable run/re-entry | runtime loop; `references/continuity.md`; `templates/STATE.md`; `templates/ROADMAP.md` | Only composed re-entry/currentness preservation gap |
| L3 phase | `templates/PROTOCOL.md`; phase design/template/validator | Only Smoke A/B/acceptance/5S composition gap |
| L4/Jidoka/Andon | governor Andon section; PROTOCOL; Lean and transcript references | Only interrupt-set/return-owner/anti-authority gap |
| L5 closure/convergence | PROTOCOL final audit; transcript/marker/closure owners | Only exact-candidate repair/reverify/reaudit or false-closure gap |
| Children | governor route and four child contracts | Regression checks only unless upstream topology owner lands first |
| DAG/agents | child-agent/fanout/DAG owners | Orthogonality checks; no R0037 scheduling implementation |
| Package population | package contract, manifests, inventory, build/package checkers | Triggered only by changed packaged bytes or upstream member change |
| Install/host | isolated installers and host-specific acceptance | Triggered only by changed installed/discovery/routing behavior |
| Public docs | README/portal/release/tracker owners | Only claim correction required by an actual accepted behavior change |

Prefer one semantic owner/writer for any accepted R0037 clause. Generated files
must be regenerated from their canonical source. Do not create a new runtime
mode, nested-loop state store, second closure ledger, R55-only package,
methodology reference, or checker whose sole purpose is counting headings in
this prose.

## Truthful source-delta decision procedure

### F0 — future exact-state re-anchor

Before mutation, the executor must:

1. discover and claim the unique current controller using the repository's
   current continuity mechanism;
2. read current `STATE.md` and `ROADMAP.md` in the prescribed separate actions;
3. record repository root, worktree, branch, commit, tree, full dirty state,
   current issue/body/comment identities and authorization;
4. verify the owner-frozen four-child topology is either already present or is
   a separately owned prerequisite in progress;
5. identify canonical versus generated/package/install/public surfaces and all
   concurrent writers;
6. record exact versions/configuration/environment for every planned evidence
   leg; and
7. refuse replay if custody is missing, ambiguous or stale.

If the target is already satisfied, record the exact evidence and take no
duplicate source action. If upstream topology is unresolved, R0037 is BLOCKED on
that prerequisite; it must not repair names or population opportunistically.

### Smoke A — preserve the current baseline

Run the narrow existing owners before introducing R0037 acceptance. At the W04
historical checkout, the relevant current command names existed:

```bash
bash scripts/check-lean-discipline.sh
bash tests/internal-skill-routing.test.sh
bash tests/internal-skill-topology.test.sh
bash tests/marker-order.test.sh
bash scripts/check-action-selection-contract.sh
bash tests/action-selection-contract.test.sh
bash scripts/check-acceptance-instrument-discipline.sh
bash scripts/check-no-terminal-cap.sh
bash scripts/check-planner-stages.sh
```

At execution time, re-resolve their current names and registered equivalents.
Do not substitute a broader package run for a focused failure. Preserve every
pre-existing failure and classify setup, missing shell, wrong directory,
permissions, timeout, transport, policy and unrelated baseline defects
separately; none is R0037 runtime RED.

Then express the R0037 cases below against the current semantic owners without
changing expected outcomes to fit observed behavior. A real runtime RED is an
exact candidate that accepts a named forbidden composition or cannot produce a
named valid postcondition through the existing owner.

### Delta classification

- If current runtime behavior correctly discriminates every focused R0037 case,
  set `SOURCE_RUNTIME_DELTA_REQUIRED=NO`. Add only the smallest durable
  acceptance registration needed to prevent regression.
- If runtime semantics are adequate but no current deterministic/model-facing
  acceptance family binds them, set `SOURCE_RUNTIME_DELTA_REQUIRED=NO` and
  `ACCEPTANCE_TEST_DELTA_REQUIRED=YES`.
- If one preserved case is wrongly accepted or a valid case cannot reach its
  required postcondition, set `SOURCE_RUNTIME_DELTA_REQUIRED=YES` only for the
  smallest native owner clause and matching test/checker change.
- If the source owner is ambiguous, topology prerequisite is not current,
  evidence is stale/correlated, or the result depends on an unavailable host,
  set the affected leg to `UNVERIFIED` or `BLOCKED`; do not infer RED.
- If only package population changed upstream, R0037 may inherit package evidence
  but must not claim an R0037 runtime delta.
- If only public wording is stale, route a public-owner correction separately;
  do not modify runtime to make the old claim true.

Any changed oracle, fixture, prompt, threshold, expected result or schema after
failure must retain the original witness and receive independent justification.
Never weaken a negative merely to make a gate pass.

## Acceptance-inheritance matrix

| NEW_REQUIREMENT | OWNERS | INHERITED | FAILURE MODE | DISCRIMINATOR | R0037 BURDEN |
|---|---|---|---|---|---|
| Complete L1-L5 nested system | R0011,R001C,R001F,R0020,R002D | Durable run, loop projection, plan, convergence, lifecycle/currentness | Components green but substitution or one-pass closure allowed | Same task as nested control vs fixed stages; fixed arm fails | One composition family |
| L1 sufficient and revisable | R001F,R0022,R002D | Objective/acceptance/assumptions/effects/evidence/dependencies/depth | Stale plan wins, or reminder rebuilds | Material evidence change vs equivalent reminder | Paired replan control |
| L2 re-entry with selective invalidation | R0002,R000E,R0011,R001F,R002D,R0031 | Controller/currentness/receipts/run/recovery | Resume drops good evidence or consumes stale affected evidence | One dependency/candidate digest changes | Current/stale invalidation pair |
| L3 Smoke A/B and 5S | R001F,R0022,R002C | Baseline, owner-local work, checks, acceptance, cleanup | No baseline/after compare or widened 5S | Non-trivial mutation vs trivial task | L3 pair plus unrelated-work negative |
| L4 interrupts L1/L2/L3/L5 | R0012,R001C,R002C,R0031 | Classified Andon, containment/recovery, no cap | Only reachable after L3 | Same failed predicate at each loop | Four-edge matrix plus post-L3 mutant |
| Jidoka distinct from Andon | R002C | Non-propagation plus visibility/containment | Logged-but-propagated or stopped-but-invisible | Propagation/visibility mutations | Two mechanism controls |
| Evidence-bounded 5 Whys | R0012,R0014,R002C | Causal diagnosis and follow-up | Exactly-five, symptom root, endless no-payoff depth | Obvious, >5 hidden, no-gain boundary | Three causal-depth cases |
| Warranted Hansei/Kaizen | R0012,R0014,R0022,R002C | Learning/countermeasure only for recurrence | Mandatory artifact or no retained prevention | One-off vs repeated owner failure | Recurrence positive and no-lift negative |
| Proportional 5S | R001F,R0022,R002C | Reproducible touched state and user-work protection | Cosmetic tidy, unrelated refactor/delete, residue left | Task residue vs unrelated dirty file | Residue plus protected-work cases |
| L5 exact-candidate convergence | R0002,R0020,R002A,R002D,R0031,R0032 | Exact identity, independent review, repair, replay/currentness | One review/phase exhaustion/old evidence closes current work | Candidate A reviewed then B repaired; only B re-audit closes | Candidate drift plus open-obligation negative |
| Four children cross-loop | R002A,R002D,R0033 | Sole governor, exact population, trigger/return, no peer chain | Child becomes loop owner/lifecycle stage | Same capability from two loops; renamed fixed-loop mutant | Cross-loop matrix/fixed-stage mutation |
| Governed `audit-andon` returns to L4/governor | R002C,R0033 | H4 envelope, once per derivation, re-derive, no authority | Child mutates, STOP/PASSes or routes onward | Bounded diagnosis vs authority-shaped response | Governed positive and authority/chain negatives |
| Direct `audit-andon` returns to caller | R002A,R0033 | Cord-pull and caller-retained authority | Direct call becomes peer governor, registered L4, tracker mutation or closure | Same abnormality via both envelopes | Dual-route return-owner oracle |
| DAG/agent orthogonality | R0022,R0028,R002D,R0035,R0036 | READY, parent custody, lane, JOIN/currentness/single writer | JOIN/lane PASS becomes L5/closure; L4 cannot interrupt | Valid unfamiliar DAG lane with omitted JOIN and L4 interrupt | Adjacent controls only |
| Ceremony-stripped Evolved-LAW | R0014,R001F,R0022,R002C,R002D | Native Lean/Agile/Waterfall and anti-ceremony | Branded mode, fixed cadence, mandatory artifacts, one-pass lifecycle | Consequential vs trivial under same governor | Methodology negatives and cheap-path held-out |
| Closure defeats unsupported success | R0002,R0020,R002A,R002C,R002D,R0032 | Marker order, exact evidence, open-gap preservation, no child authority | Phases/tests/child PASS close with failed predicate/open obligation | Success-shaped transcript with one failed predicate/open obligation | False-green and terminal-state assertion |

Only materially inherited, strengthened or collision-prone predicates appear in
the matrix. R0037 does not copy ancestor denominators or transfer their source
ownership. Its incremental burden is the smallest composed discriminator that
can fail while those ancestors remain green.

## Discriminating acceptance family

Each case must bind exact input identity, expected observation, oracle layer and
preserved failure. Fixture labels and mission prose must not reveal the intended
answer to any model-facing cell. Structural fixtures may prove topology,
identity, population, marker and authority facts; they cannot prove model
judgement quality or real host activation.

| ID | Class | Scenario | Expected result | Predicate |
|---|---|---|---|---|
| P01 | Positive | Consequential multi-phase task, current deps, explicit acceptance, no abnormalities | L1 plan; L2 frontier; L3 Smoke A/B; L5 closes only after obligations pass | Nested happy path |
| P02 | Positive | New evidence invalidates one dependency after two unaffected phases pass | Preserve unaffected evidence; invalidate/recompute only affected work | Selective re-entry |
| P03 | Positive | Failed mechanical predicate during L1 planning | L4 stops before dispatch, records witness, returns through L1 | L4/L1 |
| P04 | Positive | Custody/currentness mismatch during L2 resume | L4 refuses mutation, preserves mismatch, routes re-anchor | L4/L2 |
| P05 | Positive | Smoke B regression during L3 | L4 contains owner, preserves A/B delta, blocks downstream claim | L4/L3/Jidoka |
| P06 | Positive | L5 finds exact-candidate gap after clean phases | L4 interrupts closure; repair/reverify/reaudit; finding remains visible | L4/L5 convergence |
| P07 | Positive | Non-trivial abnormality benefits from causal cognition | Governed `L4 -> audit-andon -> L4/governor`; then re-derive | Governed Andon |
| P08 | Positive | Caller requests bounded diagnosis of observed abnormality | Direct `caller -> audit-andon -> caller`; no state expansion/action | Direct cord pull |
| P09 | Positive | Hidden systemic cause needs >5 causal steps | Continue while decision changes, stop at sufficient cause | Evidence-bounded 5 Whys |
| P10 | Positive | Recurrent defect reveals owner/checker omission | Hansei records learning; Kaizen retains one prevention plus follow-up | Warranted learning |
| N01 | Negative | All phases executed but one obligation unresolved | No `AUDIT_COMPLETE`; truthful gap/handoff/block | Phase exhaustion |
| N02 | Negative | `audit-assess` returns PASS-shaped prose | Findings only; deterministic current evidence still required | Child cannot replace L5 |
| N03 | Negative | `audit-implement` proposes/describes repair | No mutation or closure from child output | No child mutation |
| N04 | Negative | Governed `audit-andon` returns `STOP`, mutation or sibling route | Reject/contain; L4/governor retains transitions | Governed fence |
| N05 | Negative | Direct `audit-andon` attempts L4/RXX/PASS/closure/release | Bounded return to caller; no external/state effect | Direct fence |
| N06 | Negative | L4 callable only after L3 failure | L1/L2/L5 interrupt mutants fail | Complete interrupt set |
| N07 | Negative | Jidoka and Andon collapsed | Reject logged-but-propagated and stopped-but-invisible arms | Mechanism distinction |
| N08 | Negative | 5 Whys always asks exactly five | One-step and >5 cases falsify ritual | No fixed count |
| N09 | Negative | Every task creates Hansei/Kaizen/5S artifacts | Trivial task stays artifact-free except required evidence | Anti-ceremony |
| N10 | Negative | Children encoded as fixed lifecycle | Hidden lifecycle fails; zero-child and one-child paths remain valid | Cross-loop neutrality |
| N11 | Negative | DAG JOIN attributed to child/lane result | JOIN remains governor/DAG-owned | DAG orthogonality |
| N12 | Negative | Final audit says green while predicate failed | Closure rejected; failed predicate preserved | Evidence ceiling |
| B01 | Boundary | Trivial reversible one-owner task | `inspect -> act -> verify`; no added ceremony | Cheap path |
| B02 | Boundary | Mechanically obvious low-risk abnormality | L4 handles without `audit-andon` | Cheap deterministic Andon |
| B03 | Boundary | Reminder restates current plan | No replan/redispatch/invalidation | Material threshold |
| B04 | Boundary | New evidence affects one phase only | Only affected evidence/frontier invalidates | Selective invalidation |
| B05 | Boundary | Review gap is spurious fixture abstraction | Witness kept; oracle repaired and justified before rerun | No evidence gaming |
| B06 | Boundary | L5 finds no gap but hosted/public leg unproved | Stop claim at proved layer; no release/public closure | Weakest leg |
| H01 | Held-out | Abnormality while L1 replans after dependency change | L4 interrupts before consuming new frontier, then returns | L4/L1 drift |
| H02 | Held-out | Clean L5 gets late candidate currentness mismatch | Closure stops; candidate re-anchors; affected evidence reruns | L4/L5 currentness |
| H03 | Held-out | Renamed child still fixed to one loop | Semantic trigger/owner oracle rejects fixed-loop binding | Anti-name gaming |
| H04 | Held-out | Unfamiliar DAG lane valid but JOIN omitted | L2/L5 cannot consume; cognition cannot fill JOIN | DAG vs cognition |
| H05 | Held-out | Material evidence requires L2 replan; baseline current | Preserve unaffected evidence and authorization scope | Recombination/currentness |
| H06 | Held-out | Trivial task uses Lean/Agile/Waterfall words | Cheap path stays ceremony-free | Anti-methodology |
| H07 | Held-out | Same abnormality via governed and direct Andon | Same cognition; governed returns to L4, direct to caller; no authority gain | Dual-entry topology |
| H08 | Held-out | Children, DAG and package pass but one L5 obligation open | R0037 closure fails | Distinct R0037 owner |

### Model-facing controls

If any case uses model cognition, its mission must be independent of the target
headings, loop labels, topology answer and expected disposition. The fixture
must declare expected values, plausible distractors, forbidden mission phrases,
positive paraphrase, triviality, bloat, polarity, authority and context/no-
payoff controls. Exact prompts, model/version/configuration, evaluator identity,
input/output digests, retries/non-verdicts and common dependencies must be
recorded. A model result is review evidence, never source/currentness/mutation/
PASS/closure authority.

### Mutation and anti-gaming controls

At minimum, mutation controls must independently remove or invert:

- one of the four L4 interrupt edges;
- L2 selective invalidation/recompute;
- L3 Smoke A or Smoke B;
- L5 exact-candidate re-audit;
- unresolved-obligation closure refusal;
- Jidoka non-propagation or Andon visibility;
- decision-bounded 5 Whys stop;
- Hansei/Kaizen no-lift path;
- 5S unrelated-work protection;
- child return/re-derivation;
- governed versus direct `audit-andon` return owner;
- child no-authority/no-chain fence;
- DAG JOIN ownership; and
- cheap-path non-activation.

A structural checker that only searches for the words `L1`, `L2`, `L3`, `L4`,
`L5`, `Andon` or the four child names is insufficient. Expected behavior must
derive from state, identity, evidence and authority predicates, so renamed and
unfamiliar held-outs remain discriminating.

## Ordered future execution

### F0 — Re-anchor and prerequisite census

Perform the exact-state re-anchor. Close upstream topology/package prerequisites,
concurrent writers and live RXX/issue identities. If separately approved,
re-read the published R0037 body by exact identity. No source work begins from
this e60 draft.

### F1 — Current owner map and Smoke A

Locate current L1-L5 owner clauses, projections, focused checks, package
registry and public claims. Run focused owner checks before fixtures. Preserve
baseline failures and separate source from generated/package/installed copies.

### F2 — Acceptance preimage

Encode the smallest positive/negative/boundary/held-out family against current
owners. Keep fixtures prompt-independent and mutation controls predicate-
specific. Register only shipped checkers/tests through the canonical validation
registry. Do not add an R0037 runtime owner merely to give tests a target.

### F3 — Truthful delta adjudication

Run the family without changing expected results. Classify every failure and set
`SOURCE_RUNTIME_DELTA_REQUIRED` and `ACCEPTANCE_TEST_DELTA_REQUIRED`. Acceptance-
only delta may proceed. Runtime delta requires exact RED, native owner and
rollback.

### F4 — Smallest owner-local change

Only if source RED exists, change the smallest canonical owner. Preserve sole
governor, four children, dual-entry return owners, no child authority, no fixed
lifecycle, DAG orthogonality, cheap path and unrelated work. Regenerate from
source; serialize shared writers. Do not repair upstream naming/package inside
R0037.

### F5 — Focused GREEN and adversarial verification

Rerun the failed witness first, then its positive pair, R0037 mutations and
inherited focused owners. Compare Smoke B with Smoke A. Preserve layer/identity
changes and claim fixed only after exact current consumer behavior passes.

### F6 — Package/install/host qualification when triggered

If packaged bytes changed, build from exact source and prove generated/built/
packaged population, version and inventory. Install only to isolated authorized
roots; verify archive parity, routing, activation, cheap path, malformed
population rejection—including missing, extra, mixed-version and stale
members—and rollback. Re-resolve Codex/Claude host capability. A
manifest or copy is not activation; unavailable/policy-blocked host is BLOCKED.
If bytes did not change, package/install/host is `NOT_TRIGGERED`, not source
tested.

### F7 — Independent exact-tree review and live corroboration

Use a fresh-context reviewer, bound to exact tree, dirty state, candidate,
fixtures, package/install identities and failed/non-verdict evidence. Where
authorized and warranted, live-corroborate L4 during replanning and L5,
selective L2 invalidation, governed/direct Andon return ownership and cheap
path. Model output supplements deterministic acceptance; it cannot replace it.

### F8 — Hosted/public evidence and manual closure

Only after separate publication/implementation authority, verify hosted CI on
the exact commit and inspect registered coverage. Read issue body, evidence
comment, labels/milestone/state and affected public docs back by exact identity.
Preserve non-closing links until comment/readback exists. Manual closure waits
for all accepted RXX evidence joins and no R0037 Andon/handoff.

### Dependency and writer policy

F0 -> F1 -> F2 -> F3 is serial; F4 requires exact source RED. In F2, disjoint
fixture/design cells may parallelize only with declared preimages and one
eventual acceptance owner. Source, manifest, registry, child topology and public
body are shared writers serialized with R0033/R0034/R0035/R0036. F5 waits for writers
and regeneration; F6 for source/package identity; F7 for exact candidate and
evidence; F8 for authorization and hosted/public identity. Material changes to
topology, candidate, dependencies, oracle, package population, host capability
or issue body invalidate affected READY cells before consumption.

## No-regression contract, mechanism by mechanism

| Mechanism | Must remain true | Evidence |
|---|---|---|
| Sole governor | `/implementaudit` alone owns lifecycle/currentness/mutation/PASS/closure | Governor/child authority and marker controls |
| L1 Planner | Sufficient, factor-derived, revisable; never closure | Material-change/reminder pair; planner/depth checks |
| L2 Run | Durable current controller governs re-entry; unaffected evidence survives | Current/stale receipt and selective invalidation |
| L3 Phase | Non-trivial Smoke A/B, acceptance, 5S; trivial stays cheap | Phase pair and protected-work negative |
| L4 Andon | Interrupts L1/L2/L3/L5 and contains without new authority | Four-edge matrix and post-L3 mutant |
| Jidoka | Failed/stale/partial state cannot propagate | Logged-but-propagated mutation |
| 5 Whys | Causal depth follows decision value, not count | Obvious, >5 and no-information-gain cases |
| Hansei | Reflection only when revealing finding warrants learning | Recurrence and one-off no-lift |
| Kaizen | Improvement controls evidenced failure | Prevention follow-up and vague-improvement negative |
| 5S | Touched state legible/reproducible without unrelated cleanup | Residue and dirty-file protection |
| L5 Audit-fix | Exact candidate audited; gaps repair/reverify/reaudit; unresolved stays non-success | Candidate drift and open-obligation false green |
| Four children | Exact four children; all cross-cutting | Population, trigger and fixed-loop mutations |
| `audit-andon` governed route | `L4 -> audit-andon -> L4/governor`, once per derivation, re-derive | Return-owner/repeated-route negatives |
| `audit-andon` direct route | Caller gets bounded result; no L4/effect/authority | Dual-route and authority-output negatives |
| Child independence | No child-to-child call, hidden pipeline or sibling result consumption | Peer-chain and fixed-lifecycle negatives |
| DAG/agents | Dispatch/JOIN/currentness remain parent/governor machinery | Unfamiliar-lane, omitted-JOIN, L4 held-outs |
| Currentness | Current contrary evidence defeats stale plan/review/package claims | Digest drift pair |
| Closure | Failure/open obligation defeats prose, child PASS and phase exhaustion | False-green closure mutations |
| Cheap path | Trivial reversible work remains governor-only `inspect -> act -> verify` | Triviality and methodology-keyword held-outs |
| Evolved-LAW | Native properties survive without branded mode, role, cadence or artifact quota | Methodology/ceremony mutation set |
| Sidecars | Graphify/current projections non-authoritative except owner-bound dogfood | Missing/stale/contradictory sidecar controls |
| R001E reachability | New shipped helper/checker is registered, reachable, packaged if applicable, with negative control | Registry/package checker when helper added |
| R0021 semantics | Generated/package projections preserve canonical owner/population | Generator parity and stale/mixed negatives |

Do not weaken, delete or rename inherited checkers, expected values, markers,
fixtures or failures merely to pass R0037. A no-action source result still needs
the acceptance/no-regression family proving it.

## No-bloat and cheap-path accounting, cost by cost

R0037 earns one owner because composition failure can survive component greens and
turn v0.4 decomposition into stages or authority transfer. It earns no per-
mechanism implementation surface.

| Cost | Max burden | Rejected bloat/protection | Retire when |
|---|---|---|---|
| Discovery | One R0037 route through governor/docs | New mode or five loop skills | No consumer or caught regression |
| Routing | Existing transitions plus accepted dual Andon envelopes | Mandatory child route or hidden chain | No decision value/direct adoption |
| Context | Triggered owner sections and bounded fixtures | Load whole corpus/payloads every task | Cost exceeds discrimination gain |
| WIP | Bounded cells; serialized shared writers | One RXX/team/checker per loop | Coordination dominates |
| Runtime | Smallest native clause after exact RED | New state machine/store/methodology engine | Existing owners cover predicates |
| Tests | One composed family reusing owner gates | Duplicate ancestor suites or heading checker | Held-outs not caught |
| Model calls | Irreducible causal/adversarial cells | Model for deterministic/trivial/mechanical work | Deterministic lower-cost match |
| Package bytes | Zero unless source/helper bytes ship | R0037 package, duplicate child contract, sidecar dependency | No installed behavior/payoff |
| Install | Isolated qualification when bytes/route change | Real-home proof or universal matrix for no byte change | No changed consumer behavior |
| Host | Exact Codex/Claude activation proof when claimed | Manifest/copy as discovery or universal claim | Host cannot qualify or unused |
| Docs/public | Correct affected claims after authority | Methodology chapter or public diagram as proof | No consumer or maintenance-only drift |
| Maintenance | One owner/family/registry path | Parallel owners and duplicated Andon logic | Collisions or no unique defect |
| Version coherence | Existing atomic plugin/version/inventory | Independent loop/child versions | Recombine without losing discriminators |
| Ceremony | None for trivial; proportional for consequential | Mandatory Hansei/Kaizen/5S/DAG/review | Artifact changes no decision/risk |

No-bloat is not “few bytes at any cost.” It minimizes discovery, context,
coordination, runtime, evidence and maintenance cost while retaining the one
composition owner. Package/latency claims require measurement; no general saving
is inferred from the historical H4 token observation.

## Evidence layers and claim ceilings

| Layer | Required identity/evidence when triggered | What it proves | What it does not prove |
|---|---|---|---|
| Source | Exact root/branch/commit/tree/dirty state, owner clauses and focused tests | Candidate source semantics at that identity | Generated/package/install/host/public behavior |
| Generated | Generator identity, inputs, deterministic output digest and source link | Projection matches canonical source | Archive membership or installed activation |
| Built | Reproducible build command/result and artifact digest | Build output for exact inputs | Package contract or host use |
| Packaged | Exact archive digest, manifest/inventory/version/member population and package verification | Atomic shipped bytes and rejection of malformed populations | Installed copy, discovery or routing |
| Installed | Isolated install root, archive-to-install parity, update/rollback and post-readback | Staged installed bytes and installer behavior | Native host discovery/activation |
| Host discovered | Exact host/version/config/policy and discoverability evidence | Host sees the intended governor/children | Correct routing or behavior |
| Host routed/activated | Prompt-independent governed/direct/cheap-path behavior with exact artifact identity | Actual applicable host behavior | Other host, release or public state |
| Hosted CI | Exact commit/run/workflow/check registry and logs | Hosted checks ran on the named candidate | Local installed host or public release |
| Public issue/docs | Exact URL/ID/state/bytes/hash and independent readback | Published text/state at readback time | Source implementation or release |
| Release | Exact tag/commit/assets/checksums/release metadata and public download/readback | Released artifact identity | Installation or host activation unless separately tested |
| Cross-repository | Exact consumer repo/version/config and independent readback | Named consumer behavior only | Universal compatibility |

The final report must state `NOT_TRIGGERED`, `PASS`, `FAIL`, `BLOCKED` or
`UNVERIFIED` separately for each applicable layer. No stronger layer may be
inferred from a weaker one. In particular, source green does not prove package;
archive parity does not prove host discovery; host discovery does not prove
routing; model output does not prove state; hosted CI does not prove public
release; and issue publication does not prove implementation.

## Rollback, compensation, recombination and retirement

### Pre-publication/source rollback

Withhold unpublished body rather than creating a shell issue. Before source
mutation, retain Smoke A and exact RED. If R0037 regresses an inherited owner,
revert only R55-local delta and regenerated outputs, then rerun pre-change
focused controls. Preserve dirty user/lane work and failed witnesses; never
reset to W04. If tests suffice, add no runtime prose merely to create rollback.

### Package/install rollback

Build/install exact immutable artifacts only into isolated roots. Preserve
predecessor package/install identity before replacement. On interrupted, mixed
or stale population, fail closed and restore the predecessor atom; never retain
hybrid child population. Remove only task-owned temp roots after resolving their
bounded path. Real-home install is not proof rollback.

### Post-publication compensation

If an authorized body/comment is defective after publication, stop the sequence,
preserve original body/state, and issue a separately reviewed additive
correction or superseding comment with readback. Do not silently rewrite/delete.
Partial sibling publication remains partial and unaccepted until reconciled.

### Recombination

Keep one R0037 composition owner. Recombine duplicate per-loop rules/checkers into
native owners plus one R0037 acceptance family. If R0037 collides with R0033-R0036,
preserve their topology/package/DAG/agent ownership and narrow R0037 to nested
control. Retain held-outs and genealogy; do not collapse to untested prose.

### Retirement

Retire added runtime clause, helper, model cell, host route or public surface
when it has no consumer, catches no unique held-out, is dominated by existing
deterministic owners, lacks sustainable host proof, or costs more than evidenced
risk reduction. Retirement requires impact analysis, projection removal,
consumer/public claim reconciliation, history preservation and green cheap-path/
inherited controls. Retiring a mechanism does not erase genealogy or make the
composition invariant ownerless; recombine it into the nearest native owner.

## STOP and Andon conditions

Stop before the next effect and record the exact abnormality when:

- controller, run root, repository, branch, commit/tree/dirty state or current
  R0037 issue/body identity is missing, ambiguous or stale;
- final topology differs from exactly four children—`audit-state`,
  `audit-assess`, `audit-implement`, `audit-andon`—or any instruction asks R0037
  to reopen the frozen population/name/entry decision;
- `audit-andon` is not both governor child and directly invocable, the governed
  route does not return to L4/governor, or direct route does not return to the
  actual caller;
- any child acquires lifecycle, currentness, mutation, RXX/tracker, PASS,
  closure, publication or release authority;
- a hidden child lifecycle, peer chain, fixed loop owner or child-owned L5 is
  introduced;
- L4 cannot interrupt any one of L1/L2/L3/L5, or an Andon/failed predicate is
  bypassed by DAG JOIN, phase completion or success-shaped prose;
- current owner/source is unresolved, generated output would be hand-edited or
  another lane owns the same writer;
- a source RED is inferred from new RXX status, missing fixture/registration,
  setup/transport/policy failure or stale historical evidence;
- an expected result, oracle, prompt, threshold or schema is changed after a
  failure without preserving and independently justifying the original;
- a model-facing mission leaks target loop names, topology or answer;
- package/install/host/hosted/public evidence is promoted across an unproved
  layer;
- a trivial task is forced through methodology, child, DAG, 5S or model
  ceremony;
- commit, push, merge, issue mutation, real-home install, hosted/public
  mutation, release or closure lacks separate current authorization; or
- independent exact-tree review returns `GAP-REVISE`, `BLOCKED` or
  `OWNER DECISION`.

Use the current IMPLEMENTAUDIT Andon schema and abnormality class. Preserve the
original witness, candidate identity, affected layer and unaffected valid
evidence. Retry only after a decision-relevant change; no arbitrary attempt,
why, review, repair or audit count is terminal evidence.

## Terminal acceptance

R0037 is terminal only on one future exact candidate with no active Andon/handoff:

1. Controller, run root, repo root, worktree, branch, commit, tree, dirty state,
   authority and R0037 issue/body/comment identity are re-anchored; e60/W04 remain
   historical ancestry.
2. Native owner/source plus generated/package/install/host/hosted/public maps
   are explicit; every changed semantic owner has one writer; R0033-R0036 shared
   writers are serialized and joined.
3. Topology is `/implementaudit` sole governor plus exactly `audit-state`,
   `audit-assess`, `audit-implement`, `audit-andon`; no child is lifecycle
   stage or authority owner.
4. `audit-andon` proves governor-child and direct-invocable: governed route is
   `L4 -> audit-andon -> L4/governor`, direct route returns to caller, and
   neither gains lifecycle/currentness/mutation/RXX/PASS/closure/publication/
   release authority.
5. `SOURCE_RUNTIME_DELTA_REQUIRED`, `ACCEPTANCE_TEST_DELTA_REQUIRED`,
   `PACKAGE_DELTA_REQUIRED`, `INSTALL_HOST_DELTA_REQUIRED` and
   `PUBLIC_SURFACE_DELTA_REQUIRED` have evidence-backed terminal values; no RED
   is manufactured from R0037 number, missing artifact or historical gap wording.
6. L1 is sufficient/revisable; L2 re-enters with exact currentness and selective
   invalidation; L3 preserves Smoke A/work/acceptance/5S/Smoke B; L4 interrupts
   L1-L5; L5 independently audits, repairs, reverifies and reaudits exact
   candidate.
7. Jidoka/Andon remain distinct; 5 Whys is decision-bounded; Hansei/Kaizen only
   on warranted learning; 5S protects unrelated work; Lean/Agile/Waterfall
   properties survive without mode/ceremony.
8. Complete R0037 positive, negative, boundary, adjacent, held-out, mutation and
   anti-gaming family passes, including late L1/L5 Andons, selective L2
   re-entry, renamed fixed-loop child, unfamiliar DAG/missing JOIN, dual Andon
   return owner, false-green closure and cheap-path held-outs.
9. No-regression passes for governor, L1-L5, LAW mechanisms, four children,
   dual Andon entry, child no-chain/no-authority, DAG/agent orthogonality,
   currentness, marker/closure, sidecars, R001E, R0021 and cheap path. No inherited
   failure/expectation is weakened.
10. No-bloat is evidenced: no unnecessary mode, loop skill, RXX, model call,
    DAG, artifact, package member, install, host matrix, public doc or owner;
    any increment has trigger, consumer, discriminator, payoff and retirement.
11. If packaged bytes changed, exact source -> generated -> built -> packaged ->
    isolated-installed population/version/inventory/parity passes, including
    missing/extra/mixed-version/stale population rejection and rollback.
    Otherwise package/install is `NOT_TRIGGERED`.
12. Applicable host discovery and prompt-independent routing pass on exact
    host/version/config identities; unavailable/policy-blocked hosts are
    BLOCKED; manifests/copy receipts are not activation proof.
13. Bounded live corroboration exercises L4 during L1 and L5, selective L2
    invalidation, governed/direct Andon return ownership and cheap path without
    giving model output authority.
14. Fresh exact-tree cold review passes; hosted CI passes where applicable; all
    failed, partial, correlated and non-verdict predecessors remain visible at
    their evidence ceilings.
15. Source/generated/built/packaged/installed/host/hosted/public/release/
    cross-repo claims stop at the weakest proved leg; local/model receipts are
    not promoted to external effects.
16. Separately authorized publication/evidence comment is read back by exact
    identity, bytes/hash and state; defective/partial publication is corrected
    additively and remains unaccepted until readback passes.
17. Manual closure waits for evidence comment/readback and all accepted-RXX
    evidence joins before C08. Issue creation, PR merge, time, completed phases,
    one audit invocation, child PASS-like output or package success is not
    terminal acceptance.

LAB_GRADE_DRAFT_STATUS=COMPLETE


<!-- implementaudit-v041-current-state-reconciliation -->
## v0.4.1 current-state reconciliation (2026-09-07)

This additive section supersedes stale current-status statements in the historical body; it does not rewrite accepted history or itself grant implementation, qualification, release, publication, tracker-closure, or native AthruK credit.

- Current semantic status: `ENGINEERING_REQUIRED`
- Current statement: L1-L5 integration must be interceptive at applicable holon scope and cannot be backseated by generic/direct cognition.
- Applicable accepted evidence: Accepted component-level L1-L5 and lifecycle evidence remains reusable.
- Proof/authority limit: Side generic-improve displacement and missed local compaction recovery invalidate only routing/recovery slices.
- AthruK relationship: `E, G, H, J`
- Auto-LOOM relationship: parallel bounded design/tests alongside EH-3, then changed-radius qualification
- First remaining discriminator/prerequisite: Native capability precedence plus holon-local recovery integration and final composition review.
- Next consumer/owner: `NESTED_CONTROL_INTEGRATION_OWNER`
- Release accounting: no release cell closes from this reconciliation; required remaining remains 26 plus conditional B-F3.
- Frozen proposal source: `sha256:baf4ab4600363cf3047664fea87971e593a423a55de0a2ab9df8c0d15235770c` (local run evidence; not public authority).


<!-- thread8-triad-integration-f4c2a199743d -->
### Bounded SSS x BWP x AMA integration input

A deviation may expose harmful behavior, an obsolete expectation, authorized improvement or defective observation. Route the counterexample to its responsible requirement/model/protocol/plan owner; a successor validator cannot admit itself.

[Reviewed source and issue crosswalk](https://github.com/theislampill/IMPLEMENTAUDIT.md/blob/0e175fe64cbd4846fbf8e06c8b2ede12295c514c/docs/research/implementaudit/triad-integration/ISSUE_ADJUDICATION.json); [draft integration PR](https://github.com/theislampill/IMPLEMENTAUDIT.md/pull/223). The isolated canonical package gate remains failed at the frozen identity-convergence gap. This note grants no governor admission, native authority-NONE, runtime/install/release qualification or issue closure. Existing owner and qualification obligations remain in force.
