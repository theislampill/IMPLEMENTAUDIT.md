#!/usr/bin/env python3
"""Read-only M09 packet receiving; never imports or invokes product code."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

ROOT = Path('/workspace/scratch/097486cde2dd/dg17-full-family')
OUT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b')
COMMIT = '51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
TREE = '9c3913ceaa95f3f36b0377fe2dba4a302afcba89'
EXPECTED_SEAL = 'bae9f2bdf377f6c524e131be928858ce8d9f4d71fb8868357984254f70f71245'

def sha(body):
    return hashlib.sha256(body).hexdigest()

def blob(body):
    return hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()

processes = []
env = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_ALLOW_PROTOCOL='')

def git(*args):
    argv = ['/usr/bin/git', '-C', str(REPO), *args]
    proc = subprocess.run(argv, env=env, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, timeout=30)
    processes.append({'argv': argv, 'returncode': proc.returncode,
                      'stdout_bytes': len(proc.stdout), 'stdout_sha256': sha(proc.stdout),
                      'stderr_bytes': len(proc.stderr), 'stderr_sha256': sha(proc.stderr)})
    assert proc.returncode == 0 and not proc.stderr, args
    return proc.stdout

raw_seal = (ROOT / 'SEAL.json').read_bytes()
assert len(raw_seal) == 8522 and sha(raw_seal) == EXPECTED_SEAL
seal = json.loads(raw_seal)
members = seal['files']
assert len(members) == 47 and sum(x['bytes'] for x in members) == 1274368
names = [x['path'] for x in members]
assert len(set(names)) == len(names)
for item in members:
    rel = Path(item['path'])
    assert not rel.is_absolute() and '..' not in rel.parts
    path = ROOT / rel
    assert stat.S_ISREG(path.lstat().st_mode) and not path.is_symlink()
    body = path.read_bytes()
    assert len(body) == item['bytes'] and sha(body) == item['sha256'], rel
actual_files = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
assert actual_files == set(names) | {'SEAL.json'}
assert not (ROOT / 'execution-01').exists()
assert git('rev-parse', COMMIT + '^{tree}').decode().strip() == TREE

source_manifest = json.loads((ROOT / 'AUTHENTICATED_SOURCE_TREE.json').read_bytes())
sources = []
for row in source_manifest['selected_entries']:
    body = (ROOT / 'source' / row['path']).read_bytes()
    assert len(body) == row['size'] and blob(body) == row['sha']
    tree_row = git('ls-tree', '-l', COMMIT, '--', row['path']).decode().strip()
    assert tree_row.split()[0:4] == [row['mode'], 'blob', row['sha'], str(row['size'])]
    assert git('cat-file', 'blob', row['sha']) == body
    sources.append({'path': row['path'], 'bytes': len(body),
                    'git_blob': blob(body), 'sha256': sha(body)})
assert len(sources) == 22 and sum(x['bytes'] for x in sources) == 946993
mutation = json.loads((ROOT / 'MUTATION.json').read_bytes())
original = (ROOT / 'source' / mutation['path']).read_bytes()
mutant = (ROOT / 'mutant/validate-phase.sh').read_bytes()
removed = mutation['exact_removed_line'].encode() + b'\n'
assert original.count(removed) == 1
assert mutant == original.replace(removed, b'# M09 isolated mutation: the sole authority path-membership refusal is removed.\n')
assert sha(original) == mutation['original_sha256'] and sha(mutant) == mutation['mutant_sha256']
assert original.splitlines().index(removed.rstrip(b'\n')) + 1 == 102

missing_path = 'skills/implementaudit/scripts/canonical_custody.py'
dependency_tree_row = git('ls-tree', '-l', COMMIT, '--', missing_path).decode().strip()
dep_oid = dependency_tree_row.split()[2]
dependency = git('cat-file', 'blob', dep_oid)
assert dep_oid == '434f8cb1579d3dfff2ba8a6fad91849f32ef927e'
assert len(dependency) == 36367
assert sha(dependency) == 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389'
assert not (ROOT / 'source' / missing_path).exists()
reader = (ROOT / 'source/skills/implementaudit/scripts/read-canonical-pair.py').read_text().splitlines()
assert reader[23].strip() == 'path = Path(__file__).absolute().with_name("canonical_custody.py")'
assert reader[49] == '_CUSTODY = _windows_custody()'

cases = json.loads((ROOT / 'inputs/cases.json').read_bytes())['witnesses']
assert len(cases) == 8 and len({x['id'] for x in cases}) == 8
assert sum(x['mutation_target'] for x in cases) == 5
witnesses = []
for case in cases:
    phase = (ROOT / 'inputs/phases' / (case['id'] + '.md')).read_text()
    assert phase.count('RUN_ROOT_FROM_REAL_CLAIM') == 4
    assert '  mutation-authority: ' + json.dumps(case['operation'], separators=(',', ':')) in phase
    assert 'Mutation scope: ' + json.dumps(case['scope'], separators=(',', ':')) in phase
    for p in case['dirty_protected_files']:
        assert bytes.fromhex(case['files'][p]['index_hex']) != bytes.fromhex(case['files'][p]['current_hex'])
    op = case['operation']
    intended = {}
    if case['expected_process_kind'] != 'preimage-refusal':
        intended[op['source']] = (None if op['operation'] in {'delete', 'move'} else case['candidate_hex'])
        if op['operation'] == 'move':
            intended[op['destination']] = case['preimage_hex']
    witnesses.append({'id': case['id'], 'original_expected_edits': case['expected_workplane_edits'],
                      'mutant_required_edits_for_exact_receiving': intended,
                      'operation': op, 'mutation_target': case['mutation_target'],
                      'all_other_workplane_entries_must_remain_exact': True})

preparation = json.loads((ROOT / 'PREPARATION_RESULT.json').read_bytes())
assert preparation['check_count'] == len(preparation['checks']) == 85
assert preparation['source_product_behavior_executed'] is False
assert sha((ROOT / 'evidence/ORIGINAL_ISSUE211.md').read_bytes()) == 'ca62f4899a45544549f623a0312c16121bb99f432ccb87a87b7361974ceb94c4'
executables = {}
for name in ('python3.13', 'python3', 'bash', 'git'):
    path = Path('/usr/bin') / name
    executables[name] = {'selected': str(path), 'resolved': str(path.resolve()),
                         'sha256': sha(path.read_bytes())}

result = {'schema': 'dg17.m09.independent-source-receiving.v1',
          'at': datetime.now(timezone.utc).isoformat(),
          'reviewer': '/root/independent_review', 'authority': 'NONE',
          'status': 'PACKET_RECEIVING_PASS_SOURCE_ELIGIBILITY_GAP_REVISE',
          'packet_seal_bytes': len(raw_seal), 'packet_seal_sha256': sha(raw_seal),
          'packet_members': len(members), 'packet_bytes': sum(x['bytes'] for x in members),
          'source_commit': COMMIT, 'source_tree': TREE, 'sources': sources,
          'source_count': len(sources), 'source_bytes': sum(x['bytes'] for x in sources),
          'sole_mutation_verified': mutation, 'witnesses': witnesses,
          'missing_unconditionally_loaded_dependency': {'path': missing_path,
              'git_tree_row': dependency_tree_row, 'git_blob': dep_oid,
              'bytes': len(dependency), 'sha256': sha(dependency),
              'packet_member_exists': False, 'loader_call_line': 50,
              'product_module_executed': False},
          'sealed_preparation_check_count': preparation['check_count'],
          'existing_executables_read_only': executables,
          'git_reads': processes, 'git_environment': {'GIT_NO_LAZY_FETCH': '1', 'GIT_ALLOW_PROTOCOL': ''},
          'original_consumer_invocations': 0, 'mutant_invocations': 0,
          'oracle_invocations': 0, 'source_imports': 0, 'provider_writes': 0,
          'root_controller_writes': 0, 'execution_directory_absent': True,
          'root_receipt_received': 'refs/implementaudit/continuity-receipts/dg16-dg18-recovery-20261119-b/G0042@a0dee5abe9e4ee81866cdf91d7568d25d35039a0',
          'root_currentness_receipt_tool': '634a33/0', 'original_awards': []}
(OUT / 'MECHANICAL_RECEIVING.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('status', 'packet_members', 'packet_bytes', 'source_count', 'source_bytes', 'execution_directory_absent')}))
