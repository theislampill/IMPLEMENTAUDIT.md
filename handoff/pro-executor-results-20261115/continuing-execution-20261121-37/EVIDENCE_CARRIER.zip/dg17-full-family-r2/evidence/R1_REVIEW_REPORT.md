# DG17 M09 independent eligibility review — GAP_REVISE

## Decision

**GAP_REVISE for the exact frozen packet. Recommend keeping it unexecuted.** The proposed authority-layer witness family is a defensible mapping to original M09, but the packaged CLI chain is incomplete: an unconditionally loaded canonical-reader dependency is missing. This is a concrete prerequisite failure, identified from source without invoking the consumer. The static preparation result does not establish executable dependency completeness.

The provisional mutant-kill predicate also needs to be made exact before execution. It currently recognizes any protected-path change with compatible `COMMITTED` metadata, whereas the frozen contract requires five particular effects. Independent receiving remains mandatory; the driver's provisional result is not an award. The bounded correction is to freeze and require the exact post-state predicates listed below, preferably in the variant-blind oracle as part of the already-required replacement packet.

This is ordinary advisory source review by `/root/independent_review`, who did not author the packet. Authority is **NONE**. Root alone owns eligibility, execution, receiving adjudication and awards. No product module was imported, no original or mutant consumer or packet oracle was executed, and no provider, source, Git ref, controller, or accepted-operation state was changed. Review artifacts are the only writes.

Root rebound this resumed review to its live currentness verification `634a33/0`: G0042 receipt `refs/implementaudit/continuity-receipts/dg16-dg18-recovery-20261119-b/G0042@a0dee5abe9e4ee81866cdf91d7568d25d35039a0`, HEAD `6d9e145e2f2df5a0a8a150c85a4f3e2afd918d27`, tree `9b80db50562b54091c5c65414f55c9cb55981c97`. This is received Root provenance, not delegated controller authority.

## Exact receiving

Packet root: `/workspace/scratch/097486cde2dd/dg17-full-family`.

| Binding | Independently received value |
|---|---|
| `SEAL.json` | 8,522 bytes; SHA256 `bae9f2bdf377f6c524e131be928858ce8d9f4d71fb8868357984254f70f71245` |
| Sealed members | Exactly 47 regular files, 1,274,368 bytes; all sizes/hashes agree; no extra files |
| Product source commit | `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7` |
| Product source tree | `9c3913ceaa95f3f36b0377fe2dba4a302afcba89` |
| Included source population | All 22 files, 946,993 bytes, compared with exact local Git tree entries and blob bodies |
| Original phase validator | 45,816 bytes; SHA256 `07b2e04ba9aefffc572ac9cf60ecddf88654a26590aaa045dadf464da7bc7dab` |
| Mutated phase validator | 45,714 bytes; SHA256 `8e693bef6a99feb95aa6150ebbd0565cc7e5cda8c91c5ab3620e73da6871879c` |
| Sole source mutation | Original line 102 replaced by the declared non-executable comment; all other bytes agree |
| Witness population | Eight unique cases: five discriminators and three specificity/validity controls |
| Prepared evidence | Sealed 85-check static preparation; source behavior explicitly unexecuted |
| Original issue body | SHA256 `ca62f4899a45544549f623a0312c16121bb99f432ccb87a87b7361974ceb94c4` |
| Execution directory | Absent at receiving |

Mechanical receiving command: `python3 -I -B RECEIVE.py`, from this review directory, native receipt **`2499af/0`**. The retained `MECHANICAL_RECEIVING.json` records all 22 source identities, the exact missing dependency, case/phase bindings, executable byte identities, and bounded Git read receipts. Every Git read used `GIT_NO_LAZY_FETCH=1` and `GIT_ALLOW_PROTOCOL=''`. No fetch, repair of historic objects, alternate creation, or source mutation occurred.

## Findings

### M09-SR-H1 — High: missing unconditional dependency prevents the claimed consumer path

**Locations:**

- `/workspace/scratch/097486cde2dd/dg17-full-family/source/skills/implementaudit/scripts/read-canonical-pair.py:24–50`.
- `/workspace/scratch/097486cde2dd/dg17-full-family/source/skills/implementaudit/scripts/validate-phase.sh:27–42`.
- `/workspace/scratch/097486cde2dd/dg17-full-family/run_m09.py:261–265`.
- `/workspace/scratch/097486cde2dd/dg17-full-family/READINESS.md:25`.

The reader's module-level statement `_CUSTODY = _windows_custody()` runs at line 50 on POSIX as well as Windows. The platform selection occurs only afterward, at line 51. `_windows_custody()` resolves and reads sibling `canonical_custody.py`, requires exactly 36,367 bytes and SHA256 `d52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389`, then compiles that verified buffer. The frozen source directory, source map and seal omit the sibling entirely. Copying this source directory into the two runtime packages does not supply it.

The exact original dependency exists in the pinned source tree: mode `100755`, Git blob `434f8cb1579d3dfff2ba8a6fad91849f32ef927e`, 36,367 bytes. A read of that existing local blob independently matches the reader's SHA256 pin. Its name does not make its initial loading Windows-only.

**Consequence inferred from source, not observed by execution:** if the ordinary phase validator reaches its reader invocation, the missing-file exception occurs before `main()` and before the supported no-controller return code 3. `validate-phase.sh` refuses that selection, and `apply-observed-mutation.sh` propagates validator failure as exit 64. The first authorized-cleanup witness requires an actual commit, so this prerequisite failure cannot qualify an original pass or mutation kill. Earlier unrelated failures, if any, would also remain failures; no behavior is presumed green.

**Required correction:** preserve this packet and its zero-execution state. Create a separately sealed replacement packet that includes the exact existing dependency, updates the authenticated source inventory and checks dependency closure statically. Keep the actual reader and its guard unchanged; do not stub its return-3 path or move the import behind a platform test. No product behavior or original rerun is needed to establish the missing-file correction.

### M09-SR-M1 — Medium: provisional kill recognition is weaker than the declared five effects

**Locations:**

- `/workspace/scratch/097486cde2dd/dg17-full-family/oracle.py:45–57,77–93`.
- `/workspace/scratch/097486cde2dd/dg17-full-family/run_m09.py:282–295`.
- `/workspace/scratch/097486cde2dd/dg17-full-family/READINESS.md:68`.

The invariant oracle correctly compares the complete live work plane with the original expected edits, and the driver checks live/captured agreement. The separate `actual_out_of_scope_committed_effect` flag, however, is only `differences and protected_changes and committed`. The `committed` predicate binds operation/source/destination metadata and a nonempty effect list, but it does not require the requested source/destination's exact live effect, absence of additional edits, the intended candidate bytes, or the complete successful process shape already used elsewhere in the oracle.

A concrete recognizer counterexample is the `foreign-move-destination` witness with its source unchanged and intended destination absent, while a different protected user file is deleted. If the supplied helper record says exit 0/`COMMITTED` with the expected operation/source/destination and any nonempty effect list, the current Boolean becomes true. This is a static counterexample to the recognizer, **not** a claimed output of the pinned helper; neither oracle nor product was executed to produce it. The same weakness could label replacement with wrong bytes as the intended discriminator.

The driver honestly labels its result pending independent receiving and explicitly sets award false. Thus this finding is not a claim that the current driver awards M09. It is an acceptance precision gap: its provisional full-family signal is less specific than the frozen requirement.

**Correction before execution:** freeze the exact complete post-state for each proposed operation, require the full successful result shape, and require live/capture agreement. The target change must be the requested source deletion, exact candidate replacement, or exact source-to-destination move. All other work-plane entries must equal the shared baseline. This can remain variant-blind: calculate the operation's intended effects from the frozen operation/preimage/candidate values, independent of variant name. Preserve the original invariant oracle and independent receiving. Root could instead adopt an equally explicit sealed receiving predicate before launch; a generic Boolean alone cannot settle the family.

### M09-SR-L1 — Low: process-group cleanup is a limit, not demonstrated absence

**Locations:** `/workspace/scratch/097486cde2dd/dg17-full-family/run_m09.py:73–107` and `/workspace/scratch/097486cde2dd/dg17-full-family/READINESS.md:71`.

Each child gets a new session and a 45-second communication deadline. Timeout handling signals the process group with TERM, then KILL if communication still has not completed after five seconds. Normal completion records the direct process result and captures; it does not census remaining members of the process group. Nor does a return from communication after TERM establish that every possible descendant has exited. The sentence that the owned group “is contained” should not be promoted into a universal cleanup guarantee.

For the selected ordinary path, the inspected helper/validator subprocess calls are synchronous. The live authority-guard `Popen` in the full helper belongs to the protected route, which the frozen arguments and inputs do not request. The concrete missing dependency is sufficient to stop this packet; there is no evidence of an actual survivor or need to invent a native containment qualification as part of M09. Narrow the readiness claim to the implemented timeout behavior and direct-child capture. Any later exceptional survivor would require owned-process containment and retained evidence before reuse. A future stronger absence claim would need actual group evidence.

## Original-family scope and receiving predicates

The original body is sufficiently specific for this proposed layer. Issue211 line 525 requires residue plus protected-work cases; line 609 names the independent removal/inversion of “5S unrelated-work protection”; lines 543–545 permit structural authority facts while excluding model-judgment and real-host activation claims; lines 616–619 require state/identity/evidence/authority discrimination under renamed and unfamiliar inputs. Line 715 pairs touched-state reproducibility with residue and dirty-file protection.

The proposed positive cleanup, protected dirty-work negatives, destination authority checks, renamed/opaque paths and unchanged preimage refusal cover this single M09 authority predicate as a conjunction. I found no additional original M09 conjunct that requires turning this family into all five 5S pillars or the whole L3 lifecycle. That scope assessment does not make this incomplete runtime package eligible, prove future behavior, or replace the preserved earlier Seiri-policy survivor.

The following exact effects are determined before execution from `inputs/cases.json`. They should be required by the replacement packet/receiving contract, not chosen after an outcome. In every row, all unmentioned work-plane entries must retain the shared baseline kind, length and SHA256.

| Witness | Required original result | Required mutant result |
|---|---|---|
| `owned-residue-delete` | Commit; `dg17-work/task/result-cache.bin` absent; both dirty user files exact | Same |
| `foreign-source-delete` | Scope refusal, exit 64; entire work plane exact | Commit; `dg17-work/user/notes.md` absent; other entries exact |
| `heldout-name-looks-disposable` | Scope refusal; entire work plane exact, including the explicitly excluded cache-like name | Commit; `dg17-work/cache/retired-output.bin` absent; other entries exact |
| `heldout-opaque-replace` | Scope refusal; entire work plane exact | Commit; `dg17-work/x7/v19.dat` exactly equals frozen `candidate_hex`; other entries exact |
| `foreign-move-destination` | Scope refusal; source retained and destination absent; entire work plane exact | Commit; task source absent and `dg17-work/user/new-artifact.dat` exactly equals the frozen complete source preimage |
| `explicitly-excluded-destination` | Scope refusal even though destination is also in scope.in; entire work plane exact | Commit; task source absent and `dg17-work/user/excluded-artifact.dat` exactly equals the frozen complete source preimage |
| `owned-residue-relocate` | Commit; task source absent and `dg17-work/task/ordered-result.bin` exactly equals the complete source preimage; dirty user files exact | Same |
| `truncated-preimage-control` | Exit 64; `REJECTED_NO_MUTATION`, `PREIMAGE_DRIFT`, empty actual effect set; entire work plane exact | Same |

For every commit, independently require exit 0, schema `implementaudit.observation_bound_mutation.v2`, status `COMMITTED`, reason `NONE`, empty residue, exact operation/source/destination, and actual effect/journal identities consistent with the received post-state. A nonempty list alone is insufficient. Scope refusal must originate from the named scope check, not parser failure, missing dependency, timeout or unrelated guard. These predicates do not authorize their execution.

The eight witnesses use the same constructed dirty input bytes for both variants. The driver first stages different bytes, then changes the worktree and requires the actual `AM` premise. It makes an actual ordinary claim per witness, snapshots claim/phase/input state, restores the same absolute subject path, and checks input and work-plane equality before each invocation (`run_m09.py:133–202`). The two product packages differ only in the declared validator line. Physical inode values after restoration need not be identical across variants; the helper acquires each operation's actual preimage identity. No synthetic callback replaces the consumer.

## Bounds and evidence limits

The review read the complete runner and oracle, all eight frozen case definitions and phase bindings, the full phase validator and canonical-pair reader, the ordinary claim path and strict claim validator, and the helper's selected authority, preimage, mutation, fence-selection and result paths. Every included full source file was mechanically received against its exact Git object; this does not claim a fresh audit of every unreachable controller, Windows or batch branch or of the full inherited test corpus.

The selected helper reads its source/destination from the real validated phase projection; supplied CLI arguments cannot replace that target. The sole removed predicate checks both allowlist absence and explicit exclusion for source and destination. Preimage capture, path custody, claim checks, journals and the unchanged operation implementations remain present. The ordinary fixture has no controller hint/population or generation-fence request; Root authority is not manufactured by the fixture's prospective markers. The readiness-reference argument is acknowledged as a record, not an authorization mechanism.

The driver creates a finite eight-subject, two-variant experiment beneath its proposed `execution-01` directory and refuses a preexisting directory. All originals must pass before the first mutant; abnormal results are retained without automatic retry. Source-repository access locates the existing immutable object store. Disposable repositories have their own indexes/refs and read-only object alternates; this is not a claim that the historical repo's missing objects were repaired. Global/system Git config is disabled in the runner. No provider, private-input, network acquisition, or publication action is requested by this selected branch. There is no global elapsed-time, memory or output quota in the driver: the finite source/input design and per-command timeout are the actual limits.

No execution result is inferred from the 85 static controls. The original baseline, five actual mutant effects, three unchanged controls, byte-exact post-states, journals, terminal process captures and execution manifest are all **UNMEASURED**. The old packet stays frozen; a replacement must receive its own exact seal review. Prior M09 `SURVIVED` evidence remains valid and unawarded. M10/M11/P02 remain stopped, and the original denominators stay **36 cases / 14 mutation families / 17 terminal clauses**. This report grants no original award or whole-DG17 closure.
