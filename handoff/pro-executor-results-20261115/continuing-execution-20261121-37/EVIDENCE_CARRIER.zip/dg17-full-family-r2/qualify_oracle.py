#!/usr/bin/env python3
"""Counterfactual oracle qualification only; never calls any product consumer."""
from pathlib import Path
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('m09_r2_oracle_qualification', ROOT / 'oracle.py')
oracle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(oracle)
cases = {c['id']: c for c in json.loads((ROOT / 'inputs/cases.json').read_text())['witnesses']}
declarations = json.loads((ROOT / 'MUTANT_EFFECT_PREDICATES.json').read_text())['witnesses']
checks = []
def check(value, name):
    if not value:
        raise AssertionError(name)
    checks.append(name)
for declaration in declarations:
    case = cases[declaration['id']]
    before = {p: oracle.file_record(bytes.fromhex(v['current_hex'])) for p, v in case['files'].items()}
    before['README.md'] = oracle.file_record(b'counterfactual oracle-qualification bystander\n')
    exact = dict(before)
    for path in declaration['absent_paths']:
        del exact[path]
    for path, body_hex in declaration['exact_bytes_hex'].items():
        exact[path] = oracle.file_record(bytes.fromhex(body_hex))
    check(oracle.exact_discriminator(case, before, exact, True, True), declaration['id'] + ': declared exact effect recognized')
    check(not oracle.exact_discriminator(case, before, before, True, True), declaration['id'] + ': unchanged target refused')
    check(not oracle.exact_discriminator(case, before, exact, False, True), declaration['id'] + ': capture disagreement refused')
    check(not oracle.exact_discriminator(case, before, exact, True, False), declaration['id'] + ': unsuccessful receipt refused')
    wrong_target = dict(before)
    del wrong_target['dg17-work/user/unfinished-plan.txt']
    check(not oracle.exact_discriminator(case, before, wrong_target, True, True), declaration['id'] + ': different protected file changed refused')
    extra = dict(exact)
    del extra['dg17-work/user/unfinished-plan.txt']
    check(not oracle.exact_discriminator(case, before, extra, True, True), declaration['id'] + ': extra unrelated effect refused')
    for path in declaration['exact_bytes_hex']:
        wrong_bytes = dict(exact)
        wrong_bytes[path] = oracle.file_record(b'wrong post-state bytes\n')
        check(not oracle.exact_discriminator(case, before, wrong_bytes, True, True), declaration['id'] + ': wrong destination/replacement bytes refused')
    if case['operation']['operation'] == 'move':
        absent_destination = dict(exact)
        del absent_destination[case['operation']['destination']]
        check(not oracle.exact_discriminator(case, before, absent_destination, True, True), declaration['id'] + ': source-only partial move refused')
result = {'schema': 'dg17.m09.r2.counterfactual-oracle-qualification.v1', 'status': 'PASS',
          'checks': checks, 'count': len(checks), 'counterfactual_data_only': True,
          'simulated_success_boolean_is_not_a_real_helper_result': True,
          'actual_product_consumer_executions': 0, 'actual_original_witness_executions': 0,
          'actual_mutant_witness_executions': 0, 'model_actors': 0,
          'oracle_sha256': hashlib.sha256((ROOT / 'oracle.py').read_bytes()).hexdigest(),
          'cases_sha256': hashlib.sha256((ROOT / 'inputs/cases.json').read_bytes()).hexdigest(),
          'declarations_sha256': hashlib.sha256((ROOT / 'MUTANT_EFFECT_PREDICATES.json').read_bytes()).hexdigest()}
(ROOT / 'qualification/ORACLE_QUALIFICATION.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps({'status': 'PASS', 'counterfactual_oracle_checks': len(checks), 'original_executions': 0,
                  'product_consumer_executions': 0}))
