# Local receiving notes

These local tooling issues did not execute the product or alter hosted evidence.

1. The first artifact-materialization orchestration raised ReferenceError because this functions runtime has no TextEncoder global. It had written the sanitized transfer receipt, but did not launch a native downloader or request the signed URL. The next orchestration used explicit ASCII encoding and made the sole archive download. Native 11c580/0 received the provider's exact 1,885 bytes and verified the archive/return seals.
2. A bounded local metadata inspection at native 1f1b44/1 attempted len() on the integer members count in the inherited manifest. It stopped while printing metadata; it neither imported product code nor changed source or archive data. A corrected type-aware inspection completed at 30fd09/0. The final receiving verifier reads the actual files array and completed all 120 assertions at 2bfe10/0.
3. The child's host compaction interrupted receipt of the first run/jobs output. Those completed provider responses were already saved. Root reverified currentness at 72f182/0 and continued this exact read-only scope. The saved terminal responses were reused; no status replay was needed.

No local issue is normalized into hosted diagnostic success. The observed run's context refusal and native exit2 remain unchanged.

