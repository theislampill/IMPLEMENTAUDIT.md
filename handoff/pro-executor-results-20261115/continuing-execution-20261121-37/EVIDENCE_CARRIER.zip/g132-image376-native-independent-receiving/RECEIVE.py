#!/usr/bin/env python3
"""Read-only receipt of one terminal ordinary diagnostic; no product imports."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import re
import stat
import sys
import zipfile

BASE = Path("/workspace/scratch/097486cde2dd")
RAW = BASE / "g132-native-44959365296"
OUT = BASE / "g132-image376-native-independent-receiving"
COMMIT = "2c117a9513db8b683472aa40cbde40ab45472bad"
TREE = "90a6e9b7fbc066dfda8ce7e6ddb0ac921289be5e"
PARENT = "f75533f95f0d099c87e7a04beb11b0a25628acdc"
BRANCH = "pro/dg16-g132-engine-source-observe-20261121-02"
RUN = 44959365296
JOB = 137014541469
ARTIFACT = 14728049094
ARCHIVE_SHA = "da633897428211084327098d0859a343adc94c23de8478429e75eed517aa8e81"
checks = []
bindings = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

def check(name, value, evidence=None):
    checks.append(dict(name=name, passed=bool(value), evidence=evidence))
    if not value:
        raise ValueError(name)

def read_json(path):
    return json.loads(path.read_bytes())

def provider(name):
    r = read_json(RAW / ("PROVIDER_" + name + ".json"))
    check(name + " provider success", r.get("isError") is False)
    return json.loads(r["structuredContent"]["content"])

def manifest(directory, name, expected_hash, count, byte_count):
    data = (directory / name).read_bytes()
    value = json.loads(data)
    check(name + " exact seal " + directory.name, sha(data) == expected_hash)
    rows = value["files"]
    check(name + " population " + directory.name,
          len(rows) == count and sum(r["bytes"] for r in rows) == byte_count)
    check(name + " unique safe paths " + directory.name,
          len({r["path"] for r in rows}) == len(rows) and all(
              not Path(r["path"]).is_absolute() and ".." not in Path(r["path"]).parts for r in rows))
    for row in rows:
        path = directory / row["path"]
        check("exact sealed member " + directory.name + "/" + row["path"],
              stat.S_ISREG(path.lstat().st_mode) and not path.is_symlink()
              and len(path.read_bytes()) == row["bytes"]
              and sha(path.read_bytes()) == row["sha256"]
              and ("git_blob" not in row or blob(path.read_bytes()) == row["git_blob"]))
    bindings.append(dict(path=str(directory / name), bytes=len(data), sha256=sha(data),
                         members=count, payload_bytes=byte_count))
    return value

candidate = manifest(BASE / "g132-image376-candidate", "SEAL.json",
    "b828bb65aa945430e6d48891eb6856e431409c90633fe0c6857b303b3de23a8a", 17, 42994)
review = manifest(BASE / "g132-image376-independent-review", "SEAL.json",
    "0429380234130a4f602eed1235c40af01052383f6e8843df86f3c2f7d8de7b2a", 4, 43241)
inherited = manifest(BASE / "g132-qualification/frozen-packet", "PACKET_MANIFEST.json",
    "75435d932de544b9bfdef13ba74387b64e95804757727ee6711dfe266ffdc1e8", 32, 2055057)
check("candidate tree bound", candidate["expected_tree"] == TREE)
check("prior independent review authority and exact binding",
      review["candidate_tree"] == TREE and review["sole_parent"] == PARENT
      and review["disposition"] == "PASS_ORDINARY_SOURCE_DELTA_ONLY"
      and review["candidate_seal_sha256"] == bindings[0]["sha256"])
prior_mechanical = read_json(BASE / "g132-image376-independent-review/MECHANICAL_RECEIVING.json")
check("inherited exact tree and owner proof retained",
      prior_mechanical["actual_candidate_tree_object_received"] is True
      and prior_mechanical["proposed_tree"] == TREE
      and prior_mechanical["unchanged_inherited_source_count"] == 14
      and prior_mechanical["unchanged_Engine_map_count"] == 13
      and prior_mechanical["derived_base_file_count"] == 1768
      and prior_mechanical["derived_candidate_file_count"] == 1771
      and prior_mechanical["check_count"] == 170)
check("fourteen inherited full bodies received",
      len([r for r in inherited["files"] if r["path"].startswith("inherited-source/")]) == 14)

run = provider("RUN")
jobs = provider("JOBS")
artifacts = provider("ARTIFACTS")
commit = provider("COMMIT")
check("terminal exact run",
      run["id"] == RUN and run["run_attempt"] == 1 and run["status"] == "completed"
      and run["conclusion"] == "failure" and run["head_sha"] == COMMIT
      and run["head_branch"] == BRANCH and run["event"] == "push"
      and run["path"] == ".github/workflows/dg16-g132-engine-source-observe.yml")
check("exact immutable published commit",
      commit["sha"] == COMMIT and commit["tree"]["sha"] == TREE
      and [p["sha"] for p in commit["parents"]] == [PARENT])
check("one exact complete job page", jobs["total_count"] == len(jobs["jobs"]) == 1)
job = jobs["jobs"][0]
check("terminal exact job attempt",
      job["id"] == JOB and job["run_id"] == RUN and job["run_attempt"] == 1
      and job["head_sha"] == COMMIT and job["head_branch"] == BRANCH
      and job["status"] == "completed" and job["conclusion"] == "failure"
      and job["name"] == "observe" and job["labels"] == ["ubuntu-24.04"])
steps = {r["name"]: r for r in job["steps"]}
check("native step failed while checkout and artifact upload succeeded",
      steps["Observe exact Engine and one fresh complete source checkout"]["conclusion"] == "failure"
      and steps["Check out separate diagnostic owner"]["conclusion"] == "success"
      and steps["Retain complete or partial actual outcomes"]["conclusion"] == "success"
      and all(x["status"] == "completed" for x in job["steps"]))
check("one exact artifact page", artifacts["total_count"] == len(artifacts["artifacts"]) == 1)
artifact = artifacts["artifacts"][0]
check("provider artifact run and head binding",
      artifact["id"] == ARTIFACT and artifact["name"] == f"g132-engine-source-{RUN}-1"
      and artifact["size_in_bytes"] == 1885 and artifact["digest"] == "sha256:" + ARCHIVE_SHA
      and artifact["expired"] is False and artifact["workflow_run"]["id"] == RUN
      and artifact["workflow_run"]["head_sha"] == COMMIT
      and artifact["workflow_run"]["head_branch"] == BRANCH)
archive = (RAW / "PROVIDER_ARTIFACT.zip").read_bytes()
check("actual archive size and provider digest", len(archive) == 1885 and sha(archive) == ARCHIVE_SHA)
members = {}
with zipfile.ZipFile(RAW / "PROVIDER_ARTIFACT.zip") as z:
    check("exact archive member inventory", len(z.infolist()) == 4 and
          set(z.namelist()) == {"OBSERVATION.json", "STDERR.raw", "NATIVE_EXIT_STATUS.raw", "RETURN.json"})
    for info in z.infolist():
        check("regular member " + info.filename,
              not info.is_dir() and not stat.S_ISLNK(info.external_attr >> 16))
        data = z.read(info)
        check("extracted bytes equal archived member " + info.filename,
              data == (RAW / info.filename).read_bytes())
        members[info.filename] = dict(bytes=len(data), sha256=sha(data))
ret = read_json(RAW / "RETURN.json")
check("return schema and non-authority",
      ret["schema"] == "g132.ordinary-hosted-engine-source-native-return.v1"
      and ret["authority"] == "NONE" and ret["native_admission"] is False
      and ret["original_awards"] == [])
check("return member population", set(ret["members"]) == set(members) - {"RETURN.json"})
for name, row in ret["members"].items():
    check("return seal " + name, row == members[name])
check("native exit two", ret["native_exit_status"] == 2
      and (RAW / "NATIVE_EXIT_STATUS.raw").read_bytes() == b"2\n")
check("stderr empty", (RAW / "STDERR.raw").read_bytes() == b"")

published = read_json(RAW / "PUBLICATION_EXACT_FILE_READBACKS.json")
plan = read_json(RAW / "PUBLICATION_PLAN.json")
check("exact readbacks reference published commit", published["sha"] == COMMIT)
check("three expected published files",
      len(published["files"]) == len(plan["entries"]) == 3
      and {x["path"] for x in published["files"]} == {x["path"] for x in plan["entries"]})
source_bindings = []
for entry in plan["entries"]:
    record = next(x["result"] for x in published["files"] if x["path"] == entry["path"])
    check("publication file provider success " + entry["path"], record.get("isError") is False)
    sc = record["structuredContent"]
    data = sc["content"].encode("utf-8")
    local = BASE / "g132-image376-candidate/candidate" / entry["path"]
    check("published exact body " + entry["path"], sc["encoding"] == "utf-8"
          and data == local.read_bytes() and len(data) == entry["bytes"]
          and sha(data) == entry["sha256"] and blob(data) == entry["git_blob"] == sc["sha"])
    source_bindings.append({k: entry[k] for k in ("path", "bytes", "sha256", "git_blob")})
owner = (BASE / "g132-image376-candidate/candidate/engineering/g132-engine-source-diagnostic/observe.py").read_text()
tree = ast.parse(owner)
fn = next(x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name == "validate_context")
exact = next(x.value for x in fn.body if isinstance(x, ast.Assign) and
             any(isinstance(t, ast.Name) and t.id == "exact" for t in x.targets))
expected_image = ast.literal_eval(next(x.value for x in exact.keywords if x.arg == "ImageVersion"))
check("frozen owner exactly requires image376", expected_image == "20261116.376.1")
workflow = (BASE / "g132-image376-candidate/candidate/.github/workflows/dg16-g132-engine-source-observe.yml").read_text()
check("workflow binds selected owner and branch",
      "c91fe0b013c5048298fb0784d9dcec5b601768c79c22064f2a6d3065fe597d85" in workflow
      and BRANCH in workflow)
map_data = read_json(BASE / "g132-image376-candidate/candidate/engineering/g132-engine-source-diagnostic/ENGINE_MAP.json")
check("unchanged map exactly thirteen", len(map_data) == 13)

obs = read_json(RAW / "OBSERVATION.json")
expected_context = dict(GITHUB_ACTIONS="true", RUNNER_ENVIRONMENT="github-hosted",
    GITHUB_REPOSITORY="theislampill/IMPLEMENTAUDIT.md", GITHUB_EVENT_NAME="push",
    GITHUB_REF="refs/heads/" + BRANCH, GITHUB_RUN_ATTEMPT="1", GITHUB_RUN_ID=str(RUN),
    GITHUB_SHA=COMMIT, GITHUB_JOB="observe", GITHUB_WORKFLOW_SHA=COMMIT,
    GITHUB_WORKFLOW_REF="theislampill/IMPLEMENTAUDIT.md/.github/workflows/dg16-g132-engine-source-observe.yml@refs/heads/" + BRANCH,
    ImageOS="ubuntu24", ImageVersion=expected_image)
mismatches = {k: dict(expected=v, actual=obs["context"].get(k))
              for k, v in expected_context.items() if obs["context"].get(k) != v}
check("one exact context mismatch", mismatches == {
    "ImageVersion": dict(expected="20261116.376.1", actual="20261116.133.1")})
check("native context refusal", obs["status"] == "REFUSED" and obs["failed_phase"] == "context"
      and obs["exception_type"] == "ValueError"
      and obs["reason"] == "fixed ordinary context or host differs; no retry")
check("actual root process", all(obs["process"][k] == 0 for k in ("uid", "euid", "gid", "egid"))
      and obs["process"]["pid"] == 2246 and obs["process"]["ppid"] == 2245
      and obs["process"]["executable"] == "/usr/bin/python3.12"
      and obs["process"]["proc_starttime_ticks"] == "5373")
check("no later-phase observation", obs["gates"] == {} and obs["ordinary_git_children"] == []
      and obs["descriptor_restoration"] is None and all(k not in obs for k in (
          "diagnostic_owner", "engine_loaded", "engine_map", "git_before",
          "source_preparation", "source_capture", "git_bookends_equal")))
check("resource installation follows refused context",
      owner.index("validate_context(result['context']") < owner.index("resource.setrlimit(")
      < owner.index("phase='exact_engine_loading'"))
check("unchanged no-admission envelope",
      obs["authority"] == "NONE" and obs["overall_admission"] == "UNQUALIFIED"
      and obs["original_awards"] == [] and obs["provider_imports"] == 0
      and obs["no_automatic_retry"] is True and obs["source_guards_unchanged"] is True
      and all(obs[k] is False for k in ("native_admission", "original_execution",
          "session_constructed", "provider_acquired", "private_inputs_selected",
          "launcher_provisioned", "policy_changed")))

logs_record = read_json(RAW / "PROVIDER_JOB_LOGS.json")
check("job log provider success", logs_record.get("isError") is False)
logs = logs_record["structuredContent"]["content"]
check("retained decoded raw log exact", logs.encode() == (RAW / "JOB.raw").read_bytes())
log_checks = {
    "runner_actual_image": "Version: 20261116.133.1",
    "exact_checkout": "git checkout --progress --force " + COMMIT,
    "native_step_exit": "Process completed with exit code 2.",
    "archive_digest": "SHA256 digest of uploaded artifact zip is " + ARCHIVE_SHA,
    "artifact_identity": f"Artifact g132-engine-source-{RUN}-1.zip successfully finalized. Artifact ID {ARTIFACT}",
}
corroboration = {}
for name, text in log_checks.items():
    matches = [dict(line=i, text=s) for i, s in enumerate(logs.splitlines(), 1) if text in s]
    check("raw log corroboration " + name, len(matches) == 1)
    corroboration[name] = matches[0]
prior_zip = BASE / "g132-native-44957502944/PROVIDER_ARTIFACT.zip"
check("prior authenticated image evidence archive unchanged",
      sha(prior_zip.read_bytes()) == "f704c518497098e804d5a11f370bcc5a78b3c9e77813c80c59c784f45bc07da7")
with zipfile.ZipFile(prior_zip) as z:
    prior_obs = json.loads(z.read("OBSERVATION.json"))
    check("op01 actual image remains376 and refused",
          prior_obs["context"]["ImageVersion"] == "20261116.376.1"
          and prior_obs["context"]["GITHUB_RUN_ID"] == "44957502944"
          and prior_obs["status"] == "REFUSED" and prior_obs["failed_phase"] == "context")

result = dict(schema="g132.image376.independent-terminal-receiving.v1",
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    disposition="PASS_RECEIVING_TERMINAL_REFUSAL",
    diagnostic_outcome="FAILURE_CONTEXT_IMAGE_MISMATCH", authority="NONE",
    run_id=RUN, job_id=JOB, attempt=1, head_sha=COMMIT, head_branch=BRANCH,
    tree=TREE, sole_parent=PARENT, native_exit_status=2,
    expected_image=expected_image, actual_image=obs["context"]["ImageVersion"],
    context_mismatches=mismatches, actual_hosted_process=obs["process"],
    resource_caps_installation="NOT_REACHED", later_engine_source_gates="NOT_REACHED",
    observer_git_children=0, descriptor_restoration=None, overall_admission="UNQUALIFIED",
    native_admission=False, original_awards=[], protected_grant="UNISSUED",
    archive=dict(id=ARTIFACT, bytes=len(archive), sha256=sha(archive), members=members),
    raw_log_corroboration=corroboration, sealed_source_bindings=bindings,
    three_published_bodies=source_bindings, source_edits=0, product_imports=0,
    observer_executions_by_reviewer=0, provider_writes=0, controller_mutations=0,
    provider_reads=dict(run=1, attempt_jobs=1, artifacts=1, job_log=1, artifact_download=1, commit=1),
    reviewer_process=dict(pid=os.getpid(), ppid=os.getppid(), executable=sys.executable,
                          version=sys.version, uid=os.getuid(), gid=os.getgid()),
    checks=checks, check_count=len(checks))
with (OUT / "MECHANICAL_RECEIVING.json").open("x") as f:
    json.dump(result, f, sort_keys=True, indent=2)
    f.write("\n")
print(json.dumps({k: result[k] for k in ("disposition", "check_count", "run_id", "job_id",
    "native_exit_status", "expected_image", "actual_image", "resource_caps_installation",
    "later_engine_source_gates", "observer_git_children")}, sort_keys=True))

