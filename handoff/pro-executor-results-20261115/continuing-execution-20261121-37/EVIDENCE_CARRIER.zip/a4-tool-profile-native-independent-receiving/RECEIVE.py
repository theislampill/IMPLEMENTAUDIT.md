#!/usr/bin/env python3
"""Independently receive retained native observations; never execute the helper.

All Windows observations come from the authenticated hosted artifact. This
receiver checks their raw fields and bindings in Linux; it makes no native calls.
"""
import base64
from datetime import datetime
import hashlib
import io
import json
from pathlib import Path, PureWindowsPath
import re
import stat
import zipfile

ROOT = Path('/workspace/scratch/097486cde2dd')
RAW = ROOT / 'a4-tool-profile-native-44960177535'
HERE = Path(__file__).resolve().parent
SOURCE = ROOT / 'dg18-a4-tool-profile-r2'
RUN = 44960177535
JOB = 137017031461
ARTIFACT = 14728972798
HEAD = '53733a8081d518fdc58df9bfff0cefad618aea5c'
TREE = '518a52e8512d03524ffd919e1c124d2e90a676f7'
PARENT = '51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
BASE = '9c3913ceaa95f3f36b0377fe2dba4a302afcba89'
BRANCH = 'pro/dg18-a4-tool-profile-20261121-01'
REPO = 'theislampill/IMPLEMENTAUDIT.md'
HELPER_SHA = 'aa61123993614898f8d731352d04862a5a8fe9b77d1811f640e40870e8bf09b5'
OUTER_SHA = 'e01f0ee480c54f3b48f2f6baf4694f195423c4a42ed1aae3f8cf78288b700c2d'
TARGETS = [r'C:\Program Files\Git\ucrt64\bin\git.exe', r'C:\Program Files\Git\mingw64\bin\git.exe',
           r'C:\Program Files\Git\bin\git.exe', r'C:\hostedtoolcache\windows\Python\3.12.10\x64\python.exe']
CROSS_FIELDS = ('st_ino', 'st_dev', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_birthtime_ns',
                'st_file_attributes', 'st_reparse_tag')
STAT_FIELDS = (*CROSS_FIELDS, 'st_mode', 'st_ctime_ns', 'st_atime_ns')
NATIVE_FIELDS = ('file_attributes', 'reparse', 'volume_serial', 'file_index', 'file_bytes',
                 'number_of_links', 'creation_filetime', 'access_filetime', 'write_filetime')

def digest(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def read(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    raw = path.read_bytes()
    after = path.lstat()
    stable = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    assert stable(before) == stable(after)
    return raw

def load(name):
    return json.loads(read(RAW / name))

def observed(value):
    return (type(value) is dict and value.get('status') == 'OBSERVED' and type(value.get('fields')) is dict
            and all(type(value['fields'].get(k)) is int for k in STAT_FIELDS))

def same_api(a, b):
    if not observed(a) or not observed(b):
        return None
    project = lambda v: {k: x for k, x in v['fields'].items() if k != 'st_atime_ns'}
    return project(a) == project(b)

def cross_api(path, held):
    if not observed(path) or not observed(held):
        return None
    p, f = path['fields'], held['fields']
    ordinary = path.get('path') in TARGETS
    for row in (path, held):
        ordinary &= row['regular'] is True and row['directory'] is False and row['symlink'] is False and row['reparse'] is False
        ordinary &= not row['fields']['st_file_attributes'] & 0x410 and row['fields']['st_reparse_tag'] == 0
    return bool(ordinary and all(p[k] == f[k] for k in CROSS_FIELDS)
                and f['st_mode'] == (stat.S_IFREG | (0o444 if f['st_file_attributes'] & 1 else 0o666))
                and p['st_mode'] == (stat.S_IFREG | (0o444 if p['st_file_attributes'] & 1 else 0o666) | 0o111)
                and p['st_ctime_ns'] == p['st_birthtime_ns'])

def compare_raw(row):
    checks = {'path': same_api(row.get('path_before'), row.get('path_final')),
              'descriptor': same_api(row.get('held_before'), row.get('held_after')),
              'cross_before': cross_api(row.get('path_before'), row.get('held_before')),
              'cross_after': cross_api(row.get('path_final'), row.get('held_after'))}
    a, b = row.get('ancestors_before'), row.get('ancestors_final')
    if not isinstance(a, list) or not isinstance(b, list) or not a or not b:
        ancestors = None
    elif len(a) != len(b):
        ancestors = False
    else:
        pairs = [same_api(x, y) for x, y in zip(a, b)]
        ancestors = None if any(x is None for x in pairs) else all(pairs) and all(x['path'] == y['path'] for x, y in zip(a, b))
    checks['ancestors'] = ancestors
    a, b = row.get('native_before'), row.get('native_after')
    if not all(isinstance(v, dict) and all(k in v for k in NATIVE_FIELDS) for v in (a, b)):
        checks['native_handle'] = None
    else:
        clean = lambda v: {k: x for k, x in v.items() if k != 'access_filetime'}
        checks['native_handle'] = clean(a) == clean(b)
    a, b = row.get('native_final_path_before'), row.get('native_final_path_after')
    if not all(isinstance(v, dict) and v.get('status') == 'OBSERVED' and isinstance(v.get('value'), str) for v in (a, b)):
        checks['native_path'] = None
    else:
        checks['native_path'] = a['value'] == b['value']
    assert set(checks) == set(row['comparisons'])
    for key, value in checks.items():
        assert row['comparisons'][key]['equal'] is value
        assert row['comparisons'][key]['status'] == ('INCOMPLETE' if value is None else 'MATCH' if value else 'MISMATCH')
    assert row['path_to_held_identity_equal'] is checks['cross_before']
    return checks

def main():
    run_list, run, jobs, artifacts = map(load, ['RUN_LIST.json', 'RUN_ATTEMPT_1.json', 'JOBS_ATTEMPT_1.json', 'ARTIFACTS.json'])
    assert run_list['total_count'] == len(run_list['workflow_runs']) == 1
    for r in (run_list['workflow_runs'][0], run):
        assert r['id'] == RUN and r['run_attempt'] == 1 and r['run_number'] == 1
        assert r['head_sha'] == HEAD and r['head_branch'] == BRANCH and r['head_commit']['id'] == HEAD
        assert r['repository']['full_name'] == r['head_repository']['full_name'] == REPO
        assert r['repository']['id'] == r['head_repository']['id'] == 1243475954
        assert r['event'] == 'push' and r['status'] == 'completed' and r['conclusion'] == 'success'
        assert r['workflow_id'] == 426370811 and r['path'] == '.github/workflows/dg18-a4-tool-profile.yml'
    host = load('HOST_COMMIT.json')
    assert host['sha'] == HEAD and host['tree']['sha'] == TREE and [x['sha'] for x in host['parents']] == [PARENT]
    source_readbacks = []
    expected = json.loads(read(SOURCE / 'EXPECTED_TREE.json'))
    for raw_name, source_name in [('PUBLISHED_HELPER.json', 'tool_profile.py'), ('PUBLISHED_WORKFLOW.json', 'workflow.yml')]:
        item = load(raw_name)['structuredContent']
        assert item['encoding'] == 'base64'
        body = base64.b64decode(item['content'])
        assert body == read(SOURCE / source_name)
        blob = hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()
        assert item['sha'] == blob
        pin = next(v for v in expected['new_files'].values() if v['local_file'] == source_name)
        assert digest(body) == {k: pin[k] for k in ('bytes', 'sha256')} and blob == pin['git_blob']
        source_readbacks.append({'local_source': source_name, 'git_blob': blob, **digest(body)})
    assert jobs['total_count'] == len(jobs['jobs']) == 1
    job = jobs['jobs'][0]
    assert job['id'] == JOB and job['run_id'] == RUN and job['run_attempt'] == 1 and job['head_sha'] == HEAD
    assert job['status'] == 'completed' and job['conclusion'] == 'success' and job['labels'] == ['windows-2022']
    assert job['name'] == 'installed-file-metadata-only'
    assert len(job['steps']) == 9 and all(x['status'] == 'completed' and x['conclusion'] == 'success' for x in job['steps'])
    for number, name in [(4, 'Observe four installed files without executing the tools'),
                         (5, 'Seal existing complete or interrupted profile without replay'),
                         (6, 'Retain exact observed metadata and explicit refusals')]:
        assert next(x for x in job['steps'] if x['number'] == number)['name'] == name
    assert artifacts['total_count'] == len(artifacts['artifacts']) == 1
    artifact = artifacts['artifacts'][0]
    assert artifact['id'] == ARTIFACT and artifact['name'] == f'dg18-a4-tool-profile-{RUN}-1' and not artifact['expired']
    assert artifact['workflow_run'] == {'id': RUN, 'repository_id': 1243475954, 'head_repository_id': 1243475954,
                                        'head_branch': BRANCH, 'head_sha': HEAD}
    outer = read(RAW / 'PROVIDER_ARTIFACT.zip')
    assert digest(outer) == {'bytes': artifact['size_in_bytes'], 'sha256': artifact['digest'].removeprefix('sha256:')}
    assert len(outer) == 14421 and hashlib.sha256(outer).hexdigest() == OUTER_SHA
    with zipfile.ZipFile(io.BytesIO(outer)) as z:
        assert len(z.namelist()) == 2 and set(z.namelist()) == {'PROFILE_EVIDENCE.zip', 'ZIP_RECEIPT.json'} and z.testzip() is None
        for item in z.infolist():
            assert not item.flag_bits & 1 and not item.is_dir() and not stat.S_ISLNK(item.external_attr >> 16)
            assert z.read(item) == read(RAW / item.filename)
    receipt, inner = load('ZIP_RECEIPT.json'), read(RAW / 'PROFILE_EVIDENCE.zip')
    assert receipt['archive'] == digest(inner) and receipt['member_count'] == 12 and receipt['refusal_count'] == 0
    records = {}
    with zipfile.ZipFile(io.BytesIO(inner)) as z:
        assert len(z.namelist()) == len(set(z.namelist())) == 12 and z.testzip() is None
        expected_names = {'MANIFEST.json', 'INTENT.json', 'RESULT.json', 'FINALIZATION_INTENT.json'} | {
            f'PROFILE-{i:02d}{suffix}.json' for i in range(1, 5) for suffix in ('', '-INTENT')}
        assert set(z.namelist()) == expected_names
        for item in z.infolist():
            assert item.file_size <= 1024 * 1024 and not item.flag_bits & 1 and not item.is_dir() and not stat.S_ISLNK(item.external_attr >> 16)
            raw = z.read(item)
            assert raw == read(RAW / 'records' / item.filename)
            records[item.filename] = json.loads(raw)
    manifest = records['MANIFEST.json']
    assert len(manifest['members']) == 11 and {x['path'] for x in manifest['members']} == expected_names - {'MANIFEST.json'}
    assert not manifest['refusals']
    for item in manifest['members']:
        assert digest(read(RAW / 'records' / item['path'])) == {k: item[k] for k in ('bytes', 'sha256')}
    assert manifest['payload_bytes'] == sum(x['bytes'] for x in manifest['members']) <= 8 * 1024 * 1024
    intent, finalizer, result = (records[x] for x in ('INTENT.json', 'FINALIZATION_INTENT.json', 'RESULT.json'))
    binding = {'run_id': RUN, 'attempt': 1, 'host_commit': HEAD, 'branch': BRANCH,
               'helper': {'bytes': 28985, 'sha256': HELPER_SHA}}
    for row in (intent, finalizer):
        assert all(row[k] == v for k, v in binding.items())
    context = {'authority': 'NONE', 'award': None, 'operation': 'METADATA_ONLY_NO_TOOL_ADMISSION',
               'source_parent': PARENT, 'source_tree': BASE, 'source_revision': 'R2',
               'original_memory_guard_bytes': 67108864, 'original_memory_guard_changed': False,
               'original_method_order_changed': False, 'original_method_executions': 0,
               'Git_product_Job_executions': 0, 'alias_admissions': 0, 'A4_07': 'UNKNOWN_NO_REPLAY',
               'frozen_R01_R09_contract_available': False, 'historical_selected_Git_spelling': 'UNRECORDED',
               'automatic_retry': False}
    for row in (intent, finalizer, result, manifest, receipt, *(records[f'PROFILE-{i:02d}.json'] for i in range(1, 5))):
        assert all(row[k] == v for k, v in context.items())
    assert intent['targets'] == TARGETS and intent['windows'] == {'build': 20348, 'major': 10, 'minor': 0, 'platform': 2, 'product_type': 3}
    assert intent['python'].startswith('3.12.10 (tags/v3.12.10:') and '64 bit (AMD64)' in intent['python']
    assert intent['bounds'] == {'alias_records_per_file': 32, 'all_installed_file_read_bytes': 67108868,
        'cooperative_seconds': 45, 'file_read_bytes': 16777217, 'files': 4, 'native_name_buffer_characters': 4096,
        'output_file_bytes': 1048576, 'output_files': 16, 'output_total_bytes': 8388608, 'read_chunk': 65536}
    assert finalizer['cooperative_seconds'] == 20 and finalizer['profile_replayed'] is False and finalizer['profile_completion_inferred'] is False
    assert result['profile_count'] == len(result['profiles']) == 4
    assert result['status'] == 'METADATA_RECORDED_WITH_EXPLICIT_PARTIALS_NO_ADMISSION'
    profile_facts = []; partial = []; total_read = 0; previous_time = intent['started_ns']
    for i, target in enumerate(TARGETS, 1):
        row, started = records[f'PROFILE-{i:02d}.json'], records[f'PROFILE-{i:02d}-INTENT.json']
        assert row['index'] == started['index'] == i and row['path'] == started['path'] == target
        assert started['tool_execution_authorized'] is False
        assert previous_time <= started['started_ns'] <= row['started_ns'] <= row['completed_ns'] <= result['completed_ns']
        previous_time = row['completed_ns']
        parents = [str(p) for p in PureWindowsPath(target).parents]
        assert [x['path'] for x in row['ancestors_before']] == [x['path'] for x in row['ancestors_final']] == parents
        checks = compare_raw(row)
        hashed, links, native = row.get('hash'), row.get('hardlinks'), row.get('native_after')
        stable = all(x is True for x in checks.values()) and isinstance(hashed, dict) and hashed.get('status') == 'EOF_OBSERVED' and hashed.get('matches_held_size') is True
        assert row['stable_read_observed'] is stable
        assert row['stable_read_status'] == ('INCOMPLETE' if any(x is None for x in checks.values()) else 'OBSERVED_STABLE' if stable else 'NOT_ESTABLISHED')
        count_match = links['recorded_names'] == native['number_of_links'] if isinstance(links, dict) and isinstance(native, dict) else None
        assert row['hardlink_count_matches_native'] is count_match
        factual = stable and isinstance(links, dict) and links['status'] == 'COMPLETE' and links['close_succeeded'] is True and count_match is True and row['handle_closed'] is True and row['errors'] == []
        assert row['status'] == ('FACTUAL_PROFILE_OBSERVED_NO_ADMISSION' if factual else 'PARTIAL_METADATA_REFUSAL')
        summary = {'index': i, 'status': row['status'], 'handle_closed': row['handle_closed'], 'error_count': len(row['errors']),
                   'hardlink_status': links.get('status') if isinstance(links, dict) else None}
        assert result['profiles'][i - 1] == summary
        fact = {'index': i, 'path': target, 'status': row['status'], 'stable_read_observed': stable,
                'comparisons_independently_recomputed': checks, 'handle_closed': row['handle_closed'], 'errors': row['errors']}
        if factual:
            p, f = row['path_before']['fields'], row['held_before']['fields']
            assert all(x['directory'] is True and x['reparse'] is False and x['symlink'] is False for x in row['ancestors_before'] + row['ancestors_final'])
            assert row['native_file_type'] == 1 and row['native_file_type_last_error'] == 0
            assert hashed['bytes_read'] == p['st_size'] == f['st_size'] == native['file_bytes'] <= 16 * 1024 * 1024
            assert re.fullmatch('[0-9a-f]{64}', hashed['sha256']) and hashed['matches_held_size'] is True
            assert p['st_nlink'] == f['st_nlink'] == native['number_of_links'] == links['recorded_names'] == len(links['names'])
            assert len(set(links['names'])) == len(links['names']) <= 32
            assert links['record_limit'] == 32 and links['name_capacity_characters'] == 4096 and links['winerror'] == 38
            assert links['aliases_opened'] == links['aliases_admitted'] == 0
            assert all(name.startswith('\\') and len(name.encode('utf-16-le')) // 2 < 4096 for name in links['names'])
            assert p['st_ino'] == f['st_ino'] == native['file_index']
            assert p['st_file_attributes'] == f['st_file_attributes'] == native['file_attributes']
            assert native['reparse'] is False
            assert f['st_birthtime_ns'] == (native['creation_filetime'] - 116444736000000000) * 100
            assert f['st_mtime_ns'] == (native['write_filetime'] - 116444736000000000) * 100
            assert row['native_final_path_before']['value'] == row['native_final_path_after']['value'] == '\\\\?\\' + target
            assert row['native_final_path_before']['characters'] == len(('\\\\?\\' + target).encode('utf-16-le')) // 2
            total_read += hashed['bytes_read']
            fact.update(size=p['st_size'], path_link_count=p['st_nlink'], descriptor_link_count=f['st_nlink'],
                        native_link_count=native['number_of_links'], aliases=links['names'], hash_observation=hashed,
                        file_index=native['file_index'], stat_device=p['st_dev'], native_volume_serial=native['volume_serial'],
                        path_mode=oct(p['st_mode']), descriptor_mode=oct(f['st_mode']),
                        path_ctime_ns=p['st_ctime_ns'], descriptor_ctime_ns=f['st_ctime_ns'], birthtime_ns=f['st_birthtime_ns'],
                        native_final_path=row['native_final_path_before']['value'])
        else:
            partial.append(i)
            assert i == 2 and all(x is None for x in checks.values()) and row['handle_closed'] is None
            assert all(key not in row for key in ('held_before', 'held_after', 'native_before', 'native_after', 'hash', 'hardlinks'))
            for phase in ('path_before', 'path_final'):
                assert row[phase]['status'] == 'ERROR' and row[phase]['error']['type'] == 'FileNotFoundError' and row[phase]['error']['winerror'] == 3
            fact.update(path_before=row['path_before'], path_final=row['path_final'], file_bytes_observed=False, link_count_observed=False)
        profile_facts.append(fact)
    assert intent['started_ns'] <= result['completed_ns'] <= finalizer['at_ns']
    assert result['completed_ns'] - intent['started_ns'] <= 45 * 10**9
    capture = {'cleanup_inferred': False, 'complete_profile_population': True, 'native_success_inferred': False,
               'partial_profiles': partial, 'status': 'PROFILE_POPULATION_RECORDED_WITH_PARTIALS' if partial else 'PROFILE_POPULATION_RECORDED'}
    assert manifest['capture_completeness'] == receipt['capture_completeness'] == capture
    logs = read(RAW / 'JOB_LOG.txt')
    assert digest(logs) == {'bytes': 20824, 'sha256': '93869a3593736b26fd9298cdf268881a65d4d04a1ecd50e65ef2b78658c18e02'}
    text = logs.decode('utf-8-sig')
    for required in (HEAD, HELPER_SHA, '--step profile', '--step finalize', 'Successfully set up CPython (3.12.10)',
                     'Microsoft Windows Server 2022', '10.0.20348', 'Version: 20261116.370.1', OUTER_SHA,
                     f'Artifact ID {ARTIFACT}', 'Final size is 14421 bytes'):
        assert required in text
    assert '##[error]' not in text
    outcome = {'schema': 'dg18.a4.native-profile-independent-receiving.v1', 'authority': 'NONE', 'receiving': 'PASS',
               'run_id': RUN, 'run_attempt': 1, 'run_conclusion': 'success', 'job_id': JOB, 'host_commit': HEAD,
               'host_tree': TREE, 'sole_parent': PARENT, 'source_readbacks': source_readbacks,
               'provider_artifact_id': ARTIFACT, 'provider_artifact': digest(outer), 'provider_digest_match': True,
               'inner_archive': digest(inner), 'inner_member_count': 12, 'inner_manifest_payload_bytes': manifest['payload_bytes'],
               'inner_all_member_hashes_match': True, 'capture_completeness_independently_recomputed': capture,
               'native_environment': {'python': intent['python'], 'windows': intent['windows'], 'runner_image': '20261116.370.1'},
               'profile_facts': profile_facts, 'observed_total_file_bytes_read': total_read,
               'actual_memory_measurement': False, 'installed_bytes_rehashed_by_receiver': False,
               'installed_hashes_scope': 'actual held-file digest observations produced by the reviewed native helper',
               'raw_log': digest(logs), 'raw_log_scope': 'exact connector-returned decoded UTF-8 log body, preserving BOM and CRLF',
               'receiver_candidate_imports': 0, 'receiver_native_calls': 0, 'receiver_provider_writes': 0,
               'receiver_Root_controller_calls': 0, 'receiver_artifact_downloads': 1, 'receiver_retries': 0,
               'original_method_executions': 0, 'memory_worker_executions': 0, 'new_original_awards': [],
               'historical_failure_selected_spelling': 'UNRECORDED', 'A4_07': 'UNKNOWN_NO_REPLAY',
               'frozen_R01_R09_contract': 'UNAVAILABLE', 'native_error_injection_or_timeout_test': False}
    with (HERE / 'MECHANICAL_RECEIVING.json').open('x') as stream:
        json.dump(outcome, stream, sort_keys=True, indent=2); stream.write('\n')
    print(json.dumps({'receiving': 'PASS', 'run_id': RUN, 'factual_profiles': [r['index'] for r in profile_facts if r['status'] == 'FACTUAL_PROFILE_OBSERVED_NO_ADMISSION'],
                      'partial_profiles': partial, 'observed_total_file_bytes_read': total_read,
                      'inner_payload_bytes': manifest['payload_bytes'], 'native_original_awards': [],
                      'mechanical_receipt': digest(read(HERE / 'MECHANICAL_RECEIVING.json'))}, indent=2))

if __name__ == '__main__':
    main()
