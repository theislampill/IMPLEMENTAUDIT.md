#!/usr/bin/env python3
"""Consume one authenticated artifact file URL through a non-echoing stdin.

No URL is logged or saved. Only the bounded ZIP bytes and their digest are saved.
"""
import hashlib
import json
from pathlib import Path
import sys
import termios
import urllib.request

state = termios.tcgetattr(sys.stdin.fileno())
private = list(state)
private[3] &= ~termios.ECHO
termios.tcsetattr(sys.stdin.fileno(), termios.TCSANOW, private)
print('READY_FOR_PRIVATE_URL', flush=True)
url = sys.stdin.readline().rstrip('\r\n')
assert url.startswith('https://')
output = Path(__file__).resolve().parent / 'PROVIDER_ARTIFACT.zip'
bound = 20 * 1024 * 1024
total = 0
hashed = hashlib.sha256()
with urllib.request.urlopen(url, timeout=30) as response, output.open('xb') as stream:
    while True:
        data = response.read(min(65536, bound + 1 - total))
        if not data:
            break
        total += len(data)
        if total > bound:
            raise ValueError('artifact byte bound exceeded')
        stream.write(data)
        hashed.update(data)
url = None
assert total == 14421
assert hashed.hexdigest() == 'e01f0ee480c54f3b48f2f6baf4694f195423c4a42ed1aae3f8cf78288b700c2d'
receipt = {'artifact_id': 14728972798, 'bytes': total, 'sha256': hashed.hexdigest(),
           'provider_digest_match': True, 'signed_url_saved': False, 'artifact_downloads': 1}
with output.with_name('DOWNLOAD_RECEIPT.json').open('x') as stream:
    json.dump(receipt, stream, sort_keys=True, indent=2)
    stream.write('\n')
print(json.dumps(receipt), flush=True)
