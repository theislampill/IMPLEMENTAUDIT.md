# A4 installed-tool metadata profile R2: independent source review

**Disposition: PASS for the focused pre-execution source review.** R2 addresses the two blocking R1 source findings and supplies the separately bounded finalization route requested for L-01. This review identifies no further source revision required before Root's separate admission decision. Authority is **NONE**: this is ordinary independent engineering advice, not an internal `audit-assess` route, execution admission, original-method award, or closure.

Reviewer: `/root/a4_tool_profile_r2_review`. The reviewer authored no candidate and made no candidate changes. The complete first review report, findings and retained official CPython evidence were read, followed by the complete R2 report, design, source delta, helper, workflow and both control sources. Candidate modules and controls were neither imported nor executed. No Windows/native, product, Job, memory-worker or original episode ran in this review. No provider write, Root controller call, Git process or network operation was performed. The only writes are the new review artifacts in this directory.

## Exact inputs and independent receiving

| Item | Independently received identity |
|---|---|
| R2 frozen seal | 3,188 bytes; SHA-256 `49a8176eda0d51b9208518b3db5a5418ab24b294d4ec5d75c4cacc1166fcb7b3` |
| R2 payload | Exact 12 members, 94,459 bytes; every byte count, SHA-256, Git blob ID and mode matched |
| R2 helper | 28,985 bytes; SHA-256 `aa61123993614898f8d731352d04862a5a8fe9b77d1811f640e40870e8bf09b5`; blob `4fc2977cd4285859b74ae89023ea093557e13d66` |
| R2 workflow | 3,927 bytes; SHA-256 `f3ef1cb91185686bbe3049eec1b5b41dd717cf7ccd35c5a102d1176f67b99db5`; blob `00a79a92673eebb422d1354693e81be13f146b78` |
| Preserved R1 seal | 2,211 bytes; SHA-256 `f3880386a8d8d7b0aba56b1cdfbe8423d59cfc8e61f89457b05bcb1dbcb65f5c`; all eight payloads / 40,448 bytes remain exact |
| Preserved first-review seal | 2,125 bytes; SHA-256 `258fe649ebb243f2ec558dbefe15f2d75c290b326106cf8b79c3b1825a6d2d28`; all seven payloads / 45,707 bytes remain exact |
| Exact source/workflow delta | Two file sections, nine hunks, 20,005 bytes; SHA-256 `e107970edab6ac399bea9c49759f984ca4701ae5cfc36ed76d84ec0ace7c9eef` |
| Sole proposed parent | `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7` |
| Received parent tree | `9c3913ceaa95f3f36b0377fe2dba4a302afcba89`, 1,785 leaves |
| Independently rederived R2 tree | `518a52e8512d03524ffd919e1c124d2e90a676f7`, 1,787 leaves |
| Prospective branch | `pro/dg18-a4-tool-profile-20261121-01`; unissued status is supplied by Root, not freshly established through the provider by this reviewer |

The complete additive tree was independently reconstructed from existing local immutable objects, adding only `.github/workflows/dg18-a4-tool-profile.yml` and `handoff/pro-executor-results-20261115/dg18-a4-tool-profile/tool_profile.py`. The receiver decodes the local object files directly; it does not launch Git, access a remote, fetch missing objects, traverse commit parents, or write an object/index/ref. It hash-verifies the pinned parent record, all 449 reachable tree objects and two inherited workflow blobs. The unchanged inherited push filters do not select this diagnostic branch.

`MECHANICAL_RECEIVING.json` records these checks, the full workflow, all three packets' member identities, the unchanged definitions/constants, and the exact tree derivation. The receiving command completed as `e4645b/0`. All three candidate Python sources parse, and the workflow parses as YAML. No qualification control was rerun. R2's retained CPython source evidence is byte-identical to the first review's sealed `CPYTHON_SOURCE_EVIDENCE.json`.

## Disposition of the first review's findings

### GAP-01 — resolved in source: explicit cross-API mapping, strict same-API comparisons

`cross_api_identity()` accepts only one of the four fixed executable spellings and requires complete integer stat fields. It retains exact equality for device, full inode integer, link count, size, last-write time, birth time, file attributes and reparse tag. Both observations must describe ordinary regular files, without directory or reparse attributes and with zero reparse tag.

The mode relation is narrow: descriptor mode must be `S_IFREG` plus the documented read-only-attribute-derived `0444` or `0666`; the path mode must be the corresponding value plus the executable-name `0111` heuristic. It does not blindly mask unexpected execute bits. Path ctime must equal path birth time. Descriptor ctime is retained and compared within descriptor before/after observations; it is not equated to path creation time. Missing fields remain `INCOMPLETE`, and differing device/file-ID fallback representations refuse equivalence instead of truncating or guessing correspondence.

This matches the exact-release evidence retained from official CPython v3.12.10: `Modules/posixmodule.c`, blob `c21c6f06c729de2ac1a4598180a394261c86e53b`, for the executable-name heuristic and path ctime wrapper; and `Python/fileutils.c`, blob `c7521751cd26d14ce41b9ea0f93b95e27221f8a7`, for attribute-derived mode and descriptor creation/change times. No unverified native-platform observation was substituted for that source evidence.

The old `identity()` function is unchanged. `same_api_comparison()` continues to compare every captured field except access time, including the complete mode and ctime. `complete_profile()` applies it separately to the target path, held descriptor and each corresponding ancestor. Thus the semantic accommodation does not relax before/after mode or ChangeTime stability. Raw observations remain unmodified. This addresses both independent R1 mismatches.

### GAP-02 — resolved in source: incomplete native-after observations retain the row

The former unconditional use of missing `native_after` has been removed. `complete_profile()` checks each comparison's required observations and emits `INCOMPLETE` when they are absent. The descriptor-after assignment followed by a failing native-after operation now records the named `native_after` error, proceeds through descriptor/handle cleanup, and returns the current row for exclusive persistence. Its native-handle comparison remains incomplete; it cannot receive the factual-profile status or establish a stable read.

The completion function is total over the partial records produced by this helper's ordinary caught-error paths. The original exception and accumulated metadata are preserved instead of being replaced by the prior secondary `KeyError`. This is source-control-flow verification; no native failure was injected or executed during this review.

One status distinction should remain precise when receiving future data: `stable_read_observed` describes the completed hash and comparison observations. The stronger `FACTUAL_PROFILE_OBSERVED_NO_ADMISSION` status additionally requires complete hardlink enumeration, successful enumeration closure, matching link count, successful file-handle closure, and an empty error list. Cleanup or enumeration failures keep the row partial even if its narrower read observations are stable. The report's grouped wording should not be interpreted as making those two labels interchangeable.

### L-01 — addressed for surviving workflow continuation: independent finalization

The profile no longer owns the only archive-creation path. The workflow invokes the same hash-pinned helper with `--step finalize` in a separate `always()` step bounded to one minute. The finalizer has a separate 20-second cooperative deadline, rechecks the runtime/provider/run/helper binding, and calls no installed-file profiling or alias enumeration. It seals existing bytes without replaying a profile.

Finite names, single-link ordinary JSON-file checks, per-record and total byte caps, repeated identity checks, content digests, exclusive manifest/archive/receipt creation and ZIP verification remain present. The manifest and ZIP receipt include a capture-completeness record. Missing terminal results, fatal or conflicting terminals, missing records, or invalid/inconsistent records remain explicit incomplete outcomes. If all four rows are present but some are partial, completeness refers to the recorded population and explicitly does not infer native success or cleanup. An absent output directory produces an absence observation.

This resolves the absence of an independent source-level retention route after a profile step ends. It does not guarantee survival of the finalizer, runner, entire job, or uploader. It retains files already written to disk; it cannot reconstruct in-memory metadata from the currently interrupted profile. No timeout experiment or hosted finalization has occurred in this review.

## Other scope and bound checks

The original fixed targets and all resource constants are unchanged: `C:\Program Files\Git\ucrt64\bin\git.exe`, `C:\Program Files\Git\mingw64\bin\git.exe`, `C:\Program Files\Git\bin\git.exe`, and `C:\hostedtoolcache\windows\Python\3.12.10\x64\python.exe`. The profile can read at most 16 MiB plus one sentinel byte per attempted target, four targets total, in 64 KiB chunks. There is no memory worker or product/original invocation. The selected Python interpreter runs the diagnostic; Git execution by ordinary credential-free checkout remains provisioning, outside the helper's metadata-only operation.

`Native`, `FILETIME`, `INFO`, `streamed_hash`, `require_windows`, `provider_binding` and the remaining unchanged safety definitions were compared structurally with R1. The actual hardlink enumerator retains its fixed 4,096-character buffer, at most 32 recorded names, and one additional successful result only to detect truncation. Only `ERROR_HANDLE_EOF` establishes enumeration completion. Returned alias strings are not opened or admitted. Native errors, duplicates, buffer/count refusal and enumeration-close failures remain explicit. Native ABI compatibility remains unexecuted evidence.

The read-only `CreateFileW` path, noninheritable handle, `OPEN_EXISTING`, `FILE_SHARE_READ`, `FILE_FLAG_OPEN_REPARSE_POINT`, ordinary-disk/reparse checks, single CRT ownership transfer, binary mode and owner cleanup remain unchanged. Raw path, descriptor, native handle, final path and ancestor metadata remain distinct observations. They establish an observed interval when comparisons match; they do not prove enduring namespace immutability or confer executable custody.

The workflow retains the exact repository, push branch/ref, fresh branch creation, zero-before, nondeleted event and attempt-1 restrictions. The helper also checks event-after against `GITHUB_SHA`, the exact run-specific output directory, helper location and hosted Windows environment. It requires actual CPython 3.12.10 x64 and the exact interpreter spelling; the profile checks the intended Server 2022 kernel tuple before attempting the four profiles. Root retains the external sole-parent/full-tree and branch-freshness gate.

Checkout, setup-python and artifact upload remain pinned to full commit IDs. Checkout targets `github.sha`, disables credential persistence, submodules and LFS, and fetches depth one. The job is bounded to eight minutes; profile to two minutes with a shared 45-second cooperative deadline; finalization to one minute with its own cooperative deadline. Cooperative checks cannot interrupt an individual blocked system call. There is no helper subprocess, Git, network or dynamic product-loading path, no retry of the native profile, and no new secret request or environment dump. The upload population is the exact archive and receipt.

## Qualification scope and remaining gates

The retained local controls cover constructed CPython metadata pairs, drift/missing-field refusals, partial error-shaped records, full same-API mode/ctime checks, actual local partial-file sealing, actual Linux entry-point refusal, and local hardlink/missing-path/symlink observations. Their source and retained result hashes match. They are engineering controls and do not establish a Windows file fact, native API result, runtime hash, successful hosted timeout recovery, or original-method outcome. The original failure's selected spelling, individual file type and link count remain unobserved by this review.

Root supplied G0043 receipt `33c5296d4d9bf5ae370780b3d9895a8ce1b825cd` with required currentness `85538c/0`, and results publication 36 at `43f7291eee77fd4a007f258a26cfdb7b99f47350`. These are task context only; this reviewer neither revalidates nor changes Root's controller. The separate G132 ordinary run `44959365296` is outside this packet's evidence. Root must freshly establish provider branch absence, derive and receive any host commit and sole parent/full tree, issue any admission, and subsequently receive actual run/artifact evidence.

The original 64 MiB guard, 28-method order, A4-07 `UNKNOWN_NO_REPLAY`, missing frozen R01–R09 contract and prior awards remain unchanged. **New original awards: NONE. Native A4 profile: UNEXECUTED.** This PASS permits no inference of original A4 success or DG18 closure.
