#!/usr/bin/env python3
"""Independent read/hash/AST/YAML/source receiving only; never imports candidate code.

Git objects are read directly from already-present immutable local files. This
script neither launches Git nor walks commit history, fetches, or writes objects.
"""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import stat
import struct
import zlib
import yaml

ROOT = Path('/workspace/scratch/097486cde2dd')
HERE = Path(__file__).resolve().parent
R1 = ROOT / 'dg18-a4-tool-profile'
R2 = ROOT / 'dg18-a4-tool-profile-r2'
PRIOR = ROOT / 'a4-tool-profile-independent-review'
OBJECTS = Path('/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b/.git/objects')
PARENT = '51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
BASE_TREE = '9c3913ceaa95f3f36b0377fe2dba4a302afcba89'
NEW_TREE = '518a52e8512d03524ffd919e1c124d2e90a676f7'

def digest(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def oid(kind, raw):
    return hashlib.sha1(kind.encode() + b' ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

def identity(s):
    return (s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_size, s.st_mtime_ns, s.st_ctime_ns)

def receive(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1, path
    raw = path.read_bytes()
    assert identity(before) == identity(path.lstat()), path
    return raw, {**digest(raw), 'git_blob': oid('blob', raw),
                 'mode': format(stat.S_IFREG | stat.S_IMODE(before.st_mode), 'o')}

def packet(directory, seal_name, expected_seal, expected_count, expected_bytes):
    raw, sealed = receive(directory / seal_name)
    assert digest(raw) == expected_seal
    seal = json.loads(raw)
    assert set(p.name for p in directory.iterdir()) == {seal_name, *(r['path'] for r in seal['files'])}
    rows = []
    for row in seal['files']:
        assert Path(row['path']).name == row['path']
        _, actual = receive(directory / row['path'])
        assert all(actual[k] == row[k] for k in ('bytes', 'sha256', 'git_blob'))
        assert actual['mode'] == row.get('mode', '100644')
        rows.append({'path': row['path'], **actual})
    assert len(rows) == expected_count and sum(r['bytes'] for r in rows) == expected_bytes
    assert seal['payload_count'] == expected_count and seal['payload_bytes'] == expected_bytes
    return {'seal': sealed, 'payload_count': len(rows), 'payload_bytes': expected_bytes, 'files': rows}

class LocalObjects:
    """Small SHA-1 object reader; all resolved object bytes are hash checked."""
    def __init__(self):
        self.locations = {}
        self.cache = {}
        self.position_cache = {}
        self.index_count = 0
        self.resolved = {}
        for path in sorted((OBJECTS / 'pack').glob('*.idx')):
            raw = path.read_bytes()
            assert raw[:8] == b'\xfftOc\0\0\0\x02'
            assert hashlib.sha1(raw[:-20]).digest() == raw[-20:]
            count = struct.unpack_from('>I', raw, 8 + 255 * 4)[0]
            names = 8 + 1024
            offsets = names + count * 24
            large = offsets + count * 4
            for i in range(count):
                key = raw[names + i * 20:names + (i + 1) * 20].hex()
                offset = struct.unpack_from('>I', raw, offsets + i * 4)[0]
                if offset & 0x80000000:
                    offset = struct.unpack_from('>Q', raw, large + (offset & 0x7fffffff) * 8)[0]
                self.locations.setdefault(key, (path.with_suffix('.pack'), offset))
            self.index_count += 1

    @staticmethod
    def delta(base, delta):
        index = 0
        def variable():
            nonlocal index
            result = shift = 0
            while True:
                b = delta[index]; index += 1
                result |= (b & 0x7f) << shift
                if not b & 0x80:
                    return result
                shift += 7
        assert variable() == len(base)
        length = variable()
        assert length <= 64 * 1024 * 1024
        out = bytearray()
        while index < len(delta):
            command = delta[index]; index += 1
            if command & 0x80:
                offset = size = 0
                for bit in range(4):
                    if command & (1 << bit):
                        offset |= delta[index] << (bit * 8); index += 1
                for bit in range(3):
                    if command & (1 << (bit + 4)):
                        size |= delta[index] << (bit * 8); index += 1
                size = size or 0x10000
                assert offset + size <= len(base)
                out.extend(base[offset:offset + size])
            else:
                assert command and index + command <= len(delta)
                out.extend(delta[index:index + command]); index += command
            assert len(out) <= length
        assert len(out) == length
        return bytes(out)

    def position(self, pack, offset, depth=0):
        assert depth < 64
        key = (str(pack), offset)
        if key in self.position_cache:
            return self.position_cache[key]
        with pack.open('rb') as stream:
            assert stream.read(4) == b'PACK'
            assert struct.unpack('>I', stream.read(4))[0] in (2, 3)
            stream.seek(offset)
            b = stream.read(1)[0]
            kind = (b >> 4) & 7
            size = b & 15; shift = 4
            while b & 128:
                b = stream.read(1)[0]
                size |= (b & 127) << shift; shift += 7
            assert size <= 64 * 1024 * 1024
            base_position = base_oid = None
            if kind == 6:
                b = stream.read(1)[0]; distance = b & 127
                while b & 128:
                    b = stream.read(1)[0]
                    distance = ((distance + 1) << 7) | (b & 127)
                base_position = offset - distance
                assert 12 <= base_position < offset
            elif kind == 7:
                base_oid = stream.read(20).hex()
            decompressor = zlib.decompressobj()
            chunks = []; total = 0
            while not decompressor.eof:
                block = stream.read(65536)
                assert block
                data = decompressor.decompress(block)
                total += len(data); assert total <= size
                chunks.append(data)
            raw = b''.join(chunks)
            assert len(raw) == size
        if kind in (6, 7):
            base_kind, base = (self.position(pack, base_position, depth + 1) if kind == 6
                               else self.get(base_oid, depth + 1))
            result = base_kind, self.delta(base, raw)
        else:
            result = {1: 'commit', 2: 'tree', 3: 'blob', 4: 'tag'}[kind], raw
        self.position_cache[key] = result
        return result

    def get(self, key, depth=0):
        if key in self.cache:
            return self.cache[key]
        loose = OBJECTS / key[:2] / key[2:]
        if loose.is_file():
            data = zlib.decompress(loose.read_bytes())
            header, raw = data.split(b'\0', 1)
            kind, size = header.split(b' ')
            assert int(size) == len(raw)
            result = kind.decode(), raw
        else:
            result = self.position(*self.locations[key], depth=depth)
        assert oid(*result) == key
        self.cache[key] = result
        self.resolved[key] = {'kind': result[0], **digest(result[1])}
        return result

def tree_entries(raw):
    position = 0
    while position < len(raw):
        boundary = raw.index(b'\0', position)
        mode, name = raw[position:boundary].split(b' ', 1)
        position = boundary + 1
        child = raw[position:position + 20].hex(); position += 20
        assert len(child) == 40 and b'/' not in name
        yield mode, name, child
    assert position == len(raw)

def rebuild(leaves):
    root = {}
    for path, value in leaves.items():
        cursor = root
        pieces = path.split(b'/')
        for piece in pieces[:-1]:
            cursor = cursor.setdefault(piece, {})
        assert pieces[-1] not in cursor
        cursor[pieces[-1]] = value
    def assemble(node):
        rows = []
        for name, value in node.items():
            directory = isinstance(value, dict)
            mode, sha = (b'40000', assemble(value)) if directory else value
            rows.append((name + (b'/' if directory else b''), mode + b' ' + name + b'\0' + bytes.fromhex(sha)))
        return oid('tree', b''.join(raw for _, raw in sorted(rows)))
    return assemble(root)

def main():
    r2 = packet(R2, 'FROZEN_SEAL.json', {'bytes': 3188, 'sha256': '49a8176eda0d51b9208518b3db5a5418ab24b294d4ec5d75c4cacc1166fcb7b3'}, 12, 94459)
    r1 = packet(R1, 'FROZEN_SEAL.json', {'bytes': 2211, 'sha256': 'f3880386a8d8d7b0aba56b1cdfbe8423d59cfc8e61f89457b05bcb1dbcb65f5c'}, 8, 40448)
    prior = packet(PRIOR, 'SEAL.json', {'bytes': 2125, 'sha256': '258fe649ebb243f2ec558dbefe15f2d75c290b326106cf8b79c3b1825a6d2d28'}, 7, 45707)
    assert (R2 / 'REVIEW_SOURCE_EVIDENCE.json').read_bytes() == (PRIOR / 'CPYTHON_SOURCE_EVIDENCE.json').read_bytes()
    source_paths = {'tool_profile.py': 'handoff/pro-executor-results-20261115/dg18-a4-tool-profile/tool_profile.py',
                    'workflow.yml': '.github/workflows/dg18-a4-tool-profile.yml'}
    delta = ''.join(''.join(difflib.unified_diff((R1 / name).read_text().splitlines(keepends=True),
                        (R2 / name).read_text().splitlines(keepends=True),
                        fromfile='R1/' + hosted, tofile='R2/' + hosted))
                    for name, hosted in source_paths.items())
    assert delta.encode() == (R2 / 'R1_TO_R2.patch').read_bytes()
    parsed = {p.name: ast.parse(p.read_bytes(), filename=str(p)) for p in R2.glob('*.py')}
    old = ast.parse((R1 / 'tool_profile.py').read_bytes())
    new = parsed['tool_profile.py']
    definitions = lambda tree: {n.name: n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    old_defs, new_defs = definitions(old), definitions(new)
    unchanged = [name for name in old_defs if ast.dump(old_defs[name]) == ast.dump(new_defs[name])]
    for name in ('identity', 'Native', 'FILETIME', 'INFO', 'streamed_hash', 'require_windows', 'provider_binding'):
        assert name in unchanged
    assignments = lambda tree: {n.targets[0].id: n.value for n in tree.body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)}
    old_constants, new_constants = assignments(old), assignments(new)
    stable_constants = ('SOURCE_COMMIT', 'SOURCE_TREE', 'BRANCH', 'HELPER_PATH', 'WORKFLOW_PATH', 'PYTHON_PATH',
                        'TARGETS', 'FILE_LIMIT', 'READ_CHUNK', 'NAME_CAP', 'ALIAS_CAP', 'SECONDS', 'JSON_LIMIT', 'OUTPUT_LIMIT')
    assert all(ast.dump(old_constants[name]) == ast.dump(new_constants[name]) for name in stable_constants)
    imports = sorted({alias.name for node in ast.walk(new) if isinstance(node, ast.Import) for alias in node.names} |
                     {node.module for node in ast.walk(new) if isinstance(node, ast.ImportFrom)})
    assert not set(imports) & {'subprocess', 'multiprocessing', 'socket', 'urllib', 'requests', 'runpy', 'importlib'}
    workflow = yaml.load((R2 / 'workflow.yml').read_bytes(), Loader=yaml.BaseLoader)
    job = workflow['jobs']['installed-file-metadata-only']
    assert job['runs-on'] == 'windows-2022' and job['timeout-minutes'] == '8'
    profile, finalizer, upload = job['steps'][2:]
    assert profile['timeout-minutes'] == '2'
    assert finalizer['if'] == 'always()' and finalizer['timeout-minutes'] == '1'
    assert upload['if'] == 'always()' and '--step finalize' in finalizer['run']
    helper_sha = hashlib.sha256((R2 / 'tool_profile.py').read_bytes()).hexdigest()
    assert helper_sha in profile['run'] and helper_sha in finalizer['run']
    store = LocalObjects()
    kind, commit = store.get(PARENT)
    assert kind == 'commit' and commit.splitlines()[0] == b'tree ' + BASE_TREE.encode()
    leaves = {}
    def visit(tree, prefix=b''):
        kind, raw = store.get(tree); assert kind == 'tree'
        for mode, name, child in tree_entries(raw):
            path = prefix + name
            if mode == b'40000':
                visit(child, path + b'/')
            else:
                assert mode in (b'100644', b'100755', b'120000', b'160000') and path not in leaves
                leaves[path] = mode, child
    visit(BASE_TREE)
    assert len(leaves) == 1785 and rebuild(leaves) == BASE_TREE
    expected = json.loads((R2 / 'EXPECTED_TREE.json').read_bytes())
    assert expected['sole_parent'] == PARENT and expected['base_tree'] == BASE_TREE and expected['expected_host_tree'] == NEW_TREE
    assert expected['branch'] == 'pro/dg18-a4-tool-profile-20261121-01'
    assert workflow['on']['push']['branches'] == [expected['branch']]
    additions = []
    for path, row in expected['new_files'].items():
        _, actual = receive(R2 / row['local_file'])
        assert all(actual[k] == row[k] for k in ('bytes', 'sha256', 'git_blob', 'mode'))
        assert path.encode() not in leaves
        leaves[path.encode()] = row['mode'].encode(), row['git_blob']
        additions.append({'path': path, **actual})
    assert len(additions) == 2 and len(leaves) == 1787 and rebuild(leaves) == NEW_TREE
    inherited = []
    for path, (_, key) in leaves.items():
        if path.startswith(b'.github/workflows/') and path.decode() not in expected['new_files']:
            kind, raw = store.get(key); assert kind == 'blob'
            document = yaml.load(raw, Loader=yaml.BaseLoader)
            inherited.append({'path': path.decode(), 'git_blob': key, **digest(raw), 'on': document['on']})
    result = {'schema': 'dg18.a4.tool-profile-r2-independent-receiving.v1', 'authority': 'NONE',
              'mechanical_receiving': 'PASS', 'r2': r2, 'r1_preserved': r1, 'first_review_preserved': prior,
              'cpython_evidence_byte_identical': True, 'exact_source_workflow_delta': digest(delta.encode()),
              'delta_sections': delta.count('--- R1/'), 'delta_hunks': sum(line.startswith('@@ ') for line in delta.splitlines()),
              'python_syntax': sorted(parsed), 'candidate_modules_imported': 0, 'candidate_code_executed': 0,
              'unchanged_functions_and_classes': unchanged, 'unchanged_constants': list(stable_constants),
              'helper_imports': imports, 'workflow': workflow, 'parent': PARENT, 'base_tree': BASE_TREE,
              'expected_tree_independently_rederived': rebuild(leaves), 'base_leaf_count': 1785, 'new_leaf_count': len(leaves),
              'only_additions': additions, 'inherited_workflows': inherited,
              'object_reading': {'scope': 'existing parent record, recursively reachable trees, inherited workflow blobs only',
                                 'commit_history_walked': False, 'Git_processes': 0, 'network_operations': 0,
                                 'verified_pack_indexes': store.index_count, 'resolved_objects': store.resolved},
              'native_Windows_operations': 0, 'qualification_controls_run': 0, 'original_runs': 0,
              'provider_writes': 0, 'Root_controller_calls': 0, 'original_awards': []}
    with (HERE / 'MECHANICAL_RECEIVING.json').open('xb') as stream:
        stream.write((json.dumps(result, sort_keys=True, indent=2) + '\n').encode())
    print(json.dumps({'mechanical_receiving': 'PASS', 'r2_payloads': 12, 'r2_bytes': 94459,
                      'r1_payloads_preserved': 8, 'prior_review_payloads_preserved': 7,
                      'derived_tree': NEW_TREE, 'object_count': len(store.resolved),
                      'delta_sections': result['delta_sections'], 'delta_hunks': result['delta_hunks'],
                      'receipt': digest((HERE / 'MECHANICAL_RECEIVING.json').read_bytes())}, indent=2))

if __name__ == '__main__':
    main()
