#!/usr/bin/env python3
"""Independent retained-data receiver. No product imports, subprocesses, or Git.

Reads only the named frozen packet, admission, and completed operation. Writes
only its own mechanical receipt. It does not execute either variant or oracle.
"""
from pathlib import Path, PurePosixPath
from datetime import datetime
import difflib
import hashlib
import json
import re
import stat
import struct

BASE = Path('/workspace/scratch/097486cde2dd')
PACKET = BASE / 'dg17-full-family-r3'
EX = PACKET / 'execution-01'
OUT = BASE / 'dg17-m09-r3-original-independent-receiving'
SEAL_SHA = '25d14085c698ed9809dfbc062f9b24d390077327b536a4ff1560473e87a59e90'
MANIFEST_SHA = 'c026cc8d372843119ff4dd26e4b591d9da4cfaac5200afb4c7c2226eab64d93f'
ADMISSION_SHA = '647d9068d93124619072dc61270e7a84cda22cabbf82c0fe950bdd525564ad2a'
COMMIT = '51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
TREE = '9c3913ceaa95f3f36b0377fe2dba4a302afcba89'
REPO = '/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b'
CASE_IDS = ['owned-residue-delete', 'foreign-source-delete',
            'heldout-name-looks-disposable', 'heldout-opaque-replace',
            'foreign-move-destination', 'explicitly-excluded-destination',
            'owned-residue-relocate', 'truncated-preimage-control']
TARGET_IDS = CASE_IDS[1:6]
CHECKS = 0


def check(truth, label):
    global CHECKS
    CHECKS += 1
    if not truth:
        raise AssertionError(label)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def blob_oid(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def pairs(items):
    result = {}
    for k, v in items:
        check(k not in result, 'duplicate JSON key: ' + k)
        result[k] = v
    return result


def read_json(path):
    return json.loads(path.read_bytes(), object_pairs_hook=pairs)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def record(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': digest(data)}


def safe_name(name):
    p = PurePosixPath(name)
    check(not p.is_absolute() and str(p) == name and all(x not in ('', '.', '..') for x in p.parts), 'unsafe member ' + name)


def files(root, excluded=()):
    found = {}
    for p in sorted(root.rglob('*')):
        rel = p.relative_to(root).as_posix()
        st = p.lstat()
        check(not stat.S_ISLNK(st.st_mode), 'symlink: ' + str(p))
        check(stat.S_ISDIR(st.st_mode) or stat.S_ISREG(st.st_mode), 'unsupported object: ' + str(p))
        if stat.S_ISREG(st.st_mode) and rel not in excluded:
            found[rel] = p.read_bytes()
    return found


def verify_manifest(root, manifest, count, total, exact=False):
    names = []
    for item in manifest['files']:
        name = item['path']; safe_name(name); names.append(name)
        p = root / name
        check(p.is_file() and not p.is_symlink(), 'missing regular manifest member ' + str(p))
        check(record(p) == {k: item[k] for k in ('bytes', 'sha256')}, 'changed manifest member ' + str(p))
        if 'git_blob' in item:
            check(blob_oid(p.read_bytes()) == item['git_blob'], 'Git blob identity mismatch ' + name)
    check(len(names) == len(set(names)) == count == manifest['count'], 'manifest member census')
    check(sum(x['bytes'] for x in manifest['files']) == total, 'manifest byte census')
    if exact:
        check(set(files(root, ('EXECUTION_MANIFEST.json',))) == set(names), 'execution extra/missing members')
    return {'members': count, 'payload_bytes': total, 'all_exact': True}


def workplane(root):
    return {k: v for k, v in files(root).items() if k.split('/')[0] not in {'.git', '.IMPLEMENTAUDIT'}}


def observed(data):
    return {k: {'kind': 'regular', 'bytes': len(v), 'sha256': digest(v)} for k, v in data.items()}


def identity_projection(identity):
    if identity['kind'] == 'absent':
        check(identity == {'kind': 'absent'}, 'nonminimal absent identity')
        return None
    check(identity['kind'] == 'regular', 'unexpected target identity kind')
    return {'kind': 'regular', 'bytes': identity['byte_length'], 'sha256': identity['sha256']}


def parse_index(path):
    data = path.read_bytes()
    magic, version, count = struct.unpack('!4sII', data[:12])
    check(magic == b'DIRC' and version == 3, 'fixture index v3 header')
    check(hashlib.sha1(data[:-20]).digest() == data[-20:], 'fixture index checksum')
    offset = 12; entries = {}
    for _ in range(count):
        start = offset
        flags = struct.unpack_from('!H', data, offset + 60)[0]
        mode = struct.unpack_from('!I', data, offset + 24)[0]
        oid = data[offset + 40:offset + 60].hex()
        offset += 62
        if flags & 0x4000:
            offset += 2
        end = data.index(b'\0', offset)
        name = data[offset:end].decode()
        check(name not in entries and not (flags & 0x3000), 'index unique stage-zero entry')
        entries[name] = {'oid': oid, 'mode': mode}
        offset = start + ((end + 1 - start + 7) // 8) * 8
    check(offset <= len(data) - 20, 'index parse boundary')
    return entries


seal_path = PACKET / 'SEAL.json'
check(record(seal_path) == {'bytes': 20772, 'sha256': SEAL_SHA}, 'exact packet seal')
seal = read_json(seal_path)
packet_receiving = verify_manifest(PACKET, seal, 86, 1954077)
manifest_path = EX / 'EXECUTION_MANIFEST.json'
check(record(manifest_path) == {'bytes': 207325, 'sha256': MANIFEST_SHA}, 'exact execution manifest')
manifest = read_json(manifest_path)
check(manifest['packet_seal_sha256'] == SEAL_SHA, 'execution bound packet')
execution_receiving = verify_manifest(EX, manifest, 944, 11449918, exact=True)
check(not (EX / 'STOP.json').exists() and not (EX / 'BASELINE_FAILED_NO_MUTANT.json').exists(), 'no stop/baseline failure record')

admission_path = BASE / 'dg17-m09-root-r3/ROOT_EXECUTION_ADMISSION.json'
check(record(admission_path) == {'bytes': 63602, 'sha256': ADMISSION_SHA}, 'exact Root admission')
admission = read_json(admission_path)['gate']
start = read_json(EX / 'EXECUTION_START.json')
check(start['seal_sha256'] == SEAL_SHA and start['original_family'] == 'M09', 'execution start binding')
check(start['root_approval_reference'] == str(admission_path) + '@' + ADMISSION_SHA, 'execution start Root reference')
terminal = read_json(BASE / 'dg17-m09-root-r3/NATIVE_EXECUTION_TERMINAL.json')
initial = read_json(BASE / 'dg17-m09-root-r3/NATIVE_EXECUTION_INITIAL.json')
check(initial['chunk_id'] == '27b072' and initial['session_id'] == 58262, 'initial actual native receipt')
check(terminal['chunk_id'] == '10cced' and terminal['exit_code'] == 0, 'terminal actual native receipt')
terminal_summary = json.loads(terminal['output'])
check(terminal_summary == {'status': 'OBSERVED_FULL_FAMILY_DISCRIMINATOR_PENDING_INDEPENDENT_RECEIVING', 'output': str(EX), 'award': False}, 'native terminal summary')

full_source = files(PACKET / 'source')
source = files(PACKET / 'source/skills/implementaudit')
original_package = files(EX / 'packages/original')
mutant_package = files(EX / 'packages/mutant')
check(len(full_source) == 23 and sum(map(len, full_source.values())) == 983360, 'full source population')
check(len(source) == 18 and sum(map(len, source.values())) == 688266, 'complete executable package population')
check(source == original_package, 'actual original package exact all source bytes')
check(source.keys() == mutant_package.keys(), 'mutant full package population')
check([p for p in source if source[p] != mutant_package[p]] == ['scripts/validate-phase.sh'], 'sole mutant source path')
mut = read_json(PACKET / 'MUTATION.json')
check(record(PACKET / 'source/skills/implementaudit/scripts/validate-phase.sh') == {'bytes': mut['original_bytes'], 'sha256': mut['original_sha256']}, 'original validator pin')
check(record(PACKET / 'mutant/validate-phase.sh') == {'bytes': mut['mutant_bytes'], 'sha256': mut['mutant_sha256']}, 'mutant validator pin')
check(mutant_package['scripts/validate-phase.sh'] == (PACKET / 'mutant/validate-phase.sh').read_bytes(), 'actual sole mutant bytes')
old_lines = source['scripts/validate-phase.sh'].splitlines(keepends=True)
new_lines = mutant_package['scripts/validate-phase.sh'].splitlines(keepends=True)
ops = [x for x in difflib.SequenceMatcher(a=old_lines, b=new_lines, autojunk=False).get_opcodes() if x[0] != 'equal']
check(len(ops) == 1 and ops[0] == ('replace', 101, 102, 101, 102), 'exact one-line mutation at 102')
check(old_lines[101].decode().rstrip('\n') == mut['exact_removed_line'] and new_lines[101].lstrip().startswith(b'#'), 'only scope refusal removed')
check(record(PACKET / 'oracle.py')['sha256'] == '42e3f6e7b54562ee882b839f0e3d656e30ec69c02ffc266e5882e4ad94552ebc', 'fixed external oracle')
check(record(PACKET / 'inputs/cases.json')['sha256'] == '2a9f91f088bf355278571da5b6205d012a160366f518f402015373c08fe931ae', 'fixed case inputs')
check(record(PACKET / 'run_m09.py')['sha256'] == '3b83f026cd87d81e81f7b2012ab861cb9cf1dd01c1b6bd98af84ff3d0950bef8', 'fixed actual runner')

case_doc = read_json(PACKET / 'inputs/cases.json'); cases = case_doc['witnesses']
check([c['id'] for c in cases] == CASE_IDS and case_doc['count'] == 8, 'fixed eight-case ordering')
check([c['id'] for c in cases if c['mutation_target']] == TARGET_IDS, 'exact five discriminator identities')
process_dirs = sorted((EX / 'processes').iterdir())
check(len(process_dirs) == 112 and all(p.is_dir() for p in process_dirs), '112 direct process captures')
processes = []; previous_finish = None
for i, place in enumerate(process_dirs, 1):
    check(place.name.startswith(f'{i:04d}-'), 'contiguous process sequence')
    check(set(files(place)) == {'process.json', 'stdout.bin', 'stderr.bin'}, 'complete process capture')
    p = read_json(place / 'process.json'); processes.append(p)
    check(p['capture_directory'] == place.relative_to(EX).as_posix(), 'process capture binding')
    check(type(p['pid']) is int and p['pid'] > 0 and 'status' not in p, 'normal completed direct process')
    for stream in ('stdout', 'stderr'):
        check(record(place / (stream + '.bin')) == {'bytes': p[stream + '_bytes'], 'sha256': p[stream + '_sha256']}, 'raw process stream binding')
    t0 = datetime.fromisoformat(p['started']); t1 = datetime.fromisoformat(p['finished'])
    check(t0 <= t1 and (previous_finish is None or previous_finish <= t0), 'sequential start/finish timestamps')
    check((t1 - t0).total_seconds() < 45, 'normal command below timeout')
    previous_finish = t1


def proc(n, argv, cwd, suffix, exitcode):
    p = processes[n - 1]
    check(p['argv'] == argv and p['cwd'] == str(cwd), 'exact argv/cwd sequence ' + str(n))
    check(p['capture_directory'] == f'processes/{n:04d}-{suffix}', 'exact process label ' + str(n))
    check(p['returncode'] == exitcode, 'actual returncode sequence ' + str(n))
    return p


def stream(p, name='stdout'):
    return (EX / p['capture_directory'] / (name + '.bin')).read_bytes()


fixtures = {}; fixture_receipts = []; witness_receipts = []; claim_ids = []
for ci, c in enumerate(cases):
    cid = c['id']; subject = EX / 'subjects' / cid; snap = EX / 'snapshots' / cid
    f = read_json(EX / 'fixture-inputs' / (cid + '.json'))
    rel = f['run_relative']; safe_name(rel)
    check(re.fullmatch(r'\.IMPLEMENTAUDIT/runs/m09-consumer-' + re.escape(cid) + r'-[A-Za-z0-9]{6}', rel) is not None, 'ordinary unique claimed path')
    check(f['subject_root'] == str(subject) and f['controller_population'] == [] and f['native_currentness_claim'] is False, 'ordinary fixture declaration')
    baseline = workplane(snap)
    fixed_bytes = {p: bytes.fromhex(v['current_hex']) for p, v in c['files'].items()}
    check(set(baseline) == set(fixed_bytes) | {'README.md'}, 'full snapshot workplane')
    check(all(baseline[p] == data for p, data in fixed_bytes.items()), 'exact constructed initial bytes')
    check(record(snap / 'README.md') == {'bytes': 74934, 'sha256': '2267eeb5948de8842d5aecb8d6207de509e3ccd41dee9d14c8be650781555de4'}, 'exact baseline README bystander')
    check(f['before_workplane'] == observed(baseline), 'fixture observation matches snapshot bytes')
    snapshot_run = snap / rel; live_run = subject / rel
    check(set(files(snapshot_run)) == set(f['claim_and_phase_inputs']), 'snapshot complete claim/input population')
    for name, expected in f['claim_and_phase_inputs'].items():
        check(record(snapshot_run / name) == expected and record(live_run / name) == expected, 'paired frozen phase/claim input ' + cid + ':' + name)
    check(not (snapshot_run / '.controller').exists() and not (live_run / '.controller').exists(), 'no controller fixture')
    claim_rows = (snapshot_run / '.claimed').read_text().splitlines()
    claim = dict(x.split('=', 1) for x in claim_rows)
    check(len(claim) == len(claim_rows), 'unique claim fields')
    check(claim['schema'] == 'implementaudit.run-claim.v2' and claim['mode'] == 'full', 'real v2 ordinary claim')
    check(re.fullmatch('[0-9a-f]{32}', claim['claim_id']) is not None, 'actual claim ID shape')
    check(claim['repo_root'] == str(subject) and claim['git_common_dir'] == str(subject / '.git') and claim['run_root'] == rel, 'actual claim subject/run custody')
    claim_ids.append(claim['claim_id'])
    phase = (snapshot_run / 'phases/phase-1.md').read_text()
    frozen_phase = (PACKET / 'inputs/phases' / (cid + '.md')).read_text()
    check(frozen_phase.count('RUN_ROOT_FROM_REAL_CLAIM') == 4 and phase == frozen_phase.replace('RUN_ROOT_FROM_REAL_CLAIM', rel), 'exact frozen phase claim-only substitution')
    phase_scope = json.loads(re.search(r'^Mutation scope: (.*)$', phase, re.M).group(1), object_pairs_hook=pairs)
    phase_op = json.loads(re.search(r'^  mutation-authority: (.*)$', phase, re.M).group(1), object_pairs_hook=pairs)
    check(phase_scope == c['scope'] and phase_op == c['operation'], 'phase operation/scope exact case contract')
    check((snapshot_run / 'evidence/inputs/preimage.bin').read_bytes() == bytes.fromhex(c['preimage_hex']), 'exact preimage bytes')
    if c['candidate_hex'] is not None:
        check((snapshot_run / 'evidence/inputs/candidate.bin').read_bytes() == bytes.fromhex(c['candidate_hex']), 'exact candidate bytes')
    staged = [p for p, v in c['files'].items() if 'index_hex' in v]
    setup_argv = [
        (['/usr/bin/git', '-c', 'init.templateDir=', 'init', '--quiet', str(subject)], EX, 'git-init'),
        (['/usr/bin/git', '-C', REPO, 'rev-parse', '--path-format=absolute', '--git-common-dir'], EX, 'immutable-object-location'),
        (['/usr/bin/git', 'config', '--local', 'core.sparseCheckout', 'true'], subject, 'sparse-config'),
        (['/usr/bin/git', 'config', '--local', 'core.sparseCheckoutCone', 'false'], subject, 'sparse-cone-config'),
        (['/usr/bin/git', 'checkout', '--quiet', '--detach', COMMIT], subject, 'existing-baseline-checkout'),
        (['/usr/bin/git', 'rev-parse', 'HEAD', 'HEAD^{tree}'], subject, 'baseline-identity'),
        (['/usr/bin/git', 'for-each-ref', '--format=%(refname)', 'refs/implementaudit/'], subject, 'no-controller-population'),
        (['/usr/bin/git', 'add', '--', *staged], subject, 'constructed-user-index'),
        (['/usr/bin/bash', str(PACKET / 'source/skills/implementaudit/scripts/claim-run.sh'), 'm09-consumer-' + cid], subject, 'ordinary-claim'),
        (['/usr/bin/git', 'status', '--porcelain=v1', '--untracked-files=all', '--', 'dg17-work'], subject, 'actual-dirty-premise')]
    pp = [proc(ci * 10 + j + 1, argv, cwd, cid + '-' + label, 0) for j, (argv, cwd, label) in enumerate(setup_argv)]
    check(all(stream(p, 'stderr') == b'' for p in pp), 'setup stderr empty')
    check(stream(pp[5]).decode().splitlines() == [COMMIT, TREE], 'actual baseline identity stdout')
    check(stream(pp[6]) == b'', 'actual no-controller ref census stdout')
    check(stream(pp[8]).decode() == rel + '\n' and pp[8] == f['created_by_actual_claim_process'], 'actual claim capture binding')
    check(stream(pp[9]).decode() == f['dirty_status'], 'actual dirty status capture')
    check(all('AM ' + name in f['dirty_status'].splitlines() for name in c['dirty_protected_files']), 'staged then modified user bytes')
    check((snap / '.git/info/sparse-checkout').read_bytes() == b'/README.md\n/dg17-work/\n', 'actual exact sparse setup')
    check((snap / '.git/objects/info/alternates').read_text() == stream(pp[1]).decode().strip() + '/objects\n', 'actual object-location to alternates binding')
    check((snap / '.git/HEAD').read_text() == COMMIT + '\n', 'actual detached fixture HEAD')
    index = parse_index(snap / '.git/index')
    check(all(index[p]['oid'] == blob_oid(bytes.fromhex(c['files'][p]['index_hex'])) and index[p]['mode'] == 0o100644 for p in staged), 'actual index staged byte identities')
    check(files(snap / '.git') == files(subject / '.git'), 'snapshot/final Git metadata unchanged by variants')
    binding = {'schema': 'implementaudit.phase-mutation-authority-binding.v1', 'claim_id': claim['claim_id'], 'run_root': rel, 'phase': 1, 'step': 1,
               'owner_source': re.search(r'^Owner/source: (.*)$', phase, re.M).group(1), 'baseline_ref': COMMIT,
               **c['operation'], 'mutation_scope': c['scope']}
    bound_sha = digest(canonical(binding))
    fixtures[cid] = (f, baseline, claim, bound_sha)
    fixture_receipts.append({'case': cid, 'claim_id': claim['claim_id'], 'run_relative': rel, 'claim_and_inputs': len(f['claim_and_phase_inputs']),
                             'snapshot_index_entries': len(index), 'staged_protected_paths': staged, 'paired_input_integrity': True,
                             'ordinary_setup_sequences': [ci * 10 + 1, ci * 10 + 10], 'authority_binding_sha256': bound_sha})
check(len(set(claim_ids)) == 8, 'eight distinct actual claims')

for vi, variant in enumerate(('original', 'mutant')):
    for ci, c in enumerate(cases):
        cid = c['id']; f, baseline, claim, binding_sha = fixtures[cid]
        rel = f['run_relative']; subject = EX / 'subjects' / cid
        where = EX / 'observations' / variant / cid
        o = read_json(where / 'observation.json'); d = o['decoded_helper_result']
        check(o['schema'] == 'dg17.m09.actual-consumer-observation.v1' and o['case_id'] == cid and o['subject_root'] == str(subject) and o['run_relative'] == rel and o['native_or_model_claim'] is False, 'observation identity')
        check(o['before_workplane'] == observed(baseline), 'paired before workplane equality')
        op = c['operation']; src = op['source']; dst = op['destination']
        # Reconstruct each expected complete post-state from the frozen bytes.
        expected = dict(baseline)
        changed = (variant == 'mutant' and c['mutation_target']) or c['expected_process_kind'] == 'committed'
        if changed:
            check(bytes.fromhex(c['preimage_hex']) == baseline[src], 'complete preimage on every committed request')
            if op['operation'] == 'delete':
                del expected[src]
            elif op['operation'] == 'replace':
                expected[src] = bytes.fromhex(c['candidate_hex'])
            elif op['operation'] == 'move':
                check(dst not in expected, 'destination absence in snapshot')
                expected[dst] = expected.pop(src)
            else:
                raise AssertionError('unexpected operation')
        if variant == 'original':
            independently_declared = dict(baseline)
            for name, data in c['expected_workplane_edits'].items():
                if data is None:
                    independently_declared.pop(name, None)
                else:
                    independently_declared[name] = bytes.fromhex(data)
            check(expected == independently_declared, 'original unchanged frozen invariant')
        received = files(where / 'received-workplane')
        check(received == expected, 'complete exact received post-state ' + variant + '/' + cid)
        check(o['after_workplane'] == observed(received), 'capture agrees with retained actual workplane')
        if variant == 'mutant':
            check(workplane(subject) == received, 'last actual subject agrees with received mutant bytes')
        changes = sorted(p for p in set(baseline) | set(received) if baseline.get(p) != received.get(p))
        bystanders = sorted(p for p in set(baseline) | set(received) if p not in {src, dst})
        check(all(baseline.get(p) == received.get(p) for p in bystanders), 'all bystander bytes preserved')
        scope = c['scope']
        outside = src not in scope['in'] or src in scope['out'] or (dst is not None and (dst not in scope['in'] or dst in scope['out']))
        check(outside == c['mutation_target'], 'independent literal scope classifier')
        command = ['/usr/bin/bash', str(EX / 'packages' / variant / 'scripts/apply-observed-mutation.sh'), '--repo-root', str(subject), '--run-root', rel,
                   '--phase', '1', '--step', '1', '--preimage', str(subject / rel / 'evidence/inputs/preimage.bin')]
        if c['candidate_hex'] is not None:
            command += ['--candidate', str(subject / rel / 'evidence/inputs/candidate.bin')]
        seq = 81 + vi * 16 + ci * 2
        helper = proc(seq, command, subject, variant + '-' + cid + '-actual-helper', 0 if changed else 64)
        check(o['helper'] == helper and o['helper_stdout'].encode() == stream(helper) and o['helper_stderr'].encode() == stream(helper, 'stderr'), 'exact helper raw capture/observation consistency')
        if variant == 'original' and outside:
            check(d is None and stream(helper) == b'', 'scope refusal emits no result or stdout')
            expected_stderr = ('apply-observed-mutation: validator failed (1): ' + str(EX / 'packages/original/scripts/validate-phase.sh') + '\nvalidate-phase: mutation authority authority paths are outside Mutation scope\n').encode()
            check(stream(helper, 'stderr') == expected_stderr, 'exact authentic scope refusal reason')
            check(not (where / 'mutation-transactions').exists(), 'scope refusal creates no transaction')
            effect_count = 0; durable_prefix = 0
        else:
            check(json.loads(stream(helper), object_pairs_hook=pairs) == d and stream(helper, 'stderr') == b'', 'raw JSON helper result and clean stderr')
            check(d['schema'] == 'implementaudit.observation_bound_mutation.v2' and d['coordination_scope'] == 'GOVERNED_HELPER_ROUTED_WRITERS_ONLY', 'ordinary result schema/scope')
            check(d['claim_id'] == claim['claim_id'] and d['phase'] == 1 and d['step'] == 1 and d['authority_binding_sha256'] == binding_sha, 'exact authority identity and independent binding digest')
            check(d['operation'] == op['operation'] and d['source_path'] == src and d['destination_path'] == dst and d['residue'] == [], 'exact operation/result residue')
            check(d['pre_identities'][0]['path'] == src and identity_projection(d['pre_identities'][0]['identity']) == observed(baseline)[src] and len(d['pre_identities']) == 1, 'exact source pre-identity')
            post = {x['path']: identity_projection(x['identity']) for x in d['post_identities']}
            check(len(post) == len(d['post_identities']) and set(post) == ({src, dst} if dst else {src}), 'exact post-identity population')
            check(all(post[p] == observed(received).get(p) for p in post), 'post-identity byte/absence agreement')
            for x in d['pre_identities'] + d['post_identities']:
                ident = x['identity']
                if ident['kind'] == 'regular':
                    check(all(type(ident[k]) is int for k in ('device', 'inode', 'link_count')) and ident['inode'] > 0 and ident['link_count'] > 0, 'historically captured physical identity shape only')
            check(digest(canonical(d['planned_effect_set'])) == d['planned_effect_set_sha256'], 'independent planned-effect digest')
            effect_count = len(d['actual_effect_set']); durable_prefix = 0
            if changed:
                check(d['status'] == 'COMMITTED' and d['reason_code'] == 'NONE' and d['transaction_id'] == claim['claim_id'] + '-p1-s1', 'successful actual helper result')
                if op['operation'] in ('move', 'replace'):
                    candidate = baseline[src] if op['operation'] == 'move' else bytes.fromhex(c['candidate_hex'])
                    check(len(d['candidate_identities']) == 1 and d['candidate_identities'][0]['path'] == src and identity_projection(d['candidate_identities'][0]['identity']) == {'kind': 'regular', 'bytes': len(candidate), 'sha256': digest(candidate)}, 'exact projected candidate identity')
                else:
                    check(d['candidate_identities'] == [], 'delete has no candidate')
                plans = {x['path']: x for x in d['planned_effect_set']}
                check(len(plans) == len(d['planned_effect_set']), 'unique planned effect paths')
                target_effects = []
                for ei, effect in enumerate(d['actual_effect_set'], 1):
                    check(effect['sequence'] == ei and effect['scope'] == 'repo' and effect['outcome'] == 'applied', 'ordered actually-applied effects')
                    check(effect['path'] in plans and effect['effect'] in plans[effect['path']]['allowed_effects'], 'actual effect admitted by exact plan')
                    p = effect['path']; safe_name(p)
                    check(p.startswith('.IMPLEMENTAUDIT/') or p == '.IMPLEMENTAUDIT' or p in {src, dst} or (p in {str(PurePosixPath(src).parent), str(PurePosixPath(dst).parent) if dst else None} and effect['effect'] == 'fsync'), 'effect outside authorized fixture bookkeeping or exact target')
                    if p in {src, dst}:
                        target_effects.append(effect)
                for p in ({src, dst} if dst else {src}):
                    effects = [x for x in target_effects if x['path'] == p]
                    check(effects and identity_projection(effects[-1]['after']) == observed(received).get(p), 'actual final target effect byte/absence identity')
                tx = where / 'mutation-transactions' / d['transaction_id']
                check([x.name for x in (where / 'mutation-transactions').iterdir()] == [d['transaction_id']], 'single transaction per successful invocation')
                authority = read_json(tx / 'authority.json'); durable = read_json(tx / 'result.json')
                check(authority['schema'] == 'implementaudit.observation-bound-mutation.authority.v2' and authority['transaction_id'] == d['transaction_id'], 'durable authority identity')
                check(authority['claim'] == {'claim_id': claim['claim_id'], 'claim_sha256': f['claim_and_phase_inputs']['.claimed']['sha256'], 'git_common_dir': str(subject / '.git'), 'repo_root': str(subject), 'run_root': rel}, 'durable claim custody exact')
                check(authority['phase'] == {'phase': 1, 'step': 1, 'authority_binding_sha256': binding_sha}, 'durable phase binding')
                check(authority['operation'] == op['operation'] and authority['source'] == src and authority['destination'] == dst, 'durable requested operation')
                check(authority['observations']['preimage'] == {'byte_length': len(bytes.fromhex(c['preimage_hex'])), 'sha256': digest(bytes.fromhex(c['preimage_hex']))}, 'durable exact preimage observation')
                check(authority['planned_effect_set'] == d['planned_effect_set'] and authority['planned_effect_set_sha256'] == d['planned_effect_set_sha256'], 'durable plan consistency')
                check(set(durable) == set(d), 'durable complete result schema')
                check(all(durable[k] == d[k] for k in d if k != 'actual_effect_set'), 'durable result agrees on every non-prefix field')
                durable_prefix = len(durable['actual_effect_set'])
                check(durable['actual_effect_set'] == d['actual_effect_set'][:durable_prefix] and effect_count - durable_prefix == 6, 'durable result exact pre-publication effect prefix')
                check([x['effect'] for x in d['actual_effect_set'][durable_prefix:]] == ['create', 'write', 'fsync', 'replace', 'replace', 'fsync'], 'only six result-publication effects follow durable prefix')
                txfiles = files(tx)
                check(all(p in {'authority.json', 'result.json'} or re.fullmatch(r'released-locks/[a-f0-9]{64}\.lock/owner', p) for p in txfiles), 'successful transaction retains only result authority released locks')
                check(not any((tx / name).exists() for name in ('journal.json', 'journal.tmp', 'result.tmp', 'backup.bin', 'stage.bin')), 'no retained journal/stage/backup/residue after successful finalize')
                owners = [data for name, data in txfiles.items() if name.endswith('/owner')]
                check(len(owners) == (3 if dst else 2) and len(set(owners)) == 1 and re.fullmatch(b'[0-9a-f]{32}', owners[0]) is not None, 'complete released lock owner custody')
                if variant == 'mutant':
                    check(files(subject / rel / 'mutation-transactions') == files(where / 'mutation-transactions'), 'current last transaction equals received transaction')
            else:
                check(cid == 'truncated-preimage-control' and bytes.fromhex(c['preimage_hex']) == baseline[src][:7] and len(baseline[src]) == 45, 'independent truncated preimage premise')
                check(d['status'] == 'REJECTED_NO_MUTATION' and d['reason_code'] == 'PREIMAGE_DRIFT' and d['transaction_id'] is None and d['actual_effect_set'] == [] and d['planned_effect_set'] == [] and d['candidate_identities'] == [], 'unchanged preimage refusal intact')
                check(not (where / 'mutation-transactions').exists(), 'preimage refusal creates no transaction')
        oracle_exit = 1 if variant == 'mutant' and c['mutation_target'] else 0
        oracle_argv = ['/usr/bin/python3.13', '-I', '-B', str(PACKET / 'oracle.py'), '--cases', str(PACKET / 'inputs/cases.json'), '--case-id', cid, '--observation', rel + '/evidence/observation.json']
        oracle_process = proc(seq + 1, oracle_argv, subject, variant + '-' + cid + '-separate-process-oracle', oracle_exit)
        check(read_json(where / 'oracle-process.json') == oracle_process and stream(oracle_process, 'stderr') == b'', 'external oracle process raw capture')
        oracle = read_json(where / 'oracle.json')
        check(json.loads(stream(oracle_process), object_pairs_hook=pairs) == oracle, 'external oracle output capture')
        # Corroboration only: independently reconstructed full post-state above is decisive.
        killed = variant == 'mutant' and outside and changed
        check(oracle['verdict'] == ('FAIL' if killed else 'PASS') and oracle['actual_out_of_scope_committed_effect'] == killed and oracle['live_post_state_matches_capture'] is True and oracle['oracle_has_variant_input'] is False, 'oracle corroborates independent byte/status conclusion')
        if variant == 'mutant':
            check((subject / rel / 'evidence/observation.json').read_bytes() == (where / 'observation.json').read_bytes(), 'current canonical observation equals mutant archive')
            check((subject / rel / 'evidence/oracle.json').read_bytes() == stream(oracle_process), 'current canonical oracle raw output')
            lockroot = subject / '.IMPLEMENTAUDIT/.r36-locks'
            check(not lockroot.exists() or set(files(lockroot)) <= {'namespace.gate'}, 'last subject no retained active path-lock owner')
        witness_receipts.append({'variant': variant, 'case': cid, 'helper_sequence': seq, 'oracle_sequence': seq + 1,
                                 'helper_exit': helper['returncode'], 'actual_status': d['status'] if d else 'SCOPE_REFUSAL',
                                 'full_workplane_matches_independent_expected_bytes': True, 'all_bystanders_unchanged': True,
                                 'workplane_changed_paths': changes, 'absent_after': sorted(set(baseline) - set(received)),
                                 'new_after': sorted(set(received) - set(baseline)), 'post_workplane': observed(received),
                                 'actual_effects': effect_count, 'durable_result_effect_prefix': durable_prefix,
                                 'out_of_scope_effect_observed': killed, 'authority_binding_sha256': binding_sha if d else None,
                                 'historical_inode_fields_not_new_live_proof': True})

check(datetime.fromisoformat(processes[94]['finished']) < datetime.fromisoformat(processes[96]['started']), 'all eight originals precede first mutant')
summary = read_json(EX / 'RESULT.json')
check(summary['sealed_packet_sha256'] == SEAL_SHA and summary['expected_effect_witnesses'] == TARGET_IDS and summary['actual_effect_witnesses'] == TARGET_IDS and summary['specificity_controls_pass'] is True, 'driver exact five-effect/three-control corroboration')
check(summary['original_family_awarded'] is False and summary['whole_DG17'] is False and summary['original_denominators'] == {'cases': 36, 'mutation_families': 14, 'terminal_clauses': 17}, 'no unauthorized award/denominator change')
for variant in ('original', 'mutant'):
    for cid in CASE_IDS:
        check(summary['results'][variant][cid] == read_json(EX / 'observations' / variant / cid / 'oracle.json'), 'driver result equals retained oracle')

# Closing rehash: no operation or source changes were made by receiving.
verify_manifest(PACKET, seal, 86, 1954077)
verify_manifest(EX, manifest, 944, 11449918, exact=True)
receipt = {
    'schema': 'dg17.m09.r3.independent-actual-receiving.v1',
    'disposition': 'PASS_RECEIVED_FULL_M09_AUTHORITY_DISCRIMINATOR_ADVISORY',
    'reviewer': '/root/independent_review', 'authority': 'NONE', 'original_family_awarded_by_receiver': False,
    'root_currentness_binding': {'receipt': '33c5296d4d9bf5ae370780b3d9895a8ce1b825cd', 'native': 'be2c2b/0', 'epoch': 'G0043'},
    'packet_seal': record(seal_path), 'packet_receiving': packet_receiving,
    'execution_manifest': record(manifest_path), 'execution_receiving': execution_receiving,
    'root_admission': record(admission_path), 'native_initial': '27b072/session58262', 'native_terminal': '10cced/0',
    'source': {'commit': COMMIT, 'tree': TREE, 'files': 23, 'bytes': 983360, 'actual_packages_received': 2,
               'runtime_package_files_each': 18, 'original_runtime_package_bytes': 688266,
               'sole_mutation': 'scripts/validate-phase.sh:102', 'oracle_sha256': record(PACKET / 'oracle.py')['sha256'],
               'cases_sha256': record(PACKET / 'inputs/cases.json')['sha256'], 'runner_sha256': record(PACKET / 'run_m09.py')['sha256']},
    'processes': {'direct_captures': 112, 'setup_commands': 80, 'direct_git': 72, 'ordinary_claims': 8,
                  'actual_helpers': 16, 'separate_process_oracles': 16, 'all_originals_before_mutants': True,
                  'normal_completed': 112, 'timeout_captures': 0, 'no_descendant_or_process_group_absence_claim': True},
    'fixtures': fixture_receipts, 'witnesses': witness_receipts,
    'independent_results': {'original_invariant_pass': 8, 'mutant_exact_out_of_scope_effects': 5,
                            'mutant_specificity_controls_pass': 3, 'committed_helper_results': 9,
                            'scope_refusals': 5, 'preimage_refusals': 2, 'case_ids': CASE_IDS, 'exact_effect_case_ids': TARGET_IDS},
    'reading_only': {'product_imports': 0, 'product_executions': 0, 'oracle_executions': 0, 'git_invocations': 0,
                     'provider_actions': 0, 'controller_mutations': 0, 'source_edits': 0},
    'completed_assertions_including_unique_key_and_file_census_checks': CHECKS,
    'limits': ['Constructed ordinary authority-consumer evidence only; no model cognition or native lifecycle claim.',
               'Historical captured inode/device/link fields are not new live identity proof.',
               'Sequential direct process captures do not establish a descendant-wide process absence census.',
               'Completed transaction journals were finalized and removed; receipts bind their recorded effects and retained durable results.',
               'Root alone adjudicates family credit; no case, terminal-clause, or whole-DG17 award is made by this receiver.']}
(OUT / 'MECHANICAL_RECEIVING.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
print(json.dumps({'disposition': receipt['disposition'], 'assertions': CHECKS, 'manifest_members': 944,
                  'original_pass': 8, 'mutant_exact_effects': 5, 'mutant_controls_pass': 3,
                  'receipt': str(OUT / 'MECHANICAL_RECEIVING.json')}))
