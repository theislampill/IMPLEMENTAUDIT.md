#!/usr/bin/env python3
"""Read-only exact delta receiving; writes only this review result."""
import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/097486cde2dd')
OUT = ROOT / 'g132-image376-independent-review'
NEW = ROOT / 'g132-image376-candidate'
OLD = ROOT / 'g132-qualification/frozen-packet'
PRIOR_REVIEW = ROOT / 'independent-review/g132'
NATIVE = ROOT / 'g132-native-44957502944'
PROVIDER = ROOT / 'g132-publication'
REPO = Path('/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b')
BASE = 'f75533f95f0d099c87e7a04beb11b0a25628acdc'
TREE = '90a6e9b7fbc066dfda8ce7e6ddb0ac921289be5e'
OLD_BRANCH = 'pro/dg16-g132-engine-source-observe-20261121-01'
NEW_BRANCH = 'pro/dg16-g132-engine-source-observe-20261121-02'
checks = []
processes = []


def sha(data): return hashlib.sha256(data).hexdigest()
def blob(data): return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
def require(value, name):
    if not value: raise ValueError(name)
    checks.append(name)
def read(path): return json.loads(path.read_text())
def provider(name): return read(PROVIDER / name)['structuredContent']


def sealed(directory, filename, expected):
    raw = (directory / filename).read_bytes()
    require(sha(raw) == expected, 'exact supplied seal: ' + str(directory.name))
    seal = json.loads(raw)
    for item in seal['files']:
        path = directory / item['path']
        require(path.is_file() and not path.is_symlink(), 'regular sealed member: ' + str(path.relative_to(ROOT)))
        data = path.read_bytes()
        require(len(data) == item['bytes'] and sha(data) == item['sha256']
                and (not item.get('git_blob') or blob(data) == item['git_blob']),
                'exact member identity: ' + str(path.relative_to(ROOT)))
    return seal


def git(args, required=True):
    env = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
    env.update(GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0', GIT_ALLOW_PROTOCOL='')
    argv = ['/usr/bin/git', '-c', 'protocol.allow=never', '-C', str(REPO), *args]
    p = subprocess.run(argv, env=env, capture_output=True, timeout=30)
    processes.append({'argv': argv, 'returncode': p.returncode, 'stdout_bytes': len(p.stdout),
                      'stdout_sha256': sha(p.stdout), 'stderr_bytes': len(p.stderr), 'stderr_sha256': sha(p.stderr)})
    if required: require(p.returncode == 0, 'readonly Git: ' + args[0])
    return p


def parse_tree(data):
    result = {}
    for row in data.rstrip(b'\0').split(b'\0'):
        meta, path = row.split(b'\t', 1)
        mode, kind, oid = meta.decode().split()
        result[path.decode()] = {'mode': mode, 'kind': kind, 'oid': oid}
    return result


def derive_tree(files):
    root = {}
    for path, row in files.items():
        node = root
        parts = path.split('/')
        for part in parts[:-1]: node = node.setdefault(part, {})
        node[parts[-1]] = (row['mode'], row['oid'])
    def recurse(node):
        entries = []
        for name, value in node.items():
            directory = isinstance(value, dict)
            mode, oid = ('40000', recurse(value)) if directory else value
            entries.append((name.encode() + (b'/' if directory else b''),
                            mode.encode() + b' ' + name.encode() + b'\0' + bytes.fromhex(oid)))
        body = b''.join(row for _, row in sorted(entries))
        return hashlib.sha1(b'tree ' + str(len(body)).encode() + b'\0' + body).hexdigest()
    return recurse(root)


new_seal = sealed(NEW, 'SEAL.json', 'b828bb65aa945430e6d48891eb6856e431409c90633fe0c6857b303b3de23a8a')
old_seal = sealed(OLD, 'PACKET_MANIFEST.json', '75435d932de544b9bfdef13ba74387b64e95804757727ee6711dfe266ffdc1e8')
prior_seal = sealed(PRIOR_REVIEW, 'SEAL.json', '1349aa27dfbf34352bded4e3542a2dc0bc3405eeb7d0e9ef65bbe1f46927315f')
require(len(new_seal['files']) == 17 and sum(x['bytes'] for x in new_seal['files']) == 42994, '17-member candidate population')
actual_files = {p.relative_to(NEW).as_posix() for p in NEW.rglob('*') if p.is_file()}
require(actual_files == {x['path'] for x in new_seal['files']} | {'SEAL.json'}, 'no extra candidate payload')
relative_observer = 'candidate/engineering/g132-engine-source-diagnostic/observe.py'
old_observer = (OLD / relative_observer).read_bytes()
new_observer = (NEW / relative_observer).read_bytes()
require(old_observer.count(OLD_BRANCH.encode()) == 1 and old_observer.count(b'20261116.133.1') == 1, 'exact old literal population')
require(new_observer == old_observer.replace(OLD_BRANCH.encode(), NEW_BRANCH.encode()).replace(b'20261116.133.1', b'20261116.376.1'),
        'full observer differs only in branch and finite image')
relative_workflow = 'candidate/.github/workflows/dg16-g132-engine-source-observe.yml'
old_workflow = (OLD / relative_workflow).read_bytes()
new_workflow = (NEW / relative_workflow).read_bytes()
expected_workflow = old_workflow.replace(OLD_BRANCH.encode(), NEW_BRANCH.encode()).replace(
    b'g132-engine-source-observe-20261121-01', b'g132-engine-source-observe-20261121-02').replace(
    sha(old_observer).encode(), sha(new_observer).encode())
require(new_workflow == expected_workflow, 'full workflow exact corresponding trigger/group/hash/ref delta')
workflow = json.loads(new_workflow)
require(workflow['on'] == {'push': {'branches': [NEW_BRANCH]}}
        and workflow['permissions'] == {'contents': 'read'}
        and workflow['concurrency']['cancel-in-progress'] is False, 'distinct finite trigger and unchanged authority ceiling')
job = workflow['jobs']['observe']
require(job['env']['EXPECTED_OBSERVER_SHA256'] == sha(new_observer), 'workflow digest binds exact new observer')
relative_map = 'candidate/engineering/g132-engine-source-diagnostic/ENGINE_MAP.json'
map_raw = (NEW / relative_map).read_bytes()
require(map_raw == (OLD / relative_map).read_bytes() and len(json.loads(map_raw)) == 13, 'unchanged complete thirteen-member Engine map')
for relative in (relative_observer, 'test_hosted_diagnostic.py'):
    ast.parse((NEW / relative).read_text(), filename=relative)
    checks.append('Python parse without import: ' + relative)
for step in job['steps']:
    if 'run' in step:
        p = subprocess.run(['/usr/bin/bash', '-n'], input=step['run'].encode(), capture_output=True, timeout=15)
        require(p.returncode == 0, 'new workflow shell syntax; no execution')
        processes.append({'argv': ['/usr/bin/bash', '-n'], 'stdin_sha256': sha(step['run'].encode()),
                          'returncode': p.returncode, 'stdout_bytes': len(p.stdout), 'stderr_bytes': len(p.stderr)})
controls = (NEW / 'CONTROLS_STDERR.raw').read_text()
require(controls.count(' ... ok') == 7 and 'Ran 7 tests' in controls and controls.rstrip().endswith('OK'), 'received full seven-control results')
test_text = (NEW / 'test_hosted_diagnostic.py').read_text()
require("('ImageVersion','20261116.133.1')" in test_text and "('GITHUB_REF','refs/heads/" + OLD_BRANCH + "')" in test_text,
        'new controls explicitly refuse old finite image and old branch')
local = read(NEW / 'ACTUAL_NONHOST_STDOUT.raw')
require(local['status'] == 'REFUSED' and local['failed_phase'] == 'context'
        and local['process']['uid'] == 1000 and local['ordinary_git_children'] == []
        and local['original_execution'] is False and local['native_admission'] is False, 'received actual nonhost refusal with no Git children')

artifacts = provider('g132_terminal_artifacts.json')['artifacts']
artifact = next(a for a in artifacts if a['id'] == 14727857025)
archive = (NATIVE / 'PROVIDER_ARTIFACT.zip').read_bytes()
require(len(archive) == artifact['size_in_bytes'] == 1884
        and 'sha256:' + sha(archive) == artifact['digest'], 'archive bytes match retained provider digest')
require(artifact['workflow_run']['id'] == 44957502944
        and artifact['workflow_run']['head_branch'] == OLD_BRANCH
        and artifact['workflow_run']['head_sha'] == 'e1061002fffb4041f25be9ec89561a34227149b2', 'provider artifact exact run/source binding')
with zipfile.ZipFile(NATIVE / 'PROVIDER_ARTIFACT.zip') as z:
    require(set(z.namelist()) == {'OBSERVATION.json', 'STDERR.raw', 'NATIVE_EXIT_STATUS.raw', 'RETURN.json'}, 'archive exact four-member population')
    for name in z.namelist(): require(z.read(name) == (NATIVE / name).read_bytes(), 'actual archive member received: ' + name)
returned = read(NATIVE / 'RETURN.json')
for name, record in returned['members'].items():
    data = (NATIVE / name).read_bytes()
    require(len(data) == record['bytes'] and sha(data) == record['sha256'], 'native return seal member: ' + name)
observation = read(NATIVE / 'OBSERVATION.json')
context = observation['context']
require(returned['native_exit_status'] == 2 and (NATIVE / 'NATIVE_EXIT_STATUS.raw').read_bytes() == b'2\n'
        and observation['status'] == 'REFUSED' and observation['failed_phase'] == 'context'
        and observation['ordinary_git_children'] == [], 'prior actual context refusal remains failure with zero Git children')
require(context['ImageVersion'] == '20261116.376.1' and context['GITHUB_RUN_ID'] == '44957502944'
        and context['GITHUB_RUN_ATTEMPT'] == '1'
        and context['GITHUB_SHA'] == context['GITHUB_WORKFLOW_SHA'] == artifact['workflow_run']['head_sha'], 'actual image/source/run tuple')
logs = provider('g132_terminal_job_logs.json')['content']
require('Version: 20261116.376.1' in logs, 'retained provider job log corroborates actual image')
run = json.loads(provider('g132_run_current.json')['content'])
require(run['id'] == 44957502944 and run['head_sha'] == context['GITHUB_SHA']
        and run['head_branch'] == OLD_BRANCH and run['status'] == 'completed'
        and run['conclusion'] == 'failure' and run['run_attempt'] == 1, 'retained provider terminal run agrees')
for new_name, old_name in [('ACTUAL_PRIOR_IMAGE_REFUSAL.json', 'OBSERVATION.json'), ('PRIOR_RETURN.json', 'RETURN.json'), ('PRIOR_NATIVE_EXIT_STATUS.raw', 'NATIVE_EXIT_STATUS.raw')]:
    require((NEW / new_name).read_bytes() == (NATIVE / old_name).read_bytes(), 'candidate retains actual prior bytes: ' + new_name)
for i, relative in enumerate([relative_workflow, relative_map, relative_observer]):
    received = provider('g132_file_readback_' + str(i) + '.json')
    data = received['content'].encode()
    require(data == (OLD / relative).read_bytes() and blob(data) == received['sha'], 'retained published prior source exact: ' + relative)
prior_commit = json.loads(provider('g132_commit_readback.json')['content'])
require(prior_commit['sha'] == context['GITHUB_SHA'] and [p['sha'] for p in prior_commit['parents']] == [BASE]
        and prior_commit['tree']['sha'] == '84d5ae6574a26ca38b6598de1f4ca054b2adc3e5', 'prior diagnostic sole parent/tree preserved')

base_rows = parse_tree(git(['ls-tree', '-r', '-z', '--full-tree', BASE]).stdout)
require(derive_tree(base_rows) == '9b9c2b3f1453b83b87b628b665fceff492bf5b1e', 'complete base tree independently rederived without writes')
inherited = [x for x in old_seal['files'] if x['path'].startswith('inherited-source/')]
require(len(inherited) == 14, 'fourteen inherited source bodies retained')
for item in inherited:
    relative = item['path'][len('inherited-source/'):]
    require(blob((OLD / item['path']).read_bytes()) == base_rows[relative]['oid'], 'unchanged inherited body matches exact source: ' + relative)
plan = read(NEW / 'PUBLICATION_PLAN.json')
require(plan['base_commit'] == BASE and plan['base_tree'] == '9b9c2b3f1453b83b87b628b665fceff492bf5b1e'
        and plan['expected_tree'] == TREE and len(plan['entries']) == 3, 'proposed publication parent/tree/three-entry scope')
combined = dict(base_rows)
for row in plan['entries']:
    data = (NEW / 'candidate' / row['path']).read_bytes()
    require(row['path'] not in base_rows and row['mode'] == '100644'
            and len(data) == row['bytes'] and sha(data) == row['sha256'] and blob(data) == row['git_blob'], 'exact additive entry: ' + row['path'])
    combined[row['path']] = {'mode': row['mode'], 'kind': 'blob', 'oid': row['git_blob']}
require(derive_tree(combined) == TREE, 'complete proposed tree independently rederived without writes')
actual = git(['ls-tree', '-r', '-z', '--full-tree', TREE], required=False)
actual_tree_received = actual.returncode == 0
if actual_tree_received:
    require(parse_tree(actual.stdout) == combined, 'actual proposed tree object matches every inherited and added entry')
    require(git(['diff', '--no-ext-diff', '--check', '9b9c2b3f1453b83b87b628b665fceff492bf5b1e', TREE]).returncode == 0, 'exact proposed diff whitespace check')
require(sha((ROOT / 'dg17-full-family/SEAL.json').read_bytes()) == 'bae9f2bdf377f6c524e131be928858ce8d9f4d71fb8868357984254f70f71245', 'M09 frozen seal untouched')
result = {'schema': 'g132.image376.independent-delta-receiving.v1', 'at': datetime.now(timezone.utc).isoformat(),
          'status': 'PASS_ORDINARY_SOURCE_DELTA_ONLY', 'checks': checks, 'check_count': len(checks), 'processes': processes,
          'candidate_seal_sha256': sha((NEW / 'SEAL.json').read_bytes()), 'candidate_members': 17, 'candidate_bytes': 42994,
          'proposed_tree': TREE, 'derived_base_file_count': len(base_rows), 'derived_candidate_file_count': len(combined),
          'actual_candidate_tree_object_received': actual_tree_received, 'unchanged_inherited_source_count': len(inherited),
          'unchanged_Engine_map_count': 13, 'actual_prior_image': context['ImageVersion'], 'actual_prior_run': 44957502944,
          'actual_prior_native_exit': 2, 'prior_provider_archive_sha256': sha(archive),
          'provider_access': 0, 'source_edits': 0, 'ref_writes': 0, 'controller_mutations': 0,
          'reviewer_product_imports': 0, 'reviewer_original_executions': 0, 'reviewer_hosted_executions': 0,
          'controls_reexecuted': False, 'original_awards': [], 'protected_grant': 'UNISSUED'}
(OUT / 'MECHANICAL_RECEIVING.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'checks': len(checks), 'actual_tree_received': actual_tree_received,
                  'candidate_files': len(combined), 'reviewer_original_executions': 0, 'provider_access': 0}))
