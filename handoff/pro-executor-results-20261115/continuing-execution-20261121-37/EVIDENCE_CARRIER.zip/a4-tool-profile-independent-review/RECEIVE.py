#!/usr/bin/env python3
"""Read-only source receiving. Does not import the diagnostic or run its controls."""
import ast
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import yaml

SOURCE=Path('/workspace/scratch/097486cde2dd/dg18-a4-tool-profile')
HERE=Path(__file__).resolve().parent
REPO=Path('/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b')
SEAL_SHA='f3880386a8d8d7b0aba56b1cdfbe8423d59cfc8e61f89457b05bcb1dbcb65f5c'
PARENT='51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
BASE='9c3913ceaa95f3f36b0377fe2dba4a302afcba89'
EXPECTED='fc6732eda5c3ff810a05b5587362c0a92a644523'

def digest(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def oid(kind,raw):
    return hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()

def git(*args):
    env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',GIT_ALLOW_PROTOCOL='',
             GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_TERMINAL_PROMPT='0')
    return subprocess.run(['git','-c','protocol.allow=never','-c','core.fsmonitor=false',
        '--no-optional-locks','-C',str(REPO),*args],env=env,check=True,capture_output=True,
        timeout=20).stdout

def tree_oid(leaves):
    root={}
    for path,(mode,sha) in leaves.items():
        cursor=root
        parts=path.split(b'/')
        for part in parts[:-1]:cursor=cursor.setdefault(part,{})
        assert parts[-1] not in cursor
        cursor[parts[-1]]=(mode,sha)
    def walk(node):
        entries=[]
        for name,value in node.items():
            if isinstance(value,dict):
                mode,sha=b'40000',walk(value)
                sort_name=name+b'/'
            else:
                mode,sha=value
                sort_name=name
            entries.append((sort_name,mode+b' '+name+b'\0'+bytes.fromhex(sha)))
        raw=b''.join(value for _,value in sorted(entries))
        return oid('tree',raw)
    return walk(root)

def main():
    sr=(SOURCE/'FROZEN_SEAL.json').read_bytes()
    assert digest(sr)=={'bytes':2211,'sha256':SEAL_SHA}
    seal=json.loads(sr)
    members=[]
    assert set(p.name for p in SOURCE.iterdir())=={'FROZEN_SEAL.json',*(r['path'] for r in seal['files'])}
    for row in seal['files']:
        path=SOURCE/row['path'];before=path.lstat();raw=path.read_bytes();after=path.lstat()
        assert stat.S_ISREG(before.st_mode) and before.st_nlink==1 and before==after
        assert digest(raw)=={k:row[k] for k in ('bytes','sha256')}
        assert oid('blob',raw)==row['git_blob']
        assert format(stat.S_IFREG|stat.S_IMODE(before.st_mode),'o')==row['mode']
        members.append({'path':row['path'],**digest(raw),'git_blob':oid('blob',raw)})
    assert len(members)==8 and sum(r['bytes'] for r in members)==40448
    commit=git('cat-file','-p',PARENT).decode()
    assert commit.splitlines()[0]=='tree '+BASE
    leaves={}
    for item in git('ls-tree','-r','-z',BASE).split(b'\0'):
        if not item:continue
        metadata,path=item.split(b'\t',1)
        mode,kind,sha=metadata.split()
        assert kind in (b'blob',b'commit')
        assert path not in leaves
        leaves[path]=(mode,sha.decode())
    assert len(leaves)==1785 and tree_oid(leaves)==BASE
    expected=json.loads((SOURCE/'EXPECTED_TREE.json').read_bytes())
    additions=[]
    for path,row in expected['new_files'].items():
        raw=(SOURCE/row['local_file']).read_bytes()
        assert digest(raw)=={k:row[k] for k in ('bytes','sha256')}
        assert oid('blob',raw)==row['git_blob']
        assert path.encode() not in leaves
        leaves[path.encode()]=(row['mode'].encode(),row['git_blob'])
        additions.append({'path':path,'mode':row['mode'],'git_blob':row['git_blob'],**digest(raw)})
    assert len(leaves)==1787 and tree_oid(leaves)==EXPECTED
    inherited=[]
    for path,(mode,sha) in leaves.items():
        if path.startswith(b'.github/workflows/') and path.decode() not in expected['new_files']:
            raw=git('cat-file','blob',sha)
            document=yaml.load(raw,Loader=yaml.BaseLoader)
            inherited.append({'path':path.decode(),'git_blob':sha,**digest(raw),'on':document['on']})
    helper=(SOURCE/'tool_profile.py').read_bytes()
    control=(SOURCE/'qualify_local.py').read_bytes()
    h_ast=ast.parse(helper);ast.parse(control)
    imports=[]
    for node in ast.walk(h_ast):
        if isinstance(node,ast.Import):imports.extend(alias.name for alias in node.names)
        elif isinstance(node,ast.ImportFrom):imports.append(node.module)
    assert not set(imports)&{'subprocess','multiprocessing','socket','urllib','requests','runpy','importlib'}
    document=yaml.load((SOURCE/'workflow.yml').read_bytes(),Loader=yaml.BaseLoader)
    job=document['jobs']['installed-file-metadata-only']
    assert job['runs-on']=='windows-2022' and job['timeout-minutes']=='8'
    assert job['steps'][2]['timeout-minutes']=='2'
    assert hashlib.sha256(helper).hexdigest() in job['steps'][2]['run']
    assert document['on']['push']['branches']==[expected['branch']]
    result={'schema':'dg18.a4.tool-profile-independent-mechanical.v1','authority':'NONE',
      'mechanical_receiving':'PASS','source_review_disposition':'GAP','source_seal':digest(sr),
      'source_members':members,'source_payload_bytes':40448,'source_payload_count':8,
      'parent':PARENT,'parent_commit_received_without_history_walk':True,'parent_tree':BASE,
      'derived_host_tree':tree_oid(leaves),'leaf_count':len(leaves),'only_additions':additions,
      'inherited_workflows':inherited,'helper_imports':sorted(set(imports)),
      'source_and_control_ast':'PASS_NO_IMPORT_OR_EXECUTION','workflow_yaml':'PASS',
      'reviewed_workflow':document,'native_API_calls':0,'diagnostic_imports':0,
      'qualification_controls_run':0,'product_Job_original_executions':0,'provider_writes':0,
      'Git_scope':'read-only local immutable objects; no lazy fetch, protocols, optional locks, or history recovery'}
    raw=(json.dumps(result,sort_keys=True,indent=2)+'\n').encode()
    if '--save' in sys.argv:
        with (HERE/'MECHANICAL_RECEIVING.json').open('xb') as out:out.write(raw)
    print(raw.decode(),end='')

if __name__=='__main__':main()
