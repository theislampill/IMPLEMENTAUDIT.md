# A4 installed-tool metadata profile: independent source review

**Disposition: GAP — repair the cross-API comparison and partial-error retention before publishing this candidate.** This is ordinary independent engineering advice with authority **NONE**. It is not an internal `audit-assess` activation, Root execution admission, readiness decision, original award, or closure.

Reviewer: `/root/a4_tool_profile_review`. The reviewer did not author or change the candidate, import its executable code, run its qualification controls, perform native Windows operations, execute product/Job/original code, or write to the provider/controller. Only this new review directory was written. Public official CPython source was retrieved read-only to resolve the concrete Windows compatibility question.

## Findings

### GAP-01 — high: the path/descriptor comparison rejects ordinary executables before hashing

**Candidate locations:** `tool_profile.py` lines 46–57, 189–193, and 211–217.

`identity()` includes every captured field except `st_atime_ns`. The hash gate compares the entire identity of a path-based `lstat` with descriptor-based `fstat`. The required CPython **3.12.10** does not assign identical semantics to all those fields:

1. In official `Modules/posixmodule.c`, `update_st_mode_from_path` adds permission bits `0111` to names ending in `.exe`, `.bat`, `.cmd`, or `.com`. Both the fast and slow path-based stat implementations invoke it. In official `Python/fileutils.c`, `_Py_fstat_noraise` derives the regular-file mode from file attributes through `_Py_attribute_data_to_stat` and does not apply the filename heuristic. All four fixed targets end in `.exe`. Consequently, an otherwise unchanged ordinary target cannot satisfy the candidate's complete `st_mode` equality.
2. In the same exact release, `win32_xstat` copies birth time into `st_ctime` and its nanosecond component. `_Py_fstat_noraise` passes native `FILE_BASIC_INFO.ChangeTime` through `_Py_attribute_data_to_stat`; the `os_fstat_impl` path serializes that structure directly. Thus `st_ctime_ns` can also differ for the same file when creation and change times differ. Masking only the executable permission bits would leave this independent semantic mismatch.

**Effect:** otherwise readable executables reach `PATH_HELD_IDENTITY_REFUSAL` with `bytes_read: 0` at line 193. Alias enumeration can still occur, but the intended held-byte digest and stable-read result are absent. This is a deterministic source incompatibility for the named `.exe` population, not a finding that any installed native file has actually been observed. No Windows result was simulated or inferred from Linux execution.

**Recommended correction:** retain the complete raw observations, then use a separate, explicitly reviewed cross-API identity comparison. Preserve regular-file/reparse refusal and substantive device/file identity, link count, size, attributes and comparable timestamps. Account narrowly for path-only executable permission inference and compare creation time through `st_birthtime_ns`; retain same-API before/after stability checks so native change-time observations remain useful. Apply the correction only to this diagnostic's comparison. Do not remove the prior executable single-link admission guard or relax original source/output rules.

**Primary source evidence:** exact tag [`python/cpython` v3.12.10, `Modules/posixmodule.c`](https://github.com/python/cpython/blob/v3.12.10/Modules/posixmodule.c), repository-reported blob `c21c6f06c729de2ac1a4598180a394261c86e53b`; and [`Python/fileutils.c`](https://github.com/python/cpython/blob/v3.12.10/Python/fileutils.c), blob `c7521751cd26d14ce41b9ea0f93b95e27221f8a7`. The exact relevant source excerpts and line numbers are retained in `CPYTHON_SOURCE_EVIDENCE.json`. The general Python documentation alone would not have resolved this release-specific mismatch.

### GAP-02 — medium: an after-read native error can erase the current partial profile

**Candidate locations:** `tool_profile.py` lines 195–198, 211–220, and 291–300.

At line 195, the assignment to `held_after` completes before `native.held_info(handle)` is called. If that second `GetFileInformationByHandle` operation fails, the exception is correctly appended to the local row and the descriptor is closed in `finally`. However, postprocessing is guarded only by the existence of `held_after`. Line 215 then unconditionally reads missing `native_after`, producing `KeyError` outside the per-profile catch.

**Effect:** `profile_one` never returns the local row. The caller has not yet written `PROFILE-NN.json` or appended its summary. The top-level handler therefore retains a generic `KeyError` and earlier profiles, while losing the current path/ancestor/native observations and the actual native error already collected. The current intent survives, but it does not replace the lost evidence. This contradicts the candidate's stated purpose of retaining partial metadata and actual native errors.

**Recommended correction:** make derived-field construction total over partial observations. Require each field needed by a comparison, give unavailable comparisons an explicit incomplete state, and retain the actual operation/error. Ensure that a profile row is returned or written after cleanup even when a final native metadata read fails. This correction must not turn missing metadata into a stable or successful profile.

This finding follows the actual source control flow and the documented failure contract of [`GetFileInformationByHandle`](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-getfileinformationbyhandle). It does not depend on injecting or modeling a Windows API result.

## Retention limitation to keep explicit

**L-01: a hard process/step timeout has no independent finalization path.** The helper's only `seal()` call is in its own `finally` at line 300. The two-minute step can terminate that process, while the subsequent `always()` upload accepts only `PROFILE_EVIDENCE.zip` and `ZIP_RECEIPT.json`. A kill before sealing can therefore leave already-written intent/partial JSON with no uploadable archive. The 45-second checks are honestly described as cooperative and cannot interrupt a single blocked native call.

This is a source-visible limit, not evidence that a native call will stall. Root should either provide a separately bounded, pinned finalization/receiving step if timed-failure retention is required, or narrow the retention claim to caught failures that return control to the helper. `always()` on the uploader alone does not guarantee retained partial evidence after timeout. No timeout experiment was run.

## Exact frozen inputs received

| Item | Independently received identity |
|---|---|
| Source packet | `/workspace/scratch/097486cde2dd/dg18-a4-tool-profile` |
| Frozen seal | `FROZEN_SEAL.json`, 2,211 bytes; SHA-256 `f3880386a8d8d7b0aba56b1cdfbe8423d59cfc8e61f89457b05bcb1dbcb65f5c` |
| Sealed payload | Exact eight members, 40,448 bytes; every byte count, SHA-256, Git blob ID and file mode matched |
| Helper | 19,553 bytes; SHA-256 `8853052332e4dcd85c44a6478d8ae3633eef4d2fb6bd7a8e8b7431f2c9d74db5` |
| Workflow | 2,996 bytes; SHA-256 `23171fac5d7eb946e7db988ad662e389a6d38db0ddaf2a62a75c04cacad7b534` |
| Sole proposed product parent | `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7` |
| Parent tree | `9c3913ceaa95f3f36b0377fe2dba4a302afcba89`, 1,785 leaves |
| Re-derived additive tree | `fc6732eda5c3ff810a05b5587362c0a92a644523`, 1,787 leaves |
| Proposed branch | `pro/dg18-a4-tool-profile-20261121-01` |

Only the new workflow and helper blobs are added. The complete base tree was reconstructed from read-only local immutable Git objects, then the two new blobs were applied in memory. No index, ref, worktree, history, or object database was changed. Local Git reads disabled lazy fetching, all transport protocols and optional locks. The parent commit's tree field was received directly; missing ancestors were not fetched or recovered.

The prior independent refusal packet's seal was also rehashed: 4,028 bytes, SHA-256 `9e62a62edc8f4e453d21bd598cdf91f6cd6ec52ce4c9e3d02040343eab90f045`; all 12 member hashes matched. Its report, source comparison and exact traceback were read. That evidence still supports only the combined regular-file/link-count pre-worker refusal in run `44956925804`, attempt 1. It does not identify the selected spelling, individual file type, or link count, and provides no compiler-memory measurement.

## Other reviewed properties

| Area | Source-level assessment |
|---|---|
| Scope | Four fixed installed paths only. The helper has no subprocess, Git, product, Job, original-test or network launch path. Returned aliases are recorded but never opened or admitted. |
| Windows API declarations | Pointer-width handles, 32-bit DWORD/BOOL fields, 52-byte `BY_HANDLE_FILE_INFORMATION` layout, and two-byte WCHAR check match the intended x64 ABI. Native success remains unmeasured. |
| File-handle ownership | Read-only `CreateFileW`, `FILE_SHARE_READ`, `OPEN_EXISTING`, no inheritable handle and `FILE_FLAG_OPEN_REPARSE_POINT`. Ownership transfers to one CRT descriptor; binary mode is explicit. The ordinary completion/error paths close through the owner once. GAP-02 concerns post-cleanup evidence loss, not a claimed double close. |
| Alias enumeration | Actual `FindFirstFileNameW`/`FindNextFileNameW`; fixed 4,096-character buffers; at most 32 stored names and one additional success to detect truncation. Only `ERROR_HANDLE_EOF` proves completion. Native errors, truncation, duplicates and `FindClose` failure remain explicit. The returned names are not identity-admitted. |
| Content read bound | At most 16 MiB plus one sentinel byte per attempted target, 64 KiB chunks, four targets. The source arithmetic is finite; GAP-01 prevents the intended valid executable path from reaching the read. |
| Output bounds | Fresh exact run directory, exclusive JSON writes, at most 1 MiB per record, 16 pre-seal members and 8 MiB JSON payload limit. The normal fixed output population stays within these limits. The ZIP/receipt is the sole upload population. |
| Deadline | Shared 45-second cooperative deadline, two-minute profile step and eight-minute job. No helper child process is created. L-01 limits what survives a hard timeout. |
| Observation labels | Raw path, ancestor, native handle and descriptor metadata are retained separately. Metadata snapshots are interval observations, not a proof of perpetual namespace immutability or executable custody. |
| Runtime | Actual Windows, exact CPython 3.12.10 x64 and executable spelling are required before profiling; kernel build 20348/server product type is checked after the intent records the observed tuple. No native-platform substitution is present. |
| Operation binding | Exact repository, push event, branch/ref, attempt 1, zero event-before, created true/deleted false, matching event-after/SHA, exact helper location and run-specific output. Root must still establish branch freshness, exact host commit, sole parent, tree and immutable publication readback. |
| Workflow | Official checkout, setup-python and artifact actions are fixed to full commit IDs. Checkout pins `github.sha`, disables credential persistence, submodules and LFS. Setup may obtain the exact Python on a cache miss, as authorized. No secret request or environment dump was added. |
| Inherited workflows | Parent `pages.yml` pushes only on `main`; parent `validate.yml` pushes only on `main` and the named integration branch. Their pull-request/manual triggers are not invoked by the proposed diagnostic branch push. No collateral inherited workflow is selected by this push. |

The API review used primary documentation for [CreateFileW](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilew), [GetFinalPathNameByHandleW](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-getfinalpathnamebyhandlew), [FindFirstFileNameW](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-findfirstfilenamew), [FindNextFileNameW](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-findnextfilenamew), and [Python msvcrt](https://docs.python.org/3.12/library/msvcrt.html). API signatures and ownership reasoning are source review, not native qualification.

## Qualification scope and return

`RECEIVE.py` parsed both Python files without importing them, parsed YAML, received the seal and pins, re-derived both full trees and received inherited workflow triggers. Its exact output is `MECHANICAL_RECEIVING.json`. The candidate's four reported local controls are meaningful checks of real Linux refusal, hardlink fields, missing-path errors and non-following `lstat`. Their code does not fake a Windows host. They do not test Windows path/descriptor semantic equivalence or partial native-after failure retention, which explains why they do not resolve GAP-01 or GAP-02. This reviewer did not repeat those controls or claim an independently observed RED/GREEN execution.

The recommendation is to return this frozen source candidate for a new reviewed revision addressing both findings. Root retains all provider, controller, launch and original-method decisions. The original 64 MiB guard, 28-method order, A4-07 `UNKNOWN_NO_REPLAY`, missing frozen R01–R09 contract and all prior awards remain unchanged. New original awards: **NONE**. Native tool profile: **UNEXECUTED**.
