#!/usr/bin/env python3
"""Receive one actual operation03 result without executing any product owner."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import stat
import sys
import zipfile

BASE=Path("/workspace/scratch/097486cde2dd")
RAW=BASE/"g132-native-44960479304"
OUT=BASE/"g132-finite-images-native-independent-receiving"
CAND=BASE/"g132-finite-images-candidate"
INHERITED=BASE/"g132-qualification/frozen-packet"
RUN=44960479304
JOB=137017958652
ARTIFACT=14728978265
COMMIT="1980ef263b6d978d690f7fc65e2fac4cabe0de08"
TREE="e711ea3512b3f608c4972f5e144b20d494100c22"
PARENT="f75533f95f0d099c87e7a04beb11b0a25628acdc"
SOURCE_TREE="9b9c2b3f1453b83b87b628b665fceff492bf5b1e"
SOURCE_PARENT="e76a07b2bae7c945e5a9d529ed8cf9069f4c9064"
BRANCH="pro/dg16-g132-engine-source-observe-20261121-03"
ARCHIVE_SHA="d9b13fbd9ae68a8d79fe1960e0a70447cf5b18dea24e1b06699d04ea87a550fa"
checks=[]
bindings=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def check(name,value,evidence=None):
    checks.append(dict(name=name,passed=bool(value),evidence=evidence))
    if not value:raise ValueError(name)
def provider(name):
    value=read(RAW/("PROVIDER_"+name+".json"))
    check(name+" provider success",value.get("isError") is False)
    return json.loads(value["structuredContent"]["content"])
def seal(directory,filename,digest,count,total):
    raw=(directory/filename).read_bytes();value=json.loads(raw);rows=value["files"]
    check("exact seal "+directory.name,sha(raw)==digest)
    check("sealed population "+directory.name,len(rows)==count and sum(r["bytes"] for r in rows)==total
          and len({r["path"] for r in rows})==count)
    for row in rows:
        p=directory/row["path"];b=p.read_bytes()
        check("sealed member "+directory.name+"/"+row["path"],
              not Path(row["path"]).is_absolute() and ".." not in Path(row["path"]).parts
              and stat.S_ISREG(p.lstat().st_mode) and not p.is_symlink()
              and len(b)==row["bytes"] and sha(b)==row["sha256"]
              and ("git_blob" not in row or blob(b)==row["git_blob"]))
    bindings.append(dict(path=str(directory/filename),bytes=len(raw),sha256=sha(raw),
                         payload_count=count,payload_bytes=total))
    return value

candidate=seal(CAND,"SEAL.json","27f3753b8264c4ff45460e01d1d1e2c5d5606120ab66936ca79b387b69bbe43a",29,101738)
review=seal(BASE/"g132-finite-images-independent-review","SEAL.json",
            "634ff94f64d073dbcc72000ab5b4767c5327490d82b14c68ff5b2c0cca7a231d",3,73163)
inherited=seal(INHERITED,"PACKET_MANIFEST.json",
               "75435d932de544b9bfdef13ba74387b64e95804757727ee6711dfe266ffdc1e8",32,2055057)
check("source review binds exact candidate and tree",review["candidate_tree"]==TREE
      and review["sole_parent"]==PARENT and review["candidate_seal_sha256"]==bindings[0]["sha256"]
      and review["disposition"]=="PASS_ORDINARY_SOURCE_DELTA_ONLY")
prior_mechanical=read(BASE/"g132-finite-images-independent-review/MECHANICAL_RECEIVING.json")
check("independent exact full tree proof retained",
      prior_mechanical["actual_candidate_tree_object_received"] is True
      and prior_mechanical["proposed_tree"]==TREE and prior_mechanical["parent_files"]==1768
      and prior_mechanical["candidate_files"]==1771
      and prior_mechanical["unchanged_inherited_source_count"]==14
      and prior_mechanical["unchanged_Engine_map_count"]==13)

discovery=provider("DISCOVERY")
check("one actual discovered operation03 run",discovery["total_count"]==len(discovery["workflow_runs"])==1
      and discovery["workflow_runs"][0]["id"]==RUN and discovery["workflow_runs"][0]["head_sha"]==COMMIT)
run=provider("RUN");jobs=provider("JOBS_INITIAL");artifacts=provider("ARTIFACTS");commit=provider("COMMIT")
check("terminal exact run",run["id"]==RUN and run["run_attempt"]==1 and run["status"]=="completed"
      and run["conclusion"]=="failure" and run["head_sha"]==COMMIT and run["head_branch"]==BRANCH
      and run["event"]=="push" and run["path"]==".github/workflows/dg16-g132-engine-source-observe.yml")
check("exact immutable commit tree sole parent",commit["sha"]==COMMIT and commit["tree"]["sha"]==TREE
      and [p["sha"] for p in commit["parents"]]==[PARENT])
check("complete one-job page",jobs["total_count"]==len(jobs["jobs"])==1)
job=jobs["jobs"][0]
check("terminal exact job attempt",job["id"]==JOB and job["run_id"]==RUN and job["run_attempt"]==1
      and job["head_sha"]==COMMIT and job["head_branch"]==BRANCH and job["name"]=="observe"
      and job["status"]=="completed" and job["conclusion"]=="failure" and job["labels"]==["ubuntu-24.04"])
steps={s["name"]:s for s in job["steps"]}
check("observer failure with successful checkout and upload",
      steps["Observe exact Engine and one fresh complete source checkout"]["conclusion"]=="failure"
      and steps["Check out separate diagnostic owner"]["conclusion"]=="success"
      and steps["Retain complete or partial actual outcomes"]["conclusion"]=="success"
      and all(s["status"]=="completed" for s in job["steps"]))
check("complete one-artifact page",artifacts["total_count"]==len(artifacts["artifacts"])==1)
artifact=artifacts["artifacts"][0]
check("artifact identity digest and head binding",artifact["id"]==ARTIFACT
      and artifact["name"]==f"g132-engine-source-{RUN}-1" and artifact["size_in_bytes"]==10828
      and artifact["digest"]=="sha256:"+ARCHIVE_SHA and artifact["expired"] is False
      and artifact["workflow_run"]["id"]==RUN and artifact["workflow_run"]["head_sha"]==COMMIT
      and artifact["workflow_run"]["head_branch"]==BRANCH)
archive=(RAW/"PROVIDER_ARTIFACT.zip").read_bytes()
check("actual ZIP digest and size",len(archive)==10828 and sha(archive)==ARCHIVE_SHA)
members={}
with zipfile.ZipFile(RAW/"PROVIDER_ARTIFACT.zip") as z:
    check("exact safe ZIP inventory",len(z.infolist())==4 and set(z.namelist())==
          {"OBSERVATION.json","RETURN.json","STDERR.raw","NATIVE_EXIT_STATUS.raw"})
    for info in z.infolist():
        check("regular bounded ZIP member "+info.filename,
              not info.is_dir() and not stat.S_ISLNK(info.external_attr>>16) and info.file_size<=2097152)
        b=z.read(info)
        check("actual extracted member "+info.filename,b==(RAW/info.filename).read_bytes())
        members[info.filename]=dict(bytes=len(b),sha256=sha(b))
ret=read(RAW/"RETURN.json")
check("return nonauthority and exit2",ret["authority"]=="NONE" and ret["native_admission"] is False
      and ret["original_awards"]==[] and ret["native_exit_status"]==2
      and ret["schema"]=="g132.ordinary-hosted-engine-source-native-return.v1"
      and (RAW/"NATIVE_EXIT_STATUS.raw").read_bytes()==b"2\n" and (RAW/"STDERR.raw").read_bytes()==b"")
check("return exact member inventory",set(ret["members"])==set(members)-{"RETURN.json"})
for name,row in ret["members"].items():check("return hash "+name,row==members[name])

publication=read(RAW/"PUBLICATION_EXACT_FILE_READBACKS.json");plan=read(RAW/"PUBLICATION_PLAN.json")
check("publication readbacks exact commit",publication["sha"]==COMMIT and len(publication["files"])==3)
published_rows=[]
for entry in plan["entries"]:
    r=next(x["result"] for x in publication["files"] if x["path"]==entry["path"])
    check("published body provider success "+entry["path"],r.get("isError") is False)
    s=r["structuredContent"];b=s["content"].encode()
    check("published exact full body "+entry["path"],s["encoding"]=="utf-8" and b==(CAND/"candidate"/entry["path"]).read_bytes()
          and len(b)==entry["bytes"] and sha(b)==entry["sha256"] and blob(b)==entry["git_blob"]==s["sha"])
    published_rows.append({k:entry[k] for k in ("path","bytes","sha256","git_blob")})
owner_path=CAND/"candidate/engineering/g132-engine-source-diagnostic/observe.py"
owner=owner_path.read_text()
map_value=read(CAND/"candidate/engineering/g132-engine-source-diagnostic/ENGINE_MAP.json")
obs=read(RAW/"OBSERVATION.json")
expected_context=dict(GITHUB_ACTIONS="true",RUNNER_ENVIRONMENT="github-hosted",
    GITHUB_REPOSITORY="theislampill/IMPLEMENTAUDIT.md",GITHUB_EVENT_NAME="push",
    GITHUB_REF="refs/heads/"+BRANCH,GITHUB_RUN_ATTEMPT="1",GITHUB_RUN_ID=str(RUN),GITHUB_SHA=COMMIT,
    GITHUB_JOB="observe",GITHUB_WORKFLOW_SHA=COMMIT,
    GITHUB_WORKFLOW_REF="theislampill/IMPLEMENTAUDIT.md/.github/workflows/dg16-g132-engine-source-observe.yml@refs/heads/"+BRANCH,
    ImageOS="ubuntu24",ImageVersion="20261116.133.1")
check("actual finite hosted context exact",obs["context"]==expected_context)
check("actual root native process",all(obs["process"][k]==0 for k in ("uid","euid","gid","egid"))
      and obs["process"]["executable"]=="/usr/bin/python3.12"
      and obs["process"]["pid"]==2339 and obs["process"]["ppid"]==2338
      and obs["process"]["proc_starttime_ticks"]=="104313")
check("own full body pin received",obs["diagnostic_owner"]["kind"]=="FILE"
      and obs["diagnostic_owner"]["bytes"]==len(owner.encode())
      and obs["diagnostic_owner"]["sha256"]==sha(owner.encode()))
check("both actual full thirteen-member Engine maps exact",
      obs["engine_loaded"] is True and obs["engine_loading_origin"]=="DIAGNOSTIC_CHECKOUT_EXACT_R2_MEMBERS"
      and len(map_value)==13 and obs["engine_map"]==obs["actual_checkout_engine_map"]==map_value)
check("prospective Git08ca physical pin",all(obs["git_before"].get(k)==v for k,v in dict(
    kind="FILE",bytes=4640384,mode=493,sha256="08ca4d2ee4d8915e86f1faaa52603752507c57af1d16d451dec9992bc9b6d801").items()))
check("only unchanged Git input gate ran and passed",set(obs["gates"])=={"unchanged_git_input_validator"}
      and obs["gates"]["unchanged_git_input_validator"]["status"]=="PASS")
check("all seventeen selected Git rows matched",len(obs["selected_git_file_rows"])==17
      and all(r["match"] is True for r in obs["selected_git_file_rows"]))
caps=dict(address_bytes=1610612736,cpu_seconds=120,file_bytes=268435456,
          descriptors=256,report_bytes=2097152,wall_seconds=240)
check("resource declarations exact",obs["resource_caps"]==caps)
check("resource install sequence precedes reached Engine and source phase",
      owner.index("resource.setrlimit(which,(value,value))") < owner.index("signal.alarm(CAPS['wall_seconds'])")
      < owner.index("phase='exact_engine_loading'") < owner.index("phase='complete_actual_source_capture'"))
check("install exceptions cannot be bypassed by local catch",
      "for which,value in [(resource.RLIMIT_AS,CAPS['address_bytes']),(resource.RLIMIT_CPU,CAPS['cpu_seconds']),\n"
      "                            (resource.RLIMIT_FSIZE,CAPS['file_bytes']),(resource.RLIMIT_NOFILE,CAPS['descriptors'])]:\n"
      "            resource.setrlimit(which,(value,value))" in owner)
check("final observer descriptor restoration",obs["descriptor_restoration"] is True)

source=obs["source_preparation"];commands=source["commands"];children=obs["ordinary_git_children"]
check("actual source preparation tuple clean complete",
      source["source_commit"]==source["expected_commit"]==PARENT and source["source_tree"]==SOURCE_TREE
      and source["ordered_parents"]==[SOURCE_PARENT] and source["clean"] is True
      and source["complete_objects"] is True and source["credential_source"]=="NONE"
      and source["repository"]=="https://github.com/theislampill/IMPLEMENTAUDIT.md.git")
check("exact eleven children and received commands",len(commands)==len(children)==11
      and len({c["pid"] for c in commands})==11)
prefix=["/usr/bin/git","-c","credential.helper=","-c","core.askPass=/bin/false",
        "-c","core.hooksPath=/dev/null","-c","gc.auto=0","-c","maintenance.auto=false"]
expected_args=[
 ["clone","--no-local","--no-hardlinks","--no-checkout","--",source["repository"],source["path"]],
 ["-C",source["path"],"symbolic-ref","--short","HEAD"],
 ["-C",source["path"],"config","--local","--get-regexp","^branch\\."],
 ["-C",source["path"],"config","--local","--remove-section","branch.main"],
 ["-C",source["path"],"fetch","--no-tags","--no-recurse-submodules","origin",PARENT],
 ["-C",source["path"],"checkout","--detach",PARENT],
 ["-C",source["path"],"show","-s","--format=%H%n%T%n%P","HEAD"],
 ["-C",source["path"],"rev-parse","--is-shallow-repository"],
 ["-C",source["path"],"status","--porcelain=v1","--untracked-files=all","--ignored"],
 ["-C",source["path"],"fsck","--strict","--full"],
 ["-C",source["path"],"rev-list","--objects","--all","--missing=print"]]
expected_environment=dict(PATH="/usr/bin:/bin",LANG="C",LC_ALL="C",TZ="UTC",
    GIT_CONFIG_NOSYSTEM="1",GIT_CONFIG_GLOBAL="/dev/null",GIT_TERMINAL_PROMPT="0",GIT_ASKPASS="/bin/false")
for i,(command,argv,args) in enumerate(zip(commands,children,expected_args),1):
    check("exact command and fixed environment "+str(i),command["arguments"]==args
          and argv==prefix+args and command["environment"]==expected_environment)
    check("successful received command custody "+str(i),command["returncode"]==0
          and command["command_received"] is True and command["wait_reaped"] is True
          and command["owned_group_absent"] is True and command["descriptor_restoration"] is True
          and command["process_handle_returned"] is True and command["process_creation_outcome"]=="HANDLE_RETURNED"
          and command["exception"] is None and command["cleanup_errors"]==[]
          and command["eof"]==dict(stdout=True,stderr=True)
          and command["timed_out"] is False and command["output_overflow"] is False
          and command["hashes_cover"]=="captured bytes" and 0<=command["elapsed_seconds"]<60
          and all(0<=v<=4194304 for v in command["stream_bytes"].values()))
check("source tuple stdout hash receives exact tuple",
      commands[6]["stream_bytes"]["stdout"]==123
      and commands[6]["stream_sha256"]["stdout"]==sha((PARENT+"\n"+SOURCE_TREE+"\n"+SOURCE_PARENT+"\n").encode()))
check("nonshallow stdout hash",commands[7]["stream_bytes"]["stdout"]==6
      and commands[7]["stream_sha256"]["stdout"]==sha(b"false\n"))
for i in (8,9):
    check("clean/fsck empty successful captures "+str(i+1),
          commands[i]["stream_bytes"]==dict(stdout=0,stderr=0)
          and all(v==sha(b"") for v in commands[i]["stream_sha256"].values()))
check("object listing receipt exact",source["object_rows"]==29463
      and commands[10]["stream_bytes"]["stdout"]==2591737
      and commands[10]["stream_sha256"]["stdout"]==source["object_listing_sha256"]
      =="eb0ffe70a402f6a7a18c9b16521557f0f0618cdfe5230f4d47baf893a3161c43")

prefix_path=INHERITED/"inherited-source/scripts/qualify-work-graph-prefix.py"
input_path=INHERITED/"inherited-source/scripts/work-graph-c5-inputs.py"
prefix_source=prefix_path.read_text();input_source=input_path.read_text()
check("actual loaded prefix and inputs match received source bytes",
      map_value["scripts/qualify-work-graph-prefix.py"]==dict(bytes=len(prefix_path.read_bytes()),sha256=sha(prefix_path.read_bytes()))
      and map_value["scripts/work-graph-c5-inputs.py"]==dict(bytes=len(input_path.read_bytes()),sha256=sha(input_path.read_bytes())))
check("literal unchanged full source bounds",
      "SOURCE_BOUNDS = dict(file_bytes=128 * 1024**2, total_bytes=256 * 1024**2,\n"
      "                     entries=4096, depth=40)" in prefix_source)
check("unique precise capture refusal predicate",
      prefix_source.count('raise ValueError("source input byte/entry bound exceeded")')==1
      and 'if count > bounds["entries"] or before.st_size > bounds["file_bytes"] or total > bounds["total_bytes"]:\n'
      '                    raise ValueError("source input byte/entry bound exceeded")' in prefix_source)
check("complete source unfiltered route",
      "state, stamps = P.snapshot_tree(root, objects, P.SOURCE_BOUNDS)" in input_source
      and 'projection="ALL_ACTUAL_BYTES_NO_GIT_OR_HIDDEN_OMISSIONS"' in input_source)
check("actual complete-source bound refusal",
      obs["status"]=="REFUSED" and obs["failed_phase"]=="complete_actual_source_capture"
      and obs["exception_type"]=="ValueError" and obs["reason"]=="source input byte/entry bound exceeded")
check("no completed capture or later gates",
      all(k not in obs for k in ["source_capture","git_after","git_bookends_equal","source_loading_bookends_current"])
      and all(k not in obs["gates"] for k in ["git_namespace","producer_contract","captured_head_identity"]))

host=obs["selected_host_input_observation"]
mismatches=[r for r in host["pins"] if r["match"] is False]
check("exact four selected host pin mismatches",len(host["pins"])==12
      and {r["path"] for r in mismatches}=={"/etc/ld.so.cache","/lib/x86_64-linux-gnu/libc.so.6",
          "/lib64/ld-linux-x86-64.so.2","/lib/x86_64-linux-gnu/libpthread.so.0"})
for row in host["pins"]:
    check("pin match consistent with actual fields "+row["path"],
          row["match"]==(row["observed"]["kind"]=="FILE"
              and all(row["observed"].get(k)==v for k,v in row["expected"].items())))
check("all four Python alias rows match",len(host["system_aliases"])==4
      and all(r["match"] is True for r in host["system_aliases"]))
check("actual NSS mismatch preserved",host["nss"]["result"]["match"] is False
      and host["nss"]["result"]["reason"]=="C5 provider actual passwd NSS is not files-only")
check("actual full startup refusal preserved",host["unchanged_owner_full_startup"]==
      dict(match=False,reason="C5 provider startup/native pin changed: /etc/ld.so.cache"))
check("actual selected bookends and aggregate unqualified",
      host["selected_bookends_equal"] is True and obs["selected_host_input_matches"] is False
      and host["object_count"]==14 and host["object_bytes"]==13342062)
check("actual launcher absent",obs["launcher_observation"]["path"]=="/usr/bin/bwrap"
      and obs["launcher_observation"]["match"] is False
      and obs["launcher_observation"]["observed"]["kind"]=="MISSING")
check("no original native authority",
      obs["authority"]=="NONE" and obs["overall_admission"]=="UNQUALIFIED"
      and obs["original_awards"]==[] and obs["provider_imports"]==0
      and obs["no_automatic_retry"] is True and obs["source_guards_unchanged"] is True
      and all(obs[k] is False for k in ["native_admission","original_execution","session_constructed",
          "provider_acquired","private_inputs_selected","launcher_provisioned","policy_changed"]))

log_record=read(RAW/"PROVIDER_JOB_LOGS.json")
check("job log provider success",log_record.get("isError") is False)
log=log_record["structuredContent"]["content"]
check("actual raw job log exact",log.encode()==(RAW/"JOB.raw").read_bytes())
corroboration={}
for name,text in dict(image="Version: 20261116.133.1",
    checkout="git checkout --progress --force "+COMMIT,
    native_exit="Process completed with exit code 2.",
    digest="SHA256 digest of uploaded artifact zip is "+ARCHIVE_SHA,
    artifact=f"Artifact g132-engine-source-{RUN}-1.zip successfully finalized. Artifact ID {ARTIFACT}").items():
    matches=[dict(line=i,text=line) for i,line in enumerate(log.splitlines(),1) if text in line]
    check("raw log corroboration "+name,len(matches)==1)
    corroboration[name]=matches[0]

result=dict(schema="g132.finite-images.actual-native-independent-receiving.v1",
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),authority="NONE",
    reviewer="/root/dg17_next_original",disposition="PASS_RECEIVING_AUTHENTIC_COMPLETE_SOURCE_BOUND_REFUSAL",
    diagnostic_outcome="FAILURE_COMPLETE_ACTUAL_SOURCE_CAPTURE",run_id=RUN,attempt=1,job_id=JOB,
    head_sha=COMMIT,head_branch=BRANCH,tree=TREE,sole_parent=PARENT,native_exit_status=2,
    actual_image=obs["context"]["ImageVersion"],actual_hosted_process=obs["process"],
    elapsed_seconds=(obs["finished_time_ns"]-obs["started_time_ns"])/1e9,
    authentic_engine_loads=2,each_engine_map_members=13,source_preparation_git_commands=11,
    command_receipts=commands,source_tuple={k:source[k] for k in [
        "source_commit","source_tree","ordered_parents","clean","complete_objects","object_rows","object_listing_sha256"]},
    actual_capture_failure=dict(reason=obs["reason"],owner="scripts/qualify-work-graph-prefix.py",
        function="snapshot_tree",source_bounds=dict(file_bytes=134217728,total_bytes=268435456,entries=4096,depth=40),
        possible_trigger_terms=["count > bounds['entries']","before.st_size > bounds['file_bytes']",
                               "total > bounds['total_bytes']"],
        exact_trigger="UNPROVED_NO_FAILING_PATH_OR_COUNTERS_RETAINED",
        source_capture_completed=False,source_namespace_gate="NOT_REACHED",
        producer_gate="NOT_REACHED",captured_HEAD_gate="NOT_REACHED"),
    resource_installation=dict(disposition="INSTALL_CALLS_RETURNED_BY_EXACT_SOURCE_ORDER_AND_REACHED_PHASE",
        direct_kernel_limit_readback_retained=False,declared_caps=caps),
    descriptor_restoration=True,
    selected_host_input_matches=False,host_pin_mismatches=[
        dict(path=r["path"],expected=r["expected"],
             observed={k:v for k,v in r["observed"].items() if k in ["kind","bytes","sha256","mode","link","resolved"]})
        for r in mismatches],nss_result=host["nss"]["result"],
    full_startup_result=host["unchanged_owner_full_startup"],launcher_missing=True,
    selected_bookends_equal=True,git_file_rows_match=17,python_alias_rows_match=4,
    source_temp_path=source["path"],source_temp_cleanup="NO_POST_EXIT_FILESYSTEM_DELETION_RECEIPT",
    full_object_listing_bytes_retained=False,full_capture_bytes_retained=False,
    overall_admission="UNQUALIFIED",native_admission=False,protected_grant="UNISSUED",original_awards=[],
    provider_reads=dict(branch_runs_discovery=1,terminal_run=1,attempt_jobs=1,commit=1,artifact_page=1,job_log=1,artifact_download=1),
    provider_writes=0,source_edits=0,product_imports=0,original_or_hosted_executions_by_receiver=0,
    controller_mutations=0,formal_audit_assess_activation=False,
    source_bindings=bindings,published_file_bodies=published_rows,
    archive=dict(id=ARTIFACT,bytes=len(archive),sha256=sha(archive),members=members),
    raw_log_corroboration=corroboration,checks=checks,check_count=len(checks),
    receiving_process=dict(pid=os.getpid(),ppid=os.getppid(),executable=sys.executable))
with (OUT/"MECHANICAL_RECEIVING.json").open("x") as stream:
    json.dump(result,stream,sort_keys=True,indent=2);stream.write("\n")
print(json.dumps({k:result[k] for k in ["disposition","check_count","run_id","job_id","native_exit_status",
    "authentic_engine_loads","source_preparation_git_commands","diagnostic_outcome","selected_host_input_matches"]},sort_keys=True))

