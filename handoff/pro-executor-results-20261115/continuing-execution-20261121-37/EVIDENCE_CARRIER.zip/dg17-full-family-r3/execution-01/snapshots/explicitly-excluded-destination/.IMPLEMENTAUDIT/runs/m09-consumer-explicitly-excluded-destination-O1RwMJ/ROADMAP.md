# Constructed ordinary M09 fixture

| Phase | Task |
|---|---|
| 1 | Apply the declared bounded cleanup request under its scope |
