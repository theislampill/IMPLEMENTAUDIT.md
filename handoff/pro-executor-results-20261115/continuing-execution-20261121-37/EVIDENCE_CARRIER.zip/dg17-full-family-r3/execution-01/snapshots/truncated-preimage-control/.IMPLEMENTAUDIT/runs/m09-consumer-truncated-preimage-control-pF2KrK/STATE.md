# Constructed ordinary M09 fixture

Status: unexecuted
Controller: absent; no currentness assertion
Run root: .IMPLEMENTAUDIT/runs/m09-consumer-truncated-preimage-control-pF2KrK
