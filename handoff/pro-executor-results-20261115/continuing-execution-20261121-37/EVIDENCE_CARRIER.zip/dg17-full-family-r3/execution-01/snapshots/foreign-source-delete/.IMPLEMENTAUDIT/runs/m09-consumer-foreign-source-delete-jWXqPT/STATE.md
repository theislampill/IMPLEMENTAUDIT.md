# Constructed ordinary M09 fixture

Status: unexecuted
Controller: absent; no currentness assertion
Run root: .IMPLEMENTAUDIT/runs/m09-consumer-foreign-source-delete-jWXqPT
