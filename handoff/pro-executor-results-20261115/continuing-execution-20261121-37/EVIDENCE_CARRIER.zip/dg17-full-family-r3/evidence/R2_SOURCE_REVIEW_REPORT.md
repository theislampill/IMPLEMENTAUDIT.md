# DG17 M09 R2 focused independent source review — PASS

**Disposition: PASS for the exact R2 pre-execution source packet. No further revision is required by this focused review.** H1 is corrected by the authentic missing dependency; M1 is corrected by exact complete operation post-state recognition and stronger result receiving; L1 is corrected by narrowing the cleanup claim. The previously reviewed full-family mapping remains coherent at the permitted mechanical authority layer.

This is an ordinary advisory review by `/root/independent_review`, with **authority NONE**. I authored none of the candidate repairs. Root alone retains the execution gate, subsequent receiving adjudication and any original-family award. This report is not formal internal readiness, product behavior evidence, a mutation kill, or DG17 closure.

The continuing commission is bound to Root's received G0043 receipt `33c5296d4d9bf5ae370780b3d9895a8ce1b825cd`, require-current verification `71b769/0`. No controller authority is delegated. No original, mutant, apply-witness operation, product loading or qualification rerun was performed by this review.

## Exact receiving and preserved inputs

Packet: `/workspace/scratch/097486cde2dd/dg17-full-family-r2`.

| Binding | Independently verified |
|---|---|
| R2 seal | 11,903 bytes; SHA256 `ee8a88f3ed2826ad2df0ad3f35c3682bb1a175504ad9e6300f41ef2283b47aa8` |
| R2 members | Exactly 66 regular files / 1,543,412 bytes; all hashes and sizes agree; no extras |
| Source commit/tree | `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7` / `9c3913ceaa95f3f36b0377fe2dba4a302afcba89` |
| Included source | 23 files / 983,360 bytes; all 22 R1 source bodies unchanged, plus the authentic dependency |
| Original validator | SHA256 `07b2e04ba9aefffc572ac9cf60ecddf88654a26590aaa045dadf464da7bc7dab` |
| Sole mutant | SHA256 `8e693bef6a99feb95aa6150ebbd0565cc7e5cda8c91c5ab3620e73da6871879c`; unchanged from reviewed R1 |
| Full case JSON | SHA256 `2a9f91f088bf355278571da5b6205d012a160366f518f402015373c08fe931ae`; unchanged |
| R2 oracle | SHA256 `42e3f6e7b54562ee882b839f0e3d656e30ec69c02ffc266e5882e4ad94552ebc` |
| R2 runner | SHA256 `bd75cdc4af99f7624f06526b4ecd09da15a0e4de15eaad8f9a2dbc1cccb8fd67` |
| R1 preservation | Its exact 8,522-byte seal and all 47 members / 1,274,368 bytes remain unchanged |
| Execution state | Both R1 and R2 `execution-01` directories absent at receiving |

Mechanical receiving **`bb7562/0`** ran this review's `RECEIVE.py`, a read-only parser/hash/comparison program. It neither imported candidate code nor invoked a candidate operation. Its complete result is retained in `MECHANICAL_RECEIVING.json`.

The review independently reconstructed all **32** declared non-derived member changes in `REVISION_DELTA.json`. The complete **14-section** `REVISION_DIFF.patch` was reconstructed byte-for-byte from the actual R1 and R2 files. All eight phase files change only their absolute packet oracle/case locators. The runner's only change is adding `run_relative` to the observation. Original operation arguments, ordering, source selection, requests, preimages, candidate bytes, scope lists and baseline expected outcomes remain unchanged.

The prior review and its seal `3116a27362548fed1e9900f8ee4cb3b04d7116b91d00a9e3b358774796a3c860` are retained exactly. Source equality was checked against the previously independently received R1 source population; the new dependency was additionally compared directly with its exact local Git tree entry and blob. Every Git read disabled lazy fetching and protocols. No missing historical object was fetched or repaired.

## Finding dispositions

### H1 — Corrected: actual selected-path dependency closure

R2 adds `source/skills/implementaudit/scripts/canonical_custody.py` unchanged from source commit 51416: **36,367 bytes**, Git blob `434f8cb1579d3dfff2ba8a6fad91849f32ef927e`, SHA256 `d52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389`. This is precisely the sibling and pin required by the unchanged `read-canonical-pair.py:24–50`.

`DEPENDENCY_CLOSURE.md` correctly limits its claim to the selected ordinary POSIX path: the ordinary claim owner, strict early `--claim-only` validator, full phase validator, real reader and its unconditional custody-module load, then unchanged helper operation/result paths. Controller rotation, generation-fence, batch and Windows operations are not selected by these frozen inputs. No return-3 stub or import bypass was added.

Static inspection of the added module's imports and top-level AST confirms only standard-library dependencies, type/function/class declarations, a ContextVar, and the standard-library contextmanager decoration. Windows kernel, filesystem and Git operations remain inside operational functions/methods. The actual loading qualification is also retained: `qualification/PRODUCT_HELP_RESULT.json` binds `/usr/bin/python3.13 -I -B …/read-canonical-pair.py --help`, exit 0, **600 bytes stdout**, empty stderr, and matching before/after source hashes; native author receipt `eb0035/0`. The complete streams match their recorded lengths and hashes.

This help route genuinely loads product code. Its unchanged argparse call at reader lines 493–502 exits on `--help` before `materialize_pair`; it does not prove the later ordinary selection or a witness operation. The sealed packet states that distinction accurately. No repeat was needed to close the missing-file finding.

### M1 — Corrected: exact full post-state and receipt checks

In `/workspace/scratch/097486cde2dd/dg17-full-family-r2/oracle.py:39–62`, the declared operation post-state is derived from the fixed request, full preimage and candidate bytes. The initial source must match the complete preimage. Delete removes exactly the declared source; replace assigns exactly the fixed candidate record; move removes the source and creates the declared previously absent destination with the complete preimage. Recognition requires equality of the **entire** work-plane map, successful-result checks and live/capture agreement. This rejects unchanged targets, wrong protected targets, additional unrelated edits, incorrect replacement/destination bytes and partial moves. No variant name is passed to the oracle.

At `oracle.py:65–140,170–198`, successful recognition requires exit 0, the actual v2 schema, `COMMITTED`, `NONE`, empty residue and exact operation identity. Target post-identities are compared with actual live state, including regular-file device/inode/link-count values. The ordered actual effect receipts must cover the targets with matching final after-state. The real transaction result is read through the recorded ordinary run path and must agree on the relevant identity/status/effect-plan fields. Its effect list must be a prefix of the final emitted effects. That prefix relation matches the unchanged helper's actual persistence design: `apply-observed-mutation.sh:2167–2202` saves completed observations before its own result-publication effects and returns a later live record. An existing journal is checked; journal absence on ordinary successful finalization is permitted by the source.

The baseline invariant comparison and refusal checks remain present. Two authorized cleanup controls and the preimage-refusal control still need to pass, and all eight originals still precede all mutants. The runner remains explicitly provisional and awards nothing (`run_m09.py:275–296`).

`MUTANT_EFFECT_PREDICATES.json` matches the five independently required effects exactly: the two protected-source deletions, opaque-path replacement with the frozen candidate, and both complete-preimage destination moves. Their whole-state expectations are fixed before any original operation. Case JSON and the original expected outcomes are unchanged.

The retained **35** precision checks (`qualification/ORACLE_QUALIFICATION.json`, author receipt `1eb61a/0`) are bound to these exact case, declaration and oracle hashes. Source review of `qualify_oracle.py` confirms they are explicitly counterfactual dictionaries exercising `exact_discriminator`, with a simulated successful-result Boolean. They are useful evidence for the exact-effect recognizer; they do **not** exercise live durable-result receiving or establish an actual helper success. The packet labels that limitation. The new receipt checks were reviewed against the unchanged producer source; their actual witness results remain to be received after an authorized operation.

### L1 — Corrected: cleanup claim matches implementation

`READINESS.md:76` now states direct-child captures and the implemented timeout signaling, and expressly disclaims proof of process-group absence or universal descendant cleanup. `run_m09.py:73–107` is unchanged. No new native containment or survivor-absence claim is made, and no unrelated containment qualification has been introduced.

## Independent receiving feasibility and claim ceiling

The future operation retains the required independent receiving material: fixed case inputs; real claim and phase/input snapshots; both variant package bodies; direct process argv/PID/exit/timestamps and complete stdout/stderr; before/after work-plane records; per-variant copies of post-state bytes; transaction files; separate oracle results; and the final execution manifest. The original post-state copies and transactions are saved before the subject is restored for the paired mutant (`run_m09.py:190–242`). The added `run_relative` supplies the oracle's actual transaction locator without changing the product command. A later receiver can verify byte effects, required absences, unchanged bystanders, helper records and durable result consistency against this frozen contract. Archived inode observations are historical observations, not a new live inode census.

All eight originals must pass; the five designated mutants must exhibit their specific actual unauthorized effects; both authorized cleanup controls and the unchanged preimage refusal must remain valid. Timeout, missing evidence, parser error, unrelated refusal, wrong target/bytes or extra effects cannot earn the family. A success-shaped driver summary alone remains insufficient.

This focused PASS preserves the R1 full-family assessment: original Issue211's residue/protected-dirty-work requirement, independent removal of unrelated-work protection, permitted authority layer, and renamed/unfamiliar discrimination are covered as one conjunction. It does not extend to all 5S pillars, complete L3 behavior, model judgment or host activation. The earlier actual Seiri-policy `SURVIVED` result remains valid and unawarded. Denominators remain **36 cases / 14 mutation families / 17 terminal clauses**; M10/M11/P02 remain stopped.

The added authentic dependency and tightened oracle resolve the reported pre-execution gaps. Actual original baseline, mutant effects and receiving outcome remain **unmeasured**. This report conveys no execution authority, original award or closure.
