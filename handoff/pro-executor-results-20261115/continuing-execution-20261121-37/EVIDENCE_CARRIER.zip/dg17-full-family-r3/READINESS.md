# M09 R3 — explicit disposable Git metadata setup

This is a distinct replacement candidate for the first M09 scope-consumer original family, which remains unaccepted. The R2 operation DG17_M09_SCOPE_CONSUMER_ORIGINAL_20261121_01 is terminal and will not be replayed. Its native invocation52733a/1 failed after two preparatory Git processes, while writing .git/info/sparse-checkout: the empty Git init template had created no .git/info directory. No fixture claim, original helper, oracle or mutant witness executed. The complete R2 packet and failed execution remain immutable at their original locations.

## Bound contract and only change

The complete R2 original requirement, family mapping, eight frozen witnesses, exact variant-blind discriminator, supported product consumer path, source and mutation identity, resource/authority limits and receiving requirements are incorporated from evidence/R2_READINESS.md and its exact independent review. R3 makes only the disposable fixture setup directory creation explicit, then rebinds the eight prospective phase command paths to this packet. Every product source byte, all case requests/preimages/candidate bytes/scopes/expected outcomes, the sole mutant and oracle are unchanged. This engineering correction does not weaken an original acceptance predicate or turn a failed result into PASS.

Selected source remains51416b2f156b341c4a5f09029e2c6ceb5b30b1e7,tree9c3913ceaa95f3f36b0377fe2dba4a302afcba89. Root retains sole execution/adjudication/publication authority. No G132 protected grant is involved.

## Qualification and next original gate

One separate actual fixture setup is authorized solely to verify the concrete failing setup path through its supported ordinary claim and exact dirty premise. It may not call Runner.one, apply-observed-mutation, the oracle or either original/mutant witness. Its output is separate engineering evidence, never an original award. The qualification directory is not reused by the original execution.

After qualification and focused independent review, Root may admit exactly one fresh R3 operation by:

`/usr/bin/python3.13 -I -B /workspace/scratch/097486cde2dd/dg17-full-family-r3/run_m09.py --execute --root-approval-reference <actual-new-Root-admission>`

The new original execution root must be absent. All eight originals precede mutants and must pass; all five designated mutant effects must match the exact whole requested post-state and durable receipts; the two authorized cleanup controls and unchanged preimage refusal must pass. Independent receiving must inspect real process captures, post-state bytes/absences, snapshots, transactions and final manifest. Root alone may award the one M09 family. Denominators36cases/14families/17terminalclauses remain unchanged, with no separate case or terminal award. All prior awards and actual M09 Seiri SURVIVED evidence remain preserved.

A failure stops and is retained. No automatic retry, cleanup, oracle/case tuning or accepted-operation replay is authorized. Timeout claims remain limited to direct-child captures and implemented signals. No universal process-group absence, model cognition, native lifecycle, complete DG17 or programme closure is claimed.

Actual setup qualification passed in949da3/0: nine Git commands and one real ordinary claim, exact dirty premise and supported source tree, with no helper/oracle/original/mutant operation. The complete qualification is retained as a ZIP plus full manifest/result under qualification/. Its separate output is never reused for original execution. R3_DELTA.json and R2_TO_R3.patch bind the nine exact runtime differences; the complete R2 source review and failure receiving are retained under evidence/.
