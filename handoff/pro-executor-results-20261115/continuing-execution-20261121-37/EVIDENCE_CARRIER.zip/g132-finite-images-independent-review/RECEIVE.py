#!/usr/bin/env python3
"""Focused static receipt; no product imports, controls replay or provider calls."""
from pathlib import Path
import ast
import copy
import datetime
import hashlib
import json
import os
import stat
import subprocess
import sys
import zipfile

BASE = Path("/workspace/scratch/097486cde2dd")
ROOT = BASE / "g132-finite-images-candidate"
OLD = BASE / "g132-image376-candidate"
OUT = BASE / "g132-finite-images-independent-review"
REPO = Path("/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b")
PARENT = "f75533f95f0d099c87e7a04beb11b0a25628acdc"
PARENT_TREE = "9b9c2b3f1453b83b87b628b665fceff492bf5b1e"
TREE = "e711ea3512b3f608c4972f5e144b20d494100c22"
checks = []
processes = []

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def git_hash(kind, raw):
    return hashlib.sha1(kind.encode() + b" " + str(len(raw)).encode() + b"\0" + raw).hexdigest()

def check(name, condition, evidence=None):
    checks.append(dict(name=name, passed=bool(condition), evidence=evidence))
    if not condition:
        raise ValueError(name)

def read(path):
    return json.loads(path.read_bytes())

def seal(directory, name, expected, count, size):
    raw = (directory / name).read_bytes()
    value = json.loads(raw)
    check("seal hash " + str(directory.name), sha(raw) == expected)
    rows = value["files"]
    check("payload inventory " + directory.name,
          len(rows) == count and sum(x["bytes"] for x in rows) == size
          and len({x["path"] for x in rows}) == count)
    for row in rows:
        path = directory / row["path"]
        check("safe regular member " + directory.name + "/" + row["path"],
              not Path(row["path"]).is_absolute() and ".." not in Path(row["path"]).parts
              and stat.S_ISREG(path.lstat().st_mode) and not path.is_symlink())
        data = path.read_bytes()
        check("exact member " + directory.name + "/" + row["path"],
              len(data) == row["bytes"] and sha(data) == row["sha256"]
              and ("git_blob" not in row or git_hash("blob", data) == row["git_blob"]))
    return value

candidate = seal(ROOT, "SEAL.json",
    "27f3753b8264c4ff45460e01d1d1e2c5d5606120ab66936ca79b387b69bbe43a", 29, 101738)
old = seal(OLD, "SEAL.json",
    "b828bb65aa945430e6d48891eb6856e431409c90633fe0c6857b303b3de23a8a", 17, 42994)
old_review = seal(BASE / "g132-image376-independent-review", "SEAL.json",
    "0429380234130a4f602eed1235c40af01052383f6e8843df86f3c2f7d8de7b2a", 4, 43241)
inherited = seal(BASE / "g132-qualification/frozen-packet", "PACKET_MANIFEST.json",
    "75435d932de544b9bfdef13ba74387b64e95804757727ee6711dfe266ffdc1e8", 32, 2055057)
full_review = seal(BASE / "independent-review/g132", "SEAL.json",
    "1349aa27dfbf34352bded4e3542a2dc0bc3405eeb7d0e9ef65bbe1f46927315f", 4, 54045)
check("candidate exact tree and authority",
      candidate["expected_tree"] == TREE and candidate["authority"] == "NONE"
      and candidate["hosted_executions"] == candidate["original_executions"] == candidate["provider_writes"] == 0)
check("whole candidate inventory unchanged",
      {str(p.relative_to(ROOT)) for p in ROOT.rglob("*") if p.is_file()}
      == {x["path"] for x in candidate["files"]} | {"SEAL.json"})

owner_path = "engineering/g132-engine-source-diagnostic/observe.py"
workflow_path = ".github/workflows/dg16-g132-engine-source-observe.yml"
map_path = "engineering/g132-engine-source-diagnostic/ENGINE_MAP.json"
before = (OLD / "candidate" / owner_path).read_text()
after = (ROOT / "candidate" / owner_path).read_text()
expected = before.replace(
    "BRANCH='pro/dg16-g132-engine-source-observe-20261121-02'",
    "BRANCH='pro/dg16-g132-engine-source-observe-20261121-03'")
expected = expected.replace(
    "ImageOS='ubuntu24',ImageVersion='20261116.376.1')", "ImageOS='ubuntu24')")
anchor = "    need(all(context.get(k)==v for k,v in exact.items()),'fixed ordinary context or host differs; no retry')\n"
insertion = ("    need(context.get('ImageVersion') in ('20261116.133.1','20261116.376.1'),\n"
             "         'actual image is outside the two independently observed finite diagnostic profiles')\n")
check("context insertion anchor unique", before.count(anchor) == 1)
expected = expected.replace(anchor, anchor + insertion)
check("entire full observer differs only by allowed delta", after == expected)
before_tree = ast.parse(before)
after_tree = ast.parse(after)
old_functions = {x.name: ast.dump(x, include_attributes=False)
                 for x in before_tree.body if isinstance(x, ast.FunctionDef)}
new_functions = {x.name: ast.dump(x, include_attributes=False)
                 for x in after_tree.body if isinstance(x, ast.FunctionDef)}
check("function population unchanged", set(old_functions) == set(new_functions))
for name in old_functions:
    if name != "validate_context":
        check("unchanged full function " + name, old_functions[name] == new_functions[name])
ctx = next(x for x in after_tree.body if isinstance(x, ast.FunctionDef) and x.name == "validate_context")
membership = [x for x in ast.walk(ctx) if isinstance(x, ast.Compare)
              and any(isinstance(op, ast.In) for op in x.ops)]
check("one exact literal image membership predicate", len(membership) == 1
      and ast.unparse(membership[0].left) == "context.get('ImageVersion')"
      and ast.literal_eval(membership[0].comparators[0]) == ("20261116.133.1", "20261116.376.1"))
check("finite image check before run and workflow identity remains",
      after.index(insertion) < after.index("need(re.fullmatch('[1-9]")
      < after.index("need(context.get('GITHUB_WORKFLOW_SHA')==context['GITHUB_SHA']"))

old_workflow_raw = (OLD / "candidate" / workflow_path).read_bytes()
new_workflow_raw = (ROOT / "candidate" / workflow_path).read_bytes()
new_owner_sha = sha(after.encode())
expected_workflow_raw = old_workflow_raw.replace(b"20261121-02", b"20261121-03").replace(
    b"c91fe0b013c5048298fb0784d9dcec5b601768c79c22064f2a6d3065fe597d85",
    new_owner_sha.encode())
check("entire workflow differs only by branch group selfhash",
      new_workflow_raw == expected_workflow_raw)
workflow = json.loads(new_workflow_raw)
job = workflow["jobs"]["observe"]
check("prospective distinct branch and group",
      workflow["on"] == {"push": {"branches": ["pro/dg16-g132-engine-source-observe-20261121-03"]}}
      and workflow["concurrency"] == {"group": "g132-engine-source-observe-20261121-03",
                                      "cancel-in-progress": False})
check("read-only workflow and fixed runner/timeouts",
      workflow["permissions"] == {"contents": "read"}
      and job["runs-on"] == "ubuntu-24.04" and job["timeout-minutes"] == 8
      and job["steps"][1]["timeout-minutes"] == 6)
check("actual owner hash and map bound",
      job["env"] == {"EXPECTED_OBSERVER_SHA256": new_owner_sha, "EXPECTED_MAP_BYTES": "2083"})
check("map exact unchanged bytes and thirteen members",
      (ROOT / "candidate" / map_path).read_bytes() == (OLD / "candidate" / map_path).read_bytes()
      and len(read(ROOT / "candidate" / map_path)) == 13)

validation = read(ROOT / "VALIDATION.json")
check("author controls record says seven passed",
      validation["status"] == "PASS" and validation["controls_count"] == 7
      and validation["actual_hosted_observations"] == validation["actual_original_operations"] == 0)
for row in validation["records"]:
    for stream in ("STDOUT", "STDERR"):
        data = (ROOT / (row["tag"] + "_" + stream + ".raw")).read_bytes()
        check("actual author capture " + row["tag"] + "_" + stream,
              len(data) == row[stream.lower() + "_bytes"]
              and sha(data) == row[stream.lower() + "_sha256"])
check("author controls native exits preserved",
      {x["tag"]: x["exit"] for x in validation["records"]} == {"CONTROLS": 0, "ACTUAL_NONHOST": 2})
log = (ROOT / "CONTROLS_STDERR.raw").read_text()
check("seven actual controls in log", log.count(" ... ok\n") == 7 and "\nRan 7 tests in " in log
      and log.endswith("\nOK\n"))
tests = (ROOT / "test_hosted_diagnostic.py").read_text()
check("controls import full owner and do not invoke hosted observation",
      "exec(compile(OWNER.read_bytes(),str(OWNER),'exec'),self.m.__dict__)" in tests
      and ".observe(" not in tests)
for token in ["20261116.133.1", "20261116.376.1", "20261116.133.2", "20261116.376.2",
              "('ImageVersion','')", "('ImageOS','ubuntu22')", "('GITHUB_RUN_ATTEMPT','2')",
              "20261121-02", "20261121-01"]:
    check("data control covers " + token, token in tests)
nonhost = read(ROOT / "ACTUAL_NONHOST_STDOUT.raw")
check("actual nonhost refusal with no later activity",
      nonhost["status"] == "REFUSED" and nonhost["failed_phase"] == "context"
      and nonhost["reason"] == "actual UID/GID zero is required"
      and all(nonhost["process"][k] == 1000 for k in ("uid", "euid", "gid", "egid"))
      and nonhost["ordinary_git_children"] == [] and nonhost["gates"] == {}
      and nonhost["descriptor_restoration"] is None)
check("local nonhost remains unqualified",
      nonhost["native_admission"] is False and nonhost["original_execution"] is False
      and nonhost["original_awards"] == [] and nonhost["overall_admission"] == "UNQUALIFIED")

image_records = []
for operation, run, digest, image in [
    ("01", 44957502944, "f704c518497098e804d5a11f370bcc5a78b3c9e77813c80c59c784f45bc07da7", "20261116.376.1"),
    ("02", 44959365296, "da633897428211084327098d0859a343adc94c23de8478429e75eed517aa8e81", "20261116.133.1"),
]:
    evidence = ROOT / "evidence" / ("operation" + operation)
    actual_zip = BASE / ("g132-native-" + str(run)) / "PROVIDER_ARTIFACT.zip"
    check("authentic prior archive exact op" + operation, sha(actual_zip.read_bytes()) == digest)
    with zipfile.ZipFile(actual_zip) as z:
        b = z.read("OBSERVATION.json")
        check("image observation equals actual archived bytes op" + operation,
              b == (evidence / "OBSERVATION.json").read_bytes())
        obs = json.loads(b)
        ret = json.loads(z.read("RETURN.json"))
        check("prior return binds image observation op" + operation,
              ret["members"]["OBSERVATION.json"] == {"bytes": len(b), "sha256": sha(b)}
              and ret["native_exit_status"] == 2)
        check("actual observed image and terminal refusal op" + operation,
              obs["context"]["GITHUB_RUN_ID"] == str(run) and obs["context"]["ImageVersion"] == image
              and obs["context"]["ImageOS"] == "ubuntu24" and obs["failed_phase"] == "context"
              and obs["status"] == "REFUSED" and obs["ordinary_git_children"] == []
              and obs["gates"] == {} and obs["native_admission"] is False)
        image_records.append(dict(operation=operation, run_id=run, archive_sha256=digest,
                                  observation_sha256=sha(b), actual_image=image, native_exit_status=2))
    receiving_seal = read(evidence / "RECEIVING_SEAL.json")
    report_row = next(x for x in receiving_seal["files"] if x["path"] == "REPORT.md")
    report_raw = (evidence / "RECEIVING_REPORT.md").read_bytes()
    check("independent receiving report seal exact op" + operation,
          len(report_raw) == report_row["bytes"] and sha(report_raw) == report_row["sha256"])
check("finite set equals both authenticated actual images",
      set(r["actual_image"] for r in image_records) == {"20261116.133.1", "20261116.376.1"})
op02_raw = ROOT / "evidence/operation02/RAW_EVIDENCE_SEAL.json"
check("op02 full raw seal exact inherited receiving", sha(op02_raw.read_bytes()) ==
      "fcb01d7214fa91a345994472b4c06ed9da1fce8d60f75fe738ffdff03724d251")
for row in read(op02_raw)["files"]:
    b = (BASE / "g132-native-44959365296" / row["path"]).read_bytes()
    check("op02 retained raw member " + row["path"], len(b) == row["bytes"] and sha(b) == row["sha256"])
op01_seal = read(ROOT / "evidence/operation01/RECEIVING_SEAL.json")
check("op01 receiving bind matches actual received image",
      op01_seal["artifact"]["sha256"] == image_records[0]["archive_sha256"]
      and op01_seal["context_mismatches"] == {"ImageVersion": {
          "actual": "20261116.376.1", "expected": "20261116.133.1"}}
      and op01_seal["protected_admission"] is False)
adjudication = read(ROOT / "evidence/operation02/ROOT_TERMINAL_ADJUDICATION.json")
check("op02 Root preserved spent failure", adjudication["status"] == "TERMINAL_SPENT_NO_RETRY"
      and adjudication["native_exit"] == 2 and adjudication["original_awards"] == []
      and adjudication["protected_grant"] == "UNISSUED")

def command(argv, stdin=None):
    proc = subprocess.run(argv, input=stdin, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, check=False)
    processes.append(dict(argv=argv, exit=proc.returncode, stdout_bytes=len(proc.stdout),
                          stdout_sha256=sha(proc.stdout), stderr_bytes=len(proc.stderr),
                          stderr_sha256=sha(proc.stderr)))
    check("read-only receiving command " + " ".join(argv), proc.returncode == 0)
    return proc.stdout

git_prefix = ["/usr/bin/git", "-c", "protocol.allow=never", "-C", str(REPO)]
flat_raw = command(git_prefix + ["ls-tree", "-r", "-z", "--full-tree", PARENT])
flat = {}
for row in flat_raw.split(b"\0"):
    if not row:
        continue
    meta, path = row.split(b"\t", 1)
    mode, kind, object_id = meta.split()
    flat[path] = (mode, kind, object_id)
check("parent full file population", len(flat) == 1768)

def derive_tree(rows):
    root = {}
    for full_path, (mode, kind, object_id) in rows.items():
        parts = full_path.split(b"/")
        node = root
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        node[parts[-1]] = (mode, kind, object_id)
    def digest(node):
        entries = []
        for name, value in node.items():
            if isinstance(value, dict):
                mode, kind, object_id = b"40000", b"tree", digest(value).encode()
                sort_key = name + b"/"
            else:
                mode, kind, object_id = value
                sort_key = name
            entries.append((sort_key, mode + b" " + name + b"\0" + bytes.fromhex(object_id.decode())))
        data = b"".join(x[1] for x in sorted(entries))
        return git_hash("tree", data)
    return digest(root)

check("independently derived full parent tree", derive_tree(flat) == PARENT_TREE)
plan = read(ROOT / "PUBLICATION_PLAN.json")
check("publication plan exact immutable parent/tree",
      plan["base_commit"] == PARENT and plan["base_tree"] == PARENT_TREE
      and plan["expected_tree"] == TREE and len(plan["entries"]) == 3
      and plan["provider_writes"] == plan["ref_updates"] == 0)
added = copy.deepcopy(flat)
for entry in plan["entries"]:
    path = entry["path"]
    b = (ROOT / "candidate" / path).read_bytes()
    check("exact planned addition " + path,
          path.encode() not in flat and entry["mode"] == "100644"
          and len(b) == entry["bytes"] and sha(b) == entry["sha256"]
          and git_hash("blob", b) == entry["git_blob"])
    added[path.encode()] = (b"100644", b"blob", entry["git_blob"].encode())
check("exact three-addition full candidate tree",
      len(added) == 1771 and derive_tree(added) == TREE
      and set(added) - set(flat) == {workflow_path.encode(), owner_path.encode(), map_path.encode()})
for row in inherited["files"]:
    if row["path"].startswith("inherited-source/"):
        relative = row["path"][len("inherited-source/"):]
        b = (BASE / "g132-qualification/frozen-packet" / row["path"]).read_bytes()
        check("inherited authentic full source blob " + relative,
              flat[relative.encode()][2].decode() == git_hash("blob", b))
actual_tree = command(git_prefix + ["ls-tree", "-r", "-z", "--full-tree", TREE])
expected_flat = b"".join(mode + b" " + kind + b" " + object_id + b"\t" + path + b"\0"
                         for path, (mode, kind, object_id) in sorted(added.items()))
check("actual complete candidate tree object equals independent map", actual_tree == expected_flat)
command(["/usr/bin/bash", "-n"], job["steps"][1]["run"].encode())

result = dict(schema="g132.finite-images.independent-source-review.v1",
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    reviewer="/root/dg17_next_original", source_author="/root", authority="NONE",
    disposition="PASS_ORDINARY_SOURCE_DELTA_ONLY", candidate_seal_sha256=
    "27f3753b8264c4ff45460e01d1d1e2c5d5606120ab66936ca79b387b69bbe43a",
    candidate_members=29, candidate_bytes=101738, proposed_tree=TREE, sole_parent=PARENT,
    independently_derived_parent_tree=PARENT_TREE, parent_files=len(flat),
    candidate_files=len(added), actual_candidate_tree_object_received=True,
    allowed_ordinary_image_versions=["20261116.133.1", "20261116.376.1"],
    authenticated_actual_observations=image_records, unchanged_Engine_map_count=13,
    unchanged_inherited_source_count=14, product_imports=0, controls_reexecuted=False,
    hosted_executions=0, original_executions=0, provider_access=0, provider_writes=0,
    Git_mutations=0, controller_mutations=0, source_edits=0, original_awards=[],
    protected_grant="UNISSUED", formal_audit_assess_activation=False,
    processes=processes, checks=checks, check_count=len(checks),
    process=dict(pid=os.getpid(), ppid=os.getppid(), executable=sys.executable))
with (OUT / "MECHANICAL_RECEIVING.json").open("x") as stream:
    json.dump(result, stream, sort_keys=True, indent=2)
    stream.write("\n")
print(json.dumps({k: result[k] for k in ("disposition", "check_count", "proposed_tree",
    "sole_parent", "parent_files", "candidate_files", "actual_candidate_tree_object_received",
    "unchanged_inherited_source_count", "product_imports", "controls_reexecuted")}, sort_keys=True))

