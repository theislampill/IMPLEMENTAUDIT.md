# G132 finite-image operation 03 — independent focused source review

Report state: FINAL  
Disposition: **PASS_ORDINARY_SOURCE_DELTA_ONLY**  
Required revisions: **none**  
Authority: NONE. Root retains publication, execution and adjudication decisions.

## Result and reviewed scope

The proposed ordinary diagnostic admits exactly the two image-version strings independently observed in the preceding genuine hosted operations: **20261116.133.1** and **20261116.376.1**. The full observer otherwise differs from the sealed operation 02 observer only in its branch literal. The corresponding workflow changes only its branch, concurrency group, shell branch check and observer self-hash. Every other observer function, the full 13-member Engine map, all 14 inherited owner bodies, and the parent source tree remain unchanged.

This finite set is justified as a bounded context for an ordinary observation. It is not a claim that either image satisfies the complete protected runtime profile. Both prior operations remain authentic terminal failures, and operation 03 has not run.

Independent static receiving completed natively **f506e8/0**, with **282 passed checks**. The reviewer did not import or execute the product, replay the author's controls, start a hosted operation, call a provider, mutate Git, change source, touch the Root controller or delegate a nested review.

## Reviewer independence and current binding

Reviewer: /root/dg17_next_original. Source author: /root. I authored none of the G132 observer, workflow, map, inherited product owners or finite-image changes. I previously reviewed operation 02's source delta and independently received its terminal native artifact. That earlier evidence is explicit review input; it is not an undisclosed substitute for the present exact-delta and full-tree checks.

Requested/actual model: inherited parent model / GPT-6 Astra Pro, based on host/developer identity. No independent provider model-version attestation is claimed. This is ordinary advisory source review, not a formal audit-assess route.

The delegated scope is bound to Root controller dg16-dg18-recovery-20261119-b, epoch **G0043**, receipt **33c5296d4d9bf5ae370780b3d9895a8ce1b825cd**, currentness **72f182/0** supplied by Root. No Root controller authority was delegated.

## Exact packet and publication proposal

| Field | Reviewed value |
|---|---|
| Operation | G132_ENGINE_SOURCE_OBSERVE_20261121_03_FINITE_IMAGES |
| Candidate | /workspace/scratch/097486cde2dd/g132-finite-images-candidate |
| Candidate seal | 7,065 bytes; SHA256 27f3753b8264c4ff45460e01d1d1e2c5d5606120ab66936ca79b387b69bbe43a |
| Sealed payload | 29 files, 101,738 bytes |
| Proposed branch | pro/dg16-g132-engine-source-observe-20261121-03 |
| Sole parent | f75533f95f0d099c87e7a04beb11b0a25628acdc |
| Parent tree | 9b9c2b3f1453b83b87b628b665fceff492bf5b1e |
| Proposed tree | e711ea3512b3f608c4972f5e144b20d494100c22 |
| Parent / proposed file population | 1,768 / 1,771 |
| Protected grant | UNISSUED |
| Original awards | None |

All 29 candidate payloads were checked against their byte counts, SHA256 and Git blob fields where present. The whole on-disk packet inventory matches the manifest exactly.

The reviewer independently read the complete immutable parent tree with Git in network-disabled mode, reconstructed its Git tree hashes in memory, added only the three declared files, and derived **e711ea3512b3f608c4972f5e144b20d494100c22**. A separate read of the actual proposed tree object matched the complete independently assembled file/mode/blob map. No Git object, index or ref was written by the review.

| Added path | Bytes | SHA256 | Git blob |
|---|---:|---|---|
| .github/workflows/dg16-g132-engine-source-observe.yml | 3,126 | 59d22474d67aac0a3d82c480af5ddf9008c63aea97cf12970db91fc5473b5203 | d69ebf833490ba57c5f82c896187d6632e0a74ff |
| engineering/g132-engine-source-diagnostic/observe.py | 14,591 | a07c892547f76cb44dea0f8f79a178a7d147fb19f968645a4915b1aca553c1ee | c1788c24b7d9bad0ce8f9e852a19b06cfcb941b0 |
| engineering/g132-engine-source-diagnostic/ENGINE_MAP.json | 2,083 | 5d4e482896bd812dadbc49acd3d61daa3bd2ce774c650c967a86cab02d6235bf | e7ecd2aa57e0d62bc4491097422241d4bed9b915 |

These are additions to f755, not modifications to inherited product files. Root still must perform fresh provider-side absent-branch/run and exact publication checks before any separately authorized initial publication.

## Finite-image predicate and unchanged guards

The complete old observer was transformed in memory by exactly these permitted changes, then compared byte for byte with the complete new observer:

1. Branch literal 02 becomes 03.
2. ImageVersion is removed from the single-value exact-context dictionary.
3. Immediately after the unchanged exact-context check, a new requirement checks membership in the literal tuple ('20261116.133.1','20261116.376.1').

There is one image-membership predicate. It uses context.get('ImageVersion') and the two literal strings. No prefix, numeric ordering, wildcard, environment-derived allowed set or fallback is accepted. Empty, missing, neighboring and other values fail that predicate. Static AST comparison confirms that every function except validate_context is identical, including its complete body.

The required root UID/EUID/GID/EGID check remains first. Ubuntu24, GitHub-hosted context, repository, push event, branch, job, attempt 1 and exact workflow reference stay exact. Run-ID and SHA syntax and workflow/source SHA equality remain intact after the finite-image check.

The entire workflow equals the previous workflow after only the declared operation-identity and self-hash substitutions. It retains:

- Read-only contents permission, pinned checkout/upload actions, actual github.sha checkout, no persisted checkout credentials, disabled safe-directory change, submodules and LFS.
- Ubuntu24 runner, eight-minute job and six-minute observer-step timeouts, attempt 1, exact branch and bounded run-ID checks.
- Exclusive output directory and captures, clean env invocation, actual ImageOS/ImageVersion forwarding, pinned Python command and expected observer/map bindings.
- Native exit capture and return sealing that preserve failures, always-attempted artifact retention, overwrite false and no automatic retry.
- All observer physical-file, Git08ca, source tuple/completeness, namespace, producer, HEAD, audit, resource and timing guards.
- Overall UNQUALIFIED and false native/original admission; no private-input selection, launcher provisioning, policy change or original award.

The 13-member map is byte-identical. All 32 inherited source-packet payloads were re-received, including the 14 full owner bodies. Each inherited body's actual Git blob agrees with the authenticated f755 parent tree. The previous complete source-review seal and its four payloads, and the operation 02 source-review seal and its four payloads, remain exact. Their review scope and limits are inherited without treating this focused review as a fresh full-owner behavioral qualification.

## Actual evidence supporting the two image strings

| Actual operation | Run | Required image | Actual image | Native result |
|---|---:|---|---|---|
| 01 | 44957502944 | 20261116.133.1 | 20261116.376.1 | Exit 2, context refusal |
| 02 | 44959365296 | 20261116.376.1 | 20261116.133.1 | Exit 2, context refusal |

Both included OBSERVATION files equal the bytes in their actual previously authenticated archives. Archive hashes remain:

- Operation 01: **f704c518497098e804d5a11f370bcc5a78b3c9e77813c80c59c784f45bc07da7**.
- Operation 02: **da633897428211084327098d0859a343adc94c23de8478429e75eed517aa8e81**.

Both native RETURN records bind the exact observations and exit 2. Included receiving reports match their seals. Operation 02's entire raw-evidence seal and all 20 raw payloads were reverified. Root's operation 02 adjudication preserves TERMINAL_SPENT_NO_RETRY and no awards.

These are two actual environment observations with independent receiving. They do not prove a stable hosted image pool, predict the next assigned image, or establish equivalence of Git, Python, launcher, NSS, startup or any other bytes across the images. The unchanged later guards remain responsible for refusing mismatched inputs. A third image must still refuse.

## Local qualification evidence received

The author supplied seven bounded controls completed at **c467ba/0**, and their native capture hashes and results verify:

- Both exact image strings pass validate_context as data.
- Changed and neighboring image strings, an empty image, wrong Ubuntu OS, both older branches, main branch, changed repository, workflow SHA and attempt 2 refuse.
- Nonroot identity refuses.
- The exact Git08ca row passes its data predicate; the older Git body refuses.
- Incorrect source commit/tree/parents, dirty state and incomplete objects refuse.
- The base result retains no-admission and no-original claims.
- Return sealing retains a nonzero native status and exact stream hash.

The control source loads the complete observer module; it does not call observe(). Its context rows are data tests and are not passed off as genuine hosted executions. Missing ImageVersion is not a separately logged control case; its refusal follows directly from the unchanged get semantics and exact two-string membership predicate. No additional product execution was necessary to resolve that point.

The actual local nonhost entry used /usr/bin/python3.13 and recorded UID/EUID/GID/EGID 1000, PID 7, PPID 5, start ticks 389605. It refused with native exit **2** and reason actual UID/GID zero is required, before any ordinary Git child or later gate; stderr was empty. This establishes local refusal only. It does not qualify the hosted Python3.12 path.

The reviewer received these native records without replay. The only new child commands were two read-only Git tree reads and bash -n on the frozen workflow shell body; all returned zero. No observer or inherited product module ran in this review.

## Inherited limitations and publication gate

No new required finding was identified. All existing limitations remain binding:

1. **G132-SR-L1:** unchanged post-reap descendant detection may refuse without proving that the descendant group was actively terminated. No descendant survivor was observed in this source review. The review grants no universal cleanup or group-absence claim.
2. A genuine complete-source capture or captured HEAD check may refuse, including when the required loose object is packed. No repacking, unpacking, object synthesis, omitted input or relaxed guard is authorized.
3. Capture limits do not constitute a pre-clone aggregate disk quota. The current native artifact design retains summary metrics and state digest, not every hosted capture/object byte needed for independent replay.
4. The observer requires attempt 1 but does not itself enforce that this is the only push ever made to the new branch. Root must establish the distinct absent branch, expected sole parent/tree/three files and one initial publication. Later writes and retries are not admitted by this PASS.
5. Even a future native exit zero would support only the bounded ordinary Engine/source observation. The complete protected runtime, private inputs, sender/custody and original prerequisites remain separate. Original01 remains spent; no original or protected grant is issued here.

A future actual context may still fail the exact finite set or another unchanged prerequisite. The present PASS is limited to source eligibility for Root's next explicit decision. Operation 03 remains unexecuted in this report.

## Evidence and final disposition

RECEIVE.py contains the independent byte/AST/tree derivation and evidence checks. MECHANICAL_RECEIVING.json records the 282 results and the exact read-only child command captures. Native **f506e8/0** is the completed receiving run. This report and those files are sealed under the independent review directory; a final readback verifies their hashes and the unchanged candidate seal.

**PASS_ORDINARY_SOURCE_DELTA_ONLY — no required revisions; Root retains fresh publication, execution and adjudication authority.**

