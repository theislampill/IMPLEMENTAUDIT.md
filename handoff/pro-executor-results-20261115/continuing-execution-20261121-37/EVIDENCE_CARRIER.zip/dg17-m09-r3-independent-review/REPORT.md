# DG17 M09 R3 focused independent source review — PASS

**PASS for the exact R3 pre-execution packet. No further required revision identified.** The one-line disposable fixture correction addresses the observed R2 setup failure. Its separate actual setup qualification reaches the exact baseline, ordinary claim and dirty-input premise. The full M09 family contract, product source, sole mutant and exact-effect oracle remain unchanged.

This is ordinary advisory review by `/root/independent_review`, independent of Root's R3 authoring, with **authority NONE**. Root alone controls the new original-operation gate and later adjudication. No original, mutant, apply helper, oracle, setup qualification, Git command or product code was invoked by this review. Only this review's receiving/report files were written. Root supplied current G0043 receipt `33c5296d4d9bf5ae370780b3d9895a8ce1b825cd`, verification `72f182/0`; no controller authority was delegated.

## Exact mechanical receiving

| Evidence | Verified binding |
|---|---|
| R3 packet root | `/workspace/scratch/097486cde2dd/dg17-full-family-r3` |
| R3 seal | **20,772 bytes**, SHA256 `25d14085c698ed9809dfbc062f9b24d390077327b536a4ff1560473e87a59e90` |
| R3 payloads | **86 regular files / 1,954,077 bytes**, all exact; no missing or extra member |
| Product identity | Commit `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7`, tree `9c3913ceaa95f3f36b0377fe2dba4a302afcba89` |
| Unchanged product population | All **23 files / 983,360 bytes**, equal to the independently reviewed and source-bound R2 files |
| R3 runner | 18,074 bytes, SHA256 `3b83f026cd87d81e81f7b2012ab861cb9cf1dd01c1b6bd98af84ff3d0950bef8` |
| Qualification archive | **299,041 bytes**, SHA256 `ac955f3f2c49d99add4b1ffc828b98a3cbab7f87b94684ff48dbeafbbb6bd84f` |
| Qualification contents | **78 payloads / 834,291 bytes** plus its manifest; **79 unique ZIP entries / 850,389 uncompressed bytes**; CRC and every byte match the retained directory |
| R3 original execution directory | Absent at receiving |
| This review's receiving | **`ebf53c/0`**, retained in `MECHANICAL_RECEIVING.json` |

The receiving program reconstructed the complete nine-file runtime delta and `R2_TO_R3.patch` byte-for-byte. It verified the copied R2 readiness/review/failure seals against their original locations, every R2 packet member against its original seal, and every failed R2 execution member against its unchanged manifest. R2's 47 execution payloads / 1,378,688 bytes remain exact; the manifest remains 8,631 bytes with SHA256 `4ac883a973496e3c86b90c47a72197066fc15aed65d6df213e0d9e6e1bb1e93f`. The prior setup failure is preserved, not replayed or relabeled.

## Bounded runtime correction

At `/workspace/scratch/097486cde2dd/dg17-full-family-r3/run_m09.py:118`, the only executable change is:

```python
(subject / '.git/info').mkdir()
```

It runs after successful initialization of the new disposable subject and its object-store location lookup, immediately before the sparse-checkout file write. It creates the parent directory whose absence caused R2's actual failure at the equivalent write. It does not create metadata in the shared historical source repository. The new subject/output directory still uses the existing single-use setup; the operation does not reuse the failed R2 subject. The plain `mkdir()` also refuses an unexpected existing path rather than silently replacing it.

The other eight runtime file changes only rebind prospective phase command locators from the R2 absolute packet path to R3. Exact equality checks confirm that all product files, the original and mutant validator, case JSON, preimages/candidate bytes, scopes, original expected outcomes, oracle and effect declarations are unchanged. No authority predicate or expected original outcome has been altered because of the setup failure.

`READINESS.md` incorporates the complete sealed R2 family contract through `evidence/R2_READINESS.md`, supersedes its launch locator with the distinct R3 command, and explicitly preserves the failed R2 operation. `R3_DESIGN_AND_PLAN.json`, `R3_DELTA.json`, `READY.json` and the new `PREPARATION_RESULT.json` consistently describe this scope. The 175-check R2 preparation and earlier help/oracle precision qualifications are inherited evidence, not freshly rerun R3 behavior.

## Actual separate setup qualification received

Native qualification receipt **`949da3/0`** is bound in the packet. Its complete archive, manifest, result, process captures, live retained subject and snapshot were independently received from `/workspace/scratch/097486cde2dd/dg17-m09-r3-setup-qualification`.

All **ten direct runner commands** exited 0 with matching complete streams: nine Git commands and one Bash invocation of the exact unmodified ordinary `claim-run.sh`. They cover empty-template initialization, read-only source object location, sparse configuration, exact source checkout, HEAD/tree identity, absent controller-ref population, staging constructed user bytes, ordinary claim, and the final dirty-status observation. This is the direct-runner command census, not a census of every subprocess internally spawned by the Bash claim owner.

The qualification supplies concrete evidence for the repaired setup path:

- `.git/info/sparse-checkout` exists with exactly `/README.md\n/dg17-work/\n`.
- The captured checkout identity is the exact 51416 commit and its pinned tree.
- The controller-ref observation is empty and the real run has no `.controller` file.
- The claim command returns the actual ordinary run path, and the retained `.claimed`, templates, substituted phase and preimage all match the frozen input manifest.
- The staged-and-subsequently-modified user files show the required `AM` status; their current bytes equal the unchanged case data.
- The actual work-plane records match retained file bytes. The complete subject and pre-operation snapshot are byte-identical.
- No mutation transaction, per-variant observation or runtime package execution population exists in the qualification directory.

The ordinary claim is **actual product behavior** and the fixture setup makes real local writes. It must not be described as zero product execution or a purely static test. Its scope ends before `Runner.one`, `apply-observed-mutation.sh`, the oracle, or any original/mutant witness. It is not an M09 original result. The qualification output is separate from the absent R3 `execution-01` directory and is not reused for original execution.

The archive has unique safe relative file names, no symlink entries, valid CRCs and no missing/unlisted member. All archive bytes match the separately retained output. No qualification rerun was needed. Direct-child captures do not establish universal process-group absence; the previously corrected cleanup claim remains appropriately limited.

## Preserved eligibility and evidence ceiling

The R2 source-review findings remain corrected: the authentic canonical custody dependency is present, the variant-blind oracle requires the exact complete intended operation post-state and consistent successful/durable result evidence, and process cleanup claims are bounded. This R3 delta introduces no new consumer path or original-family conjunct.

The original execution contract remains one conjunction: all eight originals must pass before any mutant; all five designated mutants must show their exact unauthorized target/destination/byte effects with no extra work-plane change; the two authorized cleanup controls and unchanged preimage refusal must pass. Independent receiving remains required for actual process results, post-state bytes and absences, fixed inputs, transactions and final manifest. A driver summary alone does not award the family.

This PASS is source/setup eligibility evidence only. Actual original and mutant consumer results remain unmeasured. Root must bind a distinct new admission to this exact R3 seal before execution. The failed R2 operation and earlier actual M09 Seiri-policy survivor remain unchanged. Denominators stay **36 cases / 14 mutation families / 17 terminal clauses**; there is no separate case-row, terminal-clause, original award or whole-DG17 closure claim. M10/M11/P02 remain outside this operation.
