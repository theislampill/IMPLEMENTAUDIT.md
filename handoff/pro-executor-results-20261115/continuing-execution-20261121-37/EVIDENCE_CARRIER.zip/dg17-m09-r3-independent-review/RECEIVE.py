#!/usr/bin/env python3
"""Read-only R3 source and retained setup-qualification receiving."""
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import stat
import zipfile

BASE = Path('/workspace/scratch/097486cde2dd')
R2 = BASE / 'dg17-full-family-r2'
R3 = BASE / 'dg17-full-family-r3'
Q = BASE / 'dg17-m09-r3-setup-qualification'
OUT = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
def ident(path):
    b = path.read_bytes(); return {'bytes': len(b), 'sha256': sha(b)}
def verify_manifest(root, rows, extra=()):
    names = [r['path'] for r in rows]
    assert len(names) == len(set(names))
    for row in rows:
        name = Path(row['path']); assert not name.is_absolute() and '..' not in name.parts
        p = root / name
        assert not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)
        assert ident(p) == {k: row[k] for k in ('bytes', 'sha256')}
    assert {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()} == set(names) | set(extra)
    return len(names), sum(r['bytes'] for r in rows)

assert ident(R3 / 'SEAL.json') == {'bytes': 20772, 'sha256': '25d14085c698ed9809dfbc062f9b24d390077327b536a4ff1560473e87a59e90'}
s3 = json.loads((R3 / 'SEAL.json').read_bytes())
assert verify_manifest(R3, s3['files'], ['SEAL.json']) == (86, 1954077)
assert not (R3 / 'execution-01').exists()
assert ident(R2 / 'SEAL.json') == {'bytes': 11903, 'sha256': 'ee8a88f3ed2826ad2df0ad3f35c3682bb1a175504ad9e6300f41ef2283b47aa8'}
s2 = json.loads((R2 / 'SEAL.json').read_bytes())
for row in s2['files']:
    assert ident(R2 / row['path']) == {k: row[k] for k in ('bytes', 'sha256')}
assert ident(R2 / 'execution-01/EXECUTION_MANIFEST.json') == {'bytes': 8631, 'sha256': '4ac883a973496e3c86b90c47a72197066fc15aed65d6df213e0d9e6e1bb1e93f'}
failed = json.loads((R2 / 'execution-01/EXECUTION_MANIFEST.json').read_bytes())
assert verify_manifest(R2 / 'execution-01', failed['files'], ['EXECUTION_MANIFEST.json']) == (47, 1378688)
for history_name, current in [
    ('R2_READINESS.md', R2 / 'READINESS.md'), ('R2_SEAL.json', R2 / 'SEAL.json'),
    ('R2_SOURCE_REVIEW_SEAL.json', BASE / 'dg17-m09-r2-independent-review/SEAL.json'),
    ('R2_FAILURE_SEAL.json', BASE / 'dg17-m09-r2-failure-independent-receiving/SEAL.json')]:
    assert (R3 / 'evidence' / history_name).read_bytes() == current.read_bytes()

source_paths = sorted(p.relative_to(R2).as_posix() for p in (R2 / 'source').rglob('*') if p.is_file())
assert len(source_paths) == 23 and sum((R2 / n).stat().st_size for n in source_paths) == 983360
assert set(source_paths) == {p.relative_to(R3).as_posix() for p in (R3 / 'source').rglob('*') if p.is_file()}
for name in source_paths + ['oracle.py', 'inputs/cases.json', 'MUTANT_EFFECT_PREDICATES.json', 'MUTATION.json', 'MUTATION.diff', 'mutant/validate-phase.sh']:
    assert (R2 / name).read_bytes() == (R3 / name).read_bytes(), name
old = (R2 / 'run_m09.py').read_text(); new = (R3 / 'run_m09.py').read_text()
anchor = "        (subject / '.git/objects/info/alternates').write_text(str(objects) + '\\n')\n"
assert old.count(anchor) == 1
assert new == old.replace(anchor, anchor + "        (subject / '.git/info').mkdir()\n")
phase_paths = sorted(p.relative_to(R2).as_posix() for p in (R2 / 'inputs/phases').glob('*.md'))
for name in phase_paths:
    assert (R3 / name).read_text() == (R2 / name).read_text().replace(str(R2) + '/', str(R3) + '/')
delta = json.loads((R3 / 'R3_DELTA.json').read_bytes())
expected_delta = []
paths = ['run_m09.py', *phase_paths]
for name in paths:
    before, after = ident(R2 / name), ident(R3 / name)
    expected_delta.append({'path': name, 'before_bytes': before['bytes'], 'before_sha256': before['sha256'],
                           'after_bytes': after['bytes'], 'after_sha256': after['sha256']})
assert delta['changes'] == expected_delta
patch = ''.join(''.join(difflib.unified_diff((R2 / name).read_text().splitlines(keepends=True),
                  (R3 / name).read_text().splitlines(keepends=True), fromfile='R2/' + name, tofile='R3/' + name)) for name in paths)
assert patch == (R3 / 'R2_TO_R3.patch').read_text()

qual_manifest = json.loads((R3 / 'qualification/R3_SETUP_QUALIFICATION_MANIFEST.json').read_bytes())
assert (R3 / 'qualification/R3_SETUP_QUALIFICATION_MANIFEST.json').read_bytes() == (Q / 'MANIFEST.json').read_bytes()
assert verify_manifest(Q, qual_manifest['files'], ['MANIFEST.json']) == (78, 834291)
zip_path = R3 / 'qualification/R3_SETUP_QUALIFICATION.zip'
assert ident(zip_path) == {'bytes': 299041, 'sha256': 'ac955f3f2c49d99add4b1ffc828b98a3cbab7f87b94684ff48dbeafbbb6bd84f'}
with zipfile.ZipFile(zip_path) as z:
    infos = z.infolist(); names = [i.filename for i in infos]
    assert len(names) == len(set(names)) == 79 and z.testzip() is None
    assert set(names) == {r['path'] for r in qual_manifest['files']} | {'MANIFEST.json'}
    for info in infos:
        p = Path(info.filename)
        assert not p.is_absolute() and '..' not in p.parts and not info.is_dir()
        mode = info.external_attr >> 16
        assert not stat.S_ISLNK(mode)
        assert z.read(info.filename) == (Q / info.filename).read_bytes()
    zip_uncompressed_bytes = sum(i.file_size for i in infos)
qual = json.loads((Q / 'QUALIFICATION_RESULT.json').read_bytes())
assert (Q / 'QUALIFICATION_RESULT.json').read_bytes() == (R3 / 'qualification/R3_SETUP_QUALIFICATION_RESULT.json').read_bytes()
assert qual['runner_sha256'] == sha((R3 / 'run_m09.py').read_bytes())
assert qual['status'] == 'PASS' and qual['process_count'] == 10 and qual['fixture_claims'] == 1
assert qual['original_witness_executions'] == qual['mutant_witness_executions'] == 0
processes = []
captures = sorted((Q / 'processes').glob('*/process.json'))
assert len(captures) == 10
for p in captures:
    data = json.loads(p.read_bytes()); assert data['returncode'] == 0
    assert data['capture_directory'] == p.parent.relative_to(Q).as_posix()
    for stream in ('stdout', 'stderr'):
        assert ident(p.parent / (stream + '.bin')) == {'bytes': data[stream + '_bytes'], 'sha256': data[stream + '_sha256']}
    processes.append(data)
assert [p['argv'] for p in processes] == qual['commands']
assert sum(p['argv'][0] == '/usr/bin/git' for p in processes) == 9
assert processes[8]['argv'] == ['/usr/bin/bash', str(R3 / 'source/skills/implementaudit/scripts/claim-run.sh'), 'm09-consumer-owned-residue-delete']
assert all(p['argv'][0] == '/usr/bin/git' for i,p in enumerate(processes) if i != 8)
subject = Q / 'subjects/owned-residue-delete'; run = subject / qual['run_relative']
assert (subject / '.git/info/sparse-checkout').read_bytes() == b'/README.md\n/dg17-work/\n'
assert (captures[5].parent / 'stdout.bin').read_bytes() == b'51416b2f156b341c4a5f09029e2c6ceb5b30b1e7\n9c3913ceaa95f3f36b0377fe2dba4a302afcba89\n'
assert not (captures[6].parent / 'stdout.bin').read_bytes()
assert (captures[8].parent / 'stdout.bin').read_text().strip() == qual['run_relative']
dirty = (captures[9].parent / 'stdout.bin').read_text().splitlines()
assert 'AM dg17-work/user/notes.md' in dirty and 'AM dg17-work/user/unfinished-plan.txt' in dirty
assert not (run / '.controller').exists() and not (run / 'mutation-transactions').exists()
for name, value in qual['frozen_inputs'].items():
    assert ident(run / name) == value
case = json.loads((R3 / 'inputs/cases.json').read_bytes())['witnesses'][0]
assert case['id'] == 'owned-residue-delete'
for name, values in case['files'].items(): assert (subject / name).read_bytes() == bytes.fromhex(values['current_hex'])
assert (run / 'evidence/inputs/preimage.bin').read_bytes() == bytes.fromhex(case['preimage_hex'])
assert (run / 'phases/phase-1.md').read_text() == (R3 / 'inputs/phases/owned-residue-delete.md').read_text().replace('RUN_ROOT_FROM_REAL_CLAIM', qual['run_relative'])
for name, value in qual['before_workplane'].items():
    observed = ident(subject / name); assert value == {'kind': 'regular', **observed}
subject_files = {p.relative_to(subject).as_posix(): p.read_bytes() for p in subject.rglob('*') if p.is_file()}
snapshot = Q / 'snapshots/owned-residue-delete'
assert subject_files == {p.relative_to(snapshot).as_posix(): p.read_bytes() for p in snapshot.rglob('*') if p.is_file()}
assert not (Q / 'observations').exists() and not (Q / 'packages').exists()

result = {'schema': 'dg17.m09.r3.independent-focused-receiving.v1', 'at': datetime.now(timezone.utc).isoformat(),
    'reviewer': '/root/independent_review', 'authority': 'NONE', 'status': 'PASS',
    'R3_seal': ident(R3 / 'SEAL.json'), 'R3_payloads': 86, 'R3_payload_bytes': 1954077,
    'R2_seal_exact': True, 'R2_failure_manifest': ident(R2 / 'execution-01/EXECUTION_MANIFEST.json'),
    'R2_failure_members': 47, 'R2_failure_bytes': 1378688, 'R2_failed_operation_unmodified': True,
    'all_23_source_files_unchanged': True, 'source_bytes': 983360, 'oracle_cases_mutant_effects_unchanged': True,
    'runtime_delta': expected_delta, 'complete_patch_reconstructed': True,
    'qualification_zip': ident(zip_path), 'qualification_zip_members': 79,
    'qualification_uncompressed_bytes_including_manifest': zip_uncompressed_bytes,
    'qualification_manifest': ident(Q / 'MANIFEST.json'), 'qualification_payload_count': 78, 'qualification_payload_bytes': 834291,
    'qualification_result': qual, 'qualification_direct_processes': processes,
    'qualification_actual_source_effects': 'Nine direct Git commands and one direct Bash ordinary claim, including fixture writes; product claim is actual, zero apply/oracle/original/mutant operations',
    'process_tree_or_group_absence_claim': False, 'R3_original_execution_directory_absent': True,
    'reviewer_qualification_reruns': 0, 'reviewer_product_or_original_invocations': 0,
    'reviewer_source_provider_controller_ref_writes': 0, 'original_awards': [],
    'received_root_currentness': 'G0043@33c5296d4d9bf5ae370780b3d9895a8ce1b825cd; 72f182/0'}
(OUT / 'MECHANICAL_RECEIVING.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps({'status': 'PASS', 'packet_members': 86, 'packet_bytes': 1954077, 'runtime_delta_files': 9,
    'qualification_zip_members': 79, 'qualification_direct_commands': 10, 'ordinary_claims': 1,
    'original_or_mutant_operations': 0, 'R2_failure_preserved': True, 'R3_execution_absent': True}))
