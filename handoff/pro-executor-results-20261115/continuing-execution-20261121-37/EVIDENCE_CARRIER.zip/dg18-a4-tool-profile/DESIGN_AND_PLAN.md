# A4 installed-tool metadata profile

Authority NONE. Root selected this ordinary metadata-only operation and remains sole provider writer/adjudicator. Source parent is `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7`; prospective branch is `pro/dg18-a4-tool-profile-20261121-01`. Work is confined to this new packet. Existing packets and admission checks remain unchanged.

## Evidence and decision

Run `44956925804`, attempt 1, failed in `tool_paths()` / `physical()` before output, source receiving, Job import or any of its three workers. The predicate combined non-regular-file and link-count refusal. The actual selected spelling, `st_mode` and `st_nlink` were not recorded. Neither cause is established individually.

Root selected a separate factual profile of four finite installed paths: `C:\Program Files\Git\ucrt64\bin\git.exe`, `C:\Program Files\Git\mingw64\bin\git.exe`, `C:\Program Files\Git\bin\git.exe`, and `C:\hostedtoolcache\windows\Python\3.12.10\x64\python.exe`. Blindly relaxing the old predicate would lack a native fact; replaying unchanged code would repeat the same information gap. Neither alternative is included.

## Design

Add only `tool_profile.py` and one distinct workflow. Use Windows Server 2022, exact CPython 3.12.10 x64, credential-free pinned checkout, pinned official Python setup and artifact upload. The helper launches no subprocess, executes no Git/product/Job/original code, reads no returned alias target, and makes no network request. Standard workflow provisioning is the only checkout/Git activity.

For each fixed path retain separate `lstat` fields, type and reparse classification; ancestor snapshots before and after; held native handle information; held-descriptor `fstat`; a bounded streamed SHA-256; final path `lstat`; and the actual native final path. Open an existing file with `CreateFileW`, `GENERIC_READ`, `FILE_SHARE_READ`, and `FILE_FLAG_OPEN_REPARSE_POINT`. Reparse/non-regular/unsafe-ancestor inputs are recorded and not read. Hardlink count is a fact, not an execution allowance. Exact before/held/after metadata must agree for a stable-read label; partial failures remain explicit.

Use native `FindFirstFileNameW` / `FindNextFileNameW` with at most 32 recorded names, 4,096 characters per buffer and at most 33 successful name observations. `ERROR_HANDLE_EOF` proves enumeration completion; `ERROR_MORE_DATA`, count bounds, other errors and close failures remain observations. No returned alias is opened or admitted. Keep the source handle until hash, enumeration and final metadata receiving finish, then close it exactly once through its owning descriptor.

The helper requires actual Windows, exact Python version/x64 and exact first branch-creation push/attempt 1/ref/repository/event-after binding. Root verifies sole parent, full expected additive tree and immutable readback before publication; the helper performs no Git command to rederive that gate. It records the existing Root proof boundary explicitly.

Bounds: four files; at most 16 MiB plus one overrun sentinel byte per attempted file read; 64 KiB chunks; 32 aliases per file; 4,096-character native buffers; 45-second cooperative deadline; two-minute profile step; eight-minute whole workflow. Output is exclusive JSON only, at most 16 files, at most 1 MiB each and 8 MiB total. No environment dump, executable contents or credentials enter the artifact. Record errors and partial refusals, seal what actually exists, and upload the bounded output even when the profile fails.

Original 64 MiB, original method order, A4-07 UNKNOWN_NO_REPLAY and missing R01–R09 contract remain untouched. A profile is factual engineering evidence with no award or alias admission.

## Implementation plan

- [x] Add one small local check for absent implementation, then observe RED.
- [x] Implement the fixed-path native metadata profile and separate workflow.
- [x] Check syntax/YAML, exact pinned helper hash and bounds; run actual Linux refusal before output and real local file/hardlink metadata controls without mocking Windows.
- [x] Compute the exact two-file additive Git tree from the immutable parent and freeze payload hashes.
- [ ] Return for independent source review and Root launch decision; do not issue any provider action here.

Rollback: discard only this unissued packet. No commit or provider write in this lane. Review emphasis is API error handling, handle ownership, finite enumeration, preserved partial output, no alias execution, source/ref binding and honest evidence scope.
