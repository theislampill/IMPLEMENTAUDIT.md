# A4 installed-tool metadata profile — source packet

Disposition: **FROZEN SOURCE CANDIDATE FOR INDEPENDENT REVIEW; NATIVE PROFILE UNEXECUTED.**

Author `/root/dg18_a4_next`, authority NONE. Root remains sole provider writer/adjudicator. This follows the supplied G0042 receipt `a0dee5abe9e4ee81866cdf91d7568d25d35039a0`; the worker did not mutate or rederive Root's controller. All writes are confined to this new packet directory.

## Failure evidence and bounded next question

Actual hosted diagnostic `44956925804`, attempt 1, host commit `01e1be8ea75ea57d57b48bb98c32ec772cf849fe`, failed in `tool_paths()` line 184 and `physical()` line 55. The exception was the combined condition `not S_ISREG(st_mode) or st_nlink != 1`. The exact candidate spelling and individual metadata values were not retained. Neither alternative is established as the cause. This worker read the bounded traceback and the retained `NO_EXECUTION.json` / ZIP receipt (`508d04/0`, `58b02d/0`). Its retained diagnostic ZIP was 1,597 bytes, SHA-256 `a80db07e815f1d61b7a3da55dea2246baca6f584121646d13eaac1f14c27d3c7`.

The earlier R2 capture's physical tool check lacked this additional single-link requirement. That source difference motivates factual profiling; it does not authorize removing the new check or establish which branch of the failure fired. No installed-tool allowance, source admission or old predicate changed here.

Root selected a new metadata-only operation. It profiles exactly the three named Git candidates and exact Python executable; it never executes any Git executable, product module, Job helper or original test. It does not open any hardlink name returned by enumeration. Standard pinned checkout/provision actions are separately permitted workflow setup, not diagnostic tool execution.

## What the proposed native operation records

Each fixed path has an exclusive intent and profile record. The profile keeps separate raw `lstat` fields and regular/directory/symlink/reparse classifications; all ancestor snapshots before and after; native held-file identity and link count; held-descriptor `fstat` before and after; bounded streamed SHA-256 or an explicit partial/refused hash; final path metadata; native final-path results; and bounded hardlink enumeration.

The native file open uses `CreateFileW` with `GENERIC_READ`, `FILE_SHARE_READ`, `OPEN_EXISTING`, `FILE_FLAG_OPEN_REPARSE_POINT`, and no inheritable handle. A reparse or non-regular entry, or an unsafe/unavailable ancestor, remains an observation without content read. A hardlink count is recorded independently; it is never an executable admission. The file handle transfers to one binary-mode CRT descriptor and stays held through hashing, alias enumeration and final readback. It is closed once by its owner, with failures retained. All metadata and stability statements are bounded observations; none grants general custody or execution authority.

`FindFirstFileNameW` and `FindNextFileNameW` enumerate actual native hardlink names with at most 32 retained names, a fixed 4,096-character buffer, and one extra successful observation permitted solely to identify truncation. `ERROR_HANDLE_EOF` is the completion condition. Buffer errors, other native errors, duplicates, truncation and `FindClose` failures are retained explicitly. No returned alias is resolved, opened, executed or admitted. The count is compared to the observed native link count only as a factual consistency field.

The selected runtime is actual Windows Server 2022 (kernel build 20348 / server product type), CPython 3.12.10 x64 at the exact supplied spelling. Version or platform disagreement refuses profiling. The Windows kernel tuple is recorded before the server-build gate so a mismatch is inspectable. The helper itself starts no process, imports no product source, uses no network API and dumps no environment or executable bytes.

## Exact source and first-push binding

`EXPECTED_TREE.json` records the two additive source files. The complete immutable parent tree was independently reconstructed from read-only local Git metadata and matched `9c3913ceaa95f3f36b0377fe2dba4a302afcba89` before the two new blobs were added. The expected host tree is **`fc6732eda5c3ff810a05b5587362c0a92a644523`**, containing 1,787 leaves versus the parent's 1,785. The sole parent is **`51416b2f156b341c4a5f09029e2c6ceb5b30b1e7`**. No host commit is issued in this lane.

The proposed branch is `pro/dg18-a4-tool-profile-20261121-01`; workflow path `.github/workflows/dg18-a4-tool-profile.yml`; helper path `handoff/pro-executor-results-20261115/dg18-a4-tool-profile/tool_profile.py`. Both workflow and runtime require the exact repository/ref, push event, attempt 1, zero before SHA, event created true, deleted false, and matching event-after / current workflow SHA. The exact helper digest is pinned in the workflow. Output is bound to the exact run ID.

Root must verify the complete sole-parent/additive-tree/immutable-file conjunction before publication. As explicitly agreed with Root, the native helper does not execute Git to repeat that external gate. Credential-free checkout uses the exact workflow SHA; no credentials persist. Actions remain pinned. No automatic retry or cancel-in-progress is supplied.

## Resource and retention bounds

- Four installed files; at most 16 MiB plus one overrun sentinel byte read per file, in 64 KiB chunks.
- At most 32 retained alias names per file; 4,096-character native buffers; bounded ancestor populations.
- A shared 45-second cooperative profile deadline, a two-minute profile step, and an eight-minute workflow bound. No child processes exist to escape these bounds.
- At most 16 output files, 1 MiB per JSON record and 8 MiB of retained JSON payload. Errors and partial refusals remain in the sealed artifact. The output seal rejects non-regular, linked/reparse or unbounded output members and records omissions. Only the bounded ZIP and its exact receipt are uploaded.

If a native API, read or enumeration fails, the profile retains the actual error and any metadata already observed. Successful workflow completion means only that the fixed observation population was recorded; partial profiles and refusals remain explicit. Missing paths are not converted into successes. A lower or higher link count never changes the old admission check.

## Local qualification and limits

Expected RED `267b0a/0` proved that the small local control did not pass without implementation. Actual local control `14d149/0` then passed. Final source qualification `ab1ed9/0` checked Python syntax, parsed the workflow, verified the exact helper pin and time bounds, and reran all four actual local checks: non-Windows refusal before output; a real regular file with two hardlink names exposing link count separately; a real missing path retaining its error; and a real symlink observed with `lstat` rather than followed.

Those checks ran on Linux CPython 3.12.14. No Windows host was mocked and no native alias enumeration result was invented. Native API interoperability, installed path facts and hardlink aliases remain unmeasured until independent source review and Root launch. No broad tests or original suite was repeated. The closing process census is separate and bounded to this packet.

Original 64 MiB, method order, A4-07 `UNKNOWN_NO_REPLAY`, missing frozen R01–R09 contract, all prior awards and all unrelated constraints remain untouched. Original awards: NONE. Provider writes, hosted launches, replay, retry and cancel from this worker: ZERO.

Self-critique: before/held/after snapshots establish observations over a bounded interval, not universal namespace immutability; native enumeration may fail or be truncated and must remain incomplete; exact native facts can justify a later reviewed repair only after Root receives them. This packet does not claim the previous failure's cause.

## Primary API references consulted

- [FindFirstFileNameW](https://learn.microsoft.com/en-us/windows/desktop/api/fileapi/nf-fileapi-findfirstfilenamew) and [FindNextFileNameW](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-findnextfilenamew): signatures, fixed-buffer errors, enumeration completion and search-handle ownership.
- [CreateFileW](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilew), [GetFileInformationByHandle](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-getfileinformationbyhandle) and [GetFinalPathNameByHandleW](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-getfinalpathnamebyhandlew): read-only file opening and factual native handle/path metadata.
- [Python 3.12 msvcrt](https://docs.python.org/3.12/library/msvcrt.html): native-handle descriptor creation and explicit binary descriptor mode.
