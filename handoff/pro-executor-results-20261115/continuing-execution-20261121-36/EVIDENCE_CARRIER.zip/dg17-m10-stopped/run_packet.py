#!/usr/bin/env python3
"""Single-use execution entry. Root may invoke only after independent readiness."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
OWNER = ROOT / 'run-package/skills/implementaudit/scripts/route-transaction.py'
BASELINE = ROOT / 'source/source-peers/route-graph/skills/implementaudit/scripts/route-transaction.py'
MUTANT = ROOT / 'mutant/route-transaction.py'
PYTHON = '/usr/bin/python3'

def file_identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def verify_seal():
    seal = json.loads((ROOT / 'SEAL.json').read_bytes())
    for entry in seal['files']:
        path = ROOT / entry['path']
        if path.is_symlink() or file_identity(path) != {k: entry[k] for k in ('bytes', 'sha256')}:
            raise RuntimeError('Frozen input drift: ' + entry['path'])

def restrict():
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024 * 1024, 512 * 1024 * 1024))
    resource.setrlimit(resource.RLIMIT_CPU, (20, 20))
    resource.setrlimit(resource.RLIMIT_FSIZE, (65536, 65536))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

def invoke(directory, name, arguments):
    out, err = directory / (name + '.stdout'), directory / (name + '.stderr')
    start = time.monotonic()
    command = [PYTHON, '-I', '-S', '-B', *map(str, arguments)]
    timed_out = False
    with out.open('xb') as stdout, err.open('xb') as stderr:
        process = subprocess.Popen(command, cwd=directory, stdout=stdout, stderr=stderr,
            stdin=subprocess.DEVNULL, start_new_session=True, preexec_fn=restrict,
            env={'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8'})
        try:
            code = process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGKILL)
            code = process.wait(timeout=5)
    remaining_group = False
    try:
        os.killpg(process.pid, 0)
        remaining_group = True
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    record = {'name': name, 'argv': command, 'pid': process.pid, 'pgid': process.pid, 'exit': code,
              'wall_seconds': time.monotonic() - start, 'timed_out': timed_out,
              'group_absent_after_wait': not remaining_group, 'stdout': file_identity(out),
              'stderr': file_identity(err)}
    (directory / (name + '.process.json')).write_text(json.dumps(record, indent=2) + '\n')
    if timed_out or remaining_group or err.stat().st_size or out.stat().st_size > 65536:
        raise RuntimeError('Process failed bounded capture/custody: ' + name)
    return record

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    if output.parent != ROOT or output.exists():
        raise RuntimeError('Use a new direct child of the frozen packet directory; no replay.')
    verify_seal()
    output.mkdir()
    baseline_raw = BASELINE.read_bytes()
    if OWNER.read_bytes() != baseline_raw:
        raise RuntimeError('Fixture does not start with the authentic baseline owner')
    result = {'schema': 'dg17.m10.structural-execution.v1', 'state': 'STARTED', 'original_full_M10_award': False,
              'scope': 'Structural separate-governor-decision evidence conjunct only', 'processes': []}
    driver_args = [ROOT / 'owner_driver.py', '--owner', OWNER, '--cases', ROOT / 'inputs/CASES.json',
                   '--objects', ROOT / 'inputs/objects']
    try:
        result['processes'].append(invoke(output, 'baseline-owner', driver_args))
        if result['processes'][-1]['exit'] != 0:
            raise RuntimeError('Baseline owner process did not finish normally')
        result['processes'].append(invoke(output, 'baseline-oracle', [ROOT / 'oracle.py', '--oracle',
            ROOT / 'FROZEN_ORACLE.json', '--observations', output / 'baseline-owner.stdout']))
        if result['processes'][-1]['exit'] != 0:
            raise RuntimeError('Baseline violates the frozen oracle; stop before mutation')
        OWNER.write_bytes(MUTANT.read_bytes())
        result['processes'].append(invoke(output, 'mutant-owner', driver_args))
        if result['processes'][-1]['exit'] != 0:
            raise RuntimeError('Mutant owner process did not finish normally')
        result['processes'].append(invoke(output, 'mutant-oracle', [ROOT / 'oracle.py', '--oracle',
            ROOT / 'FROZEN_ORACLE.json', '--observations', output / 'mutant-owner.stdout']))
        judgement = json.loads((output / 'mutant-oracle.stdout').read_bytes())
        expected = json.loads((ROOT / 'FROZEN_ORACLE.json').read_bytes())['expected_mutant_violations']
        if result['processes'][-1]['exit'] != 1 or [x['name'] for x in judgement['violations']] != expected:
            raise RuntimeError('Mutation observation differs from the frozen expected contrast; preserve without repair')
        result['state'] = 'OBSERVED_FROZEN_STRUCTURAL_CONTRAST'
    except BaseException as error:
        result['state'] = 'PRESERVED_FAILURE_OR_NONVERDICT'
        result['error'] = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        OWNER.write_bytes(baseline_raw)
        try:
            verify_seal()
            result['sealed_inputs_and_baseline_restored'] = True
        except BaseException as error:
            result['sealed_inputs_and_baseline_restored'] = False
            result['poststate_error'] = type(error).__name__ + ': ' + str(error)
        (output / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    if not result['sealed_inputs_and_baseline_restored']:
        raise RuntimeError('Poststate seal failed')
    print(json.dumps({'state': result['state'], 'result': str(output / 'RESULT.json'),
                      'original_full_M10_award': False}, sort_keys=True))

if __name__ == '__main__':
    main()
