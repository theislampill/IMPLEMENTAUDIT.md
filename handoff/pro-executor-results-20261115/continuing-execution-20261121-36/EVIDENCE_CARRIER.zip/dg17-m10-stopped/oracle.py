#!/usr/bin/env python3
"""One unchanged, external behavioral oracle for either owner arm."""
import argparse
import json
from pathlib import Path

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--oracle', type=Path, required=True)
    parser.add_argument('--observations', type=Path, required=True)
    args = parser.parse_args()
    oracle = json.loads(args.oracle.read_bytes())
    observed = json.loads(args.observations.read_bytes())
    expected = oracle['cases']
    rows = observed['rows']
    if [x['name'] for x in rows] != [x['name'] for x in expected]:
        raise ValueError('Control population/order differs')
    violations = []
    for want, got in zip(expected, rows):
        errors = []
        if got['accepted'] is not want['expected_accept']:
            errors.append('acceptance differs')
        if want['expected_accept']:
            if got['exit'] != 0 or got['owner_stdout']:
                errors.append('valid control has output or nonzero status')
        elif got['accepted'] is False:
            result = json.loads(got['owner_stdout'])
            if (got['exit'] != 2 or result.get('error') != want['expected_error']
                    or result.get('advance_allowed') is not False):
                errors.append('refusal is not the frozen predicate-specific refusal')
        if errors:
            violations.append({'name': got['name'], 'errors': errors})
    print(json.dumps({'schema': 'dg17.m10.structural-oracle-result.v1', 'controls': len(rows),
                      'violations': violations, 'passed': not violations}, sort_keys=True))
    return int(bool(violations))

if __name__ == '__main__':
    raise SystemExit(main())
