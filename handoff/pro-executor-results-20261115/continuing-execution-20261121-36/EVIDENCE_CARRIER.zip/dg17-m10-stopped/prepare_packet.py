#!/usr/bin/env python3
"""Prepare frozen structural data. Never import or invoke the product owner."""
import ast
import base64
import copy
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source'
PACKAGE = ROOT / 'run-package'
PEER = 'source-peers/route-graph/skills/implementaudit/scripts/'
OWNER_SOURCE = SOURCE / (PEER + 'route-transaction.py')
OWNER_TARGET = PACKAGE / 'skills/implementaudit/scripts/route-transaction.py'

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode() + b'\n'

def digest(value):
    raw = json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
    return 'sha256:' + hashlib.sha256(raw).hexdigest()

def identity(raw):
    return {'bytes': len(raw), 'digest': 'sha256:' + hashlib.sha256(raw).hexdigest(),
            'bytes_b64': base64.b64encode(raw).decode()}

def named(value):
    return 'sha256:' + hashlib.sha256(('DG17_CONSTRUCTED_RECORD_VALUE:' + value).encode()).hexdigest()

def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(canonical(value))

def main():
    assert not PACKAGE.exists(), 'Preparation is single-use; preserve the prior packet.'
    mappings = [(f'skills/{name}/SKILL.md', f'skills/{name}/SKILL.md') for name in
                ('implementaudit', 'audit-state', 'audit-assess', 'audit-implement', 'audit-andon')]
    mappings += [('skills/implementaudit/scripts/resolve-internal-skill.py',
                  'skills/implementaudit/scripts/resolve-internal-skill.py')]
    mappings += [(PEER + name, 'skills/implementaudit/scripts/' + name) for name in
                 ('route-transaction.py', 'route_request_policy.py')]
    projection = []
    for source, target in mappings:
        raw = (SOURCE / source).read_bytes()
        destination = PACKAGE / target
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw)
        projection.append({'source_path': source, 'fixture_path': target,
                           'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    write_json(ROOT / 'PACKAGE_PROJECTION.json', {'scope': 'Exact source-byte fixture layout; no install/activation claim',
                                                'files': projection})
    owner = OWNER_SOURCE.read_text()
    removed = '            or not isinstance(lifecycle["governor_decision"], dict)\n'
    assert owner.count(removed) == 1
    changed = owner.replace(removed, '', 1)
    ast.parse(owner); ast.parse(changed)
    (ROOT / 'mutant').mkdir()
    (ROOT / 'mutant/route-transaction.py').write_text(changed)
    (ROOT / 'SOURCE_MUTATION.patch').write_text(''.join(difflib.unified_diff(owner.splitlines(True), changed.splitlines(True),
        fromfile='baseline/route-transaction.py', tofile='mutant/route-transaction.py')))

    tree = ast.parse(owner)
    constants = {node.targets[0].id: ast.literal_eval(node.value) for node in tree.body
                 if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
                 and node.targets[0].id in {'RECORD_KEYS', 'EXPIRES_ON'}}
    objects = ROOT / 'inputs/objects'
    objects.mkdir(parents=True)
    def retain(record):
        record = copy.deepcopy(record)
        record['record_identity'] = digest({k: v for k, v in record.items() if k != 'record_identity'})
        raw = canonical(record)
        oid = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        (objects / (oid + '.json')).write_bytes(raw)
        return oid, record

    child_path = PACKAGE / 'skills/audit-andon/SKILL.md'
    child = {'identity': str(child_path), **identity(child_path.read_bytes())}
    transaction = named('transaction')
    obligation = named('obligation')
    packet = {'schema': 'implementaudit.route-packet.v1', 'obligation_id': obligation,
              'route_transaction_id': transaction, 'target_identity': 'audit-andon',
              'source_event': {'schema': 'implementaudit.source-event.v1', 'source_identity': 'constructed-record-input',
                'provenance': {'schema': 'implementaudit.source-event-provenance.v1',
                               'event_id': 'constructed-record-input', 'host_correlation_id': named('correlation')},
                'body': 'Constructed structural record input; no actor, host event, authority or cognition is asserted.',
                'kind': 'one-shot-action', 'reactivation': {'reopen': False, 'target_changed': False,
                                                           'invalidating_evidence': False}}}
    packet_wire = identity(canonical(packet))
    returned = {'schema': 'implementaudit.child-return.v1', 'obligation_id': obligation,
                'route_transaction_id': transaction, 'packet_digest': packet_wire['digest'],
                'status': 'RETURNED', 'payload': {'construction': 'Structural input value; no actual child execution.'}}
    return_wire = identity(canonical(returned))
    decision = {'schema': 'implementaudit.governor-route-decision.v1', 'obligation_id': obligation,
                'route_transaction_id': transaction, 'return_digest': return_wire['digest'], 'outcome': 'SATISFIED',
                'reason': 'Constructed decision evidence value for the structural record consumer only.'}
    decision_wire = identity(canonical(decision))
    required = {key: None for key in constants['RECORD_KEYS']}
    required.update({'schema': 'implementaudit.route-decision.v1', 'predicate_version': 'R0033.route-predicate.v1',
        'controller_id': 'dg17-m10-constructed', 'claim_id': 'CONSTRUCTED_NO_AUTHORITY',
        'explicit_run_root': str(PACKAGE), 'continuity_generation': 'CONSTRUCTED_NO_CURRENTNESS',
        'continuity_receipt': 'CONSTRUCTED_NO_RECEIPT', 'host_id': 'CONSTRUCTED_NO_HOST',
        'host_session_id': 'CONSTRUCTED_NO_SESSION', 'host_binding_generation': 'CONSTRUCTED_NO_BINDING',
        'host_correlation_id': named('correlation'),
        'boundary': {'kind': 'CONSTRUCTED', 'event_id': 'constructed-record-input', 'digest': named('boundary')},
        'scope': {'identity': 'constructed-record-scope', 'digest': named('scope')},
        'action': {'identity': 'constructed-record-action', 'digest': named('action'),
                   'class': 'REQUIRED_INTERNAL_CHILD', 'argv': ['route-trigger', 'NONTRIVIAL_ANDON_DIAGNOSIS']},
        'evidence': [], 'inputs': [], 'package': {'source_digests': {}},
        'child_source': {key: child[key] for key in ('identity', 'digest')},
        'decision': 'REQUIRED', 'classification': 'MECHANICALLY_REQUIRED', 'invalidators': [],
        'expiry_fingerprint': named('fingerprint'), 'expires_on': constants['EXPIRES_ON'],
        'route_transaction_id': transaction, 'obligation_id': obligation,
        'route_state': 'UNSATISFIED', 'child_lifecycle_owned': False})
    required_oid, required = retain(required)
    opened = {**required, 'predecessor_record_oid': required_oid, 'route_state': 'OPEN', 'child_lifecycle_owned': True,
              'lifecycle': {'state': 'OPEN', 'required_record_oid': required_oid,
                'delivery': {'child': child, 'packet': packet_wire}, 'child_return': None, 'governor_decision': None,
                'governor_decision_count': 0, 'source_event_status': 'active'}}
    open_oid, opened = retain(opened)
    returned_record = {**opened, 'predecessor_record_oid': open_oid, 'route_state': 'RETURNED',
                       'lifecycle': {**opened['lifecycle'], 'state': 'RETURNED', 'child_return': return_wire}}
    returned_oid, returned_record = retain(returned_record)
    satisfied = {**returned_record, 'predecessor_record_oid': returned_oid, 'route_state': 'SATISFIED',
                 'lifecycle': {**returned_record['lifecycle'], 'state': 'SATISFIED', 'governor_decision': decision_wire,
                               'governor_decision_count': 1, 'source_event_status': 'satisfied'}}
    satisfied_oid, satisfied = retain(satisfied)
    cases = [{'name': 'open_valid', 'oid': open_oid}, {'name': 'returned_valid', 'oid': returned_oid},
             {'name': 'satisfied_valid', 'oid': satisfied_oid}]
    oracle = [{'name': row['name'], 'expected_accept': True} for row in cases]
    def negative(name, change, expected_error):
        value = copy.deepcopy(satisfied)
        change(value['lifecycle'])
        oid, _ = retain(value)
        cases.append({'name': name, 'oid': oid})
        oracle.append({'name': name, 'expected_accept': False, 'expected_error': expected_error})
    negative('missing_governor_decision', lambda x: x.update(governor_decision=None),
             'satisfied route lifecycle does not contain exactly one governor decision')
    negative('missing_child_return', lambda x: x.update(child_return=None),
             'route lifecycle governor decision has no exact child return')
    foreign = copy.deepcopy(decision); foreign['return_digest'] = named('foreign-return')
    negative('foreign_return_decision', lambda x: x.update(governor_decision=identity(canonical(foreign))),
             'route lifecycle governor decision names a foreign return')
    negative('zero_governor_decision_count', lambda x: x.update(governor_decision_count=0),
             'satisfied route lifecycle does not contain exactly one governor decision')
    negative('two_governor_decision_count', lambda x: x.update(governor_decision_count=2),
             'satisfied route lifecycle does not contain exactly one governor decision')
    write_json(ROOT / 'inputs/CASES.json', {'schema': 'dg17.m10.structural-cases.v1',
        'controller': 'dg17-m10-constructed', 'construction': 'All route/return/decision records are constructed inputs, never native evidence.',
        'cases': cases})
    write_json(ROOT / 'FROZEN_ORACLE.json', {'schema': 'dg17.m10.structural-oracle.v1', 'cases': oracle,
        'same_oracle_for_both_arms': True, 'expected_baseline_violations': [],
        'expected_mutant_violations': ['missing_governor_decision'],
        'claim_scope': 'Separate exact-return-bound governor decision evidence must exist in SATISFIED structural record.',
        'full_M10_claim': False, 'actual_child_return_and_rederivation_claim': False})
    print(json.dumps({'prepared': True, 'cases': len(cases), 'objects': len(list(objects.iterdir())),
                      'owner_executions': 0, 'mutant_sha256': hashlib.sha256(changed.encode()).hexdigest()}))

if __name__ == '__main__':
    main()
