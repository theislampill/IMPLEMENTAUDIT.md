#!/usr/bin/env python3
"""Strict canonical loader for the R0038 operational-evidence substrate."""
from __future__ import annotations

import argparse
import ast
import base64
import contextlib
import ctypes
import datetime
import decimal
import hashlib
import io
import json
import math
import os
import pathlib
import platform
import re
import secrets
import stat
import subprocess
import sys
import tempfile
import types
import unicodedata
import urllib.error
import urllib.request
from collections import Counter

# The controller's existing source identity transitively binds this new owner.
# Rebind both reviewed files together; missing, aliased or changed bytes fail closed.
_QUERY_POLICY_MODULE_SHA256 = '650e8353dc4b55c45ba3988bfc156be2b7bb9372289ab13c5b92eb5bcf48b8c8'
_QUERY_POLICY_MODULE_BYTES = 204440
def _load_query_policy_module():
    import hashlib as _hashlib
    import os as _os
    import stat as _stat
    import sys as _sys
    import types as _types
    _path = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'operational_query_policy.py')
    _fd = None
    try:
        _before = _os.lstat(_path)
        if (_stat.S_ISLNK(_before.st_mode) or not _stat.S_ISREG(_before.st_mode)
                or _before.st_nlink != 1 or _os.path.realpath(_path) != _path
                or getattr(_before, "st_file_attributes", 0) & 0x400):
            raise ImportError("operational_query_policy.py: source is not a non-aliased regular file")
        _flags = _os.O_RDONLY | getattr(_os, "O_BINARY", 0) | getattr(_os, "O_NONBLOCK", 0) | getattr(_os, "O_NOFOLLOW", 0)
        _fd = _os.open(_path, _flags)
        _info = _os.fstat(_fd)
        if (not _stat.S_ISREG(_info.st_mode) or _info.st_nlink != 1 or
                (_before.st_dev, _before.st_ino) != (_info.st_dev, _info.st_ino)):
            raise ImportError("operational_query_policy.py: source identity changed while opening")
        with _os.fdopen(_fd, "rb") as _stream:
            _fd = None
            _source = _stream.read(_QUERY_POLICY_MODULE_BYTES + 1)
    except OSError as _exc:
        raise ImportError("operational_query_policy.py: source unavailable") from _exc
    finally:
        if _fd is not None:
            _os.close(_fd)
    if len(_source) != _QUERY_POLICY_MODULE_BYTES or _hashlib.sha256(_source).hexdigest() != _QUERY_POLICY_MODULE_SHA256:
        raise ImportError("operational_query_policy.py: source identity mismatch")
    _module = _types.ModuleType(__name__ + ".query_policy_module")
    _module.__file__ = _path
    # Register before execution for annotations/introspection; undo a failed load.
    _previous = _sys.modules.get(_module.__name__)
    _sys.modules[_module.__name__] = _module
    try:
        exec(compile(_source, _path, "exec"), _module.__dict__)
    except BaseException:
        if _previous is None:
            _sys.modules.pop(_module.__name__, None)
        else:
            _sys.modules[_module.__name__] = _previous
        raise
    return _module
_query_policy_module = _load_query_policy_module()



RECORD_SCHEMA = "implementaudit-operational-evidence-v1"
VALIDATION_SCHEMA = "implementaudit-operational-evidence-validation-v1"
SCHEMA_DEFINITION = "implementaudit-operational-evidence-schema-v1"
REPOSITORY_COLLECTION_SCHEMA = "implementaudit-repository-collection-v1"
REPOSITORY_SNAPSHOT_SCHEMA = "implementaudit-repository-snapshot-v1"
CAPTURED_SNAPSHOT_SCHEMA = "implementaudit-captured-owner-snapshot-v1"
EVIDENCE_FAILURE_COLLECTION_SCHEMA = (
    "implementaudit-evidence-failure-collection-v1")
RELEASE_COLLECTION_SCHEMA = "implementaudit-release-collection-v1"
EXTERNAL_READ_CAPTURE_SCHEMA = "implementaudit-external-read-capture-v1"
STATIC_RECEIPT_SCHEMA = "implementaudit-static-receipt-v1"
STATIC_NORMALIZED_SCHEMA = "implementaudit-static-normalized-v1"
STATIC_NORMALIZED_SET_SCHEMA = "implementaudit-static-normalized-set-v1"
LEGACY_NATIVE_CURRENT_SCHEMA = "implementaudit-native-current-facts-v1"
NATIVE_ROUTE_CURRENT_SCHEMA = "implementaudit-native-current-facts-v2"
NATIVE_CURRENT_SCHEMA = "implementaudit-native-current-facts-v3"
NATIVE_ROUTE_SCHEMAS = {NATIVE_ROUTE_CURRENT_SCHEMA, NATIVE_CURRENT_SCHEMA}
SNAPSHOT_INPUT_SCHEMA = "implementaudit-operational-snapshot-input.v1"
SNAPSHOT_PAYLOAD_SCHEMA = "implementaudit-operational-snapshot-payload.v2"
SNAPSHOT_MANIFEST_SCHEMA = "IA-OPERATIONAL-SNAPSHOT-v1"
SNAPSHOT_CURRENT_SCHEMA = "implementaudit.operational-snapshot-current.v1"
SNAPSHOT_PUBLICATION_SCHEMA = "implementaudit-operational-snapshot-publication-v1"
SNAPSHOT_DIFF_SCHEMA = "implementaudit-operational-snapshot-diff.v1"
SNAPSHOT_PROJECTION_SCHEMA = "implementaudit-operational-snapshot-projection.v1"
SNAPSHOT_EXPORT_SCHEMA = "implementaudit-operational-snapshot-export.v1"
SNAPSHOT_ID_RE = re.compile(r"^iasnap-v1-[0-9a-f]{64}$")
SNAPSHOT_EVIDENCE_ID_RE = re.compile(
    r"^iasrc-v1-r0038-snapshot-([0-9a-f]{64})"
    r"(?:-([A-Za-z0-9][A-Za-z0-9._-]{0,30}))?$")
SNAPSHOT_CURRENT_KEYS = frozenset({
    "schema_version", "snapshot_id", "manifest_sha256", "source_pointer_oid"})
QUERY_SCHEMA = "implementaudit.operational-evidence-query.v1"
QUERY_STATUS_SCHEMA = "implementaudit.operational-evidence-status.v1"
QUERY_RESULT_SCHEMA = "implementaudit.operational-evidence-query-result.v1"
QUERY_WHY_SCHEMA = "implementaudit.operational-evidence-why.v1"
HISTORY_QUERY_SCHEMA = "implementaudit.history-query.v1"
HISTORY_REQUEST_SCHEMA = "implementaudit.history-query-request.v1"
HISTORY_CURSOR_SCHEMA = "implementaudit.history-query-cursor.v1"
HISTORY_EVENT_SCHEMA = "implementaudit.history-event.v1"
HISTORY_MANIFEST_SCHEMA = "implementaudit.state-generation-manifest.v1"
HISTORY_EVENT_ID_RE = re.compile(r"^iaevt-v1-[0-9a-f]{64}$")
HISTORY_SEQUENCE_RE = re.compile(r"^[0-9]{20}$")
HISTORY_FILTER_KEYS = frozenset({
    "event_ids", "record_kinds", "subject_ids", "source_evidence_ids",
    "statuses", "transitions"})
SNAPSHOT_MANIFEST_KEYS = frozenset({
    "schema_version", "controller_id", "claim_id", "run_id", "source_epoch",
    "source_pointer_oid", "source_evidence_entries"})
SNAPSHOT_OWNER_ENTRY_KEYS = frozenset({
    "source_evidence_id", "sha256", "kind", "root_identity",
    "host_identity", "input_path_flavor", "source_locator"})
SNAPSHOT_PAYLOAD_KEYS = frozenset({
    "schema_version", "snapshot_id", "aggregate", "families",
    "missing_or_omitted_state", "collections", "input_manifest_sha256"})
NATIVE_SNAPSHOT_PAYLOAD_KEYS = SNAPSHOT_PAYLOAD_KEYS | {"input_manifest", "identity_record"}
SNAPSHOT_SEMANTIC_KEYS = ("schema_version", "aggregate", "families",
                          "missing_or_omitted_state", "collections")
SNAPSHOT_COMPILER_CONTRACT = {
    "schema": "implementaudit-operational-compiler-contract.v2",
    "payload_schema": SNAPSHOT_PAYLOAD_SCHEMA,
    "input_schema": SNAPSHOT_INPUT_SCHEMA,
    "canonicalisation": "canonical_json_v1",
    "semantic_members": list(SNAPSHOT_SEMANTIC_KEYS),
    "collectors": ["evidence_failure", "native_current", "release", "repository"],
    "identity": "IA-OPERATIONAL-SNAPSHOT-v1",
}
FAMILIES = (
    "CODE", "OWNERSHIP", "EXECUTION", "EVIDENCE", "FAILURE", "RELEASE")
STATES = (
    "CURRENT", "UNKNOWN", "UNSUPPORTED", "STALE", "UNVERIFIED",
    "CONTRADICTORY", "PARSER_ERROR", "INVALID")
AGGREGATES = ("COMPLETE", "DEGRADED", "STALE", "INVALID", "SUPERSEDED")
LAYERS = (
    "repository", "git", "planning", "controller", "execution",
    "evidence", "failure", "package", "install", "host", "ci",
    "release", "external", "public")
ENTITY_FAMILIES = {
    "Repository": "CODE", "Commit": "CODE", "Tree": "CODE",
    "Worktree": "CODE", "File": "CODE", "Symbol": "CODE",
    "Package": "CODE", "GeneratedArtifact": "CODE",
    "Writer": "OWNERSHIP", "Resource": "OWNERSHIP",
    "Controller": "EXECUTION", "CustodyClaim": "EXECUTION",
    "Receipt": "EXECUTION", "Run": "EXECUTION", "Phase": "EXECUTION",
    "WorkItem": "EXECUTION", "Claim": "EVIDENCE",
    "Criterion": "EVIDENCE", "Evidence": "EVIDENCE", "Check": "EVIDENCE",
    "Review": "EVIDENCE", "Andon": "FAILURE", "Residual": "FAILURE",
    "Countermeasure": "FAILURE", "Issue": "RELEASE",
    "PullRequest": "RELEASE", "WorkflowRun": "RELEASE",
    "Release": "RELEASE", "Tag": "RELEASE", "Asset": "RELEASE",
    "Install": "RELEASE", "PublicSurface": "RELEASE",
}
RELATION_TYPES = (
    "OWNS", "WRITES", "GENERATES", "PACKAGES", "INSTALLS", "CONSUMES",
    "DEPENDS_ON", "BLOCKS", "READY_WHEN", "SERIALISES_WITH", "JOINS",
    "CLAIMS", "EVIDENCES", "CONTRADICTS", "INVALIDATES", "SUPERSEDES",
    "FAILED_AT", "CONTAINED_BY", "REPAIRED_BY", "VERIFIED_BY",
    "RECOVERED_TO", "QUALIFIES", "MERGES_TO", "TAGS", "PUBLISHES",
    "READ_BACK_AS")
TOP_LEVEL_KEYS = {
    "schema", "aggregate", "families", "affected_families",
    "capability_declarations", "currentness_predicates", "entities",
    "relations", "payload_records"}
COMMON_KEYS = {
    "id", "family", "native_owner_identity", "source_identity",
    "evidence_layer", "currentness"}
HEX = frozenset("0123456789abcdef")
STATIC_OUTCOMES = (
    "CURRENT", "STALE", "UNSUPPORTED", "PARTIAL", "PARSER_ERROR",
    "CONTRADICTORY", "VERSION_MISMATCH", "TARGET_CONFIG_UNTRUSTED",
    "NOT_INSTALLED", "UNSUPPORTED_LANGUAGE", "TOOL_TIMEOUT", "TOOL_CRASH")
STATIC_FACT_KINDS = (
    "MODULE_EDGE", "REVERSE_DEPENDENT", "SOURCE_CYCLE", "NO_EDGE", "LEAF",
    "ORPHAN", "UNUSED", "UNREACHABLE", "UNRESOLVED_IMPORT", "FILE")
STATIC_NEGATIVE_KINDS = frozenset(
    {"NO_EDGE", "LEAF", "ORPHAN", "UNUSED", "UNREACHABLE"})


class OperationalEvidenceError(ValueError):
    """A stable typed refusal for unsupported or invalid evidence input."""

    def __init__(self, code: str, path: str, message: str):
        super().__init__(message)
        self.code = code
        self.path = path
        self.message = message

    def receipt(self) -> dict[str, str]:
        return {
            "schema": "implementaudit-operational-evidence-error-v1",
            "code": self.code,
            "path": self.path,
            "message": self.message,
        }


def _error(code: str, path: str, message: str) -> None:
    raise OperationalEvidenceError(code, path, message)


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            _error("OE_JSON_DUPLICATE_KEY", "$", f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _nonfinite(token):
    _error("OE_JSON_NONFINITE", "$", f"non-finite JSON number: {token}")


def _strict_int(token):
    try:
        return int(token)
    except ValueError:
        _error("OE_JSON_NUMBER_LIMIT", "$",
               "JSON integer exceeds the runtime conversion limit")


def _lossless_float(token):
    try:
        source = decimal.Decimal(token)
        value = float(source)
        round_trip = decimal.Decimal(repr(value)) if math.isfinite(value) else None
    except decimal.DecimalException:
        _error("OE_JSON_NUMBER_LOSS", "$", f"invalid JSON number: {token}")
    if round_trip is None:
        _error("OE_JSON_NONFINITE", "$", f"non-finite JSON number: {token}")
    sign_changed = (source.is_zero() and
                    source.is_signed() != (math.copysign(1.0, value) < 0.0))
    if round_trip != source or sign_changed:
        _error("OE_JSON_NUMBER_LOSS", "$", f"lossy JSON number: {token}")
    return value


def decode_strict_json_bytes(data: bytes, owner: str):
    if data.startswith(b"\xef\xbb\xbf"):
        _error("OE_UTF8_BOM", "$", f"{owner} must not contain a UTF-8 BOM")
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        _error("OE_UTF8_INVALID", "$", f"{owner} must be valid UTF-8")
    try:
        return json.loads(
            text, object_pairs_hook=_unique_object,
            parse_constant=_nonfinite, parse_float=_lossless_float,
            parse_int=_strict_int)
    except OperationalEvidenceError:
        raise
    except (json.JSONDecodeError, RecursionError):
        _error("OE_JSON_MALFORMED", "$", f"{owner} is malformed JSON")


def validate_identity_json_v1(value, path="$"):
    """Keep canonical identity values portable across governed owners."""
    if value is None or type(value) in (bool, str):
        return
    if type(value) is int:
        if not -(2**63) <= value <= 2**63 - 1:
            _error("OE_JSON_MODEL_INVALID", path,
                   "integer is outside signed 64-bit range")
        return
    if type(value) is list:
        for index, item in enumerate(value):
            validate_identity_json_v1(item, f"{path}[{index}]")
        return
    if type(value) is dict:
        for key, item in value.items():
            if type(key) is not str:
                _error("OE_JSON_MODEL_INVALID", path, "object key is not a string")
            validate_identity_json_v1(item, f"{path}.{key}")
        return
    _error("OE_JSON_MODEL_INVALID", path, "floats and non-JSON values are forbidden")


def canonical_json_v1(value) -> bytes:
    """UTF-8 JSON, sorted object keys, declared array order, no whitespace."""
    try:
        validate_identity_json_v1(value)
        return json.dumps(
            value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
            allow_nan=False).encode("utf-8")
    except (TypeError, ValueError, RecursionError):
        _error("OE_JSON_MODEL_INVALID", "$", "value is not strict JSON")


def canonical_payload_text(value: str) -> str:
    """Normalize only line endings, then remove all trailing LF characters."""
    if type(value) is not str:
        _error("OE_SCHEMA_INVALID", "$.payload_records[].payload",
               "payload must be a string")
    return value.replace("\r\n", "\n").replace("\r", "\n").rstrip("\n")


def _object(value, path, *, exact_keys=None, required=()):
    if type(value) is not dict:
        _error("OE_SCHEMA_INVALID", path, "must be an object")
    missing = set(required) - set(value)
    extra = set(value) - set(exact_keys) if exact_keys is not None else set()
    if missing:
        _error("OE_SCHEMA_INVALID", path,
               f"missing keys: {','.join(sorted(missing))}")
    if extra:
        _error("OE_SCHEMA_INVALID", path,
               f"unknown keys: {','.join(sorted(extra))}")
    return value


def _text(value, path):
    if type(value) is not str or not value:
        _error("OE_SCHEMA_INVALID", path, "must be a non-empty string")
    return value


def _string_list_violation_v1(value, *, allowed=None, unique=True):
    """Return the one producer list-grammar violation, if any."""
    if type(value) is not list:
        return None, "must be an array"
    for index, item in enumerate(value):
        if type(item) is not str or not item:
            return index, "must be a non-empty string"
        if allowed is not None and item not in allowed:
            return index, "unsupported value"
    if unique and len(set(value)) != len(value):
        return None, "must not contain duplicates"
    return None, None


def _string_list(value, path, *, allowed=None, unique=True):
    index, violation = _string_list_violation_v1(
        value, allowed=allowed, unique=unique)
    if violation is not None:
        member_path = path if index is None else f"{path}[{index}]"
        _error("OE_SCHEMA_INVALID", member_path, violation)
    return value


def _currentness(value, path):
    _object(value, path, exact_keys={"state", "invalidators"},
            required={"state", "invalidators"})
    state = value["state"]
    if state not in STATES:
        _error("OE_SCHEMA_INVALID", f"{path}.state", "unsupported state")
    invalidators = _string_list(value["invalidators"], f"{path}.invalidators")
    if state == "CURRENT" and invalidators:
        _error("OE_STALE_RECORD", path,
               "CURRENT record cannot retain an invalidator")
    if state == "STALE" and not invalidators:
        _error("OE_STALE_RECORD", path,
               "STALE record must name an invalidator")
    return state


def _common_record(value, path, *, exact_keys, required_extra=()):
    required = COMMON_KEYS | set(required_extra)
    _object(value, path, exact_keys=COMMON_KEYS | set(exact_keys), required=required)
    _text(value["id"], f"{path}.id")
    if value["family"] not in FAMILIES:
        _error("OE_SCHEMA_INVALID", f"{path}.family", "unsupported family")
    _text(value["native_owner_identity"], f"{path}.native_owner_identity")
    source = _object(
        value["source_identity"], f"{path}.source_identity",
        exact_keys={"id", "layer"}, required={"id", "layer"})
    _text(source["id"], f"{path}.source_identity.id")
    if source["layer"] not in LAYERS or value["evidence_layer"] not in LAYERS:
        _error("OE_SCHEMA_INVALID", path, "unsupported evidence layer")
    if source["layer"] != value["evidence_layer"]:
        _error("OE_CROSS_LAYER", path,
               "source layer and evidence layer must identify the same native leg")
    state = _currentness(value["currentness"], f"{path}.currentness")
    return state


def _validate_schema_definition(schema):
    try:
        expected = schema["properties"]["schema"]["const"]
        aggregates = tuple(schema["properties"]["aggregate"]["enum"])
        families = tuple(schema["properties"]["families"]["prefixItems"])
        family_values = tuple(item["const"] for item in families)
        states = tuple(schema["$defs"]["state"]["enum"])
        layers = tuple(schema["$defs"]["layer"]["enum"])
        entity_types = set(schema["$defs"]["entity"]["properties"]
                           ["record_type"]["enum"])
        relation_types = tuple(schema["$defs"]["relation"]["properties"]
                               ["relation_type"]["enum"])
        canonicalisation = schema["x-canonicalisation"]
        payload_normalisation = schema["x-payload-normalisation"]
    except (KeyError, TypeError):
        _error("OE_SCHEMA_DEFINITION_INVALID", "$schema",
               "schema definition is incomplete")
    if (schema.get("x-implementaudit-schema") != SCHEMA_DEFINITION or
            expected != RECORD_SCHEMA or aggregates != AGGREGATES or
            family_values != FAMILIES or states != STATES or layers != LAYERS or
            entity_types != set(ENTITY_FAMILIES) or
            relation_types != RELATION_TYPES or
            canonicalisation != {
                "identity": "canonical_json_v1", "encoding": "UTF-8",
                "bom": False, "object_keys": "recursive_lexicographic",
                "array_order": "declared_semantic_order",
                "insignificant_whitespace": False, "string_rewriting": False,
            } or payload_normalisation != {
                "identity": "canonical_payload_text_v1",
                "line_endings": "CRLF_and_CR_to_LF",
                "trailing_lf": "remove_all",
                "other_whitespace": "preserve", "unicode": "preserve",
            }):
        _error("OE_SCHEMA_DEFINITION_INVALID", "$schema",
               "schema definition does not match the loader contract")


def _digest(value, path):
    if (type(value) is not str or len(value) != 64 or
            any(character not in HEX for character in value)):
        _error("OE_SCHEMA_INVALID", path, "must be 64 lowercase hexadecimal")


def _git_object(value, path):
    if (type(value) is not str or len(value) != 40 or
            any(character not in HEX for character in value)):
        _error("OE_STATIC_RECEIPT_INVALID", path,
               "must be 40 lowercase hexadecimal")


def _boolean(value, path):
    if type(value) is not bool:
        _error("OE_STATIC_RECEIPT_INVALID", path, "must be a boolean")
    return value


def _safe_relative_path(value, path):
    _text(value, path)
    pure = pathlib.PurePosixPath(value)
    if pure.is_absolute() or ".." in pure.parts or value != pure.as_posix():
        _error("OE_REPOSITORY_PATH", path,
               "must be a normalized repository-relative POSIX path")
    return pure


# Explicit repository-reading profile, qualified against the recorded main
# population. These are refusal ceilings, not claims about every repository.
REPOSITORY_MAX_FILES = 4096
REPOSITORY_MAX_FILE_BYTES = 16 * 1024 * 1024
REPOSITORY_MAX_TOTAL_BYTES = 128 * 1024 * 1024
REPOSITORY_MAX_PYTHON_BYTES = 1024 * 1024
SECURE_FILE_MAX_BYTES = 16 * 1024 * 1024
GIT_METADATA_MAX_FILES = 4096
GIT_METADATA_MAX_BYTES = 128 * 1024 * 1024


def _repository_path_policy(relative):
    parts = pathlib.PurePosixPath(relative).parts
    for part in parts:
        folded = part.casefold()
        stem = folded.split(".", 1)[0]
        if ("\\" in part or ":" in part or part[-1:] in {" ", "."} or
                any(ord(char) < 32 or ord(char) == 127 for char in part) or
                unicodedata.normalize("NFC", part) != part or
                stem in {"con", "prn", "aux", "nul", "conin$", "conout$"} or
                re.fullmatch(r"(?:com|lpt)[1-9]", stem)):
            return "nonportable-path"
        if (folded in {".git", ".ssh", ".aws", ".gnupg", ".codex", ".implementaudit",
                       "credentials", "credentials.json", "secrets.json", "secrets.yaml",
                       ".netrc", ".npmrc", ".pypirc", "id_rsa", "id_ed25519"} or
                folded == ".env" or folded.startswith(".env.") or
                folded.endswith((".pem", ".key", ".p12", ".pfx"))):
            return "secret-or-administrative-path"
    return None


def _repository_exclusions(root, paths):
    ignored_raw = _run_git(root, "ls-files", "--cached", "--ignored",
                           "--exclude-standard", "-z", text=False).stdout
    try:
        ignored = set(ignored_raw.decode("utf-8").split("\0"))
    except UnicodeDecodeError:
        _error("OE_REPOSITORY_PATH", "$repository.files", "ignored paths must be UTF-8")
    return {path: reason for path in paths
            if (reason := (_repository_path_policy(path) or
                           ("git-ignored-path" if path in ignored else None)))}


def _git_source_directories(root):
    """Locate physical Git metadata without loading target configuration."""
    root = pathlib.Path(root).absolute()

    def directory(path):
        path = pathlib.Path(os.path.abspath(path))
        info = path.lstat()
        if (not stat.S_ISDIR(info.st_mode) or path.is_symlink() or
                getattr(info, "st_file_attributes", 0) & 0x400 or
                path.resolve(strict=True) != path):
            raise OSError("Git metadata directory aliases another object")
        return path

    entry = root / ".git"
    if entry.is_dir():
        git_dir = directory(entry)
    else:
        raw, kind = _read_repository_path(entry, maximum=8192)
        if kind != "file" or not raw.startswith(b"gitdir: "):
            raise OSError("unsupported Git directory marker")
        value = raw[8:].decode("utf-8").rstrip("\r\n")
        if not value or any(c in value for c in "\r\n\0"):
            raise OSError("invalid Git directory marker")
        git_dir = directory(root / value)
    common_dir = git_dir
    marker = git_dir / "commondir"
    if marker.exists() or marker.is_symlink():
        raw, kind = _read_repository_path(marker, maximum=8192)
        value = raw.decode("utf-8").rstrip("\r\n")
        if kind != "file" or not value or any(c in value for c in "\r\n\0"):
            raise OSError("invalid common Git directory marker")
        common_dir = directory(git_dir / value)
    directory(common_dir / "objects")
    return git_dir, common_dir


@contextlib.contextmanager
def _git_read_view(root):
    """One disposable metadata view, with no target configuration or hooks.

    The actual command reads only a fixed configuration owned by this carrier.
    Mutable target filter definitions cannot enter after a configuration census.
    Objects remain read-only in their existing store; no repository is created,
    selected, committed or updated by this view.
    """
    git_dir, common = _git_source_directories(root)
    with tempfile.TemporaryDirectory(prefix="implementaudit-git-read-") as temporary:
        view = pathlib.Path(temporary)
        (view / "objects").mkdir()
        (view / "refs").mkdir()
        total = 0
        count = 0

        def copy(source, relative):
            nonlocal total, count
            if not source.exists() and not source.is_symlink():
                return
            before = source.lstat()
            raw, kind = _read_repository_path(source, maximum=SECURE_FILE_MAX_BYTES)
            after = source.lstat()
            if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (
                    after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
                raise OSError("Git metadata changed while acquiring the read view")
            count += 1
            total += len(raw)
            if kind != "file" or count > GIT_METADATA_MAX_FILES or total > GIT_METADATA_MAX_BYTES:
                raise OSError("Git metadata type or bound refused")
            target = view / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists() and target.read_bytes() != raw:
                raise OSError("ambiguous Git metadata scope")
            target.write_bytes(raw)
            # Git's racy-index test depends on this timestamp, not only bytes.
            os.utime(target, ns=(after.st_atime_ns, after.st_mtime_ns))

        for source, relative in [(git_dir / "HEAD", "HEAD"),
                (git_dir / "index", "index"), (common / "packed-refs", "packed-refs"),
                (common / "shallow", "shallow"),
                (common / "info/exclude", "info/exclude"),
                (common / "info/attributes", "info/attributes")]:
            copy(source, relative)
        for source in git_dir.glob("sharedindex.*"):
            copy(source, source.name)
        for source_root in dict.fromkeys((common / "refs", git_dir / "refs")):
            if not source_root.exists():
                continue
            for directory, directories, files in os.walk(source_root, followlinks=False):
                parent = pathlib.Path(directory)
                for child in [parent, *(parent / name for name in directories)]:
                    info = child.lstat()
                    if (child.is_symlink() or not stat.S_ISDIR(info.st_mode) or
                            getattr(info, "st_file_attributes", 0) & 0x400):
                        raise OSError("Git reference directory alias refused")
                for name in files:
                    source = parent / name
                    copy(source, pathlib.Path("refs") / source.relative_to(source_root))
        if not (view / "HEAD").is_file():
            raise OSError("Git HEAD is absent")
        (view / "config").write_text(
            "[core]\nrepositoryformatversion = 0\nbare = false\nfilemode = " +
            ("false" if os.name == "nt" else "true") + "\nautocrlf = false\nlongpaths = true\n",
            encoding="ascii")
        yield view, common / "objects"


def _run_git(root: pathlib.Path, *args: str, text: bool = True,
             allowed_returncodes: tuple[int, ...] = (0,)):
    environment = dict(os.environ)
    for name in tuple(environment):
        # Explicit -C is not sufficient: GIT_DIR/INDEX_FILE/WORK_TREE and trace
        # variables can redirect identity or create files outside the reader.
        if name.startswith("GIT_"):
            environment.pop(name)
    environment.update({
        "GIT_CONFIG_COUNT": "0",
        "GIT_CONFIG_GLOBAL": os.devnull,
        "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_CONFIG_SYSTEM": os.devnull,
        "GIT_OPTIONAL_LOCKS": "0",
        "GIT_NO_REPLACE_OBJECTS": "1",
        "GIT_NO_LAZY_FETCH": "1",
        "GIT_TERMINAL_PROMPT": "0",
    })
    for name in (
            "GIT_ASKPASS", "SSH_ASKPASS", "GIT_SSH", "GIT_SSH_COMMAND",
            "GIT_PROXY_COMMAND", "GIT_EXTERNAL_DIFF", "GIT_PAGER", "PAGER",
            "GIT_EDITOR", "GIT_SEQUENCE_EDITOR", "VISUAL", "EDITOR"):
        environment.pop(name, None)
    isolated_configuration = [
        "-c", "core.fsmonitor=false",
        "-c", "core.untrackedCache=false",
        # A child repository can declare filters absent from the parent's
        # configuration census. This collector never descends into gitlinks.
        "-c", "diff.ignoreSubmodules=all",
        "-c", "submodule.recurse=false",
        "-c", f"core.excludesFile={os.devnull}",
        "-c", f"core.hooksPath={os.devnull}",
        "-c", "credential.helper=",
        "-c", "core.sshCommand=",
        "-c", "diff.external=",
        "-c", "protocol.ext.allow=never",
        "-c", "protocol.allow=never",
    ]
    try:
        with _git_read_view(root) as (view, objects):
            environment["GIT_OBJECT_DIRECTORY"] = os.fspath(objects)
            completed = subprocess.run(
                ["git", *isolated_configuration, "--git-dir=" + os.fspath(view),
                 "--work-tree=" + os.fspath(root), "-C", os.fspath(root), *args],
                check=False, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, text=text, env=environment, timeout=30)
            if completed.returncode not in allowed_returncodes:
                completed.check_returncode()
            return completed
    except (OSError, UnicodeError, subprocess.SubprocessError):
        _error("OE_REPOSITORY_GIT", "$repository",
               "repository Git facts could not be read")


def _python_module_map(paths):
    modules = {}
    for path in paths:
        if not path.endswith(".py"):
            continue
        parts = list(pathlib.PurePosixPath(path).with_suffix("").parts)
        if parts and parts[-1] == "__init__":
            parts.pop()
        if parts:
            modules[".".join(parts)] = path
    return modules


def _import_candidates(source_path, node):
    source_parts = list(
        pathlib.PurePosixPath(source_path).with_suffix("").parts)
    if source_parts and source_parts[-1] == "__init__":
        package_parts = source_parts[:-1]
    else:
        package_parts = source_parts[:-1]
    names = []
    if isinstance(node, ast.Import):
        names.extend(alias.name for alias in node.names)
    elif isinstance(node, ast.ImportFrom):
        if node.level:
            trim = node.level - 1
            if trim > len(package_parts):
                return []
            base = package_parts[:len(package_parts) - trim]
            if node.module:
                base.extend(node.module.split("."))
            names.append(".".join(base))
        elif node.module:
            names.append(node.module)
    return sorted(set(names))


def _resolve_import(source_path, node, modules):
    return sorted({
        modules[name]
        for name in _import_candidates(source_path, node)
        if name in modules
    })


def _file_language(path):
    suffix = pathlib.PurePosixPath(path).suffix.lower()
    return {
        ".py": "python", ".sh": "shell", ".js": "javascript",
        ".jsx": "javascript", ".ts": "typescript", ".tsx": "typescript",
        ".json": "json",
    }.get(suffix, "unsupported")


class _WindowsUnicodeStringV1(ctypes.Structure):
    _fields_ = [("length", ctypes.c_uint16), ("maximum", ctypes.c_uint16),
                ("buffer", ctypes.c_void_p)]


class _WindowsObjectAttributesV1(ctypes.Structure):
    _fields_ = [("length", ctypes.c_uint32), ("root", ctypes.c_void_p),
                ("name", ctypes.POINTER(_WindowsUnicodeStringV1)),
                ("attributes", ctypes.c_uint32), ("security", ctypes.c_void_p),
                ("quality", ctypes.c_void_p)]


class _WindowsIoStatusV1(ctypes.Structure):
    _fields_ = [("status_or_pointer", ctypes.c_void_p),
                ("information", ctypes.c_size_t)]


def _windows_open_child_v1(parent, name, directory, *, create_security=None,
                           hold_directory=False):
    """Open one component relative to its held parent, never reparse a pathname."""
    native = ctypes.WinDLL("ntdll")
    native.NtCreateFile.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.c_uint32,
        ctypes.POINTER(_WindowsObjectAttributesV1), ctypes.POINTER(_WindowsIoStatusV1),
        ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32,
        ctypes.c_uint32, ctypes.c_void_p, ctypes.c_uint32]
    native.NtCreateFile.restype = ctypes.c_long
    native.RtlNtStatusToDosError.argtypes = [ctypes.c_long]
    native.RtlNtStatusToDosError.restype = ctypes.c_uint32
    buffer = ctypes.create_unicode_buffer(name)
    length = len(name.encode("utf-16-le"))
    if length > 65532:
        raise OSError("Windows name exceeds the native byte bound")
    text = _WindowsUnicodeStringV1(length, length + 2,
                                   ctypes.cast(buffer, ctypes.c_void_p))
    attributes = _WindowsObjectAttributesV1(
        ctypes.sizeof(_WindowsObjectAttributesV1), parent, ctypes.pointer(text),
        0x40 | 0x1000, create_security, None)  # CASE_INSENSITIVE | DONT_REPARSE
    result = ctypes.c_void_p()
    status = _WindowsIoStatusV1()
    access = 0x00100080 | (0 if directory else 1)
    if hold_directory:
        access = 0x80100000
    if create_security is not None:
        if directory:
            raise OSError("private export stage must be a file")
        access = 0xC0130000  # read/write, DELETE, READ_CONTROL, SYNCHRONIZE
    code = native.NtCreateFile(
        ctypes.byref(result), access,
        ctypes.byref(attributes), ctypes.byref(status), None,
        0x100 if create_security is not None else 0, 1,
        2 if create_security is not None else 1,  # CREATE_NEW or OPEN
        0x20 | 0x00200000 | (1 if directory else 0x40), None, 0)
    if code < 0:
        raise ctypes.WinError(native.RtlNtStatusToDosError(code))
    return result.value


def _windows_handle_name_v1(kernel, handle):
    """Return a bounded normalized DOS name from the already-open object."""
    size = kernel.GetFinalPathNameByHandleW(handle, None, 0, 0)
    if size == 0 or size > 32768:
        raise OSError("Windows canonical handle name is unavailable or unbounded")
    buffer = ctypes.create_unicode_buffer(size)
    length = kernel.GetFinalPathNameByHandleW(handle, buffer, size, 0)
    if length == 0 or length >= size:
        raise OSError("Windows canonical handle name changed or is unavailable")
    value = buffer.value
    if not value.startswith("\\\\?\\") or not re.match(r"[A-Za-z]:\\", value[4:]):
        raise OSError("Windows handle has an unsupported canonical namespace")
    return pathlib.PureWindowsPath(value[4:])


def _windows_repository_parts_v1(path, kernel):
    if len(path.drive) != 2 or path.drive[1] != ":":
        raise OSError("secure Windows reader requires a local drive path")
    parts = path.parts[1:]
    if not parts or any(
            part in {".", ".."} or ":" in part or part.rstrip(" .") != part or
            pathlib.PureWindowsPath(part).is_reserved() for part in parts):
        raise OSError("Windows device, stream or alias spelling refused")
    if kernel.GetDriveTypeW(path.anchor) != 3:
        raise OSError("secure Windows reader requires a fixed local drive")
    return parts


def _windows_read_held_leaf_v1(kernel, handle, before, parents, maximum):
    """Read fresh leaf bytes; no file bytes or leaf handles are retained."""
    chunks = []
    total = 0
    expected = (before.size_high << 32) | before.size_low
    limit = min(maximum, expected)
    # The observed size is already mandatory at the closing identity check.
    # One extra byte detects growth; filling the entire policy ceiling cannot
    # make a larger file admissible. Keep this buffer private to this one leaf.
    capacity = min(1024 * 1024, max(1, limit + 1))
    buffer = ctypes.create_string_buffer(capacity)
    while total <= limit:
        size = min(capacity, limit + 1 - total)
        count = ctypes.c_uint32()
        if not kernel.ReadFile(handle, buffer, size, ctypes.byref(count), None):
            raise ctypes.WinError(ctypes.get_last_error())
        if not count.value:
            break
        chunks.append(buffer.raw[:count.value])
        total += count.value
    after = _snapshot_handle_info_v1(kernel, handle)

    def identity(value):
        return (value.attributes, value.volume_serial, value.file_index_high,
                value.file_index_low, value.links, value.size_high,
                value.size_low, value.creation_time.high,
                value.creation_time.low, value.write_time.high,
                value.write_time.low)

    if (total > maximum or total != expected or
            identity(before) != identity(after)):
        raise OSError("tracked file changed or exceeded the byte ceiling")
    if any(_snapshot_handle_info_v1(kernel, parent).attributes & 0x400
           for parent in parents):
        raise OSError("Windows parent became a reparse point during acquisition")
    return b"".join(chunks), "file"


def _read_repository_windows_v1(path, maximum):
    """Read a local drive path while holding every component against replacement.

    Windows reparse points and alternate namespaces are refused, including leaf
    links. Each child is acquired relative to its held parent with reparse
    processing disabled. Sharing rules alone do not exclude metadata changes.
    """
    kernel = _snapshot_windows_kernel_v1()
    parts = _windows_repository_parts_v1(path, kernel)
    handles = []
    try:
        requested = pathlib.PureWindowsPath(path.anchor)
        for index, part in enumerate((None, *parts)):
            if part is None:
                handle = kernel.CreateFileW(
                    path.anchor, 0x80000000, 1, None, 3, 0x02200000, None)
                if handle == ctypes.c_void_p(-1).value:
                    raise ctypes.WinError(ctypes.get_last_error())
            else:
                handle = _windows_open_child_v1(handles[-1], part, index < len(parts))
                requested /= part
            handles.append(handle)
            info = _snapshot_handle_info_v1(kernel, handle)
            if info.attributes & 0x400:
                raise OSError("Windows reparse point refused")
            if str(_windows_handle_name_v1(kernel, handle)).casefold() != str(requested).casefold():
                raise OSError("Windows spelling aliases a different canonical long name")
            if index < len(parts):
                if not info.attributes & 0x10:
                    raise OSError("Windows parent is not a directory")
            elif (info.attributes & 0x10 or info.links != 1 or
                  ((info.size_high << 32) | info.size_low) > maximum):
                raise OSError("tracked file type or byte ceiling refused")
        return _windows_read_held_leaf_v1(kernel, handle, info, handles[:-1], maximum)
    finally:
        for handle in reversed(handles):
            kernel.CloseHandle(handle)


@contextlib.contextmanager
def _repository_read_scope_v1(root):
    """Hold a bounded private directory set for one physical repository scan.

    Every reuse checks current metadata. Canonical names may be retained only
    through ancestry opened with read/list access and no delete sharing; denied
    stronger access falls back to attribute handles and per-use name checks.
    Leaves are freshly opened parent-relative with DONT_REPARSE and closed after
    each read. No handle escapes the scope or enters a process-global cache.
    """
    root = pathlib.Path(root).resolve()
    if os.name != "nt":
        yield lambda path, maximum=None: _read_repository_path(path, root=root, maximum=maximum)
        return
    kernel = _snapshot_windows_kernel_v1()
    directories = {}
    active = True

    def close_directories():
        pending = tuple(handle for handle, pinned in directories.values())
        directories.clear()
        failure = None
        for handle in reversed(pending):
            try:
                if not kernel.CloseHandle(handle):
                    failure = OSError("Windows repository directory handle did not close")
            except OSError as exc:
                failure = exc
        if failure is not None:
            raise failure

    def read(path, maximum=None):
        if not active:
            raise OSError("repository read scope is closed")
        path = pathlib.Path(path).absolute()
        if not path.relative_to(root).parts:
            raise OSError("repository input has no file leaf")
        maximum = REPOSITORY_MAX_FILE_BYTES if maximum is None else min(maximum, SECURE_FILE_MAX_BYTES)
        parts = _windows_repository_parts_v1(path, kernel)
        # Exact spellings are cache keys. A short name or a differently spelled
        # component must pass its own canonical long-name acquisition check.
        keys = [tuple(path.parts[:index]) for index in range(1, len(path.parts))]
        if len(directories) + sum(key not in directories for key in keys) > 128:
            close_directories()
        if len(keys) > 128:
            # Keep the established deep-path behavior without growing the cache.
            return _read_repository_windows_v1(path, maximum)
        parents = []
        leaf = None
        try:
            for index, key in enumerate(keys):
                retained = directories.get(key)
                acquired = retained is None
                if acquired:
                    if index == 0:
                        handle = kernel.CreateFileW(
                            path.anchor, 0x80000000, 1, None, 3, 0x02200000, None)
                        if handle == ctypes.c_void_p(-1).value:
                            raise ctypes.WinError(ctypes.get_last_error())
                        pinned = True
                    else:
                        try:
                            handle = _windows_open_child_v1(
                                parents[-1], key[-1], True, hold_directory=True)
                            pinned = directories[key[:-1]][1]
                        except OSError:
                            # READ_ATTRIBUTES alone does not pin a pathname.
                            # Preserve the established access/fresh-name path
                            # when stronger read/list custody is unavailable.
                            handle = _windows_open_child_v1(parents[-1], key[-1], True)
                            pinned = False
                else:
                    handle, pinned = retained
                try:
                    info = _snapshot_handle_info_v1(kernel, handle)
                    if info.attributes & 0x400 or not info.attributes & 0x10:
                        raise OSError("Windows repository parent is not a physical directory")
                    if acquired or not pinned:
                        requested = pathlib.PureWindowsPath(*key)
                        if str(_windows_handle_name_v1(kernel, handle)).casefold() != str(requested).casefold():
                            raise OSError("Windows spelling aliases a different canonical long name")
                except BaseException:
                    if acquired:
                        kernel.CloseHandle(handle)
                    raise
                if acquired:
                    # Failed/aliased acquisitions must never become reusable.
                    directories[key] = (handle, pinned)
                parents.append(handle)
            leaf = _windows_open_child_v1(parents[-1], parts[-1], False)
            info = _snapshot_handle_info_v1(kernel, leaf)
            if (info.attributes & (0x10 | 0x400) or info.links != 1 or
                    ((info.size_high << 32) | info.size_low) > maximum):
                raise OSError("tracked file type or byte ceiling refused")
            if str(_windows_handle_name_v1(kernel, leaf)).casefold() != str(path).casefold():
                raise OSError("Windows spelling aliases a different canonical long name")
            return _windows_read_held_leaf_v1(kernel, leaf, info, parents, maximum)
        finally:
            if leaf is not None and not kernel.CloseHandle(leaf):
                raise OSError("Windows repository leaf handle did not close")

    try:
        yield read
    finally:
        active = False
        close_directories()


def _read_repository_path(path, root=None, maximum=None):
    """Read bounded bytes through non-following directory and file handles.

    Unsupported handle semantics refuse. A pathname re-stat alone cannot prevent
    a parent-junction/symlink race; do not substitute it on another platform.
    """
    path = pathlib.Path(path).absolute()
    root = pathlib.Path(root).absolute() if root is not None else pathlib.Path(path.anchor)
    relative = path.relative_to(root)
    if not relative.parts:
        raise OSError("repository input has no file leaf")
    maximum = REPOSITORY_MAX_FILE_BYTES if maximum is None else min(maximum, SECURE_FILE_MAX_BYTES)
    if os.name == "nt":
        return _read_repository_windows_v1(path, maximum)
    if (os.name != "posix" or os.open not in os.supports_dir_fd or
            not hasattr(os, "O_NOFOLLOW") or not hasattr(os, "O_DIRECTORY")):
        raise OSError("secure repository file handles unsupported on this platform")
    descriptors = []
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
    try:
        parent = os.open(root, flags | os.O_DIRECTORY)
        descriptors.append(parent)
        for part in relative.parts[:-1]:
            parent = os.open(part, flags | os.O_DIRECTORY, dir_fd=parent)
            descriptors.append(parent)
        leaf = relative.parts[-1]
        before = os.stat(leaf, dir_fd=parent, follow_symlinks=False)
        if stat.S_ISLNK(before.st_mode):
            raw = os.readlink(leaf, dir_fd=parent).encode("utf-8")
            after = os.stat(leaf, dir_fd=parent, follow_symlinks=False)
            if (before.st_dev, before.st_ino, before.st_mtime_ns) != (
                    after.st_dev, after.st_ino, after.st_mtime_ns):
                raise OSError("symlink changed while reading its inert target")
            return raw, "symlink"
        if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_size > maximum):
            raise OSError("tracked file type or byte ceiling refused")
        descriptor = os.open(leaf, flags, dir_fd=parent)
        descriptors.append(descriptor)
        opened = os.fstat(descriptor)
        if opened.st_nlink != 1 or (before.st_dev, before.st_ino) != (opened.st_dev, opened.st_ino):
            raise OSError("tracked file identity changed while opening")
        with os.fdopen(os.dup(descriptor), "rb") as stream:
            raw = stream.read(maximum + 1)
        after = os.fstat(descriptor)
        if (len(raw) > maximum or
                (opened.st_size, opened.st_mtime_ns, opened.st_ctime_ns) !=
                (after.st_size, after.st_mtime_ns, after.st_ctime_ns)):
            raise OSError("tracked file changed or exceeded the byte ceiling")
        return raw, "file"
    finally:
        for descriptor in reversed(descriptors):
            os.close(descriptor)


def _physical_file_row(relative, data=None, file_type=None):
    if data is None:
        return {"path": relative, "readable": False}
    return {
        "path": relative,
        "readable": True,
        "file_type": file_type,
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
    }


def _require_repository_snapshot_stable(
        root, paths, commit, tree, raw_paths, status, physical_file_rows, excluded=None,
        read_repository=None):
    if excluded is None:
        excluded = {}
    if _repository_exclusions(root, paths) != excluded:
        _error("OE_REPOSITORY_CHANGED_DURING_SCAN", "$repository",
               "repository input policy changed during collection")
    observed_file_rows = []
    for index, relative in enumerate(paths):
        pure = _safe_relative_path(relative, f"$repository.files[{index}]")
        path = root.joinpath(*pure.parts)
        if relative in excluded:
            observed_file_rows.append(_physical_file_row(relative))
            continue
        try:
            data, file_type = (read_repository(path) if read_repository is not None
                               else _read_repository_path(path, root=root))
            observed_file_rows.append(
                _physical_file_row(relative, data, file_type))
        except (OSError, UnicodeError):
            observed_file_rows.append(_physical_file_row(relative))
    observed_commit = _run_git(
        root, "rev-parse", "--verify", "HEAD").stdout.strip()
    observed_tree = _run_git(
        root, "rev-parse", "--verify", "HEAD^{tree}").stdout.strip()
    observed_raw_paths = _run_git(root, "ls-files", "-z", text=False).stdout
    observed_status = _run_git(
        root, "status", "--porcelain=v1", "--untracked-files=all").stdout
    if (observed_commit != commit or observed_tree != tree or
            observed_raw_paths != raw_paths or observed_status != status or
            observed_file_rows != physical_file_rows):
        _error("OE_REPOSITORY_CHANGED_DURING_SCAN", "$repository",
               "repository physical snapshot changed during collection")


def _native_file(path, label, maximum=256 * 1024):
    try:
        before = path.lstat()
        if (not stat.S_ISREG(before.st_mode) or path.is_symlink() or
                bool(getattr(before, "st_file_attributes", 0) & 0x400) or
                before.st_size > maximum):
            raise OSError("unsafe native-current file")
        raw = _read_repository_path(path, maximum=maximum)[0]
        after = path.lstat()
    except OSError:
        _error("OE_NATIVE_CURRENT_FILE", label,
               "required bounded native-current file is unreadable or unsafe")
    identity = (
        before.st_dev, before.st_ino, before.st_mode, before.st_size,
        before.st_mtime_ns)
    observed = (
        after.st_dev, after.st_ino, after.st_mode, after.st_size,
        after.st_mtime_ns)
    if identity != observed or len(raw) != before.st_size:
        _error("OE_NATIVE_CURRENT_CHANGED", label,
               "native-current file changed during observation")
    return raw


def _native_blob(repo, oid, label, maximum=512 * 1024):
    if type(oid) is not str or not re.fullmatch(r"[0-9a-f]{40}", oid):
        _error("OE_NATIVE_CURRENT_GIT", label, "Git object identity is malformed")
    try:
        object_type = _run_git(repo, "cat-file", "-t", oid).stdout.strip()
        size_text = _run_git(repo, "cat-file", "-s", oid).stdout.strip()
    except OperationalEvidenceError:
        _error("OE_NATIVE_CURRENT_GIT", label,
               "required native-current Git object is missing or unreadable")
    try:
        size = int(size_text)
    except ValueError:
        _error("OE_NATIVE_CURRENT_GIT", label, "Git object size is malformed")
    if object_type != "blob" or not 0 <= size <= maximum:
        _error("OE_NATIVE_CURRENT_GIT", label,
               "required native-current Git blob is absent or outside its bound")
    try:
        raw = _run_git(repo, "cat-file", "blob", oid, text=False).stdout
    except OperationalEvidenceError:
        _error("OE_NATIVE_CURRENT_GIT", label,
               "required native-current Git blob is missing or unreadable")
    if len(raw) != size:
        _error("OE_NATIVE_CURRENT_CHANGED", label,
               "native-current Git blob changed during observation")
    return raw


def _native_ref_oid(repo, ref, label):
    try:
        oid = _run_git(repo, "rev-parse", "--verify", ref).stdout.strip()
    except OperationalEvidenceError:
        _error("OE_NATIVE_CURRENT_GIT", label,
               "required native-current ref is missing or unreadable")
    if not re.fullmatch(r"[0-9a-f]{40}", oid):
        _error("OE_NATIVE_CURRENT_GIT", label, "native-current ref is malformed")
    return oid


def _native_refs_match_v1(repo, expected):
    """Fresh exact-ref fence in one Git read; never a cached currentness token."""
    output = _run_git(repo, "for-each-ref", "--format=%(refname)%09%(objectname)",
                      *sorted(expected)).stdout
    actual = {}
    for row in output.splitlines():
        ref, separator, oid = row.partition("\t")
        if not separator or not re.fullmatch(r"[0-9a-f]{40}", oid):
            return False
        # for-each-ref patterns may include descendants; the old individual
        # verify reads also made no claim about those unselected refs.
        if ref in expected:
            if ref in actual:
                return False
            actual[ref] = oid
    return actual == expected


def _native_exact_tsv(raw, schema, count, label):
    if (not raw.endswith(b"\n") or b"\n" in raw[:-1] or b"\r" in raw or
            b"\x00" in raw or any(
                byte < 0x20 and byte not in (0x09, 0x0A) or byte == 0x7f
                for byte in raw)):
        _error("OE_NATIVE_CURRENT_BYTES", label,
               "native-current record does not have exact LF-delimited TSV bytes")
    try:
        fields = raw[:-1].decode("utf-8", "strict").split("\t")
    except UnicodeDecodeError:
        _error("OE_NATIVE_CURRENT_BYTES", label,
               "native-current record is not exact UTF-8")
    if len(fields) != count or fields[0] != schema or any(field == "" for field in fields):
        _error("OE_NATIVE_CURRENT_BYTES", label,
               "native-current record schema or field population is malformed")
    return fields


def _native_exact_no_lf_tsv(raw, schema, count, label):
    if (not raw or b"\n" in raw or b"\r" in raw or b"\x00" in raw or any(
            byte < 0x20 and byte != 0x09 or byte == 0x7f for byte in raw)):
        _error("OE_NATIVE_CURRENT_BYTES", label,
               "native-current record does not have exact no-LF TSV bytes")
    try:
        fields = raw.decode("utf-8", "strict").split("\t")
    except UnicodeDecodeError:
        _error("OE_NATIVE_CURRENT_BYTES", label,
               "native-current record is not exact UTF-8")
    if len(fields) != count or fields[0] != schema or any(field == "" for field in fields):
        _error("OE_NATIVE_CURRENT_BYTES", label,
               "native-current record schema or field population is malformed")
    return fields


def _native_resolved_path(value, label):
    if type(value) is not str or not value or "\x00" in value:
        _error("OE_NATIVE_CURRENT_PATH", label, "native path is malformed")
    try:
        supplied = pathlib.Path(value)
        resolved = supplied.resolve(strict=True)
    except OSError:
        _error("OE_NATIVE_CURRENT_PATH", label, "native path cannot be resolved")
    if supplied.absolute() != resolved:
        _error("OE_NATIVE_CURRENT_PATH", label,
               "native path traverses an alias or is not canonical")
    return resolved


def _native_claim(run_root, repository, common, controller, claim, run_id):
    claimed_raw = _native_file(run_root / ".claimed", "$native.claim", 16 * 1024)
    if (not claimed_raw.endswith(b"\n") or b"\r" in claimed_raw or
            b"\n" in claimed_raw[:-1].replace(b"\n", b"", 9)):
        _error("OE_NATIVE_CURRENT_CLAIM", "$native.claim",
               "run claim does not have exact bounded LF records")
    try:
        lines = claimed_raw[:-1].decode("utf-8", "strict").split("\n")
    except UnicodeDecodeError:
        _error("OE_NATIVE_CURRENT_CLAIM", "$native.claim",
               "run claim is not exact UTF-8")
    keys = (
        "schema", "claim_id", "claimed_at_utc", "mode", "templates",
        "repo_root", "git_common_dir", "run_base", "run_root", "run_name")
    if len(lines) != len(keys):
        _error("OE_NATIVE_CURRENT_CLAIM", "$native.claim",
               "run claim field population is malformed")
    values = {}
    for key, line in zip(keys, lines):
        prefix = f"{key}="
        if not line.startswith(prefix) or line == prefix:
            _error("OE_NATIVE_CURRENT_CLAIM", "$native.claim",
                   "run claim field ordering is malformed")
        values[key] = line[len(prefix):]
    relative = pathlib.PurePosixPath(".IMPLEMENTAUDIT", "runs", run_id).as_posix()
    if (values["schema"] != "implementaudit.run-claim.v2" or
            values["claim_id"] != claim or values["run_base"] != ".IMPLEMENTAUDIT/runs" or
            values["run_root"] != relative or values["run_name"] != run_id or
            _native_resolved_path(values["repo_root"], "$native.claim.repo_root") != repository or
            _native_resolved_path(values["git_common_dir"], "$native.claim.git_common_dir") != common):
        _error("OE_NATIVE_CURRENT_CLAIM", "$native.claim",
               "run claim disagrees with native controller custody")
    controller_raw = _native_file(
        run_root / ".controller", "$native.controller_sentinel", 1024)
    if controller_raw != f"controller_id={controller}\n".encode("utf-8"):
        _error("OE_NATIVE_CURRENT_CLAIM", "$native.controller_sentinel",
               "controller sentinel disagrees with controller custody")
    return claimed_raw, controller_raw, relative


def _native_markdown_cells(line, expected, label):
    stripped = line.strip()
    if not stripped.startswith("|") or not stripped.endswith("|"):
        _error("OE_NATIVE_CURRENT_STATE", label, "Markdown table row is malformed")
    cells = [cell.strip() for cell in stripped[1:-1].split("|")]
    if len(cells) != expected or any(cell == "" for cell in cells):
        _error("OE_NATIVE_CURRENT_STATE", label, "Markdown table row is malformed")
    return cells


def _native_state_facts(raw):
    if raw.startswith(b"\xef\xbb\xbf"):
        _error("OE_NATIVE_CURRENT_STATE", "$native.STATE",
               "hot STATE must not contain a UTF-8 BOM")
    try:
        lines = raw.decode("utf-8", "strict").splitlines()
    except UnicodeDecodeError:
        _error("OE_NATIVE_CURRENT_STATE", "$native.STATE",
               "hot STATE is not exact UTF-8")
    epochs = [line[len("Current epoch: "):].strip() for line in lines
              if line.startswith("Current epoch: ")]
    if len(epochs) != 1 or not re.fullmatch(r"G[0-9A-F]{4}", epochs[0]):
        _error("OE_NATIVE_CURRENT_STATE", "$native.STATE.current_epoch",
               "hot STATE has no unique canonical current epoch")
    headings = [index for index, line in enumerate(lines) if line == "## Current phase"]
    if len(headings) != 1:
        _error("OE_NATIVE_CURRENT_STATE", "$native.STATE.current_phase",
               "hot STATE has no unique current-phase section")
    start = headings[0] + 1
    end = next((index for index in range(start, len(lines))
                if lines[index].startswith("## ")), len(lines))
    phase_rows = {}
    for index in range(start, end):
        if not lines[index].lstrip().startswith("|"):
            continue
        cells = _native_markdown_cells(
            lines[index], 2, f"$native.STATE.current_phase[{index + 1}]")
        if cells in (["Field", "Value"], ["---", "---"]):
            continue
        if cells[0] in phase_rows:
            _error("OE_NATIVE_CURRENT_STATE", "$native.STATE.current_phase",
                   "hot STATE current-phase field is duplicated")
        phase_rows[cells[0]] = cells[1]
    next_action = phase_rows.get("Next action", "").strip()
    andon_state = phase_rows.get("Andon state", "").strip()
    if not next_action or next_action in {"-", "none", "pending"}:
        _error("OE_NATIVE_CURRENT_MISSING", "$native.STATE.next_action",
               "hot STATE has no exact next action")
    open_andons = sorted(set(re.findall(
        r"(?<![A-Za-z0-9_-])([A-Z][A-Z0-9_-]*)=ACTIVE(?![A-Za-z0-9_-])",
        andon_state)))
    if not open_andons:
        _error("OE_NATIVE_CURRENT_MISSING", "$native.STATE.open_andons",
               "hot STATE has no explicit open Andon")

    instruction_header = [
        "Instr", "Reference", "Kind", "Authority", "Subject", "Issued epoch",
        "Status", "Status evidence", "Supersedes/by", "Scope end"]
    header_rows = []
    for index, line in enumerate(lines):
        if not line.lstrip().startswith("|"):
            continue
        try:
            cells = _native_markdown_cells(
                line, 10, f"$native.STATE.instructions[{index + 1}]")
        except OperationalEvidenceError:
            continue
        if cells == instruction_header:
            header_rows.append(index)
    if len(header_rows) != 1:
        _error("OE_NATIVE_CURRENT_STATE", "$native.STATE.instructions",
               "hot STATE has no unique instruction table")
    mapping = [
        "id", "reference", "kind", "authority", "subject", "issued_epoch",
        "status", "status_evidence", "supersedes_by", "scope_end"]
    active = []
    seen = set()
    index = header_rows[0] + 2
    while index < len(lines) and lines[index].lstrip().startswith("|"):
        cells = _native_markdown_cells(
            lines[index], 10, f"$native.STATE.instructions[{index + 1}]")
        if cells[0] in seen:
            _error("OE_NATIVE_CURRENT_STATE", "$native.STATE.instructions",
                   "instruction identity is duplicated")
        seen.add(cells[0])
        row = dict(zip(mapping, cells))
        if row["status"] == "active":
            active.append(row)
        index += 1
    if not active:
        _error("OE_NATIVE_CURRENT_MISSING", "$native.STATE.active_instructions",
               "hot STATE has no active instruction")
    return {
        "epoch": epochs[0], "next_action": next_action,
        "andon_state": andon_state, "open_andons": open_andons,
        "active_instructions": sorted(active, key=lambda row: row["id"]),
    }


def _native_pointer(raw, controller, claim, run_id):
    value = decode_strict_json_bytes(raw, "current-generation pointer")
    validate_identity_json_v1(value)
    keys = {
        "schema_version", "controller_id", "claim_id", "run_id",
        "generation_id", "predecessor_pointer_oid",
        "predecessor_pointer_digest", "generation_manifest_oid",
        "generation_manifest_digest", "cold_high_water", "hot_state_digest",
        "hot_roadmap_digest", "work_graph_path", "work_graph_digest",
        "query_contract_version", "source_epoch", "degraded_state",
        "pointer_digest"}
    _object(value, "$native.pointer", exact_keys=keys, required=keys)
    if canonical_json_v1(value) != raw:
        _error("OE_NATIVE_CURRENT_BYTES", "$native.pointer",
               "current-generation pointer bytes are not canonical_json_v1")
    patterns = {
        "claim_id": r"[0-9a-f]{32}", "run_id": r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}",
        "generation_id": r"G[0-9A-F]{4}", "source_epoch": r"G[0-9A-F]{4}",
        "generation_manifest_oid": r"[0-9a-f]{40}",
        "generation_manifest_digest": r"[0-9a-f]{64}",
        "cold_high_water": r"[0-9]{20}", "hot_state_digest": r"[0-9a-f]{64}",
        "hot_roadmap_digest": r"[0-9a-f]{64}",
        "work_graph_digest": r"[0-9a-f]{64}", "pointer_digest": r"[0-9a-f]{64}",
    }
    if any(type(value[name]) is not str or not re.fullmatch(pattern, value[name])
           for name, pattern in patterns.items()):
        _error("OE_NATIVE_CURRENT_POINTER", "$native.pointer",
               "current-generation pointer identity is malformed")
    predecessor = (
        value["predecessor_pointer_oid"], value["predecessor_pointer_digest"])
    if (predecessor[0] is None) != (predecessor[1] is None):
        _error("OE_NATIVE_CURRENT_POINTER", "$native.pointer",
               "pointer predecessor identity is incomplete")
    if predecessor[0] is not None and (
            type(predecessor[0]) is not str or
            not re.fullmatch(r"[0-9a-f]{40}", predecessor[0]) or
            type(predecessor[1]) is not str or
            not re.fullmatch(r"[0-9a-f]{64}", predecessor[1])):
        _error("OE_NATIVE_CURRENT_POINTER", "$native.pointer",
               "pointer predecessor identity is malformed")
    if (value["schema_version"] != "implementaudit.state-generation-pointer.v1" or
            value["controller_id"] != controller or value["claim_id"] != claim or
            value["run_id"] != run_id or
            value["generation_id"] != value["source_epoch"] or
            value["query_contract_version"] != "implementaudit.history-query.v1" or
            value["work_graph_path"] != "WORK_GRAPH.json" or
            value["degraded_state"] not in {"NONE", "ACTIVEGRAPH_DOGFOOD_DEGRADED"}):
        _error("OE_NATIVE_CURRENT_POINTER", "$native.pointer",
               "pointer disagrees with native controller/claim/run/epoch custody")
    unsigned = dict(value)
    supplied = unsigned.pop("pointer_digest")
    observed = hashlib.sha256(canonical_json_v1(unsigned)).hexdigest()
    if supplied != observed:
        _error("OE_NATIVE_CURRENT_POINTER", "$native.pointer.pointer_digest",
               "pointer digest is stale")
    return value


def _native_module_from_bytes(raw, path, name, label):
    module = types.ModuleType(name)
    module.__file__ = os.fspath(path)
    module.__package__ = ""
    try:
        exec(compile(raw, os.fspath(path), "exec"), module.__dict__)
    except Exception as exc:
        _error("OE_NATIVE_CURRENT_SOURCE", label,
               f"canonical read-only source cannot be loaded: {exc}")
    return module


def _native_graph_projection(raw):
    compiler_path = pathlib.Path(__file__).resolve().parents[1] / "skills/implementaudit/scripts/compile-work-graph.py"
    compiler_raw = _native_file(
        compiler_path, "$native.work_graph_compiler", 256 * 1024)
    module = _native_module_from_bytes(
        compiler_raw, compiler_path,
        "_implementaudit_native_work_graph_compiler",
        "$native.work_graph_compiler")
    try:
        projection = module.compile_frontier_projection(raw)
    except Exception as exc:
        _error("OE_NATIVE_CURRENT_GRAPH", "$native.WORK_GRAPH",
               f"canonical HC-H4 compiler rejected WORK_GRAPH: {exc}")
    if _native_file(
            compiler_path, "$native.work_graph_compiler", 256 * 1024) != compiler_raw:
        _error("OE_NATIVE_CURRENT_CHANGED", "$native.work_graph_compiler",
               "HC-H4 compiler changed during byte-bound execution")
    required_frontier = {
        "population", "counts", "active", "ready", "blocked_summary",
        "writer_holds", "resource_holds", "digest"}
    if type(projection) is not dict or not required_frontier <= set(projection):
        _error("OE_NATIVE_CURRENT_MISSING", "$native.WORK_GRAPH.frontier",
               "WORK_GRAPH frontier facts are missing")
    population = projection["population"]
    counts = projection["counts"]
    if (type(population) is not int or population < 0 or
            type(counts) is not dict or set(counts) != {
                "DONE", "ACTIVE", "READY", "BLOCKED"} or
            any(type(count) is not int or count < 0
                for count in counts.values()) or
            type(projection["digest"]) is not str or
            not re.fullmatch(r"[0-9a-f]{64}", projection["digest"])):
        _error("OE_NATIVE_CURRENT_MISSING", "$native.WORK_GRAPH.frontier",
               "WORK_GRAPH frontier population is malformed")
    active = projection["active"]
    ready = projection["ready"]
    blocked_summary = projection["blocked_summary"]
    writer_holds = projection["writer_holds"]
    resource_holds = projection["resource_holds"]
    if (type(active) is not list or type(ready) is not list or
            type(blocked_summary) is not dict or type(writer_holds) is not dict or
            type(resource_holds) is not dict):
        _error("OE_NATIVE_CURRENT_MISSING", "$native.WORK_GRAPH.frontier",
               "WORK_GRAPH frontier collection types are malformed")
    def valid_members(members):
        return (type(members) is list and
                all(type(member) is str and member for member in members) and
                members == sorted(set(members)))

    if not valid_members(active) or not valid_members(ready):
        _error("OE_NATIVE_CURRENT_MISSING", "$native.WORK_GRAPH.frontier",
               "WORK_GRAPH frontier identities are malformed")
    for mapping in (blocked_summary, writer_holds, resource_holds):
        for identity, members in mapping.items():
            if type(identity) is not str or not identity or not valid_members(members):
                _error("OE_NATIVE_CURRENT_MISSING", "$native.WORK_GRAPH.frontier",
                       "WORK_GRAPH frontier hold maps are malformed")
    if (sum(counts.values()) != population or
            len(active) != counts["ACTIVE"] or
            len(ready) != counts["READY"] or
            len(blocked_summary) != counts["BLOCKED"]):
        _error("OE_NATIVE_CURRENT_MISSING", "$native.WORK_GRAPH.frontier",
               "WORK_GRAPH frontier census is inconsistent")
    return (projection, hashlib.sha256(compiler_raw).hexdigest(),
            compiler_path, compiler_raw)


def _native_predecessor(
        repo, controller, controller_oid, claim, run_id, generation, token):
    if type(token) is not str or token.count("@") != 1:
        _error("OE_NATIVE_CURRENT_RECEIPT", "$native.receipt.predecessor",
               "receipt predecessor token is malformed")
    ref, oid = token.split("@")
    ordinal = int(generation[1:], 16)
    if ordinal <= 1:
        _error("OE_NATIVE_CURRENT_RECEIPT", "$native.receipt.predecessor",
               "receipt-v3 has no admissible predecessor generation")
    expected_generation = f"G{ordinal - 1:04X}"
    expected_ref = f"refs/implementaudit/continuity-receipts/{controller}/{expected_generation}"
    if ref != expected_ref or _native_ref_oid(
            repo, ref, "$native.receipt.predecessor_ref") != oid:
        _error("OE_NATIVE_CURRENT_RECEIPT", "$native.receipt.predecessor",
               "receipt predecessor is stale or foreign")
    raw = _native_blob(repo, oid, "$native.receipt.predecessor")
    if raw.startswith(b"implementaudit.continuity-receipt.v2\t"):
        fields = _native_exact_tsv(
            raw, "implementaudit.continuity-receipt.v2", 12,
            "$native.receipt.predecessor")
        if (fields[1:4] != [controller, controller_oid, claim] or
                not re.fullmatch(r"[0-9a-f]{40}", fields[4]) or
                not re.fullmatch(r"[0-9a-f]{40}", fields[5]) or
                not re.fullmatch(r"[0-9a-f]{64}", fields[6]) or
                not re.fullmatch(r"[0-9a-f]{64}", fields[7]) or
                not (fields[8] == "none" or
                     re.fullmatch(r"[0-9a-f]{40}", fields[8])) or
                fields[9] not in {
                    "host-reported-compaction", "new-session",
                    "handoff-resume", "manual-resume",
                    "inferred-context-gap"} or
                fields[10] != expected_generation or not fields[11]):
            _error("OE_NATIVE_CURRENT_RECEIPT", "$native.receipt.predecessor",
                   "v2 predecessor is malformed or foreign to current custody")
    elif raw.startswith(b"implementaudit.continuity-receipt.v3\t"):
        fields = _native_exact_tsv(
            raw, "implementaudit.continuity-receipt.v3", 18,
            "$native.receipt.predecessor")
        if (fields[1] != controller or fields[2] != claim or fields[3] != run_id or
                fields[4] != expected_generation or
                not re.fullmatch(r"[0-9a-f]{40}", fields[5]) or
                fields[6] != f"refs/implementaudit/current-generations/{controller}" or
                not re.fullmatch(r"[0-9a-f]{40}", fields[7]) or
                not re.fullmatch(r"[0-9a-f]{64}", fields[8]) or
                not re.fullmatch(r"[0-9a-f]{64}", fields[9]) or
                not re.fullmatch(r"[0-9a-f]{64}", fields[10]) or
                fields[11] != "WORK_GRAPH.json" or
                not re.fullmatch(r"[0-9a-f]{64}", fields[12]) or
                not re.fullmatch(r"[0-9a-f]{40}", fields[13]) or
                not re.fullmatch(r"[0-9a-f]{64}", fields[14]) or
                not re.fullmatch(r"[0-9]{20}", fields[15]) or not fields[16]):
            _error("OE_NATIVE_CURRENT_RECEIPT", "$native.receipt.predecessor",
                   "v3 predecessor is malformed or foreign to current custody")
        predecessor_ordinal = int(expected_generation[1:], 16)
        if predecessor_ordinal <= 1 or fields[17].count("@") != 1:
            _error("OE_NATIVE_CURRENT_RECEIPT", "$native.receipt.predecessor",
                   "v3 predecessor own-predecessor token is malformed")
        own_ref, own_oid = fields[17].split("@")
        own_epoch = f"G{predecessor_ordinal - 1:04X}"
        if (own_ref !=
                f"refs/implementaudit/continuity-receipts/{controller}/{own_epoch}" or
                not re.fullmatch(r"[0-9a-f]{40}", own_oid)):
            _error("OE_NATIVE_CURRENT_RECEIPT", "$native.receipt.predecessor",
                   "v3 predecessor own-predecessor token is not structurally immediate")
    else:
        _error("OE_NATIVE_CURRENT_RECEIPT", "$native.receipt.predecessor",
               "receipt predecessor schema is unsupported")
    return ref, oid, raw


def _native_route_module():
    path = pathlib.Path(__file__).resolve().parents[1] / "skills/implementaudit/scripts/route-transaction.py"
    raw = _native_file(path, "$native.route_validator", 512 * 1024)
    module = _native_module_from_bytes(
        raw, path, "_implementaudit_native_route_transaction",
        "$native.route_validator")
    required = (
        "validate_pure_current_route", "trusted_host_executable",
        "sanitized_action_environment", "bash_script_path")
    if any(not callable(getattr(module, name, None)) for name in required):
        _error("OE_NATIVE_CURRENT_SOURCE", "$native.route_validator",
               "canonical R0033 read-only predicates are incomplete")
    return module, path, raw


def _native_child_environment(route_module):
    with contextlib.redirect_stdout(io.StringIO()):
        source = route_module.sanitized_action_environment()
    inherited = {
        "comspec", "pathext", "systemdrive", "systemroot", "temp", "tmp",
        "tmpdir", "windir",
    }
    fixed = {
        "GIT_ATTR_NOSYSTEM", "GIT_CONFIG_GLOBAL", "GIT_CONFIG_NOSYSTEM",
        "GIT_EXTERNAL_DIFF", "GIT_OPTIONAL_LOCKS", "GIT_PAGER", "LC_ALL",
        "PAGER", "PATH",
    }
    environment = {
        key: value for key, value in source.items()
        if key in fixed or key.casefold() in inherited
    }
    if "PATH" not in environment:
        _error("OE_NATIVE_CURRENT_SOURCE", "$native.child_environment",
               "private R0011 child PATH is unavailable")
    environment["PYTHONNOUSERSITE"] = "1"
    environment["PYTHONSAFEPATH"] = "1"
    return environment


def _native_private_residue(closure):
    try:
        members = sorted(closure.iterdir(), key=lambda item: os.fspath(item))
    except OSError:
        members = []
    return sorted([os.fspath(closure), *(os.fspath(path) for path in members)])


def _native_cleanup_private_closure(closure, expected):
    try:
        for path, raw in expected:
            if _native_file(path, "$native.private_continuity_closure") != raw:
                raise OSError("private R0011 closure member changed before cleanup")
            os.unlink(path)
        os.rmdir(closure)
    except (OSError, OperationalEvidenceError):
        residue = _native_private_residue(closure)
        _error(
            "OE_NATIVE_CURRENT_CLEANUP",
            "$native.private_continuity_closure",
            "private R0011 closure cleanup refused; residue=" +
            json.dumps(residue, sort_keys=True, separators=(",", ":")) +
            "; manual reconciliation required",
        )


_NATIVE_R0011_CHILD_BOOTSTRAP = r'''set -u
claim_path="$1"
validate_path="$2"
expected_claim="$3"
expected_validate="$4"
shift 4
claim_payload="$(base64 < "$claim_path")" || exit 90
validate_payload="$(base64 < "$validate_path")" || exit 91
claim_text="$(printf '%s' "$claim_payload" | base64 -d; printf 'X')" || exit 92
validate_text="$(printf '%s' "$validate_payload" | base64 -d; printf 'X')" || exit 93
claim_text="${claim_text%X}"
validate_text="${validate_text%X}"
observed_claim="$(printf '%s' "$claim_text" | sha256sum | cut -d' ' -f1)" || exit 94
observed_validate="$(printf '%s' "$validate_text" | sha256sum | cut -d' ' -f1)" || exit 95
[ "$observed_claim" = "$expected_claim" ] || exit 96
[ "$observed_validate" = "$expected_validate" ] || exit 97
bash() {
  if [ "$#" -ge 1 ] && [ "${1##*/}" = "validate-run-root.sh" ]; then
    shift
    ( set -- "$@"; eval "$validate_text" )
  else
    command bash "$@"
  fi
}
( set -- "$@"; eval "$claim_text" )
status=$?
printf 'implementaudit-native-r0011-child-v1\t%s\t%s\n' \
  "$observed_claim" "$observed_validate" >&2
exit "$status"
'''



def _native_r0011_stdin_payload_v1(claim_raw, validate_raw):
    """Carry exact bounded owner bytes as data; hash them before evaluation."""
    for raw in (claim_raw, validate_raw):
        if type(raw) is not bytes or not 0 < len(raw) <= 256 * 1024 or b"\0" in raw:
            raise ValueError("bounded non-NUL continuity source bytes required")
    def literal(raw):
        return b"'" + raw.replace(b"'", b"'\\''") + b"'"
    tail = _NATIVE_R0011_CHILD_BOOTSTRAP[
        _NATIVE_R0011_CHILD_BOOTSTRAP.index("observed_claim="):]
    # The hash is still calculated over the actual loaded bytes. Parsing its
    # fixed stdin-filename output needs no separate cut subprocess.
    tail = tail.replace(" | sha256sum | cut -d' ' -f1)", " | sha256sum)")
    tail = tail.replace('[ "$observed_claim" = "$expected_claim" ]',
        'observed_claim="${observed_claim%% *}"\n'
        'observed_validate="${observed_validate%% *}"\n'
        '[ "$observed_claim" = "$expected_claim" ]', 1)
    return (b"set -u\nclaim_text=" + literal(claim_raw) + b"\nvalidate_text=" +
            literal(validate_raw) +
            b'\nexpected_claim="$1"\nexpected_validate="$2"\nshift 2\n' + tail.encode("ascii"))


def _native_r0011_stdin_script_v1(claim_raw, validate_raw, arguments):
    """Known readonly CLI domain only; other owners retain the file transport."""
    pair = (hashlib.sha256(claim_raw).hexdigest(),
            hashlib.sha256(validate_raw).hexdigest())
    original = ("07e09843b2831149dc43e5f0dc458e82ae5cf9614b116393ac774ddea19390c7",
                "fe005aea40d8eb2ea860c62f0caf1fb78ba678381ab6444e4f7b8202e82b77e5")
    combined = ("9665ba20e02c02882f3172549e90d78e790c6c0133cd31749a30e1d29c3cc0ce",
                "fe005aea40d8eb2ea860c62f0caf1fb78ba678381ab6444e4f7b8202e82b77e5")
    if pair not in (original, combined):
        return None
    readonly = (arguments == ["--current-controller"] or
        (pair == combined and arguments == ["--observe-current-continuity"]) or
        (type(arguments) is list and len(arguments) == 2 and
         arguments[0] in {"--require-current-continuity", "--verify-resume-receipt"}))
    return _native_r0011_stdin_payload_v1(claim_raw, validate_raw) if readonly else None



def _native_continuity_source_files_v1():
    claim_path = pathlib.Path(__file__).resolve().parents[1] / "skills/implementaudit/scripts/claim-run.sh"
    validate_path = claim_path.with_name("validate-run-root.sh")
    claim_raw = _native_file(claim_path, "$native.continuity_validator", 256 * 1024)
    validate_raw = _native_file(
        validate_path, "$native.continuity_claim_validator", 256 * 1024)
    return claim_path, claim_raw, validate_path, validate_raw


_NATIVE_CONTINUITY_SIX_SOURCE_PROFILE_V1 = (
    ("claim-run.sh", 17368, "50e2417a05007b34f38417fb891c8e6f806c7df25d008659939f2dc08b2a0383", 0o644),
    ("validate-run-root.sh", 61001, "d8b046b5417dce13ed66a5ac5fffaf3d18fae40c97d42aef8b38470500d575a6", 0o644),
    ("claim-run-rotation.py", 103754, "6f62f57d3a5873570161022e2ccc04cdb061655fa338bcb2c5ea1624b80454ca", 0o644),
    ("rotate-canonical-state.py", 92941, "7989a08128fedabe531fc92114baff755e77e08aebea547253793b625496bb26", 0o755),
    ("canonical_hot_projection.py", 57891, "fe733b91dff4f031ed3ab80761d669de59c0270cd7f85325a14a2d47f9ba5276", 0o755),
    ("canonical_custody.py", 33629, "bfa07f0088f2df7b8c1196ccd149ebf8c6874337b35ac9a9c91ac51367a7fb1f", 0o755),
)
# Receiving-owner allowlist: complete independently acquired fixed profiles.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 = (
    (
        ('claim-run.sh', 17368, '50e2417a05007b34f38417fb891c8e6f806c7df25d008659939f2dc08b2a0383', 0o644),
        ('validate-run-root.sh', 61001, 'd8b046b5417dce13ed66a5ac5fffaf3d18fae40c97d42aef8b38470500d575a6', 0o644),
        ('claim-run-rotation.py', 103754, '6f62f57d3a5873570161022e2ccc04cdb061655fa338bcb2c5ea1624b80454ca', 0o644),
        ('rotate-canonical-state.py', 92941, '7989a08128fedabe531fc92114baff755e77e08aebea547253793b625496bb26', 0o755),
        ('canonical_hot_projection.py', 57891, 'fe733b91dff4f031ed3ab80761d669de59c0270cd7f85325a14a2d47f9ba5276', 0o755),
        ('canonical_custody.py', 33629, 'bfa07f0088f2df7b8c1196ccd149ebf8c6874337b35ac9a9c91ac51367a7fb1f', 0o755),
    ),
    (
        ('claim-run.sh', 17368, '50e2417a05007b34f38417fb891c8e6f806c7df25d008659939f2dc08b2a0383', 0o644),
        ('validate-run-root.sh', 96597, '77f324a5d87f49dbd870e9fdc23d2e4d252d2bdb4244d523408245fbd6dbbbb3', 0o644),
        ('claim-run-rotation.py', 103754, '6f62f57d3a5873570161022e2ccc04cdb061655fa338bcb2c5ea1624b80454ca', 0o644),
        ('rotate-canonical-state.py', 92941, '7989a08128fedabe531fc92114baff755e77e08aebea547253793b625496bb26', 0o755),
        ('canonical_hot_projection.py', 57891, 'fe733b91dff4f031ed3ab80761d669de59c0270cd7f85325a14a2d47f9ba5276', 0o755),
        ('canonical_custody.py', 33629, 'bfa07f0088f2df7b8c1196ccd149ebf8c6874337b35ac9a9c91ac51367a7fb1f', 0o755),
    ),
    (
        ('claim-run.sh', 17368, '50e2417a05007b34f38417fb891c8e6f806c7df25d008659939f2dc08b2a0383', 0o644),
        ('validate-run-root.sh', 61001, 'd8b046b5417dce13ed66a5ac5fffaf3d18fae40c97d42aef8b38470500d575a6', 0o644),
        ('claim-run-rotation.py', 104704, 'f6e6d93c9ca103c21ce4f316ec7688f2e3750749d074e22f0ed16d3f612fa795', 0o644),
        ('rotate-canonical-state.py', 92941, '7989a08128fedabe531fc92114baff755e77e08aebea547253793b625496bb26', 0o755),
        ('canonical_hot_projection.py', 57891, 'fe733b91dff4f031ed3ab80761d669de59c0270cd7f85325a14a2d47f9ba5276', 0o755),
        ('canonical_custody.py', 33629, 'bfa07f0088f2df7b8c1196ccd149ebf8c6874337b35ac9a9c91ac51367a7fb1f', 0o755),
    ),
    (
        ('claim-run.sh', 17368, '50e2417a05007b34f38417fb891c8e6f806c7df25d008659939f2dc08b2a0383', 0o644),
        ('validate-run-root.sh', 96597, '77f324a5d87f49dbd870e9fdc23d2e4d252d2bdb4244d523408245fbd6dbbbb3', 0o644),
        ('claim-run-rotation.py', 104704, 'f6e6d93c9ca103c21ce4f316ec7688f2e3750749d074e22f0ed16d3f612fa795', 0o644),
        ('rotate-canonical-state.py', 92941, '7989a08128fedabe531fc92114baff755e77e08aebea547253793b625496bb26', 0o755),
        ('canonical_hot_projection.py', 57891, 'fe733b91dff4f031ed3ab80761d669de59c0270cd7f85325a14a2d47f9ba5276', 0o755),
        ('canonical_custody.py', 33629, 'bfa07f0088f2df7b8c1196ccd149ebf8c6874337b35ac9a9c91ac51367a7fb1f', 0o755),
    ),
    (
        ('claim-run.sh', 17632, '78c6391743132b5265d415bf73435cb0ee11f3e32d09d8b280018e949745e5ac', 0o644),
        ('validate-run-root.sh', 61188, '73bce773c2fa43aa1f42584121824b8179356ca6bf6348c6e10492e2f128313d', 0o644),
        ('claim-run-rotation.py', 213510, 'f2cb06e57e1b46dd7e679019acc780b7ffbfeaf21516cf53e5e0fb14eae90660', 0o644),
        ('rotate-canonical-state.py', 125155, 'c505832360e0e245aca51d1c14ee8c9d9c330d0300684a77aa6c5bd8803bad74', 0o755),
        ('canonical_hot_projection.py', 58417, 'b3fd58cef5bf79cbd8f109b352a9b80c230127bf35db0dbac2ef41a7490d967f', 0o755),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 0o755),
        ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', 0o644),
    ),
    (
        ('claim-run.sh', 17632, '78c6391743132b5265d415bf73435cb0ee11f3e32d09d8b280018e949745e5ac', 0o644),
        ('validate-run-root.sh', 96784, '23afb71f4e6660301912d97142ad087391e0308d828fecce8e45b5e2aae8b295', 0o644),
        ('claim-run-rotation.py', 213510, 'f2cb06e57e1b46dd7e679019acc780b7ffbfeaf21516cf53e5e0fb14eae90660', 0o644),
        ('rotate-canonical-state.py', 125155, 'c505832360e0e245aca51d1c14ee8c9d9c330d0300684a77aa6c5bd8803bad74', 0o755),
        ('canonical_hot_projection.py', 58417, 'b3fd58cef5bf79cbd8f109b352a9b80c230127bf35db0dbac2ef41a7490d967f', 0o755),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 0o755),
        ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', 0o644),
    ),
    (
        ('claim-run.sh', 17632, '78c6391743132b5265d415bf73435cb0ee11f3e32d09d8b280018e949745e5ac', 0o644),
        ('validate-run-root.sh', 61188, '73bce773c2fa43aa1f42584121824b8179356ca6bf6348c6e10492e2f128313d', 0o644),
        ('claim-run-rotation.py', 245953, '36da48d5e81218ff020c5fdb85fe0797e19a61459b4c167f137109e279e7f7aa', 0o644),
        ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', 0o755),
        ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 0o755),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 0o755),
        ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', 0o644),
    ),
    (
        ('claim-run.sh', 17632, '78c6391743132b5265d415bf73435cb0ee11f3e32d09d8b280018e949745e5ac', 0o644),
        ('validate-run-root.sh', 96784, '23afb71f4e6660301912d97142ad087391e0308d828fecce8e45b5e2aae8b295', 0o644),
        ('claim-run-rotation.py', 245953, '36da48d5e81218ff020c5fdb85fe0797e19a61459b4c167f137109e279e7f7aa', 0o644),
        ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', 0o755),
        ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 0o755),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 0o755),
        ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', 0o644),
    ),
    (
        ('claim-run.sh', 99730, '405ab3853dfb88c007ea2f8f8dd98fb8e9c6e77552b172f2f71a8751364ea20f', None),
        ('validate-run-root.sh', 61188, '73bce773c2fa43aa1f42584121824b8179356ca6bf6348c6e10492e2f128313d', None),
        ('claim-run-rotation.py', 213510, 'f2cb06e57e1b46dd7e679019acc780b7ffbfeaf21516cf53e5e0fb14eae90660', None),
        ('rotate-canonical-state.py', 125155, 'c505832360e0e245aca51d1c14ee8c9d9c330d0300684a77aa6c5bd8803bad74', None),
        ('canonical_hot_projection.py', 58417, 'b3fd58cef5bf79cbd8f109b352a9b80c230127bf35db0dbac2ef41a7490d967f', None),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', None),
        ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', None),
        ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', None),
    ),
    (
        ('claim-run.sh', 99730, '405ab3853dfb88c007ea2f8f8dd98fb8e9c6e77552b172f2f71a8751364ea20f', None),
        ('validate-run-root.sh', 61188, '73bce773c2fa43aa1f42584121824b8179356ca6bf6348c6e10492e2f128313d', None),
        ('claim-run-rotation.py', 245953, '36da48d5e81218ff020c5fdb85fe0797e19a61459b4c167f137109e279e7f7aa', None),
        ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', None),
        ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', None),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', None),
        ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', None),
        ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', None),
    ),
    (
        ('claim-run.sh', 99730, '405ab3853dfb88c007ea2f8f8dd98fb8e9c6e77552b172f2f71a8751364ea20f', None),
        ('validate-run-root.sh', 96784, '23afb71f4e6660301912d97142ad087391e0308d828fecce8e45b5e2aae8b295', None),
        ('claim-run-rotation.py', 213510, 'f2cb06e57e1b46dd7e679019acc780b7ffbfeaf21516cf53e5e0fb14eae90660', None),
        ('rotate-canonical-state.py', 125155, 'c505832360e0e245aca51d1c14ee8c9d9c330d0300684a77aa6c5bd8803bad74', None),
        ('canonical_hot_projection.py', 58417, 'b3fd58cef5bf79cbd8f109b352a9b80c230127bf35db0dbac2ef41a7490d967f', None),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', None),
        ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', None),
        ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', None),
    ),
    (
        ('claim-run.sh', 99730, '405ab3853dfb88c007ea2f8f8dd98fb8e9c6e77552b172f2f71a8751364ea20f', None),
        ('validate-run-root.sh', 96784, '23afb71f4e6660301912d97142ad087391e0308d828fecce8e45b5e2aae8b295', None),
        ('claim-run-rotation.py', 245953, '36da48d5e81218ff020c5fdb85fe0797e19a61459b4c167f137109e279e7f7aa', None),
        ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', None),
        ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', None),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', None),
        ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', None),
        ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', None),
    ),
    # Same independently acquired eight-member receiving domain; no admission.
    (
        ('claim-run.sh', 99730, '405ab3853dfb88c007ea2f8f8dd98fb8e9c6e77552b172f2f71a8751364ea20f', None),
        ('validate-run-root.sh', 61188, '73bce773c2fa43aa1f42584121824b8179356ca6bf6348c6e10492e2f128313d', None),
        ('claim-run-rotation.py', 246657, '4dbbd07b5a792289c13c1225a8099900682b3657396f60f4b74867502cbadf97', None),
        ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', None),
        ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', None),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', None),
        ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', None),
        ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', None),
    ),
    # Same exact eight-member captured-companion domain; no native admission.
    (
        ('claim-run.sh', 104155, 'bd0c6d2ab1ec8f695fe34e459b25d9344e11c5930d3f62d0919b29d9bc4a44ee', None),
        ('validate-run-root.sh', 61188, '73bce773c2fa43aa1f42584121824b8179356ca6bf6348c6e10492e2f128313d', None),
        ('claim-run-rotation.py', 246657, '4dbbd07b5a792289c13c1225a8099900682b3657396f60f4b74867502cbadf97', None),
        ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', None),
        ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', None),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', None),
        ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', None),
        ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', None),
    ),
    (
        ('claim-run.sh', 21636, '35232762fdd76d000bcca774a0f6f53f3d26dfb9229d9795d397b81d7ef8483e', 0o644),
        ('validate-run-root.sh', 61001, 'd8b046b5417dce13ed66a5ac5fffaf3d18fae40c97d42aef8b38470500d575a6', 0o644),
        ('claim-run-rotation.py', 103754, '6f62f57d3a5873570161022e2ccc04cdb061655fa338bcb2c5ea1624b80454ca', 0o644),
        ('rotate-canonical-state.py', 92941, '7989a08128fedabe531fc92114baff755e77e08aebea547253793b625496bb26', 0o755),
        ('canonical_hot_projection.py', 57891, 'fe733b91dff4f031ed3ab80761d669de59c0270cd7f85325a14a2d47f9ba5276', 0o755),
        ('canonical_custody.py', 33629, 'bfa07f0088f2df7b8c1196ccd149ebf8c6874337b35ac9a9c91ac51367a7fb1f', 0o755),
    ),
)
# Exact current peer-shell/core-module closure; Windows gate and admission remain separate.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += (
    (('claim-run.sh', 104155, 'bd0c6d2ab1ec8f695fe34e459b25d9344e11c5930d3f62d0919b29d9bc4a44ee', None), ('validate-run-root.sh', 113863, '66c0f6d3df8c0f1702864055f3fcc4ee3cf5403982de81fba71389cdc5860283', None), ('claim-run-rotation.py', 246657, '4dbbd07b5a792289c13c1225a8099900682b3657396f60f4b74867502cbadf97', None), ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', None), ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', None), ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', None), ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', None), ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', None)),
    # Current-core POSIX closure; no receipt-schema or native-currentness substitution.
    (
        ('claim-run.sh', 22057, '7402bc1b77db0009746b10e8a97b19e680d2ad24b5eb91c5c9b4918409d4f7f6', 420),
        ('validate-run-root.sh', 113863, '66c0f6d3df8c0f1702864055f3fcc4ee3cf5403982de81fba71389cdc5860283', 420),
        ('claim-run-rotation.py', 246657, '4dbbd07b5a792289c13c1225a8099900682b3657396f60f4b74867502cbadf97', 420),
        ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', 493),
        ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
        ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', 420),
        ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
    ),
)
# Current core successor; retained native and historical tuples remain separate.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((
    ('claim-run.sh', 22199, '34054952e3bbf13ae6ca381d4cf0d9d72bccaed10c8dd879de9351f5c0e2594b', 420),
    ('validate-run-root.sh', 113863, '66c0f6d3df8c0f1702864055f3fcc4ee3cf5403982de81fba71389cdc5860283', 420),
    ('claim-run-rotation.py', 258400, '27ae194fc92a37bd12e0fe378ffc07f788a3bffec28ebd1c0a5e3c8e1c73695e', 420),
    ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', 493),
    ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
    ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
    ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', 420),
    ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
),)
# DG07 current core; source selection supplies no native authority.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((
    ('claim-run.sh', 22199, '7d257a9b3502a78d458f80bd0c20fe4594b049a93c819aa3bc91de577bfa34af', 420),
    ('validate-run-root.sh', 113863, '66c0f6d3df8c0f1702864055f3fcc4ee3cf5403982de81fba71389cdc5860283', 420),
    ('claim-run-rotation.py', 259408, '551b1a798161fdd20cb9eebd56fb1d8a0245ec48a74f05b29f6253d8228c49cb', 420),
    ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', 493),
    ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
    ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
    ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', 420),
    ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
),)
# DG07 current core; source selection supplies no native authority.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((
    ('claim-run.sh', 30189, '23b828f298c3f21b86d9f7a2228d74ffb34d67d7b7bedc34ceca2ad754d2cbe7', 420),
    ('validate-run-root.sh', 113863, '66c0f6d3df8c0f1702864055f3fcc4ee3cf5403982de81fba71389cdc5860283', 420),
    ('claim-run-rotation.py', 259408, '551b1a798161fdd20cb9eebd56fb1d8a0245ec48a74f05b29f6253d8228c49cb', 420),
    ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', 493),
    ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
    ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
    ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', 420),
    ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
),)
# CAS phase owner; prior source profiles remain unchanged.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((
    ('claim-run.sh', 31259, 'a3ecb4d56f8b12fcfc7237906f6547bd2205b1c04cf1c843d2782c86c67ee798', 420),
    ('validate-run-root.sh', 113863, '66c0f6d3df8c0f1702864055f3fcc4ee3cf5403982de81fba71389cdc5860283', 420),
    ('claim-run-rotation.py', 259408, '551b1a798161fdd20cb9eebd56fb1d8a0245ec48a74f05b29f6253d8228c49cb', 420),
    ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', 493),
    ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
    ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
    ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', 420),
    ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
),)
# Current preparation-template source tuples; no native admission.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((
    ('claim-run.sh', 31259, 'cee4c3225be8df9c62fcc8adb4c1af18a38bd1237adac39b0ce5d5a1bce47765', 420),
    ('validate-run-root.sh', 113863, '66c0f6d3df8c0f1702864055f3fcc4ee3cf5403982de81fba71389cdc5860283', 420),
    ('claim-run-rotation.py', 259408, '8edf14f8aea58573c1eb8a3a2bd6a42394aa8ea419217606994c81b1ba162ca9', 420),
    ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', 493),
    ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
    ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
    ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', 420),
    ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
), (
    ('claim-run.sh', 104155, '322f17d86170e34788833a619586e8cb9fcc066a70933342ad3f28f036446d0d', None),
    ('validate-run-root.sh', 113863, '66c0f6d3df8c0f1702864055f3fcc4ee3cf5403982de81fba71389cdc5860283', None),
    ('claim-run-rotation.py', 246657, '31e30b564e83db80c11c18b3bf83eab9d901bf089af7dd7ebd2e7d823f5105f8', None),
    ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', None),
    ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', None),
    ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', None),
    ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', None),
    ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', None),
),)
# Exact DG08 source-only tuples; historical receipt scopes remain unchanged.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += (
    (
        ('claim-run.sh', 31259, 'e1b686be7aba7da12163810e1c99c0033bad2ec949bdc5436fb177ba2491a790', 420),
        ('validate-run-root.sh', 113863, '66c0f6d3df8c0f1702864055f3fcc4ee3cf5403982de81fba71389cdc5860283', 420),
        ('claim-run-rotation.py', 259408, '348c492cafdb3ed7d41f360ff8c219316257bdd18c4e4f22646aa7e66cb84d9e', 420),
        ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', 493),
        ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
        ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', 420),
        ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
    ),
    (
        ('claim-run.sh', 104155, 'd7db3595bfdd6b79e822375df5744597111148315cce6c980dc063792774dc36', None),
        ('validate-run-root.sh', 113863, '66c0f6d3df8c0f1702864055f3fcc4ee3cf5403982de81fba71389cdc5860283', None),
        ('claim-run-rotation.py', 246657, '4a4dc5a997f3d485c7c43be31cb45818907e1685c8506fbabcb8bcee0872aed6', None),
        ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', None),
        ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', None),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', None),
        ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', None),
        ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', None),
    ),
)
# Exact DG08 source-only tuples; historical receipt scopes remain unchanged.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += (
    (
        ('claim-run.sh', 31259, '0d1829770e3ce8da613cb48646391fc65641636ac4cd42a97149b3e8f57750b9', 420),
        ('validate-run-root.sh', 113863, '66c0f6d3df8c0f1702864055f3fcc4ee3cf5403982de81fba71389cdc5860283', 420),
        ('claim-run-rotation.py', 259408, 'c91e7c3aa243919c4cdb398f999f28734f1a630511a99f6b1aa9dc477b2fae3c', 420),
        ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', 493),
        ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
        ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', 420),
        ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
    ),
    (
        ('claim-run.sh', 104155, '5cca165879cb272a8cb494fcdc12ac461ec53c4d9c95fcb13882ea44397be529', None),
        ('validate-run-root.sh', 113863, '66c0f6d3df8c0f1702864055f3fcc4ee3cf5403982de81fba71389cdc5860283', None),
        ('claim-run-rotation.py', 246657, '908cce5054dc23a9e74b6af695204fc6d9889681611311c7136f087fe0be1663', None),
        ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', None),
        ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', None),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', None),
        ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', None),
        ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', None),
    ),
)
# Current closure-parser source tuples; no native acceptance is inherited.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += (
    (
        ('claim-run.sh', 31259, '0d1829770e3ce8da613cb48646391fc65641636ac4cd42a97149b3e8f57750b9', 420),
        ('validate-run-root.sh', 114294, 'e7a20d7d5eab497338327814367fe8c7221a35cfe61bdfaadd91d84101f0d250', 420),
        ('claim-run-rotation.py', 259408, 'c91e7c3aa243919c4cdb398f999f28734f1a630511a99f6b1aa9dc477b2fae3c', 420),
        ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', 493),
        ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
        ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', 420),
        ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
    ),
    (
        ('claim-run.sh', 104155, '5cca165879cb272a8cb494fcdc12ac461ec53c4d9c95fcb13882ea44397be529', None),
        ('validate-run-root.sh', 114294, 'e7a20d7d5eab497338327814367fe8c7221a35cfe61bdfaadd91d84101f0d250', None),
        ('claim-run-rotation.py', 246657, '908cce5054dc23a9e74b6af695204fc6d9889681611311c7136f087fe0be1663', None),
        ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', None),
        ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', None),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', None),
        ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', None),
        ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', None),
    ),
)
# Current terminal-inventory owner binding; historical subjects remain unchanged.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((('claim-run.sh', 31259, '7cfd59d8569ad04221cd4779a803dfc451d5e47b2d4674ad657090564c6c174d', 420), ('validate-run-root.sh', 114294, 'e7a20d7d5eab497338327814367fe8c7221a35cfe61bdfaadd91d84101f0d250', 420), ('claim-run-rotation.py', 259408, '1c70c0612bad4b2311bb89ddad60484937b5d195bf98380c3ef3e0d30d6cd94b', 420), ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', 493), ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493), ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493), ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', 420), ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493)), (('claim-run.sh', 104155, '10baf97b4c773d8ac386627a455bb480e8353ccfdb909fc5253d3ac4c65ecd0f', None), ('validate-run-root.sh', 114294, 'e7a20d7d5eab497338327814367fe8c7221a35cfe61bdfaadd91d84101f0d250', None), ('claim-run-rotation.py', 246657, 'bc862f87428e86c608ddc5fe31ad8a3e2c8324b52c09ba379163db160ad70e93', None), ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', None), ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', None), ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', None), ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', None), ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', None)))
# DG10 current Windows transport binding; all historical subjects retained.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((('claim-run.sh', 31259, '7cfd59d8569ad04221cd4779a803dfc451d5e47b2d4674ad657090564c6c174d', 420), ('validate-run-root.sh', 114674, 'c24e2d9a171f8ab7dd0fdc78d8035a18044d5373e2f8e9bfd7f7de2e9b03b978', 420), ('claim-run-rotation.py', 259408, '1c70c0612bad4b2311bb89ddad60484937b5d195bf98380c3ef3e0d30d6cd94b', 420), ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', 493), ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493), ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493), ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', 420), ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493)), (('claim-run.sh', 104155, '10baf97b4c773d8ac386627a455bb480e8353ccfdb909fc5253d3ac4c65ecd0f', None), ('validate-run-root.sh', 114674, 'c24e2d9a171f8ab7dd0fdc78d8035a18044d5373e2f8e9bfd7f7de2e9b03b978', None), ('claim-run-rotation.py', 246657, 'bc862f87428e86c608ddc5fe31ad8a3e2c8324b52c09ba379163db160ad70e93', None), ('rotate-canonical-state.py', 125155, '2fb6495a865d5f79948c8dfbee46ad5ffd18d47c95707b4be96890df1b3d4bbc', None), ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', None), ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', None), ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', None), ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', None)))
# DG18 current source tuple; no historical qualification expansion.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((('claim-run.sh', 31259, '1c00c1707443886a2eff09785fa945b8361f34fd1ee84b082a1326428456c3a7', 420), ('validate-run-root.sh', 114674, 'c24e2d9a171f8ab7dd0fdc78d8035a18044d5373e2f8e9bfd7f7de2e9b03b978', 420), ('claim-run-rotation.py', 259408, '969618c330cb4ae450af60431db9ab5e3a148610724e7fd674db10e2117103e8', 420), ('rotate-canonical-state.py', 127297, '8ea4b99162ebaf4f1338fbb9086b4da2fd58d94dea3cac6d82d64744520de631', 493), ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493), ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493), ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', 420), ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493)), (('claim-run.sh', 104155, '472b9f6493fa5a6c11a4ce24ca7f64176a98de6756d2ac0eca3b25397ab331e6', None), ('validate-run-root.sh', 114674, 'c24e2d9a171f8ab7dd0fdc78d8035a18044d5373e2f8e9bfd7f7de2e9b03b978', None), ('claim-run-rotation.py', 246657, '82ddcbb3cf476098fbcac57c0550d4240457688df2c4504c8ab8caea2c3367b1', None), ('rotate-canonical-state.py', 127297, '8ea4b99162ebaf4f1338fbb9086b4da2fd58d94dea3cac6d82d64744520de631', None), ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', None), ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', None), ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', None), ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', None)))
# Current repaired source closure only; historical/native acceptance is not inherited.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += (
    (
        ('claim-run.sh', 31259, '2405210c86bb842fcd3a1304e83f2a14eceb4c9f06a5d16f40c8a8e4531d4e28', 420),
        ('validate-run-root.sh', 114674, 'c24e2d9a171f8ab7dd0fdc78d8035a18044d5373e2f8e9bfd7f7de2e9b03b978', 420),
        ('claim-run-rotation.py', 259820, '2a35fc864297604be1839024fca899b3fb2becdb8d0f08377629b026d107051e', 420),
        ('rotate-canonical-state.py', 127297, '8ea4b99162ebaf4f1338fbb9086b4da2fd58d94dea3cac6d82d64744520de631', 493),
        ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
        ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', 420),
        ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
    ),
    (
        ('claim-run.sh', 104155, '83411f994564f7d5e87cbfe61ba093bf0bfc338ea6b55b1bf4fa561883b7bd2a', None),
        ('validate-run-root.sh', 114674, 'c24e2d9a171f8ab7dd0fdc78d8035a18044d5373e2f8e9bfd7f7de2e9b03b978', None),
        ('claim-run-rotation.py', 247069, '60b96654209ffa21091ce0bdcda1135d73ff0c116750842277019a1b26787a4f', None),
        ('rotate-canonical-state.py', 127297, '8ea4b99162ebaf4f1338fbb9086b4da2fd58d94dea3cac6d82d64744520de631', None),
        ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', None),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', None),
        ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', None),
        ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', None),
    ),
)
# Explicit R4 source domains; no prior native/campaign acceptance is inherited.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += (
    (
        ('claim-run.sh', 31259, 'cade5a010143b131ac70758ef68d907c4238dc5a596f341cc1be108eb1a147a0', 420),
        ('validate-run-root.sh', 114674, 'c24e2d9a171f8ab7dd0fdc78d8035a18044d5373e2f8e9bfd7f7de2e9b03b978', 420),
        ('claim-run-rotation.py', 264505, 'b599e7efbdac3008b5720f2b65796851eb163a2c287753d68abd232211c5d82a', 420),
        ('rotate-canonical-state.py', 129890, '7112fdbe9722754cb6ece6f102b06533d3c3c89902f23ade53a7477b5a276678', 493),
        ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
        ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
        ('canonical_rotation_inputs.py', 27916, 'dc95d31e4a1fabb922013fe4b1da051ba5ec6194f12a5ca0eb02a6eef1637d76', 420),
        ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
    ),
)
# R4 initialization source domain; currentness still requires the original strict owner operations.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((
    ('claim-run.sh', 31280, 'ad0dac4014087970c4898bf574207a871b8e08929a605889e038fe4dfdec404d', 420),
    ('validate-run-root.sh', 114967, 'd51d7355a3ca90201cf90af7df16aeec413a02854b2553da0cb94653f248a59a', 420),
    ('claim-run-rotation.py', 288433, '5ccadac1f8576d647b26a8dcb95beda1de55fd9abba280410087f96310d01adc', 420),
    ('rotate-canonical-state.py', 129890, '7112fdbe9722754cb6ece6f102b06533d3c3c89902f23ade53a7477b5a276678', 493),
    ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
    ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
    ('canonical_rotation_inputs.py', 27916, 'dc95d31e4a1fabb922013fe4b1da051ba5ec6194f12a5ca0eb02a6eef1637d76', 420),
    ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
),)
# R5 Windows path initialization source domain; currentness still requires the original strict owner operations.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((
    ('claim-run.sh', 31280, '7320327b903714358647bdee550bd795e087cc83db3b756e804264ad5bbf7be3', 420),
    ('validate-run-root.sh', 114967, 'd51d7355a3ca90201cf90af7df16aeec413a02854b2553da0cb94653f248a59a', 420),
    ('claim-run-rotation.py', 288439, 'ce40c4410011e46b209df718207b58c15d18e60db1379e7b66b24f04616637f9', 420),
    ('rotate-canonical-state.py', 129890, '7112fdbe9722754cb6ece6f102b06533d3c3c89902f23ade53a7477b5a276678', 493),
    ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
    ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
    ('canonical_rotation_inputs.py', 27916, 'dc95d31e4a1fabb922013fe4b1da051ba5ec6194f12a5ca0eb02a6eef1637d76', 420),
    ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
),)
# R5 Windows companion capture source domain; currentness still requires the original strict owner operations.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((
    ('claim-run.sh', 32290, 'dce0e6af8ce69e63283d0ed5ad1496779d5f2c1b90024c79228af5e22df75d4c', 420),
    ('validate-run-root.sh', 114967, 'd51d7355a3ca90201cf90af7df16aeec413a02854b2553da0cb94653f248a59a', 420),
    ('claim-run-rotation.py', 288439, 'ce40c4410011e46b209df718207b58c15d18e60db1379e7b66b24f04616637f9', 420),
    ('rotate-canonical-state.py', 129890, '7112fdbe9722754cb6ece6f102b06533d3c3c89902f23ade53a7477b5a276678', 493),
    ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
    ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
    ('canonical_rotation_inputs.py', 27916, 'dc95d31e4a1fabb922013fe4b1da051ba5ec6194f12a5ca0eb02a6eef1637d76', 420),
    ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
),)
# R5 Windows internal load binding; original owner/currentness checks remain required.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((
    ('claim-run.sh', 32290, '58b2d0a257f90fcf50a87e9b4f31789bdf2bea1574d75ff55bcef7f80fd8e1bc', 420),
    ('validate-run-root.sh', 114967, 'd51d7355a3ca90201cf90af7df16aeec413a02854b2553da0cb94653f248a59a', 420),
    ('claim-run-rotation.py', 289555, '5563f6a8ccbdfdfeea25b6370a4fc7a94ca44f424187b6527d6103a9e56ba8bc', 420),
    ('rotate-canonical-state.py', 129890, '7112fdbe9722754cb6ece6f102b06533d3c3c89902f23ade53a7477b5a276678', 493),
    ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
    ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
    ('canonical_rotation_inputs.py', 27916, 'dc95d31e4a1fabb922013fe4b1da051ba5ec6194f12a5ca0eb02a6eef1637d76', 420),
    ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
),)
# Exact H0 source-template admission, with no authentic telemetry admission.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((
    ('claim-run.sh', 32290, '9bce5c887cd89c2d2991b84f1bf765787e7a6b75a2eba29a8433c3a6c05f73a3', 420),
    ('validate-run-root.sh', 114967, 'd51d7355a3ca90201cf90af7df16aeec413a02854b2553da0cb94653f248a59a', 420),
    ('claim-run-rotation.py', 291624, '128dfe66ce656cd194d5fe1e55b245fecb1b4fd811dea87f75f8ace4a59a0487', 420),
    ('rotate-canonical-state.py', 129890, '7112fdbe9722754cb6ece6f102b06533d3c3c89902f23ade53a7477b5a276678', 493),
    ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
    ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
    ('canonical_rotation_inputs.py', 27916, 'dc95d31e4a1fabb922013fe4b1da051ba5ec6194f12a5ca0eb02a6eef1637d76', 420),
    ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
),)
# Exact DG17 owner-timeout reason source admission, with no authentic telemetry admission.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((
    ('claim-run.sh', 32290, '167a5c2570efbbfccd8aee506fde244118878c52ca0ae8c17af05bf22292e706', 420),
    ('validate-run-root.sh', 115445, '9b23638dcc3b9d13c7297068132c68fee8c553b8ab27aab214685f1be29e8ece', 420),
    ('claim-run-rotation.py', 291624, 'ad4afefacddefe7bb153ab12f0c68bf4ad919eb7794217aecec05730fba72630', 420),
    ('rotate-canonical-state.py', 129890, '7112fdbe9722754cb6ece6f102b06533d3c3c89902f23ade53a7477b5a276678', 493),
    ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
    ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
    ('canonical_rotation_inputs.py', 27916, 'dc95d31e4a1fabb922013fe4b1da051ba5ec6194f12a5ca0eb02a6eef1637d76', 420),
    ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
),)
# Exact DG17 yield scheduling and Windows owner-tree bound source admission, with no authentic telemetry admission.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((
    ('claim-run.sh', 32290, 'a58d27accd96b91c4fcd66efa9680360ca45394505b22572ea114541a1449728', 420),
    ('validate-run-root.sh', 121794, '06ba1dd6e516348b1248bae502361b1e610c06a19950b9cd03ecdcc25575b562', 420),
    ('claim-run-rotation.py', 291624, '860fb174149c7c35a18e7b1ceea6cef6eefef6f7f055e4235f8eeea0de9450e8', 420),
    ('rotate-canonical-state.py', 129890, '7112fdbe9722754cb6ece6f102b06533d3c3c89902f23ade53a7477b5a276678', 493),
    ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
    ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
    ('canonical_rotation_inputs.py', 27916, 'dc95d31e4a1fabb922013fe4b1da051ba5ec6194f12a5ca0eb02a6eef1637d76', 420),
    ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
),)
# Exact DG17 Windows job-completion source admission, with no authentic telemetry admission.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((
    ('claim-run.sh', 32290, '5b8f88cbf8d9ab5c2d9c3f5647887578eb7fd52913c673c6eb947f41ce8cb196', 420),
    ('validate-run-root.sh', 122448, 'ee2bb6e5b49d56be8541816d3e906998b0083d8446d56c89667a7213a79acc13', 420),
    ('claim-run-rotation.py', 291624, '8da36303035cad030e01331ca1eafb0968137e0e42004e908e85d37cd8cffa2a', 420),
    ('rotate-canonical-state.py', 129890, '7112fdbe9722754cb6ece6f102b06533d3c3c89902f23ade53a7477b5a276678', 493),
    ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
    ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
    ('canonical_rotation_inputs.py', 27916, 'dc95d31e4a1fabb922013fe4b1da051ba5ec6194f12a5ca0eb02a6eef1637d76', 420),
    ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
),)
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((
    ('claim-run.sh', 32290, '0a1966997827478a4aa017712be3b668b7896dc4fe97d6e8b7bc6e572e4277fb', 420),
    ('validate-run-root.sh', 122768, '9ffd7a2ae38ba9c1fea49738168b26c840856d88be5b80f4532562ca09981d20', 420),
    ('claim-run-rotation.py', 291624, '7523ed5fd31c498f0ef32cf1be5ea5c14f1ba969cc1e780cfe788d685995693a', 420),
    ('rotate-canonical-state.py', 129890, '7112fdbe9722754cb6ece6f102b06533d3c3c89902f23ade53a7477b5a276678', 493),
    ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
    ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
    ('canonical_rotation_inputs.py', 27916, 'dc95d31e4a1fabb922013fe4b1da051ba5ec6194f12a5ca0eb02a6eef1637d76', 420),
    ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
),)
# Exact DG17 owner temporary-directory source admission, with no authentic telemetry admission.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((
    ('claim-run.sh', 32290, '0815c06589f657a2ae467f7ebc1d106e6f0cc425f4b99ee4edce6b38ce5db353', 420),
    ('validate-run-root.sh', 123126, '7787569b4bceb541c33ee3287f0a8297882caff5478687e84fc534077e4c28ad', 420),
    ('claim-run-rotation.py', 291624, '866e9f669625fe3df29a3b3f4ff58f32d77a8a4b905ff8d6bffc9ef34561e42d', 420),
    ('rotate-canonical-state.py', 129890, '7112fdbe9722754cb6ece6f102b06533d3c3c89902f23ade53a7477b5a276678', 493),
    ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
    ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
    ('canonical_rotation_inputs.py', 27916, 'dc95d31e4a1fabb922013fe4b1da051ba5ec6194f12a5ca0eb02a6eef1637d76', 420),
    ('read-canonical-pair.py', 27208, 'c2868db4f385029ed75bd528d00026cb417d96c30fee6bb2bf5669c7c1128be8', 493),
),)
# Exact current native owner source profile; no native evidence admission.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((
    ('claim-run.sh', 32290, 'd8cff91ec4ba64a6cec43922f359c40c96539d1e1d2544f796814d0441c12b71', 420),
    ('validate-run-root.sh', 123126, '7787569b4bceb541c33ee3287f0a8297882caff5478687e84fc534077e4c28ad', 420),
    ('claim-run-rotation.py', 291693, '9eebc5d5e57b47b0e4b4a2a846de1c0b55407713e14008a6de4d01e7a8c5e19e', 420),
    ('rotate-canonical-state.py', 129959, '86a9a2a8501aea60f1e333c421e25b19d4e9758a121296fedfa881185de0a5fd', 493),
    ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', 493),
    ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', 493),
    ('canonical_rotation_inputs.py', 27916, 'dc95d31e4a1fabb922013fe4b1da051ba5ec6194f12a5ca0eb02a6eef1637d76', 420),
    ('read-canonical-pair.py', 27024, '733964e51ed4d65ebf8bdfba0e63cae1942e3697cab6a5cb95825d1a62f97b8c', 493),
),)
# Current shared-reader overlay; the historical original14 closure remains exact.
_NATIVE_CONTINUITY_SOURCE_PROFILES_V1 += ((
    ('claim-run.sh', 104155, '83411f994564f7d5e87cbfe61ba093bf0bfc338ea6b55b1bf4fa561883b7bd2a', None),
    ('validate-run-root.sh', 114674, 'c24e2d9a171f8ab7dd0fdc78d8035a18044d5373e2f8e9bfd7f7de2e9b03b978', None),
    ('claim-run-rotation.py', 247069, '60b96654209ffa21091ce0bdcda1135d73ff0c116750842277019a1b26787a4f', None),
    ('rotate-canonical-state.py', 127297, '8ea4b99162ebaf4f1338fbb9086b4da2fd58d94dea3cac6d82d64744520de631', None),
    ('canonical_hot_projection.py', 93893, '10f852a7b5741b4798824a06ae8933e6a5845b0541765470f3849455bddfba2f', None),
    ('canonical_custody.py', 36367, 'd52369e56c9e06d0b10b43ddffbae8f353c37b53aac8f7642bbaea356c31a389', None),
    ('canonical_rotation_inputs.py', 27154, '96aefca5859a974ebbccfd9a6d8bac80b472017366ba45aee07d4c0f36099489', None),
    ('read-canonical-pair.py', 27024, '733964e51ed4d65ebf8bdfba0e63cae1942e3697cab6a5cb95825d1a62f97b8c', None),
),)
_NATIVE_LEGACY_CONTINUITY_PAIRS_V1 = (
    ('07e09843b2831149dc43e5f0dc458e82ae5cf9614b116393ac774ddea19390c7',
     'fe005aea40d8eb2ea860c62f0caf1fb78ba678381ab6444e4f7b8202e82b77e5'),
    ('9665ba20e02c02882f3172549e90d78e790c6c0133cd31749a30e1d29c3cc0ce',
     'fe005aea40d8eb2ea860c62f0caf1fb78ba678381ab6444e4f7b8202e82b77e5'),
)

_NATIVE_CONTINUITY_TRANSPORT_SHA256 = 'de6025b8c5e48d924643387e85c1554d60b4208c751e0b5f64376cb53368f2ce'
_NATIVE_CONTINUITY_TRANSPORT_BYTES = 40203
_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1 = {
    _NATIVE_CONTINUITY_TRANSPORT_SHA256: _NATIVE_CONTINUITY_TRANSPORT_BYTES,
    # Same six-source runtime plus the exact combined original14 source selector.
    'ba79f1ba7d7f8908f869141ca3bfd950430e63932bbffdb5994892c54a052b01': 41212,
    # Exact current-core POSIX profile with unchanged command/execution guards.
    'b481e9bbad4564a3cf4cc12a67b3deafa76aaedaa01ef2407fa0b3d4b54c2720': 42323,
    # Exact donor and composed three-profile additions; no native credit.
    '84e2230251a98802b1f2500bce6e6ad58763c0931fda1ae6693a69579b519f36': 43200,
    'a532deae6bfd9360308dea01e4b9e2d492ccbe132c5850cac530d12d0f7d664e': 45320,
    '447d6eec38c60215b0e2b9a1f6f69044fb448325258de80f48fc643f78acec6a': 46368,
    # Exact DG07 profile addition; retained transports remain historical.
    '0c3e00bce07d0f5c58a00777aa40f52bbbf752e29ad8251cf023b4252e2e8c0f': 48446,
    '174553905a3f18929dfa08ce35a557feceb9d381b2661ea18a9f50b6fc9de5c2': 49494,
    # Exact DG07 profile addition; retained transports remain historical.
    'd1ccf5b3507c63c2586828a74d3a33dd7513ef2c3dbe3618b9a54a329f61acaf': 47400,
    '0dfdd58d07784164581e265d0db8a52cc08270e791bf29e6d9e1f9814113a171': 51541,
    # Exact DG08 source-only profile addition; no native credit.
    '7dfa4f3ff1d09855472cd1f8764e53f3c9f1a08ac8f85f363d6364ce429e6cd0': 53560,
    # Exact DG08 source-only profile addition; no native credit.
    '797382b4d87a3c03a64e2dfb48b1dd90860b060e177685ebda837d797931be68': 55589,
    # Exact current closure-parser source selection; historical transports retained.
    'aeb7aaf05214c65707205f53d6cfa4ec95347e1358073003a0d96280435a5ee1': 57615,
}
# Current terminal-inventory owner binding; historical subjects remain unchanged.
_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1['46c043889d7bd6ec4c39992d98a5d9db15c710b06af59dad1c1b0ee817e2c912'] = 59668
# DG10 current Windows transport binding; all historical subjects retained.
_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1['ed2305671968f08090e4be5eeb9e5a129ecb4ed34cd077fb2fc883cd938a2fcc'] = 61705


# Current canonical snapshot/NTFS CORE8 source; all qualified historical entries retained.
_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1['47898b1057aa02a3841d38a90d347cfaba311025914cf267421c01c95671fd07'] = 81384
_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1['9ac6eb3862a95df809449a53ef81753b34823a0cdbcce10fa6d5f959bbac9eab'] = 83563
# Prospective Windows fullsnapshot containment; all old transport identities remain.
_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1['e74b75859e471a3ddad6e04c645e61ff7e3b9974a511b524114913d010cf5c5e'] = 83793


# Current repaired transport; every earlier exact transport remains retained.
_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1['7f6fbc766be6f6232d70cb4862f7b9298b27389bbbd408ed1bf76f475ed21bbb'] = 86153


# Exact R4 transport; every prior receiver remains retained.
_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1['24f316c7a2eb83e7c11d39dcbeea6c00fc998b3bb03d8c4070ff4edb3ac3594c'] = 87494

_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1['9948c6a866ed780ef862719397b47871aa0acf5e5db1b7d161ad92e85208ddfb'] = 88790

_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1['aa98b1a45b9345d3ccf88611a7b90cd2939e04ee3f520b82610546ba96b77d48'] = 90101

_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1['d198e8c65c30c20cd33d0e3acf1e3a27f67b200e3bce521f018f8a947b9bf967'] = 91399

_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1['39fd9e9a2c9f07bbf10569e2811043e33b9097dcbd2126825e7e0c018f5ee2a3'] = 92708

_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1['a6ecc502ef72cdd280684353899f306a3d5dbd1a858c2ae9b39269e047d04760'] = 93973

_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1['c513f29781da905be428172cd5a3c0dfce96f337b1b9a5ef83e533752b2bb0b3'] = 95279

_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1['c7b34db11a5db190556cfc8d9a70590f91556a72ee6abd37bc1b0af6815d6322'] = 96625

_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1['53dc52b18f5be2dda4cebbe066025412842e149471abba4185af71377158e2cb'] = 97939
_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1['ecbfaf090b65e0b94023316752787138ddc0d70d6518d095398ca05044c27af4'] = 99245
_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1['fdfc02372d0b51f5741ce119a0e8475cec17775ad9a69f8b2dada48d229fa45f'] = 100540
_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1['ee0d2c2cfdbae3c18ead1b056e1b69f3b426e799e2e4f06bee7aa47e4ffc6182'] = 102980

def _native_check_continuity_closure_v1(value, repository, compiler_path, pair):
    """Check the complete live source set at fixed paths, never captured paths.

    The compiler's context owns execution and currentness. This receiving check
    independently binds its complete profile output to this same source checkout. A
    retained JSON object alone is not execution or native acceptance evidence.
    """
    helper_pair = (pair.get("claim_sha256"), pair.get("validate_sha256"))
    profiles = tuple(profile for profile in _NATIVE_CONTINUITY_SOURCE_PROFILES_V1
                     if (profile[0][2], profile[1][2]) == helper_pair)
    if os.name == "nt" and helper_pair in (
        ('dce0e6af8ce69e63283d0ed5ad1496779d5f2c1b90024c79228af5e22df75d4c', 'd51d7355a3ca90201cf90af7df16aeec413a02854b2553da0cb94653f248a59a'),
        ('9bce5c887cd89c2d2991b84f1bf765787e7a6b75a2eba29a8433c3a6c05f73a3', 'd51d7355a3ca90201cf90af7df16aeec413a02854b2553da0cb94653f248a59a'),
        ('167a5c2570efbbfccd8aee506fde244118878c52ca0ae8c17af05bf22292e706', '9b23638dcc3b9d13c7297068132c68fee8c553b8ab27aab214685f1be29e8ece'),
        ('a58d27accd96b91c4fcd66efa9680360ca45394505b22572ea114541a1449728', '06ba1dd6e516348b1248bae502361b1e610c06a19950b9cd03ecdcc25575b562'),
        ('5b8f88cbf8d9ab5c2d9c3f5647887578eb7fd52913c673c6eb947f41ce8cb196', 'ee2bb6e5b49d56be8541816d3e906998b0083d8446d56c89667a7213a79acc13'),
        ('0a1966997827478a4aa017712be3b668b7896dc4fe97d6e8b7bc6e572e4277fb', '9ffd7a2ae38ba9c1fea49738168b26c840856d88be5b80f4532562ca09981d20'),
        ('0815c06589f657a2ae467f7ebc1d106e6f0cc425f4b99ee4edce6b38ce5db353', '7787569b4bceb541c33ee3287f0a8297882caff5478687e84fc534077e4c28ad'),
        ('d8cff91ec4ba64a6cec43922f359c40c96539d1e1d2544f796814d0441c12b71', '7787569b4bceb541c33ee3287f0a8297882caff5478687e84fc534077e4c28ad'),
    ):
        profiles = tuple(tuple((*row[:3], None) for row in profile) for profile in profiles)
    if not profiles:
        if value is not None or helper_pair not in _NATIVE_LEGACY_CONTINUITY_PAIRS_V1:
            _error("OE_NATIVE_CURRENT_SOURCE", "$native.continuity_closure", "unknown or incomplete source closure")
        return
    root = pathlib.Path(__file__).absolute().parents[1]
    source_root = root / "skills/implementaudit/scripts"
    if pathlib.Path(compiler_path).absolute() != source_root / "compile-work-graph.py":
        _error("OE_NATIVE_CURRENT_SOURCE", "$native.continuity_closure", "closure compiler is outside the receiving source checkout")
    windows = profiles[0][0][3] is None
    if windows and os.name != "nt":
        _error("OE_NATIVE_CURRENT_SOURCE", "$native.continuity_closure", "original14 requires qualified Windows custody")
    rows, identity = [], []
    for index, (name, _, _, _) in enumerate(profiles[0]):
        path = source_root / name
        raw = _native_file(path, "$native.continuity_closure", max(p[index][1] for p in profiles))
        info = path.lstat()
        size, digest, mode = len(raw), hashlib.sha256(raw).hexdigest(), stat.S_IMODE(info.st_mode)
        if info.st_nlink != 1:
            _error("OE_NATIVE_CURRENT_CHANGED", "$native.continuity_closure", "continuity source is aliased")
        identity.append((name, size, digest, mode))
        row = dict(name=name, path=str(path), bytes=size, sha256=digest, mode=mode, links=1)
        row.update(dict(held=True) if windows else dict(readonly=True, seals=15))
        rows.append(row)
    if not any(len(identity) == len(profile) and all(actual[:3] == expected[:3] and (expected[3] is None or actual[3] == expected[3])
                       for actual, expected in zip(identity, profile)) for profile in profiles):
        _error("OE_NATIVE_CURRENT_CHANGED", "$native.continuity_closure", "continuity source differs from the qualified closure")
    path = root / "scripts/work-graph-continuity-transport.py"
    raw = _native_file(path, "$native.continuity_transport",
                       max(_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1.values()))
    info = path.lstat()
    if (_NATIVE_CONTINUITY_TRANSPORT_PROFILES_V1.get(hashlib.sha256(raw).hexdigest()) != len(raw)
            or info.st_nlink != 1):
        _error("OE_NATIVE_CURRENT_CHANGED", "$native.continuity_transport", "transport source differs from the executed profile")
    execution = dict(schema="implementaudit.continuity-source-closure.v2",
                     repository=str(pathlib.Path(repository).absolute()), members=rows,
                     startup=dict(profile="ISOLATED_CPYTHON_V1", isolated=True,
                                  no_site=True, dont_write_bytecode=True))
    if windows:
        execution = dict(schema="implementaudit.continuity-windows-source-closure.v1",
                         repository=str(pathlib.Path(repository).absolute()), members=rows,
                         custody="WINDOWS_HELD_FILES_V1")
    expected = dict(schema="implementaudit.native-continuity-closure.v1",
        execution=execution,
        transport=dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                       mode=stat.S_IMODE(info.st_mode)))
    # Equality also refuses aliases, extra members, reordered members and
    # foreign captured path strings without ever opening those supplied paths.
    if type(value) is not dict or canonical_json_v1(value) != canonical_json_v1(expected):
        _error("OE_NATIVE_CURRENT_SOURCE", "$native.continuity_closure", "executed closure differs from fixed receiving sources")


def _native_require_current_receipt(repo, controller, receipt, route_module):
    claim_path, claim_raw, validate_path, validate_raw = _native_continuity_source_files_v1()
    closure = None
    completed = None
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            bash = route_module.trusted_host_executable(repo, "bash")
        environment = _native_child_environment(route_module)
        closure = pathlib.Path(tempfile.mkdtemp(
            prefix="implementaudit-native-current-r0011-"))
        materialized_claim = closure / claim_path.name
        materialized_validate = closure / validate_path.name
        expected = (
            (materialized_claim, claim_raw),
            (materialized_validate, validate_raw),
        )
        for target, raw in expected:
            with target.open("xb") as stream:
                stream.write(raw)
            if _native_file(
                    target, "$native.private_continuity_closure",
                    256 * 1024) != raw:
                _error(
                    "OE_NATIVE_CURRENT_CHANGED",
                    "$native.private_continuity_closure",
                    "private R0011 materialization changed before child launch")
        with contextlib.redirect_stdout(io.StringIO()):
            claim_arg = route_module.bash_script_path(materialized_claim)
            validate_arg = route_module.bash_script_path(materialized_validate)
        completed = subprocess.run(
            [
                os.fspath(bash), "-c", _NATIVE_R0011_CHILD_BOOTSTRAP,
                "implementaudit-native-r0011-child", claim_arg, validate_arg,
                hashlib.sha256(claim_raw).hexdigest(),
                hashlib.sha256(validate_raw).hexdigest(),
                "--require-current-continuity", controller,
            ],
            cwd=repo, env=environment, stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            check=False)
    except (OSError, SystemExit):
        _error("OE_NATIVE_CURRENT_RECEIPT", "$native.receipt",
               "canonical R0011 currentness validator is unavailable")
    finally:
        if closure is not None:
            _native_cleanup_private_closure(closure, expected)
    child_binding = (
        "implementaudit-native-r0011-child-v1\t" +
        hashlib.sha256(claim_raw).hexdigest() + "\t" +
        hashlib.sha256(validate_raw).hexdigest())
    if completed.returncode or completed.stdout.strip() != receipt:
        _error("OE_NATIVE_CURRENT_RECEIPT", "$native.receipt",
               "canonical R0011 currentness validator rejected the receipt chain")
    if completed.stderr.splitlines().count(child_binding) != 1:
        _error("OE_NATIVE_CURRENT_CHANGED", "$native.continuity_child",
               "completed R0011 child did not bind the exact helper identities")
    if _native_file(
            claim_path, "$native.continuity_validator", 256 * 1024) != claim_raw:
        _error("OE_NATIVE_CURRENT_CHANGED", "$native.continuity_validator",
               "R0011 validator changed during currentness validation")
    if _native_file(
            validate_path, "$native.continuity_claim_validator",
            256 * 1024) != validate_raw:
        _error("OE_NATIVE_CURRENT_CHANGED", "$native.continuity_claim_validator",
               "R0011 claim validator changed during currentness validation")
    return claim_path, claim_raw, validate_path, validate_raw


def _native_route(
        repo, controller, controller_oid, claim, run_root, generation, receipt,
        boundary_kind, boundary_event_id, next_action, route_module):
    expected_current = {
        "controller_id": controller,
        "controller_record_oid": controller_oid,
        "claim_id": claim,
        "explicit_run_root": os.fspath(run_root),
        "continuity_generation": generation,
        "continuity_receipt": receipt,
        "boundary_kind": boundary_kind,
        "boundary_event_id": boundary_event_id,
        "next_action": next_action,
    }
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            return route_module.validate_pure_current_route(
                repo, controller, expected_current)
    except (Exception, SystemExit):
        _error("OE_NATIVE_CURRENT_ROUTE", "$native.route",
               "canonical R0033 pure current-route validator rejected the route record")

def _native_route_relation(repository, run_root, graph_raw, route,
                           compiler_path, compiler_raw, route_module):
    """Consume the fixed semantic owners; do not derive governed node scope."""
    compiler = _native_module_from_bytes(compiler_raw, compiler_path,
        "_implementaudit_native_route_graph", "$native.route_graph_compiler")
    graph_capable = callable(getattr(compiler, "bind_native_route_relation_v1", None))
    route_capable = callable(getattr(route_module, "read_current_route_scope_v1", None))
    if not graph_capable and not route_capable:
        # Historical source peers retain their old observation interface. The
        # compiler/query census below exposes this mandatory capability gap.
        return None
    if not graph_capable or not route_capable or not callable(
            getattr(compiler, "read_native_run_v1", None)):
        _error("OE_NATIVE_CURRENT_SOURCE", "$native.route_graph_compiler",
               "canonical route/node peer composition is incomplete")
    try:
        graph = compiler.read_native_run_v1(run_root, repository)
        relation = compiler.bind_native_route_relation_v1(graph, graph_raw)
    except (Exception, SystemExit):
        _error("OE_NATIVE_CURRENT_ROUTE", "$native.route_relation",
               "canonical affected-node acquisition or binding refused")
    if graph["route_scope"]["route"] != route:
        _error("OE_NATIVE_CURRENT_CHANGED", "$native.route_relation",
               "canonical route changed during affected-node acquisition")
    if _native_file(compiler_path, "$native.route_graph_compiler", 256 * 1024) != compiler_raw:
        _error("OE_NATIVE_CURRENT_CHANGED", "$native.route_graph_compiler",
               "graph owner source changed during acquisition")
    return graph, relation


@contextlib.contextmanager
def _native_current_observation_v1(
        repository, source_repository, controller, controller_oid, claim, run_root,
        generation, receipt, boundary_kind, boundary_event_id, next_action,
        graph_raw, compiler_path, compiler_raw, route_module, *, continuity_sources=None, _episode_output=None):
    """Hold the fixed native owners' complete guards around the C03 read."""
    compiler = _native_module_from_bytes(compiler_raw, compiler_path,
        "_implementaudit_native_route_graph", "$native.route_graph_compiler")
    observe = getattr(compiler, "observe_native_run_v1", None)
    source_observation = False
    episode_observation = False
    source_version = 1
    closure_observation = None
    if continuity_sources is not None:
        if (type(continuity_sources) is not dict or
                set(continuity_sources) != {"claim_sha256", "validate_sha256"} or
                any(type(value) is not str or not re.fullmatch(r"[0-9a-f]{64}", value)
                    for value in continuity_sources.values())):
            _error("OE_NATIVE_CURRENT_SOURCE", "$native.continuity_sources", "invalid executed-source constraint")
        observe_sources = getattr(compiler, "observe_native_run_sources_v2", None)
        if observe_sources is not None:
            source_version = 2
        else:
            observe_sources = getattr(compiler, "observe_native_run_sources_v1", None)
        if observe_sources is not None and repository == source_repository:
            if not callable(observe_sources) or not callable(observe):
                _error("OE_NATIVE_CURRENT_SOURCE", "$native.continuity_sources", "incomplete source-observation interface")
            observe, source_observation = observe_sources, True
            if _episode_output is not None:
                observe_episode = getattr(compiler, f"observe_native_run_episode_sources_v{source_version}", None)
                if observe_episode is not None:
                    if not callable(observe_episode):
                        _error("OE_NATIVE_CURRENT_SOURCE", "$native.episode", "malformed enclosing episode owner")
                    observe, episode_observation = observe_episode, True
        else:
            # Historical/separate owners retain C03's original fixed-byte call.
            actual = _native_require_current_receipt(repository, controller, receipt, route_module)
            if {"claim_sha256": hashlib.sha256(actual[1]).hexdigest(),
                    "validate_sha256": hashlib.sha256(actual[3]).hexdigest()} != continuity_sources:
                _error("OE_NATIVE_CURRENT_CHANGED", "$native.continuity_sources", "continuity helper bytes changed")
    route_args = (source_repository, controller, controller_oid, claim, run_root,
                  generation, receipt, boundary_kind, boundary_event_id,
                  next_action, route_module)
    if observe is None or repository != source_repository:
        # Historical peers and separate checkout custody retain the original
        # full acquisitions. No new capability is inferred for those sources.
        route = _native_route(*route_args)
        projection = _native_route_relation(repository, run_root, graph_raw,
            route, compiler_path, compiler_raw, route_module)
        yield route, projection
        if _native_route_relation(repository, run_root, graph_raw, route,
                compiler_path, compiler_raw, route_module) != projection:
            _error("OE_NATIVE_CURRENT_CHANGED", "$native.route_relation",
                   "affected-node sources changed during final observation")
        if _native_route(*route_args) != route:
            _error("OE_NATIVE_CURRENT_CHANGED", "$native.route",
                   "R0033 route identity changed during final semantic observation")
        return
    if (not callable(observe) or
            not callable(getattr(compiler, "bind_native_route_relation_v1", None)) or
            not callable(getattr(route_module, "read_current_route_scope_v1", None))):
        _error("OE_NATIVE_CURRENT_SOURCE", "$native.route_graph_compiler",
               "canonical route/node observation composition is incomplete")
    try:
        expected_current = {
            "controller_id": controller, "controller_record_oid": controller_oid,
            "claim_id": claim, "explicit_run_root": os.fspath(run_root),
            "continuity_generation": generation, "continuity_receipt": receipt,
            "boundary_kind": boundary_kind, "boundary_event_id": boundary_event_id,
            "next_action": next_action}
        with observe(run_root, repository, expected_current=expected_current) as raw:
            if type(raw) is not bytes:
                _error("OE_NATIVE_CURRENT_SOURCE", "$native.route_relation",
                       "native owner did not yield immutable projection bytes")
            graph = decode_strict_json_bytes(raw, "native owner observation")
            if source_observation:
                fields = {"schema", "projection", "continuity_sources"}
                if source_version == 2:
                    fields.add("continuity_closure")
                if episode_observation:
                    fields.add("ordinary_episode")
                _object(graph, "$native.continuity_sources", exact_keys=fields, required=fields)
                schema = (f"implementaudit.native-run-episode-source-observation.v{source_version}" if episode_observation
                          else f"implementaudit.native-run-source-observation.v{source_version}")
                if (graph["schema"] != schema or
                        graph["continuity_sources"] != continuity_sources):
                    _error("OE_NATIVE_CURRENT_SOURCE", "$native.continuity_sources", "executed helper sources differ")
                if source_version == 2:
                    closure_observation = graph["continuity_closure"]
                    _native_check_continuity_closure_v1(closure_observation, repository, compiler_path, continuity_sources)
                elif (continuity_sources.get("claim_sha256"), continuity_sources.get("validate_sha256")) not in _NATIVE_LEGACY_CONTINUITY_PAIRS_V1:
                    _error("OE_NATIVE_CURRENT_SOURCE", "$native.continuity_closure", "complete continuity composition requires the v2 observation")
                if episode_observation:
                    _episode_output.append(graph["ordinary_episode"])
                graph = graph["projection"]
            scope = graph["route_scope"]
            route = scope["route"]
            if (scope["owner"] != {
                    "controller_id": controller, "claim_id": claim,
                    "explicit_run_root": os.fspath(run_root),
                    "continuity_generation": generation, "continuity_receipt": receipt}
                    or route["controller_id"] != controller
                    or route["controller_record_oid"] != controller_oid):
                _error("OE_NATIVE_CURRENT_CHANGED", "$native.route_relation",
                       "native owner projection crossed the exact C03 current identity")
            relation = compiler.bind_native_route_relation_v1(graph, graph_raw)
            yield route, (graph, relation)
            retained = decode_strict_json_bytes(raw, "native owner observation")
            if source_observation:
                retained = retained["projection"]
            if graph != retained:
                _error("OE_NATIVE_CURRENT_CHANGED", "$native.route_relation",
                       "provisional native projection was mutated")
        # Context exit retains the owner's fresh source/readset/continuity,
        # semantic route, receipt, ref and producer-source validation.
        if source_observation and source_version == 2:
            _native_check_continuity_closure_v1(closure_observation, repository, compiler_path, continuity_sources)
    except OperationalEvidenceError:
        raise
    except (Exception, SystemExit):
        _error("OE_NATIVE_CURRENT_ROUTE", "$native.route_relation",
               "canonical affected-node observation or terminal validation refused")
    if _native_file(compiler_path, "$native.route_graph_compiler", 256 * 1024) != compiler_raw:
        _error("OE_NATIVE_CURRENT_CHANGED", "$native.route_graph_compiler",
               "graph owner source changed during observation")


def _native_episode_peer_bytes():
    # source repo: fixed generic owner contracts, outside shipped skills.
    root = pathlib.Path(__file__).resolve().parents[1] / "source-peers/native-runtime/skills/implementaudit/scripts"
    return [(root / name, _native_file(root / name, "$native.episode_contract", 256 * 1024))
            for name in ("compaction-audit-pending.py", "compaction-result-observation.py")]


def _native_episode_owners_v1():
    """Acquire the fixed episode owners, retaining exact bytes for exit checks."""
    root = pathlib.Path(__file__).resolve().parents[1] / "skills/implementaudit/scripts"
    paths = [root / name for name in ("compaction-audit-pending.py", "compaction-result-observation.py")]
    raws = [_native_file(path, "$native.episode_owner", 256 * 1024)
            if path.exists() or path.is_symlink() else None for path in paths]
    markers = (b"def acquire_selected_episode_export_v1(", b"def validate_frozen_episode_export_v1(")
    capable = [raw is not None and marker in raw for raw, marker in zip(raws, markers)]
    if not any(capable):
        return None  # Historical peer set: retain an explicit capability gap.
    if not all(capable):
        _error("OE_NATIVE_CURRENT_SOURCE", "$native.episode", "native episode peer composition is incomplete")
    peers = _native_episode_peer_bytes()
    if raws != [raw for path, raw in peers]:
        _error("OE_NATIVE_CURRENT_SOURCE", "$native.episode", "native episode owners differ from the selected source composition")
    producer = _native_module_from_bytes(raws[0], paths[0], "_native_episode_producer", "$native.episode")
    contract = _native_module_from_bytes(raws[1], paths[1], "_native_episode_contract", "$native.episode")
    return producer, contract, [*zip(paths, raws), *peers], raws


def _native_episode_wrap_v1(value, owners):
    _, contract, files, raws = owners
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            if contract.validate_frozen_episode_export_v1(value) != value:
                raise ValueError("episode owner changed its exported value")
    except (Exception, SystemExit):
        _error("OE_NATIVE_CURRENT_EPISODE", "$native.episode", "selected accepted episode refused owner validation")
    if any(_native_file(path, "$native.episode_fence", 256 * 1024) != raw
           for path, raw in files):
        _error("OE_NATIVE_CURRENT_CHANGED", "$native.episode", "episode owner source changed during read")
    return {"producer_sha256": hashlib.sha256(raws[0]).hexdigest(),
            "contract_sha256": hashlib.sha256(raws[1]).hexdigest(), "value": value}


def _native_episode():
    """Read the selected accepted owner episode; no caller path/profile input."""
    owners = _native_episode_owners_v1()
    if owners is None:
        return None
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            value = owners[0].acquire_selected_episode_export_v1()
    except (Exception, SystemExit):
        _error("OE_NATIVE_CURRENT_EPISODE", "$native.episode", "selected accepted episode refused owner validation")
    return _native_episode_wrap_v1(value, owners)


def _native_episode_binding(wrapped, route, graph):
    value = wrapped["value"]
    if value["status"] != "AVAILABLE":
        return
    if graph is None or value["owner"]["canonical_route"] != route:
        raise ValueError("accepted episode belongs to a different current route")
    scope = graph["route_scope"]
    expected = {**scope["owner"], **scope["host"],
                **{key: route[key] for key in ("obligation_id", "route_transaction_id")}}
    if value["owner"]["host_and_scope"] != expected:
        raise ValueError("accepted episode belongs to a different host/currentness scope")
    if (value["schema"] == "implementaudit.ordinary-episode-export.v1" and
            scope["satisfaction"] != value["acceptance"]["decision"]["digest"]):
        raise ValueError("ordinary acceptance differs from the canonical satisfied route")
    pins = value["owner"]["code_pins"]
    normalized = {key.replace("\\", "/"): digest for key, digest in pins.items()}
    expected_pins = {"implementaudit/scripts/route-transaction.py": scope["source"]["producer_sha256"],
                     "implementaudit/scripts/compaction-audit-pending.py": wrapped["producer_sha256"],
                     "implementaudit/scripts/compaction-result-observation.py": wrapped["contract_sha256"]}
    if len(normalized) != len(pins) or any(normalized.get(key) != digest for key, digest in expected_pins.items()):
        raise ValueError("accepted episode route source identity differs")




# A selected reader owns this invocation-local handoff. It conveys no native
# proof and cannot be supplied as a serialized token or reused by another read.
import contextvars
_SELECTED_REPOSITORY_READ_V1 = contextvars.ContextVar(
    "implementaudit_selected_repository_read", default=None)


class _SelectedRepositoryReadV1:
    def __init__(self):
        from concurrent.futures import ThreadPoolExecutor
        self._pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="implementaudit-repository")
        self._root = None
        self._future = None
        self._closed = False
        self._taken = False

    def start(self, root):
        if self._closed:
            _error("OE_SNAPSHOT_INPUT_CHANGED", "$snapshot.repository", "repository read is closed")
        root = pathlib.Path(root).absolute()
        if self._root is not None and self._root != root:
            _error("OE_SNAPSHOT_INPUT_CHANGED", "$snapshot.repository", "repository observation changed root")
        if self._future is None:
            self._root = root
            self._future = self._pool.submit(_collect_repository_observation_v1, root)

    def take(self, root):
        if self._taken:
            _error("OE_SNAPSHOT_INPUT_CHANGED", "$snapshot.repository", "repository observation was already consumed")
        self.start(root)
        result = self._future.result()
        self._taken = True
        return result

    def close(self):
        self._closed = True
        self._pool.shutdown(wait=True, cancel_futures=True)


def _start_selected_repository_read_v1(repository):
    observation = _SELECTED_REPOSITORY_READ_V1.get()
    if observation is not None:
        if type(observation) is not _SelectedRepositoryReadV1:
            _error("OE_SNAPSHOT_INPUT_CHANGED", "$snapshot.repository", "unowned repository observation")
        observation.start(repository)



def collect_native_current():
    """Return exact native facts only after their complete observation closes."""
    with _observe_native_current_v1() as result:
        pass
    return result


@contextlib.contextmanager
def _observe_native_current_v1():
    """Read one exact native hot/current fact set without lifecycle authority."""
    source_repository = pathlib.Path(__file__).resolve().parents[1]
    observed_source = _native_resolved_path(
        _run_git(source_repository, "rev-parse", "--path-format=absolute",
                 "--show-toplevel").stdout.strip(), "$native.source_repository")
    if observed_source != source_repository:
        _error("OE_NATIVE_CURRENT_CUSTODY", "$native.source_repository",
               "carrier source is not in its own repository checkout")
    common = _git_source_directories(source_repository)[1]
    controller_refs = _run_git(
        source_repository, "for-each-ref", "--format=%(refname)",
        "refs/implementaudit/controllers/").stdout.splitlines()
    if len(controller_refs) != 1:
        _error("OE_NATIVE_CURRENT_CUSTODY", "$native.controller",
               "native controller population must contain exactly one ref")
    controller_ref = controller_refs[0]
    prefix = "refs/implementaudit/controllers/"
    controller = controller_ref[len(prefix):] if controller_ref.startswith(prefix) else ""
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,47}", controller):
        _error("OE_NATIVE_CURRENT_CUSTODY", "$native.controller",
               "native controller identity is malformed")
    controller_oid = _native_ref_oid(
        source_repository, controller_ref, "$native.controller.ref")
    controller_fields = _native_exact_tsv(
        _native_blob(source_repository, controller_oid, "$native.controller"),
        "implementaudit.controller-current.v1", 4, "$native.controller")
    claim = controller_fields[2]
    if (controller_fields[1] != controller or
            not re.fullmatch(r"[0-9a-f]{32}", claim)):
        _error("OE_NATIVE_CURRENT_CUSTODY", "$native.controller",
               "native controller record is foreign or malformed")
    run_root = _native_resolved_path(controller_fields[3], "$native.run_root")
    try:
        repository = run_root.parents[2]
    except (ValueError, IndexError):
        _error("OE_NATIVE_CURRENT_CUSTODY", "$native.run_root",
               "native run root is outside fixed run custody")
    try:
        run_relative = run_root.relative_to(repository)
    except ValueError:
        _error("OE_NATIVE_CURRENT_CUSTODY", "$native.run_root",
               "native run root is outside controller repository")
    if (len(run_relative.parts) != 3 or run_relative.parts[:2] != (
            ".IMPLEMENTAUDIT", "runs") or run_root.is_symlink()):
        _error("OE_NATIVE_CURRENT_CUSTODY", "$native.run_root",
               "native run root is not the fixed bound-run-root location")
    run_id = run_relative.parts[2]
    controller_common = _git_source_directories(repository)[1]
    if controller_common != common:
        _error("OE_NATIVE_CURRENT_CUSTODY", "$native.controller",
               "controller repository is foreign to carrier Git custody")
    claimed_raw, sentinel_raw, run_relative_text = _native_claim(
        run_root, repository, common, controller, claim, run_id)
    # C02 is an independent readonly acquisition of this actual bound root.
    # Its own full lifetime and the later post-native input fence remain owed.
    # The selected consumer alone installs the invocation-local read owner.
    _start_selected_repository_read_v1(repository)

    state_path = run_root / "STATE.md"
    roadmap_path = run_root / "ROADMAP.md"
    graph_path = run_root / "WORK_GRAPH.json"
    state_raw = _native_file(state_path, "$native.STATE")
    roadmap_raw = _native_file(roadmap_path, "$native.ROADMAP")
    graph_raw = _native_file(graph_path, "$native.WORK_GRAPH")
    state = _native_state_facts(state_raw)
    (projection, compiler_sha256, compiler_path,
     compiler_raw) = _native_graph_projection(graph_raw)
    state_sha256 = hashlib.sha256(state_raw).hexdigest()
    roadmap_sha256 = hashlib.sha256(roadmap_raw).hexdigest()
    graph_sha256 = hashlib.sha256(graph_raw).hexdigest()

    invalidation_ref = f"refs/implementaudit/continuity-invalidations/{controller}"
    invalidation_oid = _native_ref_oid(
        source_repository, invalidation_ref, "$native.invalidation.ref")
    invalidation = _native_exact_tsv(
        _native_blob(source_repository, invalidation_oid, "$native.invalidation"),
        "implementaudit.continuity-invalidation.v1", 6, "$native.invalidation")
    if (invalidation[1:4] != [controller, controller_oid, claim] or
            invalidation[4] not in {
                "host-reported-compaction", "new-session", "handoff-resume",
                "manual-resume", "inferred-context-gap"}):
        _error("OE_NATIVE_CURRENT_RECEIPT", "$native.invalidation",
               "continuity invalidation is foreign or malformed")

    pointer_ref = f"refs/implementaudit/current-generations/{controller}"
    pointer_oid = _native_ref_oid(
        source_repository, pointer_ref, "$native.pointer.ref")
    pointer_raw = _native_blob(source_repository, pointer_oid, "$native.pointer")
    pointer = _native_pointer(pointer_raw, controller, claim, run_id)
    generation = pointer["source_epoch"]
    if (state["epoch"] != generation or pointer["hot_state_digest"] != state_sha256 or
            pointer["hot_roadmap_digest"] != roadmap_sha256 or
            pointer["work_graph_digest"] != graph_sha256):
        _error("OE_NATIVE_CURRENT_STALE", "$native.hot",
               "hot STATE/ROADMAP/WORK_GRAPH disagree with current pointer")

    receipt_ref = f"refs/implementaudit/continuity-receipts/{controller}/{generation}"
    receipt_oid = _native_ref_oid(
        source_repository, receipt_ref, "$native.receipt.ref")
    receipt_fields = _native_exact_tsv(
        _native_blob(source_repository, receipt_oid, "$native.receipt"),
        "implementaudit.continuity-receipt.v3", 18, "$native.receipt")
    receipt = f"{receipt_ref}@{receipt_oid}"
    expected_receipt = [
        "implementaudit.continuity-receipt.v3", controller, claim, run_id,
        generation, invalidation_oid, pointer_ref, pointer_oid,
        pointer["pointer_digest"], state_sha256, roadmap_sha256,
        "WORK_GRAPH.json", graph_sha256, pointer["generation_manifest_oid"],
        pointer["generation_manifest_digest"], pointer["cold_high_water"],
        state["next_action"], receipt_fields[17]]
    if receipt_fields != expected_receipt:
        _error("OE_NATIVE_CURRENT_RECEIPT", "$native.receipt",
               "receipt-v3 disagrees with pointer, hot files, or next action")
    predecessor_ref, predecessor_oid, predecessor_raw = _native_predecessor(
        source_repository, controller, controller_oid, claim, run_id,
        generation, receipt_fields[17])

    marker_ref = f"refs/implementaudit/current-generation-migrations/{controller}"
    marker_oid = _native_ref_oid(
        source_repository, marker_ref, "$native.marker.ref")
    marker = _native_exact_no_lf_tsv(
        _native_blob(source_repository, marker_oid, "$native.marker"),
        "implementaudit.current-generation-migration.v1", 10, "$native.marker")
    if (marker[:4] != [
            "implementaudit.current-generation-migration.v1", controller, claim,
            run_id] or not re.fullmatch(r"G[0-9A-F]{4}", marker[4]) or
            marker[5:7] != [
                pointer_ref, "implementaudit.state-generation-pointer.v1"] or
            marker[9] != "true"):
        _error("OE_NATIVE_CURRENT_RECEIPT", "$native.marker",
               "permanent migration marker is malformed or foreign")
    genesis_generation = marker[4]
    genesis_receipt_ref = marker[7]
    genesis_receipt_oid = marker[8]
    if (genesis_receipt_ref !=
            f"refs/implementaudit/continuity-receipts/{controller}/{genesis_generation}" or
            _native_ref_oid(source_repository, genesis_receipt_ref,
                            "$native.marker.receipt_ref") != genesis_receipt_oid):
        _error("OE_NATIVE_CURRENT_RECEIPT", "$native.marker",
               "permanent migration marker receipt is stale or foreign")
    genesis_receipt_fields = _native_exact_tsv(
        _native_blob(source_repository, genesis_receipt_oid,
                     "$native.marker.receipt"),
        "implementaudit.continuity-receipt.v3", 18,
        "$native.marker.receipt")
    if (genesis_receipt_fields[:5] != [
            "implementaudit.continuity-receipt.v3", controller, claim, run_id,
            genesis_generation] or genesis_receipt_fields[6] != pointer_ref or
            not re.fullmatch(r"[0-9a-f]{40}", genesis_receipt_fields[7])):
        _error("OE_NATIVE_CURRENT_RECEIPT", "$native.marker",
               "permanent migration marker receipt is malformed or foreign")
    genesis_pointer_oid = genesis_receipt_fields[7]
    genesis_pointer = _native_pointer(
        _native_blob(source_repository, genesis_pointer_oid,
                     "$native.marker.pointer"),
        controller, claim, run_id)
    if (genesis_pointer["source_epoch"] != genesis_generation or
            genesis_pointer["generation_id"] != genesis_generation or
            genesis_pointer["predecessor_pointer_oid"] is not None or
            genesis_pointer["predecessor_pointer_digest"] is not None or
            genesis_receipt_fields[8:16] != [
                genesis_pointer["pointer_digest"],
                genesis_pointer["hot_state_digest"],
                genesis_pointer["hot_roadmap_digest"],
                genesis_pointer["work_graph_path"],
                genesis_pointer["work_graph_digest"],
                genesis_pointer["generation_manifest_oid"],
                genesis_pointer["generation_manifest_digest"],
                genesis_pointer["cold_high_water"]]):
        _error("OE_NATIVE_CURRENT_RECEIPT", "$native.marker",
               "permanent migration marker does not bind the immutable genesis")
    if genesis_receipt_fields[17].count("@") != 1:
        _error("OE_NATIVE_CURRENT_RECEIPT", "$native.marker",
               "permanent genesis predecessor token is malformed")
    genesis_predecessor_ref, genesis_predecessor_oid = (
        genesis_receipt_fields[17].split("@"))
    genesis_ordinal = int(genesis_generation[1:], 16)
    if (genesis_ordinal <= 1 or genesis_predecessor_ref !=
            f"refs/implementaudit/continuity-receipts/{controller}/"
            f"G{genesis_ordinal - 1:04X}" or
            not re.fullmatch(r"[0-9a-f]{40}", genesis_predecessor_oid)):
        _error("OE_NATIVE_CURRENT_RECEIPT", "$native.marker",
               "permanent genesis predecessor token is not structurally immediate")
    current_ordinal = int(generation[1:], 16)
    if current_ordinal < genesis_ordinal:
        _error("OE_NATIVE_CURRENT_RECEIPT", "$native.marker",
               "current generation predates permanent genesis")
    if current_ordinal == genesis_ordinal:
        if (pointer_oid != genesis_pointer_oid or
                pointer["predecessor_pointer_oid"] is not None or
                pointer["predecessor_pointer_digest"] is not None):
            _error("OE_NATIVE_CURRENT_RECEIPT", "$native.marker",
                   "current genesis disagrees with permanent marker")
    else:
        predecessor_fields = _native_exact_tsv(
            predecessor_raw, "implementaudit.continuity-receipt.v3", 18,
            "$native.receipt.predecessor")
        if (pointer["predecessor_pointer_oid"] != predecessor_fields[7] or
                pointer["predecessor_pointer_digest"] != predecessor_fields[8]):
            _error("OE_NATIVE_CURRENT_RECEIPT", "$native.pointer.predecessor",
                   "current pointer is not joined to its immediate receipt predecessor")
    route_module, route_validator_path, route_validator_raw = _native_route_module()
    (continuity_validator_path, continuity_validator_raw,
     continuity_claim_validator_path, continuity_claim_validator_raw) = (
        _native_continuity_source_files_v1())
    episode_output = []
    with _native_current_observation_v1(
            repository, source_repository, controller, controller_oid, claim, run_root,
            generation, receipt, invalidation[4], invalidation[5], state["next_action"],
            graph_raw, compiler_path, compiler_raw, route_module,
            continuity_sources={"claim_sha256": hashlib.sha256(continuity_validator_raw).hexdigest(),
                                "validate_sha256": hashlib.sha256(continuity_claim_validator_raw).hexdigest()},
            _episode_output=episode_output) as (route, route_projection):
        episode_owners = None
        if episode_output and episode_output[0] is not None:
            episode_owners = _native_episode_owners_v1()
            if episode_owners is None:
                _error("OE_NATIVE_CURRENT_SOURCE", "$native.episode", "enclosing episode has no exact owner composition")
            native_episode = _native_episode_wrap_v1(episode_output[0], episode_owners)
        else:
            native_episode = _native_episode()
        if native_episode is not None:
            try:
                _native_episode_binding(native_episode, route,
                                        route_projection[0] if route_projection is not None else None)
            except (KeyError, TypeError, ValueError):
                _error("OE_NATIVE_CURRENT_EPISODE", "$native.episode", "accepted episode crossed native route custody")

        ref_fence = {
            controller_ref: controller_oid, invalidation_ref: invalidation_oid,
            pointer_ref: pointer_oid, receipt_ref: receipt_oid, marker_ref: marker_oid,
            genesis_receipt_ref: genesis_receipt_oid,
            predecessor_ref: predecessor_oid,
            route["ref"]: route["record_oid"]}
        file_fence = {
            run_root / ".claimed": claimed_raw, run_root / ".controller": sentinel_raw,
            state_path: state_raw, roadmap_path: roadmap_raw, graph_path: graph_raw,
            compiler_path: compiler_raw,
            route_validator_path: route_validator_raw,
            continuity_validator_path: continuity_validator_raw,
            continuity_claim_validator_path: continuity_claim_validator_raw}
        if _run_git(
                source_repository, "for-each-ref", "--format=%(refname)",
                "refs/implementaudit/controllers/").stdout.splitlines() != controller_refs:
            _error("OE_NATIVE_CURRENT_CHANGED", "$native.controller",
                   "controller population changed during observation")
        if not _native_refs_match_v1(source_repository, ref_fence):
            _error("OE_NATIVE_CURRENT_CHANGED", "$native.refs",
                   "native-current ref changed during observation")
        # Reuse the opening route-source bound; the route owner is larger than
        # the default hot-file bound. Equality below still refuses every change.
        if any(_native_file(path, "$native.final_file_fence",
                            512 * 1024 if path == route_validator_path else 256 * 1024) != raw
               for path, raw in file_fence.items()):
            _error("OE_NATIVE_CURRENT_CHANGED", "$native.hot",
                   "native-current file changed during observation")

        result = {
            "schema": NATIVE_CURRENT_SCHEMA,
            "authority_ceiling": "READ_ONLY_NATIVE_CURRENT_FACT",
            "establishes": [],
            "repository": {
                "root": repository.as_posix(), "git_common_dir": common.as_posix()},
            "controller": {
                "id": controller, "ref": controller_ref, "record_oid": controller_oid},
            "claim": {
                "id": claim, "run_id": run_id, "run_root": run_relative_text},
            "continuity": {
                "generation": generation, "source_epoch": pointer["source_epoch"],
                "invalidation_ref": invalidation_ref,
                "invalidation_oid": invalidation_oid,
                "boundary_kind": invalidation[4], "boundary_event_id": invalidation[5],
                "pointer_ref": pointer_ref, "pointer_oid": pointer_oid,
                "pointer_digest": pointer["pointer_digest"],
                "receipt_schema": receipt_fields[0], "receipt_ref": receipt_ref,
                "receipt_oid": receipt_oid, "receipt": receipt,
                "marker_ref": marker_ref, "marker_oid": marker_oid,
                "generation_manifest_oid": pointer["generation_manifest_oid"],
                "generation_manifest_digest": pointer["generation_manifest_digest"],
                "cold_high_water": pointer["cold_high_water"],
                "degraded_state": pointer["degraded_state"]},
            "hot": {
                "state_path": "STATE.md", "state_sha256": state_sha256,
                "roadmap_path": "ROADMAP.md", "roadmap_sha256": roadmap_sha256,
                "work_graph_path": "WORK_GRAPH.json",
                "work_graph_sha256": graph_sha256,
                "work_graph_compiler_sha256": compiler_sha256},
            "frontier": projection,
            "andon_state": state["andon_state"],
            "open_andons": state["open_andons"],
            "active_instructions": state["active_instructions"],
            "next_action": state["next_action"],
            "route": route,
        }
        result.update(route_graph=route_projection[0] if route_projection is not None else None,
                      route_relation=route_projection[1] if route_projection is not None else None,
                      canonical_work_graph=graph_raw.decode("utf-8", "strict"),
                      native_episode=native_episode)
        result["semantic_sha256"] = hashlib.sha256(canonical_json_v1(result)).hexdigest()
        native_record_raw = canonical_json_v1(result)
        yield result
        if canonical_json_v1(result) != native_record_raw:
            _error("OE_NATIVE_CURRENT_CHANGED", "$native.observation",
                   "provisional native facts were mutated during read-only use")
        final_episode = (_native_episode_wrap_v1(episode_output[0], episode_owners)
                         if episode_owners is not None else _native_episode())
        if final_episode != native_episode:
            _error("OE_NATIVE_CURRENT_CHANGED", "$native.episode", "accepted episode changed during native observation")
    # Recheck C03's own custody after the enclosing owner has closed.
    if not _native_refs_match_v1(source_repository, ref_fence):
        _error("OE_NATIVE_CURRENT_CHANGED", "$native.refs",
               "native-current ref changed before observation closure")
    if any(_native_file(path, "$native.closed_file_fence",
                        512 * 1024 if path == route_validator_path else 256 * 1024) != raw
           for path, raw in file_fence.items()):
        _error("OE_NATIVE_CURRENT_CHANGED", "$native.hot",
               "native-current file changed before observation closure")


def collect_repository(root: pathlib.Path):
    """Collect exact read-only Git/file/package facts and bounded Python AST edges."""
    return _collect_repository_observation_v1(root)[0]


def _repository_collector_signature_v1(include_python):
    """Bind private semantic reuse to freshly read collector/runtime provenance."""
    source = _native_file(pathlib.Path(__file__).absolute(), "$repository.collector", 2 * 1024 * 1024)
    runtime = (platform.python_implementation(), platform.python_version(), sys.version, sys.executable)
    if not include_python:
        return source, runtime, None, None
    try:
        ast_path = pathlib.Path(ast.__file__).absolute()
        ast_raw = _native_file(ast_path, "$repository.python_ast", 2 * 1024 * 1024)
    except (AttributeError, OSError, OperationalEvidenceError):
        _error("OE_STATIC_COLLECTOR_IDENTITY", "$repository.python_ast",
               "Python AST collector bytes could not be identified")
    return source, runtime, str(ast_path), ast_raw


def _collect_repository_observation_v1(root):
    with _repository_read_scope_v1(root) as read_repository:
        return _collect_repository_observation_scoped_v1(root, read_repository)


def _collect_repository_observation_scoped_v1(root, read_repository):
    """Acquire one live result and a transaction-local fresh-byte reobserver.

    The closure owns immutable result bytes and its physical/Git input census.
    No supplied JSON, persisted token or process-global cache can create it.
    """
    root = pathlib.Path(root).resolve()
    if not root.is_dir():
        _error("OE_REPOSITORY_UNREADABLE", "$repository",
               "repository root must be a readable directory")
    top = pathlib.Path(
        _run_git(root, "rev-parse", "--show-toplevel").stdout.strip()).resolve()
    if top != root:
        _error("OE_REPOSITORY_ROOT", "$repository",
               "root must be the exact Git worktree top level")
    commit = _run_git(root, "rev-parse", "--verify", "HEAD").stdout.strip()
    tree = _run_git(
        root, "rev-parse", "--verify", "HEAD^{tree}").stdout.strip()
    _git_object(commit, "$repository.commit")
    _git_object(tree, "$repository.tree")
    raw_paths = _run_git(root, "ls-files", "-z", text=False).stdout
    try:
        path_values = raw_paths.decode("utf-8").split("\0")
    except UnicodeDecodeError:
        _error("OE_REPOSITORY_PATH", "$repository.files",
               "tracked paths must be valid UTF-8")
    paths = sorted(path for path in path_values if path)
    if len(paths) > REPOSITORY_MAX_FILES:
        _error("OE_REPOSITORY_LIMIT", "$repository.files", "tracked path ceiling exceeded")
    portable_names = [unicodedata.normalize("NFC", path).casefold() for path in paths]
    if len(portable_names) != len(set(portable_names)):
        _error("OE_REPOSITORY_PATH", "$repository.files",
               "case or Unicode path identities collide")
    excluded = _repository_exclusions(root, paths)
    status = _run_git(
        root, "status", "--porcelain=v1", "--untracked-files=all").stdout
    worktree_state = "CLEAN" if not status else "DIRTY"

    facts = []
    diagnostics = {"warnings": [], "errors": [], "skipped": [], "unknown": []}
    file_rows = []
    physical_file_rows = []
    file_bytes = {}
    file_types = {}
    file_error = False
    total_bytes = 0
    for index, relative in enumerate(paths):
        pure = _safe_relative_path(relative, f"$repository.files[{index}]")
        path = root.joinpath(*pure.parts)
        if relative in excluded:
            file_error = True
            physical_file_rows.append(_physical_file_row(relative))
            diagnostics["skipped"].append(f"policy-excluded:{relative}:{excluded[relative]}")
            facts.append({
                "kind": "FILE_EXCLUDED_OBSERVATION", "path": relative,
                "state": "UNSUPPORTED", "provenance": {
                    "method": "repository-default-deny-v1", "commit": commit, "tree": tree}})
            continue
        try:
            data, file_type = read_repository(path)
        except (OSError, UnicodeError):
            file_error = True
            physical_file_rows.append(_physical_file_row(relative))
            diagnostics["errors"].append(f"tracked-path-unreadable:{relative}")
            facts.append({
                "kind": "FILE_UNREADABLE_OBSERVATION", "path": relative,
                "state": "STALE", "provenance": {
                    "method": "git-ls-files+working-tree-read",
                    "commit": commit, "tree": tree,
                },
            })
            continue
        total_bytes += len(data)
        if total_bytes > REPOSITORY_MAX_TOTAL_BYTES:
            _error("OE_REPOSITORY_LIMIT", "$repository.files", "total byte ceiling exceeded")
        digest = hashlib.sha256(data).hexdigest()
        physical_file_rows.append(
            _physical_file_row(relative, data, file_type))
        file_bytes[relative] = data
        file_types[relative] = file_type
        file_rows.append({"path": relative, "bytes": len(data), "sha256": digest})
        facts.append({
            "kind": "FILE", "path": relative, "sha256": digest,
            "bytes": len(data), "file_type": file_type,
            "language": _file_language(relative), "state": "CURRENT",
            "provenance": {
                "method": "git-ls-files+working-tree-sha256",
                "commit": commit, "tree": tree,
            },
        })

    _require_repository_snapshot_stable(
        root, paths, commit, tree, raw_paths, status, physical_file_rows, excluded, read_repository)
    input_file_set_sha256 = hashlib.sha256(
        canonical_json_v1(file_rows)).hexdigest()

    regular_paths = [path for path in file_bytes if file_types[path] == "file"]
    modules = _python_module_map(regular_paths)
    python_paths = sorted(path for path in regular_paths if path.endswith(".py"))
    collector_signature = _repository_collector_signature_v1(bool(python_paths))
    ast_provenance = None
    if python_paths:
        ast_package_sha256 = hashlib.sha256(collector_signature[3]).hexdigest()
        ast_provenance = {
            "collector_identity": "python-stdlib-ast",
            "collector_version": (
                f"{platform.python_implementation()}-{platform.python_version()}"),
            "collector_package_sha256": ast_package_sha256,
            "invocation_identity": "ast.parse(mode=exec,type_comments=false)",
            "output_schema_identity": REPOSITORY_COLLECTION_SCHEMA,
            "parser": "python-ast-static-imports-v1",
        }
    static_invocations = []
    parser_error = False
    for relative in python_paths:
        digest = hashlib.sha256(file_bytes[relative]).hexdigest()
        static_invocations.append({
            "collector": "python_ast", "input_path": relative,
            "input_sha256": digest, **ast_provenance,
        })
        if len(file_bytes[relative]) > REPOSITORY_MAX_PYTHON_BYTES:
            parser_error = True
            diagnostics["errors"].append(f"python-parser-limit:{relative}")
            facts.append({
                "kind": "PARSER_LIMIT_OBSERVATION", "path": relative,
                "state": "UNSUPPORTED", "provenance": {
                    **ast_provenance, "input_path": relative, "input_sha256": digest}})
            continue
        try:
            source = file_bytes[relative].decode("utf-8")
            parsed = ast.parse(source, filename=relative, mode="exec")
        except (UnicodeDecodeError, SyntaxError, ValueError, RecursionError, MemoryError) as exc:
            parser_error = True
            diagnostics["errors"].append(
                f"python-parser-error:{relative}:{type(exc).__name__}")
            facts.append({
                "kind": "PARSER_ERROR_OBSERVATION", "path": relative,
                "state": "PARSER_ERROR",
                "provenance": {
                    **ast_provenance,
                    "input_path": relative, "input_sha256": digest,
                },
            })
            continue
        for node in ast.walk(parsed):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                candidates = _import_candidates(relative, node)
                resolved = _resolve_import(relative, node, modules)
                for target in resolved:
                    provenance = {
                        **ast_provenance,
                        "input_path": relative, "input_sha256": digest,
                    }
                    facts.append({
                        "kind": "PYTHON_IMPORT", "source": relative,
                        "target": target, "state": "CURRENT",
                        "provenance": provenance,
                    })
                    facts.append({
                        "kind": "PYTHON_REVERSE_DEPENDENT", "source": target,
                        "target": relative, "state": "CURRENT",
                        "provenance": provenance,
                    })
                for target in sorted(name for name in candidates
                                     if name not in modules):
                    facts.append({
                        "kind": "UNSUPPORTED_IMPORT_OBSERVATION",
                        "source": relative, "target": target,
                        "state": "UNSUPPORTED", "provenance": {
                            **ast_provenance,
                            "input_path": relative, "input_sha256": digest,
                            "reason": "outside-declared-local-module-map",
                        },
                    })
            elif (isinstance(node, ast.Call) and
                  ((isinstance(node.func, ast.Name) and
                    node.func.id == "__import__") or
                   (isinstance(node.func, ast.Attribute) and
                    node.func.attr == "import_module"))):
                diagnostics["unknown"].append(
                    f"computed-import:{relative}:{getattr(node, 'lineno', 0)}:"
                    f"{getattr(node, 'col_offset', 0)}")

    package_state = "NOT_APPLICABLE"
    package_path = "package/implementaudit-package.json"
    if package_path in file_bytes:
        package_state = "SUPPORTED"
        try:
            manifest = decode_strict_json_bytes(
                file_bytes[package_path], "package manifest")
            _object(manifest, "$package", required={"package_name"})
            package_name = _text(manifest["package_name"], "$package.package_name")
            facts.append({
                "kind": "PACKAGE_MANIFEST", "path": package_path,
                "package_name": package_name,
                "sha256": hashlib.sha256(file_bytes[package_path]).hexdigest(),
                "state": "CURRENT", "provenance": {
                    "parser": "strict-json-v1", "input_path": package_path,
                },
            })
            roots = manifest.get("shared_resource_roots", [])
            if type(roots) is not list:
                _error("OE_SCHEMA_INVALID", "$package.shared_resource_roots",
                       "must be an array")
            for index, declared in enumerate(roots):
                pure = _safe_relative_path(
                    declared, f"$package.shared_resource_roots[{index}]")
                prefix = pure.as_posix().rstrip("/") + "/"
                if any(path == pure.as_posix() or path.startswith(prefix)
                       for path in file_bytes):
                    facts.append({
                        "kind": "PACKAGE_ROOT", "package_name": package_name,
                        "path": pure.as_posix(), "state": "CURRENT",
                        "provenance": {
                            "parser": "strict-json-v1",
                            "input_path": package_path,
                            "input_sha256": hashlib.sha256(
                                file_bytes[package_path]).hexdigest(),
                        },
                    })
                else:
                    diagnostics["unknown"].append(
                        f"declared-package-root-missing:{pure.as_posix()}")
        except OperationalEvidenceError as exc:
            package_state = "PARSER_ERROR"
            diagnostics["errors"].append(
                f"package-manifest-error:{exc.code}:{exc.path}")
            facts.append({
                "kind": "PACKAGE_MANIFEST_ERROR", "path": package_path,
                "state": "PARSER_ERROR", "provenance": {
                    "parser": "strict-json-v1", "input_path": package_path,
                    "input_sha256": hashlib.sha256(
                        file_bytes[package_path]).hexdigest(),
                },
            })

    registry_path = "scripts/verify-package.sh"
    if registry_path in file_bytes:
        facts.append({
            "kind": "REGISTRY_FILE", "path": registry_path,
            "sha256": hashlib.sha256(file_bytes[registry_path]).hexdigest(),
            "state": "UNSUPPORTED", "provenance": {
                "method": "exact-file-fact-only",
                "reason": "shell-registry-parser-not-admitted",
            },
        })
        registry_state = "UNSUPPORTED"
        registry_reason = "shell_registry_exact_file_fact_only"
    else:
        registry_state = "NOT_APPLICABLE"
        registry_reason = "registry_file_absent"

    if not static_invocations:
        python_state = "NOT_APPLICABLE"
        python_reason = "no_tracked_python_inputs"
    elif parser_error:
        python_state = "PARTIAL"
        python_reason = "parser_error_population_retained"
    else:
        python_state = "SUPPORTED"
        python_reason = "bounded_positive_ast_edges"
    python_capability = {
        "capability": "python_ast", "state": python_state,
        "reason_code": python_reason,
    }
    if ast_provenance is not None:
        python_capability["provenance"] = {
            **ast_provenance,
            "input_file_set_sha256": input_file_set_sha256,
        }
    capabilities = [
        {"capability": "file_facts",
         "state": "PARTIAL" if file_error else "SUPPORTED",
         "reason_code": ("tracked_file_unreadable" if file_error else
                         "tracked_working_tree_bytes_hashed")},
        {"capability": "package_manifest", "state": package_state,
         "reason_code": "strict_json_positive_declarations_only"},
        python_capability,
        {"capability": "validation_registry_entries", "state": registry_state,
         "reason_code": registry_reason},
    ]
    _require_repository_snapshot_stable(
        root, paths, commit, tree, raw_paths, status, physical_file_rows, excluded, read_repository)
    facts.sort(key=lambda row: canonical_json_v1(row))
    static_invocations.sort(key=lambda row: canonical_json_v1(row))
    for values in diagnostics.values():
        values.sort()
    result = {
        "schema": REPOSITORY_COLLECTION_SCHEMA,
        "repository": {
            "commit": commit, "tree": tree,
            "worktree_state": worktree_state,
            "input_file_set_sha256": input_file_set_sha256,
        },
        "capabilities": sorted(capabilities, key=lambda row: row["capability"]),
        "diagnostics": diagnostics,
        "facts": facts,
        "static_collector_invocations": static_invocations,
    }
    result_raw = canonical_json_v1(result)
    immutable_result = decode_strict_json_bytes(result_raw, "repository collection result")

    def reobserve():
        # Decode before the terminal fence: callers cannot mutate the retained
        # baseline, and no parser/canonicalization callback follows fresh reads.
        observed_result = decode_strict_json_bytes(result_raw, "repository collection result")
        if _repository_collector_signature_v1(bool(python_paths)) != collector_signature:
            _error("OE_REPOSITORY_CHANGED_DURING_SCAN", "$repository",
                   "repository collector source or runtime changed during collection")
        with _repository_read_scope_v1(root) as fresh_reader:
            _require_repository_snapshot_stable(
                root, paths, commit, tree, raw_paths, status, physical_file_rows, excluded, fresh_reader)
        return observed_result

    if _repository_collector_signature_v1(bool(python_paths)) != collector_signature:
        _error("OE_REPOSITORY_CHANGED_DURING_SCAN", "$repository",
               "repository collector source or runtime changed during collection")
    _require_repository_snapshot_stable(
        root, paths, commit, tree, raw_paths, status, physical_file_rows, excluded, read_repository)
    return immutable_result, reobserve


def collect_evidence_failure(root: pathlib.Path):
    """Collect canonical EVIDENCE/FAILURE run artifacts without promotion."""
    root = pathlib.Path(root).resolve()
    if not root.is_dir():
        _error("OE_RUN_ARTIFACT_MISSING", "$run_artifact",
               "run-artifact root must be a readable directory")
    artifact_path = root / "operational-evidence.json"
    if artifact_path.is_symlink() or not artifact_path.is_file():
        _error("OE_RUN_ARTIFACT_MISSING", "$run_artifact",
               "canonical operational-evidence.json is required")
    try:
        if artifact_path.stat().st_size > 1024 * 1024:
            _error("OE_RUN_ARTIFACT_INVALID", "$run_artifact",
                   "canonical run artifact exceeds the C04 byte bound")
        artifact_bytes = _read_repository_path(artifact_path, root=root, maximum=1024 * 1024)[0]
    except OSError:
        _error("OE_RUN_ARTIFACT_MISSING", "$run_artifact",
               "canonical operational-evidence.json is unreadable")
    if len(artifact_bytes) > 1024 * 1024:
        _error("OE_RUN_ARTIFACT_INVALID", "$run_artifact",
               "canonical run artifact exceeds the C04 byte bound")
    artifact = decode_strict_json_bytes(artifact_bytes, "canonical run artifact")
    top_keys = {
        "schema", "run_identity", "artifact_identity", "first_red_id",
        "weakest_leg_id", "residual_ids", "evidence_records",
        "failure_records"}
    _object(artifact, "$run_artifact", exact_keys=top_keys, required=top_keys)
    if artifact["schema"] != "implementaudit-run-evidence-v1":
        _error("OE_RUN_ARTIFACT_INVALID", "$run_artifact.schema",
               "unsupported canonical run-artifact schema")
    run_identity = _text(
        artifact["run_identity"], "$run_artifact.run_identity")
    artifact_identity = _text(
        artifact["artifact_identity"], "$run_artifact.artifact_identity")
    artifact_sha256 = hashlib.sha256(artifact_bytes).hexdigest()

    if type(artifact["evidence_records"]) is not list:
        _error("OE_RUN_ARTIFACT_INVALID", "$run_artifact.evidence_records",
               "must be an array")
    evidence_keys = {
        "id", "sequence", "record_type", "claim_id", "criterion_id", "leg",
        "result_class", "proxy", "source_identity", "native_owner_identity",
        "currentness", "controls", "contrary_evidence"}
    evidence_records = []
    evidence_by_id = {}
    evidence_sequences = []
    for index, source_record in enumerate(artifact["evidence_records"]):
        path = f"$run_artifact.evidence_records[{index}]"
        record = _object(
            source_record, path, exact_keys=evidence_keys,
            required=evidence_keys)
        record_id = _text(record["id"], f"{path}.id")
        if record_id in evidence_by_id:
            _error("OE_RUN_ARTIFACT_INVALID", f"{path}.id",
                   "evidence record id must be unique")
        sequence = record["sequence"]
        if type(sequence) is not int or sequence < 0:
            _error("OE_RUN_ARTIFACT_INVALID", f"{path}.sequence",
                   "sequence must be a non-negative integer")
        if record["record_type"] not in (
                "Claim", "Criterion", "Evidence", "Check", "Review"):
            _error("OE_RUN_ARTIFACT_INVALID", f"{path}.record_type",
                   "unsupported EVIDENCE record type")
        for key in (
                "claim_id", "criterion_id", "source_identity",
                "native_owner_identity"):
            _text(record[key], f"{path}.{key}")
        if record["leg"] not in (
                "ATTEMPT", "RECEIPT", "EFFECT", "RECOVERY", "CLOSURE"):
            _error("OE_RUN_ARTIFACT_INVALID", f"{path}.leg",
                   "unsupported evidence leg")
        if record["result_class"] not in (
                "RED", "GREEN", "NONVERDICT", "UNKNOWN"):
            _error("OE_RUN_ARTIFACT_INVALID", f"{path}.result_class",
                   "unsupported evidence result class")
        proxy = _boolean(record["proxy"], f"{path}.proxy")
        if proxy and record["leg"] not in ("ATTEMPT", "RECEIPT"):
            _error("OE_RUN_EVIDENCE_PROXY", path,
                   "proxy evidence cannot become effect, recovery or closure")
        _currentness(record["currentness"], f"{path}.currentness")
        _string_list(record["controls"], f"{path}.controls")
        _string_list(
            record["contrary_evidence"], f"{path}.contrary_evidence")
        normalized = {
            **record,
            "family": "EVIDENCE",
            "authority_ceiling": "READ_ONLY_NATIVE_ARTIFACT_FACT",
            "artifact_sha256": artifact_sha256,
        }
        evidence_records.append(normalized)
        evidence_by_id[record_id] = normalized
        evidence_sequences.append(sequence)
    if evidence_sequences != sorted(evidence_sequences) or len(set(
            evidence_sequences)) != len(evidence_sequences):
        _error("OE_RUN_ARTIFACT_INVALID", "$run_artifact.evidence_records",
               "evidence sequence must be unique and increasing")
    for record in evidence_records:
        if any(reference not in evidence_by_id
               for reference in record["contrary_evidence"]):
            _error("OE_RUN_EVIDENCE_REFERENCE",
                   f"$run_artifact.evidence_records[{record['id']}].contrary_evidence",
                   "contrary evidence must reference a retained evidence record")

    red_records = [
        record for record in evidence_records
        if record["result_class"] == "RED" and not record["proxy"]]
    if red_records:
        first_red_id = _text(
            artifact["first_red_id"], "$run_artifact.first_red_id")
        if (first_red_id not in evidence_by_id or
                first_red_id != min(
                    red_records, key=lambda row: row["sequence"])["id"]):
            _error("OE_RUN_EVIDENCE_FIRST_RED", "$run_artifact.first_red_id",
                   "first RED must retain the earliest non-proxy RED record")
        first_red_state = "PRESENT"
    else:
        if artifact["first_red_id"] is not None:
            _error("OE_RUN_EVIDENCE_FIRST_RED", "$run_artifact.first_red_id",
                   "no-first-RED population must use JSON null")
        first_red_id = None
        first_red_state = "NOT_APPLICABLE"
    weakest_leg_id = _text(
        artifact["weakest_leg_id"], "$run_artifact.weakest_leg_id")
    weakest = evidence_by_id.get(weakest_leg_id)
    if (weakest is None or weakest["proxy"] or
            (red_records and weakest["result_class"] != "RED")):
        _error("OE_RUN_EVIDENCE_WEAKEST", "$run_artifact.weakest_leg_id",
               "weakest leg must be non-proxy and RED when a RED exists")

    if type(artifact["failure_records"]) is not list:
        _error("OE_RUN_ARTIFACT_INVALID", "$run_artifact.failure_records",
               "must be an array")
    failure_keys = {
        "id", "sequence", "record_type", "andon_id", "abnormality_class",
        "statement", "cause_confidence", "evidence_ids", "recovery_state",
        "source_identity", "native_owner_identity", "currentness"}
    failure_records = []
    failure_by_id = {}
    failure_sequences = []
    for index, source_record in enumerate(artifact["failure_records"]):
        path = f"$run_artifact.failure_records[{index}]"
        record = _object(
            source_record, path, exact_keys=failure_keys, required=failure_keys)
        record_id = _text(record["id"], f"{path}.id")
        if record_id in failure_by_id or record_id in evidence_by_id:
            _error("OE_RUN_FAILURE_INVALID", f"{path}.id",
                   "failure record id must be globally unique")
        sequence = record["sequence"]
        if type(sequence) is not int or sequence < 0:
            _error("OE_RUN_FAILURE_INVALID", f"{path}.sequence",
                   "sequence must be a non-negative integer")
        if record["record_type"] not in (
                "Andon", "Residual", "Containment", "Countermeasure",
                "Rerun", "Recovery"):
            _error("OE_RUN_FAILURE_INVALID", f"{path}.record_type",
                   "unsupported FAILURE record type")
        for key in (
                "andon_id", "abnormality_class", "statement",
                "source_identity", "native_owner_identity"):
            _text(record[key], f"{path}.{key}")
        if record["cause_confidence"] not in (
                "UNKNOWN", "LOW", "MEDIUM", "HIGH"):
            _error("OE_RUN_FAILURE_INVALID", f"{path}.cause_confidence",
                   "unsupported cause confidence")
        if record["recovery_state"] not in (
                "NOT_CLAIMED", "ATTEMPTED", "OBSERVED", "UNVERIFIED"):
            _error("OE_RUN_FAILURE_INVALID", f"{path}.recovery_state",
                   "unsupported recovery state")
        _string_list(record["evidence_ids"], f"{path}.evidence_ids")
        _currentness(record["currentness"], f"{path}.currentness")
        normalized = {
            **record,
            "family": "FAILURE",
            "authority_ceiling": "READ_ONLY_NATIVE_ARTIFACT_FACT",
            "artifact_sha256": artifact_sha256,
        }
        failure_records.append(normalized)
        failure_by_id[record_id] = normalized
        failure_sequences.append(sequence)
    if failure_sequences != sorted(failure_sequences) or len(set(
            failure_sequences)) != len(failure_sequences):
        _error("OE_RUN_FAILURE_INVALID", "$run_artifact.failure_records",
               "failure sequence must be unique and increasing")
    andon_ids = {
        record["id"] for record in failure_records
        if record["record_type"] == "Andon"}
    for record in failure_records:
        if record["andon_id"] not in andon_ids:
            _error("OE_RUN_FAILURE_REFERENCE",
                   f"$run_artifact.failure_records[{record['id']}].andon_id",
                   "failure lineage must reference a retained Andon")
        if any(reference not in evidence_by_id
               for reference in record["evidence_ids"]):
            _error("OE_RUN_FAILURE_REFERENCE",
                   f"$run_artifact.failure_records[{record['id']}].evidence_ids",
                   "failure lineage must reference retained evidence")
        if record["recovery_state"] == "OBSERVED":
            recovery_evidence = [
                evidence_by_id[reference]
                for reference in record["evidence_ids"]]
            if (not recovery_evidence or any(
                    evidence["leg"] != "RECOVERY" or
                    evidence["result_class"] != "GREEN" or
                    evidence["proxy"] or
                    evidence["currentness"]["state"] != "CURRENT"
                    for evidence in recovery_evidence)):
                _error("OE_RUN_RECOVERY_EVIDENCE",
                       f"$run_artifact.failure_records[{record['id']}]",
                       "observed recovery requires current direct recovery evidence")
    residual_ids = _string_list(
        artifact["residual_ids"], "$run_artifact.residual_ids")
    if any(residual_id not in failure_by_id or
           failure_by_id[residual_id]["record_type"] != "Residual"
           for residual_id in residual_ids):
        _error("OE_RUN_FAILURE_REFERENCE", "$run_artifact.residual_ids",
               "declared residual must reference a retained Residual record")

    layer_census = Counter(
        record["leg"] for record in evidence_records)
    layer_census_result = {
        leg: layer_census.get(leg, 0)
        for leg in (
            "ATTEMPT", "RECEIPT", "EFFECT", "RECOVERY", "CLOSURE")
    }
    result = {
        "schema": EVIDENCE_FAILURE_COLLECTION_SCHEMA,
        "families": ["EVIDENCE", "FAILURE"],
        "source": {
            "path": "operational-evidence.json",
            "sha256": artifact_sha256,
            "run_identity": run_identity,
            "artifact_identity": artifact_identity,
        },
        "first_red_id": first_red_id,
        "first_red_state": first_red_state,
        "weakest_leg_id": weakest_leg_id,
        "residual_ids": list(residual_ids),
        "layer_census": layer_census_result,
        "evidence_records": evidence_records,
        "failure_records": failure_records,
        "establishes": [],
    }
    result["semantic_sha256"] = hashlib.sha256(
        canonical_json_v1(result)).hexdigest()
    immutable_result = decode_strict_json_bytes(
        canonical_json_v1(result), "evidence/failure collection")
    if artifact_path.is_symlink():
        _error("OE_RUN_ARTIFACT_CHANGED", "$run_artifact",
               "canonical run artifact changed during collection")
    try:
        final_artifact_bytes = _read_repository_path(artifact_path, root=root, maximum=1024 * 1024)[0]
    except OSError:
        _error("OE_RUN_ARTIFACT_CHANGED", "$run_artifact",
               "canonical run artifact changed during collection")
    if final_artifact_bytes != artifact_bytes:
        _error("OE_RUN_ARTIFACT_CHANGED", "$run_artifact",
               "canonical run artifact changed during collection")
    return immutable_result


def _utc_timestamp(value, path):
    _text(value, path)
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z", value) is None:
        _error("OE_EXTERNAL_CAPTURE_INVALID", path,
               "must be an exact UTC second timestamp")
    try:
        datetime.datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ")
    except ValueError:
        _error("OE_EXTERNAL_CAPTURE_INVALID", path,
               "must be a valid UTC calendar timestamp")
    return value


def _validate_capture_chronology(captured_at, expires_at, evaluated_at, path):
    if captured_at >= expires_at or evaluated_at < captured_at:
        _error("OE_EXTERNAL_CAPTURE_INVALID", path,
               "capture chronology must satisfy captured < expires and "
               "evaluated >= captured")


def _external_boundary_currentness(
        auth_state, rate_state, pagination_state, object_drift,
        expires_at, evaluated_at):
    invalidators = []
    if auth_state == "ABSENT":
        invalidators.append("AUTH_ABSENT")
    elif auth_state == "UNKNOWN":
        invalidators.append("AUTH_UNKNOWN")
    if rate_state == "EXHAUSTED":
        invalidators.append("RATE_LIMITED")
    elif rate_state == "UNKNOWN":
        invalidators.append("RATE_UNKNOWN")
    if pagination_state == "INCOMPLETE":
        invalidators.append("PAGINATION_INCOMPLETE")
    elif pagination_state == "UNKNOWN":
        invalidators.append("PAGINATION_UNKNOWN")
    if object_drift:
        invalidators.append("OBJECT_DRIFT")
    if evaluated_at >= expires_at:
        invalidators.append("CAPTURE_EXPIRED")
    if any(item in invalidators for item in ("OBJECT_DRIFT", "CAPTURE_EXPIRED")):
        state = "STALE"
    elif any(item in invalidators for item in ("AUTH_ABSENT", "AUTH_UNKNOWN")):
        state = "UNVERIFIED"
    elif invalidators:
        state = "UNKNOWN"
    else:
        state = "CURRENT"
    return {"state": state, "invalidators": invalidators}


def _compose_currentness(native, capture):
    """Retain both native and capture invalidators without promotion."""
    state_rank = {
        "CURRENT": 0, "UNSUPPORTED": 1, "UNKNOWN": 2, "UNVERIFIED": 3,
        "STALE": 4, "PARSER_ERROR": 5, "CONTRADICTORY": 6,
        "INVALID": 7,
    }
    state = max(
        (native["state"], capture["state"]), key=state_rank.__getitem__)
    invalidators = []
    for invalidator in [
            *native["invalidators"], *capture["invalidators"]]:
        if invalidator not in invalidators:
            invalidators.append(invalidator)
    return {"state": state, "invalidators": invalidators}


_RELEASE_RECORD_TYPES_V1 = frozenset({
    "Commit", "Tree", "Worktree", "GeneratedArtifact", "Package",
    "Install", "Host", "PullRequest", "Check", "Merge", "Tag",
    "Release", "Asset", "PublicSurface"})


def _release_omissions_v1(missing_types):
    return [{"record_type": record_type, "state": "UNKNOWN",
             "invalidator": f"MISSING_RELEASE_LAYER:{record_type}"}
            for record_type in missing_types]


def _release_candidate_v1(repository, nodes, boundary_currentness, missing_types):
    """Derive the same non-authoritative candidate for collection and checking.

    Retain the caller's node order and first occurrence of each invalidator.
    This pure calculation neither authenticates inputs nor renews observations.
    """
    public_nodes = [row for row in nodes if row["record_type"] == "PublicSurface"]
    invalidators = list(boundary_currentness["invalidators"])
    for row in (item for item in nodes if item["layer"] == "EXTERNAL"):
        for invalidator in row["currentness"]["invalidators"]:
            if invalidator not in invalidators:
                invalidators.append(invalidator)
    invalidators.extend(
        f"MISSING_RELEASE_LAYER:{record_type}" for record_type in missing_types)
    public_commit = None
    if len(public_nodes) != 1:
        invalidators.append("PUBLIC_IDENTITY_NOT_EXACTLY_ONE")
    else:
        public_commit = public_nodes[0]["commit_identity"]
        if public_commit != repository["commit"]:
            invalidators.append("PUBLIC_PREDECESSOR_DIFFERS_FROM_LOCAL_COMMIT")
    if repository["worktree_state"] != "CLEAN":
        invalidators.append("LOCAL_WORKTREE_DIRTY")
    if not invalidators:
        invalidators.append("NATIVE_CANDIDATE_QUALIFICATION_REQUIRED")
    return {"state": "UNVERIFIED", "invalidators": invalidators,
            "local_commit": repository["commit"], "public_commit": public_commit}


def collect_release(root: pathlib.Path):
    """Collect local and frozen external RELEASE facts without promotion."""
    root = pathlib.Path(root).resolve()
    return _repository_collectors_v1(root)[1]()


def _collect_release_from_repository_v1(root, repository_before):
    """A supplied collection remains data; require independent live derivation."""
    result = _derive_release_from_repository_v1(root, repository_before)
    if collect_repository(root) != repository_before:
        _error("OE_RELEASE_CHANGED_DURING_SCAN", "$release",
               "repository changed during RELEASE collection")
    return result


def _repository_collectors_v1(root):
    """Own one live C02 capture and C05's freshly fenced local derivation."""
    repository, reobserve = _collect_repository_observation_v1(root)
    repository_raw = canonical_json_v1(repository)

    def release():
        before = decode_strict_json_bytes(repository_raw, "repository collection result")
        result = _derive_release_from_repository_v1(root, before)
        try:
            after = reobserve()
        except OperationalEvidenceError as exc:
            if exc.code != "OE_REPOSITORY_CHANGED_DURING_SCAN":
                raise
            _error("OE_RELEASE_CHANGED_DURING_SCAN", "$release",
                   "repository changed during RELEASE collection")
        if after != before:
            _error("OE_RELEASE_CHANGED_DURING_SCAN", "$release",
                   "repository changed during RELEASE collection")
        return result

    return repository, release, reobserve


def _derive_release_from_repository_v1(root, repository_before):
    """Derive C05 data; each caller owns its separate live repository fence."""
    repository = repository_before["repository"]
    file_facts = {
        row["path"]: row for row in repository_before["facts"]
        if row.get("kind") == "FILE"}

    def read_fixed_json(relative, owner):
        path = root / relative
        if relative not in file_facts or path.is_symlink() or not path.is_file():
            _error("OE_RELEASE_ARTIFACT_MISSING", f"$release.{relative}",
                   f"canonical {relative} is required")
        try:
            data = _read_repository_path(path, root=root)[0]
        except OSError:
            _error("OE_RELEASE_ARTIFACT_MISSING", f"$release.{relative}",
                   f"canonical {relative} is unreadable")
        tracked = file_facts.get(relative)
        digest = hashlib.sha256(data).hexdigest()
        if tracked is None or tracked.get("sha256") != digest:
            _error("OE_RELEASE_CHANGED_DURING_SCAN", f"$release.{relative}",
                   "release owner artifact changed after repository scan")
        return decode_strict_json_bytes(data, owner), digest

    local, local_manifest_sha256 = read_fixed_json(
        "release-local.json", "local release manifest")
    local_top = {"schema", "records"}
    _object(local, "$release.local", exact_keys=local_top, required=local_top)
    if local["schema"] != "implementaudit-local-release-v1":
        _error("OE_RELEASE_LOCAL_INVALID", "$release.local.schema",
               "unsupported local release schema")
    if type(local["records"]) is not list:
        _error("OE_RELEASE_LOCAL_INVALID", "$release.local.records",
               "must be an array")

    nodes = [{
        "id": identity, "record_type": kind, "layer": "LOCAL",
        "family": "RELEASE", "object_identity": repository[key],
        "source_identity": source, "native_owner_identity": "git:repository",
        "currentness": {"state": "CURRENT", "invalidators": []},
        "authority_ceiling": "READ_ONLY_NATIVE_OBSERVATION",
    } for identity, kind, key, source in (
        ("git-commit", "Commit", "commit", "git:HEAD"),
        ("git-tree", "Tree", "tree", "git:HEAD^{tree}"),
        ("git-worktree", "Worktree", "worktree_state", "git:status--porcelain-v1"),
    )]
    seen_ids = {row["id"] for row in nodes}
    local_keys = {
        "id", "record_type", "path", "sha256", "source_identity",
        "native_owner_identity", "currentness"}
    for index, source_record in enumerate(local["records"]):
        path = f"$release.local.records[{index}]"
        record = _object(
            source_record, path, exact_keys=local_keys, required=local_keys)
        record_id = _text(record["id"], f"{path}.id")
        if record_id in seen_ids:
            _error("OE_RELEASE_LOCAL_INVALID", f"{path}.id",
                   "release node id must be unique")
        if record["record_type"] not in (
                "GeneratedArtifact", "Package", "Install", "Host"):
            _error("OE_RELEASE_LOCAL_INVALID", f"{path}.record_type",
                   "unsupported local RELEASE record type")
        relative = _safe_relative_path(record["path"], f"{path}.path").as_posix()
        _digest(record["sha256"], f"{path}.sha256")
        _text(record["source_identity"], f"{path}.source_identity")
        _text(
            record["native_owner_identity"],
            f"{path}.native_owner_identity")
        _currentness(record["currentness"], f"{path}.currentness")
        observed = file_facts.get(relative)
        if observed is None or observed.get("sha256") != record["sha256"]:
            _error("OE_RELEASE_LOCAL_DIGEST", f"{path}.sha256",
                   "local release fact does not match working-tree bytes")
        nodes.append({
            **record, "layer": "LOCAL", "family": "RELEASE",
            "authority_ceiling": "READ_ONLY_NATIVE_OBSERVATION",
            "manifest_sha256": local_manifest_sha256,
        })
        seen_ids.add(record_id)

    capture, capture_sha256 = read_fixed_json(
        "external-capture.json", "external release capture")
    capture_keys = {
        "schema", "capture_identity", "source_identity", "auth_state",
        "rate", "pagination", "object_drift", "captured_at", "expires_at",
        "evaluated_at", "records"}
    _object(
        capture, "$release.external", exact_keys=capture_keys,
        required=capture_keys)
    if capture["schema"] != "implementaudit-external-release-capture-v1":
        _error("OE_EXTERNAL_CAPTURE_INVALID", "$release.external.schema",
               "unsupported external capture schema")
    capture_identity = _text(
        capture["capture_identity"], "$release.external.capture_identity")
    external_source = _text(
        capture["source_identity"], "$release.external.source_identity")
    auth_state = capture["auth_state"]
    if auth_state not in ("PRESENT", "ABSENT", "UNKNOWN"):
        _error("OE_EXTERNAL_CAPTURE_INVALID", "$release.external.auth_state",
               "unsupported external auth state")
    rate = _object(
        capture["rate"], "$release.external.rate",
        exact_keys={"state", "remaining", "reset_at"},
        required={"state", "remaining", "reset_at"})
    if rate["state"] not in ("AVAILABLE", "EXHAUSTED", "UNKNOWN"):
        _error("OE_EXTERNAL_CAPTURE_INVALID", "$release.external.rate.state",
               "unsupported external rate state")
    if type(rate["remaining"]) is not int or rate["remaining"] < 0:
        _error("OE_EXTERNAL_CAPTURE_INVALID",
               "$release.external.rate.remaining",
               "rate remaining must be a non-negative integer")
    _utc_timestamp(rate["reset_at"], "$release.external.rate.reset_at")
    pagination = _object(
        capture["pagination"], "$release.external.pagination",
        exact_keys={"state", "pages"}, required={"state", "pages"})
    if pagination["state"] not in ("COMPLETE", "INCOMPLETE", "UNKNOWN"):
        _error("OE_EXTERNAL_CAPTURE_INVALID",
               "$release.external.pagination.state",
               "unsupported pagination state")
    if type(pagination["pages"]) is not int or pagination["pages"] < 1:
        _error("OE_EXTERNAL_CAPTURE_INVALID",
               "$release.external.pagination.pages",
               "pagination pages must be a positive integer")
    object_drift = _boolean(
        capture["object_drift"], "$release.external.object_drift")
    captured_at = _utc_timestamp(
        capture["captured_at"], "$release.external.captured_at")
    expires_at = _utc_timestamp(
        capture["expires_at"], "$release.external.expires_at")
    evaluated_at = _utc_timestamp(
        capture["evaluated_at"], "$release.external.evaluated_at")
    _validate_capture_chronology(
        captured_at, expires_at, evaluated_at, "$release.external")
    boundary_currentness = _external_boundary_currentness(
        auth_state, rate["state"], pagination["state"], object_drift,
        expires_at, evaluated_at)
    if type(capture["records"]) is not list:
        _error("OE_EXTERNAL_CAPTURE_INVALID", "$release.external.records",
               "must be an array")
    external_keys = {
        "id", "record_type", "stable_id", "commit_identity",
        "source_identity", "native_owner_identity", "updated_at", "etag",
        "payload_sha256", "currentness"}
    external_types = {
        "PullRequest", "Check", "Merge", "Tag", "Release", "Asset",
        "PublicSurface"}
    for index, source_record in enumerate(capture["records"]):
        path = f"$release.external.records[{index}]"
        record = _object(
            source_record, path, exact_keys=external_keys,
            required=external_keys)
        record_id = _text(record["id"], f"{path}.id")
        if record_id in seen_ids:
            _error("OE_EXTERNAL_CAPTURE_INVALID", f"{path}.id",
                   "release node id must be unique")
        if record["record_type"] not in external_types:
            _error("OE_EXTERNAL_CAPTURE_INVALID", f"{path}.record_type",
                   "unsupported external RELEASE record type")
        _text(record["stable_id"], f"{path}.stable_id")
        _git_object(record["commit_identity"], f"{path}.commit_identity")
        for key in ("source_identity", "native_owner_identity", "etag"):
            _text(record[key], f"{path}.{key}")
        _utc_timestamp(record["updated_at"], f"{path}.updated_at")
        _digest(record["payload_sha256"], f"{path}.payload_sha256")
        _currentness(record["currentness"], f"{path}.currentness")
        native_currentness = {
            "state": record["currentness"]["state"],
            "invalidators": list(record["currentness"]["invalidators"]),
        }
        capture_currentness = {
            "state": boundary_currentness["state"],
            "invalidators": list(boundary_currentness["invalidators"]),
        }
        currentness = _compose_currentness(
            native_currentness, capture_currentness)
        nodes.append({
            **record,
            "native_currentness": native_currentness,
            "capture_currentness": capture_currentness,
            "currentness": currentness, "layer": "EXTERNAL",
            "family": "RELEASE",
            "authority_ceiling": "READ_ONLY_NATIVE_OBSERVATION",
            "capture_identity": capture_identity,
            "capture_sha256": capture_sha256,
        })
        seen_ids.add(record_id)

    observed_types = {row["record_type"] for row in nodes}
    missing_types = sorted(_RELEASE_RECORD_TYPES_V1 - observed_types)
    candidate = _release_candidate_v1(
        repository, nodes, boundary_currentness, missing_types)

    type_census = Counter(row["record_type"] for row in nodes)
    nodes.sort(key=lambda row: (row["layer"], row["record_type"], row["id"]))
    result = {
        "schema": RELEASE_COLLECTION_SCHEMA,
        "families": ["RELEASE"],
        "repository": {
            "commit": repository["commit"], "tree": repository["tree"],
            "worktree_state": repository["worktree_state"],
        },
        "local_manifest_sha256": local_manifest_sha256,
        "external_capture_sha256": capture_sha256,
        "external_boundary": {
            "capture_identity": capture_identity,
            "source_identity": external_source,
            "auth_state": auth_state,
            "rate_state": rate["state"],
            "rate_remaining": rate["remaining"],
            "pagination_state": pagination["state"],
            "pagination_pages": pagination["pages"],
            "object_drift": object_drift,
            "captured_at": captured_at, "expires_at": expires_at,
            "evaluated_at": evaluated_at,
        },
        "omissions": _release_omissions_v1(missing_types),
        "node_type_census": {
            key: type_census[key] for key in sorted(_RELEASE_RECORD_TYPES_V1)},
        "nodes": nodes,
        "candidate": candidate,
        "establishes": [],
    }
    result["semantic_sha256"] = hashlib.sha256(
        canonical_json_v1(result)).hexdigest()
    immutable_result = decode_strict_json_bytes(
        canonical_json_v1(result), "release collection")
    return immutable_result


def _snapshot_stage_v1(stage: str) -> None:
    """Internal fault boundary; tests may replace this no-op, callers may not."""
    del stage


def _snapshot_is_link_v1(path: pathlib.Path) -> bool:
    try:
        metadata = os.lstat(path)
    except OSError:
        return False
    return (stat.S_ISLNK(metadata.st_mode) or
            bool(getattr(metadata, "st_file_attributes", 0) &
                 getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)))


def _snapshot_read_regular_v1(
        path: pathlib.Path, root: pathlib.Path, code: str,
        *, maximum: int = 16 * 1024 * 1024) -> bytes:
    try:
        root_absolute = pathlib.Path(os.path.abspath(root))
        path_absolute = pathlib.Path(os.path.abspath(path))
        relative = path_absolute.relative_to(root_absolute)
        cursor = root_absolute
        if _snapshot_is_link_v1(cursor) or not cursor.is_dir():
            _error(code, "$snapshot", "snapshot custody root is not a physical directory")
        for component in relative.parts:
            if component in {"", ".", ".."}:
                _error(code, "$snapshot", "snapshot path is not canonical")
            cursor = cursor / component
            if _snapshot_is_link_v1(cursor):
                _error(code, "$snapshot", "snapshot path crosses a link or reparse point")
        metadata = os.lstat(path_absolute)
        if (not stat.S_ISREG(metadata.st_mode) or metadata.st_nlink != 1 or
                metadata.st_size > maximum):
            _error(code, "$snapshot", "snapshot member is not one bounded physical file")
        raw = (_read_repository_path(path_absolute, root=root_absolute, maximum=maximum)[0]
               if os.name == "posix" else path_absolute.read_bytes())
        if len(raw) != metadata.st_size:
            _error(code, "$snapshot", "snapshot member changed during read")
        return raw
    except OperationalEvidenceError:
        raise
    except (OSError, ValueError):
        _error(code, "$snapshot", "snapshot member is unreadable or outside custody")


def _snapshot_decode_canonical_object_v1(raw: bytes, code: str) -> dict:
    value = decode_strict_json_bytes(raw, "operational snapshot")
    if type(value) is not dict or canonical_json_v1(value) != raw:
        _error(code, "$snapshot", "snapshot JSON is not one exact canonical object")
    return value


def _snapshot_write_new_file_v1(path: pathlib.Path, raw: bytes) -> None:
    try:
        with path.open("xb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
    except OSError:
        _error("OE_SNAPSHOT_WRITE_FAILED", "$snapshot",
               "immutable snapshot member could not be durably created")


def _snapshot_portable_native_v1(native: dict) -> dict:
    """Remove volatile checkout spelling while retaining owner-native identity."""
    repository_root = pathlib.Path(native["repository"]["root"])
    common_root = pathlib.Path(native["repository"]["git_common_dir"])
    run_relative = pathlib.PurePosixPath(native["claim"]["run_root"])
    run_root = repository_root.joinpath(*run_relative.parts)

    def spellings(path):
        return {str(path), os.fspath(path), path.as_posix(),
                str(path.resolve()), path.resolve().as_posix()}

    replacements = {}
    for spelling in spellings(repository_root):
        replacements[spelling] = "$REPOSITORY_ROOT"
    for spelling in spellings(common_root):
        replacements[spelling] = "$GIT_COMMON_DIR"
    for spelling in spellings(run_root):
        replacements[spelling] = "$RUN_ROOT"

    def replace(value):
        if type(value) is dict:
            return {key: item if key in {"route_graph", "route_relation", "canonical_work_graph", "native_episode"}
                    else replace(item) for key, item in value.items()
                    if key != "semantic_sha256"}
        if type(value) is list:
            return [replace(item) for item in value]
        if type(value) is str:
            return replacements.get(value, value)
        return value

    result = replace(native)
    result["semantic_sha256"] = hashlib.sha256(
        canonical_json_v1(result)).hexdigest()
    return result


def _snapshot_optional_collection_v1(owner: str, action) -> dict:
    try:
        value = action()
    except OperationalEvidenceError as exc:
        if exc.code not in {"OE_RUN_ARTIFACT_MISSING", "OE_RELEASE_ARTIFACT_MISSING"}:
            raise
        value = {"code": exc.code, "path": exc.path}
        return {
            "owner": owner, "state": "UNKNOWN", "value": value,
            "sha256": hashlib.sha256(canonical_json_v1(value)).hexdigest()}
    return {
        "owner": owner, "state": "CURRENT", "value": value,
        "sha256": hashlib.sha256(canonical_json_v1(value)).hexdigest()}


def _collect_snapshot_inputs_v1(native: dict) -> dict:
    return _capture_snapshot_inputs_v1(native)[0]


def _capture_snapshot_inputs_v1(native):
    """Keep pure repository reuse inside this one input-observation transaction."""
    repository_root = pathlib.Path(native["repository"]["root"])
    run_relative = pathlib.PurePosixPath(native["claim"]["run_root"])
    run_root = repository_root.joinpath(*run_relative.parts)
    repository_observation = _SELECTED_REPOSITORY_READ_V1.get()
    if repository_observation is None:
        repository, reobserve_repository = _collect_repository_observation_v1(repository_root)
    else:
        if type(repository_observation) is not _SelectedRepositoryReadV1:
            _error("OE_SNAPSHOT_INPUT_CHANGED", "$snapshot.repository", "unowned repository observation")
        repository, reobserve_repository = repository_observation.take(repository_root)
    repository_raw = canonical_json_v1(repository)

    def collect(observed_native, *, initial=False):
        # This private immutable baseline was derived live by C02. Optional
        # collectors consume a fresh copy; only the final fresh-byte fence
        # qualifies the combined result, including missing optional owners.
        observed_repository = decode_strict_json_bytes(repository_raw, "snapshot repository baseline")
        collections = {
            "native_current": {
                "owner": "R0038-C03", "state": "CURRENT",
                "value": _snapshot_portable_native_v1(observed_native)},
            "repository": {
                "owner": "R0038-C02", "state": "CURRENT", "value": observed_repository},
            "evidence_failure": _snapshot_optional_collection_v1(
                "R0038-C04", lambda: collect_evidence_failure(run_root)),
            "release": _snapshot_optional_collection_v1(
                "R0038-C05", lambda: _derive_release_from_repository_v1(repository_root, observed_repository)),
        }
        for row in collections.values():
            row.setdefault(
                "sha256", hashlib.sha256(canonical_json_v1(row["value"])).hexdigest())
        failure_code = ("OE_RELEASE_CHANGED_DURING_SCAN" if initial and collections["release"]["state"] == "CURRENT"
                        else "OE_SNAPSHOT_INPUT_CHANGED")
        try:
            after = reobserve_repository()
        except OperationalEvidenceError as exc:
            if exc.code != "OE_REPOSITORY_CHANGED_DURING_SCAN":
                raise
            _error(failure_code, "$snapshot.input_fence", "repository changed during optional collection")
        if after != observed_repository:
            _error(failure_code, "$snapshot.input_fence", "repository baseline changed during optional collection")
        return collections

    def reobserve(observed_native):
        if (pathlib.Path(observed_native["repository"]["root"]) != repository_root or
                pathlib.PurePosixPath(observed_native["claim"]["run_root"]) != run_relative):
            _error("OE_SNAPSHOT_INPUT_CHANGED", "$snapshot.input_fence",
                   "repository or run-root custody changed during collection")
        try:
            return collect(observed_native)
        except OperationalEvidenceError as exc:
            if exc.code not in {"OE_REPOSITORY_CHANGED_DURING_SCAN", "OE_RELEASE_CHANGED_DURING_SCAN"}:
                raise
            _error("OE_SNAPSHOT_INPUT_CHANGED", "$snapshot.input_fence",
                   "repository or collector input drifted")

    return collect(native, initial=True), reobserve


def _snapshot_missing_census_v1(collections: dict) -> list[dict]:
    missing = []
    native = collections["native_current"]["value"]
    if native.get("schema") in NATIVE_ROUTE_SCHEMAS and native.get("route_relation") is None:
        missing.append({"kind": "NATIVE_CAPABILITY_UNVERIFIED", "collector": "native_current",
            "owner": "R0033/R0035", "state": "UNVERIFIED",
            "code": "NATIVE_ROUTE_NODE_MAPPING_UNAVAILABLE"})
    elif native.get("schema") in NATIVE_ROUTE_SCHEMAS:
        for scope in native["route_relation"]["uncovered_scopes"]:
            missing.append({"kind": "NATIVE_CAPABILITY_UNVERIFIED", "collector": "native_current",
                "owner": "R0033/R0035", "state": "UNVERIFIED",
                "code": "NATIVE_ROUTE_SCOPE_UNCOVERED", "scope": scope})
    if native.get("schema") == NATIVE_CURRENT_SCHEMA:
        wrapped = native.get("native_episode")
        episode = wrapped["value"] if wrapped is not None else None
        if episode is None or episode["status"] != "AVAILABLE":
            missing.append({"kind": "NATIVE_CAPABILITY_UNVERIFIED", "collector": "native_current",
                "owner": "R003A/continuity", "state": "UNVERIFIED", "code": "NATIVE_EPISODE_UNAVAILABLE"})
        elif (episode["schema"] == "implementaudit.ordinary-episode-export.v1" or
              episode["lifecycle"]["h0"]["status"] != "RECORDED"):
            missing.append({"kind": "NATIVE_CAPABILITY_UNVERIFIED", "collector": "native_current",
                "owner": "R003A/continuity", "state": "UNVERIFIED", "code": "NATIVE_H0_LIFECYCLE_UNAVAILABLE"})
        if (episode is not None and episode["status"] == "AVAILABLE" and
                episode["schema"] != "implementaudit.ordinary-episode-export.v1"):
            for boundary in episode["pending"]["observations"]:
                if boundary["kind"] != "COMPLETED_RESUMED_BOUNDARY":
                    missing.append({"kind": "NATIVE_CAPABILITY_UNVERIFIED", "collector": "native_current",
                        "owner": "R003A/continuity", "state": "UNVERIFIED",
                        "code": "NATIVE_PENDING_BOUNDARY_UNVERIFIED", "scope": boundary["id"]})
    for name in sorted(collections):
        row = collections[name]
        if row["state"] != "CURRENT":
            missing.append({
                "kind": "COLLECTOR_NON_CURRENT", "collector": name,
                "owner": row["owner"], "state": row["state"],
                "code": row["value"].get("code")})
    repository = collections["repository"]["value"]
    for bucket in ("errors", "unknown"):
        for value in repository.get("diagnostics", {}).get(bucket, []):
            missing.append({
                "kind": "REPOSITORY_DIAGNOSTIC", "collector": "repository",
                "owner": collections["repository"]["owner"],
                "state": "UNKNOWN", "code": f"{bucket}:{value}"})

    evidence_failure = collections["evidence_failure"]
    if evidence_failure["state"] == "CURRENT":
        for bucket in ("evidence_records", "failure_records"):
            for record in evidence_failure["value"].get(bucket, []):
                currentness = record["currentness"]
                if currentness["state"] == "CURRENT":
                    continue
                missing.append({
                    "kind": "OWNER_FACT_NON_CURRENT",
                    "collector": "evidence_failure",
                    "owner": evidence_failure["owner"],
                    "family": record["family"],
                    "fact_path": f"{bucket}/{record['id']}",
                    "record_id": record["id"],
                    "record_type": record["record_type"],
                    "native_owner_identity": record["native_owner_identity"],
                    "state": currentness["state"],
                    "invalidators": list(currentness["invalidators"]),
                })

    release = collections["release"]
    if release["state"] == "CURRENT":
        for record in release["value"].get("nodes", []):
            currentness = record["currentness"]
            if currentness["state"] == "CURRENT":
                continue
            missing.append({
                "kind": "OWNER_FACT_NON_CURRENT",
                "collector": "release",
                "owner": release["owner"],
                "family": record["family"],
                "layer": record["layer"],
                "fact_path": f"nodes/{record['id']}",
                "record_id": record["id"],
                "record_type": record["record_type"],
                "native_owner_identity": record["native_owner_identity"],
                "state": currentness["state"],
                "invalidators": list(currentness["invalidators"]),
            })
        for value in release["value"].get("candidate", {}).get("invalidators", []):
            missing.append({
                "kind": "RELEASE_INVALIDATOR", "collector": "release",
                "owner": release["owner"],
                "state": release["value"]["candidate"].get("state", "UNVERIFIED"),
                "code": value})
    return sorted(missing, key=canonical_json_v1)


def _snapshot_input_manifest_v1(collections: dict, schema_sha256: str,
                                compiler_sha256: str) -> dict:
    native = collections["native_current"]["value"]
    missing = _snapshot_missing_census_v1(collections)
    return {
        "schema_version": SNAPSHOT_INPUT_SCHEMA,
        "compiler_sha256": compiler_sha256,
        "schema_sha256": schema_sha256,
        "current_tuple": {
            "controller_id": native["controller"]["id"],
            "claim_id": native["claim"]["id"],
            "run_id": native["claim"]["run_id"],
            "source_epoch": native["continuity"]["source_epoch"],
            "source_pointer_oid": native["continuity"]["pointer_oid"],
            "hot_state_sha256": native["hot"]["state_sha256"],
            "hot_roadmap_sha256": native["hot"]["roadmap_sha256"],
            "work_graph_sha256": native["hot"]["work_graph_sha256"],
            "route_identity": native["route"]["record_identity"],
        },
        "collector_inputs": [
            {"name": name, "owner": row["owner"], "state": row["state"],
             "sha256": row["sha256"]}
            for name, row in sorted(collections.items())],
        "native_semantic_sha256": native["semantic_sha256"],
        "missing_or_omitted_state": missing,
    }


def _snapshot_identity_record_v1(semantic: dict, input_manifest: dict) -> dict:
    return {
        "domain": "IA-OPERATIONAL-SNAPSHOT-v1", "encoding": "UTF-8",
        "canonicalisation": "canonical_json_v1",
        "semantic_payload_sha256": hashlib.sha256(canonical_json_v1(semantic)).hexdigest(),
        "canonical_input_manifest_sha256": hashlib.sha256(canonical_json_v1(input_manifest)).hexdigest(),
        "schema_sha256": input_manifest["schema_sha256"],
        "compiler_contract_sha256": hashlib.sha256(canonical_json_v1(SNAPSHOT_COMPILER_CONTRACT)).hexdigest(),
        "compiler_blob_sha256": input_manifest["compiler_sha256"],
    }


def _build_snapshot_material_v1(
        native: dict, collections: dict, schema_raw: bytes,
        compiler_raw: bytes) -> dict:
    missing = _snapshot_missing_census_v1(collections)
    aggregate = "DEGRADED" if missing else "COMPLETE"
    input_manifest = _snapshot_input_manifest_v1(collections,
        hashlib.sha256(schema_raw).hexdigest(), hashlib.sha256(compiler_raw).hexdigest())
    input_raw = canonical_json_v1(input_manifest)
    payload = {
        "schema_version": SNAPSHOT_PAYLOAD_SCHEMA,
        "aggregate": aggregate,
        "families": list(FAMILIES),
        "missing_or_omitted_state": missing,
        "collections": {name: row for name, row in sorted(collections.items())},
    }
    identity_record = _snapshot_identity_record_v1(payload, input_manifest)
    snapshot_digest = hashlib.sha256(canonical_json_v1(identity_record)).hexdigest()
    snapshot_id = "iasnap-v1-" + snapshot_digest
    payload.update(snapshot_id=snapshot_id, input_manifest=input_manifest,
                   input_manifest_sha256=hashlib.sha256(input_raw).hexdigest(),
                   identity_record=identity_record)
    payload_raw = canonical_json_v1(payload)
    root_identity = "sha256:" + hashlib.sha256(canonical_json_v1({
        "controller_id": native["controller"]["id"],
        "claim_id": native["claim"]["id"],
        "run_id": native["claim"]["run_id"],
    })).hexdigest()
    evidence_id = (
        "iasrc-v1-r0038-snapshot-" + snapshot_digest + "-operational-evidence")
    entry = {
        "source_evidence_id": evidence_id,
        "sha256": hashlib.sha256(payload_raw).hexdigest(),
        "kind": "run-root-relative", "root_identity": root_identity,
        "host_identity": None, "input_path_flavor": "posix",
        "source_locator": {
            "kind": "run-root-relative", "root_identity": root_identity,
            "path": (
                f"operational-evidence/snapshots/{snapshot_id}/snapshot.json"),
            "host_identity": None,
        },
    }
    manifest = {
        "schema_version": SNAPSHOT_MANIFEST_SCHEMA,
        "controller_id": native["controller"]["id"],
        "claim_id": native["claim"]["id"],
        "run_id": native["claim"]["run_id"],
        "source_epoch": native["continuity"]["source_epoch"],
        "source_pointer_oid": native["continuity"]["pointer_oid"],
        "source_evidence_entries": [entry],
    }
    manifest_raw = canonical_json_v1(manifest)
    current = {
        "schema_version": SNAPSHOT_CURRENT_SCHEMA,
        "snapshot_id": snapshot_id,
        "manifest_sha256": hashlib.sha256(manifest_raw).hexdigest(),
        "source_pointer_oid": native["continuity"]["pointer_oid"],
    }
    return {
        "snapshot_id": snapshot_id, "aggregate": aggregate,
        "evidence_id": evidence_id, "input_raw": input_raw,
        "payload_raw": payload_raw, "manifest_raw": manifest_raw,
        "current_raw": canonical_json_v1(current),
    }


def _snapshot_validate_owner_entry_v1(entry: object, snapshot_digest: str) -> None:
    if (type(entry) is not dict or set(entry) != SNAPSHOT_OWNER_ENTRY_KEYS or
            type(entry.get("source_evidence_id")) is not str or
            type(entry.get("sha256")) is not str or
            not re.fullmatch(r"[0-9a-f]{64}", entry["sha256"]) or
            entry.get("kind") != "run-root-relative" or
            type(entry.get("root_identity")) is not str or
            not re.fullmatch(r"sha256:[0-9a-f]{64}", entry["root_identity"]) or
            entry.get("host_identity") is not None or
            entry.get("input_path_flavor") != "posix"):
        _error("OE_SNAPSHOT_MANIFEST_INVALID", "$snapshot.manifest",
               "source-evidence entry is malformed")
    match = SNAPSHOT_EVIDENCE_ID_RE.fullmatch(entry["source_evidence_id"])
    locator = entry.get("source_locator")
    if (match is None or match.group(1) != snapshot_digest or
            type(locator) is not dict or set(locator) != {
                "kind", "root_identity", "path", "host_identity"} or
            locator.get("kind") != entry["kind"] or
            locator.get("root_identity") != entry["root_identity"] or
            locator.get("host_identity") is not None or
            locator.get("path") != (
                f"operational-evidence/snapshots/iasnap-v1-{snapshot_digest}/"
                "snapshot.json")):
        _error("OE_SNAPSHOT_MANIFEST_INVALID", "$snapshot.manifest",
               "source-evidence entry does not bind this snapshot")


def _snapshot_validate_manifest_v1(raw: bytes, snapshot_id: str) -> dict:
    value = _snapshot_decode_canonical_object_v1(
        raw, "OE_SNAPSHOT_MANIFEST_INVALID")
    if (set(value) != SNAPSHOT_MANIFEST_KEYS or
            value.get("schema_version") != SNAPSHOT_MANIFEST_SCHEMA or
            not SNAPSHOT_ID_RE.fullmatch(snapshot_id) or
            type(value.get("controller_id")) is not str or
            not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,47}", value["controller_id"]) or
            type(value.get("claim_id")) is not str or
            not re.fullmatch(r"[0-9a-f]{32}", value["claim_id"]) or
            type(value.get("run_id")) is not str or
            not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", value["run_id"]) or
            type(value.get("source_epoch")) is not str or
            not re.fullmatch(r"G[0-9A-F]{4}", value["source_epoch"]) or
            type(value.get("source_pointer_oid")) is not str or
            not re.fullmatch(
                r"(?:[0-9a-f]{40}|[0-9a-f]{64})", value["source_pointer_oid"]) or
            type(value.get("source_evidence_entries")) is not list or
            not value["source_evidence_entries"]):
        _error("OE_SNAPSHOT_MANIFEST_INVALID", "$snapshot.manifest",
               "snapshot owner manifest has the wrong schema or key set")
    identities = set()
    digest = snapshot_id.removeprefix("iasnap-v1-")
    for entry in value["source_evidence_entries"]:
        _snapshot_validate_owner_entry_v1(entry, digest)
        identity = entry["source_evidence_id"]
        if identity in identities:
            _error("OE_SNAPSHOT_MANIFEST_INVALID", "$snapshot.manifest",
                   "source-evidence identities must be unique")
        identities.add(identity)
    return value


def _snapshot_validate_current_v1(
        raw: bytes, snapshots: pathlib.Path) -> dict:
    value = _snapshot_decode_canonical_object_v1(
        raw, "OE_SNAPSHOT_CURRENT_INVALID")
    if (set(value) != SNAPSHOT_CURRENT_KEYS or
            value.get("schema_version") != SNAPSHOT_CURRENT_SCHEMA or
            type(value.get("snapshot_id")) is not str or
            not SNAPSHOT_ID_RE.fullmatch(value["snapshot_id"]) or
            type(value.get("manifest_sha256")) is not str or
            not re.fullmatch(r"[0-9a-f]{64}", value["manifest_sha256"]) or
            type(value.get("source_pointer_oid")) is not str or
            not re.fullmatch(
                r"(?:[0-9a-f]{40}|[0-9a-f]{64})", value["source_pointer_oid"])):
        _error("OE_SNAPSHOT_CURRENT_INVALID", "$snapshot.CURRENT",
               "CURRENT has the wrong schema, key set, or identity")
    manifest_path = snapshots / value["snapshot_id"] / "manifest.json"
    manifest_raw = _snapshot_read_regular_v1(
        manifest_path, snapshots, "OE_SNAPSHOT_CURRENT_INVALID")
    if hashlib.sha256(manifest_raw).hexdigest() != value["manifest_sha256"]:
        _error("OE_SNAPSHOT_CURRENT_INVALID", "$snapshot.CURRENT",
               "CURRENT does not bind its immutable manifest")
    manifest = _snapshot_validate_manifest_v1(manifest_raw, value["snapshot_id"])
    if manifest["source_pointer_oid"] != value["source_pointer_oid"]:
        _error("OE_SNAPSHOT_CURRENT_INVALID", "$snapshot.CURRENT",
               "CURRENT and manifest pointer identities disagree")
    run_root = snapshots.parents[1]
    for entry in manifest["source_evidence_entries"]:
        relative = pathlib.PurePosixPath(entry["source_locator"]["path"])
        source_path = run_root.joinpath(*relative.parts)
        source_raw = _snapshot_read_regular_v1(
            source_path, run_root, "OE_SNAPSHOT_CURRENT_INVALID")
        if hashlib.sha256(source_raw).hexdigest() != entry["sha256"]:
            _error("OE_SNAPSHOT_CURRENT_INVALID", "$snapshot.CURRENT",
                   "CURRENT-selected source evidence does not match its digest")
    return value


def _snapshot_current_raw_v1(snapshots: pathlib.Path) -> bytes | None:
    current = snapshots / "CURRENT"
    if not current.exists() and not current.is_symlink():
        return None
    raw = _snapshot_read_regular_v1(
        current, snapshots, "OE_SNAPSHOT_CURRENT_INVALID", maximum=64 * 1024)
    _snapshot_validate_current_v1(raw, snapshots)
    return raw


def _snapshot_verify_materialization_v1(
        snapshot_dir: pathlib.Path, expected: dict[str, bytes],
        snapshot_id: str) -> None:
    try:
        if (_snapshot_is_link_v1(snapshot_dir) or not snapshot_dir.is_dir() or
                {path.name for path in snapshot_dir.iterdir()} != set(expected)):
            _error("OE_SNAPSHOT_IMMUTABLE_MISMATCH", "$snapshot",
                   "immutable snapshot population differs from the candidate")
    except OSError:
        _error("OE_SNAPSHOT_IMMUTABLE_MISMATCH", "$snapshot",
               "immutable snapshot population cannot be enumerated")
    for name, raw in expected.items():
        if _snapshot_read_regular_v1(
                snapshot_dir / name, snapshot_dir,
                "OE_SNAPSHOT_IMMUTABLE_MISMATCH") != raw:
            _error("OE_SNAPSHOT_IMMUTABLE_MISMATCH", "$snapshot",
                   "immutable snapshot bytes differ from the candidate")
    _snapshot_validate_manifest_v1(expected["manifest.json"], snapshot_id)


def _snapshot_cleanup_pending_v1(path: pathlib.Path | None) -> None:
    if path is None or not path.exists():
        return
    try:
        members = {member.name: member for member in path.iterdir()}
        if set(members) - {"input-manifest.json", "snapshot.json", "manifest.json"}:
            _error("OE_SNAPSHOT_CLEANUP_REFUSED", "$snapshot.pending",
                   "pending directory contains non-task-owned residue")
        for member in members.values():
            if _snapshot_is_link_v1(member) or not member.is_file():
                _error("OE_SNAPSHOT_CLEANUP_REFUSED", "$snapshot.pending",
                       "pending directory contains a non-file member")
            member.unlink()
        path.rmdir()
    except OperationalEvidenceError:
        raise
    except OSError:
        _error("OE_SNAPSHOT_CLEANUP_REFUSED", "$snapshot.pending",
               "pending task-owned snapshot residue needs reconciliation")


def _snapshot_require_input_fence_v1(
        compiler_path: pathlib.Path, schema_path: pathlib.Path,
        snapshots: pathlib.Path, compiler_raw: bytes, schema_raw: bytes,
        native: dict, collections: dict, before_current: bytes | None,
        reobserve_inputs) -> None:
    final_compiler = _native_file(
        compiler_path, "$snapshot.final_compiler", 2 * 1024 * 1024)
    final_schema = _native_file(
        schema_path, "$snapshot.final_schema", 512 * 1024)
    final_native = collect_native_current()
    final_collections = reobserve_inputs(final_native)
    if (compiler_raw != final_compiler or schema_raw != final_schema or
            canonical_json_v1(_snapshot_portable_native_v1(native)) !=
            canonical_json_v1(_snapshot_portable_native_v1(final_native)) or
            canonical_json_v1(collections) != canonical_json_v1(final_collections)):
        _error("OE_SNAPSHOT_INPUT_CHANGED", "$snapshot.input_fence",
               "a compiler, schema, native, route, graph, or collector input drifted")
    final_current = (_snapshot_current_raw_v1(snapshots)
                     if snapshots.exists() else None)
    if final_current != before_current:
        _error("OE_SNAPSHOT_CURRENT_CHANGED", "$snapshot.CURRENT",
               "CURRENT changed during the complete input fence")


def _snapshot_require_non_native_input_fence_v1(
        compiler_path, schema_path, snapshots, compiler_raw, schema_raw,
        native, collections, before_current, reobserve_inputs):
    """Close static inputs after the selected reader's native owner has closed.

    This private helper supplies no native proof. The no-argument selected
    reader owns that enclosing observation; the publisher uses the full fence.
    """
    final_compiler = _native_file(compiler_path, "$snapshot.final_compiler", 2 * 1024 * 1024)
    final_schema = _native_file(schema_path, "$snapshot.final_schema", 512 * 1024)
    final_collections = reobserve_inputs(native)
    if (compiler_raw != final_compiler or schema_raw != final_schema or
            canonical_json_v1(collections) != canonical_json_v1(final_collections)):
        _error("OE_SNAPSHOT_INPUT_CHANGED", "$snapshot.input_fence",
               "compiler, schema or collector input drifted after native observation")
    final_current = _snapshot_current_raw_v1(snapshots) if snapshots.exists() else None
    if final_current != before_current:
        _error("OE_SNAPSHOT_CURRENT_CHANGED", "$snapshot.CURRENT",
               "CURRENT changed during the complete input fence")


def publish_current_snapshot():
    """Compile and atomically select one native-custody R0038 snapshot."""
    source_repository = pathlib.Path(__file__).resolve().parents[1]
    common = _git_source_directories(source_repository)[1]
    lock = common / "implementaudit-r0038-snapshot-writer.lock"
    pending = None
    current_temp = None
    lock_held = False
    selection_replaced = False
    try:
        try:
            lock.mkdir()
            lock_held = True
        except OSError:
            _error("OE_SNAPSHOT_WRITER_BUSY", "$snapshot.writer",
                   "the single R0038 output-root writer is already held")
        _snapshot_stage_v1("writer-held")

        compiler_path = pathlib.Path(__file__).resolve()
        schema_path = compiler_path.parent.parent / "docs" / (
            "operational-evidence-schema.json")
        compiler_raw = _native_file(compiler_path, "$snapshot.compiler", 2 * 1024 * 1024)
        schema_raw = _native_file(schema_path, "$snapshot.schema", 512 * 1024)
        schema_value = decode_strict_json_bytes(schema_raw, "snapshot schema")
        if schema_value.get("x-immutable-snapshot-publication", {}).get(
                "schema") != SNAPSHOT_MANIFEST_SCHEMA:
            _error("OE_SNAPSHOT_SCHEMA_INVALID", "$snapshot.schema",
                   "schema does not admit the immutable snapshot contract")

        native = collect_native_current()
        repository_root = pathlib.Path(native["repository"]["root"])
        run_relative = pathlib.PurePosixPath(native["claim"]["run_root"])
        run_root = repository_root.joinpath(*run_relative.parts)
        snapshots = run_root / "operational-evidence" / "snapshots"
        if snapshots.exists() and (_snapshot_is_link_v1(snapshots) or not snapshots.is_dir()):
            _error("OE_SNAPSHOT_OUTPUT_INVALID", "$snapshot.output_root",
                   "snapshot output root is not one physical directory")
        before_current = (_snapshot_current_raw_v1(snapshots)
                          if snapshots.exists() else None)
        collections, reobserve_inputs = _capture_snapshot_inputs_v1(native)
        _snapshot_stage_v1("after-first-observation")

        _snapshot_require_input_fence_v1(
            compiler_path, schema_path, snapshots, compiler_raw, schema_raw,
            native, collections, before_current, reobserve_inputs)

        material = _build_snapshot_material_v1(
            native, collections, schema_raw, compiler_raw)
        if material["aggregate"] == "INVALID":
            _error("OE_SNAPSHOT_INVALID_AGGREGATE", "$snapshot.aggregate",
                   "INVALID input cannot be published")
        _snapshot_stage_v1("before-temp-creation")
        operational_root = run_root / "operational-evidence"
        operational_root.mkdir(exist_ok=True)
        if _snapshot_is_link_v1(operational_root) or not operational_root.is_dir():
            _error("OE_SNAPSHOT_OUTPUT_INVALID", "$snapshot.output_root",
                   "operational-evidence root is not one physical directory")
        snapshots.mkdir(exist_ok=True)
        if _snapshot_is_link_v1(snapshots) or not snapshots.is_dir():
            _error("OE_SNAPSHOT_OUTPUT_INVALID", "$snapshot.output_root",
                   "snapshot output root is not one physical directory")

        expected = {
            "input-manifest.json": material["input_raw"],
            "snapshot.json": material["payload_raw"],
            "manifest.json": material["manifest_raw"],
        }
        snapshot_dir = snapshots / material["snapshot_id"]
        if snapshot_dir.exists() or snapshot_dir.is_symlink():
            _snapshot_verify_materialization_v1(
                snapshot_dir, expected, material["snapshot_id"])
        else:
            pending = pathlib.Path(tempfile.mkdtemp(
                prefix=".pending-r0038-", dir=snapshots))
            _snapshot_stage_v1("after-temp-creation")
            for name in ("input-manifest.json", "snapshot.json", "manifest.json"):
                _snapshot_stage_v1("before-" + name)
                _snapshot_write_new_file_v1(pending / name, expected[name])
                _snapshot_stage_v1("after-" + name)
            _snapshot_verify_materialization_v1(
                pending, expected, material["snapshot_id"])
            _snapshot_stage_v1("after-manifest-reread")
            try:
                pending.rename(snapshot_dir)
            except OSError:
                _error("OE_SNAPSHOT_IMMUTABLE_MISMATCH", "$snapshot",
                       "immutable snapshot identity already has different custody")
            pending = None
            _snapshot_verify_materialization_v1(
                snapshot_dir, expected, material["snapshot_id"])

        if _snapshot_current_raw_v1(snapshots) != before_current:
            _error("OE_SNAPSHOT_CURRENT_CHANGED", "$snapshot.CURRENT",
                   "CURRENT changed immediately before atomic selection")
        _snapshot_stage_v1("before-current-temp")
        descriptor, current_name = tempfile.mkstemp(
            prefix=".CURRENT-r0038-", dir=snapshots)
        current_temp = pathlib.Path(current_name)
        try:
            with os.fdopen(descriptor, "wb") as stream:
                stream.write(material["current_raw"])
                stream.flush()
                os.fsync(stream.fileno())
        except OSError:
            _error("OE_SNAPSHOT_WRITE_FAILED", "$snapshot.CURRENT",
                   "CURRENT temporary sibling could not be durably written")
        _snapshot_stage_v1("after-current-temp")
        if _snapshot_read_regular_v1(
                current_temp, snapshots, "OE_SNAPSHOT_CURRENT_INVALID",
                maximum=64 * 1024) != material["current_raw"]:
            _error("OE_SNAPSHOT_CURRENT_INVALID", "$snapshot.CURRENT",
                   "CURRENT temporary sibling failed exact reread")
        _snapshot_stage_v1("before-current-replace")
        _snapshot_require_input_fence_v1(
            compiler_path, schema_path, snapshots, compiler_raw, schema_raw,
            native, collections, before_current, reobserve_inputs)
        _snapshot_verify_materialization_v1(
            snapshot_dir, expected, material["snapshot_id"])
        if _snapshot_read_regular_v1(
                current_temp, snapshots, "OE_SNAPSHOT_CURRENT_INVALID",
                maximum=64 * 1024) != material["current_raw"]:
            _error("OE_SNAPSHOT_CURRENT_INVALID", "$snapshot.CURRENT",
                   "CURRENT temporary sibling changed before atomic selection")
        try:
            os.replace(current_temp, snapshots / "CURRENT")
            current_temp = None
            selection_replaced = True
        except OSError:
            _error("OE_SNAPSHOT_WRITE_FAILED", "$snapshot.CURRENT",
                   "CURRENT atomic replacement failed")
        try:
            _snapshot_stage_v1("after-current-replace")
        except Exception:
            _error("OE_SNAPSHOT_PUBLICATION_UNKNOWN_EFFECT", "$snapshot.CURRENT",
                   "CURRENT replaced but post-selection completion is unknown")
        readback = _snapshot_current_raw_v1(snapshots)
        if readback != material["current_raw"]:
            _error("OE_SNAPSHOT_PUBLICATION_UNKNOWN_EFFECT", "$snapshot.CURRENT",
                   "post-selection readback did not match the candidate")
        _snapshot_verify_materialization_v1(
            snapshot_dir, expected, material["snapshot_id"])
        return {
            "schema": SNAPSHOT_PUBLICATION_SCHEMA,
            "snapshot_id": material["snapshot_id"],
            "aggregate": material["aggregate"],
            "manifest_sha256": hashlib.sha256(material["manifest_raw"]).hexdigest(),
            "current_sha256": hashlib.sha256(material["current_raw"]).hexdigest(),
            "source_evidence_ids": [material["evidence_id"]],
            "selection_state": (
                "UNCHANGED" if before_current == material["current_raw"] else "ADVANCED"),
            "authority_ceiling": "R0038_OUTPUT_ROOT_ONLY",
            "establishes": [],
        }
    except OperationalEvidenceError:
        raise
    except Exception:
        if selection_replaced:
            _error("OE_SNAPSHOT_PUBLICATION_UNKNOWN_EFFECT", "$snapshot.CURRENT",
                   "publication failed after atomic selection")
        _error("OE_SNAPSHOT_PUBLICATION_FAILED", "$snapshot",
               "snapshot publication failed before atomic selection")
    finally:
        if current_temp is not None:
            try:
                current_temp.unlink(missing_ok=True)
            except OSError:
                pass
        if pending is not None:
            _snapshot_cleanup_pending_v1(pending)
        if lock_held:
            try:
                lock.rmdir()
            except OSError:
                if sys.exc_info()[0] is None:
                    _error("OE_SNAPSHOT_CLEANUP_REFUSED", "$snapshot.writer",
                           "writer lock residue needs manual reconciliation")


def _native_external_get(url, headers):
    """Perform the runner's concrete GET-only network operation."""
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, response_headers, newurl):
            return None

    request = urllib.request.Request(url, headers=headers, method="GET")
    try:
        response = urllib.request.build_opener(NoRedirect()).open(request, timeout=30)
    except urllib.error.HTTPError as exc:
        response = exc
    try:
        raw_headers = {}
        seen_headers = set()
        for key, value in response.headers.raw_items():
            normalized = key.lower()
            # Only these fields enter capture identity/currentness. Unconsumed
            # transport metadata (including OAuth client hints) grants no facts.
            if normalized not in {"etag", "x-ratelimit-remaining", "x-ratelimit-reset", "link"}:
                continue
            if normalized in seen_headers:
                _error("OE_EXTERNAL_RESPONSE", "$external.response.headers",
                       "response headers must not collide case-insensitively")
            seen_headers.add(normalized)
            raw_headers[key] = value
        body = response.read(16 * 1024 * 1024 + 1)
        if len(body) > 16 * 1024 * 1024:
            _error("OE_EXTERNAL_RESPONSE", "$external.response.body", "response exceeds bounded capture")
        return {
            "status": response.status,
            "headers": raw_headers,
            "body": body,
        }
    finally:
        response.close()


def _external_response_matches_v1(request, payload):
    """Bind response identity to the requested repository and operation."""
    if type(payload) is not dict:
        return False
    parts = request["path"].split("/")
    repo = "/".join(parts[1:4])
    api = "https://api.github.com/" + repo
    operation, selected = request["operation"], parts[-1]
    positive_id = lambda value: type(value) is int and value > 0
    oid = lambda value: type(value) is str and re.fullmatch(r"[0-9a-f]{40}", value) is not None
    if operation == "PULL_REQUEST":
        return (positive_id(payload.get("id")) and type(payload.get("number")) is int and
                payload["number"] == int(selected) and payload.get("url") == api + "/pulls/" + selected and
                payload.get("base", {}).get("repo", {}).get("full_name") == "/".join(parts[2:4]))
    if operation == "CHECK_RUNS":
        rows = payload.get("check_runs")
        return (type(rows) is list and type(payload.get("total_count")) is int and
                payload["total_count"] >= len(rows) and all(type(row) is dict and
                positive_id(row.get("id")) and row.get("url") == api + "/check-runs/" + str(row["id"]) and
                row.get("head_sha") == parts[-2] for row in rows) and
                len({row["id"] for row in rows}) == len(rows))
    if operation == "TAG":
        obj = payload.get("object", {})
        return (payload.get("ref") == "refs/tags/" + selected and
                payload.get("url") == api + "/git/refs/tags/" + selected and type(obj) is dict and
                obj.get("type") in {"commit", "tag"} and oid(obj.get("sha")))
    if operation == "RELEASE":
        return (positive_id(payload.get("id")) and payload.get("tag_name") == selected and
                payload.get("url") == api + "/releases/" + str(payload["id"]))
    if operation == "ASSET":
        return (positive_id(payload.get("id")) and payload["id"] == int(selected) and
                payload.get("url") == api + "/releases/assets/" + selected)
    if operation == "PUBLIC_READBACK":
        return (payload.get("type") == "file" and payload.get("path") == "/".join(parts[5:]) and
                payload.get("url") == "https://api.github.com" + request["path"] and oid(payload.get("sha")))
    return False


def run_external_readonly(request, transport=None, *, authorization_token=None):
    """Run one fixed allowlisted external GET and return a frozen capture."""
    request_keys = {
        "schema", "source", "operation", "path", "auth_state", "page",
        "per_page", "expected_etag", "captured_at", "expires_at",
        "evaluated_at"}
    if type(request) is not dict or set(request) != request_keys:
        _error("OE_EXTERNAL_REQUEST", "$external.request",
               "external request must use the exact read-only request keys")
    if request["schema"] != "implementaudit-external-read-request-v1":
        _error("OE_EXTERNAL_REQUEST", "$external.request.schema",
               "unsupported external request schema")
    if request["source"] != "GITHUB_API":
        _error("OE_EXTERNAL_REQUEST", "$external.request.source",
               "only the fixed GitHub API read source is supported")
    repository_path = r"/repos/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+"
    allowlist = {
        "PULL_REQUEST": repository_path + r"/pulls/[1-9]\d*",
        "CHECK_RUNS": (
            repository_path + r"/commits/[0-9a-f]{40}/check-runs"),
        "TAG": repository_path + r"/git/ref/tags/[A-Za-z0-9._-]+",
        "RELEASE": repository_path + r"/releases/tags/[A-Za-z0-9._-]+",
        "ASSET": repository_path + r"/releases/assets/[1-9]\d*",
        "PUBLIC_READBACK": repository_path + r"/contents/[A-Za-z0-9._/-]+",
    }
    pattern = allowlist.get(request["operation"])
    if (pattern is None or re.fullmatch(pattern, request["path"]) is None or
            ".." in pathlib.PurePosixPath(request["path"]).parts):
        _error("OE_EXTERNAL_REQUEST", "$external.request",
               "external request is outside the fixed read-only allowlist")
    auth_state = request["auth_state"]
    if auth_state not in ("PRESENT", "ABSENT", "UNKNOWN"):
        _error("OE_EXTERNAL_REQUEST", "$external.request.auth_state",
               "unsupported external auth state")
    page = request["page"]
    per_page = request["per_page"]
    if (type(page) is not int or page < 1 or type(per_page) is not int or
            per_page < 1 or per_page > 100):
        _error("OE_EXTERNAL_REQUEST", "$external.request",
               "page must be positive and per_page must be 1..100")
    expected_etag = request["expected_etag"]
    if expected_etag is not None:
        _text(expected_etag, "$external.request.expected_etag")
    captured_at = _utc_timestamp(
        request["captured_at"], "$external.request.captured_at")
    expires_at = _utc_timestamp(
        request["expires_at"], "$external.request.expires_at")
    evaluated_at = _utc_timestamp(
        request["evaluated_at"], "$external.request.evaluated_at")
    _validate_capture_chronology(
        captured_at, expires_at, evaluated_at, "$external.request")
    if transport is not None and not callable(transport):
        _error("OE_EXTERNAL_REQUEST", "$external.transport",
               "transport must be callable when supplied")
    if authorization_token is not None and (transport is not None or
            type(authorization_token) is not str or not re.fullmatch(r"[A-Za-z0-9_.-]{1,4096}", authorization_token)):
        _error("OE_EXTERNAL_REQUEST", "$external.authentication", "credential requires the fixed native transport")
    if transport is None:
        auth_state = "PRESENT" if authorization_token is not None else "ABSENT"
    url = (
        f"https://api.github.com{request['path']}?page={page}&per_page={per_page}")
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if authorization_token is not None:
        headers["Authorization"] = "Bearer " + authorization_token
    try:
        response = (
            _native_external_get(url, headers) if transport is None else
            transport(url, headers))
    except (OSError, TimeoutError):
        _error("OE_EXTERNAL_TRANSPORT", "$external.response",
               "external read transport failed")
    response = _object(
        response, "$external.response",
        exact_keys={"status", "headers", "body"},
        required={"status", "headers", "body"})
    status = response["status"]
    if type(status) is not int or status < 100 or status > 599:
        _error("OE_EXTERNAL_RESPONSE", "$external.response.status",
               "HTTP status must be an integer from 100 through 599")
    raw_headers = _object(response["headers"], "$external.response.headers")
    normalized_headers = {}
    for key, value in raw_headers.items():
        if type(key) is not str or type(value) is not str:
            _error("OE_EXTERNAL_RESPONSE", "$external.response.headers",
                   "response headers must be strings")
        normalized = key.lower()
        if normalized in normalized_headers:
            _error("OE_EXTERNAL_RESPONSE", "$external.response.headers",
                   "response headers must not collide case-insensitively")
        normalized_headers[normalized] = value
    body = response["body"]
    if type(body) is not bytes:
        _error("OE_EXTERNAL_RESPONSE", "$external.response.body",
               "response body must be bytes")
    payload = decode_strict_json_bytes(body, "external response")
    remaining_text = normalized_headers.get("x-ratelimit-remaining")
    try:
        rate_remaining = (
            int(remaining_text) if remaining_text is not None else None)
    except ValueError:
        _error("OE_EXTERNAL_RESPONSE", "$external.response.headers",
               "rate remaining header must be an integer")
    if rate_remaining is not None and rate_remaining < 0:
        _error("OE_EXTERNAL_RESPONSE", "$external.response.headers",
               "rate remaining header must be non-negative")
    reset_text = normalized_headers.get("x-ratelimit-reset")
    rate_reset_at = None
    if reset_text is not None:
        if not re.fullmatch(r"[0-9]{1,12}", reset_text) or int(reset_text) > 253402300799:
            _error("OE_EXTERNAL_RESPONSE", "$external.response.headers",
                   "rate reset header must be a bounded UTC epoch")
        rate_reset_at = (datetime.datetime(1970, 1, 1, tzinfo=datetime.timezone.utc) +
                         datetime.timedelta(seconds=int(reset_text))).strftime("%Y-%m-%dT%H:%M:%SZ")
    rate_state = (
        "EXHAUSTED" if status == 429 or rate_remaining == 0 else
        "AVAILABLE" if rate_remaining is not None else "UNKNOWN")
    link = normalized_headers.get("link", "")
    pagination_state = (
        "INCOMPLETE" if 'rel="next"' in link or page != 1 else "COMPLETE")
    if (request["operation"] == "CHECK_RUNS" and type(payload) is dict and
            type(payload.get("total_count")) is int and type(payload.get("check_runs")) is list and
            payload["total_count"] != len(payload["check_runs"])):
        pagination_state = "INCOMPLETE"
    actual_etag = normalized_headers.get("etag")
    object_drift = (
        expected_etag is not None and actual_etag != expected_etag)
    currentness = _external_boundary_currentness(
        auth_state, rate_state, pagination_state, object_drift,
        expires_at, evaluated_at)
    if 200 <= status < 300:
        try:
            object_matches = _external_response_matches_v1(request, payload)
        except (AttributeError, TypeError, ValueError, KeyError):
            object_matches = False
        if not object_matches:
            currentness = _compose_currentness(currentness, {
                "state": "CONTRADICTORY", "invalidators": ["RESPONSE_OBJECT_MISMATCH"]})
    if status in (401, 403):
        currentness = _compose_currentness(currentness, {
            "state": "UNVERIFIED", "invalidators": ["AUTH_REJECTED"]})
    if status < 200 or status >= 300:
        known = set(currentness["invalidators"])
        if status not in (401, 403, 429) or not known:
            currentness = _compose_currentness(currentness, {
                "state": "UNKNOWN", "invalidators": [f"HTTP_STATUS_{status}"]})
    injected_transport = transport is not None
    if injected_transport:
        currentness = {
            "state": ("UNVERIFIED" if currentness["state"] == "CURRENT" else
                      currentness["state"]),
            "invalidators": [*currentness["invalidators"],
                             "UNTRUSTED_INJECTED_TRANSPORT"],
        }
    result = {
        "schema": EXTERNAL_READ_CAPTURE_SCHEMA,
        "authority_ceiling": "READ_ONLY_EXTERNAL_CAPTURE",
        "establishes": [],
        "boundary": {
            "method": "UNVERIFIED" if injected_transport else "GET",
            "network_used": True,
            "write_verb_exposed": (
                "UNKNOWN" if injected_transport else False),
            "transport_trust": (
                "UNTRUSTED_INJECTED" if injected_transport else
                "NATIVE_FIXED_GET"),
        },
        "request": {
            "source": request["source"], "operation": request["operation"],
            "path": request["path"], "auth_state": auth_state,
            "page": page, "per_page": per_page,
            "expected_etag": expected_etag,
        },
        "response": {
            "status": status, "etag": actual_etag,
            "rate_remaining": rate_remaining, "rate_reset_at": rate_reset_at,
            "pagination": pagination_state,
            "body_sha256": hashlib.sha256(body).hexdigest(),
            "body_bytes": len(body),
        },
        "captured_at": captured_at, "expires_at": expires_at,
        "evaluated_at": evaluated_at, "currentness": currentness,
        "payload": payload,
    }
    result["semantic_sha256"] = hashlib.sha256(
        canonical_json_v1(result)).hexdigest()
    return decode_strict_json_bytes(
        canonical_json_v1(result), "external read capture")


def _validate_static_qualification(value, outcome):
    if outcome == "CURRENT":
        _error("OE_STATIC_QUALIFICATION_REQUIRED", "$static.qualification",
               "C02 has no native qualification owner for external CURRENT")
    if value is not None:
        _error("OE_STATIC_QUALIFICATION_UNTRUSTED", "$static.qualification",
               "caller-issued qualification has no authority in C02")
    return None


def _validate_static_receipt(value):
    _object(
        value, "$static", exact_keys={
            "schema", "outcome", "invalidators", "collector", "target", "scope",
            "diagnostics", "facts", "qualification"},
        required={
            "schema", "outcome", "invalidators", "collector", "target", "scope",
            "diagnostics", "facts"})
    if value["schema"] != STATIC_RECEIPT_SCHEMA:
        _error("OE_STATIC_RECEIPT_INVALID", "$static.schema",
               "unsupported static receipt schema")
    outcome = value["outcome"]
    if outcome not in STATIC_OUTCOMES:
        _error("OE_STATIC_RECEIPT_INVALID", "$static.outcome",
               "unsupported static outcome")
    invalidators = _string_list(
        value["invalidators"], "$static.invalidators", unique=False)
    if outcome == "CURRENT" and invalidators:
        _error("OE_STATIC_CURRENTNESS", "$static.invalidators",
               "CURRENT static receipt cannot retain an invalidator")
    if outcome == "STALE" and not invalidators:
        _error("OE_STATIC_CURRENTNESS", "$static.invalidators",
               "STALE static receipt must name an invalidator")
    collector = _object(
        value["collector"], "$static.collector", exact_keys={
            "identity", "version", "package_sha256", "invocation_identity",
            "output_schema_identity", "parser_mode", "configuration_sha256",
            "trust_mode", "executes_target_code", "auto_installs",
            "network_access"}, required={
            "identity", "version", "package_sha256", "invocation_identity",
            "output_schema_identity", "parser_mode", "configuration_sha256",
            "trust_mode", "executes_target_code", "auto_installs",
            "network_access"})
    for key in ("identity", "version", "invocation_identity",
                "output_schema_identity", "parser_mode", "trust_mode"):
        _text(collector[key], f"$static.collector.{key}")
    _digest(collector["package_sha256"], "$static.collector.package_sha256")
    _digest(
        collector["configuration_sha256"],
        "$static.collector.configuration_sha256")
    trust_effects = (
        _boolean(collector["executes_target_code"],
                 "$static.collector.executes_target_code"),
        _boolean(collector["auto_installs"], "$static.collector.auto_installs"),
        _boolean(collector["network_access"], "$static.collector.network_access"),
    )
    if any(trust_effects):
        _error("OE_STATIC_TRUST", "$static.collector",
               "C02 accepts only data-only, offline, pre-installed collectors")

    target = _object(
        value["target"], "$static.target", exact_keys={
            "repository_identity", "snapshot_identity", "commit", "tree",
            "worktree_state", "input_file_set_sha256", "physical_change"},
        required={
            "repository_identity", "snapshot_identity", "commit", "tree",
            "worktree_state", "input_file_set_sha256", "physical_change"})
    _text(target["repository_identity"], "$static.target.repository_identity")
    _text(target["snapshot_identity"], "$static.target.snapshot_identity")
    _git_object(target["commit"], "$static.target.commit")
    _git_object(target["tree"], "$static.target.tree")
    if target["worktree_state"] not in ("CLEAN", "DIRTY"):
        _error("OE_STATIC_RECEIPT_INVALID", "$static.target.worktree_state",
               "unsupported worktree state")
    _digest(
        target["input_file_set_sha256"],
        "$static.target.input_file_set_sha256")
    physical_change = _boolean(
        target["physical_change"], "$static.target.physical_change")
    if physical_change and outcome == "CURRENT":
        _error("OE_STATIC_STALE", "$static.target.physical_change",
               "physical change invalidates a CURRENT static receipt")

    scope_keys = {
        "applicable", "supported", "unsupported", "input_complete",
        "entrypoints_complete", "workspace_complete",
        "extension_resolution_complete", "dynamic_entrypoints_complete",
        "generated_policy_complete", "parser_complete"}
    scope = _object(
        value["scope"], "$static.scope", exact_keys=scope_keys,
        required=scope_keys)
    supported = _string_list(scope["supported"], "$static.scope.supported")
    unsupported = _string_list(
        scope["unsupported"], "$static.scope.unsupported")
    completeness_keys = (
        "applicable", "input_complete", "entrypoints_complete",
        "workspace_complete", "extension_resolution_complete",
        "dynamic_entrypoints_complete", "generated_policy_complete",
        "parser_complete")
    completeness = {
        key: _boolean(scope[key], f"$static.scope.{key}")
        for key in completeness_keys
    }

    diagnostics = _object(
        value["diagnostics"], "$static.diagnostics", exact_keys={
            "warnings", "errors", "skipped", "unknown"}, required={
            "warnings", "errors", "skipped", "unknown"})
    for key in ("warnings", "errors", "skipped", "unknown"):
        _string_list(
            diagnostics[key], f"$static.diagnostics.{key}", unique=False)
    if (outcome == "CURRENT" and
            (diagnostics["errors"] or diagnostics["skipped"] or
             not completeness["parser_complete"] or
             not completeness["applicable"])):
        _error("OE_STATIC_CURRENTNESS", "$static",
               "CURRENT static receipt cannot hide incomplete parser population")

    if type(value["facts"]) is not list:
        _error("OE_STATIC_RECEIPT_INVALID", "$static.facts",
               "must be an array")
    facts = []
    fact_ids = set()

    def fact_provenance():
        return {
            "collector_identity": collector["identity"],
            "collector_version": collector["version"],
            "collector_package_sha256": collector["package_sha256"],
            "invocation_identity": collector["invocation_identity"],
            "output_schema_identity": collector["output_schema_identity"],
            "parser_mode": collector["parser_mode"],
            "configuration_sha256": collector["configuration_sha256"],
            "target_snapshot_identity": target["snapshot_identity"],
            "input_file_set_sha256": target["input_file_set_sha256"],
        }

    for index, source_fact in enumerate(value["facts"]):
        path = f"$static.facts[{index}]"
        fact = _object(
            source_fact, path, exact_keys={
                "id", "kind", "polarity", "source", "target", "resolution",
                "state", "work_consequence", "mapping"}, required={
                "id", "kind", "polarity", "source", "target", "resolution",
                "state", "work_consequence", "mapping"})
        _text(fact["id"], f"{path}.id")
        if fact["id"] in fact_ids:
            _error("OE_STATIC_RECEIPT_INVALID", f"{path}.id",
                   "fact id must be unique")
        fact_ids.add(fact["id"])
        if fact["kind"] not in STATIC_FACT_KINDS:
            _error("OE_STATIC_RECEIPT_INVALID", f"{path}.kind",
                   "unsupported static fact kind")
        if fact["polarity"] not in ("POSITIVE", "NEGATIVE"):
            _error("OE_STATIC_RECEIPT_INVALID", f"{path}.polarity",
                   "unsupported fact polarity")
        _text(fact["source"], f"{path}.source")
        _text(fact["target"], f"{path}.target")
        if fact["resolution"] not in (
                "RESOLVED", "UNRESOLVED", "UNSUPPORTED", "PARTIAL"):
            _error("OE_STATIC_RECEIPT_INVALID", f"{path}.resolution",
                   "unsupported resolution")
        if fact["state"] not in STATIC_OUTCOMES:
            _error("OE_STATIC_RECEIPT_INVALID", f"{path}.state",
                   "unsupported fact state")
        if fact["work_consequence"] != "NONE":
            _error("OE_STATIC_AUTHORITY", f"{path}.work_consequence",
                   "source topology cannot create a work-DAG or lifecycle effect")
        mapping = fact["mapping"]
        if mapping is not None:
            _error("OE_STATIC_MAPPING_FORBIDDEN", f"{path}.mapping",
                   "C02 static facts cannot supply governed work-node mappings")
        if fact["kind"] in STATIC_NEGATIVE_KINDS:
            if (fact["polarity"] != "NEGATIVE" or unsupported or
                    not all(completeness.values())):
                _error("OE_STATIC_NEGATIVE_UNQUALIFIED", path,
                       "absence fact requires complete supported scope")
        if fact["kind"] in ("MODULE_EDGE", "REVERSE_DEPENDENT") and (
                fact["polarity"] != "POSITIVE" or
                fact["resolution"] != "RESOLVED"):
            _error("OE_STATIC_RECEIPT_INVALID", path,
                   "positive structural relation must be resolved")
        provenance = fact_provenance()
        facts.append({
            **fact,
            "state": (outcome if outcome != "CURRENT" and
                      fact["state"] == "CURRENT" else fact["state"]),
            "native_owner_identity": target["repository_identity"],
            "authority_ceiling": "READ_ONLY_STRUCTURAL_FACT",
            "provenance": provenance,
        })

    synthetic = {
        "PARSER_ERROR": "PARSER_ERROR_OBSERVATION",
        "UNSUPPORTED": "UNSUPPORTED_OBSERVATION",
        "UNSUPPORTED_LANGUAGE": "UNSUPPORTED_OBSERVATION",
        "NOT_INSTALLED": "TOOL_UNAVAILABLE_OBSERVATION",
        "TOOL_TIMEOUT": "TOOL_FAILURE_OBSERVATION",
        "TOOL_CRASH": "TOOL_FAILURE_OBSERVATION",
        "VERSION_MISMATCH": "TOOL_FAILURE_OBSERVATION",
        "TARGET_CONFIG_UNTRUSTED": "UNSUPPORTED_OBSERVATION",
    }
    if not facts and outcome in synthetic:
        facts.append({
            "id": f"synthetic:{collector['identity']}:{outcome.lower()}",
            "kind": synthetic[outcome], "polarity": "POSITIVE",
            "source": collector["identity"],
            "target": target["snapshot_identity"],
            "resolution": "UNSUPPORTED" if outcome != "PARSER_ERROR" else "PARTIAL",
            "state": outcome, "work_consequence": "NONE", "mapping": None,
            "native_owner_identity": target["repository_identity"],
            "authority_ceiling": "READ_ONLY_STRUCTURAL_FACT",
            "provenance": fact_provenance(),
        })
    if not facts:
        _error("OE_STATIC_EMPTY", "$static.facts",
               "static receipt must retain a fact or typed degradation")
    qualification = _validate_static_qualification(
        value.get("qualification"), outcome)
    normalized = {
        "schema": STATIC_NORMALIZED_SCHEMA,
        "normalization_identity": "canonical_json_v1",
        "outcome": outcome,
        "invalidators": sorted(invalidators),
        "qualification": {
            "collector": dict(collector), "target": dict(target),
            "scope": {**scope, "supported": list(supported),
                      "unsupported": list(unsupported)},
            "self_probe": qualification,
        },
        "diagnostics": {
            key: sorted(diagnostics[key])
            for key in ("warnings", "errors", "skipped", "unknown")
        },
        "facts": sorted(facts, key=lambda row: canonical_json_v1(row)),
    }
    normalized["semantic_sha256"] = hashlib.sha256(
        canonical_json_v1(normalized)).hexdigest()
    return normalized


def normalize_static_receipt(value):
    """Qualify one external static receipt without executing its collector."""
    if type(value) is not dict:
        _error("OE_STATIC_RECEIPT_INVALID", "$static", "must be an object")
    return _validate_static_receipt(json.loads(
        canonical_json_v1(value).decode("utf-8")))


def normalize_static_receipts(values):
    """Retain distinct provenance and surface opposite edge claims."""
    if type(values) is not list or not values:
        _error("OE_STATIC_RECEIPT_INVALID", "$static_set",
               "must be a non-empty array")
    receipts = [normalize_static_receipt(value) for value in values]
    target_identity = receipts[0]["qualification"]["target"]
    if any(receipt["qualification"]["target"] != target_identity
           for receipt in receipts[1:]):
        _error("OE_STATIC_SET_MISMATCH", "$static_set",
               "collector receipts must bind the same exact target snapshot")
    facts = [fact for receipt in receipts for fact in receipt["facts"]]
    positive_edges = {
        (fact["source"], fact["target"])
        for fact in facts
        if fact["kind"] == "MODULE_EDGE" and fact["polarity"] == "POSITIVE"
    }
    negative_edges = {
        (fact["source"], fact["target"])
        for fact in facts
        if fact["kind"] == "NO_EDGE" and fact["polarity"] == "NEGATIVE"
    }
    contradictions = [
        {"source": source, "target": target}
        for source, target in sorted(positive_edges & negative_edges)
    ]
    if contradictions:
        outcome = "CONTRADICTORY"
    elif len({receipt["outcome"] for receipt in receipts}) == 1:
        outcome = receipts[0]["outcome"]
    else:
        outcome = "PARTIAL"
    result = {
        "schema": STATIC_NORMALIZED_SET_SCHEMA,
        "normalization_identity": "canonical_json_v1", "outcome": outcome,
        "contradictions": contradictions,
        "facts": sorted(facts, key=lambda row: canonical_json_v1(row)),
        "receipt_sha256": sorted(
            receipt["semantic_sha256"] for receipt in receipts),
    }
    result["semantic_sha256"] = hashlib.sha256(
        canonical_json_v1(result)).hexdigest()
    return result


def _snapshot_diff_exact_object_v1(value: object, keys: set[str], path: str) -> dict:
    if type(value) is not dict or set(value) != keys:
        _error("OE_DIFF_SNAPSHOT_INVALID", path,
               "snapshot member does not match its exact producer schema")
    return value


def _snapshot_diff_text_v1(value: object, path: str) -> str:
    if type(value) is not str or not value:
        _error("OE_DIFF_SNAPSHOT_INVALID", path,
               "snapshot member text must be non-empty")
    return value


def _snapshot_diff_digest_v1(value: object, path: str) -> str:
    if type(value) is not str or re.fullmatch(r"[0-9a-f]{64}", value) is None:
        _error("OE_DIFF_SNAPSHOT_INVALID", path,
               "snapshot member digest must be lowercase SHA-256")
    return value


def _snapshot_diff_unique_string_list_v1(value: object, path: str) -> list[str]:
    index, violation = _string_list_violation_v1(value)
    if violation is not None:
        member_path = path if index is None else f"{path}[{index}]"
        _error("OE_DIFF_SNAPSHOT_INVALID", member_path,
               f"snapshot producer list {violation}")
    return value


def _snapshot_diff_currentness_v1(value: object, path: str) -> None:
    currentness = _snapshot_diff_exact_object_v1(
        value, {"state", "invalidators"}, path)
    state = currentness["state"]
    invalidators = currentness["invalidators"]
    _snapshot_diff_unique_string_list_v1(invalidators, f"{path}.invalidators")
    if (state not in STATES or (state == "CURRENT" and invalidators) or
            (state == "STALE" and not invalidators)):
        _error("OE_DIFF_SNAPSHOT_INVALID", path,
               "snapshot currentness state and invalidators are inconsistent")


def _snapshot_diff_semantic_v1(value: dict, path: str) -> None:
    digest = _snapshot_diff_digest_v1(
        value.get("semantic_sha256"), f"{path}.semantic_sha256")
    semantic = dict(value)
    semantic.pop("semantic_sha256")
    if hashlib.sha256(canonical_json_v1(semantic)).hexdigest() != digest:
        _error("OE_DIFF_SNAPSHOT_INVALID", path,
               "snapshot collection semantic digest differs")


def _snapshot_diff_keyset_v1(names: str) -> frozenset[str]:
    return frozenset(names.split())


# The closed-tree census and branch validators share these exact producer
# grammars. Every field remains explicit; no branch is admitted by inference.
_SNAPSHOT_NATIVE_MEMBER_KEYS_V1 = {
    "repository": frozenset({"root", "git_common_dir"}),
    "controller": frozenset({"id", "ref", "record_oid"}),
    "claim": frozenset({"id", "run_id", "run_root"}),
    "continuity": frozenset({
        "generation", "source_epoch", "invalidation_ref", "invalidation_oid",
        "boundary_kind", "boundary_event_id", "pointer_ref", "pointer_oid",
        "pointer_digest", "receipt_schema", "receipt_ref", "receipt_oid",
        "receipt", "marker_ref", "marker_oid", "generation_manifest_oid",
        "generation_manifest_digest", "cold_high_water", "degraded_state"}),
    "hot": frozenset({
        "state_path", "state_sha256", "roadmap_path", "roadmap_sha256",
        "work_graph_path", "work_graph_sha256", "work_graph_compiler_sha256"}),
    "frontier": frozenset({
        "population", "counts", "active", "ready", "blocked_summary",
        "writer_holds", "resource_holds", "digest"}),
    "route": frozenset({
        "controller_id", "controller_record_oid", "ref", "record_oid",
        "record_identity", "decision", "classification",
        "route_transaction_id", "obligation_id", "route_state"}),
}

_SNAPSHOT_REPOSITORY_FACT_KEYS_V1 = {
    "FILE": frozenset({"kind", "path", "sha256", "bytes", "file_type",
                       "language", "state", "provenance"}),
    "FILE_UNREADABLE_OBSERVATION": frozenset({"kind", "path", "state", "provenance"}),
    "FILE_EXCLUDED_OBSERVATION": frozenset({"kind", "path", "state", "provenance"}),
    "PARSER_ERROR_OBSERVATION": frozenset({"kind", "path", "state", "provenance"}),
    "PARSER_LIMIT_OBSERVATION": frozenset({"kind", "path", "state", "provenance"}),
    "PYTHON_IMPORT": frozenset({"kind", "source", "target", "state", "provenance"}),
    "PYTHON_REVERSE_DEPENDENT": frozenset({"kind", "source", "target", "state", "provenance"}),
    "UNSUPPORTED_IMPORT_OBSERVATION": frozenset({"kind", "source", "target", "state", "provenance"}),
    "PACKAGE_MANIFEST": frozenset({"kind", "path", "package_name", "sha256", "state", "provenance"}),
    "PACKAGE_ROOT": frozenset({"kind", "package_name", "path", "state", "provenance"}),
    "PACKAGE_MANIFEST_ERROR": frozenset({"kind", "path", "state", "provenance"}),
    "REGISTRY_FILE": frozenset({"kind", "path", "sha256", "state", "provenance"}),
}

_SNAPSHOT_REPOSITORY_AST_KEYS_V1 = frozenset({
    "collector_identity", "collector_version", "collector_package_sha256",
    "invocation_identity", "output_schema_identity", "parser",
    "input_path", "input_sha256"})

_SNAPSHOT_REPOSITORY_PROVENANCE_KEYS_V1 = {
    "FILE": frozenset({"method", "commit", "tree"}),
    "FILE_UNREADABLE_OBSERVATION": frozenset({"method", "commit", "tree"}),
    "FILE_EXCLUDED_OBSERVATION": frozenset({"method", "commit", "tree"}),
    "PARSER_ERROR_OBSERVATION": _SNAPSHOT_REPOSITORY_AST_KEYS_V1,
    "PARSER_LIMIT_OBSERVATION": _SNAPSHOT_REPOSITORY_AST_KEYS_V1,
    "PYTHON_IMPORT": _SNAPSHOT_REPOSITORY_AST_KEYS_V1,
    "PYTHON_REVERSE_DEPENDENT": _SNAPSHOT_REPOSITORY_AST_KEYS_V1,
    "UNSUPPORTED_IMPORT_OBSERVATION": _SNAPSHOT_REPOSITORY_AST_KEYS_V1 | {"reason"},
    "PACKAGE_MANIFEST": frozenset({"parser", "input_path"}),
    "PACKAGE_ROOT": frozenset({"parser", "input_path", "input_sha256"}),
    "PACKAGE_MANIFEST_ERROR": frozenset({"parser", "input_path", "input_sha256"}),
    "REGISTRY_FILE": frozenset({"method", "reason"}),
}


_SNAPSHOT_DIFF_CLOSED_KEYSETS_V1 = frozenset({
    NATIVE_SNAPSHOT_PAYLOAD_KEYS,
    _snapshot_diff_keyset_v1(
        "schema_version compiler_sha256 schema_sha256 current_tuple collector_inputs "
        "native_semantic_sha256 missing_or_omitted_state"),
    _snapshot_diff_keyset_v1(
        "controller_id claim_id run_id source_epoch source_pointer_oid hot_state_sha256 "
        "hot_roadmap_sha256 work_graph_sha256 route_identity"),
    _snapshot_diff_keyset_v1("name owner state sha256"),
    _snapshot_diff_keyset_v1(
        "domain encoding canonicalisation semantic_payload_sha256 canonical_input_manifest_sha256 "
        "schema_sha256 compiler_contract_sha256 compiler_blob_sha256"),
    *_SNAPSHOT_NATIVE_MEMBER_KEYS_V1.values(),
    *_SNAPSHOT_REPOSITORY_FACT_KEYS_V1.values(),
    *_SNAPSHOT_REPOSITORY_PROVENANCE_KEYS_V1.values(),
    _snapshot_diff_keyset_v1(
        "native_current repository evidence_failure release"),
    _snapshot_diff_keyset_v1("owner state value sha256"),
    _snapshot_diff_keyset_v1("state invalidators"),
    _snapshot_diff_keyset_v1(
        "schema authority_ceiling establishes repository controller claim "
        "continuity hot frontier andon_state open_andons "
        "active_instructions next_action route semantic_sha256"),
    _snapshot_diff_keyset_v1(
        "schema authority_ceiling establishes repository controller claim "
        "continuity hot frontier andon_state open_andons "
        "active_instructions next_action route semantic_sha256 "
        "route_graph route_relation canonical_work_graph"),
    _snapshot_diff_keyset_v1(
        "schema authority_ceiling establishes repository controller claim "
        "continuity hot frontier andon_state open_andons "
        "active_instructions next_action route semantic_sha256 "
        "route_graph route_relation canonical_work_graph native_episode"),
    _snapshot_diff_keyset_v1("kind collector owner state code scope"),
    _snapshot_diff_keyset_v1("DONE ACTIVE READY BLOCKED"),
    _snapshot_diff_keyset_v1(
        "id reference kind authority subject issued_epoch status "
        "status_evidence supersedes_by scope_end"),
    _snapshot_diff_keyset_v1(
        "schema repository capabilities diagnostics facts "
        "static_collector_invocations"),
    _snapshot_diff_keyset_v1(
        "commit tree worktree_state input_file_set_sha256"),
    _snapshot_diff_keyset_v1("warnings errors skipped unknown"),
    _snapshot_diff_keyset_v1("capability state reason_code"),
    _snapshot_diff_keyset_v1("capability state reason_code provenance"),
    _snapshot_diff_keyset_v1(
        "collector_identity collector_version collector_package_sha256 "
        "invocation_identity output_schema_identity parser "
        "input_file_set_sha256"),
    _snapshot_diff_keyset_v1(
        "collector input_path input_sha256 collector_identity "
        "collector_version collector_package_sha256 invocation_identity "
        "output_schema_identity parser"),
    _snapshot_diff_keyset_v1(
        "schema families source first_red_id first_red_state weakest_leg_id "
        "residual_ids layer_census evidence_records failure_records "
        "establishes semantic_sha256"),
    _snapshot_diff_keyset_v1("path sha256 run_identity artifact_identity"),
    _snapshot_diff_keyset_v1("ATTEMPT RECEIPT EFFECT RECOVERY CLOSURE"),
    _snapshot_diff_keyset_v1(
        "id sequence record_type claim_id criterion_id leg result_class proxy "
        "source_identity native_owner_identity currentness controls "
        "contrary_evidence family authority_ceiling artifact_sha256"),
    _snapshot_diff_keyset_v1(
        "id sequence record_type andon_id abnormality_class statement "
        "cause_confidence evidence_ids recovery_state source_identity "
        "native_owner_identity currentness family authority_ceiling "
        "artifact_sha256"),
    _snapshot_diff_keyset_v1(
        "schema families repository local_manifest_sha256 "
        "external_capture_sha256 external_boundary omissions node_type_census "
        "nodes candidate establishes semantic_sha256"),
    _snapshot_diff_keyset_v1("commit tree worktree_state"),
    _snapshot_diff_keyset_v1(
        "capture_identity source_identity auth_state rate_state rate_remaining "
        "pagination_state pagination_pages object_drift captured_at expires_at "
        "evaluated_at"),
    _snapshot_diff_keyset_v1("record_type state invalidator"),
    _snapshot_diff_keyset_v1(
        "Commit Tree Worktree GeneratedArtifact Package Install Host "
        "PullRequest Check Merge Tag Release Asset PublicSurface"),
    _snapshot_diff_keyset_v1(
        "state invalidators local_commit public_commit"),
    _snapshot_diff_keyset_v1(
        "id record_type family source_identity native_owner_identity "
        "currentness authority_ceiling layer object_identity"),
    _snapshot_diff_keyset_v1(
        "id record_type family source_identity native_owner_identity "
        "currentness authority_ceiling layer path sha256 manifest_sha256"),
    _snapshot_diff_keyset_v1(
        "id record_type family source_identity native_owner_identity "
        "currentness authority_ceiling layer stable_id commit_identity "
        "updated_at etag payload_sha256 native_currentness "
        "capture_currentness capture_identity capture_sha256"),
    _snapshot_diff_keyset_v1("code path"),
    _snapshot_diff_keyset_v1("kind collector owner state code"),
    _snapshot_diff_keyset_v1(
        "kind collector owner family fact_path record_id record_type "
        "native_owner_identity state invalidators"),
    _snapshot_diff_keyset_v1(
        "kind collector owner family layer fact_path record_id record_type "
        "native_owner_identity state invalidators"),
})

_SNAPSHOT_DIFF_DYNAMIC_MAP_SUFFIXES_V1 = (
    ".frontier.blocked_summary", ".frontier.writer_holds",
    ".frontier.resource_holds")


def _snapshot_diff_closed_tree_v1(value: object, path: str) -> None:
    """Consume every JSON branch admitted by the four producer grammars."""
    if path.endswith((".collections.native_current.value.route_graph",
                      ".collections.native_current.value.route_relation",
                      ".collections.native_current.value.native_episode")):
        # These branches have their semantic owner's closed grammar, checked by the fixed
        # pure owner below. They are not interpreted as R0038 fact scalars.
        return
    if type(value) is dict:
        dynamic = path.endswith(_SNAPSHOT_DIFF_DYNAMIC_MAP_SUFFIXES_V1)
        if not dynamic and frozenset(value) not in _SNAPSHOT_DIFF_CLOSED_KEYSETS_V1:
            _error("OE_DIFF_SNAPSHOT_INVALID", path,
                   "snapshot object has an unconsumed producer branch")
        for key, member in value.items():
            if type(key) is not str or not key:
                _error("OE_DIFF_SNAPSHOT_INVALID", path,
                       "snapshot object key must be non-empty text")
            _snapshot_diff_closed_tree_v1(member, f"{path}.{key}")
        return
    if type(value) is list:
        for index, member in enumerate(value):
            _snapshot_diff_closed_tree_v1(member, f"{path}[{index}]")
        return
    key = path.rsplit(".", 1)[-1]
    nullable = {
        "code", "public_commit", "obligation_id", "route_state",
        "first_red_id", "weakest_leg_id"}
    if value is None:
        if key not in nullable:
            _error("OE_DIFF_SNAPSHOT_INVALID", path,
                   "snapshot scalar is not nullable")
        return
    if type(value) is bool:
        if key not in {"proxy", "object_drift"}:
            _error("OE_DIFF_SNAPSHOT_INVALID", path,
                   "snapshot scalar boolean is not admitted here")
        return
    if type(value) is int:
        if value < 0 or key not in {
                "sequence", "bytes", "population", "rate_remaining",
                "pagination_pages", "DONE", "ACTIVE", "READY", "BLOCKED",
                "ATTEMPT", "RECEIPT", "EFFECT", "RECOVERY", "CLOSURE",
                "Commit", "Tree", "Worktree", "GeneratedArtifact", "Package",
                "Install", "Host", "PullRequest", "Check", "Merge", "Tag",
                "Release", "Asset", "PublicSurface"}:
            _error("OE_DIFF_SNAPSHOT_INVALID", path,
                   "snapshot scalar integer is not admitted here")
        return
    if type(value) is not str or not value:
        _error("OE_DIFF_SNAPSHOT_INVALID", path,
               "snapshot scalar must be non-empty text")
    if ("sha256" in key or key.endswith("_digest") or key == "digest"):
        _snapshot_diff_digest_v1(value, path)
    enum_values = {
        "family": set(FAMILIES),
        "layer": {"LOCAL", "EXTERNAL"},
        "record_type": {
            "Claim", "Criterion", "Evidence", "Check", "Review", "Andon",
            "Residual", "Containment", "Countermeasure", "Rerun", "Recovery",
            "Commit", "Tree", "Worktree", "GeneratedArtifact", "Package",
            "Install", "Host", "PullRequest", "Merge", "Tag", "Release",
            "Asset", "PublicSurface"},
        "leg": {"ATTEMPT", "RECEIPT", "EFFECT", "RECOVERY", "CLOSURE"},
        "result_class": {"RED", "GREEN", "NONVERDICT", "UNKNOWN"},
        "cause_confidence": {"UNKNOWN", "LOW", "MEDIUM", "HIGH"},
        "recovery_state": {"NOT_CLAIMED", "ATTEMPTED", "OBSERVED", "UNVERIFIED"},
        "worktree_state": {"CLEAN", "DIRTY"},
        "file_type": {"file", "symlink"},
        "language": {"python", "shell", "javascript", "typescript", "json", "unsupported"},
        "auth_state": {"PRESENT", "ABSENT", "UNKNOWN"},
        "rate_state": {"AVAILABLE", "EXHAUSTED", "UNKNOWN"},
        "pagination_state": {"COMPLETE", "INCOMPLETE", "UNKNOWN"},
    }
    if key in enum_values and value not in enum_values[key]:
        _error("OE_DIFF_SNAPSHOT_INVALID", path,
               "snapshot scalar has a foreign enum value")
    if key == "state" and value not in set(STATES) | {
            "SUPPORTED", "PARTIAL", "NOT_APPLICABLE"}:
        _error("OE_DIFF_SNAPSHOT_INVALID", path,
               "snapshot state has a foreign enum value")


def _snapshot_diff_evidence_record_v1(
        value: object, path: str, identities: set[str]) -> dict:
    keys = {
        "id", "sequence", "record_type", "claim_id", "criterion_id", "leg",
        "result_class", "proxy", "source_identity", "native_owner_identity",
        "currentness", "controls", "contrary_evidence", "family",
        "authority_ceiling", "artifact_sha256"}
    row = _snapshot_diff_exact_object_v1(value, keys, path)
    identity = _snapshot_diff_text_v1(row["id"], f"{path}.id")
    if identity in identities:
        _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.id",
               "snapshot record identity must be globally unique")
    identities.add(identity)
    if type(row["sequence"]) is not int or row["sequence"] < 0:
        _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.sequence",
               "evidence sequence must be non-negative")
    if (row["record_type"] not in {
            "Claim", "Criterion", "Evidence", "Check", "Review"} or
            row["family"] != "EVIDENCE" or
            row["leg"] not in {
                "ATTEMPT", "RECEIPT", "EFFECT", "RECOVERY", "CLOSURE"} or
            row["result_class"] not in {"RED", "GREEN", "NONVERDICT", "UNKNOWN"} or
            type(row["proxy"]) is not bool or
            (row["proxy"] and row["leg"] not in {"ATTEMPT", "RECEIPT"}) or
            row["authority_ceiling"] != "READ_ONLY_NATIVE_ARTIFACT_FACT"):
        _error("OE_DIFF_SNAPSHOT_INVALID", path,
               "evidence member type, family, leg, or authority differs")
    for key in ("claim_id", "criterion_id", "source_identity",
                "native_owner_identity"):
        _snapshot_diff_text_v1(row[key], f"{path}.{key}")
    for key in ("controls", "contrary_evidence"):
        _snapshot_diff_unique_string_list_v1(row[key], f"{path}.{key}")
    _snapshot_diff_currentness_v1(row["currentness"], f"{path}.currentness")
    _snapshot_diff_digest_v1(row["artifact_sha256"], f"{path}.artifact_sha256")
    return row


def _snapshot_diff_failure_record_v1(
        value: object, path: str, identities: set[str]) -> dict:
    keys = {
        "id", "sequence", "record_type", "andon_id", "abnormality_class",
        "statement", "cause_confidence", "evidence_ids", "recovery_state",
        "source_identity", "native_owner_identity", "currentness", "family",
        "authority_ceiling", "artifact_sha256"}
    row = _snapshot_diff_exact_object_v1(value, keys, path)
    identity = _snapshot_diff_text_v1(row["id"], f"{path}.id")
    if identity in identities:
        _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.id",
               "snapshot record identity must be globally unique")
    identities.add(identity)
    if (type(row["sequence"]) is not int or row["sequence"] < 0 or
            row["record_type"] not in {
                "Andon", "Residual", "Containment", "Countermeasure",
                "Rerun", "Recovery"} or row["family"] != "FAILURE" or
            row["cause_confidence"] not in {"UNKNOWN", "LOW", "MEDIUM", "HIGH"} or
            row["recovery_state"] not in {
                "NOT_CLAIMED", "ATTEMPTED", "OBSERVED", "UNVERIFIED"} or
            row["authority_ceiling"] != "READ_ONLY_NATIVE_ARTIFACT_FACT"):
        _error("OE_DIFF_SNAPSHOT_INVALID", path,
               "failure member type, family, recovery, or authority differs")
    for key in ("andon_id", "abnormality_class", "statement",
                "source_identity", "native_owner_identity"):
        _snapshot_diff_text_v1(row[key], f"{path}.{key}")
    _snapshot_diff_unique_string_list_v1(
        row["evidence_ids"], f"{path}.evidence_ids")
    _snapshot_diff_currentness_v1(row["currentness"], f"{path}.currentness")
    _snapshot_diff_digest_v1(row["artifact_sha256"], f"{path}.artifact_sha256")
    return row


def _snapshot_diff_release_record_v1(
        value: object, path: str, identities: set[str]) -> dict:
    required = {
        "id", "record_type", "family", "source_identity",
        "native_owner_identity", "currentness", "authority_ceiling", "layer"}
    variants = (
        required | {"object_identity"},
        required | {"path", "sha256", "manifest_sha256"},
        required | {
            "stable_id", "commit_identity", "updated_at", "etag",
            "payload_sha256", "native_currentness", "capture_currentness",
            "capture_identity", "capture_sha256"},
    )
    if type(value) is not dict or set(value) not in variants:
        _error("OE_DIFF_SNAPSHOT_INVALID", path,
               "release member does not match an exact producer variant")
    identity = _snapshot_diff_text_v1(value["id"], f"{path}.id")
    if identity in identities:
        _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.id",
               "snapshot record identity must be globally unique")
    identities.add(identity)
    if (value["record_type"] not in _RELEASE_RECORD_TYPES_V1 or
            value["family"] != "RELEASE" or
            value["authority_ceiling"] != "READ_ONLY_NATIVE_OBSERVATION" or
            value["layer"] not in {"LOCAL", "EXTERNAL"}):
        _error("OE_DIFF_SNAPSHOT_INVALID", path,
               "release member type, family, layer, or authority differs")
    for key in ("source_identity", "native_owner_identity"):
        _snapshot_diff_text_v1(value[key], f"{path}.{key}")
    _snapshot_diff_currentness_v1(value["currentness"], f"{path}.currentness")
    for key in ("native_currentness", "capture_currentness"):
        if key in value:
            _snapshot_diff_currentness_v1(value[key], f"{path}.{key}")
    if "object_identity" in value:
        object_identity = _snapshot_diff_text_v1(
            value["object_identity"], f"{path}.object_identity")
        if value["record_type"] in {"Commit", "Tree"}:
            if re.fullmatch(r"[0-9a-f]{40}", object_identity) is None:
                _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.object_identity",
                       "release Git object identity is malformed")
        elif value["record_type"] != "Worktree" or object_identity not in {
                "CLEAN", "DIRTY"}:
            _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.object_identity",
                   "release object identity differs from its local variant")
    if "path" in value:
        _snapshot_diff_text_v1(value["path"], f"{path}.path")
        _snapshot_diff_digest_v1(value["sha256"], f"{path}.sha256")
        _snapshot_diff_digest_v1(
            value["manifest_sha256"], f"{path}.manifest_sha256")
    if "stable_id" in value:
        for key in ("stable_id", "source_identity", "native_owner_identity",
                    "updated_at", "etag", "capture_identity"):
            _snapshot_diff_text_v1(value[key], f"{path}.{key}")
        _snapshot_diff_digest_v1(
            value["payload_sha256"], f"{path}.payload_sha256")
        _snapshot_diff_digest_v1(
            value["capture_sha256"], f"{path}.capture_sha256")
        if re.fullmatch(r"[0-9a-f]{40}", value["commit_identity"]) is None:
            _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.commit_identity",
                   "external release commit identity is malformed")
    return value


def _snapshot_diff_missing_v1(value: object, path: str) -> None:
    if type(value) is not dict or value.get("kind") not in {
            "COLLECTOR_NON_CURRENT", "REPOSITORY_DIAGNOSTIC",
            "OWNER_FACT_NON_CURRENT", "RELEASE_INVALIDATOR", "NATIVE_CAPABILITY_UNVERIFIED"}:
        _error("OE_DIFF_SNAPSHOT_INVALID", path,
               "missing-or-omitted entry has a foreign schema")
    kind = value["kind"]
    if kind == "NATIVE_CAPABILITY_UNVERIFIED":
        expected = {"kind", "collector", "owner", "state", "code"}
        if value.get("code") in {"NATIVE_ROUTE_SCOPE_UNCOVERED", "NATIVE_PENDING_BOUNDARY_UNVERIFIED"}:
            expected.add("scope")
            _snapshot_diff_text_v1(value.get("scope"), f"{path}.scope")
        elif value.get("code") not in {"NATIVE_ROUTE_NODE_MAPPING_UNAVAILABLE", "NATIVE_EPISODE_UNAVAILABLE", "NATIVE_H0_LIFECYCLE_UNAVAILABLE"}:
            _error("OE_DIFF_SNAPSHOT_INVALID", path, "unknown native capability omission")
        owner = "R003A/continuity" if value.get("code") in {"NATIVE_EPISODE_UNAVAILABLE", "NATIVE_H0_LIFECYCLE_UNAVAILABLE", "NATIVE_PENDING_BOUNDARY_UNVERIFIED"} else "R0033/R0035"
        if (set(value) != expected or value.get("collector") != "native_current" or
                value.get("owner") != owner or value.get("state") != "UNVERIFIED"):
            _error("OE_DIFF_SNAPSHOT_INVALID", path, "native capability omission differs")
        return
    schemas = {
        "COLLECTOR_NON_CURRENT": {
            "kind", "collector", "owner", "state", "code"},
        "REPOSITORY_DIAGNOSTIC": {
            "kind", "collector", "owner", "state", "code"},
        "RELEASE_INVALIDATOR": {"kind", "collector", "owner", "state", "code"},
    }
    if kind == "OWNER_FACT_NON_CURRENT":
        evidence_keys = {
            "kind", "collector", "owner", "family", "fact_path", "record_id",
            "record_type", "native_owner_identity", "state", "invalidators"}
        release_keys = evidence_keys | {"layer"}
        if set(value) not in (evidence_keys, release_keys):
            _error("OE_DIFF_SNAPSHOT_INVALID", path,
                   "owner-fact omission has a foreign schema")
        if value["family"] not in FAMILIES:
            _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.family",
                   "omitted owner fact has a foreign family")
        invalidators = value["invalidators"]
        if (type(invalidators) is not list or any(
                type(item) is not str or not item for item in invalidators) or
                (value["state"] == "STALE" and not invalidators)):
            _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.invalidators",
                   "omitted owner-fact invalidators are inconsistent")
    elif set(value) != schemas[kind]:
        _error("OE_DIFF_SNAPSHOT_INVALID", path,
               "missing-or-omitted entry has a foreign key set")
    if value["state"] not in STATES or value["state"] == "CURRENT":
        _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.state",
               "omitted state must be a supported non-current state")
    for key in ("collector", "owner"):
        _snapshot_diff_text_v1(value[key], f"{path}.{key}")
    if kind != "OWNER_FACT_NON_CURRENT" and value["code"] is not None:
        _snapshot_diff_text_v1(value["code"], f"{path}.code")


def _snapshot_diff_repository_v1(value: dict, path: str) -> None:
    # Both native and repository-only envelopes consume the same closed scalar
    # grammar. A recomputed content digest is not producer-schema validation.
    _snapshot_diff_closed_tree_v1(value, path)
    repository = _snapshot_diff_exact_object_v1(
        value["repository"],
        {"commit", "tree", "worktree_state", "input_file_set_sha256"},
        f"{path}.repository")
    for key in ("commit", "tree"):
        if re.fullmatch(r"[0-9a-f]{40}", repository[key]) is None:
            _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.repository.{key}",
                   "repository Git identity is malformed")
    _snapshot_diff_digest_v1(
        repository["input_file_set_sha256"],
        f"{path}.repository.input_file_set_sha256")

    diagnostics = _snapshot_diff_exact_object_v1(
        value["diagnostics"], {"warnings", "errors", "skipped", "unknown"},
        f"{path}.diagnostics")
    for bucket, members in diagnostics.items():
        if (type(members) is not list or any(
                type(member) is not str or not member for member in members) or
                len(set(members)) != len(members)):
            _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.diagnostics.{bucket}",
                   "repository diagnostic population is malformed")

    invocations = value["static_collector_invocations"]
    if type(invocations) is not list:
        _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.static_collector_invocations",
               "static invocation population must be an array")
    invocation_keys = {
        "collector", "input_path", "input_sha256", "collector_identity",
        "collector_version", "collector_package_sha256", "invocation_identity",
        "output_schema_identity", "parser"}
    for index, invocation in enumerate(invocations):
        _snapshot_diff_exact_object_v1(
            invocation, invocation_keys,
            f"{path}.static_collector_invocations[{index}]")
        if invocation["collector"] != "python_ast":
            _error("OE_DIFF_SNAPSHOT_INVALID",
                   f"{path}.static_collector_invocations[{index}].collector",
                   "static invocation collector is foreign")

    capabilities = value["capabilities"]
    if type(capabilities) is not list:
        _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.capabilities",
               "repository capabilities must be an array")
    seen_capabilities = set()
    for index, capability in enumerate(capabilities):
        capability_path = f"{path}.capabilities[{index}]"
        name = capability.get("capability") if type(capability) is dict else None
        keys = {"capability", "state", "reason_code"}
        if name == "python_ast" and invocations:
            keys.add("provenance")
        row = _snapshot_diff_exact_object_v1(capability, keys, capability_path)
        if (name not in {"file_facts", "package_manifest", "python_ast",
                         "validation_registry_entries"} or
                name in seen_capabilities):
            _error("OE_DIFF_SNAPSHOT_INVALID", f"{capability_path}.capability",
                   "repository capability identity is foreign or duplicated")
        seen_capabilities.add(name)
        if "provenance" in row:
            expected = {
                "collector_identity", "collector_version",
                "collector_package_sha256", "invocation_identity",
                "output_schema_identity", "parser", "input_file_set_sha256"}
            _snapshot_diff_exact_object_v1(
                row["provenance"], expected, f"{capability_path}.provenance")
    if seen_capabilities != {
            "file_facts", "package_manifest", "python_ast",
            "validation_registry_entries"}:
        _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.capabilities",
               "repository capability population is incomplete")

    facts = value["facts"]
    if type(facts) is not list:
        _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.facts",
               "repository facts must be an array")
    for index, fact in enumerate(facts):
        fact_path = f"{path}.facts[{index}]"
        kind = fact.get("kind") if type(fact) is dict else None
        if kind not in _SNAPSHOT_REPOSITORY_FACT_KEYS_V1:
            _error("OE_DIFF_SNAPSHOT_INVALID", fact_path,
                   "repository fact kind is foreign")
        row = _snapshot_diff_exact_object_v1(
            fact, _SNAPSHOT_REPOSITORY_FACT_KEYS_V1[kind], fact_path)
        provenance_keys = _SNAPSHOT_REPOSITORY_PROVENANCE_KEYS_V1[kind]
        _snapshot_diff_exact_object_v1(
            row["provenance"], provenance_keys, f"{fact_path}.provenance")


def _snapshot_diff_route_graph_v2(value, path):
    """Revalidate captured owner data without native selection or execution."""
    # source repo: the fixed repository-only R0035 peer also accompanies the
    # materialized canonical layout. Frozen readers use only its pure contract.
    peer = pathlib.Path(__file__).resolve().parents[1] / (
        "source-peers/route-graph/skills/implementaudit/scripts/compile-work-graph.py")
    try:
        source = value["canonical_work_graph"]
        if type(source) is not str or len(source.encode("utf-8")) > 256 * 1024:
            raise ValueError("canonical graph source exceeds its original bound")
        source = source.encode("utf-8")
        if hashlib.sha256(source).hexdigest() != value["hot"]["work_graph_sha256"]:
            raise ValueError("canonical graph source identity differs")
        if value["route_graph"] is None or value["route_relation"] is None:
            if value["route_graph"] is not None or value["route_relation"] is not None:
                raise ValueError("partial route/node projection is ambiguous")
            return  # Capability absence is mandatory UNVERIFIED census, not a positive.
        raw = _native_file(peer, "$snapshot.route_graph_contract", 256 * 1024)
        if hashlib.sha256(raw).hexdigest() != value["hot"]["work_graph_compiler_sha256"]:
            raise ValueError("captured graph contract source differs")
        owner = _native_module_from_bytes(raw, peer,
            "_implementaudit_frozen_route_graph", "$snapshot.route_graph_contract")
        graph, relation = value["route_graph"], value["route_relation"]
        if owner.bind_native_route_relation_v1(graph, source) != relation:
            raise ValueError("affected-node relation differs from canonical source")
        binding = graph["binding"]
        if (graph["route_scope"]["route"] != value["route"] or
                binding["controller"] != value["controller"]["id"] or
                binding["claim"] != value["claim"]["id"] or
                binding["epoch"] != value["continuity"]["generation"] or
                binding["receipt"] != value["continuity"]["receipt"]):
            raise ValueError("graph crossed native route/currentness custody")
        # The native input root is the repository selected by C03, and R0033's
        # run must be that repository's exact claimed relative run. Preserve
        # the producer platform's path spelling when checking its root digest.
        run_text = graph["route_scope"]["owner"]["explicit_run_root"]
        if type(run_text) is not str or any(part in {".", ".."}
                for part in run_text.replace("\\", "/").split("/")):
            raise ValueError("route run root has a lexical alias")
        windows = bool(re.match(r"^[A-Za-z]:[/\\]", run_text))
        run_path = pathlib.PureWindowsPath(run_text) if windows else pathlib.PurePosixPath(run_text)
        relative = pathlib.PurePosixPath(value["claim"]["run_root"])
        if (not run_path.is_absolute() or (not windows and "\\" in run_text) or
                relative.parts != (".IMPLEMENTAUDIT", "runs", value["claim"]["run_id"]) or
                run_path.parts[-3:] != relative.parts):
            raise ValueError("route run root differs from native claim")
        input_root = str(run_path.parents[2])
        if hashlib.sha256(input_root.encode("utf-8")).hexdigest() != binding["input_root_identity"]:
            raise ValueError("route run root and native input root differ")
        for name, member in (("STATE.md", "state_sha256"), ("ROADMAP.md", "roadmap_sha256")):
            if hashlib.sha256(graph["source_documents"][name].encode("utf-8")).hexdigest() != value["hot"][member]:
                raise ValueError("graph source differs from native hot identity")
        if _native_file(peer, "$snapshot.route_graph_contract", 256 * 1024) != raw:
            raise ValueError("graph contract source changed during frozen validation")
    except (Exception, SystemExit):
        _error("OE_DIFF_SNAPSHOT_INVALID", path,
               "captured route/node source, population, relation or contract differs")


def _snapshot_diff_native_episode_v3(native, path):
    wrapped = native["native_episode"]
    if wrapped is None:
        return
    try:
        _snapshot_diff_exact_object_v1(wrapped, {"producer_sha256", "contract_sha256", "value"}, path)
        peers = _native_episode_peer_bytes()
        if (wrapped["producer_sha256"] != hashlib.sha256(peers[0][1]).hexdigest() or
                wrapped["contract_sha256"] != hashlib.sha256(peers[1][1]).hexdigest()):
            raise ValueError("episode contract/producer source identity differs")
        contract = _native_module_from_bytes(peers[1][1], peers[1][0],
            "_frozen_episode_contract", "$snapshot.episode_contract")
        if contract.validate_frozen_episode_export_v1(wrapped["value"]) != wrapped["value"]:
            raise ValueError("episode contract changed the captured value")
        _native_episode_binding(wrapped, native["route"], native["route_graph"])
        if any(_native_file(source, "$snapshot.episode_contract", 256 * 1024) != raw for source, raw in peers):
            raise ValueError("episode source changed during frozen validation")
    except (Exception, SystemExit):
        _error("OE_DIFF_SNAPSHOT_INVALID", path, "accepted episode shape, source, scope or physical binding differs")


def _snapshot_diff_native_v1(value: dict, path: str) -> None:
    for key, keys in _SNAPSHOT_NATIVE_MEMBER_KEYS_V1.items():
        _snapshot_diff_exact_object_v1(value[key], keys, f"{path}.{key}")
    for key in ("controller", "continuity", "route"):
        for member, item in value[key].items():
            if member.endswith("_oid") and re.fullmatch(r"[0-9a-f]{40}", item) is None:
                _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.{key}.{member}",
                       "native Git object identity is malformed")
    if value["route"]["decision"] not in {"REQUIRED", "NOT_REQUIRED"}:
        _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.route.decision",
               "native route decision is foreign")
    if value["route"]["decision"] == "REQUIRED":
        if (type(value["route"]["obligation_id"]) is not str or
                value["route"]["route_state"] not in {
                    "UNSATISFIED", "OPEN", "RETURNED", "SATISFIED"}):
            _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.route",
                   "required route obligation state is malformed")
    counts = _snapshot_diff_exact_object_v1(
        value["frontier"]["counts"], {"DONE", "ACTIVE", "READY", "BLOCKED"},
        f"{path}.frontier.counts")
    if (sum(counts.values()) != value["frontier"]["population"] or
            len(value["frontier"]["active"]) != counts["ACTIVE"] or
            len(value["frontier"]["ready"]) != counts["READY"] or
            len(value["frontier"]["blocked_summary"]) != counts["BLOCKED"]):
        _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.frontier",
               "native frontier census differs from its population")
    for name in ("active", "ready"):
        members = value["frontier"][name]
        if (type(members) is not list or members != sorted(set(members)) or
                any(type(member) is not str or not member for member in members)):
            _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.frontier.{name}",
                   "native frontier identities are malformed")
    for name in ("blocked_summary", "writer_holds", "resource_holds"):
        mapping = value["frontier"][name]
        if type(mapping) is not dict:
            _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.frontier.{name}",
                   "native frontier hold map is malformed")
        for identity, members in mapping.items():
            if (not identity or type(members) is not list or
                    members != sorted(set(members)) or
                    any(type(member) is not str or not member for member in members)):
                _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.frontier.{name}",
                       "native frontier hold population is malformed")
    frontier = dict(value["frontier"])
    digest = frontier.pop("digest")
    if hashlib.sha256(canonical_json_v1(frontier)).hexdigest() != digest:
        _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.frontier.digest",
               "native frontier digest differs")
    if (type(value["open_andons"]) is not list or
            value["open_andons"] != sorted(set(value["open_andons"])) or
            not value["open_andons"]):
        _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.open_andons",
               "native open-Andon population is malformed")
    instructions = value["active_instructions"]
    instruction_keys = {
        "id", "reference", "kind", "authority", "subject", "issued_epoch",
        "status", "status_evidence", "supersedes_by", "scope_end"}
    if type(instructions) is not list or not instructions:
        _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.active_instructions",
               "native active-instruction population is absent")
    seen = set()
    for index, instruction in enumerate(instructions):
        row = _snapshot_diff_exact_object_v1(
            instruction, instruction_keys, f"{path}.active_instructions[{index}]")
        if row["status"] != "active" or row["id"] in seen:
            _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.active_instructions[{index}]",
                   "native active instruction is foreign or duplicated")
        seen.add(row["id"])
    if value["schema"] in NATIVE_ROUTE_SCHEMAS:
        _snapshot_diff_route_graph_v2(value, path)
    if value["schema"] == NATIVE_CURRENT_SCHEMA:
        _snapshot_diff_native_episode_v3(value, path + ".native_episode")


def _snapshot_diff_release_v1(value: dict, path: str) -> None:
    repository = _snapshot_diff_exact_object_v1(
        value["repository"], {"commit", "tree", "worktree_state"},
        f"{path}.repository")
    boundary = _snapshot_diff_exact_object_v1(
        value["external_boundary"], {
            "capture_identity", "source_identity", "auth_state", "rate_state",
            "rate_remaining", "pagination_state", "pagination_pages",
            "object_drift", "captured_at", "expires_at", "evaluated_at"},
        f"{path}.external_boundary")
    candidate = _snapshot_diff_exact_object_v1(
        value["candidate"], {"state", "invalidators", "local_commit", "public_commit"},
        f"{path}.candidate")
    if (candidate["state"] != "UNVERIFIED" or
            candidate["local_commit"] != repository["commit"]):
        _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.candidate",
               "release candidate state or local identity differs")
    for key in ("captured_at", "expires_at", "evaluated_at"):
        if (type(boundary[key]) is not str or re.fullmatch(
                r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z", boundary[key]) is None):
            _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.external_boundary.{key}",
                   "release boundary timestamp is malformed")
    if (boundary["captured_at"] >= boundary["expires_at"] or
            boundary["evaluated_at"] < boundary["captured_at"]):
        _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.external_boundary",
               "release boundary chronology differs")
    boundary_currentness = _external_boundary_currentness(
        boundary["auth_state"], boundary["rate_state"],
        boundary["pagination_state"], boundary["object_drift"],
        boundary["expires_at"], boundary["evaluated_at"])
    local_types = {"GeneratedArtifact", "Package", "Install", "Host"}
    external_types = {
        "PullRequest", "Check", "Merge", "Tag", "Release", "Asset",
        "PublicSurface"}
    for index, row in enumerate(value["nodes"]):
        node_path = f"{path}.nodes[{index}]"
        if "object_identity" in row:
            if row["record_type"] not in {"Commit", "Tree", "Worktree"} or row["layer"] != "LOCAL":
                _error("OE_DIFF_SNAPSHOT_INVALID", node_path,
                       "release object node uses a foreign variant")
        elif "path" in row:
            if row["record_type"] not in local_types or row["layer"] != "LOCAL":
                _error("OE_DIFF_SNAPSHOT_INVALID", node_path,
                       "release local-path node uses a foreign variant")
        elif row["record_type"] not in external_types or row["layer"] != "EXTERNAL":
            _error("OE_DIFF_SNAPSHOT_INVALID", node_path,
                   "release external node uses a foreign variant")
        if row["layer"] == "EXTERNAL":
            expected = _compose_currentness(
                row["native_currentness"], row["capture_currentness"])
            if (row["capture_currentness"] != boundary_currentness or
                    row["currentness"] != expected or
                    row["capture_identity"] != boundary["capture_identity"] or
                    row["capture_sha256"] != value["external_capture_sha256"]):
                _error("OE_DIFF_SNAPSHOT_INVALID", node_path,
                       "release external currentness or capture identity differs")
    observed_types = {row["record_type"] for row in value["nodes"]}
    missing_types = sorted(_RELEASE_RECORD_TYPES_V1 - observed_types)
    expected_omissions = _release_omissions_v1(missing_types)
    if value["omissions"] != expected_omissions:
        _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.omissions",
               "release omission census differs from validated nodes")
    expected_candidate = _release_candidate_v1(
        repository, value["nodes"], boundary_currentness, missing_types)
    if candidate["public_commit"] != expected_candidate["public_commit"]:
        _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.candidate.public_commit",
               "release public candidate identity differs")
    if candidate["invalidators"] != expected_candidate["invalidators"]:
        _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.candidate.invalidators",
               "release candidate invalidators differ from validated nodes")


def _snapshot_diff_collections_v1(
        collections: object, path: str) -> tuple[set[str], list[dict]]:
    owners = {
        "native_current": "R0038-C03", "repository": "R0038-C02",
        "evidence_failure": "R0038-C04", "release": "R0038-C05"}
    if type(collections) is not dict or set(collections) != set(owners):
        _error("OE_DIFF_SNAPSHOT_INVALID", path,
               "snapshot must retain the complete producer collection population")
    identities: set[str] = set()
    population: list[dict] = []
    for name in sorted(owners):
        member_path = f"{path}.{name}"
        member = _snapshot_diff_exact_object_v1(
            collections[name], {"owner", "state", "value", "sha256"}, member_path)
        if member["owner"] != owners[name] or member["state"] not in {"CURRENT", "UNKNOWN"}:
            _error("OE_DIFF_SNAPSHOT_INVALID", member_path,
                   "snapshot collection owner or state differs")
        if name in {"native_current", "repository"} and member["state"] != "CURRENT":
            _error("OE_DIFF_SNAPSHOT_INVALID", member_path,
                   "required snapshot collector is not CURRENT")
        value = member["value"]
        digest = _snapshot_diff_digest_v1(member["sha256"], f"{member_path}.sha256")
        if hashlib.sha256(canonical_json_v1(value)).hexdigest() != digest:
            _error("OE_DIFF_SNAPSHOT_INVALID", member_path,
                   "snapshot collection digest differs")
        if member["state"] == "UNKNOWN":
            unknown = _snapshot_diff_exact_object_v1(
                value, {"code", "path"}, f"{member_path}.value")
            _snapshot_diff_text_v1(unknown["code"], f"{member_path}.value.code")
            _snapshot_diff_text_v1(unknown["path"], f"{member_path}.value.path")
            continue
        if name == "native_current":
            keys = {
                "schema", "authority_ceiling", "establishes", "repository",
                "controller", "claim", "continuity", "hot", "frontier",
                "andon_state", "open_andons", "active_instructions",
                "next_action", "route", "semantic_sha256"}
            if type(value) is dict and value.get("schema") in NATIVE_ROUTE_SCHEMAS:
                keys.update({"route_graph", "route_relation", "canonical_work_graph"})
                if value["schema"] == NATIVE_CURRENT_SCHEMA:
                    keys.add("native_episode")
            current = _snapshot_diff_exact_object_v1(value, keys, f"{member_path}.value")
            if (current["schema"] not in {LEGACY_NATIVE_CURRENT_SCHEMA, *NATIVE_ROUTE_SCHEMAS} or
                    current["authority_ceiling"] != "READ_ONLY_NATIVE_CURRENT_FACT" or
                    current["establishes"] != [] or any(
                        type(current[key]) is not dict or not current[key]
                        for key in ("repository", "controller", "claim", "continuity",
                                    "hot", "frontier", "route")) or
                    type(current["open_andons"]) is not list or
                    type(current["active_instructions"]) is not list):
                _error("OE_DIFF_SNAPSHOT_INVALID", member_path,
                       "native-current collection schema differs")
            _snapshot_diff_text_v1(current["andon_state"], f"{member_path}.andon_state")
            _snapshot_diff_text_v1(current["next_action"], f"{member_path}.next_action")
            _snapshot_diff_native_v1(current, f"{member_path}.value")
            route = current["route"]
            if (route["decision"] != "REQUIRED" and
                    (route["obligation_id"] is not None or
                     route["route_state"] is not None)):
                _error("OE_DIFF_SNAPSHOT_INVALID", f"{member_path}.value.route",
                       "non-required route cannot retain obligation state")
            _snapshot_diff_semantic_v1(current, f"{member_path}.value")
        elif name == "repository":
            keys = {
                "schema", "repository", "capabilities", "diagnostics", "facts",
                "static_collector_invocations"}
            repository = _snapshot_diff_exact_object_v1(
                value, keys, f"{member_path}.value")
            if (repository["schema"] != REPOSITORY_COLLECTION_SCHEMA or
                    type(repository["repository"]) is not dict or
                    type(repository["capabilities"]) is not list or
                    type(repository["facts"]) is not list or
                    type(repository["static_collector_invocations"]) is not list or
                    type(repository["diagnostics"]) is not dict):
                _error("OE_DIFF_SNAPSHOT_INVALID", member_path,
                       "repository collection schema differs")
            _snapshot_diff_repository_v1(repository, f"{member_path}.value")
        elif name == "evidence_failure":
            keys = {
                "schema", "families", "source", "first_red_id", "first_red_state",
                "weakest_leg_id", "residual_ids", "layer_census",
                "evidence_records", "failure_records", "establishes",
                "semantic_sha256"}
            evidence = _snapshot_diff_exact_object_v1(
                value, keys, f"{member_path}.value")
            if (evidence["schema"] != EVIDENCE_FAILURE_COLLECTION_SCHEMA or
                    evidence["families"] != ["EVIDENCE", "FAILURE"] or
                    evidence["establishes"] != [] or
                    type(evidence["evidence_records"]) is not list or
                    type(evidence["failure_records"]) is not list or
                    type(evidence["residual_ids"]) is not list):
                _error("OE_DIFF_SNAPSHOT_INVALID", member_path,
                       "evidence/failure collection schema differs")
            evidence_sequences = []
            for index, row in enumerate(evidence["evidence_records"]):
                record_path = f"{member_path}.value.evidence_records[{index}]"
                parsed = _snapshot_diff_evidence_record_v1(
                    row, record_path, identities)
                population.append({"path": f"record:{parsed['id']}",
                                   "record": parsed})
                evidence_sequences.append(row["sequence"])
            failure_sequences = []
            for index, row in enumerate(evidence["failure_records"]):
                record_path = f"{member_path}.value.failure_records[{index}]"
                parsed = _snapshot_diff_failure_record_v1(
                    row, record_path, identities)
                population.append({"path": f"record:{parsed['id']}",
                                   "record": parsed})
                failure_sequences.append(row["sequence"])
            if (len(evidence_sequences) != len(set(evidence_sequences)) or
                    len(failure_sequences) != len(set(failure_sequences))):
                _error("OE_DIFF_SNAPSHOT_INVALID", member_path,
                       "snapshot evidence/failure sequences are not unique")
            evidence_by_id = {
                row["id"]: row for row in evidence["evidence_records"]}
            failure_by_id = {
                row["id"]: row for row in evidence["failure_records"]}
            red_records = [
                row for row in evidence["evidence_records"]
                if row["result_class"] == "RED" and not row["proxy"]]
            expected_first_red = (min(
                red_records, key=lambda row: row["sequence"])["id"]
                if red_records else None)
            if (evidence["first_red_id"] != expected_first_red or
                    evidence["first_red_state"] != (
                        "PRESENT" if red_records else "NOT_APPLICABLE")):
                _error("OE_DIFF_SNAPSHOT_INVALID", member_path,
                       "first RED identity/state differs from validated evidence")
            weakest = evidence_by_id.get(evidence["weakest_leg_id"])
            if (weakest is None or weakest["proxy"] or
                    (red_records and weakest["result_class"] != "RED")):
                _error("OE_DIFF_SNAPSHOT_INVALID", member_path,
                       "weakest leg differs from validated evidence")
            for row in evidence["evidence_records"]:
                if any(reference not in evidence_by_id
                       for reference in row["contrary_evidence"]):
                    _error("OE_DIFF_SNAPSHOT_INVALID", member_path,
                           "contrary evidence references an absent record")
            andon_ids = {
                row["id"] for row in evidence["failure_records"]
                if row["record_type"] == "Andon"}
            for row in evidence["failure_records"]:
                if (row["andon_id"] not in andon_ids or any(
                        reference not in evidence_by_id
                        for reference in row["evidence_ids"])):
                    _error("OE_DIFF_SNAPSHOT_INVALID", member_path,
                           "failure lineage references an absent record")
                if row["recovery_state"] == "OBSERVED":
                    recovery = [evidence_by_id[item] for item in row["evidence_ids"]]
                    if (not recovery or any(
                            item["leg"] != "RECOVERY" or
                            item["result_class"] != "GREEN" or item["proxy"] or
                            item["currentness"]["state"] != "CURRENT"
                            for item in recovery)):
                        _error("OE_DIFF_SNAPSHOT_INVALID", member_path,
                               "observed recovery lacks current direct evidence")
            _snapshot_diff_unique_string_list_v1(
                evidence["residual_ids"], f"{member_path}.value.residual_ids")
            if (any(item not in failure_by_id or
                        failure_by_id[item]["record_type"] != "Residual"
                        for item in evidence["residual_ids"])):
                _error("OE_DIFF_SNAPSHOT_INVALID", member_path,
                       "residual census differs from validated failure records")
            expected_census = Counter(
                row["leg"] for row in evidence["evidence_records"])
            if evidence["layer_census"] != {
                    leg: expected_census.get(leg, 0)
                    for leg in ("ATTEMPT", "RECEIPT", "EFFECT", "RECOVERY", "CLOSURE")}:
                _error("OE_DIFF_SNAPSHOT_INVALID", member_path,
                       "evidence layer census differs from validated records")
            _snapshot_diff_semantic_v1(evidence, f"{member_path}.value")
        else:
            keys = {
                "schema", "families", "repository", "local_manifest_sha256",
                "external_capture_sha256", "external_boundary", "omissions",
                "node_type_census", "nodes", "candidate", "establishes",
                "semantic_sha256"}
            release = _snapshot_diff_exact_object_v1(
                value, keys, f"{member_path}.value")
            if (release["schema"] != RELEASE_COLLECTION_SCHEMA or
                    release["families"] != ["RELEASE"] or
                    release["establishes"] != [] or
                    type(release["nodes"]) is not list or
                    type(release["omissions"]) is not list or
                    type(release["node_type_census"]) is not dict or
                    type(release["candidate"]) is not dict):
                _error("OE_DIFF_SNAPSHOT_INVALID", member_path,
                       "release collection schema differs")
            for index, row in enumerate(release["nodes"]):
                record_path = f"{member_path}.value.nodes[{index}]"
                parsed = _snapshot_diff_release_record_v1(
                    row, record_path, identities)
                population.append({"path": f"record:{parsed['id']}",
                                   "record": parsed})
            type_census = Counter(row["record_type"] for row in release["nodes"])
            if release["node_type_census"] != {
                    key: type_census[key] for key in sorted(_RELEASE_RECORD_TYPES_V1)}:
                _error("OE_DIFF_SNAPSHOT_INVALID", member_path,
                       "release node-type census differs from validated records")
            _snapshot_diff_release_v1(release, f"{member_path}.value")
            _snapshot_diff_semantic_v1(release, f"{member_path}.value")
    # Use the same logical identities and observations as C07. The previous
    # population validated CODE/native branches but then silently omitted them.
    for name in ("repository", "native_current"):
        for record in _snapshot_query_policy.project_collector(name, collections[name]["value"]):
            if record["id"] in identities:
                _error("OE_DIFF_SNAPSHOT_INVALID", path, "projected record identity collides")
            identities.add(record["id"])
            population.append({"path": "record:" + record["id"], "record": record})
    return identities, population


def _parse_diff_snapshot_v1(snapshot: object, path: str) -> tuple[dict, list[dict]]:
    """Validate one immutable payload without repairing or selecting authority."""
    if type(snapshot) is dict and snapshot.get("schema_version") == CAPTURED_SNAPSHOT_SCHEMA:
        return _parse_captured_snapshot_v1(snapshot, path)
    if type(snapshot) is dict and snapshot.get("schema_version") == REPOSITORY_SNAPSHOT_SCHEMA:
        return _parse_repository_snapshot_v1(snapshot, path)
    if (type(snapshot) is not dict or set(snapshot) != NATIVE_SNAPSHOT_PAYLOAD_KEYS or
            snapshot.get("schema_version") != SNAPSHOT_PAYLOAD_SCHEMA or
            type(snapshot.get("snapshot_id")) is not str or
            not SNAPSHOT_ID_RE.fullmatch(snapshot["snapshot_id"]) or
            snapshot.get("aggregate") not in AGGREGATES or
            tuple(snapshot.get("families", ())) != FAMILIES or
            type(snapshot.get("missing_or_omitted_state")) is not list or
            type(snapshot.get("collections")) is not dict or
            type(snapshot.get("input_manifest_sha256")) is not str or
            not re.fullmatch(r"[0-9a-f]{64}", snapshot["input_manifest_sha256"])):
        _error("OE_DIFF_SNAPSHOT_INVALID", path,
               "snapshot payload schema, identity, families, or manifest differs")
    try:
        validate_identity_json_v1(snapshot, path)
        canonical = json.loads(canonical_json_v1(snapshot).decode("utf-8"))
        _snapshot_diff_closed_tree_v1(canonical, path)
        missing = canonical["missing_or_omitted_state"]
        for index, row in enumerate(missing):
            _snapshot_diff_missing_v1(row, f"{path}.missing_or_omitted_state[{index}]")
        if canonical["aggregate"] not in {"COMPLETE", "DEGRADED"} or (
                canonical["aggregate"] == "COMPLETE") != (not missing):
            _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.aggregate",
                   "snapshot aggregate and missing-state census differ")
        validated_identities, population = _snapshot_diff_collections_v1(
            canonical["collections"], f"{path}.collections")
        inputs = canonical["input_manifest"]
        for name in ("schema_sha256", "compiler_sha256"):
            if type(inputs.get(name)) is not str or not re.fullmatch(r"[0-9a-f]{64}", inputs[name]):
                _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.input_manifest.{name}",
                       "snapshot input source digest is invalid")
        expected_inputs = _snapshot_input_manifest_v1(canonical["collections"],
            inputs["schema_sha256"], inputs["compiler_sha256"])
        semantic = {key: canonical[key] for key in SNAPSHOT_SEMANTIC_KEYS}
        identity = _snapshot_identity_record_v1(semantic, expected_inputs)
        if (inputs != expected_inputs or canonical["identity_record"] != identity or
                canonical["input_manifest_sha256"] != identity["canonical_input_manifest_sha256"] or
                canonical["snapshot_id"] != "iasnap-v1-" + hashlib.sha256(canonical_json_v1(identity)).hexdigest()):
            _error("OE_DIFF_SNAPSHOT_INVALID", path,
                   "snapshot semantic content, input manifest and structured identity differ")
        if _snapshot_missing_census_v1(canonical["collections"]) != missing:
            _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.missing_or_omitted_state",
                   "snapshot missing-state census differs from validated collections")
        if {row["record"]["id"] for row in population} != validated_identities:
            _error("OE_DIFF_SNAPSHOT_INVALID", f"{path}.collections",
                   "snapshot record population differs from validated members")
    except OperationalEvidenceError as exc:
        if exc.code == "OE_DIFF_SNAPSHOT_INVALID":
            raise
        _error("OE_DIFF_SNAPSHOT_INVALID", path,
               "snapshot payload contains invalid or duplicate records")
    except Exception:
        _error("OE_DIFF_SNAPSHOT_INVALID", path,
               "snapshot payload contains a malformed producer branch")
    return canonical, population


def _validate_diff_snapshot_v1(snapshot: object, path: str) -> dict:
    return _parse_diff_snapshot_v1(snapshot, path)[0]


def _snapshot_diff_items_v1(
        snapshot: dict, population: list[dict]) -> dict[str, object]:
    items = {
        "snapshot:aggregate": snapshot["aggregate"],
        "snapshot:families": snapshot["families"],
        "snapshot:missing_or_omitted_state": sorted(
            snapshot["missing_or_omitted_state"], key=canonical_json_v1),
    }
    for row in population:
        items[row["path"]] = row["record"]
    return items


def diff_snapshots(before: object, after: object) -> dict:
    """Return a deterministic semantic diff between two validated payloads."""
    left, left_population = _parse_diff_snapshot_v1(before, "$.before")
    right, right_population = _parse_diff_snapshot_v1(after, "$.after")
    if left["schema_version"] != right["schema_version"]:
        _error("OE_DIFF_SNAPSHOT_INVALID", "$diff", "snapshot acquisition scopes differ")
    left_items = _snapshot_diff_items_v1(left, left_population)
    right_items = _snapshot_diff_items_v1(right, right_population)
    left_keys = set(left_items)
    right_keys = set(right_items)
    added = [
        {"identity": identity, "record": right_items[identity]}
        for identity in sorted(right_keys - left_keys)]
    removed = [
        {"identity": identity, "record": left_items[identity]}
        for identity in sorted(left_keys - right_keys)]
    changed = [
        {"identity": identity, "before": left_items[identity],
         "after": right_items[identity]}
        for identity in sorted(left_keys & right_keys)
        if canonical_json_v1(left_items[identity]) !=
        canonical_json_v1(right_items[identity])]
    return {
        "schema": SNAPSHOT_DIFF_SCHEMA,
        "before_snapshot_id": left["snapshot_id"],
        "after_snapshot_id": right["snapshot_id"],
        "before_input_manifest_sha256": left["input_manifest_sha256"],
        "after_input_manifest_sha256": right["input_manifest_sha256"],
        "added": added, "removed": removed, "changed": changed,
        "counts": {"added": len(added), "removed": len(removed),
                   "changed": len(changed)},
        "authority_ceiling": "READ_ONLY_OBSERVATION", "establishes": [],
    }


def render_snapshot_projection_v1(
        snapshot: object, *, output_format: str,
        max_rows: int, max_bytes: int) -> bytes:
    """Render an inert bounded table/graph projection as canonical JSON."""
    value, population = _parse_diff_snapshot_v1(snapshot, "$snapshot")
    return _render_snapshot_projection_parsed_v1(
        value, population, output_format=output_format,
        max_rows=max_rows, max_bytes=max_bytes)


def _render_snapshot_projection_parsed_v1(
        value: dict, population: list[dict], *, output_format: str,
        max_rows: int, max_bytes: int) -> bytes:
    if output_format not in ("table", "graph"):
        _error("OE_EXPORT_FORMAT_INVALID", "$.format",
               "bounded projection format must be table or graph")
    if (type(max_rows) is not int or max_rows <= 0 or
            type(max_bytes) is not int or max_bytes <= 0):
        _error("OE_EXPORT_BOUND_INVALID", "$export",
               "projection bounds must be finite positive integers")
    population.sort(key=lambda row: (
        row["record"]["currentness"]["state"] == "CURRENT",
        row["record"]["currentness"]["state"],
        row["record"]["family"], row["record"]["id"],
        canonical_json_v1(row["record"])))
    state_census = Counter(
        row["record"]["currentness"]["state"] for row in population)
    retained = []
    retained_bytes = 0
    for row in population:
        row_bytes = len(canonical_json_v1(row))
        if len(retained) >= max_rows or retained_bytes + row_bytes > max_bytes:
            break
        retained.append(row)
        retained_bytes += row_bytes
    retained_ids = {row["record"]["id"] for row in retained}
    omitted_state_census = Counter(
        row["record"]["currentness"]["state"] for row in population
        if row["record"]["id"] not in retained_ids)
    omitted_count = len(population) - len(retained)
    result = {
        "schema": SNAPSHOT_PROJECTION_SCHEMA,
        "format": output_format, "snapshot_id": value["snapshot_id"],
        "rows": retained, "row_bytes": retained_bytes,
        "max_rows": max_rows, "max_bytes": max_bytes,
        "population_count": len(population),
        "included_count": len(retained), "omitted_count": omitted_count,
        "state_census": dict(sorted(state_census.items())),
        "omitted_state_census": dict(sorted(omitted_state_census.items())),
        "missing_or_omitted_state": sorted(
            value["missing_or_omitted_state"], key=canonical_json_v1),
        "truncated": omitted_count != 0,
        "code": ("OE_EXPORT_REQUIRES_BOUNDED_REVIEW"
                 if omitted_count else "OK"),
        "decision_usable": omitted_count == 0,
        "authority_ceiling": "READ_ONLY_OBSERVATION", "establishes": [],
    }
    return canonical_json_v1(result)


def _export_destination_v1(
        destination: object, owned_root: object) -> tuple[pathlib.Path, pathlib.Path]:
    if not isinstance(destination, (str, os.PathLike)) or not isinstance(
            owned_root, (str, os.PathLike)):
        _error("OE_EXPORT_DESTINATION_INVALID", "$.destination",
               "destination and owned root must be explicit paths")
    requested_spelling = os.fspath(destination)
    root_spelling = os.fspath(owned_root)
    requested = pathlib.Path(requested_spelling)
    root = pathlib.Path(root_spelling)
    if not requested.is_absolute() or not root.is_absolute():
        _error("OE_EXPORT_DESTINATION_INVALID", "$.destination",
               "destination authority cannot be cwd-relative")
    try:
        if (os.path.normpath(requested_spelling) != requested_spelling or
                os.path.normpath(root_spelling) != root_spelling or
                pathlib.Path(os.path.abspath(requested_spelling)) != requested or
                pathlib.Path(os.path.abspath(root_spelling)) != root):
            raise OSError("destination or owned root spelling is not canonical")
        if _snapshot_is_link_v1(root):
            raise OSError("owned root is a link or reparse point")
        resolved_root = root.resolve(strict=True)
        if (not resolved_root.is_dir() or
                os.fspath(resolved_root) != os.fspath(root)):
            raise OSError("owned root is not a directory")
        resolved_destination = requested.resolve(strict=False)
        if os.fspath(resolved_destination) != os.fspath(requested):
            raise OSError("destination spelling aliases a different path")
        resolved_destination.relative_to(resolved_root)
        relative_parent = resolved_destination.parent.relative_to(resolved_root)
        cursor = resolved_root
        for part in relative_parent.parts:
            cursor = cursor / part
            if (_snapshot_is_link_v1(cursor) or not cursor.is_dir() or
                    os.fspath(cursor.resolve(strict=True)) != os.fspath(cursor)):
                raise OSError("destination parent is not an owned regular directory")
        repository = pathlib.Path(__file__).resolve().parents[1]
        try:
            resolved_root.relative_to(repository)
        except ValueError:
            pass
        else:
            raise OSError("repository and authority roots are not export custody")
    except (OSError, RuntimeError, ValueError):
        _error("OE_EXPORT_DESTINATION_INVALID", "$.destination",
               "destination is outside the explicit isolated owned root")
    if os.path.lexists(resolved_destination):
        _error("OE_EXPORT_DESTINATION_EXISTS", "$.destination",
               "export destination must be new and task-owned")
    return resolved_destination, resolved_root


def _snapshot_same_file_identity_v1(left: os.stat_result, right: os.stat_result) -> bool:
    return (left.st_dev, left.st_ino) == (right.st_dev, right.st_ino)


def _snapshot_windows_kernel_v1():
    if os.name != "nt":
        raise OSError("staged export requires Windows no-replace handle rename")
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateFileW.argtypes = [
        ctypes.c_wchar_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p,
        ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p]
    kernel.CreateFileW.restype = ctypes.c_void_p
    kernel.WriteFile.argtypes = [
        ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint32), ctypes.c_void_p]
    kernel.WriteFile.restype = ctypes.c_int
    kernel.ReadFile.argtypes = [
        ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint32), ctypes.c_void_p]
    kernel.ReadFile.restype = ctypes.c_int
    kernel.FlushFileBuffers.argtypes = [ctypes.c_void_p]
    kernel.FlushFileBuffers.restype = ctypes.c_int
    kernel.SetFilePointerEx.argtypes = [
        ctypes.c_void_p, ctypes.c_int64, ctypes.POINTER(ctypes.c_int64),
        ctypes.c_uint32]
    kernel.SetFilePointerEx.restype = ctypes.c_int
    kernel.SetFileInformationByHandle.argtypes = [
        ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
    kernel.SetFileInformationByHandle.restype = ctypes.c_int
    kernel.GetFileInformationByHandle.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    kernel.GetFileInformationByHandle.restype = ctypes.c_int
    kernel.GetDriveTypeW.argtypes = [ctypes.c_wchar_p]
    kernel.GetDriveTypeW.restype = ctypes.c_uint32
    kernel.GetFinalPathNameByHandleW.argtypes = [
        ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_uint32, ctypes.c_uint32]
    kernel.GetFinalPathNameByHandleW.restype = ctypes.c_uint32
    kernel.GetVolumeInformationByHandleW.argtypes = [
        ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_uint32),
        ctypes.POINTER(ctypes.c_uint32), ctypes.c_wchar_p, ctypes.c_uint32]
    kernel.GetVolumeInformationByHandleW.restype = ctypes.c_int
    kernel.CloseHandle.argtypes = [ctypes.c_void_p]
    kernel.CloseHandle.restype = ctypes.c_int
    return kernel


class _SnapshotFileTimeV1(ctypes.Structure):
    _fields_ = [("low", ctypes.c_uint32), ("high", ctypes.c_uint32)]


class _SnapshotHandleInfoV1(ctypes.Structure):
    _fields_ = [
        ("attributes", ctypes.c_uint32),
        ("creation_time", _SnapshotFileTimeV1),
        ("access_time", _SnapshotFileTimeV1),
        ("write_time", _SnapshotFileTimeV1),
        ("volume_serial", ctypes.c_uint32),
        ("size_high", ctypes.c_uint32),
        ("size_low", ctypes.c_uint32),
        ("links", ctypes.c_uint32),
        ("file_index_high", ctypes.c_uint32),
        ("file_index_low", ctypes.c_uint32),
    ]


def _snapshot_handle_info_v1(kernel, handle) -> _SnapshotHandleInfoV1:
    info = _SnapshotHandleInfoV1()
    if not kernel.GetFileInformationByHandle(handle, ctypes.byref(info)):
        raise ctypes.WinError(ctypes.get_last_error())
    return info


def _snapshot_handle_regular_v1(info: _SnapshotHandleInfoV1, size: int) -> bool:
    observed_size = (info.size_high << 32) | info.size_low
    return not (info.attributes & (0x10 | 0x400)) and info.links == 1 and (
        observed_size == size)


def _snapshot_hardlink_publication_capable_v1(kernel, handle) -> bool:
    """Require no hard links or a live, immutable owner-only descriptor."""
    flags = ctypes.c_uint32()
    if not kernel.GetVolumeInformationByHandleW(
            handle, None, 0, None, None, ctypes.byref(flags), None, 0):
        raise ctypes.WinError(ctypes.get_last_error())
    return not bool(flags.value & 0x00400000) or bool(
        flags.value & 0x8 and _snapshot_sealed_dacl_v1(handle))


def _snapshot_security_api_v1():
    security = ctypes.WinDLL("advapi32", use_last_error=True)
    pointer = ctypes.c_void_p
    security.ConvertStringSecurityDescriptorToSecurityDescriptorW.argtypes = [
        ctypes.c_wchar_p, ctypes.c_uint32, ctypes.POINTER(pointer), pointer]
    security.ConvertStringSecurityDescriptorToSecurityDescriptorW.restype = ctypes.c_int
    security.ConvertSecurityDescriptorToStringSecurityDescriptorW.argtypes = [
        pointer, ctypes.c_uint32, ctypes.c_uint32, ctypes.POINTER(pointer), pointer]
    security.ConvertSecurityDescriptorToStringSecurityDescriptorW.restype = ctypes.c_int
    security.GetSecurityInfo.argtypes = [pointer, ctypes.c_int, ctypes.c_uint32,
        pointer, pointer, pointer, pointer, ctypes.POINTER(pointer)]
    security.GetSecurityInfo.restype = ctypes.c_uint32
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.LocalFree.argtypes = [pointer]
    kernel.LocalFree.restype = pointer
    return security, kernel.LocalFree


@contextlib.contextmanager
def _snapshot_creation_security_v1():
    """Seal a new stage at creation, without touching any pre-existing ACL.

    Deny WRITE_ATTRIBUTES (including native hard links), WRITE_DAC and
    WRITE_OWNER to ordinary reopeners, including OWNER RIGHTS. Only the owner
    can read/delete after the original write-capable creation handle closes.
    """
    security, free = _snapshot_security_api_v1()
    descriptor = ctypes.c_void_p()
    if not security.ConvertStringSecurityDescriptorToSecurityDescriptorW(
            "D:P(D;;0x000C0100;;;WD)(D;;0x000C0100;;;OW)(A;;0x00130089;;;OW)",
            1, ctypes.byref(descriptor), None):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        yield descriptor
    finally:
        free(descriptor)


def _snapshot_sealed_dacl_v1(handle):
    """Read back the actual protected DACL through the original object handle."""
    security, free = _snapshot_security_api_v1()
    observed = ctypes.c_void_p()
    code = security.GetSecurityInfo(
        handle, 1, 4, None, None, None, None, ctypes.byref(observed))
    if code:
        raise ctypes.WinError(code)
    try:
        with _snapshot_creation_security_v1() as expected:
            values = []
            for descriptor in (expected, observed):
                text = ctypes.c_void_p()
                if not security.ConvertSecurityDescriptorToStringSecurityDescriptorW(
                        descriptor, 1, 4, ctypes.byref(text), None):
                    raise ctypes.WinError(ctypes.get_last_error())
                try:
                    values.append(ctypes.wstring_at(text))
                finally:
                    free(text)
            return values[0] == values[1]
    finally:
        free(observed)


def _snapshot_check_parents_v1(kernel, parents):
    for handle, path, identity in parents:
        info = _snapshot_handle_info_v1(kernel, handle)
        if (info.attributes & 0x400 or not info.attributes & 0x10 or
                (info.volume_serial, info.file_index_high, info.file_index_low) != identity or
                str(_windows_handle_name_v1(kernel, handle)).casefold() != str(path).casefold()):
            raise OSError("export parent identity, canonical name or type changed")


@contextlib.contextmanager
def _snapshot_export_parents_v1(kernel, target):
    """Hold every component through publication; create only below this parent."""
    if (not target.is_absolute() or len(target.drive) != 2 or target.drive[1] != ":" or
            kernel.GetDriveTypeW(target.anchor) != 3 or any(
                part in {".", ".."} or ":" in part or part.rstrip(" .") != part or
                pathlib.PureWindowsPath(part).is_reserved() for part in target.parts[1:])):
        raise OSError("export requires a canonical fixed-drive path")
    parents = []
    try:
        requested = pathlib.PureWindowsPath(target.anchor)
        for part in (None, *target.parent.parts[1:]):
            if part is None:
                handle = kernel.CreateFileW(
                    target.anchor, 0x80000000, 1, None, 3, 0x02200000, None)
                if handle == ctypes.c_void_p(-1).value:
                    raise ctypes.WinError(ctypes.get_last_error())
            else:
                handle = _windows_open_child_v1(
                    parents[-1][0], part, True, hold_directory=True)
                requested /= part
            # Own the handle before any subsequent operation can fail.
            parents.append((handle, requested, None))
            info = _snapshot_handle_info_v1(kernel, handle)
            parents[-1] = (handle, requested,
                (info.volume_serial, info.file_index_high, info.file_index_low))
            _snapshot_check_parents_v1(kernel, parents)
        yield parents
    finally:
        failed = False
        for handle, _, _ in reversed(parents):
            if not kernel.CloseHandle(handle):
                failed = True
        if failed:
            raise OSError("export parent handle cleanup failed")


def _snapshot_delete_stage_v1(kernel, handle) -> None:
    disposition = ctypes.c_ubyte(1)
    if not kernel.SetFileInformationByHandle(
            handle, 4, ctypes.byref(disposition), ctypes.sizeof(disposition)):
        raise ctypes.WinError(ctypes.get_last_error())


def _snapshot_atomic_no_replace_v1(handle, target: pathlib.Path) -> None:
    """Rename inside the live stage's held parent; replacement is forbidden."""
    kernel = _snapshot_windows_kernel_v1()
    if str(_windows_handle_name_v1(kernel, handle).parent).casefold() != str(target.parent).casefold():
        raise OSError("stage is outside the held intended export parent")
    name = target.name.encode("utf-16-le")
    pointer_size = ctypes.sizeof(ctypes.c_void_p)
    root_offset = (4 + pointer_size - 1) // pointer_size * pointer_size
    length_offset = root_offset + pointer_size
    name_offset = length_offset + 4
    buffer = ctypes.create_string_buffer(name_offset + len(name) + 2)
    ctypes.c_uint32.from_buffer(buffer, 0).value = 0
    ctypes.c_void_p.from_buffer(buffer, root_offset).value = None
    ctypes.c_uint32.from_buffer(buffer, length_offset).value = len(name)
    ctypes.memmove(ctypes.addressof(buffer) + name_offset, name, len(name))
    native = ctypes.WinDLL("ntdll")
    native.NtSetInformationFile.argtypes = [ctypes.c_void_p,
        ctypes.POINTER(_WindowsIoStatusV1), ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int]
    native.NtSetInformationFile.restype = ctypes.c_long
    native.RtlNtStatusToDosError.argtypes = [ctypes.c_long]
    native.RtlNtStatusToDosError.restype = ctypes.c_uint32
    status = _WindowsIoStatusV1()
    result = native.NtSetInformationFile(
        handle, ctypes.byref(status), buffer, name_offset + len(name), 10)
    if result < 0:
        code = native.RtlNtStatusToDosError(result)
        if code in {80, 183}:
            raise FileExistsError(code, "export destination became occupied")
        raise ctypes.WinError(code)


def _snapshot_stage_export_v1(raw: bytes, target: pathlib.Path) -> None:
    """Publish one exact byte string through a write/delete-excluded stage."""
    kernel = _snapshot_windows_kernel_v1()
    with _snapshot_export_parents_v1(kernel, target) as parents:
        with _snapshot_creation_security_v1() as descriptor:
            _snapshot_stage_export_held_v1(kernel, parents, descriptor, raw, target)


def _snapshot_stage_export_held_v1(kernel, parents, descriptor, raw, target):
    stage = target.with_name(
        f".{target.name}.{secrets.token_hex(16)}.implementaudit-stage")
    handle = _windows_open_child_v1(
        parents[-1][0], stage.name, False, create_security=descriptor)
    published = False
    delete_marked = False
    try:
        created = _snapshot_handle_info_v1(kernel, handle)
        if not _snapshot_handle_regular_v1(created, 0):
            raise OSError("private stage is not one regular physical file")
        if not _snapshot_hardlink_publication_capable_v1(kernel, handle):
            raise OSError(
                "volume cannot exclude hard-link topology through publication")
        _snapshot_check_parents_v1(kernel, parents)
        _snapshot_stage_v1("stage-created")
        offset = 0
        while offset < len(raw):
            chunk = raw[offset:offset + 1024 * 1024]
            buffer = ctypes.create_string_buffer(chunk)
            written = ctypes.c_uint32()
            if (not kernel.WriteFile(handle, buffer, len(chunk),
                                     ctypes.byref(written), None) or
                    written.value != len(chunk)):
                raise ctypes.WinError(ctypes.get_last_error())
            offset += written.value
        _snapshot_stage_v1("write-complete")
        if not kernel.FlushFileBuffers(handle):
            raise ctypes.WinError(ctypes.get_last_error())
        _snapshot_stage_v1("fsync-complete")
        if not kernel.SetFilePointerEx(handle, 0, None, 0):
            raise ctypes.WinError(ctypes.get_last_error())
        _snapshot_stage_v1("readback-start")
        observed = bytearray()
        while len(observed) <= len(raw):
            capacity = min(1024 * 1024, len(raw) + 1 - len(observed))
            buffer = ctypes.create_string_buffer(capacity)
            count = ctypes.c_uint32()
            if not kernel.ReadFile(
                    handle, buffer, capacity, ctypes.byref(count), None):
                raise ctypes.WinError(ctypes.get_last_error())
            if count.value == 0:
                break
            observed.extend(buffer.raw[:count.value])
        _snapshot_stage_v1("readback-eof")
        verified = _snapshot_handle_info_v1(kernel, handle)
        if (bytes(observed) != raw or
                not _snapshot_handle_regular_v1(verified, len(raw)) or
                (created.volume_serial, created.file_index_high,
                 created.file_index_low) !=
                (verified.volume_serial, verified.file_index_high,
                 verified.file_index_low)):
            raise OSError("private stage identity or exact bytes changed")
        _snapshot_stage_v1("before-publish")
        _snapshot_check_parents_v1(kernel, parents)
        if not _snapshot_hardlink_publication_capable_v1(kernel, handle):
            raise OSError("private stage publication security changed")
        final_stage = _snapshot_handle_info_v1(kernel, handle)
        if (not _snapshot_handle_regular_v1(final_stage, len(raw)) or
                (created.volume_serial, created.file_index_high,
                 created.file_index_low) !=
                (final_stage.volume_serial, final_stage.file_index_high,
                 final_stage.file_index_low)):
            raise OSError("private stage changed immediately before publication")
        _snapshot_atomic_no_replace_v1(handle, target)
        published = True
        _snapshot_check_parents_v1(kernel, parents)
        final = _snapshot_handle_info_v1(kernel, handle)
        if (not _snapshot_handle_regular_v1(final, len(raw)) or
                (created.volume_serial, created.file_index_high, created.file_index_low) !=
                (final.volume_serial, final.file_index_high, final.file_index_low) or
                str(_windows_handle_name_v1(kernel, handle)).casefold() != str(target).casefold() or
                not _snapshot_hardlink_publication_capable_v1(kernel, handle)):
            raise OSError("published export identity or custody changed")
    finally:
        if not published:
            try:
                _snapshot_delete_stage_v1(kernel, handle)
                delete_marked = True
            except OSError:
                pass
        if not kernel.CloseHandle(handle):
            raise ctypes.WinError(ctypes.get_last_error())
        if not published and not delete_marked:
            raise OSError("private stage cleanup could not be identity-bound")


def export_snapshot(
        snapshot: object, destination: object, *, owned_root: object,
        output_format: str = "json", max_rows: int | None = None,
        max_bytes: int | None = None) -> dict:
    """Write one new export below an explicit isolated task-owned root."""
    value, population = _parse_diff_snapshot_v1(snapshot, "$snapshot")
    target, root = _export_destination_v1(destination, owned_root)
    if output_format == "json":
        if max_rows is not None or max_bytes is not None:
            _error("OE_EXPORT_BOUND_INVALID", "$export",
                   "canonical JSON export is complete and cannot be truncated")
        raw = canonical_json_v1(value)
        truncated = False
    elif output_format in ("table", "graph"):
        raw = _render_snapshot_projection_parsed_v1(
            value, population, output_format=output_format,
            max_rows=max_rows, max_bytes=max_bytes)
        truncated = json.loads(raw.decode("utf-8"))["truncated"]
    else:
        _error("OE_EXPORT_FORMAT_INVALID", "$.format",
               "export format must be json, table, or graph")
    try:
        _snapshot_stage_export_v1(raw, target)
    except FileExistsError:
        _error("OE_EXPORT_DESTINATION_EXISTS", "$.destination",
               "export destination became occupied")
    except OSError:
        _error("OE_EXPORT_WRITE_FAILED", "$.destination",
               "export could not be written and verified atomically")
    return {
        "schema": SNAPSHOT_EXPORT_SCHEMA, "snapshot_id": value["snapshot_id"],
        "format": output_format, "output_sha256": hashlib.sha256(raw).hexdigest(),
        "output_bytes": len(raw), "truncated": truncated,
        "decision_usable": not truncated,
        "authority_ceiling": "EXPLICIT_TASK_OWNED_DESTINATION_ONLY",
        "establishes": [],
    }


def _load_diff_snapshot_file_v1(path: pathlib.Path, label: str) -> dict:
    try:
        raw = _native_file(path, label, 16 * 1024 * 1024)
        value = _snapshot_decode_canonical_object_v1(raw, "OE_DIFF_SNAPSHOT_INVALID")
    except OperationalEvidenceError as exc:
        if exc.code == "OE_DIFF_SNAPSHOT_INVALID":
            raise
        _error("OE_DIFF_SNAPSHOT_INVALID", label,
               "snapshot input is unreadable or not a regular canonical file")
    return _validate_diff_snapshot_v1(value, label)


def _query_observation_liveness_v1(snapshot, rows):
    """Overlay present expiry on copied query rows, never the frozen payload."""
    release = snapshot.get("collections", {}).get("release", {}).get("value")
    if type(release) is not dict or release.get("schema") != RELEASE_COLLECTION_SCHEMA:
        return rows
    boundary = release["external_boundary"]
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    if now >= boundary["expires_at"]:
        live = {"state": "STALE", "invalidators": ["CAPTURE_EXPIRED"]}
    elif now < boundary["captured_at"] or now < boundary["evaluated_at"]:
        live = {"state": "UNVERIFIED", "invalidators": ["CAPTURE_CLOCK_UNCERTAIN"]}
    else:
        live = {"state": "CURRENT", "invalidators": []}
    for row in rows:
        record = row["record"]
        if record.get("layer") != "EXTERNAL":
            continue
        record["observed_currentness"] = record["currentness"]
        record["currentness"] = _compose_currentness(record["currentness"], live)
        record["liveness"] = {"evaluated_at": now, "expires_at": boundary["expires_at"],
                              "basis": "QUERY_TIME_ONLY_NO_REFRESH"}
    return rows


_snapshot_query_policy = _query_policy_module.SnapshotQueryPolicy(
    families=FAMILIES, states=STATES,
    snapshot_schema=(SNAPSHOT_PAYLOAD_SCHEMA, REPOSITORY_SNAPSHOT_SCHEMA, CAPTURED_SNAPSHOT_SCHEMA),
    status_schema=QUERY_STATUS_SCHEMA, result_schema=QUERY_RESULT_SCHEMA,
    why_schema=QUERY_WHY_SCHEMA, canonical_json=canonical_json_v1, error=_error,
    observation_liveness=_query_observation_liveness_v1)

def _snapshot_query_records_v1(snapshot: object) -> list[dict]:
    return _snapshot_query_policy._snapshot_query_records_v1(_query_input_v1(snapshot))


def _query_input_v1(snapshot):
    if type(snapshot) is dict and type(snapshot.get("collections")) is dict and (
            snapshot.get("schema_version") in (REPOSITORY_SNAPSHOT_SCHEMA, CAPTURED_SNAPSHOT_SCHEMA) or
            set(snapshot.get("collections", {})) == {
                "native_current", "repository", "evidence_failure", "release"}):
        return _parse_diff_snapshot_v1(snapshot, "$snapshot")[0]
    return snapshot


def evaluate_currentness(snapshot: dict) -> dict:
    return _snapshot_query_policy.evaluate_currentness(_query_input_v1(snapshot))


def query_family(snapshot: dict, family: str, current_only: bool=False) -> dict:
    return _snapshot_query_policy.query_family(_query_input_v1(snapshot), family, current_only)


def explain_history_why_v1(snapshot: dict, record_id: str) -> dict:
    return _snapshot_query_policy.explain_history_why_v1(_query_input_v1(snapshot), record_id)


def normalize_history_filters_v1(filters: object) -> dict:
    """Normalize a direct query filter or the exact HC-H2B one-ID request."""
    if type(filters) is not dict:
        _error("OE_QUERY_FILTER_INVALID", "$.filters", "must be an object")
    if filters.get("schema") == HISTORY_REQUEST_SCHEMA:
        if (set(filters) != {"schema", "route", "requirement", "evidence_ids"} or
                filters.get("route") != "QUERY_HISTORY_THEN_RESUME" or
                filters.get("requirement") != "REQUIRED" or
                type(filters.get("evidence_ids")) is not list or
                len(filters["evidence_ids"]) != 1 or
                type(filters["evidence_ids"][0]) is not str or
                not HISTORY_EVENT_ID_RE.fullmatch(filters["evidence_ids"][0])):
            _error("OE_QUERY_FILTER_INVALID", "$.filters",
                   "HC-H2B request must carry one canonical evidence identity")
        return {"event_ids": list(filters["evidence_ids"])}
    if not filters or not set(filters) <= HISTORY_FILTER_KEYS:
        _error("OE_QUERY_FILTER_INVALID", "$.filters",
               "at least one supported filter is required")
    normalized = {}
    for key in sorted(filters):
        values = filters[key]
        if (type(values) is not list or not values or
                any(type(item) is not str or not item for item in values)):
            _error("OE_QUERY_FILTER_INVALID", f"$.filters.{key}",
                   "filter values must be a non-empty string array")
        unique = sorted(set(values))
        if len(unique) != len(values):
            _error("OE_QUERY_FILTER_INVALID", f"$.filters.{key}",
                   "filter values must be unique")
        if key == "event_ids" and any(
                not HISTORY_EVENT_ID_RE.fullmatch(item) for item in unique):
            _error("OE_QUERY_FILTER_INVALID", f"$.filters.{key}",
                   "event identity is not canonical")
        normalized[key] = unique
    return normalized


def _history_request_v1(request: object) -> tuple[dict, int, int]:
    if (type(request) is not dict or
            set(request) != {"schema", "filters", "max_rows", "max_bytes"} or
            request.get("schema") != QUERY_SCHEMA):
        _error("OE_QUERY_FILTER_INVALID", "$query",
               "query request has the wrong schema or key set")
    filters = normalize_history_filters_v1(request["filters"])
    for key in ("max_rows", "max_bytes"):
        value = request[key]
        if type(value) is not int or value <= 0:
            _error("OE_QUERY_BOUND_INVALID", f"$.{key}",
                   "bound must be a finite positive integer")
    return filters, request["max_rows"], request["max_bytes"]


def _load_r39_query_contract_v1() -> tuple[types.ModuleType, pathlib.Path, bytes]:
    """Execute the exact fixed sibling R0027 verifier bytes as trusted source."""
    path = pathlib.Path(__file__).resolve().parents[1] / "skills/implementaudit/scripts/rotate-canonical-state.py"
    raw = _native_file(path, "$query.r39_contract", 512 * 1024)
    name = "_implementaudit_r39_query_contract_v1"
    module = types.ModuleType(name)
    module.__file__ = os.fspath(path)
    previous = sys.modules.get(name)
    sys.modules[name] = module
    try:
        exec(compile(raw, os.fspath(path), "exec"), module.__dict__)
    except Exception:
        _error("OE_QUERY_R39_CONTRACT_INVALID", "$query.r39_contract",
               "exact R0027 query contract could not be loaded")
    finally:
        if previous is None:
            sys.modules.pop(name, None)
        else:
            sys.modules[name] = previous
    if not all(hasattr(module, name) for name in (
            "RotationError", "verify_generation_manifest_v1",
            "load_governed_source_custody_v1",
            "load_canonical_generation_pointer_oid_v1",
            "load_canonical_generation_manifest_oid_v1",
            "verify_pointer_manifest_tuple_v1",
            "require_complete_pointer_receipt_marker_route_v1")):
        _error("OE_QUERY_R39_CONTRACT_INVALID", "$query.r39_contract",
               "exact R0027 query contract is incomplete")
    return module, path, raw


def _validate_query_manifest_v1(
        manifest: object, path: str, r39: types.ModuleType | None = None) -> dict:
    contract = r39 or _load_r39_query_contract_v1()[0]
    try:
        contract.verify_generation_manifest_v1(manifest)
    except contract.RotationError:
        _error("OE_QUERY_MANIFEST_INVALID", path,
               "canonical R0027 manifest verification failed")
    return manifest


def _require_r39_current_manifest_v1(
        r39: types.ModuleType, expected: dict) -> dict:
    """Bind one exact manifest to the live no-argument R0027 current selection."""
    try:
        live = r39.load_governed_source_custody_v1()
        pointer_oid = live.get("pointer_oid")
        marker_oid = live.get("marker_oid")
        if pointer_oid is None or marker_oid is None:
            raise r39.RotationError("current R0027 pointer route is incomplete")
        pointer = r39.load_canonical_generation_pointer_oid_v1(
            live["repo_path"], pointer_oid)
        manifest_oid = pointer["generation_manifest_oid"]
        observed = r39.load_canonical_generation_manifest_oid_v1(
            live["repo_path"], manifest_oid)
        r39.verify_pointer_manifest_tuple_v1(
            pointer=pointer, manifest=observed, manifest_oid=manifest_oid)
        r39.require_complete_pointer_receipt_marker_route_v1(
            live=live, receipt=live["receipt"], pointer=pointer,
            pointer_oid=pointer_oid, marker_oid=marker_oid)
    except r39.RotationError:
        _error("OE_QUERY_CURRENT_MANIFEST_INVALID", "$query.current_manifest",
               "live R0027 pointer/receipt/marker selection is not exact")
    if canonical_json_v1(observed) != canonical_json_v1(expected):
        _error("OE_QUERY_CURRENT_MANIFEST_INVALID", "$query.current_manifest",
               "supplied manifest is not the live R0027 current selection")
    return observed


def encode_query_cursor_v1(
        request: dict, manifest: dict, position: dict) -> str:
    filters, _rows, _bytes = _history_request_v1(request)
    _validate_query_manifest_v1(manifest, "$manifest")
    if (type(position) is not dict or set(position) != {"sequence", "event_id"} or
            type(position.get("sequence")) is not str or
            not HISTORY_SEQUENCE_RE.fullmatch(position["sequence"]) or
            type(position.get("event_id")) is not str or
            not HISTORY_EVENT_ID_RE.fullmatch(position["event_id"])):
        _error("OE_QUERY_CURSOR_POSITION_STALE", "$.requested_position",
               "cursor position is not canonical")
    body = {
        "schema": HISTORY_CURSOR_SCHEMA,
        "query_contract": HISTORY_QUERY_SCHEMA,
        "generation_id": manifest["generation_id"],
        "manifest_digest": manifest["manifest_digest"],
        "filters_sha256": hashlib.sha256(canonical_json_v1(filters)).hexdigest(),
        "requested_position": dict(position),
    }
    raw = canonical_json_v1(body)
    payload = base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")
    return f"iaqcur-v1.{payload}.{hashlib.sha256(raw).hexdigest()}"


def decode_query_cursor_v1(
        cursor: str, request: dict, manifest: dict) -> dict:
    filters, _rows, _bytes = _history_request_v1(request)
    _validate_query_manifest_v1(manifest, "$manifest")
    if type(cursor) is not str:
        _error("OE_QUERY_CURSOR_DIGEST_INVALID", "$.cursor",
               "cursor is not text")
    parts = cursor.split(".")
    if len(parts) != 3 or parts[0] != "iaqcur-v1" or not re.fullmatch(
            r"[0-9a-f]{64}", parts[2]):
        _error("OE_QUERY_CURSOR_DIGEST_INVALID", "$.cursor",
               "cursor framing or checksum is malformed")
    try:
        raw = base64.b64decode(
            parts[1] + "=" * (-len(parts[1]) % 4), altchars=b"-_",
            validate=True)
    except (ValueError, TypeError):
        _error("OE_QUERY_CURSOR_DIGEST_INVALID", "$.cursor",
               "cursor payload is malformed")
    if hashlib.sha256(raw).hexdigest() != parts[2]:
        _error("OE_QUERY_CURSOR_DIGEST_INVALID", "$.cursor",
               "cursor checksum does not match its payload")
    body = decode_strict_json_bytes(raw, "history query cursor")
    if (type(body) is not dict or set(body) != {
            "schema", "query_contract", "generation_id", "manifest_digest",
            "filters_sha256", "requested_position"} or
            body.get("schema") != HISTORY_CURSOR_SCHEMA or
            body.get("query_contract") != HISTORY_QUERY_SCHEMA):
        _error("OE_QUERY_CURSOR_VERSION_MISMATCH", "$.cursor",
               "cursor schema or query contract is unsupported")
    if body.get("generation_id") != manifest["generation_id"]:
        _error("OE_QUERY_CURSOR_GENERATION_MISMATCH", "$.cursor",
               "cursor generation is not current")
    if body.get("manifest_digest") != manifest["manifest_digest"]:
        _error("OE_QUERY_CURSOR_MANIFEST_MISMATCH", "$.cursor",
               "cursor manifest is not current")
    if body.get("filters_sha256") != hashlib.sha256(
            canonical_json_v1(filters)).hexdigest():
        _error("OE_QUERY_CURSOR_FILTER_MISMATCH", "$.cursor",
               "cursor filters differ from this request")
    position = body.get("requested_position")
    if (type(position) is not dict or set(position) != {"sequence", "event_id"} or
            type(position.get("sequence")) is not str or
            not HISTORY_SEQUENCE_RE.fullmatch(position["sequence"]) or
            type(position.get("event_id")) is not str or
            not HISTORY_EVENT_ID_RE.fullmatch(position["event_id"])):
        _error("OE_QUERY_CURSOR_POSITION_STALE", "$.cursor.requested_position",
               "cursor position is not canonical")
    return body


def _history_manifests_v1(
        current_manifest: dict, load_predecessor,
        r39: types.ModuleType) -> list[dict]:
    current = _validate_query_manifest_v1(current_manifest, "$manifest", r39)
    manifests = [current]
    seen = {current["manifest_digest"]}
    expected = current.get("predecessor_manifest_digest")
    while expected is not None:
        if type(expected) is not str or not re.fullmatch(r"[0-9a-f]{64}", expected):
            _error("OE_QUERY_MANIFEST_INVALID", "$manifest.predecessor",
                   "predecessor digest is malformed")
        if expected in seen:
            _error("OE_QUERY_MANIFEST_INVALID", "$manifest.predecessor",
                   "predecessor chain contains a cycle")
        try:
            predecessor = load_predecessor(expected)
        except OperationalEvidenceError:
            raise
        except Exception:
            _error("OE_QUERY_MANIFEST_INVALID", "$manifest.predecessor",
                   "verified predecessor could not be loaded")
        predecessor = _validate_query_manifest_v1(
            predecessor, "$manifest.predecessor", r39)
        if predecessor["manifest_digest"] != expected:
            _error("OE_QUERY_MANIFEST_INVALID", "$manifest.predecessor",
                   "loader returned a foreign predecessor")
        if (predecessor.get("controller_id") != current.get("controller_id") or
                predecessor.get("claim_id") != current.get("claim_id") or
                predecessor.get("run_id") != current.get("run_id")):
            _error("OE_QUERY_MANIFEST_INVALID", "$manifest.predecessor",
                   "predecessor crossed controller, claim, or run custody")
        manifests.append(predecessor)
        seen.add(expected)
        expected = predecessor.get("predecessor_manifest_digest")
    return manifests


def _history_event_v1(manifest: dict, row: dict, load_segment) -> tuple[dict, bytes]:
    try:
        raw = load_segment(manifest, row)
    except OperationalEvidenceError:
        raise
    except Exception:
        _error("OE_QUERY_SEGMENT_INVALID", "$.segment",
               "referenced event segment could not be loaded")
    if type(raw) is not bytes or hashlib.sha256(raw).hexdigest() != (
            row["segment_digest"].removeprefix("sha256:")):
        _error("OE_QUERY_SEGMENT_INVALID", "$.segment",
               "referenced event segment digest differs")
    event = decode_strict_json_bytes(raw, "history event segment")
    if canonical_json_v1(event) != raw:
        _error("OE_QUERY_SEGMENT_INVALID", "$.segment",
               "event segment is not canonical")
    candidate = dict(event) if type(event) is dict else {}
    candidate.pop("event_id", None)
    expected_id = "iaevt-v1-" + hashlib.sha256(
        canonical_json_v1(candidate)).hexdigest()
    if (type(event) is not dict or
            event.get("schema_version") != HISTORY_EVENT_SCHEMA or
            event.get("event_id") != row["event_id"] or
            event.get("event_id") != expected_id or
            event.get("sequence") != row["sequence"] or
            event.get("record_kind") != row["record_kind"] or
            event.get("source_evidence_id") != row["source_evidence_id"] or
            event.get("generation_id") != manifest["generation_id"] or
            event.get("controller_id") != manifest.get("controller_id") or
            event.get("run_id") != manifest.get("run_id")):
        _error("OE_QUERY_SEGMENT_INVALID", "$.segment",
               "event segment crossed its verified manifest custody")
    return event, raw


def _history_matches_v1(event: dict, filters: dict) -> bool:
    fields = {
        "event_ids": "event_id", "record_kinds": "record_kind",
        "subject_ids": "subject_id", "source_evidence_ids": "source_evidence_id",
        "statuses": "status", "transitions": "transition"}
    return all(event.get(fields[key]) in values for key, values in filters.items())


def query_history_v1(
        request: dict, current_manifest: dict, cursor: str | None = None,
        *, load_segment, load_predecessor) -> dict:
    """Read only the verified predecessor chain under explicit finite bounds."""
    filters, max_rows, max_bytes = _history_request_v1(request)
    r39, r39_path, r39_raw = _load_r39_query_contract_v1()
    _validate_query_manifest_v1(current_manifest, "$manifest", r39)
    _require_r39_current_manifest_v1(r39, current_manifest)
    manifests = _history_manifests_v1(
        current_manifest, load_predecessor, r39)
    cursor_body = (decode_query_cursor_v1(cursor, request, current_manifest)
                   if cursor is not None else None)
    requested_position = (cursor_body["requested_position"]
                          if cursor_body is not None else None)
    population = []
    identities = set()
    for manifest in manifests:
        for row in manifest["events"]:
            identity = (row["sequence"], row["event_id"])
            if identity in identities:
                _error("OE_QUERY_MANIFEST_INVALID", "$.manifest.events",
                       "predecessor population repeats an event position")
            identities.add(identity)
            population.append((identity, manifest, row))
    population.sort(key=lambda item: item[0])
    if requested_position is not None:
        position_tuple = (
            requested_position["sequence"], requested_position["event_id"])
        if position_tuple not in identities:
            _error("OE_QUERY_CURSOR_POSITION_STALE", "$.cursor.requested_position",
                   "cursor position is absent from verified history")
    else:
        position_tuple = None
    rows = []
    row_bytes = 0
    truncated = False
    observed_start = None
    observed_end = None
    next_position = None
    metadata_fields = {
        "event_ids": "event_id", "record_kinds": "record_kind",
        "source_evidence_ids": "source_evidence_id"}
    for identity, manifest, row in population:
        if position_tuple is not None and identity <= position_tuple:
            continue
        if observed_start is None:
            observed_start = {"sequence": identity[0], "event_id": identity[1]}
        observed_end = {"sequence": identity[0], "event_id": identity[1]}
        if any(row[metadata_fields[key]] not in values
               for key, values in filters.items() if key in metadata_fields):
            continue
        event, raw = _history_event_v1(manifest, row, load_segment)
        if not _history_matches_v1(event, filters):
            continue
        if len(rows) >= max_rows or row_bytes + len(raw) > max_bytes:
            truncated = True
            break
        rows.append(event)
        row_bytes += len(raw)
        next_position = {"sequence": identity[0], "event_id": identity[1]}
    next_cursor = None
    if truncated and next_position is not None:
        next_cursor = encode_query_cursor_v1(
            request, current_manifest, next_position)
    result = {
        "schema": QUERY_RESULT_SCHEMA,
        "query_contract": HISTORY_QUERY_SCHEMA,
        "filters": filters,
        "rows": rows,
        "row_bytes": row_bytes,
        "max_rows": max_rows, "max_bytes": max_bytes,
        "coverage": {"start": observed_start, "end": observed_end},
        "requested_position": requested_position,
        "next_cursor": next_cursor,
        "truncated": truncated,
        "code": ("OE_QUERY_REQUIRES_BOUNDED_REVIEW" if truncated else "OK"),
        "decision_usable": cursor is None and not truncated,
        "authority_ceiling": "READ_ONLY_OBSERVATION",
        "establishes": [],
    }
    if _native_file(r39_path, "$query.r39_contract", 512 * 1024) != r39_raw:
        _error("OE_QUERY_R39_CONTRACT_CHANGED", "$query.r39_contract",
               "R0027 query contract changed during the bounded read")
    _require_r39_current_manifest_v1(r39, current_manifest)
    return result


def _load_selected_snapshot_v1() -> dict:
    # This read-only consumer stays inside the real native observation. No
    # provisional fact can escape a failed owner close; it accepts no token or
    # caller-supplied native state. Publisher checks retain their own lifetime.
    repository_read = _SelectedRepositoryReadV1()
    token = _SELECTED_REPOSITORY_READ_V1.set(repository_read)
    try:
        with _observe_native_current_v1() as native:
            payload, fence = _read_selected_snapshot_material_v1(native)
        # Native completion still precedes this fresh physical/Git/static fence.
        _snapshot_require_non_native_input_fence_v1(*fence)
        return payload
    finally:
        _SELECTED_REPOSITORY_READ_V1.reset(token)
        repository_read.close()


def _read_selected_snapshot_material_v1(native):
    """Read provisional material; only the enclosing caller qualifies it."""
    repository_root = pathlib.Path(native["repository"]["root"])
    run_root = repository_root.joinpath(
        *pathlib.PurePosixPath(native["claim"]["run_root"]).parts)
    snapshots = run_root / "operational-evidence" / "snapshots"
    raw = _snapshot_current_raw_v1(snapshots)
    if raw is None:
        _error("OE_SNAPSHOT_CURRENT_INVALID", "$snapshot.CURRENT",
               "no selected operational snapshot exists")
    current = _snapshot_validate_current_v1(raw, snapshots)
    if current["source_pointer_oid"] != native["continuity"]["pointer_oid"]:
        _error("OE_SNAPSHOT_STALE", "$snapshot.CURRENT",
               "selected snapshot belongs to a different native generation")
    payload_raw = _snapshot_read_regular_v1(
        snapshots / current["snapshot_id"] / "snapshot.json", snapshots,
        "OE_SNAPSHOT_CURRENT_INVALID")
    payload = _snapshot_decode_canonical_object_v1(
        payload_raw, "OE_SNAPSHOT_CURRENT_INVALID")
    if (payload.get("schema_version") != SNAPSHOT_PAYLOAD_SCHEMA or
            payload.get("snapshot_id") != current["snapshot_id"]):
        _error("OE_SNAPSHOT_CURRENT_INVALID", "$snapshot.snapshot",
               "selected snapshot identity or schema differs")
    observed_native = _snapshot_portable_native_v1(native)
    if payload.get("collections", {}).get("native_current", {}).get("value") != observed_native:
        _error("OE_SNAPSHOT_STALE", "$snapshot.native_current",
               "selected snapshot no longer binds the observed native owners, route or hot sources")
    # An unchanged native pointer does not prove unchanged repository, optional
    # owner inputs, compiler or schema bytes. Reuse the publisher's exact input
    # derivation and complete read fence; this path does not publish anything.
    compiler_path = pathlib.Path(__file__).absolute()
    schema_path = compiler_path.parent.parent / "docs/operational-evidence-schema.json"
    compiler_raw = _native_file(compiler_path, "$snapshot.compiler", 2 * 1024 * 1024)
    schema_raw = _native_file(schema_path, "$snapshot.schema", 512 * 1024)
    collections, reobserve_inputs = _capture_snapshot_inputs_v1(native)
    material = _build_snapshot_material_v1(native, collections, schema_raw, compiler_raw)
    input_raw = _snapshot_read_regular_v1(
        snapshots / current["snapshot_id"] / "input-manifest.json", snapshots,
        "OE_SNAPSHOT_CURRENT_INVALID")
    if payload_raw != material["payload_raw"] or input_raw != material["input_raw"]:
        _error("OE_SNAPSHOT_STALE", "$snapshot.inputs",
               "selected snapshot compiler, schema or collector inputs are no longer exact")
    return payload, (compiler_path, schema_path, snapshots, compiler_raw, schema_raw,
                     native, collections, raw, reobserve_inputs)


def _repository_snapshot_missing_v1(collection):
    missing = [{"kind": "COLLECTOR_NOT_ACQUIRED", "family": family,
                "state": "UNVERIFIED", "code": "REPOSITORY_ONLY_SCOPE"}
               for family in FAMILIES if family != "CODE"]
    for fact in collection["facts"]:
        if fact["state"] not in {"CURRENT", "UNSUPPORTED"}:
            missing.append({"kind": "REPOSITORY_FACT_NON_CURRENT", "family": "CODE",
                            "state": fact["state"], "code": fact["kind"],
                            "anchor": fact.get("path", fact.get("source"))})
    return sorted(missing, key=canonical_json_v1)


def observe_repository_snapshot_v1(root: pathlib.Path) -> dict:
    """Explicit repository observation; no native owner, run or CURRENT pointer.

    This separate scope is useful before native acquisition is available. It
    cannot be consumed as a native C03/C06 snapshot or restore any currentness.
    """
    collection = collect_repository(root)
    script = pathlib.Path(__file__)
    schema_path = script.parent.parent / "docs/operational-evidence-schema.json"
    compiler_raw, _ = _read_repository_path(script)
    schema_raw, _ = _read_repository_path(schema_path)
    manifest = {
        "domain": "IA-OPERATIONAL-REPOSITORY-SNAPSHOT-v1",
        "scope": "REPOSITORY_ONLY", "schema_sha256": hashlib.sha256(schema_raw).hexdigest(),
        "compiler_sha256": hashlib.sha256(compiler_raw).hexdigest(),
        "query_policy_sha256": _QUERY_POLICY_MODULE_SHA256,
        "collection_sha256": hashlib.sha256(canonical_json_v1(collection)).hexdigest(),
        "input_profile": {"max_files": REPOSITORY_MAX_FILES,
                          "max_file_bytes": REPOSITORY_MAX_FILE_BYTES,
                          "max_total_bytes": REPOSITORY_MAX_TOTAL_BYTES,
                          "max_python_bytes": REPOSITORY_MAX_PYTHON_BYTES}}
    identity = hashlib.sha256(canonical_json_v1(manifest)).hexdigest()
    value = {
        "schema_version": REPOSITORY_SNAPSHOT_SCHEMA,
        "snapshot_id": "iarepo-v1-" + identity, "aggregate": "DEGRADED",
        "families": list(FAMILIES), "scope": "REPOSITORY_ONLY",
        "input_manifest": manifest, "input_manifest_sha256": identity,
        "missing_or_omitted_state": _repository_snapshot_missing_v1(collection),
        "collections": {"repository": {"owner": "R0038-C02", "state": "CURRENT",
            "value": collection, "sha256": manifest["collection_sha256"]}}}
    # Reuse the closed producer grammar used by diff/export. Observation metadata
    # is semantically bound but cannot authenticate the acquisition of a file.
    return _parse_repository_snapshot_v1(value, "$snapshot")[0]


def _parse_repository_snapshot_v1(value, path):
    try:
        return _parse_repository_snapshot_value_v1(value, path)
    except OperationalEvidenceError as exc:
        if exc.code == "OE_DIFF_SNAPSHOT_INVALID":
            raise
        _error("OE_DIFF_SNAPSHOT_INVALID", path, "repository snapshot contains invalid producer data")
    except (KeyError, TypeError, ValueError, OverflowError, RecursionError):
        _error("OE_DIFF_SNAPSHOT_INVALID", path, "repository snapshot contains a malformed producer branch")


def _parse_repository_snapshot_value_v1(value, path):
    keys = set(SNAPSHOT_PAYLOAD_KEYS) | {"scope", "input_manifest"}
    _snapshot_diff_exact_object_v1(value, keys, path)
    manifest = _snapshot_diff_exact_object_v1(value["input_manifest"], {
        "domain", "scope", "schema_sha256", "compiler_sha256", "query_policy_sha256",
        "collection_sha256", "input_profile"}, path + ".input_manifest")
    if (value["schema_version"] != REPOSITORY_SNAPSHOT_SCHEMA or
            value["scope"] != "REPOSITORY_ONLY" or manifest["scope"] != "REPOSITORY_ONLY" or
            manifest["domain"] != "IA-OPERATIONAL-REPOSITORY-SNAPSHOT-v1" or
            value["aggregate"] != "DEGRADED" or value["families"] != list(FAMILIES)):
        _error("OE_DIFF_SNAPSHOT_INVALID", path, "repository-only scope was widened")
    for key in ("schema_sha256", "compiler_sha256", "query_policy_sha256", "collection_sha256"):
        _snapshot_diff_digest_v1(manifest[key], path + ".input_manifest." + key)
    profile = _snapshot_diff_exact_object_v1(manifest["input_profile"], {
        "max_files", "max_file_bytes", "max_total_bytes", "max_python_bytes"}, path + ".input_profile")
    if any(type(number) is not int or number <= 0 for number in profile.values()):
        _error("OE_DIFF_SNAPSHOT_INVALID", path, "input profile must declare positive bounds")
    identity = hashlib.sha256(canonical_json_v1(manifest)).hexdigest()
    if (value["input_manifest_sha256"] != identity or value["snapshot_id"] != "iarepo-v1-" + identity):
        _error("OE_DIFF_SNAPSHOT_INVALID", path, "repository snapshot identity differs")
    collections = _snapshot_diff_exact_object_v1(value["collections"], {"repository"}, path + ".collections")
    member = _snapshot_diff_exact_object_v1(collections["repository"], {
        "owner", "state", "value", "sha256"}, path + ".collections.repository")
    if (member["owner"] != "R0038-C02" or member["state"] != "CURRENT" or
            member["sha256"] != manifest["collection_sha256"] or
            member["sha256"] != hashlib.sha256(canonical_json_v1(member["value"])).hexdigest()):
        _error("OE_DIFF_SNAPSHOT_INVALID", path, "repository collection binding differs")
    collection = _snapshot_diff_exact_object_v1(member["value"], {
        "schema", "repository", "capabilities", "diagnostics", "facts",
        "static_collector_invocations"}, path + ".collection")
    if collection["schema"] != REPOSITORY_COLLECTION_SCHEMA:
        _error("OE_DIFF_SNAPSHOT_INVALID", path, "repository producer schema differs")
    _snapshot_diff_repository_v1(collection, path + ".collection")
    if value["missing_or_omitted_state"] != _repository_snapshot_missing_v1(collection):
        _error("OE_DIFF_SNAPSHOT_INVALID", path, "missing family census differs")
    canonical = decode_strict_json_bytes(canonical_json_v1(value), "repository snapshot")
    records = _snapshot_query_policy.project_collector("repository", canonical["collections"]["repository"]["value"])
    return canonical, [{"path": "record:" + row["id"], "record": row} for row in records]


def _captured_projection_v1(member, code):
    try:
        if type(member) is not dict or type(member.get("input_text")) is not str:
            raise ValueError("captured member input_text must be text")
        # Validate the captured source before the pure decoder sees it. Raw
        # producer locators remain text and are never traversed by this path.
        value = decode_strict_json_bytes(member["input_text"].encode("utf-8"), "captured owner input")
        validate_identity_json_v1(value)
        projected = _query_policy_module.project_captured_collection(member)
        canonical_json_v1(projected)
        if any(row["family"] not in FAMILIES for row in projected["records"]):
            raise ValueError("captured projection crossed the six-family boundary")
        return projected
    except (KeyError, TypeError, ValueError, UnicodeError, RecursionError, OverflowError) as exc:
        detail = str(exc).encode("utf-8", "backslashreplace").decode("utf-8")
        _error(code, "$capture", "captured source format or structural binding differs: " + detail)


def observe_captured_snapshot_v1(kind: str, source: pathlib.Path) -> dict:
    """Explicit byte-bound source capture; no host selection or currentness gate."""
    if kind not in _query_policy_module.CAPTURE_KINDS:
        _error("OE_CAPTURE_KIND_UNSUPPORTED", "$capture", "captured source kind is not implemented")
    try:
        raw, file_type = _read_repository_path(source, maximum=_query_policy_module.CAPTURE_INPUT_MAX_BYTES)
        if file_type != "file":
            raise OSError("captured input is not a regular file")
        text = raw.decode("utf-8")
        script = pathlib.Path(__file__)
        compiler_raw, _ = _read_repository_path(script)
        schema_raw, _ = _read_repository_path(script.parent.parent / "docs/operational-evidence-schema.json")
    except (OSError, UnicodeError):
        _error("OE_CAPTURE_INPUT_UNREADABLE", "$capture", "bounded non-aliased UTF-8 file or secure reader is unavailable")
    member = {"owner": "R0038-AS03-AS08", "kind": kind, "state": "UNVERIFIED",
              "input_text": text, "sha256": hashlib.sha256(raw).hexdigest()}
    projection = _captured_projection_v1(member, "OE_CAPTURE_INVALID")
    manifest = {"domain": "IA-CAPTURED-OWNER-SNAPSHOT-v1", "scope": "CAPTURED_OWNER", "kind": kind,
                "schema_sha256": hashlib.sha256(schema_raw).hexdigest(),
                "compiler_sha256": hashlib.sha256(compiler_raw).hexdigest(),
                "query_policy_sha256": _QUERY_POLICY_MODULE_SHA256,
                "input_sha256": member["sha256"], "input_bytes": len(raw),
                "input_profile": {"max_input_bytes": _query_policy_module.CAPTURE_INPUT_MAX_BYTES,
                                  "max_records": _query_policy_module.CAPTURE_RECORD_MAX}}
    identity = hashlib.sha256(canonical_json_v1(manifest)).hexdigest()
    snapshot = {"schema_version": CAPTURED_SNAPSHOT_SCHEMA, "snapshot_id": "iacapture-v1-" + identity,
                "scope": "CAPTURED_OWNER", "aggregate": "DEGRADED", "families": list(FAMILIES),
                "input_manifest": manifest, "input_manifest_sha256": identity,
                "missing_or_omitted_state": projection["omissions"], "collections": {"captured_owner": member}}
    return _parse_captured_snapshot_v1(snapshot, "$capture")[0]


def _parse_captured_snapshot_v1(value, path):
    try:
        _snapshot_diff_exact_object_v1(value, set(SNAPSHOT_PAYLOAD_KEYS) | {"scope", "input_manifest"}, path)
        manifest = _snapshot_diff_exact_object_v1(value["input_manifest"], {
            "domain", "scope", "kind", "schema_sha256", "compiler_sha256", "query_policy_sha256",
            "input_sha256", "input_bytes", "input_profile"}, path + ".input_manifest")
        collections = _snapshot_diff_exact_object_v1(value["collections"], {"captured_owner"}, path + ".collections")
        member = _snapshot_diff_exact_object_v1(collections["captured_owner"], {
            "owner", "kind", "state", "input_text", "sha256"}, path + ".collections.captured_owner")
        if type(member["input_text"]) is not str:
            raise ValueError("captured input_text must be text")
        if (value["schema_version"] != CAPTURED_SNAPSHOT_SCHEMA or value["scope"] != "CAPTURED_OWNER" or
                value["aggregate"] != "DEGRADED" or value["families"] != list(FAMILIES) or
                manifest["domain"] != "IA-CAPTURED-OWNER-SNAPSHOT-v1" or manifest["scope"] != "CAPTURED_OWNER" or
                manifest["kind"] != member["kind"] or manifest["input_sha256"] != member["sha256"] or
                type(manifest["input_bytes"]) is not int or manifest["input_bytes"] != len(member["input_text"].encode("utf-8")) or
                manifest["input_profile"] != {"max_input_bytes": _query_policy_module.CAPTURE_INPUT_MAX_BYTES,
                                              "max_records": _query_policy_module.CAPTURE_RECORD_MAX}):
            raise ValueError("captured scope, population or input binding differs")
        for key in ("schema_sha256", "compiler_sha256", "query_policy_sha256", "input_sha256"):
            _snapshot_diff_digest_v1(manifest[key], path + ".input_manifest." + key)
        identity = hashlib.sha256(canonical_json_v1(manifest)).hexdigest()
        if value["input_manifest_sha256"] != identity or value["snapshot_id"] != "iacapture-v1-" + identity:
            raise ValueError("captured snapshot identity differs")
        projection = _captured_projection_v1(member, "OE_DIFF_SNAPSHOT_INVALID")
        if value["missing_or_omitted_state"] != projection["omissions"]:
            raise ValueError("captured omission census differs")
        raw = canonical_json_v1(value)
        if len(raw) > REPOSITORY_MAX_FILE_BYTES:
            raise ValueError("captured snapshot exceeds the existing file inspection ceiling")
        return decode_strict_json_bytes(raw, "captured snapshot"), [
            {"path": "record:" + row["id"], "record": row} for row in projection["records"]]
    except (KeyError, TypeError, ValueError, UnicodeError, RecursionError, OverflowError):
        _error("OE_DIFF_SNAPSHOT_INVALID", path, "captured snapshot contains invalid scope, source or derived census")


def _bounded_query_result_v1(result, max_rows, max_bytes):
    if (type(max_rows) is not int or max_rows <= 0 or type(max_bytes) is not int or max_bytes <= 0):
        _error("OE_QUERY_BOUND_INVALID", "$query", "query bounds must be finite positive integers")
    rows, retained, size = result["rows"], [], 0
    for row in rows:
        row_size = len(canonical_json_v1(row))
        if len(retained) >= max_rows or size + row_size > max_bytes:
            break
        retained.append(row)
        size += row_size
    omissions = Counter(row["record"]["currentness"]["state"] for row in rows[len(retained):])
    result.update({"rows": retained, "row_bytes": size, "max_rows": max_rows,
                   "max_bytes": max_bytes, "population_count": len(rows),
                   "bounded_omitted_state_census": dict(sorted(omissions.items())),
                   "truncated": len(retained) != len(rows),
                   "code": "OE_QUERY_REQUIRES_BOUNDED_REVIEW" if omissions else "OK",
                   "decision_usable": not omissions})
    return result


def build_cli_parser_v1() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="validate, query, diff, and export R0038 operational evidence")
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("validate", "canonicalize"):
        command = commands.add_parser(name)
        command.add_argument("input", type=pathlib.Path)
    scan = commands.add_parser("scan", help="emit a repository-only observation; no native selection or publication")
    scan.add_argument("repository", type=pathlib.Path)
    capture = commands.add_parser("capture", help="decode an explicit captured owner file as UNVERIFIED observations")
    capture.add_argument("kind", choices=_query_policy_module.CAPTURE_KINDS)
    capture.add_argument("input", type=pathlib.Path)
    inspect = commands.add_parser("inspect", help="inspect a frozen repository or captured-owner snapshot offline")
    inspect.add_argument("input", type=pathlib.Path)
    choice = inspect.add_mutually_exclusive_group()
    choice.add_argument("--family", choices=FAMILIES)
    choice.add_argument("--why", dest="record_id")
    choice.add_argument("--format", choices=("json", "table", "graph"))
    inspect.add_argument("--current-only", action="store_true")
    inspect.add_argument("--max-rows", type=int, default=100)
    inspect.add_argument("--max-bytes", type=int, default=262144)
    commands.add_parser("status")
    query = commands.add_parser("query")
    query.add_argument("--family", required=True, choices=FAMILIES)
    query.add_argument("--current-only", action="store_true")
    query.add_argument("--max-rows", required=True, type=int)
    query.add_argument("--max-bytes", required=True, type=int)
    why = commands.add_parser("why")
    why.add_argument("record_id")
    diff = commands.add_parser("diff")
    diff.add_argument("before", type=pathlib.Path)
    diff.add_argument("after", type=pathlib.Path)
    export = commands.add_parser("export")
    export.add_argument("--destination", required=True, type=pathlib.Path)
    export.add_argument("--owned-root", required=True, type=pathlib.Path)
    export.add_argument("--format", choices=("json", "table", "graph"),
                        default="json")
    export.add_argument("--max-rows", type=int)
    export.add_argument("--max-bytes", type=int)
    return parser


def _validate_record(value):
    if type(value) is not dict:
        _error("OE_SCHEMA_INVALID", "$", "must be an object")
    if value.get("schema") != RECORD_SCHEMA:
        _error("OE_SCHEMA_UNSUPPORTED", "$.schema",
               f"unsupported operational-evidence schema: {value.get('schema')!r}")
    _object(value, "$", exact_keys=TOP_LEVEL_KEYS, required=TOP_LEVEL_KEYS)
    if value["aggregate"] not in AGGREGATES:
        _error("OE_SCHEMA_INVALID", "$.aggregate", "unsupported aggregate")
    if type(value["families"]) is not list or tuple(value["families"]) != FAMILIES:
        _error("OE_SCHEMA_INVALID", "$.families",
               "must preserve the six frozen families in canonical order")
    affected = _string_list(
        value["affected_families"], "$.affected_families", allowed=FAMILIES)
    if value["aggregate"] == "COMPLETE" and affected:
        _error("OE_SCHEMA_INVALID", "$.affected_families",
               "COMPLETE cannot name affected families")
    if value["aggregate"] != "COMPLETE" and not affected:
        _error("OE_SCHEMA_INVALID", "$.affected_families",
               "non-COMPLETE aggregate must name affected families")

    collections = (
        ("capability_declarations", {"supported", "reason_code"},
         {"supported", "reason_code"}),
        ("currentness_predicates", {"predicate", "input_sha256"},
         {"predicate", "input_sha256"}),
        ("entities", {"record_type", "required"},
         {"record_type", "required"}),
        ("relations", {"relation_type", "source_entity_id",
                       "target_entity_id", "confidence", "inference_rule"},
         {"relation_type", "source_entity_id", "target_entity_id",
          "confidence", "inference_rule"}),
        ("payload_records", {"media_type", "payload", "payload_sha256"},
         {"media_type", "payload", "payload_sha256"}),
    )
    all_ids = set()
    entities = set()
    required_current_families = set()
    for name, keys, required in collections:
        rows = value[name]
        if type(rows) is not list:
            _error("OE_SCHEMA_INVALID", f"$.{name}", "must be an array")
        for index, row in enumerate(rows):
            path = f"$.{name}[{index}]"
            state = _common_record(
                row, path, exact_keys=keys, required_extra=required)
            if row["id"] in all_ids:
                _error("OE_SCHEMA_INVALID", path, "record id must be unique")
            all_ids.add(row["id"])
            if name == "capability_declarations":
                if type(row["supported"]) is not bool:
                    _error("OE_SCHEMA_INVALID", f"{path}.supported",
                           "must be a boolean")
                _text(row["reason_code"], f"{path}.reason_code")
            elif name == "currentness_predicates":
                _text(row["predicate"], f"{path}.predicate")
                _digest(row["input_sha256"], f"{path}.input_sha256")
            elif name == "entities":
                record_type = row["record_type"]
                if type(record_type) is not str:
                    _error("OE_SCHEMA_INVALID", f"{path}.record_type",
                           "must be a string")
                expected_family = ENTITY_FAMILIES.get(record_type)
                if expected_family is None:
                    _error("OE_SCHEMA_INVALID", f"{path}.record_type",
                           "unsupported entity type")
                if expected_family != row["family"]:
                    _error("OE_CROSS_LAYER", path,
                           "entity type crossed its frozen projection family")
                if type(row["required"]) is not bool:
                    _error("OE_SCHEMA_INVALID", f"{path}.required",
                           "must be a boolean")
                entities.add(row["id"])
                if row["required"] and state == "CURRENT":
                    required_current_families.add(row["family"])
                if (value["aggregate"] == "COMPLETE" and row["required"] and
                        state != "CURRENT"):
                    _error("OE_STALE_RECORD", path,
                           "COMPLETE requires every required entity CURRENT")
            elif name == "relations":
                if row["relation_type"] not in RELATION_TYPES:
                    _error("OE_SCHEMA_INVALID", f"{path}.relation_type",
                           "unsupported relation type")
                _text(row["source_entity_id"], f"{path}.source_entity_id")
                _text(row["target_entity_id"], f"{path}.target_entity_id")
                if row["confidence"] not in ("mechanical", "declared", "inferred"):
                    _error("OE_SCHEMA_INVALID", f"{path}.confidence",
                           "unsupported confidence")
                if row["confidence"] == "inferred":
                    _text(row["inference_rule"], f"{path}.inference_rule")
                elif row["inference_rule"] is not None:
                    _error("OE_SCHEMA_INVALID", f"{path}.inference_rule",
                           "only inferred relations name an inference rule")
            elif name == "payload_records":
                _text(row["media_type"], f"{path}.media_type")
                normalized = canonical_payload_text(row["payload"])
                digest = hashlib.sha256(normalized.encode("utf-8")).hexdigest()
                _digest(row["payload_sha256"], f"{path}.payload_sha256")
                if digest != row["payload_sha256"]:
                    _error("OE_PAYLOAD_DIGEST", f"{path}.payload_sha256",
                           "payload digest does not match canonical payload bytes")
                row["payload"] = normalized

    for index, relation in enumerate(value["relations"]):
        if (relation["source_entity_id"] not in entities or
                relation["target_entity_id"] not in entities):
            _error("OE_SCHEMA_INVALID", f"$.relations[{index}]",
                   "relation endpoint is not a retained entity")
    if (value["aggregate"] == "COMPLETE" and
            required_current_families != set(FAMILIES)):
        _error("OE_SCHEMA_INVALID", "$.entities",
               "COMPLETE must retain a required CURRENT entity for every family")
    return value


def load_operational_evidence(path: pathlib.Path):
    script_root = pathlib.Path(__file__).resolve().parent.parent
    schema_path = script_root / "docs" / "operational-evidence-schema.json"
    try:
        schema_bytes, _ = _read_repository_path(schema_path)
        input_bytes, input_type = _read_repository_path(path)
        if input_type != "file":
            raise OSError("input is not a regular file")
    except OSError:
        _error("OE_INPUT_UNREADABLE", "$", "input or schema cannot be read")
    schema = decode_strict_json_bytes(schema_bytes, "operational-evidence schema")
    _validate_schema_definition(schema)
    value = decode_strict_json_bytes(input_bytes, "operational-evidence input")
    return _validate_record(value), hashlib.sha256(
        canonical_json_v1(schema)).hexdigest()


def main() -> int:
    parser = build_cli_parser_v1()
    args = parser.parse_args()
    try:
        if args.command == "scan":
            sys.stdout.buffer.write(canonical_json_v1(observe_repository_snapshot_v1(args.repository)))
            return 0
        if args.command == "capture":
            sys.stdout.buffer.write(canonical_json_v1(observe_captured_snapshot_v1(args.kind, args.input)))
            return 0
        if args.command == "inspect":
            value = _load_diff_snapshot_file_v1(args.input, "$inspect")
            if value["schema_version"] not in (REPOSITORY_SNAPSHOT_SCHEMA, CAPTURED_SNAPSHOT_SCHEMA):
                _error("OE_INSPECT_SCOPE_INVALID", "$inspect",
                       "inspect requires a repository or captured-owner observation; native routes remain owner-selected")
            if args.current_only and not args.family:
                _error("OE_QUERY_FILTER_INVALID", "$inspect", "current-only requires a family query")
            if args.format == "json":
                result = value
            elif args.format:
                sys.stdout.buffer.write(render_snapshot_projection_v1(value, output_format=args.format,
                    max_rows=args.max_rows, max_bytes=args.max_bytes))
                return 0
            elif args.family:
                result = _bounded_query_result_v1(query_family(value, args.family, args.current_only),
                                                  args.max_rows, args.max_bytes)
            elif args.record_id:
                result = explain_history_why_v1(value, args.record_id)
                if (len(result["chain"]) + len(result["relations"]) > args.max_rows or
                        len(canonical_json_v1(result)) > args.max_bytes):
                    _error("OE_QUERY_REQUIRES_BOUNDED_REVIEW", "$inspect", "why result exceeds explicit bounds")
            else:
                result = evaluate_currentness(value)
            # A matching digest proves only the declared file/producer relation.
            if args.format != "json":
                result["acquisition_scope"] = value["scope"] + "_UNAUTHENTICATED_FILE"
            sys.stdout.buffer.write(canonical_json_v1(result))
            return 0
        if args.command in ("validate", "canonicalize"):
            value, schema_sha256 = load_operational_evidence(args.input)
            canonical = canonical_json_v1(value)
            if args.command == "canonicalize":
                sys.stdout.buffer.write(canonical)
                return 0
            census = Counter(
                row["currentness"]["state"]
                for name in ("capability_declarations", "currentness_predicates",
                             "entities", "relations", "payload_records")
                for row in value[name])
            receipt = {
                "schema": VALIDATION_SCHEMA,
                "record_schema": RECORD_SCHEMA,
                "aggregate": value["aggregate"],
                "families": list(FAMILIES),
                "canonical_sha256": hashlib.sha256(canonical).hexdigest(),
                "schema_sha256": schema_sha256,
                "fact_state_census": dict(sorted(census.items())),
            }
            sys.stdout.buffer.write(canonical_json_v1(receipt))
            return 0
        if args.command == "diff":
            before = _load_diff_snapshot_file_v1(args.before, "$.before")
            after = _load_diff_snapshot_file_v1(args.after, "$.after")
            sys.stdout.buffer.write(canonical_json_v1(
                diff_snapshots(before, after)))
            return 0
        snapshot = _load_selected_snapshot_v1()
        if args.command == "export":
            receipt = export_snapshot(
                snapshot, args.destination, owned_root=args.owned_root,
                output_format=args.format, max_rows=args.max_rows,
                max_bytes=args.max_bytes)
            sys.stdout.buffer.write(canonical_json_v1(receipt))
            return 0
        if args.command == "status":
            result = evaluate_currentness(snapshot)
        elif args.command == "why":
            result = explain_history_why_v1(snapshot, args.record_id)
        else:
            result = _bounded_query_result_v1(query_family(
                snapshot, args.family, current_only=args.current_only),
                args.max_rows, args.max_bytes)
        sys.stdout.buffer.write(canonical_json_v1(result))
        return 0
    except OperationalEvidenceError as exc:
        sys.stderr.buffer.write(canonical_json_v1(exc.receipt()))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
