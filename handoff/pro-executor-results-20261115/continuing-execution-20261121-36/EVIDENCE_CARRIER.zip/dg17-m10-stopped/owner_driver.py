#!/usr/bin/env python3
"""Execute full selected-source record consumer; no oracle knowledge or mutation."""
import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
import re
import sys
from pathlib import Path

class FileObjects:
    def __init__(self, root):
        self.root = root
        self.reads = []
    def read(self, oid, label):
        if not re.fullmatch('[0-9a-f]{40}', oid):
            raise ValueError('noncanonical fixture object identity')
        path = self.root / (oid + '.json')
        if path.is_symlink():
            raise ValueError('aliased fixture object')
        raw = path.read_bytes()
        actual = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        if actual != oid:
            raise ValueError('fixture object content identity mismatch')
        self.reads.append({'oid': oid, 'label': label})
        return raw

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--owner', type=Path, required=True)
    parser.add_argument('--cases', type=Path, required=True)
    parser.add_argument('--objects', type=Path, required=True)
    args = parser.parse_args()
    data = json.loads(args.cases.read_bytes())
    owner_raw = args.owner.read_bytes()
    specification = importlib.util.spec_from_file_location('selected_full_route_owner', args.owner)
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    rows = []
    for case in data['cases']:
        reader = FileObjects(args.objects)
        record = json.loads(reader.read(case['oid'], 'root fixture record'))
        output = io.StringIO()
        code = 0
        with contextlib.redirect_stdout(output):
            try:
                module.validate_route_record_semantics(args.objects, data['controller'], case['oid'], record,
                    allow_immutable_terminal_child=False, allow_immutable_active_child=False, object_reader=reader)
            except SystemExit as exc:
                if type(exc.code) is not int:
                    raise
                code = exc.code
        stdout = output.getvalue()
        rows.append({'name': case['name'], 'oid': case['oid'], 'exit': code, 'accepted': code == 0,
                     'owner_stdout': stdout, 'object_reads': reader.reads})
    if args.owner.read_bytes() != owner_raw:
        raise RuntimeError('Owner changed while the consumer was running')
    print(json.dumps({'schema': 'dg17.m10.structural-observations.v1',
        'owner_sha256': hashlib.sha256(owner_raw).hexdigest(), 'owner_bytes': len(owner_raw),
        'owner_function': 'validate_route_record_semantics', 'full_module_import': True,
        'constructed_record_inputs': True, 'currentness_admission': False,
        'actual_child_or_governor_actor': False, 'rows': rows}, sort_keys=True))

if __name__ == '__main__':
    main()
