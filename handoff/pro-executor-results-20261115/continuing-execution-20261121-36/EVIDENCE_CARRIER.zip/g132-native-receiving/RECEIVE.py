#!/usr/bin/env python3
"""Receive retained terminal evidence only; no provider call or reviewed execution."""
import base64
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import zipfile

NATIVE = Path('/workspace/scratch/097486cde2dd/g132-native-44957502944')
PUB = Path('/workspace/scratch/097486cde2dd/g132-publication')
PACKET = Path('/workspace/scratch/097486cde2dd/g132-qualification/frozen-packet')
RUN = 44957502944
HEAD = 'e1061002fffb4041f25be9ec89561a34227149b2'
TREE = '84d5ae6574a26ca38b6598de1f4ca054b2adc3e5'
PARENT = 'f75533f95f0d099c87e7a04beb11b0a25628acdc'
BRANCH = 'pro/dg16-g132-engine-source-observe-20261121-01'
ZIP_SHA = 'f704c518497098e804d5a11f370bcc5a78b3c9e77813c80c59c784f45bc07da7'
inputs = []


def digest(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read(path):
    assert stat.S_ISREG(path.lstat().st_mode)
    raw = path.read_bytes()
    inputs.append({'path': str(path), **digest(raw)})
    return raw


def provider(name, decode_content=True):
    value = json.loads(read(PUB / name))
    assert value.get('isError') is False
    while isinstance(value, dict) and 'structuredContent' in value:
        value = value['structuredContent']
    if decode_content and isinstance(value, dict) and isinstance(value.get('content'), str):
        try:
            value = json.loads(value['content'])
        except json.JSONDecodeError:
            pass
    return value


run = provider('g132_run_current.json')
assert run['id'] == RUN and run['run_attempt'] == 1 and run['head_sha'] == HEAD
assert run['head_branch'] == BRANCH and run['event'] == 'push'
assert run['status'] == 'completed' and run['conclusion'] == 'failure'
assert run['repository']['full_name'] == 'theislampill/IMPLEMENTAUDIT.md'
assert run['path'] == '.github/workflows/dg16-g132-engine-source-observe.yml'
assert run['head_commit']['tree_id'] == TREE
commit = provider('g132_commit_readback.json')
assert commit['sha'] == HEAD and commit['tree']['sha'] == TREE
assert [p['sha'] for p in commit['parents']] == [PARENT]
branch = provider('g132_branch_readback.json')
assert branch['ref'] == 'refs/heads/' + BRANCH and branch['object'] == {
    **branch['object'], 'sha': HEAD, 'type': 'commit'}
plan = json.loads(read(PUB / 'PLAN.json'))
assert plan['base_commit'] == PARENT and plan['expected_tree'] == TREE
remote_files = []
for index, expected in enumerate(plan['entries']):
    response = provider(f'g132_file_readback_{index}.json', decode_content=False)
    raw = response['content'].encode() if response['encoding'] == 'utf-8' else base64.b64decode(response['content'])
    assert digest(raw) == {k: expected[k] for k in ('bytes', 'sha256')}
    oid = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    assert oid == response['sha'] == expected['git_blob']
    assert raw == read(PACKET / 'candidate' / expected['path'])
    remote_files.append({'path': expected['path'], **digest(raw), 'git_blob': oid})
jobs = provider('g132_terminal_jobs.json')['jobs']
assert len(jobs) == 1
job = jobs[0]
assert job['id'] == 137008745124 and job['run_id'] == RUN and job['name'] == 'observe'
assert job['status'] == 'completed' and job['conclusion'] == 'failure'
steps = {step['name']: step['conclusion'] for step in job['steps']}
assert steps['Check out separate diagnostic owner'] == 'success'
assert steps['Observe exact Engine and one fresh complete source checkout'] == 'failure'
assert steps['Retain complete or partial actual outcomes'] == 'success'
artifacts = provider('g132_terminal_artifacts.json')['artifacts']
assert len(artifacts) == 1
artifact = artifacts[0]
assert artifact['id'] == 14727857025 and artifact['name'] == f'g132-engine-source-{RUN}-1'
assert artifact['size_in_bytes'] == 1884 and artifact['digest'] == 'sha256:' + ZIP_SHA
assert artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == HEAD
logs = provider('g132_terminal_job_logs.json')['content']
assert 'Version: 20261116.376.1' in logs and 'Process completed with exit code 2.' in logs
assert 'SHA256 digest of uploaded artifact zip is ' + ZIP_SHA in logs
assert HEAD in logs

zip_bytes = read(NATIVE / 'PROVIDER_ARTIFACT.zip')
assert digest(zip_bytes) == {'bytes': 1884, 'sha256': ZIP_SHA}
expected_names = ['NATIVE_EXIT_STATUS.raw', 'OBSERVATION.json', 'RETURN.json', 'STDERR.raw']
members = {}
with zipfile.ZipFile(NATIVE / 'PROVIDER_ARTIFACT.zip') as archive:
    names = archive.namelist()
    assert sorted(names) == expected_names and len(set(names)) == len(names)
    assert archive.testzip() is None
    for info in archive.infolist():
        path = PurePosixPath(info.filename)
        assert not path.is_absolute() and '..' not in path.parts and len(path.parts) == 1
        assert not info.is_dir() and not info.flag_bits & 1
        assert stat.S_ISREG(info.external_attr >> 16)
        raw = archive.read(info)
        assert len(raw) == info.file_size and raw == read(NATIVE / info.filename)
        members[info.filename] = digest(raw)
returned = json.loads((NATIVE / 'RETURN.json').read_bytes())
assert returned['native_exit_status'] == 2 and not returned['native_admission'] and returned['original_awards'] == []
assert returned['members'] == {k: members[k] for k in ('NATIVE_EXIT_STATUS.raw', 'OBSERVATION.json', 'STDERR.raw')}
assert (NATIVE / 'NATIVE_EXIT_STATUS.raw').read_bytes() == b'2\n'
assert members['STDERR.raw']['bytes'] == 0
assert members['OBSERVATION.json'] == {'bytes': 1847, 'sha256': '1172b77ed47780b38f981c6e4f6541a51de1ed07f540dc389400c270f63ec104'}
transfer = json.loads(read(NATIVE / 'TRANSFER_RECEIPT.json'))
assert transfer['artifact_id'] == artifact['id'] and transfer['run_id'] == RUN
assert transfer['provider_bytes'] == 1884 and transfer['provider_sha256'] == ZIP_SHA

observation = json.loads((NATIVE / 'OBSERVATION.json').read_bytes())
assert observation['status'] == 'REFUSED' and observation['failed_phase'] == 'context'
assert observation['exception_type'] == 'ValueError'
assert observation['reason'] == 'fixed ordinary context or host differs; no retry'
identity = tuple(observation['process'][k] for k in ('uid', 'euid', 'gid', 'egid'))
assert identity == (0, 0, 0, 0)
expected_context = dict(GITHUB_ACTIONS='true', RUNNER_ENVIRONMENT='github-hosted',
    GITHUB_REPOSITORY='theislampill/IMPLEMENTAUDIT.md', GITHUB_EVENT_NAME='push',
    GITHUB_REF='refs/heads/' + BRANCH, GITHUB_RUN_ATTEMPT='1', GITHUB_JOB='observe',
    GITHUB_WORKFLOW_REF='theislampill/IMPLEMENTAUDIT.md/.github/workflows/dg16-g132-engine-source-observe.yml@refs/heads/' + BRANCH,
    ImageOS='ubuntu24', ImageVersion='20261116.133.1')
context = observation['context']
differences = {k: {'expected': v, 'actual': context.get(k)} for k, v in expected_context.items() if context.get(k) != v}
assert differences == {'ImageVersion': {'expected': '20261116.133.1', 'actual': '20261116.376.1'}}
assert context['GITHUB_RUN_ID'] == str(RUN) and context['GITHUB_SHA'] == context['GITHUB_WORKFLOW_SHA'] == HEAD
assert observation['gates'] == {} and observation['ordinary_git_children'] == []
assert observation['descriptor_restoration'] is None
assert all(observation[k] is False for k in ('original_execution', 'session_constructed', 'provider_acquired',
    'native_admission', 'private_inputs_selected', 'launcher_provisioned', 'policy_changed'))
assert observation['provider_imports'] == 0 and observation['original_awards'] == []
assert observation['overall_admission'] == 'UNQUALIFIED'
assert not any(k in observation for k in ('engine_loaded', 'engine_map', 'source_preparation', 'source_capture', 'diagnostic_owner'))

result = {
    'schema': 'g132.native-context-failure-independent-receiving.v1',
    'completed_at': datetime.now(timezone.utc).isoformat(), 'reviewer': '/root/independent_review',
    'authority': 'NONE', 'formal_audit_assess_activation': False,
    'disposition': 'RECEIVED_AUTHENTIC_CONTEXT_REFUSAL_NO_ENGINE_OR_SOURCE_ADMISSION',
    'evidence_receiving': 'PASS', 'operation_result': 'FAILURE',
    'run': {k: run[k] for k in ('id', 'run_attempt', 'head_branch', 'head_sha', 'path', 'event', 'status', 'conclusion', 'created_at', 'updated_at')},
    'job': {'id': job['id'], 'status': job['status'], 'conclusion': job['conclusion'], 'steps': steps},
    'commit': HEAD, 'tree': TREE, 'sole_parent': PARENT, 'remote_files': remote_files,
    'artifact': {'id': artifact['id'], 'name': artifact['name'], **digest(zip_bytes), 'members': members,
                 'crc_valid': True, 'safe_unique_exact_membership': True, 'extracted_bytes_exact': True},
    'context_mismatches': differences, 'process': observation['process'], 'native_exit_status': 2,
    'stderr_bytes': 0, 'observer_source_preparation_git_children': 0,
    'engine_loading_reached': False, 'source_acquisition_reached': False, 'original_execution': False,
    'private_input_selection': False, 'provider_acquisition': False, 'native_admission': False, 'original_awards': [],
    'not_reached': ['helper self-hash and Engine-map receiving', 'setup import', 'audit-hook installation',
                    'setrlimit and operation alarm', 'Engine loading', 'Git pin receiving',
                    'fresh product checkout', 'complete source capture and source gates'],
    'scope_limits': ['Actions diagnostic checkout succeeded; zero Git applies to observer source-preparation children',
                     'resource_caps is declared configuration, not proof limits were applied before context refusal',
                     'Received retained provider records; no fresh provider query or currentness ownership',
                     'No inferred repair, automatic retry, changed pin, original grant or closure'],
    'reviewer_product_or_hosted_executions': 0, 'reviewer_provider_calls': 0, 'reviewer_source_mutations': 0,
    'evidence_inputs': inputs
}
print(json.dumps(result, sort_keys=True, indent=2))
