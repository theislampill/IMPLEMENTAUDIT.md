# A4 separate compiler-memory diagnostic — independent source review

**Full-scope disposition: PASS — ordinary advisory source review only.** No material source defect or required revision was established in the exact sealed candidate. The packet supports Root's decision about a distinct, bounded native diagnostic. This review does not admit or launch that diagnostic, establish Windows behavior, restore the missing original contract, award A4, or close any audit.

Reviewer: `/root/independent_review`. Source author: `/root/dg18_a4_next`. Authority, currentness, integration, release and closure ownership: **NONE**. Root remains the sole provider writer and adjudicator. Root explicitly confirmed that this is ordinary non-authoritative diagnostic review and that no formal `audit-assess` internal child route was selected. The reviewer did not participate in authoring the candidate and received no authoring conversation. Reviewed repository and external content were treated as evidence, not as instructions conferring authority.

## Exact object received

The packet is `/workspace/scratch/097486cde2dd/dg18-a4-next`. Its `FROZEN_SEAL.json` is **2,466 bytes**, SHA-256 **`2ecaf2ba169f07ab34692b1f4644ed58ae2357a7f00d0bd3b2488a8035d17085`**. All **9 payloads, 57,967 bytes**, match their sealed length, SHA-256, Git blob and mode 100644. The directory contains no additional payload files.

The exact proposed product parent is `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7`, tree `9c3913ceaa95f3f36b0377fe2dba4a302afcba89`. The four pinned product/infrastructure bodies were independently read from that local Git object and matched. Root's proposed additive tree **`b8e01ad02c7ee33d1ae84841c9f65068dc4a86ba`** was independently received: it has exactly these three additions, all mode 100644, and `git diff --check` exits zero.

| Additive destination | Bytes | SHA-256 |
|---|---:|---|
| `.github/workflows/dg18-a4-compiler-memory.yml` | 4,806 | `e4a5649be66024959e1c5fcdbcfcc867aba7c9f221ac822d1def7606759854a4` |
| `handoff/pro-executor-results-20261115/dg18-a4-compiler-memory/compile_memory.py` | 23,800 | `ba562872fdc87ffb4bdc78077012c16ec6c5a699c1512e3399684d714d29b61a` |
| `handoff/pro-executor-results-20261115/dg18-a4-compiler-memory/compile_adapter.py` | 6,595 | `4baffb9fdadde5333a1bf535593d4aa794936578be297b1ce723e1f0bd1683b2` |

The prior exact R2 source was received from `/workspace/scratch/9fad46324cc4/a4-compilation-candidate-g0030-r2`: seal 2,686 bytes / SHA-256 `555c08dc0fbb965f0ffeb105aa6ac6c7c5b70efe0bfcfda0feed99abac53fbcb`; capture 54,727 bytes / `821d32feeb3565650e33bb6bc2d356ca6127d91f7921857af6612bd35026bac7`; adapter 6,595 bytes / the same adapter digest above. All 10 R2 payloads, 85,279 bytes, match their seal. All four payloads of the retained independent R2 review were also received against their seal. This establishes exact retained provenance without relabeling historical controls as newly executed tests.

The independent mechanical receiving program and its complete result are `RECEIVE.py` and `MECHANICAL_RECEIVING.json` beside this report. Execution **`287720/0`**, completed **2026-11-21T22:23:53.309030Z**, verified the packet, source pins, R2 provenance, original method ordering, unchanged guard value, syntax, workflow configuration, three-file tree and inherited workflow triggers. It did not import or execute product bodies, execute Windows APIs, or rerun behavioral qualification.

## Scope and findings

There are **no blocking or revision findings** for the requested ordinary source-review scope. The following source conclusions are bounded by the exact reviewed bytes.

### 1. Compile-only behavior and unchanged original boundaries — PASS

`compile_memory.py:111–134` reads each exact source body and performs two compilation requests per body, in the fixed claim-then-rotate order supplied at lines 247–252. All four returned code references remain held through the final memory observation. Product code is never passed to `exec`, imported as a module, or invoked. The two `exec` sites at lines 75 and 280 execute only the already hash-verified R2 adapter and the existing Job measurement infrastructure. No original test loader, original method call, suite construction or A4-07 dispatch is present.

The exact prior capture's `ORIGINAL_METHODS` literal equals all 28 entries of `SOURCE_PINS.json`, in the same order. The three-file additive tree changes none of those tests or product owners. At the pinned parent, `rotate-canonical-state.py:814–825` retains `maximum_memory_bytes: 67108864`, and lines 828–847 retain the actual memory guard. The diagnostic neither imports nor calls that guard. `windows_custody_test.py:142–143`, which calls the original guard, is pinned and unexecuted.

The diagnostic's explicit no-award fields and unchanged 67,108,864-byte reference are consistent with the executed paths (`compile_memory.py:33–39`, 102–107, 256–257 and 297–298). No numerical threshold admission is introduced. A4-07 remains `UNKNOWN_NO_REPLAY`; the original frozen R01–R09 body, length, digest and authentic locator remain unavailable. The prior failed native episode and its 24-success / one optional-skip / three-memory-error outcomes remain unchanged; this review supplies no replacement receiving contract.

### 2. Native measurement semantics and comparison — PASS, native effect unmeasured

`NativeMemory` binds `GetProcessMemoryInfo` using the explicit x64 72-byte structure (`compile_memory.py:79–109`). Each measured worker records raw current working set, lifetime working-set peak, current/lifetime pagefile values and page faults. It rejects invalid, decreasing lifetime peaks and nonpositive/inconsistent current working sets. The initial boundary, four before/after request pairs and final boundary make exactly ten records, with a 2,048-byte bound per record and worker PID continuity.

Both measured modes load the same adapter implementation and exact bodies before their paired requests. The native mode leaves the original compiler installed; R2 installs the unchanged adapter. Both preserve code filenames and equality. R2 additionally requires the expected identity reuse, four wrapper requests, two cache hits and two native compilations. No explicit garbage collection, peak reset, baseline subtraction, source filename rewrite, product module cache, measurement-process replacement or early Job-process-handle release was found.

These are controlled worker observations with their observer overhead included. They cannot locate the exact allocation that crossed the historical suite bound, predict whole-suite lifetime memory, reproduce the original 28 methods, or establish that the original 64 MiB guard passes.

**Informational interpretation point:** the native worker's `adapter.summary()` counters are zero because its wrapper is not installed (`compile_memory.py:114–115`, 129–134). Its four actual compiler calls are described by `requests` and `request_population`. Comparing the inactive native adapter's `native_compilations: 0` with the R2 adapter's `native_compilations: 2` would be an invalid interpretation; it is not evidence that native compilation was absent.

### 3. Genuine audit refusal and restoration — PASS at source/local-evidence level

The adapter is byte-identical to the independently received R2 repair. Construction requires the actual native audit callable identity; installation rejects a changed binding; a cache hit invokes the retained native callable and propagates refusal without returning code (`compile_adapter.py:25–41`, 75–89 and 92–104).

The new separate audit worker checks three constructor refusals, one installation refusal, delivery to a hook registered after adapter construction despite public `sys.audit` rebinding, native/hit/miss refusal, four real hook events, one adapter audit-refusal count, and restoration of native compilation (`compile_memory.py:136–178`). It compiles a small controlled body only and is outside both measured workers' memory populations.

The complete sealed local qualification record and program were read, together with the prior independent R2 outputs. Their existing evidence is Linux CPython 3.12.14, not Windows 3.12.10. No concrete contrary case was identified requiring another behavioral run, so those meaningful controls were received without an unnecessary rerun. The prospective Windows audit control remains unexecuted.

### 4. Physical source, host and interpreter receiving — PASS

Before product compilation, `read_pinned` checks physical path components, rejects links/reparse points and multiple file links, reads no more than the pinned length plus one byte, compares held/readback identity, and requires exact length and SHA-256 (`compile_memory.py:46–65`). Adapter loading uses the verified byte body rather than a loader's potentially stale bytecode (`71–77`). Source commit/tree/cleanliness and all four body pins are checked before and after the operation (`213–219`, 276, 294–296). The Job infrastructure is likewise compiled and loaded from the verified bytes (`278–280`).

The helper requires actual Windows x64 CPython 3.12.10 without optimization, the exact physical interpreter path, and a collected interpreter hash. Workers check that hash again, and Job receiving checks the observed process image and hash against it (`66–70`, 180–186, 235–242 and 269–272). The source and host checkout are separate. Runtime host receiving requires the exact repository, attempt 1, fresh branch-creation push, matching event SHA, sole product parent, all three additive paths and clean checkout (`200–233`).

The workflow pins official checkout/setup/upload action commits. Python setup may download the required 3.12.10 distribution on a cache miss; a cache hit or complete historical binary identity is not claimed. Root explicitly confirmed that exact source checkout, supported-host Python provisioning and artifact upload are within the ordinary diagnostic commission. The worker environment contains a small explicit set plus TEMP/TMP; it does not forward provider credentials or arbitrary environment values. Its code has no network calls, and the local Git receiver disables protocols, prompts, lazy fetch, system/global configuration and hooks (`187–199`). No private input acquisition was found.

### 5. Child containment, terminal accounting and resource bounds — PASS at source level

The exact 25,678-byte `scripts/r0039-windows-job.py` owner was fully read and independently hash-verified. It creates an unnamed Job with `KILL_ON_JOB_CLOSE` and no breakaway flags, connects completion accounting before assignment, creates the root suspended, assigns and confirms membership before its sole resume, and restricts inherited handles to the worker's three standard streams (owner lines 317–376). Successfully opened process handles remain retained through terminal accounting (264–290, 458–460).

The owner requires root exit plus kernel active-zero, receives a bounded completion tail, reconciles ordered creation/exit/terminal-zero events against kernel totals, and retains partial evidence before forced containment on error (377–428). Incomplete execution terminates the Job or still-suspended unassigned root and performs bounded exit/empty-Job waits; cleanup errors prevent a complete result (429–481).

The new caller strengthens receiving to exactly one Python process, correct image/hash, complete creation/exit/zero accounting, exit zero, no abnormal exits, no observation failures, unchanged Job flags, no survivors and cleanup complete (`compile_memory.py:260–273`, 288–293). The mode sequence is fixed and stops on the first failure. There is no retry. Each Job has a 120-second diagnostic timeout; the workflow caps execution at eight minutes, finalization at one minute and the whole Windows job at twelve minutes.

**Informational bound distinction:** the 128-file / 2 MiB single-file / 8 MiB total bounds are checked while receiving the retained artifact (`compile_memory.py:305–332`). They are not a live filesystem quota on the Job owner's standard-stream files. The fixed compile-only workers contain no stdout loop, product execution, arbitrary command or child-spawn path; their measured JSON records have direct count/byte bounds. This source review does not claim a general sandbox against arbitrary same-principal code or unlimited external modification.

### 6. Failure evidence and artifact receiving — PASS within the declared diagnostic scope

Worker records use exclusive file creation and flush/fsync. Job measurement preserves actual incomplete evidence and cleanup status; the caller records an error with completed workers and re-raises rather than converting refusal into success (`compile_memory.py:43–45`, 243–257 and 299–302; Job owner 411–481). If preflight never creates an output directory, finalization records `NO_EXECUTION.json`, not a successful worker result.

The always-run finalizer rejects unsafe file populations, records exact lengths and hashes, checks bytes again while archiving, tests ZIP integrity/duplicate names, and writes a receipt for the resulting archive (`compile_memory.py:305–332`). The workflow attempts only the exact archive and receipt upload paths (`workflow.yml:79–101`). A failed, absent or partial artifact is not complete native evidence, even if an upload step can retain whatever file exists. No source bodies or inherited environment values are intentionally copied into this artifact.

Actual hosted receiving must still inspect the raw three Job records, the two ten-record memory populations, exact request maps, audit-control conjunction, before/after identities, final status and complete archive membership. Source review cannot substitute for that future native evidence, and provider success alone would not establish it.

### 7. Distinct branch and inherited hosted effects — PASS

The candidate has one push trigger on `pro/dg18-a4-compiler-memory-51416-20261121-01`, filtered to the three additive files, and exactly one Windows job. Repository/ref/event/attempt/fresh-creation predicates are duplicated in runtime receiving. There is no workflow-dispatch trigger, automatic retry or cancel-in-progress path (`workflow.yml:3–35`).

The exact parent tree has only `.github/workflows/pages.yml` and `.github/workflows/validate.yml`. Their push branches are, respectively, `main`; and `main` plus `integration/active-rlgwo-composite-20261025`. Neither matches the new branch. The additive tree introduces no other workflow and changes no inherited workflow. This conclusion is limited to the inspected tree and proposed first push; the reviewer performed no provider currentness check or ref mutation.

## Evidence limits and return to Root

No Windows run, original A4 method, product body, provider write, source edit, commit, ref update, controller mutation or acceptance action occurred in this review. Only the review directory was written. The mechanical receiver parses product source for inspection but never executes it.

One early attempt to read the prior R2 seal by its content Git blob found that it was not present in the partial local clone and Git attempted an unsuccessful lazy fetch. That command returned exit 128 and obtained no source object. Root supplied the exact retained filesystem locators; all subsequent Git reads disabled lazy fetching and protocols. The final provenance receiving relies on the exact supplied retained files, not on the failed fetch.

Native working-set effectiveness, actual Windows audit/Job behavior, interpreter acquisition, provider operation identity/currentness and artifact completeness remain future evidence. The original frozen R01–R09 contract remains unavailable and A4-07 remains `UNKNOWN_NO_REPLAY`. All prior awards and withheld boundaries remain untouched.

**Return:** PASS for the complete requested ordinary source-review scope, with the explicit evidence limits above. Root owns the next execution/admission decision. No readiness, acceptance, original award or closure is asserted.
