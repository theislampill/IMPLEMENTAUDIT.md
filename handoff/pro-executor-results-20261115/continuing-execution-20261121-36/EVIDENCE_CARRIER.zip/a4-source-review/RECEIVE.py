#!/usr/bin/env python3
"""Read-only ordinary receiving; no product import, Windows run or provider write."""
import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import yaml

PACKET = Path('/workspace/scratch/097486cde2dd/dg18-a4-next')
R2 = Path('/workspace/scratch/9fad46324cc4/a4-compilation-candidate-g0030-r2')
R2_REVIEW = Path('/workspace/scratch/9fad46324cc4/a4-compilation-review-g0030-r2')
REPO = Path('/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b')
PLAN = Path('/workspace/scratch/097486cde2dd/a4-publication/PLAN.json')
EXPECTED_SEAL = '2ecaf2ba169f07ab34692b1f4644ed58ae2357a7f00d0bd3b2488a8035d17085'
EXPECTED_TREE = 'b8e01ad02c7ee33d1ae84841c9f65068dc4a86ba'


def digest(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}


def receive(path, expected=None):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode) == 0o644, str(path)
    raw = path.read_bytes()
    actual = digest(raw)
    if expected is not None:
        assert all(actual[k] == expected[k] for k in actual if k in expected), str(path)
    return {'path': str(path), **actual, 'mode': '100644'}


def git(*args):
    env = {**os.environ, 'GIT_NO_LAZY_FETCH': '1', 'GIT_ALLOW_PROTOCOL': ''}
    result = subprocess.run(['git', '-c', 'protocol.allow=never', *args], cwd=REPO,
                            env=env, check=True, capture_output=True, timeout=30)
    return result.stdout


def literal_assignment(tree, name):
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets):
            return ast.literal_eval(node.value)
    raise AssertionError(name)


seal_row = receive(PACKET / 'FROZEN_SEAL.json')
assert seal_row['bytes'] == 2466 and seal_row['sha256'] == EXPECTED_SEAL
seal = json.loads((PACKET / 'FROZEN_SEAL.json').read_bytes())
members = [receive(PACKET / row['path'], row) for row in seal['files']]
assert len(members) == 9 and sum(x['bytes'] for x in members) == 57967
actual_paths = sorted(str(p.relative_to(PACKET)) for p in PACKET.rglob('*') if p.is_file())
assert actual_paths == sorted([r['path'] for r in seal['files']] + ['FROZEN_SEAL.json'])
pins = json.loads((PACKET / 'SOURCE_PINS.json').read_bytes())
assert pins['proposed_sole_parent'] == pins['product_commit'] == '51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
assert git('rev-parse', pins['product_commit'] + '^{tree}').decode().strip() == pins['product_tree']

source_rows = []
source_bodies = {}
for path, expected in pins['product_source_pins'].items():
    raw = git('show', pins['product_commit'] + ':' + path)
    actual = digest(raw)
    assert all(actual[k] == expected[k] for k in expected)
    ast.parse(raw)
    source_bodies[path] = raw
    source_rows.append({'path': path, **actual})

r2_seal = receive(R2 / 'FROZEN_SEAL.json', pins['R2_frozen_seal'])
r2_description = json.loads((R2 / 'FROZEN_SEAL.json').read_bytes())
r2_members = [receive(R2 / row['path'], row) for row in r2_description['files']]
assert len(r2_members) == 10 and sum(x['bytes'] for x in r2_members) == 85279
receive(R2 / 'capture.py', pins['R2_capture_read'])
receive(R2 / 'compile_adapter.py', pins['source_adapter_R2'])
assert (R2 / 'compile_adapter.py').read_bytes() == (PACKET / 'compile_adapter.py').read_bytes()
r2_tree = ast.parse((R2 / 'capture.py').read_bytes())
methods = literal_assignment(r2_tree, 'ORIGINAL_METHODS')
assert methods == pins['unchanged_original_method_order'] and len(methods) == pins['unchanged_original_method_count'] == 28
r2_review_seal = receive(R2_REVIEW / 'SEAL.json')
r2_review_description = json.loads((R2_REVIEW / 'SEAL.json').read_bytes())
r2_review_members = [receive(R2_REVIEW / row['path'], row) for row in r2_review_description['payloads']]
assert len(r2_review_members) == 4 and sum(x['bytes'] for x in r2_review_members) == 8421

parsed = {name: ast.parse((PACKET / name).read_bytes())
          for name in ('compile_memory.py', 'compile_adapter.py', 'qualify_diagnostic.py')}
helper = parsed['compile_memory.py']
assert literal_assignment(helper, 'SOURCE_COMMIT') == pins['product_commit']
assert literal_assignment(helper, 'SOURCE_TREE') == pins['product_tree']
assert literal_assignment(helper, 'SOURCE_PINS') == pins['product_source_pins']
assert literal_assignment(helper, 'ADAPTER_PIN') == {k: pins['source_adapter_R2'][k] for k in ('bytes', 'sha256')}
assert literal_assignment(helper, 'MODES') == ('native', 'r2', 'audit')
assert literal_assignment(helper, 'REFERENCE_LIMIT') == 67108864
rotate = ast.parse(source_bodies['skills/implementaudit/scripts/rotate-canonical-state.py'])
contract = next(n for n in rotate.body if isinstance(n, ast.FunctionDef) and n.name == 'calibration_contract_v1')
returned = next(n for n in contract.body if isinstance(n, ast.Return)).value
guard = next(ast.literal_eval(v) for k, v in zip(returned.keys, returned.values)
             if isinstance(k, ast.Constant) and k.value == 'maximum_memory_bytes')
assert guard == 67108864

workflow_raw = (PACKET / 'workflow.yml').read_text()
workflow = yaml.load(workflow_raw, Loader=yaml.BaseLoader)
assert list(workflow['on']) == ['push']
assert workflow['on']['push']['branches'] == [pins['prospective_branch']]
assert sorted(workflow['on']['push']['paths']) == sorted(pins['host_mutations'])
assert workflow['permissions'] == {'contents': 'read'}
assert workflow['concurrency']['cancel-in-progress'] == 'false'
assert len(workflow['jobs']) == 1
job = next(iter(workflow['jobs'].values()))
assert job['runs-on'] == 'windows-2022' and job['timeout-minutes'] == '12'
steps = job['steps']
actions = [s['uses'] for s in steps if 'uses' in s]
assert len(actions) == 4 and all(re.fullmatch(r'actions/[a-z-]+@[0-9a-f]{40}', a) for a in actions)
assert [s['timeout-minutes'] for s in steps if 'run' in s] == ['8', '1']
helper_sha = digest((PACKET / 'compile_memory.py').read_bytes())['sha256']
assert workflow_raw.count(helper_sha) == 2
assert workflow_raw.count(pins['source_adapter_R2']['sha256']) == 1
qualification = json.loads((PACKET / 'LOCAL_QUALIFICATION.json').read_bytes())
assert qualification['qualification']['status'] == 'PASS'
assert qualification['qualification']['controls'] == [
    'non-Windows-refuses-before-output', 'changed-physical-body-refuses',
    'compile-only-equivalence-retention-and-boundaries', 'actual-audit-refusals-and-restoration']
assert qualification['qualification']['native_Windows_executions'] == 0
assert qualification['qualification']['original_executions'] == 0

plan_row = receive(PLAN)
plan = json.loads(PLAN.read_bytes())
assert plan['expected_tree'] == EXPECTED_TREE
assert plan['base_commit'] == pins['product_commit'] and plan['base_tree'] == pins['product_tree']
tree_diff = git('diff', '--raw', '--no-abbrev', pins['product_tree'], EXPECTED_TREE).decode()
status_diff = git('diff', '--name-status', pins['product_tree'], EXPECTED_TREE).decode().splitlines()
assert status_diff == ['A\t' + p for p in sorted(pins['host_mutations'])]
assert git('diff', '--check', pins['product_tree'], EXPECTED_TREE) == b''
for path, expected in pins['host_mutations'].items():
    raw = git('show', EXPECTED_TREE + ':' + path)
    assert raw == (PACKET / expected['local_file']).read_bytes()
    entry = git('ls-tree', EXPECTED_TREE, '--', path).decode().strip()
    assert entry == '100644 blob ' + expected['git_blob'] + '\t' + path

workflow_names = git('ls-tree', '-r', '--name-only', pins['product_commit'], '.github/workflows').decode().splitlines()
assert workflow_names == ['.github/workflows/pages.yml', '.github/workflows/validate.yml']
inherited = []
for path in workflow_names:
    raw = git('show', pins['product_commit'] + ':' + path)
    value = yaml.load(raw, Loader=yaml.BaseLoader)
    branches = value['on']['push']['branches']
    assert pins['prospective_branch'] not in branches
    inherited.append({'path': path, **digest(raw), 'push_branches': branches})

result = {
    'schema': 'dg18.a4.compiler-memory.ordinary-independent-receiving.v1',
    'reviewer': '/root/independent_review', 'source_author': '/root/dg18_a4_next',
    'authority': 'NONE', 'formal_audit_assess_activation': False,
    'completed_at': datetime.now(timezone.utc).isoformat(), 'status': 'PASS_SOURCE_RECEIVING_ONLY',
    'packet_seal': seal_row, 'packet_members': members, 'payload_count': 9, 'payload_bytes': 57967,
    'source_commit': pins['product_commit'], 'source_tree': pins['product_tree'], 'source_members': source_rows,
    'r2_seal': r2_seal, 'r2_members': r2_members,
    'r2_prior_review_seal': r2_review_seal, 'r2_prior_review_members': r2_review_members,
    'original_method_order_exact': True, 'original_method_count': 28, 'unchanged_guard_bytes': guard,
    'syntax_parsed_only': list(parsed), 'existing_controls_received_not_reexecuted': qualification,
    'host_plan': plan_row, 'expected_tree': EXPECTED_TREE, 'exact_tree_diff': tree_diff,
    'diff_check_exit': 0, 'inherited_workflows': inherited,
    'candidate_actions': actions, 'candidate_worker_order': ['native', 'r2', 'audit'],
    'native_Windows_executions': 0, 'original_executions': 0, 'product_body_executions': 0,
    'provider_writes': 0, 'ref_mutations': 0, 'new_original_awards': [],
    'limits': [
        'Read-only source and existing local evidence receiving; no Windows API or Job execution',
        'Root admission/currentness and hosted receiving remain independent decisions',
        'Exact Python setup may download on cache miss; no cache-hit claim',
        'Retention bounds are finalization admission bounds, not a live filesystem quota',
        'Native worker adapter counters remain zero because its wrapper is not installed',
        'A4-07 UNKNOWN_NO_REPLAY and missing frozen R01-R09 contract remain unchanged'
    ]
}
print(json.dumps(result, sort_keys=True, indent=2))
