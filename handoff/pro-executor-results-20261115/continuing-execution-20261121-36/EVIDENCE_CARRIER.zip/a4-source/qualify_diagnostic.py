#!/usr/bin/env python3
"""Bounded behavioral controls; Linux source qualification, no native claim."""
import builtins
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
def main():
    candidate = HERE / 'compile_memory.py'
    if not candidate.is_file():
        print(json.dumps({'status':'EXPECTED_RED','failure':'diagnostic implementation absent'}))
        return 1
    spec = importlib.util.spec_from_file_location('qualified_diagnostic', candidate)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    controls=[]
    with tempfile.TemporaryDirectory(dir=HERE, prefix='control-') as tmp:
        root=Path(tmp); destination=root/'not-created'
        result=subprocess.run([sys.executable,'-I','-B',str(candidate),'--step','worker',
            '--source',str(root),'--output',str(destination),'--mode','native'],capture_output=True)
        if result.returncode == 0 or destination.exists() or b'actual Windows' not in result.stderr:
            raise AssertionError('non-Windows invocation was not refused before output')
        controls.append('non-Windows-refuses-before-output')
        body=b'raise RuntimeError("CONTROL: body executed")\n'
        path=root/'controlled.py';path.write_bytes(body)
        pin={'bytes':len(body),'sha256':__import__('hashlib').sha256(body).hexdigest()}
        if module.read_pinned(path,pin)!=body:raise AssertionError('fresh exact body differs')
        path.write_bytes(body+b'# drift\n')
        try:module.read_pinned(path,pin)
        except ValueError:pass
        else:raise AssertionError('changed physical body admitted')
        controls.append('changed-physical-body-refuses')
        path.write_bytes(body)
        rows=[]
        class Observer:
            def sample(self,label,request=None):rows.append((label,request))
        for mode in ('native','r2'):
            before=builtins.compile
            results,summary=module.compile_workload(mode,{'controlled.py':(path,pin)},Observer())
            if builtins.compile is not before:raise AssertionError('native compile not restored')
            if len(results)!=2 or results[0]!=results[1]:raise AssertionError('code equivalence failed')
            if (results[0] is results[1]) != (mode=='r2'):raise AssertionError('wrong reuse identity')
            if summary['requests']!=2 or summary['product_body_executions']!=0:
                raise AssertionError('controlled request or execution scope wrong')
        if rows != [('before-compile',1),('after-compile',1),('before-compile',2),('after-compile',2)]*2:
            raise AssertionError('compile boundaries or order changed')
        controls.append('compile-only-equivalence-retention-and-boundaries')
    audit=module.audit_controls()
    if audit != {'construction_refusals':3,'installation_refusals':1,'hook_events':4,
                 'native_refused':True,'hit_refused':True,'miss_refused':True,'compile_restored':True}:
        raise AssertionError('audit-refusal conjunction differs')
    controls.append('actual-audit-refusals-and-restoration')
    print(json.dumps({'status':'PASS','controls':controls,'original_executions':0,
        'native_Windows_executions':0,'provider_writes':0,'python':sys.version},sort_keys=True,indent=2))
    return 0
if __name__=='__main__':raise SystemExit(main())
