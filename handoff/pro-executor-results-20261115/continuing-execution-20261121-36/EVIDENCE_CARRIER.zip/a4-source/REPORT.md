# A4 separate native compiler-memory candidate

Disposition: **SOURCE-ONLY CANDIDATE FROZEN FOR INDEPENDENT COLD REVIEW; NO HOSTED OPERATION ISSUED.**

Author `/root/dg18_a4_next`; authority NONE; original awards NONE. Root remains sole adjudicator and provider writer. This packet is an engineering diagnostic, not the missing frozen R01–R09 receiving contract and not a new original A4 episode.

## New concrete progress

The full retained 823-line R2 capture, exact adapter, workflow, independent R2 receiving report, prior native-memory diagnosis, and results35 prerequisite disposition were read. The unchanged R2 adapter is now paired with a separate three-file additive workflow candidate. It answers a new bounded question: what native Windows current/lifetime peaks occur around first and repeated compilation of each exact body, and does the same R2 adapter preserve the actual native audit-refusal boundary on Windows 3.12.10?

The fixed diagnostic sequence is native, R2, then audit. The native and R2 workers each compile claim twice then rotate twice, retain all four returned code references until termination, check exact filenames and code equality, and never execute those compiled product bodies. They are deliberately controlled workers, not a reproduction of the original 28 methods. The audit worker compiles only a tiny controlled body and separately verifies three construction refusals, one installation refusal, current real hook delivery despite public audit rebinding, native/hit/miss refusal, and restoration of native compile.

The exact original source method list and product memory guard remain unchanged and unexecuted. The original 64 MiB guard is not replaced by these observations. Raw peaks are retained with 67,108,864 bytes as the unchanged reference; no numerical threshold acceptance, subtraction, GC, reset or original award is performed. A lower controlled peak cannot establish original suite success or the exact historical crossing allocation.

## Hosted proposal and resource bounds

Proposed sole parent `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7`, product tree `9c3913ceaa95f3f36b0377fe2dba4a302afcba89`. Distinct prospective branch `pro/dg18-a4-compiler-memory-51416-20261121-01`. The exact three additive destination paths and bytes are in `SOURCE_PINS.json`; a read-only `git ls-tree` on the parent confirmed all three absent (`9c8a9e/0`). No host commit/tree or branch was created in this lane.

Both workflow and runtime require the exact repository, fresh branch-creation push, attempt 1, and sole product parent. The workflow has read-only contents permission, pinned actions, no persisted checkout credentials, no cancel-in-progress, and no replay path. The helper checks exact physical Python 3.12.10, source commit/tree/cleanliness, adapter bytes, selected source bodies and current Job owner before execution; before/after readbacks must agree. Adapter and Job code are executed from the already hash-verified bytes, avoiding stale bytecode loading.

One private native Job is used per worker. The unchanged 25,678-byte `r0039-windows-job.py` owner enforces assignment before resume, KILL_ON_JOB_CLOSE, no breakaway, bounded completion waiting and terminal containment. The receiving conjunction requires exactly one Python process, the correct physical image/hash, complete creation/exit/terminal-zero accounting, exit zero, no observation failures, no survivors and cleanup complete. No process reference is released early. Each worker has a 120-second diagnostic timeout; the execute step has eight minutes, finalization one minute and the whole Windows job twelve minutes. Native sampling permits exactly ten records per measured worker, each at most 2,048 bytes. Retention permits at most 128 files, each at most 2 MiB, total at most 8 MiB; links/reparse entries refuse. Source bodies and environment values are not copied into the diagnostic artifact.

## Local evidence actually established

Expected RED `1de474/0` established that the local behavioral control could not pass without the diagnostic implementation. GREEN `11734c/0` exercised the initial candidate. After the exact-byte loading and request-map improvement, GREEN `a489c4/0` again passed all four bounded controls. Final receiving `7caf32/0` parsed all three Python files, parsed the workflow, received the exact R2 digest, checked the two workflow helper-digest bindings and timeouts, and re-executed the focused controls. Its full output is retained in `LOCAL_QUALIFICATION.json`.

Local controls were Linux CPython 3.12.14 only. They proved non-Windows refusal before output, changed physical source refusal, compile-only equivalence/reuse and actual native Python audit-hook refusals. They did not execute original methods or establish Windows memory/API/Job behavior. No broad package or original suite was rerun, because the product is unchanged and the outstanding question is explicitly native. The original 24-success / one optional-skip / three-memory-error result remains unchanged.

## Unresolved and preserved boundaries

Independent cold review and Root admission are still required before any effect. The native compiler-memory effect remains unmeasured. A4-07 remains `UNKNOWN_NO_REPLAY`; this packet neither reconciles nor retries it. The original frozen R01–R09 body, length, hash and locator remain unavailable in the bounded supplied records. Root also reported one targeted Personal Context lookup that supplied no concrete new locator; this is not a global absence claim. No archive rescan or replacement contract was produced.

DG18 Root 12/14, A2/A7 missing-body valid awards, accepted A5 current consumer/cold preservation with full A5 WITHHELD, and all OR/C02/cost-tokenizer-native/historical N1 LOST_UNKNOWN constraints remain untouched. No A5 or N1 operation was issued.

Self-critique: this small controlled workload cannot predict whole-suite lifetime peak; native observers contribute overhead; the Windows workflow and containment receiving remain unexecuted until independent review and Root admission. These limitations are explicit rather than inferred successes.

All writes in this lane are confined to this packet directory. No Root/controller/provider write, native launch, branch replay, retry, cancel, commit or original execution occurred. `PROCESS_CENSUS.json` records the closing bounded census. Suggested commit subject if Root later authorizes publication: `test: add bounded A4 native compiler-memory diagnostic`.
