# A4 separate native compiler-memory diagnostic

Authority: NONE. Product source: `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7` / tree `9c3913ceaa95f3f36b0377fe2dba4a302afcba89`. Root alone may admit or issue any hosted operation.

## Design

Build a distinct, compile-only Windows 3.12.10 diagnostic. It measures whether exact R2 reuse removes repeated native compilation of the two already pinned bodies. It does not execute those bodies, any original test method, or a replacement A4 contract. One native worker and one R2 worker each compile claim then claim again, rotate then rotate again, retaining the first code while comparing the second. All four results remain referenced until the worker terminates. This is a declared controlled workload, not a simulation or reproduction of the original 28-method population.

A third, separately contained worker exercises small-source controls: genuine native audit refusal despite public attribute rebinding, construction and installation refusals, and restoration of native compile. Controls run separately so their memory does not enter either compiler measurement. The exact 6,595-byte R2 adapter is copied without edits. The unchanged current source Job owner contains each worker, with one process required per Job, complete native creation/exit/zero accounting, exact Python image identity, and no breakaway. The control order is fixed: native, R2, audit. There is no retry.

Raw native `WorkingSetSize` and lifetime `PeakWorkingSetSize` are recorded immediately before and after each compile request and at worker boundaries. There is no GC, peak reset, baseline subtraction, altered threshold, order change, process-reference release, or product-module cache. The 64 MiB value is retained only as an unchanged reference; diagnostic completion grants no threshold pass or original award. Original method order and guard implementation are bound by source identity and remain unexecuted and unchanged.

The proposed new branch and workflow path are distinct from A4-07. The helper admits only a fresh branch creation push, attempt 1, the exact repository, sole product parent, and its three additive paths. Preflight verifies physical Python, immutable adapter bytes, source commit/tree/cleanliness, and exact source bodies plus Job owner. No writer is issued here. A4-07 remains `UNKNOWN_NO_REPLAY`.

Alternatives considered: repeating the 28-method R2 candidate would re-enter the unresolved A4-07 boundary and would still lack frozen receiving criteria; a Linux allocation rerun would not answer the native question. The compile-only Windows diagnostic answers one new bounded question without either problem. Its limitation is that any lower native peak does not establish success of the original suite or identify the precise historical case-14 allocation.

## Implementation and receiving plan

- [x] Write behavioral controls for native platform refusal before output, source drift refusal before compilation, controlled execution refusal if a product body would run, fixed paired-request population, and preserved real audit refusal.
- [x] Observe the controls fail because the new diagnostic helper is absent.
- [x] Add the exact R2 adapter, lean diagnostic helper, and first-push workflow under this packet only.
- [x] Run meaningful Linux source-only controls and syntax/YAML checks; these do not constitute Windows measurements.
- [x] Verify exact adapter and immutable source pins; seal all packet files and report explicit scope, no active process, and remaining blockers.
- [ ] Root obtains independent cold receiving and decides whether the separate diagnostic is admitted. This worker does not call provider write/launch/retry/cancel APIs.

Rollback is removal of this unissued local packet; no product tree, controller, existing evidence or provider state is modified. No commit is authorized in this lane. Suggested eventual commit subject, only if Root authorizes: `test: add bounded A4 native compiler-memory diagnostic`.

## Review focus

The worker must refuse non-Windows execution before output; immutable source drift before compile; missing native memory observations; incomplete or unexpected Job process populations; changed audit binding; and source/adapter changes between before/after readback. Raw unsuccessful observations must remain visible. The workflow's artifact seal must not follow reparse points or include source bodies/secrets. The host-source topology and unique fresh operation require independent review before admission.

Frozen contract recovery remains blocked: results35 supplies no new authentic body/length/hash/locator. No broader search or invented replacement is part of this packet.
