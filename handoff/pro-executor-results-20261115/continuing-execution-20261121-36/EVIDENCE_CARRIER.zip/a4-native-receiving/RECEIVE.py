#!/usr/bin/env python3
"""Independent read-only receiving; never import or run the diagnostic/product."""
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import time
import zipfile

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
SRC=ROOT/'dg18-a4-next'
PRIOR=ROOT/'independent-review/a4'
PUB=ROOT/'a4-publication'
ART=ROOT/'a4-native-44956925804'
OLD=Path('/workspace/scratch/9fad46324cc4/a4-compilation-candidate-g0030-r2/capture.py')
HOST='01e1be8ea75ea57d57b48bb98c32ec772cf849fe'
TREE='b8e01ad02c7ee33d1ae84841c9f65068dc4a86ba'
PRODUCT='51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
RUN=44956925804
CHECKS=[]
INPUTS={}

def check(label,value):
    CHECKS.append(dict(check=label,passed=bool(value)))
    if not value:raise AssertionError(label)

def descriptor(raw):
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),
                git_blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest())

def read(path):
    path=Path(path);raw=path.read_bytes()
    INPUTS[str(path)]=descriptor(raw)
    return raw

def unwrap(row):
    for _ in range(8):
        if isinstance(row,dict) and 'structuredContent' in row:
            row=row['structuredContent'];continue
        if isinstance(row,dict) and isinstance(row.get('content'),str):
            try:value=json.loads(row['content'])
            except (ValueError,TypeError):break
            if isinstance(value,(dict,list)):row=value;continue
        break
    return row

def provider(name):return unwrap(json.loads(read(PUB/name)))

def receive_seal(directory,name):
    raw=read(directory/name);seal=json.loads(raw)
    count=0;size=0
    for entry in seal['files']:
        value=descriptor(read(directory/entry['path']))
        check('sealed member '+str(directory.name)+'/'+entry['path'],all(value[k]==entry[k] for k in value))
        count+=1;size+=value['bytes']
    check('sealed population '+directory.name,count==seal['payload_count'] and size==seal['payload_bytes'])
    return seal,descriptor(raw)

def zip_members(raw,expected):
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        names=z.namelist()
        check('ZIP exact unique member population '+','.join(sorted(expected)),len(names)==len(set(names)) and set(names)==set(expected))
        check('ZIP complete CRC check',z.testzip() is None)
        values={}
        for entry in z.infolist():
            check('ZIP member regular safe name '+entry.filename,
                  not Path(entry.filename).is_absolute() and '..' not in Path(entry.filename).parts
                  and stat.S_IFMT(entry.external_attr>>16)!=stat.S_IFLNK and not entry.is_dir())
            value=z.read(entry)
            check('ZIP member declared length '+entry.filename,len(value)==entry.file_size)
            values[entry.filename]=value
        return values

source_seal,source_desc=receive_seal(SRC,'FROZEN_SEAL.json')
review_seal,review_desc=receive_seal(PRIOR,'SEAL.json')
check('exact source seal',source_desc['sha256']=='2ecaf2ba169f07ab34692b1f4644ed58ae2357a7f00d0bd3b2488a8035d17085')
check('prior review binds exact source seal',all(source_desc[k]==review_seal['source_seal'][k] for k in source_desc))
check('prior review expected exact host tree',review_seal['expected_host_tree']==TREE)
pins=json.loads(read(SRC/'SOURCE_PINS.json'))
run=provider('a4_run_current.json')
check('provider run identity',run['id']==RUN and run['run_attempt']==1 and run['head_sha']==HOST)
check('provider terminal outcome',run['status']=='completed' and run['conclusion']=='failure')
check('provider exact host tree',run['head_commit']['tree_id']==TREE)
check('provider exact branch and event',run['head_branch']==pins['prospective_branch'] and run['event']=='push')
check('provider workflow path',run['path']=='.github/workflows/dg18-a4-compiler-memory.yml')
check('publication message binds review seal',review_desc['sha256'] in run['head_commit']['message'])
commit=provider('a4_commit_readback.json')
check('retained commit readback tuple',commit['sha']==HOST and commit['tree']['sha']==TREE and [x['sha'] for x in commit['parents']]==[PRODUCT])
branch=provider('a4_branch_readback.json')
check('retained branch publication readback',branch['ref']=='refs/heads/'+pins['prospective_branch'] and branch['object']['sha']==HOST)
for number,local in [(0,'workflow.yml'),(1,'compile_adapter.py'),(2,'compile_memory.py')]:
    body=provider('a4_file_readback_'+str(number)+'.json')
    raw=body['content'].encode('utf-8')
    check('full provider body readback '+local,raw==read(SRC/local) and descriptor(raw)['git_blob']==body['sha'])

jobs=provider('a4_jobs_current.json')['jobs']
check('one terminal failed job',len(jobs)==1 and jobs[0]['id']==137006995607 and jobs[0]['run_id']==RUN
      and jobs[0]['status']=='completed' and jobs[0]['conclusion']=='failure')
steps={row['number']:row for row in jobs[0]['steps']}
check('execute failure and successful finalization/upload',steps[5]['conclusion']=='failure'
      and steps[6]['conclusion']=='success' and steps[7]['conclusion']=='success')
artifacts=provider('a4_terminal_artifacts.json')['artifacts']
check('one exact artifact',len(artifacts)==1 and artifacts[0]['id']==14728236298
      and artifacts[0]['workflow_run']['id']==RUN and artifacts[0]['workflow_run']['head_sha']==HOST)
archive=read(ART/'PROVIDER_ARTIFACT.zip');archive_desc=descriptor(archive)
check('provider artifact actual digest and size',archive_desc['bytes']==2173
      and archive_desc['sha256']=='817b8b1b0413111917c08ebd4bd951350de16bbf9e3b5e9034ef9b6a7e624af5'
      and artifacts[0]['size_in_bytes']==2173 and artifacts[0]['digest']=='sha256:'+archive_desc['sha256'])
outer=zip_members(archive,{'DIAGNOSTIC.zip','ZIP_RECEIPT.json'})
for name,raw in outer.items():check('received outer member equal '+name,raw==read(ART/name))
inner_desc=descriptor(outer['DIAGNOSTIC.zip'])
check('exact inner archive',inner_desc['bytes']==1597 and inner_desc['sha256']=='a80db07e815f1d61b7a3da55dea2246baca6f584121646d13eaac1f14c27d3c7')
receipt=json.loads(outer['ZIP_RECEIPT.json'])
check('inner archive receipt',receipt['archive']=={k:inner_desc[k] for k in ('bytes','sha256')} and receipt['members']==3)
inner=zip_members(outer['DIAGNOSTIC.zip'],{'FINALIZE_INTENT.json','NO_EXECUTION.json','MANIFEST.json'})
for name,raw in inner.items():check('received inner member equal '+name,raw==read(ART/'members'/name))
manifest=json.loads(inner['MANIFEST.json'])
check('inner manifest exact retained population',set(x['path'] for x in manifest['members'])=={'FINALIZE_INTENT.json','NO_EXECUTION.json'} and len(manifest['members'])==2)
for entry in manifest['members']:
    got=descriptor(inner[entry['path']])
    check('inner manifest complete byte/hash '+entry['path'],all(got[k]==entry[k] for k in ('bytes','sha256')))
check('inner manifest aggregate',manifest['bytes']==1339 and sum(x['bytes'] for x in manifest['members'])==1339)
transfer=json.loads(read(ART/'TRANSFER_RECEIPT.json'))
check('Root transfer record identity',transfer['run_id']==RUN and transfer['artifact_id']==14728236298 and transfer['provider_bytes']==2173 and transfer['provider_sha256']==archive_desc['sha256'])
for entry in transfer['members']:
    got=descriptor(inner[entry['path']])
    check('Root transfer member '+entry['path'],all(got[k]==entry[k] for k in ('bytes','sha256')))

logs=provider('a4_terminal_job_logs.json')['content']
lines=logs.splitlines()
start=next(i for i,line in enumerate(lines) if 'Traceback (most recent call last)' in line)
end=next(i for i in range(start,len(lines)) if '##[error]Process completed with exit code 1.' in lines[i])
failure='\n'.join(lines[start:end+1])+'\n'
check('traceback exact preflight route',all(part in failure for part in [
    'line 276, in execute','line 221, in host_receiving','line 184, in tool_paths',
    'line 55, in physical',"info.st_nlink!=1","ValueError: single-link regular file required"]))
check('provider log upload concordance',archive_desc['sha256'] in logs and 'Artifact ID 14728236298' in logs)
check('provider image and Python context','Version: 20261116.370.1' in logs and 'Successfully set up CPython (3.12.10)' in logs)
check('Actions wrapper observation',r'C:\Program Files\Git\bin\git.exe' in logs and 'git version 2.56.1.windows.1' in logs)

raw=read(SRC/'compile_memory.py');tree=ast.parse(raw)
functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
physical=functions['physical'];execute=functions['execute'];tools=functions['tool_paths']
condition=next(n for n in ast.walk(physical) if isinstance(n,ast.If) and 'st_nlink' in ast.unparse(n.test))
check('conjoined guard distinguishes neither failed arm',ast.unparse(condition.test)=='not stat.S_ISREG(info.st_mode) or info.st_nlink != 1')
check('execute preflight precedes all output and worker effects',execute.body[0].lineno==276
      and execute.body[1].lineno==276 and execute.body[2].lineno==277
      and next(n.lineno for n in ast.walk(execute) if isinstance(n,ast.Call) and ast.unparse(n.func)=='job.measure')==288)
old_raw=read(OLD)
check('exact retained prior capture identity',all(descriptor(old_raw)[k]==pins['R2_capture_read'][k] for k in ('bytes','sha256','git_blob')))
old_tree=ast.parse(old_raw);old_functions={n.name:n for n in old_tree.body if isinstance(n,ast.FunctionDef)}
check('prior physical tool guard lacks nlink test','st_nlink' not in ast.unparse(old_functions['physical']))
check('prior tool census retains same direct candidates',all(value in ast.unparse(old_functions['tools_census']) for value in [r'C:\\Program Files\\Git\\ucrt64\\bin\\git.exe',r'C:\\Program Files\\Git\\mingw64\\bin\\git.exe']))

# Re-derive the additive host tree from immutable parent metadata, with network/lazy fetch denied.
repo='/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b'
environment=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_ALLOW_PROTOCOL='',GIT_OPTIONAL_LOCKS='0')
process=subprocess.run(['git','-C',repo,'ls-tree','-rz',PRODUCT],env=environment,capture_output=True,check=True)
entries={}
for line in process.stdout.split(b'\0'):
    if not line:continue
    head,name=line.split(b'\t',1);mode,kind,blob=head.decode().split()
    check('parent tree leaf is blob '+name.decode(),kind=='blob')
    entries[name.decode()]=(mode,blob)
def hash_tree(leaves):
    root={}
    for name,value in leaves.items():
        parts=name.split('/');d=root
        for part in parts[:-1]:d=d.setdefault(part,{})
        d[parts[-1]]=value
    def encode(d):
        rows=[]
        for name,value in sorted(d.items(),key=lambda item:(item[0]+('/' if isinstance(item[1],dict) else '')).encode()):
            mode,blob=('40000',encode(value)) if isinstance(value,dict) else value
            rows.append(mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(blob))
        raw=b''.join(rows)
        return hashlib.sha1(b'tree '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    return encode(root)
check('immutable product tree',hash_tree(entries)==pins['product_tree'])
for path,entry in pins['host_mutations'].items():
    check('host path additive '+path,path not in entries)
    entries[path]=(entry['mode'],entry['git_blob'])
check('independently derived exact hosted tree',hash_tree(entries)==TREE)

summary=dict(schema='dg18.a4.independent-native-refusal-receiving.v1',authority='NONE',
    reviewer='/root/g132_qualification',run_id=RUN,attempt=1,host_commit=HOST,host_tree=TREE,sole_parent=PRODUCT,
    disposition='RECEIVED_AUTHENTIC_PREWORKER_REFUSAL_ONLY',checks=len(CHECKS),all_checks_passed=True,
    provider_authentication='ROOT_RETAINED_RESPONSES_REHASHED_NO_NEW_PROVIDER_CALL',
    provider_archive=archive_desc,inner_archive=inner_desc,inner_members={name:descriptor(raw) for name,raw in inner.items()},
    exact_failure=dict(exception_type='ValueError',message='single-link regular file required',
        function='physical',source_line=55,caller='tool_paths',caller_line=184,
        predicate=ast.unparse(condition.test),selected_path='UNRECORDED',actual_mode='UNRECORDED',actual_nlink='UNRECORDED'),
    worker_executions=0,worker_execution_basis='EXACT_SOURCE_CONTROL_FLOW_JOINED_TO_AUTHENTIC_TRACEBACK_AND_NO_EXECUTION_ARTIFACT',
    native_memory_measurements=0,native_compiler_effect='UNMEASURED',original_method_executions=0,
    product_body_executions=0,new_original_awards=[],provider_writes=0,source_edits=0,
    before_diagnostic_intent=True,prior_guard_change='NEW_HELPER_ADDS_SINGLE_LINK_TEST_FOR_TOOL_PATHS',
    process=dict(pid=os.getpid(),ppid=os.getppid(),uid=os.getuid(),euid=os.geteuid()),completed_time_ns=time.time_ns())
(OUT/'MECHANICAL_RECEIVING.json').write_text(json.dumps(dict(summary=summary,checks=CHECKS),sort_keys=True,indent=2)+'\n')
(OUT/'INPUT_EVIDENCE_INDEX.json').write_text(json.dumps(INPUTS,sort_keys=True,indent=2)+'\n')
(OUT/'FAILURE_TRACEBACK.txt').write_text(failure)
(OUT/'SOURCE_COMPARISON.json').write_text(json.dumps(dict(
    current_physical=ast.unparse(physical),current_tool_paths=ast.unparse(tools),
    prior_physical=ast.unparse(old_functions['physical']),prior_tools_census=ast.unparse(old_functions['tools_census']),
    prior_capture=descriptor(old_raw),current_helper=descriptor(raw)),sort_keys=True,indent=2)+'\n')
retained=OUT/'received';retained.mkdir(exist_ok=True)
for name,raw in inner.items():(retained/name).write_bytes(raw)
(retained/'PROVIDER_ARTIFACT.zip').write_bytes(archive)
(retained/'ZIP_RECEIPT.json').write_bytes(outer['ZIP_RECEIPT.json'])
print(json.dumps(summary,sort_keys=True,indent=2))
