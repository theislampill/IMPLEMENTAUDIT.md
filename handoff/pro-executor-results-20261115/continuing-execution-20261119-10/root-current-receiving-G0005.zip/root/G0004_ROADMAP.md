# Continuing original DG16–DG18 recovery

1. Restore and independently receive published checkpoint06 and actual ordinary public probe evidence. Preserve all older accepted scopes and every UNKNOWN.
2. Reconcile missing checkpoint07 payloads and two interrupted first-blob requests. Never reconstruct lost proof bytes from summaries or replay completed actors.
3. Continue the smallest executable ordinary DG17 exact-source host preparation and G132 public interface work from recovered source. Original protected effects remain separately gated.
4. Recover or lawfully prepare the N10 route-decision experiment with one substantive independent source assessment only after genuine eligibility. No actor dispatch from unavailable packets.
5. Preserve DG18 original14 criteria and binding amendments; execute only against genuine prerequisites. N1 remains LOST/UNKNOWN.
6. Publish small guarded recovery/source evidence with complete remote readback, then update PR255 continuity accurately without merge/release/closure.

This local G0001 belongs to fresh recovered custody. It does not recreate historical G000E or certify its unavailable bytes. Keep STATE/ROADMAP fixed after verified receipt; later progress goes to PROGRESS_G0001.jsonl.

## G0002 next actions

1. Complete exact already-delivered35-blob publication with currentness, expected tree/sole parent and guarded nonforce ref; read remote tree and bytes. No blob replay.
2. Rehydrate the paused G132 source child under current Root custody; it owns only its new local source directory and may not mutate Root controller or externally publish.
3. Fresh nonauthor prospective review of sealed N10 protocol, preserving the unconsumed exact-host substantive review need. Then neutral stage, current admissible route, real notice continuation and at most one actual canonical substantive host review.
4. Receive G132 provenance addendum in bounded complete reads, verify hashes and preserve six original full-source gaps; continue actual-source/interface work.
5. If exact host source passes real review and Root preflight, use authorized ordinary initial-branch push once; receive actual terminal result. Whole P04/B02 and native claims remain separately bounded.
6. Publish subsequent small continuity/evidence additions and accurately update PR255 without merge/release/closure.

## G0003 next actions

1. Stage exact reviewed v2 neutral98file tree, record actual current source/task identities, dispatch one fresh admission-only governor and receive its real decision.
2. Authorize appropriate notice continuation and at most one genuine helper source-review route. If formal child selected, obtain actual inert reservation identity, bind immutable envelope, execute actual exact resolver under scope, then release same context. No invented identity/currentness.
3. After source review and actual candidate/readiness gates, publish one authorized ordinary host branch and receive actual terminal evidence; no whole P04/B02/native promotion.
4. Receive and independently review the ongoing exact G132 interface/source packet; prove executability before isolating any fresh protected owner operation.
5. Finish/review/execute original N09 only when its actual neutral task/control packet is ready.
6. Publish precise current evidence and continuity in bounded guarded commits. Preserve every original unknown, failure, accepted scope and unchanged requirement.

## G0004 next actions

1. Fully receive actual N10 admission/poststate and persistence tail; continue the same governor with notice-only Stage2 after currentness. No repeat admission.
2. Establish actual inert reviewer reservation, immutable envelope and exact resolver receipt for the selected one substantive helper source-review route. Actual reviewer judgment precedes any candidate/readiness/host effect.
3. Fresh nonauthor N09 prospective review, then a genuine original observation only if the packet and authority pass.
4. Repair G132 complete-result custody, executable entry and tools-adoption composition in a separate source generation; preserve sealed baseline and original protected boundaries.
5. Publish frozen checkpoint09r2 with actual expected-head/tree/parent and exact remote byte readbacks. Append newer actual results separately; no rewriting sealed generations.
6. Continue original acceptance work after these milestones; no whole-cell claims, protected replay, lateG2, native fabrication, merge/release/closure.
