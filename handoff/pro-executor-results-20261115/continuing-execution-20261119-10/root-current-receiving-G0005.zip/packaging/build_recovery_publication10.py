from pathlib import Path
import datetime, hashlib, json, os, re, shutil, stat, subprocess, tarfile, zipfile

BASE = Path('/workspace/scratch/2678f1e431c3')
REPO = BASE / 'recovery-repo'
OUT = BASE / 'recovery-publication10'
STAGE = OUT / 'stage'
PARENT = '9294db8b6cfbe7c833789ac1b7e6ce43d76b48ff'
BASE_TREE = 'f27b64b42fc18898dbd530caedaa6187c58be635'
PREFIX = 'handoff/pro-executor-results-20261115/continuing-execution-20261119-10/'
PART_BYTES = 393216

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def desc(raw):
    return {'bytes': len(raw), 'sha256': sha(raw)}

def dump(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def safe(name):
    p = Path(name)
    assert not p.is_absolute() and '..' not in p.parts and '\\' not in name

def scan(raw, name):
    for rule in [rb'gh[pousr]_[A-Za-z0-9]{30,}', rb'AKIA[A-Z0-9]{16}',
                 rb'X-Amz-Signature=[A-Fa-f0-9]{64}', rb'[?&]sig=[A-Za-z0-9%+/]{20,}',
                 rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n[A-Za-z0-9+/=]{32,}']:
        assert re.search(rule, raw) is None, ('sensitive-pattern-needs-review', name)

def add_dir(target, root, prefix):
    for p in sorted(root.rglob('*')):
        assert not p.is_symlink(), p
        if p.is_file():
            name = prefix + str(p.relative_to(root))
            safe(name)
            raw = p.read_bytes()
            scan(raw, name)
            target[name] = (raw, stat.S_IMODE(p.stat().st_mode))

def make_zip(name, inputs, scope):
    for key, (raw, mode) in inputs.items():
        safe(key)
        scan(raw, key)
    manifest = {'schema': 'root.actual-evidence-snapshot.v1', 'scope': scope,
                'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'files': [{'path': k, **desc(v[0]), 'mode': oct(v[1])} for k, v in sorted(inputs.items())],
                'no_current_authority_or_ref_restoration_from_snapshot': True}
    assert 'SNAPSHOT_MANIFEST.json' not in inputs
    inputs['SNAPSHOT_MANIFEST.json'] = ((json.dumps(manifest, indent=2) + '\n').encode(), 0o644)
    path = OUT / name
    with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for key, (raw, mode) in sorted(inputs.items()):
            info = zipfile.ZipInfo(key, (1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | mode) << 16
            archive.writestr(info, raw)
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(inputs)
        for key, (raw, mode) in inputs.items():
            assert archive.read(key) == raw
            assert stat.S_IMODE(archive.getinfo(key).external_attr >> 16) == mode
    return path

assert not OUT.exists(), 'Never overwrite a prior attempt'
OUT.mkdir()
STAGE.mkdir()

n09 = {}
add_dir(n09, BASE / 'handoff-note-observation-evidence-20261118', 'actual-actor-and-caller/')
add_dir(n09, BASE / 'dg17-n09-actual-receiving', 'independent-receiving/')
for name in ['ROOT_N09_ACTUAL_INTEGRITY_G0005.json', 'ROOT_N09_ORIGINAL_ADJUDICATION_G0005.json']:
    p = BASE / 'recovery-evidence' / name
    n09['root/' + name] = (p.read_bytes(), 0o644)
n09_zip = make_zip('dg17-n09-actual-observation-and-receiving.zip', n09,
    'One actual original N09 forcing observation, genuine independent receiving and Root acceptance only at declared model/received-command-file-effect layer; terminal expanded tail request unavailable; no replay, native or whole-cell award.')

n10 = {}
add_dir(n10, BASE / 'ordinary-work-observation-evidence-20261118', 'actual-governor-and-caller/')
add_dir(n10, BASE / 'ordinary-source-assessment-20261118', 'canonical-helper-source-review/')
for name in ['ROOT_N10_STAGE1_RECEIVING_G0004.json', 'ROOT_N10_STAGE2_RECEIVING_G0004.json',
             'ROOT_REVIEW_PRELOAD_RECEIVING_G0004.json', 'ROOT_N10_STAGE4_RECEIVING_G0005.json']:
    p = BASE / 'recovery-evidence' / name
    n10['root/' + name] = (p.read_bytes(), 0o644)
n10_zip = make_zip('dg17-n10-actual-admission-review-and-return.zip', n10,
    'Actual Stage1-4 admission, notice, one reserved canonical review and real Root-relayed return/re-derivation. Source review NEEDS_REVISION. Case receiving and source revision are active and excluded. No original N10 or hosted award.')

root_inputs = {}
for p in sorted((BASE / 'recovery-evidence').iterdir()):
    if p.is_file() and (('G0004' in p.name or 'G0005' in p.name) or p.name == 'RECOVERED_PUBLICATION09_FINAL.json'):
        root_inputs['root/' + p.name] = (p.read_bytes(), stat.S_IMODE(p.stat().st_mode))
run_root = REPO / '.IMPLEMENTAUDIT/runs/dg16-dg18-recovered-custody-20261118-Zsj2RI'
for name in ['STATE.md', 'ROADMAP.md', 'PROGRESS_G0004.jsonl', 'PROGRESS_G0005.jsonl']:
    root_inputs['current-runtime/' + name] = ((run_root / name).read_bytes(), 0o644)
for p in sorted((BASE / 'recovery-publication09-r2').glob('*.json')):
    root_inputs['completed-publication09/' + p.name] = (p.read_bytes(), 0o644)
add_dir(root_inputs, BASE / 'recovery-publication09-r2/blob-results', 'completed-publication09/blob-results/')
for directory, names in [
    ('dg17-n09-prospective-preparation', ['SEALED_PACKET.json']),
    ('dg17-n09-prospective-review', ['SEALED_REVIEW.json', 'FINALIZATION_TOOL_RECEIPT.json']),
    ('g132-recovered-interface-continuation', ['SEAL.json']),
    ('g132-current-root-entry-preparation', ['SEAL.json']),
    ('dg17-h03-prospective-preparation', ['SEALED_PACKET.json']),
    ('dg17-h03-prospective-review', ['SEALED_PACKET.json'])]:
    for name in names:
        p = BASE / directory / name
        root_inputs['outer-seals/' + directory + '/' + name] = (p.read_bytes(), stat.S_IMODE(p.stat().st_mode))
root_inputs['packaging/build_recovery_publication10.py'] = (Path(__file__).read_bytes(), 0o644)
root_zip = make_zip('root-current-receiving-G0005.zip', root_inputs,
    'Actual G0004/G0005 continuity, prior completed publication, reconciliation, original frontier and Root decisions. Older UNKNOWNs remain. Snapshots do not confer present host authority; active outcomes excluded.')

sources = [
    ('dg17-n09-prospective-source.tar.gz', BASE/'dg17-n09-prospective-preparation/DG17_N09_PROSPECTIVE_SOURCE_PACKET.tar.gz', 48221, '23a8c305dd50775b4d1b183cc9eacc63ef5a35f5a063af10f5f5ac2ad4587a60', 'Frozen original forcing scenario and private controls; exact source dependency retained in prior09 and actual observation snapshots'),
    ('dg17-n09-prospective-review.tar.gz', BASE/'dg17-n09-prospective-review/DG17_N09_PROSPECTIVE_REVIEW.tar.gz', 1426790, '4aa9503c5024a3637d46933b45de0c46fb75a3a5f4d3fc8f028e602353d66c4d', 'Independent prospective source PASS, corrected verifier failure retained'),
    (n09_zip.name, n09_zip, n09_zip.stat().st_size, sha(n09_zip.read_bytes()), 'Actual original N09 observation/independent receiving and bounded Root decision'),
    (n10_zip.name, n10_zip, n10_zip.stat().st_size, sha(n10_zip.read_bytes()), 'Actual governor route, source NEEDS_REVISION and actual returned finding; no case award yet'),
    ('g132-interface-source-baseline.zip', BASE/'g132-recovered-interface-continuation/G132_RECOVERED_INTERFACE_SOURCE_PACKET.zip', 398874, '97b4f96d8f16d06b05c9cb284d4df4207ab404b13f5721bbc039ad83130f7c0e', 'Preserved full-body derivation/current-interface source baseline; no original effect'),
    ('g132-current-root-entry-source.zip', BASE/'g132-current-root-entry-preparation/G132_CURRENT_ROOT_ENTRY_SOURCE_PACKET.zip', 1738259, '6ad2944d296440917b2ad452385f3912fb944a9aa44f8d872b44c427e94764a6', 'Sealed P04/P03/P06 current source composition; local native transport and synthetic provider controls; source review/adoption and original gates open'),
    ('dg17-h03-prospective-source.tar.gz', BASE/'dg17-h03-prospective-preparation/DG17_H03_PROSPECTIVE_SOURCE_PACKET.tar.gz', 19667, 'da1f22d58c3accbcd08ef06eb631c58c11d96747c74615fcc08088a246f273f5', 'Frozen prospective semantic renamed-capability case; target still unissued'),
    ('dg17-h03-prospective-review.tar.gz', BASE/'dg17-h03-prospective-review/DG17_H03_PROSPECTIVE_REVIEW.tar.gz', 80160, '948f80f8237fbb80d9a4d9f3b4e7c77bd5d9ee7a2701e6b1f03f806514159134', 'Fresh independent SOURCE_ONLY_PASS; actor_readyfalse, no target content/behavior consumed'),
    (root_zip.name, root_zip, root_zip.stat().st_size, sha(root_zip.read_bytes()), 'Root currentness, acceptance boundaries and completed publication readbacks')
]
archives = []
for name, path, size, digest, scope in sources:
    raw = path.read_bytes()
    assert len(raw) == size and sha(raw) == digest, name
    members = []
    if name.endswith('.zip'):
        with zipfile.ZipFile(path) as a:
            assert a.testzip() is None
            for i in a.infolist():
                safe(i.filename)
                assert not i.is_dir() and not stat.S_ISLNK(i.external_attr >> 16)
                members.append(i.filename)
    else:
        with tarfile.open(path, 'r:gz') as a:
            for i in a.getmembers():
                safe(i.name)
                assert i.isfile()
                members.append(i.name)
    assert len(members) == len(set(members))
    parts = []
    if len(raw) <= PART_BYTES:
        (STAGE/name).write_bytes(raw)
    else:
        for i, offset in enumerate(range(0, len(raw), PART_BYTES), 1):
            piece = raw[offset:offset+PART_BYTES]
            partname = name + f'.part{i:03d}'
            (STAGE/partname).write_bytes(piece)
            parts.append({'name': partname, **desc(piece)})
    archives.append({'name': name, **desc(raw), 'members': len(members), 'scope': scope, 'transport_parts': parts})

shutil.copyfile(BASE/'recovery-publication09-r2/stage/reassemble_archives.py', STAGE/'reassemble_archives.py')
(STAGE/'README.md').write_text('''# Continued original DG16-DG18: actual observation and source recovery

This additive checkpoint preserves one newly accepted original N09 observation
at its selected-source model and received-command/file-effect layer. The actual
worker read the complete every-task forcing instruction and completed the useful
197-byte note update. All 89 task files were received; only the note changed.
Required evidence remains distinct from unnecessary ceremonial records. The
expanded final capture request and unexposed provider metadata remain unavailable.
There is no stronger native, universal-absence or whole-DG17 claim.

N10 now has actual admission, direct notice correction, one independently loaded
canonical source reviewer and an actual returned finding consumed by the same
governor. The direct reviewer-to-governor send failed; the documented Root relay
succeeded. The source verdict is NEEDS_REVISION: timeout cleanup could skip
command evidence, and inherited-workflow definitions were missing. The source
author is preparing a separate revision. Independent N10 case receiving is active;
neither active outcome is included or pre-awarded here.

G132 has a sealed current entry, byte-backed result custody and tools-control
composition. Actual local process/TTY tests used synthetic GitHub callbacks. The
original hosted consumer, issuer, private sender, fifteen proofs/Q06/M4 and
source-adoption gates remain binding. Raw proposed 3f commit bytes are available,
but inherited object closure and exact-identity publication remain unproved at
this snapshot. Native Git dry-run returned128/HTTP401; no ref was published.
Read-only closure receiving continues separately. Protected625f/301 remain
UNKNOWN_NO_REPLAY, including the now observed301 commit-object effect.

H03 source design has a genuine independent SOURCE_ONLY_PASS, with actor_ready
false. No target binding or actor is issued in the frozen preparation. Unknown
name rejection cannot substitute for its semantic trigger/owner discriminator.

Root G0004 and G0005 are actual local continuity evidence. Raw Git custody objects
are historical data and never permission to restore refs or claim another host's
currentness. Registry/store anomalies and all missing captures remain explicit.
All original48/M1-M6,36cases/14mutations/17terminal clauses, and DG18 original14
plus amendments remain unchanged. Prior accepted scopes are preserved. G2 run
44239735578 remains terminal failed despite timely control and five equal
correspondence relations; originalM2 is unawarded. DG18 authentic prerequisites
remain required and historicalN1 remains LOST/UNKNOWN with no exception.

This commit adds evidence only. It launches no workflow, replays no original
operation, changes no protected ref or acceptance requirement, and does not merge,
release or close issues. Earlier checkpoints remain byte-exact.

Run `python reassemble_archives.py` to verify and reconstruct the full archives.
It does not extract or execute their content. MANIFEST.json binds every archive
and transport part. Outer seals omitted from their own archives are preserved
under outer-seals in the Root snapshot. Source inventories with dependencies on
prior checkpoints retain their exact references; they are not reconstructed from
summaries. Current observations after this cutoff are later additive evidence.
''')
manifest = {'schema':'implementaudit.additive-continuation-evidence.v1',
            'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'parent':PARENT,'base_tree':BASE_TREE,'archives':archives,
            'files':[{'name':p.name,**desc(p.read_bytes())} for p in sorted(STAGE.iterdir())],
            'original_new_awards':[{'id':'N09','scope':'literal observation at declared model/received-command-file-effect layer'}],
            'active_source_revision_case_receiving_object_closure_excluded':True,
            'no_protected_or_original_replay':True}
dump(STAGE/'MANIFEST.json',manifest)
verify=OUT/'reassembly-verification'
shutil.copytree(STAGE,verify)
v=subprocess.run(['python',str(verify/'reassemble_archives.py')],capture_output=True,text=True)
dump(OUT/'REASSEMBLY_VERIFICATION.json',{'returncode':v.returncode,'stdout':v.stdout,'stderr':v.stderr})
assert v.returncode==0
env=dict(os.environ,GIT_INDEX_FILE=str(OUT/'publication.index'))
def git(*args):
    p=subprocess.run(['git',*args],cwd=REPO,env=env,capture_output=True)
    assert p.returncode==0,(args,p.returncode,p.stderr.decode())
    return p.stdout
assert git('rev-parse',PARENT+'^{tree}').decode().strip()==BASE_TREE
assert not git('ls-tree',PARENT,PREFIX).strip()
git('read-tree',PARENT)
additions=[]
for p in sorted(STAGE.iterdir()):
    raw=p.read_bytes(); blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    assert git('hash-object','-w',str(p)).decode().strip()==blob
    path=PREFIX+p.name
    git('update-index','--add','--cacheinfo','100644',blob,path)
    additions.append({'path':path,'name':p.name,'mode':'100644','type':'blob','sha':blob,**desc(raw)})
tree=git('write-tree').decode().strip()
c=subprocess.run(['git','diff','--check',PARENT,tree],cwd=REPO,capture_output=True,text=True)
dump(OUT/'DIFF_CHECK.json',{'returncode':c.returncode,'stdout':c.stdout,'stderr':c.stderr});assert c.returncode==0
changes=git('diff','--name-status',PARENT,tree).decode().splitlines()
assert len(changes)==len(additions)and all(x.startswith('A\t'+PREFIX)for x in changes)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip()=='6d9e145e2f2df5a0a8a150c85a4f3e2afd918d27'
assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=REPO)==b''
publication={'schema':'implementaudit.exact-additive-evidence-publication.v1','parent':PARENT,'base_tree':BASE_TREE,
             'tree':tree,'branch':'engineering/pro-executor-original-completion-20261115','additions':additions,
             'total_bytes':sum(a['bytes']for a in additions),'force':False,'root_continuity':'G0005@28ac647c6e2bcbe9d7bafd180e25a6b6ad909074',
             'archives':archives,'scope':'Additive completed source/review/actual observation/receiving evidence; active outcomes excluded'}
dump(OUT/'PUBLICATION.json',publication)
print(json.dumps({'files':len(additions),'bytes':publication['total_bytes'],'tree':tree,
                  'archives':[{k:a[k]for k in ['name','bytes','sha256','members']}for a in archives],
                  'reassembly_exit':v.returncode,'diff_check_exit':c.returncode,'root_HEAD_worktree_unchanged':True},indent=2))
