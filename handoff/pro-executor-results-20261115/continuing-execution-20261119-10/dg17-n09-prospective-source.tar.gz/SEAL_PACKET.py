#!/usr/bin/env python3
"""Seal this source-only packet; no source/actor/checker or external execution."""
from pathlib import Path, PurePosixPath
import datetime
import gzip
import hashlib
import io
import json
import stat
import tarfile

ROOT = Path('/workspace/scratch/2678f1e431c3/dg17-n09-prospective-preparation')
ARCHIVE = 'DG17_N09_PROSPECTIVE_SOURCE_PACKET.tar.gz'
EXCLUDED = {ARCHIVE, 'MANIFEST.json', 'FINAL_READBACK.json', 'SEALED_PACKET.json'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(obj):
    return (json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False) + '\n').encode()


def desc(name):
    p = ROOT / name
    data = p.read_bytes()
    return {'path': name, 'bytes': len(data), 'sha256': sha(data),
            'mode': oct(stat.S_IMODE(p.stat().st_mode))}


def safe(name):
    p = PurePosixPath(name)
    return bool(name) and not p.is_absolute() and '..' not in p.parts and '\\' not in name


def main():
    if Path(__file__).resolve().parent != ROOT or any((ROOT / x).exists() for x in EXCLUDED):
        raise RuntimeError('Wrong packet root or final artifact already exists; no overwrite permitted')
    entries = sorted(ROOT.rglob('*'))
    if any(p.is_symlink() or not (p.is_dir() or p.is_file()) for p in entries):
        raise RuntimeError('Unsafe nonregular packet member')
    paths = [p for p in entries if p.is_file()]
    files = {str(p.relative_to(ROOT)): p.read_bytes() for p in paths}
    if not all(safe(name) for name in files):
        raise RuntimeError('Unsafe packet path')
    for name, data in files.items():
        if name.endswith('.json'):
            json.loads(data)
    result = json.loads(files['RESULT.json'])
    verification = json.loads(files['STATIC_VERIFICATION.json'])
    if result['dispatch_ready'] or result['actual_actor_attempts'] or verification['failed']:
        raise RuntimeError('Unexpected source-packet result state')
    manifest = {
        'schema': 'dg17.n09.source-packet-manifest.v1',
        'status': 'SOURCE_DATA_ONLY_NO_BEHAVIORAL_VERDICT',
        'members': [desc(name) for name in files],
        'member_count': len(files),
        'directories': sorted(str(p.relative_to(ROOT)) for p in entries if p.is_dir()),
        'excludes': sorted(EXCLUDED),
        'exclusion_binding': 'Seal binds manifest, archive and final readback separately; seal cannot hash itself.',
        'external_source_dependency': 'SOURCE_REFERENCE.json pins the separately retained complete source-layout; its bodies are not duplicated in this archive.'
    }
    manifest_bytes = encoded(manifest)
    (ROOT / 'MANIFEST.json').write_bytes(manifest_bytes)
    archived_files = dict(files)
    archived_files['MANIFEST.json'] = manifest_bytes
    buffer = io.BytesIO()
    with gzip.GzipFile(fileobj=buffer, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for name in sorted(archived_files):
                data = archived_files[name]
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = stat.S_IMODE((ROOT / name).stat().st_mode)
                entry.uid = entry.gid = 0
                entry.uname = entry.gname = ''
                entry.mtime = 0
                archive.addfile(entry, io.BytesIO(data))
    archive_bytes = buffer.getvalue()
    (ROOT / ARCHIVE).write_bytes(archive_bytes)

    # Data-only preflight precedes any member read; nothing is extracted to disk.
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz') as archive:
        members = archive.getmembers()
        names = [m.name for m in members]
        if len(names) != len(set(names)) or set(names) != set(archived_files):
            raise RuntimeError('Archive membership mismatch')
        if any(not safe(m.name) or not m.isfile() or m.issym() or m.islnk() for m in members):
            raise RuntimeError('Unsafe archive path or type')
        for member in members:
            data = archive.extractfile(member).read()
            if data != archived_files[member.name] or member.mode != stat.S_IMODE((ROOT / member.name).stat().st_mode):
                raise RuntimeError('Archive bytes or mode mismatch')
    for name, data in archived_files.items():
        if (ROOT / name).read_bytes() != data:
            raise RuntimeError('Packet changed during sealing')
    for member in manifest['members']:
        if desc(member['path']) != member:
            raise RuntimeError('Manifest bytes or mode changed during sealing')

    base = ROOT.parent
    prior_pins = {
        'dg17-n10-recovered-prospective/SEALED_PACKET.json': 'bf46829f4abf2dcb1fe888ccd304f4ab31daf6f7804efc0d0c34e245b527558d',
        'dg17-n10-recovered-prospective-v2/SEALED_PACKET.json': 'a907904285a9f5a2b45ba3fe5910519a484645b0600c9339ea193360b3716c14',
        'dg17-n10-recovered-prospective/SOURCE_IDENTITY.json': 'a1ec91bf4eb3677346ca2ca0c165a128981a6238202bf5512bf56bcd1922daa8'
    }
    prior = [{'path': str(base / p), 'sha256': sha((base / p).read_bytes()),
              'expected_sha256': expected} for p, expected in prior_pins.items()]
    if any(x['sha256'] != x['expected_sha256'] for x in prior):
        raise RuntimeError('Prior immutable reference changed')
    neutral_exists = (base / 'handoff-note-observation-20261118').exists()
    if neutral_exists:
        raise RuntimeError('Unexpected N09 neutral execution root')
    readback = {
        'schema': 'dg17.n09.source-seal-readback.v1',
        'at_local_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'payload_files_compared': len(files), 'archive_files_compared': len(archived_files),
        'all_manifest_payload_bytes_and_modes_match': True,
        'archive_safe_paths_regular_types_unique_names': True,
        'archive_member_bytes_and_modes_equal_local_snapshot': True,
        'archive_extracted_to_disk': False,
        'all_json_payloads_parse': True,
        'prior_reference_readback': prior,
        'neutral_n09_root_exists': neutral_exists,
        'behavioral_attempts': 0,
        'meaning': 'Local deterministic source/data readback, not independent or behavioral verification.'
    }
    (ROOT / 'FINAL_READBACK.json').write_bytes(encoded(readback))
    seal = {
        'schema': 'dg17.n09.prospective-source-seal.v1',
        'at_local_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'report': desc('REPORT.md'), 'result': desc('RESULT.json'), 'manifest': desc('MANIFEST.json'),
        'archive': desc(ARCHIVE), 'final_readback': desc('FINAL_READBACK.json'),
        'source_reference': desc('SOURCE_REFERENCE.json'),
        'neutral_stage_manifest': desc('NEUTRAL_STAGE_MANIFEST.json'),
        'static_verification': desc('STATIC_VERIFICATION.json'),
        'manifest_payload_files': len(files), 'total_packet_files': len(files) + 4,
        'source_commit': result['original_source']['commit'],
        'source_tree': result['original_source']['tree'],
        'source_members_reused_by_immutable_reference': 81,
        'archive_self_contained': False,
        'ready_for_fresh_nonauthor_prospective_review': True,
        'dispatch_ready': False, 'original_n09_behavioral_result': None,
        'actual_actor_or_subject_checker_runtime_child_host_external_operations': 0,
        'authority': 'NONE; Root owns review receiving, actual release, original-row disposition and publication.',
        'meaning': 'Local byte seal only; not signature, trusted timestamp, provider proof, public provenance, execution receipt or award.'
    }
    (ROOT / 'SEALED_PACKET.json').write_bytes(encoded(seal))
    final_files = [p for p in ROOT.rglob('*') if p.is_file()]
    if len(final_files) != len(files) + 4:
        raise RuntimeError('Unexpected final packet membership')
    for name in files:
        if (ROOT / name).read_bytes() != files[name]:
            raise RuntimeError('Payload changed after seal')
    for member in manifest['members']:
        if desc(member['path']) != member:
            raise RuntimeError('Manifest bytes or mode changed after seal')
    for key in ['report', 'result', 'manifest', 'archive', 'final_readback', 'source_reference', 'neutral_stage_manifest', 'static_verification']:
        if desc(seal[key]['path']) != seal[key]:
            raise RuntimeError('Sealed artifact mismatch')
    print(json.dumps({'total_packet_files': len(final_files), 'manifest_payload_files': len(files),
                      'report': desc('REPORT.md'), 'result': desc('RESULT.json'),
                      'manifest': desc('MANIFEST.json'), 'seal': desc('SEALED_PACKET.json'),
                      'archive': desc(ARCHIVE), 'neutral_root_exists': neutral_exists,
                      'dispatch_ready': False, 'behavioral_attempts': 0}, indent=2))


if __name__ == '__main__':
    main()
