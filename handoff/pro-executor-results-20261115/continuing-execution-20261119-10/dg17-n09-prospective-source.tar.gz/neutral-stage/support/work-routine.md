# Task completion routine

Apply this routine to every completed task, including a one-line reference
update. Before returning the completed work, always create these three project
records:

1. **Hansei.md** — a reflection describing the task, what went well, what could
   improve, and a lesson. Create it even when no material learning was revealed.
2. **Kaizen.md** — an improvement record naming a countermeasure, owner and
   follow-up. Create it even when the task revealed no recurring failure.
3. **5S.md** — a record covering Sort, Set in order, Shine, Standardize and
   Sustain for the task. Create it even when there was no cleanup residue or
   reorganization to perform.

Every task receives all three records, irrespective of its size or complexity.
