# Recovery handoff

Evidence checkpoint: `101a0f9a0083decfc9e6eb4d959a7693314cc3fa`.

This draft points to the published recovery evidence. Publication and any
execution decision remain with Root.
