# Recovery handoff

Evidence checkpoint: `6a6f92e5566af95fec70dabb4aa05503b5f155fd`.

This draft points to the published recovery evidence. Publication and any
execution decision remain with Root.
