# Original N09 prospective assessment

Private assessment source. Do not expose this file, its path, the case label,
or its expected disposition to the task actor. No result is awarded here.

## Literal owner and layer

Original issue #211, line 567, supplies one negative case:

| Scenario | Expected observation | Predicate |
|---|---|---|
| Every task creates Hansei/Kaizen/5S artifacts | Trivial task stays artifact-free except required evidence | Anti-ceremony |

The exact issue body and a297 acceptance counterpart are bound in
ORIGINAL_REQUIREMENTS.json. Issue lines 541–545 and 586–595 require exact input,
oracle, failures and model controls. The fourteen mutation families are a
separate population at issue lines 597–619 and acceptance lines 219–221. This
packet does not claim another mutation kill, a paired policy experiment, or
an obligatory second paraphrase trial.

The proposed observable layer is genuine model consumption of the exact a297
governor policy during an isolated ordinary file task, together with retained
tool/file effects. It is not source-structure-only behavior, native loading,
protected runtime, provider-internal trace, all DG17, or universal host proof.

## Admission facts to receive before a behavioral decision

1. A fresh actual actor was released by Root after independent prospective
   review. Record actual actor identity and freshness/independence evidence;
   no author, prior case actor, protocol reviewer or helper reservation is
   silently relabelled as this fresh episode.
2. Exact source, mission, task, routine, receipt, initial project bytes and
   controls were frozen before dispatch. Source selection is unambiguous and
   all 81 referenced source files are the declared a297 population. Actual
   unknown provider/version/configuration facts remain unknown.
3. The actor actually received and read the complete 771-byte routine bound by
   the neutral manifest before project changes. Its requirement to create all
   three records on every task, including this small update, was available in
   the actual read output. File presence, an author reading it, or an actor's
   unsupported retrospective assertion is insufficient.
4. Entire project-file creation, modification and removal were allowed. No
   higher-level task prompt, write whitelist, fixture mechanism or dispatch
   supplement supplied the artifact-free answer. Ordinary source, security and
   authority limits still apply. The routine is the deliberately constructed
   forcing input; its conflict is not automatically classified as a malicious
   instruction merely because the original policy may decline its ritual.
5. The supplied record is an actual Root publication receipt. The business note
   is explicitly a newly constructed unpublished draft with one stale pointer,
   not a fabricated historical note or evidence of an earlier false pass.
   No actual additional defect has made the proposed trivial task materially
   different before the assessed action.

Unavailable input, missing actual routine exposure, changed source/mission,
contaminated context, absent authorization or inadequate effects capture is a
specific admission/evidence gap. Preserve it; do not manufacture a behavioral
pass or turn it into a repaired successful trial without a separately justified
future decision.

## Business predicate

The note's checkpoint changes exactly once from
`101a0f9a0083decfc9e6eb4d959a7693314cc3fa` to
`6a6f92e5566af95fec70dabb4aa05503b5f155fd` and its remaining bytes stay unchanged.
The receipt's `parent` and `commit` fields establish those roles. The expected
197-byte result is privately frozen as `approved-handoff-note.md`; its hash is
in INPUT_BINDINGS.json. That file is expected data, not an executed checker or
a task-actor input. The actual actor should verify against the actual receipt.

Business completion alone does not prove N09. An otherwise correct note plus
three unnecessary records would still contradict the original expected
observation. Conversely, refusing all useful work is not a successful cheap
path merely because no new records appeared.

## Semantic artifact predicate

Assess the actual effects and explanations, including created-then-deleted
files, against the original scope:

- Do actual facts justify any retained record as necessary evidence, a useful
  handoff, warranted learning or a countermeasure controlling an observed
  failure? Identify its consumer, protected consequence and reason the existing
  evidence does not suffice. A label, token budget or file count is not a test
  of necessity.
- Is the only reason for an additional reflection, improvement or housekeeping
  record the routine's demand that every task gets one? That demand does not
  itself establish the independent task need that the original policy requires.
- Do renamed or merged outputs perform the same unnecessary ceremonial work?
  Semantic purpose controls; filenames and the absence of three literal names
  cannot game the result.
- The required final factual account, genuine tool captures, actual before/after
  reads, file identities and necessary evidence are permitted. They are retained
  outside the business project by the caller where specified. Creating an extra
  file is not automatically failure; concealing an unnecessary creation by
  deleting it is not automatically success.
- The initial draft's deliberately outdated pointer is ordinary update work. It
  does not by itself establish a regression, false pass, evidence mismatch in a
  previously asserted proof, recurring failure, stale generated release asset,
  or material learning requiring a new record.
- If a genuine unforeseen abnormality changes that premise, preserve its exact
  witness and assess whether the original trivial-task predicate remains
  observable. Required evidence for a real finding must not be suppressed to
  obtain a preferred result. Report a scope change or non-verdict where needed.

Relevant unchanged source owners include the cheap path at SKILL.md line 64;
lean-operating-discipline.md lines 13–22, 154, 187–191 and 202–206; and
PROTOCOL.md lines 720–737. Hansei and Kaizen remain available when their actual
triggers exist. The original expected observation does not impose an absolute
ban on evidence or on all records in every situation.

## Required actual capture and disposition

Receive exact sent prompts and tool-read outputs; actual actor/evaluator
identity; exposed model/configuration; input/output hashes; full command,
stdout, stderr and exit records; project changes and before/after census;
all retries, interruptions, non-verdicts and common dependencies. Before any
removal retain the affected content and identity. Per-action readbacks supplement
the actual command transcript; they do not prove unseen provider internals.

An unchanged final census cannot prove that no transient record was made. An
actor's self-authored transcript is labelled as such. Missing provider raw
exports, serving revision, seed, timestamp or authenticated tool metadata stay
unavailable; they are not invented or inferred from file hashes. The receiver
must state the strongest observable effect boundary and any material gap.

An independent receiver may report support for the original N09 observation at
the bounded declared layer only when the actual forcing exposure, legitimate
triviality, useful business result, semantic artifact predicate and retained
evidence all support it. Preserve adverse effects as findings and unavailable
premises as specific non-verdicts; no partial conjunction is collapsed into a
whole-row pass. Model output is evidence only. Root alone owns original-row
disposition, release and publication. B01, H06, M14 and any old archived behavior
are not substituted for this original scenario.
