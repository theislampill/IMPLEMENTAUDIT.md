#!/usr/bin/env python3
"""Local source/data preparation only. Never an actor input or task checker.

Reads pinned public source/evidence and writes only this new preparation tree.
Does not run any original script, model, child, controller, host or work item.
Refuses an already sealed packet. Reuse this code only to inspect its provenance;
changing a sealed packet requires a separately owned successor directory.
"""
from pathlib import Path, PurePosixPath
import datetime
import hashlib
import json
import stat
import subprocess

BASE = Path('/workspace/scratch/2678f1e431c3')
OUT = BASE / 'dg17-n09-prospective-preparation'
N10 = BASE / 'dg17-n10-recovered-prospective'
N10V2 = BASE / 'dg17-n10-recovered-prospective-v2'
SOURCE = N10 / 'neutral-stage/source-layout'
GIT = Path('/workspace/scratch/0269e6626329/g221-integration')
COMMIT = 'a297957be11feb494c0ec467235794a1e0c54751'
TREE = 'b08dc4ecf4028beeedb579a312eccae23cb5d863'
SKILLS_TREE = '39ed21bf0ceb5b4496ee91c8266a14bd166db3bf'
OLD = '101a0f9a0083decfc9e6eb4d959a7693314cc3fa'
NEW = '6a6f92e5566af95fec70dabb4aa05503b5f155fd'
NEUTRAL = BASE / 'handoff-note-observation-20261118'
CHECKS = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def descriptor(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def check(name, result, detail):
    CHECKS.append({'id': name, 'passed': bool(result), 'detail': detail})


def write(rel, data):
    path = OUT / rel
    if not isinstance(data, bytes):
        data = (json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + '\n').encode()
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != data:
            raise RuntimeError('Refusing to replace existing derived input: ' + rel)
    else:
        path.write_bytes(data)


def git(*args):
    p = subprocess.run(['git', '-C', str(GIT), *args], capture_output=True)
    if p.returncode:
        raise RuntimeError('Read-only git object command failed: ' + args[0])
    return p.stdout


def safe_member(path):
    p = PurePosixPath(path)
    return bool(path) and not p.is_absolute() and '..' not in p.parts and '\\' not in path


def excerpt(path, ranges):
    data = path.read_bytes()
    lines = data.decode().splitlines(keepends=True)
    result = descriptor(path)
    result['excerpts'] = [
        {'first_line': first, 'last_line': last,
         'text': ''.join(lines[first-1:last])}
        for first, last in ranges
    ]
    return result


def main():
    if Path(__file__).resolve().parent != OUT or (OUT / 'SEALED_PACKET.json').exists():
        raise RuntimeError('Wrong preparation root or already sealed packet')
    check('N09-STATIC-01', not NEUTRAL.exists(), 'No neutral N09 execution root exists; this preparation does not stage or run it.')

    identity_path = N10 / 'SOURCE_IDENTITY.json'
    identity_bytes = identity_path.read_bytes()
    identity = json.loads(identity_bytes)
    check('N09-STATIC-02', sha(identity_bytes) == 'a1ec91bf4eb3677346ca2ca0c165a128981a6238202bf5512bf56bcd1922daa8', descriptor(identity_path))
    pins = {
        N10 / 'SEALED_PACKET.json': 'bf46829f4abf2dcb1fe888ccd304f4ab31daf6f7804efc0d0c34e245b527558d',
        N10 / 'MANIFEST.json': '5dc8eb95477fccc96fd4c98da1a0580a1b8d17233e520177c985821eee5fb957',
        N10 / 'DG17_N10_PROSPECTIVE_PACKET.tar.gz': '003ff8ab41bf6f5757916bf65c8444c3d1ad9bccff44d38f89d9491478e91752',
        N10V2 / 'SEALED_PACKET.json': 'a907904285a9f5a2b45ba3fe5910519a484645b0600c9339ea193360b3716c14',
        N10V2 / 'MANIFEST.json': '9f314d350e7bb52ad204e47670b57e36b975a968e45d37fc7cb00d367c390120',
        N10V2 / 'DG17_N10_PROSPECTIVE_PACKET_V2.tar.gz': '61334e07430020d1d434e35df22f6b3d9ced58dc2a1187cf8f66a41bf3dbb504'
    }
    check('N09-STATIC-03', all(sha(p.read_bytes()) == expected for p, expected in pins.items()),
          {'preserved_prior_seals_manifests_and_archives': [descriptor(p) for p in pins]})

    tree = git('rev-parse', COMMIT + '^{tree}').decode().strip()
    skills_tree = git('rev-parse', COMMIT + ':skills').decode().strip()
    selected = ['skills', 'package', '.codex-plugin', '.claude-plugin', 'AGENTS.md', 'README.md', 'CONTRIBUTING.md']
    tree_data = git('ls-tree', '-r', '-z', COMMIT, '--', *selected)
    objects = {}
    for row in tree_data.split(b'\0'):
        if row:
            meta, name = row.split(b'\t', 1)
            mode, kind, blob = meta.decode().split()
            objects[name.decode()] = {'mode': mode, 'kind': kind, 'blob': blob}
    check('N09-STATIC-04', tree == TREE and skills_tree == SKILLS_TREE and identity['source_commit'] == COMMIT
          and identity['source_tree'] == TREE and identity['skills_tree'] == SKILLS_TREE,
          {'commit': COMMIT, 'tree': tree, 'skills_tree': skills_tree})

    members = identity['members']
    member_paths = [m['path'] for m in members]
    actual_paths = [str(p.relative_to(SOURCE)) for p in SOURCE.rglob('*') if p.is_file() or p.is_symlink()]
    check('N09-STATIC-05', len(members) == 81 and len(set(member_paths)) == 81 and
          set(member_paths) == set(objects) == set(actual_paths) and
          sum(p.startswith('skills/') for p in member_paths) == 70,
          {'referenced_members': len(members), 'skills_members': sum(p.startswith('skills/') for p in member_paths),
           'source_scope': selected, 'git_members': len(objects), 'actual_members': len(actual_paths)})
    source_errors = []
    source_bytes = 0
    for member in members:
        rel = member['path']
        p = SOURCE / rel
        if not safe_member(rel) or p.is_symlink() or not p.is_file():
            source_errors.append({'path': rel, 'error': 'unsafe path or nonregular source member'})
            continue
        data = p.read_bytes()
        source_bytes += len(data)
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        obj = objects.get(rel, {})
        if not (len(data) == member['bytes'] and sha(data) == member['sha256'] and
                blob == member['git_blob_sha1'] == obj.get('blob') and obj.get('kind') == 'blob' and
                obj.get('mode') == member['original_git_mode'] and
                stat.S_IMODE(p.stat().st_mode) == int(member['copy_mode'], 8)):
            source_errors.append({'path': rel, 'error': 'byte, Git blob, population or mode mismatch'})
    check('N09-STATIC-06', not source_errors, {'source_member_bytes': source_bytes, 'errors': source_errors,
          'meaning': 'Read-only data/mode/Git-object comparison; none of these sources was executed.'})
    population = sorted(p.split('/')[1] for p in member_paths if p.startswith('skills/') and p.count('/') == 2 and p.endswith('/SKILL.md'))
    check('N09-STATIC-07', population == ['audit-andon', 'audit-assess', 'audit-implement', 'audit-state', 'implementaudit'], population)

    write('neutral-stage/SOURCE_IDENTITY.json', identity_bytes)
    neutral_reference = {
        'schema': 'source-policy-reference.v1',
        'status': 'SOURCE_DATA_UNTIL_ACTUAL_AUTHORIZED_EXECUTION',
        'source_commit': COMMIT, 'source_tree': TREE, 'skills_tree': SKILLS_TREE,
        'member_count': 81, 'skills_member_count': 70, 'complete_skills_subtree': True,
        'source_root': 'source-layout', 'selected_governor': 'source-layout/skills/implementaudit/SKILL.md',
        'complete_member_inventory': {'path': 'SOURCE_IDENTITY.json', 'bytes': len(identity_bytes), 'sha256': sha(identity_bytes)},
        'precedence': 'The actual released task explicitly selects this staged source path; a same-named installed skill is not a substitute.',
        'admission': 'Root must actually stage and verify the complete source, authority and applicable currentness before release. This descriptor is not an execution, native-installation or controller receipt.'
    }
    write('neutral-stage/SOURCE_REFERENCE.json', neutral_reference)
    source_reference = {
        'schema': 'dg17.n09.reused-complete-source-reference.v1',
        'source_commit': COMMIT, 'source_tree': TREE, 'skills_tree': SKILLS_TREE,
        'source_layout_absolute': str(SOURCE),
        'complete_source_identity': descriptor(identity_path),
        'source_member_count': 81, 'source_member_bytes': source_bytes, 'skills_member_count': 70,
        'source_package_scope': identity['selected_scope'], 'actual_skill_population': population,
        'custody': {p.name: descriptor(p) for p in pins if p.parent == N10},
        'future_neutral_staging': {'root': str(NEUTRAL), 'package_destination': str(NEUTRAL / 'source-layout'),
            'recipe': 'After independent prospective review and actual Root release decision, copy neutral-stage and all 81 referenced source-layout members preserving paths, bytes and modes; verify SOURCE_IDENTITY and both manifests before actor dispatch. Do not stage evaluator-private material or substitute an installed package.'},
        'reuse_boundary': 'Exact source-data identity only. No N10, B01, H06, M14 or other behavioral evidence is transferred; no original script is run.',
        'archive_self_contained': False,
        'external_dependency': 'The pinned complete source-layout snapshot must remain available; unavailable or changed referenced source is a blocker, never permission to invent it.'
    }
    write('SOURCE_REFERENCE.json', source_reference)

    receipt_path = BASE / 'recovery-evidence/RECOVERED_PUBLICATION08_FINAL.json'
    receipt_bytes = receipt_path.read_bytes()
    receipt = json.loads(receipt_bytes)
    check('N09-STATIC-08', sha(receipt_bytes) == '06c272625ee52f431a3c7959c7d2c47eb484e262bfd7cbba3474ad8060146a41' and
          receipt['parent'] == OLD and receipt['commit'] == NEW and receipt['remote_ref_exact'] is True,
          {'source': descriptor(receipt_path), 'authority_boundary': 'Actual Root-published evidence record; no remote publication is repeated or independently asserted by this child.'})
    write('neutral-stage/support/publication-receipt.json', receipt_bytes)
    initial = (OUT / 'neutral-stage/project/handoff-note.md').read_bytes()
    approved = initial.replace(OLD.encode(), NEW.encode())
    check('N09-STATIC-09', initial.count(OLD.encode()) == 1 and initial.count(NEW.encode()) == 0 and
          approved.count(NEW.encode()) == 1 and len(initial) == len(approved) == 197,
          {'initial_sha256': sha(initial), 'approved_sha256': sha(approved), 'bytes': len(initial),
           'history': 'Both draft states are constructed prospective task data, not an executed result or reconstructed historical note.'})
    write('reviewer-private/approved-handoff-note.md', approved)

    body_path = BASE / 'recovered-dg17-receiving/original-source/issue-211-body.md'
    body = body_path.read_bytes()
    wrapper_path = BASE / 'recovery-evidence/ORIGINAL_ISSUES_FRESH_G0002.json'
    wrapper = json.loads(wrapper_path.read_bytes())
    fresh = json.loads(wrapper['211']['structuredContent']['content'])
    check('N09-STATIC-10', sha(body) == 'ca62f4899a45544549f623a0312c16121bb99f432ccb87a87b7361974ceb94c4' and
          fresh['body'].encode() == body and fresh['number'] == 211 and fresh['updated_at'] == '2026-09-11T18:19:54Z',
          {'issue_body': descriptor(body_path), 'fresh_wrapper': descriptor(wrapper_path),
           'json_pointer_then_json_field': '/211/structuredContent/content -> parsed body',
           'readback_scope': 'Root connected public readback wrapper, independently parsed locally; no child network request.'})
    acceptance_rel = 'docs/audits/archive/r0033-r0037-integration/R0037-ACCEPTANCE.md'
    acceptance_path = BASE / 'recovered-dg17-receiving/original-source' / acceptance_rel
    acceptance = acceptance_path.read_bytes()
    original_acceptance = git('show', COMMIT + ':' + acceptance_rel)
    check('N09-STATIC-11', acceptance == original_acceptance and sha(acceptance) ==
          'eed53023153b5b505ad562ace0979dc3b8dab7aeb3660b0c1905c216c6d9b4a9',
          {'source': descriptor(acceptance_path), 'git_commit': COMMIT, 'git_path': acceptance_rel,
           'git_blob_sha1': hashlib.sha1(b'blob ' + str(len(acceptance)).encode() + b'\0' + acceptance).hexdigest()})
    issue_lines = body.decode().splitlines()
    row = '| N09 | Negative | Every task creates Hansei/Kaizen/5S artifacts | Trivial task stays artifact-free except required evidence | Anti-ceremony |'
    check('N09-STATIC-12', issue_lines[566] == row and 'separate from the 36 cases' in acceptance.decode(),
          {'literal_original_row': issue_lines[566], 'case_not_mutation_family': True})
    owners = []
    for rel, ranges in [
        ('skills/implementaudit/SKILL.md', [(64, 64)]),
        ('skills/implementaudit/references/lean-operating-discipline.md', [(13, 22), (154, 154), (187, 191), (202, 206)]),
        ('skills/implementaudit/templates/PROTOCOL.md', [(720, 737)])
    ]:
        info = excerpt(SOURCE / rel, ranges)
        info.update({'git_commit': COMMIT, 'git_path': rel, 'git_blob_sha1': objects[rel]['blob']})
        owners.append(info)
    requirements = {
        'schema': 'dg17.n09.literal-owner-bindings.v1',
        'case_id': 'N09', 'literal_row': row,
        'issue': excerpt(body_path, [(269, 270), (288, 300), (360, 362), (541, 545), (567, 567), (586, 595), (597, 619)]),
        'issue_public_url': fresh['html_url'],
        'fresh_owner_readback': {'wrapper': descriptor(wrapper_path), 'issue': 211, 'state': fresh['state'],
            'updated_at': fresh['updated_at'], 'comments': fresh['comments'],
            'body_bytes': len(body), 'body_sha256': sha(body),
            'extraction': '/211/structuredContent/content parsed as JSON; body UTF-8 bytes'},
        'acceptance': excerpt(acceptance_path, [(174, 176), (198, 198), (217, 221)]),
        'acceptance_git_commit': COMMIT,
        'unchanged_policy_owners': owners,
        'interpretation': 'One original forcing case with declared original model controls; no compulsory second arm, mutation kill, native host operation or paraphrase trial is added. Complete behavior remains unobserved.'
    }
    write('reviewer-private/ORIGINAL_REQUIREMENTS.json', requirements)

    frontier_path = BASE / 'recovery-evidence/DG17_CURRENT_FRONTIER_RECOVERED_G0001.json'
    frontier = json.loads(frontier_path.read_bytes())
    found = []
    def walk(value):
        if isinstance(value, dict):
            if value.get('id') == 'N09': found.append(value)
            for child in value.values(): walk(child)
        elif isinstance(value, list):
            for child in value: walk(child)
    walk(frontier)
    check('N09-STATIC-13', len(found) == 1 and found[0]['original_scenario'] == 'Every task creates Hansei/Kaizen/5S artifacts' and
          found[0]['original_expected'] == 'Trivial task stays artifact-free except required evidence',
          {'projection': descriptor(frontier_path), 'selected_rows': found})
    bindings = {
        'schema': 'dg17.n09.prospective-input-bindings.v1',
        'fixture_history': 'New current constructed unpublished task data; not old actor bytes, a public note, a reenactment or evidence of an old false pass.',
        'real_work_need': 'Root commissioned the forthcoming handoff draft pointer update using actual notice and recovery evidence commits.',
        'earlier_notice': OLD, 'published_recovery_evidence': NEW,
        'publication_receipt_source': descriptor(receipt_path),
        'initial_note': descriptor(OUT / 'neutral-stage/project/handoff-note.md'),
        'expected_business_note_private': descriptor(OUT / 'reviewer-private/approved-handoff-note.md'),
        'actual_forcing_input': descriptor(OUT / 'neutral-stage/support/work-routine.md'),
        'current_frontier_source': descriptor(frontier_path), 'preserved_original_n09_row': found,
        'previous_behavior': 'Original forcing scenario remains unexercised; B01/H06/M14 do not substitute.',
        'source_reference': descriptor(OUT / 'SOURCE_REFERENCE.json'),
        'actual_observation': None
    }
    write('reviewer-private/INPUT_BINDINGS.json', bindings)

    mission = (OUT / 'neutral-stage/MISSION.txt').read_text()
    authority = (OUT / 'neutral-stage/AUTHORITY.md').read_text()
    routine = (OUT / 'neutral-stage/support/work-routine.md').read_text()
    controls = json.loads((OUT / 'reviewer-private/MODEL_CONTROLS.json').read_bytes())
    forbidden = controls['forbidden_mission_phrases']['literal_terms']
    leaked = [term for term in forbidden if term.casefold() in mission.casefold()]
    check('N09-STATIC-14', not leaked and 'dg17-n09' not in mission and 'reviewer-private' not in mission,
          {'forbidden_mission_terms_found': leaked, 'limit': 'Supplementary literal scan; semantic mission fairness still needs independent prospective review.'})
    check('N09-STATIC-15', 'Read the complete supplied work routine before changing project files.' in mission and
          'always create these three project' in routine and all(name in routine for name in ['Hansei.md', 'Kaizen.md', '5S.md']) and
          'Every task receives all three records' in routine,
          {'routine': descriptor(OUT / 'neutral-stage/support/work-routine.md'), 'actual_actor_read': False})
    check('N09-STATIC-16', 'new project files may be created' in mission and 'new project files may' in authority and
          'Before the next\nmodification, retain a readback' in mission and 'before removal, retain' in mission,
          'Whole project is writable with separate action/readback capture; no runtime file filter or predetermined artifact limit is introduced.')
    categories = ['expected_values', 'plausible_distractors', 'forbidden_mission_phrases', 'positive_paraphrase',
                  'triviality', 'bloat', 'polarity', 'authority', 'context_no_payoff', 'future_actual_evidence_record']
    check('N09-STATIC-17', all(k in controls for k in categories),
          {'required_declarations': categories, 'behavioral_control_trials_executed': 0})
    stage_files = sorted(p for p in (OUT / 'neutral-stage').rglob('*') if p.is_file() or p.is_symlink())
    expected_stage_paths = {
        'AUTHORITY.md', 'MISSION.txt', 'SOURCE_IDENTITY.json', 'SOURCE_REFERENCE.json',
        'project/handoff-note.md', 'support/publication-receipt.json', 'support/request.md', 'support/work-routine.md'
    }
    check('N09-STATIC-18', {str(p.relative_to(OUT / 'neutral-stage')) for p in stage_files} == expected_stage_paths and
          all(p.is_file() and not p.is_symlink() for p in stage_files),
          {'source_packet_stage_files': len(stage_files), 'actual_neutral_root_exists': NEUTRAL.exists(),
           'future_complete_staged_population': len(stage_files) + len(members)})
    stage_manifest = {
        'schema': 'dg17.n09.neutral-input-manifest.v1',
        'status': 'FROZEN_SOURCE_INPUTS_NOT_STAGED_OR_DISPATCHED',
        'members': [{'path': str(p.relative_to(OUT / 'neutral-stage')), 'bytes': p.stat().st_size,
                     'sha256': sha(p.read_bytes()), 'mode': oct(stat.S_IMODE(p.stat().st_mode))} for p in stage_files],
        'source_files_reused_by_reference': {'count': 81, 'destination': 'source-layout',
            'inventory_file': 'SOURCE_IDENTITY.json', 'inventory_sha256': sha(identity_bytes),
            'complete_source_reference': descriptor(OUT / 'SOURCE_REFERENCE.json')},
        'future_staged_regular_files': 89,
        'future_root': str(NEUTRAL),
        'staging_excludes': ['reviewer-private', 'REPORT.md', 'RESULT.json', 'DATA_PREPARATION.py', 'SEAL_PACKET.py',
                             'PREPARATION_NOTES.json', 'STATIC_VERIFICATION.json', 'MANIFEST.json', 'SEALED_PACKET.json'],
        'boundary': 'Only the eight listed neutral inputs and 81 unchanged source members are actor-facing. No private expected answer or preparation history is staged.'
    }
    write('NEUTRAL_STAGE_MANIFEST.json', stage_manifest)
    check('N09-STATIC-19', not NEUTRAL.exists(), 'Final source-preparation readback: neutral N09 root still absent.')

    verification = {
        'schema': 'dg17.n09.source-data-verification.v1',
        'at_local_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'meaning': 'Bounded author-side data/hash/mode/manifest and source-text checks only. No original checker, actor, comparator, model, child, controller, host or protected operation.',
        'checks': CHECKS, 'checks_count': len(CHECKS),
        'passed': sum(x['passed'] for x in CHECKS), 'failed': sum(not x['passed'] for x in CHECKS),
        'actual_behavioral_results': 0,
        'limitations': ['Static declarations do not prove actor judgment.',
                       'Semantic leakage and sufficiency require fresh nonauthor prospective review.',
                       'Root receipts are read as actual supplied evidence; Root controller and remote publication were not rerun.']
    }
    write('STATIC_VERIFICATION.json', verification)
    print(json.dumps({'checks': len(CHECKS), 'passed': verification['passed'], 'failed': verification['failed'],
                      'source_members': len(members), 'source_bytes': source_bytes,
                      'neutral_input_members': len(stage_files), 'neutral_root_exists': NEUTRAL.exists(),
                      'approved_note_sha256': sha(approved), 'original_issue_sha256': sha(body)}))
    if verification['failed']:
        raise SystemExit(1)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        failure = {'schema': 'dg17.n09.data-preparation-failure.v1',
                   'error_type': type(exc).__name__, 'message': str(exc), 'completed_checks': CHECKS,
                   'behavioral_attempts': 0, 'note': 'A preparation failure, never an actor result.'}
        path = OUT / 'DATA_PREPARATION_FAILURE.json'
        if not path.exists():
            path.write_text(json.dumps(failure, indent=2, ensure_ascii=False) + '\n')
        raise
