# DG18 one-file package-reserve repair: independent source receiving

**Disposition: READY for guarded one-file source integration.** Exact base HEAD: 11c0dbd060723782ee896ea9d359b0e0233aa1cc. This is source readiness and retained-artifact verification, not a new original DG18/W-FULL award or publication authority.

## Exact source delta

The only modified path in the integration checkout is skills/implementaudit/scripts/read-canonical-pair.py. Its base bytes exactly equal read-canonical-pair.before.py; the worktree exactly equals read-canonical-pair.after.py. The source shrinks from 27,278 to 27,024 bytes (254 bytes). Before SHA-256: 25acc73dfeebe2f75a98d475128b00b529f98dddc80171ef498cd3979231aad7. After SHA-256: 733964e51ed4d65ebf8bdfba0e63cae1942e3697cab6a5cb95825d1a62f97b8c.

An independent AST comparison removes only module/class/function docstrings and ignores source-location attributes. The remaining executable trees are identical. The five textual hunks shorten the module description, the private-substrate comment, directory() documentation, the native Markdown/reference population comment, and the derivative-snapshot comment. The meanings that snapshots are derivative and nonauthoritative, native validators remain unchanged, links/aliases are not followed, and full owner-bound populations are preserved remain stated. No executable statement, function signature, constant, import, guard, source pin, package rule or reserve is altered. The actual Git diff is one file, nine added lines/eleven removed lines; diff-check exits 0.

## Retained package evidence

Both retained archives are readable, have unique member paths, pass CRC verification and contain the exact after-reader bytes at their expected projection paths.

| Artifact | Bytes | SHA-256 | Members | Actual reserve | Required reserve | Margin above required |
|---|---:|---|---:|---:|---:|---:|
| IMPLEMENTAUDIT.plugin.zip | 588519 | 14655df6e0cef849b83b0fef5f6da15ad3aaf1ce143ef61847d9052d9c08018f | 75 | 1305 | 1240 | 65 |
| IMPLEMENTAUDIT.skill | 583915 | d53aee27423eb040a747f4af009f366e9d3eb31eb6674c552b9c3678b5b3957f | 72 | 5909 | 2000 | 3909 |

The unchanged package contract sets both caps to 589824 bytes, with separate canonical and compatibility reserves shown above. These arithmetic checks use the actual retained compressed files. The canonical margin is 65 bytes; subsequent packaged source changes must satisfy the existing rule anew. No cap or reserve relaxation is present.

SOURCE_CHECK.json records the preceding CI failure at run 44637807032: 588597-byte canonical archive, leaving 1227 against the required 1240, a 13-byte shortfall. The received canonical artifact is 78 compressed bytes smaller and clears that requirement. Root reports the actual /usr/bin/python3, zopfli 0.2.3.post1 package-contract --build completed in inherited session 80266, poll 912fcb/0, producing both artifacts and 'ok'. That terminal transcript is not among this packet's five files, so the build completion/toolchain observation is attributed to Root; archive sizes, hashes, CRCs and embedded reader are independently checked here. No build replay was needed for this source-only disposition.

## Receiving limits and actions

Integrate only the exact after-reader under Root's current source authority. Preserve unrelated changes, the restored UCRT runtime logic, existing package limits and original evidence. No source/provider/controller mutation, test suite or costly build execution was performed by this reviewer. Checks were read-only Git identity/diff reads, AST parsing, hashing and archive inspection. Reports are confined to the assigned independent-engineering-review directory.

Evidence identities and checks are in SOURCE_AND_ARTIFACT_CHECKS.json and INPUT_BINDINGS.json. The source packet remains unchanged.
