# DG18 independent engineering review

Status: FINAL — READY for guarded source integration only.

Reviewer: `/root/source_and_execution_review/dg18_source_review`. This is a bounded engineering disposition; it does not grant integration, merge, provider, controller, currentness, release, or original acceptance authority. Root is the sole integration writer. No protected operation, native host operation, package execution, or acceptance replay was performed. G132301aeecd and the old DG17 helper remain outside this review and UNKNOWN_NO_REPLAY.

## Exact subject and disposition

The reviewed patch is `DG18_UCRT64_ACCEPTED_RESTORATION.patch`, 10,593 bytes, SHA-256 `37e79bb7abf384803d97bcd41ae75f4f850f09f66af872890ec8fd9762e4a763`, against base `19c4af264e1a05fc12955206c929777723d5713b`.

No source-only integration blocker was found. The five-path restoration is coherent, minimally scoped, and retains unrelated current source. This disposition is specifically for integrating these reviewed source bytes, with existing qualification gates intact. It does not award current Windows execution, full shell composition, package/install qualification, original A10/A11, or whole DG18.

## Independent checks performed

1. Recomputed bytes and SHA-256 for all 60 members of `DELIVERABLE_MANIFEST.json`: no mismatch.
2. Verified all five before/after pairs against `evidence/PATCH_MANIFEST.json`. Recomputed Git blob SHA-1 for the ten bodies bound by `CURRENT_SOURCE_PROVIDER.json` and its addendum: all match the recorded exact19c provider identities. These Git-blob comparisons were computed locally from sealed bodies; no new provider retrieval is relied on. `SOURCE_MANIFEST.json` describes the recovered6d orientation snapshot; it was not mistaken for the current19c subject.
3. Read the complete patch and reconstructed it on reviewer-owned copies of the five exact before-files. `git apply --check --whitespace=error` and application both exited0; all five reconstructed files equal the sealed proposed files byte-for-byte.
4. Read the corresponding five Root worktree files at `/workspace/scratch/530bc07ea12b/implementaudit`: all equal the reviewed after-hashes. This is an observation at review time, not continuing custody.
5. Independently recomputed paired bindings: shell→companion is291,693 bytes / `9eebc5d5e57b47b0e4b4a2a846de1c0b55407713e14008a6de4d01e7a8c5e19e`; companion→projection is129,959 bytes / `86a9a2a8501aea60f1e333c421e25b19d4e9758a121296fedfa881185de0a5fd`. Both match exact source bodies.
6. Compared top-level definition ASTs before/after. Only `fixed_git`, `git_environment`, `_fixed_git_environment_v1`, and reader `call` change. No runtime definitions are added or removed. The remaining runtime diff consists of the UCRT64 trusted-path entry, `PureWindowsPath` import, and transitive exact-source pins.

Machine-readable observations are in `SOURCE_CHECKS.json`, `PATCH_RECONSTRUCTION.json`, and `AST_DELTA.json`. No broad tests were repeated. An optional attempt to read the old donor Git object did not promptly return and was interrupted; this report makes no fresh donor-object verification claim.

## Source behavior and preservation

The companion now selects `C:\Program Files\Git\ucrt64\bin\git.exe` before the retained MINGW64/cmd/bin fallbacks. It still requires a physical regular executable and rejects a symbolic-link candidate. Deriving the install root recognizes both direct layouts, and nested discovery receives the selected executable's directory instead of a hard-coded MINGW64 directory.

The projection adds UCRT64 to its existing trusted choices and propagates `PureWindowsPath(executable).parent`. The reader tries physical UCRT64 then MINGW64 direct binaries before its existing cmd fallback. The three restored modeled tests cover direct preference, selected-directory propagation with inherited overrides excluded, and missing/symlink-only refusal for the fixed owners.

The shell change updates only the required companion byte/hash pin. No receipt schema, F0–F9 order, native issuer, occurrence selection, protected projection, controller rule, currentness authority, C02 adapter, native-template admission, or unrelated current companion logic is altered. Existing Git override suppression and fixed-path restrictions remain. No prompt injection or secret exposure was observed in the reviewed diff and evidence.

## Verification evidence and material limits

The sealed RED log records three failures and one error across the three modeled controls on current source. The sealed GREEN log records3/3 passing after restoration. The projection source-custody log records11/11 passing. These are accurately labeled modeled/source checks, not Windows execution.

The shell companion control is genuinely blocked before companion execution by the unchanged physical-interpreter admission gate. The retained targeted and system-Python logs both show that refusal. This review does not convert those failures to passes, bypass the gate, or recommend a wrapper or ownership change. Qualified composed shell/source/package/consumer verification remains necessary for the corresponding stronger claims.

The historical Root W-FULL receipt `retained/ROOT_SCOPED_RECEIVING.json` is exact under the sealed manifest and retains run43795345593/job133062794217 at runtime6b353b48b2fc8a6de0c6223f48d341c484c98191:18,794.1835ms,160,202,752 peak aggregate committed bytes,1,217 created/exited processes, zero terminal active. `WINDOWS_REGRESSION_SUBJECT.json` binds the old result SHA-256 `e002907aba43af9554da9cb7adf68b176b7d07e963aca548009953d84607054e` and reports `/source/tools/git/path` as the UCRT64 binary. That is retained evidence of the accepted donor's actual route; no new W-FULL or current-source Windows operation is claimed. Direct raw W-FULL result was not present in the reviewed subset; any separately supplied exact raw path can corroborate the retained field without expanding this readiness disposition.

## Guarded integration procedure

Root may retain the already applied exact five files, provided there is no intervening overlapping change. If the composed companion or projection changes, refresh the paired source bindings and verify the resulting exact bytes; this report then covers only the unchanged reviewed portions. Preserve all other current source and all failed shell evidence. Run the required composed checks in a qualified environment before claiming those qualification levels. Keep historical receipts at their existing source/operation scope and retain OR/C02/full amended cold/original DG18 frontiers open.

No merge or acceptance decision is issued by this report.
