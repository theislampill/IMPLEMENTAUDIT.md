# G2 pre-provision host inventory: independent source review

**Disposition: READY for the exact ordinary, one-shot public host observation.** This is source readiness for observing pre-provision inputs. It is not host admission, an executed inventory, original full-G2 readiness, permission to run the pair, or M2 acceptance.

## Exact packet

Manifest: /workspace/scratch/530bc07ea12b/dg16-g2-original-successor/HOST_INVENTORY_BUNDLE_MANIFEST.json

Manifest SHA-256: da9f0592a12b620d65c95c044f1646a4b41eb8847f249e9c8f110cce173bb2c0.

The exact three-member population under host-inventory-bundle verifies by regular-file type, size and SHA-256:

| Member | Bytes | SHA-256 |
|---|---:|---|
| .github/workflows/dg16-g2-source-host-inventory.yml | 2089 | 8a36090f4d5fea0501940ffedbc02a6d453183d23ee69df9adc1caec558a157f |
| qualification/dg16-g2-host-inventory/observe.py | 3122 | c221b016d3e6ef7ec3742c3a47673b143ecbd50eba42c721c342d4c8aad518e1 |
| qualification/dg16-g2-host-inventory/host_utility.py | 65235 | 02a15dc96ecce23e14a3a84bca880aa536d79fffc4f6d6160835cb4ba97a19b5 |

The utility is byte-identical to the previously received production utility. Source readiness attaches to these exact bytes and does not cover subsequent edits.

## Workflow boundary

The sole host-facts job is restricted to repository theislampill/IMPLEMENTAUDIT.md, push on pro/dg16-g2-source-host-inventory-20261119-01, a created/nondeleted/nonforced branch event, zero before-SHA and attempt 1. It uses ubuntu-26.04, a five-minute job bound, contents:read, a fixed concurrency group without cancellation, and exact checkout/upload action commits. Checkout selects github.sha, disables credential persistence, submodules and LFS, and keeps the packet under its named checkout directory. There is no workflow_dispatch, pull-request trigger, repository write, installation or test-pair step.

The earlier job-level runner-context error is absent: this job has no job env. runner.temp appears only in the observer step's env and the upload step's with.path. Current official GitHub context documentation explicitly permits runner in both positions and excludes it from job env. This was checked against https://docs.github.com/en/actions/reference/workflows-and-actions/contexts (context-availability table: jobs.<job_id>.steps.env and jobs.<job_id>.steps.with).

The observer is executed with /usr/bin/python3 -I -S -B only after its full body matches the fixed SHA-256. It imports the exact hash-checked utility body under a non-main module identity and checks those utility bytes again afterward. YAML and Python syntax parse; the exact shell body passes bash -n. No observer or utility code was executed by this reviewer. These checks do not claim server-side workflow admission or a run result.

## Observation semantics

The observer reads the same kinds of host inputs used by the original run inventory: selected OS release values; architecture and kernel; effective UID and all six real/effective/saved UID/GID values; Python version; ImageOS/ImageVersion; the exact trusted facts for bash, bwrap, git and python3; and a SHA-256 of boot identity. The six credential fields match original native_profile.credentials(). It adds a byte/hash observation of the actual unittest.runner file and a bounded child-census read. Public facts have strict token/file bounds; boot and child bodies are hashed, not exported. No entire environment, credential value, private key, unrelated filesystem population or raw proc body is dumped.

All tool inspection uses the unchanged trusted() gate: canonical /usr/bin resolution, executable file, root-owned nonwritable path chain, no set-ID/file capabilities, bounded regular-file read and content digest. The observer performs file inspection; it does not execute those tools, enable subreaper behavior, install packages, invoke a controller or run a native bank/pair.

Original run.py calls inventory(), observe_host() and native admit_host() before entering provision(). The original provision command installs python3-venv, ripgrep and nodejs and then creates/qualifies its ordinary dependency environment; it does not install bwrap. Labeling this output PRE_PROVISION_INPUTS is therefore materially correct. The observer does not claim that the tuple is post-provision or will be unchanged on another job.

The original inventory additionally enforces nonroot Linux/x86_64, Ubuntu 26.04, every required trusted tool, interpreter identity and native-profile validation. This observation intentionally does not claim those checks succeeded: its schema/scope says public read-only facts without qualification, observation_phase names the pre-provision boundary, qualification_or_post_provision_match is false, and original_acceptance/full_G2/M2 are false. Facts may be received as inputs for a prospective binding decision; they cannot substitute for those actual original gates.

### Missing bwrap remains a refused prerequisite

trusted() returns (None, an available:false fact with code/errno) on a missing or untrusted tool. The observer preserves that returned fact; it does not substitute a different path, install a tool or coerce available to true. Consequently an inventory job can succeed while reporting bwrap unavailable. That means observation succeeded, not that host admission succeeded.

The original run requires every returned tool path and raises TRUSTED_TOOL_UNAVAILABLE before provisioning when bwrap is missing. Its native profile independently requires available:true and the complete trusted-tool fact shape. Those constraints remain untouched and cannot be discharged by the observer's output. A future missing-bwrap observation must remain an unresolved original prerequisite, without an admission or fallback claim.

### Procfs size semantics

The exact checked_file() requires a regular file, permitted link count, stable pre/post metadata, stat size within the bound and actual read bytes within the bound. It does not equate stat size with read length. Therefore a regular procfs boot-id file reporting stat size zero while returning 37 bytes is not intrinsically rejected. HOST_INVENTORY_PROCFS_CHECK.json retains that author-side read observation with the exact utility digest. No procfs or cleanup recheck was rerun here; the actual hosted child-census read remains an observation to receive from the new run.

## Output and actual receiving boundary

The only output directory is the fresh run-specific runner-temp path; mkdir has no exist_ok and the sole HOST_FACTS.json is created exclusively. JSON is bounded at 16 KiB. Upload selects only that directory, excludes hidden files, requires an output and retains it for seven days. A failed observation remains a failed run; there is no continue-on-error, outcome repair, automatic retry or fallback. Missing tools, as described above, are explicitly represented facts rather than a swallowed tool refusal.

After Root's separate issuance, receive the actual run/attempt/commit, all step outcomes, exact workflow/source identity, full observer output and artifact digest/member bytes. Require the actual HOST_FACTS.json to retain these ceilings and compare available/refused facts directly. Preserve any failed read or partial provider outcome. Do not promote job success, another boot's identifier or these pre-provision observations to original admission, native qualification, complete-pair execution, closing, M2 or full G2.

## Reviewer operations and authority

Read-only inspection, manifest/hash checks, AST/YAML parsing and shell syntax checking were performed. There was no provider write, source/controller mutation, observer execution, test or package-build replay. Root alone owns issuance and any later integration, profile/policy/effect binding or original acceptance. Reports and manifests are confined to the commissioned independent-engineering-review/new-current-source directory.
