# Independent receiving: actual G2 pre-provision host inventory

**Disposition: RECEIVED_PRE_PROVISION_HOST_FACTS.** The exact independently reviewed observation ran once at attempt 1 and its public facts are received. This is not original host admission, native qualification, readiness to execute the pair, M2 or full-G2 acceptance.

## Actual provider and source identity

| Field | Independently received identity |
|---|---|
| Repository | theislampill/IMPLEMENTAUDIT.md |
| Branch | pro/dg16-g2-source-host-inventory-20261119-01 |
| Commit | 90fa005389b5e3872d002cbabca8fdd44c1711e0 |
| Tree | 1f1dc9d1e37cf86970d239cbc041b4698850708d |
| Sole parent | 14ed4c7179d477d90882ebf5c5031692056e5491 |
| Run / attempt | 44641408350 / 1 |
| Check suite | 120839973887 |
| Job / check run | 135973097448, host-facts |
| Provider status | completed / success |
| Job interval | 2026-11-19T23:53:49Z to 23:54:02Z |

Direct run: https://github.com/theislampill/IMPLEMENTAUDIT.md/actions/runs/44641408350

The recursive Git tree is untruncated and contains exactly the three reviewed regular blobs. I independently computed their Git blob identities from the reviewed bodies and matched every published mode, byte count and blob ID. The SHA-256 values remain workflow 8a36090f4d5fea0501940ffedbc02a6d453183d23ee69df9adc1caec558a157f, observer c221b016d3e6ef7ec3742c3a47673b143ecbd50eba42c721c342d4c8aad518e1, and utility 02a15dc96ecce23e14a3a84bca880aa536d79fffc4f6d6160835cb4ba97a19b5.

The complete jobs API has one job and six step records. Setup, exact checkout, observer, public-facts upload, checkout post-cleanup and job completion all succeeded; none is skipped. Full logs corroborate source-hash enforcement, actual observer output, upload and cleanup. Token permissions were Contents: read and Metadata: read. Checkout removed authentication before observation. The job retains the actual Node deprecation warning for the pinned actions; the check API counts one annotation, without an independently retrieved annotation body. No error or failed step is hidden by this receiving.

Source: retained runs/run/jobs/checks/Git-commit/Git-tree tool returns and job.log. The exact three-member source comparisons are in RECEIVING_CHECKS.json.

## Downloaded artifact and exact output

Artifact 14586122537, g2-host-facts-44641408350-1, was independently downloaded. Its ZIP is **1350 bytes**, SHA-256 **658c0031c816559137315fd5d322f13887253f9c2aa2d86c6deac6438ff85f1c**, matching the provider artifact record and actual upload log.

It contains exactly one regular member, HOST_FACTS.json: **2931 bytes**, SHA-256 **33550ce5c2daba94e5a2d3b629b757bc832ca4ccda845e0c6614cbbda680e93b**. The extracted body is byte-identical to the observer's stdout after removal of provider log timestamps. Its run ID, attempt, workflow commit and source hashes match the independent provider/source readbacks. This log/artifact match establishes consistency of one producer's retained output; it is not counted as two independent measurements of the host.

The full actual JSON is retained as HOST_FACTS.json. ARTIFACT_RECEIPT.json binds the ZIP and member. The short-lived signed download URL is omitted from the durable receipt.

## Exact observed host facts

| Field | Actual pre-provision value |
|---|---|
| OS release | ubuntu / 26.04 |
| Architecture | x86_64 |
| Kernel | 7.0.0-1016-aws |
| Python | 3.14.4 |
| ImageOS / ImageVersion | ubuntu26 / 20261111.82.6 |
| UID, EUID, SUID, GID, EGID, SGID | all 1001 |
| Boot-identity SHA-256 | 3515902b2111619d1a825dbe8936a69a9b45fde1507c0d422f1835718008f18e |
| Child census | readable; zero bytes; empty-content SHA-256 |
| unittest.runner | /usr/lib/python3.14/unittest/runner.py; 11383 bytes |
| unittest.runner SHA-256 | 51780085229bd3547a2751e8d75ab1d8f391dd2c9c3ca1d011b54529348faeb4 |

The provider log identifies runner 2.338.2, Ubuntu 26.04.1 LTS and AWS us-west-2. That display's patch-level OS label is not a replacement for the observer's exact /etc/os-release VERSION_ID. The log's image version equals the observed ImageVersion.

All four required tools were observed available. Each returned fact records the exact root-owned/nonwritable chain check and absence of set-ID or file capabilities, enforced by the unchanged trusted() helper:

| Tool | Canonical path | Bytes | SHA-256 |
|---|---|---:|---|
| bash | /usr/bin/bash | 1540520 | 450c68376d14e5040d36cce58605c35b2211d244f3079297440dc9d602ee4994 |
| bwrap | /usr/bin/bwrap | 80424 | a85b0ff8664c52ab923e0daf7e20cbc394272cd3831cc492ab144105d8091361 |
| git | /usr/bin/git | 4771424 | 8fb7c4c2a0e5ec847626098c2a375ff01d6a9e5f81352e3ae56f30b41ec850cd |
| python3 | /usr/bin/python3.14 | 7468968 | be9a2a5eada8c89c1c399fdfb8397179e877c20d8db0739c802f726d4d0e69fd |

No missing-tool refusal occurred in this actual observation. This does not weaken the refusal behavior: a later available:false tool fact, including bwrap, remains a refused prerequisite under the original inventory. No installation, substitution or fallback was performed here.

## Evidence ceiling and next gate

HOST_FACTS.json retains authority NONE, scope PUBLIC_READ_ONLY_FACTS_NO_QUALIFICATION, the PRE_PROVISION_INPUTS observation boundary, qualification_or_post_provision_match=false, original_acceptance=false, full_G2=false and M2=false. It also explicitly reports no decision/grant and no test pair/native bank. The exact workflow and all actual step records agree with those limits.

These are actual observations from this job and boot. They can inform review of a prospective exact source/native-profile binding. They cannot serve as another job's host-admission receipt or establish post-provision currentness. The producer commit's parent being 14ed4c7… is not evidence that the product candidate's entire native or verifier behavior ran in this three-file observation tree.

For the future original episode, the genuine **same-job nine-case native bank remains mandatory before the complete pair**. This inventory neither creates that receipt nor removes the gate. No redundant separate native execution is requested by this review. Preserve the original source/native applicability, actual policy/effect decisions, complete pair, authentic live review/Root consumption and same-job closing requirements.

The upcoming original candidate remains unreceived until Root supplies its sealed exact manifest. This reviewer did not inspect or adopt the unsealed candidate. Protected G132 and old DG17 UNKNOWN_NO_REPLAY boundaries remain untouched.

## Operations and retained evidence

This receiving used read-only provider fetches, independent artifact download, bounded extraction and file/hash/JSON comparisons. No observer rerun, source/provider/controller mutation, native bank or pair execution was performed. The public source and prior sealed reviews remain unchanged. All new files are confined to the commissioned new-current-source/g2-host-inventory-run directory. Root retains original acceptance and all consequential actions.
