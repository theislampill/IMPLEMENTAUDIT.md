# Independent engineering review: DG17 interruption variants

Report state: FINAL  
Reviewer: /root/dg17_interrupt_variants_reviewer  
Review date: 2026-11-19  
Review kind: independent nonauthor source and prospective-observation review  
Authority: advisory findings only; no formal child-skill route, operational admission, native attestation, case acceptance, integration, or closure authority

## Disposition

**PASS — bounded source preparation.** The three recovered PROTOCOL variants are coherent candidates for excluding one incoming L4 interruption at L1, L2, or L5 while retaining independent non-propagation, witness, currentness, and nonclosure duties. Their present hashes equal the three commissioned hashes, and a direct current-byte diff readback matches each retained patch exactly. This is a source finding, not an observed mutant kill or proof that every future consumer will resolve overlapping clauses correctly.

**GAP-REVISE — a concrete successor observation design.** Before an actual comparison, a successor must bind one genuine failed predicate across all four owners, specify an observable interruption discriminator and component-level attribution, complete its required post-L3-only control, and freeze real task, source-selection, visibility, model/configuration, capture, and receiving inputs. The current preparation explicitly leaves these unfilled. Revise by adding an independently reviewed successor; do not edit the frozen input or tune after an unfavorable observation.

**BLOCKED — current original-case scoring.** The reviewed bytes contain no experimental consumer output, genuine owner-stage observation, complete four-owner family, or actual receiving decision. They cannot presently award N06, M01, a completed return, or any native/host obligation. This is a statement about missing evidence in this packet, not a claim that a host, model, or authorized future route is universally unavailable.

The original acceptance predicate remains unchanged. A particular historical L3 fixture ID is not intrinsically required. A fresh genuine matched family may qualify if every original applicable premise and control is observed. This review neither waives original requirements nor adds a universal native gate to source or read-only model-policy preparation.

## 1. Identity, recovery boundary, and review independence

The reviewed root is:

/workspace/scratch/2678f1e431c3/recovered-interrupt-source-after-workspace-loss-20261119

Below, P/ means its recovered-bytes/ directory. S/ means P/source/baseline/. Exact file identities, spans, excerpts, and observed readback locators are retained in EVIDENCE_INDEX.json. The complete independent review artifacts are under:

/workspace/scratch/2678f1e431c3/dg17-interrupt-variants-independent-review-20261119

The NEW recovery manifest is 17,084 bytes, SHA-256 ff268fa28d60381f77f956aaf50a575c864019c7fed95c5f85e6de1ad3986ed1. My direct readback 08b882/0 observed that exact manifest identity. The recovery receipt is 15f8c02b538b734d35e7dba96ccee6618ae4820857388e98026e9a324aec4665, with separately recorded actual recovery return 0c9f0a/0. Those identify a new recovery population. They are not the old source-preparation seal. [E01–E03]

The recovery records distinguish 72 materialized original paths out of 86: 46 match retained individual old hashes, 26 were recovered from complete retained authoring inputs or output without independent individual old pins, and 14 original file byte populations remain unavailable. The 46 include all 35 baseline/policy copies. The complete old 80-file static manifest, its checksum file, original timed verification receipt, and other listed files remain unavailable. The new manifest covers 88 static recovery files; the receipt/envelope population brings that new recovery population to 92. These are different denominators, explicitly identified in the recovery records. [E01–E03]

I reuse the retained actual 44ff77/0 source-integrity return only as a historical observation. Its output says PASS_SOURCE_INTEGRITY_ONLY, three variants, one changed file and two replacements per variant, 80 sealed static files, and zero behavioral/model execution or original acceptance. The retained 507946/0 return records the old seal readback. Neither observation restores the missing old complete manifest or timed receipt. A new source verifier run would not restore that history either, and I did not run one. [E04]

The source baseline is attributed to commit a297957be11feb494c0ec467235794a1e0c54751, tree b08dc4ecf4028beeedb579a312eccae23cb5d863. Root independently reacquired the seven originals and issue/comments; my source use is the exact currently available bytes and their retained/reacquired identity records. Target SKILL.md and all other policy copies were inspected as source DATA. They were not activated as instructions governing this review.

I did not author or modify the reviewed packet, consult another reviewer's findings, or operate an experimental consumer. The author report is an object under review, not a source of independent behavioral evidence. The supplied parent currentness identity, dg16-dg18-recovery-20261119-b/G0001@423187ec3dc21309154f6854a36323a0337b2c3f with caller-reported require return 422c5e/0, is caller context only. It is not my native attestation or an actor admission. Exact requested/actual reviewer model identity, deployment version and configuration are not established by a host model receipt in the supplied task; this review does not manufacture that attestation or claim to discharge a formal prospective native review gate.

My operations were source reads, bounded current-byte comparisons, retention of observations, and writes inside the newly owned review directory. I issued no provider/Git/GitHub mutation, source test/verifier execution, actor dispatch, controller transition, native callback, hosted operation, or mutation of the input packet. A broad orientation grep was transport-truncated; it was used only to locate material. The decisive spans were separately read completely and the essential full texts retained.

## 2. Source mutations: coherent and bounded, with a precise minimality limit

| Variant | Policy population | Current PROTOCOL SHA-256 | Source edit |
|---|---|---|---|
| L1 exclusion | p2a9 | f10ab608a5ac508f66a17e33b5d701146072716f0b6d8945ea09296cc7cd8a8f | Replace eligibility text; remove baseline return row 824 |
| L2 exclusion | p6d1 | 9cd92215b653c61b3b82aac90c876ff61d8be98caba507516988775dde39b67a | Replace eligibility text; remove baseline return row 825 |
| L5 exclusion | p4e8 | e755bf64654c29ef036337e957bbc1f9ebc8374d8881b58a0e560a7d9d11b26d | Replace eligibility text; remove baseline return row 827 |

The baseline PROTOCOL is 24b5079e1cacdbb8d195d94d48e82f5683e915424aaf3fb8514a282dd3396c5c. My actual readback 08b882/0 computed each diff from the current full files and found byte equality with P/diffs/L1.patch, L2.patch, and L5.patch. Their respective patch hashes are 88a0fbfe31f32b2d9828f133881d34bd6b56eeafc4b530c960f51eb0f2e7ba04, 08b310711e47f9737073f148e64472ffe6d24d6e1ad2f520e3a70ded49d30737, and 981bc39d4367757f294ac5eb26abe15f6ed3a5eb2f34f139511c7a9ba1b34f4e. [E05–E08]

The exception has a coherent local reading. It names exactly the excluded owner, retains the other three eligible owners, states that the exception governs Andon referrals at that control, and explicitly preserves independent guards. This is enough to express a specific exception to otherwise general referral rules without creating a second transition owner. Removing the corresponding conditional return row is coupled to removal of that route; the other return rows and prerequisite restrictions remain. The historical integrity receipt and recovery pins support preservation of the other policy files. My direct comparison independently confirms the three present PROTOCOL deltas; I do not restate the old broad verification as a newly executed check. [E04–E09]

The explicit exception is materially stronger than deleting an owner name from the permission list. The unchanged source contains:

- SKILL.md lines 23–35: gate failure routes to Andon/handoff; lines 271–306 also impose structural/refusal and final-audit duties.
- Lean lines 15–16: a general ordered Jidoka chain and visible Andon signaling.
- PROTOCOL lines 706–730 and 772–779: general mandatory-failure and any-abnormality referrals.
- PROTOCOL lines 322–333: resume corruption triggers a probe.
- Transcript contract lines 191–213: first-abnormality probe and phase-resume shorthand.
- PROTOCOL lines 1018–1029 and 1063–1078: final command-failure visibility and independently required audit-fix/re-audit.

The owner-scoped exception can qualify entry to L4 without canceling those clauses' independent obligations. A visible abnormality signal, preserved mismatch, or normal audit-fix is not necessarily proof that L4 interrupted the owner. Conversely, the exception cannot fairly be used to erase all visibility or currentness duties merely because they occur in paragraphs containing the word Andon. The new text's explicit preservation sentence and the retained control sources support this restricted interpretation. [E09–E12]

I accept this as a bounded two-span, single-route source mutation. I do not certify the stronger assertion that it is the mathematically smallest possible textual mutation. An entry exclusion alone could leave a conditionally unreachable return row; therefore row removal is not proved logically necessary merely because the route is excluded. Its present removal is coherent and in scope, but there is no need for another source edit just to pursue minimum byte count.

The two spans also require attribution care. If a consumer still performs the incoming interruption but then returns to the wrong owner because the return row is absent, that is an observed return-path failure under this mutation. It must not silently become proof that the incoming edge was behaviorally unavailable. Component-level evidence should distinguish those findings. This does not change the original predicate; it prevents a stronger inference than the observation supports.

## 3. Original N06/M01 requirements are preserved, but the complete family is absent

The exact issue body is 64,795 bytes, SHA-256 ca62f4899a45544549f623a0312c16121bb99f432ccb87a87b7361974ceb94c4. The controlling original clauses are:

- Line 521: L4 interrupts L1/L2/L3/L5; the discriminator is the same failed predicate at each loop; the burden is a four-edge matrix plus post-L3 mutant.
- Lines 551–554: the positive scenarios identify planning failure before dispatch, custody/currentness mismatch during resume, Smoke B regression, and an exact-candidate final-audit gap after clean phases.
- Line 564: N06's post-L3-only scenario must fail at the L1/L2/L5 interrupts.
- Line 601: mutation controls independently remove or invert one of the four interruption edges.
- Lines 588–595 and 616–619: model-facing independence/capture requirements and semantic behavior, rather than word presence.
- Lines 762–783: evidence layers and claim ceilings. [E13]

M01 is the campaign label for the line-601 requirement, not a literal invented issue row. The prepared mutation files do not alter the issue or owner comments. The preparation's descriptions of these source obligations are faithful.

P/evaluator/MATCHED_COMPARISONS.json, however, declares exactly three pairs and leaves each predicate, task hash, command hash, witness, layer and output null. Its line 67 refers to already existing L3 evidence without binding an actual locator or its predicate equivalence. Cross-pair predicate equivalence is null. None of the three variants is a post-L3-only policy: each individually retains two other non-phase edges. [E14]

This is acceptable as explicitly partial preparation. It is not a complete original N06 observation family. A successor must either retrieve genuinely applicable retained L3/post-L3 evidence with exact identity and an evidence-transfer justification, or bind fresh observations for those cells. The recovery clarification correctly rejects treating a historical L3 locator as a permanent added acceptance prerequisite. There is no need to recreate a lost fixture merely to preserve its name. [E02, E14]

One frozen predicate must mean the same decisive proposition across owners. Four nonzero exits, four evidence-mismatch labels, or four differently owned checks renamed to a common umbrella are insufficient. Stage-specific prerequisites and occurrence IDs may differ. The command owner, decisive check/component, subject binding, expected versus observed relation and interpretation of failure must remain demonstrably equivalent. If the command is composite, preserve the exact common failing component, not merely its aggregate exit status.

The exact original case remains open here. This report does not decide the entire historical campaign's status from a three-pair preparation. It preserves all other original positive, negative, boundary, held-out, terminal, host, and receiving duties at their actual scopes.

## 4. Behavioral oracle: strong safeguards, but concrete attribution is still needed

P/evaluator/ORACLE.json already contains valuable protections. Eligibility requires real task/checkpoint/source/configuration/witness binding, matched inputs apart from policy, actual changed-source selection, same-predicate evidence, and an explicit observation layer. B1–B5 separate timing, supported abnormality, non-propagation, owner continuation, and authority. Its outcome set retains canonical failure, survival, refusal, nonverdict, partial observation, unfilled premises and confounding. Source differences and refusals alone cannot kill a mutant. The report also correctly says that a recommended next action is not executed correction or return. [E15]

The remaining gap is an operational rubric for a real task. Before exposure, the successor must state what observations distinguish all of these:

| Observation | Permissible interpretation |
|---|---|
| Consumer never received or admitted the selected source/task, or a required input is absent | Admission refusal, unfilled premise, or nonverdict; no behavioral kill |
| Admitted canonical consumer merely refuses a stale operation but omits the original applicable abnormality/return obligations | Canonical failure or partial observation at the declared layer |
| Admitted variant explicitly excludes L4 and omits the required interruption while retaining independent stops | Candidate target-edge failure, if the canonical witness and causal attribution are supported |
| Variant performs the complete required interruption and continuation despite its exclusion text | Mutant survived; preserve the source conflict/interpretation |
| Variant intercepts correctly but fails only the owner return | Return-path finding; record B1 and B4 separately |
| Both arms merely say stop/re-anchor/re-audit | Insufficient by itself to distinguish L4 control from surviving independent guards |
| Model describes a repair, a receipt, or a future re-audit | Decision evidence only until actual relevant owner/command/receiving evidence exists |

A refusal caused by the admitted variant's behavioral rule is not the same thing as refusal to admit the experiment. Otherwise the very intended negative can be discarded as REFUSED_UNSCORED, or an infrastructure refusal can be incorrectly counted as a kill. The predecessor oracle's reason distinctions support a proper implementation, but no concrete instance or adjudication examples have yet been bound.

Relevant distinguishing evidence can include the actual decision ordering, the abnormality record/class and witness, containment scope, the selected probe/countermeasure/rerun obligations appropriate to that occurrence, and the current-evidence condition for returning to the actual owner. Use the policy's applicable obligations, not a requirement to print a magic L4 or ANDON token. The actor need not execute unauthorized effects to produce a bounded model-policy decision, but then the claim must stay at that decision layer.

L2 and L5 are the strongest confounds. Currentness refusal survives the L2 mutation. Bounded audit-fix and exact-candidate re-audit survive the L5 mutation. A result caused entirely by these independent clauses may be a correct surviving behavior. Do not remove those guards, make the task unsafe, or edit the mission to force a kill. This source review does not predict the model outcome.

## 5. Neutral delivery, controls, and capture

The common primary prompt (SHA-256 713b3bd02eb975aaeb772e194a034f1ef13d5c9497ae4961d603b01759fdaf4a) and paraphrase (054fe86e28c6d0e5deed3e7076960f3ed6f9a6dc1ed2047ae89167a8e09ec7e6) are neutral with respect to DG17/N06/M01, selected target owner, canonical/variant polarity, and expected outcome. They ask for a supported next decision within scope, with unknown facts retained. The opaque policy-population names also avoid direct answer labels. This is a PASS for those template texts only. [E16]

P/evaluator/ANTI_GAMING_CONTROLS.json declares expected values, plausible distractors, forbidden mission phrases, positive paraphrase, triviality, bloat, polarity, authority and context/no-payoff controls. It truthfully leaves their actual inputs unfilled and outcomes unexecuted. A single predeclared first observation per arm is an experimental sampling rule, not an arbitrary cap on authorized policy repair. Retain all first outputs and nonverdicts; any additional warranted study must preserve its predecessor and justify a changed premise prospectively. [E17]

A real delivery can still leak the answer through work-record fields, task filenames, outer directory names, requirement extracts, diffs, reviewer commentary, other arms or an evaluator map. The final delivery must consist of the selected policy, one prospectively selected neutral mission, the policy index and genuinely filled work inputs, as the packet itself requires. The all-arm map and null templates are not dispatchable input. Review the complete final task and artifact population, not just the common prompt's absence of forbidden words. [E18]

A fresh conversation via fork_turns: none removes inherited conversation history; it does not itself prove filesystem isolation or absence of other accessible files. The recorded environment gives sibling agents a shared filesystem. Use an actual neutral per-arm delivery root and a recorded allowed-read/action boundary, preserve the delivered population and observed reads, and record any exposure to evaluator material. If stronger isolation is claimed, it needs actual evidence. This is an input-fidelity requirement, not a new universal sandbox prerequisite.

The seven-file population is sufficient for this source review, but it is not a complete installed package. A later consumer that follows SKILL or PROTOCOL to a required script/progressive source may legitimately refuse if that dependency is absent. Bind the exact additional inputs actually required by the chosen route, equally in both arms. Demonstrate that the changed PROTOCOL clause was selected and available before inferring source consumption. A path in the policy index, an agent ID, or a completion does not prove that read. [E09, E15, E19]

P/evaluator/CAPTURE_MAP.json names prospective interfaces and correctly leaves operational values unbound. Before the first draw, establish that the selected route can retain the exact submitted prompt and delivered hashes; requested and actually observed model/version/configuration; external outputs and relevant tool activity; dispatch/completion/transport status; complete command stdout/stderr, actual producer exit status, argv/cwd/environment/source and times; evaluator identity and disposition; and actual Root receiving. Unknown host fields must remain unknown. A requested model, default model, or self-description is not a substitute for an actual model/configuration binding where the original requirement demands it. No hidden internal reasoning trace is needed. [E19]

For mandatory commands, capture complete producer streams to evidence files before displaying excerpts. A truncated host return cannot establish complete capture, absence of findings, or success. An exit from a downstream formatting command is not the producer's exit. Lean lines 66–89 already impose those rules; they are not new review requirements. If the selected model interface cannot expose a required field or complete return, narrow the observation and preserve the exact capture gap instead of inventing it. This packet has not demonstrated such an interface failure; the fields are simply unbound. [E10, E19]

## 6. Genuine owner-stage premises

P/evaluator/ADMISSION_TEMPLATE.json has the right conditional shape: actual common and owner-stage values remain null, and a successful currentness receipt is not demanded as a fictional premise for a mismatch case. Its safeguards deserve preservation. They are not evidence that any owner stage currently exists. [E20]

| Owner | Genuine premise to bind | What cannot substitute |
|---|---|---|
| L1 | Real planning scope and pending owner/dependency/authority/acceptance decision; last safe checkpoint and failure before dependent dispatch | A fabricated phase number, a generic prompt saying planning, or a dispatch assumed to have happened |
| L2 | Actual controller/claim/run root, real boundary provenance where applicable, source/pointer generation, ordered reads and original receipts or specifically observed absence, exact mismatch and affected current use | Root's unrelated receipt, a remembered old receipt, an invented compaction, or a model sentence minting currentness |
| L3 | Real applicable phase/task, clean baseline where required, actual execution/Smoke B evidence and the same failed predicate component | A package-refusal fixture, different test failure, or inherited fixture name without the operative records |
| L5 | Exact real candidate and audit object, actual final-audit entry and clean prior phases/checks for the original cell; late same-predicate witness and retained finding | A file named final audit, a parent summary, assumed earlier passes, or an unrelated already-green candidate |

For L2, the original continuity owner distinguishes ordinary post-boundary execution from the narrow required completed-boundary cognition exception. Unresolved currentness can be the observed negative premise; it cannot authorize ordinary execution around the stop. A separate properly admitted observer may consume a genuine frozen checkpoint at a read-only model-policy layer without replaying a completed transition. That observer's lawful route and actual evidence boundary must be specified. Do not pretend it is the stopped owner's native re-entry or required governed cognition. The original G0011 physical currentness receipt is unavailable and is not restored by this review. [E02, E11, E20]

For L5, a legitimately applicable direct route may support a bounded source-policy observation. It cannot silently replace the original P06 premise of a late gap after clean phases. If that original premise is the selected claim, the predecessor clean-phase and actual audit-entry evidence must exist. Any claim of repair, focused verification or return to AUDIT_START against the resulting exact candidate requires the actual authorized work and receiving evidence. A next-action answer establishes none of those effects. [E12–E13, E20]

The source-policy and model-policy layers do not discharge the separately scoped host-session binding, native callback, turn-exit, required cognition/accepted JOIN, or actual native transition obligations. The owner comments retain those distinctions and do not introduce an all-native-work barrier to this advisory preparation. In particular, comment 5638868695 lines 27 and 50–62 preserves independent preparation, exact scoped cognition/consumption and native receipts without appointing this review an acceptance owner. [E21]

## 7. Smallest useful next observation

No model dispatch is currently executable from the frozen preparation as an admitted original comparison. The first missing discriminator is the concrete task/predicate/owner-stage family, not another source-integrity test.

The smallest useful continuation is a new, bounded successor record made by the actual authorized owner:

1. **Select one genuine task and one existing authoritative predicate.** Name the exact task, source command/check component, subject binding, expected relation, failure and authorized observation route. A currentness or exact-evidence identity check is a plausible candidate only if its actual native source proves the same decisive rule applies at all four selected checkpoints. Do not write a replacement transition engine or umbrella predicate merely to make four labels match.

2. **Bind the four real checkpoints before claiming the family.** Retrieve sufficient existing evidence where it genuinely applies, or prospectively obtain fresh authorized observations. Preserve L1's pending dispatch, L2's real mismatch and currentness limits, L3's applicable baseline/regression, and L5's actual clean-prior/final-audit premise. Different occurrence IDs are permissible; different failed predicates are not. A fresh family avoids any unnecessary dependency on one historical L3 fixture ID.

3. **Declare the required comparison cells and claim layers.** Include the canonical four-owner discriminator, the intended independent edge-ablation control(s), and the original post-L3-only negative at the required non-phase owners. The existing three variants can supply their respective single-edge source arms; they do not together become one post-L3-only source population by relabeling. Reuse already sufficient controls at their actual scope. This review does not impose a new fixed model-call quota or repeat completed observations.

4. **Freeze the concrete oracle and neutral delivered populations.** Resolve the admission-refusal versus behavioral-refusal distinction, entry versus return attribution, unaffected evidence treatment, L2/L5 confounds, all required model controls, actual source load route and complete capture method. Keep evaluator-only materials out of each admitted consumer's mission and observed input population.

5. **Run only the smallest admissible first pair.** If a genuine L1 checkpoint and the full prospective family design are available first, one canonical/L1-variant matched pair is a reasonable next bounded observation. Its identical task/witness/configuration/authority inputs can be reused within that pair with the reuse labeled. It establishes only its supported cell, not all N06. If L2 or L5 premises are absent, leave those dependent cells unexecuted rather than manufacture them. Preserve every first return, including canonical failure or mutant survival.

6. **Receive and decide at the actual owner.** Evaluate the declared components against full raw observations, retain unresolved capture/currentness/native fields, and record the receiver's actual disposition. Perform correction/return work only where separately authorized and needed for the selected claim. Obtain any original acceptance through its own owner; this review and a future actor completion do not grant it.

Steps 1–4 require no replay of the old source verifier and no broad ancestor test suite. They are concrete evidence selection and preparation. I cannot provide an honest exact command argv, live task ID, actor model/configuration, L2 receipt, or L5 checkpoint now because none is bound in the reviewed input. Those are the specific unresolved values, not placeholders to be filled by prediction.

## 8. Findings and stopping condition

| ID | Scope | Disposition | Finding |
|---|---|---|---|
| R01 | Recovery truthfulness | PASS | New inventory and historical observations are distinguished; old full seal/timed receipt remain unavailable. |
| R02 | Three source variants | PASS | Exact current hashes/deltas support a coherent owner-scoped candidate; no behavioral kill or absolute minimum-byte claim follows. |
| R03 | Concrete oracle/attribution | GAP-REVISE | Bind observable control behavior, semantic versus admission refusal, and entry versus return failure before observations. |
| R04 | Original family coverage | GAP-REVISE | Bind same predicate at all four owners and required post-L3-only control, using genuine fresh or supported retained evidence. |
| R05 | Final delivery and capture | GAP-REVISE | Real task neutrality, complete selected inputs/reads, required model/configuration and full capture are unbound. |
| R06 | Present original-case scoring | BLOCKED | Actual task, source route, predicate, commands, L2/L5 premises, actors and receiving are absent; no original award is supported. |
| R07 | Original predicate/authority ceiling | PASS | Requirements remain unchanged; no mandatory historical L3 ID, universal native gate, or acceptance transfer is justified. |

No source revision is demanded by the present evidence. The appropriate next state is a reviewed source preparation available for an actual owner's bounded successor work, with operational readiness and original-case acceptance still open. Stop this review after retaining its exact artifacts and actual terminal return. A later re-review is warranted by a filled concrete successor, changed relevant source or an observed contradiction, not by an unchanged reminder.

REVIEW_COMPLETE_SOURCE_ONLY
