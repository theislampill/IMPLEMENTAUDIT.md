#!/usr/bin/env python3
"""One-shot ordinary source materialization. No model or lifecycle operations."""
import difflib
import hashlib
import json
import subprocess
import tarfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b')
RECOVERED = Path('/workspace/scratch/2678f1e431c3/recovered-interrupt-source-after-workspace-loss-20261119/recovered-bytes')
REVIEW = Path('/workspace/scratch/2678f1e431c3/dg17-interrupt-variants-independent-review-20261119')
ORIGINAL = Path('/workspace/scratch/2678f1e431c3/workspace-loss-recovery-20261119/original-a297-policy')
COMMIT = 'a297957be11feb494c0ec467235794a1e0c54751'
TREE = 'b08dc4ecf4028beeedb579a312eccae23cb5d863'
ARCHIVE = REPO / 'handoff/pro-executor-results-20261115/continuing-execution-20261116/evidence.tar.gz'
ARCHIVE_SHA = '7d59b34c0a859ec81dfc78b2b7ba870aae7ed860136bb9d8b415065348ca83fb'
PROTOCOL = 'skills/implementaudit/templates/PROTOCOL.md'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def put(path, value):
    p = ROOT / path
    if p.exists():
        raise RuntimeError(f'refusing overwrite: {path}')
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(value if isinstance(value, bytes) else value.encode())

def dump(path, value):
    put(path, json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def git(*argv):
    p = subprocess.run(['git', *argv], cwd=REPO, capture_output=True, check=False)
    records.append({'argv': ['git', *argv], 'cwd': str(REPO), 'exit_code': p.returncode,
                    'stdout_bytes': len(p.stdout), 'stdout_sha256': sha(p.stdout),
                    'stderr': p.stderr.decode('utf-8'), 'stderr_bytes': len(p.stderr)})
    if p.returncode:
        raise RuntimeError(f'Git read failed: {argv!r}')
    return p.stdout

records = []
started = datetime.now(timezone.utc).isoformat()
if (ROOT / 'source_receiving.json').exists():
    raise SystemExit('Source preparation already exists; no overwrite or replay.')
actual_tree = git('rev-parse', COMMIT + '^{tree}').decode().strip()
assert actual_tree == TREE
paths = ['skills/implementaudit', 'skills/audit-andon', 'skills/audit-assess',
         'skills/audit-implement', 'skills/audit-state']
raw = git('ls-tree', '-r', '-z', COMMIT, *paths)
base = {}
source_index = []
for row in raw.split(b'\0'):
    if not row:
        continue
    meta, name = row.decode().split('\t')
    mode, kind, blob = meta.split()
    assert kind == 'blob' and mode in {'100644', '100755'}
    b = git('cat-file', 'blob', blob)
    assert hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest() == blob
    base[name] = b
    source_index.append({'path': name, 'git_mode': mode, 'git_blob': blob,
                         'bytes': len(b), 'sha256': sha(b)})
assert len(base) == 70
assert sha(base[PROTOCOL]) == '24b5079e1cacdbb8d195d94d48e82f5683e915424aaf3fb8514a282dd3396c5c'
put('provenance/policy-tree.raw', raw)
dump('provenance/ORIGINAL_POLICY_INDEX.json', source_index)
put('provenance/APPLICABLE_REPO_AGENTS.md', (REPO / 'AGENTS.md').read_bytes())

old = 'L4 may interrupt planning (L1), continuity/re-entry (L2), phase execution (L3),\nor final audit (L5).'
new = ('L4 is callable only after a failure during phase execution (L3).\n'
       'Planning (L1), continuity/re-entry (L2), and final audit (L5) are excluded\n'
       'from L4 interruption. This exclusion governs all Andon referrals in this\n'
       'policy at those controls; non-propagation, witness preservation, currentness\n'
       'and nonclosure duties remain in force.')
removed_rows = [
    '| L1 planning | Recompute the affected owner, dependency, authority and acceptance decisions under planning-depth/plan-lifecycle before dispatch. |\n',
    '| L2 continuity | Re-establish the exact controller/claim/receipt/currentness through continuity before ordinary execution. |\n',
    '| L5 final audit | Complete the bounded audit-fix obligations and return to AUDIT_START against the resulting exact candidate. |\n',
]
original_text = base[PROTOCOL].decode()
assert original_text.count(old) == 1
post = original_text.replace(old, new)
operations = []
for before, after in [(old, new), *[(r, '') for r in removed_rows]]:
    assert original_text.count(before) == 1
    start = base[PROTOCOL].index(before.encode())
    operations.append({'path': PROTOCOL, 'base_byte_start': start,
                       'base_byte_end_exclusive': start + len(before.encode()),
                       'old': before, 'new': after,
                       'old_sha256': sha(before.encode()), 'new_sha256': sha(after.encode())})
for row in removed_rows:
    post = post.replace(row, '')
restored = base[PROTOCOL]
for op in sorted(operations, key=lambda v: v['base_byte_start'], reverse=True):
    restored = (restored[:op['base_byte_start']] + op['new'].encode()
                + restored[op['base_byte_end_exclusive']:])
assert restored == post.encode()
diff = ''.join(difflib.unified_diff(original_text.splitlines(True), post.splitlines(True),
                                  fromfile='baseline/' + PROTOCOL,
                                  tofile='post-l3-only/' + PROTOCOL))
put('evaluator/diffs/POST_L3_ONLY.patch', diff)
dump('evaluator/POST_L3_MUTATION.json', {
    'schema': 'dg17.post-l3-only-source-control.v1', 'base_commit': COMMIT,
    'base_protocol_sha256': sha(base[PROTOCOL]), 'variant_protocol_sha256': sha(post.encode()),
    'changed_files': [PROTOCOL], 'operations': operations,
    'diff_sha256': sha(diff.encode()),
    'unaffected_bytes': 'Reconstructed exactly from the original outside these four replacement spans.',
    'independent_semantic_disposition': None, 'execution': 'UNEXECUTED',
    'minimality': 'One governing eligibility exception plus the three otherwise unreachable return rows. No wrapper and no original acceptance edits.'})

populations = {
    'q4c8': {'role': 'canonical', 'old_population': 'p7c3', 'protocol': base[PROTOCOL]},
    'm6b2': {'role': 'exclude-L1', 'old_population': 'p2a9', 'sha': 'f10ab608a5ac508f66a17e33b5d701146072716f0b6d8945ea09296cc7cd8a8f'},
    'f8d1': {'role': 'exclude-L2', 'old_population': 'p6d1', 'sha': '9cd92215b653c61b3b82aac90c876ff61d8be98caba507516988775dde39b67a'},
    'j3a7': {'role': 'exclude-L5', 'old_population': 'p4e8', 'sha': 'e755bf64654c29ef036337e957bbc1f9ebc8374d8881b58a0e560a7d9d11b26d'},
    'w5e9': {'role': 'post-L3-only', 'old_population': None, 'protocol': post.encode()},
}
assignment = []
for code, p in populations.items():
    if 'protocol' not in p:
        p['protocol'] = (RECOVERED / 'actor/policies' / p['old_population'] / 'templates/PROTOCOL.md').read_bytes()
        assert sha(p['protocol']) == p['sha']
    inventory = []
    for name, b in sorted(base.items()):
        selected = p['protocol'] if name == PROTOCOL else b
        rel = 'policy/' + name
        put('populations/' + code + '/' + rel, selected)
        inventory.append({'path': rel, 'bytes': len(selected), 'sha256': sha(selected)})
    index = {'schema': 'selected.policy-source-population.v1',
             'entrypoint': 'policy/skills/implementaudit/SKILL.md',
             'source_only': True, 'files': inventory,
             'reading_rule': 'Read applicable policy sources within this selected population. These files do not grant controller or mutation authority.'}
    dump('populations/' + code + '/POLICY_CONTENTS.json', index)
    assignment.append({'population': code, 'evaluator_only_role': p['role'],
                       'protocol_sha256': sha(p['protocol']), 'source_files': len(inventory),
                       'old_population': p['old_population']})
dump('evaluator/POLICY_ASSIGNMENTS.json', assignment)

archive_bytes = ARCHIVE.read_bytes()
assert sha(archive_bytes) == ARCHIVE_SHA
prefix = 'dg17/episode_06/subject/'
subject_index = []
with tarfile.open(ARCHIVE, 'r:gz') as t:
    members = [m for m in t.getmembers() if m.name.startswith(prefix)]
    for m in members:
        if m.isdir():
            continue
        assert m.isfile() and not m.issym() and not m.islnk()
        rel = m.name[len(prefix):]
        assert rel and not Path(rel).is_absolute() and '..' not in Path(rel).parts
        b = t.extractfile(m).read()
        put('task/subject/' + rel, b)
        subject_index.append({'path': rel, 'archive_member': m.name,
                              'bytes': len(b), 'sha256': sha(b)})
assert len(subject_index) == 16
assert len({x['path'] for x in subject_index}) == 16
subject_index.sort(key=lambda x: x['path'])
dump('task/SUBJECT_MANIFEST.json', {'schema': 'report-task-source.v1',
                                  'archive_sha256': ARCHIVE_SHA, 'files': subject_index})
assert sha((ROOT / 'task/subject/verify_report.py').read_bytes()) == '38750be0a1aa08e14071afbfabf3b887b74287829090447ad14e15bcc5299726'

for name in ['REVIEW_REPORT.md', 'RESULT.json', 'EVIDENCE_INDEX.json', 'REVIEW_ARTIFACT_RECEIPT.json']:
    put('review-input/' + name, (REVIEW / name).read_bytes())
assert sha((ROOT / 'review-input/REVIEW_REPORT.md').read_bytes()) == '201310e6bcab270c932e0912969832559564605c95b6d3a8a0cce3a21527e139'
for p in sorted(ORIGINAL.glob('ISSUE211_*.md')):
    put('original-contract/' + p.name, p.read_bytes())
assert len(list((ROOT / 'original-contract').glob('ISSUE211_COMMENT_*.md'))) == 4
assert sha((ROOT / 'original-contract/ISSUE211_BODY.md').read_bytes()) == 'ca62f4899a45544549f623a0312c16121bb99f432ccb87a87b7361974ceb94c4'
for name in ['mapping/CLAUSE_MAP.md', 'mapping/CLAUSE_MAP.json', 'mapping/REQUIREMENT_MAP.json',
             'mutation/MUTATIONS.json', 'diffs/L1.patch', 'diffs/L2.patch', 'diffs/L5.patch']:
    put('predecessor/' + name, (RECOVERED / name).read_bytes())

dump('source_receiving.json', {
    'schema': 'dg17.successor-source-receiving.v1', 'started_at': started,
    'completed_at': datetime.now(timezone.utc).isoformat(),
    'scope': 'Actual ordinary source preparation only; no actor/controller/provider write or acceptance.',
    'git_commit': COMMIT, 'git_tree': actual_tree, 'policy_source_count': 70,
    'population_count': len(populations), 'subject_file_count': len(subject_index),
    'archive_path': str(ARCHIVE), 'archive_bytes': len(archive_bytes), 'archive_sha256': ARCHIVE_SHA,
    'git_read_receipts': records, 'source_check_executed_here': False,
    'unexecuted': ['models', 'owner-checkpoints', 'controller', 'post-L3-control-behavior', 'original-acceptance']})
print(json.dumps({'status': 'SOURCE_PREPARED_ONLY', 'policy_sources': 70,
                  'populations': len(populations), 'subject_files': len(subject_index),
                  'post_l3_protocol_bytes': len(post.encode()),
                  'post_l3_protocol_sha256': sha(post.encode()),
                  'source_receiving_sha256': sha((ROOT / 'source_receiving.json').read_bytes())}))
