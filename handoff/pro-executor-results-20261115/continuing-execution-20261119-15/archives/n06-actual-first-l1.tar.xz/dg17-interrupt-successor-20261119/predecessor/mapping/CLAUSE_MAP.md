# Source-clause map

Every range below refers to the byte-exact baseline. JSON also binds each span by SHA-256. The only edited file in each variant is `templates/PROTOCOL.md`. The owner-scoped exception explicitly qualifies general Andon referrals; it does not relax independent safety, currentness, witness, or nonclosure duties. This semantic interpretation is a reviewable proposal, not a behavioral result.

| ID | Original source and lines | Clause | Effect or preservation |
|---|---|---|---|
| C01 | `SKILL.md:23–35` | General gate-to-Andon/handoff referral | Selected-owner L4 invocation is scoped by the explicit exception; gate, stop, evidence and other owners remain. |
| C02 | `SKILL.md:124–159` | Actual child selection and authority | Unchanged. No removed edge creates a child route; cheap deterministic handling stays child-free. |
| C03 | `SKILL.md:253–274` | Planning progressive-source and stage admission | Unchanged. Actual selected source and independent review remain required where triggered. |
| C04 | `SKILL.md:277–306` | Continuity ordering and final-audit structural-failure referral | Continuity/refusal and closure guards remain. Final L4 Andon invocation is scoped only in the L5 variant. |
| C05 | `references/lean-operating-discipline.md:15–17` | Jidoka chain and visible Andon signal | General referrals cannot restore the excluded L4 edge; non-propagation and truthful witness duties remain. |
| C06 | `references/lean-operating-discipline.md:66–104` | Complete producer capture and evidence-bounded escalation | Unchanged capture/exit-status duties; eligible escalation still needs evidence, not a count. |
| C07 | `templates/PROTOCOL.md:63–77` | Plan quality and revise/block referral | L1 eligibility exception scopes the general Andon referral; scope and review gates remain. |
| C08 | `templates/PROTOCOL.md:105–124` | Canonical read and native receiving rules | Unchanged. Text, old receipt or snapshot cannot substitute for actual currentness/native acceptance. |
| C09 | `templates/PROTOCOL.md:207–224` | Evidence anchor mismatch and unaffected evidence | Identity mismatch may supply the same predicate only with actual task admission and a real command witness. |
| C10 | `templates/PROTOCOL.md:322–333` | Resume corruption triggers probe | L2 exception scopes the probe referral; invalid state still cannot be resumed through. |
| C11 | `templates/PROTOCOL.md:706–730` | Mandatory failure and ordered Jidoka chain | One-owner exception controls L4 eligibility; remaining duties and owners are preserved. |
| C12 | `templates/PROTOCOL.md:772–779` | Any-abnormality protocol referral | Explicit owner exclusion prevents this broad referral from silently restoring that one L4 edge. |
| C13 | `templates/PROTOCOL.md:806–827` | Interrupt eligibility, preservation and exact returns | Only the eligibility paragraph and one return row change. The interrupted-owner/witness text is byte-identical. |
| C14 | `templates/PROTOCOL.md:829–885` | Return predicates and probe steps | Return only after deciding check passes. No invented phase or skipped prerequisite; disjoint evidence survives. |
| C15 | `templates/PROTOCOL.md:889–955` | Escalation and return duties | Same eligible-owner return rule; no numerical cap and no child/phase result grants closure. |
| C16 | `templates/PROTOCOL.md:958–978` | Genuine handoff and independent work | Unchanged blocking conditions; no global abandonment or numerical cap. |
| C17 | `templates/PROTOCOL.md:980–1013` | Final audit admission and phase completeness | Actual completed-phase/checkpoint evidence is required for L5; this packet creates none. |
| C18 | `templates/PROTOCOL.md:1017–1030` | Final mandatory rerun and Andon before classification | L5 exception scopes the general referral only. Actual command result, failure and nonclosure remain mandatory. |
| C19 | `templates/PROTOCOL.md:1061–1079` | Audit-fix and exact-candidate re-audit | Unchanged L5 audit-fix duties may permit mutant survival; source names cannot decide behavior. |
| C20 | `templates/PROTOCOL.md:1123–1159` | Closure conditions and qualification draws | Unchanged. No blocking-gap closure, layer promotion or outcome-selected replay. |
| C21 | `references/transcript-contract.md:95–118` | Ordered Andon and classed row | Exception scopes L4 eligibility only; no new class/state. |
| C22 | `references/transcript-contract.md:185–238` | Ledger substrate and first-abnormality probe/escalation | General referrals are scoped. Phase-resume shorthand applies to phase cases; PROTOCOL supplies exact owner returns. Genuine baseline conflicts remain canonical failure, not repaired here. |
| C23 | `references/transcript-contract.md:264–285` | Boundary receipt before effects | Unchanged. Root historical currentness is not actor admission. |
| C24 | `references/transcript-contract.md:390–456` | Load/return/accept/JOIN distinctions | Unchanged. Labels and prose are not native transitions or accepted occurrence consumption. |
| C25 | `references/planning-depth.md:150–196` | Verifier selection, revisability and admission | Unchanged. Live consumer/consequence and unresolved possibilities are required; earlier PASS gives no authority. |
| C26 | `references/plan-lifecycle.md:7–46` | Self-contained live-source plan; HOLD for placeholders | Operational nulls keep this preparation conditional, never executor-ready. |
| C27 | `references/plan-lifecycle.md:157–201` | Independent review before readiness | Author does not perform the independent gate; Root must obtain and intake a distinct result. |
| C28 | `references/plan-lifecycle.md:235–292` | Preflight, capability and receiving completeness | Unchanged. Bind actual task, authority, inputs and receiving evidence before applicable execution. |
| C29 | `references/plan-lifecycle.md:532–602` | Complete planning stages | Unchanged. No manufactured phases or ceremonial stage claims. |
| C30 | `references/continuity.md:6–53` | Initialization and interrupted preparation | Unchanged. Data copies/unactivated preparation are not an admitted L2 run. |
| C31 | `references/continuity.md:55–138` | Boundary, controller, ordered reads and receipt | Unchanged. Genuine owner-stage evidence required; no fake compaction/currentness. |
| C32 | `references/continuity.md:284–309` | Completed-boundary obligation | Unchanged separate mandatory cognition when triggered; no generic substitute or fabricated JOIN. |
