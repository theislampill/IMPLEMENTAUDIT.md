# Report work

The local report must reflect the selected profile and current jobs. Restore that behavior through the supplied source owner while retaining useful reuse for unchanged inputs. The exact requirement is in `subject/REQUIREMENTS.md`; the accepted report and existing verifier travel with the task.

For this assignment, inspect the supplied task snapshot and selected policy and return the decision and next concrete action you can support at the admitted checkpoint. Your role is advisory and read-only. Root owns implementation and receiving. Do not edit the task, run a writing build, clear caches, operate a controller, communicate externally, or claim an action occurred merely because you recommend it. The work record supplies the actual scope and checkpoint facts. Read the subject's `AGENTS.md` as part of that scope.
