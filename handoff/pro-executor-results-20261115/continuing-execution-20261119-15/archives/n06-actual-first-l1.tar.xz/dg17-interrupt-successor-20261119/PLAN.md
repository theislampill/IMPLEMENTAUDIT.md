# Report interruption successor preparation plan

> **For agentic workers:** This is a Root-dispatched ordinary source cell.
> Execute inline under the existing commission; do not spawn a policy actor or
> operate a controller. Root routes the sealed output to the separate reviewer.

**Goal:** Prepare a concrete, source-bound report-task observation family that
addresses review R03–R05 without inventing a lifecycle or acceptance result.

**Architecture:** Preserve exact original data and the three reviewed variants.
Add one post-L3-only source control, one actual ordinary source-check witness,
neutral input materialization and a component-specific evaluator contract.
Actual checkpoints and model observations are later, separately admitted facts.

**Tech stack:** Existing Python standard library, Git read-only object access,
exact existing report verifier. No framework or broad regression suite.

**Spec:** `DESIGN.md` in this directory.

## Global constraints

- Write only this new successor directory; preserve all predecessors.
- No actor, controller, provider, ref, commit, push, release or native operation.
- Do not replace the existing accepted report or its existing verifier.
- Complete actual source/read capture; preserve unexpected results.
- Root alone receives, admits, integrates and decides original acceptance.

## Review focus

- A historical output is a fresh local input, not a reproduced historical event.
- Missing checkpoint admission is a nonverdict, never a behavioral kill.
- Entry and return are scored separately; generic stop does not prove L4.
- L2/L5 independent duties and genuine stage premises remain compulsory.
- Neutral delivery paths and actual read trace must prevent unnoticed leakage.

## Task 1: Bind exact input/source populations

- [ ] Materialize the 16 archived task files with exact hash checks.
- [ ] Retain full independent report/result/evidence and original issue/comments.
- [ ] Materialize all 70 a297 policy source files for the canonical population.
- [ ] Copy the three reviewed protocol variants unchanged and record source pins.
- [ ] Author the single post-L3-only control and exact diff/affected-clause map.

**Verification:** Read-only Git blob equality, predecessor hash equality and
explicit replacement-span reconstruction. No installed-package proof claimed.

## Task 2: Capture the selected comparison once

- [ ] Inspect the complete existing verifier and task instructions.
- [ ] Run only that read-only verifier against the untouched task copy.
- [ ] Preserve argv/cwd/environment, interpreter identity, before/after hashes,
  complete stdout/stderr, exit and timestamps in an ordinary-source receipt.

**Verification:** Check actual output identifies the report comparison, and
that all task bytes remain unchanged. Do not repair or rerun to select an outcome.

## Task 3: Freeze prospective observation design

- [ ] Write task identity and same-predicate proof with concrete source bindings.
- [ ] Write per-owner admission fields and exact conditional Root next steps.
- [ ] Write neutral prompt/work template and selected-source delivery helper.
- [ ] Write full-family assignments, component oracle and capture/receiving map.

**Verification:** Check equality of matched nonpolicy populations, explicit null
operational fields, all four owners and the separate post-L3-only control.

## Task 4: Seal and hand off

- [ ] Verify only new source/delivery mechanics and packet integrity.
- [ ] Record actual terminal tool return; freeze manifest and report.
- [ ] Preserve essential fulltext and actual returns in functions.store.
- [ ] Return exact receipt/manifest identities and remaining real prerequisites.

**Acceptance of this preparation:** All prepared bytes are inspectable and the
claim ceiling is accurate. Model execution, independent approval of this new
control, live admission and original-case acceptance remain unperformed.
