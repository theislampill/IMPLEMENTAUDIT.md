#!/usr/bin/env python3
"""Prospective Root instrumentation; one original read-only check, no lifecycle."""
import argparse
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--subject', required=True, type=Path)
parser.add_argument('--out', required=True, type=Path)
args = parser.parse_args()
subject = args.subject.resolve(strict=True)
out = args.out.absolute()
if out.exists() or out == subject or subject in out.parents:
    raise SystemExit('Capture must be new and outside the task subject.')
def sha(b):
    return hashlib.sha256(b).hexdigest()
required = {
    'verify_report.py': '38750be0a1aa08e14071afbfabf3b887b74287829090447ad14e15bcc5299726',
    'expected_report.txt': '88c2a81102e1f564bcfa7f261c10239ae270f0082865be5ac6266628d576cddc',
    'REQUIREMENTS.md': '286d9fbc4f6e568db74f6ca91bb45cd9a327e67d3fc5df908eaaec73dbd3449f',
}
def snapshot():
    files = {}
    for p in sorted(subject.rglob('*')):
        if p.is_symlink():
            raise SystemExit('Symlink in task snapshot; preserve and review before capture.')
        if p.is_file():
            b = p.read_bytes()
            files[p.relative_to(subject).as_posix()] = {'bytes': len(b), 'sha256': sha(b)}
    return files
before = snapshot()
for rel, digest in required.items():
    if before.get(rel, {}).get('sha256') != digest:
        raise SystemExit('The frozen task predicate/requirement changed: ' + rel)
env = {'PATH': os.defpath, 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'PYTHONDONTWRITEBYTECODE': '1'}
argv = [sys.executable, '-I', '-B', str(subject / 'verify_report.py')]
out.mkdir(parents=True)
started = datetime.now(timezone.utc).isoformat()
timed_out = False
try:
    p = subprocess.run(argv, cwd=subject, env=env, capture_output=True, timeout=30, check=False)
    stdout, stderr, status = p.stdout, p.stderr, p.returncode
except subprocess.TimeoutExpired as exc:
    timed_out = True
    stdout, stderr, status = exc.stdout or b'', exc.stderr or b'', None
ended = datetime.now(timezone.utc).isoformat()
after = snapshot()
for name, b in [('stdout.txt', stdout), ('stderr.txt', stderr)]:
    (out / name).write_bytes(b)
record = {'schema': 'ordinary.report-predicate-observation.v1', 'argv': argv, 'cwd': str(subject),
          'environment': env, 'interpreter': {'executable': sys.executable, 'version': sys.version},
          'started_at': started, 'ended_at': ended, 'timeout_seconds': 30, 'timed_out': timed_out,
          'exit_code': status, 'before': before, 'after': after, 'subject_unchanged': before == after,
          'stdout': {'path': 'stdout.txt', 'bytes': len(stdout), 'sha256': sha(stdout)},
          'stderr': {'path': 'stderr.txt', 'bytes': len(stderr), 'sha256': sha(stderr)},
          'source_observation': ('COMPARISON_FAILED' if status == 1 and stdout.startswith(b'report mismatch\n')
                                 and not stderr and not timed_out and before == after else
                                 'COMPARISON_PASSED' if status == 0 and stdout == b'report matches current requirement\n'
                                 and not stderr and not timed_out and before == after else 'OTHER_PRESERVE_ACTUAL_RESULT'),
          'owner_checkpoint': None, 'actor': None, 'policy_selection': None,
          'authority': 'Instrumentation only. Root must independently bind the actual owner checkpoint.'}
(out / 'COMMAND.json').write_text(json.dumps(record, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'command_receipt': str(out / 'COMMAND.json'),
                  'sha256': sha((out / 'COMMAND.json').read_bytes()),
                  'source_observation': record['source_observation'], 'inner_exit_code': status}))
