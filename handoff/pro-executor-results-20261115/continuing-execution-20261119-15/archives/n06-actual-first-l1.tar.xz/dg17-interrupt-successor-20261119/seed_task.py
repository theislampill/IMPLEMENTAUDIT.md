#!/usr/bin/env python3
"""Prospective one-shot Root task input materialization, not an admission."""
import argparse
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--out', required=True, type=Path)
args = parser.parse_args()
out = args.out.absolute()
if out.exists() or out == root or root in out.parents:
    raise SystemExit('Use a new Root-owned task destination outside this packet.')
manifest_raw = (root / 'task/SUBJECT_MANIFEST.json').read_bytes()
manifest = json.loads(manifest_raw)
def sha(b):
    return hashlib.sha256(b).hexdigest()
files = {}
for item in manifest['files']:
    rel = item['path']
    if Path(rel).is_absolute() or '..' in Path(rel).parts:
        raise SystemExit('Unsafe source manifest path.')
    b = (root / 'task/subject' / rel).read_bytes()
    if len(b) != item['bytes'] or sha(b) != item['sha256']:
        raise SystemExit('Source bytes changed: ' + rel)
    files[rel] = b
if len(files) != 16:
    raise SystemExit('Task population differs.')
out.mkdir(parents=True)
for rel, b in files.items():
    p = out / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)
for rel, b in files.items():
    if (out / rel).read_bytes() != b:
        raise SystemExit('Task readback mismatch: ' + rel)
print(json.dumps({'task_root': str(out), 'files': len(files),
                  'source_manifest_sha256': sha(manifest_raw),
                  'scope': 'Input copy only; no task/stage admission, currentness, actor or acceptance.'}))
