#!/usr/bin/env python3
"""One-shot new packet integrity check. Not a policy/model acceptance engine."""
import difflib
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXCLUDED = {'MANIFEST.json', 'VERIFICATION_RECEIPT.json', 'TERMINAL_TOOL_RETURN.json', 'SEAL.json'}
if any((ROOT / name).exists() for name in EXCLUDED):
    raise SystemExit('A verification/seal already exists; no replay or overwrite.')
started = datetime.now(timezone.utc).isoformat()
checks = []
def sha(b):
    return hashlib.sha256(b).hexdigest()
def read(name):
    return (ROOT / name).read_bytes()
def load(name):
    return json.loads(read(name))
def check(ok, label):
    if not ok:
        raise AssertionError(label)
    checks.append(label)
def write_json(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

index = load('provenance/ORIGINAL_POLICY_INDEX.json')
check(len(index) == 70 and len({x['path'] for x in index}) == 70, 'Complete distinct 70-file original source index')
assignments = load('evaluator/POLICY_ASSIGNMENTS.json')
check(len(assignments) == 5, 'Five selected-source populations')
protocol = 'skills/implementaudit/templates/PROTOCOL.md'
canonical = read('populations/q4c8/policy/' + protocol)
expected_protocols = {
    'q4c8': '24b5079e1cacdbb8d195d94d48e82f5683e915424aaf3fb8514a282dd3396c5c',
    'm6b2': 'f10ab608a5ac508f66a17e33b5d701146072716f0b6d8945ea09296cc7cd8a8f',
    'f8d1': '9cd92215b653c61b3b82aac90c876ff61d8be98caba507516988775dde39b67a',
    'j3a7': 'e755bf64654c29ef036337e957bbc1f9ebc8374d8881b58a0e560a7d9d11b26d',
    'w5e9': '64d667256455db3b7a3b3e5ab44de3b0256cdc9cbefadb82cbca2cb80358c56e',
}
for assignment in assignments:
    code = assignment['population']
    check(sha(read('populations/' + code + '/policy/' + protocol)) == expected_protocols[code],
          'Exact selected protocol: ' + code)
    supplied = load('populations/' + code + '/POLICY_CONTENTS.json')
    check(set(supplied) == {'schema', 'entrypoint', 'source_only', 'files', 'reading_rule'},
          'Neutral policy-index field population: ' + code)
    check(len(supplied['files']) == 70, 'Complete policy-index population: ' + code)
    actual_files = {p.relative_to(ROOT / 'populations' / code).as_posix()
                    for p in (ROOT / 'populations' / code).rglob('*') if p.is_file()}
    check(actual_files == {'POLICY_CONTENTS.json'} | {x['path'] for x in supplied['files']},
          'No undeclared selected-policy files: ' + code)
    for item in supplied['files']:
        b = read('populations/' + code + '/' + item['path'])
        if len(b) != item['bytes'] or sha(b) != item['sha256']:
            raise AssertionError('Policy inventory mismatch: ' + code + '/' + item['path'])
    for item in index:
        b = read('populations/' + code + '/policy/' + item['path'])
        if item['path'] != protocol or code == 'q4c8':
            if len(b) != item['bytes'] or sha(b) != item['sha256']:
                raise AssertionError('Unaffected source changed: ' + code + '/' + item['path'])
            blob = hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
            if blob != item['git_blob']:
                raise AssertionError('Original Git blob differs: ' + item['path'])
    checks.append('All unaffected source bytes and original Git blob identities preserved: ' + code)

mutation = load('evaluator/POST_L3_MUTATION.json')
rebuilt = canonical
for op in sorted(mutation['operations'], key=lambda x: x['base_byte_start'], reverse=True):
    a, b = op['base_byte_start'], op['base_byte_end_exclusive']
    check(canonical[a:b] == op['old'].encode(), 'Post-L3 exact original replacement span ' + str(a))
    rebuilt = rebuilt[:a] + op['new'].encode() + rebuilt[b:]
post = read('populations/w5e9/policy/' + protocol)
check(rebuilt == post and len(mutation['operations']) == 4, 'Post-L3 control reconstructed from exactly four declared spans')
diff = ''.join(difflib.unified_diff(canonical.decode().splitlines(True), post.decode().splitlines(True),
                                  fromfile='baseline/' + protocol, tofile='post-l3-only/' + protocol)).encode()
check(diff == read('evaluator/diffs/POST_L3_ONLY.patch'), 'Exact new control diff')
check(mutation['independent_semantic_disposition'] is None, 'New control semantic approval remains unprovided')

source = load('task/SUBJECT_MANIFEST.json')
expected = {x['path']: {'bytes': x['bytes'], 'sha256': x['sha256']} for x in source['files']}
actual = {p.relative_to(ROOT / 'task/subject').as_posix(): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
          for p in (ROOT / 'task/subject').rglob('*') if p.is_file()}
check(len(actual) == 16 and actual == expected, 'Exact unchanged 16-file report task population')
command_raw = read('observations/source-check-01/COMMAND.json')
command = json.loads(command_raw)
check(sha(command_raw) == 'c4b96ee3afa62c46bb69ade18724f7cd85f4ff43f23b9da53e6532dc4a0cc350', 'Actual source-check receipt hash retained')
check(command['before'] == expected and command['after'] == expected and command['subject_unchanged'],
      'Actual source check preserved all task bytes')
check(command['source_observation'] == 'COMPARISON_FAILED' and command['exit_code'] == 1 and not command['timed_out'],
      'Actual original comparison failure retained without rerun')
for name in ['stdout', 'stderr']:
    b = read('observations/source-check-01/' + name + '.txt')
    check(len(b) == command[name]['bytes'] and sha(b) == command[name]['sha256'], 'Actual complete ' + name + ' retained')
check(command['stdout']['bytes'] == 266 and command['stderr']['bytes'] == 0, 'Actual original stream sizes')
check(command['owner_checkpoint'] is None and command['actor'] is None, 'Source check not promoted to owner/actor evidence')

known = {
    'review-input/REVIEW_REPORT.md': '201310e6bcab270c932e0912969832559564605c95b6d3a8a0cce3a21527e139',
    'review-input/RESULT.json': 'cfca9bd5e24bfe83eb32db2af7237d133a61d7ff7c9d798943f67fc45e1f0929',
    'review-input/EVIDENCE_INDEX.json': 'ff8102e99b528f8b99d6ce2ae8c99854b6bcd999083f4be14c71200ff7d9e234',
    'review-input/REVIEW_ARTIFACT_RECEIPT.json': 'e993cef24a7327f965bc8218b61726e254e7a6371eb5b53b854bb2ce526491c2',
    'original-contract/ISSUE211_BODY.md': 'ca62f4899a45544549f623a0312c16121bb99f432ccb87a87b7361974ceb94c4',
    'original-contract/ISSUE211_COMMENT_5312883966.md': '3cc85a827866836af965c03c64d814e37006e995b84c1c54a599d8cd8252a44d',
    'original-contract/ISSUE211_COMMENT_5343276081.md': '7f39828c5f76683d74531bd49c2ec9a6a2c84bc4d59e52ba8d7a07c251c8c38e',
    'original-contract/ISSUE211_COMMENT_5636805839.md': 'd49b1b839a24b103289acee1f4726231bff12fb7e1824bbff6a93df0ea60a388',
    'original-contract/ISSUE211_COMMENT_5638868695.md': '7ca42522f7fa411b5c5b376f25f0020713816dfaea2eaa5024d59343cd757082',
    'actor-inputs/PROMPT.txt': '713b3bd02eb975aaeb772e194a034f1ef13d5c9497ae4961d603b01759fdaf4a',
}
for name, digest in known.items():
    check(sha(read(name)) == digest, 'Retained exact input: ' + name)

family = load('evaluator/FAMILY.json')
check(len(family['required_cells']) == 11 and all(x['observation'] is None and x['disposition'] == 'UNEXECUTED' for x in family['required_cells']),
      'Complete declared four-owner/edge/post-L3 family remains unexecuted')
check({x['owner'] for x in family['required_cells'] if x['id'].startswith('post-l3-')} == {'L1','L2','L3','L5'},
      'Distinct post-L3-only control covers the declared four-owner comparison')
admission = load('evaluator/ADMISSION.json')
check(all(v is None for v in admission['common'].values()), 'Actual common operational/model fields remain unprovided')
check(load('actor-inputs/WORK_RECORD.template.json')['actual_checkpoint'] is None,
      'No fictitious actor-visible owner checkpoint')
check(load('evaluator/DISPATCH_SPEC.json')['actual_dispatch'] is None and not family['first_pair']['dispatch_now'],
      'No dispatch or present execution permission inferred')
check(load('evaluator/RETURN_CONTINUATION.json')['current_status'] == 'NOT_EXERCISED',
      'No fabricated successful correction/return')
for name in ['prepare_sources.py','capture_source_check.py','capture_live_predicate.py','materialize_delivery.py','seed_task.py','verify_preparation.py']:
    compile(read(name), name, 'exec')
checks.append('New ordinary helper syntax is valid; prospective helpers not executed')
for p in ROOT.rglob('*'):
    check(not p.is_symlink(), 'No symlink: ' + p.relative_to(ROOT).as_posix()) if p.is_symlink() else None
    if p.is_file() and p.suffix == '.json':
        json.loads(p.read_bytes())
checks.append('All existing packet JSON parses; no symlink files')

report = '''# Successor preparation report

## Result

**PREPARATION_INTEGRITY_VERIFIED_ONLY.** The new packet's sources, declared
replacement spans, inventories, concrete task and actual source-check witness
passed the bounded mechanical checks recorded in VERIFICATION_RECEIPT.json.
This is neither a semantic approval of the new control nor original acceptance.

The existing report verifier actually returned 1, with 266 bytes of stdout and
empty stderr, against the unchanged 16-file task copy. Its comparison is
concrete: the current report still has the earlier heading/separator, while the
accepted report requires the current profile. The full witness is retained.
No historical task lifecycle or build sequence was reconstructed.

## Review responses

| Finding | Prepared response | Present disposition |
|---|---|---|
| R03 | Component oracle separates admission, entry and return; independent L2/L5 duties remain; generic stop is insufficient; canonical failure/refusal/survival retained | Prepared for independent review; behavior unobserved |
| R04 | One exact existing report predicate/task, actual ordinary witness, full four-owner family and new post-L3-only source control; precise real-checkpoint requirements and first-pair Root recipe | Source/task bound; actual L1 admission and later owner checkpoints unprovided |
| R05 | Complete 70-file selected source populations, neutral primary/continuation prompts, exact first-pair input helper and full actual capture/receiving map | Prepared; actual deliveries/model/read/transport/receiving still unexecuted |

Canonical and the three predecessor protocol variants are byte-exact. The new
post-L3-only protocol is 73,980 bytes, SHA-256
64d667256455db3b7a3b3e5ab44de3b0256cdc9cbefadb82cbca2cb80358c56e.
The full original issue body and four owner amendments are unchanged.

## Smallest next action and limits

Root sends this sealed packet to the separate reviewer. Following that review,
Root can establish the real report task's L1 planning checkpoint and capture the
existing verifier there, then materialize the canonical/L1-excluded pair under
the exact ROOT_NEXT_ACTIONS.md recipe. This preparation has performed none of
those owner or model actions. Actual final-delivery hashes and model metadata
must be captured when they exist, not filled from expectation.

The initial pair can support entry/decision findings at its admitted layer.
Return remains NOT_EXERCISED until an actual passing deciding check. The same
existing comparison can be carried to later real task checkpoints, but L2,
L3 and L5 evidence is absent. The prospective cache stimulus is expressly
controlled input; it cannot manufacture a boundary, clean phase or legal
final-audit entry. If the source invalidation rules prevent that stage, retain
the unexecuted cell. A particular historical L3 fixture is not compulsory.

No broad tests, old predecessor integrity verifier, model consumer, controller,
native event, provider mutation, source repair, writing build or cache mutation
was executed. Complete original/native/JOIN/terminal duties remain unwaived.
The new mechanical seal does not replace the lost predecessor seal bytes.
'''
(ROOT / 'PREPARATION_REPORT.md').write_text(report)
inventory = []
for p in sorted(ROOT.rglob('*')):
    if p.is_file() and p.relative_to(ROOT).as_posix() not in EXCLUDED:
        b = p.read_bytes()
        inventory.append({'path': p.relative_to(ROOT).as_posix(), 'bytes': len(b), 'sha256': sha(b)})
manifest = {'schema': 'dg17.successor-preparation-manifest.v1',
            'scope': 'New source/prospective-observation packet only', 'files': inventory,
            'excluded_seal_metadata': sorted(EXCLUDED),
            'source_commit': 'a297957be11feb494c0ec467235794a1e0c54751',
            'source_tree': 'b08dc4ecf4028beeedb579a312eccae23cb5d863'}
write_json('MANIFEST.json', manifest)
receipt = {'schema': 'dg17.successor-preparation-verification.v1',
           'started_at': started, 'completed_at': datetime.now(timezone.utc).isoformat(),
           'status': 'PREPARATION_INTEGRITY_VERIFIED_ONLY', 'static_files': len(inventory),
           'manifest_bytes': (ROOT / 'MANIFEST.json').stat().st_size,
           'manifest_sha256': sha(read('MANIFEST.json')), 'checks': checks,
           'source_observation': {'tool': 'dafb61/0', 'inner_exit': 1, 'receipt_sha256': sha(command_raw)},
           'new_control_semantic_review': None, 'actual_owner_admission': None,
           'model_observations': None, 'original_acceptance': None,
           'not_run': ['predecessor integrity verifier', 'policy/model consumers', 'prospective delivery/seed/live-capture helpers', 'controller commands', 'writing task build', 'broad tests']}
write_json('VERIFICATION_RECEIPT.json', receipt)
print(json.dumps({'status': receipt['status'], 'static_files': len(inventory),
                  'manifest_bytes': receipt['manifest_bytes'], 'manifest_sha256': receipt['manifest_sha256'],
                  'verification_receipt_sha256': sha(read('VERIFICATION_RECEIPT.json')),
                  'recorded_check_count': len(checks), 'model_observations': 0, 'controller_operations': 0}))
