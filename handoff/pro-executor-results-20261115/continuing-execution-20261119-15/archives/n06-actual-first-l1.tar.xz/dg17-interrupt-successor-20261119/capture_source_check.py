#!/usr/bin/env python3
"""Capture the existing task comparison once. Does not operate a workflow."""
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parent
subject = root / 'task/subject'
out = root / 'observations/source-check-01'
if out.exists():
    raise SystemExit('Existing capture preserved; no replay.')
def sha(b):
    return hashlib.sha256(b).hexdigest()
def snapshot():
    return {p.relative_to(subject).as_posix(): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
            for p in sorted(subject.rglob('*')) if p.is_file()}
before = snapshot()
manifest = json.loads((root / 'task/SUBJECT_MANIFEST.json').read_text())
expected = {x['path']: {'bytes': x['bytes'], 'sha256': x['sha256']} for x in manifest['files']}
if before != expected:
    raise SystemExit('Input bytes differ from the frozen source population.')
argv = [sys.executable, '-I', '-B', str(subject / 'verify_report.py')]
env = {'PATH': os.defpath, 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'PYTHONDONTWRITEBYTECODE': '1'}
out.mkdir(parents=True)
start = datetime.now(timezone.utc).isoformat()
timed_out = False
try:
    result = subprocess.run(argv, cwd=subject, env=env, capture_output=True, timeout=30, check=False)
    stdout, stderr, status = result.stdout, result.stderr, result.returncode
except subprocess.TimeoutExpired as exc:
    timed_out = True
    stdout, stderr, status = exc.stdout or b'', exc.stderr or b'', None
end = datetime.now(timezone.utc).isoformat()
after = snapshot()
(out / 'stdout.txt').write_bytes(stdout)
(out / 'stderr.txt').write_bytes(stderr)
receipt = {
    'schema': 'ordinary.report-predicate-observation.v1',
    'scope': 'Fresh read-only source check on an exact retained task copy; not an actor or lifecycle checkpoint.',
    'argv': argv, 'cwd': str(subject), 'environment': env,
    'interpreter': {'executable': sys.executable, 'version': sys.version},
    'started_at': start, 'ended_at': end, 'timeout_seconds': 30, 'timed_out': timed_out,
    'exit_code': status,
    'stdout': {'path': 'stdout.txt', 'bytes': len(stdout), 'sha256': sha(stdout)},
    'stderr': {'path': 'stderr.txt', 'bytes': len(stderr), 'sha256': sha(stderr)},
    'before': before, 'after': after, 'subject_unchanged': before == after,
    'predicate_source': 'task/subject/verify_report.py',
    'failing_component': 'decoded output/report.txt != decoded expected_report.txt',
    'source_observation': ('COMPARISON_FAILED' if status == 1 and stdout.startswith(b'report mismatch\n')
                           and not stderr and not timed_out and before == after else 'OTHER_PRESERVE_ACTUAL_RESULT'),
    'owner_checkpoint': None, 'actor': None, 'policy_selection': None,
    'original_case_acceptance': None,
}
(out / 'COMMAND.json').write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'capture': str(out), 'inner_exit_code': status,
                  'observation': receipt['source_observation'], 'subject_unchanged': before == after,
                  'stdout_bytes': len(stdout), 'stderr_bytes': len(stderr),
                  'command_receipt_sha256': sha((out / 'COMMAND.json').read_bytes())}))
