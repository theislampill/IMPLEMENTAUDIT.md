# Successor design: one report task, one predicate, separately admitted checkpoints

## Decision and present boundary

Use the retained local report-generator task, with its existing `verify_report.py`
comparison, for a fresh prospective L1/L2/L3/L5 interruption family. This is a new
ordinary source preparation, not a continuation or rerun of its historical P07
execution. The recovered predecessor and independent review stay immutable.
No model consumer, controller, lifecycle transition or provider operation is
executed by this preparation. Root alone receives and admits later operations.

The smallest next comparison is canonical versus the existing L1-excluded
policy at a genuinely admitted planning checkpoint. Its inputs can be prepared
now. This document does not assert that Root has admitted that checkpoint or
that either model has been invoked. The full family, including the required
post-L3-only control, remains unexecuted until its actual premises exist.

## Concrete task and source

The task is to bring a local report into conformance with its current selected
profile and jobs, preserving useful unchanged-build reuse. The 16 exact input
files come from `dg17/episode_06/subject/` in the retained
`continuing-execution-20261116/evidence.tar.gz` archive. The archive SHA-256 is
`7d59b34c0a859ec81dfc78b2b7ba870aae7ed860136bb9d8b415065348ca83fb`.
Its `REQUIREMENTS.md` already defines both the business requirement and the
accepted report. No new expected output or acceptance checker is invented.

The deciding component is the existing equality in `verify_report.py`:

`output/report.txt.read_text() == expected_report.txt.read_text()`.

The verifier SHA-256 is
`38750be0a1aa08e14071afbfabf3b887b74287829090447ad14e15bcc5299726`.
The accepted report is 105 bytes, SHA-256
`88c2a81102e1f564bcfa7f261c10239ae270f0082865be5ac6266628d576cddc`.
The retained output is 97 bytes, SHA-256
`813560253e90823caacbb4c54efa1005a46ef8be43c1323d8ab1be3d552cb737`.
Both are UTF-8 LF text, so the decisive text comparison has no normalization
ambiguity here. An ordinary read-only execution will preserve actual streams,
exit status, source/input hashes, interpreter identity and times. It proves a
current source-level comparison on this copy, not an owner-stage passage.

The retained source explains why this is a useful real work item: the builder
keys reuse on jobs plus profile name, while the projection also consumes the
profile heading and separator. The supplied output agrees with the earlier
profile, not the current one. That is source-supported diagnosis, not a claim
to know an unrecorded historical build sequence. No repair is applied here.

The alternative evidence-anchor helper was considered and rejected for this
task: inspected historical reports did not provide a suitable artifact-level
anchor for a legitimate current-use failure. A historical report is not made
defective merely by comparing it to an unrelated current HEAD.

## Same-predicate contract

Every prospective checkpoint uses the same verifier bytes, accepted report,
task requirement, subject-relative output path, comparison semantics and
failure interpretation. The source owner is the supplied report task; the
policy does not own or replace this check. Each within-checkpoint matched pair
also shares the exact whole subject snapshot and captured failure bytes.

Across actual stages, implementation/cache state and cause may change only
through disclosed Root-owned work. A common nonzero exit or class name is
insufficient. The evaluator must prove that the failing component is this
specific comparison. A missing file, import error, timeout or different
checker error is not the selected predicate. Later evidence must bind the
actual subject state; this initial witness is not copied into a later stage as
though a new command ran.

The four checkpoints belong to one Root-admitted task and task identity. They
are not four relabelled copies. Controlled disturbances, if used later, must be
declared and actually performed in the disposable task. They are experiment
inputs, not accidental product defects. They do not establish a native event.

## Real checkpoint premises

| Owner | Required genuine state | What this packet supplies | What remains absent |
|---|---|---|---|
| L1 | Root has accepted this report repair as the current planning work; owner/dependency/authority/acceptance decisions are pending before dependent dispatch | Exact task, original failure component, all source inputs, neutral prompt, first-pair materialization recipe | Root task/checkpoint admission and actual model/receiving observations |
| L2 | Same task is actually at continuity/re-entry; real controller, claim, boundary if applicable, ordered currentness recovery and pending source-validity decision are captured | Exact read-only comparison and conditional sequence; independent continuity requirements preserved | Actual boundary/receipt/checkpoint. A report mismatch alone does not award P04's custody mismatch scenario |
| L3 | Actual phase and last safe step; actual passing Smoke A where required; an actual implementation or disclosed stimulus; same comparison failing in Smoke B | Frozen task and verifier, a precise prospective controlled-input route | Phase admission, true A/B sequence and resulting subject/command evidence |
| L5 | Actual final-audit entry on the exact candidate after genuine clean phases/checks; a late same-comparison finding | Exact predicate and bounded audit-fix/reaudit rubric | Real phase completion, clean evidence, candidate, late finding and audit entry |

No historical particular L3 fixture ID is intrinsically required. No current
model/host incapability is inferred from an unfilled field. If L2 or L5 cannot
yet be established, leave that cell unexecuted; do not manufacture a receipt,
phase number, clean history or end-of-task event. An L2 source-policy observer
after lawful admission is different from the stopped owner's native route.

## Source population

Freeze all 70 original source files under the five `skills/` directories at
commit `a297957be11feb494c0ec467235794a1e0c54751`, tree
`b08dc4ecf4028beeedb579a312eccae23cb5d863`. The full reference/script/template
population avoids the predecessor's seven-file availability gap for ordinary
policy reading. This is a source population, not an installed or qualified
runtime package. Additional dependencies needed for a later executable route
must be explicitly admitted and identically bound before that route runs.

Canonical and the three accepted single-edge source variants are copied
byte-for-byte from their verified originals/recovery. Only one new control is
authored: a PROTOCOL policy where L4 is callable only after an L3 failure, with
L1/L2/L5 excluded and their return rows removed. The remaining independent stop,
witness, currentness and nonclosure duties stay in force. This is an exact
policy-source mutation, not a wrapper or replacement transition engine. Every
other byte is preserved. The new control needs independent semantic review.

The four-owner canonical discriminator, three single-edge comparisons and
post-L3-only control are separately declared. Their population is not collapsed
into three pairs. The first L1 pair cannot by itself award complete N06/M01.

## Entry, return and refusal attribution (R03)

Score admission before behavior. Missing source selection, actual checkpoint,
essential evidence or required capability yields an admission refusal or
premise-unfilled nonverdict; it is not a mutant kill. Keep transport failure and
policy refusal separate. Within an admitted comparison, a canonical answer can
fail or remain partial; a mutant can survive.

Entry assessment concerns the supported decision at the actual failure: timely
interception before dependent use, preserved observed witness and owner/last
safe step, applicable class, bounded containment, proportional diagnosis,
countermeasure/probe and deciding rerun requirements. Generic stop language or
the word ANDON is neither necessary nor sufficient evidence for the whole
behavior. Mandatory original recording/marker obligations remain separately
scored at their proper operational layer; paraphrase alone does not perform
them.

Return assessment is separately conditional on a real passing deciding check.
The same continuation input, if later available, is delivered identically to
both arms. L1 must recompute planning decisions; L2 must establish exact
controller/claim/receipt/currentness; L3 resumes the earliest unfinished or
invalidated step; L5 completes bounded audit-fix duties and returns to
AUDIT_START against the resulting exact candidate. An answer describing a
future repair or receipt proves no actual repair, receipt or return.

Because each single-edge variant changes eligibility and its matching return
row, a return-only failure cannot prove missing entry. Record ENTRY and RETURN
results independently. Preserve L2's independent currentness refusal and L5's
independent audit-fix/re-audit obligations in both policy source and scoring.
No new component-control variants are necessary to prevent that overclaim;
if later causal attribution requires them, they need a new reviewed freeze.

## Neutral delivery and capture (R05)

Evaluator-only files hold variant meanings, original-case IDs, expected
decisions, comparisons and review. Actor-visible inputs contain only the
selected policy, concrete task, actual admitted work record and observed
command evidence. Materialize each arm under a fresh opaque destination with
identical relative paths; do not expose a parent path containing the experiment
label. No evaluator report or other arm is in the allowed read population.

The actor receives a neutral primary prompt and explicit read-only advisory
scope. It may not manufacture task history or change the subject. The task's
existing AGENTS.md remains intact. Actual Root records and performed effects
remain separate from the advisory answer. No prompt says the expected policy
response, mutation target, test case or verdict. Backend/configuration and
native metadata stay unknown unless the host actually supplies them.

The proposed collaboration interface can create a fresh context with
`fork_turns: none`; this is not a filesystem sandbox. Its shared workspace
access must be recorded, all actual read/tool events captured, and a run that
reads the oracle or another arm is contaminated. A task name or completed
dispatch is not proof that selected source was read. The host may not expose
enough actual trace to qualify the claimed layer; preserve that limitation.

Freeze all submitted bytes and allowed populations before observations.
Capture every refusal, partial result, failure, surviving mutant and transport
event. No outcome-driven prompt/input alteration, rerun or selected answer is
allowed. A materially revised successor is separately identified, preserves its
predecessor and does not overwrite the first observation.

## Original acceptance boundary

This packet prepares source and prospective observation inputs only. It does
not amend issue211, award a case, establish clean L5, invoke an internal child,
prove native host/Stop/session behavior, or close the original work. The exact
issue and four amendments travel in evaluator evidence. Original acceptance,
required cognition/JOIN, host-native/session and final task duties remain with
their original owners. Root and the independent reviewer must inspect the
sealed result before an actor is admitted.
