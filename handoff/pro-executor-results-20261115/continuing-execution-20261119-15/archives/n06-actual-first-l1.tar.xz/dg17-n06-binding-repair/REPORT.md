# N06/M01 delivery binding repair

Report state: PARTIAL

The retained independent successor review demonstrated delivery from an author-only command observation at a different physical task directory. Root reproduced that missing binding and five closely related command identity/freshness gaps. No actor was dispatched. The original428-file source packet is unchanged. This prospective replacement materializer reads it through an explicit --packet input.

The real captured regression has eight cases: valid real capture accepted, different physical task rejected, receipt before checkpoint rejected, receipt after admission rejected, wrong script rejected, wrong flags rejected, author witness reuse rejected, and unfilled admission rejected. Original helper: six failures, two passes (actual fa21d7, exit1). Revised helper: eight passes (actual d1a222, exit0). Tests exercise real materialization side effects with explicit control-only admissions; no fixture grants Root authority.

The new actual_checkpoint_established_at field must come from the real task checkpoint record. It is an evidence-consistency predicate, not authentication; original review, genuine Root admission, currentness, source census and actor receiving remain mandatory. The existing author-source witness cannot be relabelled as a fresh live observation. All policy populations, neutral prompts, comparison predicate, source witnesses, oracle and original requirements remain unchanged.

Owner/source: materialize_delivery.py from dg17-interrupt-successor-20261119. Rollback: do not adopt replacement; original packet and negative review evidence remain immutable. Independent review is pending before any original episode admission.
