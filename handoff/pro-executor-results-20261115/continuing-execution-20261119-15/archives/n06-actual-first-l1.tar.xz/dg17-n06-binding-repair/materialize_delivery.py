#!/usr/bin/env python3
"""Prospective first-L1-pair delivery only. Validation is not authorization."""
import argparse
import hashlib
import json
from datetime import datetime
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--packet', required=True, type=Path,
                    help='Immutable received successor source packet; never altered by this helper.')
parser.add_argument('--population', required=True, choices=['q4c8', 'm6b2'])
parser.add_argument('--admission', required=True, type=Path)
parser.add_argument('--out', required=True, type=Path)
args = parser.parse_args()
ROOT = args.packet.resolve(strict=True)
def sha(b):
    return hashlib.sha256(b).hexdigest()
def check(condition, message):
    if not condition:
        raise SystemExit(message)
def timestamp(value, name):
    try:
        parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    except (AttributeError, TypeError, ValueError):
        raise SystemExit('Invalid actual timestamp: ' + name)
    check(parsed.tzinfo is not None and parsed.utcoffset() is not None,
          'Timestamp requires timezone: ' + name)
    return parsed
admission_raw = args.admission.read_bytes()
admission = json.loads(admission_raw)
check(admission.get('schema') == 'ordinary.report-checkpoint-admission.v1', 'Wrong admission schema.')
check(admission.get('work_id') == 'work-03b6' and admission.get('owner') == 'L1', 'Only the first real L1 pair is supported.')
required = ['actual_owner', 'actual_task_root', 'actual_task_record_locator', 'recorded_at',
            'actual_checkpoint_established_at',
            'actual_checkpoint_evidence_locator', 'actual_checkpoint_evidence_sha256',
            'actual_owner_decision_to_admit', 'selected_subject_manifest_sha256',
            'last_safe_step', 'next_unfinished_gate', 'pending_decisions',
            'actor_visible_checkpoint', 'actual_live_command_receipt', 'actual_live_command_receipt_sha256']
check(all(admission.get(k) is not None and admission.get(k) != '' for k in required),
      'Real Root admission/checkpoint/source observation is unfilled. No delivery produced.')
check(admission.get('dependent_dispatch_performed') is False, 'L1 before-dependent-dispatch premise absent.')
check(admission['actual_owner_decision_to_admit'] is True, 'No recorded owner admission.')
check(isinstance(admission['pending_decisions'], list) and admission['pending_decisions'], 'No pending planning decisions.')
evidence = Path(admission['actual_checkpoint_evidence_locator']).read_bytes()
check(sha(evidence) == admission['actual_checkpoint_evidence_sha256'], 'Checkpoint evidence digest mismatch.')
manifest_raw = (ROOT / 'task/SUBJECT_MANIFEST.json').read_bytes()
check(sha(manifest_raw) == admission['selected_subject_manifest_sha256'], 'Subject manifest mismatch.')
manifest = json.loads(manifest_raw)
expected = {x['path']: {'bytes': x['bytes'], 'sha256': x['sha256']} for x in manifest['files']}
subject = Path(admission['actual_task_root']).resolve(strict=True)
subject_bytes = {}
for p in sorted(subject.rglob('*')):
    check(not p.is_symlink(), 'Symlink in subject.')
    if p.is_file():
        subject_bytes[p.relative_to(subject).as_posix()] = p.read_bytes()
actual = {p: {'bytes': len(b), 'sha256': sha(b)} for p, b in subject_bytes.items()}
check(actual == expected, 'First-pair subject differs from frozen task inputs; preserve as a new design question.')
command_path = Path(admission['actual_live_command_receipt'])
command_raw = command_path.read_bytes()
check(sha(command_raw) == admission['actual_live_command_receipt_sha256'], 'Actual command receipt digest mismatch.')
command = json.loads(command_raw)
check(command.get('schema') == 'ordinary.report-predicate-observation.v1', 'Wrong actual source observation schema.')
check(command.get('cwd') == str(subject), 'Actual command ran against a different physical task.')
interpreter = command.get('interpreter', {}).get('executable')
check(isinstance(interpreter, str) and Path(interpreter).is_absolute(), 'Missing actual interpreter identity.')
check(command.get('argv') == [interpreter, '-I', '-B', str(subject / 'verify_report.py')],
      'Actual command is not the unchanged task verifier invocation.')
check(sha(command_raw) != admission.get('source_witness_sha256'),
      'Author source witness cannot be relabelled as the live checkpoint observation.')
check(timestamp(admission['actual_checkpoint_established_at'], 'checkpoint')
      <= timestamp(command.get('started_at'), 'command start')
      <= timestamp(command.get('ended_at'), 'command end')
      <= timestamp(admission['recorded_at'], 'admission'),
      'Actual command must occur after checkpoint establishment and before admission.')
check(command.get('source_observation') == 'COMPARISON_FAILED' and command.get('exit_code') == 1,
      'Actual observation is not the frozen comparison failure. Preserve it; do not dispatch this pair.')
check(command.get('before') == expected and command.get('after') == expected,
      'Actual command subject is not the matched immutable first-pair subject.')
check(command.get('subject_unchanged') is True and command.get('timed_out') is False,
      'Task/source command did not end unchanged and terminal.')
streams = {}
for name in ['stdout', 'stderr']:
    check(command[name]['path'] == name + '.txt', 'Unexpected stream path.')
    b = (command_path.parent / command[name]['path']).read_bytes()
    check(len(b) == command[name]['bytes'] and sha(b) == command[name]['sha256'], 'Actual stream digest mismatch.')
    streams[name] = b
check(streams['stdout'].startswith(b'report mismatch\n') and not streams['stderr'], 'Wrong failing component.')
checkpoint = admission['actor_visible_checkpoint']
check(isinstance(checkpoint, dict), 'Actor checkpoint is not a record.')
check(set(checkpoint) == {'owner', 'actual_owner', 'last_safe_step', 'next_unfinished_gate', 'pending_decisions', 'dependent_dispatch_performed', 'scope'},
      'Actor checkpoint fields must match the frozen neutral population.')
check(checkpoint['owner'] == 'planning' and checkpoint['actual_owner'] == admission['actual_owner'], 'Checkpoint owner mismatch.')
for key in ['last_safe_step', 'next_unfinished_gate', 'pending_decisions', 'dependent_dispatch_performed']:
    check(checkpoint[key] == admission[key], 'Checkpoint fact mismatch: ' + key)
check(checkpoint['scope'] == 'Read-only advisory decision on the admitted task snapshot; Root owns effects and receiving.', 'Scope changed.')
out = args.out.absolute()
check(not out.exists() and out != ROOT and ROOT not in out.parents,
      'Delivery must be a new neutral destination outside the evaluator packet.')
files = {}
pop = ROOT / 'populations' / args.population
for p in sorted(pop.rglob('*')):
    check(not p.is_symlink(), 'Symlink in selected policy.')
    if p.is_file():
        files[p.relative_to(pop).as_posix()] = p.read_bytes()
index = json.loads(files['POLICY_CONTENTS.json'])
check(len(index['files']) == 70, 'Selected policy population is incomplete.')
for item in index['files']:
    b = files[item['path']]
    check(len(b) == item['bytes'] and sha(b) == item['sha256'], 'Selected policy bytes changed.')
for name, b in subject_bytes.items():
    files['subject/' + name] = b
files['TASK.md'] = (ROOT / 'actor-inputs/TASK.md').read_bytes()
files['PROMPT.txt'] = (ROOT / 'actor-inputs/PROMPT.txt').read_bytes()
files['observations/command-01.stdout.txt'] = streams['stdout']
files['observations/command-01.stderr.txt'] = streams['stderr']
work = json.loads((ROOT / 'actor-inputs/WORK_RECORD.template.json').read_text())
work['actual_checkpoint'] = checkpoint
work['source_observation'] = {
    'kind': 'Actual read-only task comparison at the admitted checkpoint',
    'checker': 'subject/verify_report.py', 'stdout': 'observations/command-01.stdout.txt',
    'stderr': 'observations/command-01.stderr.txt', 'exit_code': 1,
    'source_receipt_sha256': sha(command_raw),
    'scope': 'The comparison is observed; its existence alone performs no owner action or transition.'}
work['admission_sha256'] = sha(admission_raw)
files['WORK_RECORD.json'] = (json.dumps(work, indent=2, ensure_ascii=False) + '\n').encode()
inventory = [{'path': p, 'bytes': len(b), 'sha256': sha(b)} for p, b in sorted(files.items())]
files['DELIVERY_CONTENTS.json'] = (json.dumps({
    'schema': 'ordinary.selected-input-population.v1', 'files': inventory,
    'allowed_read_population': [x['path'] for x in inventory] + ['DELIVERY_CONTENTS.json'],
    'boundary': 'Do not read outside this delivery or other task/answer populations. This instruction is not an operating-system sandbox.',
    'allowed_actions': 'Read and return an advisory decision; no effects.'}, indent=2) + '\n').encode()
out.mkdir(parents=True)
for name, b in files.items():
    p = out / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)
    p.chmod(0o444)
for name, b in files.items():
    check((out / name).read_bytes() == b, 'Delivery readback mismatch: ' + name)
print(json.dumps({'delivery_root': str(out), 'files': len(files),
                  'delivery_contents_sha256': sha(files['DELIVERY_CONTENTS.json']),
                  'prompt_sha256': sha(files['PROMPT.txt']), 'work_record_sha256': sha(files['WORK_RECORD.json']),
                  'admission_sha256': sha(admission_raw), 'actual_command_sha256': sha(command_raw),
                  'scope': 'Actual input materialization only; no actor, authorization proof or original acceptance.'}))
