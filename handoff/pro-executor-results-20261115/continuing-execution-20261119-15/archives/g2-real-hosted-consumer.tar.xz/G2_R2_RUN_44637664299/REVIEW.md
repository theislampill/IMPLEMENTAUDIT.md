# Independent receiving: G2 r2 hosted consumer route

**Disposition: RECEIVED — the exact synthetic full-consumer route passed its frozen hosted receiving criteria.** This report receives engineering behavior at the explicitly nonacceptance scope. It does not award original M2/full G2, adopt policy, authorize an original episode, or replace Root receiving.

## Actual provider identity and complete job

| Field | Independently read value |
|---|---|
| Repository | theislampill/IMPLEMENTAUDIT.md |
| Branch | pro/dg16-g2-full-consumer-smoke-20261119-02 |
| Commit | fd8d516dbef7bff291da1ba7946935bf7851abcd |
| Tree | 1408e8fa3eca2096bb778630d221c118f26d0883 |
| Sole parent | 5f6302aa16e31e705ffed2c967d4bb4b97763a51 |
| Workflow | .github/workflows/dg16-g2-full-consumer-smoke.yml |
| Workflow SHA-256 | 5f53ee066ababb7c02d114eddbec97527c4e0a8bce8377bdc881c30f858aa5e2 |
| Workflow Git blob | ba9e79cec386ff9becd9d4bc40f1800cb14ca89f |
| Run / attempt | 44637664299 / 1 |
| Check suite | 120830302601 |
| Job / check run | 135960263858, full-consumer-only |
| Provider disposition | completed / success |
| Job interval | 2026-11-19T23:26:28Z to 23:26:46Z |
| Runner | ubuntu-26.04; actual Ubuntu 26.04.1 LTS, runner 2.338.2, image 20261116.202.1 |

The exact provider workflow body equals the reviewed r2 body. The commit API reports only that workflow changed from r1. The complete jobs API reports one job and nine step records: setup, checkout, runtime paths, preflight, test suite, collector, upload, checkout post-cleanup, and complete job. Every record is completed/success; none was skipped. Full decoded logs corroborate the checkout of the exact commit, source checks, execution, upload, and cleanup.

The observed token permissions are Contents: read and Metadata: read. The checkout log explicitly removes its authentication header before test execution; no credential value is disclosed in this review. The actual run preserves pinned actions and their exact source identities. Its log retains Node deprecation warnings, including the runner's use of Node 24 for the pinned Node 20 actions. The check API reports one annotation; its exact annotation endpoint is not supported by the connector. This report records the observed log warning and does not fabricate an API annotation body. That retrieval limitation does not negate the complete successful job and retained artifact.

Source: run_TOOL_RETURN.json, jobs_TOOL_RETURN.json, jobs_raw_TOOL_RETURN.json, commit_TOOL_RETURN.json, checks_TOOL_RETURN.json, published_workflow_TOOL_RETURN.json, PUBLISHED_WORKFLOW.yml, logs_TOOL_RETURN.json, and job.log in this directory. Direct run URL: https://github.com/theislampill/IMPLEMENTAUDIT.md/actions/runs/44637664299

## Artifact custody and preflight

Artifact 14583874539 is named g2-full-consumer-44637664299-1. Its downloaded ZIP is **41,524 bytes**, SHA-256 **4c568d2a93b1a7b66562dd59095f0382f226cda0f024bd90b419441678e16137**. The independently computed digest equals both the artifact API digest and the actual upload-log digest.

The ZIP has 48 regular file members totaling 181,624 uncompressed bytes. Every one of the artifact manifest's 47 payload descriptors verifies by exact byte count and SHA-256; the remaining member is MANIFEST.json itself. No extra member, duplicate path, path traversal, symlink, Git store, TLS private key, arbitrary worker output, or unexpected file population is present. The retained members satisfy the exact collector allowlist. A bounded secret-pattern check found no private-key or GitHub-token pattern in the artifact; that is a scoped check, not a universal proof of absence.

PREFLIGHT.json binds the actual workflow commit and all four reviewed nonworkflow source digests. It reports the required procfs child-census path exists and is readable, with zero bytes and the empty-string digest. The executed workflow compares actual source bytes with the fixed expected digests and fails before testing if they differ or the census cannot be read. The preflight step succeeded. Consumer cd8262defc85c2541632fe00e51bc78c804b13a3a8a4501e39300b4269f866ff and utility 02a15dc96ecce23e14a3a84bca880aa536d79fffc4f6d6160835cb4ba97a19b5 are therefore the actual tested bytes.

SUITE.log and the full job log agree: all ten named tests passed in 11.713 seconds. The shell uses pipefail and the workflow passed the suite's actual success to the collector. There is no retry in this receiving record.

Source: artifacts_TOOL_RETURN.json, DOWNLOAD_REFERENCE.json, g2-r2-44637664299-1.zip, ARTIFACT_INVENTORY.json, artifact/MANIFEST.json, artifact/PREFLIGHT.json, artifact/RESULT.json, artifact/SUITE.log. The ephemeral download bearer URL is intentionally omitted from the durable descriptor.

## Complete positive route

The valid case has exactly thirteen capture records in both route-result.json and consumed/CONTROL_READS.json, with byte-for-byte equal command arrays. All thirteen report a started process, acquired pidfd, zero exit, complete stdout/stderr, no timeout, no output overflow, no internal failure, and ECHILD cleanup. The TLS server records exactly three real Git advertisements: discovery, fetch negotiation, and stable-head re-read. The source uses a real smart-HTTPS Git backend and a generated loopback TLS certificate; its only bindings are the loopback remote and a wrapper that adds the certificate trust path. It does not mock command results, enable other protocols, or alter production capture/environment.

The accepted reservation binds the actual synthetic control commit 601cd5cd73639948265233fdc02727f76d5f6e09 and the exact request digest 247637e26ae79a4723d992bae7025e74772e0db7a42c78a30e15bdf5c0de96bb. Its accepted epoch 1795130792 precedes the request expiry 1795130882. CONTROL.json, INDEPENDENT_REVIEW.json and ROOT_CONSUMPTION.json are retained in full; all sizes, hashes, common source/policy/request/proof bindings, review-to-Root binding, and reservation descriptors independently verify.

The exact executed test confirms sole-parent and exact-only-additions enforcement through the production consumer, exact consumed payload parity with the fixture, successful production validate() on the reserved bytes, and NO_REPEAT_LIVE_CONSUMPTION on the second hold call. The persisted reservation and route record agree. This is one synthetic exclusive reservation, not an authentic independent review or Root decision for an original run.

I independently reconstructed the stdout byte lengths and SHA-256 values for twelve of the thirteen positive commands: empty init/fetch output; initial/final advertisements; regular-blob tree listing; exact additions; and each payload size/body. The commit-header command retains its complete-stream flag, 251-byte length and digest, but its raw header is not an artifact member. Its actual source enforcement and the successful wrong-parent negative are retained evidence; I do not claim an independent raw-header replay.

## Negative controls and cleanup

| Case | Capture count | Final exit | Refusal | Reservation |
|---|---:|---:|---|---|
| Absent ref | 2 | 2 | ACTUAL_REVIEW_WINDOW_EXPIRED | Absent |
| Author as reviewer | 12 | 0 | ACTUAL_INDEPENDENT_LIVE_REVIEW_REQUIRED | Absent |
| Extra tree addition | 6 | 0 | LIVE_CONTROL_EXACT_ONLY_ADDITIONS | Absent |
| Changed review bytes | 12 | 0 | LIVE_DECISION_DIGEST | Absent |
| UTC expiry during final read | 13 | 0 | LIVE_CONTROL_CHANGED_OR_EXPIRED | Absent |
| Fatal discovery | 2 | 128 | LIVE_CONTROL_GIT_REFUSED | Absent |
| Denied file transport | 2 | 128 | LIVE_CONTROL_GIT_REFUSED | Absent |
| Changed remote head | 13 | 0 | LIVE_CONTROL_CHANGED_OR_EXPIRED | Absent |
| Wrong parent | 4 | 0 | LIVE_CONTROL_SOLE_WORKFLOW_PARENT | Absent |

All nine refusals match the frozen test expectations. Their absent reservation files agree with both the per-case records and collector summary. Fatal discovery is not treated as absence; denied file transport produced zero HTTPS advertisements. The absent case observed no commit and stopped within its bounded interval. Moving-head and UTC-expiry cases reached the final read and refused before reserving. The author negative reached the actual independence guard, rather than the scratch-host cleanup failure.

Across all ten cases, all **79** capture records independently verify complete streams, acquired pidfds, no timeout/overflow/internal failure and ECHILD. Eight retained terminal-child statuses have correct canonical status-list digests; no retained status list is truncated. No pidfd signal was needed. Actual subreaper enablement/readback is asserted by the unchanged executed worker before capture. The procfs/reaper guards were not weakened.

Source: artifact/{case}/route-result.json, TEST_SCOPE.json, REQUEST.json and consumed/CONTROL_READS.json; valid consumed payloads; RECEIVING_CHECKS.json. The exact executed test and collector are bound in SOURCE_BINDINGS.json.

## Scope and next boundary

This receives the exact-source engineering discriminator that the earlier equivalent local run could not establish. The first failed hosted run 44636484713 remains a preserved workflow-validation failure; r2 is a separate branch and attempt-1 run. No failure was overwritten.

The synthetic fixture intentionally uses NON_ACCEPTANCE run identities and invented public review/Root payloads. RESULT.json expressly sets original_acceptance, M2, full_G2, full_pair_executed, original_control_replayed, protected_G132_effect and provider_write_by_test to false. No original complete verifier pair, authentic live review, Root consumption, original closing, native/session outcome or acceptance follows from this smoke.

The immediate original G2 boundary is a newly reviewed immutable original-route packet with consistent repaired-consumer, adapter, source/policy/effect and actual-author-exclusion bindings. Exact details are in NEXT_ORIGINAL_G2_BOUNDARY.md. The old adapter pins the old consumer, and its policy adoption binds the adapter's exact bytes; a source copy alone cannot lawfully pass those gates. No extra generic test expansion or another synthetic smoke is demanded by this receiving result.

## Reviewer operations

Read-only provider fetches and bounded file/hash/JSON analysis were performed. No production module was imported or executed during receiving, and no test, capture/reaper, original pair, source/ref/provider/controller mutation or actor dispatch was performed. Writes are confined to this reviewer directory. A proposed bounded child review could not spawn because the agent thread limit was reached; no child result is claimed. Root retains integration, prospective dispatch, policy/effect decisions and original acceptance authority.
