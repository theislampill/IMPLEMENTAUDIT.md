# Exact next boundary for original full G2

**The repaired consumer route is received at synthetic scope. The immediate next original boundary is prospective packet rebinding and independent receiving before a new original episode.** The smoke does not make the old packet executable under new bytes and does not authorize replay.

## Concrete existing bindings that must be resolved

The preserved original source is /workspace/scratch/530bc07ea12b/dg16-g2-repair/source-original/qualification/dg16-r5-full-g2.

- run.py line 33 pins live_control.py SHA-256 05918b2d5c2f791a92c52fd72cf795a870f24ddedc1c6867fbbf358218cb400a. The received repair is cd8262defc85c2541632fe00e51bc78c804b13a3a8a4501e39300b4269f866ff. The old adapter correctly refuses the changed member.
- run.py line 22 pins original branch pro/dg16-g2-reviewed-20261118-01. live_control.py line 14 pins pro/dg16-g2-reviewed-control-20261118-01. Root must choose and bind lawful fresh prospective issuance/control identities while preserving old run/request/control custody. This reviewer does not change or authorize any ref.
- run.py actual_policy_adoption() binds the exact source commit/tree, policy, receiver inputs, **adapter SHA-256**, and pair driver. Updating the adapter invalidates the prior exact adoption; copying an old PASS is insufficient.
- policy_control.py requires the two exact files INDEPENDENT_COLD_REVIEW.json and ROOT_POLICY_ADOPTION.json, a candidate-seal binding, an independent reviewer, and actual Root adoption for one exact prospective episode. Both policy and live-control gates need author exclusions that reflect actual relevant prospective authors, including the transport-repair authors; the static historic list alone is not proof of current independence.
- Preserve original comparator, complete population, normalization/policy semantics, bounds, cleanup/currentness and authority gates. Retain the original candidate source identity e91df00685c55c193d288ccdb0f8ffe1e16a9957 / tree df8008fd3d25b1d32f75ec80fa45da22e3fc68ca if that remains Root's intended original qualification target; a changed target needs its own explicit applicable bindings. No target replacement is implied by this smoke.

A focused successor can change the necessary prospective branch/identity literals, consumer pin and resulting dependent hashes/decisions while preserving the proven HTTPS correction and all guard behavior. Its exact final bytes and affected bindings require independent review. This is an explicit packet-preparation boundary, not a demand to repeat the full pair or broad test suites during preparation.

## Original episode only after that receiving

1. Root establishes current authority/effect prerequisites and the actual fresh original workflow/candidate/control custody, with an independent receiver available for the fixed live window. Protected G132301aeecd remains UNKNOWN_NO_REPLAY.
2. The new original episode must execute and completely receive the original same-candidate legacy/DAG pair and full declared correspondence. The smoke did not execute that pair.
3. Original run.py prepare-review requires all declared relations equal and at least HOLD_SECONDS (3600) plus FINAL_SECONDS (180) remaining. It produces a fresh actual request/proof while private raw inputs remain live. No old request, review, control or deadline extension can substitute.
4. A genuine independent reviewer inspects the actual live proof at its claimed scope. Root separately makes its actual consumption decision. The exact control commit must have the workflow as sole parent, only the declared regular additions, complete byte bindings, stable final head, and timely reservation through the now-qualified consumer. No synthetic identity or this smoke review supplies those live decisions.
5. The same job must perform the original sealed-capture/source/runtime/native/currentness closing and revalidate the reserved request/payload before teardown. Only the complete resulting original evidence can be received for any M2/full-G2 claim.

Relevant original source: run.py actual_policy_adoption(), prepare-review/hold, check_review_public(), closing_control_readback(); policy_control.py validate(); live_control.py validate()/hold(). Root owns all source, provider, lifecycle and acceptance actions. This report supplies no original award.
