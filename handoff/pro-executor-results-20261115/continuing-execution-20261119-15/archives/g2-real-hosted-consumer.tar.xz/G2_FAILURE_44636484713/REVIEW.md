# G2 first hosted smoke: independent failure receiving

**Actual result: FAILED before runner assignment, at GitHub Actions workflow validation. The consumer smoke did not execute.** No hosted route, full G2 or M2 pass is supported.

## Exact observation

Run `44636484713`, attempt `1`, is bound to commit `5f6302aa16e31e705ffed2c967d4bb4b97763a51`, tree `8d3287c01c86523db388b00b6af03c0b7b6231be`, branch `pro/dg16-g2-full-consumer-smoke-20261119-01` and check suite `120827271890`. Independent API reads show `completed/failure`, with creation and update both `2026-11-19T23:18:17Z`, no jobs, no artifacts and zero check runs. The permitted commit check-suite collection confirms the exact suite, all-zero before SHA and the new commit after SHA.

The direct check-suite URL was refused by the connector's endpoint allowlist, and the public search fetch could not retrieve the run page. A read-only browser view of the actual public run summary displayed the decisive validation annotation: `runner` was an unrecognized named value in `runner.temp`, at line 27 column 26 and line 28 column 27 of the published workflow. The visible page also showed failure, no job graph and no artifacts. No sign-in or provider mutation occurred. The exact annotation is retained in `BROWSER_ANNOTATION.json`.

Published workflow bytes independently fetched at the exact commit match the sealed workflow: SHA-256 `5ebb7105a0068d73c113dade8c1ca473b28246cadcca23bc4863890794ea1cce`. Thus this is an authored workflow context error, not a publication mismatch, runner capability failure, TLS/Git failure or observed production-capture failure.

## Cause and smallest correction

The two offending expressions are the job-level `G2_ROUTE_EVIDENCE` and `G2_PUBLIC_EVIDENCE` definitions. Current official GitHub context rules exclude `runner` from `jobs.<job_id>.env` but permit it in step environment/run contexts. The documentation independently proves source invalidity; the actual provider annotation confirms attribution for this attempt.

Root should remove those two job-level expressions and add one runtime setup step that derives the same absolute paths from the runner's actual `RUNNER_TEMP` and `GITHUB_RUN_ID`, writing the two application variables to `GITHUB_ENV` for subsequent steps. The setup step must use its current local values; newly written environment variables are made available only to later steps.

Put setup before checkout to preserve the existing collector condition naturally: if setup fails, checkout is skipped and the collector's required successful-checkout condition is false. If setup is instead placed after checkout, additionally require its success in the collector condition, so `always()` cannot invoke collection with unset evidence paths. Do not move unrelated context values merely because these two are invalid.

The correction should retain the exact consumer, utility, test and collector bytes; immutable action references; contents-read permission; no persisted credentials; source hashes; real procfs/subreaper/pidfd cleanup checks; positive and negative expectations; time limits; and branch-created/nonforced/zero-before/attempt-1 guards. A separately identified successor needs its new exact branch/concurrency bindings and source review. Preserve this original branch, commit and failed run; no rerun, automatic retry or update is recommended.

## Accountability and claim limits

The initial independent source review missed expression-context scope and therefore did not detect this admission error. This report preserves that review and the failed first attempt instead of rewriting them. No production-capture re-execution, source fix, provider write or controller operation was performed by this reviewer. Root owns correction, one-shot successor issuance and receiving. G132301aeecd remains UNKNOWN_NO_REPLAY.

## Primary references

- Actual run summary: https://github.com/theislampill/IMPLEMENTAUDIT.md/actions/runs/44636484713
- GitHub context availability: https://docs.github.com/en/actions/reference/workflows-and-actions/contexts
- GitHub environment-file behavior: https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-commands#setting-an-environment-variable

Raw connected-tool returns, exact published workflow, browser annotation record and bounded documentation facts are retained alongside this report.
