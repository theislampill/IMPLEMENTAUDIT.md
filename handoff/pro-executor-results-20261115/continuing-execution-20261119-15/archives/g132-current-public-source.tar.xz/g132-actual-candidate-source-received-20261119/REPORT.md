# Actual-candidate G132 source rebinding

**State: UNISSUED source generation prepared for genuine nonauthor review.** This author performed bounded source work and source controls only. No adoption, issuer grant, original operation or operational readiness is claimed. Self-reported model: GPT-6 Astra Pro; no native model attestation.

## Outcome

This is a distinct generation selecting actual provider commit **`bd347ba6848e976c993ec82f5aa85d8e5964f6e1`**. It preserves the archived offline candidate **`3f6003cce29d077ad66497c30788a38af081976b`** as a different identity. Both encode root tree **`bc3f8f1a10cbea041a6bf066acda113f3252360b`** and sole parent **`301aeecde08ba6f169bc3cd837eae6f6ad068219`**. Their raw commit bodies are different: the old body is 339 bytes; the actually received new body is 919 bytes, SHA256 `be8ebb876f2b13c4fbf94facddb392412cae4a832a34b6759214826671e66a80`.

Root's candidate preparation used one supported create-tree and one create-commit call, with no blob/ref/host operation. This lane made no provider call. Root's actual intents, complete results, GET failures and native receiving files are retained under `inputs/actual-candidate/`. `REMOTE_VERIFIED.json` is pinned at 8,647 bytes, SHA256 `64597825e4fb66085a55ae1ff8f6f622577cde56b35e0de724d71b5e578db982`.

Current receiving independently checked the supplied raw commit ID, all **1,819 candidate file paths**, and reconstructed the exact tree from their mode/path/object IDs. The supplied native batch contains all **23 changed file bodies, 738,854 bytes**, each matching the previous selected-host source body and Git blob identity. The **1,796 other parent file paths are unchanged**. This does not claim individual native receiving of every inherited blob body or original host execution. Evidence: `evidence/RECEIVED_INPUTS.json` and `INPUT_RECEIVING_TOOL_RESULT.json` (e036fb, exit 0).

## New binding chain

| Artifact | Bytes | SHA256 |
|---|---:|---|
| Installation `SOURCE_INDEX.json` | 23998 | `58a831b74aec61df5f159ca72cc5c54bc2d50c13f0aea78651bdfe48f0d8e983` |
| `COMPOSITION_SOURCE_INDEX.json` | 1591 | `6d6f561278bcf5516bb05098dfc484eeca3094942dc6041bec508231584eec86` |
| Complete issuer source | 8932 | `15f88402a807fa905591d97b9f02633c205b6bd90ce71096cb092f309a44de68` |
| Bounded issuer projection | 4146 | `a1561116f4125792552a466b7bda5ed78c1bb5a3276d53aeb55a3b6a40a4e158` |
| UNISSUED Root config | 641 | `2c6cadc80a50464927316116b026e78f238a935f8e63cb23dc79e27ecb325014` |

The closed runtime installation still has **157 indexed files plus its index**. The composition still has exactly **12 runtime files**. The standalone complete issuer body is `complete-sources/issuer.py`; its exact before/after descriptors and projection relationship are bound by `GENERATION_PROVENANCE.json`, `PURE_SOURCE_PLAN.json` and this packet manifest. It is outside the runtime installation and is not imported as an operational issuer.

`HOST_IDENTITY_UNISSUED.json` records the new commit's observed **unreferenced commit-object publication**. Separate fields explicitly record that reference publication, host launch and source adoption have not been observed or issued. The identity remains UNISSUED, with no awards or retry authority. The original `SOURCE_INDEX.outer_manifest_sha256` is retained as the earlier public-source provenance anchor; it is not presented as this generation's manifest or review acceptance.

## Exact source change

| Current path | Change |
|---|---|
| `COMPOSITION_SOURCE_INDEX.json` | Updated |
| `ROOT_CONTROL_CONFIG_UNISSUED.json` | Updated |
| `dependencies/installation/HOST_IDENTITY_UNISSUED.json` | Updated |
| `dependencies/installation/PURE_SOURCE_PLAN.json` | Updated |
| `dependencies/installation/SOURCE_INDEX.json` | Updated |
| `dependencies/installation/git-candidate/3f6003cce29d077ad66497c30788a38af081976b.commit` | Removed from current selection |
| `dependencies/installation/git-candidate/bd347ba6848e976c993ec82f5aa85d8e5964f6e1.commit` | Added |
| `dependencies/installation/pure/issuer.py` | Updated |
| `source/current_pro_interfaces.py` | Updated |
| `source/current_root_entry.py` | Updated |

There are eight modified current files and one raw-commit path replacement, represented as one removal and one addition. The prior raw commit remains in `inputs/baseline/` and the archived packet. Ten runtime files are byte-identical. The two changed runtime files differ only in their installation-index literals; all their other AST nodes are unchanged. No entry/bridge/frame/journal/tool capability behavior was added or relaxed.

The exact complete issuer body was already recovered by a deterministic public-source derivation and pinned at 8,932 bytes, SHA256 `609b0ec3b77a0e1d07bc105d20675518cc07f653b222c78e045c61ca547634cf`. The new generator replaces only its top-level `HOST_COMMIT` literal, then selects the original declaration source segments verbatim. The selected three function AST hashes remain unchanged. No complete issuer module or `issuer.derive` was executed.

The generator updates both full-source and projection descriptors, all affected installation pins, the two loader constants, the unissued configuration's installation path/hash and the composition index. `SOURCE_DIFF.patch` is the exact textual difference, including the complete issuer change. `SOURCE_DELTA.json` provides the compact before/after pin map. The generator consumes the exact baseline archive and received Root candidate bytes; it does not invent source from a summary.

## Preserved original requirements

All **53 hosted phase bodies** and the phase manifest are byte-identical to the baseline. All other installation bodies and source-plan rows are unchanged except the named identity/projection/index items. The full fifteen-proof conjunction, Q06, current G3 predicates, original rows/gates, accepted-retained-M4 joins and original deadlines remain unchanged. The initial one-leaf and final two-leaf G132 publication contract remains unchanged; no G2 third-file criterion was introduced.

The original source/transport context distinction remains seven owner fields versus nine transport fields. Explicit model-side capability injection, typed results, tools/PRESENT/three-write/five-read route, exact initial/final parent rules and complete bounded wrapper custody remain the prior source implementations. The previous source packet's synthetic provider callbacks remain synthetic; their results are not promoted to actual original provider or host evidence.

## Meaningful controls and actual failures

| Control | Actual result | Scope |
|---|---|---|
| Baseline binding control, ef650f | Exit 1: four expected identity mismatches, three preserved refusal checks pass | Proves the archived 3f generation does not already select bd; not a defect claim against its original intended identity. |
| First projection recipe precheck, 40400f | Exit 1: AST unparse produced 3,773 bytes instead of the exact 4,146-byte projection | Formatting changed; failed output descriptor and receipt preserved. No source module executed. |
| Recipe diagnosis, 336f04 | Exit 0: verbatim selected source segments exactly reproduce the existing 4,146-byte projection | Uses the actual complete source and existing source-preserving method. |
| New binding source cases, b4fb59 | Exit 0: seven pass | New commit accepted by selected validation; old commit, wrong tree/parent and old protected head refused. Publication ref/run inputs are explicitly synthetic. No issuer derivation or provider call. |
| New generation controls, 816654 | Exit 0: 477 data/source assertions pass | Input/output pins, closed populations, exact source/AST invariants, phase preservation and three actual native entry invocations. This is not 477 original proof gates. |
| Actual source-only entry | Exit 0 | Loads the new exact installation/index and reports UNISSUED, no original effect and operational entry not permitted. |
| Stale index / UNISSUED prepare | Both exit 1 with their required refusal codes | `INSTALLATION_INDEX_PIN` and `CURRENT_ROOT_SELECTION_REQUIRED`; no current public-input or journal selection supplied. |

The initial read-only display helper also failed once (8f9362, list/mapping assumption). Its observed failure is retained in `INITIAL_READBACK_FAILURE.json`; a named-field readback completed in 129f28. The original complete wrapper for that incidental failure was not retained and is not fabricated. Later source-generation and control tool results are retained completely and incrementally. The older truncated receiving return remains UNKNOWN and was not rerun.

An actual child compaction occurred after the finalizer script's initial file-write call. That call requested only `apply_patch`; its complete outer result was truncated. Under Root's reported G0007 admission (`03a4c376cf2aa12c233d4cbdeef5ec86ebec5d0d`, current check 088b63 exit 0), readback received the complete 24,853-byte finalizer file, all 233 then-existing owned files, no final outputs and no matching owned process. The patch's outer metadata remains UNKNOWN; file existence was received directly. `evidence/POST_COMPACTION_RECONCILIATION_G0007.json` preserves that census and boundary. Only remaining report/seal finalization continued; no source generation, control or operation was repeated. G0006 remains the original commission record. Both currentness claims are Root reports, not child-native attestation.

The source-only entry ran on local Linux with UID/EUID/GID/EGID **1000**, Python 3.12.14. This is separate from Root's model-side tools and from the original root-owned GitHub-hosted consumer. Neither local transport nor the earlier ordinary public UID0/HTTP probe proves original same-host custody or native model identity.

## Remaining gates

`OPEN_PREDICATES.json` preserves the original P01–P09 operations and adds the observed API-readback limitation as P10:

- **Genuine nonauthor source review and Root adoption:** this exact frozen generation needs its own affected-source review. The author did not read current reviewer contexts or results. Earlier source identities or reviews are not grandfathered.
- **Actual host publication and current receiving:** bd exists as an unreferenced commit object. No branch was moved, job launched or current host admitted by this lane. Any future reference/host effect is separately controlled by Root.
- **Current Root composition:** the source entry is concrete and checked, but its configuration remains UNISSUED with null context, phase, deadlines, inputs, bodies, receiving and journal selection. Actual admission and effect-specific authority remain separate.
- **Full actual-result custody:** the prior bounded byte-retention implementation is unchanged. Oversized, unserializable, nonfaithful/no-return or persistence gaps remain explicit UNKNOWN without replay; no native-history attestation follows.
- **Initial/final control issuance:** genuine initial absence, actual selected host commit/ref/run, issued initial body, prior initial publication, current final ref and all final M4/decision joins remain mandatory.
- **Same-host tools and recipient:** real hosted tool/profile observations, the original adoption validator's actual receiving, recipient creation and Root adoption remain unissued.
- **Original sender/private route:** the eleven private inputs, five late-selected bodies, fresh nonroot sender/capture, original single encryption and eighteen metadata returns remain separately controlled. None were acquired or executed.
- **Original G1/G3 acceptance:** the full fifteen proofs, current G3, Q06, original rows/gates, accepted-retained-M4 joins, clocks, native corroboration/model applicability and actual owner consumption remain required. These controls award none.
- **Old no-replay state:** protected 625f and interrupted 301 remain UNKNOWN_NO_REPLAY. Root's current object/ref/run observations do not establish cancellation, non-use or replay permission; a new commit identity does not reset them.
- **Actual connected tree readback:** Root preserved two tree GET 404 results after successful object creation; cause UNKNOWN. Fresh remote native Git receiving proves this candidate's object facts, but it is not an automatic fallback in the runtime API adapter. Future actual control tree/file readbacks must meet unchanged typed-result requirements or have a separately reviewed adapter change. A 404 is not evidence that no effect happened.

The historical exact-3f native transport failure remains archived. This generation implements the separately identified actual-returned-commit source route Root selected; it does not claim that old raw-3f publication succeeded. No protected grant request is justified by this packet.

## Review and reproduction

Start with `RESULT.json`, `SOURCE_DELTA.json`, `GENERATION_PROVENANCE.json`, `VERIFICATION_INDEX.json` and `OPEN_PREDICATES.json`. Review the exact issuer change and two runtime literal changes in `SOURCE_DIFF.patch`. Complete current runtime/installation source and the complete issuer body are included.

Regeneration additionally requires the explicitly pinned admitted baseline archive, SHA256 `6ad2944d296440917b2ad452385f3912fb944a9aa44f8d872b44c427e94764a6`, at the path recorded in `evidence/RECEIVED_INPUTS.json`; the archived baseline is not duplicated inside this compact packet. `generators/rebind_source.py` uses write-once output paths and must be applied only to a new owned generation directory. It is not an instruction to overwrite this sealed packet. The new current source is complete and inspectable without running that generator.

The default source-only check uses the current entry with `--check`, the exact composition-index pin and unissued config pin listed above. Deployment or relocation requires separate Root installation/config selection and its actual readback; no operational invocation is authorized here. Source files/indexes are retained read-only; the config is frozen owner-readable (0400), which the unchanged entry accepts.

This task wrote only its owned directory. No Root controller/cache/shared edit, credential action, connected mutation, original/private operation, issuer effect, host launch, actor/reviewer dispatch or old broad-suite rerun occurred. All repository/API content was treated as data; authority remained the explicit Root commission. The packet carries no independent-review, readiness, adoption or closure authority.
