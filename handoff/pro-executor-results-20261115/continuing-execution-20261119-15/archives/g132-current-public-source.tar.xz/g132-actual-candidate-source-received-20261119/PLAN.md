# Actual Candidate Rebinding Implementation Plan

> Execution method: same admitted author lane, serial source work. Root independently commissions review; no new child or reviewer dispatch here.

**Goal:** Prepare a distinct, coherent UNISSUED source generation for the actually returned `bd347ba…` commit.

**Architecture:** Preserve the current entry/bridge topology and hosted tree. Derive the issuer binding from exact complete source, then propagate content hashes through the unchanged loader contracts.

**Tech stack:** Python data/AST derivation, the existing twelve Python/JavaScript runtime files, JSON source indexes and bounded local source controls.

**Spec:** `DESIGN.md` and `TASK_BOUNDARY.json`, implementing Root's explicit commission.

## Global constraints

Write only this owned directory. Prior packets and Root stores are immutable. No provider call, original/private effect, issuer operation, grants, source adoption or host launch. `625f…` / `301…` remain UNKNOWN_NO_REPLAY. Preserve actual failures and missing historical results.

## Review focus

- Same-tree commits remain distinct identities: old 3f must fail the new selected-host check.
- Raw commit bytes, parent and tree must join the received provider candidate, including all 1,819 paths and 23 changed files.
- Descriptor propagation must not leave stale installation, issuer-projection or composition pins.
- Full-source derivation must change only the intended top-level identity declaration; all selected function ASTs and original proof source remain unchanged.
- An UNISSUED config must still refuse operational prepare/run before input or journal effects.

## Tasks

1. [ ] Receive pinned baseline/current object receipts and Root candidate records into `inputs/`; record exact baseline mismatch and input provenance in `evidence/`.
2. [ ] Implement `generators/rebind_source.py`: exact input checks; copy admitted runtime/installation bodies; derive complete/pure issuer; update new identity/raw commit, source plan/index, two runtime constants, unissued config and composition index. Produce an exact change ledger and standalone complete issuer body.
3. [ ] Add and execute `tests/check_rebinding.py` for received-object joins, exact source/population/pin checks, AST and phase invariance, old/new and parent/tree negative controls, actual source-only entry loading and default operational refusal. No old broad test suite rerun.
4. [ ] Freeze `REPORT.md`, `RESULT.json`, `OPEN_PREDICATES.json`, exact diff, input/generation/verification indexes, payload manifest, ZIP and seal. Retain complete actual tool results and failures incrementally.

No commit, ref update, publication or grant is part of this plan.
