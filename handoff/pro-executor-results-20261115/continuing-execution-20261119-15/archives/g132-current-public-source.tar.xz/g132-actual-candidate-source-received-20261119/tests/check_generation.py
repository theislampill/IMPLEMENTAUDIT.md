"""Exact-source and entry checks for the new unissued binding only."""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys
import zipfile

BASE=Path(__file__).resolve().parent.parent
INSTALL=BASE/'dependencies/installation'
NEW='bd347ba6848e976c993ec82f5aa85d8e5964f6e1'
OLD='3f6003cce29d077ad66497c30788a38af081976b'
OLD_INDEX='6281cff522f9e13d24992816f9db35c3cff12a45875c9b13bdd6b6d3812ae50a'
def desc(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def load(path):return json.loads(path.read_bytes())
def dump(v):return (json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode()
rows=[]
def check(name,condition):
    rows.append({'name':name,'pass':bool(condition)})
    if not condition:raise AssertionError(name)
def ast_without(raw,name):
    tree=ast.parse(raw)
    tree.body=[n for n in tree.body if not (isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))]
    return ast.dump(tree,include_attributes=False)

provenance=load(BASE/'GENERATION_PROVENANCE.json')
inputs=load(BASE/'evidence/RECEIVED_INPUTS.json')
for row in inputs['inputs']:
    check('input-pin:'+row['path'],desc((BASE/row['path']).read_bytes())=={k:row[k] for k in ('bytes','sha256')})
for name,pin in provenance['outputs'].items():
    check('generated-body:'+name,desc((BASE/name).read_bytes())==pin)
index_raw=(INSTALL/'SOURCE_INDEX.json').read_bytes();index=json.loads(index_raw);index_sha=desc(index_raw)['sha256']
actual={p.relative_to(INSTALL).as_posix() for p in INSTALL.rglob('*') if p.is_file()}
check('exact-installation-population',actual==set(index['files'])|{'SOURCE_INDEX.json'})
check('installation-still-unissued',index['state']=='UNISSUED' and index['authority']=='NONE' and index['runtime_adoption_issued'] is False and index['old_G132']=='UNKNOWN_NO_REPLAY')
check('actual-host-distinct-from-old',index_sha!=OLD_INDEX and provenance['actual_candidate']==NEW and provenance['historical_candidate']==OLD)
for name,pin in index['files'].items():check('installation-pin:'+name,desc((INSTALL/name).read_bytes())==pin)
identity=load(INSTALL/'HOST_IDENTITY_UNISSUED.json')
check('object-publication-not-host-grant',identity['commit']==NEW and identity['provider_publication_observed'] is True
      and identity['provider_publication_scope']=='COMMIT_OBJECT_ONLY_UNREFERENCED' and identity['reference_publication_observed'] is False
      and identity['host_launch_observed'] is False and identity['source_adoption_issued'] is False and identity['state']=='UNISSUED'
      and identity['old_unknown_operations']==['625f310d04cb5b5a1f02901cfdcf3c3815730a5e','301aeecde08ba6f169bc3cd837eae6f6ad068219'])
raw=(INSTALL/'git-candidate'/f'{NEW}.commit').read_bytes()
check('actual-raw-commit-received',raw==(BASE/'inputs/actual-candidate/REMOTE_COMMIT.raw').read_bytes())
check('actual-git-commit-id',hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==NEW)
old_raw=(BASE/'inputs/baseline/dependencies/installation/git-candidate'/f'{OLD}.commit').read_bytes()
check('same-tree-old-commit-remains-distinct',hashlib.sha1(b'commit '+str(len(old_raw)).encode()+b'\0'+old_raw).hexdigest()==OLD and old_raw!=raw)
check('old-active-commit-file-removed-only-in-new-generation',not (INSTALL/'git-candidate'/f'{OLD}.commit').exists())
plan=load(INSTALL/'PURE_SOURCE_PLAN.json');old_plan=load(BASE/'inputs/baseline/dependencies/installation/PURE_SOURCE_PLAN.json')
check('all-other-source-plans-unchanged',{k:v for k,v in plan.items() if k!='issuer'}=={k:v for k,v in old_plan.items() if k!='issuer'})
full=(BASE/'complete-sources/issuer.py').read_bytes();old_full=(BASE/'inputs/issuer.full.before.py').read_bytes()
projection=(INSTALL/'pure/issuer.py').read_bytes();old_projection=(BASE/'inputs/baseline/dependencies/installation/pure/issuer.py').read_bytes()
check('full-issuer-descriptor',desc(full)=={'bytes':plan['issuer']['source_bytes'],'sha256':plan['issuer']['source_sha256']})
check('projection-descriptor',desc(projection)=={'bytes':plan['issuer']['projection_bytes'],'sha256':plan['issuer']['projection_sha256']})
check('complete-issuer-only-host-constant-changed',ast_without(full,'HOST_COMMIT')==ast_without(old_full,'HOST_COMMIT'))
check('pure-issuer-only-host-constant-changed',ast_without(projection,'HOST_COMMIT')==ast_without(old_projection,'HOST_COMMIT'))
def selected_nodes(raw):
    out={}
    for n in ast.parse(raw).body:
        if isinstance(n,(ast.FunctionDef,ast.ClassDef)):out[n.name]=n
        elif isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):out[n.targets[0].id]=n
    return out
full_nodes=selected_nodes(full);projection_nodes=selected_nodes(projection)
check('selected-declaration-population',set(projection_nodes)==set(plan['issuer']['declarations']))
check('full-to-pure-declaration-correspondence',all(ast.dump(n,include_attributes=False)==ast.dump(full_nodes[k],include_attributes=False) for k,n in projection_nodes.items()))
check('selected-function-plan-unchanged',plan['issuer']['functions']==old_plan['issuer']['functions'])
for name,pin in plan['issuer']['functions'].items():
    check('issuer-function-ast:'+name,hashlib.sha256(ast.dump(full_nodes[name],include_attributes=False).encode()).hexdigest()==pin)
check('issuer-host-literal',ast.literal_eval(full_nodes['HOST_COMMIT'].value)==NEW)
with zipfile.ZipFile(inputs['baseline_archive']['path']) as z:
    old_index=json.loads(z.read('dependencies/installation/SOURCE_INDEX.json'))
    installation_changed={'HOST_IDENTITY_UNISSUED.json','PURE_SOURCE_PLAN.json','pure/issuer.py','git-candidate/'+OLD+'.commit'}
    check('only-selected-installation-path-renamed',set(index['files'])==(set(old_index['files'])-{'git-candidate/'+OLD+'.commit'})|{'git-candidate/'+NEW+'.commit'})
    unchanged_names=[n for n in old_index['files'] if n not in installation_changed and not n.startswith('phase/')]
    check('all-other-installation-source-bodies-unchanged',all((INSTALL/n).read_bytes()==z.read('dependencies/installation/'+n) for n in unchanged_names))
    expected_delta={'dependencies/installation/'+n for n in installation_changed}|{'dependencies/installation/SOURCE_INDEX.json',
                    'dependencies/installation/git-candidate/'+NEW+'.commit','source/current_pro_interfaces.py','source/current_root_entry.py',
                    'ROOT_CONTROL_CONFIG_UNISSUED.json','COMPOSITION_SOURCE_INDEX.json'}
    check('exact-ten-current-path-delta',{r['path'] for r in provenance['current_source_delta']}==expected_delta)
    phase=load(INSTALL/'phase/PHASE.json')
    check('phase-manifest-unchanged',(INSTALL/'phase/PHASE.json').read_bytes()==z.read('dependencies/installation/phase/PHASE.json'))
    for name in phase['members']:
        check('original-phase-unchanged:'+name,(INSTALL/'phase'/name).read_bytes()==z.read('dependencies/installation/phase/'+name))
    composition=load(BASE/'COMPOSITION_SOURCE_INDEX.json')
    check('composition-population',len(composition['files'])==12 and set(composition['files'])=={p.name for p in (BASE/'source').iterdir() if p.is_file()})
    check('composition-index-join',composition['installation_index_sha256']==index_sha)
    for name,pin in composition['files'].items():
        now=(BASE/'source'/name).read_bytes();previous=z.read('source/'+name)
        check('runtime-pin:'+name,desc(now)==pin)
        if name in ('current_pro_interfaces.py','current_root_entry.py'):
            literal='INDEX_SHA256' if name=='current_pro_interfaces.py' else 'INDEX'
            check('runtime-only-index-literal:'+name,ast_without(now,literal)==ast_without(previous,literal))
            node=selected_nodes(now)[literal];check('runtime-current-index:'+name,ast.literal_eval(node.value)==index_sha)
        else:check('unchanged-runtime:'+name,now==previous)

config_path=BASE/'ROOT_CONTROL_CONFIG_UNISSUED.json';config=load(config_path)
check('default-config-still-unissued',config['state']=='UNISSUED' and config['installation']=={'path':str(INSTALL),'index_sha256':index_sha})
check('no-run-operation-selection',all(config[k] is None for k in ('context','phase','deadline_unix_ms','input_root','receivings','current_receiving','root_body','parent_observation','host_publication','initial_publication','journal_parent','journal_name')))
controls=BASE/'controls';controls.mkdir(mode=0o700)
invocations=[]
def entry(name,config_file,mode,expected_code=None):
    command=[sys.executable,'-I','-S','-B',str(BASE/'source/current_root_entry.py'),
             '--source-index',str(BASE/'COMPOSITION_SOURCE_INDEX.json'),'--source-index-sha256',desc((BASE/'COMPOSITION_SOURCE_INDEX.json').read_bytes())['sha256'],
             '--config',str(config_file),'--config-sha256',desc(config_file.read_bytes())['sha256'],mode]
    result=subprocess.run(command,capture_output=True,timeout=30,stdin=subprocess.DEVNULL)
    decoded=json.loads(result.stdout)
    invocations.append({'name':name,'command':command,'returncode':result.returncode,'stdout_utf8':result.stdout.decode(),'stderr_utf8':result.stderr.decode()})
    check(name+':stderr-empty',not result.stderr)
    if expected_code is None:
        check(name+':success',result.returncode==0 and decoded['state']=='UNISSUED' and decoded['original_effects'] is False and decoded['operational_entry_permitted'] is False)
        check(name+':actual-host',decoded['installation']['host_identity']['commit']==NEW)
    else:
        check(name+':expected-refusal',result.returncode==1 and decoded['code']==expected_code and decoded['original_consumer_invoked'] is False and decoded['automatic_retry'] is False)
    return decoded
entry('actual-source-only-entry',config_path,'--check')
stale=dict(config,installation=dict(config['installation'],index_sha256=OLD_INDEX))
stale_path=controls/'STALE_INDEX_CONFIG.json';stale_path.write_bytes(dump(stale));stale_path.chmod(0o400)
entry('stale-installation-index-refused',stale_path,'--check','INSTALLATION_INDEX_PIN')
entry('unissued-operational-prepare-refused',config_path,'--prepare','CURRENT_ROOT_SELECTION_REQUIRED')
check('no-journal-or-input-selection-created',set(p.name for p in controls.iterdir())=={'STALE_INDEX_CONFIG.json'})

result={'schema':'g132.actual-candidate-generation-controls.v1','authority':'NONE','state':'UNISSUED_SOURCE_CONTROL_RESULT',
        'passed':sum(r['pass'] for r in rows),'failed':sum(not r['pass'] for r in rows),'checks':rows,'entry_invocations':invocations,
        'local_environment':{'python':sys.version,'uid':os.getuid(),'euid':os.geteuid(),'gid':os.getgid(),'egid':os.getegid()},
        'actual_provider_calls':0,'issuer_derive_called':False,'original_or_private_operation':False,'host_launch':False,
        'native_model_attestation':False,'source_adoption':False,'protected_operation':'UNKNOWN_NO_REPLAY'}
with (BASE/'evidence/GENERATION_CONTROLS.json').open('x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({'passed':result['passed'],'failed':result['failed'],'entry_results':[{'name':r['name'],'returncode':r['returncode']} for r in invocations],
                  'actual_host':NEW,'installation_index':desc(index_raw),'original_or_private_operation':False,'provider_calls':0,'authority':'NONE'},indent=2))
