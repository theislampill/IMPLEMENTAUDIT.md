"""Bounded synthetic/public-data checks; never calls issuer.derive or a tool."""
import argparse
import ast
import json
from pathlib import Path
import types

OLD='3f6003cce29d077ad66497c30788a38af081976b'
NEW='bd347ba6848e976c993ec82f5aa85d8e5964f6e1'
TREE='bc3f8f1a10cbea041a6bf066acda113f3252360b'
PARENT='301aeecde08ba6f169bc3cd837eae6f6ad068219'

def need(value, code):
    if not value:raise ValueError(code)

def main():
    p=argparse.ArgumentParser();p.add_argument('--generation',required=True);p.add_argument('--receipt',required=True);a=p.parse_args()
    root=Path(a.generation);install=root/'dependencies/installation'
    identity=json.loads((install/'HOST_IDENTITY_UNISSUED.json').read_bytes())
    source=ast.parse((root/'source/current_pro_interfaces.py').read_bytes())
    klass=next(n for n in source.body if isinstance(n,ast.ClassDef) and n.name=='CurrentSources')
    validator=next(n for n in klass.body if isinstance(n,ast.FunctionDef) and n.name=='host_commit')
    namespace={'need':need,'re':__import__('re')}
    exec(compile(ast.Module(body=[validator],type_ignores=[]),'<selected-host-commit-validator>','exec'),namespace)
    holder=types.SimpleNamespace(identity=identity)
    holder.host_commit=lambda commit:namespace['host_commit'](holder,commit)
    projection=(install/'pure/issuer.py').read_bytes();t=ast.parse(projection)
    assert all(isinstance(n,(ast.Assign,ast.FunctionDef)) for n in t.body)
    assert not any(isinstance(n,(ast.Import,ast.ImportFrom)) for n in ast.walk(t))
    selected={};exec(compile(t,'<bounded-issuer-projection>','exec'),selected)
    R=types.SimpleNamespace(parse=lambda raw,*args:json.loads(raw),MAX_RESULT=1048576)
    def commit(h=NEW,tree=TREE,parent=PARENT):return {'sha':h,'tree':{'sha':tree},'parents':[{'sha':parent}]}
    def publication(h=NEW):
        ctx={k:identity[k] for k in ('repository','branch','workflow_path','job_name')}
        ctx.update(workflow_commit=h,run_id='123',run_attempt=1)
        body={'ref':{'ref':'refs/heads/'+ctx['branch'],'object':{'type':'commit','sha':h}},'commit':commit(h),
              'run':{'head_sha':h,'repository':{'full_name':ctx['repository']},'head_repository':{'full_name':ctx['repository']},
                     'head_branch':ctx['branch'],'path':ctx['workflow_path'],'event':'push','id':123,'run_attempt':1}}
        return json.dumps(body).encode(),ctx
    rows=[]
    def case(name, action, expected=None):
        try:
            action();actual=None
        except ValueError as e:actual=str(e)
        rows.append({'name':name,'expected_refusal':expected,'actual_refusal':actual,'pass':actual==expected})
    case('actual_new_commit_is_selected',lambda:holder.host_commit(commit()))
    case('historical_old_commit_is_refused',lambda:holder.host_commit(commit(OLD)),'EXACT_SELECTED_HOST_COMMIT_TREE_PARENT')
    case('wrong_tree_is_refused',lambda:holder.host_commit(commit(tree='0'*40)),'EXACT_SELECTED_HOST_COMMIT_TREE_PARENT')
    case('wrong_parent_is_refused',lambda:holder.host_commit(commit(parent='0'*40)),'EXACT_SELECTED_HOST_COMMIT_TREE_PARENT')
    def join(h):
        body,ctx=publication(h);selected['publication_join'](R,holder,body,ctx)
    case('new_commit_join_with_explicit_synthetic_ref_run',lambda:join(NEW))
    case('old_commit_join_is_refused',lambda:join(OLD),'PUBLICATION_HEAD_CHANGED')
    def current_protected_ref_is_not_new_host():
        body,ctx=publication(NEW);body=json.loads(body);body['ref']['object']['sha']='625f310d04cb5b5a1f02901cfdcf3c3815730a5e'
        selected['publication_join'](R,holder,json.dumps(body).encode(),ctx)
    case('old_protected_head_cannot_supply_new_publication_join',current_protected_ref_is_not_new_host,'PUBLICATION_HEAD_CHANGED')
    result={'schema':'g132.binding-source-controls.v1','authority':'NONE','generation':str(root),'expected_current_candidate':NEW,
            'observed_selected_candidate':identity['commit'],'synthetic_ref_run_used':True,'synthetic_run_id':'123',
            'actual_provider_success_claimed':False,'issuer_derive_called':False,'issuer_effect':False,'provider_calls':0,
            'original_acceptance':False,'tests':rows,'passed':sum(r['pass'] for r in rows),'failed':sum(not r['pass'] for r in rows)}
    with Path(a.receipt).open('x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
    print(json.dumps(result,indent=2));return bool(result['failed'])

if __name__=='__main__':raise SystemExit(main())
