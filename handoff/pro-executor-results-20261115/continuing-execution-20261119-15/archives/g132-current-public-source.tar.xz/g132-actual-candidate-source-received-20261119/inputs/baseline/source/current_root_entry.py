#!/usr/bin/env python3
"""Pinned current Root control entry: public data receiving and framed intents.

No network, model tool, issuer, sender, decryptor, original G3 consumer or host
launcher exists here. The separately admitted model bridge invokes real tools.
JSON selection labels and successful source checks are never authority.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import select
import stat
import sys
import termios
import time
import types

INDEX='6281cff522f9e13d24992816f9db35c3cff12a45875c9b13bdd6b6d3812ae50a'
READY='READY_FOR_EPHEMERAL_DOWNLOAD_RESULT_LENGTH_FRAME'
MAX_RESULT=4*1024*1024
MAX_DATA=32*1024*1024
MODULES=('publication_owner','file_readback','tools_transport_owner','current_control_api',
         'current_tools_control_api','current_control_driver','current_pro_interfaces')
SOURCE_FILES={n+'.py' for n in MODULES}|{'current_root_entry.py','g132_linux_host.py',
              'g132_operator_bridge.js','codec.js','g132_root_composition.js'}
CONFIG_FIELDS={'schema','state','purpose','installation','context','phase','deadline_unix_ms',
               'input_root','receivings','current_receiving','root_body','parent_observation',
               'host_publication','initial_publication','journal_parent','journal_name'}

class Refusal(ValueError):pass
def need(v,c):
    if not v:raise Refusal(c)
def desc(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def encode(v):return (json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def parse(b,maximum=1024*1024):
    need(type(b)is bytes and 0<len(b)<=maximum,'BOUNDED_JSON')
    def pairs(rows):
        d={}
        for k,v in rows:need(k not in d,'DUPLICATE_KEY');d[k]=v
        return d
    return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda _:need(False,'NONFINITE'))
def mark(s):return (s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def canonical_path(value):
    need(type(value)is str and value.startswith('/') and '\0' not in value,'ABSOLUTE_PATH')
    p=Path(value)
    need(str(p)==value and '..' not in p.parts and p.resolve(strict=True)==p
         and not any(x.is_symlink() for x in p.parents),'CANONICAL_NO_ALIAS_PATH')
    return p
def read(path,maximum,pin=None,source=False):
    p=canonical_path(str(path));s=p.lstat()
    need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_uid==os.geteuid()
         and 0<s.st_size<=maximum and stat.S_IMODE(s.st_mode) in ((0o400,0o444) if source else (0o400,0o600)),
         'OWNED_BOUNDED_SELECTED_FILE')
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK)
    try:
        need(mark(os.fstat(fd))==mark(s) and not os.listxattr(fd),'FILE_OPEN_CHANGED')
        raw=os.pread(fd,maximum+1,0)
        need(len(raw)==s.st_size and mark(os.fstat(fd))==mark(s)==mark(p.lstat()),'FILE_READ_CHANGED')
    finally:os.close(fd)
    need(pin is None or desc(raw)==pin,'EXACT_SELECTED_BYTES')
    return raw

def load_composition(index_path,index_sha256):
    p=canonical_path(index_path);raw=read(p,65536,source=True)
    need(desc(raw)['sha256']==index_sha256,'COMPOSITION_INDEX_PIN')
    index=parse(raw)
    need(set(index)=={'schema','state','authority','installation_index_sha256','files'}
         and index['schema']=='g132.current-root-composition-source-index.v1'
         and index['state']=='UNISSUED' and index['authority']=='NONE'
         and index['installation_index_sha256']==INDEX
         and set(index['files'])==SOURCE_FILES,'EXACT_CURRENT_COMPOSITION_POPULATION')
    base=p.parent/'source';base=canonical_path(str(base))
    need({x.name for x in base.iterdir()}==SOURCE_FILES,'NO_UNINDEXED_RUNTIME_SOURCE')
    bodies={name:read(base/name,1024*1024,pin,source=True) for name,pin in index['files'].items()}
    need(Path(__file__).resolve()==base/'current_root_entry.py','ENTRY_IN_SELECTED_COMPOSITION')
    modules={}
    for name in MODULES:
        need(name not in sys.modules,'NO_PRELOADED_COMPOSITION_MODULE')
        m=types.ModuleType(name);m.__file__=str(base/(name+'.py'));sys.modules[name]=m
        try:exec(compile(bodies[name+'.py'],m.__file__,'exec'),m.__dict__)
        except BaseException:sys.modules.pop(name,None);raise
        modules[name]=m
    return modules,desc(raw),index

class PublicInputs:
    """Only exact individually selected public evidence files; no directory scan."""
    def __init__(self,root):
        self.root=canonical_path(root);s=self.root.stat()
        need(stat.S_ISDIR(s.st_mode) and s.st_uid==os.geteuid()
             and stat.S_IMODE(s.st_mode)==0o700 and not os.listxattr(self.root),'PUBLIC_INPUT_CUSTODY')
        self.pins={};self.total=0
    def body(self,ref,maximum=MAX_RESULT):
        need(type(ref)is dict and set(ref)=={'path','bytes','sha256'}
             and type(ref['bytes'])is int and 0<ref['bytes']<=maximum
             and type(ref['sha256'])is str and re.fullmatch('[0-9a-f]{64}',ref['sha256']),
             'EXACT_PUBLIC_INPUT_SELECTION')
        p=canonical_path(ref['path']);need(p.is_relative_to(self.root),'PUBLIC_INPUT_PATH_ESCAPE')
        pin={k:ref[k] for k in ('bytes','sha256')}
        need(str(p) not in self.pins or self.pins[str(p)]==pin,'PUBLIC_INPUT_REBOUND')
        if str(p) not in self.pins:
            self.total+=ref['bytes'];need(self.total<=MAX_DATA,'PUBLIC_INPUT_AGGREGATE')
        self.pins[str(p)]=pin
        return read(p,maximum,pin)

def host_publication(s,inputs,refs,O,D,context):
    need(type(refs)is dict and set(refs)=={'commit','ref','run'},'ACTUAL_HOST_READBACK_POPULATION')
    api='https://api.github.com/repos/'+context['repository']
    urls={'commit':api+'/git/commits/'+context['workflow_commit'],
          'ref':api+'/git/ref/heads/'+context['branch'],'run':api+'/actions/runs/'+context['run_id']}
    raw={k:inputs.body(v) for k,v in refs.items()}
    for b in raw.values():D.metadata_guard(b)
    values={k:O.unwrap_control(raw[k],urls[k]) for k in refs}
    # A derived owner input, explicitly distinct from the actual tool wrappers.
    values.update(schema='g132.actual-host-readback-owner-input.v1',authority='NONE',
                  full_actual_tool_results={k:desc(b) for k,b in raw.items()})
    return encode(values)

def parent_selection(s,R,received,inputs,ref,host_refs,O,D):
    raw=inputs.body(ref);D.metadata_guard(raw);host=None
    if received['phase']=='g3_initial':
        url='https://api.github.com/repos/'+received['context']['repository']+'/git/ref/heads/'+R.requirements(s,received)['branch']
        raw=encode(dict(schema='dg16.actual-read-only-tool-interface-observation.v1',
              tool='mcp__codex_apps__github_fetch',url=url,purpose='Current exact initial control parent observation',result=O.parse(raw)))
        host=host_publication(s,inputs,host_refs,O,D,received['context'])
    else:need(host_refs is None,'NO_HOST_PARENT_SUBSTITUTION')
    selected=R.control_parent(received,raw,host)
    return selected,({'ref_observation':raw,'host_publication':host} if host is not None else None)

def prepare(config,config_pin,modules,manifest_pin):
    need(type(config)is dict and set(config)==CONFIG_FIELDS
         and config['schema']=='g132.current-root-entry-config.v1'
         and config['state']=='ROOT_SELECTED_FOR_CURRENT_CONTROL'
         and config['purpose']=='CONTROL_DATA_PUBLICATION_ONLY','CURRENT_ROOT_SELECTION_REQUIRED')
    phase=config['phase'];need(phase in ('tools','g3_initial','g3_final'),'CURRENT_CONTROL_PHASE')
    now=time.time_ns()//1000000;deadline=config['deadline_unix_ms']
    need(type(deadline)is int and now<deadline<=now+600000,'ORIGINAL_PROCESS_DEADLINE')
    C=modules['current_pro_interfaces'];O=modules['publication_owner'];D=modules['current_control_driver']
    installation=config['installation']
    need(type(installation)is dict and set(installation)=={'path','index_sha256'}
         and installation['index_sha256']==INDEX,'EXACT_INSTALLATION_SELECTION')
    s=C.CurrentSources(installation['path']);s.context(config['context'])
    inputs=PublicInputs(config['input_root']);receivings={}
    rows=config['receivings'];phases=['g3_initial','g3_final'] if phase=='g3_final' else [phase]
    need(type(rows)is list and [r.get('phase') for r in rows]==phases,'EXACT_RECEIVING_PHASE_SEQUENCE')
    for row in rows:
        need(type(row)is dict and set(row)=={'id','phase','results','archive','note','previous','actual_root'}
             and type(row['id'])is str and re.fullmatch('[a-z0-9_-]{1,32}',row['id'])
             and row['id'] not in receivings and (row['previous'] is None or row['previous'] in receivings),
             'EXACT_CURRENT_RECEIVING_INPUTS')
        need(type(row['results'])is dict and set(row['results'])==set(s.B.KINDS),'ACTUAL_PUBLIC_RESULT_POPULATION')
        results={k:inputs.body(v) for k,v in row['results'].items()}
        for b in results.values():D.metadata_guard(b)
        archive=inputs.body(row['archive'],8*1024*1024);note=O.parse(inputs.body(row['note'],65536),65536)
        prior=receivings.get(row['previous']);actual=None if row['actual_root'] is None else inputs.body(row['actual_root'],8192)
        if row['phase']=='g3_final':need(prior is not None and prior['phase']=='g3_initial' and actual is not None,'ACTUAL_FIRST_HOLD_REQUIRED')
        else:need(prior is None and actual is None,'NO_UNEXPECTED_PREVIOUS_HOLD')
        receivings[row['id']]=s.receive_public(row['phase'],config['context'],results,archive,note,prior,actual)
    need(config['current_receiving'] in receivings,'CURRENT_RECEIVING_HANDLE')
    received=receivings[config['current_receiving']];need(received['phase']==phase,'CURRENT_PHASE_HANDLE')
    R=(modules['current_tools_control_api'].CurrentToolsControlAPI(s) if phase=='tools'
       else modules['current_control_api'].CurrentControlAPI(s))
    body=inputs.body(config['root_body'],65536);D.metadata_guard(body)
    selected,parent_state=parent_selection(s,R,received,inputs,config['parent_observation'],config['host_publication'],O,D)
    initial=None
    if phase=='g3_final':
        q=config['initial_publication']
        need(type(q)is dict and set(q)=={'receiving_id','body','published_commit','parent_observation','host_publication','readbacks'}
             and q['receiving_id'] in receivings,'ACTUAL_INITIAL_PUBLICATION_REQUIRED')
        prior=receivings[q['receiving_id']];need(prior['phase']=='g3_initial','INITIAL_PUBLICATION_PHASE')
        first=inputs.body(q['body'],8192);D.metadata_guard(first)
        first_parent,first_state=parent_selection(s,R,prior,inputs,q['parent_observation'],q['host_publication'],O,D)
        # The original final conjunction checks the prior decision at its recorded
        # issuance; this is not a new historical execution or current grant.
        issued=O.parse(first,8192)['issued_unix_ms']
        prior_plan=R.publication_plan(s,prior,first,first_parent['commit_parent_sha'],issued,None,first_state)
        need(type(q['readbacks'])is dict,'INITIAL_ACTUAL_READBACKS')
        prior_results={k:inputs.body(v) for k,v in q['readbacks'].items()}
        for b in prior_results.values():D.metadata_guard(b)
        modules['current_control_api'].verify_publication(prior_plan,q['published_commit'],prior_results)
        need(selected['commit_parent_sha']==q['published_commit'],'CURRENT_REF_IS_ACTUAL_INITIAL_PUBLICATION')
        initial={'body':first,'receiving':prior,'published_commit':q['published_commit']}
    else:need(config['initial_publication'] is None,'NO_UNEXPECTED_INITIAL_PUBLICATION')
    plan=R.publication_plan(s,received,body,selected['commit_parent_sha'],time.time_ns()//1000000,initial,parent_state)
    journal_parent=s.work_root(config['journal_parent'])
    need(type(config['journal_name'])is str and re.fullmatch('[A-Za-z0-9_-]{1,100}',config['journal_name']),
         'FRESH_CURRENT_JOURNAL_NAME')
    journal=journal_parent/config['journal_name'];need(not os.path.lexists(journal),'NO_CURRENT_JOURNAL_REPLAY')
    need(time.time_ns()//1000000<deadline,'PREPARATION_AFTER_ORIGINAL_DEADLINE')
    binding={'schema':'g132.current-root-executable-binding.v1','authority':'NONE',
             'config':config_pin,'composition_source_index':manifest_pin,'installation_index_sha256':INDEX,
             'context':config['context'],
             'model_context':dict(config['context'],source_commit=s.P.SOURCE_COMMIT,source_tree=s.P.SOURCE_TREE),
             'phase':phase,'deadline_unix_ms':deadline,
             'root_body':desc(body),'journal':str(journal),'input_files':inputs.pins,
             'publication':{'kind':'CONTROL_DATA_ONLY','phase':phase,'branch':plan['branch'],
                  'parent_sha':plan['parent_sha'],'ref_state':selected['ref_state'],
                  'expected_tree_sha':plan['expected_tree_sha'],'paths':sorted(plan['files']),
                  'files':{p:{k:r[k] for k in ('bytes','sha256')} for p,r in plan['files'].items()},
                  'writes':3,'reads':len(plan['files'])+4},
             'source_adoption_issued':False,'live_external_admission_required':True,
             'original_consumer_invoked':False,'original_awards':[]}
    return {'sources':s,'api':R,'received':received,'body':body,'parent_sha':plan['parent_sha'],
            'initial_control':initial,'parent_state':parent_state,'journal':journal,'binding':binding}

def frame(maximum,timeout):
    need(sys.stdin.isatty() and type(maximum)is int and 0<maximum<=MAX_RESULT
         and type(timeout) in (int,float) and 0<timeout<=45,'BOUNDED_ACTUAL_TTY_FRAME')
    end=time.monotonic()+timeout;before=termios.tcgetattr(0);changed=list(before);changed[6]=list(before[6])
    changed[3]&=~(termios.ECHO|termios.ICANON);changed[6][termios.VMIN]=1;changed[6][termios.VTIME]=0
    termios.tcsetattr(0,termios.TCSANOW,changed)
    def exact(n):
        out=[];size=0
        while size<n:
            need(time.monotonic()<end,'ORIGINAL_FRAME_DEADLINE')
            if select.select([0],[],[],min(.1,max(0,end-time.monotonic())))[0]:
                b=os.read(0,min(65536,n-size));need(b,'FRAME_EOF');out.append(b);size+=len(b)
        return b''.join(out)
    try:
        print(READY,flush=True);header=b''
        while not header.endswith(b'\n'):
            need(len(header)<9,'FRAME_HEADER_BOUND');header+=exact(1)
        need(re.fullmatch(rb'[1-9][0-9]*\n',header),'FRAME_LENGTH')
        n=int(header);need(n<=maximum,'FRAME_BYTE_BOUND');return exact(n)
    finally:termios.tcsetattr(0,termios.TCSANOW,before)

def emit(v):sys.stdout.buffer.write(encode(v));sys.stdout.buffer.flush()
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-index',required=True);p.add_argument('--source-index-sha256',required=True)
    p.add_argument('--config',required=True);p.add_argument('--config-sha256',required=True)
    a=p.add_mutually_exclusive_group(required=True);a.add_argument('--check',action='store_true');a.add_argument('--prepare',action='store_true');a.add_argument('--run',action='store_true')
    p.add_argument('--expected-binding-sha256');args=p.parse_args()
    need(sys.platform=='linux' and sys.flags.isolated and sys.dont_write_bytecode,'ISOLATED_LINUX_ENTRY_REQUIRED')
    modules,manifest,index=load_composition(args.source_index,args.source_index_sha256)
    raw=read(args.config,1024*1024);need(desc(raw)['sha256']==args.config_sha256,'CURRENT_CONFIG_PIN')
    config=parse(raw);need(type(config)is dict and set(config)==CONFIG_FIELDS
          and config['schema']=='g132.current-root-entry-config.v1'
          and config['purpose']=='CONTROL_DATA_PUBLICATION_ONLY','CONFIG_SHAPE')
    if args.check:
        need(args.expected_binding_sha256 is None and config['state']=='UNISSUED','SOURCE_ONLY_UNISSUED_CHECK')
        need(config['installation']['index_sha256']==INDEX,'INSTALLATION_INDEX_PIN')
        s=modules['current_pro_interfaces'].CurrentSources(config['installation']['path'])
        emit({'schema':'g132.current-root-composition-check.v1','authority':'NONE','state':'UNISSUED',
              'composition_source_index':manifest,'config':desc(raw),'source_files':len(index['files']),
              'installation':s.description(),'original_effects':False,'operational_entry_permitted':False});return
    prepared=prepare(config,desc(raw),modules,manifest)
    binding=prepared['binding'];binding_pin=desc(encode(binding))
    if args.prepare:
        need(args.expected_binding_sha256 is None,'NO_PREPARATION_AUTHORITY_SUBSTITUTE')
        emit({'schema':'g132.current-root-preparation.v1','authority':'NONE','state':'PREPARED_NOT_AUTHORIZED',
              'binding':binding,'binding_descriptor':binding_pin,'provider_calls':0,'host_consumption':False});return
    need(args.expected_binding_sha256==binding_pin['sha256'],'EXACT_PREPARED_ENTRY_BINDING')
    D=modules['current_control_driver'];journal=D.Journal(prepared['journal'])
    try:
        journal.write('ENTRY_BINDING.json',encode(binding))
        result=D.run_publication(prepared['api'],prepared['sources'],prepared['received'],prepared['body'],
            prepared['parent_sha'],config['deadline_unix_ms'],journal,frame,emit,
            initial_control=prepared['initial_control'],parent_state=prepared['parent_state'])
        need(result is not None,'PUBLICATION_UNKNOWN_NO_REPLAY')
    finally:journal.close()

if __name__=='__main__':
    try:main()
    except BaseException as e:
        # Fixed source codes only; no arbitrary exceptions, paths, or bodies.
        code=str(e) if type(e)is Refusal else 'ENTRY_REFUSED_OR_UNKNOWN'
        emit({'event':'failure','status':'REFUSED_OR_UNKNOWN','code':code,'authority':'NONE',
              'automatic_retry':False,'original_consumer_invoked':False,'original_awards':[]})
        raise SystemExit(1)
