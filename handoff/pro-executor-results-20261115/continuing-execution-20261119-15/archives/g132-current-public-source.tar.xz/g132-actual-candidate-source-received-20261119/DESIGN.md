# Distinct binding to the actual unreferenced candidate

State: PARTIAL ordinary source preparation, with no source adoption or original authority.

Root explicitly selected a new generation bound to the actual provider commit `bd347ba6848e976c993ec82f5aa85d8e5964f6e1`. The admitted baseline is source packet SHA256 `6ad2944d296440917b2ad452385f3912fb944a9aa44f8d872b44c427e94764a6`; the actual candidate has the same root tree `bc3f8f1a10cbea041a6bf066acda113f3252360b` and parent `301aeecde08ba6f169bc3cd837eae6f6ad068219` as the archived offline `3f6003…` candidate.

## Chosen approach

Produce a new explicit generation from the pinned baseline. Change the host identity and candidate raw commit selection, change only the issuer's top-level `HOST_COMMIT` declaration in its exact complete source, derive its projection and full/projection descriptors, then propagate the resulting installation-index hash through the two runtime constants, unissued configuration and composition index. Keep the twelve runtime-file population and original phase source unchanged. Retain the new complete issuer body outside the runtime installation and bind its exact path in the generation's provenance record; the runtime installation continues to select the exact bounded projection.

This is the actual-returned-commit route Root authorized. A raw-3f transport attempt is outside scope. Blind replacement across historical records or hosted phase source would change unrelated identities and is rejected. The previous generation remains immutable and explicitly indexed as the baseline.

## Authority and observations

The new identity records actual unreferenced commit-object publication only. Ref publication, hosted run/job custody, source adoption, private receiving, initial/final controls and grants remain unissued. The old protected disposition stays `UNKNOWN_NO_REPLAY`. Provider tree GET 404 observations and their unknown cause remain in the received Root evidence; native remote receiving establishes the exact tree/body facts without pretending those API calls succeeded.

The author may receive public bytes, derive ordinary source and run isolated source controls. No issuer operation, original private input, protected sender/consumer, host launch, provider mutation, native dry-run or Root controller/cache action is allowed. Root will arrange genuine nonauthor review after freezing this new generation.

## Source invariants

- All 53 phase bodies, original 15-proof/Q06/current-G3 requirements and accepted-retained-M4 joins remain byte-identical.
- All original selected function AST hashes remain identical; only the issuer `HOST_COMMIT` assignment changes.
- Ten runtime files remain byte-identical; `current_pro_interfaces.py` and `current_root_entry.py` change only their installation-index constants.
- Current fixed-file populations, full-result custody, explicit model-side tool injection, initial-one/final-two paths and parent rules remain unchanged.
- The default configuration remains UNISSUED, with no context/run/deadline/body/journal selection supplied.
- Public commit identity is not native model identity or original hosted custody.

## Controls

Receive and pin Root's actual commit, all path metadata and changed-body bytes. Prove the prior selected identity differs from the actual candidate. Generate the new bytes from exact source, then check all index/body joins and unchanged declaration/function ASTs. Run the actual source-only entry check. Use bounded negative controls for old/new commit confusion, wrong parent/tree, stale installation index and the unissued operational configuration. These source/synthetic controls establish no original acceptance and make no provider call.
