"""Derive one distinct source generation; no issuer, provider or host operation."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import zipfile

BASE = Path(__file__).resolve().parent.parent
OLD = '3f6003cce29d077ad66497c30788a38af081976b'
NEW = 'bd347ba6848e976c993ec82f5aa85d8e5964f6e1'
OLD_INDEX = '6281cff522f9e13d24992816f9db35c3cff12a45875c9b13bdd6b6d3812ae50a'
TREE = 'bc3f8f1a10cbea041a6bf066acda113f3252360b'
PARENT = '301aeecde08ba6f169bc3cd837eae6f6ad068219'

def desc(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def encode(v):return (json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def load(path):return json.loads(path.read_bytes())
def ast_key(node):
    if isinstance(node,(ast.FunctionDef,ast.ClassDef)):return node.name
    if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):return node.targets[0].id
    return None

def replace_literal(raw, name, before, after):
    """Verbatim source splice at one selected literal; preserve all other bytes."""
    text=raw.decode('utf-8');assert text.isascii()
    tree=ast.parse(text);nodes=[n for n in tree.body if ast_key(n)==name]
    assert len(nodes)==1 and isinstance(nodes[0],ast.Assign)
    value=nodes[0].value;assert isinstance(value,ast.Constant) and value.value==before
    segment=ast.get_source_segment(text,value);assert segment==repr(before)
    lines=text.splitlines(keepends=True)
    start=sum(map(len,lines[:value.lineno-1]))+value.col_offset
    end=sum(map(len,lines[:value.end_lineno-1]))+value.end_col_offset
    out=(text[:start]+repr(after)+text[end:]).encode()
    new_tree=ast.parse(out)
    old_others=[ast.dump(n,include_attributes=False) for n in tree.body if ast_key(n)!=name]
    new_others=[ast.dump(n,include_attributes=False) for n in new_tree.body if ast_key(n)!=name]
    assert old_others==new_others
    return out

def project(full, plan):
    """The exact observed projection recipe: source segments, never AST reformatting."""
    text=full.decode('utf-8');nodes=[n for n in ast.parse(text).body if ast_key(n) in plan['declarations']]
    assert {ast_key(n) for n in nodes}==set(plan['declarations'])
    return ('# Exact bounded source projection; source module is never imported.\n'
            +'\n\n'.join(ast.get_source_segment(text,n) for n in nodes)+'\n').encode()

received=load(BASE/'evidence/RECEIVED_INPUTS.json')
for r in received['inputs']:
    assert desc((BASE/r['path']).read_bytes())=={k:r[k] for k in ('bytes','sha256')}
red=load(BASE/'evidence/BASELINE_BINDING_CONTROL.json')
assert red['failed']==4 and red['passed']==3 and red['observed_selected_candidate']==OLD
archive=Path(received['baseline_archive']['path'])
assert desc(archive.read_bytes())=={k:received['baseline_archive'][k] for k in ('bytes','sha256')}
with zipfile.ZipFile(archive) as z:
    manifest=load(BASE/'inputs/baseline/MANIFEST.json')
    pins={r['path']:{k:r[k] for k in ('bytes','sha256')} for r in manifest['files']}
    names=[n for n in pins if n.startswith('source/') or n.startswith('dependencies/installation/')]
    names+=['COMPOSITION_SOURCE_INDEX.json','ROOT_CONTROL_CONFIG_UNISSUED.json']
    before={n:z.read(n) for n in names}
    assert all(desc(raw)==pins[n] for n,raw in before.items())
after=dict(before)
install='dependencies/installation/'
full_before=(BASE/'inputs/issuer.full.before.py').read_bytes()
plan=json.loads(before[install+'PURE_SOURCE_PLAN.json'])
issuer_plan_before=dict(plan['issuer'])
assert desc(full_before)=={'bytes':issuer_plan_before['source_bytes'],'sha256':issuer_plan_before['source_sha256']}
assert project(full_before,issuer_plan_before)==before[install+'pure/issuer.py']
full_after=replace_literal(full_before,'HOST_COMMIT',OLD,NEW)
projection_after=project(full_after,issuer_plan_before)
assert projection_after==replace_literal(before[install+'pure/issuer.py'],'HOST_COMMIT',OLD,NEW)
function_pins={}
decls={ast_key(n):n for n in ast.parse(full_after).body if ast_key(n)}
for name,pin in issuer_plan_before['functions'].items():
    h=hashlib.sha256(ast.dump(decls[name],include_attributes=False).encode()).hexdigest()
    assert h==pin;function_pins[name]=h
plan['issuer'].update(source_bytes=len(full_after),source_sha256=desc(full_after)['sha256'],
                     projection_bytes=len(projection_after),projection_sha256=desc(projection_after)['sha256'])
after[install+'pure/issuer.py']=projection_after
after[install+'PURE_SOURCE_PLAN.json']=encode(plan)

raw_commit=(BASE/'inputs/actual-candidate/REMOTE_COMMIT.raw').read_bytes()
assert hashlib.sha1(b'commit '+str(len(raw_commit)).encode()+b'\0'+raw_commit).hexdigest()==NEW
assert desc(raw_commit)=={'bytes':919,'sha256':'be8ebb876f2b13c4fbf94facddb392412cae4a832a34b6759214826671e66a80'}
old_commit_path=install+'git-candidate/'+OLD+'.commit';new_commit_path=install+'git-candidate/'+NEW+'.commit'
assert old_commit_path in after and new_commit_path not in after
del after[old_commit_path];after[new_commit_path]=raw_commit

identity=json.loads(before[install+'HOST_IDENTITY_UNISSUED.json'])
assert identity['commit']==OLD and identity['tree']==TREE and identity['parent']==PARENT
identity.update(commit=NEW,
    identity_kind='ACTUAL_UNREFERENCED_PROVIDER_COMMIT_OBJECT_NOT_HOST_LAUNCH',
    provider_publication_observed=True,
    provider_publication_scope='COMMIT_OBJECT_ONLY_UNREFERENCED',
    reference_publication_observed=False,host_launch_observed=False,
    historical_candidate_identity=OLD,
    actual_candidate_receiving_sha256='64597825e4fb66085a55ae1ff8f6f622577cde56b35e0de724d71b5e578db982')
assert identity['state']=='UNISSUED' and identity['authority']=='NONE' and identity['source_adoption_issued'] is False
assert identity['original_awards']==[] and identity['automatic_retry'] is False
after[install+'HOST_IDENTITY_UNISSUED.json']=encode(identity)
index=json.loads(before[install+'SOURCE_INDEX.json'])
assert desc(before[install+'SOURCE_INDEX.json'])['sha256']==OLD_INDEX
index['files']={n.removeprefix(install):desc(raw) for n,raw in after.items() if n.startswith(install) and n!=install+'SOURCE_INDEX.json'}
assert len(index['files'])==157
index['host_identity']=desc(after[install+'HOST_IDENTITY_UNISSUED.json'])
index['pure_plan']=desc(after[install+'PURE_SOURCE_PLAN.json'])
assert index['phase']==desc(after[install+'phase/PHASE.json'])
after[install+'SOURCE_INDEX.json']=encode(index)
new_index=desc(after[install+'SOURCE_INDEX.json'])['sha256']
assert new_index!=OLD_INDEX
for name,literal in [('current_pro_interfaces.py','INDEX_SHA256'),('current_root_entry.py','INDEX')]:
    path='source/'+name;after[path]=replace_literal(before[path],literal,OLD_INDEX,new_index)

config_raw=before['ROOT_CONTROL_CONFIG_UNISSUED.json']
config=json.loads(config_raw);old_path=config['installation']['path']
assert config['state']=='UNISSUED' and config['installation']['index_sha256']==OLD_INDEX
assert config_raw.count(OLD_INDEX.encode())==1 and config_raw.count(old_path.encode())==1
after['ROOT_CONTROL_CONFIG_UNISSUED.json']=config_raw.replace(OLD_INDEX.encode(),new_index.encode()).replace(old_path.encode(),str(BASE/'dependencies/installation').encode())
new_config=json.loads(after['ROOT_CONTROL_CONFIG_UNISSUED.json'])
assert {k:v for k,v in config.items() if k!='installation'}=={k:v for k,v in new_config.items() if k!='installation'}

composition=json.loads(before['COMPOSITION_SOURCE_INDEX.json'])
assert len(composition['files'])==12 and composition['installation_index_sha256']==OLD_INDEX
composition['installation_index_sha256']=new_index
composition['files']={name:desc(after['source/'+name]) for name in composition['files']}
after['COMPOSITION_SOURCE_INDEX.json']=encode(composition)
phase_files=[n for n in before if n.startswith(install+'phase/')]
assert len([n for n in phase_files if '/tree/' in n])==53
assert all(before[n]==after[n] for n in phase_files)
unchanged_runtime=[n for n in before if n.startswith('source/') and before[n]==after[n]]
assert len(unchanged_runtime)==10

delta=[];patch=[]
for name in sorted(set(before)|set(after)):
    old=before.get(name);new=after.get(name)
    if old==new:continue
    delta.append({'path':name,'before':None if old is None else desc(old),'after':None if new is None else desc(new)})
    patch.extend(difflib.unified_diff([] if old is None else old.decode().splitlines(keepends=True),
                                   [] if new is None else new.decode().splitlines(keepends=True),
                                   fromfile='baseline/'+name,tofile='new-generation/'+name))
patch.extend(difflib.unified_diff(full_before.decode().splitlines(keepends=True),full_after.decode().splitlines(keepends=True),fromfile='inputs/issuer.full.before.py',tofile='complete-sources/issuer.py'))

for name,raw in sorted(after.items()):
    path=BASE/name;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f:f.write(raw)
    path.chmod(0o600 if name=='ROOT_CONTROL_CONFIG_UNISSUED.json' else 0o444)
full_path=BASE/'complete-sources/issuer.py';full_path.parent.mkdir()
with full_path.open('xb') as f:f.write(full_after)
full_path.chmod(0o444)
with (BASE/'SOURCE_DIFF.patch').open('x') as f:f.writelines(patch)

provenance={'schema':'g132.actual-candidate-source-generation.v1','authority':'NONE','state':'UNISSUED',
    'actual_candidate':NEW,'historical_candidate':OLD,'tree':TREE,'parent':PARENT,
    'before_installation_index':desc(before[install+'SOURCE_INDEX.json']),
    'after_installation_index':desc(after[install+'SOURCE_INDEX.json']),
    'composition_source_index':desc(after['COMPOSITION_SOURCE_INDEX.json']),
    'unissued_config':desc(after['ROOT_CONTROL_CONFIG_UNISSUED.json']),
    'complete_issuer':{'before':{'path':'inputs/issuer.full.before.py',**desc(full_before)},'after':{'path':'complete-sources/issuer.py',**desc(full_after)},
                       'changed_declarations':['HOST_COMMIT'],'functions_unchanged':function_pins},
    'projection_recipe':'Exact source segments of selected declarations, joined with two newlines and the existing fixed projection header; full source never imported.',
    'prior_projection_precheck_failure':'evidence/PROJECTION_REGENERATION_PRECHECK.json',
    'historical_outer_manifest_role':'SOURCE_INDEX.outer_manifest_sha256 remains the unchanged original public-source provenance anchor; it is not this new generation manifest or source adoption.',
    'installation_indexed_files':157,'runtime_indexed_files':12,'unchanged_runtime_files':unchanged_runtime,
    'hosted_phase_members_unchanged':53,'all_nonissuer_source_plan_entries_unchanged':True,
    'current_source_delta':delta,'outputs':{n:desc(raw) for n,raw in after.items()},
    'complete_source_issuer_executed':False,'issuer_derive_called':False,'provider_calls':0,'host_launch':False,
    'source_adoption':False,'all_grants':'UNISSUED','protected_operation':'UNKNOWN_NO_REPLAY'}
with (BASE/'GENERATION_PROVENANCE.json').open('x') as f:json.dump(provenance,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({'state':'GENERATED_UNISSUED_SOURCE_NOT_YET_VERIFIED','actual_candidate':NEW,'historical_candidate':OLD,
                  'installation_index':provenance['after_installation_index'],'composition_index':provenance['composition_source_index'],
                  'complete_issuer':provenance['complete_issuer']['after'],'projection':desc(projection_after),
                  'changed_current_paths':len(delta),'unchanged_runtime_files':len(unchanged_runtime),'phase_members_unchanged':53,
                  'provider_calls':0,'issuer_effects':False},indent=2))
