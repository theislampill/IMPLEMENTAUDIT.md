"""Receive only explicitly admitted source and public candidate data."""
from pathlib import Path
import hashlib
import json
import zipfile

BASE = Path(__file__).resolve().parent.parent
ROOT = BASE.parent
OLD = '3f6003cce29d077ad66497c30788a38af081976b'
NEW = 'bd347ba6848e976c993ec82f5aa85d8e5964f6e1'
TREE = 'bc3f8f1a10cbea041a6bf066acda113f3252360b'
PARENT = '301aeecde08ba6f169bc3cd837eae6f6ad068219'

def desc(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def oid(kind, raw):
    return hashlib.sha1(kind.encode() + b' ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

records = []
def retain(name, raw, origin):
    path = BASE / 'inputs' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as f:
        f.write(raw)
    path.chmod(0o444)
    records.append({'path': 'inputs/' + name, **desc(raw), 'origin': origin})

archive = ROOT / 'g132-current-root-entry-preparation/G132_CURRENT_ROOT_ENTRY_SOURCE_PACKET.zip'
archive_raw = archive.read_bytes()
assert desc(archive_raw) == {'bytes': 1738259, 'sha256': '6ad2944d296440917b2ad452385f3912fb944a9aa44f8d872b44c427e94764a6'}
with zipfile.ZipFile(archive) as z:
    manifest_raw = z.read('MANIFEST.json')
    assert desc(manifest_raw) == {'bytes': 73282, 'sha256': 'a93a95ca630ed41b0b733db1f4e3bc6bc2386cd775f93e60ddad2ab47fa97768'}
    pins = {r['path']: {k:r[k] for k in ('bytes','sha256')} for r in json.loads(manifest_raw)['files']}
    selected = ['COMPOSITION_SOURCE_INDEX.json', 'ROOT_CONTROL_CONFIG_UNISSUED.json',
                'source/current_pro_interfaces.py', 'source/current_root_entry.py',
                'dependencies/installation/HOST_IDENTITY_UNISSUED.json',
                'dependencies/installation/PURE_SOURCE_PLAN.json',
                'dependencies/installation/SOURCE_INDEX.json',
                'dependencies/installation/pure/issuer.py',
                'dependencies/installation/git-candidate/' + OLD + '.commit']
    retain('baseline/MANIFEST.json', manifest_raw, {'archive': str(archive), 'archive_sha256': desc(archive_raw)['sha256'], 'member': 'MANIFEST.json'})
    for name in selected:
        raw = z.read(name); assert desc(raw) == pins[name]
        retain('baseline/' + name, raw, {'archive': str(archive), 'archive_sha256': desc(archive_raw)['sha256'], 'member': name})
    old_installation = {name.removeprefix('dependencies/installation/'):z.read(name) for name in pins if name.startswith('dependencies/installation/')}
    for name, raw in old_installation.items():
        assert desc(raw) == pins['dependencies/installation/' + name]

issuer_path = ROOT / 'g132-recovered-interface-continuation/derived-exact/issuer.py'
issuer = issuer_path.read_bytes()
assert desc(issuer) == {'bytes': 8932, 'sha256': '609b0ec3b77a0e1d07bc105d20675518cc07f653b222c78e045c61ca547634cf'}
retain('issuer.full.before.py', issuer, {'path': str(issuer_path), 'provenance': 'Earlier exact deterministic public-source derivation; no historical execution or review claim.'})

receiver_archive = ROOT / 'g132-selected-host-object-receiving/G132_SELECTED_HOST_OBJECT_RECEIVING.zip'
receiver_raw = receiver_archive.read_bytes()
assert desc(receiver_raw) == {'bytes':1128357,'sha256':'8728bd73119c877694e14ed5dd2ba55262e99874cbadae68565a15b7872bcd1c'}
with zipfile.ZipFile(receiver_archive) as z:
    rpins = {r['path']:{k:r[k] for k in ('bytes','sha256')} for r in json.loads(z.read('MANIFEST.json'))['files']}
    for name in ['evidence/TREE_PATH_CENSUS_COMPLETE.json','evidence/CHANGED_OBJECTS_COMPLETE.json','evidence/AUTHORITATIVE_LINEAGE.json','RESULT.json']:
        raw = z.read(name); assert desc(raw) == rpins[name]
        retain('selected-host/' + name, raw, {'archive':str(receiver_archive),'archive_sha256':desc(receiver_raw)['sha256'],'member':name})

candidate_dir = ROOT / 'g132-api-candidate-preparation-20261119'
root_files = sorted([p for p in candidate_dir.iterdir() if p.is_file() and (p.suffix == '.json' or p.name in ('REMOTE_COMMIT.raw','REMOTE_TREE_LEAVES.raw','REMOTE_CHANGED_BLOBS.batch'))])
for path in root_files:
    retain('actual-candidate/' + path.name, path.read_bytes(), {'path':str(path),'custody':'Root-provided public source/object receiving; no new provider call by this lane'})
actual = lambda name:(BASE / 'inputs/actual-candidate' / name).read_bytes()
verified_raw = actual('REMOTE_VERIFIED.json')
assert desc(verified_raw) == {'bytes':8647,'sha256':'64597825e4fb66085a55ae1ff8f6f622577cde56b35e0de724d71b5e578db982'}
verified = json.loads(verified_raw)
raw = actual('REMOTE_COMMIT.raw')
assert desc(raw) == {'bytes':919,'sha256':'be8ebb876f2b13c4fbf94facddb392412cae4a832a34b6759214826671e66a80'} and oid('commit',raw) == NEW
lines = raw.split(b'\n\n',1)[0].splitlines()
assert [l[5:].decode() for l in lines if l.startswith(b'tree ')] == [TREE]
assert [l[7:].decode() for l in lines if l.startswith(b'parent ')] == [PARENT]
assert [l[7:].decode() for l in raw.splitlines() if l.startswith(b'parent ')] == [PARENT]

first_raw = json.loads(actual('REMOTE_FIRST_RAW_RECEIVING.json'))
for command in first_raw:
    assert command['returncode'] == 0 and not command['stderr']
    body = actual(command['stdout_file'])
    assert desc(body) == {'bytes':command['stdout_bytes'],'sha256':command['stdout_sha256']}
raw_leaves = actual('REMOTE_TREE_LEAVES.raw')
assert raw_leaves.endswith(b'\0')
leaves = []
for record in raw_leaves[:-1].split(b'\0'):
    meta,path = record.split(b'\t',1); mode,kind,h = meta.decode().split(); path = path.decode('utf-8')
    assert mode in ('100644','100755') and kind == 'blob' and all(part not in ('','.','..') for part in path.split('/'))
    leaves.append({'mode':mode,'kind':kind,'oid':h,'path':path})
assert len(leaves) == len({r['path'] for r in leaves}) == 1819
prior_census = json.loads((BASE/'inputs/selected-host/evidence/TREE_PATH_CENSUS_COMPLETE.json').read_bytes())
assert sorted(leaves,key=lambda r:r['path']) == sorted([r for r in prior_census['candidate'] if r['kind']=='blob'],key=lambda r:r['path'])
nodes = {}
for row in leaves:
    node = nodes; parts = row['path'].split('/')
    for part in parts[:-1]:
        node = node.setdefault(part,{})
        assert isinstance(node,dict)
    assert parts[-1] not in node; node[parts[-1]] = (row['mode'], row['oid'])
def tree_id(node):
    rows=[]
    for name,item in node.items():
        if isinstance(item,tuple):
            rows.append((name,item[0],item[1]))
        else:
            rows.append((name,'40000',tree_id(item)))
    rows.sort(key=lambda r:r[0].encode()+(b'/' if r[1]=='40000' else b''))
    body=b''.join(mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(h) for name,mode,h in rows)
    return oid('tree',body)
assert tree_id(nodes) == TREE

changed = json.loads((BASE/'inputs/selected-host/evidence/CHANGED_OBJECTS_COMPLETE.json').read_bytes())['changes']
command = json.loads(actual('REMOTE_CHANGED_BLOBS_COMMAND.json'))
assert command['returncode'] == 0 and command['stderr'] == ''
batch = actual('REMOTE_CHANGED_BLOBS.batch')
assert desc(batch) == {'bytes':command['stdout_bytes'],'sha256':command['stdout_sha256']}
blob_bodies = {}; pos = 0
while pos < len(batch):
    end=batch.index(b'\n',pos); h,kind,size=batch[pos:end].decode().split(); size=int(size)
    body=batch[end+1:end+1+size]; pos=end+1+size
    assert batch[pos:pos+1] == b'\n'; pos+=1
    assert kind=='blob' and len(body)==size and oid('blob',body)==h and h not in blob_bodies
    blob_bodies[h]=body
assert set(blob_bodies)=={r['after']['oid'] for r in changed} and len(blob_bodies)==23
assert list(blob_bodies)==command['stdin_utf8'].splitlines()
assert sum(map(len,blob_bodies.values()))==738854
for row in changed:
    body=blob_bodies[row['after']['oid']]
    assert desc(body)==row['new_body_descriptor']
    assert body==old_installation['phase/tree/'+row['path']]
assert verified['candidate_leaf_count']==1819 and verified['changed_leaves']==23 and verified['unchanged_parent_leaves']==1796
old_identity = json.loads(old_installation['HOST_IDENTITY_UNISSUED.json'])
assert old_identity['commit']==OLD and old_identity['tree']==TREE and old_identity['parent']==PARENT

result={'schema':'g132.actual-candidate-rebind-input-receiving.v1','authority':'NONE','state':'PARTIAL_INPUTS_RECEIVED',
        'baseline_archive':{'path':str(archive),**desc(archive_raw)},'selected_host_archive':{'path':str(receiver_archive),**desc(receiver_raw)},
        'actual_candidate':NEW,'historical_candidate':OLD,'same_tree_and_parent':True,'same_identity':False,
        'remote_raw_commit':desc(raw),'full_leaf_census':1819,'reconstructed_tree':TREE,'changed_bodies':23,'changed_body_bytes':738854,
        'unchanged_parent_leaves':1796,'target_source_executed':False,'provider_calls':0,'protected_operation':'UNKNOWN_NO_REPLAY','all_grants':'UNISSUED','inputs':records}
out=BASE/'evidence/RECEIVED_INPUTS.json'
with out.open('x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k!='inputs'},indent=2))
