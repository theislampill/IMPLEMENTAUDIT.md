(() => {
  'use strict';
  const REPO='theislampill/IMPLEMENTAUDIT.md';
  const TOOL='mcp__codex_apps__github_fetch';
  const MAX=4*1024*1024;
  const CONCLUSIONS=[null,'success','failure','cancelled','timed_out','action_required','neutral','skipped','stale','startup_failure'];
  const need=(v,c)=>{if(!v)throw Error(c);};
  const object=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
  const exact=(v,keys)=>object(v)&&Object.keys(v).sort().join('|')===[...keys].sort().join('|');
  const hex=(v,n)=>typeof v==='string'&&new RegExp('^[0-9a-f]{'+n+'}$').test(v);
  const integer=(v,min=0,max=Number.MAX_SAFE_INTEGER)=>Number.isSafeInteger(v)&&v>=min&&v<=max;
  function utf8(text){
    const out=[];
    for(const ch of text){let n=ch.codePointAt(0);if(n>=0xd800&&n<=0xdfff)n=0xfffd;
      if(n<128)out.push(n);else if(n<2048)out.push(192|n>>6,128|n&63);
      else if(n<65536)out.push(224|n>>12,128|n>>6&63,128|n&63);
      else out.push(240|n>>18,128|n>>12&63,128|n>>6&63,128|n&63);
    }return out;
  }
  function sha256(text){
    const bytes=utf8(text),bits=bytes.length*8;bytes.push(128);while(bytes.length%64!==56)bytes.push(0);
    for(const x of [Math.floor(bits/4294967296),bits>>>0])for(let s=24;s>=0;s-=8)bytes.push(x>>>s&255);
    const K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
    const H=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19],rot=(n,s)=>(n>>>s)|(n<<(32-s));
    for(let off=0;off<bytes.length;off+=64){const w=[];for(let i=0;i<16;i++)w[i]=(bytes[off+4*i]<<24|bytes[off+4*i+1]<<16|bytes[off+4*i+2]<<8|bytes[off+4*i+3])>>>0;
      for(let i=16;i<64;i++){const a=w[i-15],b=w[i-2];w[i]=(w[i-16]+(rot(a,7)^rot(a,18)^(a>>>3))+w[i-7]+(rot(b,17)^rot(b,19)^(b>>>10)))>>>0;}
      let [a,b,c,d,e,f,g,h]=H;for(let i=0;i<64;i++){const t1=(h+(rot(e,6)^rot(e,11)^rot(e,25))+((e&f)^(~e&g))+K[i]+w[i])>>>0,t2=((rot(a,2)^rot(a,13)^rot(a,22))+((a&b)^(a&c)^(b&c)))>>>0;h=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0;}
      for(const [i,x] of [a,b,c,d,e,f,g,h].entries())H[i]=(H[i]+x)>>>0;
    }return H.map(x=>x.toString(16).padStart(8,'0')).join('');
  }
  function descriptor(text){need(typeof text==='string','STRING_BYTES_REQUIRED');return {bytes:utf8(text).length,sha256:sha256(text)};}
  function canonical(value,depth=0){
    need(depth<=80,'JSON_DEPTH');
    if(value===null||typeof value==='string'||typeof value==='boolean')return JSON.stringify(value);
    if(typeof value==='number'){need(Number.isFinite(value),'NONFINITE_JSON');return JSON.stringify(value);}
    if(Array.isArray(value))return '['+value.map(x=>canonical(x,depth+1)).join(',')+']';
    need(object(value),'JSON_ONLY');return '{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+canonical(value[k],depth+1)).join(',')+'}';
  }
  const same=(a,b)=>canonical(a)===canonical(b);
  function strict(text){
    need(typeof text==='string'&&utf8(text).length<=MAX,'JSON_BOUND');let at=0;
    const ws=()=>{while(/[\x20\t\r\n]/.test(text[at]||'!'))at++;};
    function string(){const begin=at;need(text[at++]==='"','JSON_STRING');while(at<text.length){const c=text[at++];if(c==='"')return JSON.parse(text.slice(begin,at));if(c==='\\')at++;}throw Error('JSON_STRING');}
    function value(depth){need(depth<=80,'JSON_DEPTH');ws();const c=text[at];
      if(c==='"')return string();
      if(c==='{'){at++;const out=Object.create(null);ws();if(text[at]==='}'){at++;return out;}for(;;){ws();const key=string();need(!Object.prototype.hasOwnProperty.call(out,key),'DUPLICATE_JSON_KEY');ws();need(text[at++]===':','JSON_COLON');out[key]=value(depth+1);ws();const sep=text[at++];if(sep==='}')return out;need(sep===',','JSON_OBJECT');}}
      if(c==='['){at++;const out=[];ws();if(text[at]===']'){at++;return out;}for(;;){out.push(value(depth+1));ws();const sep=text[at++];if(sep===']')return out;need(sep===',','JSON_ARRAY');}}
      for(const [word,result] of [['true',true],['false',false],['null',null]])if(text.slice(at,at+word.length)===word){at+=word.length;return result;}
      const m=/-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/.exec(text.slice(at));need(m&&m.index===0,'JSON_NUMBER');at+=m[0].length;const n=Number(m[0]);need(Number.isFinite(n),'JSON_NONFINITE');return n;
    }
    const out=value(0);ws();need(at===text.length,'JSON_TRAILING');return out;
  }
  return Object.freeze({descriptor,canonical,strict});
})()
