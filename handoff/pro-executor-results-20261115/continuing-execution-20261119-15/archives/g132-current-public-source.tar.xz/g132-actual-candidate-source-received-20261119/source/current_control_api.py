"""New public-data control adapter for the current connected GitHub capability.

The original selected decision/parent/publication functions remain in
publication_owner.py. Only immutable file transport/readback is replaced here.
No tool dispatch, source adoption, Root issuer authentication or grant occurs.
This adapter deliberately has no tools-phase or original-consumer entry point.
"""
import hashlib
import re

import publication_owner as O
import file_readback as F

FETCH = 'mcp__codex_apps__github_fetch'
FILE = 'mcp__codex_apps__github_fetch_file'
REPOSITORY = 'theislampill/IMPLEMENTAUDIT.md'
BRANCH = 'pro/dg16-g1-g3-control-32-20261114'
INITIAL = 'qualification/dg16-r5-g3/ROOT_DECISION.json'
FINAL = 'qualification/dg16-r5-g3/ORIGINAL_DECISION.json'


def need(value, code):
    if not value:
        raise ValueError(code)


def bounded_plan(plan):
    need(type(plan) is dict and plan.get('schema') == 'dg16.root-control-publication-plan.v1'
         and plan.get('authority') == 'NONE' and plan.get('phase') in ('g3_initial', 'g3_final'), 'CURRENT_G3_DATA_PLAN_ONLY')
    need(plan.get('context', {}).get('repository') == REPOSITORY and plan.get('branch') == BRANCH,
         'EXACT_G132_PUBLICATION_SCOPE')
    need(type(plan.get('parent_sha')) is str and re.fullmatch('[0-9a-f]{40}', plan['parent_sha'])
         and type(plan.get('expected_tree_sha')) is str and re.fullmatch('[0-9a-f]{40}', plan['expected_tree_sha']),
         'EXACT_CONTROL_GIT_SELECTION')
    required = {INITIAL} if plan['phase'] == 'g3_initial' else {INITIAL, FINAL}
    need(type(plan.get('files')) is dict and set(plan['files']) == required, 'EXACT_G132_CONTROL_PATHS')
    bodies = {}
    for path, row in plan['files'].items():
        need(type(row) is dict and set(row) == {'body_utf8', 'bytes', 'sha256', 'git_blob_sha'}
             and type(row['body_utf8']) is str and type(row['bytes']) is int and 0 < row['bytes'] <= 65536,
             'EXACT_CONTROL_FILE_DESCRIPTOR')
        body = row['body_utf8'].encode('utf-8')
        need(O.desc(body) == {'bytes': row['bytes'], 'sha256': row['sha256']}
             and O.git_object('blob', body) == row['git_blob_sha'], 'CONTROL_SELECTED_BODY_CHANGED')
        bodies[path] = body
    need(O.fixed_tree(bodies) == plan['expected_tree_sha'], 'CONTROL_SELECTED_TREE_CHANGED')
    return bodies


def control_read_plan(plan, published_commit):
    """Inert typed calls; paths are pinned to the actual new commit, never a ref."""
    bounded_plan(plan)
    need(type(published_commit) is str and re.fullmatch('[0-9a-f]{40}', published_commit), 'ACTUAL_PUBLISHED_COMMIT_REQUIRED')
    prefix = 'https://api.github.com/repos/' + REPOSITORY
    ref_url = prefix + '/git/ref/heads/' + BRANCH
    calls = [dict(kind='ref', tool=FETCH, arguments={'url': ref_url}),
             dict(kind='commit', tool=FETCH, arguments={'url': prefix + '/git/commits/' + published_commit}),
             dict(kind='tree', tool=FETCH, arguments={'url': prefix + '/git/trees/' + plan['expected_tree_sha'] + '?recursive=1'})]
    for i, path in enumerate(sorted(plan['files'])):
        calls.append(dict(kind='file' + str(i), tool=FILE, arguments=dict(repository_full_name=REPOSITORY,
                     path=path, ref=published_commit, encoding='base64')))
    calls.append(dict(kind='closing_ref', tool=FETCH, arguments={'url': ref_url}))
    return calls


def validate_read_result(call, raw, plan, published_commit):
    calls = control_read_plan(plan, published_commit)
    need(call in calls, 'EXACT_SELECTED_READ_CALL')
    if call['tool'] == FETCH:
        return O.unwrap_control(raw, call['arguments']['url'])
    path = call['arguments']['path']
    row = plan['files'][path]
    selection = {k: row[k] for k in ('bytes', 'sha256', 'git_blob_sha')}
    body = F.decode_file_result(raw, {'tool': call['tool'], 'arguments': call['arguments']}, selection, 65536)
    need(body == row['body_utf8'].encode('utf-8'), 'ACTUAL_CONTROL_FILE_BODY')
    return body


def verify_publication(plan, published_commit, results):
    """Verify public transport only. No original decision is accepted here.

    Keep complete actual wrappers separate from decoded file bytes. Never build
    a synthetic provider blob object or represent file decoding as a provider GET.
    """
    bodies = bounded_plan(plan)
    calls = control_read_plan(plan, published_commit)
    need(type(results) is dict and set(results) == {r['kind'] for r in calls}
         and all(type(v) is bytes for v in results.values())
         and sum(map(len, results.values())) <= O.MAX_JOURNAL, 'CONTROL_FULL_RESULT_POPULATION')
    got = {c['kind']: validate_read_result(c, results[c['kind']], plan, published_commit) for c in calls}
    provider = {k: v for k, v in got.items() if not k.startswith('file')}
    need(sum(len(O.encode(v)) for v in provider.values()) <= 1024**2, 'CONTROL_METADATA_AGGREGATE')
    ref, commit, tree = (provider[k] for k in ('ref', 'commit', 'tree'))
    need(ref == provider['closing_ref'] and ref.get('ref') == 'refs/heads/' + BRANCH
         and ref.get('object', {}).get('type') == 'commit' and ref['object'].get('sha') == published_commit
         and commit.get('sha') == published_commit and commit.get('tree', {}).get('sha') == plan['expected_tree_sha']
         and type(commit.get('parents')) is list and len(commit['parents']) == 1
         and commit['parents'][0].get('sha') == plan['parent_sha'], 'CONTROL_COMMIT_PARENT_REF_JOIN')
    need(tree.get('sha') == plan['expected_tree_sha'] and tree.get('truncated') is False
         and type(tree.get('tree')) is list, 'CONTROL_TREE_BOUND')
    expected, prefixes = {}, set()
    for path, row in plan['files'].items():
        expected[path] = ('blob', '100644', row['git_blob_sha'], row['bytes'])
        parts = path.split('/')
        prefixes.update('/'.join(parts[:i]) for i in range(1, len(parts)))
    rows = {}
    for row in tree['tree']:
        need(type(row) is dict, 'CONTROL_TREE_ROW')
        path = row.get('path')
        need(type(path) is str and path not in rows, 'CONTROL_TREE_DUPLICATE')
        rows[path] = row
    need(set(rows) == set(expected) | prefixes, 'CONTROL_EXACT_TREE_POPULATION')
    for path, row in rows.items():
        if path in prefixes:
            need(row.get('type') == 'tree' and row.get('mode') == '040000' and type(row.get('sha')) is str
                 and re.fullmatch('[0-9a-f]{40}', row['sha']), 'CONTROL_TREE_DIRECTORY')
        else:
            need((row.get('type'), row.get('mode'), row.get('sha'), row.get('size')) == expected[path], 'CONTROL_EXACT_LEAF')
    for i, path in enumerate(sorted(plan['files'])):
        need(got['file' + str(i)] == bodies[path], 'ACTUAL_CONTROL_FILE_BODY')
    return dict(schema='g132.current-base64-control-transport-receiving.v1', authority='NONE',
                state='UNISSUED_TRANSPORT_RECEIVING', phase=plan['phase'], published_commit=published_commit,
                control_parent=plan['parent_sha'], control_tree=plan['expected_tree_sha'],
                files={p: O.desc(b) for p, b in sorted(bodies.items())},
                full_actual_tool_results={k: O.desc(v) for k, v in sorted(results.items())},
                file_transport='ACTUAL_FETCH_FILE_BASE64_AT_IMMUTABLE_COMMIT',
                issuer_authenticated=False, host_consumption_observed=False, effect_grant=False, original_awards=[])


class CurrentControlAPI:
    """Facade over the exact current receiving object, never an issuer.

    Root must supply the already selected, reviewed installation object. Current
    receiving membership is rechecked on every owner predicate invocation.
    No historic body, receipt text or fixture can enter its checked-receiving set.
    """
    MAX_RESULT = O.MAX_RESULT
    desc = staticmethod(O.desc)
    parse = staticmethod(O.parse)
    encode = staticmethod(O.encode)
    result_sha = staticmethod(O.result_sha)
    control_read_plan = staticmethod(control_read_plan)
    validate_read_result = staticmethod(validate_read_result)

    def __init__(self, sources):
        self.sources = sources
        need(callable(getattr(sources, '_require_received', None)) and callable(getattr(sources, 'context', None)),
             'CURRENT_SOURCE_RECEIVING_INTERFACE_REQUIRED')

    def checked(self, sources, received):
        need(sources is self.sources and received['phase'] in ('g3_initial', 'g3_final'), 'EXACT_CURRENT_G3_SOURCE_OBJECT')
        sources._require_received(received)
        sources.context(received['context'])

    def requirements(self, sources, received):
        self.checked(sources, received)
        return O.requirements(sources, received)

    def validate_control(self, sources, received, body, now_ms):
        self.checked(sources, received)
        # This is the unchanged owner function: final validation retains all M4
        # bodies and calls the actual full original request/decision predicates.
        return O.validate_control(sources, received, body, now_ms)

    def control_parent(self, received, observation_raw, host_publication=None):
        self.checked(self.sources, received)
        return O.control_parent(self.sources, received, observation_raw, host_publication)

    def publication_plan(self, sources, received, body, parent_sha, now_ms, initial_control=None, parent_state=None):
        self.checked(sources, received)
        if initial_control is not None:
            self.checked(sources, initial_control['receiving'])
        plan = O.publication_plan(sources, received, body, parent_sha, now_ms, initial_control, parent_state)
        bounded_plan(plan)
        return plan

    def publication_call(self, plan, previous_results):
        bounded_plan(plan)
        return O.publication_call(plan, previous_results)

    def receive_control(self, sources, received, plan, published_commit, results, body, now_ms):
        self.validate_control(sources, received, body, now_ms)
        need(plan['receiving'] == O.desc(O.encode(received['receipt'])) and plan['context'] == received['context'],
             'CONTROL_RECEIVING_JOIN')
        requirement = self.requirements(sources, received)
        need(requirement['path'] in plan['files'] and plan['files'][requirement['path']]['sha256'] == O.sha(body),
             'ACTUAL_CONTROL_BODY_JOIN')
        transport = verify_publication(plan, published_commit, results)
        return dict(schema='g132.current-control-owner-and-transport-receiving.v1', authority='NONE',
                    phase=received['phase'], context=received['context'], root_body=O.desc(body),
                    artifact_receiving=plan['receiving'], validated_unix_ms=now_ms,
                    transport=transport, authentication_boundary=O.AUTH,
                    root_issuer_authentication_required=True, host_consumption_observed=False,
                    effect_grant=False, original_awards=[])
