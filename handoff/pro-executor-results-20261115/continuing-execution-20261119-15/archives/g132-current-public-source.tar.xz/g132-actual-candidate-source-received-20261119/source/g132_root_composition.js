/* New inert functions.exec composition. Loading does not invoke a tool.
 * Root must receive these exact source bytes and supply its actual tools and
 * external live admission/no-replay capabilities. No Python tool fiction.
 * This controls public data publication only; it never launches the G1/G3 host.
 */
((injected)=>{
  'use strict';
  const {tools,codec,bridgeFactory,linux}=injected;
  const need=(v,c)=>{if(!v)throw Error(c);};
  const same=(a,b)=>codec.canonical(a)===codec.canonical(b);
  const clone=v=>codec.strict(codec.canonical(v));
  const hex=v=>typeof v==='string'&&/^[0-9a-f]{64}$/.test(v);
  const path=v=>typeof v==='string'&&v.startsWith('/')&&!/[\x00-\x1f\x7f]/.test(v);
  need(typeof bridgeFactory==='function'&&tools&&codec&&linux,'EXPLICIT_ACTUAL_COMPOSITION_CAPABILITIES');
  const bridge=bridgeFactory({tools,codec,linux});
  const names=Object.freeze({
    fetch:'mcp__codex_apps__github_fetch',file:'mcp__codex_apps__github_fetch_file',
    tree:'mcp__codex_apps__github_create_tree',commit:'mcp__codex_apps__github_create_commit',
    initialRef:'mcp__codex_apps__github_create_branch',positiveRef:'mcp__codex_apps__github_update_ref',
    process:'exec_command',frame:'write_stdin'});
  function selected(value){
    const x=clone(value);
    need(x.schema==='g132.current-model-root-selection.v1'&&x.state==='ROOT_SELECTED_FOR_CURRENT_CONTROL'
      &&x.authority==='NONE'&&['tools','g3_initial','g3_final'].includes(x.phase),
      'CURRENT_ROOT_SELECTION_REQUIRED');
    for(const k of ['entry','source_index','config'])need(path(x[k]?.path)&&hex(x[k]?.sha256),
      'EXACT_SELECTED_SOURCE_AND_CONFIG');
    need(path(x.exchange_root)&&Number.isSafeInteger(x.deadline_ms)&&Date.now()<x.deadline_ms
      &&x.deadline_ms===x.operator_spec?.expires_ms,'ORIGINAL_COMPOSITION_DEADLINE');
    // The digest label alone is not reviewed source or live authority. Actual
    // external admission receives the complete spec and physical Linux identity.
    need(x.operator_spec.operator_source?.index_sha256===x.source_index.sha256,
      'CURRENT_COMPOSITION_SOURCE_JOIN');
    return x;
  }
  function processSelection(x,mode,binding){
    const args=['--source-index',x.source_index.path,'--source-index-sha256',x.source_index.sha256,
      '--config',x.config.path,'--config-sha256',x.config.sha256,mode];
    if(mode==='--run')args.push('--expected-binding-sha256',binding);
    return {path:x.entry.path,sha256:x.entry.sha256,args,exchange_root:x.exchange_root,deadline_ms:x.deadline_ms};
  }
  async function prepare(selection,admit){
    const x=selected(selection),process=processSelection(x,'--prepare');
    const spec={...x.operator_spec,role:'control-preparation',stage:x.phase,process,
      composition_selection:clone(x)};
    return bridge.prepareControl(spec,admit,process);
  }
  async function publish(selection,actualPreparation,admit){
    const x=selected(selection);
    need(actualPreparation?.status==='TRANSPORT_COMPLETE_REQUIRES_ORIGINAL_RECEIVING'
      &&actualPreparation.role==='control-preparation','ACTUAL_PREPARATION_RECEIVING_REQUIRED');
    const p=actualPreparation.result?.preparation,b=p?.binding;
    need(p?.schema==='g132.current-root-preparation.v1'&&p.state==='PREPARED_NOT_AUTHORIZED'
      &&p.authority==='NONE'&&b?.schema==='g132.current-root-executable-binding.v1'&&b.authority==='NONE'
      &&b.config?.sha256===x.config.sha256&&b.composition_source_index?.sha256===x.source_index.sha256
      &&b.phase===x.phase&&b.deadline_unix_ms===x.deadline_ms
      &&same(b.model_context,x.operator_spec.context)&&b.live_external_admission_required===true
      &&b.source_adoption_issued===false&&b.original_consumer_invoked===false,
      'EXACT_CURRENT_PREPARATION_BINDING');
    // Python's binding encoding is canonical ASCII JSON plus newline. Pass its
    // exact binding descriptor back to the same entry; the entry recomputes it.
    need(hex(p.binding_descriptor?.sha256)&&Number.isSafeInteger(p.binding_descriptor?.bytes),
      'EXACT_PREPARATION_BINDING_DESCRIPTOR');
    for(const key of ['fetch','file','tree','commit',x.phase==='g3_initial'?'initialRef':'positiveRef'])
      need(typeof tools[names[key]]==='function','ACTUAL_CONNECTED_CAPABILITY_REQUIRED');
    const process=processSelection(x,'--run',p.binding_descriptor.sha256);
    const spec={...x.operator_spec,role:'publication',stage:x.phase,process,
      composition_selection:clone(x),preparation_result:codec.descriptor(codec.canonical(actualPreparation)),
      executable_binding:clone(b),publication:clone(b.publication)};
    return bridge.publish(spec,admit,bridge.framedProcess(process));
  }
  return Object.freeze({prepare,publish,capabilityNames:names,
    sourceState:'UNISSUED',originalHostLaunchAvailable:false,originalConsumerAvailable:false});
})
