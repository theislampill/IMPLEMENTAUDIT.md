"""Current tools-adoption data composition; no issuer, dispatch or host effect.

Requires the actual current CurrentSources object and checked tools receiving.
Decision validation delegates unchanged to publication_owner.validate_control,
which calls sources.H.validate_adoption with exact observation/binding/time.
"""
import re
import publication_owner as O
import file_readback as F
import tools_transport_owner as T

FETCH='mcp__codex_apps__github_fetch'
FILE='mcp__codex_apps__github_fetch_file'
REPOSITORY='theislampill/IMPLEMENTAUDIT.md'
BRANCH='pro/dg16-g1-tools-control-32-20261114'
PARENT='54821a9ad99becd6b4dce0ab491f11ae128e02f3'
PATH='HOST_TOOL_ADOPTION.json'
MAX_BODY=65536


def need(v,c):
    if not v:raise ValueError(c)


def bounded_plan(plan):
    need(type(plan)is dict and plan.get('schema')=='dg16.root-control-publication-plan.v1'
         and plan.get('authority')=='NONE' and plan.get('phase')=='tools','TOOLS_DATA_PLAN_ONLY')
    need(plan.get('context',{}).get('repository')==REPOSITORY and plan.get('branch')==BRANCH
         and plan.get('parent_sha')==PARENT,'EXACT_TOOLS_SCOPE_AND_FIXED_PARENT')
    need(type(plan.get('files'))is dict and set(plan['files'])=={PATH},'EXACT_TOOLS_SINGLE_LEAF')
    row=plan['files'][PATH]
    need(type(row)is dict and set(row)=={'body_utf8','bytes','sha256','git_blob_sha'}
         and type(row['body_utf8'])is str and type(row['bytes'])is int
         and 0<row['bytes']<=MAX_BODY,'EXACT_TOOLS_FILE_DESCRIPTOR')
    body=row['body_utf8'].encode('utf-8')
    need(O.desc(body)=={'bytes':row['bytes'],'sha256':row['sha256']}
         and O.git_object('blob',body)==row['git_blob_sha']
         and O.fixed_tree({PATH:body})==plan.get('expected_tree_sha'),'TOOLS_SELECTED_BODY_OR_TREE_CHANGED')
    return body


def control_read_plan(plan,published_commit):
    bounded_plan(plan)
    need(type(published_commit)is str and re.fullmatch('[0-9a-f]{40}',published_commit)
         and published_commit!=PARENT,'FRESH_TOOLS_PUBLISHED_COMMIT')
    prefix='https://api.github.com/repos/'+REPOSITORY;ref=prefix+'/git/ref/heads/'+BRANCH
    return [dict(kind='ref',tool=FETCH,arguments={'url':ref}),
            dict(kind='commit',tool=FETCH,arguments={'url':prefix+'/git/commits/'+published_commit}),
            dict(kind='tree',tool=FETCH,arguments={'url':prefix+'/git/trees/'+plan['expected_tree_sha']+'?recursive=1'}),
            dict(kind='file0',tool=FILE,arguments=dict(repository_full_name=REPOSITORY,path=PATH,ref=published_commit,encoding='base64')),
            dict(kind='closing_ref',tool=FETCH,arguments={'url':ref})]


def validate_read_result(call,raw,plan,published_commit):
    need(call in control_read_plan(plan,published_commit),'EXACT_TOOLS_READ_CALL')
    if call['tool']==FETCH:return O.unwrap_control(raw,call['arguments']['url'])
    row=plan['files'][PATH]
    body=F.decode_file_result(raw,{'tool':FILE,'arguments':call['arguments']},
                              {k:row[k] for k in ('bytes','sha256','git_blob_sha')},MAX_BODY)
    need(body==row['body_utf8'].encode('utf-8'),'ACTUAL_TOOLS_BODY_CHANGED')
    return body


def verify_publication(plan,published_commit,results,policy,declaration,binding):
    body=bounded_plan(plan);calls=control_read_plan(plan,published_commit)
    need(type(results)is dict and set(results)=={r['kind'] for r in calls}
         and all(type(v)is bytes for v in results.values()) and sum(map(len,results.values()))<=O.MAX_JOURNAL,
         'TOOLS_FULL_RESULT_POPULATION')
    values={c['kind']:validate_read_result(c,results[c['kind']],plan,published_commit) for c in calls}
    provider={k:values[k] for k in ('ref','commit','tree','closing_ref')}
    need(sum(len(O.encode(v)) for v in provider.values())<=1024**2,'TOOLS_METADATA_AGGREGATE')
    need(provider['commit'].get('sha')==published_commit
         and provider['tree'].get('sha')==plan['expected_tree_sha'],'TOOLS_EXPECTED_PUBLICATION_IDENTITIES')
    need(T.check_control_file(provider,body,binding,values['file0'],policy,declaration)==published_commit,
         'TOOLS_ORIGINAL_CONTROL_TRANSPORT_JOIN')
    return dict(schema='g132.current-tools-control-transport-receiving.v1',authority='NONE',
                state='UNISSUED_TRANSPORT_RECEIVING',phase='tools',published_commit=published_commit,
                control_parent=PARENT,control_tree=plan['expected_tree_sha'],root_body=O.desc(body),
                full_actual_tool_results={k:O.desc(v) for k,v in sorted(results.items())},
                file_transport='ACTUAL_FETCH_FILE_BASE64_AT_IMMUTABLE_COMMIT',
                issuer_authenticated=False,tool_adoption_issued=False,host_consumption_observed=False,
                effect_grant=False,original_awards=[])


class CurrentToolsControlAPI:
    MAX_RESULT=O.MAX_RESULT
    desc=staticmethod(O.desc);parse=staticmethod(O.parse);encode=staticmethod(O.encode)
    result_sha=staticmethod(O.result_sha)
    control_read_plan=staticmethod(control_read_plan)
    validate_read_result=staticmethod(validate_read_result)

    def __init__(self,sources):
        self.sources=sources
        need(callable(getattr(sources,'_require_received',None)) and callable(getattr(sources,'context',None)),
             'CURRENT_TOOLS_RECEIVING_INTERFACE_REQUIRED')

    def checked(self,sources,received):
        need(sources is self.sources and received['phase']=='tools','EXACT_CURRENT_TOOLS_SOURCE_OBJECT')
        sources._require_received(received);sources.context(received['context'])
        d=sources.H.declaration(sources.binding)
        need(d['control_branch']==BRANCH and d['control_parent']==PARENT,'SELECTED_TOOLS_BINDING_CHANGED')

    def requirements(self,sources,received):
        self.checked(sources,received)
        return O.requirements(sources,received)

    def validate_control(self,sources,received,body,now_ms):
        self.checked(sources,received)
        return O.validate_control(sources,received,body,now_ms)

    def control_parent(self,received,observation_raw,host_publication=None):
        self.checked(self.sources,received)
        need(host_publication is None,'NO_HOST_PARENT_SUBSTITUTION_FOR_TOOLS')
        selected=O.control_parent(self.sources,received,observation_raw,None)
        need(selected==dict(ref_state='PRESENT',ref_parent_sha=PARENT,commit_parent_sha=PARENT),
             'ACTUAL_FIXED_WAITING_TOOLS_PARENT_REQUIRED')
        return selected

    def publication_plan(self,sources,received,body,parent_sha,now_ms,initial_control=None,parent_state=None):
        self.checked(sources,received)
        need(initial_control is None and parent_state is None,'NO_G3_OR_ABSENT_INPUTS_FOR_TOOLS')
        plan=O.publication_plan(sources,received,body,parent_sha,now_ms,None,None)
        bounded_plan(plan)
        return plan

    def publication_call(self,plan,previous_results):
        bounded_plan(plan)
        return O.publication_call(plan,previous_results)

    def receive_control(self,sources,received,plan,published_commit,results,body,now_ms):
        self.validate_control(sources,received,body,now_ms)
        need(plan['receiving']==O.desc(O.encode(received['receipt'])) and plan['context']==received['context'],
             'TOOLS_CURRENT_RECEIVING_JOIN')
        req=self.requirements(sources,received)
        need(req['path']==PATH and req['branch']==BRANCH and req['required_parent']==PARENT
             and plan['files'][PATH]['sha256']==O.sha(body),'ACTUAL_TOOLS_REQUIREMENT_BODY_JOIN')
        transport=verify_publication(plan,published_commit,results,sources.P,sources.H.declaration,sources.binding)
        return dict(schema='g132.current-tools-owner-and-transport-receiving.v1',authority='NONE',
                    phase='tools',context=received['context'],root_body=O.desc(body),artifact_receiving=plan['receiving'],
                    validated_unix_ms=now_ms,transport=transport,authentication_boundary=O.AUTH,
                    root_issuer_authentication_required=True,tool_adoption_issued=False,
                    host_consumption_observed=False,effect_grant=False,original_awards=[])
