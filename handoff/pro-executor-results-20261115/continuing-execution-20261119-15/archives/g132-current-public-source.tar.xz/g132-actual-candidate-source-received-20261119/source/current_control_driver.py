"""Bounded current control frame driver, composed by current_root_entry.py.
Root admissions stay external. No model-side calls or full original receiver import.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import time
import urllib.parse
CAP = 32*1024**2

def need(ok, code):
    if not ok: raise ValueError(code)

def sha(raw): return hashlib.sha256(raw).hexdigest()

def encode(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)+'\n').encode()

def parse(raw):
    def pairs(rows):
        out = {}
        for key,value in rows:
            need(key not in out, 'DUPLICATE_KEY'); out[key] = value
        return out
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda _: need(False, 'NONFINITE'))

def metadata_guard(raw):
    """Unexpected credentials cannot qualify or reach public diagnostics.
    The exact bounded return is already in the owner-private custody journal.
    """
    credential_keys = {'authorization','password','token','accesstoken','refreshtoken',
                       'completiontoken','clientsecret','secretaccesskey','apikey','credential','credentials'}
    signed_query_keys = {'sig','signature','xgoogsignature','xgoogcredential'}
    def walk(v, depth=0):
        need(depth <= 64, 'METADATA_DEPTH')
        if type(v) is dict:
            for k,x in v.items():
                key = re.sub('[-_]', '', k.lower())
                if key in credential_keys:
                    need(x in (None, '', False), 'CREDENTIAL_RESULT_REFUSED')
                walk(x, depth+1)
        elif type(v) is list:
            for x in v: walk(x, depth+1)
        elif type(v) is str:
            need(not re.search(r'(?i)\bBearer\s+[A-Za-z0-9._~+/=-]{8,}|\bgh[pousr]_[A-Za-z0-9]{20,}', v), 'CREDENTIAL_RESULT_REFUSED')
            for url in re.findall(r'https?://[^\s<>"\']+', v):
                p = urllib.parse.urlsplit(url)
                keys = {re.sub('[-_]', '', urllib.parse.unquote(k).lower()) for k in urllib.parse.parse_qs(p.query)}
                need(not p.username and not p.password and
                     not keys.intersection(credential_keys | signed_query_keys)
                     and not any(k.startswith('xamz') for k in keys), 'SIGNED_RESULT_REFUSED')
            if v.lstrip().startswith(('{','[')):
                try: nested = parse(v.encode())
                except (ValueError, TypeError, RecursionError): return
                walk(nested, depth+1)
    walk(parse(raw))

def run_publication(R, sources, received, body, parent_sha, deadline_ms, journal,
                    frame, emit, *, now_ms=None, initial_control=None, parent_state=None):
    """Concrete loop; frame supplies actual Root results, never invokes tools."""
    now_ms = now_ms if now_ms is not None else (lambda: time.time_ns()//1000000)
    pending = None; writes = []; reads = {}; raw = None
    def current():
        need(type(deadline_ms) is int and now_ms() < deadline_ms, 'EXISTING_ROOT_DEADLINE')
        R.validate_control(sources, received, body, now_ms())
    def retain_return(kind, actual):
        # Retain complete bounded bytes before parsing, credentials, shape,
        # currentness or deadline refusal. These private files are not a report.
        descriptor = R.desc(actual) if type(actual) is bytes else None
        retained = False
        try:
            need(type(actual) is bytes and 0<len(actual)<=R.MAX_RESULT, 'FULL_RETURN_BOUND')
            journal.write(kind+'.RESULT.json', actual); retained = True
            journal.write(kind+'.RETURNED.json', R.encode(dict(authority='NONE', actual_result=descriptor,
                          returned_unix_ms=now_ms(), deadline_unix_ms=deadline_ms,
                          qualification='NOT_YET_CHECKED', source_acceptance=False, automatic_retry=False)))
            metadata_guard(actual); value=R.parse(actual)
            need(type(value) is dict and set(value)<={'content','structuredContent','isError','_meta'}
                 and type(value.get('isError')) is bool and type(value.get('_meta',{})) is dict
                 and not any(value.get('_meta',{}).get(k) for k in ('truncated','isTruncated','partial','hasMore'))
                 and (value['isError'] or type(value.get('structuredContent')) is dict), 'TYPED_COMPLETE_RETURN')
        except BaseException:
            journal.write(kind+'.REJECTED.json', R.encode(dict(authority='NONE', actual_result=descriptor,
                          raw_result_retained=retained, reason='RETURN_SHAPE_OR_CREDENTIAL_REFUSED',
                          source_acceptance=False, automatic_retry=False)))
            raise
        return value
    try:
        current()
        plan = R.publication_plan(sources, received, body, parent_sha, now_ms(), initial_control, parent_state)
        journal.write('PLAN.json', R.encode(plan))
        journal.write('REQUIREMENTS.json', R.encode(R.requirements(sources, received)))
        for ordinal in range(3):
            current(); call = R.publication_call(plan, writes)
            need(call['tool'] == plan['supported_tool_order'][ordinal], 'EXACT_THREE_WRITE_ORDER')
            pending = 'write-'+str(ordinal)
            journal.reserve(R.MAX_RESULT+65536)
            frame_started = now_ms(); frame_deadline = min(deadline_ms, frame_started + 45000)
            intent = dict(schema='dg16.root-control-exclusive-call-intent.v1', authority='NONE',
                          kind=pending, ordinal=ordinal, call=call, deadline_unix_ms=deadline_ms,
                          frame_started_unix_ms=frame_started, frame_deadline_unix_ms=frame_deadline,
                          automatic_retry=False, actual_native_history_required=True)
            journal.write(pending+'.INTENT.json', R.encode(intent))
            current(); emit(dict(event='intent', intent=intent))
            need(now_ms() < frame_deadline, 'ORIGINAL_FRAME_EXPIRED')
            raw = frame(R.MAX_RESULT, (frame_deadline-now_ms())/1000)
            value = retain_return(pending, raw)
            need(now_ms() < frame_deadline, 'LATE_FRAME_RETURN_NO_REPLAY')
            current()
            need(type(value) is dict and value.get('isError') is False and type(value.get('structuredContent')) is dict
                 and not any(value.get('_meta',{}).get(k) for k in ('truncated','isTruncated','partial','hasMore')), 'FULL_WRITE_RESULT_REQUIRED')
            if ordinal < 2:
                result_sha = R.result_sha(raw)
                if ordinal == 0: need(result_sha == plan['expected_tree_sha'], 'ACTUAL_CREATED_TREE_DIFFERS')
            writes.append(raw); raw = None
            emit(dict(event='retained', kind=pending, receipt=R.desc(writes[-1])))
            pending = None
        published = R.result_sha(writes[1])
        for ordinal,call in enumerate(R.control_read_plan(plan, published)):
            current(); pending = 'read-'+call['kind']; journal.reserve(R.MAX_RESULT+65536)
            frame_started = now_ms(); frame_deadline = min(deadline_ms, frame_started + 45000)
            intent = dict(schema='dg16.root-control-exclusive-read-intent.v1', authority='NONE',
                          kind=pending, ordinal=ordinal, call=call, deadline_unix_ms=deadline_ms,
                          frame_started_unix_ms=frame_started, frame_deadline_unix_ms=frame_deadline,
                          automatic_retry=False, actual_native_history_required=True)
            journal.write(pending+'.INTENT.json', R.encode(intent))
            current(); emit(dict(event='intent', intent=intent))
            need(now_ms() < frame_deadline, 'ORIGINAL_FRAME_EXPIRED')
            raw = frame(R.MAX_RESULT, (frame_deadline-now_ms())/1000)
            retain_return(pending, raw)
            need(now_ms() < frame_deadline, 'LATE_FRAME_RETURN_NO_REPLAY')
            current(); R.validate_read_result(call, raw, plan, published)
            reads[call['kind']] = raw; raw = None
            emit(dict(event='retained', kind=pending, receipt=R.desc(reads[call['kind']])))
            pending = None
        current()
        receipt = R.receive_control(sources, received, plan, published, reads, body, now_ms())
        journal.write('RECEIVING.json', R.encode(receipt)); current()
        emit(dict(event='complete', receipt=receipt)); return receipt
    except BaseException:
        raw = None
        try: journal.write('UNKNOWN.json', R.encode(dict(authority='NONE', status='UNKNOWN_NO_REPLAY',
                          pending=pending, automatic_retry=False, no_effect_inferred=False)))
        except BaseException: pass
        emit(dict(event='failure', status='UNKNOWN_NO_REPLAY')); return None
    finally: raw = None

class Journal:
    def __init__(self, path):
        # Explicit current caller-selected parent; no historical workspace alias.
        self.path = Path(path)
        parent = self.path.parent
        need(self.path.is_absolute() and parent.resolve(strict=True) == parent
             and all(not p.is_symlink() for p in parent.parents)
             and re.fullmatch('[A-Za-z0-9_-]{1,100}', self.path.name)
             and not os.path.lexists(self.path), 'FRESH_CURRENT_CONTROL_DIRECTORY')
        st = parent.lstat()
        need(stat.S_ISDIR(st.st_mode) and st.st_uid == os.geteuid()
             and stat.S_IMODE(st.st_mode) == 0o700 and not os.listxattr(parent), 'CURRENT_PARENT_CUSTODY')
        self.path.mkdir(mode=0o700)
        self.fd = os.open(self.path, os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
        self.identity = self.mark(os.fstat(self.fd)); self.names=set(); self.bytes=0
        self.check()
    @staticmethod
    def mark(s): return (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid)
    def check(self):
        s=os.fstat(self.fd)
        need(self.mark(s)==self.identity==self.mark(self.path.lstat()) and s.st_uid==os.geteuid()
             and stat.S_IMODE(s.st_mode)==0o700 and not os.listxattr(self.fd)
             and set(os.listdir(self.fd))==self.names, 'CONTROL_JOURNAL_CUSTODY')
    def reserve(self, additional):
        self.check(); need(self.bytes+additional<=CAP and len(self.names)+3<=64, 'CONTROL_JOURNAL_CAPACITY')
    def write(self, name, raw):
        self.check(); need(type(raw) is bytes and re.fullmatch('[A-Za-z0-9_.-]{1,100}',name)
                          and name not in self.names and self.bytes+len(raw)<=CAP and len(self.names)<64, 'EXCLUSIVE_CONTROL_WRITE')
        fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=self.fd)
        try:
            os.fchmod(fd,0o600); view=memoryview(raw)
            while view:
                n=os.write(fd,view); need(n>0,'SHORT_WRITE');view=view[n:]
            os.fsync(fd)
        finally:os.close(fd)
        os.fsync(self.fd); fd=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC,dir_fd=self.fd)
        try:
            before=os.fstat(fd); need(stat.S_ISREG(before.st_mode) and before.st_nlink==1
                and before.st_uid==os.geteuid() and stat.S_IMODE(before.st_mode)==0o600 and before.st_size==len(raw), 'CONTROL_WRITE_SHAPE')
            got=b''
            while len(got)<=len(raw):
                block=os.read(fd,min(65536,len(raw)+1-len(got)))
                if not block:break
                got+=block
            end=os.fstat(fd);named=os.stat(name,dir_fd=self.fd,follow_symlinks=False)
            mark=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
            need(got==raw and mark(before)==mark(end)==mark(named) and not os.listxattr(fd), 'CONTROL_WRITE_READBACK')
        finally:os.close(fd)
        self.names.add(name);self.bytes+=len(raw);self.check()
    def close(self):os.close(self.fd)
