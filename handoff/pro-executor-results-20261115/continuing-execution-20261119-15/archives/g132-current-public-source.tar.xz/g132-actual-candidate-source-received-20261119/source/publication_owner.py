"""Selected original public planning declarations; no full receiver import.
New selection requires new review; loading creates no source/admission authority.
"""
import hashlib
import json
import re

TOOL = 'mcp__codex_apps__github_fetch'

MAX_RESULT = 4 * 1024**2

MAX_JOURNAL = 8 * 1024**2

AUTH = 'ACTUAL_ROOT_TOOL_HISTORY_AND_PROVIDER_AUTHENTICATION_REQUIRED'

class Refusal(ValueError): pass

def need(ok, code):
    if not ok: raise Refusal(code)

def sha(raw): return hashlib.sha256(raw).hexdigest()

def desc(raw): return dict(bytes=len(raw),sha256=sha(raw))

def encode(v): return (json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode()

def parse(raw, maximum=MAX_RESULT):
    need(type(raw) is bytes and 0 < len(raw) <= maximum,'JSON_BOUND')
    def pairs(rows):
        out={}
        for k,v in rows:
            need(k not in out,'DUPLICATE_JSON_KEY');out[k]=v
        return out
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(Refusal('NONFINITE_JSON')))

def integer(v,low=0,high=10**20):
    need(type(v) is int and low <= v <= high,'INTEGER_BOUND');return v

def requirements(s,received):
    phase=received['phase'];f=received['files'];ctx=received['context'];pending=[]
    if phase=='tools':
        q=parse(f['HOST_TOOL_OBSERVATION.json']);fixed=dict(schema='dg16.same-host-fixed-tool-root-adoption.v2',issuer='R5_ROOT_GOVERNOR',successor='PRO-EXECUTOR-01, designated by owner',operation='ADOPT_FIXED_SAME_HOST_TOOL_BODIES',observation=desc(f['HOST_TOOL_OBSERVATION.json']),command_scope=['recipient','decrypt'],automatic_retry=False,crypto_capability_claim=False,core_or_native_effect_grant=False,original_awards=[])
        for k in ('context','source_commit','source_tree','carrier_binding_sha256','input_index_sha256','public_manifest_sha256','bootstrap_admission_sha256','nonce','host_identity','tools','host_profile'):fixed[k]=q[k]
        pending=['issued_unix_ms','expires_unix_ms'];path='HOST_TOOL_ADOPTION.json';branch=s.binding['host_tools']['control_branch'];parent=s.binding['host_tools']['control_parent']
    elif phase=='g3_initial':
        q=s.G.validate_public_request(f['ROOT_REQUEST.json']);fixed=dict(schema='dg16.g3-root-consumption-decision.v2',issuer='R5_ROOT_GOVERNOR',successor='PRO-EXECUTOR-01, designated by owner',action='CONSUME_COMPONENT_RETURNS_ONLY',request_sha256=sha(f['ROOT_REQUEST.json']),outputs={s.G.PAIR:q['g1_return_sha256'],s.G.SCOPE:q['scope_return_sha256']},consumed_nodes=s.G.SELECTED,owner_arrangement=s.G.OWNER_ARRANGEMENT,original_awards=0)
        for k in ('run_id','attempt','nonce','source_commit','source_tree','graph_sha256','dispatch_sha256','join_sha256','decision_before','decision_after','full_g2','expires_unix_ms'):fixed[k]=q[k]
        pending=['issued_unix_ms'];path=q['control_path'];branch=q['control_branch'];parent=None
    elif phase=='g3_final':
        q=s.G.validate_public_final_request(f['FINAL_REQUEST.json'],retained_bodies=s.retained_m4_bodies());fixed=dict(schema='dg16.g3-root-original-decision.v3',issuer='R5_ROOT_GOVERNOR',successor='PRO-EXECUTOR-01, designated by owner',action='RECEIVE_EXACT_ORIGINAL_IDS_AND_GATES',request_sha256=sha(f['FINAL_REQUEST.json']),whole_DG16_awarded=False,full_g2='NOT_DISPATCHED_OR_CONSUMED_IN_THIS_HOST',v041_admission='PENDING_NOT_GRANTED_BY_THIS_EPISODE',global_liveness='NOT_ESTABLISHED',retirement_or_transfer='NOT_PERFORMED')
        for k in ('run_id','attempt','nonce','source_commit','source_tree','final_graph_sha256','current_receipt_sha256','proofs','retained_m4','expires_unix_ms'):fixed[k]=q[k]
        pending=['issued_unix_ms','independent_review_sha256','source_applicability_review_sha256','original_rows','gate_decisions'];path=q['control_path'];branch=q['control_branch'];parent=None
    else:raise Refusal('ROOT_CONTROL_REQUIREMENTS_PHASE')
    return dict(schema='dg16.root-control-requirements.v1',authority='NONE',receiving=desc(encode(received['receipt'])),required_fixed_fields=fixed,root_supplied_fields=pending,path=path,branch=branch,required_parent=parent,root_body_issued=False,effect_grant=False,original_awards=[])

def validate_control(s,received,raw,now_ms):
    phase=received['phase'];f=received['files'];integer(now_ms,1,10**16)
    if phase=='tools':return s.H.validate_adoption(raw,f['HOST_TOOL_OBSERVATION.json'],s.binding,now_ms)
    if phase=='g3_initial':
        q=s.G.validate_public_request(f['ROOT_REQUEST.json']);return s.G.validate_decision(raw,q,sha(f['ROOT_REQUEST.json']),now_ms)
    if phase=='g3_final':
        q=s.G.validate_public_final_request(f['FINAL_REQUEST.json'],retained_bodies=s.retained_m4_bodies());return s.G.validate_final_decision(raw,q,sha(f['FINAL_REQUEST.json']),now_ms,retained_bodies=s.retained_m4_bodies())
    raise Refusal('CONTROL_PHASE')

def git_object(kind,raw):return hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()

def fixed_tree(files):
    """Pure object hashing only, no Git process or repository operation."""
    tree={}
    for path,raw in files.items():
        node=tree;parts=path.split('/')
        for part in parts[:-1]:node=node.setdefault(part,{})
        node[parts[-1]]=raw
    def digest_tree(node):
        rows=[]
        for name,value in node.items():
            directory=type(value) is dict
            h=digest_tree(value) if directory else git_object('blob',value)
            key=(name+'/' if directory else name).encode()
            rows.append((key,(b'40000' if directory else b'100644')+b' '+name.encode()+b'\0'+bytes.fromhex(h)))
        return git_object('tree',b''.join(row for _,row in sorted(rows)))
    return digest_tree(tree)

def published_host_parent(s,received,raw):
    need(type(raw) is bytes,'PUBLISHED_HOST_RECEIVING_REQUIRED')
    p=parse(raw,65536);need(type(p) is dict and all(k in p for k in ('commit','ref','run')),'PUBLISHED_HOST_RECEIVING_FIELDS')
    c,r,run=p['commit'],p['ref'],p['run'];ctx=received['context'];s.context(ctx)
    head=c.get('sha');need(type(head) is str and re.fullmatch('[0-9a-f]{40}',head),'PUBLISHED_HOST_COMMIT')
    need(s.host_commit(c)==head,'PUBLISHED_HOST_SOURCE_PARENT')
    need(r.get('ref')=='refs/heads/'+s.binding['branch'] and r.get('object',{}).get('type')=='commit' and r['object'].get('sha')==head,'PUBLISHED_HOST_REF_JOIN')
    need(ctx['repository']==s.binding['repository'] and ctx['workflow_commit']==head and ctx['branch']==s.binding['branch']
      and run.get('head_sha')==head and run.get('head_branch')==ctx['branch'] and run.get('path')==ctx['workflow_path']==s.binding['workflow_path']
      and type(run.get('id')) is int and str(run['id'])==ctx['run_id'] and type(run.get('run_attempt')) is int and run['run_attempt']==ctx['run_attempt']==1,'PUBLISHED_HOST_RUN_CONTEXT_JOIN')
    return head

def control_parent(s,received,raw,host_publication=None):
    req=requirements(s,received);url='https://api.github.com/repos/'+received['context']['repository']+'/git/ref/heads/'+req['branch']
    if received['phase']=='g3_initial':
        need(req['required_parent'] is None,'INITIAL_REF_NOT_EXPECTED_ABSENT')
        v=parse(raw);need(type(v) is dict and set(v)=={'schema','tool','url','purpose','result'}
          and v['schema']=='dg16.actual-read-only-tool-interface-observation.v1' and v['tool']=='mcp__codex_apps__github_fetch'
          and v['url']==url and type(v['purpose']) is str,'INITIAL_REF_OBSERVATION_SCOPE')
        result=v['result'];need(type(result) is dict and set(result)<={'content','structuredContent','isError','_meta'} and result.get('isError') is True,'INITIAL_REF_NOT_ABSENT')
        meta=result.get('_meta',{});need(type(meta) is dict and not any(meta.get(k) for k in ('truncated','isTruncated','partial','hasMore')),'INITIAL_REF_OBSERVATION_TRUNCATED')
        sc=result.get('structuredContent');need(type(sc) is dict and set(sc)<={'error','error_code','error_data'} and sc.get('error_code')=='NOT_FOUND' and type(sc.get('error')) is str,'INITIAL_REF_TYPED_NOT_FOUND_REQUIRED')
        data=sc.get('error_data');need(type(data) is dict and set(data)<={'message','documentation_url','status'} and data.get('status')=='404' and data.get('message')=='Not Found','INITIAL_REF_TYPED_404_REQUIRED')
        return dict(ref_state='ABSENT',ref_parent_sha=None,commit_parent_sha=published_host_parent(s,received,host_publication))
    need(received['phase'] in ('tools','g3_final') and host_publication is None,'POSITIVE_CONTROL_PARENT_ONLY')
    ref=unwrap_control(raw,url);parent=ref.get('object',{}).get('sha')
    need(ref.get('ref')=='refs/heads/'+req['branch'] and ref.get('object',{}).get('type')=='commit' and type(parent) is str and re.fullmatch('[0-9a-f]{40}',parent),'ACTUAL_CURRENT_PARENT_REF')
    return dict(ref_state='PRESENT',ref_parent_sha=parent,commit_parent_sha=parent)

def publication_plan(s,received,body,parent_sha,now_ms,initial_control=None,parent_state=None):
    """Require an actual root-issued body; return inert supported-call inputs."""
    validate_control(s,received,body,now_ms);req=requirements(s,received)
    need(type(parent_sha) is str and re.fullmatch('[0-9a-f]{40}',parent_sha),'ACTUAL_CONTROL_PARENT_REQUIRED')
    if received['phase']=='g3_initial':
        need(type(parent_state) is dict and set(parent_state)=={'ref_observation','host_publication'},'ACTUAL_INITIAL_REF_ABSENCE_PROOF_REQUIRED')
        selected=control_parent(s,received,parent_state['ref_observation'],parent_state['host_publication'])
        need(selected['ref_state']=='ABSENT' and parent_sha==selected['commit_parent_sha'],'INITIAL_PUBLISHED_HOST_PARENT_JOIN')
    else:need(parent_state is None,'NO_ABSENCE_PROOF_FOR_POSITIVE_PARENT')
    if req['required_parent'] is not None:need(parent_sha==req['required_parent'],'FIXED_WAITING_PARENT')
    files={req['path']:body}
    if received['phase']=='g3_final':
        need(type(initial_control) is dict and set(initial_control)=={'body','receiving','published_commit'},'PRIOR_ACTUAL_G3_CONTROL_REQUIRED')
        prior=initial_control['receiving'];need(prior['phase']=='g3_initial' and prior['context']==received['context'],'PRIOR_G3_CONTROL_CONTEXT')
        q=s.G.validate_public_request(prior['files']['ROOT_REQUEST.json']);v=parse(initial_control['body'],8192)
        # Check the prior body at its recorded issuance; this grants no currentness.
        s.G.validate_decision(initial_control['body'],q,sha(prior['files']['ROOT_REQUEST.json']),v['issued_unix_ms'])
        need(parent_sha==initial_control['published_commit'] and received['receipt']['details']['request']['initial_request_sha256']==sha(prior['files']['ROOT_REQUEST.json']),'PRIOR_PUBLISHED_G3_COMMIT_JOIN')
        need(desc(initial_control['body'])==received['receipt']['details']['actual_first_root_decision'],'ACTUAL_FIRST_DECISION_CUSTODY_JOIN')
        files[s.G.CONTROL_PATH]=initial_control['body']
    plan=dict(schema='dg16.root-control-publication-plan.v1',authority='NONE',phase=received['phase'],context=received['context'],branch=req['branch'],parent_sha=parent_sha,
      files={n:dict(body_utf8=b.decode('utf-8'),**desc(b),git_blob_sha=git_object('blob',b)) for n,b in sorted(files.items())},expected_tree_sha=fixed_tree(files),
      receiving=desc(encode(received['receipt'])),root_body_validation_at_unix_ms=now_ms,root_issuer_authentication_required=True,authentication_boundary=AUTH,
      supported_tool_order=['mcp__codex_apps__github_create_tree','mcp__codex_apps__github_create_commit','mcp__codex_apps__github_update_ref'],
      reserve_and_retain_full_actual_result_before_next_call=True,automatic_retry=False,effect_grant=False,original_awards=[])
    if received['phase']=='g3_initial':
        plan.update(ref_state='ABSENT',ref_parent_sha=None,absent_ref_observation=desc(parent_state['ref_observation']),published_host_receiving=desc(parent_state['host_publication']))
        plan['supported_tool_order'][-1]='mcp__codex_apps__github_create_branch'
    return plan

def result_sha(raw):
    v=parse(raw);need(type(v) is dict and set(v)<= {'content','structuredContent','isError','_meta'} and v.get('isError') is False,'WRITE_TOOL_RESULT_ERROR')
    m=v.get('_meta',{});need(type(m) is dict and not any(m.get(k) for k in ('truncated','isTruncated','partial','hasMore')),'WRITE_TOOL_TRUNCATION')
    sc=v.get('structuredContent');need(type(sc) is dict and type(sc.get('sha')) is str and re.fullmatch('[0-9a-f]{40}',sc['sha']),'ACTUAL_WRITE_RESULT_SHA_REQUIRED');return sc['sha']

def publication_call(plan,previous_results):
    need(plan.get('schema')=='dg16.root-control-publication-plan.v1' and plan.get('authority')=='NONE' and type(previous_results) is list and len(previous_results)<3,'PUBLICATION_PLAN_OR_STEP')
    files={n:r['body_utf8'].encode('utf-8') for n,r in plan['files'].items()}
    need(fixed_tree(files)==plan['expected_tree_sha'] and all(desc(files[n])=={'bytes':r['bytes'],'sha256':r['sha256']} and git_object('blob',files[n])==r['git_blob_sha'] for n,r in plan['files'].items()),'PUBLICATION_BODY_CHANGED')
    repo=plan['context']['repository'];i=len(previous_results)
    if i==0:args=dict(repository_full_name=repo,tree_elements=[dict(path=n,mode='100644',type='blob',content=b.decode('utf-8')) for n,b in sorted(files.items())])
    else:
        tree=result_sha(previous_results[0]);need(tree==plan['expected_tree_sha'],'ACTUAL_CREATED_TREE_DIFFERS')
        if i==1:args=dict(repository_full_name=repo,tree_sha=tree,parent_sha=plan['parent_sha'],message='DG16 root control '+plan['phase']+' run '+plan['context']['run_id'])
        elif plan.get('ref_state')=='ABSENT':
            need(plan['phase']=='g3_initial' and plan.get('ref_parent_sha') is None and plan['parent_sha']==plan['context']['workflow_commit'],'INITIAL_CREATE_ONLY_PLAN')
            args=dict(repository_full_name=repo,branch_name=plan['branch'],sha=result_sha(previous_results[1]))
        else:args=dict(repository_full_name=repo,branch_name=plan['branch'],sha=result_sha(previous_results[1]),expected_sha=plan['parent_sha'],force=False)
    return dict(authority='NONE',tool=plan['supported_tool_order'][i],arguments=args,requires_separate_root_effect_authorization=True,
      previous_actual_tool_results=[desc(b) for b in previous_results],no_unknown_effect_replay=True)

def unwrap_control(raw,url):
    v=parse(raw);need(type(v) is dict and set(v)<= {'content','structuredContent','isError','_meta'} and v.get('isError') is False,'CONTROL_TOOL_RESULT')
    m=v.get('_meta',{});need(type(m) is dict and not any(m.get(k) for k in ('truncated','isTruncated','partial','hasMore')),'CONTROL_TOOL_TRUNCATED')
    sc=v.get('structuredContent');need(type(sc) is dict and set(sc)<= {'content','title','modified_date','url','display_url','display_title','structuredContent'}
      and sc.get('url')==url and sc.get('display_url')==url and type(sc.get('content')) is str,'CONTROL_ACTUAL_ENDPOINT')
    if 'structuredContent' in sc:
        inner=sc['structuredContent'];need(type(inner) is dict and set(inner)<= {'title','content','display_url'} and inner.get('content')==sc['content'] and inner.get('display_url')==url,'CONTROL_NESTED_CHANGED')
    body=sc['content'].encode();v=parse(body,1024**2);need(type(v) is dict,'CONTROL_PROVIDER_BODY');return v
