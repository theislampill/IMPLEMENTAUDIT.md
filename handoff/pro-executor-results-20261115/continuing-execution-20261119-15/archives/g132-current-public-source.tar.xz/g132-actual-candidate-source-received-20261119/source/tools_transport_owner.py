"""New transport variant; original adoption decision validator is unchanged.
Metadata wrappers stay actual; immutable file bytes are an explicit input.
"""
import hashlib

def git_blob(raw):
    return hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()

def check_control_file(provider,body,binding,file_body,P,declaration):
    P.exact(provider,('ref','commit','tree','closing_ref'))
    d=declaration(binding);r=provider['ref'];c=provider['commit'];t=provider['tree']
    P.need(r==provider['closing_ref'] and r.get('ref')=='refs/heads/'+d['control_branch']
      and r.get('object',{}).get('type')=='commit' and r['object']['sha']==c.get('sha')
      and c['sha']!=d['control_parent'] and type(c.get('parents')) is list and len(c['parents'])==1
      and c['parents'][0].get('sha')==d['control_parent'],
      'HOST_TOOL_CONTROL_FRESH_PARENT')
    P.need(c.get('tree',{}).get('sha')==t.get('sha') and t.get('truncated') is False
      and type(t.get('tree')) is list and len(t['tree'])==1,'HOST_TOOL_CONTROL_TREE')
    row=t['tree'][0]
    P.need(row.get('path')=='HOST_TOOL_ADOPTION.json' and row.get('mode')=='100644' and row.get('type')=='blob'
      and row.get('size')==len(body) and type(file_body) is bytes and row.get('sha')==git_blob(file_body)
      and file_body==body,'HOST_TOOL_CONTROL_BODY')
    return c['sha']
