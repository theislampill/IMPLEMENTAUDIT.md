"""Freeze the already-generated and checked source; no operational execution."""
from pathlib import Path
import hashlib
import json
import stat
import zipfile

BASE=Path(__file__).resolve().parent
def desc(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def load(name):return json.loads((BASE/name).read_bytes())
def write(name,value):
    raw=value.encode() if isinstance(value,str) else (json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
    with (BASE/name).open('xb') as f:f.write(raw)
    return desc(raw)
g=load('GENERATION_PROVENANCE.json');v=load('evidence/GENERATION_CONTROLS.json');b=load('evidence/NEW_BINDING_CONTROL.json')
assert v['passed']==477 and v['failed']==0 and b['passed']==7 and b['failed']==0
assert load('evidence/GENERATION_CONTROL_TOOL_RESULT.json')['result']['exit_code']==0
assert load('evidence/NEW_BINDING_CONTROL_TOOL_RESULT.json')['result']['exit_code']==0
assert load('evidence/SOURCE_GENERATION_TOOL_RESULT.json')['result']['exit_code']==0
inputs=load('evidence/RECEIVED_INPUTS.json')
for row in inputs['inputs']:assert desc((BASE/row['path']).read_bytes())=={k:row[k] for k in ('bytes','sha256')}
for name,pin in g['outputs'].items():assert desc((BASE/name).read_bytes())==pin
assert desc((BASE/g['complete_issuer']['after']['path']).read_bytes())=={k:g['complete_issuer']['after'][k] for k in ('bytes','sha256')}
assert desc(Path(inputs['baseline_archive']['path']).read_bytes())=={k:inputs['baseline_archive'][k] for k in ('bytes','sha256')}
assert desc(Path(inputs['selected_host_archive']['path']).read_bytes())=={k:inputs['selected_host_archive'][k] for k in ('bytes','sha256')}

with zipfile.ZipFile(inputs['baseline_archive']['path']) as z:
    old_open=z.read('OPEN_PREDICATES.json')
    old_manifest=load('inputs/baseline/MANIFEST.json')
    pin=next(r for r in old_manifest['files'] if r['path']=='OPEN_PREDICATES.json')
    assert desc(old_open)=={k:pin[k] for k in ('bytes','sha256')}
    write('inputs/baseline/OPEN_PREDICATES.json',old_open.decode())
predicates=json.loads(old_open)
predicates.update(schema='g132.actual-candidate-rebind-open-predicates.v1',generation=g['actual_candidate'],
    genuine_nonauthor_review_performed=False,source_adoption=False,original_predicates_changed=False,
    protected_grant_request_justified=False,operational_readiness='BLOCKED_BY_UNISSUED_ORIGINAL_GATES')
for p in predicates['predicates']:
    if p['id']=='P01':
        p['proof_needed']='Genuine nonauthor review of this exact new frozen binding generation, followed by separate Root source/installation adoption. The author did not read reviewer contexts/results. No prior review is grandfathered.'
    if p['id']=='P02':
        p['owner']='Root issuer + actually supported publication/receiving capability'
        p['status']='ACTUAL_OBJECT_AND_SOURCE_REBIND_PREPARED_HOST_GATES_OPEN'
        p['proof_needed']='Root actually created unreferenced bd347ba6848e976c993ec82f5aa85d8e5964f6e1 with tree bc3f8f1a10cbea041a6bf066acda113f3252360b and sole parent 301aeecde08ba6f169bc3cd837eae6f6ad068219. This generation binds it explicitly. Independent affected-source review/adoption, separately authorized reference/host operation, actual current hosted publication/run/job receiving and same-host custody remain open. The old raw 3f generation and its bounded transport failures remain historical, not a silent replacement or fresh operational gate discharged by this source work.'
    if p['id']=='P03':
        p['proof_needed']='The unchanged concrete twelve-file entry/bridge composition now selects the new installation index and actually passes source-only --check. Default UNISSUED prepare refuses before inputs/journal. Real current artifacts, issuer provenance, source/installation admission, Root operation selection and original deadline remain open; no fixture supplies them.'
    if p['id']=='P04':
        p['proof_needed']+=' The rebind changes none of this custody code and does not rerun or promote the earlier controls into native/original evidence.'
    if p['id']=='P06':
        p['proof_needed']+=' This new generation changes none of that route. Prior synthetic-callback provenance remains explicitly synthetic and was not rerun.'
predicates['predicates'].append({'id':'P10','operation':'ACTUAL_CONNECTED_GIT_READBACK','owner':'Root + admitted model-side transport capability','status':'OBSERVED_TREE_GET_FAILURE_CAUSE_UNKNOWN',
    'proof_needed':'Root retained two API tree GET 404 results after successful object creation; fresh remote-only native Git receiving proved this candidate tree and changed bytes. Cause UNKNOWN. Future actual control/tree/file readbacks must satisfy the unchanged admitted API/typed-result predicates, or require a separately reviewed adapter change. Native candidate receiving is not an automatic runtime fallback. A 404 does not prove no object effect or replay safety.'})
write('OPEN_PREDICATES.json',predicates)
write('SOURCE_DELTA.json',{'schema':'g132.exact-current-source-delta.v1','authority':'NONE','baseline_archive':inputs['baseline_archive'],
    'current_paths':g['current_source_delta'],'complete_issuer':g['complete_issuer'],'exact_patch':'SOURCE_DIFF.patch',
    'phase_members_unchanged':53,'unchanged_runtime_files':g['unchanged_runtime_files'],'original_function_predicates_changed':False})
verification_files=['evidence/RECEIVED_INPUTS.json','evidence/INPUT_RECEIVING_TOOL_RESULT.json','evidence/BASELINE_BINDING_CONTROL.json',
 'evidence/BASELINE_BINDING_TOOL_RESULT.json','evidence/PROJECTION_REGENERATION_PRECHECK.json','evidence/PROJECTION_PRECHECK_TOOL_RESULT.json',
 'evidence/PROJECTION_RECIPE_DIAGNOSIS.json','evidence/PROJECTION_DIAGNOSIS_TOOL_RESULT.json','evidence/SOURCE_GENERATION_TOOL_RESULT.json',
 'evidence/NEW_BINDING_CONTROL.json','evidence/NEW_BINDING_CONTROL_TOOL_RESULT.json','evidence/GENERATION_CONTROLS.json',
 'evidence/GENERATION_CONTROL_TOOL_RESULT.json','evidence/SOURCE_CHECK_READBACK_TOOL_RESULT.json','evidence/INITIAL_READBACK_FAILURE.json',
 'evidence/POST_COMPACTION_RECONCILIATION_G0007.json']
write('VERIFICATION_INDEX.json',{'schema':'g132.rebind-verification-index.v1','authority':'NONE','files':{n:desc((BASE/n).read_bytes()) for n in verification_files},
    'source_control_assertions':477,'binding_cases':7,'baseline_expected_binding_mismatches':4,
    'unrelated_old_suites_rerun':False,'actual_model_provider_calls':0,'original_acceptance':False})
result={'schema':'g132.actual-candidate-rebind-result.v1','state':'UNISSUED_SOURCE_GENERATION_FOR_GENUINE_NONAUTHOR_REVIEW','authority':'NONE',
    'author_lane':'/root/recovered_public_probe','self_reported_model':'GPT-6 Astra Pro','native_model_attestation':False,
    'root_reported_currentness_at_commission':'G0006@de0c26dae4765a0c56aa15f2905df424de1e011b; fresh require d23c39 exit 0; caller report, not child-native attestation',
    'root_reported_currentness_at_finalization':'G0007@03a4c376cf2aa12c233d4cbdeef5ec86ebec5d0d; current check 088b63 exit 0; caller report, not child-native attestation',
    'actual_child_boundary':'evidence/POST_COMPACTION_RECONCILIATION_G0007.json; finalizer file received after truncated patch result; no process execution or control replay inferred',
    'actual_candidate':g['actual_candidate'],'historical_candidate':g['historical_candidate'],'tree':g['tree'],'parent':g['parent'],
    'source_index':g['after_installation_index'],'composition_index':g['composition_source_index'],'unissued_config':g['unissued_config'],
    'complete_issuer':g['complete_issuer']['after'],'pure_issuer':desc((BASE/'dependencies/installation/pure/issuer.py').read_bytes()),
    'current_path_delta':10,'runtime_files':12,'runtime_files_byte_unchanged':10,'runtime_changes':'Only two installation-index string literals',
    'installation_indexed_files':157,'phase_bodies_byte_unchanged':53,'issuer_function_asts_unchanged':3,'all_original_predicates_preserved':True,
    'binding_source_cases':{'passed':7,'failed':0,'synthetic_ref_run':True,'issuer_derive_called':False},
    'data_source_assertions':{'passed':477,'failed':0},'actual_entry_source_check':'PASS',
    'stale_index_control':'REFUSED_INSTALLATION_INDEX_PIN','unissued_prepare_control':'REFUSED_CURRENT_ROOT_SELECTION_REQUIRED',
    'local_executor_uid':v['local_environment']['uid'],'same_host_original_custody_proved':False,
    'provider_tree_GET_404_cause':'UNKNOWN; retained Root native receiving proves candidate object facts only',
    'new_provider_calls_by_author':0,'issuer_effects':False,'host_launch':False,'private_inputs_read':False,'source_adoption':False,
    'genuine_nonauthor_review_performed_by_author':False,'protected_grant_requested':False,'all_grants':'UNISSUED',
    'protected_operation':'UNKNOWN_NO_REPLAY','old_truncated_verifier_return':'UNKNOWN_COMPLETE_RESULT_TRUNCATED, unchanged',
    'old_archived_packets_changed':False,'known_pending_source_process_or_provider_call':False}
write('RESULT.json',result)

delta_table='\n'.join('| `'+r['path']+'` | '+('Added' if r['before'] is None else 'Removed from current selection' if r['after'] is None else 'Updated')+' |' for r in g['current_source_delta'])
report=f'''# Actual-candidate G132 source rebinding

**State: UNISSUED source generation prepared for genuine nonauthor review.** This author performed bounded source work and source controls only. No adoption, issuer grant, original operation or operational readiness is claimed. Self-reported model: GPT-6 Astra Pro; no native model attestation.

## Outcome

This is a distinct generation selecting actual provider commit **`{g['actual_candidate']}`**. It preserves the archived offline candidate **`{g['historical_candidate']}`** as a different identity. Both encode root tree **`{g['tree']}`** and sole parent **`{g['parent']}`**. Their raw commit bodies are different: the old body is 339 bytes; the actually received new body is 919 bytes, SHA256 `be8ebb876f2b13c4fbf94facddb392412cae4a832a34b6759214826671e66a80`.

Root's candidate preparation used one supported create-tree and one create-commit call, with no blob/ref/host operation. This lane made no provider call. Root's actual intents, complete results, GET failures and native receiving files are retained under `inputs/actual-candidate/`. `REMOTE_VERIFIED.json` is pinned at 8,647 bytes, SHA256 `64597825e4fb66085a55ae1ff8f6f622577cde56b35e0de724d71b5e578db982`.

Current receiving independently checked the supplied raw commit ID, all **1,819 candidate file paths**, and reconstructed the exact tree from their mode/path/object IDs. The supplied native batch contains all **23 changed file bodies, 738,854 bytes**, each matching the previous selected-host source body and Git blob identity. The **1,796 other parent file paths are unchanged**. This does not claim individual native receiving of every inherited blob body or original host execution. Evidence: `evidence/RECEIVED_INPUTS.json` and `INPUT_RECEIVING_TOOL_RESULT.json` (e036fb, exit 0).

## New binding chain

| Artifact | Bytes | SHA256 |
|---|---:|---|
| Installation `SOURCE_INDEX.json` | {g['after_installation_index']['bytes']} | `{g['after_installation_index']['sha256']}` |
| `COMPOSITION_SOURCE_INDEX.json` | {g['composition_source_index']['bytes']} | `{g['composition_source_index']['sha256']}` |
| Complete issuer source | {g['complete_issuer']['after']['bytes']} | `{g['complete_issuer']['after']['sha256']}` |
| Bounded issuer projection | {result['pure_issuer']['bytes']} | `{result['pure_issuer']['sha256']}` |
| UNISSUED Root config | {g['unissued_config']['bytes']} | `{g['unissued_config']['sha256']}` |

The closed runtime installation still has **157 indexed files plus its index**. The composition still has exactly **12 runtime files**. The standalone complete issuer body is `complete-sources/issuer.py`; its exact before/after descriptors and projection relationship are bound by `GENERATION_PROVENANCE.json`, `PURE_SOURCE_PLAN.json` and this packet manifest. It is outside the runtime installation and is not imported as an operational issuer.

`HOST_IDENTITY_UNISSUED.json` records the new commit's observed **unreferenced commit-object publication**. Separate fields explicitly record that reference publication, host launch and source adoption have not been observed or issued. The identity remains UNISSUED, with no awards or retry authority. The original `SOURCE_INDEX.outer_manifest_sha256` is retained as the earlier public-source provenance anchor; it is not presented as this generation's manifest or review acceptance.

## Exact source change

| Current path | Change |
|---|---|
{delta_table}

There are eight modified current files and one raw-commit path replacement, represented as one removal and one addition. The prior raw commit remains in `inputs/baseline/` and the archived packet. Ten runtime files are byte-identical. The two changed runtime files differ only in their installation-index literals; all their other AST nodes are unchanged. No entry/bridge/frame/journal/tool capability behavior was added or relaxed.

The exact complete issuer body was already recovered by a deterministic public-source derivation and pinned at 8,932 bytes, SHA256 `609b0ec3b77a0e1d07bc105d20675518cc07f653b222c78e045c61ca547634cf`. The new generator replaces only its top-level `HOST_COMMIT` literal, then selects the original declaration source segments verbatim. The selected three function AST hashes remain unchanged. No complete issuer module or `issuer.derive` was executed.

The generator updates both full-source and projection descriptors, all affected installation pins, the two loader constants, the unissued configuration's installation path/hash and the composition index. `SOURCE_DIFF.patch` is the exact textual difference, including the complete issuer change. `SOURCE_DELTA.json` provides the compact before/after pin map. The generator consumes the exact baseline archive and received Root candidate bytes; it does not invent source from a summary.

## Preserved original requirements

All **53 hosted phase bodies** and the phase manifest are byte-identical to the baseline. All other installation bodies and source-plan rows are unchanged except the named identity/projection/index items. The full fifteen-proof conjunction, Q06, current G3 predicates, original rows/gates, accepted-retained-M4 joins and original deadlines remain unchanged. The initial one-leaf and final two-leaf G132 publication contract remains unchanged; no G2 third-file criterion was introduced.

The original source/transport context distinction remains seven owner fields versus nine transport fields. Explicit model-side capability injection, typed results, tools/PRESENT/three-write/five-read route, exact initial/final parent rules and complete bounded wrapper custody remain the prior source implementations. The previous source packet's synthetic provider callbacks remain synthetic; their results are not promoted to actual original provider or host evidence.

## Meaningful controls and actual failures

| Control | Actual result | Scope |
|---|---|---|
| Baseline binding control, ef650f | Exit 1: four expected identity mismatches, three preserved refusal checks pass | Proves the archived 3f generation does not already select bd; not a defect claim against its original intended identity. |
| First projection recipe precheck, 40400f | Exit 1: AST unparse produced 3,773 bytes instead of the exact 4,146-byte projection | Formatting changed; failed output descriptor and receipt preserved. No source module executed. |
| Recipe diagnosis, 336f04 | Exit 0: verbatim selected source segments exactly reproduce the existing 4,146-byte projection | Uses the actual complete source and existing source-preserving method. |
| New binding source cases, b4fb59 | Exit 0: seven pass | New commit accepted by selected validation; old commit, wrong tree/parent and old protected head refused. Publication ref/run inputs are explicitly synthetic. No issuer derivation or provider call. |
| New generation controls, 816654 | Exit 0: 477 data/source assertions pass | Input/output pins, closed populations, exact source/AST invariants, phase preservation and three actual native entry invocations. This is not 477 original proof gates. |
| Actual source-only entry | Exit 0 | Loads the new exact installation/index and reports UNISSUED, no original effect and operational entry not permitted. |
| Stale index / UNISSUED prepare | Both exit 1 with their required refusal codes | `INSTALLATION_INDEX_PIN` and `CURRENT_ROOT_SELECTION_REQUIRED`; no current public-input or journal selection supplied. |

The initial read-only display helper also failed once (8f9362, list/mapping assumption). Its observed failure is retained in `INITIAL_READBACK_FAILURE.json`; a named-field readback completed in 129f28. The original complete wrapper for that incidental failure was not retained and is not fabricated. Later source-generation and control tool results are retained completely and incrementally. The older truncated receiving return remains UNKNOWN and was not rerun.

An actual child compaction occurred after the finalizer script's initial file-write call. That call requested only `apply_patch`; its complete outer result was truncated. Under Root's reported G0007 admission (`03a4c376cf2aa12c233d4cbdeef5ec86ebec5d0d`, current check 088b63 exit 0), readback received the complete 24,853-byte finalizer file, all 233 then-existing owned files, no final outputs and no matching owned process. The patch's outer metadata remains UNKNOWN; file existence was received directly. `evidence/POST_COMPACTION_RECONCILIATION_G0007.json` preserves that census and boundary. Only remaining report/seal finalization continued; no source generation, control or operation was repeated. G0006 remains the original commission record. Both currentness claims are Root reports, not child-native attestation.

The source-only entry ran on local Linux with UID/EUID/GID/EGID **1000**, Python 3.12.14. This is separate from Root's model-side tools and from the original root-owned GitHub-hosted consumer. Neither local transport nor the earlier ordinary public UID0/HTTP probe proves original same-host custody or native model identity.

## Remaining gates

`OPEN_PREDICATES.json` preserves the original P01–P09 operations and adds the observed API-readback limitation as P10:

- **Genuine nonauthor source review and Root adoption:** this exact frozen generation needs its own affected-source review. The author did not read current reviewer contexts or results. Earlier source identities or reviews are not grandfathered.
- **Actual host publication and current receiving:** bd exists as an unreferenced commit object. No branch was moved, job launched or current host admitted by this lane. Any future reference/host effect is separately controlled by Root.
- **Current Root composition:** the source entry is concrete and checked, but its configuration remains UNISSUED with null context, phase, deadlines, inputs, bodies, receiving and journal selection. Actual admission and effect-specific authority remain separate.
- **Full actual-result custody:** the prior bounded byte-retention implementation is unchanged. Oversized, unserializable, nonfaithful/no-return or persistence gaps remain explicit UNKNOWN without replay; no native-history attestation follows.
- **Initial/final control issuance:** genuine initial absence, actual selected host commit/ref/run, issued initial body, prior initial publication, current final ref and all final M4/decision joins remain mandatory.
- **Same-host tools and recipient:** real hosted tool/profile observations, the original adoption validator's actual receiving, recipient creation and Root adoption remain unissued.
- **Original sender/private route:** the eleven private inputs, five late-selected bodies, fresh nonroot sender/capture, original single encryption and eighteen metadata returns remain separately controlled. None were acquired or executed.
- **Original G1/G3 acceptance:** the full fifteen proofs, current G3, Q06, original rows/gates, accepted-retained-M4 joins, clocks, native corroboration/model applicability and actual owner consumption remain required. These controls award none.
- **Old no-replay state:** protected 625f and interrupted 301 remain UNKNOWN_NO_REPLAY. Root's current object/ref/run observations do not establish cancellation, non-use or replay permission; a new commit identity does not reset them.
- **Actual connected tree readback:** Root preserved two tree GET 404 results after successful object creation; cause UNKNOWN. Fresh remote native Git receiving proves this candidate's object facts, but it is not an automatic fallback in the runtime API adapter. Future actual control tree/file readbacks must meet unchanged typed-result requirements or have a separately reviewed adapter change. A 404 is not evidence that no effect happened.

The historical exact-3f native transport failure remains archived. This generation implements the separately identified actual-returned-commit source route Root selected; it does not claim that old raw-3f publication succeeded. No protected grant request is justified by this packet.

## Review and reproduction

Start with `RESULT.json`, `SOURCE_DELTA.json`, `GENERATION_PROVENANCE.json`, `VERIFICATION_INDEX.json` and `OPEN_PREDICATES.json`. Review the exact issuer change and two runtime literal changes in `SOURCE_DIFF.patch`. Complete current runtime/installation source and the complete issuer body are included.

Regeneration additionally requires the explicitly pinned admitted baseline archive, SHA256 `{inputs['baseline_archive']['sha256']}`, at the path recorded in `evidence/RECEIVED_INPUTS.json`; the archived baseline is not duplicated inside this compact packet. `generators/rebind_source.py` uses write-once output paths and must be applied only to a new owned generation directory. It is not an instruction to overwrite this sealed packet. The new current source is complete and inspectable without running that generator.

The default source-only check uses the current entry with `--check`, the exact composition-index pin and unissued config pin listed above. Deployment or relocation requires separate Root installation/config selection and its actual readback; no operational invocation is authorized here. Source files/indexes are retained read-only; the config is frozen owner-readable (0400), which the unchanged entry accepts.

This task wrote only its owned directory. No Root controller/cache/shared edit, credential action, connected mutation, original/private operation, issuer effect, host launch, actor/reviewer dispatch or old broad-suite rerun occurred. All repository/API content was treated as data; authority remained the explicit Root commission. The packet carries no independent-review, readiness, adoption or closure authority.
'''
write('REPORT.md',report)

# Freeze a mode compatible with the already-checked unchanged entry contract.
(BASE/'ROOT_CONTROL_CONFIG_UNISSUED.json').chmod(0o400)
payload=[]
excluded={'MANIFEST.json','SEAL.json','G132_ACTUAL_CANDIDATE_REBIND_SOURCE.zip','FINAL_SEAL_TOOL_RESULT.json'}
for path in sorted(BASE.rglob('*')):
    if not path.is_file() or path.relative_to(BASE).parts[0] in excluded:continue
    assert not path.is_symlink()
    payload.append({'path':str(path.relative_to(BASE)),**desc(path.read_bytes()),'mode':'0400' if path.name in ('ROOT_CONTROL_CONFIG_UNISSUED.json','STALE_INDEX_CONFIG.json') else '0444'})
manifest_pin=write('MANIFEST.json',{'schema':'g132.actual-candidate-rebind-manifest.v1','authority':'NONE','state':result['state'],
    'files':payload,'payload_files':len(payload),'runtime_composition_index':g['composition_source_index'],
    'external_regeneration_dependency':inputs['baseline_archive'],'excluded':['MANIFEST.json self-hash','SEAL.json detached seal','ZIP container','FINAL_SEAL_TOOL_RESULT.json post-seal complete outer result']})
archive=BASE/'G132_ACTUAL_CANDIDATE_REBIND_SOURCE.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for row in payload+[{'path':'MANIFEST.json','mode':'0444'}]:
        info=zipfile.ZipInfo(row['path'],date_time=(2026,11,19,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=(stat.S_IFREG|int(row['mode'],8))<<16
        z.writestr(info,(BASE/row['path']).read_bytes())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.infolist())==len(payload)+1 and len(set(z.namelist()))==len(z.namelist())
    for row in payload:assert desc(z.read(row['path']))=={k:row[k] for k in ('bytes','sha256')}
    assert desc(z.read('MANIFEST.json'))==manifest_pin
archive_pin=desc(archive.read_bytes())
seal={'schema':'g132.actual-candidate-rebind-seal.v1','authority':'NONE','state':result['state'],
    'archive':{'path':archive.name,**archive_pin,'members':len(payload)+1},'manifest':{'path':'MANIFEST.json',**manifest_pin},
    'report':desc((BASE/'REPORT.md').read_bytes()),'result':desc((BASE/'RESULT.json').read_bytes()),
    'source_index':g['after_installation_index'],'composition_index':g['composition_source_index'],
    'all_payload_hashes_and_zip_crc_verified':True,'source_adoption':False,'genuine_nonauthor_review_performed':False,
    'all_grants':'UNISSUED','protected_operation':'UNKNOWN_NO_REPLAY'}
seal_pin=write('SEAL.json',seal)
for row in payload:(BASE/row['path']).chmod(int(row['mode'],8))
for path in (BASE/'MANIFEST.json',BASE/'SEAL.json',archive):path.chmod(0o444)
print(json.dumps({'status':'SEALED_UNISSUED_NEW_SOURCE_GENERATION','payload_files':len(payload),'zip_members':len(payload)+1,
    'archive':archive_pin,'manifest':manifest_pin,'seal':seal_pin,'report':seal['report'],'result':seal['result'],
    'source_index':g['after_installation_index'],'composition_index':g['composition_source_index'],
    'source_controls':'7 binding cases; 477 data/source assertions; source-only entry passes; unissued prepare refuses',
    'authority':'NONE','all_grants':'UNISSUED','protected_operation':'UNKNOWN_NO_REPLAY'},indent=2))
