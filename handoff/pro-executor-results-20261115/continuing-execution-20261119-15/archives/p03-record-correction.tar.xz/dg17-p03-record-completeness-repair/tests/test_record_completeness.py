"""Focused regression controls; no actual actor, Root decision or host grant."""
import argparse
import json
from pathlib import Path
import unittest
import support as s


class RecordCompleteness(unittest.TestCase):
    def setUp(self):
        s.reset_currentness()

    def test_writer_refuses_missing_scope_fields_without_state_effect(self):
        f = s.Fixture('missing-writer-scopes')
        session = f.recorder_session()
        record = f.record()
        record['containment'] = 'TEST ONLY: implementation remains held; evidence review remains available.'
        before = f.state()
        refused = False
        try:
            s.OWNER.andon(session, 'plan', {'record': record})
        except s.OWNER.u.Refusal:
            refused = True
        s.write(f.evidence / 'OBSERVATION.json', {'test_only': True, 'refused': refused,
            'state_unchanged': before == f.state()})
        self.assertTrue(refused)
        self.assertEqual(before, f.state())

    def test_adapter_refuses_missing_scope_fields_before_recording_effects(self):
        f = s.Fixture('missing-adapter-scopes')
        request = f.request('record-failure')
        record = f.record()
        record['containment'] = 'TEST ONLY: implementation remains held; evidence review remains available.'
        f.replace_decision(request, 'missing-scopes', record=record)
        refused = False
        try:
            f.admit(request, 'attempt')
        except s.ADAPTER.AdmissionRefused:
            refused = True
        s.write(f.evidence / 'OBSERVATION.json', {'test_only': True, 'refused': refused,
            'records_absent': not (f.root / 'records').exists(),
            'currentness_double_calls': len(s.CURRENTNESS_CALLS)})
        self.assertTrue(refused)
        self.assertFalse((f.root / 'records').exists())
        self.assertEqual(s.CURRENTNESS_CALLS, [])

    def test_both_actual_recording_paths_refresh_current_summary(self):
        for arm in ['arm-a', 'arm-b']:
            with self.subTest(arm=arm):
                f = s.Fixture('summary-' + arm, arm)
                subject = (f.task / 'subject/service.json').read_bytes()
                first = f.admit(f.request('record-failure'), 'initial')
                f.correct()
                rerun = f.request('record-rerun', s.binding(Path(first['receipt_path'])))
                r = f.record(command=f.success)
                r['reason'] = 'TEST ONLY: actual parser rerun passed; ordinary planning reassessment is pending.'
                f.replace_decision(rerun, 'rerun-reason', record=r)
                second = f.admit(rerun, 'rerun')
                rerun_last = '| Last check | ' + r['reason'] + ' |'
                rerun_fresh = rerun_last in f.state().decode()
                post = f.request('record-l1-return', s.binding(Path(second['receipt_path'])))
                r = f.record('policy-conflict' if arm == 'arm-a' else 'none', f.success)
                r['reason'] = 'TEST ONLY: completed post-check planning return; implementation remains unperformed.'
                f.replace_decision(post, 'return-reason', record=r)
                final = f.admit(post, 'return')
                post_fresh = '| Last check | ' + r['reason'] + ' |' in f.state().decode()
                rows = s.rows(f.root / 'records/STATE.md')
                s.write(f.evidence / 'OBSERVATION.json', {'test_only': True,
                    'rerun_summary_fresh': rerun_fresh, 'post_summary_fresh': post_fresh,
                    'row_classes': [x[3] for x in rows], 'stage': final['stage']})
                self.assertTrue(rerun_fresh)
                self.assertTrue(post_fresh)
                self.assertEqual([x[3] for x in rows], ['failed-criterion', 'policy-conflict']
                                 if arm == 'arm-a' else ['failed-criterion'])
                self.assertEqual(rows[0][7], 'resolved')
                self.assertTrue(all('blocked_scope:' in x[5] and 'unblocked_work:' in x[5] for x in rows))
                self.assertEqual((f.task / 'subject/service.json').read_bytes(), subject)
                self.assertFalse(final['implementation_ready'])
                self.assertFalse(final['original_acceptance'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    s.initialize(args.out)
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(RecordCompleteness))
    raise SystemExit(0 if result.wasSuccessful() else 1)
