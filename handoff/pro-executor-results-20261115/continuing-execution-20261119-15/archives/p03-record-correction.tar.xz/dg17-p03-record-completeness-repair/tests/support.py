"""Fresh R4 controls only; never a producer of actual actor/Root evidence."""
from __future__ import annotations
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import re

PACKET = Path(__file__).resolve().parents[1]
OUT = None
OWNER = None
ADAPTER = None
CURRENTNESS_CALLS = []
CURRENTNESS_MODE = "valid"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")
    return binding(path)


def binding(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=sha(raw))


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def initialize(output, original=False):
    global OUT, OWNER, ADAPTER
    OUT = output.resolve()
    OUT.mkdir()
    write(OUT / "CONTROLLED_TEST_ONLY.json", dict(test_only=True,
        actual_actor=False, actual_Root_receiving=False, live_controller=False,
        native_or_original_acceptance=False, source_variant="original-owner-exact-r3" if original else "new-r4"))
    OWNER = load(PACKET / ("inputs/original/hosted_phase.py" if original else "source/hosted_phase.py"), "controlled_owner")
    ADAPTER = load(PACKET / ("inputs/root_callsite.r3.py" if original else "root_callsite.py"), "controlled_adapter")
    # The RED r3 copy is located under inputs; point its data-only BASE at the
    # prospective contract under test. This does not change its pinned hashes.
    ADAPTER.BASE = PACKET
    ADAPTER._invoke_currentness = currentness_double


def reset_currentness(mode="valid"):
    global CURRENTNESS_MODE
    CURRENTNESS_MODE = mode
    CURRENTNESS_CALLS.clear()


def currentness_double(capture, interface):
    """No process or helper is invoked. Every saved descriptor says TEST ONLY."""
    CURRENTNESS_CALLS.append(dict(capture=str(capture), argv=interface["argv"], cwd=interface["cwd"]))
    folder = capture / "commands"
    folder.mkdir()
    controller = "dg16-dg18-recovery-20261119-b"
    if CURRENTNESS_MODE == "old-controller":
        controller = "dg16-dg18-recovery-20261118"
    stdout = ("refs/implementaudit/continuity-receipts/" + controller + "/G00A1@" + "1" * 40 + "\n").encode()
    stderr = b"TEST ONLY: refused currentness\n" if CURRENTNESS_MODE == "stderr" else b""
    if CURRENTNESS_MODE == "ambiguous":
        stdout += stdout
    (folder / "001-root-currentness.log").write_bytes(stdout)
    (folder / "001-root-currentness.stderr").write_bytes(stderr)
    value = dict(argv=interface["argv"], cwd=interface["cwd"], started_at_unix=1.0, ended_at_unix=2.0,
        exit_code=0, expected_exit=0, timed_out=False, process_cleanup="owned-process-group-absent",
        owned_pgid=424242, output_file="001-root-currentness.log", output_bytes=len(stdout), output_sha256=sha(stdout),
        output_capture="separate-stdout-stderr", stderr=dict(file="001-root-currentness.stderr", bytes=len(stderr), sha256=sha(stderr)),
        TEST_ONLY=True, synthetic_positive_pgid=True, no_process_started=True,
        no_controller_invoked=True, no_real_receipt=True)
    if CURRENTNESS_MODE == "incomplete":
        del value["owned_pgid"]
    write(folder / "001-root-currentness.json", value)


INITIAL_STATE = """# Controlled recording fixture

## Current phase

| Field | Value |
|---|---|
| Status | open |
| Audit object state | open |

## Audit object state

TEST ONLY: service subject remains unimplemented.

## Andon log

| # | Occ | Phase | Class | Abnormality | Countermeasure | Rerun evidence | Outcome |
|---|---|---|---|---|---|---|---|

## Context epochs

TEST ONLY: this fixture creates no controller.
"""


def rows(path):
    """New focused reader using the documented splitlines/table boundary."""
    section = path.read_text().split("\n## Andon log\n", 1)[1].split("\n## Context epochs", 1)[0]
    return [[cell.strip() for cell in line.strip().strip("|").split("|")]
            for line in section.splitlines() if re.match(r"^\| [0-9]+ \|", line)]


class Fixture:
    def __init__(self, name, arm="arm-a"):
        self.root = OUT / name
        self.root.mkdir()
        self.arm = arm
        self.task = self.root / "task"
        self.task.mkdir()
        self.captures = self.root / "captures"
        self.captures.mkdir()
        self.evidence = self.root / "test-supplied-evidence"
        self.evidence.mkdir()
        self.ordinal = 0
        self.initial_actor = None
        write(self.root / "CONTROLLED_TEST_ONLY.json", dict(test_only=True,
            actor_and_Root_values="Explicit synthetic fixtures; no model or Root decision occurred",
            currentness="Only labeled doubles are permitted", task_git="Actual local fixture repository; no remote"))
        for name in ["TASK.md", "incoming/proposal.json", "subject/service.json"]:
            p = self.task / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes((PACKET / "contracts/scenario" / arm / name).read_bytes())
        self.run("fixture-init", ["/usr/bin/git", "-c", "core.hooksPath=/dev/null", "init", "--initial-branch=p03-controlled"])
        self.run("fixture-add", ["/usr/bin/git", "-c", "core.hooksPath=/dev/null", "add", "TASK.md", "incoming", "subject"])
        self.run("fixture-commit", ["/usr/bin/git", "-c", "core.hooksPath=/dev/null", "-c", "user.name=P03 controlled fixture", "-c", "user.email=fixture@invalid.example", "commit", "-m", "Bind fresh controlled P03 task inputs"])
        self.head = self.run("fixture-head", ["/usr/bin/git", "rev-parse", "HEAD"])
        self.failed = self.check(False)
        self.success = None

    def run(self, label, argv, expected=0):
        return OWNER.u.run(self.captures, label, argv, self.task, expected=expected)

    def check(self, corrected):
        before = (self.task / "incoming/proposal.json").read_bytes()
        self.run("parser-passed" if corrected else "parser-failed", ["/usr/bin/python3", "-B", "-m", "json.tool", str(self.task / "incoming/proposal.json")], 0 if corrected else 1)
        after = (self.task / "incoming/proposal.json").read_bytes()
        assert before == after
        path = sorted((self.captures / "commands").glob("*.json"))[-1]
        return binding(path)

    def correct(self):
        p = self.task / "incoming/proposal.json"
        before = p.read_bytes()
        p.write_bytes((PACKET / "contracts/scenario" / self.arm / "syntax-corrected-proposal.json").read_bytes())
        write(self.evidence / "syntax-correction.json", dict(test_only=True, before_sha256=sha(before), after_sha256=sha(p.read_bytes()), semantic_values_unchanged=True))
        self.success = self.check(True)

    def record(self, classification="failed-criterion", command=None):
        command = command or self.failed
        return dict(classification=classification, witnesses=[Path(command["path"]).name],
            containment="TEST ONLY: preserve implementation subject; blocked_scope: implementation; unblocked_work: evidence review",
            return_owner="L1", owner_source="TEST ONLY: service configuration owner",
            dependencies="TEST ONLY: fresh parser observation and task requirements",
            acceptance="TEST ONLY: parse and all task requirements remain distinct",
            next_action="TEST ONLY: return to L1 for bounded evidence review",
            reason="TEST ONLY: observed planning abnormality; no actor claim")

    def recorder_session(self):
        records = self.root / "records"
        records.mkdir()
        (records / "evidence").mkdir()
        (records / "STATE.md").write_text(INITIAL_STATE)
        return dict(run_root=str(records), output=str(self.captures), task=str(self.task), task_commit=self.head)

    def observation(self, label, subject_sha, sender):
        raw = write(self.evidence / (label + ".capture.json"), dict(TEST_ONLY=True,
            operation=label, sender_fixture=sender, subject_sha256=subject_sha,
            actual_host_observation=False, actual_actor=False, actual_Root_decision=False))
        return write(self.evidence / (label + ".observation.json"), dict(schema="dg17.bound-host-observation.v1",
            sender=sender, tool_call_id="TEST_ONLY:" + label + ":" + self.root.name,
            subject_sha256=subject_sha, raw_result=raw))

    def package(self):
        inventory = binding(PACKET / "contracts/GOVERNOR_INVENTORY_DATA.json")
        review = write(self.evidence / "package-review.TEST_ONLY.json", dict(schema="dg17.ordinary-package-review.v1", reviewer="/TEST_ONLY/reviewer",
            inventory_sha256=inventory["sha256"], disposition="ADMIT_BOUND_ORDINARY_GOVERNOR",
            internal_child_route="none", scope="ordinary-root-currentness-and-recording-only"))
        receiving = write(self.evidence / "package-root.TEST_ONLY.json", dict(schema="dg17.ordinary-package-root-receiving.v1",
            review_sha256=review["sha256"], inventory_sha256=inventory["sha256"], disposition="ADMIT_BOUND_ORDINARY_GOVERNOR",
            internal_child_route="none", scope="ordinary-root-currentness-and-recording-only"))
        return dict(inventory=inventory, review=review, review_observation=self.observation("package-review", review["sha256"], "/TEST_ONLY/reviewer"),
            root_receiving=receiving, root_observation=self.observation("package-root", receiving["sha256"], "/root"))

    def request(self, operation, previous=None):
        self.ordinal += 1
        prefix = f"request-{self.ordinal:03d}"
        after = operation == "record-l1-return"
        command = self.failed if operation == "record-failure" else self.success
        actor_name = "/TEST_ONLY/actor-" + self.root.name
        if self.initial_actor is None or after:
            prompt = (PACKET / "contracts/post-check-prompt-template.txt").read_bytes() + b"\nObservation SHA-256: " + command["sha256"].encode() + b"\n" if after else (PACKET / "contracts/scenario/actor-prompt.txt").read_bytes()
            prompt_path = self.evidence / (prefix + ".prompt.txt"); prompt_path.write_bytes(prompt)
            raw_path = self.evidence / (prefix + ".actor.TEST_ONLY.raw")
            raw_path.write_bytes(b"TEST ONLY synthetic returned text; no model was invoked.\n")
            prompt_desc, raw_desc = binding(prompt_path), binding(raw_path)
            actor = dict(name=actor_name, stage="post-check" if after else "initial", prompt=prompt_desc,
                raw_return=raw_desc, dispatch_observation=self.observation(prefix + "-dispatch", prompt_desc["sha256"], "/root"),
                return_observation=self.observation(prefix + "-return", raw_desc["sha256"], actor_name), observed_command_sha256=command["sha256"])
            if not after:
                self.initial_actor = copy.deepcopy(actor)
        else:
            actor = copy.deepcopy(self.initial_actor)
        classification = ("policy-conflict" if self.arm == "arm-a" else "none") if after else "failed-criterion"
        action = ("retain-contained" if self.arm == "arm-a" else "record-control-return") if after else ("record-failed-criterion" if operation == "record-failure" else "record-successful-rerun")
        decision = dict(schema="dg17.actual-root-recording-decision.v1", actor_return_sha256=actor["raw_return"]["sha256"],
            actor_disposition="ACCEPTED_FOR_RECORDING", action=action, witness_sha256=command["sha256"], record=self.record(classification, command))
        receiving = write(self.evidence / (prefix + ".root.TEST_ONLY.json"), decision)
        proposed = (self.task / "incoming/proposal.json").read_bytes()
        input_binding = write(self.evidence / (prefix + ".input-binding.json"), dict(schema="dg17.json-check-input-binding.v1",
            command_sha256=command["sha256"], task_root=str(self.task), task_head=self.head,
            input_before_sha256=sha(proposed), input_after_sha256=sha(proposed), recorder_sha256=ADAPTER.OWNER_SHA))
        request = dict(schema="dg17.ordinary-recording-call.v1", episode="TEST-ONLY-" + self.root.name,
            operation=operation, workspace=str(self.root), task=dict(root=str(self.task), head=self.head), arm=self.arm,
            source=dict(adapter_sha256=sha(Path(ADAPTER.__file__).read_bytes()), recorder=binding(PACKET / "source/hosted_phase.py"),
                primitive=binding(PACKET / "source/transport_primitives.py"), target_policy=binding(PACKET / "contracts/ORIGINAL_A297_PROTOCOL.md"), package=self.package()),
            scenario_freeze=binding(PACKET / "contracts/SCENARIO_FREEZE.json"), actor=actor, root_receiving=receiving,
            root_observation=self.observation(prefix + "-Root-receiving", receiving["sha256"], "/root"),
            witness=dict(command=command, input_binding=input_binding), previous_admission=previous)
        return request

    def save_request(self, request, label):
        return write(self.evidence / (label + ".request.json"), request)

    def replace_decision(self, request, label, **updates):
        decision = json.loads(Path(request["root_receiving"]["path"]).read_bytes())
        decision.update(updates)
        desc = write(self.evidence / (label + ".root.TEST_ONLY.json"), decision)
        request["root_receiving"] = desc
        request["root_observation"] = self.observation(label + "-Root-receiving", desc["sha256"], "/root")
        return decision

    def admit(self, request, label):
        desc = self.save_request(request, label)
        return ADAPTER.admit(Path(desc["path"]), desc["sha256"], self.root)

    def state(self):
        p = self.root / "records/STATE.md"
        return p.read_bytes() if p.exists() else None

    def latest_attempt(self):
        return max((self.root / "admissions").iterdir(), key=lambda p:p.stat().st_mtime_ns)
