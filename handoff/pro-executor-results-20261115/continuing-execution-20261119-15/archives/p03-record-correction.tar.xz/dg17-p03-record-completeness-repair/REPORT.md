# Prospective P03 record-completeness repair

Source-only successor; no actual episode or actor replay and no original award. The independently received actual episode and its353files remain immutable. A separate Root-owned current-record correction is at ../p03-current-record-correction/CURRENT_RECORDS.json.

The adapter now refuses every classed record lacking exactly one nonempty blocked_scope: and unblocked_work: field in its containment projection, before currentness/record effects. The dedicated recorder enforces the same requirement before writing any row. Successful rerun and all post-check L1 returns now update the current Last check from the actual supplied Root decision. The prospective adapter binds the exact repaired recorder hash. All scenario, actor prompt, target policy, currentness and primitive contracts remain unchanged.

Focused regression: actual5b780b/1 ran3tests with4failures against original source. The first attempted source edit f30292/1 failed before any source write because copied source retained read-only mode. An erroneously continued control invocation42b233/1 ran the unchanged source again and failed identically; the directory named green/ is this failed unchanged-source repetition, not a pass. It remains retained. Only the new Root-owned candidate source copies were made writable; original sealed sources remained unchanged. Actual0b73c2/0 applied the source repair; actualc44115/0 ran the same3tests successfully, including both real controlled recording sequences. The successful results are in green-after-source-repair/.

Controls explicitly use TEST_ONLY actor/Root/currentness doubles. Their Git/parser commands are real local fixture operations, not original actors or authentic currentness observations. They check missing-scope refusal without state effects, adapter rejection before currentness/recording, fresh rerun/return summaries, retained failed witness/resolved row, correct separate policy-conflict class and unchanged service subjects. No test or helper supplies model metadata.

Recorder SHA-256: f7d703fd2577d1d1f81c821d883b51840d1bc842585b967c5b197c887c600f18
Adapter SHA-256: f58200ef751f8213e98f22f3b7a962ab0c747697f527d0b807d2d2a71d2b24cb

Independent exact source/current-record receiving remains pending. The original P03 behavioral conjunction is independently observed; complete original model-case qualification remains open on exact exposed model/version/configuration evidence. No native or whole-DG17 claim is made.
