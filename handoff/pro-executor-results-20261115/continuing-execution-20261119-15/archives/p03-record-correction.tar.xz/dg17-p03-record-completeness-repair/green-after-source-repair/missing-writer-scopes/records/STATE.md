# Controlled recording fixture

## Current phase

| Field | Value |
|---|---|
| Status | open |
| Audit object state | open |

## Audit object state

TEST ONLY: service subject remains unimplemented.

## Andon log

| # | Occ | Phase | Class | Abnormality | Countermeasure | Rerun evidence | Outcome |
|---|---|---|---|---|---|---|---|

## Context epochs

TEST ONLY: this fixture creates no controller.
