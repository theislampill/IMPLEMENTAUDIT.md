"""Read-only bounded receiving; writes only this review's verification result."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re

OUT = Path(__file__).resolve().parent
COR = Path('/workspace/scratch/530bc07ea12b/p03-current-record-correction')
NEW = Path('/workspace/scratch/530bc07ea12b/dg17-p03-record-completeness-repair')
OLD = Path('/workspace/scratch/2678f1e431c3/dg17-p03-prospective-r4-20261119')
EP = Path('/workspace/scratch/530bc07ea12b/p03-episode-receiving/EPISODE_MANIFEST.json')
errors = []
def need(ok, text):
    if not ok:
        errors.append(text)
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def desc(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=sha(b))
def checked(row, base=None):
    p = Path(row['path'])
    if not p.is_absolute():
        p = base / p
    d = desc(p)
    need(d['bytes'] == row['bytes'] and d['sha256'] == row['sha256'], 'descriptor mismatch ' + str(p))
    return d
def json_read(p):
    return json.loads(p.read_text())
def refs(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            yield value
        for v in value.values():
            yield from refs(v)
    elif isinstance(value, list):
        for v in value:
            yield from refs(v)
def rows(text):
    section = text.split('\n## Andon log\n', 1)[1].split('\n## Context epochs', 1)[0]
    return [[v.strip() for v in s.strip().strip('|').split('|')]
            for s in section.splitlines() if re.match(r'^\| [0-9]+ \|', s)]

expected = {
    COR / 'CURRENT_RECORDS.json': '6a2bb8695ab5cddecd30d2428bbf0e2af350c155099273711f276af11fcaab61',
    NEW / 'MANIFEST.json': '733c02b1b1f7ca7c2316771345c47b7e92289ebe853d436013257725169733af',
    NEW / 'SOURCE_REPAIR.patch': 'e3e9faf7166715dd01e45d5e1964495213145a8fa6889ea890b31eb5412c65dc',
    NEW / 'source/hosted_phase.py': 'f7d703fd2577d1d1f81c821d883b51840d1bc842585b967c5b197c887c600f18',
    NEW / 'root_callsite.py': 'f58200ef751f8213e98f22f3b7a962ab0c747697f527d0b807d2d2a71d2b24cb',
    OLD / 'source/hosted_phase.py': '33a4eccc631cfc1e031e886f2b6f77b1502799a9242d72311be27d819474a7e0',
    OLD / 'root_callsite.py': '8cd14886d451007ec1d580362b098aaca1a63b610cc931013169f90fec4a8c20',
    EP: 'e986c73611a5f4c6478db30ef5b8539596ac2b5ad5d6605a34cec0835a011119',
}
for p, h in expected.items():
    need(desc(p)['sha256'] == h, 'commissioned or original pin mismatch ' + str(p))
episode = json_read(EP)
original_members = [checked(r) for r in episode['files']]
need(len(original_members) == 353 and sum(r['bytes'] for r in original_members) == 847577, 'original population differs')
manifest = json_read(NEW / 'MANIFEST.json')
source_members = [checked(r, NEW) for r in manifest['files']]
declared = {str((NEW / r['path']).resolve()) for r in manifest['files']}
actual = {str(p.resolve()) for p in NEW.rglob('*') if p.is_file() and p != NEW / 'MANIFEST.json'}
need(declared == actual, 'prospective source population has missing or extra members')

cor = json_read(COR / 'CURRENT_RECORDS.json')
root_decision = json_read(COR / 'ROOT_DECISION.json')
currentness = json_read(COR / 'CURRENTNESS_COMMAND.json')
checked_refs = [checked(r) for j in [cor, root_decision, currentness] for r in refs(j)]
need(root_decision['original_episode_manifest']['sha256'] == expected[EP], 'correction refers to another episode')
need(root_decision['actual_owner'] == '/root', 'correction owner differs')
need(currentness['exit_code'] == 0 and currentness['started_at'] < currentness['ended_at'], 'currentness terminal observation invalid')
interface = json_read(OLD / 'contracts/ROOT_CURRENTNESS_INTERFACE.json')
need(currentness['argv'] == interface['argv'] and currentness['cwd'] == interface['cwd'], 'currentness interface differs')
stdout = (COR / 'currentness.stdout').read_text()
need(bool(re.fullmatch(r'refs/implementaudit/continuity-receipts/dg16-dg18-recovery-20261119-b/G[0-9A-Z]+@[0-9a-f]{40}\n', stdout)), 'currentness output ambiguous or malformed')
need((COR / 'currentness.stderr').read_bytes() == b'', 'currentness stderr nonempty')
correction_details = []
for r in cor['records']:
    arm = r['arm']
    original = Path(episode['episode_root']) / arm / 'records'
    before = COR / arm / 'before'
    current = COR / arm / 'current'
    for rel in ['STATE.md', 'ordinary-binding.json', 'evidence/governor-events.jsonl']:
        need((before / rel).read_bytes() == (original / rel).read_bytes(), arm + ' before copy differs: ' + rel)
    pre = (before / 'STATE.md').read_text()
    post = (current / 'STATE.md').read_text()
    pre_rows, post_rows = rows(pre), rows(post)
    need(len(pre_rows) == len(post_rows) == r['row_count'], arm + ' row count changed')
    for a, b in zip(pre_rows, post_rows):
        need(a[:5] == b[:5] and a[6:] == b[6:] and b[5].startswith(a[5]), arm + ' changed historical row values')
        for field in ['blocked_scope', 'unblocked_work']:
            vals = re.findall(r'(?:^|;\s*)' + field + r':([^;]*)', b[5])
            need(len(vals) == 1 and bool(vals[0].strip()) and vals[0].strip() != 'none', arm + ' scope field incomplete')
        need('separate post-episode Root correction' in b[5], arm + ' missing temporal correction label')
    old_events = (before / 'evidence/governor-events.jsonl').read_bytes()
    new_events = (current / 'evidence/governor-events.jsonl').read_bytes()
    need(new_events.startswith(old_events), arm + ' historical events modified')
    extra = new_events[len(old_events):].decode().splitlines()
    need(len(extra) == 1, arm + ' has more than one corrective event')
    event = json.loads(extra[0])
    checked_refs.extend(checked(x) for x in refs(event))
    need(event['event'] == 'actual-Root-post-episode-record-correction' and event['actor_replayed'] is False and event['model_qualification_gap_remains'] is True, arm + ' corrective event scope differs')
    prior_bind, new_bind = json_read(before / 'ordinary-binding.json'), json_read(current / 'ordinary-binding.json')
    for k, v in prior_bind.items():
        if k not in ['state_sha256', 'events_sha256']:
            need(new_bind[k] == v, arm + ' historical binding field changed: ' + k)
    need(new_bind['state_sha256'] == sha(post.encode()) and new_bind['events_sha256'] == sha(new_events), arm + ' successor binding mismatch')
    need(new_bind['post_episode_correction']['original_binding']['sha256'] == sha((original / 'ordinary-binding.json').read_bytes()), arm + ' original binding provenance missing')
    checked_refs.extend(checked(x) for x in refs(new_bind))
    expected_post = pre
    for a, b in zip(pre.splitlines(True), post.splitlines(True)):
        # Only row supplements and the arm-b Last check can differ.
        if a != b:
            need((bool(re.match(r'^\| [0-9]+ \|', a)) and bool(re.match(r'^\| [0-9]+ \|', b))) or
                 (arm == 'arm-b' and a.startswith('| Last check |') and b.startswith('| Last check |')),
                 arm + ' unexpected state alteration')
    need(len(pre.splitlines()) == len(post.splitlines()), arm + ' unexpected state line count change')
    if arm == 'arm-b':
        d = json_read(Path(episode['episode_root']) / arm / 'root-receiving/record-l1-return.decision.json')
        need('| Last check | ' + d['record']['reason'] + ' |' in post, 'arm-b Last check differs from actual final Root reason')
    correction_details.append(dict(arm=arm, rows=len(post_rows), original_history_preserved=True,
        state=desc(current/'STATE.md'), binding=desc(current/'ordinary-binding.json'), events=desc(current/'evidence/governor-events.jsonl'),
        diff=''.join(difflib.unified_diff(pre.splitlines(True),post.splitlines(True),fromfile='before',tofile='current'))))

diff = ''
source_changes = {}
for rel in ['source/hosted_phase.py', 'root_callsite.py']:
    a, b = (OLD/rel).read_text(), (NEW/rel).read_text()
    diff += ''.join(difflib.unified_diff(a.splitlines(True), b.splitlines(True), fromfile='a/'+rel, tofile='b/'+rel))
    aa, bb = ast.parse(a).body, ast.parse(b).body
    need(len(aa) == len(bb), 'unexpected top-level source population change: '+rel)
    changed = []
    for x,y in zip(aa,bb):
        if ast.dump(x,include_attributes=False) != ast.dump(y,include_attributes=False):
            changed.append(getattr(y,'name',ast.unparse(y.targets[0]) if isinstance(y,ast.Assign) else type(y).__name__))
    source_changes[rel] = changed
need(diff == (NEW/'SOURCE_REPAIR.patch').read_text(), 'published source patch differs from actual source delta')
need(source_changes == {'source/hosted_phase.py':['andon'], 'root_callsite.py':['OWNER_SHA','actual_decision','admit']}, 'source change scope differs')
unchanged_contracts = []
for f in (NEW/'contracts').rglob('*'):
    if f.is_file():
        rel=f.relative_to(NEW)
        need(f.read_bytes() == (OLD/rel).read_bytes(), 'contract changed: '+str(rel))
        unchanged_contracts.append(str(rel))
need((NEW/'source/transport_primitives.py').read_bytes() == (OLD/'source/transport_primitives.py').read_bytes(), 'transport primitive changed')
retained_controls = {}
for lane in ['red','green','green-after-source-repair']:
    retained_controls[lane] = {f.parent.parent.name:json_read(f) for f in sorted((NEW/lane).glob('*/test-supplied-evidence/OBSERVATION.json'))}
green = retained_controls['green-after-source-repair']
need(green['missing-writer-scopes']['refused'] and green['missing-writer-scopes']['state_unchanged'], 'writer GREEN evidence insufficient')
need(green['missing-adapter-scopes']['refused'] and green['missing-adapter-scopes']['records_absent'] and green['missing-adapter-scopes']['currentness_double_calls'] == 0, 'adapter GREEN evidence insufficient')
for arm in ['arm-a','arm-b']:
    obs=green['summary-'+arm]
    need(obs['rerun_summary_fresh'] and obs['post_summary_fresh'], arm+' summary GREEN evidence insufficient')
    need(obs['row_classes'] == (['failed-criterion','policy-conflict'] if arm=='arm-a' else ['failed-criterion']), arm+' controlled class changed')
need(retained_controls['red'] == retained_controls['green'], 'retained unchanged-source repeat differs in substantive outcomes')
tools = {n:json_read(NEW/n) for n in ['RED_TOOL_RETURN.json','UNPATCHED_REPEAT_TOOL_RETURN.json','SOURCE_REPAIR_TOOL_RETURN.json','GREEN_TOOL_RETURN.json']}
need([tools[n]['exit_code'] for n in tools] == [1,1,0,0], 'retained terminal result exits differ')
result=dict(schema='dg17.p03-independent-correction-verification.v1',status='PASS' if not errors else 'GAP-REVISE',errors=errors,
    commissioned_inputs=[desc(p) for p in expected],original_episode_files=len(original_members),original_episode_bytes=sum(x['bytes'] for x in original_members),
    source_packet_files=len(source_members),source_packet_bytes=sum(x['bytes'] for x in source_members),
    source_inventory_complete=declared==actual,correction_inventory=[desc(p) for p in sorted(COR.rglob('*')) if p.is_file()],
    source_members=source_members,original_members=original_members,checked_references=checked_refs,correction_details=correction_details,
    actual_currentness=currentness,currentness_stdout=stdout,source_changes=source_changes,unchanged_contracts=unchanged_contracts,
    retained_test_observations=retained_controls,retained_terminal_results=tools,
    reviewer_actor_or_parser_replay=False,reviewer_test_suite_rerun=False,reviewer_controller_operations=False,
    F1_current_corrective_record='PASS' if not errors else 'PENDING',F2_current_corrective_record='PASS' if not errors else 'PENDING',
    F3_model_metadata='OPEN',original_award=False)
(OUT/'VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k in ['status','errors','original_episode_files','original_episode_bytes','source_packet_files','source_packet_bytes','source_inventory_complete','source_changes','currentness_stdout','F1_current_corrective_record','F2_current_corrective_record','F3_model_metadata','original_award']},indent=2))
raise SystemExit(0 if not errors else 1)
