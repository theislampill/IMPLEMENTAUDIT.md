#!/usr/bin/env python3
"""Current G132 artifact and binary interfaces; no issuer or protected launcher.

Every original dependency is received by its frozen public digest. Artifact
transport returns authority-NONE evidence. Binary run still requires the actual
single-sender outcome, exact original Root admission and external live bridge
admission. No original sender, encryption or provider call is made by this file.
"""
import argparse,hashlib,json,os,re,stat,sys,time,types
from pathlib import Path

COMPOSITION_SHA='6d6f561278bcf5516bb05098dfc484eeca3094942dc6041bec508231584eec86'
INSTALLATION_SHA='58a831b74aec61df5f159ca72cc5c54bc2d50c13f0aea78651bdfe48f0d8e983'
MAX_RESULT=4*1024**2
ARTIFACT_FIELDS={'schema','state','purpose','installation_index_sha256','phase','context','input_root','results','archive','previous','actual_root','download_call','deadline_unix_ms','journal_path'}
BINARY_FIELDS={'schema','state','purpose','installation_index_sha256','deadline_unix_ms','sender_entry','sender_install_manifest','sender_terminal','sender_receiving','parent_ref_result','admission','journal_directory'}

def need(value,code):
    if not value:raise ValueError(code)
def descriptor(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def encode(value):return (json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def parse(raw):
    need(type(raw) is bytes and 0<len(raw)<=4*1024**2,'BOUNDED_JSON')
    def pairs(items):
        result={}
        for name,value in items:
            need(name not in result,'DUPLICATE_JSON_KEY');result[name]=value
        return result
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _:need(False,'NONFINITE_JSON'))
def stamp(s):return (s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def read_source(path,pin=None,maximum=1024**2):
    p=Path(path)
    need(p.is_absolute() and p.resolve(strict=True)==p and '..' not in p.parts and not any(x.is_symlink() for x in p.parents),'SOURCE_NONALIAS_PATH')
    before=p.lstat()
    need(stat.S_ISREG(before.st_mode) and before.st_nlink==1 and before.st_uid==os.geteuid()
         and stat.S_IMODE(before.st_mode) in (0o400,0o444) and 0<before.st_size<=maximum,'SOURCE_CUSTODY')
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        need(stamp(os.fstat(fd))==stamp(before) and not os.listxattr(fd),'SOURCE_OPEN_CHANGED')
        raw=os.pread(fd,maximum+1,0)
        need(len(raw)==before.st_size and stamp(os.fstat(fd))==stamp(before)==stamp(p.lstat()),'SOURCE_READ_CHANGED')
    finally:os.close(fd)
    need(pin is None or descriptor(raw)==pin,'SOURCE_PIN')
    return raw
def load_body(raw,path,name):
    m=types.ModuleType(name);m.__file__=str(path)
    exec(compile(raw,str(path),'exec'),m.__dict__);return m

class Runtime:
    def __init__(self,packet):
        self.packet=Path(packet)
        raw=read_source(self.packet/'COMPOSITION_SOURCE_INDEX.json',maximum=65536)
        need(descriptor(raw)['sha256']==COMPOSITION_SHA,'EXACT_COMPOSITION_INDEX')
        index=parse(raw);self.composition_index=index
        entry_path=self.packet/'source/current_root_entry.py'
        entry_raw=read_source(entry_path,index['files']['current_root_entry.py'])
        self.entry=load_body(entry_raw,entry_path,'g132_original_current_entry')
        self.modules,_,_=self.entry.load_composition(str(self.packet/'COMPOSITION_SOURCE_INDEX.json'),COMPOSITION_SHA)
        self.sources=self.modules['current_pro_interfaces'].CurrentSources(str(self.packet/'dependencies/installation'))
        self.driver=self.modules['current_control_driver']
        self.binary=self.operator('operator/root-final-operators-01/binary_publish_v3.py','g132_original_binary_owner')
        self.resolver=self.operator('operator/public-receiver-02/author/resolve_artifact.py','g132_original_resolver')
        self.current()
    def operator(self,name,module_name):
        return load_body(self.sources.file(name),self.sources.root/name,module_name)
    def current(self):
        need(descriptor(read_source(self.packet/'COMPOSITION_SOURCE_INDEX.json'))['sha256']==COMPOSITION_SHA,'CURRENT_COMPOSITION_CHANGED')
        for name,pin in self.composition_index['files'].items():read_source(self.packet/'source'/name,pin)
        raw=self.entry.read(self.sources.root/'SOURCE_INDEX.json',65536,source=True)
        need(descriptor(raw)['sha256']==INSTALLATION_SHA,'CURRENT_INSTALLATION_INDEX_CHANGED')
        # Keep the existing complete source population current across the call.
        rows=self.sources.source_index['files']
        paths=list(self.sources.root.rglob('*'))
        need(not any(p.is_symlink() for p in paths) and
             {p.relative_to(self.sources.root).as_posix() for p in paths if p.is_file()}==set(rows)|{'SOURCE_INDEX.json'},
             'CURRENT_INSTALLATION_POPULATION_CHANGED')
        for name in rows:self.sources.file(name)

def load_runtime(packet):return Runtime(packet)
def selected_deadline(config,state,schema,fields,purpose):
    need(type(config) is dict and set(config)==fields and config.get('schema')==schema
         and config.get('state')==state and config.get('purpose')==purpose
         and config.get('installation_index_sha256')==INSTALLATION_SHA,'CURRENT_SELECTION_REQUIRED')
    now=time.time_ns()//1000000;end=config['deadline_unix_ms']
    need(type(end) is int and now<end<=now+600000,'ORIGINAL_DEADLINE_REQUIRED')
    return end
def metadata_inputs(rt,inputs,refs):
    need(type(refs) is dict and set(refs)==set(rt.sources.B.KINDS),'EXACT_METADATA_POPULATION')
    values={k:inputs.body(v) for k,v in refs.items()}
    for raw in values.values():rt.driver.metadata_guard(raw)
    return values
def previous_receiving(rt,inputs,config):
    previous=config['previous'];actual=config['actual_root']
    if config['phase']!='g3_final':
        need(previous is None and actual is None,'NO_UNEXPECTED_FIRST_HOLD');return None,None
    need(type(previous) is dict and set(previous)=={'results','archive','note'} and actual is not None,'ACTUAL_FIRST_HOLD_REQUIRED')
    p=rt.sources.receive_public('g3_initial',config['context'],
        metadata_inputs(rt,inputs,previous['results']),inputs.body(previous['archive'],65536),
        parse(inputs.body(previous['note'],65536)))
    return p,inputs.body(actual,8192)

def receive_artifact(rt,config,actual_download_raw,*,transport=None):
    """One exact returned reference or exact already-downloaded ZIP.

    transport is the same explicit boundary used by the retained resolver's
    controlled tests; the CLI has no transport/URL/host override. It always uses
    the original fetch_once implementation for a required GET.
    """
    end=selected_deadline(config,'ROOT_SELECTED_FOR_CURRENT_ARTIFACT','g132.current-artifact-entry-config.v1',ARTIFACT_FIELDS,'PUBLIC_ARTIFACT_ACQUISITION_ONLY')
    rt.current();s=rt.sources;R=s.receiver;s.context(config['context'])
    phase=config['phase'];need(phase in R.PHASES,'FIXED_ARTIFACT_PHASE')
    inputs=rt.entry.PublicInputs(config['input_root'])
    results=metadata_inputs(rt,inputs,config['results'])
    prior,actual_root=previous_receiving(rt,inputs,config)
    candidate=R.candidate(s,phase,config['context'],results['artifacts'])
    artifact_id=candidate['id'];file_name=R.artifact_name(phase,config['context'])+'.zip'
    call={'tool':'mcp__codex_apps__github_download_workflow_artifact','arguments':{
        'repo_full_name':config['context']['repository'],'artifact_id':artifact_id,'file_name':file_name}}
    need(config['download_call']==call,'EXACT_ACTUAL_DOWNLOAD_CALL_REQUIRED')
    note=R.download_note(actual_download_raw,artifact_id,file_name)
    cap=R.PHASES[phase][2]
    need(type(candidate.get('size_in_bytes')) is int and 0<candidate['size_in_bytes']<=cap
         and type(candidate.get('digest')) is str and re.fullmatch('sha256:[0-9a-f]{64}',candidate['digest']),'ACTUAL_PROVIDER_ARCHIVE_DESCRIPTOR')
    expected={'bytes':candidate['size_in_bytes'],'sha256':candidate['digest'][7:]}
    journal=rt.driver.Journal(config['journal_path']);body=None;attempts=0;url=None
    try:
        journal.reserve(sum(map(len,results.values()))+cap+MAX_RESULT+131072)
        for kind,raw in results.items():journal.write(kind+'.RESULT.json',raw)
        # Explicit signed-URL exception: exact raw digest + original complete
        # redacted note; the ephemeral raw wrapper never reaches disk or output.
        journal.write('download.INTENT.json',encode({'tool':call['tool'],'arguments':call['arguments']}))
        journal.write('download.READY.json',encode(note))
        view=types.SimpleNamespace(path=journal.path,ready=lambda kind:rt.entry.read(journal.path/'download.READY.json',MAX_RESULT))
        original=types.SimpleNamespace(parse=R.parse,desc=R.desc,download_note=R.download_note,
            read=lambda p:rt.entry.read(p,MAX_RESULT))
        url,reference=rt.resolver.exact_reference(original,view,actual_download_raw)
        actual_download_raw=None
        seconds=min(45,s.binding['limits']['command_seconds'],(end-time.time_ns()//1000000)/1000)
        need(0<seconds<=45,'ORIGINAL_ACQUISITION_WINDOW')
        start=time.monotonic();deadline=start+seconds
        intent={'schema':'g132.current-artifact-body-intent.v1','authority':'NONE',
            'phase':phase,'context':config['context'],'reference':reference,'expected_body':expected,
            'source':'EXACT_DOWNLOADED_ZIP' if config['archive'] is not None else 'ONE_RETURNED_REFERENCE_GET',
            'archive_selection':config['archive'],'acceptance_deadline_monotonic':deadline,
            'deadline_unix_ms':end,'max_body_get_attempts':0 if config['archive'] is not None else 1,
            'automatic_retry':False,'signed_url_retained':False,'original_awards':[]}
        journal.write('BODY_INTENT.json',encode(intent))
        if config['archive'] is None:
            need(time.monotonic()<deadline,'BODY_GET_START_DEADLINE');attempts=1
            body=(rt.resolver.fetch_once if transport is None else transport)(url,cap,seconds)
        else:body=inputs.body(config['archive'],cap)
        url=None
        need(type(body) is bytes and 0<len(body)<=cap and descriptor(body)==expected,'ACTUAL_BODY_DIGEST_OR_SIZE_CHANGED')
        need(time.monotonic()<deadline and time.time_ns()//1000000<end,'BODY_RETURNED_AFTER_ORIGINAL_DEADLINE')
        journal.write('ARTIFACT.zip',body)
        received=s.receive_public(phase,config['context'],results,body,note,prior,actual_root)
        rt.current()
        need(time.monotonic()<deadline and time.time_ns()//1000000<end,'RECEIVING_CLOSED_AFTER_ORIGINAL_DEADLINE')
        outcome={'schema':'g132.current-artifact-acquisition-receiving.v1','authority':'NONE',
            'status':'RECEIVED_REQUIRES_ROOT_AUTHENTICATION','receipt':received['receipt'],
            'download_note':descriptor(encode(note)),'resolver_body_get_attempts':attempts,
            'signed_url_retained':False,'automatic_retry':False,'original_awards':[],
            'authentication_boundary':'ACTUAL_ROOT_TOOL_HISTORY_AND_PROVIDER_AUTHENTICATION_REQUIRED',
            'effect_grant':False}
        journal.write('RECEIVING.json',encode(outcome));return outcome
    except BaseException as error:
        # Preserve real failures without URL/exception text or absence inference.
        try:journal.write('UNKNOWN.json',encode({'schema':'g132.current-artifact-refusal.v1','authority':'NONE',
            'status':'REFUSED_OR_UNCERTAIN_NO_REPLAY','error_class_code':rt.resolver.failure_class(error),
            'resolver_body_get_attempts':attempts,'observed_body':descriptor(body) if type(body) is bytes else None,
            'automatic_retry':False,'no_effect_inferred':False,'signed_url_retained':False,'original_awards':[]}))
        except BaseException:pass
        raise
    finally:
        url=None;actual_download_raw=None;journal.close()

def bound_binary(rt,ref,maximum,source=False):
    need(type(ref) is dict and set(ref)=={'path','bytes','sha256'} and type(ref['bytes']) is int
         and 0<ref['bytes']<=maximum and type(ref['sha256']) is str and re.fullmatch('[0-9a-f]{64}',ref['sha256']),'EXACT_BINARY_INPUT_SELECTION')
    return rt.entry.read(ref['path'],maximum,{k:ref[k] for k in ('bytes','sha256')},source=source)

def prepare_binary(rt,config,*,require_admission=False):
    """Receive a real already-finished sender; never calls sender()."""
    end=selected_deadline(config,'ROOT_SELECTED_FOR_CURRENT_BINARY','g132.current-binary-entry-config.v1',BINARY_FIELDS,'EXACT_EXISTING_CIPHERTEXT_PUBLICATION_ONLY')
    rt.current();B=rt.binary
    entry_raw=bound_binary(rt,config['sender_entry'],1024**2,source=True)
    install_raw=bound_binary(rt,config['sender_install_manifest'],4*1024**2)
    manifest=parse(install_raw)
    need(manifest['members']['root_sender_entry.py']==descriptor(entry_raw),'ACTUAL_SENDER_INSTALL_SOURCE')
    terminal_raw=bound_binary(rt,config['sender_terminal'],65536);terminal=parse(terminal_raw)
    need(terminal['result']['status']=='PAYLOAD_READY','NO_REENCRYPTION_OR_UNREADY_READ')
    E=load_body(entry_raw,config['sender_entry']['path'],'g132_actual_finished_sender_source')
    loader,m,binding,selection,archive=E.inputs()  # No sender invocation.
    rt.sources.context(selection['operation']['context'])
    directory=m.carrier.session_path(binding,selection['operation']['context'],root=True)
    outcome_raw=m.files.read_file(directory/'OUTCOME.json',65536,private=True)[0]
    outcome=m.policy.parse(outcome_raw,65536)
    need(outcome['public']==terminal['result'] and outcome['public']['cleanup_complete'] is True,'ACTUAL_SINGLE_SENDER_OUTCOME')
    files={n:m.files.read_file(directory/n,m.policy.MAX_CONTROL if n=='CONTROL.json' else m.policy.MAX_CIPHERTEXT,private=True)[0] for n in ('CONTROL.json','INPUTS.cms')}
    request=m.provider.artifact_files(archive)['REQUEST.json'];m.carrier.require_auth_enveloped(files['INPUTS.cms'])
    now=lambda:time.time_ns()//1000000
    plan=B.plan(m.policy,m.provider,binding,request,terminal,files['CONTROL.json'],files['INPUTS.cms'],now())
    plan['expires_unix_ms']=min(plan['expires_unix_ms'],selection['operation']['expires_unix_ms'],end)
    parent_raw=bound_binary(rt,config['parent_ref_result'],MAX_RESULT);rt.driver.metadata_guard(parent_raw)
    parent=B.unwrap(parent_raw,'https://api.github.com/repos/'+plan['repository']+'/git/ref/heads/'+plan['branch'])
    need(parent.get('ref')=='refs/heads/'+plan['branch'] and parent.get('object',{}).get('type')=='commit'
         and parent['object']['sha']==plan['parent_sha'],'ACTUAL_EXPECTED_PARENT_REF')
    receiving_raw=bound_binary(rt,config['sender_receiving'],4*1024**2)
    expected=dict(schema='dg16.root-binary-cipher-publication-admission.v2',issuer_thread=B.ISSUER,
        successor='PRO-EXECUTOR-01, designated by owner',context=plan['context'],branch=plan['branch'],parent_sha=plan['parent_sha'],
        sender_receiving=descriptor(receiving_raw),sender_install_manifest=descriptor(install_raw),
        sender_terminal=descriptor(terminal_raw),parent_ref_result=config['parent_ref_result'],files=plan['files'],request=plan['request'],
        readback_profile=B.READBACK_PROFILE,file_reader_source_sha256=B.FILE_READER_SHA,frame_seconds=B.FRAME_SECONDS,
        argument_chunk_bytes=B.ARGUMENT_CHUNK_BYTES,expected_tree=plan['expected_tree'],journal_directory=config['journal_directory'],
        deadline_unix_ms=plan['expires_unix_ms'],tools=list(B.TOOLS),automatic_retry=False,private_key_operation=False,original_awards=[])
    if require_admission:
        need(config['admission'] is not None,'ACTUAL_ROOT_BINARY_PUBLICATION_ADMISSION')
        admission=parse(bound_binary(rt,config['admission'],65536))
        need(admission==expected and now()<plan['expires_unix_ms'],'ACTUAL_ROOT_BINARY_PUBLICATION_ADMISSION')
    else:need(config['admission'] is None,'PREPARATION_DOES_NOT_ISSUE_OR_CONSUME_ADMISSION')
    def current():
        rt.current()
        m.carrier.current_binding(binding);m.sender_policy.current(selection);loader.current()
        for name,maximum,source in (('sender_entry',1024**2,True),('sender_install_manifest',4*1024**2,False),
            ('sender_terminal',65536,False),('sender_receiving',4*1024**2,False),('parent_ref_result',MAX_RESULT,False)):
            bound_binary(rt,config[name],maximum,source)
    current()
    return types.SimpleNamespace(plan=plan,expected_admission=expected,files=files,request=request,
        policy=m.policy,provider=m.provider,current=current,now=now)

def public_binary_preparation(prepared):
    p=prepared.plan
    return {'schema':'g132.current-binary-preparation.v1','authority':'NONE','state':'PREPARED_NOT_AUTHORIZED',
        'plan':p,'required_root_admission':prepared.expected_admission,'admission_issued':False,
        'publication':{'kind':'CONTROL_DATA_ONLY','phase':'cipher','ref_state':'PRESENT','branch':p['branch'],'parent_sha':p['parent_sha'],
            'writes':5,'reads':6,'paths':['CONTROL.json','INPUTS.cms']},
        'provider_calls':0,'sender_invoked':False,'original_awards':[]}

def run_binary(rt,config):
    prepared=prepare_binary(rt,config,require_admission=True)
    journal=rt.driver.Journal(config['journal_directory'])
    try:
        return rt.binary.run(prepared.policy,prepared.provider,prepared.plan,prepared.files,prepared.request,
            journal,rt.driver.metadata_guard,rt.resolver.read_ephemeral_frame,
            lambda event:print(encode(event).decode(),end='',flush=True),prepared.now,prepared.current)
    finally:journal.close()

def main():
    need(os.name=='posix' and sys.platform=='linux' and os.getuid()==os.geteuid()>0
         and sys.flags.isolated and sys.dont_write_bytecode,'DEDICATED_NONROOT_ISOLATED_PROCESS_REQUIRED')
    parser=argparse.ArgumentParser()
    parser.add_argument('command',choices=['check','artifact-receive','binary-prepare','binary-run'])
    parser.add_argument('--packet',required=True);parser.add_argument('--configuration')
    parser.add_argument('--configuration-sha256')
    args=parser.parse_args();rt=load_runtime(args.packet)
    if args.command=='check':
        need(args.configuration is None and args.configuration_sha256 is None,'NO_CHECK_CONFIGURATION')
        print(encode({'schema':'g132.current-interface-source-check.v1','authority':'NONE','state':'UNISSUED',
            'composition_index_sha256':COMPOSITION_SHA,'installation_index_sha256':INSTALLATION_SHA,
            'original_host_launch_available':False,'provider_calls':0,'original_awards':[]}).decode(),end='');return 0
    need(args.configuration is not None and type(args.configuration_sha256) is str
         and re.fullmatch('[0-9a-f]{64}',args.configuration_sha256),'EXACT_CONFIGURATION_REQUIRED')
    raw=rt.entry.read(args.configuration,65536)
    need(descriptor(raw)['sha256']==args.configuration_sha256,'CONFIGURATION_PIN')
    config=parse(raw)
    if args.command=='binary-prepare':
        print(encode(public_binary_preparation(prepare_binary(rt,config))).decode(),end='');return 0
    need(sys.stdin.isatty(),'ORIGINAL_NOECHO_FRAME_REQUIRED')
    if args.command=='artifact-receive':
        # Selection must refuse before accepting any ephemeral tool result.
        selected_deadline(config,'ROOT_SELECTED_FOR_CURRENT_ARTIFACT','g132.current-artifact-entry-config.v1',ARTIFACT_FIELDS,'PUBLIC_ARTIFACT_ACQUISITION_ONLY')
        actual=rt.resolver.read_ephemeral_frame(MAX_RESULT)
        result=receive_artifact(rt,config,actual);actual=None
        print(encode(result).decode(),end='',flush=True);return 0
    result=run_binary(rt,config)
    return 0 if result is not None else 1

if __name__=='__main__':
    try:code=main()
    except BaseException:
        print('{"event":"failure","status":"REFUSED_OR_UNKNOWN_NO_REPLAY","authority":"NONE","original_awards":[]}',flush=True);code=1
    raise SystemExit(code)

