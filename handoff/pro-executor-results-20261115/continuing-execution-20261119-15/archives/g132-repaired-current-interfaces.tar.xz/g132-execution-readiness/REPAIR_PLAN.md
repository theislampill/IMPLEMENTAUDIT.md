# Two bounded current-interface repairs

1. Preserve READONLY_FINDINGS.md and exact input/capability receipts before source work.
2. Exercise current-path regression first; it must fail because the current composition is absent.
3. Add one current operator with fixed artifact acquisition/receiving and binary preparation/publication entries. Pin the unchanged twelve-file source composition and157-file installation. Reuse original pure artifact predicates, binary plan/receive/run, current relocatable Journal and original frame reader.
4. Exercise TEST_ONLY complete public artifact transport and eleven synthetic binary provider returns; refuse wrong artifact/ZIP/context/reference/readback, replays and UNISSUED config. No original sender or provider calls.
5. Seal source, tests, map and results for independent receiving. Actual source adoption, authentic sender/capture, host execution, two Root decisions and original acceptance remain outside this lane.

No original byte body is rewritten; no historical path or17MB recovery package is recreated. Original authority, predicates, population, hashes, deadlines, windows, journals and UNKNOWN_NO_REPLAY remain binding.
