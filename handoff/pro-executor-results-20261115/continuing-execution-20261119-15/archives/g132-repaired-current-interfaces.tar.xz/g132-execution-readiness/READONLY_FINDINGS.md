# G132 read-only findings before ordinary interface repair

Report state: PARTIAL. Authority: NONE. Root owns adoption, admissions, provider operations and all awards.

The original source packet is /workspace/scratch/2678f1e431c3/g132-actual-candidate-source-received-20261119. Its current selected unreferenced commit is bd347ba6848e976c993ec82f5aa85d8e5964f6e1, tree bc3f8f1a10cbea041a6bf066acda113f3252360b, parent 301aeecde08ba6f169bc3cd837eae6f6ad068219. Protected 625f remains; historical301 remains UNKNOWN_NO_REPLAY. No new grant follows from this review.

Root's /workspace/scratch/530bc07ea12b/receiving/G132_ELEVEN_INPUTS_VERIFIED.json receives all eleven original private inputs, 647343 bytes. This lane read that receipt's metadata, not the private bodies. The earlier retained-input packet already demonstrates exact private role/core binding and package relation; it supplies no fresh host or native award.

Current source integrity (actual tool7573a2/0):240 source-packet manifest entries,157 installation entries plus index and12 runtime entries all match, with exact installation/runtime populations. Installation index58a831b74aec61df5f159ca72cc5c54bc2d50c13f0aea78651bdfe48f0d8e983; composition index6d6f561278bcf5516bb05098dfc484eeca3094942dc6041bec508231584eec86.

Two concrete composition gaps:
1. Indexed operator/public-receiver-02/author/resolve_artifact.py main calls a sibling full receiver.py pinned68d343...; that full module is not in the157-file installation. CurrentSources.receive_public and the pure receiver remain complete. Available current connector github_download_workflow_artifact returns a reusable ZIP reference. A current bounded acquisition/receiving entry can join those existing components without regenerating the lost monolith.
2. Indexed binary_publish_v3.py contains the exact two-leaf plan/receive/run and bridge.publish supports five writes/six reads. Its full CLI pins control_process_v3.py, whose Journal/read_owned require obsolete /workspace/scratch/48c1b1d4cf7d/... . Current relocatable Journal and current framed bridge already exist. A current binary entry can compose unchanged binary predicates with them. No sender/encryption rewrite is needed.

Current physical sender observations (39a0a1/0):UID/EUID/GID/EGID1000; Linux/Python3.12.14; single proc PID view; self pidfd_open and signal0 pass; self/all-child WNOWAIT give ECHILD; PR_GET_CHILD_SUBREAPER returns0. No SET, fork, capture, encryption or private inputs occurred. Actual selected phase already pins env56144/eb1c64... and openssl1103304/acc101..., matching current bytes. The earlier inert-template mismatch is not selected source. Binary ownership65534 is not independently a sender refusal: its actual command gate checks the exact bodies/modes; other maintained root-trust helpers are outside the extracted _CaptureChildren sender owner. Missing task children file is not alone a blocker because that owner has bounded proc fallback.

Not yet proven: subreaper SET/restoration, actual nonroot three-FD capture, actual current file/proc closure, same-host root island and exact Ubuntu24.04/Python3.12.3 native bank, original G1, both hosted G3 holds/consumers, actual independent applicability and terminal custody. These are live prerequisites, not claims that the generic capability is absent.

Root continuity re-entry:Root reports actual d9aeb8/0 require-current check for G0007@9259a8aac63ed397ae06efc24f700b286b410bd1 after this child's compaction. This lane did not mutate the Root controller.

Root subsequently authorized only the two ordinary interface repairs within this directory. Old sources stay untouched; controlled tests are TEST_ONLY. No provider write, original private sender, protected launch, source adoption, new grant or original acceptance is authorized here.

