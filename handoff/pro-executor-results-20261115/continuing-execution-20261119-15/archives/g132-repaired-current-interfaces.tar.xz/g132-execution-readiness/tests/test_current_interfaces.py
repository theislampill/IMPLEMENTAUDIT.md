"""TEST_ONLY: public synthetic data, no original sender, host, provider or grant.

Breaks caught: obsolete dependency/path; wrong artifact/ZIP/hash/context; changed
publication readbacks; replayed journal; UNISSUED operational config.
"""
import ast,base64,copy,datetime,hashlib,importlib.util,io,json,os
from pathlib import Path
import stat,sys,tempfile,time,types,unittest,zipfile

ROOT=Path(__file__).resolve().parents[1]
PACKET=Path('/workspace/scratch/2678f1e431c3/g132-actual-candidate-source-received-20261119')
OPERATOR=ROOT/'current_interfaces.py'
CONTROLS=ROOT/'controls'
def enc(v):return (json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def desc(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def module(p,name):
 m=types.ModuleType(name);m.__file__=str(p);exec(compile(p.read_bytes(),str(p),'exec'),m.__dict__);return m
def ref(p,b):
 p.write_bytes(b);p.chmod(0o600);return {'path':str(p),**desc(b)}
def wrapper(url,v):
 return enc({'content':[],'isError':False,'structuredContent':{'url':url,'display_url':url,'content':v if isinstance(v,str) else enc(v).decode()}})
def context():
 return {'repository':'theislampill/IMPLEMENTAUDIT.md','branch':'pro/dg16-g1-original-g3-32-20261114','workflow_commit':'bd347ba6848e976c993ec82f5aa85d8e5964f6e1','workflow_path':'.github/workflows/dg16-r5-g1-hosted-episode.yml','run_id':'99999999999','run_attempt':1,'job_name':'qualify'}

class CurrentInterfaces(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  CONTROLS.mkdir(mode=0o700,exist_ok=True)
  cls.api=module(OPERATOR,'test_current_interfaces') if OPERATOR.exists() else None
  cls.rt=cls.api.load_runtime(str(PACKET)) if cls.api else None
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='TEST_ONLY_',dir=CONTROLS)
  self.base=Path(self.tmp.name);self.base.chmod(0o700)
 def tearDown(self):self.tmp.cleanup()
 def required(self):
  self.assertIsNotNone(self.api,'Current adapter absent: legacy resolver depends on missing receiver.py and binary Journal requires old workspace')
 def artifact(self):
  self.required();s=self.rt.sources;ctx=context();now=time.time_ns()//1000000
  names=s.receiver.PHASES['terminal'][1]
  files={n:enc({'schema':'TEST_ONLY_PUBLIC_TRANSPORT_NOT_ORIGINAL_EVIDENCE','original_awards':[]}) for n in names if n!='ARTIFACT_MANIFEST.json'}
  files['ARTIFACT_MANIFEST.json']=enc({'schema':'dg16.g1-hosted-artifacts.v1','members':[{'name':n,**desc(b)} for n,b in sorted(files.items())]})
  stream=io.BytesIO()
  with zipfile.ZipFile(stream,'w',compression=zipfile.ZIP_STORED) as z:
   for n,b in files.items():z.writestr(n,b)
  archive=stream.getvalue()
  stamp=lambda ms:datetime.datetime.fromtimestamp(ms/1000,datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
  run={'id':int(ctx['run_id']),'run_attempt':1,'event':'push','status':'completed','conclusion':'success','head_branch':ctx['branch'],'head_sha':ctx['workflow_commit'],'path':ctx['workflow_path'],'repository':{'id':123,'full_name':ctx['repository']},'head_repository':{'id':123,'full_name':ctx['repository']},'run_started_at':stamp(now-5000)}
  jobs={'total_count':1,'jobs':[{'id':456,'run_id':int(ctx['run_id']),'run_attempt':1,'head_sha':ctx['workflow_commit'],'name':'qualify','status':'completed','conclusion':'success','started_at':stamp(now-4000)}]}
  a={'id':789,'name':'dg16-g1-hosted-'+ctx['run_id']+'-1','expired':False,'size_in_bytes':len(archive),'digest':'sha256:'+desc(archive)['sha256'],'created_at':stamp(now-2000),'workflow_run':{'id':int(ctx['run_id']),'head_sha':ctx['workflow_commit'],'head_branch':ctx['branch'],'repository_id':123,'head_repository_id':123}}
  listing={'total_count':1,'artifacts':[a]}
  values={'run':run,'attempt':run,'jobs':jobs,'artifact':listing,'artifacts':listing,'workflow':s.body('tree/'+ctx['workflow_path']).decode()}
  results={k:ref(self.base/(k+'.json'),wrapper(s.endpoint(ctx,789,k),v)) for k,v in values.items()}
  file_name=a['name']+'.zip';url='https://sdmntpr-test-only.oaiusercontent.com/archive.zip?sig=TEST_ONLY'
  uri={'file_id':'file_'+'1'*32,'file_name':file_name,'mime_type':'application/zip','download_url':url}
  raw=enc({'content':[],'isError':False,'structuredContent':{'artifact_id':789,'file_name':file_name,'mime_type':'application/zip','file_uri':uri}})
  cfg={'schema':'g132.current-artifact-entry-config.v1','state':'ROOT_SELECTED_FOR_CURRENT_ARTIFACT','purpose':'PUBLIC_ARTIFACT_ACQUISITION_ONLY','installation_index_sha256':'58a831b74aec61df5f159ca72cc5c54bc2d50c13f0aea78651bdfe48f0d8e983','phase':'terminal','context':ctx,'input_root':str(self.base),'results':results,'archive':ref(self.base/'downloaded.zip',archive),'previous':None,'actual_root':None,'download_call':{'tool':'mcp__codex_apps__github_download_workflow_artifact','arguments':{'repo_full_name':ctx['repository'],'artifact_id':789,'file_name':file_name}},'deadline_unix_ms':now+120000,'journal_path':str(self.base/'receiving')}
  return cfg,raw,archive
 def test_artifact_current_path_unchanged_receiver_and_no_signed_url_retention(self):
  cfg,raw,archive=self.artifact()
  out=self.api.receive_artifact(self.rt,cfg,raw)
  self.assertEqual(out['status'],'RECEIVED_REQUIRES_ROOT_AUTHENTICATION')
  self.assertEqual(out['receipt']['phase'],'terminal')
  self.assertEqual(out['receipt']['archive'],desc(archive))
  self.assertEqual(out['receipt']['original_awards'],[])
  self.assertEqual((self.base/'receiving/ARTIFACT.zip').read_bytes(),archive)
  retained=b''.join(p.read_bytes() for p in (self.base/'receiving').iterdir())
  self.assertNotIn(b'sig=TEST_ONLY',retained)
  self.assertNotIn(b'https://sdmntpr-test-only',retained)
  with self.assertRaises(ValueError):self.api.receive_artifact(self.rt,cfg,raw)
 def test_artifact_one_get_uses_original_fixed_reference_rules(self):
  cfg,raw,archive=self.artifact();cfg['archive']=None;calls=[]
  def transport(url,maximum,seconds):
   calls.append((url,maximum,seconds));return archive
  out=self.api.receive_artifact(self.rt,cfg,raw,transport=transport)
  self.assertEqual(out['status'],'RECEIVED_REQUIRES_ROOT_AUTHENTICATION')
  self.assertEqual(len(calls),1);self.assertEqual(calls[0][1],262144)
  self.assertLessEqual(calls[0][2],45)
 def test_artifact_wrong_download_binding_refuses(self):
  cfg,raw,_=self.artifact();v=json.loads(raw);v['structuredContent']['artifact_id']=790
  with self.assertRaises(ValueError):self.api.receive_artifact(self.rt,cfg,enc(v))
  self.assertFalse((self.base/'receiving/RECEIVING.json').exists())
 def test_artifact_wrong_zip_digest_refuses(self):
  cfg,raw,archive=self.artifact();cfg['archive']=ref(self.base/'wrong.zip',archive+b'changed')
  with self.assertRaises(ValueError):self.api.receive_artifact(self.rt,cfg,raw)
  self.assertFalse((self.base/'receiving/RECEIVING.json').exists())
 def test_artifact_unlisted_reference_host_refuses_before_get(self):
  cfg,raw,_=self.artifact();cfg['archive']=None;v=json.loads(raw);v['structuredContent']['file_uri']['download_url']='https://example.com/archive?sig=TEST_ONLY';calls=[]
  with self.assertRaises(ValueError):self.api.receive_artifact(self.rt,cfg,enc(v),transport=lambda *a:calls.append(a))
  self.assertEqual(calls,[])
 def test_artifact_wrong_context_refuses(self):
  cfg,raw,_=self.artifact();cfg['context']['workflow_commit']='0'*40
  with self.assertRaises(ValueError):self.api.receive_artifact(self.rt,cfg,raw)
  self.assertFalse((self.base/'receiving/RECEIVING.json').exists())
 def test_unissued_configs_refuse_before_selected_inputs_or_journal(self):
  self.required()
  with self.assertRaises(ValueError):self.api.receive_artifact(self.rt,{'state':'UNISSUED'},b'{}')
  with self.assertRaises(ValueError):self.api.prepare_binary(self.rt,{'state':'UNISSUED'})
  self.assertEqual(list(self.base.iterdir()),[])
 def binary_case(self):
  self.required();rt=self.rt;B=rt.binary;s=rt.sources
  # The original full policy has no effectful import; bind only its original codec.
  path=PACKET/'dependencies/installation/phase/tree/qualification/dg16-r5-g1-hosted-episode/carrier/carrier_policy.py'
  old=sys.modules.get('bundle_codec');sys.modules['bundle_codec']=module(path.parent/'bundle_codec.py','TEST_ONLY_original_full_codec')
  try:P=module(path,'TEST_ONLY_original_policy')
  finally:
   if old is None:sys.modules.pop('bundle_codec',None)
   else:sys.modules['bundle_codec']=old
  now=time.time_ns()//1000000;ctx=context()
  request=P.make_request(ctx,s.index,b'TEST_ONLY_CERTIFICATE_NOT_A_RECIPIENT','2'*64,now-1000,now+120000)
  cipher=b'TEST_ONLY_NOT_CMS_NO_ENCRYPTION';control=P.make_control(request,cipher,'3'*64,now)
  files={'CONTROL.json':control,'INPUTS.cms':cipher}
  terminal={'schema':'dg16.root-sender-terminal-export.v1','authority':'NONE','publication_performed':False,'original_awards':[],'ciphertext_members':{n:desc(b) for n,b in files.items()},'result':{'status':'PAYLOAD_READY','cleanup_complete':True,'original_awards':[],'request_sha256':desc(request)['sha256']}}
  p=B.plan(P,s.V,s.binding,request,terminal,control,cipher,now)
  published='4'*40
  writes=[enc({'content':[],'isError':False,'structuredContent':{'sha':x}}) for x in (p['files']['CONTROL.json']['git_blob'],p['files']['INPUTS.cms']['git_blob'],p['expected_tree'],published,published)]
  reads=[]
  for key,call in B.read_plan(p,published):
   if key in ('ref','closing_ref'):v={'ref':'refs/heads/'+p['branch'],'object':{'type':'commit','sha':published}}
   elif key=='commit':v={'sha':published,'parents':[{'sha':p['parent_sha']}],'tree':{'sha':p['expected_tree']}}
   elif key=='tree':v={'sha':p['expected_tree'],'truncated':False,'tree':[{'path':n,'mode':'100644','type':'blob','sha':p['files'][n]['git_blob'],'size':len(b)} for n,b in sorted(files.items())]}
   else:
    n=call['arguments']['path'];b=files[n]
    reads.append(enc({'content':[],'isError':False,'structuredContent':{'content':base64.b64encode(b).decode(),'encoding':'base64','sha':p['files'][n]['git_blob'],'display_url':'https://github.com/theislampill/IMPLEMENTAUDIT.md/blob/'+published+'/'+n,'display_title':n}}));continue
   reads.append(wrapper(call['arguments']['url'],v))
  return P,p,files,request,writes+reads,now
 def test_current_binary_composition_executes_original_five_write_six_read_loop(self):
  P,p,files,request,replies,now=self.binary_case();events=[];q=list(replies)
  journal=self.rt.driver.Journal(str(self.base/'binary'))
  try:
   result=self.rt.binary.run(P,self.rt.sources.V,p,files,request,journal,self.rt.driver.metadata_guard,lambda maximum,seconds:q.pop(0),events.append,lambda:now,lambda:None)
  finally:journal.close()
  self.assertIsNotNone(result);self.assertEqual(result['published_commit'],'4'*40)
  self.assertEqual(result['sole_parent'],p['parent_sha']);self.assertEqual(result['original_awards'],[])
  self.assertEqual(len([e for e in events if e['event']=='intent']),11);self.assertEqual(q,[])
  self.assertEqual(len(list((self.base/'binary').glob('*.RESULT.json'))),11)
  self.assertEqual(events[-1]['event'],'complete')
 def test_binary_changed_tree_refuses_without_success_receipt(self):
  P,p,files,request,replies,now=self.binary_case();value=json.loads(replies[7]);body=json.loads(value['structuredContent']['content']);body['tree'][0]['sha']='9'*40;value['structuredContent']['content']=enc(body).decode();replies[7]=enc(value);q=list(replies)
  journal=self.rt.driver.Journal(str(self.base/'binary_bad'))
  try:r=self.rt.binary.run(P,self.rt.sources.V,p,files,request,journal,self.rt.driver.metadata_guard,lambda maximum,seconds:q.pop(0),lambda e:None,lambda:now,lambda:None)
  finally:journal.close()
  self.assertIsNone(r);self.assertTrue((self.base/'binary_bad/UNKNOWN.json').is_file())
  self.assertFalse((self.base/'binary_bad/RECEIVING.json').exists())
 def test_binary_wrong_cipher_binding_refuses_before_any_loop(self):
  P,p,files,request,_,now=self.binary_case()
  with self.assertRaises(ValueError):P.validate_control(files['CONTROL.json'],files['INPUTS.cms']+b'changed',request,now)

if __name__=='__main__':
 print('TEST_ONLY controlled interface regression; no original awards',flush=True)
 unittest.main(verbosity=2)

