# G132 current execution readiness and interface repairs

Report state: FINAL FOR INDEPENDENT REVIEW. Authority: NONE. New original awards: none. Source adoption and operational readiness are not claimed.

## Outcome

The eleven original private inputs are recovered at their exact647343-byte census. Further generic recovery is not the next engineering task. Two current-interface gaps were found and repaired in current_interfaces.py:

1. The retained artifact resolver's full CLI depended on a missing sibling full receiver.py. The new current entry uses the surviving current installation, original exact_reference/fetch_once/frame rules and unchanged CurrentSources.receive_public.
2. The retained binary publication CLI depended on a journal fixed to the expired48c1b... workspace. The new binary entry composes its unchanged plan/run/receive bodies with the current relocatable Journal and existing model-side bridge.

Ten TEST_ONLY controls pass. The actual isolated source-only CLI passes as UNISSUED with zero provider calls. No original sender, genuine hosted G1/G3 result, Root decision, independent applicability or original award occurred.

## Exact retained identities

The source packet is /workspace/scratch/2678f1e431c3/g132-actual-candidate-source-received-20261119. Its selected commit is bd347ba6848e976c993ec82f5aa85d8e5964f6e1, tree bc3f8f1a10cbea041a6bf066acda113f3252360b, sole parent301aeecde08ba6f169bc3cd837eae6f6ad068219. The offline3f6003... commit remains a different identity. The selected bd object is not a grant.

The protected branch pro/dg16-g1-original-g3-32-20261114 remains at625f310d04cb5b5a1f02901cfdcf3c3815730a5e according to the parent commission. Historical301 effects remain UNKNOWN_NO_REPLAY. This lane made no provider observation or write while producing this interface packet.

Root's receiving/G132_ELEVEN_INPUTS_VERIFIED.json receives all11 original private inputs. The retained-input packet records actual scope, package relation, selected-source, role_check and core_bind observations. This lane read that receipt and public source/evidence, not the private bodies, and did not repeat private binding or regenerate a lost archive.

Actual7573a2/0 checked240 source-manifest entries,157 installation members plus index and12 runtime members: all byte pins match, with exact installation/runtime populations. Installation index SHA25658a831b74aec61df5f159ca72cc5c54bc2d50c13f0aea78651bdfe48f0d8e983 and composition index6d6f561278bcf5516bb05098dfc484eeca3094942dc6041bec508231584eec86 remain exact. INPUT_VERIFICATION_TOOL_RETURN.json retains the complete result and source/receipt descriptors.

## Repairs and preserved predicates

### Artifact entry

The actual connector remains model-side: mcp__codex_apps__github_download_workflow_artifact. The current entry consumes its complete actual wrapper through the original no-echo length frame. Original download_note retains the complete redacted structure and exact original descriptor; signed URLs remain ephemeral. Original exact_reference validates file identity, duplicate references, HTTPS and the fixed connector storage family.

The one-GET mode uses original fetch_once, with no redirects/retry and at most45 seconds. The already-downloaded mode reads a separately pinned owned/nonalias ZIP. Both join the actual provider artifact size/digest, exact six metadata wrappers, source/workflow/run/job, original ZIP population and current source before returning the unchanged pure receiver's evidence. Final-G3 intake also reconstructs the actual first receiving and consumes actual first-Root-decision bytes.

Exclusive current journals refuse replay and retain refusals/uncertainty without inferring absence. Results remain authority-NONE and require actual Root tool-history/provider authentication. Tests used synthetic public terminal transport, not original receiving. The actual current connector wrapper/storage family still needs qualification; an unexpected actual shape/host must refuse rather than be guessed.

### Binary entry

Original binary_publish_v3.py plan, write_call, read_plan, receive and run bodies execute unchanged from their exact pinned file. Original immutable file decoder and no-echo frame reader remain selected. The current Journal replaces only the obsolete workspace dependency.

Preparation still requires a genuine previously completed sender entry/install manifest, PAYLOAD_READY terminal, exact owned OUTCOME, cleanup completion, original cryptographic-envelope check, exact request/control/cipher bodies, current expected parent and actual sender receiving. It calls inputs(), never sender() or encryption. The original Root binary-publication admission schema/relations remain exact; preparation returns requirements without issuing them.

Run requires actual admission, original expiry, fresh journal and current source/input guards. The existing bridge must separately supply live assertCurrent/assertNoReplay authority and full real-result custody. Matching JSON cannot authenticate an issuer.

The binary positive control executes the original core with current Journal and eleven TEST_ONLY provider returns. It does not simulate an authentic post-sender operational CLI admission. Complete genuine execution remains unexecuted.

## Complete path map

PREDICATE_MAP.json provides fourteen precise source/capability rows. Relative source paths refer to the pinned packet.

| Predicate | Existing or repaired path | Exact remaining requirement |
|---|---|---|
|Eleven private inputs/source/package|Original compose/retained relation|Fresh actual private installation/readback|
|Hosted Root tools/recipient|Pinned workflow/bootstrap/carrier/current tools adapter|Actual current UID0 host, profile/tool observation and Root adoption|
|Authentic late sender selection|CurrentSources/original issuer/assembler/dispatcher|Five actual late bodies, genuine Root issuance, exact nonroot installation|
|Contained private sender|Original CaptureSession/_CaptureChildren/current bridge|Actual SET/restoration and child/FD/stream custody; one encryption and18 original metadata returns|
|Encrypted publication|New current binary entry/original5-write6-read core|Actual live admission and provider/readback qualification|
|Original G1|Original hosted run/native prerequisites/raw receiver|Genuine original19 shared-image pair and native bank|
|First Root G3 decision|Current Root requirements/initial publication|Actual first hold, typed absence, host join and timely one-leaf decision|
|G3 JOIN/stale/recompute|Original g3_receiving.consume/proof_consumer|Actual generation transition, current native bookends and stale/missing-return discrimination|
|Second Root decision/independent receiving|Original final validators/M4 joins/two-leaf publication|Genuine reviews, exact row/gate decisions and hosted final consumption|
|Terminal/cold receiving|Original export/new artifact route|Actual closing custody and independent semantic receiving|

The proof consumer's15 proofs,7 supports,2 requests and4 retained-M4 bodies, plus original scope/compiler/owner/consumer source bodies, retain the declared32-input total and8MB aggregate. Original30-second consumer,300-second first hold,600-second shared window,180-second enclosing reserve and60-second final reserve remain unchanged.

Complete G3 acceptance requires all original Q06/L01–L07 rows at their exact scopes. M4 supports only its accepted L04 branch. Natural L04's separate native status, full G2, global liveness, retirement/transfer and whole-DG16 reservations remain. No M6 until the required G1/G2 result JOIN, original48 dispositions and final cold receiving.

## Physical capability evidence

Actual read-only39a0a1/0 observed Linux/Python3.12.14 and UID/EUID/GID/EGID1000. The exact single-proc-view predicate passes. Self pidfd_open/signal0 pass; self/all-child WNOWAIT give ECHILD; PR_GET_CHILD_SUBREAPER returns0. No SET, fork, capture, encryption or private input occurred.

Selected source already pins the current binaries:

|Tool|Bytes|SHA256|
|---|---:|---|
|env|56144|eb1c64bbc9908afcdf8cb48524f17112d8dd76a249f80dee2f01da14747b3b6e|
|openssl|1103304|acc10176d038aeb7b2a77d9ec972ac2985857a7191f7aecb7c54ef0e2c7e9549|

The earlier mismatch came from an inert old template, not selected phase. Observed65534 binary ownership does not independently fail this sender gate, which checks exact bodies/executable modes. Other root-trust helpers are outside the extracted _CaptureChildren class. Missing task/children is not alone a blocker because the original owner has a bounded proc fallback and requires pidfd/kernel-child proof before signaling.

There is no demonstrated physically unavailable sender prerequisite in this read-only subset. Actual subreaper SET/restoration, contained three-FD capture and closing custody remain UNEXECUTED. The original hosted native gate separately requires UID0/Ubuntu24.04/Python3.12.3; local3.12.14 does not satisfy or amend it. Historical Codex tool names do not establish a missing capability.

## Next ordinary work versus safeguards

Independently receive this exact operator, then qualify actual public artifact acquisition and current bridge/frame/readback behavior. Prior P10 tree-GET404 cause remains UNKNOWN; Root now reports successful current public object/ref reads in G2/DG18, so the required API route is testable on fixed ordinary public data. It is not globally unavailable. Native Git receiving of bd is not an automatic runtime API fallback.

Separately qualify actual local contained capture, then pre-position the existing late-body/installation driver and independent final reviewer. These are ordinary engineering and capability tasks; no additional generic recovery is needed. Actual late bodies/decisions must come from the genuine episode. The current source intentionally does not launch the original host or impersonate its consumer.

A fresh protected operation still requires separate safeguards after the complete path is ready. The historical UNKNOWN cannot be replayed. Fresh host/recipient/sender results do not exist until that operation runs; this is an execution/authority dependency, not lost archived source. No new protected grant request is made here.

## Validation and limitations

Baseline77652a exited1 with10 expected failures because the new operator was absent. Its displayed output was truncated and a trailing orchestration expression raised TypeError after the command; the complete original wrapper was not retained and is not invented. First implementationc05c32 exited1:7 passed,3 fixture errors because the test supplied pure codec instead of the present original full codec. Complete failure is retained. Correcting only the fixture produced90f8f9/0,10/10. Complete currentness guards then produced0cb688/0,10/10. Isolated source-check8e2b4d/0 returned UNISSUED and zero provider calls. Final verification binds the final source bytes.

These are TEST_ONLY source/interface controls. They establish no authentic native sender, real connected callbacks, network GET, original G1/G3 award, actual issuer authority or independent applicability. Original dependency bytes and sealed N06 evidence remain unchanged.

Root re-admitted this child after compaction through its actual d9aeb8/0 currentness check of G0007@9259a8aac63ed397ae06efc24f700b286b410bd1, then authorized these two bounded local repairs. The child did not mutate Root custody. Independent review remains required before operational adoption.

