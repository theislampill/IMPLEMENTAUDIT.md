# Current operator contract

This file documents UNISSUED source. It does not authorize any protected launch, private sender, publication or Root grant.

The entry is current_interfaces.py. Its fixed external dependency is the complete source packet /workspace/scratch/2678f1e431c3/g132-actual-candidate-source-received-20261119. It receives the existing composition index6d6f56... and installation index58a831.... It neither modifies nor copies them. Root must independently receive the new operator bytes and select them by exact hash in the existing model-side bridge.

## Source check

The non-effect command is:

    /usr/bin/python3 -I -B current_interfaces.py check --packet /absolute/pinned/source-packet

The remaining fixed commands are artifact-receive, binary-prepare and binary-run. Each requires --packet, --configuration and --configuration-sha256. Configurations are exact owned nonalias0400/0600 files. The operational command uses the actual current Unix clock, nonroot isolated interpreter and unchanged original windows. Artifact/binary run requires a TTY with the original no-echo length frame. The CLI offers no URL, host, transport callback or arbitrary tool selector.

## Artifact configuration

Exact keys are ARTIFACT_FIELDS in the source. State is ROOT_SELECTED_FOR_CURRENT_ARTIFACT; schema g132.current-artifact-entry-config.v1; purpose PUBLIC_ARTIFACT_ACQUISITION_ONLY. The installation_index_sha256 must equal58a831b74aec61df5f159ca72cc5c54bc2d50c13f0aea78651bdfe48f0d8e983.

Context is the original seven owner fields:repository,branch,workflow_commit,workflow_path,run_id,run_attempt,job_name. results binds exactlyrun,attempt,jobs,artifact,artifacts,workflow, each as {path,bytes,sha256} beneath input_root. Every selected file must be actual whole bytes, not a reconstructed wrapper. The exact actual download_call is mcp__codex_apps__github_download_workflow_artifact with repo_full_name, artifact_id and the phase's fixed ZIP filename.

archive is either null for one exact-reference GET or an owned selected downloaded ZIP reference. previous and actual_root are null except g3_final. For g3_final, previous has exactly results/archive/note and reconstructs the actual first receiving; actual_root selects the actual first decision bytes. deadline_unix_ms and journal_path select a fresh owned journal under current custody. All original request expiry/currentness checks remain downstream.

Root first invokes the actual connector under its live provenance and retains its call identity. It sends the complete returned JSON wrapper only after READY_FOR_EPHEMERAL_DOWNLOAD_RESULT_LENGTH_FRAME:decimal UTF-8 byte length, newline, then exact bytes. Signed URLs must never be printed or inserted into command arguments. They are not retained in the journal. The original exact_reference storage rule remains unchanged.

The output journal contains exact six RESULT bodies, download.INTENT.json, redacted download.READY.json, BODY_INTENT.json, ARTIFACT.zip and RECEIVING.json or explicit UNKNOWN. These files can be selected by the existing current Root control entry. The acquisition receipt itself carries no Root/provider authentication and no award.

The adapter's injected transport argument exists only at the same bounded test seam as the retained resolver. Production CLI always uses original fetch_once. TEST_ONLY callers cannot produce authentic provider evidence by passing a callback.

## Binary configuration

Exact keys are BINARY_FIELDS. State ROOT_SELECTED_FOR_CURRENT_BINARY; schema g132.current-binary-entry-config.v1; purpose EXACT_EXISTING_CIPHERTEXT_PUBLICATION_ONLY; exact installation index as above.

All sender_entry, sender_install_manifest, sender_terminal, sender_receiving and parent_ref_result values are exact {path,bytes,sha256} selections. These must come from the actual current completed sender. No test fixture is operational input. journal_directory must be a fresh current owned path; deadline_unix_ms remains within the original recipient/operation expiry.

For binary-prepare, admission is null. Output gives the unchanged original expected Root admission, exact two-file plan and public five-write/six-read specification. No grant is issued. Root separately adjudicates/issues the authentic admission and supplies its exact file reference in a newly hashed configuration for binary-run.

Binary run uses original plan/run/receive and decoder from the immutable installation, current Journal and original frame reader. It never calls old driver_module or recreates the old directory. It validates real sender terminal/OUTCOME/cleanup, exact control/cipher/request and original authenticated-envelope predicate before producing any call intent.

Root uses the existing g132_operator_bridge.js publish and framedProcess capabilities. The process selection pins this operator hash and the binary-run/configuration arguments; exchange_root contains the selected current journal. The publication spec is CONTROL_DATA_ONLY, phase cipher, ref_state PRESENT, exact ciphertext branch/parent, writes5, reads6 and paths CONTROL.json/INPUTS.cms. The model-side transport context retains its original nine fields, including source_commit/source_tree; it is not substituted into seven-field owner context.

Root supplies the bridge's actual live admit capability with currentness/no-replay checks. Actual five writes and six typed readbacks remain mandatory, including immutable file bytes and closing ref. All actual bounded wrappers are retained by the bridge before validation/deadline refusal. Unknown writes are reconciled rather than replayed. A local source PASS or publication receipt cannot prove hosted consumption.

## Integration boundary

This operator does not implement host launch, actual issuer authority, late packet installation/adoption or independent original review. Those existing guarded stages must be pre-positioned before a fresh protected operation. It does not loosen any comparator, population, hash, window, private custody, source or acceptance requirement.

