"""Read-only public-source/custody receiving; no native/provider/sender action."""
from pathlib import Path
import ast
import hashlib
import json
import os
import stat

OUT=Path(__file__).resolve().parent
NEW=Path('/workspace/scratch/530bc07ea12b/g132-execution-readiness')
DEP=Path('/workspace/scratch/2678f1e431c3/g132-actual-candidate-source-received-20261119')
errors=[]
def need(value,why):
    if not value:errors.append(why)
def desc(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p):return json.loads(p.read_text())
def verify(p,pin):
    d=desc(p);s=p.lstat()
    need(d['bytes']==pin['bytes'] and d['sha256']==pin['sha256'],'byte pin mismatch '+str(p))
    need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_uid==os.geteuid(),'source custody mismatch '+str(p))
    need(p.resolve(strict=True)==p and not any(q.is_symlink() for q in p.parents),'source alias '+str(p))
    need(stat.S_IMODE(s.st_mode) in (0o400,0o444) and not os.listxattr(p),'readonly/extended source custody mismatch '+str(p))
    if 'mode' in pin:need(format(stat.S_IMODE(s.st_mode),'04o')==pin['mode'],'declared mode mismatch '+str(p))
    return d

new_manifest=load(NEW/'MANIFEST.json')
need(desc(NEW/'MANIFEST.json')['sha256']=='763fda7d083bf075cb5f5288e38808b79c235ad4b01201d80414bf183879a581','commissioned new manifest mismatch')
new_members=[verify(NEW/r['path'],r) for r in new_manifest['files']]
need(len(new_members)==18 and sum(x['bytes'] for x in new_members)==99044,'commissioned 18-file census mismatch')
allowed={r['path'] for r in new_manifest['files']}
actual={p.relative_to(NEW).as_posix() for p in NEW.rglob('*') if p.is_file()
        and p.relative_to(NEW).parts[0]!='followup-native-probe' and p.name not in {'MANIFEST.json','SEAL_TOOL_RETURN.json'}}
need(actual==allowed,'unlisted/missing source packet members outside explicit exclusions')
need(desc(NEW/'current_interfaces.py')['sha256']=='2f5fdf5021df1db83320d286828898cfdbaaebe13e41acc7716329306f1fbe06','commissioned adapter mismatch')
dep_manifest=load(DEP/'MANIFEST.json')
verify(DEP/'MANIFEST.json',new_manifest['source_packet_manifest'])
dep_members=[verify(DEP/r['path'],r) for r in dep_manifest['files']]
need(len(dep_members)==240,'original manifest census mismatch')
installation=DEP/'dependencies/installation';ii=load(installation/'SOURCE_INDEX.json')
need(desc(installation/'SOURCE_INDEX.json')['sha256']==new_manifest['installation_index_sha256']=='58a831b74aec61df5f159ca72cc5c54bc2d50c13f0aea78651bdfe48f0d8e983','installation index mismatch')
installation_members=[verify(installation/name,pin) for name,pin in ii['files'].items()]
need(len(installation_members)==157,'installation member census mismatch')
install_actual={p.relative_to(installation).as_posix() for p in installation.rglob('*') if p.is_file()}
need(install_actual==set(ii['files'])|{'SOURCE_INDEX.json'},'installation population differs')
ci=load(DEP/'COMPOSITION_SOURCE_INDEX.json')
need(desc(DEP/'COMPOSITION_SOURCE_INDEX.json')['sha256']==new_manifest['composition_index_sha256']=='6d6f561278bcf5516bb05098dfc484eeca3094942dc6041bec508231584eec86','composition index mismatch')
runtime_members=[verify(DEP/'source'/name,pin) for name,pin in ci['files'].items()]
need(len(runtime_members)==12 and {p.name for p in (DEP/'source').iterdir()}==set(ci['files']),'runtime exact population differs')

def functions(path):
    text=path.read_text();t=ast.parse(text);out={}
    for node in ast.walk(t):
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
            out[node.name]={'first_line':node.lineno,'last_line':node.end_lineno,
                           'ast_sha256':hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest()}
    return out
original_functions={}
targets={
    'dependencies/installation/operator/root-final-operators-01/binary_publish_v3.py':['plan','write_call','read_plan','receive','run','file_reader','frame_remaining'],
    'dependencies/installation/operator/public-receiver-02/author/resolve_artifact.py':['exact_reference','fetch_once','read_ephemeral_frame','failure_class'],
    'source/current_control_driver.py':['Journal','metadata_guard'],
    'source/current_root_entry.py':['PublicInputs','read','load_composition'],
    'source/current_pro_interfaces.py':['receive_public','_require_received','context'],
    'dependencies/installation/pure/receiver.py':['candidate','download_note','receive','check_download','provider_join'],
}
for rel,names in targets.items():
    fs=functions(DEP/rel);original_functions[rel]={n:fs[n] for n in names}
    need(rel in {r['path'] for r in dep_manifest['files']},'selected original owner outside original manifest '+rel)

new_ast=ast.parse((NEW/'current_interfaces.py').read_text())
binary_ast=ast.parse((DEP/'dependencies/installation/operator/root-final-operators-01/binary_publish_v3.py').read_text())
def expected_admission_keys(tree):
    rows=[]
    for n in ast.walk(tree):
        if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='expected' for x in n.targets) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='dict':
            rows.append({kw.arg for kw in n.value.keywords})
    return rows
old_keys=expected_admission_keys(binary_ast);new_keys=expected_admission_keys(new_ast)
need(len(old_keys)==len(new_keys)==1 and old_keys[0]==new_keys[0],'original expected admission fields changed')
call_names=[ast.unparse(n.func) for n in ast.walk(new_ast) if isinstance(n,ast.Call)]
need('E.inputs' in call_names and not any(n in {'E.sender','m.sender','sender','rt.binary.main','rt.binary.driver_module','rt.resolver.main','rt.resolver.receiver'} for n in call_names),'effectful/obsolete owner entry selected')
need('rt.binary.run' in call_names and 's.receive_public' in call_names and 'rt.sources.receive_public' in call_names,'original receive/core composition missing')

control_names=['CONTROL_FAILURE_TOOL_RETURN.json','CONTROL_GREEN_TOOL_RETURN.json','FINAL_CONTROL_TOOL_RETURN.json','SEAL_CONTROL_TOOL_RETURN.json','SOURCE_CHECK_TOOL_RETURN.json','SEAL_SOURCE_CHECK_TOOL_RETURN.json']
controls={}
for name in control_names:
    row=load(NEW/name);row=row['value'] if row.get('status')=='fulfilled' else row;controls[name]=row
need(controls['CONTROL_FAILURE_TOOL_RETURN.json']['exit_code']==1 and 'FAILED (errors=3)' in controls['CONTROL_FAILURE_TOOL_RETURN.json']['output'],'preserved fixture failure mismatch')
for name in ['CONTROL_GREEN_TOOL_RETURN.json','FINAL_CONTROL_TOOL_RETURN.json','SEAL_CONTROL_TOOL_RETURN.json']:
    need(controls[name]['exit_code']==0 and 'Ran 10 tests' in controls[name]['output'] and '\nOK\n' in controls[name]['output'],'preserved green result mismatch '+name)
history=load(NEW/'TEST_HISTORY.json')
need(history['runs'][0]['full_raw_tool_return_retained'] is False,'truncated baseline history incorrectly claimed complete')
predicate_map=load(NEW/'PREDICATE_MAP.json')
need(len(predicate_map['map'])==14 and predicate_map['operational_readiness']=='NOT_ESTABLISHED' and predicate_map['original_awards']==[],'predicate-map authority inflated')
result={'schema':'g132.independent-current-interface-source-verification.v1','status':'PASS' if not errors else 'GAP-REVISE','errors':errors,
    'new_manifest':desc(NEW/'MANIFEST.json'),'new_member_count':len(new_members),'new_member_bytes':sum(x['bytes'] for x in new_members),'new_members':new_members,
    'dependency_manifest':desc(DEP/'MANIFEST.json'),'dependency_member_count':len(dep_members),'dependency_member_bytes':sum(x['bytes'] for x in dep_members),'dependency_members':dep_members,
    'installation_index':desc(installation/'SOURCE_INDEX.json'),'installation_member_count':len(installation_members),'installation_members':installation_members,
    'composition_index':desc(DEP/'COMPOSITION_SOURCE_INDEX.json'),'runtime_member_count':len(runtime_members),'runtime_members':runtime_members,
    'preserved_original_functions':original_functions,'original_admission_fields':sorted(old_keys[0]),'new_admission_fields':sorted(new_keys[0]),
    'retained_controls':controls,'baseline_missing_full_return_preserved':True,'native_followup_reviewed':False,
    'reviewer_provider_or_network_calls':0,'reviewer_original_sender_calls':0,'reviewer_private_input_bodies_read':0,'reviewer_controller_operations':0,
    'test_suite_rerun':False,'authority':'NONE','original_awards':[]}
(OUT/'VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k in ['status','errors','new_member_count','new_member_bytes','dependency_member_count','dependency_member_bytes','installation_member_count','runtime_member_count','original_admission_fields','new_admission_fields','baseline_missing_full_return_preserved','native_followup_reviewed','test_suite_rerun','authority','original_awards']},indent=2))
raise SystemExit(0 if not errors else 1)
