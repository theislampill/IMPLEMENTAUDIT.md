#!/usr/bin/env python3
"""Finite new R4 controls. No ancestor suite, model, provider or live helper."""
import argparse
import json
from pathlib import Path
import unittest
import support
import test_focused

parser=argparse.ArgumentParser()
parser.add_argument("--phase",choices=["red","green"],required=True)
parser.add_argument("--output",type=Path,required=True)
args=parser.parse_args()
support.initialize(args.output,original=args.phase=="red")
suite=unittest.TestSuite()
for cls in [test_focused.RecorderControls,test_focused.CurrentnessPairingControl]:
    suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(cls))
if args.phase=="green":
    suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(test_focused.AdapterAffectedControls))
result=unittest.TextTestRunner(verbosity=2).run(suite)
summary=dict(schema="dg17.p03-r4-focused-controls.v1",phase=args.phase,tests_run=result.testsRun,
    failures=len(result.failures),errors=len(result.errors),successful=result.wasSuccessful(),
    owner_path=str(support.OWNER.__file__),owner_sha256=support.sha(Path(support.OWNER.__file__).read_bytes()),
    adapter_path=str(support.ADAPTER.__file__),adapter_sha256=support.sha(Path(support.ADAPTER.__file__).read_bytes()),
    test_only=True,actor_calls=0,provider_calls=0,live_currentness_calls=0,old_host_calls=0,original_acceptance=False)
support.write(support.OUT/"RESULT.json",summary)
print(json.dumps(summary,indent=2))
raise SystemExit(0 if result.wasSuccessful() else 1)
