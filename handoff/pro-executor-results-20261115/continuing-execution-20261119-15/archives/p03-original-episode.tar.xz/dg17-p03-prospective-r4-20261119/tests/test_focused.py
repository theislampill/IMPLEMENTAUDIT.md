from __future__ import annotations
import ast
import copy
import json
from pathlib import Path
import types
import unittest
import jsonschema
import support as s


class RecorderControls(unittest.TestCase):
    def setUp(self):
        s.reset_currentness()

    def test_dispatch_conflict_is_a_distinct_open_classed_row(self):
        f = s.Fixture("recorder-dispatch")
        session = f.recorder_session()
        s.OWNER.andon(session, "plan", {"record": f.record()})
        f.correct()
        before = f.state(); (f.evidence / "before-dispatch.STATE.md").write_bytes(before)
        error = None
        try:
            s.OWNER.andon(session, "dispatch", {"record": f.record("policy-conflict", f.success)})
        except Exception as exc:
            error = type(exc).__name__ + ": " + str(exc)
        (f.evidence / "after-dispatch.STATE.md").write_bytes(f.state())
        self.assertIsNone(error, "A separately witnessed dispatch conflict must be recordable: " + str(error))
        rows = s.rows(f.root / "records/STATE.md")
        self.assertEqual([r[3] for r in rows], ["failed-criterion", "policy-conflict"])
        self.assertEqual([len(r) for r in rows], [8, 8])
        self.assertEqual(rows[1][2], "before dispatch")
        self.assertEqual(rows[1][7], "open (rerun pending)")
        self.assertIn(Path(f.failed["path"]).name, rows[0][4])
        self.assertIn(b"| Status | BLOCKED |", f.state())
        self.assertIn(b"| Audit object state | open |", f.state())

    def test_successful_rerun_replaces_cell_and_retains_failure_and_fresh_anchor(self):
        f = s.Fixture("recorder-rerun")
        session = f.recorder_session()
        s.OWNER.andon(session, "plan", {"record": f.record()})
        failed_bytes = Path(f.failed["path"]).read_bytes()
        (f.evidence / "failed-row-preimage.STATE.md").write_bytes(f.state())
        f.correct()
        s.OWNER.resolve_andon(session, "plan", Path(f.success["path"]).name)
        row = s.rows(f.root / "records/STATE.md")[0]
        self.assertIn(Path(f.success["path"]).name, row[6])
        self.assertNotIn(Path(f.failed["path"]).name, row[6])
        self.assertIn(Path(f.failed["path"]).name, row[4])
        self.assertIn("Anchor: " + f.head, row[6])
        self.assertEqual(row[7], "resolved")
        self.assertEqual(Path(f.failed["path"]).read_bytes(), failed_bytes)
        anchors = sorted((f.captures / "commands").glob("*-andon-rerun-anchor.json"))
        self.assertEqual(len(anchors), 1)
        record = json.loads(anchors[0].read_bytes())
        self.assertEqual(record["argv"], ["/usr/bin/git", "rev-parse", "HEAD"])
        self.assertEqual((anchors[0].parent / record["output_file"]).read_text().strip(), f.head)
        self.assertIn(b"| Status | BLOCKED |", f.state())

    def test_failed_foreign_and_stale_anchor_reruns_refuse_without_state_effect(self):
        observations = []
        for kind in ["failed", "foreign", "stale-anchor"]:
            f = s.Fixture("recorder-refuse-" + kind)
            session = f.recorder_session()
            s.OWNER.andon(session, "plan", {"record": f.record()})
            witness = Path(f.failed["path"]).name
            if kind != "failed":
                f.correct()
                witness = Path(f.success["path"]).name
            if kind == "foreign":
                witness = "../" + witness
            if kind == "stale-anchor":
                session["task_commit"] = "0" * 40
            before = f.state(); (f.evidence / "before.STATE.md").write_bytes(before)
            refused = False
            try:
                s.OWNER.resolve_andon(session, "plan", witness)
            except s.OWNER.u.Refusal:
                refused = True
            after = f.state(); (f.evidence / "after.STATE.md").write_bytes(after)
            observations.append(dict(kind=kind, refused=refused, state_unchanged=before == after))
            with self.subTest(kind=kind):
                self.assertTrue(refused)
                self.assertEqual(before, after)
        s.write(s.OUT / "rerun-refusal-observations.json", observations)

    def test_pure_receiver_gate_distinguishes_containment_from_normal_dispatch(self):
        # Execute only exact pure record-validation statements from the owner.
        # Never call receive_decision, current, mailbox, refresh or snapshot.
        tree = ast.parse(Path(s.OWNER.__file__).read_text())
        function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "receive_decision")
        start = next(i for i,n in enumerate(function.body) if isinstance(n, ast.Assign)
                     and any(isinstance(t, ast.Tuple) and [x.id for x in t.elts] == ["record", "provenance"] for t in n.targets))
        end = next(i for i,n in enumerate(function.body[start:], start) if isinstance(n, ast.For))
        fragment = ast.Module(body=function.body[start:end], type_ignores=[])
        code = compile(ast.fix_missing_locations(fragment), str(s.OWNER.__file__) + ":pure-record-gate", "exec")
        results = []
        for action, classification, expected in [("retain-contained", "policy-conflict", True),
                                                  ("retain-contained", "none", False),
                                                  ("dispatch-reviewed-phase", "none", True)]:
            record = dict(classification=classification, witnesses=["001-observed.json"], containment="test containment",
                return_owner="L1", owner_source="test owner source", dependencies="test dependencies",
                acceptance="test acceptance", next_action="test next action", reason="test recorded reason")
            context = dict(args=types.SimpleNamespace(operation="dispatch"), value=dict(action=action, record=record, provenance={}),
                session=dict(binding=dict(witness_command_ids=["001-observed.json"])), completing=False,
                classification=s.OWNER.STAGES["dispatch"][3], owner="L1", u=s.OWNER.u)
            accepted = True
            try:
                exec(code, context)
            except s.OWNER.u.Refusal:
                accepted = False
            results.append(dict(action=action, classification=classification, expected=expected, accepted=accepted,
                pure_source_predicate_only=True, old_host_invoked=False))
            with self.subTest(action=action, classification=classification):
                self.assertEqual(accepted, expected)
        s.write(s.OUT / "receiver-pure-predicate-observations.json", results)


class CurrentnessPairingControl(unittest.TestCase):
    def test_new_exact_interface_pairs_with_new_controller_without_a_live_call(self):
        s.reset_currentness()
        attempt = s.OUT / "new-interface-pairing"; attempt.mkdir()
        inventory = json.loads((s.PACKET / "contracts/GOVERNOR_INVENTORY_DATA.json").read_bytes())
        result, error = None, None
        try:
            result = s.ADAPTER.require_currentness(attempt, inventory)
        except Exception as exc:
            error = type(exc).__name__ + ": " + str(exc)
        s.write(attempt / "CONTROL_RESULT.json", dict(test_only=True, result=result, error=error,
            double_calls=s.CURRENTNESS_CALLS, live_controller_calls=0))
        self.assertIsNone(error, "New contract must pair without accepting the old pinned interface: " + str(error))
        self.assertEqual(result, "refs/implementaudit/continuity-receipts/dg16-dg18-recovery-20261119-b/G00A1@" + "1" * 40)
        self.assertEqual(len(s.CURRENTNESS_CALLS), 1)


class AdapterAffectedControls(unittest.TestCase):
    def setUp(self):
        s.reset_currentness()

    def test_two_arm_sequence_preserves_independent_conflict_and_open_state(self):
        for arm in ["arm-a", "arm-b"]:
            with self.subTest(arm=arm):
                f = s.Fixture("sequence-" + arm, arm)
                original_task = (f.task / "TASK.md").read_bytes()
                original_subject = (f.task / "subject/service.json").read_bytes()
                failed_descriptor = Path(f.failed["path"]).read_bytes()
                initial = f.request("record-failure")
                # Ordinary Unicode must remain byte-for-byte usable in real rows.
                record = f.record()
                for field in ["reason", "containment", "owner_source", "dependencies", "acceptance", "next_action"]:
                    record[field] = "Résumé Δ 漢字 café — " + field
                f.replace_decision(initial, "unicode-initial", record=record)
                a = f.admit(initial, "initial")
                (f.evidence / "failure-after.STATE.md").write_bytes(f.state())
                f.correct()
                (f.evidence / "rerun-before.STATE.md").write_bytes(f.state())
                b = f.admit(f.request("record-rerun", s.binding(Path(a["receipt_path"]))), "rerun")
                (f.evidence / "rerun-after.STATE.md").write_bytes(f.state())
                c = f.admit(f.request("record-l1-return", s.binding(Path(b["receipt_path"]))), "l1")
                rows = s.rows(f.root / "records/STATE.md")
                self.assertEqual([len(x) for x in rows], [8, 8] if arm == "arm-a" else [8])
                self.assertEqual(rows[0][3], "failed-criterion")
                self.assertEqual(rows[0][7], "resolved")
                self.assertIn(Path(f.failed["path"]).name, rows[0][4])
                self.assertIn(Path(f.success["path"]).name, rows[0][6])
                self.assertIn("Anchor: " + f.head, rows[0][6])
                self.assertIn("Résumé Δ 漢字 café — reason", rows[0][4])
                if arm == "arm-a":
                    self.assertEqual(rows[1][3], "policy-conflict")
                    self.assertEqual(rows[1][7], "open (rerun pending)")
                    self.assertEqual(c["stage"], "policy-conflict-contained")
                else:
                    self.assertEqual(c["stage"], "control-return-recorded")
                for outcome in [a,b,c]:
                    self.assertIs(outcome["implementation_ready"], False)
                    self.assertIs(outcome["original_acceptance"], False)
                    self.assertIs(outcome["native_claim"], False)
                self.assertIn(b"| Status | BLOCKED |", f.state())
                self.assertIn(b"| Audit object state | open |", f.state())
                self.assertEqual((f.task / "TASK.md").read_bytes(), original_task)
                self.assertEqual((f.task / "subject/service.json").read_bytes(), original_subject)
                self.assertEqual(Path(f.failed["path"]).read_bytes(), failed_descriptor)
                events = (f.root / "records/evidence/governor-events.jsonl").read_text()
                self.assertNotIn("actual-Root-data-decision-received", events)
                self.assertNotIn("IMPLEMENTAUDIT_PHASE_START", events)
        self.assertEqual(len(s.CURRENTNESS_CALLS), 6)

    def test_scalar_guard_and_schema_cover_all_six_fields_and_consumer_boundaries(self):
        f = s.Fixture("scalar-matrix")
        base = f.request("record-failure")
        schema = json.loads((s.PACKET / "INTAKE_SCHEMAS.json").read_bytes())
        record_schema = dict(schema, **{"$ref":"#/$defs/Record"})
        validator = jsonschema.Draft202012Validator(record_schema)
        prompt = (s.PACKET / "contracts/scenario/actor-prompt.txt").read_bytes()
        proposed = (f.task / "incoming/proposal.json").read_bytes()
        results = []
        for field in ["reason", "containment", "owner_source", "dependencies", "acceptance", "next_action"]:
            for delimiter in ["\r", "\n", "\v", "\f", "\x1c", "\x1d", "\x1e", "\x85", "\u2028", "\u2029", "|"]:
                for position in ["embedded", "trailing"]:
                    value = "abc" + delimiter + "defg" if position == "embedded" else "abcdefg" + delimiter
                    request = copy.deepcopy(base); record = f.record(); record[field] = value
                    label = field + "-" + str(ord(delimiter)) + "-" + position
                    f.replace_decision(request, label, record=record)
                    f.save_request(request, label)
                    before = Path(request["root_receiving"]["path"]).read_bytes()
                    refused = False
                    try:
                        s.ADAPTER.actual_decision(request, prompt, proposed, None)
                    except s.ADAPTER.AdmissionRefused:
                        refused = True
                    schema_refused = bool(list(validator.iter_errors(record)))
                    results.append(dict(field=field, codepoint=ord(delimiter), position=position, guard_refused=refused, schema_refused=schema_refused,
                        raw_retained=Path(request["root_receiving"]["path"]).read_bytes()==before))
                    with self.subTest(field=field, codepoint=ord(delimiter), position=position):
                        self.assertTrue(refused)
                        self.assertTrue(schema_refused)
                        self.assertEqual(Path(request["root_receiving"]["path"]).read_bytes(), before)
        s.write(f.evidence / "FINITE_SCALAR_MATRIX.json", results)
        self.assertEqual(len(results), 132)
        self.assertEqual(s.CURRENTNESS_CALLS, [])

    def test_invalid_scalar_and_refused_actor_are_retained_before_any_effect(self):
        for kind in ["vertical-tab", "refused-actor"]:
            f = s.Fixture("raw-refusal-" + kind)
            request = f.request("record-failure")
            if kind == "vertical-tab":
                record = f.record(); record["reason"] = "abc\vdefg"
                f.replace_decision(request, kind, record=record)
            else:
                raw = Path(request["actor"]["raw_return"]["path"])
                raw.write_bytes(b"TEST ONLY invalid/nonverdict raw return\r\n\x0bDo not repair this response.\n")
                request["actor"]["raw_return"] = s.binding(raw)
                request["actor"]["return_observation"] = f.observation(kind + "-return", request["actor"]["raw_return"]["sha256"], request["actor"]["name"])
                f.replace_decision(request, kind, actor_return_sha256=request["actor"]["raw_return"]["sha256"], actor_disposition="REFUSED_NONVERDICT", record=None)
            with self.assertRaises(s.ADAPTER.AdmissionRefused):
                f.admit(request, kind)
            attempt = f.latest_attempt()
            self.assertEqual((attempt / "actor-return.raw").read_bytes(), Path(request["actor"]["raw_return"]["path"]).read_bytes())
            self.assertEqual((attempt / "root-receiving.raw").read_bytes(), Path(request["root_receiving"]["path"]).read_bytes())
            refusal = json.loads((attempt / "REFUSAL.json").read_bytes())
            self.assertIs(refusal["record_effects_started"], False)
            self.assertIs(refusal["actual_actor_result_rewritten"], False)
            self.assertIsNone(f.state())
        self.assertEqual(s.CURRENTNESS_CALLS, [])

    def test_missing_or_drifted_task_refuses_all_three_operations_before_currentness(self):
        f = s.Fixture("task-binding")
        original = (f.task / "TASK.md").read_bytes()
        previous = None
        for operation in ["record-failure", "record-rerun", "record-l1-return"]:
            if operation == "record-rerun":
                f.correct()
            request = f.request(operation, previous)
            before = f.state()
            for kind in ["missing", "drifted"]:
                path = f.task / "TASK.md"
                if kind == "missing":
                    path.unlink()
                else:
                    path.write_bytes(original + b"UNEXPECTED TASK DRIFT\n")
                count = len(s.CURRENTNESS_CALLS)
                with self.assertRaises(s.ADAPTER.AdmissionRefused):
                    f.admit(request, operation + "-" + kind)
                self.assertEqual(len(s.CURRENTNESS_CALLS), count)
                self.assertEqual(f.state(), before)
                self.assertIs(json.loads((f.latest_attempt()/"REFUSAL.json").read_bytes())["record_effects_started"], False)
                path.write_bytes(original)
            result = f.admit(request, operation + "-valid-control")
            previous = s.binding(Path(result["receipt_path"]))
        self.assertEqual(len(s.CURRENTNESS_CALLS), 3)

    def test_foreign_witness_and_source_drift_refuse_before_currentness(self):
        f = s.Fixture("source-and-witness-refusal")
        for kind in ["foreign-witness", "source-drift", "missing-review"]:
            request = f.request("record-failure")
            if kind == "foreign-witness":
                p = f.evidence / Path(f.failed["path"]).name
                p.write_bytes(Path(f.failed["path"]).read_bytes())
                request["witness"]["command"] = s.binding(p)
            elif kind == "source-drift":
                request["source"]["adapter_sha256"] = "0" * 64
            else:
                request["source"]["package"]["review"]["path"] = str(f.evidence / "actually-absent-review.json")
            with self.assertRaises(s.ADAPTER.AdmissionRefused):
                f.admit(request, kind)
            self.assertIsNone(f.state())
            self.assertIs(json.loads((f.latest_attempt()/"REFUSAL.json").read_bytes())["record_effects_started"], False)
        self.assertEqual(s.CURRENTNESS_CALLS, [])

    def test_real_terminal_capture_and_invalid_terminal_metadata_matrix(self):
        f = s.Fixture("terminal-fields")
        original = json.loads(Path(f.failed["path"]).read_bytes())
        s.ADAPTER.capture_record(Path(f.failed["path"]), original["argv"], str(f.task), 1, "actual fixture parser")
        cases = [("missing-"+k, k, "DELETE") for k in ["argv","cwd","started_at_unix","ended_at_unix","exit_code","expected_exit","timed_out","process_cleanup","owned_pgid","output_file","output_bytes","output_sha256","output_capture","stderr"]]
        cases += [("pgid-"+str(i),"owned_pgid",v) for i,v in enumerate([None,False,0,-1,1.5])]
        cases += [("capture-"+str(i),"output_capture",v) for i,v in enumerate([None,True,"combined"])]
        cases += [("exit-bool","exit_code",True),("expected-bool","expected_exit",True),("time-bool","started_at_unix",True),("reversed-time","ended_at_unix",original["started_at_unix"]-1)]
        results=[]
        for name,key,value in cases:
            folder=f.evidence/name;folder.mkdir()
            record=copy.deepcopy(original)
            record["output_file"]="001-negative.log";record["stderr"]["file"]="001-negative.stderr"
            for suffix,source in [(".log",original["output_file"]),(".stderr",original["stderr"]["file"])]:
                (folder/("001-negative"+suffix)).write_bytes((Path(f.failed["path"]).parent/source).read_bytes())
            if value=="DELETE":del record[key]
            else:record[key]=value
            path=folder/"001-negative.json";s.write(path,record)
            refused=False
            try:s.ADAPTER.capture_record(path,original["argv"],str(f.task),1,"negative fixture")
            except s.ADAPTER.AdmissionRefused:refused=True
            results.append(dict(case=name,refused=refused))
            with self.subTest(case=name):self.assertTrue(refused)
        s.write(f.evidence/"TERMINAL_MATRIX.json",results)
        self.assertEqual(len(results),26)
        self.assertEqual(s.CURRENTNESS_CALLS,[])

    def test_currentness_wrong_controller_ambiguous_and_incomplete_results_preserve_refusal(self):
        for mode in ["old-controller", "ambiguous", "incomplete", "stderr"]:
            s.reset_currentness(mode)
            f=s.Fixture("currentness-refusal-"+mode)
            with self.assertRaises(s.ADAPTER.AdmissionRefused):
                f.admit(f.request("record-failure"),mode)
            attempt=f.latest_attempt()
            self.assertTrue((attempt/"currentness/INVOCATION.json").is_file())
            self.assertTrue((attempt/"currentness/commands/001-root-currentness.log").is_file())
            self.assertTrue((attempt/"currentness/commands/001-root-currentness.stderr").is_file())
            refusal=json.loads((attempt/"REFUSAL.json").read_bytes())
            self.assertIs(refusal["record_effects_started"],False)
            self.assertIsNone(f.state())
            self.assertEqual(len(s.CURRENTNESS_CALLS),1)

    def test_new_schemas_validate_real_controlled_inputs_without_claiming_actual_receiving(self):
        f=s.Fixture("schema-inputs")
        request=f.request("record-failure")
        schema=json.loads((s.PACKET/"INTAKE_SCHEMAS.json").read_bytes())
        jsonschema.Draft202012Validator.check_schema(schema)
        values={"Request":request,
            "RootDecision":json.loads(Path(request["root_receiving"]["path"]).read_bytes()),
            "HostObservation":json.loads(Path(request["actor"]["return_observation"]["path"]).read_bytes()),
            "PackageReview":json.loads(Path(request["source"]["package"]["review"]["path"]).read_bytes()),
            "PackageReceiving":json.loads(Path(request["source"]["package"]["root_receiving"]["path"]).read_bytes()),
            "WitnessInputBinding":json.loads(Path(request["witness"]["input_binding"]["path"]).read_bytes()),
            "CommandCapture":json.loads(Path(f.failed["path"]).read_bytes())}
        for name,value in values.items():
            with self.subTest(schema=name):jsonschema.Draft202012Validator(dict(schema,**{"$ref":"#/$defs/"+name})).validate(value)
        self.assertEqual(s.CURRENTNESS_CALLS,[])
