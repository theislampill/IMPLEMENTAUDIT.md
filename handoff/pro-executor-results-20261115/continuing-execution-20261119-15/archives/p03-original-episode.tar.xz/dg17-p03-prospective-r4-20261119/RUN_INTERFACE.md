# R4 ordinary Root invocation interface

**Preparation only.** This packet supplies new prospective source and metadata for genuine independent review. It contains no actual actor, Root intake or currentness result. Run no template as a request. Root remains the sole actual integration/recording caller.

## Exact source and historical boundary

The runtime recorder is a new narrow repair of the received original 110fe owner, not a reconstruction of the lost historical corrected recorder. Its only changed functions are receive_decision, andon and resolve_andon. The primitive is unchanged. The adapter is exact recovered r3 with only OWNER_SHA, FREEZE_SHA, INTERFACE_SHA and CONTROLLER rebound. All scalar, TASK, source, provenance, terminal and per-effect currentness guards remain intact.

The installed governor census is descriptive data for the actual supplied 54-file package. ORIGINAL_A297_PROTOCOL.md is distinct immutable target-policy data. This ordinary route requests no internal child resolver, native activation, install qualification or sibling-package route. No currentness helper is invoked by the author. Actual package/source applicability and receiving remain the existing independent/Root judgments, not author-issued facts.

The old TASK, freeze and schema bodies were lost. R4's TASK, SCENARIO_FREEZE.json and INTAKE_SCHEMAS.json are explicitly new prospective inputs. Both TASK copies are identical. The six JSON files, neutral common prompt, post-check template and evaluator oracle retain their exact recovered bytes. The oracle remains evaluator-only. No prior failed actor or original historical episode is retried by this new design.

## Typed inputs and their owners

INTAKE_SCHEMAS.json documents the actual adapter shapes; the executable guard additionally enforces exact physical files, source identities, finite/exact numeric types and stage semantics. ROOT_REQUEST.template.json is deliberately incomplete. ROOT_PREFLIGHT.template.json records preparation gaps and is not an extra runtime gate or a source-review verdict.

| Input | Actual data Root must retain | Judgment that remains outside Python |
|---|---|---|
| Exact final source/packet | Final manifest, immutable source bytes, independent review's complete return and Root's receiving record | Same reviewer judges this new source and pre-actor packet; Root receives that actual disposition before actors |
| `source.package.inventory` | Complete actual selected package census, physical paths, modes, bytes and hashes; this packet's census is available for rechecking | Applicable ordinary governor-only scope and source precedence; no unused native/child/install requirement is added |
| `source.package.review` and `review_observation` | Actual reviewer-produced six-field PackageReview object and actual host observation binding its bytes | Independent disposition; the author must not populate this judgment |
| `source.package.root_receiving` and `root_observation` | Actual Root-produced PackageReceiving object and distinct Root observation | Root independently consumes the actual review and inventory |
| `task` | Fresh actual task directory and full 40-hex Git HEAD, with complete creation/read captures | Root owns the new task and its bounded syntax-preparation authority |
| `actor` | Actual actor task identity, exact assignment prompt component, raw return, real dispatch/return envelopes and observed-command digest | Attribution, genuine evidence receipt and actual cognition; different reference strings alone are insufficient |
| `root_receiving` and `root_observation` | Actual separate Root decision bound to the exact actor return and current witness | Root re-derives the actual next action and record; never repairs an invalid actor answer into an expected one |
| `witness` | Actual primitive-produced JSON command record, both complete streams and exact before/after input binding | The observed command has the claimed real origin and satisfies only its actual parser scope |
| `previous_admission` | Actual previous RESULT.json binding from this namespace; null for the first operation | No historical receipt or another namespace is substituted |
| Boundary captures | Every mapped full artifact before/after each call, including honest absence and failed-row preimage | Root/later independent receiving checks actual state, blocker content and task-level meaning |

The minimal package-review fields are schema, reviewer, inventory_sha256, disposition, internal_child_route and scope. PackageReceiving fields are schema, review_sha256, inventory_sha256, disposition, internal_child_route and scope. Their accepted constants are documented in the existing adapter/schema. They are **unissued** here. The descriptive census or one helper hash does not itself supply either decision. A full source-packet review is received at Root's existing pre-actor boundary; it is not fabricated from a PackageReview string.

## Actual message-only delivery

The exposed collaboration interface has a message string and task name, with no separate attachment/workdir parameter. Use the frozen ACTOR_TRANSPORT_MESSAGE.template.txt and a fresh actor with fork_turns="none". Expand its assignment-prompt component from exact bytes and its four path/digest placeholders from the actual assigned manifest. Use neutral task names without condition labels. Send no evaluator, sibling, test outcome or Root snapshot in the message, referenced files or inherited context.

For the initial stage, `actor.prompt` binds the recovered 736-byte common prompt. For the post-check stage, it binds the exact 303-byte template followed by:

```text
LF + Observation SHA-256: <actual successful command-record SHA-256> + LF
```

The full submitted message is larger. Capture it separately, with its actual UTF-8 bytes/digest and the exact byte interval occupied by the assignment-prompt component. Do not claim that the 736-byte file equals the submitted message. The actual message's file-reference manifest is the complete delivered path population; calling it an attachment manifest does not assert an attachment API existed.

`dispatch_observation.subject_sha256` continues to bind the prompt component. Its `raw_result` may bind a lossless, explicitly Root-authored host capture envelope under plan/HOST_CAPTURE_ENVELOPE.schema.json. That envelope separately retains actual invocation arguments, full message, prompt component interval, all referenced files and exact actual tool result. The unchanged opaque HostObservation reader can represent this; no sixth observation field or provider-ID source change is needed. Root must check the relationship against actual bytes and later actual actor observations.

An actual canonical task reference, actor-owned exec chunk or explicitly labeled derived task/operation/content reference is admissible as an opaque reference. Root reads remain Root observations. Empty send/followup results remain empty and imply no delivery acknowledgment. Retain raw empty result bytes plus the faithful capture envelope; wait for actual actor evidence. No backend/native identity is inferred.

## Fresh namespace and command capture

The exact planned namespaces are:

```text
/workspace/scratch/2678f1e431c3/dg17-p03-r4-actual-20261119/arm-a
/workspace/scratch/2678f1e431c3/dg17-p03-r4-actual-20261119/arm-b
```

They have not been created by the author. Each must have its own `task/`, `captures/commands/`, actual supplied evidence and admissions. Initial `records/` must be absent. Root copies only the assigned TASK, initial proposal and subject into the actual task, captures its local Git creation and full HEAD, and preserves the complete input manifest. Never copy controlled fixtures or synthetic package/actor/Root evidence into a live namespace.

Use the unchanged `source/transport_primitives.py` `run(out, label, argv, cwd, expected=..., timeout=...)` producer for real command receipts. Its `out` is the actual arm's `captures` directory. The exact witness argv is:

```text
["/usr/bin/python3", "-B", "-m", "json.tool", "<actual arm workspace>/task/incoming/proposal.json"]
cwd = <actual arm workspace>/task
```

The producer retains start/end, exit and expected exit, process-group terminal evidence, stdout/stderr names, full bytes and hashes. Preserve its complete raw tool invocation/result too. A metadata file invented after an unobserved command is not equivalent. Retain a full command census, including real task setup/read and the recorder's fresh anchor command.

Before and after the parser command, retain the actual proposal bytes and digest. Create the seven-field WitnessInputBinding from the observed command descriptor, actual task root/full HEAD, equal before/after proposal digests and the exact recorder digest. The descriptor path must be this namespace's `captures/commands/<ordinal>-<label>.json`. Initial parser exit is 1; the syntax-only rerun exit is 0. Unexpected output or terminal state remains a refusal, not an expected-answer repair.

The task HEAD remains stable through this bounded namespace. The authorized syntax correction changes only the working-tree proposal to the exact supplied corrected bytes; it changes no values and does not move HEAD. The successful candidate bytes are independently bound by its command/input receipt. `resolve_andon` obtains a fresh actual Git HEAD capture and requires the full Anchor to match the admitted task HEAD before replacing the rerun cell.

## Three actual operations

1. **record-failure.** Supply the initial real parser refusal, actual initial actor return, separate Root receiving and complete boundary captures. `previous_admission` is null. The dedicated classed failed-criterion row is created only after all guards and actual currentness pass. Original failed witness bytes remain retained.
2. **record-rerun.** Only after actual bounded authorization, apply the exact syntax-only correction and capture its successful parser result. Reuse the exact initial actor return/return observation and its original failed observed-command digest; do not create another actor result. Supply a new actual Root decision bound to the successful witness and the actual prior RESULT. The source/input/task contract is rechecked. Resolution preserves the original failed witness in the abnormality cell and names the actual successful command plus fresh full task Anchor in the rerun cell.
3. **record-l1-return.** Continue the same actual actor with the exact post-check prompt component and current actual evidence. Supply the distinct actual post-check return, separate Root rederivation and actual rerun RESULT. The policy conflict, if actually received, is a separate open policy-conflict row with BLOCKED status and open audit object. A conformant control does not invent a conflict. Neither path performs implementation or grants readiness/closure.

The Root projection has the exact nine Record fields. Six text scalars must be 8–4096 characters and contain none of CR, LF, VT, FF, FS, GS, RS, NEL, U+2028, U+2029 or pipe. Refuse rather than normalize. Raw actual actor/Root bytes are retained before admission checks. A REFUSED_NONVERDICT or REFUSED_INVALID disposition can carry null record; it is retained and refused before currentness/effects. Do not replace actual refusal text with expected record text.

The actual broader Andon meaning remains a receiving obligation: interrupted owner/decision, last safe step, next unfinished gate, affected evidence, blocked_scope, unblocked_work and any required justification. Successful parser shape and a permitted class do not establish that meaning.

## Exact production currentness and next invocation

The adapter automatically invokes the following immediately before record effects, retaining its complete command result before interpreting it:

```text
argv = ["bash", "/home/agent/.codex/skills/remote-skills/skill-6a85962852788191bb717a1a61592b58/scripts/claim-run.sh", "--require-current-continuity", "dg16-dg18-recovery-20261119-b"]
cwd = /workspace/scratch/2678f1e431c3/recovery-repo-20261119-b
```

The helper is 14,707 bytes, SHA-256 `9c9945fdf650c72b8019f0dd908fff360162cc11ae7eb3197ccafe0f6ab3730f`. The new exact interface digest is pinned in source. The output must be the actual then-current full receipt for that controller. No G0002 or other epoch/commit is prefilled. There is no production skip/double flag.

After genuine source review and Root receiving, fresh actual task/actor/command data and the before capture exist, the first recording invocation has this form:

```text
/usr/bin/python3 -B /workspace/scratch/2678f1e431c3/dg17-p03-prospective-r4-20261119/root_callsite.py \
  --request /workspace/scratch/2678f1e431c3/dg17-p03-r4-actual-20261119/arm-a/root-receiving/record-failure.request.json \
  --sha256 <SHA256_OF_THAT_ACTUAL_COMPLETE_REQUEST> \
  --workspace /workspace/scratch/2678f1e431c3/dg17-p03-r4-actual-20261119/arm-a
```

Retain the actual terminal output and perform the mapped after capture immediately, including on refusal. Do not run this command with placeholders or test data. The actor and Root decisions are supplied by actual model-side tools outside Python; the adapter cannot manufacture or authenticate them.

## Acceptance ceiling

Controlled R4 evidence demonstrates only the new source/metadata paths described in REPORT.md. Same-reviewer independent source/packet review is pending. Actual episode, per-effect currentness, actor cognition, broader blocker content and independent episode receiving remain unobserved. Original F1, whole P03/DG17, M01/N06, native Stop/M4, release and closure remain separate and unawarded.
