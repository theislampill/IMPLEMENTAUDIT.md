# Controlled recording fixture

## Current phase

| Field | Value |
|---|---|
| Status | BLOCKED |
| Audit object state | open |

| Last check | TEST ONLY: observed planning abnormality; no actor claim |

| Next action | TEST ONLY: return to L1 for bounded evidence review |

## Audit object state

TEST ONLY: service subject remains unimplemented.

## Andon log

| # | Occ | Phase | Class | Abnormality | Countermeasure | Rerun evidence | Outcome |
|---|---|---|---|---|---|---|---|

| 1 | plan | before dispatch | failed-criterion | TEST ONLY: observed planning abnormality; no actor claim | TEST ONLY: preserve implementation subject; blocked_scope: implementation; unblocked_work: evidence review; owner/source=TEST ONLY: service configuration owner | actual command witnesses: 005-parser-failed.json | open (rerun pending) |

## Context epochs

TEST ONLY: this fixture creates no controller.
