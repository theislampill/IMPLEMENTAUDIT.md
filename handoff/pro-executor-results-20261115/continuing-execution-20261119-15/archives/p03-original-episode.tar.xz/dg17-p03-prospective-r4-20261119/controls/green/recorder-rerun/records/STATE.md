# Controlled recording fixture

## Current phase

| Field | Value |
|---|---|
| Status | BLOCKED |
| Audit object state | open |

| Last check | TEST ONLY: observed planning abnormality; no actor claim |

| Next action | TEST ONLY: return to L1 for bounded evidence review |

## Audit object state

TEST ONLY: service subject remains unimplemented.

## Andon log

| # | Occ | Phase | Class | Abnormality | Countermeasure | Rerun evidence | Outcome |
|---|---|---|---|---|---|---|---|

| 1 | plan | before dispatch | failed-criterion | TEST ONLY: observed planning abnormality; no actor claim; original command witnesses: 005-parser-failed.json | TEST ONLY: preserve implementation subject; blocked_scope: implementation; unblocked_work: evidence review; owner/source=TEST ONLY: service configuration owner | actual successful command: 006-parser-passed.json; Anchor: d6eed864a43687fe13e83788be8db8ef682c8573 | resolved |

## Context epochs

TEST ONLY: this fixture creates no controller.
