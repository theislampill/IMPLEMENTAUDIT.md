#!/usr/bin/env python3
"""Read-only R4 byte/capture verification; no source tests or helper calls."""
from __future__ import annotations
import ast
import datetime
import hashlib
import json
import math
from pathlib import Path
import stat
import sys
import jsonschema

BASE = Path(__file__).resolve().parent
EXCLUDED = {"MANIFEST.json", "TERMINAL_RECEIPT.json", "TERMINAL_TOOL_RECEIPT.json"}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def check(condition, reason):
    if not condition:
        raise AssertionError(reason)


def read_json(path):
    return json.loads(path.read_bytes())


def file_row(path, relative):
    check(path.is_file() and not path.is_symlink(), "nonphysical file: " + str(path))
    raw = path.read_bytes()
    return dict(path=relative, type="file", bytes=len(raw), sha256=digest(raw), mode=oct(stat.S_IMODE(path.stat().st_mode)))


def census(root):
    rows=[]
    for path in sorted(root.rglob("*")):
        check(not path.is_symlink(), "unexpected alias: " + str(path))
        relative=path.relative_to(root).as_posix()
        if path.is_dir():
            rows.append(dict(path=relative,type="directory",mode=oct(stat.S_IMODE(path.stat().st_mode))))
        else:
            rows.append(file_row(path,relative))
    return rows


def main():
    manifest=read_json(BASE/"MANIFEST.json")
    check(manifest["schema"]=="dg17.p03-r4-final-packet-manifest.v1", "manifest schema")
    direct=[file_row(p,p.relative_to(BASE).as_posix()) for p in sorted(BASE.rglob("*"))
            if p.is_file() and not p.relative_to(BASE).parts[0]=="controls"
            and p.relative_to(BASE).as_posix() not in EXCLUDED]
    check(direct==manifest["files"],"direct byte population differs")
    tree_stats={}
    for tree in manifest["trees"]:
        payload=read_json(BASE/tree["census_path"])
        rows=census(BASE/tree["path"])
        check(rows==payload["entries"],"controlled tree differs: "+tree["path"])
        check(digest((BASE/tree["census_path"]).read_bytes())==tree["census_sha256"],"tree census digest")
        files=[r for r in rows if r["type"]=="file"]
        check(len(files)==tree["files"] and sum(x["bytes"] for x in files)==tree["bytes"],"tree totals")
        tree_stats[tree["path"]]=dict(entries=len(rows),files=len(files),bytes=sum(x["bytes"] for x in files))

    lineage=read_json(BASE/"INPUT_LINEAGE.json")
    for row in lineage["copies"]:
        original=Path(row["source"]).read_bytes()
        check((len(original),digest(original))==(row["bytes"],row["sha256"]),"received source drift")
        if row["copy"] not in lineage["working_copies_expected_to_change"]:
            check((BASE/row["copy"]).read_bytes()==original,"immutable received copy drift")
    old=ast.parse((BASE/"inputs/original/hosted_phase.py").read_text())
    new=ast.parse((BASE/"source/hosted_phase.py").read_text())
    old_f={n.name:ast.dump(n,include_attributes=False) for n in old.body if isinstance(n,ast.FunctionDef)}
    new_f={n.name:ast.dump(n,include_attributes=False) for n in new.body if isinstance(n,ast.FunctionDef)}
    check(set(old_f)==set(new_f),"owner function population changed")
    check([n for n in old_f if old_f[n]!=new_f[n]]==["receive_decision","andon","resolve_andon"],"unrelated owner function changed")
    check(ast.dump(ast.Module(body=[n for n in old.body if not isinstance(n,ast.FunctionDef)],type_ignores=[]))==ast.dump(ast.Module(body=[n for n in new.body if not isinstance(n,ast.FunctionDef)],type_ignores=[])),"owner top-level behavior changed")
    old_a=ast.parse((BASE/"inputs/root_callsite.r3.py").read_text())
    new_a=ast.parse((BASE/"root_callsite.py").read_text())
    check(len(old_a.body)==len(new_a.body),"adapter node population changed")
    changed=[];constants={}
    for left,right in zip(old_a.body,new_a.body):
        if isinstance(right,ast.Assign) and len(right.targets)==1 and isinstance(right.targets[0],ast.Name) and isinstance(right.value,ast.Constant):
            constants[right.targets[0].id]=right.value.value
        if ast.dump(left,include_attributes=False)!=ast.dump(right,include_attributes=False):
            check(isinstance(left,ast.Assign) and isinstance(right,ast.Assign),"adapter behavior changed")
            changed.append(right.targets[0].id)
    check(changed==["OWNER_SHA","FREEZE_SHA","INTERFACE_SHA","CONTROLLER"],"unexpected adapter delta")
    for key,path in [("OWNER_SHA","source/hosted_phase.py"),("PRIMITIVE_SHA","source/transport_primitives.py"),("POLICY_SHA","contracts/ORIGINAL_A297_PROTOCOL.md"),("FREEZE_SHA","contracts/SCENARIO_FREEZE.json"),("INTERFACE_SHA","contracts/ROOT_CURRENTNESS_INTERFACE.json"),("POST_PROMPT_SHA","contracts/post-check-prompt-template.txt")]:
        check(constants[key]==digest((BASE/path).read_bytes()),"runtime pin differs: "+key)
    check(constants["CONTROLLER"]=="dg16-dg18-recovery-20261119-b","wrong controller binding")
    check(constants["PRIMITIVE_SHA"]=="348bebac70e43bb8fba37e3731ab73b7bf8f99f5fbd9baf4a59cfba8a2e545c3","primitive changed")

    for row in read_json(BASE/"PRE_ACTOR_FREEZE.json")["entries"]:
        raw=(BASE/row["path"]).read_bytes()
        check((len(raw),digest(raw))==(row["bytes"],row["sha256"]),"pre-actor member drift")
    freeze=read_json(BASE/"contracts/SCENARIO_FREEZE.json")
    for row in freeze["entries"]:
        raw=(BASE/row["local_path"]).read_bytes()
        check((len(raw),digest(raw))==(row["bytes"],row["sha256"]),"scenario member drift")
    for name in ["INTAKE_SCHEMAS.json","plan/HOST_CAPTURE_ENVELOPE.schema.json"]:
        jsonschema.Draft202012Validator.check_schema(read_json(BASE/name))
    interface=read_json(BASE/"contracts/ROOT_CURRENTNESS_INTERFACE.json")
    check(interface["argv"]==["bash",interface["helper"]["path"],"--require-current-continuity",constants["CONTROLLER"]],"interface pairing differs")
    check(interface["cwd"]=="/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b","interface cwd differs")
    inventory=read_json(BASE/"contracts/GOVERNOR_INVENTORY_DATA.json")
    package=Path(inventory["selected_package"])
    paths=set()
    for row in inventory["files"]:
        p=Path(row["path"]);raw=p.read_bytes();paths.add(row["relative_path"])
        check(p==package/row["relative_path"] and not p.is_symlink(),"governor path differs")
        check((len(raw),digest(raw),oct(stat.S_IMODE(p.stat().st_mode)))==(row["bytes"],row["sha256"],row["mode"]),"governor census changed")
    check(paths=={p.relative_to(package).as_posix() for p in package.rglob("*") if p.is_file()} and len(paths)==inventory["file_count"]==54,"governor population changed")
    request=read_json(BASE/"ROOT_REQUEST.template.json")
    check(request["actor"]["name"] is None and request["root_receiving"] is None,"live request prefilled")
    check(all(request["source"]["package"][k] is None for k in ["review","review_observation","root_receiving","root_observation"]),"package judgment prefilled")

    real=0;doubles=0
    fields={"argv","cwd","started_at_unix","ended_at_unix","exit_code","expected_exit","timed_out","process_cleanup","owned_pgid","output_file","output_bytes","output_sha256","output_capture","stderr"}
    for path in sorted(BASE.rglob("commands/*.json")):
        value=read_json(path)
        if value.get("TEST_ONLY"):
            doubles+=1
            check(value.get("no_controller_invoked") is True and value.get("no_process_started") is True and value.get("no_real_receipt") is True,"unlabeled currentness double")
        else:
            real+=1
            check(fields<=set(value),"real producer terminal fields absent")
            check(type(value["exit_code"]) is int and type(value["expected_exit"]) is int and value["exit_code"]==value["expected_exit"],"unexpected real command exit")
            check(value["timed_out"] is False and value["process_cleanup"]=="owned-process-group-absent" and type(value["owned_pgid"]) is int and value["owned_pgid"]>0,"unverified real process terminal state")
            check(all(type(value[k]) in {int,float} and math.isfinite(value[k]) for k in ["started_at_unix","ended_at_unix"]) and value["started_at_unix"]<=value["ended_at_unix"],"real terminal times")
            check(value["output_capture"]=="separate-stdout-stderr","real stream capture mode")
            check(Path(value["cwd"]).is_relative_to(BASE),"real command outside owned directory")
            check(value["argv"][0] in {"/usr/bin/git","/usr/bin/python3",sys.executable},"unexpected real command executable")
            if value["argv"][0]=="/usr/bin/git":
                check(not {"push","pull","fetch","clone","remote"}.intersection(value["argv"]),"external Git operation")
        for suffix,stream in [(".log",dict(file=value["output_file"],bytes=value["output_bytes"],sha256=value["output_sha256"])),(".stderr",value["stderr"])]:
            p=path.with_suffix(suffix);raw=p.read_bytes()
            check(stream["file"]==p.name and type(stream["bytes"]) is int and stream["bytes"]==len(raw) and stream["sha256"]==digest(raw),"producer stream identity differs")
    for directory in {p.parent for p in BASE.rglob("commands/*.json")}:
        check({p.stem for p in directory.glob("*.json")}=={p.stem for p in directory.glob("*.log")}=={p.stem for p in directory.glob("*.stderr")},"omitted command stream or metadata")
    check(real==159 and doubles==14,"producer census differs")
    red=read_json(BASE/"controls/red/RESULT.json");green=read_json(BASE/"controls/green/RESULT.json")
    check((red["tests_run"],red["failures"],red["errors"],red["successful"])==(5,8,0,False),"RED result differs")
    check((green["tests_run"],green["failures"],green["errors"],green["successful"])==(13,0,0,True),"GREEN result differs")
    check(green["owner_sha256"]==constants["OWNER_SHA"] and green["adapter_sha256"]==digest((BASE/"root_callsite.py").read_bytes()),"GREEN source differs")
    refusals=list((BASE/"controls/green").rglob("admissions/*/REFUSAL.json"))
    check(len(refusals)==15 and all(read_json(p)["record_effects_started"] is False and read_json(p)["actual_actor_result_rewritten"] is False for p in refusals),"controlled refusal population differs")
    results=list((BASE/"controls/green").rglob("admissions/*/RESULT.json"))
    check(len(results)==9 and all(all(read_json(p)[k] is False for k in ["implementation_ready","original_acceptance","native_claim"]) for p in results),"controlled result ceiling differs")
    output=dict(schema="dg17.p03-r4-actual-terminal-verification.v1",verified_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        status="SOURCE_ONLY_PACKET_BYTES_VERIFIED_NOT_OPERATIONAL_ADMISSION",manifest_sha256=digest((BASE/"MANIFEST.json").read_bytes()),
        direct_files=len(direct),direct_bytes=sum(x["bytes"] for x in direct),controlled_trees=tree_stats,
        real_local_command_records=real,explicit_currentness_doubles=doubles,red=dict(tests=5,failed_assertions=8,errors=0),green=dict(tests=13,failures=0,errors=0),
        controlled_recording_results=9,retained_admission_refusals=15,changed_owner_functions=["receive_decision","andon","resolve_andon"],changed_adapter_constants=changed,
        live_actor_calls=0,live_controller_calls=0,provider_calls=0,native_calls=0,source_tests_replayed_by_verifier=False,
        original_acceptance=False,operational_admission=False,independent_review="PENDING_SAME_REVIEWER")
    print(json.dumps(output,indent=2))


if __name__=="__main__":
    main()
