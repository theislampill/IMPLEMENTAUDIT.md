# P03 R4 prospective source and invocation packet

**PARTIAL — bounded source engineering is complete; independent source/packet review and the real episode remain pending.** The new focused GREEN run passed 13 tests with no failures or errors. This is source-only evidence. No actor, actual Root receiving, live currentness/helper, provider, native host, original workflow or original acceptance occurred in this cell.

All writes stayed under `/workspace/scratch/2678f1e431c3/dg17-p03-prospective-r4-20261119`. Root remains the sole integration writer. The recovered packets and review were read as immutable inputs and were not changed. Cleanup is limited to this directory after Root receiving; every first failure, raw refusal and full terminal stream remains retained.

## What is new, and what is exact recovered data

The source owner was received at 46,053 bytes, SHA-256 `9f4d7301d6c93c86a7f27225ef92d0b5c6aa5c6a6a14809b1371927bdabf8e5d`, from original commit `110fe9b16e2142f7076d81f812fb6874ccaa1d57`, path `handoff/dg17-phase-return/hosted_phase.py`, Git blob `867ef66afce98fd58fea1b942c0c195809040ab5`. The lost historical corrected `feb54...` file was not reconstructed. R4 is an honest new repair with its own identity and diff.

The exact recovered r3 adapter is `2c7d974a158b1328cde82e07a646ca352a7f83bdf94466de1cbaabe5e03a2f8b`. The full recovered independent R2 report is `e644c696c1cbb35b9fd068b5dc55d3f2d572e90a872efb1aae1e36e23a108338`, and its HostObservation judgment is `094b61e902881d97d4d8dfd8d91e40e73f3185b0a395edf0bd04fea853314e61`. Their actual census and complete reports were read. Their historical R1/R3/R4 support and R2.1 NEEDS_REVISION finding remain at the original review scope; this author supplies no new independent admission.

The 44,881-byte primitive, original a297 policy, common prompt, post-check template, six scenario JSON files and evaluator oracle are exact hash-verified copies. The installed 54-file governor census is freshly read descriptive data, not a positive package/precedence/native disposition. The original policy remains distinct target-policy data and is unchanged.

The old TASK, scenario freeze and full schema bodies remain unavailable. New identical 1,588-byte TASK files explicitly restate the already-frozen logging/retention requirements, SHA-256 `85edbc8e2ef5c79f3d8c5a6b6003527edbbaddff4a75ecd3281c41a95c92402d`. Their new scenario freeze and new schemas have new identities. No missing old hash or result is attributed to these replacements.

## Narrow production changes

Only three functions changed in the original recorder. The complete module's other functions and non-function AST are unchanged.

1. `receive_decision` distinguishes a dispatch policy-conflict containment from normal none-class dispatch, and registers an actual abnormality row when a classed containment is received. The legacy host/mailbox flow remains dormant; it was neither launched nor emulated in this cell.
2. `andon` can record a separate dispatch policy-conflict occurrence, keeps exactly one applicable official class per row, and retains original command witnesses in the abnormality cell outside the replaceable rerun cell. Planning/dispatch rows use “before dispatch”, not an invented phase.
3. `resolve_andon` requires one physical captured successful command from the same task, complete relevant terminal fields and both streams, and a fresh actual full Git HEAD matching the admitted task commit. It replaces the rerun cell with that actual successful command and Anchor while preserving the original failure. It does not provide a resolution route for the independent dispatch policy conflict. It does not promote overall status or implementation readiness.

The new recorder is 49,617 bytes, SHA-256 `33a4eccc631cfc1e031e886f2b6f77b1502799a9242d72311be27d819474a7e0`. The unchanged primitive is `348bebac70e43bb8fba37e3731ab73b7bf8f99f5fbd9baf4a59cfba8a2e545c3`.

The adapter changes exactly four constants: OWNER_SHA, FREEZE_SHA, INTERFACE_SHA and CONTROLLER. Its new SHA-256 is `8cd14886d451007ec1d580362b098aaca1a63b610cc931013169f90fec4a8c20`. The original r3 six-field scalar exclusion, TASK binding, provenance, terminal checks, source/input rechecks, operation ordering and production currentness behavior are unchanged. No replacement recorder, host mode, skip flag, callback or new actor/protocol producer was introduced.

The exact diffs are `diffs/original-to-r4-recorder.patch` and `diffs/r3-to-r4-callsite.patch`. SOURCE_DESCRIPTOR.json records original and new identities. INPUT_LINEAGE.json explicitly describes the initial received copies before the working source copies were repaired.

## Focused actual RED and GREEN

The tests were written before the production repair and were unchanged between the two runs. The RED subset exercises the newly repaired owner/currentness behaviors. The GREEN run includes that subset plus the necessary affected ordinary-callsite controls. This is a new bounded suite, not a replay of the old 30/33 checks or original workflow.

| Observation | Actual result |
|---|---|
| RED terminal tool return | `1775a3/0`, following actual launch `98a1ab` / session 59924 |
| RED test process | Exit 1 as expected; 5 tests, 8 failed assertions, 0 errors |
| GREEN terminal tool return | `f75563/0`, following actual launch `744d39` / session 15900 |
| GREEN test process | Exit 0; 13 tests, 0 failures/errors |
| RED stdout / stderr | 694 B / 7,592 B, complete |
| GREEN stdout / stderr | 677 B / 2,519 B, complete |

The RED failures were concrete: dispatch recording had no mapping; a failed/foreign/stale-anchor witness could resolve the row; the pure receiver gate rejected policy-conflict containment and accepted none-class containment; the rerun cell still cited the failed command; and exact r3 refused the new currentness interface pin. All original failures and states remain in `controls/red` and `receipts/red-run`.

GREEN exercises the real recorder/state/event effects and the unchanged primitive's real local command captures. Both complete controlled arm sequences retain the failure, use the actual successful parser receipt and fresh full task Anchor, and preserve an independent open policy conflict only where applicable. All nine controlled recording results keep implementation readiness, original acceptance and native claims false. No ordinary stream contains a fabricated legacy `actual-Root-data-decision-received` or phase-start event.

The finite scalar matrix covers all six fields, all eleven excluded delimiters, and embedded/trailing positions: 132 guard-and-schema cases. Ordinary Unicode round-trips through the real recorded row. Raw invalid actor/Root bytes remain unchanged on refusal. The delimiter issue is the existing splitlines consumer boundary; the writer/state helper themselves do not call splitlines for that path.

The actual terminal descriptor matrix covers fourteen missing required fields plus twelve invalid type/value/capture cases: 26 refusals. Missing/drifted TASK is refused at all three operations before currentness/effects. Foreign witness, source drift, absent review, actual controlled nonverdict and wrong-controller/ambiguous/incomplete/refused currentness responses also fail closed with retained evidence.

The GREEN tree has 128 real local producer command records and 14 explicitly labeled currentness doubles. RED has 29 real local command records and no currentness double invocation. The two outer test-run producer records are additional. Every currentness double is marked synthetic/no-process/no-controller; its values are ineligible for real admission. Actual local fixture commits were expressly authorized by Root and their full argv/results are retained. They are controlled fixture history, not original/runtime-source acceptance.

GREEN retains 9 controlled recording results and 15 admission refusals, all with record_effects_started=false and no actor rewrite. Source-level rerun refusals and the pure receiver predicate observations are separately retained. The receiver test executes only the exact AST-extracted pure record-validation statements; it calls no legacy receiver, mailbox, current, refresh or snapshot routine. The containment branch's local recording methods are exercised through the ordinary adapter and direct owner controls; no claim of a complete legacy-host test is made.

Complete actual tool returns are in receipts/RED_TOOL_CAPTURE.json and GREEN_TOOL_CAPTURE.json. The primitive-produced command JSON, stdout and stderr are under the corresponding receipts/*-run/commands directories. Controlled task trees, complete command populations, state/event preimages, raw requests and refusals remain available. CONTROL_COUNTS.json records the exact populations; final tree censuses bind every retained byte.

## New currentness and invocation binding

The new interface is SHA-256 `0e778c3fd9eb1cd4bba728535fb589a0ff82578a7abfbda4acfef6214ef95f6b`. It binds controller `dg16-dg18-recovery-20261119-b`, cwd `/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b`, and the actual installed 14,707-byte helper `9c9945fdf650c72b8019f0dd908fff360162cc11ae7eb3197ccafe0f6ab3730f`. Source binds both the new controller and the new complete interface digest. No epoch or receipt commit is hardcoded.

Future production invokes the actual helper immediately before record effects, captures its full result before interpreting it, and requires the actual returned full receipt for that controller. Author tests replace only the existing explicit seam. Root's caller-reported continuity is context, not a receipt obtained by this author and not a future effect's currentness.

RUN_INTERFACE.md supplies concrete invocation forms, exact typed inputs, operation order and the minimal existing package-review/Root-receiving schema. ROOT_REQUEST.template.json and ROOT_PREFLIGHT.template.json leave all live judgments/actors/results unfilled. The descriptive census may be rechecked and received; it does not self-issue package/source acceptance or introduce a native/install/child gate.

## Complete message and capture relationship

Root identified the message-only host delivery risk, and R4 resolves it prospectively in metadata using the existing opaque HostObservation representation. The 736-byte common prompt is an exact component of the larger actual submitted message. A frozen neutral transport template adds only actual path/digest routing and access boundaries. Root must capture the full actual message separately, record the prompt component's exact UTF-8 interval, retain the complete file-reference population and actual invocation/result, and obtain later actual actor evidence. No separate attachment API or workdir parameter is claimed.

HostObservation.subject_sha256 continues to bind the exact prompt component. Its raw_result can bind a lossless, explicitly Root-authored capture envelope, separately binding the full message and exact observed result. The wrapper is not provider output or proof of delivery. Empty results remain empty. Actual task/operation references and actor-owned chunks remain distinct from Root reads and unavailable provider IDs. No live reference has been populated.

The new ACTOR_TRANSPORT_MESSAGE template, submission manifest and capture-envelope schema are frozen in PRE_ACTOR_FREEZE.json before any actor. The objective reason is host interface executability, not an actor outcome. Exact common/post-check prompt bytes and oracle remain unchanged. Root must use fresh non-inheriting actor contexts so hidden evaluator, sibling and engineering history are not inherited.

ROOT_CAPTURE_MAP.json names the actual Root-supplied STATE/ROADMAP paths separately from each new arm's dedicated STATE/events/checkpoint and task inputs/subject. The plan requires eight full artifact observations at six boundaries per arm, including failed-row preimage before resolution and honest initial absence. Root documents may stay identical. No task ROADMAP, Root snapshot or synthetic governance event was manufactured here.

## Remaining evidence and semantic boundaries

Same-reviewer genuine independent source/pre-actor review and actual Root receiving are still pending. Then the episode needs actual fresh task workspaces/full HEADs, actual initial/post-check message submissions and returns, actual failed/successful command receipts, separate actual Root decisions, all mapped full captures, each actual paired-helper result and final independent episode receiving against the unchanged oracle. Python supplies no cognition or host authentication.

Broader a297 Andon semantics remain actual receiving obligations: interrupted owner/decision, last safe step, next unfinished gate, affected evidence, blocked_scope/unblocked_work and any required justification. If an actual return asserts absent capability/resource exhaustion, the original negative-capability/probe-evidence/falsification requirements also remain applicable. This packet does not infer those claims, fabricate their probes or add them as a universal new gate. A correct class, a successful parser or absence of implementation alone does not establish the actor recognized the independent conflict.

The lost historical corrected recorder, original TASK/freeze/schema bodies, complete old controlled trees and full old seals remain missing. This new packet does not substitute its files for them. Original F1, whole P03/DG17, M01/N06, native Stop/M4, ancestor JOIN, release and closure remain unawarded. No recovery of redundant controlled fixtures is imposed as a new original native requirement.

MANIFEST.json will bind the final small direct population and the two complete controlled-tree censuses. TERMINAL_RECEIPT.json and TERMINAL_TOOL_RECEIPT.json retain the actual final verification result and bind that manifest. Essential full source, metadata and actual returns are also retained in functions.store pending durable Root publication. No publication or provider mutation is performed by this author.
