# Concrete prospective Root capture plan

This plan is frozen before any actor. It describes future Root-owned observations and has no live captures. ROOT_CAPTURE_MAP.json binds the exact supplied owning Root STATE/ROADMAP and two new dedicated namespace paths. The author has not read or created those live namespaces or changed Root state.

## Complete population and timing

For each arm, capture all eight mapped artifacts immediately before and after each of record-failure, record-rerun and record-l1-return. Before means after the exact request and all its evidence are ready, with no intervening mutation before invocation. After means after the actual terminal result, including refusal or partial effects, and before the next mutation or actor continuation. The two existing Root documents remain separate from the dedicated recording STATE/events/checkpoint.

Every boundary is a new actual read, even when its bytes match an earlier capture. Preserve the full observed bytes, source path, byte count, SHA-256, mode and actual observation reference. A storage copy may be deduplicated by digest only after a fresh read is recorded. Retain the actual capture argv/code, complete result and terminal outcome. No hash-only snapshot substitutes for the bytes.

At record-failure-before, dedicated STATE/events/checkpoint are expected to be absent. Record observed absence with source path and an actual observation reference; use null for payload/byte count/digest. Do not create an empty file or invent a hash for absence. Root STATE/ROADMAP and task files must exist. If a refused initial call leaves dedicated files absent, retain that actual after-state. Missing required files, aliases, unreadable files, capture races or unfinished commands remain explicit gaps.

Before record-rerun, preserve the entire failed-row STATE preimage, not only the earlier admission/checkpoint hashes. After rerun, retain the complete changed table and events. This captures the original failure outside the replaced rerun cell and the actual successful command/Anchor in that cell. TASK and implementation subject remain byte-identical across all boundaries; only the supplied proposal may receive the separately authorized syntax-only correction.

Root STATE/ROADMAP can truthfully remain identical at every boundary. Create no task ROADMAP and no synthetic Root governance event to make them appear changed. If actual owning Root paths change after a boundary, receive the changed paths and review the objective map binding before dispatch; preserve this plan as historical data.

## Actor-visible submission captures

Before each actual initial or post-check submission, fill the submission-manifest template from actual bytes. Include the complete attachment population: assigned TASK, current proposal, unchanged subject, permitted neutral prompt, immutable policy source, separately received executing governor source, actual parser record and both full streams. Keep the oracle, sibling arm, source repair report, tests/results and Root snapshots outside actor-visible material.

ACTOR_TRANSPORT_MESSAGE.template.txt is a new neutral routing template because this host exposes a message string and task name, with no separate attachment/workdir parameter. Expand only its exact prompt-component placeholder and four path/digest placeholders. Initial assignment prompt bytes remain the recovered 736-byte common prompt. Post-check assignment bytes are exactly the recovered template plus the actual deciding-command SHA-256 line required by the adapter. The common prompt is a component of a larger submitted message, never the whole message. Capture both complete byte populations separately and record the component's UTF-8 byte interval in the actual submitted message.

The manifest is the complete file-reference population conveyed through that message; it does not claim an attachment API was used. Capture the complete actual invocation arguments, full message/expansion, referenced files and exact actual result. Bind a lossless, explicitly Root-authored envelope under HostObservation.raw_result. Its subject_sha256 identifies the exact assignment-prompt component required by the adapter. The envelope separately binds the full submitted message and its routing context; those digests are not interchangeable. A prompt-file hash or successful send alone is not evidence that any file was read. HOST_CAPTURE_ENVELOPE.schema.json documents this opaque envelope without adding a sixth HostObservation field or changing the adapter.

Use one fresh ordinary actor task for each arm with fork_turns="none", then its actual continuation for the post-check stage. This prevents inheritance of Root's oracle, sibling and engineering history. Do not use condition-bearing task names. Preserve exact initial and later returns. A wrong answer, refusal, nonverdict or absent observation remains evidence; do not revise the prompt or repeat an actor to obtain a preferred result. Syntax preparation is a separately authorized Root action. It changes no semantic value and supplies no actor reasoning.

## Host observations and attribution

The existing five-field HostObservation shape remains unchanged. Its opaque 1–256-character reference may carry a typed actual task/operation reference. If a content/operation reference is derived, label it derived. Actual actor-owned command chunks, actual canonical task names and Root read references remain distinct. None attests an unavailable provider ID, native route or backend identity.

An empty send/followup return remains empty. A nonempty lossless envelope may bind the actual invocation, actual arguments and exact empty result, with Root-authored metadata explicitly labeled. Preserve raw empty bytes separately. This supplies no delivery acknowledgment; later actual actor evidence must establish the observed return/read. Different reference strings alone do not prove separate operations.

## Receiving ceiling

Python binds Root-supplied evidence and records it. Actual source applicability, full packet review, actor provenance and semantic L1 rederivation remain Root and independent receiving obligations. The a297 broader Andon content must still describe interrupted owner/decision, last safe step, next unfinished gate, affected evidence, blocked_scope and unblocked_work, with a justification if none remains unblocked. Valid scalar shape or the expected class alone does not establish those meanings.

No live currentness result, source-review admission, Root decision, actor assignment or episode verdict is prefilled. Currentness is obtained by the production adapter immediately before each effect from the actual pinned helper. Capture and preserve any refusal; no historical receipt or test double is eligible.
