#!/usr/bin/env python3
"""Read-only independent episode verification; writes only this review's result."""
import datetime, hashlib, json, math, os, re, subprocess
from pathlib import Path

OUT=Path('/workspace/scratch/530bc07ea12b/dg17-p03-episode-independent-review')
ROOT=Path('/workspace/scratch/2678f1e431c3/dg17-p03-r4-actual-20261119')
PACKET=Path('/workspace/scratch/2678f1e431c3/dg17-p03-prospective-r4-20261119')
SEAL=Path('/workspace/scratch/530bc07ea12b/p03-episode-receiving/EPISODE_MANIFEST.json')
RECEIVING=Path('/workspace/scratch/530bc07ea12b/receiving')
EXPECTED_SEAL='e986c73611a5f4c6478db30ef5b8539596ac2b5ad5d6605a34cec0835a011119'
errors=[]; notes=[]; files=[]; timeline=[]; actor_checks=[]; git_reads=[]

def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(p): return json.loads(Path(p).read_bytes())
def need(ok,msg):
    if not ok: errors.append(msg)
def physical(p):
    p=Path(p)
    need(p.is_absolute() and str(p)==os.path.abspath(p),'noncanonical '+str(p))
    need(p.is_file() and not any(x.is_symlink() for x in [p,*p.parents]),'nonphysical '+str(p))
    return p
def binding(p):
    p=physical(p); raw=p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=sha(raw))
def bound(row):
    actual=binding(row['path'])
    need(all(actual[k]==row[k] for k in ['path','bytes','sha256']),'binding differs '+row['path'])
    return Path(row['path']).read_bytes()

need(sha(SEAL.read_bytes())==EXPECTED_SEAL,'episode seal digest')
manifest=read(SEAL)
expected=set()
for row in manifest['files']:
    need(row['relative_path'] not in expected,'duplicate file')
    expected.add(row['relative_path'])
    need(row['path']==str(ROOT/row['relative_path']),'relative/absolute path mismatch')
    bound(row);files.append(row)
actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and '.git' not in p.relative_to(ROOT).parts}
need(expected==actual,'closed non-Git file population')
need(len(files)==353 and sum(x['bytes'] for x in files)==847577,'commissioned file/byte totals')

commands={}
fields={'argv','cwd','started_at_unix','ended_at_unix','exit_code','expected_exit','timed_out','process_cleanup','owned_pgid','output_file','output_bytes','output_sha256','output_capture','stderr'}
for p in sorted(ROOT.rglob('commands/*.json')):
    d=read(p);commands[str(p)]=d
    need(fields<=set(d),'command fields '+str(p))
    need(type(d['exit_code']) is int and type(d['expected_exit']) is int and d['exit_code']==d['expected_exit'],'command exit '+str(p))
    need(d['timed_out'] is False and d['process_cleanup']=='owned-process-group-absent' and type(d['owned_pgid']) is int and d['owned_pgid']>0,'terminal process '+str(p))
    need(all(type(d[k]) in (float,int) and math.isfinite(d[k]) for k in ['started_at_unix','ended_at_unix']) and d['started_at_unix']<=d['ended_at_unix'],'command times '+str(p))
    need(d['output_capture']=='separate-stdout-stderr','stream mode '+str(p))
    need(not d.get('TEST_ONLY') and not d.get('no_controller_invoked'),'test double in actual command '+str(p))
    for suffix,row in [('.log',dict(file=d['output_file'],bytes=d['output_bytes'],sha256=d['output_sha256'])),('.stderr',d['stderr'])]:
        s=p.with_suffix(suffix);raw=s.read_bytes()
        need(row['file']==s.name and type(row['bytes']) is int and row['bytes']==len(raw) and row['sha256']==sha(raw),'command stream '+str(s))
for folder in {Path(p).parent for p in commands}:
    need({p.stem for p in folder.glob('*.json')}=={p.stem for p in folder.glob('*.log')}=={p.stem for p in folder.glob('*.stderr')},'command closed stream population '+str(folder))

capture_map=read(PACKET/'ROOT_CAPTURE_MAP.json')
common=(PACKET/'contracts/scenario/actor-prompt.txt').read_bytes()
post=(PACKET/'contracts/post-check-prompt-template.txt').read_bytes()
transport=(PACKET/'plan/ACTOR_TRANSPORT_MESSAGE.template.txt').read_text()
sources={x:binding(PACKET/x) for x in ['root_callsite.py','source/hosted_phase.py','source/transport_primitives.py','contracts/ORIGINAL_A297_PROTOCOL.md']}
required_ids={'root-state','root-roadmap','dedicated-state','dedicated-events','dedicated-checkpoint','task-requirements','proposal','implementation-subject'}
for arm,actor in [('arm-a','/root/configuration_reader_one'),('arm-b','/root/configuration_reader_two')]:
    ws=ROOT/arm; task=ws/'task'; ident=read(ws/'TASK_IDENTITY.json')
    need(ident['root']==str(task) and re.fullmatch('[0-9a-f]{40}',ident['head']),arm+' task identity')
    initial=(PACKET/'contracts/scenario'/arm/'incoming/proposal.json').read_bytes()
    corrected=(PACKET/'contracts/scenario'/arm/'syntax-corrected-proposal.json').read_bytes()
    task_bytes=(PACKET/'contracts/scenario'/arm/'TASK.md').read_bytes()
    subject=(PACKET/'contracts/scenario'/arm/'subject/service.json').read_bytes()
    need(initial.replace(b',}',b'}')==corrected and initial!=corrected,arm+' exact one-comma transformation')
    need((ws/'syntax-correction-before.raw').read_bytes()==initial and (ws/'syntax-correction-after.raw').read_bytes()==corrected,arm+' full correction bytes')
    need((task/'TASK.md').read_bytes()==task_bytes and (task/'subject/service.json').read_bytes()==subject and (task/'incoming/proposal.json').read_bytes()==corrected,arm+' final task content')
    failed=ws/'captures/commands/007-syntax-failure.json';success=ws/'captures/commands/008-syntax-rerun.json'
    for p,raw,expected_exit in [(failed,initial,1),(success,corrected,0)]:
        c=commands[str(p)]
        need(c['argv']==['/usr/bin/python3','-B','-m','json.tool',str(task/'incoming/proposal.json')] and c['cwd']==str(task) and c['exit_code']==expected_exit,arm+' parser invocation')
        ib=read(ws/('syntax-failure-binding.json' if expected_exit else 'syntax-rerun-binding.json'))
        need(ib==dict(schema='dg17.json-check-input-binding.v1',command_sha256=sha(p.read_bytes()),task_root=str(task),task_head=ident['head'],input_before_sha256=sha(raw),input_after_sha256=sha(raw),recorder_sha256=sources['source/hosted_phase.py']['sha256']),arm+' parser input binding')
        if expected_exit: need(p.with_suffix('.log').read_bytes()==b'' and bool(p.with_suffix('.stderr').read_bytes()),arm+' real refusal streams')
        else: need(p.with_suffix('.stderr').read_bytes()==b'' and read(p.with_suffix('.log'))==json.loads(raw),arm+' success streams')
    need(commands[str(failed)]['ended_at_unix']<commands[str(success)]['started_at_unix'],arm+' failure-before-success')
    actor_returns={}
    for stage in ['initial','post-check']:
        d=ws/'actor-delivery'/stage; im=read(d/'INPUT_MANIFEST.json'); env=read(d/'ACTUAL_DISPATCH_ENVELOPE.json')
        prompt=common if stage=='initial' else post+b'\nObservation SHA-256: '+sha(success.read_bytes()).encode()+b'\n'
        need((d/'PROMPT.txt').read_bytes()==prompt,arm+' exact prompt '+stage)
        need(im['actor']==actor and im['task_root']==str(task) and im['task_head']==ident['head'],arm+' actor manifest binding '+stage)
        need(len(im['complete_referenced_file_population'])==63,arm+' assigned file count '+stage)
        rows=im['complete_referenced_file_population']; need(len({x['path'] for x in rows})==63,arm+' assigned population duplicates')
        for row in rows:
            if row['path']==str(task/'incoming/proposal.json'):
                raw=initial if stage=='initial' else corrected
                need((row['bytes'],row['sha256'])==(len(raw),sha(raw)),arm+' stage proposal binding')
            else: bound(row)
        need(not any('/evaluator/' in x['path'] or '/controls/' in x['path'] or '/root-boundary-captures/' in x['path'] or '/'+('arm-b' if arm=='arm-a' else 'arm-a')+'/' in x['path'] for x in rows),arm+' hidden input in actor population')
        expected_message=transport.replace('{{ASSIGNMENT_PROMPT_EXACT_BYTES}}',prompt.decode()).replace('{{PROMPT_ABSOLUTE_PATH}}',str(d/'PROMPT.txt')).replace('{{PROMPT_SHA256}}',sha(prompt)).replace('{{MANIFEST_ABSOLUTE_PATH}}',str(d/'INPUT_MANIFEST.json')).replace('{{MANIFEST_SHA256}}',sha((d/'INPUT_MANIFEST.json').read_bytes())).encode()
        need((d/'MESSAGE.txt').read_bytes()==expected_message,arm+' frozen transport expansion '+stage)
        actual_message=env['arguments']['message'].encode()
        if arm=='arm-b' and stage=='initial':
            need(actual_message==expected_message[:-1] and expected_message[-1:]==b'\n' and (d/'ACTUAL_SUBMITTED_MESSAGE.txt').read_bytes()==actual_message,'precise arm-b final-LF variation')
            notes.append('Arm-b initial actual routing message omits exactly one final LF; exact assignment prompt and all routing text unchanged; both populations retained.')
        else: need(actual_message==expected_message,arm+' actual/frozen full message '+stage)
        start,end=env['prompt_utf8_byte_interval'];need(actual_message[start:end]==prompt,arm+' actual prompt interval '+stage)
        bound(env['input_manifest']);bound(env['prompt_component']);raw_result=bound(env['raw_tool_result'])
        if stage=='initial':
            need(env['tool']=='collaboration.spawn_agent' and env['arguments']['fork_turns']=='none' and env['actual_result']['task_name']==actor,arm+' fresh actual actor')
            need(json.loads(raw_result)==env['actual_result'],arm+' actual spawn result')
        else:
            need(env['tool']=='collaboration.followup_task' and env['arguments']['target']==actor.rsplit('/',1)[-1] and raw_result==b'',arm+' actual empty same-actor continuation')
        ret=(d/'ACTUAL_ACTOR_RETURN.md').read_bytes();actor_returns[stage]=sha(ret)
        ret_env=read(d/'ACTUAL_RETURN_ENVELOPE.json');need(ret_env['actual_sender']==actor and bound(ret_env['actual_return'])==ret,arm+' return attribution '+stage)
        for name,sender,subject_sha in [('DISPATCH_OBSERVATION.json','/root',sha(prompt)),('RETURN_OBSERVATION.json',actor,sha(ret))]:
            ob=read(d/name);need(ob['sender']==sender and ob['subject_sha256']==subject_sha and ob['tool_call_id'].startswith('derived:'),arm+' typed actual observation '+stage+' '+name);bound(ob['raw_result'])
        actor_checks.append(dict(arm=arm,stage=stage,actor=actor,prompt_sha256=sha(prompt),actual_message_sha256=sha(actual_message),return_sha256=sha(ret),assigned_files=63))
    previous=None; prior_after=None
    map_rows={x['id']:x for x in next(x for x in capture_map['arms'] if x['arm']==arm)['artifacts']}
    for op in ['record-failure','record-rerun','record-l1-return']:
        rp=ws/'root-receiving'/(op+'.request.json');req=read(rp);dec=read(ws/'root-receiving'/(op+'.decision.json'))
        bd=read(ws/'outer-recording-captures'/op/'BOUNDARY_RECEIPT.json');res=bd['actual_result']
        need(res==read(res['receipt_path']),arm+' actual result binding '+op)
        need(req['operation']==op and req['task']=={'root':str(task),'head':ident['head']},arm+' request task '+op)
        need(res['request_sha256']==sha(rp.read_bytes()) and res['Root_receiving_sha256']==sha(bound(req['root_receiving'])),arm+' actual root receiving '+op)
        need(req['actor']['name']==actor and res['actor_return_sha256']==actor_returns['post-check' if op=='record-l1-return' else 'initial'],arm+' exact actor return binding '+op)
        need(bound(req['actor']['raw_return'])==(ws/'actor-delivery'/('post-check' if op=='record-l1-return' else 'initial')/'ACTUAL_ACTOR_RETURN.md').read_bytes(),arm+' raw actor bytes '+op)
        need(req['source']['adapter_sha256']==sources['root_callsite.py']['sha256'],arm+' exact adapter '+op)
        for key,source in [('recorder','source/hosted_phase.py'),('primitive','source/transport_primitives.py'),('target_policy','contracts/ORIGINAL_A297_PROTOCOL.md')]:need(req['source'][key]==sources[source],arm+' exact '+key+' '+op)
        for v in req['source']['package'].values(): bound(v)
        if previous is None: need(req['previous_admission'] is None,arm+' initial no prior')
        else: need(json.loads(bound(req['previous_admission']))==previous,arm+' prior result ordering '+op)
        previous=res
        outer_path=ws/'outer-recording-captures'/op/'commands/001-ordinary-recording.json';outer=commands[str(outer_path)]
        need(outer['argv']==['/usr/bin/python3','-B',str(PACKET/'root_callsite.py'),'--request',str(rp),'--sha256',sha(rp.read_bytes()),'--workspace',str(ws)] and outer['cwd']==str(ws),arm+' actual production invocation '+op)
        need(read(outer_path.with_suffix('.log'))==res and outer_path.with_suffix('.stderr').read_bytes()==b'',arm+' actual production output '+op)
        cap={}
        for moment in ['before','after']:
            c=read(ws/'root-boundary-captures'/(op+'-'+moment)/'CAPTURE.json');bound(bd[moment]);obs={x['id']:x for x in c['observations']}
            need(set(obs)==required_ids and len(c['observations'])==8,arm+' complete boundary '+op+' '+moment)
            for key,x in obs.items():
                need(x['source']==map_rows[key]['source'],arm+' mapped path '+key)
                if x['exists']:
                    raw=Path(x['payload']).read_bytes();need(len(raw)==x['bytes'] and sha(raw)==x['sha256'],arm+' full boundary payload '+op+' '+moment+' '+key)
                    if key in ['task-requirements','implementation-subject']:need(raw==(task_bytes if key=='task-requirements' else subject),arm+' unchanged task/subject '+op+' '+moment)
                    if key=='proposal':need(raw==(initial if op=='record-failure' else corrected),arm+' correct candidate stage '+op+' '+moment)
                else:need(op=='record-failure' and moment=='before' and key in ['dedicated-state','dedicated-events','dedicated-checkpoint'] and all(x[k] is None for k in ['bytes','sha256','payload']),arm+' honest initial absence')
            cap[moment]=obs
        need(max(x['observed_at_unix'] for x in cap['before'].values())<=outer['started_at_unix']<=outer['ended_at_unix']<=min(x['observed_at_unix'] for x in cap['after'].values()),arm+' boundary timing '+op)
        after=cap['after'];need(after['dedicated-state']['sha256']==res['state_sha256'] and after['dedicated-checkpoint']['sha256']==res['checkpoint_sha256'],arm+' actual resulting state '+op)
        if prior_after:
            need(all(cap['before'][k]['sha256']==prior_after[k]['sha256'] for k in ['dedicated-state','dedicated-events','dedicated-checkpoint']),arm+' retained complete preimage '+op)
        prior_after=after
        attempt=Path(res['receipt_path']).parent;curpath=next((attempt/'currentness/commands').glob('*.json'));cur=commands[str(curpath)]
        interface=read(PACKET/'contracts/ROOT_CURRENTNESS_INTERFACE.json')
        need(cur['argv']==interface['argv'] and cur['cwd']==interface['cwd'],arm+' live helper pairing '+op)
        receipt=curpath.with_suffix('.log').read_text().rstrip('\n')
        need(re.fullmatch(r'refs/implementaudit/continuity-receipts/dg16-dg18-recovery-20261119-b/G[0-9A-F]{4}@[0-9a-f]{40}',receipt) and receipt==res['root_currentness_receipt'] and curpath.with_suffix('.stderr').read_bytes()==b'',arm+' actual full continuity receipt '+op)
        need(outer['started_at_unix']<=cur['started_at_unix']<=cur['ended_at_unix']<=outer['ended_at_unix'],arm+' helper inside operation '+op)
        toolname='P03_'+('A' if arm=='arm-a' else 'B')+'_'+{'record-failure':'FAILURE','record-rerun':'RERUN','record-l1-return':'L1_RETURN'}[op]+'_RECORD_TOOL.json'
        tool=read(RECEIVING/toolname);need(tool['exit_code']==0 and json.loads(tool['output'])==res,arm+' genuine outer tool result '+op)
        timeline.append(dict(arm=arm,operation=op,started=outer['started_at_unix'],ended=outer['ended_at_unix'],stage=res['stage'],currentness=receipt,actual_tool_chunk=tool['chunk_id']))
    need(commands[str(failed)]['ended_at_unix']<timeline[-3]['started']<timeline[-3]['ended']<commands[str(success)]['started_at_unix']<commands[str(success)]['ended_at_unix']<timeline[-2]['started']<timeline[-2]['ended']<timeline[-1]['started'],arm+' failure record correction rerun return order')
    anchor_path=ws/'captures/commands/009-andon-rerun-anchor.json';need(anchor_path.with_suffix('.log').read_text().strip()==ident['head'],arm+' fresh full Anchor')
    need(commands[str(anchor_path)]['argv']==['/usr/bin/git','rev-parse','HEAD'],arm+' actual Anchor command')
    for argv in [['/usr/bin/git','--no-optional-locks','rev-parse','HEAD'],['/usr/bin/git','--no-optional-locks','show','HEAD:incoming/proposal.json']]:
        rr=subprocess.run(argv,cwd=task,capture_output=True)
        git_reads.append(dict(arm=arm,argv=argv,cwd=str(task),exit_code=rr.returncode,stdout=rr.stdout.decode(),stderr=rr.stderr.decode()))
        need(rr.returncode==0 and rr.stderr==b'',arm+' independent task Git read')
        need(rr.stdout.strip().decode()==ident['head'] if 'rev-parse' in argv else rr.stdout==initial,arm+' independent task baseline HEAD/content')

result=dict(schema='dg17.p03-independent-episode-verification.v1',observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='PASS' if not errors else 'GAP-REVISE',errors=errors,notes=notes,input_manifest_sha256=EXPECTED_SEAL,files=len(files),bytes=sum(x['bytes'] for x in files),actual_command_records=len(commands),snapshots=12,artifact_observations=96,actor_submissions=actor_checks,recording_timeline=timeline,independent_task_git_reads=git_reads,verified_file_census=files,actual_source_execution=False,new_actor_calls=0,new_controller_calls=0,original_case_award=False)
(OUT/'VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['verified_file_census','independent_task_git_reads']},indent=2))
raise SystemExit(bool(errors))
