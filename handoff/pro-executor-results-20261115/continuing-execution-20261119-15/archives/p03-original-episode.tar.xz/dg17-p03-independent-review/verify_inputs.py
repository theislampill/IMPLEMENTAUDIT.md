#!/usr/bin/env python3
"""Independent read-only byte census; output is confined to the review directory."""
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat

PACKET = Path('/workspace/scratch/2678f1e431c3/dg17-p03-prospective-r4-20261119')
OUT = Path('/workspace/scratch/530bc07ea12b/dg17-p03-independent-review')
MANIFEST_SHA = '393beb634e9736f7a95fc65021dee7b43ad2456f43c90026db46019f16e2c5ab'
errors = []
verified = []


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(condition, message):
    if not condition:
        errors.append(message)


def read_json(path):
    return json.loads(path.read_bytes())


def file(path, size=None, digest=None, mode=None):
    require(path.is_absolute() and str(path) == os.path.abspath(path), 'noncanonical ' + str(path))
    require(not any(p.is_symlink() for p in [path, *path.parents]), 'alias ' + str(path))
    require(path.is_file(), 'not a regular file ' + str(path))
    if not path.is_file():
        return None
    raw = path.read_bytes()
    actual = dict(path=str(path), bytes=len(raw), sha256=sha(raw), mode=oct(stat.S_IMODE(path.stat().st_mode)))
    if size is not None:
        require(actual['bytes'] == size, 'byte count ' + str(path))
    if digest is not None:
        require(actual['sha256'] == digest, 'digest ' + str(path))
    if mode is not None:
        require(actual['mode'] == mode, 'mode ' + str(path))
    verified.append(actual)
    return raw


manifest = read_json(PACKET / 'MANIFEST.json')
file(PACKET / 'MANIFEST.json', digest=MANIFEST_SHA)
require(len(manifest['files']) == 57, 'direct population count')
expected_direct = set()
for row in manifest['files']:
    require(row['path'] not in expected_direct, 'duplicate direct member')
    expected_direct.add(row['path'])
    require(row['type'] == 'file', 'unexpected direct member type')
    file(PACKET / row['path'], row['bytes'], row['sha256'], row['mode'])
actual_direct = {
    p.relative_to(PACKET).as_posix() for p in PACKET.rglob('*')
    if p.is_file() and p.relative_to(PACKET).parts[0] != 'controls'
    and p.relative_to(PACKET).as_posix() not in manifest['exclusions']
}
require(actual_direct == expected_direct, 'direct closed population differs')
tree_results = []
for tree in manifest['trees']:
    census_path = PACKET / tree['census_path']
    file(census_path, digest=tree['census_sha256'])
    census = read_json(census_path)
    root = PACKET / tree['path']
    expected = set()
    total_bytes = total_files = 0
    for row in census['entries']:
        relative = row['path']
        require(relative not in expected, 'duplicate tree member')
        expected.add(relative)
        path = root / relative
        if row['type'] == 'directory':
            require(path.is_dir() and not path.is_symlink(), 'directory ' + str(path))
            require(oct(stat.S_IMODE(path.stat().st_mode)) == row['mode'], 'directory mode ' + str(path))
        else:
            require(row['type'] == 'file', 'unsupported tree member')
            file(path, row['bytes'], row['sha256'], row['mode'])
            total_bytes += row['bytes']
            total_files += 1
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*')}
    require(actual == expected, 'closed tree population ' + tree['path'])
    require((len(expected), total_files, total_bytes) == (tree['entries'], tree['files'], tree['bytes']), 'tree summary ' + tree['path'])
    tree_results.append(dict(path=tree['path'], entries=len(expected), files=total_files, bytes=total_bytes))

lineage = read_json(PACKET / 'INPUT_LINEAGE.json')
for row in lineage['copies']:
    raw = file(Path(row['source']), row['bytes'], row['sha256'])
    if row['copy'] not in lineage['working_copies_expected_to_change']:
        require((PACKET / row['copy']).read_bytes() == raw, 'lineage copy ' + row['copy'])

for name, key in [('PRE_ACTOR_FREEZE.json', 'path'), ('contracts/SCENARIO_FREEZE.json', 'local_path')]:
    for row in read_json(PACKET / name)['entries']:
        file(PACKET / row[key], row['bytes'], row['sha256'])

inventory = read_json(PACKET / 'contracts/GOVERNOR_INVENTORY_DATA.json')
root = Path(inventory['selected_package'])
expected = set()
for row in inventory['files']:
    require(row['relative_path'] not in expected, 'duplicate installed member')
    expected.add(row['relative_path'])
    require(str(root / row['relative_path']) == row['path'], 'installed member path binding')
    file(Path(row['path']), row['bytes'], row['sha256'], row['mode'])
require(len(expected) == inventory['file_count'] == 54, 'installed population count')
require(expected == {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}, 'installed closed population')

interface = read_json(PACKET / 'contracts/ROOT_CURRENTNESS_INTERFACE.json')
helper = interface['helper']
file(Path(helper['path']), helper['bytes'], helper['sha256'])
require(interface['argv'] == ['bash', helper['path'], '--require-current-continuity', 'dg16-dg18-recovery-20261119-b'], 'currentness interface argv')
require(interface['cwd'] == '/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b', 'currentness cwd')

old = ast.parse((PACKET / 'inputs/original/hosted_phase.py').read_text())
new = ast.parse((PACKET / 'source/hosted_phase.py').read_text())
def functions(tree):
    return {n.name: ast.dump(n, include_attributes=False) for n in tree.body if isinstance(n, ast.FunctionDef)}
old_f, new_f = functions(old), functions(new)
require(set(old_f) == set(new_f), 'recorder function population')
changed_functions = [k for k in old_f if old_f[k] != new_f[k]]
require(changed_functions == ['receive_decision', 'andon', 'resolve_andon'], 'recorder changed functions')
require([ast.dump(n, include_attributes=False) for n in old.body if not isinstance(n, ast.FunctionDef)] == [ast.dump(n, include_attributes=False) for n in new.body if not isinstance(n, ast.FunctionDef)], 'recorder nonfunction AST')
old_a = ast.parse((PACKET / 'inputs/root_callsite.r3.py').read_text())
new_a = ast.parse((PACKET / 'root_callsite.py').read_text())
require(len(old_a.body) == len(new_a.body), 'adapter AST population')
changed_constants = []
for left, right in zip(old_a.body, new_a.body):
    if ast.dump(left, include_attributes=False) != ast.dump(right, include_attributes=False):
        require(isinstance(left, ast.Assign) and isinstance(right, ast.Assign), 'adapter nonassignment delta')
        changed_constants.append(right.targets[0].id)
require(changed_constants == ['OWNER_SHA', 'FREEZE_SHA', 'INTERFACE_SHA', 'CONTROLLER'], 'adapter changed constant population')

terminal = read_json(PACKET / 'TERMINAL_RECEIPT.json')
tool_terminal = read_json(PACKET / 'TERMINAL_TOOL_RECEIPT.json')
file(PACKET / 'TERMINAL_RECEIPT.json')
file(PACKET / 'TERMINAL_TOOL_RECEIPT.json')
require(terminal['manifest_sha256'] == MANIFEST_SHA, 'terminal manifest binding')
require(tool_terminal['terminal_resume_result']['exit_code'] == 0, 'retained terminal exit')
require(json.loads(tool_terminal['terminal_resume_result']['output']) == terminal, 'retained tool result and terminal receipt equality')
result = dict(
    schema='dg17.p03.independent-input-verification.v1',
    observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    reviewer='/root/dg17_p03_review', input_manifest_sha256=MANIFEST_SHA,
    status='PASS' if not errors else 'GAP-REVISE', errors=errors,
    direct_files=len(expected_direct), controlled_trees=tree_results,
    installed_governor_files=len(expected), lineage_entries=len(lineage['copies']),
    changed_recorder_functions=changed_functions, changed_adapter_constants=changed_constants,
    verified_file_observations=verified,
    source_tests_replayed=False, live_currentness_invoked=False, actor_calls=0,
    original_acceptance=False,
)
(OUT / 'INPUT_VERIFICATION.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'verified_file_observations'}, indent=2))
raise SystemExit(bool(errors))
