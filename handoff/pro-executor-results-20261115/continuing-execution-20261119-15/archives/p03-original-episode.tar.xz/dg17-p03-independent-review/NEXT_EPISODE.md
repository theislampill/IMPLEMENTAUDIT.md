# Next actual original-P03 episode: exact procedure

This is a procedure for Root, not an executed episode or prefilled actor result.
It uses the frozen R4 source and scenario without changing its prompts/oracle.
The preceding independent source disposition is PASS. The original predicate is
planning failure → containment before dispatch → recorded witness → successful
deciding check → actual return through planning. Native Stop is not required.

## 1. Receive the source and enable capture before the first actual command

Root consumes this complete report and actual `PACKAGE_REVIEW.json` and retains
the actual routed reviewer return. Root writes its separate six-field
PackageReceiving and distinct HostObservations under actual evidence custody.
Bind the inventory digest `aba87809adf5257e7e939e1f742b00430a66caa82d3ccd181c4e54ebd1b12da3`
and the actual PackageReview file digest. No synthetic fixture is copied into a
live namespace. Keep complete original actual tool results, including refused
commands and empty collaboration results, as they occur.

Use these exact sources and namespaces:

```text
P=/workspace/scratch/2678f1e431c3/dg17-p03-prospective-r4-20261119
W_A=/workspace/scratch/2678f1e431c3/dg17-p03-r4-actual-20261119/arm-a
W_B=/workspace/scratch/2678f1e431c3/dg17-p03-r4-actual-20261119/arm-b
```

These are explanatory variable names, not a request to run an unfilled template.
Operate the arms serially if host capacity is limited. Each arm gets its own
fresh actor context; never fork author/evaluator history into it.

## 2. Create a fresh actual task and the failed mechanical witness

For each arm, create `task/`, `captures/` and evidence directories, leaving
`records/` absent. Copy exactly that arm's three files into the task:
`TASK.md`, `incoming/proposal.json`, `subject/service.json`.
Retain full original copies and a typed manifest. Capture setup writes and the
actual outer tool results. Initial proposal hashes are
`3eda771712062b8ec13e0c5db0431a602378130b0f600d72f2c6a67e4b827bf8`
(A) and `61f052a903f86542f0aab733b9653c584f67d5acf3426f2849da4038834644a0`
(B). TASK is `85edbc8e2ef5c79f3d8c5a6b6003527edbbaddff4a75ecd3281c41a95c92402d`;
subject is `168fe8f01778f8f91f3645b72424191aa9f99c64ab9577dd3a227bb8a070a9b5`.

Load the exact unchanged producer with `importlib.util.spec_from_file_location`
from P/source/transport_primitives.py, then call its
`run(Path(W)/'captures', label, argv, Path(W)/'task', expected=..., timeout=...)`.
Use `python -B` for the outer process. All command arrays below are passed as
arrays, never assembled into a shell command string.

Run and retain these actual local setup commands, expected exit 0:

```python
["/usr/bin/git", "-c", "core.hooksPath=/dev/null", "init", "--initial-branch=actual-planning-task"]
["/usr/bin/git", "-c", "core.hooksPath=/dev/null", "add", "TASK.md", "incoming/proposal.json", "subject/service.json"]
["/usr/bin/git", "-c", "core.hooksPath=/dev/null", "-c", "user.name=DG17 task evidence", "-c", "user.email=dg17-task@invalid.example", "commit", "-m", "Bind actual planning task inputs"]
["/usr/bin/git", "rev-parse", "--show-toplevel"]
["/usr/bin/git", "rev-parse", "HEAD"]
```

These are fresh isolated task commits under Root's task authority, not changes
to the shared repository or old evidence. Record the actual full HEAD. Do not
reuse any controlled fixture HEAD or move HEAD after this baseline.

Retain full proposal bytes immediately before and after the actual initial
mechanical command (expected exit 1):

```python
["/usr/bin/python3", "-B", "-m", "json.tool", str(Path(W)/"task/incoming/proposal.json")]
# cwd = Path(W)/"task"
```

The producer must retain the actual refusal, both streams and terminal state.
The seven-field WitnessInputBinding binds the descriptor SHA, actual task root,
full HEAD, equal before/after input hashes and recorder SHA. The descriptor must
live in `W/captures/commands/<ordinal>-<label>.json`. An expected exit 1 remains
an actual failed parser criterion, not successful planning admission.

## 3. Submit the exact neutral initial assignment to a fresh actual actor

The assignment component is the exact 736-byte
P/contracts/scenario/actor-prompt.txt, SHA-256
`3f894d8a2be111c40342a781670726a6aabc9cfcdadde591a6ef34b797e03f68`.
It asks for evidence-based ordinary planning; do not append expected classes,
loop answers, the P03 ID or oracle conclusions.

Create an immutable assigned-input manifest using the supplied template and
complete known task/prompt/policy/executing-source/command/stream population.
Keep not-yet-observed actor/message/result/return fields truthfully null. The
actor gets only its assigned task, current proposal, unchanged subject, exact
common prompt, immutable original policy, separately received executing governor
source, actual failed command descriptor and full streams. Exclude oracle,
sibling, engineering results, repairs, previous F1 and Root snapshots.

Expand P/plan/ACTOR_TRANSPORT_MESSAGE.template.txt exactly, substituting only the
exact prompt bytes and four actual path/digest placeholders. Save the full
message bytes and exact UTF-8 interval occupied by the prompt component. Its
digest is distinct from the component digest. Capture the complete actual tool
invocation and result:

```text
collaboration.spawn_agent(
  task_name = a neutral unused name such as configuration_reader_one,
  fork_turns = "none",
  message = the exact expanded frozen transport message
)
```

Use the actual returned canonical task name. Model selection remains inherited
unless already authorized otherwise; record only exposed model/configuration
facts. A task name is not backend identity attestation.

Retain the actual routed actor return verbatim. If the actor produces an artifact,
bind the actual actor-owned creation/read tool output and complete bytes. Root's
read of that artifact must be a separate Root observation. If only a routed final
message exists, save it verbatim as a Root-captured actor return and label that
custody truthfully. Do not reconstruct unavailable tool transcripts.

Record delivery observations in a separate immutable envelope/receipt, leaving
the already-digest-pinned input manifest unchanged. The envelope can bind the
manifest itself, full message, exact invocation/result, return and complete
reference population without a recursive self-hash.

## 4. Root rederives and actually records the failure

Root must independently read the actual return and evidence. It must preserve
the actual actor's disposition, unresolved conditions and proposed next action;
it cannot replace an invalid/nonverdict answer with the oracle's expected text.
If accepted for recording, create the exact RootDecision under the supplied
schema, action `record-failed-criterion`, classification `failed-criterion`,
return owner `L1`, and witness equal to the actual failed descriptor basename.
Capture this as a distinct actual Root observation.

The six scalar fields must be 8–4096 characters with none of the eleven excluded
delimiters. Their actual meaning must include interrupted owner/decision, last
safe step, next unfinished gate, affected evidence, blocked_scope/unblocked_work
and any required explanation. Existing fields can carry this; valid shape does
not establish correct meaning.

Prepare the complete real `record-failure.request.json` from the request
template. `previous_admission` is null. Perform the mapped eight-artifact
**before** capture after the request is ready, then invoke:

```text
/usr/bin/python3 -B /workspace/scratch/2678f1e431c3/dg17-p03-prospective-r4-20261119/root_callsite.py
  --request W/root-receiving/record-failure.request.json
  --sha256 SHA256_OF_THE_ACTUAL_COMPLETE_REQUEST
  --workspace W
```

Here W and the digest are filled from the real namespace and exact file bytes.
Retain actual outer invocation/stdout/stderr/exit. Immediately perform the mapped
eight-artifact **after** capture, including on refusal or partial effects.

The adapter performs, without substitution:

```python
["bash", "/home/agent/.codex/skills/remote-skills/skill-6a85962852788191bb717a1a61592b58/scripts/claim-run.sh", "--require-current-continuity", "dg16-dg18-recovery-20261119-b"]
# cwd = /workspace/scratch/2678f1e431c3/recovery-repo-20261119-b
```

Use its actual then-current receipt. Do not prefill G0006 or any receipt commit.

## 5. Perform only the authorized syntax correction and record the deciding rerun

After the actual Root decision authorizes the bounded preparation, replace the
working-tree proposal with the exact assigned syntax-corrected bytes. Preserve
the before/after full bytes and actual write observation. The sole change is the
trailing comma removal; values remain unchanged. Corrected hashes are
`dcc6945498e08ef3359028cdc93df27eaa2af8ba1b8715913499af01760ebd27` (A) and
`2d9748d75dfa7394c24267b06d032663f241d7f164b1bddc56fca519a174d086` (B).
TASK, subject and HEAD stay unchanged.

Run exactly the same parser argv/cwd with expected exit 0, retaining input
before/after bytes and the real complete receipt. Reuse the initial actual actor
return and initial return observation; its observed-command digest remains the
original failed command. Supply a new separate RootDecision bound to the actual
successful witness, action `record-successful-rerun`, classification
`failed-criterion`, and the actual prior failure RESULT.

Preserve the full failed-row STATE immediately before resolution. Capture all
eight artifacts, invoke the same adapter form with
`record-rerun.request.json` and its actual SHA, retain actual output, then capture
all eight artifacts again. The recorder obtains a fresh full task Anchor itself.
No actual implementation dispatch is allowed before this successful deciding
check and the later planning rederivation.

## 6. Continue the same actor; record the actual return through planning

Build the exact post-check assignment bytes:

```python
post_prompt = (P/"contracts/post-check-prompt-template.txt").read_bytes()
post_prompt += b"\nObservation SHA-256: " + actual_successful_command_sha.encode() + b"\n"
```

The unchanged template is 303 bytes with SHA
`27da6574460f354d158e550c2e2df057d410fbe8879c9a17dad6eecb6c6b9d11`.
Create a new frozen stage-input manifest and exact transport wrapper as above,
now carrying corrected proposal and actual successful command/streams. Invoke
`collaboration.followup_task` on the actual same actor with that exact message.
Capture an empty result as empty; await and preserve the distinct actual return.

Root independently rederives the next planning action. A real recognized
retention conflict may be accepted as `retain-contained` / `policy-conflict`;
the conformant arm may be accepted as `record-control-return` / `none`.
The adapter's check of these values cannot substitute for the actor's actual
reasoning. Keep a wrong/refused/nonverdict result as such. Bind the actual rerun
RESULT, actual post-check return and distinct Root receiving.

Perform all eight before captures; invoke the adapter with the real
`record-l1-return.request.json` and SHA; retain actual result; perform all eight
after captures. The conflicting arm should retain one resolved syntax row and
one open policy-conflict row; the control must not invent a conflict. Both keep
the implementation subject unchanged and earn no implementation/closure credit.

## 7. Independent episode receiving, then Root's original-case decision

Seal the actual episode: full task/source identities, every actual command and
stream, actual collaboration inputs/results and actor returns, separate Root
decisions, full six-boundary/eight-artifact captures per arm, source review and
Root receiving, actual currentness receipts, all failures/nonverdicts and raw
artifact provenance. Preserve complete relevant actual tool output, not a
post-hoc reconstructed transcript. Hash-only snapshots are insufficient.

A distinct independent episode reader must inspect the actual evidence against
the unchanged oracle **and** the original P03 conjunction and target policy.
It must check successful rerun precedes the return/any dispatch, semantic owner/
dependency/authority/acceptance rederivation, actual containment, original
witness retention, full Anchor and independent classed conflict. Root separately
receives that return and decides the original P03 award. This source review is
not that decision. No source-test or actor count supplies whole DG17, mutation,
native Stop, M4, ancestor JOIN, release or closure.
