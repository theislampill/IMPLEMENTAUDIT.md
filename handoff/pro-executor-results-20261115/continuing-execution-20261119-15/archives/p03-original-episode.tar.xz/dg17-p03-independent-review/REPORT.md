# DG17 P03 independent source and episode readiness review

Status: **PASS at bounded source and pre-actor preparation scope.** The frozen
R4 packet is suitable for a fresh actual original-P03 episode under the current
ordinary Root host route. No further source repair or historical control replay
is required by this review. Actual episode evidence and independent episode
receiving remain outstanding; this is no original-case or closure award.

Role: fresh independent reviewer; no implementation, integration, provider-write,
main-controller, release, acceptance, or closure authority.

authoring_context_reuse: no

Requested model: inherited parent model, with no override requested.
Actual model self-report: GPT-6 Astra Pro, based on the developer-provided identity;
the underlying execution model is not independently attested by this review.
This reviewer does not claim the identity of any previous reviewer.

Input packet: `/workspace/scratch/2678f1e431c3/dg17-p03-prospective-r4-20261119`.
Read boundary: that packet, its frozen inherited inputs, the specified prior
review scope, and original-case repository source where needed to determine the
actual executable episode procedure.

Review purpose: verify frozen source/input hashes and meaningful source evidence;
determine whether the original P03 actor episode is executable under Root's
authentic present host capability; identify the precise next executable
procedure without awarding the original case from adapter tests.

All new review artifacts and probes are confined to this report directory.

## Findings

### 1. Independent complete verification

The packet's manifest is SHA-256
`393beb634e9736f7a95fc65021dee7b43ad2456f43c90026db46019f16e2c5ab`.
The independent verification command completed as actual tool chunk `5385bd`,
exit 0. Its invocation/result is retained in `INPUT_VERIFICATION_TOOL_CAPTURE.json`;
the full independently read census is `INPUT_VERIFICATION.json`. Every declared
byte, file mode, physical path and closed population checked matched. [E1]

| Population | Verified result |
| --- | --- |
| Direct frozen packet | All 57 files match |
| RED tree | 431 entries, 285 files, 199,454 file bytes match |
| GREEN tree | 2,710 entries, 2,093 files, 2,191,679 file bytes match |
| Input lineage | All 18 original-source copies match; changed working copies are explicitly distinguished |
| Pre-actor/scenario freezes | Every declared member matches |
| Actual installed governor | All 54 files and complete population match |
| Currentness helper | 14,707 bytes, SHA-256 `9c9945fdf650c72b8019f0dd908fff360162cc11ae7eb3197ccafe0f6ab3730f` |
| Terminal seal | Retained tool-output JSON equals terminal receipt; manifest binding matches |

Recorder identity is `33a4eccc631cfc1e031e886f2b6f77b1502799a9242d72311be27d819474a7e0`;
adapter is `8cd14886d451007ec1d580362b098aaca1a63b610cc931013169f90fec4a8c20`;
primitive is `348bebac70e43bb8fba37e3731ab73b7bf8f99f5fbd9baf4a59cfba8a2e545c3`;
currentness interface is `0e778c3fd9eb1cd4bba728535fb589a0ff82578a7abfbda4acfef6214ef95f6b`.
Independent AST comparison confirms only `receive_decision`, `andon` and
`resolve_andon` changed in the recorder, with all other functions/nonfunction
AST unchanged. Only `OWNER_SHA`, `FREEZE_SHA`, `INTERFACE_SHA` and `CONTROLLER`
changed in the recovered r3 adapter. [E1; S1–S3]

Repository HEAD was observed as `6d9e145e2f2df5a0a8a150c85a4f3e2afd918d27`
with no tracked working-tree changes (actual tool observations `65bedc`,
`983923`). Root's supplied G0006 receipt is context, not a reviewer-produced
currentness result. The production adapter obtains then-current continuity for
the bound controller immediately before each effect. [S1]

### 2. A fresh task can satisfy original P03

The retained complete #211 body defines P03 as a failed mechanical predicate
during planning, containment before dispatch, a retained witness, and an actual
return through planning. It fixes no greeting task, historical command number,
provider run, task commit or host brand. The original-case disposition expressly
permits portable Andon registration on an eligible actual planning failure and
says native Stop is not intrinsically required. [C1 P03; C2 P03]

A real JSON parser failure in the actual governed task can therefore supply the
mechanical premise. R4's statement that it is not a historical replay preserves
history; it does not disqualify a fresh original-P03 discriminator. Its unchanged
oracle distinguishes a resolved syntax failure from an independent unresolved
retention conflict, with a conformant matched arm. The actual actor and Root
must still supply the cognition, containment and return observations. [S6]

The wider #211 model-control/held-out/mutation populations remain separate.
This two-arm episode does not by itself qualify all of them, M01/N06, native
Stop, M4 or whole DG17. Historical F1 stays a real defect of its historical run.
A later corrected execution cannot retroactively change that old table. [C1; C3]

### 3. Source and retained actual evidence

| Boundary | Finding |
| --- | --- |
| Task/ref binding | PASS. Every operation rechecks exact TASK, proposal and unchanged subject. Physical task root and actual full Git HEAD must match; checkpoint fingerprints bind task, episode, source, arm and freeze. |
| Scalar/reader contract | PASS. All six scalars reject CR/LF/VT/FF/FS/GS/RS/NEL/U+2028/U+2029/pipe before effects. The schema uses absolute end-of-input. Retained 132-case guard/schema evidence rejects prior R2.1; ordinary Unicode survives real rows. |
| Terminal capture | PASS. Fourteen required producer fields, strict integer/finite-time checks, exact argv/cwd/exit, terminal process cleanup and both full streams are bound. The retained 26 invalid-metadata cases refuse. |
| Currentness | PASS at source applicability. Exact installed helper/controller/cwd are bound. No epoch is hardcoded; no production skip/double flag exists. |
| Rerun before continuation | PASS. Correct stage and actual successful parser/input are required; failed witness is retained; a fresh full task HEAD is captured before replacing the rerun cell. |
| Policy-conflict recording | PASS. A distinct one-class open row preserves the independent conflict and BLOCKED/open state. Parser success does not grant implementation readiness. |
| Actual provenance | PASS as a binding interface. Exact sender/subject/return bytes and distinct observed operations are required. Python cannot authenticate cognition or replace Root's semantic receiving. |
| Ordinary package scope | PASS. Installed 54-file executing governor is distinct from immutable a297 target policy. No unused child, native activation or installation gate is added. |

I read the test implementation and retained source/command/state/event evidence.
RED ran five tests with eight failed assertions; GREEN ran thirteen with zero
failures/errors. Concrete REDs include missing dispatch mapping, failed/foreign/
stale-anchor rerun acceptance, incorrect dispatch class, the failed command left
in the rerun cell, and obsolete currentness pin refusal. The actual GREEN
two-arm terminal states retain the original failure and successful full Anchor;
only the conflicting arm has a separate open policy-conflict row. These are
explicit TEST ONLY fixtures, not actor results. [S1–S5]

The reviewer ran no source suite, actor, controller/currentness helper or
provider call. Complete byte/AST checks and the retained meaningful controls
resolved the concrete risks; repeating those suites adds no actual episode.
The old mailbox receiver was not exercised. Its pure predicate was checked by
the author, while the admitted ordinary path uses the actual local record
methods. This review does not admit the dormant legacy host/mailbox flow. [S2; S4]

### 4. Capture ownership and truthful host observations

Root is actual governor, command initiator, capture custodian and separate
receiving decision-maker. Each fresh actor is a data-return planner, continued
in the same task after the successful check. A final independent episode reader
receives the resulting evidence; none gains Root's currentness or lifecycle
authority. [S6–S8]

The primitive captures commands routed through `run` by default: exact argv/cwd,
times, exit/expectation, terminal process evidence and complete separate streams.
It is not an automatic recorder of every actor tool action. Root must preserve
the actual collaboration invocations/results, routed final messages and relevant
actor-owned tool results. A targeted inspection of exposed tool metadata found
no separate agent-transcript/native-observer export; no such export is assumed.
This limits automatic capture, not the ordinary host's ability to run P03.

The existing opaque HostObservation reference accepts typed actual task/operation
references and actor-owned exec chunks. Derived task/stage/content references
must be labeled derived. Root's artifact read remains a Root observation. An
actor final message saved verbatim by Root is a Root-captured copy of an actual
actor return, not an actor-written file. Empty continuation results remain empty;
a lossless Root-authored envelope supplies no acknowledgment. Unavailable tool
results cannot be reconstructed from a summary or artifact hash. [S8]

The capture map specifies eight artifacts and six before/after boundaries per
arm. Dedicated files are honestly absent initially; Root documents remain
separate. Every boundary requires a fresh read and complete retained bytes,
including the failed-row preimage before resolution. Root reports the mapped
STATE/ROADMAP paths remain current. [S7]

**Operational clarification:** freeze the digest-pinned assigned-input manifest
with future message/result/return fields truthfully null. Construct the full
message afterwards; retain its byte interval, actual invocation/result and actor
return in a separate immutable delivery receipt/envelope. Do not back-fill the
manifest already named by digest, place its own digest inside itself, or make
it depend recursively on the full message containing its digest. The existing
nullable template fields and separate envelope support this order without a
source/prompt/oracle/scenario change. [S6–S8]

### 5. Actual reviewer artifact and authority boundary

`PACKAGE_REVIEW.json` is this reviewer's authentic six-field judgment for the
verified ordinary governor inventory. It contains the adapter's accepted
constants and is distinct from source-author fixtures and Root's later
PackageReceiving. Root must consume the real artifact and independently record
that receiving; no observation IDs or Root records are invented here.

This is an ordinary independent review, not a formal internal audit-assess
route. The audit-assess skill was inspected for role boundaries; no resolver or
route-envelope admission is claimed. The absence of such a formal route is not
a new gate for this commissioned ordinary review. The prior R4 scope record is
partial; I claim no continuity of its reviewer identity.

No concrete source blocker remains. Wrong actor answers, refusals, nonverdicts,
missing captures or actual helper failures must be retained if they occur;
do not rewrite the prompt or rerun an actor to obtain the expected result.

## Evidence and next step

Execute `NEXT_EPISODE.md` using actual Root/actor evidence, then obtain a distinct
independent episode return and separate Root acceptance decision. No source-only
or adapter-test award can substitute.

Packet base P: `/workspace/scratch/2678f1e431c3/dg17-p03-prospective-r4-20261119`.
Repository base R: `/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b`.

- E1: this directory's verifier, full input verification and exact tool capture.
- S1: P/root_callsite.py, especially `package_identity`, `scenario`,
  `capture_record`, `actual_decision`, `require_currentness`, `admit`.
- S2: P/source/hosted_phase.py and immutable originals under P/inputs.
- S3: P/source/transport_primitives.py and contracts/ROOT_CURRENTNESS_INTERFACE.json.
- S4: P/tests/test_focused.py, tests/support.py, tests/run_focused.py;
  P/receipts/RED_TOOL_CAPTURE.json, GREEN_TOOL_CAPTURE.json and complete streams.
- S5: P/controls/green/sequence-arm-a and sequence-arm-b terminal STATE/events;
  retained scalar/terminal matrices and complete RED evidence.
- S6: P/RUN_INTERFACE.md, PRE_ACTOR_FREEZE.json, scenario freeze, exact common/
  post-check prompts, TASK and evaluator/ORACLE.json.
- S7: P/ROOT_CAPTURE_MAP.json and plan/ROOT_CAPTURE_PLAN.md.
- S8: P/plan/ACTOR_TRANSPORT_MESSAGE.template.txt, ACTOR_SUBMISSION_MANIFEST.template.json,
  HOST_CAPTURE_ENVELOPE.schema.json; inputs/review/R2_REPORT.md and
  HOST_OBSERVATION_REPRESENTATION.md.
- C1: R/handoff/pro-executor-results-20261115/fresh-original-operations-20261116/dg17/ISSUE211_CURRENT_TOOL_RESULT.json,
  `structuredContent.issue.body` (original P03, model-controls and terminal clauses).
- C2: R/handoff/pro-executor-results-20261115/continuing-execution-20261117/DG17_ORIGINAL36_CURRENT_DISPOSITION.json,
  P03 row; corroborated by docs/audits/archive/r0033-r0037-integration/R0037-ACCEPTANCE.md.
- C3: R/handoff/pro-executor-results-20261115/continuing-execution-20261117/live-execution/P03_INDEPENDENT_REVIEW.md
  and P03_ROOT_RECEIVING.json.

Terminal disposition: **PASS — bounded source/pre-actor preparation; actual
original-P03 episode and independent receiving remain required.**
