#!/usr/bin/env python3
"""Receive only results15 V2 additions and verify earlier frozen bytes unchanged."""
from pathlib import Path, PurePosixPath
import base64, hashlib, json, stat, sys

S=Path('/workspace/scratch/530bc07ea12b/continuation-results15')
R=Path('/workspace/scratch/530bc07ea12b/results15-independent-review')
O=R/'delta-v2'
PRIVATE=Path('/workspace/scratch/2678f1e431c3/g132-private-recovered-inputs-20261119')
EXPECTED='93c277ae7ab5ec8277fb7ea6393de4d1aa28752a7c515e77592e346aab9dcb60'
checks=[]
def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def ck(name,condition,details=None): checks.append({'check':name,'pass':bool(condition),'details':details})
def readj(p): return json.loads(p.read_bytes())
v1=readj(R/'INPUT_STAGE_MANIFEST.json'); raw=(S/'STAGE_MANIFEST_V2.json').read_bytes(); v2=json.loads(raw)
ck('V2_frozen_identity',sha(raw)==EXPECTED)
ck('V1_manifest_unchanged',(S/'STAGE_MANIFEST.json').read_bytes()==(R/'INPUT_STAGE_MANIFEST.json').read_bytes())
old={r['path']:r for r in v1['files']}; new={r['path']:r for r in v2['files']}
ck('V1_all_21_descriptors_unchanged',all(new.get(p)==v for p,v in old.items()) and len(old)==21)
expected_added={'PUBLICATION_ADDENDUM.json','additional-n06-receiving/SOURCE_IDENTITIES.json','additional-n06-receiving/DG17_REVIEW.md','additional-n06-receiving/DG17_DISPOSITION.json','additional-n06-receiving/N06_R1_ADDENDUM_REVIEW.md','additional-n06-receiving/N06_R1_ADDENDUM_DISPOSITION.json','additional-n06-receiving/N06_R1_ADDENDUM_REVIEW_MANIFEST.json'}
added=set(new)-set(old)-{'STAGE_MANIFEST.json'}
ck('exact_seven_additions',added==expected_added,sorted(added))
population={str(p.relative_to(S)) for p in S.rglob('*') if p.is_file() or p.is_symlink()}
ck('complete_stage_population',population==set(new)|{'STAGE_MANIFEST_V2.json'} and len(new)==len(v2['files'])==29)
ck('stage_total_bytes',sum(r['bytes'] for r in new.values())==v2['bytes']==2224267)
file_results=[]
for name,r in sorted(new.items()):
    p=S/name; data=p.read_bytes(); safe=not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
    matched=safe and p.is_file() and not p.is_symlink() and len(data)==r['bytes'] and sha(data)==r['sha256'] and blob(data)==r['git_blob_sha'] and r['mode']=='100644' and stat.S_IMODE(p.stat().st_mode)==0o644
    ck('stage_file:'+name,matched)
    file_results.append({'path':name,'sha256':sha(data),'bytes':len(data),'unchanged_prior_member':name in old or name=='STAGE_MANIFEST.json','pass':matched})
ck('scope_identity_unchanged',all(v2[k]==v1[k] for k in ['base_commit','base_tree','destination_prefix','new_complete_original_awards','ordinary_additive_evidence_only','private_original_inputs_included','active_new_probe_and_G2_candidate_excluded']))
ck('V2_explicit_succession',v2['supersedes_stage_manifest_sha256']==sha((R/'INPUT_STAGE_MANIFEST.json').read_bytes()) and v2['self_excluded']=='STAGE_MANIFEST_V2.json')
ident=readj(S/'additional-n06-receiving/SOURCE_IDENTITIES.json')
ck('source_identity_record_exact',(S/'additional-n06-receiving/SOURCE_IDENTITIES.json').read_bytes()==(R/'EXTERNAL_N06_REVIEW_IDENTITIES.json').read_bytes())
ck('five_original_review_bodies',len(ident['files'])==5 and sum(r['bytes'] for r in ident['files'])==20034)
for r in ident['files']:
    source=Path(r['path']); dest=S/'additional-n06-receiving'/source.name; data=dest.read_bytes()
    ck('source_body:'+source.name,len(data)==r['bytes'] and sha(data)==r['sha256'] and data==source.read_bytes() and stat.S_IMODE(source.stat().st_mode)==stat.S_IMODE(dest.stat().st_mode))
review_manifest=readj(S/'additional-n06-receiving/N06_R1_ADDENDUM_REVIEW_MANIFEST.json')
ck('N06_addendum_review_manifest_exact',len(review_manifest['files'])==2 and all(len((S/'additional-n06-receiving'/r['path']).read_bytes())==r['bytes'] and sha((S/'additional-n06-receiving'/r['path']).read_bytes())==r['sha256'] for r in review_manifest['files']))
dg=readj(S/'additional-n06-receiving/DG17_DISPOSITION.json'); ad=readj(S/'additional-n06-receiving/N06_R1_ADDENDUM_DISPOSITION.json')
ck('helper_source_scope_only',dg['source_disposition']=='READY_FOR_GENUINE_FIRST_L1_PREPARATION_AND_MATERIALIZATION' and all(dg[k] is False for k in ['actual_actor_dispatched','original_M01_awarded','original_N06_awarded','source_or_helper_executed_by_reviewer']))
ck('declaration_scope_only',ad['disposition']=='N06_R1_SATISFIED_AT_DECLARATION_SCOPE' and not ad['original_acceptance'] and not ad['actor_dispatch_performed'] and ad['all_outcomes_unexecuted'] and ad['authority']=='NONE')
prior_members=readj(R/'VERIFIED_ARCHIVE_MEMBERS.json'); previous={r['path']:r for r in prior_members if r['archive']=='archives/n06-actual-first-l1.tar.xz'}
for key,path in [('successor_manifest_sha256','dg17-interrupt-successor-20261119/MANIFEST.json'),('successor_seal_sha256','dg17-interrupt-successor-20261119/SEAL.json'),('repair_manifest_sha256','dg17-n06-binding-repair/REPAIR_MANIFEST.json'),('repaired_helper_sha256','dg17-n06-binding-repair/materialize_delivery.py')]:
    ck('helper_prior_evidence_binding:'+key,dg[key]==previous[path]['sha256'])
for key,path in [('manifest_sha256','dg17-n06-control-declarations/MANIFEST.json'),('declaration_sha256','dg17-n06-control-declarations/ANTI_GAMING_CONTROLS.json')]:
    ck('declaration_prior_evidence_binding:'+key,ad[key]==previous[path]['sha256'])
addendum=readj(S/'PUBLICATION_ADDENDUM.json')
ck('publication_addendum_exact_scope',addendum['new_original_awards']==[] and addendum['source_bytes']==20034 and addendum['original_stage_sha256']==sha((R/'INPUT_STAGE_MANIFEST.json').read_bytes()) and '92 payloads plus DELIVERY_CONTENTS.json' in addendum['n06_delivery_distinction'] and 'third derivative raw manifest difference' in addendum['n06_delivery_distinction'])
# Preserve the original independent report and every sealed original review file.
prior_seal=readj(R/'MANIFEST.json')
ck('prior_review_manifest_identity',sha((R/'MANIFEST.json').read_bytes())=='164d25ebf699e0d84ff702740c0c7e4f74ccbd05e54e12a02bb7631a040600dc')
ck('prior_review_all_sealed_files_unchanged',all(len((R/r['path']).read_bytes())==r['bytes'] and sha((R/r['path']).read_bytes())==r['sha256'] and stat.S_IMODE((R/r['path']).stat().st_mode)==int(r['mode'],8) for r in prior_seal['files']))
# Earlier private-body exclusion is carried by unchanged original bytes; scan only additions.
private=readj(R/'INTEGRITY_RESULT.json')['private_availability']; hits=[]
objects={name:(S/name).read_bytes() for name in added}; objects['STAGE_MANIFEST_V2.json']=raw
for r in private:
    data=(PRIVATE/r['path']).read_bytes(); ck('private_scan_input_identity:'+r['path'],len(data)==r['bytes'] and sha(data)==r['sha256'])
    variants={'raw':data,'base64':base64.b64encode(data)}
    text=data.decode('utf-8'); variants['json_escaped']=json.dumps(text,ensure_ascii=False)[1:-1].encode(); variants['json_canonical']=json.dumps(json.loads(data),sort_keys=True,separators=(',',':')).encode()
    for name,body in objects.items():
        for form,needle in variants.items():
            if needle and needle in body: hits.append({'published_member':name,'private_path':r['path'],'form':form})
ck('new_files_contain_no_private_original_bodies',not hits,hits)
result={'schema':'results15-independent-V2-delta-receiving.v1','stage_manifest_sha256':EXPECTED,'prior_stage_manifest_sha256':sha((R/'INPUT_STAGE_MANIFEST.json').read_bytes()),'checks':checks,'check_count':len(checks),'failed':[r for r in checks if not r['pass']],'pass':all(r['pass'] for r in checks),'stage_files':29,'stage_bytes':2224267,'added_files':7,'added_bytes':sum(new[n]['bytes'] for n in added),'source_review_files':5,'source_review_bytes':20034,'original_stage_members_unchanged':21,'original_stage_manifest_unchanged':True,'prior_review_seal_unchanged':True,'files':file_results,'private_new_objects_scanned':len(objects),'private_body_matches':hits,'new_original_awards':[],'actor_test_build_native_provider_controller_or_source_effects':0}
(O/'VERIFICATION.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
(O/'INPUT_STAGE_MANIFEST_V2.json').write_bytes(raw)
print(json.dumps({k:v for k,v in result.items() if k not in ['checks','files']},indent=2,sort_keys=True))
sys.exit(0 if result['pass'] else 1)
