#!/usr/bin/env python3
"""Verify selected publication claim bindings without executing subject source."""
from pathlib import Path
import ast, hashlib, io, json, tarfile, zipfile, sys

P=Path('/workspace/scratch/530bc07ea12b/continuation-results15')
O=Path('/workspace/scratch/530bc07ea12b/results15-independent-review')
checks=[]
def sha(b): return hashlib.sha256(b).hexdigest()
def ck(name,passed,evidence,details=None): checks.append({'check':name,'pass':bool(passed),'evidence':evidence,'details':details})
archives={}
for p in (P/'archives').glob('*.tar.xz'):
    with tarfile.open(p,'r:xz') as t: archives[p.name]={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
def b(archive,name): return archives[archive][name]
def j(archive,name): return json.loads(b(archive,name))
stage=(P/'STAGE_MANIFEST.json').read_bytes()
ck('input_stage_exact',sha(stage)=='0a5faf8dad555cad25e7e7eb982bdc0d7fae3d67a44c598b12f79636701cf6d0','STAGE_MANIFEST.json')
(O/'INPUT_STAGE_MANIFEST.json').write_bytes(stage)
source_bodies={}
for archive,members in archives.items():
    am=json.loads(members['ARCHIVE_MANIFEST.json'])
    for path,body in members.items():
        for s in am['sources']:
            if path.startswith(s['archive_prefix']+'/'):
                source_bodies[s['original_root']+'/'+path[len(s['archive_prefix'])+1:]]=body

# P03 original seal and independent outcome remain distinct from case qualification.
a='p03-original-episode.tar.xz'; e='p03-episode-receiving/EPISODE_MANIFEST.json'; m=j(a,e)
ck('P03_original_seal_identity',sha(b(a,e))=='e986c73611a5f4c6478db30ef5b8539596ac2b5ad5d6605a34cec0835a011119',e)
ck('P03_all_353_original_bodies',len(m['files'])==353 and sum(x['bytes'] for x in m['files'])==847577 and all(x['path'] in source_bodies and len(source_bodies[x['path']])==x['bytes'] and sha(source_bodies[x['path']])==x['sha256'] for x in m['files']),e)
r=j(a,'dg17-p03-episode-independent-review/RESULT.json')
ck('P03_behavior_pass_case_gap',r['original_P03_behavioral_conjunction']=='PASS' and r['fully_qualified_original_model_policy_P03_case']=='GAP' and not r['original_case_award_issued'],'dg17-p03-episode-independent-review/RESULT.json')
ck('P03_original_review_hash',sha(b(a,'dg17-p03-episode-independent-review/REPORT.md'))=='80ee8c93ff69cc34232b99a189590c2102c4ad3eefc94b79fe7067d53a4c2d41','dg17-p03-episode-independent-review/REPORT.md')
a='p03-record-correction.tar.xz'; r=j(a,'dg17-p03-correction-independent-review/RESULT.json')
ck('P03_F1_F2_new_scope_closed_F3_open',r['F1_current_corrective_record']=='CLOSED' and r['F2_current_corrective_record']=='CLOSED' and r['F3_model_metadata_qualification']=='OPEN' and not r['original_case_award_issued'] and not r['historical_F1_rewritten'],'dg17-p03-correction-independent-review/RESULT.json')
ck('P03_correction_review_hashes',sha(b(a,'dg17-p03-correction-independent-review/REPORT.md'))=='974e2ef1d2262ae85aea093c5c607cf3e970b96ebb530cae0e5a5b05fc19c514' and sha(b(a,'dg17-p03-correction-independent-review/MANIFEST.json'))=='277f90c26a26d072ca1ff5111284b5db88926de45eff9321ba664be5a9446f4d','dg17-p03-correction-independent-review/{REPORT.md,MANIFEST.json}')
for a,root in [('p03-original-episode.tar.xz','dg17-p03-episode-independent-review'),('p03-record-correction.tar.xz','dg17-p03-correction-independent-review')]:
    mm=j(a,root+'/MANIFEST.json')
    ck(root+'_seal_all_files',all(x['path'] in source_bodies and len(source_bodies[x['path']])==x['bytes'] and sha(source_bodies[x['path']])==x['sha256'] for x in mm['files']),root+'/MANIFEST.json')

# Both nested hosted artifact ZIPs: exact contents, CRC and retained extraction parity.
for a,root,zipname,expected_count,expected_sha in [
('g2-real-hosted-consumer.tar.xz','G2_R2_RUN_44637664299','g2-r2-44637664299-1.zip',48,'4c568d2a93b1a7b66562dd59095f0382f226cda0f024bd90b419441678e16137'),
('g2-current-host-facts.tar.xz','g2-host-inventory-actual-receiving','g2-host-facts-44641408350-1.zip',1,'658c0031c816559137315fd5d322f13887253f9c2aa2d86c6deac6438ff85f1c')]:
    data=b(a,root+'/'+zipname)
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names=z.namelist()
        ck(zipname+'_outer_identity',sha(data)==expected_sha,root+'/'+zipname)
        ck(zipname+'_unique_complete_crc',len(names)==len(set(names))==expected_count and z.testzip() is None,root+'/'+zipname)
        if 'MANIFEST.json' in names:
            mm=json.loads(z.read('MANIFEST.json'))
            ck(zipname+'_manifest_members',set(names)=={r['path'] for r in mm['members']}|{'MANIFEST.json'} and all(len(z.read(r['path']))==r['bytes'] and sha(z.read(r['path']))==r['sha256'] for r in mm['members']),root+'/'+zipname)
            ck(zipname+'_retained_extraction',all(z.read(n)==b(a,root+'/artifact/'+n) for n in names),root+'/artifact')
        else: ck(zipname+'_retained_extraction',names==['HOST_FACTS.json'] and z.read(names[0])==b(a,root+'/HOST_FACTS.json'),root+'/HOST_FACTS.json')
a='g2-real-hosted-consumer.tar.xz'; r=j(a,'G2_R2_RUN_44637664299/artifact/RESULT.json')
ck('G2_synthetic_ten_control_scope',r['suite_outcome']=='success' and len(r['cases'])==10 and sum(x['accepted'] for x in r['cases'])==1 and all(not r[k] for k in ['M2','full_G2','full_pair_executed','original_acceptance','original_control_replayed','protected_G132_effect','provider_write_by_test']) and r['scope']=='SYNTHETIC_NON_ACCEPTANCE_FULL_CONSUMER_ROUTE','G2_R2_RUN_44637664299/artifact/RESULT.json')
ck('G2_old_failure_preserved',b'FAILED before runner assignment' in b(a,'G2_FAILURE_44636484713/REVIEW.md') and b'44636484713' in b(a,'G2_FAILURE_44636484713/REVIEW.md'),'G2_FAILURE_44636484713/REVIEW.md')
a='g2-current-host-facts.tar.xz'; r=j(a,'g2-host-inventory-actual-receiving/HOST_FACTS.json')
ck('G2_inventory_preprovision_only',r['run_id']=='44641408350' and r['workflow_commit']=='90fa005389b5e3872d002cbabca8fdd44c1711e0' and r['no_test_pair_or_native_bank'] and all(not r[k] for k in ['M2','full_G2','original_acceptance','qualification_or_post_provision_match']),'g2-host-inventory-actual-receiving/HOST_FACTS.json')
ck('G2_inventory_python_four_tools',r['host']['python_version']==[3,14,4] and len(r['host']['tools'])==4 and all(v['available'] and v['root_owned_nonwritable_chain'] for v in r['host']['tools'].values()),'g2-host-inventory-actual-receiving/HOST_FACTS.json')

# N06: capture and materializations are actual, actor outcome remains unissued.
a='n06-actual-first-l1.tar.xz'; r=j(a,'dg17-n06-actual/l1-command/COMMAND.json')
ck('N06_actual_failure_16_unchanged',r['exit_code']==1 and r['source_observation']=='COMPARISON_FAILED' and r['before']==r['after'] and len(r['before'])==16 and all(len(b(a,'dg17-report-task-03b6/'+n))==v['bytes'] and sha(b(a,'dg17-report-task-03b6/'+n))==v['sha256'] for n,v in r['before'].items()),'dg17-n06-actual/l1-command/COMMAND.json')
for stream in ['stdout','stderr']:
    ck('N06_'+stream+'_exact',len(b(a,'dg17-n06-actual/l1-command/'+stream+'.txt'))==r[stream]['bytes'] and sha(b(a,'dg17-n06-actual/l1-command/'+stream+'.txt'))==r[stream]['sha256'],'dg17-n06-actual/l1-command/'+stream+'.txt')
d1={n[len('inputs-c3a8/'):]:v for n,v in archives[a].items() if n.startswith('inputs-c3a8/')}
d2={n[len('inputs-f7b2/'):]:v for n,v in archives[a].items() if n.startswith('inputs-f7b2/')}
diff=sorted(n for n in set(d1)|set(d2) if d1.get(n)!=d2.get(n))
payload_diff=[n for n in diff if n!='DELIVERY_CONTENTS.json']
dm1=json.loads(d1['DELIVERY_CONTENTS.json']); dm2=json.loads(d2['DELIVERY_CONTENTS.json'])
manifest_metadata_equal={k:v for k,v in dm1.items() if k!='files'}=={k:v for k,v in dm2.items() if k!='files'}
delivery_manifests_valid=all(len(dm['files'])==92 and {x['path'] for x in dm['files']}==set(delivery)-{'DELIVERY_CONTENTS.json'} and all(len(delivery[x['path']])==x['bytes'] and sha(delivery[x['path']])==x['sha256'] for x in dm['files']) for delivery,dm in [(d1,dm1),(d2,dm2)])
ck('N06_two_matched_93_file_deliveries',len(d1)==len(d2)==93 and payload_diff==['POLICY_CONTENTS.json','policy/skills/implementaudit/templates/PROTOCOL.md'] and manifest_metadata_equal and delivery_manifests_valid,'inputs-c3a8/, inputs-f7b2/',{'all_raw_differences':diff,'payload_differences':payload_diff,'self_manifest_difference_is_derivative':True})
ck('N06_no_actor_result_claim',j(a,'dg17-n06-actual/MATCHED_DELIVERY_VERIFICATION.json')['actor_calls_issued'] is False,'dg17-n06-actual/MATCHED_DELIVERY_VERIFICATION.json')

# DG18 retained executable equivalence and exact provider-cutoff status.
a='dg18-source-and-reserve-repair.tar.xz'
class StripDocstrings(ast.NodeTransformer):
    def visit_Module(self,node): return self.strip(node)
    def visit_FunctionDef(self,node): return self.strip(node)
    def visit_AsyncFunctionDef(self,node): return self.strip(node)
    def visit_ClassDef(self,node): return self.strip(node)
    def strip(self,node):
        self.generic_visit(node)
        if node.body and isinstance(node.body[0],ast.Expr) and isinstance(node.body[0].value,ast.Constant) and isinstance(node.body[0].value.value,str): node.body=node.body[1:]
        return node
trees=[ast.dump(StripDocstrings().visit(ast.parse(b(a,'dg18-package-reserve-repair/read-canonical-pair.'+which+'.py'))),include_attributes=False) for which in ['before','after']]
ck('DG18_executable_AST_equal',trees[0]==trees[1],'dg18-package-reserve-repair/read-canonical-pair.{before,after}.py')
r=j(a,'dg18-package-reserve-repair/SOURCE_CHECK.json')
ck('DG18_actual_first_shortfall',r['original_failure']=={'run':44637807032,'artifact_bytes':588597,'cap':589824,'required_reserve':1240,'actual_reserve':1227} and not r['cap_or_reserve_changed'],'dg18-package-reserve-repair/SOURCE_CHECK.json')
ck('DG18_actual_build_completed',j(a,'dg18-package-reserve-repair/PINNED_BUILD_TOOL_RETURN.json')['completion']['value']['exit_code']==0,'dg18-package-reserve-repair/PINNED_BUILD_TOOL_RETURN.json')
provider=json.loads((P/'PROVIDER_STATUS_AT_CUTOFF.json').read_bytes())
jobs=json.loads(provider['ci_jobs']['value']['structuredContent']['content'])['jobs']
pr=provider['pr']['value']['structuredContent']
ck('DG18_latest_CI_unfinished_at_cutoff',len(jobs)==1 and jobs[0]['run_id']==44641197003 and jobs[0]['status']=='in_progress' and jobs[0]['conclusion'] is None,'PROVIDER_STATUS_AT_CUTOFF.json')
ck('PR255_open_draft_unmerged_14ed',pr['number']==255 and pr['state']=='open' and pr['draft'] and pr['merged'] is False and pr['head_sha']=='14ed4c7179d477d90882ebf5c5031692056e5491','PROVIDER_STATUS_AT_CUTOFF.json')

# G132 reviewed limits and disclosed inherited-mode discrepancy.
a='g132-repaired-current-interfaces.tar.xz'; r=j(a,'g132-current-interface-independent-review/RESULT.json')
ck('G132_two_source_scopes_only',r['disposition']=='PASS_AT_TWO_STATED_SOURCE_COMPOSITION_SCOPES' and r['original_awards']==[] and not r['whole_DG16_or_G132_award'] and r['complete_operational_receiving']=='NOT_ESTABLISHED' and r['genuine_post_sender_binary_preparation']=='UNEXECUTED','g132-current-interface-independent-review/RESULT.json')
v=j(a,'g132-execution-readiness/VERIFICATION.json')
ck('G132_ten_controls_test_only',v['classification']=='TEST_ONLY_SOURCE_AND_DATA' and v['controls']['passed']==10 and v['controls']['exit_code']==0 and v['original_sender_executions']==v['provider_calls']==0 and v['original_awards']==[],'g132-execution-readiness/VERIFICATION.json')
ck('G132_new_source_pin',len(b(a,'g132-execution-readiness/current_interfaces.py'))==19976 and sha(b(a,'g132-execution-readiness/current_interfaces.py'))=='2f5fdf5021df1db83320d286828898cfdbaaebe13e41acc7716329306f1fbe06','g132-execution-readiness/current_interfaces.py')
mode=j(a,'g132-current-interface-independent-review/CUSTODY_FINDING.json')
ck('G132_three_inactive_mode_gaps_disclosed',len(mode['rows'])==3 and all(x['declared_mode']=='0400' and x['actual_mode']=='0444' and x['selected_new_runtime_input'] is False and x['state']=='UNISSUED' for x in mode['rows']),'g132-current-interface-independent-review/CUSTODY_FINDING.json')
ck('G132_active_followup_excluded',not any('followup-native-probe/' in n for n in archives[a]),'g132-repaired-current-interfaces.tar.xz: member population')
rec=j('root-reconciliation-receipts.tar.xz','receiving/REMOTE_RECONCILIATION.json')
ck('recovery_exact_61_scoped_404',rec['known_chunk_probe_count']==len(rec['known_chunk_probe_results'])==61 and all(x['isError'] and '404' in x['error'] for x in rec['known_chunk_probe_results']),'receiving/REMOTE_RECONCILIATION.json')
ck('recovery_unknown_and_prior_blob_preserved',rec['protected_unknown']=='301aeecde08ba6f169bc3cd837eae6f6ad068219 UNKNOWN_NO_REPLAY' and rec['already_succeeded_blob']=='ebaaa18fb0b6b88b5a7ef18c6034a582e176f022','receiving/REMOTE_RECONCILIATION.json')
readme=(P/'README.md').read_text()
ck('README_N1_native_amendments_preserved',all(x in readme for x in ['N1 is LOST/UNKNOWN and mandatory; no exception','applicable genuine-host conditions','DG18 14 criteria plus binding amendments','UNKNOWN_NO_REPLAY','Full P03 model-case qualification remains open on F3']), 'README.md')
result={'schema':'results15-independent-publication-claim-bindings.v1','stage_manifest_sha256':sha(stage),'checks':checks,'check_count':len(checks),'failed':[x for x in checks if not x['pass']],'pass':all(x['pass'] for x in checks),'execution':'Read-only parsing/hash/AST comparisons only; no original actors, tests, builds, native probes or provider calls.'}
(O/'CLAIM_CHECKS_RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'check_count':result['check_count'],'failed':result['failed'],'pass':result['pass'],'stage_manifest_sha256':sha(stage)},indent=2))
sys.exit(0 if result['pass'] else 1)
