#!/usr/bin/env python3
"""Read-only independent verification of the frozen results15 publication."""
from pathlib import Path, PurePosixPath
from collections import Counter
import base64, hashlib, io, json, stat, sys, tarfile, zipfile

STAGE = Path('/workspace/scratch/530bc07ea12b/continuation-results15')
OUT = Path('/workspace/scratch/530bc07ea12b/results15-independent-review')
PRIVATE = Path('/workspace/scratch/2678f1e431c3/g132-private-recovered-inputs-20261119')
EXPECTED_STAGE = '0a5faf8dad555cad25e7e7eb982bdc0d7fae3d67a44c598b12f79636701cf6d0'
OUT.mkdir(parents=True, exist_ok=True)
errors, inventory, archive_results, private_hits = [], [], [], []
scan_count = 0
def sha(data): return hashlib.sha256(data).hexdigest()
def blob(data): return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def check(condition, label, details=None):
    if not condition: errors.append({'check':label, 'details':details})
def load(path): return json.loads(path.read_bytes())
def safe(name):
    p=PurePosixPath(name)
    return bool(name) and not p.is_absolute() and '..' not in p.parts and str(p)==name

stage_data=(STAGE/'STAGE_MANIFEST.json').read_bytes()
manifest=json.loads(stage_data)
check(sha(stage_data)==EXPECTED_STAGE, 'frozen_stage_sha256')
declared={x['path']:x for x in manifest['files']}
check(len(declared)==len(manifest['files'])==21, 'stage_unique_file_count')
actual={str(x.relative_to(STAGE)) for x in STAGE.rglob('*') if x.is_file() or x.is_symlink()}
check(actual==set(declared)|{'STAGE_MANIFEST.json'}, 'stage_complete_membership', sorted(actual ^ (set(declared)|{'STAGE_MANIFEST.json'})))
for name, record in declared.items():
    p=STAGE/name; data=p.read_bytes()
    check(safe(name) and p.is_file() and not p.is_symlink(), 'stage_regular_safe_path',name)
    check(len(data)==record['bytes'] and sha(data)==record['sha256'] and blob(data)==record['git_blob_sha'], 'stage_bytes_sha256_git_blob',name)
    check(record['mode']=='100644' and stat.S_IMODE(p.stat().st_mode)==0o644, 'stage_mode', name)
check(sum(x['bytes'] for x in declared.values())==manifest['bytes']==2196221, 'stage_total_bytes')
index=load(STAGE/'PUBLICATION_INDEX.json')
descriptors=(load(STAGE/'COMPLETED_ARCHIVES.json')['archives']+
             load(STAGE/'ADDITIONAL_COMPLETED_ARCHIVES.json')['archives']+
             [load(STAGE/'G132_REPAIR_COMPLETED_ARCHIVE.json')])
by_archive={x['archive']:x for x in descriptors}
check(len(by_archive)==len(descriptors)==index['archive_count']==9, 'nine_archive_descriptors')
for record in index['archives']:
    check(record=={k:v for k,v in by_archive[record['archive']].items() if k in record}, 'index_descriptor_agreement', record['archive'])
check(sum(x['compressed_bytes'] for x in descriptors)==index['archive_compressed_bytes']==2102932, 'compressed_total')
with tarfile.open(STAGE/'archives/root-reconciliation-receipts.tar.xz','r:xz') as tf:
    receipt=json.load(tf.extractfile('receiving/G132_ELEVEN_INPUTS_VERIFIED.json'))
private_records, private_patterns = [], []
for r in receipt['rows']:
    data=(PRIVATE/r['path']).read_bytes()
    expected=r['expected']
    check(len(data)==expected['bytes'] and sha(data)==expected['sha256'] and r['actual']==expected and r['equal'] is True, 'private_availability_receipt',r['path'])
    private_records.append({'path':r['path'],'bytes':len(data),'sha256':sha(data),'verified':True})
    variants={'raw':data,'base64':base64.b64encode(data)}
    try:
        text=data.decode('utf-8')
        variants['json_escaped']=json.dumps(text,ensure_ascii=False)[1:-1].encode()
        variants['json_canonical']=json.dumps(json.loads(data),sort_keys=True,separators=(',',':')).encode()
    except (UnicodeDecodeError,ValueError): pass
    private_patterns.append((r['path'],variants))
check(len(private_records)==receipt['count']==11 and sum(x['bytes'] for x in private_records)==receipt['bytes']==647343, 'private_availability_count_bytes')
def scan(name,data,depth=0):
    global scan_count
    scan_count+=1
    for private_name,variants in private_patterns:
        for encoding,needle in variants.items():
            if needle and needle in data:
                private_hits.append({'published_member':name,'private_path':private_name,'form':encoding})
    if depth>=6: return
    if data.startswith(b'PK\x03\x04') and zipfile.is_zipfile(io.BytesIO(data)):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for zinfo in z.infolist():
                if not zinfo.is_dir(): scan(name+'!'+zinfo.filename,z.read(zinfo),depth+1)
    elif data.startswith(b'\xfd7zXZ\x00') or data.startswith(b'\x1f\x8b'):
        try:
            with tarfile.open(fileobj=io.BytesIO(data),mode='r:*') as nested:
                for member in nested.getmembers():
                    if member.isfile(): scan(name+'!'+member.name,nested.extractfile(member).read(),depth+1)
        except tarfile.ReadError: pass

for name in sorted(actual):
    if not name.startswith('archives/'): scan(name,(STAGE/name).read_bytes())
for name, descriptor in by_archive.items():
    error_start=len(errors); data=(STAGE/name).read_bytes()
    check(len(data)==descriptor['compressed_bytes'] and sha(data)==descriptor['sha256'], 'archive_outer_digest',name)
    with tarfile.open(fileobj=io.BytesIO(data),mode='r:xz') as tf:
        members=tf.getmembers(); member_names=[m.name for m in members]
        check(len(member_names)==len(set(member_names)), 'archive_unique_members',name)
        check(all(m.isfile() and safe(m.name) for m in members), 'archive_regular_safe_members',name)
        am_bytes=tf.extractfile('ARCHIVE_MANIFEST.json').read(); am=json.loads(am_bytes)
        check(sha(am_bytes)==descriptor['manifest_sha256'], 'archive_manifest_digest',name)
        check(tf.getmember('ARCHIVE_MANIFEST.json').mode==0o644, 'archive_manifest_mode',name)
        declared_members={m['path']:m for m in am['members']}
        check(len(declared_members)==len(am['members'])==descriptor['source_files']==descriptor['verified_members'], 'archive_declared_file_count',name)
        check(set(member_names)==set(declared_members)|{'ARCHIVE_MANIFEST.json'}, 'archive_complete_inner_membership',name)
        check(sum(m['bytes'] for m in am['members'])==descriptor['source_bytes'], 'archive_uncompressed_total',name)
        check(am['new_original_award'] is False and am['private_source_input_bodies'] is False, 'archive_scope_flags',name)
        if 'sources' in descriptor: check(am['sources']==descriptor['sources'], 'archive_source_map_matches_descriptor',name)
        excluded=am.get('excluded_files',[])
        if 'excluded' in descriptor: check(excluded==descriptor['excluded'], 'archive_exclusion_descriptor',name)
        check(not set(m['path'] for m in excluded)&set(declared_members), 'excluded_paths_absent',name)
        scan(name+'!ARCHIVE_MANIFEST.json',am_bytes)
        mode_counts=Counter()
        for path, expected in declared_members.items():
            member=tf.getmember(path); body=tf.extractfile(member).read(); digest=sha(body)
            matches=[s for s in am['sources'] if path.startswith(s['archive_prefix']+'/')]
            check(len(matches)==1,'unique_original_source_mapping',name+'!'+path)
            if len(matches)!=1: continue
            source=Path(matches[0]['original_root'])/path[len(matches[0]['archive_prefix'])+1:]
            check(not (source==PRIVATE or PRIVATE in source.parents),'private_source_root_excluded',name+'!'+path)
            check(member.size==expected['bytes']==len(body) and digest==expected['sha256'],'archive_body_matches_manifest',name+'!'+path)
            check(member.mode==int(expected['mode'],8),'archive_mode_matches_manifest',name+'!'+path)
            source_exists=source.is_file() and not source.is_symlink()
            check(source_exists,'original_source_exists_regular',str(source))
            source_equal=source_exists and source.read_bytes()==body
            source_mode=stat.S_IMODE(source.stat().st_mode) if source_exists else None
            check(source_equal,'archive_exact_source_bytes',name+'!'+path)
            check(source_mode==member.mode,'archive_exact_source_mode',name+'!'+path)
            mode_counts[oct(member.mode)]+=1
            inventory.append({'archive':name,'path':path,'bytes':len(body),'sha256':digest,'mode':oct(member.mode),'source':str(source),'source_bytes_equal':source_equal,'source_mode_equal':source_mode==member.mode})
            scan(name+'!'+path,body)
        archive_results.append({'archive':name,'file_count':len(declared_members),'bytes':sum(m['bytes'] for m in am['members']),'mode_counts':dict(mode_counts),'errors':len(errors)-error_start,'pass':len(errors)==error_start,'manifest_sha256':sha(am_bytes)})
check(not private_hits,'no_private_input_bodies_found',private_hits)
check(manifest['new_complete_original_awards']==index['new_complete_original_awards']==index['original_whole_cell_awards']==[], 'no_new_awards')
check(index['original_denominators']=={'DG16_milestones':6,'DG16_rows':48,'DG17_cases':36,'DG17_mutation_families':14,'DG17_terminal_clauses':17,'DG18_criteria':14},'original_denominators_preserved')
check(not any(index[k] for k in ['merge','release','protected_replay','private_original_input_bodies_included']), 'scope_no_merge_release_replay_private_bodies')
summary={'schema':'results15-independent-publication-integrity.v1','stage_manifest_sha256':sha(stage_data),'stage_selected_files':len(declared),'stage_selected_bytes':sum(x['bytes'] for x in declared.values()),'stage_manifest_self_excluded_delivery_file':True,'archives':archive_results,'archive_member_count':len(inventory),'archive_member_bytes':sum(x['bytes'] for x in inventory),'private_availability':private_records,'private_scan_objects':scan_count,'private_input_matches':private_hits,'private_scan_scope':'All top-level text and manifest, every tar member, and recursively recognized ZIP/tar compression members; full-body raw, Base64, JSON-escaped and canonical-form comparison. Private bodies are not emitted.','errors':errors,'pass':not errors,'no_actor_test_build_or_provider_operations':True}
(OUT/'INTEGRITY_RESULT.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
(OUT/'VERIFIED_ARCHIVE_MEMBERS.json').write_text(json.dumps(inventory,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['private_availability','private_scan_scope']},indent=2,sort_keys=True))
sys.exit(0 if not errors else 1)
