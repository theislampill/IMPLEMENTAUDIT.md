# Results15 independent cold publication review

**Disposition: GAP-REVISE for one small evidence-packaging omission.** All tested byte-integrity and substantive scope claims pass. The omitted final N06 receiving records exist and support the README; include their bounded evidence before this publication is treated as the durable record of that receiving. No actor, verifier, build, native probe or historical operation needs replay.

## Exact subject and authority

The reviewed frozen stage is `/workspace/scratch/530bc07ea12b/continuation-results15`, bound by `STAGE_MANIFEST.json` SHA-256 `0a5faf8dad555cad25e7e7eb982bdc0d7fae3d67a44c598b12f79636701cf6d0`. It declares 21 selected files / 2,196,221 bytes plus the self-excluded stage manifest. Its nine archives total 2,102,932 compressed bytes. Proposed destination: `handoff/pro-executor-results-20261115/continuing-execution-20261119-15/`, additive to commit `c3f86d95404f898d26c4be44f8fe23f59e4a0782`, tree `6bd94bded00eab125bbe0a1970e93891fe911af1`.

Reviewer: `/root/results15_cold_receiving`, with no authoring context and no provider, controller, integration, acceptance or closure authority. This review concerns ordinary evidence publication. It does not receive any new original case/cell, grant a protected operation, or certify future currentness. Root's current-head preflight, complete prior-leaf preservation check and provider readbacks remain Root's separately commissioned publication work.

## F1 — final N06 receiving bodies are outside this frozen publication

README section “DG17 N06/M01” says the evaluator declaration and materializer repair have independent scoped receiving. The archive retains the producer reports, actual L1 capture/admission and deliveries, but omits the later independent receiving bodies. The old binding-repair report correctly remains marked PARTIAL / independent review pending; the later evidence must accompany it to substantiate the current summary durably.

I followed the packet's explicit reference to `independent-engineering-review` and found the actual final records. The claim is truthful, with no invented success. `EXTERNAL_N06_REVIEW_IDENTITIES.json` binds five small files, totaling 20,034 bytes: `DG17_REVIEW.md`, `DG17_DISPOSITION.json`, and the N06-R1 addendum report, disposition and manifest. The source/helper disposition is READY for genuine first-L1 preparation/materialization. The addendum is satisfied at declaration/preparation scope only; actors and original N06/M01 acceptance remain unissued.

**Smallest correction:** add those final receiving bodies and their exact binding records to a clearly new selected evidence group; refresh the archive/index/stage descriptors. An explicit immutable already-published location containing the same exact bodies would also resolve the omission. Preserve every historical preparation record. This finding adds no acceptance condition or execution quota.

## Integrity and exclusion results

`INTEGRITY_RESULT.json` records a complete PASS:

- All 21 selected file sizes, SHA-256 values, Git blob IDs and physical modes match. Stage membership is exact, including its additional self-excluded manifest.
- All nine outer archive sizes/digests and manifest digests match the descriptors. Every tar member is a regular, safe, unique path; the complete member populations equal their manifests plus each archive manifest itself.
- All **6,167 archived source files / 50,690,393 bytes** match their declared sizes/digests, stored modes, exact mapped source bytes and actual source modes. All declared exclusions remain excluded.
- Both nested hosted ZIPs pass CRC, unique-member and exact retained-extraction checks. The G2 consumer ZIP has 48 members, including its 47-member payload manifest; the host-inventory ZIP contains the exact single host-facts member.
- All eleven actual private inputs independently match the availability receipt: **647,343 bytes**. No mapped source is beneath the private input root. Scanning 6,238 top-level, tar and recognized nested-archive objects found no complete private body in raw, Base64, JSON-escaped or canonical JSON form. Private bodies were read only for this bounded exclusion check and were not written or printed. This is an exact-body exclusion check, not a claim about every possible transformed encoding.

## Claim fidelity and preserved frontiers

`CLAIM_CHECKS_RESULT.json` records 38 passing focused checks. I also read the publication README/index, relevant source/episode/independent reports, cutoff provider records, reconciliation receipt and snapshot boundary statements.

| Scope | Received publication claim and limit |
|---|---|
| P03 | All 353 original sealed members / 847,577 bytes remain exact. Independent behavioral PASS is distinct from whole-case qualification. New F1/F2 corrective receiving is bounded to successor records; F3 effective model/version/configuration remains OPEN. No original award, actor replay or invented metadata follows. |
| G2 | Run 44637664299's ten controls and both retained hosted artifacts support the engineering result. Scope stays SYNTHETIC_NON_ACCEPTANCE. Run 44636484713's actual workflow-validation failure remains retained. Inventory 44641408350 is pre-provision only; the same-job native bank, original pair, live decisions/consumption and closing remain mandatory. Historical five-equality records do not award M2. |
| N06/M01 | The actual first-L1 verifier exits 1 with sixteen source files unchanged. Both deliveries have 93 files: 92 payloads and a self manifest. Payload differences are exactly the two declared policy files; `DELIVERY_CONTENTS.json` also differs derivatively to bind their hashes. The historical receipt's two-item list is a payload comparison, not literal equality of all other raw files. No actor or later L2/L3/L5 result is claimed. |
| DG18 | The first actual CI reserve failure is retained. Independent AST parsing confirms the later reader repair changes no executable AST after docstrings are removed. Retained build completion and artifact receiving support the unchanged cap/reserve arithmetic. CI 44641197003 is in progress with null conclusion at the saved cutoff, and PR255 is open/draft/unmerged at 14ed4c7…; no later CI success is claimed. |
| G132 | The current interface pin and ten TEST_ONLY controls support only the two reviewed source-composition scopes. Genuine sender, live callbacks, hosted G1/G3 and Root decisions remain unexecuted. The three inactive UNISSUED config mode discrepancies remain explicit; no full inherited mode-equality claim is made. The selected complete-run-artifact route is distinguished from the exploratory rejected direct endpoint. |
| Recovery | The exact 61 queried candidate blobs all record 404, expressly without inferring universal absence or cancellation. Known completed blob ebaaa18f… remains identified as reused. Checkpoint12 historical loss and unidentified old effects remain preserved. No demand to regenerate the old 17 MB population is introduced. |

The publication preserves DG16 M1–M6/48, DG17 36/14/17 plus genuine-host conditions, and DG18 14 plus binding amendments. New complete original awards remain `[]`. Prior accepted scopes are retained as historical bounded scopes; N1 remains mandatory LOST/UNKNOWN with no exception. Protected G132 625f/301 and the old DG17 helper request remain UNKNOWN_NO_REPLAY. Active later G2/native/download work is outside the selected archive cutoff. Nothing in this content purports to merge, release, close an issue, or alter these denominators.

## Actual reviewer checks and operations

Complete integrity verification finished at actual tool return `f0cc79`, exit 0, after start `a3079d` / session 13853. Final claim verification finished at `989a88`, exit 0. These complete returns and scripts are retained.

The initial claim checker (`15baf7`, exit 1) mistakenly expected only two raw delivery differences. Inspection established the derivative self-manifest distinction above; the original failed checker/result are retained, and the corrected checker validates both 92-member manifests as well as payload equality. A subsequent successful run `2c12ff` was followed by a failed attempt to persist its wrapper; the final read-only rerun `989a88` preserves a complete actual wrapper. No subject code ran during any of these checks.

Writes are confined to the commissioned reviewer directory. No publication/source/controller mutation, provider request, actor dispatch, original test/build rerun, native probe, protected replay or acceptance action was performed.
