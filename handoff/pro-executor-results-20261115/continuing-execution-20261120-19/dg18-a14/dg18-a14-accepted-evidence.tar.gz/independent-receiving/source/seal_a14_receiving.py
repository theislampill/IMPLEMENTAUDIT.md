#!/usr/bin/env python3
"""Bind original provider/contract inputs and seal only this new receiving packet."""
import hashlib
import json
from pathlib import Path
import tarfile

BASE=Path('/workspace/scratch/530bc07ea12b')
ROOT=BASE/'dg18-next-original-execution'
E=ROOT/'evidence'


def desc(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),
            'git_blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()}


def write(relative,data):
    p=ROOT/relative;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes((json.dumps(data,indent=2,sort_keys=True)+'\n').encode())


def decode_provider(path):
    obj=json.loads(path.read_text())
    if 'structuredContent' not in obj:return obj
    structured=obj['structuredContent']
    if isinstance(structured.get('content'),str):return json.loads(structured['content'])
    return structured


retained=json.loads((E/'RETAINED_INPUT_RECEIVING.json').read_text())
provider_rows=[]
for label,run_id,job_id,head,run_file,jobs_file,artifacts_file,zip_file in [
 ('first_migration_preparation',43785700341,133032705690,'801889a5dada43c4c17d08939c330dd358e56e92',
  'TERMINAL_RUN_TOOL_RESULT.json','TERMINAL_JOBS_TOOL_RESULT.json','TERMINAL_ARTIFACTS_TOOL_RESULT.json','WFULL_PREPARATION_43785700341.zip'),
 ('wfull',43795345593,133062794217,'a540ce32f74fa2e4a7a3002a56a6ccf3eca6a1b5',
  'RUN.json',None,'ARTIFACTS.json','ARTIFACT.zip')]:
    folder=E/'retained'/label
    run=decode_provider(folder/run_file)
    assert (run['id'],run['run_attempt'],run['head_sha'],run['status'],run['conclusion'])==(run_id,1,head,'completed','success')
    if jobs_file:
        jobs=decode_provider(folder/jobs_file)['jobs']
    else:
        responses=json.loads((folder/'independent/WFULL_TERMINAL_PROVIDER_OBSERVATION.json').read_text())['responses']
        jo=responses['jobs']
        if 'structuredContent' in jo:
            jo=jo['structuredContent']
            if 'content' in jo:jo=json.loads(jo['content'])
        jobs=jo['jobs']
    selected_jobs=[job for job in jobs if job['id']==job_id]
    assert len(selected_jobs)==1 and selected_jobs[0]['conclusion']=='success'
    if label=='first_migration_preparation':
        assert len(jobs)==1
    else:
        assert len(jobs)==2
        assert [(j['id'],j['conclusion']) for j in jobs if j['id']!=job_id]==[(133062795484,'skipped')]
    artifacts=decode_provider(folder/artifacts_file)['artifacts']
    assert len(artifacts)==1
    artifact=artifacts[0]; raw=(folder/zip_file).read_bytes(); identity=desc(raw)
    assert artifact['workflow_run']['id']==run_id and artifact['workflow_run']['head_sha']==head
    assert artifact['size_in_bytes']==len(raw) and artifact['digest']=='sha256:'+identity['sha256']
    provider_rows.append({'label':label,'run':{k:run[k] for k in ['id','head_sha','run_attempt','status','conclusion']},
      'selected_executed_job':selected_jobs[0],'complete_job_population':jobs,'artifact':artifact,'exact_archive':identity})
write('evidence/ORIGINAL_PROVIDER_BINDING_RECEIVING.json',{
 'schema':'dg18.a14.original-provider-binding-receiving.v1','authority':'NONE','rows':provider_rows,
 'provider_calls_by_this_lane':0,'originals_received_from_exact_published_git_blobs':True})

published=BASE/'results16-a10-publication/stage/dg18-a10-evidence.tar.gz'
assert desc(published.read_bytes())['sha256']=='ec2f97b965b703cbf62eb3a1b779391020e5b31a0b0d886d116ddb3fd2245359'
contract=[]
current_ci=[]
with tarfile.open(published) as archive:
    for member,local in [
      ('source/ISSUE215_CURRENT_BODY.md',BASE/'dg18-a10-current-51416/ISSUE215_CURRENT_BODY.md'),
      ('source/COMMENT_5638756120_CURRENT.md',BASE/'dg18-a10-current-51416/COMMENT_5638756120_CURRENT.md'),
      ('current-ci/ACTUAL_JOBS_TOOL_RETURN.json',BASE/'g2-profile-integration-publication/ci-observations/G0011_SUCCESS/ACTUAL_JOBS_TOOL_RETURN.json'),
      ('current-ci/ACTUAL_JOB_LOG_TOOL_RETURN.json',BASE/'g2-profile-integration-publication/ci-observations/G0011_SUCCESS/ACTUAL_JOB_LOG_TOOL_RETURN.json'),
      ('current-ci/JOB136022135798.log',BASE/'g2-profile-integration-publication/ci-observations/G0011_SUCCESS/JOB136022135798.log')]:
        raw=archive.extractfile(member).read()
        assert raw==local.read_bytes()
        row={'archive_member':member,'actual_local_path':str(local),**desc(raw)}
        if member.startswith('source/'):
            row['full_text']=raw.decode();contract.append(row)
        else:current_ci.append(row)
    published_run=json.loads(archive.extractfile('current-ci/ACTUAL_WORKFLOW_RUN.json').read())
    current_run=decode_provider(BASE/'g2-profile-integration-publication/ci-observations/G0011_SUCCESS/ACTUAL_RUN_TOOL_RETURN.json')
    assert published_run==current_run
    current_ci.append({'archive_member':'current-ci/ACTUAL_WORKFLOW_RUN.json',**desc(archive.extractfile('current-ci/ACTUAL_WORKFLOW_RUN.json').read()),'matches_current_full_provider_run_body':True})
ledger_path=BASE/'dg18-original-frontier-continuation/ACCEPTANCE_DELTA.json'
ledger=json.loads(ledger_path.read_text()); rows=ledger['original_fourteen']
assert len(rows)==14
a14=[r for r in rows if r['id']=='A14'];assert len(a14)==1 and a14[0]['this_continuation_new_original_award'] is False
assert a14[0]['retained_status']=='RETAIN_ACYCLIC_TRANSITION_SCOPE'
root_path=BASE/'dg18-c11-current-root-adjudication/ROOT_ADJUDICATION.json';root=json.loads(root_path.read_text())
assert root['product_source']=='51416b2f156b341c4a5f09029e2c6ceb5b30b1e7' and root['original_denominator']==14
root_wfull=json.loads((E/'retained/wfull/ROOT_SCOPED_RECEIVING.json').read_text())
assert root_wfull['root_decision']=='ACCEPT_AT_EXACT_DECLARED_WINDOWS_OPERATION_SCOPE'
write('evidence/CONTRACT_CURRENTNESS_AND_LEDGER_RECEIVING.json',{
 'schema':'dg18.a14.original-contract-ledger-receiving.v1','authority':'NONE',
 'original_contract_and_amendment':contract,'original_denominator':14,
 'prior_ledger':{'local_path':str(ledger_path),**desc(ledger_path.read_bytes()),'exact_a14_row':a14[0],
                 'full_original14_rows':rows},
 'retained_wfull_root_decision':root_wfull,
 'current51416_root_c11_decision':{'local_path':str(root_path),**desc(root_path.read_bytes()),'body':root},
 'parent_direction':{'source':'Root collaboration message received by this agent',
   'text':'No whole A14 award is recorded in my received current summaries; only WFULL, C11/A10 current, A7 and H002/H005/H0 bounded. Please verify actual ledger and complete A14 original conjunction from existing genuine execution if possible. Do not infer from CI alone; full source/currentness and relevant adverse observations needed. Useful direction.'},
 'currentness_limit':'Exact51416 candidate applicability received; Root must establish its own live adoption/currentness before awarding. No child live controller read or mutation.',
 'new_owner_awards_by_child':0})

write('evidence/EXTERNAL_IMMUTABLE_BINDINGS.json',{
 'schema':'dg18.a14.selected-immutable-external-inputs.v1','authority':'NONE',
 'selected_original_git_blobs':retained['selected_files'],
 'existing_results16_archive':{'repository':'theislampill/IMPLEMENTAUDIT.md',
    'commit':'8807b8e966c9d23749e94e8f8ff41903ef8a93a9',
    'path':'handoff/pro-executor-results-20261115/continuing-execution-20261120-16/dg18-a10-evidence.tar.gz',
    **desc(published.read_bytes()),'received_current_ci_members':current_ci},
 'source_bindings_index':'evidence/CURRENT_A14_SOURCE_APPLICABILITY.json',
 'source_commits':['6b353b48b2fc8a6de0c6223f48d341c484c98191','51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'],
 'retained_archives_need_not_be_republished':True,
 'no_complete_unselected_source_archive_claim':True})

write('FINDINGS.json',{
 'schema':'dg18.independent-original-criterion-receiving.v1','criterion':14,'original_denominator':14,
 'reviewer':'/root/dg18_c11_independent_review','authority':'NONE',
 'recommendation':'ACCEPT_ORIGINAL_A14_AT_EXACT_CURRENT_51416_CONJUNCTION',
 'product_commit':'51416b2f156b341c4a5f09029e2c6ceb5b30b1e7','product_tree':'9c3913ceaa95f3f36b0377fe2dba4a302afcba89',
 'complete_predicate_components':[
   'actual first migration: draft/archive, pre-invalidation event digest, allocation, final pair/manifests, pointer/CAS source and actual publication, original14 receipt, first marker',
   'full selected upstream population excludes future receipt OID; original archive entries/refs/objects and separate currentness reads match',
   'actual accepted G2-to-G3 successor preserves first marker and every first-generation file',
   'complete44 original runtime compared with immutable6b and51416 sources; A14 owner functions/classes and core modules preserve applicable behavior',
   'exact current workflow/verifier/suite and full raw CI;14 specifically received actual test methods include all named future-receipt refusal stages and real helper positives'],
 'actual_tool_returns':['f254e8/0','2c741e/0'],
 'receiving_mechanical_assertions':2560,'product_tests_executed_by_reviewer':0,
 'original_operations_replayed':0,'provider_writes':0,'controller_actions':0,'model_or_native_launches':0,
 'new_owner_awards_by_child':0,'whole_DG18_accepted':False,
 'prior_preparation_zero_award_and_wfull_scoped_award_unchanged':True,
 'hard_remaining_boundaries':['Authentic OR source/issuer/custody unavailable','No actual eligible C02 erroneous migrated event and complete entitled census supplied','Full amended cold and occurrence conjunction open; N1 LOST/UNKNOWN/PENDING without exception'],
 'no_inferred_awards':['OR','C02','N1','native Stop/session','other DG18 criteria','DG16','DG17','whole DG18','release','merge','issue closure'],
 'root_next_action':'Receive exact packet, establish live candidate applicability, and issue genuine Root A14 adjudication if adopted.'})

members=[
 'REPORT.md','FINDINGS.json','source/receive_retained_a14_inputs.py','source/receive_a14_conjunction.py','source/seal_a14_receiving.py',
 'evidence/RETAINED_INPUT_RECEIVING.json','evidence/ORIGINAL_A14_DATA_RECEIVING.json',
 'evidence/CURRENT_A14_SOURCE_APPLICABILITY.json','evidence/CURRENT_A14_ADVERSE_AND_POSITIVE_RECEIVING.json',
 'evidence/RECEIVING_CHECKS.json','evidence/ORIGINAL_PROVIDER_BINDING_RECEIVING.json',
 'evidence/CONTRACT_CURRENTNESS_AND_LEDGER_RECEIVING.json','evidence/EXTERNAL_IMMUTABLE_BINDINGS.json',
 'evidence/ACTUAL_RECEIVING_TOOL_RETURNS.json','evidence/RECEIVING_SEAL_ATTEMPT1.json']
rows=[{'path':p,**desc((ROOT/p).read_bytes())} for p in members]
manifest={'schema':'dg18.a14.independent-receiving-packet.v1','authority':'NONE',
 'reviewer':'/root/dg18_c11_independent_review','member_count':len(rows),'member_bytes':sum(r['bytes'] for r in rows),
 'members':rows,'selection':'Complete new original A14 receiving packet; original public archives, full raw current CI and exact source remain externally immutable-bound, not re-archived.',
 'external_bindings':'evidence/EXTERNAL_IMMUTABLE_BINDINGS.json','owner_award':None,
 'product_commit':'51416b2f156b341c4a5f09029e2c6ceb5b30b1e7','original_denominator':14}
write('MANIFEST.json',manifest)
for row in rows:assert desc((ROOT/row['path']).read_bytes())=={k:row[k] for k in ['bytes','sha256','git_blob']}
print(json.dumps({'result':'SEALED_NEW_A14_RECEIVING_PACKET_NO_OWNER_AWARD',
 'manifest_path':str(ROOT/'MANIFEST.json'),**desc((ROOT/'MANIFEST.json').read_bytes()),
 'member_count':len(rows),'member_bytes':sum(r['bytes'] for r in rows),
 'original_provider_bindings':2,'current_ci_full_published_run_equal':True},indent=2))
