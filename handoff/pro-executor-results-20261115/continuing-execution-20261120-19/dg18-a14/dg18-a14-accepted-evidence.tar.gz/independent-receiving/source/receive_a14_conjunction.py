#!/usr/bin/env python3
"""Receive existing original A14 data, exact source and completed CI; run no product."""
import ast
import copy
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile
import zlib

BASE = Path('/workspace/scratch/530bc07ea12b')
ROOT = BASE / 'dg18-next-original-execution'
REPO = BASE / 'implementaudit'
CURRENT = BASE / 'dg16-g2-current-profile-fix/checkout'
OLD_COMMIT = '6b353b48b2fc8a6de0c6223f48d341c484c98191'
NEW_COMMIT = '51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_ALLOW_PROTOCOL='',
           GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null')
CONTROLLER = 'dg18-w-full-43785700341-1'
RUN_ROOT = '.IMPLEMENTAUDIT/runs/fresh-windows-w-full-preparation-EjF48t'
POINTER_REF = 'refs/implementaudit/current-generations/' + CONTROLLER
MARKER_REF = 'refs/implementaudit/current-generation-migrations/' + CONTROLLER
ARCHIVE_PREFIX = 'refs/implementaudit/state-archives/' + CONTROLLER
RECEIPT_PREFIX = 'refs/implementaudit/continuity-receipts/' + CONTROLLER
PREP = ROOT / 'evidence/extracted/first_migration_preparation'
WFULL = ROOT / 'evidence/extracted/wfull'
EXECUTION = WFULL / (CONTROLLER + '/operation/execution')
checks = []


def require(condition, label):
    if not condition:
        raise AssertionError(label)
    checks.append(label)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def describe(raw):
    return dict(bytes=len(raw), sha256=sha(raw), git_blob=blob(raw))


def emit(relative, data):
    target = ROOT / relative
    raw = (json.dumps(data, indent=2, sort_keys=True) + '\n').encode()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    return dict(path=relative, **describe(raw))


def git(*args):
    return subprocess.run(['git', '-c', 'protocol.allow=never', *args], cwd=REPO,
                          env=ENV, check=True, capture_output=True).stdout


def tree(commit):
    rows = git('ls-tree', '-r', commit).decode().splitlines()
    return {line.split('\t', 1)[1]: line.split()[2] for line in rows}


def subject(path):
    rows, files, refs, objects = [], {}, {}, {}
    with tarfile.open(path) as archive:
        seen = set()
        for entry in archive.getmembers():
            p = PurePosixPath(entry.name)
            require(not p.is_absolute() and '..' not in p.parts, 'safe tar member ' + entry.name)
            require(entry.name not in seen, 'unique tar member ' + entry.name)
            seen.add(entry.name)
            require(entry.isdir() or entry.isfile(), 'regular tar member ' + entry.name)
            if not entry.isfile():
                continue
            raw = archive.extractfile(entry).read()
            require(len(raw) == entry.size, 'exact tar member bytes ' + entry.name)
            files[entry.name] = raw
            rows.append(dict(path=entry.name, mode=oct(entry.mode), **describe(raw)))
            if entry.name.startswith('subject/.git/refs/'):
                refs[entry.name[len('subject/.git/'):]] = raw.decode().strip()
            if re.fullmatch(r'subject/\.git/objects/[0-9a-f]{2}/[0-9a-f]{38}', entry.name):
                oid = ''.join(entry.name.split('/')[-2:])
                decoded = zlib.decompress(raw)
                require(hashlib.sha1(decoded).hexdigest() == oid, 'loose object identity ' + oid)
                header, content = decoded.split(b'\0', 1)
                typ, length = header.decode().split(' ')
                require(len(content) == int(length), 'loose object size ' + oid)
                objects[oid] = dict(type=typ, raw=content)
    for ref, oid in refs.items():
        require(oid in objects, 'retained ref object present ' + ref)
    return dict(path=str(path.relative_to(ROOT)), descriptor=describe(path.read_bytes()),
                files=files, refs=refs, objects=objects, members=rows)


def get_blob(snapshot, oid):
    require(snapshot['objects'][oid]['type'] == 'blob', 'object is blob ' + oid)
    return snapshot['objects'][oid]['raw']


def command_record(base, stem):
    record = json.loads((base / (stem + '.json')).read_text())
    streams = {}
    for kind in ('stdout', 'stderr'):
        raw = (base / (stem + '.' + kind)).read_bytes()
        require(sha(raw) == record[kind + '_sha256'], 'command stream ' + stem + ' ' + kind)
        streams[kind] = dict(**describe(raw), text=raw.decode())
    return dict(stem=stem, record=record, streams=streams)


old = subject(PREP / 'SUBJECT.tar')
new = subject(WFULL / 'dg18-w-full-continuation-43795345593-1/SUBJECT_AFTER.tar')
require(len(old['members']) == 156, 'first migration archive complete 156 regular files')
require(old['descriptor']['sha256'] == '00a78074048486262ad856b28ad6b2f94eb96a22188766ddd0165ce36bc05c65', 'first migration tar hash')
require(new['descriptor']['sha256'] == '6652196d5311dad32fe3c3ef8517ccda26aa71e7a7f057da1be3e64607ce74b4', 'W-FULL final tar hash')
require(old['refs'][MARKER_REF] == new['refs'][MARKER_REF] == '47b38f763b036979437062464718f95bfea509f8', 'first marker preserved across actual G2 and G3')


def receive_generation(snapshot, epoch, expected_pointer, expected_receipt, first):
    files, refs = snapshot['files'], snapshot['refs']
    prefix = 'subject/' + RUN_ROOT + '/state-generations/' + epoch + '/'
    receipt_ref = RECEIPT_PREFIX + '/' + epoch
    epoch_ref = ARCHIVE_PREFIX + '/epochs/' + epoch
    receipt_oid = refs[receipt_ref]
    receipt_raw = get_blob(snapshot, receipt_oid)
    receipt = receipt_raw.decode().rstrip('\n').split('\t')
    require(receipt_oid == expected_receipt and len(receipt) == 14, epoch + ' exact original14 receipt')
    pointer_oid = receipt[7]
    require(pointer_oid == expected_pointer, epoch + ' exact pointer identity')
    pointer_raw = get_blob(snapshot, pointer_oid)
    pointer = json.loads(pointer_raw)
    epoch_raw = get_blob(snapshot, refs[epoch_ref])
    allocation = json.loads(epoch_raw)
    transition, prepared = allocation['transition'], allocation['prepared']
    archive_oid = prepared['archive_manifest_oid']
    archive_raw = get_blob(snapshot, archive_oid)
    archive = json.loads(archive_raw)
    require(refs[prepared['archive_ref']] == archive_oid, epoch + ' retained archive ref binds actual blob')
    require(archive_raw == files[prefix + 'archive-manifest.json'], epoch + ' full archive manifest matches file')
    require(sha(archive_raw) == prepared['archive_manifest_sha256'], epoch + ' prepared archive digest')
    for entry in archive['entries']:
        body = get_blob(snapshot, entry['blob_oid'])
        require(len(body) == entry['byte_length'] and sha(body) == entry['sha256'], epoch + ' exact archived population ' + entry['artifact_id'])
    generation = json.loads(files[prefix + 'generation-manifest.json'])
    require(generation['transition'] == transition and generation['prepared'] == prepared, epoch + ' allocation and generation manifest identical')
    draft = json.loads(files[prefix + 'draft/draft-manifest.json'])
    require(draft['transition'] is None, epoch + ' draft has no successor transition')
    require(draft['authority_ceiling'] == 'NO_CURRENTNESS_AUTHORITY', epoch + ' draft has no currentness authority')
    require(sha(files[prefix + 'draft/draft-manifest.json']) == prepared['draft_manifest_sha256'], epoch + ' prepared exact draft manifest')
    for role, key in [('STATE.md', 'state_sha256'), ('ROADMAP.md', 'roadmap_sha256'), ('protected-state.json', 'protected_manifest_sha256')]:
        require(sha(files[prefix + 'draft/' + role]) == draft[key], epoch + ' actual draft binding ' + role)
        require(sha(files[prefix + role]) == pointer[key], epoch + ' final pointer binding ' + role)
    require(sha(archive_raw) == pointer['archive_manifest_sha256'], epoch + ' pointer archive binding')
    require(pointer['expected_receipt_ref_schema'] == {'ref': receipt_ref, 'schema': 'implementaudit.continuity-receipt.v3'}, epoch + ' pointer carries only future receipt ref/schema')
    expected_fields = [
        'implementaudit.continuity-receipt.v3', CONTROLLER, pointer['claim_id'], RUN_ROOT,
        epoch, pointer['invalidation_oid'], POINTER_REF, pointer_oid,
        pointer['state_sha256'], pointer['roadmap_sha256'], pointer['protected_manifest_sha256'],
        pointer['archive_manifest_sha256'], pointer['exact_next_action'], pointer['predecessor_receipt_ref_oid']]
    require(receipt == expected_fields, epoch + ' all original14 fields join exact pointer')
    predecessor = prepared['predecessor']
    require(pointer['predecessor_receipt_ref_oid'] == predecessor['receipt_ref'] + '@' + predecessor['receipt_oid'], epoch + ' actual predecessor receipt chain')
    require(refs[predecessor['receipt_ref']] == predecessor['receipt_oid'], epoch + ' predecessor retained ref')
    publication_ref = epoch_ref + '-publication'
    publication_raw = get_blob(snapshot, refs[publication_ref])
    publication = json.loads(publication_raw)
    require(publication['epoch_oid'] == refs[epoch_ref] and publication['pointer_oid'] == pointer_oid, epoch + ' actual publication intent joins allocation and pointer')
    require(publication['expected_pointer_oid'] == allocation['expected_pointer_oid'], epoch + ' publication exact expected-old pointer')
    invalidation_raw = get_blob(snapshot, pointer['invalidation_oid'])
    invalidation = invalidation_raw.decode().rstrip('\n').split('\t')
    require(invalidation[:4] == ['implementaudit.continuity-invalidation.v1', CONTROLLER, allocation['controller_oid'], pointer['claim_id']], epoch + ' actual invalidation owner binding')
    if first:
        require(allocation['expected_pointer_oid'] is None and allocation['expected_marker_oid'] is None, 'first migration exact absent pointer and marker predecessors')
        preallocation = copy.deepcopy(allocation)
        preallocation['transition']['invalidation_oid'] = None
        expected_event = 'canonical-state-rotation/' + epoch + '/' + sha(canonical(preallocation))
        require(invalidation[4:] == ['canonical-state-rotation', expected_event], 'rotation invalidation event hashes pre-invalidation allocation, without a hash cycle')
        require(predecessor['receipt_schema'] == 'implementaudit.continuity-receipt.v2', 'actual first migration has real v2 predecessor')
    else:
        require(allocation['expected_pointer_oid'] == 'aa30ebe62894c0be1d5a9d05af7d818009f9856e', 'actual G3 expected-old is actual G2 pointer')
        require(allocation['expected_marker_oid'] == old['refs'][MARKER_REF], 'actual G3 expects existing first marker')
        require(transition['boundary'] == invalidation[4] == 'manual-resume', 'actual G3 is manual resume, not fabricated host event')
    upstream = {'pointer': pointer_raw, 'allocation': epoch_raw, 'invalidation': invalidation_raw,
                'archive': archive_raw, 'publication_intent': publication_raw}
    upstream.update({p[len(prefix):]: raw for p, raw in files.items() if p.startswith(prefix)})
    for entry in archive['entries']:
        upstream['archive-entry:' + entry['artifact_id']] = get_blob(snapshot, entry['blob_oid'])
    for name, raw in upstream.items():
        require(receipt_oid.encode() not in raw, epoch + ' future receipt OID absent upstream ' + name)
    for key, raw in [('draft/STATE.md', files[prefix + 'draft/STATE.md']),
                     ('draft/ROADMAP.md', files[prefix + 'draft/ROADMAP.md']),
                     ('draft/protected-state.json', files[prefix + 'draft/protected-state.json'])]:
        if first:
            require(pointer['invalidation_oid'].encode() not in raw, 'first draft excludes future invalidation ' + key)
    marker_oid = refs[MARKER_REF]
    marker_raw = get_blob(snapshot, marker_oid)
    marker = marker_raw.decode().split('\t')
    require(len(marker) == 10 and marker[0] == 'implementaudit.current-generation-migration.v1', epoch + ' real ten-field permanent marker')
    require(marker[1:4] == [CONTROLLER, pointer['claim_id'], RUN_ROOT], epoch + ' marker identity join')
    require(marker[4:] == ['G0002', POINTER_REF, 'implementaudit.current-generation.v1', RECEIPT_PREFIX + '/G0002', '185372db50b4ae63b6763ed93d666f141b68cba2', 'true'], epoch + ' first marker references actual completed first v3 receipt')
    for oid in [archive_oid, pointer_oid, receipt_oid, marker_oid, pointer['invalidation_oid'], refs[epoch_ref], refs[publication_ref]]:
        require(refs[ARCHIVE_PREFIX + '/objects/' + oid] == oid, epoch + ' permanent retained anchor ' + oid)
    return dict(epoch=epoch, transition_kind=transition['transition_kind'], pointer_oid=pointer_oid,
                receipt_oid=receipt_oid, receipt_fields=receipt, marker_oid=marker_oid, marker_fields=marker,
                allocation_oid=refs[epoch_ref], allocation=allocation,
                publication_oid=refs[publication_ref], publication=publication,
                pointer=pointer, invalidation_oid=pointer['invalidation_oid'], invalidation_fields=invalidation,
                archive_oid=archive_oid, archive_manifest=archive, draft_manifest=draft,
                exact_upstream_population=[dict(name=k, **describe(v)) for k,v in upstream.items()],
                future_receipt_oid_absent_from_entire_selected_upstream_population=True)


g2 = receive_generation(old, 'G0002', 'aa30ebe62894c0be1d5a9d05af7d818009f9856e', '185372db50b4ae63b6763ed93d666f141b68cba2', True)
g3 = receive_generation(new, 'G0003', 'c5e718b93bd86e80a3801cd42e0edfc7893f9f05', '89ec24496f3a52cb62b1b229943a205f08ff56b3', False)
require(all(new['files'][p] == raw for p,raw in old['files'].items() if '/state-generations/G0002/' in p), 'all original G2 generation files preserved in actual G3 archive')
commands = [command_record(PREP / 'raw', stem) for stem in [
    '012-first-resume', '013-verify-first', '014-require-first', '015-first-receipt-blob',
    '016-first-rotation', '017-require-migrated']]
require(all(c['record']['exit_code'] == 0 for c in commands), 'all six selected original first-migration command exits succeeded')
require(json.loads(commands[4]['streams']['stdout']['text']) == dict(
    continuity_epoch='G0002', marker_oid=g2['marker_oid'], pointer_token=POINTER_REF+'@'+g2['pointer_oid'],
    receipt_token=RECEIPT_PREFIX+'/G0002@'+g2['receipt_oid'], status='ROTATED'), 'actual first rotation return binds full G2 conjunction')
require(commands[5]['streams']['stdout']['text'].strip() == RECEIPT_PREFIX+'/G0002@'+g2['receipt_oid'], 'separate actual currentness command verifies first migration')
wf_commands = [command_record(EXECUTION, stem) for stem in ['verify-receipt','require-current','resolve-current','current-STATE','current-ROADMAP']]
require(all(c['record']['exit_code'] == 0 for c in wf_commands), 'all five selected actual W-FULL receiving commands succeeded')
require(wf_commands[0]['streams']['stdout']['text'].strip() == wf_commands[1]['streams']['stdout']['text'].strip() == RECEIPT_PREFIX+'/G0003@'+g3['receipt_oid'], 'actual verify and require agree on G3 receipt')
require((EXECUTION/'RECEIPT.raw').read_bytes() == get_blob(new,g3['receipt_oid']), 'actual retained W-FULL receipt body matches archived object')
original_result = dict(schema='dg18.a14.original-data-conjunction.v1', authority='NONE',
    historical_runtime=OLD_COMMIT, first_migration_run=43785700341, wfull_run=43795345593,
    first_migration=g2, later_original_transition=g3, original_commands=commands+wf_commands,
    subject_archives=[{k:v for k,v in s.items() if k in ['path','descriptor','members','refs']} for s in [old,new]],
    no_original_operation_replayed=True, no_subject_git_restored_or_executed=True)
outputs = [emit('evidence/ORIGINAL_A14_DATA_RECEIVING.json', original_result)]

# Bind every recorded actual runtime file to both exact immutable source trees.
old_tree, new_tree = tree(OLD_COMMIT), tree(NEW_COMMIT)
operation = json.loads((PREP/'operation/OPERATION.json').read_text())
runtime_rows = []
for path, descriptor in operation['prepared']['snapshot']['runtime'].items():
    historical = old['files']['subject/'+path]
    current = (CURRENT/path).read_bytes()
    require(len(historical) == descriptor['bytes'] and sha(historical) == descriptor['sha256'], 'original runtime descriptor ' + path)
    require(blob(historical) == old_tree[path], 'original runtime exact6b Git blob ' + path)
    require(blob(current) == new_tree[path], 'current runtime exact51416 Git blob ' + path)
    runtime_rows.append(dict(path=path, historical=describe(historical), current=describe(current), byte_identical=historical==current))
require(len(runtime_rows)==44, 'complete original44 runtime source population')


class RemoveDocstrings(ast.NodeTransformer):
    def generic_visit(self, node):
        node = super().generic_visit(node)
        if isinstance(node, (ast.Module,ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)) and node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value,ast.Constant) and isinstance(node.body[0].value.value,str):
            node.body = node.body[1:]
        return node


def normalized(raw):
    return RemoveDocstrings().visit(ast.parse(raw))


owner_path='skills/implementaudit/scripts/claim-run-rotation.py'
original_ast=normalized(old['files']['subject/'+owner_path])
current_ast=normalized((CURRENT/owner_path).read_bytes())
original_nodes={n.name:n for n in original_ast.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
current_nodes={n.name:n for n in current_ast.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
require(original_nodes.keys()==current_nodes.keys(), 'complete claim-owner function/class population unchanged')
functions=[]
for name,node in original_nodes.items():
    old_dump=ast.dump(node,include_attributes=False); new_dump=ast.dump(current_nodes[name],include_attributes=False)
    require(old_dump==new_dump,'claim-owner normalized executable function/class identical '+name)
    functions.append(dict(name=name,normalized_ast_sha256=sha(old_dump.encode())))
changed_constants=[]
for before,after in zip(original_ast.body,current_ast.body):
    if ast.dump(before,include_attributes=False)!=ast.dump(after,include_attributes=False):
        require(isinstance(before,ast.Assign) and isinstance(after,ast.Assign),'all owner non-doc executable changes are module assignments')
        require(ast.dump(before.targets[0])==ast.dump(after.targets[0]),'changed module assignment keeps target')
        changed_constants.append(dict(name=before.targets[0].id, historical=ast.unparse(before.value),current=ast.unparse(after.value)))
require(len(original_ast.body)==len(current_ast.body),'owner module AST population unchanged')
require({x['name'] for x in changed_constants} == {'_NATIVE_SOURCE_OWNER_TEMPLATE_SHA256S','_INITIALIZATION_VALIDATOR_BYTES','_INITIALIZATION_VALIDATOR_SHA256'},'exact three known changed owner constants')
reader_path='skills/implementaudit/scripts/read-canonical-pair.py'
require(ast.dump(normalized(old['files']['subject/'+reader_path]))==ast.dump(normalized((CURRENT/reader_path).read_bytes())),'canonical reader entire executable AST identical')
selected_paths=[
 '.github/workflows/validate.yml','scripts/verify-package.sh','scripts/check-canonical-state-rotation.sh',
 'tests/canonical-state-rotation.test.sh','tests/canonical_source_custody.py',
 'tests/shell_companion_source_custody.py','fixtures/canonical-state-rotation/cases.json',
 'fixtures/canonical-state-rotation/protected_projection_v2_test.py',
 'fixtures/canonical-state-rotation/archive_v2_test.py','fixtures/canonical-state-rotation/native_resume_v2_test.py',
 'fixtures/canonical-state-rotation/claim_transaction_test.py','fixtures/canonical-state-rotation/canonical_reader_test.py',
 'fixtures/canonical-state-rotation/v2/source.json',
 'skills/implementaudit/references/canonical-state-rotation.md']
selected=[]
for path in selected_paths:
    raw=(CURRENT/path).read_bytes()
    require(blob(raw)==new_tree[path],'selected current qualification source exact51416 '+path)
    selected.append(dict(path=path,**describe(raw)))
require('bash tests/canonical-state-rotation.test.sh' in (CURRENT/'scripts/verify-package.sh').read_text(),'current canonical verifier invokes full selected suite')
require('run: bash scripts/verify-package.sh' in (CURRENT/'.github/workflows/validate.yml').read_text(),'current hosted workflow invokes actual verifier')
source_result=dict(schema='dg18.a14.exact-source-applicability.v1',authority='NONE',historical_commit=OLD_COMMIT,current_commit=NEW_COMMIT,
 historical_tree=git('rev-parse',OLD_COMMIT+'^{tree}').decode().strip(),current_tree=git('rev-parse',NEW_COMMIT+'^{tree}').decode().strip(),
 original44_runtime=runtime_rows,owner_normalized_functions_and_classes=functions,changed_owner_constants=changed_constants,
 selected_current_qualification_sources=selected,
 applicability_limit='A14 dependency-order/currentness implementation and named executed controls only; no whole runtime, native producer, OR or C02 authority equivalence.')
outputs.append(emit('evidence/CURRENT_A14_SOURCE_APPLICABILITY.json',source_result))

# Receive completed current CI from full retained provider bodies and native job log.
CI=BASE/'g2-profile-integration-publication/ci-observations/G0011_SUCCESS'
manifest=json.loads((CI/'MANIFEST.json').read_text())
def provider(filename):
    raw=(CI/filename).read_bytes()
    require(len(raw)==manifest[filename]['bytes'] and sha(raw)==manifest[filename]['sha256'],'exact retained provider body '+filename)
    result=json.loads(raw)
    return json.loads(result['structuredContent']['content'])
run=provider('ACTUAL_RUN_TOOL_RETURN.json'); jobs=provider('ACTUAL_JOBS_TOOL_RETURN.json')
require(run['id']==44655969487 and run['run_attempt']==1 and run['head_sha']==NEW_COMMIT and run['status']=='completed' and run['conclusion']=='success','actual current run identity and terminal status')
require(jobs['total_count']==1 and len(jobs['jobs'])==1,'actual current complete job population')
job=jobs['jobs'][0]
require(job['id']==136022135798 and job['run_id']==run['id'] and job['head_sha']==NEW_COMMIT and job['conclusion']=='success','actual current job bound to exact source')
verify_step=[s for s in job['steps'] if s['name']=='Verify package contract']
require(len(verify_step)==1 and verify_step[0]['conclusion']=='success','actual original verifier step completed')
log_raw=(CI/'JOB136022135798.log').read_bytes(); log=log_raw.decode()
require(describe(log_raw)['sha256']=='7d58c311832168a01e8dc12841d4b770bd16a1873e63a7063ecc0d64f962b893' and len(log_raw)==569919,'full original current CI log exact bytes')
require(NEW_COMMIT in log,'actual current checkout commit present in full raw log')
tests=[
 ('protected_projection_v2_test.py','ProtectedProjectionV2','test_rotation_transition_and_recovery_skip_only_exact_failed_allocation'),
 ('archive_v2_test.py','ArchiveQualification','test_draft_corruption_and_future_receipt_are_not_finalized'),
 ('archive_v2_test.py','ArchiveQualification','test_unknown_predecessor_metadata_refuses_before_archive_effects'),
 ('archive_v2_test.py','ArchiveQualification','test_prepared_envelope_unknown_fields_refuse_before_final_generation'),
 ('archive_v2_test.py','ArchiveQualification','test_rebound_archive_metadata_must_match_complete_source_population'),
 ('archive_v2_test.py','ArchiveQualification','test_two_clean_roots_produce_byte_identical_draft_and_final_files'),
 ('native_resume_v2_test.py','NativeResumeAlgebra','test_native_resume_rejects_reuse_substitution_relabel_and_future_bindings'),
 ('native_resume_v2_test.py','NativeResumeArchive','test_native_predecessor_omissions_future_fields_and_identity_changes_write_nothing'),
 ('native_resume_v2_test.py','NativeResumeArchive','test_native_resume_rejects_transition_substitution_without_current_effects'),
 ('claim_transaction_test.py','CompleteOwnerDiscriminators','test_all_retained_transition_gate_removals_refuse_currentness'),
 ('claim_transaction_test.py','RealHelperIntegration','test_real_helper_migrates_real_main_receipt_and_separate_readers'),
 ('claim_transaction_test.py','RealHelperIntegration','test_real_helper_retains_actual_failed_receipt_and_pair_on_marker_failure'),
 ('claim_transaction_test.py','TransactionControls','test_first_migration_mints_real_v3_and_a_permanent_marker'),
 ('claim_transaction_test.py','TransactionControls','test_second_rotation_preserves_first_migration_marker'),
]
test_rows=[]
for filename,expected_class,test_name in tests:
    path='fixtures/canonical-state-rotation/'+filename
    raw=(CURRENT/path).read_bytes(); module=ast.parse(raw)
    matches=[(cls,node) for cls in module.body if isinstance(cls,ast.ClassDef) for node in cls.body if isinstance(node,ast.FunctionDef) and node.name==test_name]
    require(len(matches)==1,'unique actual selected test definition '+test_name)
    cls,node=matches[0]
    # Class identity is derived from the exact source, rather than a guessed label.
    logged=[(i+1,line) for i,line in enumerate(log.splitlines()) if (' '+test_name+' (__main__.'+cls.name+'.'+test_name+') ... ok') in line]
    require(len(logged)==1,'unique actual successful executed test '+test_name)
    require(('"${py[@]}" '+path) in (CURRENT/'tests/canonical-state-rotation.test.sh').read_text(),'suite selects exact test file '+filename)
    test_rows.append(dict(path=path,source=describe(raw),class_name=cls.name,test_name=test_name,
      source_body=ast.get_source_segment(raw.decode(),node),source_start_line=node.lineno,source_end_line=node.end_lineno,
      actual_log_line_number=logged[0][0],actual_log_line=logged[0][1],execution_scope='EXISTING_CURRENT_QUALIFICATION_CONTROL_NOT_NEW_NATIVE_OR_OR_C02_EPISODE'))
ci_result=dict(schema='dg18.a14.completed-current-controls-receiving.v1',authority='NONE',
 run={k:run[k] for k in ['id','head_sha','head_branch','path','run_attempt','status','conclusion','created_at','updated_at']},
 job={k:job[k] for k in ['id','run_id','head_sha','status','conclusion','steps']},
 full_raw_log=describe(log_raw),full_raw_log_path=str(CI/'JOB136022135798.log'),
 provider_originals={k:v for k,v in manifest.items() if k in ['ACTUAL_RUN_TOOL_RETURN.json','ACTUAL_JOBS_TOOL_RETURN.json','ACTUAL_JOB_LOG_TOOL_RETURN.json']},
 selected_full_test_bodies_and_actual_observations=test_rows,
 no_tests_rerun=True,no_fixture_label_alone_used_for_acceptance=True)
outputs.append(emit('evidence/CURRENT_A14_ADVERSE_AND_POSITIVE_RECEIVING.json',ci_result))
outputs.append(emit('evidence/RECEIVING_CHECKS.json',dict(schema='dg18.a14.mechanical-receiving-checks.v1',authority='NONE',
 checks=checks,check_count=len(checks),result='PASS',product_commands=0,original_operation_replays=0,
 provider_reads=0,provider_writes=0,controller_actions=0,native_events=0,award_authority='NONE')))
print(json.dumps(dict(result='EXISTING_ORIGINAL_A14_CONJUNCTION_RECEIVED',checks=len(checks),
 original_operations_replayed=0,product_commands=0,provider_writes=0,outputs=outputs),indent=2))
