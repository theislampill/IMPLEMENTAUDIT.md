#!/usr/bin/env python3
"""Offline, read-only receipt of selected already-published DG18 actuals."""
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/530bc07ea12b/dg18-next-original-execution')
REPO = Path('/workspace/scratch/530bc07ea12b/implementaudit')
CHECKPOINT = 'c3f86d95404f898d26c4be44f8fe23f59e4a0782'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_ALLOW_PROTOCOL='',
           GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null')


def git(*args):
    return subprocess.run(['git', '-c', 'protocol.allow=never', *args], cwd=REPO,
                          env=ENV, check=True, capture_output=True).stdout


def sha(b):
    return hashlib.sha256(b).hexdigest()


def write_exact(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, f'existing file differs: {path}'
    else:
        path.write_bytes(raw)


groups = {
    'wfull': {
        'prefix': 'handoff/pro-executor-results-20261115/authorized-execution-20261116/dg18/wfull',
        'files': ['ARTIFACT.zip', 'ARTIFACTS.json', 'RUN.json', 'JOB_LOG.txt',
                  'MEMBER_MANIFEST.json', 'ROOT_SCOPED_RECEIVING.json',
                  'independent/WFULL_ACTUAL_DATA_RECEIVING.json',
                  'independent/WFULL_TERMINAL_RECEIVING.md',
                  'independent/WFULL_TERMINAL_PROVIDER_OBSERVATION.json',
                  'selected-originals/OPERATION.json'],
    },
    'first_migration_preparation': {
        'prefix': 'handoff/pro-executor-results-20261115/fresh-original-operations-20261116/dg18/actual-43785700341',
        'files': ['WFULL_PREPARATION_43785700341.zip', 'ARCHIVE_GET_OUTCOME.json',
                  'ARCHIVE_MEMBERS.json', 'INDEPENDENT_PREPARATION_RECEIVING.md',
                  'TERMINAL_ARTIFACTS_TOOL_RESULT.json', 'TERMINAL_JOBS_TOOL_RESULT.json',
                  'TERMINAL_JOB_LOG.txt', 'TERMINAL_RUN_TOOL_RESULT.json',
                  'artifact/PREPARATION.json'],
    },
}
received = []
archives = []
for label, selection in groups.items():
    listing = git('ls-tree', '-r', '-l', CHECKPOINT, selection['prefix']).decode()
    tree = {}
    for line in listing.splitlines():
        meta, path = line.split('\t', 1)
        mode, typ, oid, size = meta.split()
        tree[path] = (mode, typ, oid, int(size))
    for rel in selection['files']:
        remote_path = selection['prefix'] + '/' + rel
        mode, typ, oid, size = tree[remote_path]
        assert typ == 'blob' and mode == '100644'
        raw = git('cat-file', 'blob', oid)
        assert len(raw) == size
        assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == oid
        local = Path('evidence/retained') / label / rel
        write_exact(ROOT / local, raw)
        received.append(dict(checkpoint=CHECKPOINT, repository_path=remote_path,
                             local_path=str(local), bytes=size, sha256=sha(raw), git_blob=oid))
        if rel.endswith('.zip'):
            if label == 'wfull':
                assert size == 1255530
                assert sha(raw) == '909a89c6d30922117dd6f7a05fb2fc178f157170dd4aa43b966f8e14ee49fe40'
            members = []
            with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                assert archive.testzip() is None
                seen = set()
                for info in archive.infolist():
                    if info.is_dir():
                        continue
                    name = PurePosixPath(info.filename)
                    assert not name.is_absolute() and '..' not in name.parts
                    assert info.filename not in seen
                    seen.add(info.filename)
                    member = archive.read(info)
                    assert len(member) == info.file_size
                    dest = ROOT / 'evidence' / 'extracted' / label / name
                    write_exact(dest, member)
                    members.append(dict(path=info.filename, bytes=len(member), sha256=sha(member)))
            if label == 'wfull':
                assert len(members) == 60 and sum(m['bytes'] for m in members) == 5737539
            archives.append(dict(label=label, archive_local_path=str(local), sha256=sha(raw),
                                 bytes=size, member_count=len(members),
                                 member_bytes=sum(m['bytes'] for m in members), members=members))
result = dict(schema='dg18.a14.retained-original-input-receiving.v1', authority='NONE',
              original_operations_replayed=0, provider_reads=0, provider_writes=0,
              git_network_transports_disabled=True, source_checkpoint=CHECKPOINT,
              selected_files=received, archives=archives)
out = ROOT / 'evidence' / 'RETAINED_INPUT_RECEIVING.json'
write_exact(out, (json.dumps(result, indent=2, sort_keys=True)+'\n').encode())
print(json.dumps(dict(result='RECEIVED_EXACT_SELECTED_PUBLISHED_BYTES', selected_files=len(received),
                      selected_bytes=sum(x['bytes'] for x in received),
                      archives=[{k:v for k,v in x.items() if k != 'members'} for x in archives],
                      receipt_path=str(out), receipt_sha256=sha(out.read_bytes())), indent=2))
