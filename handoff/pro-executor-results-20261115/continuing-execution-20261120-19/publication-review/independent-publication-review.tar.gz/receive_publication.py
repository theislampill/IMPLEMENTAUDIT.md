#!/usr/bin/env python3
"""Bounded local publication receiving. No provider, controller, or product runs."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import re
import tarfile
import zipfile
import zlib
from datetime import datetime, timezone

BASE=Path('/workspace/scratch/530bc07ea12b')
OUT=Path(__file__).resolve().parent
STAGE=BASE/'results19-original-outcomes/stage'
checks=[]
summary={}


def sha(raw):return hashlib.sha256(raw).hexdigest()
def blob(raw):return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def desc(raw):return {'bytes':len(raw),'sha256':sha(raw),'git_blob':blob(raw)}
def encode(v):return (json.dumps(v,sort_keys=True,indent=2,ensure_ascii=True,allow_nan=False)+'\n').encode()
def read(p):return json.loads(Path(p).read_bytes())
def check(name,ok,details=None):
 checks.append({'name':name,'pass':bool(ok),'details':details})
 if not ok:raise ValueError(name)
def save(name,raw):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():
  if p.read_bytes()!=raw:raise ValueError('EXISTING_REVIEW_DIFFERENT:'+name)
 else:p.write_bytes(raw)
def unwrap(v):
 if v.get('isError'):raise ValueError('ACTUAL_PROVIDER_ERROR')
 while isinstance(v,dict) and 'structuredContent' in v:v=v['structuredContent']
 return json.loads(v['content']) if isinstance(v,dict) and isinstance(v.get('content'),str) else v
def safe(name):
 return bool(name) and not PurePosixPath(name).is_absolute() and str(PurePosixPath(name))==name and '..' not in PurePosixPath(name).parts and '\\' not in name


def open_archive(raw,index,label):
 decoder=zlib.decompressobj(31);plain=decoder.decompress(raw)+decoder.flush()
 check(label+'_one_complete_gzip_stream_no_trailing_data',decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail)
 with tarfile.open(fileobj=io.BytesIO(plain),mode='r:') as tf:
  items=tf.getmembers();names=[m.name for m in items]
  check(label+'_regular_safe_unique_tar_members',len(items)==len(set(names))==index['member_count'] and all(m.isfile() and safe(m.name) and m.mode==0o644 and m.uid==m.gid==0 and not m.uname and not m.gname and set(m.pax_headers)<= {'path'} for m in items) and not tf.pax_headers)
  bodies={m.name:tf.extractfile(m).read() for m in items}
  check(label+'_every_declared_member_exact',len(index['members'])==len(bodies) and set(bodies)=={r['path'] for r in index['members']} and sum(map(len,bodies.values()))==index['member_bytes'] and all(desc(bodies[r['path']])=={k:r[k] for k in ['bytes','sha256','git_blob']} for r in index['members']))
  final_end=max(m.offset_data+((m.size+511)//512)*512 for m in items)
  check(label+'_tar_end_padding_only',not any(plain[final_end:]))
 return bodies


def check_seal(bodies,prefix,seal_name,expected_sha):
 raw=bodies[prefix+'/'+seal_name];s=json.loads(raw)
 check(prefix+'_'+seal_name+'_unchanged',sha(raw)==expected_sha)
 rows=s.get('files',s.get('members'))
 check(prefix+'_sealed_payloads_exact',isinstance(rows,list) and all(prefix+'/'+r['path'] in bodies and len(bodies[prefix+'/'+r['path']])==r['bytes'] and sha(bodies[prefix+'/'+r['path']])==r['sha256'] for r in rows))


def main():
 manifest=read(STAGE/'MANIFEST.json')
 check('exact_requested_stage_manifest',sha((STAGE/'MANIFEST.json').read_bytes())=='07365c2fd86d817f0827f6f604255bb0ea9701cbd93c85f18516a41344291580')
 paths={r['path'] for r in manifest['files']}
 check('exact27_file_stage_population',len(manifest['files'])==len(paths)==26 and paths=={str(p.relative_to(STAGE)) for p in STAGE.rglob('*') if p.is_file()}-{'MANIFEST.json'})
 check('every_stage_byte_sha256_git_blob_mode',all(safe(r['path']) and r['mode']=='100644' and desc((STAGE/r['path']).read_bytes())=={k:r[k] for k in ['bytes','sha256','git_blob']} for r in manifest['files']))
 check('exact_stage_totals',sum(r['bytes'] for r in manifest['files'])==manifest['file_bytes_excluding_manifest']==1957362 and sum(p.stat().st_size for p in STAGE.rglob('*') if p.is_file())==1965099)
 check('exact_branch_parent_prefix_additions_only',manifest['parent']=='e852e16ae9ce29492312e66e46f081d0b45e3d7d' and manifest['base_tree']=='5cdbea859e544f12936df0d050832d532827f885' and manifest['branch']=='engineering/pro-executor-original-completion-20261115' and manifest['prefix']=='handoff/pro-executor-results-20261115/continuing-execution-20261120-19' and manifest['no_prior_file_changes'] is True and all(safe(manifest['prefix']+'/'+r['path']) for r in manifest['files']))
 base=read(BASE/'results19-original-outcomes/receipts/BASE_ACTUAL.json');commit,ref=unwrap(base['commit']),unwrap(base['ref'])
 check('retained_actual_results_parent_ref_tree_bound',commit['sha']==manifest['parent'] and commit['tree']['sha']==manifest['base_tree'] and ref['object']['sha']==manifest['parent'] and ref['ref']=='refs/heads/'+manifest['branch'])
 tree_path=BASE/'results19-original-outcomes/receipts/BASE_TREE_PROVIDER_CONTENT.json'
 tree_raw=tree_path.read_bytes();tree=json.loads(tree_raw)
 check('exact_previously_received_complete_base_tree_content',len(tree_raw)==1316176 and sha(tree_raw)=='fd2a665487e6ec248c518ef4468984abd61cc733d25d7255bfce791aa2c9c7c8' and tree['sha']==manifest['base_tree'] and tree['truncated'] is False)
 entries={r['path']:r for r in tree['tree']}
 leaves={name:(r['mode'],r['sha']) for name,r in entries.items() if r['type']!='tree'}
 check('all3688_prior_leaves_and_fresh_prefix',len(entries)==len(tree['tree']) and len(leaves)==3688 and all(r['type']=='blob' for r in entries.values() if r['type']!='tree') and not any(name==manifest['prefix'] or name.startswith(manifest['prefix']+'/') for name in entries))
 def git_tree(leaves):
  root={};trees={}
  for path,(mode,ident) in leaves.items():
   node=root;pieces=path.split('/')
   for part in pieces[:-1]:node=node.setdefault(part,{})
   if pieces[-1] in node:raise ValueError('TREE_PATH_COLLISION')
   node[pieces[-1]]=(mode,ident)
  def build(node,prefix=''):
   raw=b''
   for name,value in sorted(node.items(),key=lambda item:(item[0]+('/' if isinstance(item[1],dict) else '')).encode()):
    if isinstance(value,dict):mode,ident='40000',build(value,prefix+name+'/')
    else:mode,ident=value;mode=format(int(mode,8),'o')
    raw+=mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(ident)
   ident=hashlib.sha1(b'tree '+str(len(raw)).encode()+b'\0'+raw).hexdigest();trees[prefix.rstrip('/')]=ident;return ident
  return build(root),trees
 original_root,subtrees=git_tree(leaves)
 check('independent_Git_tree_reconstruction_matches_all_original_trees',original_root==manifest['base_tree'] and all(subtrees[name]==r['sha'] for name,r in entries.items() if r['type']=='tree'))
 additions={manifest['prefix']+'/'+r['path']:(r['mode'],r['git_blob']) for r in manifest['files']}
 additions[manifest['prefix']+'/MANIFEST.json']=('100644',blob((STAGE/'MANIFEST.json').read_bytes()))
 check('all27_additions_have_no_prior_path_or_parent_collision',len(additions)==27 and not(set(additions)&set(leaves)) and all('/'.join(n.split('/')[:i]) not in leaves for n in additions for i in range(1,len(n.split('/')))))
 expected_tree,_=git_tree(dict(leaves,**additions))
 expected_addition={'schema':'results19.independent-expected-additions.v1','authority':'NONE','actual_provider_write_performed':False,'base_provider_content':{'path':str(tree_path),'bytes':len(tree_raw),'sha256':sha(tree_raw)},'parent':manifest['parent'],'base_tree':manifest['base_tree'],'expected_tree':expected_tree,'prior_leaves':len(leaves),'additions':len(additions),'expected_total_leaves':len(leaves)+len(additions),'all_prior_leaves_preserved':True,'prefix':manifest['prefix'],'added_paths':[{'path':name,'mode':mode,'git_blob':ident} for name,(mode,ident) in sorted(additions.items())]}
 save('EXPECTED_ADDITION.json',encode(expected_addition))
 summary['expected_addition']=expected_addition
 save('inputs/STAGE_MANIFEST.json',(STAGE/'MANIFEST.json').read_bytes())
 save('inputs/BASE_ACTUAL.json',(BASE/'results19-original-outcomes/receipts/BASE_ACTUAL.json').read_bytes())
 save('inputs/ACCEPTANCE_DELTA.json',(STAGE/'ACCEPTANCE_DELTA.json').read_bytes())
 save('inputs/README.md',(STAGE/'README.md').read_bytes())
 maps={
  'dg16-m2':{'closing':BASE/'dg16-g2-actual-closing-independent-review','live':BASE/'dg16-g2-actual-live-independent-review','preparation':BASE/'dg16-g2-live-review-preparation','root':BASE/'dg16-g2-original-root-adjudication'},
  'dg17-b02':{'independent':BASE/'dg17-b02-actual-independent-review','root':BASE/'dg17-b02-original-root-adjudication'},
  'dg18-a14':{'independent-receiving':BASE/'dg18-next-original-execution','root':BASE/'dg18-a14-current-root-adjudication'}}
 all_bodies={};archive_summaries=[];original_zip_rows=[];privacy_urls=[]
 for label in ['dg16-m2','dg17-b02','dg18-a14']:
  directory=STAGE/label;index=read(directory/'ARCHIVE_MEMBERS.json')
  if label!='dg18-a14':
   parts=read(directory/'EVIDENCE_PARTS.json')
   check(label+'_bounded_parts_order_identity',len(parts['parts'])==(3 if label=='dg16-m2' else 6) and [r['path'] for r in parts['parts']]==[parts['archive_file']+'.part%03d'%i for i in range(len(parts['parts']))] and all(desc((directory/r['path']).read_bytes())=={k:r[k] for k in ['bytes','sha256','git_blob']} and r['bytes']<=196608 for r in parts['parts']))
   archive=b''.join((directory/r['path']).read_bytes() for r in parts['parts'])
   check(label+'_exact_full_reassembly',len(archive)==parts['bytes']==index['archive_bytes'] and sha(archive)==parts['sha256']==index['archive_sha256'] and any(a=={'bytes':len(archive),'directory':label,'parts':len(parts['parts']),'sha256':sha(archive)} for a in manifest['binary_archive_assemblies']))
  else:
   archive=(directory/'dg18-a14-accepted-evidence.tar.gz').read_bytes()
   oldstage=BASE/'dg18-a14-publication-preparation/stage'
   check('A14_prepared_archive_and_all_six_files_reused_exact',len(archive)==138459 and sha(archive)=='0fd58c7a2a64e8cc20d79649d5cd12f3129603bf6075933aa1cef37e48eccfd9' and all((directory/p.name).read_bytes()==p.read_bytes() for p in oldstage.iterdir() if p.is_file()) and len([p for p in oldstage.iterdir() if p.is_file()])==6)
  bodies=open_archive(archive,index,label);all_bodies[label]=bodies
  direct,derived=0,0
  for name,raw in bodies.items():
   prefix,suffix=name.split('/',1)
   if label=='dg18-a14' and name=='root/ROOT_AWARD_RECEIVING.json':
    value=json.loads(raw);award=read(BASE/'dg18-a14-current-root-adjudication/ROOT_ADJUDICATION.json')
    check('A14_preparer_descriptor_genuine_scope_and_decision_binding',value['authority']=='NONE' and value['awarding_actor']=='/root' and value['decision_exact_bytes']==desc((BASE/'dg18-a14-current-root-adjudication/ROOT_ADJUDICATION.json').read_bytes()) and value['actual_root_adjudication_return_reference']=='7e88a3/0' and value['root_continuity_receipt']==award['continuity_receipt'] and value['preparer_provider_writes']==value['preparer_controller_actions']==0)
    derived+=1
   else:
    source=maps[label][prefix]/suffix
    if source.read_bytes()!=raw:raise ValueError('ARCHIVE_SOURCE_MISMATCH:'+label+'/'+name)
    direct+=1
   if raw.startswith(b'PK\x03\x04'):
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
     entries=z.infolist()
     if not all(safe(e.filename) and not e.is_dir() for e in entries):raise ValueError('UNSAFE_NESTED_ORIGINAL_ZIP')
     for e in entries:z.read(e)
     original_zip_rows.append({'archive':label,'path':name,**desc(raw),'members':len(entries),'expanded_bytes':sum(e.file_size for e in entries)})
   try:text=raw.decode('utf8')
   except UnicodeDecodeError:continue
   for value in re.findall(r'https?://[^\s<>"\\]+',text):
    if re.search(r'(?i)([?&](?:sig|x-amz-signature|x-amz-credential|x-goog-signature|token|access_token)=)',value) or re.search(r'(?i)https?://[^/\s]*:[^/@\s]+@',value):
     privacy_urls.append({'archive':label,'path':name,'kind':'CREDENTIAL_BEARING_URL_PATTERN','url_sha256':sha(value.encode())})
  check(label+'_all_selected_members_match_exact_sources',direct+derived==index['member_count'],{'direct_source_members':direct,'original_prepared_descriptor_members':derived})
  archive_summaries.append({'directory':label,'compressed':desc(archive),'members':len(bodies),'expanded_bytes':sum(map(len,bodies.values())),'index_sha256':sha((directory/'ARCHIVE_MEMBERS.json').read_bytes()),'source_roots':{k:str(v) for k,v in maps[label].items()}})
  award_source=maps[label]['root']/'ROOT_ADJUDICATION.json'
  check(label+'_exact_visible_report_and_Root_decision',bodies['root/ROOT_ADJUDICATION.json']==award_source.read_bytes()==(directory/'ROOT_ADJUDICATION.json').read_bytes() and (directory/'INDEPENDENT_RECEIVING_REPORT.md').read_bytes()==bodies[{'dg16-m2':'closing/REPORT.md','dg17-b02':'independent/REPORT.md','dg18-a14':'independent-receiving/REPORT.md'}[label]])
  save('inputs/'+label+'_ROOT_ADJUDICATION.json',(directory/'ROOT_ADJUDICATION.json').read_bytes())
 check('all1136_declared_archive_members_received',sum(a['members'] for a in archive_summaries)==1136 and sum(a['expanded_bytes'] for a in archive_summaries)==5829929)
 m2,b02,a14=[all_bodies[n] for n in ['dg16-m2','dg17-b02','dg18-a14']]
 check_seal(m2,'closing','SEAL.json','a5cadd0b7fbb8d44bf3c8981bdbcb2f641c61dde3b93cd631516870e7d806e21')
 check_seal(m2,'live','SEAL.json','0cf7d8853c808176b2e081d3e90a8bea6479c2ea0af3677afed7b7c80b057c8d')
 check_seal(m2,'preparation','SEAL.json','c547d824a84cb642163d0495e0c70766005613b08cff5461462a1d3346748987')
 check_seal(b02,'independent','SEAL.json','7e5e3e5249fc7f878d014325ee07959b6f78bd580f38d591d0787868b9883283')
 check_seal(a14,'independent-receiving','MANIFEST.json','a78c178110a63867f8b5055a0e7443f22e4c438523c77c6645314ce0fc8fe84b')
 expected_zips={
  '02bef43692cc56ef8056929cf3ab3b483c344338515a5b7557899f5a9bffe663':(15982,7),
  '702453ece5005a6abe8b45912686c3fc53a8b78eaf9bcfd47b8ce0197d122286':(17982,9),
  'ed809c07ec01b69f045832e5ca9317fe531c3a4b76145bce5c8242952029f58f':(128372,248),
  'ac3b7d7d38932e54f64c3457d61348fcfaeb3c11416c4c2ea11286f13529b5ba':(463468,635)}
 check('only_four_exact_original_public_ZIPs',len(original_zip_rows)==4 and {r['sha256']:(r['bytes'],r['members']) for r in original_zip_rows}==expected_zips)
 check('no_actual_credential_bearing_ephemeral_URL_found',not privacy_urls,privacy_urls)
 check('no_unmapped_private_input_archive_population',all(set(name.split('/',1)[0] for name in all_bodies[label])==set(maps[label]) for label in maps) and manifest['private_G132_input_bodies_included'] is False and read(STAGE/'dg16-m2/ARCHIVE_MEMBERS.json')['private_original_bodies_included'] is False and not any(name.endswith(('FULL_RELATION_PRIVATE.json','CONSUMPTION_RESERVED.json')) for bodies in all_bodies.values() for name in bodies))
 for label,expected_chunk,expected_digest in [('dg16-m2','eebcf4','5acaf9f41b5b189982f4106f799febae55c278b8234be58fb8b8d149852e4fb4'),('dg17-b02','3c389c','bc98d73fa26224399aa948a8b07388fd2735aaca5c610166803d4af622570c70'),('dg18-a14','7e88a3','caff3e4b0286ee07fffc9fc5073c47324c0c4d7d69ff4a01b18296082322552b')]:
  raw=(STAGE/label/'ROOT_ADJUDICATION.json').read_bytes()
  tool_raw=(STAGE/label/'ACTUAL_ROOT_ADJUDICATION_TOOL_RETURN.json').read_bytes() if label=='dg18-a14' else all_bodies[label]['root/ACTUAL_ROOT_ADJUDICATION_TOOL_RETURN.json']
  t=json.loads(tool_raw);v=json.loads(t['output'])
  check(label+'_genuine_actual_Root_award_return_bound',sha(raw)==expected_digest and t['chunk_id']==expected_chunk and t['exit_code']==0 and v['sha256']==expected_digest and v['bytes']==len(raw))
  if label=='dg18-a14':check('A14_added_actual_Root_return_exact_source',tool_raw==(maps[label]['root']/'ACTUAL_ROOT_ADJUDICATION_TOOL_RETURN.json').read_bytes())
 delta=read(STAGE/'ACCEPTANCE_DELTA.json')
 check('only_three_already_issued_bounded_awards',manifest['new_original_awards']==['DG16_M2','DG17_B02','DG18_A14'] and len(delta['new_complete_original_awards'])==3 and delta['new_complete_mutation_families']==delta['new_terminal_clauses']==[] and all(sha((STAGE/r['decision']).read_bytes())==r['sha256'] for r in delta['new_complete_original_awards']))
 check('denominators_and_no_whole_cell_release_closure_preserved',delta['original_denominators']=={'DG16':{'milestones':6,'requirements':48},'DG17':{'cases':36,'mutation_families':14,'terminal_clauses':17},'DG18':{'criteria':14}} and delta['whole_cells_accepted']==0 and delta['merge_release_issue_closure'] is False and delta['prior_results_commit']==manifest['parent'])
 awards=[read(STAGE/n/'ROOT_ADJUDICATION.json') for n in maps]
 check('M2_case_A14_scopes_bound_to_original_review_no_overaward',awards[0]['milestone']=='M2' and awards[0]['product_source']=='51416b2f156b341c4a5f09029e2c6ceb5b30b1e7' and awards[0]['automatic_whole_row_awards']==[] and awards[1]['case']=='B02' and awards[1]['source_commit']=='a297957be11feb494c0ec467235794a1e0c54751' and awards[1]['new_complete_cases']==['B02'] and awards[1]['new_mutation_families']==awards[1]['new_terminal_clauses']==[] and awards[2]['criterion']==awards[2]['original_denominator']==14 and awards[2]['product_source']==awards[0]['product_source'] and all(a['whole_cell_accepted'] is False and a['issued_by']=='/root' for a in awards))
 external=a14['independent-receiving/evidence/EXTERNAL_IMMUTABLE_BINDINGS.json']
 check('A14_external_immutable_index_exact_and_not_rearchived',sha(external)=='7e362e27a29199e116b64f42fb6ee4133aeddb5b106cd81861e7a9c1b1d04421' and read(STAGE/'dg18-a14/MANIFEST.json')['old_inputs_rearchived'] is False and read(STAGE/'dg18-a14/ARCHIVE_MEMBERS.json')['no_claim_of_archiving_unselected_source_population'] is True)
 summary.update({'archives':archive_summaries,'original_public_ZIPs':original_zip_rows,'stage':{'manifest_sha256':sha((STAGE/'MANIFEST.json').read_bytes()),'files':27,'bytes':1965099,'parent':manifest['parent'],'base_tree':manifest['base_tree'],'prefix':manifest['prefix']},'claim_review':'Only previously issued original M2/B02/A14; original denominators and explicit limits remain; no new award issued by this reviewer','provider_mutations':0,'original_tests_or_replays':0})
 save('INPUT_BINDINGS.json',encode({'stage_manifest':desc((STAGE/'MANIFEST.json').read_bytes()),'stage_files':manifest['files'],'archive_summaries':archive_summaries}))


if __name__=='__main__':
 error=None
 try:main()
 except Exception as exc:error={'type':type(exc).__name__,'message':str(exc)}
 value={'schema':'results19.independent-publication-receiving.v1','reviewer':'/root/dg17_p04_independent_review','authority':'NONE','observed_at':datetime.now(timezone.utc).isoformat(),'checks':checks,'passed':sum(c['pass'] for c in checks),'total':len(checks),'error':error,'all_checks_pass':error is None and all(c['pass'] for c in checks),'summary':summary,'new_original_awards':[]}
 name='VERIFICATION.json' if value['all_checks_pass'] else 'VERIFICATION_FAILED.json'
 save(name,encode(value))
 print(json.dumps({'result':name,'passed':value['passed'],'total':value['total'],'error':error,'sha256':sha(encode(value))},sort_keys=True))
 raise SystemExit(0 if value['all_checks_pass'] else 1)
