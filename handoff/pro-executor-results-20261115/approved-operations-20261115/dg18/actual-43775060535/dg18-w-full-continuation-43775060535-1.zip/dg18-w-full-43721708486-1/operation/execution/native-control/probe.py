import json, os, subprocess, sys, time
allocation = bytearray(32 * 1024 * 1024)
child = subprocess.Popen([sys.executable, '-I', '-c', 'import time; a=bytearray(32*1024*1024); time.sleep(1.0)'])
git = subprocess.Popen([sys.argv[1], 'hash-object', '--stdin'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
time.sleep(0.25)
git.communicate(b'constructed job measurement control')
child.wait()
print(json.dumps({'python_pid':os.getpid(),'child_pid':child.pid,'git_pid':git.pid,'child_exit':child.returncode,'git_exit':git.returncode}))
