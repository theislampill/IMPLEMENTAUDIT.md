from pathlib import Path
import ast,contextlib,hashlib,importlib.util,json,os,shutil,tempfile,traceback,datetime
ROOT=Path(__file__).resolve().parent
SCRIPT=ROOT/'stage/handoff/pro-executor-results-20261115/dg18-c11-current-51416-20261120/qualify.py'
SOURCE=Path('/workspace/scratch/530bc07ea12b/implementaudit')
spec=importlib.util.spec_from_file_location('current_c11_source_control_only',SCRIPT)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
# Public source controls only. No host_context admission is forged. This patch
# prevents every original installer/claim/activation/currentness loop.
m.ROUTES=()
out=ROOT/'source-controls';out.mkdir(mode=0o700)
results=[]
def record(label,f):
 try:v=f();results.append({'name':label,'status':'PASS','result':v})
 except BaseException as e:results.append({'name':label,'status':'FAIL','error':type(e).__name__,'message':str(e)});raise

def hosted_refusal():
 try:m.host_context()
 except RuntimeError as e:
  assert str(e)=='unbound hosted source qualification',str(e)
  return {'refusal':str(e),'host_environment_forged':False,'controllers':0}
 raise AssertionError('non-hosted context accepted')
record('unbound_actual_local_host_refused',hosted_refusal)

def positive():
 op=m.Operation(SOURCE,ROOT/'stage',out/'positive',{'scope':'TEST_ONLY_SOURCE_PACKAGE_INTAKE','installed_routes_disabled':True})
 op.prepare()
 evidence=json.loads((op.evidence/'PACKAGES.json').read_bytes())
 captures={p.name:json.loads(p.read_bytes()) for p in op.evidence.glob('verify-*.json')}
 assert len(captures)==2 and all(v['exit_code']==0 and not v['timeout'] for v in captures.values())
 assert all('--verify-artifact' in v['argv'] and '--require-clean-source' in v['argv'] for v in captures.values())
 assert evidence['source']=={'commit':m.SOURCE_HEAD,'tree':m.SOURCE_TREE,'worktree_state':'clean'}
 return {'actual_unchanged_package_verifier_calls':2,'actual_installer_calls':0,'actual_controller_calls':0,'budget_floor_by_role':m.RESERVES,'archive_sizes':{k:v[1] for k,v in m.ARCHIVES.items()}}
record('exact_current_archives_pass_unchanged_verifier',positive)

def tamper():
 packet=out/'tampered-packet';folder=packet/m.PACKAGE_ROOT;folder.mkdir(parents=True)
 for role,(name,size,sha) in m.ARCHIVES.items():
  b=(ROOT/'stage'/m.PACKAGE_ROOT/name).read_bytes()
  if role=='canonical_plugin':b=b[:-1]+bytes([b[-1]^1])
  (folder/name).write_bytes(b)
 op=m.Operation(SOURCE,packet,out/'tampered-result',{'scope':'TEST_ONLY_SOURCE_PACKAGE_INTAKE','installed_routes_disabled':True})
 try:op.prepare()
 except RuntimeError as e:
  assert str(e)=='selected archive identity or reserve differs';assert not list(op.evidence.glob('verify-*.json'))
  return {'refusal':str(e),'original_effects':0,'verifier_calls_before_refusal':0}
 raise AssertionError('changed archive accepted')
record('one_byte_archive_substitution_refused_before_verifier',tamper)

def unchanged_owners():
 def definitions(raw):
  t=ast.parse(raw);d={}
  for node in t.body:
   if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):d[node.name]=ast.dump(node,include_attributes=False)
   elif isinstance(node,ast.ClassDef):
    for f in node.body:
     if isinstance(f,(ast.FunctionDef,ast.AsyncFunctionDef)):d[node.name+'.'+f.name]=ast.dump(f,include_attributes=False)
  return d
 old=definitions((ROOT/'historical/qualify.py').read_text());new=definitions(SCRIPT.read_text());assert old.keys()==new.keys()
 changed=sorted(k for k in old if old[k]!=new[k]);assert changed==['Operation.prepare'],changed
 oldwf=(ROOT/'historical/dg18-source-qualification.yml').read_text();job=oldwf[oldwf.index('  installed-current:\n'):]
 job=job.replace('refs/heads/engineering/pro-dg18-installed-current-20261115','refs/heads/pro/dg18-c11-current-51416-20261120-01').replace('6b353b48b2fc8a6de0c6223f48d341c484c98191',m.SOURCE_HEAD).replace('handoff/pro-executor-results-20261115/dg18-installed-current/qualify.py',m.PACKAGE_ROOT+'/qualify.py')
 newwf=(ROOT/'stage/.github/workflows/dg18-c11-current-51416.yml').read_text();assert newwf[newwf.index('  installed-current:\n'):]==job
 return {'all_definitions':len(old),'changed_definitions':changed,'exact_historical_installed_job_except_three_selected_literals':True,'actions_timeouts_read_only_permissions_unchanged':True}
record('unchanged_runtime_owner_and_workflow_guards',unchanged_owners)
report={'schema':'dg18.current-c11.source-controls.v1','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'SOURCE_CONTROLS_ONLY_NO_ORIGINAL_CONSUMER','production_source_modified_by_tests':False,'test_process_only_patches':['ROUTES=() to exclude every installed/controller call'],'controls':results,'passed':len(results),'original_awards':[]}
(out/'RESULT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps(report,indent=2,sort_keys=True))
