from pathlib import Path, PurePosixPath
import sys,json,hashlib,urllib.request,termios,os,zipfile,stat,datetime
root=Path('/workspace/scratch/530bc07ea12b/dg18-c11-current-actual')
assert root.is_dir()
dest=root/'final';dest.mkdir(mode=0o700)
expected='12cd7e62b12f4b4bb41f173eec13062d15e13e580ade3849e068c7ad80343990'
intent={'artifact_id':14600167086,'run_id':44671501741,'attempt':1,'expected_zip_bytes':284640,'expected_zip_sha256':expected,'network_body_gets_selected':1,'automatic_retry':False,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(dest/'DOWNLOAD_INTENT.json').write_text(json.dumps(intent,indent=2,sort_keys=True)+'\n')
old=termios.tcgetattr(0);new=list(old);new[3]&=~(termios.ECHO|termios.ICANON);new[6]=list(old[6]);new[6][termios.VMIN]=1;new[6][termios.VTIME]=0;termios.tcsetattr(0,termios.TCSANOW,new)
print('READY_FOR_EPHEMERAL_REFERENCE',flush=True)
try:
 frame=sys.stdin.buffer.readline(20000);value=json.loads(frame);url=value.pop('url');assert not value and type(url)is str and url.startswith('https://')
 target=dest/'ARTIFACT.zip';h=hashlib.sha256();count=0
 with urllib.request.urlopen(url,timeout=45)as response,target.open('xb')as f:
  status=response.status
  assert status==200
  while True:
   chunk=response.read(65536)
   if not chunk:break
   count+=len(chunk);assert count<=284640
   f.write(chunk);h.update(chunk)
  f.flush();os.fsync(f.fileno())
 url=None;frame=None
 assert count==284640 and h.hexdigest()==expected
 out=dest/'extracted';out.mkdir(mode=0o700);files={}
 with zipfile.ZipFile(target)as z:
  names=set()
  for item in z.infolist():
   p=PurePosixPath(item.filename);assert not p.is_absolute()and '..'not in p.parts and '\\'not in item.filename and str(p)==item.filename.rstrip('/')and item.filename not in names;names.add(item.filename)
   mode=item.external_attr>>16;assert not stat.S_ISLNK(mode)
   q=out/p
   if item.is_dir():q.mkdir(parents=True,exist_ok=True);continue
   b=z.read(item);assert len(b)==item.file_size
   q.parent.mkdir(parents=True,exist_ok=True);q.open('xb').write(b);files[item.filename]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 receipt=dict(intent,status='COMPLETE_EXACT_ARCHIVE_RECEIVED',actual_http_status=status,actual_zip_bytes=count,actual_zip_sha256=h.hexdigest(),files=files,total_member_bytes=sum(x['bytes']for x in files.values()),url_retained=False)
 (dest/'RECEIPT.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'status':receipt['status'],'zip_bytes':count,'zip_sha256':h.hexdigest(),'files':len(files),'member_bytes':receipt['total_member_bytes']}),flush=True)
except BaseException as e:
 (dest/'ERROR.json').write_text(json.dumps({'type':type(e).__name__,'effect':'RECONCILE_RETAINED_FILES_NO_AUTOMATIC_RETRY','url_retained':False})+'\n')
 print(json.dumps({'error_type':type(e).__name__,'state':'RECONCILE_RETAINED_FILES_NO_AUTOMATIC_RETRY'}),flush=True)
 raise SystemExit(1)
finally:
 termios.tcsetattr(0,termios.TCSANOW,old)
