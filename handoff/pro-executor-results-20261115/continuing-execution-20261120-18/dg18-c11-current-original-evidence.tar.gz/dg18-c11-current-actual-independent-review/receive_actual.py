#!/usr/bin/env python3
"""Independent, offline receiving of completed C11 evidence; no target execution."""
import datetime
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import zipfile

W = Path('/workspace/scratch/530bc07ea12b')
OUT = W / 'dg18-c11-current-actual-independent-review'
ACT = W / 'dg18-c11-current-actual'
E = ACT / 'final/extracted'
PUB = W / 'dg18-c11-current-publication'
PRIOR = W / 'dg18-c11-current-independent-review'
PACK = W / 'dg18-continuing-original-execution'
STAGE = PACK / 'stage'
SOURCE = '51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
TREE = '9c3913ceaa95f3f36b0377fe2dba4a302afcba89'
COMMIT = '019397037b85a379174c77213d9e6700b7d98770'
PUBLICATION_TREE = 'b01b405d4e10a0ae0746f88410ed520298d5e453'
BRANCH = 'pro/dg18-c11-current-51416-20261120-01'
RUN = 44671501741
JOB = 136073294407
ARTIFACT = 14600167086
ZIP_SHA = '12cd7e62b12f4b4bb41f173eec13062d15e13e580ade3849e068c7ad80343990'
PREFIX = 'handoff/pro-executor-results-20261115/dg18-c11-current-51416-20261120'
ROUTES = ['plugin-codex', 'plugin-claude', 'standalone-codex', 'standalone-claude']
SRC = '/home/runner/work/IMPLEMENTAUDIT.md/IMPLEMENTAUDIT.md/qualified-source'
BASE = '/home/runner/work/_temp/dg18-installed-44671501741-1'
NEXT = 'Independently receive actual installed currentness and archive parity before any further operation'
IDENTITY = {'commit': SOURCE, 'tree': TREE, 'worktree_state': 'clean'}
ARCHIVES = {
    'canonical_plugin': ('IMPLEMENTAUDIT.plugin.zip', 588564, '12502ae8c75dfc5127aec7b6c038ee0fe12e191c9976cef3b5545503d64e0aa8', 75),
    'standalone_compatibility': ('IMPLEMENTAUDIT.skill', 583962, '320100fe575bd5ea56a1789953d7b26b6fcb4f8e15aed3f81f6bf4f4ef24808b', 72),
}
FILES = {}
RAW = {}
CHECKS = []
ROUTE_RESULTS = []
COMMANDS = {}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git_hash(kind, raw):
    return hashlib.sha1(kind.encode() + b' ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def phys(s):
    return {k: getattr(s, k) for k in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_mode')}


def read(path):
    path = Path(path)
    if not path.is_absolute():
        raise ValueError('nonabsolute input')
    for parent in path.parents:
        if stat.S_ISLNK(parent.lstat().st_mode):
            raise ValueError('symlink input ancestry: ' + str(path))
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError('nonregular input: ' + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        inside = os.fstat(fd)
        if phys(before) != phys(inside):
            raise ValueError('open identity changed: ' + str(path))
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read()
        after_fd = os.fstat(fd)
    finally:
        os.close(fd)
    after = path.lstat()
    if not (phys(before) == phys(after_fd) == phys(after)) or len(raw) != before.st_size:
        raise ValueError('read identity changed: ' + str(path))
    key = str(path)
    row = {'path': key, 'bytes': len(raw), 'sha256': sha(raw), 'physical': phys(before)}
    if key in FILES and FILES[key] != row:
        raise ValueError('input changed since first read: ' + key)
    FILES[key], RAW[key] = row, raw
    return raw


def js(path):
    return json.loads(read(path))


def fact(raw):
    return {'bytes': len(raw), 'sha256': sha(raw)}


def must(value, label):
    if not value:
        raise ValueError(label)


def done(label, **details):
    CHECKS.append({'check': label, 'status': 'PASS', **details})


def unwrap(value):
    must(not value.get('isError', False), 'provider error')
    sc = value.get('structuredContent', value)
    if isinstance(sc.get('content'), str):
        try:
            return json.loads(sc['content'])
        except json.JSONDecodeError:
            return sc['content']
    return sc


def enum_files(root):
    result = set()
    for path in root.rglob('*'):
        s = path.lstat()
        must(not stat.S_ISLNK(s.st_mode), 'symlink in population')
        if stat.S_ISREG(s.st_mode):
            result.add(path.relative_to(root).as_posix())
        else:
            must(stat.S_ISDIR(s.st_mode), 'special population entry')
    return result


def sealed(root, expected_sha, count, size):
    manifest = js(root / 'MANIFEST.json')
    must(sha(RAW[str(root / 'MANIFEST.json')]) == expected_sha, 'input manifest hash')
    must(manifest['count'] == count and manifest['bytes'] == size, 'manifest census')
    must(len(manifest['files']) == count and len({x['path'] for x in manifest['files']}) == count, 'manifest duplicates')
    for item in manifest['files']:
        must(fact(read(root / item['path'])) == {k: item[k] for k in ('bytes', 'sha256')}, 'sealed member mismatch: ' + item['path'])
    must(sum(x['bytes'] for x in manifest['files']) == size, 'manifest aggregate bytes')
    return manifest


def command(label, argv, cwd):
    data = js(E / (label + '.json'))
    must(data['argv'] == argv and data['cwd'] == cwd, 'actual argv or cwd mismatch: ' + label)
    must(data['exit_code'] == 0 and data['timeout'] is False and data['timeout_descendant_termination'] == 'NOT_TRIGGERED', 'nonterminal command: ' + label)
    must(isinstance(data['elapsed_seconds'], (int, float)) and 0 <= data['elapsed_seconds'] < 120, 'elapsed command bound: ' + label)
    streams = {}
    for stream in ('stdout', 'stderr'):
        raw = read(E / (label + '.' + stream + '.txt'))
        must(fact(raw) == {k: data[stream][k] for k in ('bytes', 'sha256')}, 'stream identity: ' + label)
        must(data[stream]['mode'] in (0o600, 0o644), 'unexpected actual stream mode')
        streams[stream] = raw
    must(label not in COMMANDS, 'duplicate command receive')
    COMMANDS[label] = {'argv': argv, 'cwd': cwd, 'exit_code': 0, 'timeout': False,
                       'stdout': fact(streams['stdout']), 'stderr': fact(streams['stderr'])}
    return streams


def main():
    sealed(PRIOR, '77b3a95ea672f4c9d749b8769d91528ab1d0caae07de7c3d25f1b198aa87e02d', 22, 263600)
    author_manifest = sealed(PACK, 'b4817510cb0a022d85570209bba4e0a164b65f20c26d62c36658295d18f9c3b2', 56, 1446849)
    done('immutable prior independent source review and submitted packet', source_review_members=22, source_packet_members=56)
    contract = read(W / 'dg18-a10-current-51416/ISSUE215_CURRENT_BODY.md').decode()
    must('11. If helper/schema/reference bytes ship, R001E/R0034 isolated-package/install and\n   current-consumer evidence is required; otherwise the leg is `NOT_TRIGGERED`.' in contract, 'original C11 clause')
    done('original C11 contract retained; current leg triggered', original_denominator=14)
    adoption = js(PUB / 'ROOT_OPERATION_ADOPTION.json')
    must(adoption['issuer'] == '/root' and adoption['source'] == SOURCE and adoption['source_tree'] == TREE and adoption['sole_publication_parent'] == SOURCE, 'Root source adoption')
    must(adoption['independent_review_manifest_sha256'] == '77b3a95ea672f4c9d749b8769d91528ab1d0caae07de7c3d25f1b198aa87e02d', 'Root reviewed source binding')
    must(adoption['budget_applicability'] == 'APPLICABLE_EXISTING_V5_RULE_AT_EXACT_CURRENT_SOURCE', 'Root budget applicability')
    must(adoption['branch'] == BRANCH and adoption['operation'] == 'ONE_FIRST_ATTEMPT_FOUR_ROUTE_INSTALLED_CURRENT_EPISODE' and adoption['automatic_retry'] is False, 'Root bounded operation')
    must(adoption['original_C11_award'] is False and adoption['original_denominator'] == 14, 'no source award')
    must(adoption['currentness']['returncode'] == 0, 'Root adoption currentness receipt')
    done('genuine Root source and existing v5 applicability adoption')
    four = js(PUB / 'receipts/FOUR_FILES_AND_COMMIT_READBACK.json')
    commit = unwrap(four['actual_commit_readback'])
    must(commit['sha'] == COMMIT and commit['tree']['sha'] == PUBLICATION_TREE and [x['sha'] for x in commit['parents']] == [SOURCE], 'publication exact sole-parent commit')
    expected_files = adoption['files']
    must(len(expected_files) == 4 and len(four['rows']) == 4, 'four additions only')
    for expected, actual in zip(expected_files, four['rows']):
        must(all(actual[k] == v for k, v in expected.items()) and actual['remote_commit'] == COMMIT and actual['complete_remote_base64_bytes_equal'] is True, 'retained Root complete remote readback')
        raw = read(STAGE / expected['path'])
        must(fact(raw) == {k: expected[k] for k in ('bytes', 'sha256')} and git_hash('blob', raw) == expected['git_blob'], 'publication local bytes join')
    diff = js(PUB / 'receipts/TREE_COMPLETE_DIFF_READBACK.json')
    must(diff['base'] == TREE and diff['tree'] == PUBLICATION_TREE and diff['changed'] == [] and diff['new_leaves'] == diff['base_leaves'] + 4, 'Root tree census')
    must({x[0]: (x[1]['sha'], x[1]['mode']) for x in diff['added']} == {x['path']: (x['git_blob'], x['mode']) for x in expected_files}, 'Root complete tree additions')
    for name, expected in [('TREE_ACTUAL.json', PUBLICATION_TREE), ('COMMIT_ACTUAL.json', COMMIT)]:
        must(unwrap(js(PUB / 'receipts' / name))['sha'] == expected, 'actual publication return')
    done('actual sole-parent publication and complete retained four-file readback', commit=COMMIT, tree=PUBLICATION_TREE)
    launch = js(PUB / 'receipts/LAUNCH_INTENT.json')
    must(launch['args'] == {'repository_full_name': 'theislampill/IMPLEMENTAUDIT.md', 'branch_name': BRANCH, 'sha': COMMIT}, 'launch args')
    must(launch['first_attempt_only'] is True and launch['automatic_retry'] is False, 'launch first attempt')
    must(unwrap(js(PUB / 'receipts/LAUNCH_ACTUAL.json'))['branch'] == BRANCH, 'actual branch creation')
    root_adoption_return = json.loads(launch['root_adoption_actual']['output'])
    must(root_adoption_return['bytes'] == len(RAW[str(PUB / 'ROOT_OPERATION_ADOPTION.json')]) and root_adoption_return['sha256'] == sha(RAW[str(PUB / 'ROOT_OPERATION_ADOPTION.json')]), 'actual adoption return digest')
    branch_readback = js(PUB / 'receipts/LAUNCH_READBACK_AND_RUNS.json')
    ref = unwrap(branch_readback['ref'])
    must(ref['ref'] == 'refs/heads/' + BRANCH and ref['object']['sha'] == COMMIT, 'actual branch readback')
    runs = unwrap(js(PUB / 'receipts/RECOVERED_G0012_FIRST_RUNS.json'))
    must(runs['total_count'] == 1 and len(runs['workflow_runs']) == 1, 'single actual run')
    run = runs['workflow_runs'][0]
    must(run['id'] == RUN and run['run_attempt'] == 1 and run['run_number'] == 1 and run['event'] == 'push' and run['head_sha'] == COMMIT and run['head_branch'] == BRANCH and run['path'] == '.github/workflows/dg18-c11-current-51416.yml', 'actual run identity')
    must(run['status'] == 'completed' and run['conclusion'] == 'success' and run['previous_attempt_url'] is None and run['repository']['full_name'] == 'theislampill/IMPLEMENTAUDIT.md', 'actual first-attempt terminal')
    must(run['head_commit']['tree_id'] == PUBLICATION_TREE, 'run tree identity')
    done('one actual first-attempt push run', run_id=RUN, run_attempt=1)
    bundle = js(ACT / 'ACTUAL_REMOTE_RECEIVING.json')
    for key in ('ACTUAL_JOBS', 'ACTUAL_ARTIFACTS', 'ACTUAL_JOB_LOG_TOOL_RETURN', 'ACTUAL_DOWNLOAD_NATIVE_RETURN'):
        must(bundle[key] == js(ACT / (key + '.json')), 'retained provider/native bundle join')
    jobs = unwrap(bundle['ACTUAL_JOBS'])['jobs']
    must(len(jobs) == 1 and jobs[0]['id'] == JOB and jobs[0]['run_id'] == RUN and jobs[0]['name'] == 'installed-current', 'actual job identity')
    must(jobs[0]['status'] == 'completed' and jobs[0]['conclusion'] == 'success' and len(jobs[0]['steps']) == 11 and all(x['status'] == 'completed' and x['conclusion'] == 'success' for x in jobs[0]['steps']), 'all actual job steps terminal success')
    expected_step_names = ['Set up job', 'Check out exact installed-consumer instructions and retained archives', 'Check out the exact archive source', 'Install the retained packages and initialize fresh actual tasks', 'Read each actual STATE', 'Read each actual ROADMAP', 'Receive actual installed receipts and currentness', 'Retain actual installed-consumer evidence', 'Post Check out the exact archive source', 'Post Check out exact installed-consumer instructions and retained archives', 'Complete job']
    must([x['name'] for x in jobs[0]['steps']] == expected_step_names, 'actual separate step population')
    log_raw = read(ACT / 'ACTUAL_JOB.log')
    must(log_raw.decode() == unwrap(bundle['ACTUAL_JOB_LOG_TOOL_RETURN']), 'full actual job log tool body')
    log = log_raw.decode()
    positions = []
    for step in ('prepare', 'read-state', 'read-roadmap', 'consume'):
        text = 'DG18 actual installed task step completed: ' + step
        must(log.count(text) == 1, 'actual step log uniqueness')
        positions.append(log.index(text))
    must(positions == sorted(positions), 'actual separate read/consume order')
    must('HEAD is now at 0193970' in log and 'HEAD is now at 51416b2' in log, 'actual two checkout completions')
    must('SHA256 digest of uploaded artifact zip is ' + ZIP_SHA in log and 'Artifact ID ' + str(ARTIFACT) in log and 'there will be 289 files uploaded' in log, 'actual upload log digest census')
    done('actual eleven job steps and full provider log; canonical read order', job_id=JOB, log_bytes=len(log_raw))
    artifacts = unwrap(bundle['ACTUAL_ARTIFACTS'])
    must(artifacts['total_count'] == 1 and len(artifacts['artifacts']) == 1, 'actual artifact census')
    artifact = artifacts['artifacts'][0]
    must(artifact['id'] == ARTIFACT and artifact['size_in_bytes'] == 284640 and artifact['digest'] == 'sha256:' + ZIP_SHA and artifact['expired'] is False, 'provider artifact identity')
    must(artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == COMMIT and artifact['workflow_run']['head_branch'] == BRANCH, 'artifact run/source binding')
    receipt = js(ACT / 'final/RECEIPT.json')
    must(receipt['status'] == 'COMPLETE_EXACT_ARCHIVE_RECEIVED' and receipt['actual_http_status'] == 200 and receipt['run_id'] == RUN and receipt['artifact_id'] == ARTIFACT and receipt['attempt'] == 1, 'Root completed download')
    must(receipt['network_body_gets_selected'] == 1 and receipt['automatic_retry'] is False, 'Root one-get boundary')
    native = bundle['ACTUAL_DOWNLOAD_NATIVE_RETURN']
    must(native['chunk_id'] == 'b175e4' and native['exit_code'] == 0 and json.loads(native['output']) == {'status': 'COMPLETE_EXACT_ARCHIVE_RECEIVED', 'zip_bytes': 284640, 'zip_sha256': ZIP_SHA, 'files': 289, 'member_bytes': 580016}, 'actual one-get native return')
    zipraw = read(ACT / 'final/ARTIFACT.zip')
    must(len(zipraw) == 284640 and sha(zipraw) == ZIP_SHA, 'exact downloaded ZIP')
    names = set()
    members = {}
    with zipfile.ZipFile(io.BytesIO(zipraw)) as z:
        must(z.testzip() is None, 'artifact full CRC')
        for info in z.infolist():
            name = info.filename
            parts = PurePosixPath(name).parts
            must(name not in names and not name.startswith('/') and '\\' not in name and all(x not in ('', '.', '..') for x in parts), 'unsafe/duplicate member')
            must(not info.is_dir() and stat.S_IFMT(info.external_attr >> 16) in (0, stat.S_IFREG) and not info.flag_bits & 1, 'nonregular or encrypted ZIP member')
            raw = z.read(info)
            must(raw == read(E / name), 'full artifact/extracted byte mismatch')
            names.add(name)
            members[name] = fact(raw)
    must(len(names) == 289 and sum(x['bytes'] for x in members.values()) == 580016, 'full artifact census')
    must(members == receipt['files'] and names == enum_files(E), 'full Root extraction/member receipt census')
    done('complete artifact CRC, safe paths and exact extracted file population', files=289, bytes=580016, zip_bytes=284640, zip_sha256=ZIP_SHA)
    host = js(E / 'HOST.json')
    must(host['repository'] == 'theislampill/IMPLEMENTAUDIT.md' and host['branch'] == 'refs/heads/' + BRANCH and host['run_id'] == str(RUN) and host['attempt'] == '1' and host['workflow_commit'] == COMMIT and host['scope'] == 'ORDINARY_INSTALLED_SOURCE_CONSUMERS_ONLY', 'host source and ordinary scope')
    must(set(host['tools']) == {'python3', 'bash', 'git'} and host['python_version'] == [3, 12, 3], 'host system tool census')
    for tool, path in [('python3', '/usr/bin/python3.12'), ('bash', '/usr/bin/bash'), ('git', '/usr/bin/git')]:
        entry = host['tools'][tool]
        must(entry['path'] == path and entry['mode'] == 0o755 and entry['bytes'] > 0 and re.fullmatch('[0-9a-f]{64}', entry['sha256']), 'host tool record')
    done('actual hosted context bound to source-reviewed system-custody guard')
    for when in ('before', 'after'):
        streams = command('source-' + when, ['/usr/bin/git', 'rev-parse', 'HEAD', 'HEAD^{tree}'], SRC)
        must(streams['stdout'] == (SOURCE + '\n' + TREE + '\n').encode() and streams['stderr'] == b'', 'actual source identity')
        clean = command('source-' + when + '-clean', ['/usr/bin/git', 'status', '--porcelain=v1', '--untracked-files=all'], SRC)
        must(clean['stdout'] == clean['stderr'] == b'', 'actual source cleanliness')
    done('exact source HEAD/tree and complete tracked/untracked clean before and after')
    package = js(E / 'PACKAGES.json')
    must(package['source'] == IDENTITY and package['archive_transport'] == 'EXACT_PUBLISHED_GIT_BLOBS' and package['rebuilt'] is False and package['native_discovery'] is False, 'actual package source/transport')
    must(package['cap_bytes'] == 589824 and package['required_reserve_by_role'] == {'canonical_plugin': 1240, 'standalone_compatibility': 2000}, 'unchanged actual budget')
    must(package['budget_approval'] == ['package/budgets/pr255-v5-owner-approval.md', 6571, '9cce88d8d9822c42fcaa485ffbb8a82cf9b53256c93ca926969448d3affc1538'] and package['package_contract'] == ['package/implementaudit-package.json', 5617, 'c4844781b4063e02f8fbe33dea67937d3efb3c913f726583c10a0d41387f9c2e'], 'exact existing approval/contract')
    archive_members = {}
    checksums = b''
    for role, (name, size, digest, count) in ARCHIVES.items():
        raw = read(STAGE / PREFIX / name)
        must(len(raw) == size and sha(raw) == digest, 'selected source archive')
        must(package['artifacts'][name] == {'bytes': size, 'sha256': digest, 'mode': 0o600}, 'actual archive fact')
        streams = command('verify-' + role, ['/usr/bin/python3', '-I', '-B', SRC + '/scripts/package-contract.py', '--verify-artifact', role, BASE + '/packages/' + name, '--require-clean-source'], SRC)
        must(streams['stdout'] == b'package-contract: ok\n' and streams['stderr'] == b'', 'actual original package verifier result')
        expect = {}
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            must(z.testzip() is None, 'package CRC')
            for info in z.infolist():
                data = z.read(info)
                must(info.filename not in expect, 'duplicate package member')
                expect[info.filename] = {**fact(data), 'mode': (info.external_attr >> 16) & 0o777}
        must(len(expect) == count, 'selected package member count')
        archive_members[role] = expect
        checksums += ('sha256 ' + digest + ' ' + name + '\n').encode()
    must(package['artifacts']['CHECKSUMS.txt'] == {**fact(checksums), 'mode': 0o600} and len(package['artifacts']) == 3, 'complete actual package transport population')
    done('both unchanged original package verifiers; exact v5 budgets and archive populations', plugin_members=75, standalone_members=72, plugin_reserve=1260, standalone_reserve=5862)
    labels = ['install', 'init', 'add', 'baseline', 'claim', 'author', 'inspect', 'activate', 'read-state', 'read-roadmap', 'resume', 'verify', 'current', 'controller', 'refs-before', 'receipt', 'current-readback', 'refs-after']
    docnames = {'.claimed', '.controller', 'STATE.md', 'ROADMAP.md', 'PROTOCOL.md', 'THINKING.md', 'sidecars.md', 'tools.md', 'context.md', 'phases/phase-1.md'}
    expected_names = {'HOST.json', 'PACKAGES.json', 'RESULT.json'}
    for label in ('source-before', 'source-before-clean', 'source-after', 'source-after-clean', 'verify-canonical_plugin', 'verify-standalone_compatibility'):
        expected_names.update(label + s for s in ('.json', '.stdout.txt', '.stderr.txt'))
    for route in ROUTES:
        base = BASE + '/' + route
        subject = base + '/subject'
        host_root = base + '/host'
        installed = host_root + ('/plugins/implementaudit' if route.startswith('plugin-') else '/skills/implementaudit')
        skill = installed + ('/skills/implementaudit' if route.startswith('plugin-') else '')
        owner = ['/usr/bin/bash', skill + '/scripts/claim-run.sh']
        controller = 'dg18-installed-' + str(RUN) + '-1-' + route
        role = 'canonical_plugin' if route.startswith('plugin-') else 'standalone_compatibility'
        task = js(E / (route + '-TASK.json'))
        result = js(E / (route + '-RESULT.json'))
        pending, active, relative = task['initialization'], task['activation'], task['relative']
        must(task['source'] == IDENTITY and task['controller'] == controller and task['installed_skill'] == skill, 'actual task identity ' + route)
        must(re.fullmatch(r'\.IMPLEMENTAUDIT/runs/dg18-installed-current-consumer-[A-Za-z0-9]{6}', relative), 'actual fresh root shape')
        root = subject + '/' + relative
        purpose = 'Receive the exact DG18 installed package through ' + route + ' and establish its actual fresh task currentness before independent receiving.'
        installer_args = ['/usr/bin/bash', SRC + '/scripts/install-plugin-from-release.sh', '--asset', BASE + '/packages/IMPLEMENTAUDIT.plugin.zip', '--checksum', BASE + '/packages/CHECKSUMS.txt', '--host', route.split('-')[1], '--host-root', host_root] if route.startswith('plugin-') else ['/usr/bin/bash', SRC + '/scripts/install-' + route.split('-')[1] + '-from-release.sh', '--asset', BASE + '/packages/IMPLEMENTAUDIT.skill', '--checksum', BASE + '/packages/CHECKSUMS.txt'] + (['--codex-home', host_root] if route.endswith('codex') else ['--claude-skills-dir', installed])
        install = command(route + '-install', installer_args, SRC)
        must(install['stderr'] == b'' and 'package-contract: ok' in install['stdout'].decode(), 'actual installer completion')
        must(js(E / (route + '-INSTALLED_BEFORE.json')) == archive_members[role], 'complete installed archive parity ' + route)
        command(route + '-init', ['/usr/bin/git', '-c', 'init.templateDir=', 'init', '-q', '-b', 'qualification'], subject)
        command(route + '-add', ['/usr/bin/git', 'add', '--', 'TASK.md', '.gitignore'], subject)
        command(route + '-baseline', ['/usr/bin/git', '-c', 'user.name=PRO-EXECUTOR-01', '-c', 'user.email=pro-executor@example.invalid', '-c', 'commit.gpgsign=false', '-c', 'core.hooksPath=/dev/null', 'commit', '-qm', 'Define actual disposable DG18 installed-consumer task'], subject)
        claim = command(route + '-claim', owner + ['--controller', controller, 'DG18 installed current consumer'], subject)
        must(claim['stdout'].decode().strip() == relative and 'initialization pending; token=' + pending['initialization_token'] in claim['stderr'].decode(), 'actual installed claim')
        author = command(route + '-author', ['/usr/bin/python3', '-I', '-S', '-B', SRC + '/fixtures/controller-initialization/author_checkpoint.py', '--repo', subject, '--run-root', relative, '--source', SRC, '--purpose', purpose, '--next-action', NEXT], subject)
        inspect = command(route + '-inspect', owner + ['--inspect-controller-initialization', controller, '--run-root', relative], subject)
        activate = command(route + '-activate', owner + ['--activate-controller', controller, '--run-root', relative, '--expected-initialization', pending['initialization_token']], subject)
        must(json.loads(inspect['stdout']) == pending and json.loads(activate['stdout']) == active, 'actual init/activation stdout join')
        must(pending['controller'] == controller and pending['run_root'] == relative and pending['missing_files'] == [] and pending['predecessor_kind'] == 'NONE' and pending['current_controller_oid'] is None and pending['binding_record_oid'] is None and pending['authority_ceiling'] == 'EVIDENCE_ONLY_NO_EXECUTION_OR_CONTINUITY', 'fresh pending owner state')
        must(active['status'] == 'BOUND_ELIGIBLE_FOR_NORMAL_CURRENTNESS' and active['authority_ceiling'] == 'ELIGIBLE_FOR_NORMAL_CURRENTNESS_ONLY' and active['initialization_token'] == pending['initialization_token'] and active['structural_validation'] == 'EXACT_CONTENT_EXISTING_FULL_VALIDATOR', 'actual bound eligibility')
        docmap = {x['path']: {k: x[k] for k in ('bytes', 'sha256', 'mode')} for x in active['run_population']['files']}
        must(active['run_population']['directories'] == ['.', 'phases'] and docmap == task['documents'] and set(docmap) == docnames, 'complete initialization/run document census')
        runtime = E / (route + '-runtime')
        must(enum_files(runtime) == docnames, 'complete closing runtime population')
        for name, row in docmap.items():
            must(fact(read(runtime / name)) == {k: row[k] for k in ('bytes', 'sha256')}, 'closing bytes differ from initialization')
        authored = json.loads(author['stdout'])
        must(authored == {name: docmap[name]['sha256'] for name in docnames - {'.claimed', '.controller'}}, 'complete exact authored checkpoint')
        for role_name, label in [('STATE', 'read-state'), ('ROADMAP', 'read-roadmap')]:
            read_stream = command(route + '-' + label, ['/usr/bin/cat', root + '/' + role_name + '.md'], subject)
            must(read_stream['stdout'] == read(runtime / (role_name + '.md')) and read_stream['stderr'] == b'', 'separate actual complete document read')
        token = result['receipt_token']
        must(re.fullmatch('refs/implementaudit/continuity-receipts/' + controller + r'/G0001@[0-9a-f]{40}', token), 'actual receipt shape')
        for label, args in [('resume', ['--resume-controller', controller, '--boundary', 'new-session', '--epoch', 'G0001']), ('verify', ['--verify-resume-receipt', token]), ('current', ['--require-current-continuity', controller]), ('current-readback', ['--require-current-continuity', controller])]:
            stream = command(route + '-' + label, owner + args, subject)
            must(stream['stdout'] == (token + '\n').encode() and stream['stderr'] == b'', 'actual installed receipt/currentness ' + label)
        controller_out = command(route + '-controller', owner + ['--current-controller', controller], subject)
        expected_controller = '\t'.join([controller, subject, root, pending['claim_id']])
        must(controller_out['stdout'] == (expected_controller + '\n').encode() and result['controller_readback'] == expected_controller, 'actual controller root/claim readback')
        refs_argv = ['/usr/bin/git', 'for-each-ref', '--format=%(refname)\t%(objectname)']
        before_refs = command(route + '-refs-before', refs_argv, subject)
        after_refs = command(route + '-refs-after', refs_argv, subject)
        must(before_refs == after_refs, 'closing actual refs unchanged')
        refrows = [line.split('\t') for line in before_refs['stdout'].decode().splitlines()]
        must(len(refrows) == 5 and len({x[0] for x in refrows}) == 5, 'complete actual ref census')
        refs = dict(refrows)
        iref, ioid = pending['initialization_token'].rsplit('@', 1)
        rref, roid = token.rsplit('@', 1)
        must(refs == {'refs/heads/qualification': pending['prepared_source_head'], rref: roid, iref: ioid,
                      'refs/implementaudit/controller-initialization-bindings/' + controller + '/' + pending['claim_id']: active['binding_record_oid'],
                      'refs/implementaudit/controllers/' + controller: active['controller_oid']}, 'exact ref/object joins')
        receipt_out = command(route + '-receipt', ['/usr/bin/git', 'cat-file', 'blob', roid], subject)
        raw_receipt = receipt_out['stdout']
        must(git_hash('blob', raw_receipt) == roid and receipt_out['stderr'] == b'', 'actual raw receipt Git object recomputation')
        fields = raw_receipt.decode().rstrip('\n').split('\t')
        subject_task = ('# Actual DG18 installed consumer task\n\n' + purpose + '\n\nProduct source: ' + SOURCE + '.\nNo N1, host compaction, authentic OR, accepting C02 or W-FULL operation is asserted.\n').encode()
        baseline_tree_body = b''
        for name, body in [('.gitignore', b'.IMPLEMENTAUDIT/\n'), ('TASK.md', subject_task)]:
            baseline_tree_body += b'100644 ' + name.encode() + b'\0' + bytes.fromhex(git_hash('blob', body))
        baseline_tree = git_hash('tree', baseline_tree_body)
        expected_fields = ['implementaudit.continuity-receipt.v2', controller, active['controller_oid'], pending['claim_id'], pending['prepared_source_head'], baseline_tree, docmap['STATE.md']['sha256'], docmap['ROADMAP.md']['sha256'], 'none', 'new-session', 'G0001', NEXT]
        must(fields == expected_fields, 'receipt exact 12-field binding and subject tree')
        state, roadmap = read(runtime / 'STATE.md').decode(), read(runtime / 'ROADMAP.md').decode()
        must('Current epoch: G0001' in state and '| Next action | ' + NEXT + ' |' in state and purpose in state and purpose in roadmap and '`' + pending['prepared_source_head'] + '` / `' + baseline_tree + '`' in state, 'real checkpoint scope/epoch/source/next action')
        claim_text = read(runtime / '.claimed').decode()
        claim_fields = dict(x.split('=', 1) for x in claim_text.splitlines())
        must(claim_fields['claim_id'] == pending['claim_id'] and claim_fields['repo_root'] == subject and claim_fields['run_root'] == relative and claim_fields['schema'] == 'implementaudit.run-claim.v2', 'closing actual claim marker')
        must(read(runtime / '.controller') == ('controller_id=' + controller + '\n').encode(), 'closing actual controller marker')
        must(result == {'route': route, 'controller_readback': expected_controller, 'receipt_token': token, 'installed_archive_parity': True, 'task_readback_unchanged': True, 'refs_readback_unchanged': True}, 'route success only after unchanged production closing guards')
        expected_names.update(route + '-' + label + suffix for label in labels for suffix in ('.json', '.stdout.txt', '.stderr.txt'))
        expected_names.update(route + '-' + label + '.json' for label in ('TASK', 'RESULT', 'INSTALLED_BEFORE'))
        expected_names.update(route + '-runtime/' + name for name in docnames)
        ROUTE_RESULTS.append({'route': route, 'receipt_token': token, 'receipt_git_oid_recomputed': roid,
                              'installed_member_count': len(archive_members[role]), 'documents': 10,
                              'command_records': 18, 'refs': 5, 'subject_tree_recomputed': baseline_tree,
                              'controller_oid': active['controller_oid'], 'claim_id': pending['claim_id'],
                              'state_sha256': docmap['STATE.md']['sha256'], 'roadmap_sha256': docmap['ROADMAP.md']['sha256'],
                              'status': 'ACTUAL_COMPLETE_ORIGINAL_INSTALLED_CURRENT_ROUTE_RECEIVED'})
        done('complete original installed-runtime route: ' + route, commands=18, documents=10, refs=5, installed_members=len(archive_members[role]))
    must(names == expected_names and len(COMMANDS) == 78, 'complete expected successful evidence population without failures/extras')
    result = js(E / 'RESULT.json')
    must(result['source'] == IDENTITY and result['host'] == host and result['routes'] == [js(E / (route + '-RESULT.json')) for route in ROUTES] and result['status'] == 'ACTUAL_INSTALLED_CURRENT_CONSUMERS_RECORDED', 'complete actual result joins')
    must(result['N1'] == 'LOST_UNKNOWN_UNCONSUMED' and result['criterion5_exception_approved'] is False and result['original_DG18_acceptance'] is False and result['model_turns'] == 0 and result['package_builds'] == 0 and result['protected_operations'] == 0 and result['native_host_discovery'] is False and result['independent_receiving'] == 'PENDING_ROOT_REVIEW', 'original claim ceilings preserved')
    done('78 real command records, all stdout/stderr and full 289-member successful terminal population; no synthetic award')
    for path in list(FILES):
        read(path)
    must(enum_files(E) == names, 'closing evidence population changed')
    done('complete closing physical-identity and byte rereads stable', files=len(FILES))
    return {'status': 'PASS', 'recommendation': 'ACCEPT_ORIGINAL_C11_AT_EXACT_CURRENT_51416_SCOPE',
            'authority': 'NONE', 'reviewer': '/root/dg18_c11_independent_review',
            'original_denominator': 14, 'run_id': RUN, 'run_attempt': 1, 'job_id': JOB,
            'artifact_id': ARTIFACT, 'artifact_zip_sha256': ZIP_SHA, 'publication_commit': COMMIT,
            'product_commit': SOURCE, 'product_tree': TREE, 'routes': ROUTE_RESULTS,
            'commands': COMMANDS, 'checks': CHECKS, 'inputs': sorted(FILES.values(), key=lambda x: x['path']),
            'artifact_population': members, 'check_count': len(CHECKS), 'input_files': len(FILES),
            'target_execution_by_reviewer': False, 'provider_calls_by_reviewer': 0,
            'limitations': ['Retained provider results and Root publication readbacks received locally; no independent remote ref refresh',
                'Host tool UID/ancestry and closing installed parity enforced by exact source-reviewed production helper; no live runner access after termination',
                'Claude standalone remains its explicit file-copy compatibility route, with no native Desktop import or host discovery claim',
                'Original current C11 scope only; no OR/C02/N1/native Stop-session/whole DG18 transfer']}


if __name__ == '__main__':
    result = None
    try:
        result = main()
    except Exception as error:
        result = {'status': 'REVIEW_CHECK_FAILED', 'type': type(error).__name__, 'reason': str(error),
                  'checks_completed': CHECKS, 'inputs': sorted(FILES.values(), key=lambda x: x['path']),
                  'target_execution_by_reviewer': False, 'provider_calls_by_reviewer': 0}
    result['observed_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    raw = (json.dumps(result, indent=2, sort_keys=True) + '\n').encode()
    with (OUT / 'VERIFICATION.json').open('xb') as f:
        f.write(raw)
    print(json.dumps({k: result[k] for k in ('status', 'recommendation', 'reason', 'check_count', 'input_files') if k in result} | {'verification_bytes': len(raw), 'verification_sha256': sha(raw)}))
    sys.exit(0 if result['status'] == 'PASS' else 1)
