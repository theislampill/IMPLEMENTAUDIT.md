from pathlib import Path
import ast, datetime, difflib, hashlib, json, os, stat

BASE = Path('/workspace/scratch/530bc07ea12b/dg18-continuing-original-execution')
OUT = Path('/workspace/scratch/530bc07ea12b/dg18-c11-current-independent-review')
SOURCE = Path('/workspace/scratch/530bc07ea12b/implementaudit')
PIN = 'b4817510cb0a022d85570209bba4e0a164b65f20c26d62c36658295d18f9c3b2'
HELPER = 'stage/handoff/pro-executor-results-20261115/dg18-c11-current-51416-20261120/qualify.py'
WORKFLOW = 'stage/.github/workflows/dg18-c11-current-51416.yml'
reads = {}
checks = []

def identity(s):
    return {k: getattr(s, 'st_' + k) for k in ('dev', 'ino', 'mode', 'uid', 'gid', 'nlink', 'size', 'mtime_ns', 'ctime_ns')}

def body(p):
    p = Path(p)
    before = p.lstat()
    assert stat.S_ISREG(before.st_mode), str(p)
    fd = os.open(p, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        opened = os.fstat(fd)
        assert identity(before) == identity(opened)
        with os.fdopen(fd, 'rb', closefd=False) as f:
            raw = f.read()
        assert identity(os.fstat(fd)) == identity(before)
    finally:
        os.close(fd)
    assert identity(p.lstat()) == identity(before)
    current = {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'identity': identity(before)}
    if str(p) in reads:
        assert reads[str(p)] == current
    reads[str(p)] = current
    return raw

def load(p):
    return json.loads(body(p))

def check(name, value, detail=None):
    assert value, name
    checks.append({'name': name, 'status': 'PASS', 'detail': detail})

def descriptors(root, rows):
    assert len({r['path'] for r in rows}) == len(rows)
    for row in rows:
        path = Path(row['path'])
        assert not path.is_absolute() and '..' not in path.parts
        raw = body(root / path)
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'], str(path)

def definitions(raw):
    result = {}
    tree = ast.parse(raw)
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            result[node.name] = node
        if isinstance(node, ast.ClassDef):
            for f in node.body:
                if isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    result[node.name + '.' + f.name] = f
    return tree, result

def dump(node):
    return ast.dump(node, include_attributes=False)

raw_manifest = body(BASE / 'MANIFEST.json')
check('exact_manifest_pin', len(raw_manifest) == 11826 and hashlib.sha256(raw_manifest).hexdigest() == PIN)
manifest = json.loads(raw_manifest)
descriptors(BASE, manifest['files'])
check('selected_56_member_population', len(manifest['files']) == manifest['count'] == 56 and sum(x['bytes'] for x in manifest['files']) == manifest['bytes'] == 1446849)
for row in manifest['external_evidence']:
    raw = body(row['path'])
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
check('three_external_evidence_bindings', len(manifest['external_evidence']) == 3)
controls = load(BASE / 'CONTROL_POPULATION.json')
descriptors(BASE, controls['files'])
actual_controls = sorted(str(p.relative_to(BASE)) for name in ('source-controls', 'source-controls-r2') for p in (BASE / name).rglob('*') if p.is_file())
check('exact_control_population', actual_controls == sorted(x['path'] for x in controls['files']) and controls['count'] == 34 and controls['bytes'] == 2353726)
check('no_original_effect_claim_in_source_packet', manifest['original_awards'] == [] and manifest['original_execution_issued'] is False and manifest['authority'] == 'NONE')

old_raw = body(BASE / 'historical/qualify.py')
new_raw = body(BASE / HELPER)
old_tree, old = definitions(old_raw)
new_tree, new = definitions(new_raw)
changed = sorted(k for k in old if dump(old[k]) != dump(new[k]))
check('complete_definition_census_18', old.keys() == new.keys() and len(old) == 18)
check('only_prepare_function_changed', changed == ['Operation.prepare'], changed)
check('prepare_prefix_unchanged', [dump(x) for x in old['Operation.prepare'].body[:5]] == [dump(x) for x in new['Operation.prepare'].body[:5]])
check('prepare_original_installer_and_owner_loop_unchanged', dump(old['Operation.prepare'].body[-1]) == dump(new['Operation.prepare'].body[-1]))
check('prepare_checksum_generation_unchanged', dump(old['Operation.prepare'].body[-3]) == dump(new['Operation.prepare'].body[-3]))
selected = {'SOURCE_HEAD', 'SOURCE_TREE', 'BRANCH', 'TRANSPORT', 'TRANSPORT_BYTES', 'TRANSPORT_SHA', 'PACKAGE_ROOT', 'RESERVES', 'BUDGET_APPROVAL', 'PACKAGE_CONTRACT', 'ARCHIVES'}
def remainder(tree):
    result = []
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id in selected:
            continue
        if isinstance(node, ast.ClassDef):
            node.body = [x for x in node.body if not isinstance(x, ast.FunctionDef) or x.name != 'prepare']
        result.append(dump(node))
    return result
check('all_other_module_semantics_unchanged', remainder(old_tree) == remainder(new_tree))
constants = {n.targets[0].id: ast.literal_eval(n.value) for n in ast.parse(new_raw).body if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name)}
check('four_original_routes_in_production', constants['ROUTES'] == ('plugin-codex', 'plugin-claude', 'standalone-codex', 'standalone-claude'))
check('no_test_hook_in_production', b'TEST_ONLY' not in new_raw and b'ROUTES=()' not in new_raw)
check('source_literal_binding', constants['SOURCE_HEAD'] == '51416b2f156b341c4a5f09029e2c6ceb5b30b1e7' and constants['SOURCE_TREE'] == '9c3913ceaa95f3f36b0377fe2dba4a302afcba89')
patch = ''.join(difflib.unified_diff(old_raw.decode().splitlines(True), new_raw.decode().splitlines(True), fromfile='historical/qualify.py', tofile='prospective/qualify.py')).encode()
check('exact_declared_source_diff', patch == body(BASE / 'SOURCE_DELTA.patch'))

old_workflow = body(BASE / 'historical/dg18-source-qualification.yml').decode()
new_workflow = body(BASE / WORKFLOW).decode()
job = old_workflow[old_workflow.index('  installed-current:\n'):]
job = job.replace('refs/heads/engineering/pro-dg18-installed-current-20261115', constants['BRANCH']).replace('6b353b48b2fc8a6de0c6223f48d341c484c98191', constants['SOURCE_HEAD']).replace('handoff/pro-executor-results-20261115/dg18-installed-current/qualify.py', constants['PACKAGE_ROOT'] + '/qualify.py')
check('exact_original_installed_job_with_three_selected_literal_changes', job == new_workflow[new_workflow.index('  installed-current:\n'):])
check('workflow_single_selected_job', new_workflow.count('\n  installed-current:') == 1 and '\n  c02-' not in new_workflow and '\n  source-' not in new_workflow)
check('read_only_permission_and_non_canceling_concurrency', 'permissions:\n  contents: read\n' in new_workflow and '  cancel-in-progress: false\n' in new_workflow)
check('exact_first_attempt_push_scope', "github.run_attempt == '1'" in new_workflow and "github.event_name == 'push'" in new_workflow and '    branches: [pro/dg18-c11-current-51416-20261120-01]' in new_workflow)
check('literal_packet_depth_matches_main', len(Path(constants['PACKAGE_ROOT'] + '/qualify.py').parts) == 4)
check('separate_state_roadmap_consume_order', new_workflow.index('--step read-state') < new_workflow.index('--step read-roadmap') < new_workflow.index('--step consume'))
check('pinned_actions_and_always_hidden_evidence', new_workflow.count('actions/checkout@11d5960a326750d5838078e36cf38b85af677262') == 2 and 'actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02' in new_workflow and 'if: always()' in new_workflow and 'include-hidden-files: true' in new_workflow)
check('bounded_system_host', 'runs-on: ubuntu-24.04' in new_workflow and 'timeout-minutes: 15' in new_workflow)

for stored, historical, kind in [('receiving/HISTORICAL_QUALIFY_FETCH_TOOL_RETURN.json', 'historical/qualify.py', 'blob'), ('receiving/HISTORICAL_WORKFLOW_FETCH_TOOL_RETURN.json', 'historical/dg18-source-qualification.yml', 'blob')]:
    value = load(BASE / stored)
    raw = body(BASE / historical)
    assert not value['isError'] and value['structuredContent']['content'].encode() == raw
    oid = hashlib.sha1(kind.encode() + b' ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    assert value['structuredContent']['url'].endswith('/' + oid)
check('exact_historical_provider_bodies_received', True)
op = load(BASE / 'SOURCE_OPERATION.json')
for row in op['files']:
    raw = body(BASE / 'stage' / row['path'])
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == row['git_blob']
check('four_publication_files_and_two_reused_blobs', len(op['files']) == 4 and sum(x['reuse_existing_git_blob'] for x in op['files']) == 2)
check('selected_parent_and_current_source_scope', op['preferred_parent'] == constants['SOURCE_HEAD'] and op['product_commit'] == constants['SOURCE_HEAD'] and op['product_tree'] == constants['SOURCE_TREE'])

green = load(BASE / 'receiving/ACTUAL_SOURCE_CONTROL_RETURN.json')
check('actual_green_transcription_joins_exact_result_bytes', green['actual_return']['chunk_id'] == '76998a' and green['actual_return']['exit_code'] == 0 and green['actual_return']['output'].encode() == body(BASE / 'source-controls-r2/RESULT.json'))
result = load(BASE / 'source-controls-r2/RESULT.json')
check('four_bounded_source_controls_passed', result['passed'] == 4 and all(x['status'] == 'PASS' for x in result['controls']))
check('source_control_scope_explicit_no_original_routes', result['scope'] == 'SOURCE_CONTROLS_ONLY_NO_ORIGINAL_CONSUMER' and result['original_awards'] == [] and result['test_process_only_patches'] == ['ROUTES=() to exclude every installed/controller call'])
captures = []
for p in sorted((BASE / 'source-controls-r2/positive/evidence').glob('verify-*.json')):
    value = load(p)
    assert value['exit_code'] == 0 and value['timeout'] is False and '--verify-artifact' in value['argv'] and '--require-clean-source' in value['argv']
    for kind in ('stdout', 'stderr'):
        raw = body(p.with_name(p.stem + '.' + kind + '.txt'))
        assert len(raw) == value[kind]['bytes'] and hashlib.sha256(raw).hexdigest() == value[kind]['sha256']
    captures.append(value)
check('two_complete_actual_package_verifier_captures', len(captures) == 2 and {x['argv'][5] for x in captures} == {'canonical_plugin', 'standalone_compatibility'})
tampered = BASE / 'source-controls-r2/tampered-result/evidence'
check('tampered_packet_refused_before_verifier', not list(tampered.glob('verify-*.json')) and len([x for x in result['controls'] if x['name'] == 'one_byte_archive_substitution_refused_before_verifier' and x['status'] == 'PASS']) == 1)
red = load(BASE / 'receiving/ACTUAL_RED_TOOL_RETURN_TRANSCRIPTION.json')
check('original_source_control_red_retained', red['actual_return']['chunk_id'] == '7e2351' and red['actual_return']['exit_code'] == 1 and "contract['budget_revision'] == 5" in red['actual_return']['output'] and b"contract['budget_revision'] == 5" in body(BASE / 'controls-red/qualify.py'))
check('no_red_installer_or_controller_effect', not list((BASE / 'source-controls/positive').glob('plugin-*')) and not list((BASE / 'source-controls/positive/evidence').glob('verify-*.json')))
seal_return = load(BASE / 'SEAL_ACTUAL_TOOL_RETURN.json')
sealed = json.loads(seal_return['output'])
check('actual_author_seal_return', seal_return['chunk_id'] == '45de1d' and seal_return['exit_code'] == 0 and sealed['manifest_sha256'] == PIN and sealed['selected_files'] == 56 and sealed['selected_bytes'] == 1446849)

issue_path = Path('/workspace/scratch/530bc07ea12b/dg18-a10-current-51416/ISSUE215_CURRENT_BODY.md')
issue = body(issue_path).decode()
check('original_criterion_11_body_received', '11. If helper/schema/reference bytes ship, R001E/R0034 isolated-package/install and\n   current-consumer evidence is required; otherwise the leg is `NOT_TRIGGERED`.' in issue)
for p in list(reads):
    body(p)
check('closing_all_selected_reads_unchanged', True, {'files': len(reads), 'integer_safe_stat_fields': True})
report = {'schema': 'dg18.current-c11.independent-source-receiving.v1', 'authority': 'NONE', 'reviewer': '/root/dg18_c11_independent_review',
    'observed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source_manifest_sha256': PIN,
    'checks': checks, 'passed': len(checks), 'reads': list(reads.values()), 'target_import_or_execution': False,
    'original_controller_installer_provider_operations': 0, 'control_reruns': 0, 'original_awards': [],
    'boundary': 'SOURCE_READINESS_ONLY; actual Root applicability, exact source publication and four hosted installed-current episodes plus independent receiving remain required'}
OUT.mkdir(exist_ok=True)
raw = (json.dumps(report, indent=2, sort_keys=True) + '\n').encode()
with (OUT / 'SOURCE_VERIFICATION.json').open('xb') as f:
    f.write(raw)
print(json.dumps({'passed': len(checks), 'files': len(reads), 'verification_bytes': len(raw), 'verification_sha256': hashlib.sha256(raw).hexdigest(), 'authority': 'NONE', 'original_awards': []}, sort_keys=True))
