# DG18 C11 package and budget mechanical subreview

**Finding: no mechanical package or altered-intake defect found within this bounded source-only scope.** This is ordinary engineering receiving for `/root/dg18_c11_independent_review`, not a formal `audit-assess` child route and not an acceptance, currentness, publication, release, readiness-authority or closure decision. Original denominator **14** is preserved; original awards from this subreview are **zero**. Historical budget RED evidence remains RED at its original scope.

## Bound inputs and actual checks

Input: `/workspace/scratch/530bc07ea12b/dg18-continuing-original-execution/MANIFEST.json`, SHA-256 `b4817510cb0a022d85570209bba4e0a164b65f20c26d62c36658295d18f9c3b2`.

Independent reads verified all 56 manifest entries, their 1,446,849 total bytes, all three external-evidence identities, and all 34 entries of `CONTROL_POPULATION.json`. Packet files and the manifest were rechecked at the end without mismatch. These identity checks do not adopt every prose claim in the packet.

The successful independent checker returned actual terminal **42810a / exit 0**, with `errors: []`. Its complete actual tool return is `ACTUAL_OFFLINE_TOOL_RETURN.json`; machine-readable evidence is under `offline/`. It uses standard-library parsing, hashing, ZIP inspection, AST inspection and local Git reads. It does not import or execute the submitted helper, package verifier, installers or controllers.

## Exact archives and inventory

| Artifact | Compressed bytes | Members | Cap | Required existing reserve | Actual reserve | Margin |
|---|---:|---:|---:|---:|---:|---:|
| Canonical plugin | 588,564 | 75 | 589,824 | 1,240 | 1,260 | 20 |
| Standalone compatibility | 583,962 | 72 | 589,824 | 2,000 | 5,862 | 3,862 |

Canonical SHA-256: `12502ae8c75dfc5127aec7b6c038ee0fe12e191c9976cef3b5545503d64e0aa8`.

Standalone SHA-256: `320100fe575bd5ea56a1789953d7b26b6fcb4f8e15aed3f81f6bf4f4ef24808b`.

Both archives pass a full CRC read; every path is unique, sorted and safe. All members have the expected regular-file type, Unix mode and canonical ZIP metadata. Embedded member sizes and SHA-256 hashes exactly match the actual contents. The complete expected source inventory matches: 74 canonical payload files plus inventory, and 71 standalone payload files plus inventory. This includes the four frontmatter-stripped standalone child procedures and their resource-path projection.

Both inventories bind `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7`, tree `9c3913ceaa95f3f36b0377fe2dba4a302afcba89`, `worktree_state: clean`. The current commit and tree raw object hashes were recomputed. Each selected source file's Git blob hash matches its entry in that exact tree; every expected archive body matches that source projection. HEAD, tree and full tracked/untracked status are unchanged and clean before and after the successful checker.

The submitted bytes independently compute to the named archive Git blob IDs `cf3699afeec7337be567d72df74c0121e2983439` and `db4c21dac466726f0ffad536ba7a4c12ca7264d7`. This verifies object identity from bytes. It does not independently establish current remote publication availability; optional direct archive-object retrieval was omitted in the offline successor.

## Unchanged budget lineage and bounded applicability

Raw local Git reads confirm byte identity between the supplied historical source `6b353b48b2fc8a6de0c6223f48d341c484c98191`, current 51416, and the current worktree:

| File | Bytes | SHA-256 |
|---|---:|---|
| `scripts/package-contract.py` | 46,034 | `506d52a9e12261c295a1bf0fe16e4cf4c382ec06335feeb8806f404396568c1f` |
| `package/implementaudit-package.json` | 5,617 | `c4844781b4063e02f8fbe33dea67937d3efb3c913f726583c10a0d41387f9c2e` |
| `package/budgets/pr255-v5-owner-approval.md` | 6,571 | `9cce88d8d9822c42fcaa485ffbb8a82cf9b53256c93ca926969448d3affc1538` |

The exact v5 revision object, both 589,824-byte caps, canonical 1,240-byte reserve and standalone 2,000-byte reserve therefore predate this C11 preparation. No new exception or package-rule modification is introduced by the submitted intake adapter. The author's `BUDGET_6B_TO_CURRENT.json` matches these independent raw-object comparisons.

The v5 approval remains expressly limited to the reviewed DG17 Stop correction and its necessary contract integration. It still requires final-source measurement and preserves containment, descendant termination, failure handling, cleanup, integrity, isolated installs and affected qualification. Byte equality of the rule files is not a new owner grant. Root owns applicability receiving, including its established acceptance/integration history.

The local Git interlock bodies corroborate the supplied lineage: approval-adoption 4a50065d has 31,464-byte `8ad392459f9c8cff07fe8b25045dd2604f4866e91c6a6452f7f580ef7d46b37b`; 1b6b8911 and current 51416 have 31,585-byte `b42fbbc2184aee40e507dcd2be4630ce14b68cacc13a42264b8ca874563f8837`. Historical 6b has the same 31,585-byte body except for the binding-core digest. The complete 6b-to-current Git diff contains exactly that one literal change. This confirms the distinction identified by the main reviewer without granting broader authority.

The old operator's 2,000-byte canonical check remains historical. Applying that arithmetic to the current archive would yield a 740-byte shortfall. The existing v5 floor yields the 20-byte margin above. These are different predicates; the present arithmetic does not rewrite historical failures or turn historical budget RED green.

## Altered intake and source preservation

Static inspection of `Operation.prepare` confirms that the changed acquisition prefix reads the exact source identity, checks the pinned approval and contract bytes, checks the complete v5 revision object and role budgets, and verifies the complete selected archive bytes and hashes before saving output copies. It invokes the unchanged package verifier with `--require-clean-source` before the inherited installation loop. Its new writes are confined to package/evidence output; no source write is introduced in the altered intake.

The inherited `for route in ROUTES` block and remainder of `prepare` are AST-identical to the historical helper. This subreview does not independently cover the complete workflow/runtime acceptance predicate; the main reviewer owns that separate scope. The successful source/read-only observations do not establish future hosted source custody or award original C11.

## Retained automatic rejection

The initial checker performed a local Git object lookup that attempted an implicit HTTPS fetch to github.com. Automatic approval review denied that network action because only a bounded local review was authorized. The exact rejection text and the limits on command identification are retained in `BLOCKED_GIT_ACCESS.json`; the initial script and its emitted evidence are preserved. No successful remote retrieval is claimed.

The safer successor omitted optional archive-object reads, read expected source bodies directly against exact-tree blob IDs, set `GIT_NO_LAZY_FETCH=1`, disabled all Git transports with empty `GIT_ALLOW_PROTOCOL` and `protocol.allow=never`, and completed locally. No escalation was requested and no blocked optional lookup was retried. This operational failure does not alter the submitted source packet or its historical evidence.

## Return boundary

Return these mechanical findings to the main independent reviewer. The exact packet passes the examined integrity, source-parity and existing-budget arithmetic checks; root-owned applicability, actual first-attempt hosted execution and independent original receiving remain separate. No new original award, denominator reduction, publication instruction, provider operation, installer operation, controller operation or closure follows from this report.
