#!/usr/bin/env python3
"""Offline read-only package subreview; never imports or executes reviewed code."""
from pathlib import Path, PurePosixPath
import ast
import os
import datetime
import hashlib
import json
import re
import stat
import subprocess
import zipfile
import zlib

BASE = Path('/workspace/scratch/530bc07ea12b')
PACKET = BASE / 'dg18-continuing-original-execution'
REPO = BASE / 'implementaudit'
OUT = BASE / 'dg18-c11-current-independent-review/package-subreview/offline'
HEAD = '51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
TREE = '9c3913ceaa95f3f36b0377fe2dba4a302afcba89'
OLD = '6b353b48b2fc8a6de0c6223f48d341c484c98191'
PACKET_SHA = 'b4817510cb0a022d85570209bba4e0a164b65f20c26d62c36658295d18f9c3b2'
PACKAGE_ROOT = PACKET / 'stage/handoff/pro-executor-results-20261115/dg18-c11-current-51416-20261120'
errors = []
git_receipts = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob_oid(data, kind='blob'):
    return hashlib.sha1(kind.encode() + b' ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def fact(path):
    before = path.lstat()
    data = path.read_bytes()
    after = path.lstat()
    check(stat.S_ISREG(before.st_mode), 'nonregular input ' + str(path))
    check((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
          (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
          'input changed during read ' + str(path))
    return {'bytes':len(data), 'sha256':sha(data)}, data

def check(value, label):
    if not value:
        errors.append(label)

def git(*args, allow_failure=False):
    argv = ['/usr/bin/git','--no-optional-locks','-c','protocol.allow=never','-C',str(REPO),*args]
    p = subprocess.run(argv, capture_output=True, timeout=20, env={**os.environ,'GIT_NO_LAZY_FETCH':'1','GIT_ALLOW_PROTOCOL':'','GIT_TERMINAL_PROMPT':'0'})
    git_receipts.append({'argv':argv,'exit_code':p.returncode,'stdout_bytes':len(p.stdout),
                         'stdout_sha256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')})
    if not allow_failure:
        check(p.returncode == 0, 'git failed ' + ' '.join(args))
    return p.returncode,p.stdout

def write(name,value):
    with (OUT / name).open('x') as f:
        json.dump(value,f,indent=2,sort_keys=True)
        f.write('\n')

manifest_fact, manifest_raw = fact(PACKET / 'MANIFEST.json')
check(manifest_fact['sha256'] == PACKET_SHA,'packet manifest digest mismatch')
manifest = json.loads(manifest_raw)
manifest_checks = []
for row in manifest['files']:
    observed,_ = fact(PACKET / row['path'])
    equal = observed == {k:row[k] for k in ('bytes','sha256')}
    check(equal,'manifest member mismatch '+row['path'])
    manifest_checks.append({'path':row['path'],**observed,'matches':equal})
check(len(manifest_checks)==manifest['count'],'manifest count mismatch')
check(sum(r['bytes'] for r in manifest_checks)==manifest['bytes'],'manifest byte total mismatch')
external_checks=[]
for row in manifest['external_evidence']:
    observed,_ = fact(Path(row['path']))
    equal=observed=={k:row[k] for k in ('bytes','sha256')}
    check(equal,'external evidence mismatch '+row['path'])
    external_checks.append({'path':row['path'],**observed,'matches':equal})
control=json.loads((PACKET/'CONTROL_POPULATION.json').read_bytes())
control_checks=[]
for row in control['files']:
    observed,_=fact(PACKET/row['path'])
    equal=observed=={k:row[k] for k in ('bytes','sha256')}
    check(equal,'control population mismatch '+row['path'])
    control_checks.append({'path':row['path'],**observed,'matches':equal})
check(len(control_checks)==control['count'],'control population count mismatch')
check(sum(r['bytes'] for r in control_checks)==control['bytes'],'control population bytes mismatch')
write('INPUT_BINDINGS.json',{'manifest':manifest_fact,'members':manifest_checks,
                            'external_evidence':external_checks,'control_population':control_checks})

_,before_head=git('rev-parse','HEAD','HEAD^{tree}')
_,before_status=git('status','--porcelain=v1','--untracked-files=all')
check(before_head.decode().splitlines()==[HEAD,TREE],'current checkout identity mismatch')
check(before_status==b'','current checkout not clean')
raw_objects=[]
for kind,oid in [('commit',HEAD),('tree',TREE),('commit',OLD)]:
    _,raw=git('cat-file',kind,oid)
    observed=blob_oid(raw,kind)
    check(observed==oid,'raw object identity mismatch '+oid)
    raw_objects.append({'kind':kind,'oid':oid,'bytes':len(raw),'sha256':sha(raw),'recomputed_oid':observed})

budget_paths=['scripts/package-contract.py','package/implementaudit-package.json',
              'package/budgets/pr255-v5-owner-approval.md']
budget=[]
for path in budget_paths:
    _,old=git('cat-file','blob',OLD+':'+path)
    _,current=git('cat-file','blob',HEAD+':'+path)
    worktree= (REPO/path).read_bytes()
    equal=old==current==worktree
    check(equal,'budget lineage mismatch '+path)
    budget.append({'path':path,'old_commit':OLD,'current_commit':HEAD,'old_bytes':len(old),
                   'current_bytes':len(current),'old_sha256':sha(old),'current_sha256':sha(current),
                   'old_git_blob':blob_oid(old),'current_git_blob':blob_oid(current),
                   'old_current_worktree_equal':equal})
contract_raw=(REPO/budget_paths[1]).read_bytes()
contract=json.loads(contract_raw)
check(contract['budgets']['canonical_plugin']['reserve_bytes']==1240,'canonical floor differs')
check(contract['budgets']['standalone_compatibility']['reserve_bytes']==2000,'standalone floor differs')
check(all(v['cap_bytes']==589824 for v in contract['budgets'].values()),'cap differs')
claimed_lineage=json.loads((PACKET/'receiving/BUDGET_6B_TO_CURRENT.json').read_bytes())
check(all(c['path']==b['path'] and c['old6b_sha256']==b['old_sha256'] and
          c['current_sha256']==b['current_sha256'] and c['equal']==b['old_current_worktree_equal']
          for c,b in zip(claimed_lineage,budget)),'recorded lineage differs from raw Git')

interlock_path='skills/implementaudit/scripts/host-stop-interlock.py'
interlocks=[]
for commit in [OLD,HEAD,'4a50065da0fd3be6dd8757911ac0d2f18163213e','1b6b8911c00d2c94a62c2e9431ec80128719a9cf']:
    code,raw=git('cat-file','blob',commit+':'+interlock_path,allow_failure=True)
    interlocks.append({'commit':commit,'available':code==0,
                        'bytes':len(raw) if code==0 else None,'sha256':sha(raw) if code==0 else None})
_,old_current_interlock_diff=git('diff','--no-ext-diff','--no-textconv',OLD,HEAD,'--',interlock_path)
with (OUT/'INTERLOCK_6B_TO_CURRENT.patch').open('xb') as f:f.write(old_current_interlock_diff)
write('BUDGET_LINEAGE.json',{'raw_git_lineage':budget,'budget_revision':contract['budget_revision'],
                           'budgets':contract['budgets'],'interlock_objects':interlocks,
                           'existing_approval_is_bounded_to_DG17_correction':True,
                           'new_exception_in_packet':False,'authority_applicability_decision':'ROOT_OWNED_NOT_AWARDED'})

_,tree_rows=git('ls-tree','-r','-z',HEAD,'--','skills/implementaudit',
               *['skills/'+x+'/SKILL.md' for x in contract['required_skills'][1:]],
               '.codex-plugin/plugin.json','.claude-plugin/plugin.json','.claude-plugin/marketplace.json',
               'package/implementaudit-package.json')
source={}
source_objects=[]
normalize_suffixes={'.md','.txt','.sh','.json','.yaml','.yml'}
for row in tree_rows.split(b'\0'):
    if not row:continue
    metadata,path_raw=row.split(b'\t',1)
    mode,kind,oid=metadata.decode().split()
    path=path_raw.decode()
    check(kind=='blob' and mode in {'100644','100755'},'nonregular source '+path)
    raw=(REPO/path).read_bytes()
    check(blob_oid(raw)==oid,'source worktree does not match exact tree blob '+path)
    source[path]=raw.replace(b'\r\n',b'\n') if PurePosixPath(path).suffix.lower() in normalize_suffixes else raw
    source_objects.append({'path':path,'mode':mode,'oid':oid,'bytes':len(raw),'sha256':sha(raw)})

blocked_parts={'.git','.IMPLEMENTAUDIT','.github','docs','fixtures','tests','graphify-out','.graphify','.activegraph','tmp','temp','dist'}
blocked_names={'graph.json','quickstart_demo_run.db'}
blocked_suffixes=('.log','.tmp','.db','.sqlite','.sqlite3','.jsonl')
governor={p[len('skills/implementaudit/'):]:data for p,data in source.items() if p.startswith('skills/implementaudit/')}
for path in governor:
    posix=PurePosixPath(path)
    check(not (any(x in blocked_parts for x in posix.parts) or posix.name in blocked_names or
               path.startswith('.env') or path.endswith(blocked_suffixes)),'blocked source member '+path)
children={p:data for p,data in source.items() if p.startswith('skills/') and not p.startswith('skills/implementaudit/')}
expected_plugin={**{'skills/implementaudit/'+p:data for p,data in governor.items()},**children,
                  **{p:source[p] for p in ('.codex-plugin/plugin.json','.claude-plugin/plugin.json','.claude-plugin/marketplace.json')},
                  'IMPLEMENTAUDIT_PACKAGE.json':contract_raw}
expected_standalone={**governor,'IMPLEMENTAUDIT_PACKAGE.json':contract_raw}
projection_rows=[]
for path,data in children.items():
    name=PurePosixPath(path).parts[1]
    text=data.decode()
    check(text.startswith('---\n'),'missing source child frontmatter '+path)
    frontmatter,separator,body=text[4:].partition('\n---\n')
    check(bool(separator),'unclosed child frontmatter '+path)
    projected=body.lstrip('\n')
    projected=re.sub(r'\.\.[\\/]+implementaudit[\\/]+((?:references|scripts|templates)[\\/]+[^`\r\n]+)',
                     lambda match:'../'+match.group(1).replace('\\','/'),projected)
    output_path='internal-procedures/'+name+'.md'
    expected_standalone[output_path]=projected.encode()
    projection_rows.append({'source':path,'target':output_path,'bytes':len(projected.encode()),'sha256':sha(projected.encode())})

archives=[]
archive_member_checks=[]
expectations=[('canonical_plugin','IMPLEMENTAUDIT.plugin.zip',588564,
               '12502ae8c75dfc5127aec7b6c038ee0fe12e191c9976cef3b5545503d64e0aa8',
               'cf3699afeec7337be567d72df74c0121e2983439',75,expected_plugin),
              ('standalone_compatibility','IMPLEMENTAUDIT.skill',583962,
               '320100fe575bd5ea56a1789953d7b26b6fcb4f8e15aed3f81f6bf4f4ef24808b',
               'db4c21dac466726f0ffad536ba7a4c12ca7264d7',72,expected_standalone)]
for role,name,size,digest,blob,count,expected in expectations:
    af,raw=fact(PACKAGE_ROOT/name)
    check(af=={'bytes':size,'sha256':digest},'archive bytes/digest mismatch '+name)
    check(blob_oid(raw)==blob,'archive Git blob mismatch '+name)
    code=1  # Optional published archive-object lookup deliberately omitted; no retry of missing-object access.
    with zipfile.ZipFile(PACKAGE_ROOT/name) as z:
        infos=z.infolist()
        names=[i.filename for i in infos]
        check(len(names)==count,'archive member count mismatch '+name)
        check(names==sorted(names) and len(names)==len(set(names)),'member order or uniqueness mismatch '+name)
        crc_bad=z.testzip()
        check(crc_bad is None,'archive CRC mismatch '+name)
        inv_raw=z.read('IMPLEMENTAUDIT_INVENTORY.json')
        inv=json.loads(inv_raw)
        check(inv['source']=={'commit':HEAD,'tree':TREE,'worktree_state':'clean'},'inventory source mismatch '+name)
        check(inv['artifact_role']==role and inv['schema']==contract['inventory_contract']['format'],'inventory metadata mismatch '+name)
        for field in ['package_name','runtime_version','release_family','public_governor','required_skills','internal_skills']:
            check(inv[field]==contract[field],'inventory field differs '+name+' '+field)
        check(set(names)==set(expected)|{'IMPLEMENTAUDIT_INVENTORY.json'},'expected source inventory population mismatch '+name)
        actual_members=[]
        member_rows=[]
        for info in infos:
            path=info.filename
            p=PurePosixPath(path)
            data=z.read(info)
            mode=stat.S_IMODE(info.external_attr>>16)
            expected_mode=0o755 if path.startswith(('scripts/','skills/implementaudit/scripts/')) else 0o644
            safe=not p.is_absolute() and '..' not in p.parts and '\\' not in path
            metadata_ok=(info.create_system==3 and info.compress_type==zipfile.ZIP_DEFLATED and
                         not info.extra and not info.comment and stat.S_IFMT(info.external_attr>>16)==stat.S_IFREG and
                         mode==expected_mode)
            crc_ok=(zlib.crc32(data)&0xffffffff)==info.CRC
            check(safe and metadata_ok and crc_ok,'member metadata/CRC mismatch '+name+':'+path)
            check(not(path.endswith('.sh') and b'\r\n' in data),'shell CRLF '+name+':'+path)
            source_equal=data==expected[path] if path in expected else None
            if path!='IMPLEMENTAUDIT_INVENTORY.json':
                check(source_equal,'source member content differs '+name+':'+path)
                actual_members.append({'path':path,'bytes':len(data),'sha256':sha(data)})
            member_rows.append({'path':path,'bytes':len(data),'sha256':sha(data),'mode':oct(mode),
                                'crc32':f'{info.CRC:08x}','crc_matches':crc_ok,'metadata_matches':metadata_ok,
                                'matches_exact_source_projection':source_equal})
        check(inv['members']==actual_members,'embedded inventory hashes/sizes mismatch '+name)
        expected_inv={k:inv[k] for k in inv if k!='members'}
        expected_inv['members']=[{'path':p,'bytes':len(d),'sha256':sha(d)} for p,d in sorted(expected.items())]
        check(inv_raw==(json.dumps(expected_inv,sort_keys=True,indent=2)+'\n').encode(),'inventory canonical bytes mismatch '+name)
        budget_row=contract['budgets'][role]
        reserve=budget_row['cap_bytes']-len(raw)
        check(reserve>=budget_row['reserve_bytes'],'existing v5 reserve failed '+name)
        archives.append({'role':role,'path':str(PACKAGE_ROOT/name),**af,'git_blob':blob,
                         'existing_git_blob_lookup':'OMITTED_NO_RETRY; Git blob identity independently recomputed from submitted archive bytes','members':len(infos),'crc_bad_member':crc_bad,
                         'inventory_bytes':len(inv_raw),'inventory_sha256':sha(inv_raw),'embedded_source':inv['source'],
                         'expected_payload_members':len(expected),'all_expected_source_members_equal':True,
                         'cap_bytes':budget_row['cap_bytes'],'required_reserve':budget_row['reserve_bytes'],
                         'actual_reserve':reserve,'margin_above_existing_floor':reserve-budget_row['reserve_bytes'],
                         'margin_above_historical_operator_2000':reserve-2000})
        archive_member_checks.append({'artifact':name,'members':member_rows})
write('ARCHIVE_CHECKS.json',{'archives':archives,'member_checks':archive_member_checks,
                           'source_projection_objects':source_objects,'standalone_projection':projection_rows})

new_path=PACKAGE_ROOT/'qualify.py'
old_path=PACKET/'historical/qualify.py'
new_tree=ast.parse(new_path.read_text())
old_tree=ast.parse(old_path.read_text())
def prepare(tree):
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Operation')
    return next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='prepare')
def route_loop_index(node):
    return next(i for i,n in enumerate(node.body) if isinstance(n,ast.For) and isinstance(n.iter,ast.Name) and n.iter.id=='ROUTES')
new_prepare=prepare(new_tree)
old_prepare=prepare(old_tree)
ni=route_loop_index(new_prepare)
oi=route_loop_index(old_prepare)
suffix_equal=ast.dump(ast.Module(body=new_prepare.body[ni:],type_ignores=[]),include_attributes=False)==ast.dump(ast.Module(body=old_prepare.body[oi:],type_ignores=[]),include_attributes=False)
check(suffix_equal,'prepare inherited route suffix changed')
new_prefix_calls=[ast.unparse(n) for s in new_prepare.body[:ni] for n in ast.walk(s) if isinstance(n,ast.Call)]
write('INTAKE_STATIC_CHECKS.json',{'new_helper':{'path':str(new_path),**fact(new_path)[0]},
                                  'old_helper':{'path':str(old_path),**fact(old_path)[0]},
                                  'inherited_route_loop_and_suffix_ast_equal':suffix_equal,
                                  'changed_prefix_calls':new_prefix_calls,
                                  'assessment':'Altered intake reads source identity, budget and approval; validates full selected archive bytes twice; writes only package/evidence output; invokes the unchanged package verifier with require-clean-source before the inherited installer loop. No source write was introduced in the altered intake. This is static analysis, not an execution result.'})

_,after_head=git('rev-parse','HEAD','HEAD^{tree}')
_,after_status=git('status','--porcelain=v1','--untracked-files=all')
check(after_head==before_head and after_status==before_status==b'','source identity/status changed across review')
check((PACKET/'MANIFEST.json').read_bytes()==manifest_raw,'packet manifest changed across review')
for row in manifest['files']:
    actual,_=fact(PACKET/row['path'])
    check(actual=={k:row[k] for k in ('bytes','sha256')},'packet member changed across review '+row['path'])
write('RAW_GIT_RECEIPTS.json',{'objects':raw_objects,'commands':git_receipts,
                             'before_head_and_tree':before_head.decode(),'after_head_and_tree':after_head.decode(),
                             'before_status':before_status.decode(),'after_status':after_status.decode()})
summary={'schema':'dg18.c11.mechanical-package-subreview.v1','reviewer':'/root/dg18_c11_independent_review/package_budget_receiving',
         'scope':'Mechanical source-only subreview; not audit-assess routing, original execution, readiness authority, acceptance or closure.',
         'packet_manifest':manifest_fact,'packet_count':len(manifest_checks),'control_population_count':len(control_checks),
         'current_source':HEAD,'current_tree':TREE,'source_clean_before_and_after':before_status==after_status==b'',
         'archive_summaries':archives,'raw_git_budget_lineage_matches':all(r['old_current_worktree_equal'] for r in budget),
         'errors':errors,'original_denominator':14,'original_awards':[],
         'budget_RED':'PRESERVED: historical failure records and historical 2000-byte operator rule retain original scope; current arithmetic does not erase or relabel them.',
         'existing_v5_applicability':'NO AUTHORITY CLAIM; bounded correction scope and final-source requirements must be reconciled by Root.',
         'forbidden_operations_executed':{'qualify':0,'package_verifier':0,'installers':0,'controllers':0,'provider':0,'network':0},
         'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
write('SUMMARY.json',summary)
print(json.dumps({'errors':errors,'archives':archives,'budget_raw_git_equal':summary['raw_git_budget_lineage_matches'],
                  'source_clean_before_after':summary['source_clean_before_and_after'],'manifest_count':len(manifest_checks),
                  'control_count':len(control_checks),'receipt_directory':str(OUT)},indent=2))
raise SystemExit(1 if errors else 0)
