#!/usr/bin/env python3
"""Independent data-only receipt. Never imports or executes candidate code/Git."""
from pathlib import Path, PurePosixPath
import ast
import hashlib
import json
import os
import re
import stat

PACKET = Path('/workspace/scratch/097486cde2dd/dg17-after-m09-next')
OUT = Path(__file__).absolute().parent
SEAL_SHA = 'e07021288d1afdbd2ade7583f7fb154ae5d41e325e48a9646c5d58dd963d6a38'
BASE = '51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
BASE_TREE = '9c3913ceaa95f3f36b0377fe2dba4a302afcba89'
CANDIDATE_TREE = 'e15ee980fcec18875482ad5639f7b4a5dbc76531'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def obj(kind, data):
    return hashlib.sha1(kind.encode()+b' '+str(len(data)).encode()+b'\0'+data).hexdigest()

def read(name):
    return (PACKET/name).read_bytes()

def js(name):
    return json.loads(read(name))

def inventory(root):
    rows = {}
    for parent, dirs, files in os.walk(root, followlinks=False):
        for name in dirs+files:
            path = Path(parent)/name
            st = path.lstat()
            rel = path.relative_to(root).as_posix()
            if stat.S_ISLNK(st.st_mode):
                rows[rel] = {'path':rel, 'kind':'symlink', 'target':os.readlink(path)}
            elif stat.S_ISREG(st.st_mode):
                data = path.read_bytes()
                rows[rel] = {'path':rel, 'kind':'regular', 'bytes':len(data),
                             'sha256':sha(data), 'mode':stat.S_IMODE(st.st_mode)}
            else:
                assert stat.S_ISDIR(st.st_mode), ('unsupported member', rel)
    return rows

seal_bytes = read('SEAL.json')
assert len(seal_bytes) == 61699 and sha(seal_bytes) == SEAL_SHA
seal = json.loads(seal_bytes)
actual = inventory(PACKET)
declared = {}
for row in seal['files']:
    name = row['path']
    path = PurePosixPath(name)
    assert not path.is_absolute() and str(path) == name and '..' not in path.parts
    assert name not in declared
    declared[name] = row
    assert all(actual[name].get(k) == v for k,v in row.items()), ('member mismatch', name)
assert set(actual) == set(declared) | {'SEAL.json'}
regular = [r for r in actual.values() if r['kind']=='regular' and r['path']!='SEAL.json']
links = [r for r in actual.values() if r['kind']=='symlink']
assert len(regular) == seal['regular_count'] == 261
assert len(links) == seal['symlink_probe_count'] == 2
assert sum(r['bytes'] for r in regular) == seal['bytes'] == 3851470
assert {r['path']:r['target'] for r in links} == {
    'qualification/support-03/link.bin':'regular.bin',
    'qualification/support-final/link.bin':'regular.bin'}

authenticated = js('evidence/AUTHENTICATED_BASE_TREE.json')
assert authenticated['commit']==BASE and authenticated['tree']==BASE_TREE and authenticated['truncated'] is False
entries = {e['path']:e for e in authenticated['entries']}
assert len(entries)==len(authenticated['entries'])==2242
leaves = {p:e for p,e in entries.items() if e['type']!='tree'}
assert len(leaves)==1785

def derive_tree(selected):
    root = {}
    trees = {}
    for name, row in selected.items():
        parts = name.split('/')
        node = root
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        assert parts[-1] not in node
        node[parts[-1]] = (row['mode'], row['sha'])
    def emit(node, prefix):
        result = []
        for name, value in node.items():
            full = prefix+'/'+name if prefix else name
            if isinstance(value, dict):
                oid = emit(value, full)
                result.append((name.encode()+b'/', b'40000 '+name.encode()+b'\0'+bytes.fromhex(oid)))
            else:
                mode, oid = value
                result.append((name.encode(), mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(oid)))
        oid = obj('tree', b''.join(body for _,body in sorted(result)))
        trees[prefix]=oid
        return oid
    return emit(root,''), trees

base_oid, base_dirs = derive_tree(leaves)
assert base_oid==BASE_TREE
assert all(base_dirs[p]==e['sha'] for p,e in entries.items() if e['type']=='tree')
intake = js('evidence/SOURCE_INTAKE.json')
assert intake['base_commit']==BASE and intake['base_tree']==BASE_TREE
base_files = inventory(PACKET/'base')
candidate_files = inventory(PACKET/'candidate')
assert len(base_files)==intake['source_count']==len(intake['files'])==27
assert set(base_files)=={r['path'] for r in intake['files']}
for row in intake['files']:
    name=row['path']; data=read('base/'+name); leaf=leaves[name]
    assert row['bytes']==len(data)==leaf['size']
    assert row['sha256']==sha(data)==base_files[name]['sha256']
    assert row['git_blob']==obj('blob',data)==leaf['sha']
    assert row['mode']==leaf['mode']
    assert row['exit']==0 and row['stderr_bytes']==0
    assert ('100755' if base_files[name]['mode'] & 0o111 else '100644')==leaf['mode']

changed = sorted(p for p in set(base_files)|set(candidate_files) if base_files.get(p)!=candidate_files.get(p))
delta = js('evidence/SOURCE_DELTA.json')
assert changed==[r['path'] for r in delta['changed_files']] and len(changed)==7
assert set(base_files)<=set(candidate_files) and len(candidate_files)==31
candidate_leaves = dict(leaves)
changes=[]
for row in delta['changed_files']:
    name=row['path']; data=read('candidate/'+name)
    assert row['bytes']==len(data) and row['sha256']==sha(data)
    assert row['after_blob']==obj('blob',data)
    assert row['before_blob']==(leaves[name]['sha'] if name in leaves else None)
    assert row['mode']==('100755' if candidate_files[name]['mode'] & 0o111 else '100644')
    candidate_leaves[name]={'mode':row['mode'],'sha':row['after_blob'],'type':'blob','path':name,'size':len(data)}
    changes.append(row)
candidate_oid,candidate_dirs=derive_tree(candidate_leaves)
assert candidate_oid==delta['proposed_tree']==CANDIDATE_TREE
assert len(candidate_leaves)==delta['candidate_leaf_count']==1789

# Apply the supplied textual patch to frozen base bytes without invoking Git.
patch_text=read('SOURCE.patch').decode()
blocks=re.split(r'(?m)^diff --git ',patch_text)[1:]
patched=[]
for block in blocks:
    lines=block.splitlines(keepends=True)
    m=re.fullmatch(r'a/(.+) b/(.+)\n',lines[0]); assert m and m[1]==m[2]
    name=m[1]; old=read('base/'+name).decode().splitlines(keepends=True) if name in base_files else []
    result=[]; cursor=0; i=1
    while i<len(lines):
        if not lines[i].startswith('@@ '): i+=1; continue
        header=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i]); assert header
        start=int(header[1]); oldcount=int(header[2] or 1); newcount=int(header[4] or 1)
        at=start-1 if oldcount else start
        assert at>=cursor
        result.extend(old[cursor:at]); cursor=at; i+=1; oc=nc=0
        while i<len(lines) and not lines[i].startswith('@@ '):
            line=lines[i]
            assert line[:1] in {' ','+','-'}, (name,line[:80])
            if line[0] in ' -': assert cursor<len(old) and old[cursor]==line[1:]; cursor+=1; oc+=1
            if line[0] in ' +': result.append(line[1:]); nc+=1
            i+=1
        assert (oc,nc)==(oldcount,newcount)
    result.extend(old[cursor:])
    assert ''.join(result).encode()==read('candidate/'+name), ('patch mismatch',name)
    patched.append(name)
assert sorted(patched)==changed
base_cli=read('base/skills/implementaudit/scripts/apply-observed-mutation.sh')
new_cli=read('candidate/skills/implementaudit/scripts/apply-observed-mutation.sh')
base_tail=base_cli.split(b"<<'PY'\n",1)[1]
new_tail=new_cli.split(b"<<'PY'\n",1)[1]
assert base_tail==new_tail and len(base_tail)==114332 and base_tail.endswith(b'\nPY\n')
assert sha(base_tail)=='68858ff60076dc81db58ae9230fdf115b9eb76bd8429695b6253001ce27264c5'
base_body=base_tail[:-3]
assert len(base_body)==114329
assert sha(base_body)=='c7ab6d73b7f84ae48c0c91c0fc91c97a9d60f2b18e4273b23af1bb65f213632d'

module=read('candidate/skills/implementaudit/scripts/verified-mutation-step.py')
mutations=[]
for row in js('inputs/MUTATIONS.json'):
    original=(row['removed']+'\n').encode(); replacement=(row['replacement']+'\n').encode()
    assert module.count(original)==1 and row['original_sha256']==sha(module)
    data=read('mutations/'+row['variant']+'/verified-mutation-step.py')
    assert data==module.replace(original,replacement,1) and sha(data)==row['sha256']
    mutations.append(row)
matrix=js('inputs/cases.json')
assert list(matrix['variant_cases'])==['original','skip_baseline','skip_postcheck']
assert matrix['variant_cases']['original']==[f'c{i:02d}' for i in range(1,9)]
assert matrix['variant_cases']['skip_baseline']==['c02','c04','c08']
assert matrix['variant_cases']['skip_postcheck']==['c03','c05','c02','c08']
assert len(matrix['cases'])==8
case_summary=[]
for case in matrix['cases']:
    for name in ('before_hex','candidate_hex'):
        ast.parse(bytes.fromhex(case[name]))  # syntax only, never evaluated
    phase=read('inputs/phases/'+case['id']+'.md').decode()
    assert phase.count('RUN_ROOT_FROM_REAL_CLAIM')==4
    scopes=re.findall(r'(?m)^Mutation scope: (.*)$',phase)
    authorities=re.findall(r'(?m)^  mutation-authority: (.*)$',phase)
    assert len(scopes)==len(authorities)==1
    scope=json.loads(scopes[0])
    assert scope=={'in':[case['target']], 'out':[case['unrelated_file'],'checks/inspect_result.py','checks/examples.json']}
    scope_sorted=all(scope[k]==sorted(scope[k],key=lambda value:value.encode()) for k in ('in','out'))
    assert scope_sorted is False  # H3: exact retained inputs violate the selected native guard.
    assert json.loads(authorities[0])=={'operation':'replace','source':case['target'],'destination':None}
    case_summary.append({**{k:v for k,v in case.items() if not k.endswith('_hex')},
                         'frozen_scope':scope, 'native_mutation_scope_sorted_predicate':scope_sorted})
assert sha(read('inputs/cases.json'))==js('qualification/PHASE_TEMPLATE_CORRECTION.json')['case_expectations_unchanged_sha256']
for row in js('qualification/PHASE_TEMPLATE_CORRECTION.json')['changed']:
    assert sha(read(row['path']))==row['after_sha256']
for name in ['run_m03.py','oracle.py','receive_m03.py','prepare_inputs.py',
             'candidate/skills/implementaudit/scripts/verified-mutation-step.py',
             'candidate/tests/verified_mutation_step_support.py']:
    ast.parse(read(name),filename=name)

processes=[]
for path in sorted((PACKET/'qualification').rglob('process.json')):
    row=json.loads(path.read_bytes())
    for stream in ('stdout','stderr'):
        data=path.with_name(stream+'.bin').read_bytes()
        expected=row.get(stream)
        if isinstance(expected,dict):
            assert expected['bytes']==len(data) and expected['sha256']==sha(data)
        else:
            assert row[stream+'_bytes']==len(data) and row[stream+'_sha256']==sha(data)
    assert not any(arg in {'--batch-preflight','--batch-apply','--mutation-authority'} for arg in row['argv'])
    processes.append({'path':path.relative_to(PACKET).as_posix(),**row})
assert len(processes)==25
support=js('qualification/support-final/RESULT.json')
assert support['original_witnesses_executed'] is False and len(support['rows'])==15
assert all(row['pass'] is True for row in support['rows'])
loaded=next(r['details'] for r in support['rows'] if r['name']=='full-product-module-load')
assert loaded['sha256']==sha(module)
replay=next(r['details'] for r in support['rows'] if r['name']=='existing-evidence-refuses-without-writing-or-launching')
assert replay['before']==replay['after'] and replay['result']['processes']==[] and replay['exit']==64
setup=[r for r in processes if '/setup-01/' in r['path']]
assert len(setup)==9 and all(r['returncode']==0 for r in setup[:8]) and setup[8]['returncode']==1
assert sum(r['argv'][0]=='/usr/bin/git' for r in setup)==7
assert setup[7]['argv'][1].endswith('/claim-run.sh')
assert b'boilerplate STOP conditions' in read('qualification/setup-01/processes/0009-normal-phase-shape/stderr.bin')
shape=[r for r in processes if '/phase-shape-02/' in r['path']]
assert len(shape)==8 and all(r['returncode']==0 for r in shape)
fixture=js('qualification/setup-01/fixtures/c01.json')
for root in ['qualification/setup-01/subjects/c01','qualification/setup-01/snapshots/c01']:
    run=PACKET/root/fixture['run_relative']
    assert (run/'.claimed').is_file() and not (run/'.controller').exists()
    assert not (run/'mutation-transactions').exists()
    assert not (run/'evidence/verified-step-current').exists()
    assert (PACKET/root/'work/q.py').read_bytes()==bytes.fromhex(matrix['cases'][0]['before_hex'])
    for row in fixture['run_inputs']:
        data=(run/row['path']).read_bytes()
        assert len(data)==row['bytes'] and sha(data)==row['sha256']
toolchain=js('evidence/TOOLCHAIN.json')
for row in toolchain['tools']:
    path=Path(row['path']); data=path.read_bytes()
    assert len(data)==row['bytes'] and sha(data)==row['sha256']
assert os.readlink(toolchain['python3_alias']['path'])==toolchain['python3_alias']['target']
assert not (PACKET/'execution-01').exists()

result={
    'schema':'dg17.m03.independent-static-receiving.v1',
    'status':'PASS_MECHANICAL_RECEIVING_ONLY_SOURCE_REVIEW_GAP_SEPARATE',
    'reviewer':'/root/independent_review', 'authority':'NONE',
    'root_binding':{'controller':'dg16-dg18-recovery-20261119-b','generation':'G0045',
                    'receipt':'da78b456997516f38e8e8b048c221bec6e4c0c4b','verified_native':'3a414d/0','current_native':'7b3a11/0'},
    'packet':{'path':str(PACKET),'seal_bytes':len(seal_bytes),'seal_sha256':SEAL_SHA,
              'regular_members':len(regular),'symlink_probes':len(links),'regular_bytes':sum(r['bytes'] for r in regular),
              'exact_inventory':True,'members':[actual[k] for k in sorted(declared)]},
    'source':{'base_commit':BASE,'base_tree':base_oid,'authenticated_entries':len(entries),
              'all_subtrees_rederived':len(base_dirs)-1,'base_leaves':len(leaves),'candidate_leaves':len(candidate_leaves),
              'proposed_tree':candidate_oid,'inherited_files':len(base_files),'candidate_subset_files':len(candidate_files),
              'changes':changes,'patch_applies_exactly_as_data':True,
              'heredoc_suffix_including_terminator_bytes':len(base_tail),'heredoc_suffix_sha256':sha(base_tail),
              'embedded_python_body_bytes':len(base_body),'embedded_python_body_sha256':sha(base_body)},
    'cases':case_summary,'mutations':mutations,'variant_cases':matrix['variant_cases'],
    'expected_mutation_observations':matrix['expected_mutation_observations'],
    'qualification':{'support_checks':15,'preserved_process_captures':len(processes),
                     'setup_processes':9,'successful_setup_git':7,'successful_setup_ordinary_claim':1,
                     'preserved_normal_shape_failure':1,'subsequent_normal_shapes':8,
                     'raw_streams_match':True,'processes':processes,
                     'qualification_is_not_original_or_native_containment':True},
    'toolchain_read_only_identity_check':toolchain,
    'original_execution_directory_absent':True,
    'candidate_or_product_import_or_execution':False,'git_execution':False,
    'provider_or_controller_calls':False,'oracle_execution':False,
    'source_tree_or_packet_mutation':False,'no_award_or_execution_authority':True,
}
(OUT/'MECHANICAL_RECEIVING.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({'status':result['status'],'regular_members':len(regular),'symlink_probes':len(links),
                  'regular_bytes':sum(r['bytes'] for r in regular),'base_tree':base_oid,'proposed_tree':candidate_oid,
                  'source_changes':len(changes),'retained_process_captures':len(processes),
                  'original_directory_absent':True,'review_findings':'REPORT.md: H1, H2, H3; no original execution'}))
