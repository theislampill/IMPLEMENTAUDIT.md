# A4 compiler-memory R2: narrow installed-Git admission

Report state: AUTHOR PLAN — source-only ordinary engineering, no execution authority.

## Evidence and selected correction

The prior ordinary diagnostic (run 44956925804, host
`01e1be8ea75ea57d57b48bb98c32ec772cf849fe`) failed before its source receiving,
Job import, or three workers. Its combined regular-file/single-link refusal did
not record the selected spelling or either individual predicate. This successor
does not retrospectively attribute that failure.

Root accepted the independently received metadata operation 44960177535,
attempt 1, host `53733a8081d518fdc58df9bfff0cefad618aea5c`, Windows image
20261116.370.1, CPython 3.12.10 x64. Its actual ucrt64 Git file was ordinary,
non-reparse, 4,414,792 bytes, SHA-256
`9bf8ee81d79f38a11eaf7799499a634c46a718e009a4a9b2b20b115804643302`.
Native enumeration completed with exactly four names in its installed bin
directory: git.exe, git-upload-pack.exe, git-receive-pack.exe, and
git-upload-archive.exe. Those observations were not executable admission;
installed executable bodies were not archived.

| Alternative | Decision and reason |
|---|---|
| Remove the general single-link guard | Rejected: would expand every source/tool admission without supporting evidence. |
| Substitute the single-link Git wrapper | Rejected: wrapper execution/delegation has not been qualified. |
| Replay the failed operation unchanged | Rejected: no correction and prohibited replay. |
| Fresh, held admission for the exact observed native Git identity and complete alias set | Selected: uses new native facts, a distinct operation, and explicit fresh receiving; all other guards remain. |

## Scope and mechanics

Only a new helper, exact unchanged R2 adapter, byte-identical native metadata
helper, and a distinct workflow are proposed as additions to sole parent
`51416b2f156b341c4a5f09029e2c6ceb5b30b1e7`.
Branch: `pro/dg18-a4-compiler-memory-51416-20261121-02`.
The old compiler and metadata packets stay byte-identical.

The supervisor lazily loads the pinned metadata helper whose comparison and
native enumeration code actually ran in the accepted metadata operation. It
does not call that helper's operation, provider binding, or finalizer. Workers
do not load it. Reuse preserves the reviewed CPython 3.12.10 mode/ctime semantic
mapping and avoids a new implementation of the native enumerator.

A separate Git receiver accepts only the fixed ucrt64 git.exe spelling, exact
size and SHA-256, complete EOF-terminated unique four-name native enumeration,
ordinary disk-file type, non-reparse path/descriptor/handle metadata, exact
same-API stability, and the reviewed cross-API identity comparison. Raw fields
are retained. Full stat device values are not compared to narrower native
volume serials or truncated to manufacture equality. The other returned aliases
are neither opened nor executed. Generic `physical()` and `read_pinned()` keep
their single-link guards unchanged; Python remains a single-link tool.

Five ancestor directories are opened root-first using
FILE_LIST_DIRECTORY|FILE_READ_ATTRIBUTES (0x81),
FILE_SHARE_READ|FILE_SHARE_WRITE (no delete sharing), OPEN_EXISTING, and
BACKUP_SEMANTICS|OPEN_REPARSE_POINT. Each must be an ordinary directory with its
exact final DOS path, and its same-API metadata must remain stable. The target
file is opened with GENERIC_READ, FILE_SHARE_READ only, OPEN_EXISTING, and
OPEN_REPARSE_POINT. These non-inheritable handles remain held across the
supervisor's existing twelve direct Git commands and the three workers. File
sharing excludes new writable/delete opens; directory sharing excludes rename
or deletion. This is a same-process, same-boot receiver, not a reusable historical
allowance. Native uptime and PID are recorded; uptime must remain monotone.

Fresh path/descriptor/native/final-path/ancestor/alias checks occur before and
after every Git command, with initial and terminal held-file hashes. Any drift,
incomplete enumeration, native error, failed closure, or unsupported runtime
refuses and preserves the partial observation. A finite intent is written before
tool admission so a refusal is retained. The existing separate always-run
finalizer seals retained bytes without retry or inferred worker completion.

Microsoft's CreateFileW documentation defines directory flags, non-inheritable
NULL security attributes, and share modes for read/write/delete access;
GetTickCount64 documents elapsed milliseconds since system start. These support
the source design, not a claim that the new custody path has executed natively:

- https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilew
- https://learn.microsoft.com/en-us/windows/win32/api/sysinfoapi/nf-sysinfoapi-gettickcount64
- https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-fsa/82b364ce-6d7b-422f-8d88-4db32eea809a
- https://learn.microsoft.com/en-us/windows/win32/fileio/file-access-rights-constants

The MS-FSA sharing algorithm requires a data/list, execute, write, append, or
delete access right for a non-delete-sharing open to conflict with a later
delete open. Attributes-only access is insufficient. The 0x81 directory request
therefore includes FILE_LIST_DIRECTORY (the directory interpretation of bit 1)
without enumerating directory contents. This corrects the unfrozen author's
initial 0x80 draft before independent review or native execution.

## Bounds and preservation

| Surface | Bound |
|---|---|
| Git target | One exact file; no search/fallback or returned-alias execution |
| Held ancestors | Exact five, root-first; reverse-order cleanup |
| Fresh byte reads | Two hashes of 4,414,792 bytes; each uses existing 16 MiB+1 read cap and 64 KiB chunks |
| Alias enumeration | Existing fixed 32-name / 4,096-character buffers; exact four-name acceptance only |
| Receiving observations | At most 26 (initial, 24 command boundaries, terminal); each has a 45-second cooperative deadline; supervisor checks a 420-second cooperative deadline before/after bounded operations |
| Git calls | Twelve maximum; unchanged direct command arguments, clean environment and 30-second timeout each |
| Workers | Exact native, R2, audit order; each existing native Job deadline 120 seconds, kill-on-close, no breakaway, complete process census required |
| Workflow | Windows 2022, exact Python 3.12.10 x64; 8-minute execute step, 1-minute independent finalizer, 12-minute job |
| Retention | Existing 128 files, 2 MiB/file, 8 MiB payload; exclusive output, no retry; 7-day artifact |

Each receiving JSON is capped at 1 MiB. This accommodates one refusing native
enumeration's full 32 fixed-buffer names (at most 32×4,095 UTF-16 code units,
including JSON escaping) plus finite metadata. A nonmatching enumeration stops
the operation; it cannot generate 26 maximally sized accepted records. Normal
accepted rows contain only the four exact short names. Initial acquisition is
inside one cleanup boundary, including failure after any prefix of the five
ancestor handles or after target open but before descriptor conversion. Closure
records distinguish absent file handles, successful closure, and actual errors;
all acquired ancestor handles are attempted in reverse order even after a file
closure error.

No original A4 methods run. The original 64 MiB guard is neither changed nor
invoked. Original 28-method order, source pins, R2 adapter, audit-refusal controls,
and Job checks remain unchanged. R01–R09 frozen contract remains unavailable;
A4-07 remains UNKNOWN_NO_REPLAY. No original award follows from this operation.
Native calls or a currently running child may outlast a cooperative check; the
workflow's 8-minute step and 12-minute job are external hard bounds. A hard
termination does not imply observed handle closure or complete workers; the
independent finalizer retains the actual partial bytes. Source definitions added
to the supervisor helper are also parsed by workers; their startup overhead
remains included in every raw worker lifetime peak. No baseline is subtracted.

## Implementation and evidence plan

1. Verify both frozen input packets and accepted profile/receiving seals. Capture
   the old diagnostic guard and accepted raw metadata as the baseline.
2. Copy exact retained dependencies, add the narrow supervisor receiver, and
   update only distinct operation paths, source receipt plumbing, and early
   partial-output retention. Keep worker/compiler/audit/Job functions unchanged.
3. Run bounded source/data controls for every admission predicate and the
   default real hardlink refusal; label them unit engineering. Run actual Linux
   refusal before output. Check syntax, workflow pins, source delta and exact
   inherited function/adapter preservation. Do not mock the OS into Windows or
   represent data controls as native qualification.
4. Recompute the complete additive host tree read-only from the unchanged
   source tree. Freeze a finite packet with exact hashes, source delta, report,
   controls and process census for independent cold review.

Acceptance for this author task is a reviewable source-only packet with truthful
bounds and evidence. Native interoperability remains unobserved until Root's
independent source gate and separately authorized first branch creation.
Rollback is omission of these four additive paths; no existing source changes.
No provider, Root-controller, native operation, branch, or original-suite action
is delegated to this author.
