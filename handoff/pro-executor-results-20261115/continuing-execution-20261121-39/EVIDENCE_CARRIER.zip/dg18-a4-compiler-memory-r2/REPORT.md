# A4 compiler-memory R2 author packet

Report state: FINAL — authored source-only packet for independent review.
Author: `/root/dg18_a4_next`. Authority and original awards: **NONE**.

The new packet provides a narrow, fresh receiver for the exact ucrt64 Git file
observed in the accepted native metadata operation. It retains the ordinary
compiler diagnostic's two compile workers and one audit worker. **The successor
has not executed on Windows, and it establishes no memory result or original A4
acceptance.** Root alone may publish and launch it after independent source
review and current provider gates.

## Input evidence and baseline

Root's native-profile adjudication accepted authentic bounded observations from
run **44960177535**, attempt 1, host
`53733a8081d518fdc58df9bfff0cefad618aea5c`, Windows image 20261116.370.1,
CPython 3.12.10 x64. The observed ucrt64 Git executable was a regular,
non-reparse **4,414,792-byte, four-link** file with SHA-256
`9bf8ee81d79f38a11eaf7799499a634c46a718e009a4a9b2b20b115804643302`.
Its native enumeration completed with exactly the four names recorded in the
new source's `GIT_ALIASES`. The native binary body was not archived. No prior
observation is reused as a current executable allowance.

The independent receiving seal is
`23fd3d64e5bd32f272c0e4c2b24a5171817636f0b13019d3f12cdd4c68b2e4c8`;
the raw seal is
`b25353cc50a485f449a455121bca39de456f30d73faeac5a445617c28f7a1011`;
Root's 2,670-byte adjudication is SHA-256
`bf11280969ee08eac284a1d14c10f27fa82f7f3128339655bf81b1f4d757d725`.
Their local bytes were checked before authoring. Full references and file pins
are in `EVIDENCE_INPUTS.json`.

The earlier compiler-memory run **44956925804** failed before source receiving,
Job import, output initialization, or any worker. Its combined type/link-count
condition did not record its selected spelling or either individual predicate.
This packet does not retroactively identify that historical cause. The earlier
compiler packet and accepted metadata packet remain byte-identical to their
seals; neither operation is replayed.

## Exact source proposal

Sole parent: `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7`.
Branch: `pro/dg18-a4-compiler-memory-51416-20261121-02`.
The complete expected additive tree and every byte/blob pin are in
`SOURCE_PINS.json`; the author made no Git object, index, commit, ref or provider
write. Root must verify branch absence and the complete immutable host tree.

Exactly four new host paths are proposed:

| Local packet member | Proposed host path |
|---|---|
| `workflow.yml` | `.github/workflows/dg18-a4-compiler-memory-r2.yml` |
| `compile_memory.py` | `handoff/pro-executor-results-20261115/dg18-a4-compiler-memory-r2/compile_memory.py` |
| `compile_adapter.py` | `handoff/pro-executor-results-20261115/dg18-a4-compiler-memory-r2/compile_adapter.py` |
| `observed_tool_profile.py` | `handoff/pro-executor-results-20261115/dg18-a4-compiler-memory-r2/observed_tool_profile.py` |

The 6,595-byte adapter is unchanged. The 28,985-byte metadata helper is also
byte-identical to the reviewed body that actually ran in the accepted metadata
operation. It is lazily loaded by the supervisor under a fixed byte/hash pin;
its `main`, provider binding, operation and finalizer are not called. Workers do
not import it. This reuse retains the exact reviewed CPython mode/ctime mapping
and bounded native alias enumeration.

The ordinary diagnostic's changed functions are only `tool_paths`, `git`,
`provider_binding` (new operation output), `source_receiving`, `host_receiving`
(explicit live receiver and fourth additive source), and `execute` (early
intent, live receiver lifetime, and closure before terminal success). The source
delta is retained in `SOURCE_DELTA.diff`.

## Current-operation admission and lifetime

Only `C:\Program Files\Git\ucrt64\bin\git.exe` can be selected. There is no
fallback search, wrapper substitution, other executable allowance, or returned
alias execution. `physical()` and `read_pinned()` retain their ordinary
single-link requirements unchanged for source files and other tools.

Before byte reads or alias enumeration, the held target must be an ordinary
disk file with the exact size/link count, expected final path, and the reviewed
path/descriptor semantic identity. Admission then requires a fresh held-file
hash and complete native EOF-terminated enumeration of the exact four unique
names. Same-API metadata retains full mode and ctime comparisons; the explicit
CPython 3.12.10 cross-API mapping is unchanged. Native volume serials are not
silently equated to or substituted for full stat-device values.

Five ancestors are opened root-first with access **0x81**
(FILE_LIST_DIRECTORY|FILE_READ_ATTRIBUTES), share READ|WRITE without DELETE,
OPEN_EXISTING, BACKUP_SEMANTICS and OPEN_REPARSE_POINT. Their ordinary directory
type, exact final path, and same-API metadata are checked. The target's
GENERIC_READ / FILE_SHARE_READ handle excludes write and delete sharing. All
handles are non-inheritable and remain held through the twelve existing Git
commands and three workers.

The directory access choice follows Microsoft's precise share-conflict rule:
an attributes-only handle does not supply the relevant access bit. The directory
list/read-data bit does. The initial unfrozen author draft was corrected before
freeze; it was never launched. Primary source references are in the design and
evidence index. No directory contents are enumerated by this receiver.

Each Git call has a fresh before/after observation. A terminal held-file rehash
must match before the receiver closes. PID and monotone native uptime bind the
observations to the same live process and retained handles; this receiver
cannot be serialized and reused across operations or boots. Historical file
indices, native serials, or timestamps are not pinned across separate VMs.

## Bounds, failure records, and cleanup

The fixed success path has **12 Git commands**, **26 receiving observations**,
**two held-file hashes**, **five held ancestors**, and **three sequential
workers** in the unchanged native/R2/audit order. Each alias enumeration retains
the existing 32-name/4,096-character limits and accepts only four exact names.
Each hash uses the existing 64 KiB streaming reads and 16 MiB+1 read cap while
requiring the exact 4,414,792-byte EOF. Accepted hashes therefore read 8,829,584
bytes in total; refusals are still bounded by the read caps.

Receiving has 45-second cooperative per-observation checks and a 420-second
cooperative supervisor deadline. Existing Git calls have 30-second timeouts;
each existing native Job has a 120-second timeout. The workflow supplies the
external **8-minute execute step, 1-minute finalizer, and 12-minute job** bounds.
Cooperative deadlines do not forcibly interrupt a blocked native call. The
external timeout remains the hard boundary.

`ADMISSION_INTENT.json` precedes tool acquisition. Acquisition and observation
records retain the current partial row and original error. Acquisition's
cleanup boundary covers every prefix of ancestor opens, target open, descriptor
conversion and initial receiving. Cleanup attempts the file handle and every
acquired ancestor in reverse order; failure does not skip later closures. The
record distinguishes no acquired file handle (`null`), actual successful
closure, and closure failure. Native handles are not acquired in `__init__`;
its failures can leave only the early intent/error.

Records are capped at 1 MiB, allowing a full refusing 32-name enumeration within
the fixed native buffer bounds. The existing independent always-run finalizer
retains at most 128 files, 2 MiB/file, 8 MiB aggregate, then uploads its sealed
archive and receipt for seven days. It does not retry workers or invent their
completion. A hard termination may leave only partial intent/observations;
absent closure or terminal records remain absent, not successful cleanup.

## Source and local qualification

`LOCAL_QUALIFICATION.json` records the actual commands and structured outputs.

- **28 admission/lifecycle controls passed:** retained authentic JSON exercises
  the exact predicate; altered hash/size/type/path/link/alias/metadata inputs
  refuse. Missing native-after metadata refuses without a secondary KeyError.
  Portable callback controls exercise pre-descriptor cleanup and cleanup
  continuation after a real Linux descriptor error plus a declared callback
  refusal. Those tokens are data, never actual Windows handles.
- **Actual Linux refusal passed** for execute, worker and finalizer before
  output. A real Linux hardlink remains refused by both generic guards.
- The four inherited small-source controls passed: exact-body drift refusal,
  compile-only equivalence/retention/boundaries, native audit-hook refusals and
  restoration, and non-Windows refusal. Only a controlled tiny body was compiled;
  no original product body or method executed.
- Syntax, workflow pins and first-creation/attempt-1 gates, credential-free
  checkouts, time bounds, exact dependency bytes, and the complete additive tree
  reconstruction passed. Sixteen inherited functions/classes and the product
  pins, modes, source commit/tree, adapter pin and 64 MiB reference are unchanged.

All local controls ran on actual Linux CPython **3.12.14**. No OS identity was
spoofed. Callback controls are unit engineering, not native evidence. No Windows
API, native Git, Job, original suite, provider mutation or controller operation
occurred in this author task. The new native acquisition/lifetime code remains
**UNOBSERVED** until an authorized reviewed run.

## Boundaries and remaining gate

The original **64 MiB** guard is unchanged and uninvoked. The original
**28-method order** is unchanged, and none of those methods run. The adapter,
native observer, compiler workload, audit-refusal controls, worker and Job
qualification are preserved. Additional helper definitions are parsed at worker
startup; every raw lifetime peak includes that overhead, and no baseline is
subtracted. This diagnostic cannot award or predict the original matrix.

R01–R09 original frozen body/locator remains missing. Root's bounded targeted
lookup supplied no new locator; this is not a global absence claim. A4-07
remains `UNKNOWN_NO_REPLAY`. Prior awards and unrelated work remain untouched.

Self-critique: the source design now explicitly handles the observed hardlinks
and holds names through use, but new directory-handle/runtime interoperability
has not run natively. Full same-API ancestor stability is deliberately
conservative and may refuse actual concurrent metadata change. A later runner
whose installed Git hash, size, aliases or runtime differs must refuse; a new
factual receiving and review would be required for any changed allowance.

The next step is **independent source review of this frozen packet**, then
Root's external currentness, exact sole-parent/full-tree and branch-absence
gates before any distinct first-push attempt. Authoring completion grants no
execution, readiness, release or original-award authority.
