#!/usr/bin/env python3
"""Linux source/data controls only. No native API, Git, Job, or original execution."""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

HERE=Path(__file__).resolve().parent
PROFILE=HERE.parent/'a4-tool-profile-native-44960177535/records/PROFILE-01.json'

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def main():
    if not (HERE/'compile_memory.py').is_file():
        print(json.dumps({'status':'EXPECTED_RED','reason':'successor implementation absent','native_calls':0}))
        return 1
    module=load('admission_source',HERE/'compile_memory.py')
    profile=load('profile_source',HERE/'observed_tool_profile.py')
    actual=json.loads(PROFILE.read_text())
    if actual['status']!='FACTUAL_PROFILE_OBSERVED_NO_ADMISSION':raise AssertionError('wrong retained data input')
    # Replaying retained JSON exercises only a predicate; it is never a new native observation.
    module.validate_git_metadata(profile,actual,hash_required=True)
    module.validate_git_metadata(profile,actual,baseline=actual,hash_required=True)
    controls=['accepted-raw-profile-data-matches-fixed-predicate']
    cases=[]
    def altered(label,change):
        row=copy.deepcopy(actual);change(row);cases.append((label,row))
    altered('different-content-hash',lambda r:r['hash'].update(sha256='0'*64))
    altered('different-held-size',lambda r:r['held_before']['fields'].update(st_size=1))
    altered('incomplete-hash',lambda r:r['hash'].update(status='ERROR'))
    altered('different-target-spelling',lambda r:r.update(path=r'C:\Program Files\Git\bin\git.exe'))
    altered('different-final-path',lambda r:r['native_final_path_after'].update(value=r'\\?\C:\elsewhere\git.exe'))
    altered('missing-native-after',lambda r:r.pop('native_after'))
    altered('retained-native-error',lambda r:r['errors'].append({'type':'CONTROL_ERROR'}))
    altered('reparse-file',lambda r:r['path_before'].update(reparse=True))
    altered('non-disk-type',lambda r:r.update(native_file_type=3))
    altered('unexpected-link-count',lambda r:r['native_after'].update(number_of_links=5))
    altered('incomplete-alias-enumeration',lambda r:r['hardlinks'].update(status='NATIVE_ERROR',winerror=234))
    altered('alias-close-failure',lambda r:r['hardlinks'].update(close_succeeded=False))
    altered('extra-alias',lambda r:r['hardlinks']['names'].append(r'\elsewhere\git.exe'))
    altered('missing-alias',lambda r:r['hardlinks']['names'].pop())
    altered('duplicate-alias',lambda r:r['hardlinks']['names'].__setitem__(1,r['hardlinks']['names'][0]))
    altered('opened-returned-alias',lambda r:r['hardlinks'].update(aliases_opened=1))
    altered('same-api-path-mode-drift',lambda r:r['path_final']['fields'].update(st_mode=0o100666))
    altered('same-api-descriptor-change-time-drift',lambda r:r['held_after']['fields'].update(st_ctime_ns=0))
    altered('ancestor-identity-drift',lambda r:r['ancestors_final'][0]['fields'].update(st_ino=1))
    altered('truncated-device-identity',lambda r:r['held_before']['fields'].update(st_dev=r['native_before']['volume_serial']))
    for label,row in cases:
        try:module.validate_git_metadata(profile,row,hash_required=True)
        except ValueError:controls.append(label+'-refused')
        else:raise AssertionError(label+' admitted')
    drift=copy.deepcopy(actual)
    for key in ('held_before','held_after'):drift[key]['fields']['st_ctime_ns']+=1
    try:module.validate_git_metadata(profile,drift,baseline=actual,hash_required=True)
    except ValueError:controls.append('stable-new-descriptor-state-differs-from-held-baseline-refused')
    else:raise AssertionError('inter-observation descriptor drift admitted')
    with tempfile.TemporaryDirectory(dir=HERE,prefix='unit-') as temp:
        root=Path(temp);target=root/'source.py';target.write_bytes(b'pass\n')
        pin={'bytes':5,'sha256':hashlib.sha256(b'pass\n').hexdigest()}
        if module.read_pinned(target,pin)!=b'pass\n':raise AssertionError('ordinary source read changed')
        os.link(target,root/'alias.py')
        for call in (lambda:module.physical(target),lambda:module.read_pinned(target,pin)):
            try:call()
            except ValueError:pass
            else:raise AssertionError('real Linux hardlink admitted by generic guard')
        controls.append('actual-Linux-generic-hardlink-refusal')
        # Portable lifecycle callback controls only. Tokens are data, never Windows handles.
        # No os.name/sys.platform override and no Native constructor or native API call.
        class CloseCallbacks:
            def __init__(self,refuse=None):self.calls=[];self.refuse=refuse
            def close(self,token):self.calls.append(token);return token!=self.refuse
            def win_error(self,label):return OSError('UNIT_CALLBACK_REFUSAL: '+label)
        def cleanup_control(fd=None,handle=None,refuse=None):
            item=module.HeldGit.__new__(module.HeldGit)
            item.fd=fd;item.handle=handle;item.profile=profile;item.native=CloseCallbacks(refuse)
            item.git_calls=0;item.sequence=0;item.finished=False
            item.directories=[{'path':Path('unit-parent'),'handle':'parent-token'},
                              {'path':Path('unit-child'),'handle':'child-token'}]
            rows=[];item.record=lambda name,row:rows.append((name,row))
            result=item.close()
            return item,result,rows
        item,closed,rows=cleanup_control(handle='pre-fd-target-token')
        if not closed or item.native.calls!=['pre-fd-target-token','child-token','parent-token']:
            raise AssertionError('pre-descriptor initialization cleanup skipped or reordered resources')
        if rows[0][1]['file_handle_closed']is not True or item.directories or item.handle is not None:
            raise AssertionError('initialization cleanup state/closure record differs')
        controls.append('unit-callback-pre-descriptor-initialization-cleanup')
        fd=os.open(target,os.O_RDONLY);os.close(fd)
        item,closed,rows=cleanup_control(fd=fd,refuse='child-token')
        if closed or item.native.calls!=['child-token','parent-token']:
            raise AssertionError('cleanup stopped after actual Linux descriptor error or callback refusal')
        record=rows[0][1]
        if record['status']!='HANDLE_CLEANUP_REFUSAL' or record['file_handle_closed']is not False or len(record['errors'])!=2:
            raise AssertionError('cleanup failures were promoted to closure')
        controls.append('unit-cleanup-retains-actual-Linux-fd-error-and-callback-refusal')
        for step in ('execute','worker','finalize'):
            output=root/('absent-'+step)
            command=[sys.executable,'-I','-B',str(HERE/'compile_memory.py'),'--step',step,
                     '--source',str(root),'--output',str(output)]
            if step=='worker':command.extend(('--mode','native'))
            result=subprocess.run(command,capture_output=True,timeout=10)
            if result.returncode==0 or output.exists() or b'actual Windows' not in result.stderr:
                raise AssertionError(step+' did not actually refuse Linux before output')
            controls.append('actual-Linux-'+step+'-refusal-before-output')
    print(json.dumps({'status':'PASS_SOURCE_AND_DATA_CONTROLS_ONLY','controls':controls,
        'profile_json_sha256':hashlib.sha256(PROFILE.read_bytes()).hexdigest(),
        'qualification_scope':'retained JSON, portable cleanup callbacks, and actual Linux refusals; no Windows simulation',
        'native_API_calls':0,'Git_executions':0,'Job_executions':0,'original_executions':0,
        'provider_writes':0,'python':sys.version},sort_keys=True,indent=2))
    return 0

if __name__=='__main__':raise SystemExit(main())
