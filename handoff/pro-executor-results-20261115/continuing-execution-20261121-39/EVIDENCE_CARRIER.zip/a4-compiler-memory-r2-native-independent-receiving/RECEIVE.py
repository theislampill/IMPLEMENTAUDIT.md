#!/usr/bin/env python3
"""Independent static receipt of an immutable actual run; no candidate import/execution."""
import ast
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import stat
import zipfile

ROOT=Path('/workspace/scratch/097486cde2dd')
RAW=ROOT/'a4-compiler-memory-r2-native-44964191955'
SOURCE=ROOT/'dg18-a4-compiler-memory-r2'
PRIOR=ROOT/'a4-compiler-memory-r2-independent-review'
PUB=ROOT/'a4-compiler-memory-r2-publication'
OUT=Path(__file__).absolute().parent
RUN=44964191955
COMMIT='105c6c197d27860dc63c4ed149011085ed8ca6a9'
TREE='098ff67306e52878422712f2a9ba082e98e7c5fa'
BASE='51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
BASE_TREE='9c3913ceaa95f3f36b0377fe2dba4a302afcba89'
BRANCH='pro/dg18-a4-compiler-memory-51416-20261121-02'
GIT_PATH=r'C:\Program Files\Git\ucrt64\bin\git.exe'
GIT_SHA='9bf8ee81d79f38a11eaf7799499a634c46a718e009a4a9b2b20b115804643302'
ALIASES={str(PureWindowsPath(r'\Program Files\Git\ucrt64\bin')/n) for n in ['git.exe','git-upload-pack.exe','git-receive-pack.exe','git-upload-archive.exe']}
PARENTS=[str(p) for p in reversed(PureWindowsPath(GIT_PATH).parents)]
assert len(PARENTS)==5

def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def js(path): return json.loads(path.read_bytes())
def record(path):
    assert stat.S_ISREG(path.lstat().st_mode) and not path.is_symlink()
    b=path.read_bytes()
    return {'path':str(path),'bytes':len(b),'sha256':sha(b)}
def inventory(root):
    paths={}
    for parent,dirs,files in os.walk(root,followlinks=False):
        for name in dirs+files:
            p=Path(parent)/name; st=p.lstat()
            assert not stat.S_ISLNK(st.st_mode)
            if stat.S_ISREG(st.st_mode): paths[p.relative_to(root).as_posix()]=record(p)
            else: assert stat.S_ISDIR(st.st_mode)
    return paths
def receive_seal(root,filename,expected_sha,expected_size):
    seal_path=root/filename; b=seal_path.read_bytes()
    assert sha(b)==expected_sha and len(b)==expected_size
    seal=json.loads(b); entries=seal['files']; actual=inventory(root)
    assert len({r['path'] for r in entries})==len(entries)
    assert set(actual)=={r['path'] for r in entries}|{filename}
    for row in entries:
        p=PurePosixPath(row['path']); assert not p.is_absolute() and '..' not in p.parts and str(p)==row['path']
        got=actual[row['path']]
        assert got['bytes']==row['bytes'] and got['sha256']==row['sha256']
        if 'git_blob' in row: assert blob((root/row['path']).read_bytes())==row['git_blob']
        if 'mode' in row:
            mode=row['mode'];expected_mode=int(mode,8)&0o777 if isinstance(mode,str) else mode
            assert stat.S_IMODE((root/row['path']).lstat().st_mode)==expected_mode
    return {'seal':record(seal_path),'count':len(entries),'bytes':sum(r['bytes'] for r in entries),'members':entries}

raw_receiving=receive_seal(RAW,'SEAL.json','524181ef0e38ca9a87639eb7546a4619229bd8faf04ef653ddbc35e33fb8fcfb',8923)
assert (raw_receiving['count'],raw_receiving['bytes'])==(52,593930)
source_receiving=receive_seal(SOURCE,'FROZEN_SEAL.json','2a267be1bacd9c735c14a9e42e4014fbd66af90c004866eeb4a7e96889226788',3515)
assert (source_receiving['count'],source_receiving['bytes'])==(13,162777)
prior_seal=record(PRIOR/'SEAL.json')
assert prior_seal['sha256']=='429162f6f6b1a3a5f940e7b3eaa9863607e26bd3eb93d9f063aa7a32986f3f6b'
prior_receiving=receive_seal(PRIOR,'SEAL.json',prior_seal['sha256'],prior_seal['bytes'])
prior_mech=js(PRIOR/'MECHANICAL_RECEIVING.json')
assert prior_mech['rederived_host_tree']==TREE and prior_mech['sole_parent']==BASE
pins=js(SOURCE/'SOURCE_PINS.json')
assert pins['expected_host_tree']==TREE and pins['sole_parent']==BASE and len(pins['changed_files'])==4
readback=js(PUB/'COMMITTED_FILE_READBACK.json')
assert (readback['commit'],readback['tree'],readback['parent'])==(COMMIT,TREE,BASE)
for row in pins['changed_files']:
    body=(SOURCE/row['local']).read_bytes()
    assert body==(RAW/'source'/row['path']).read_bytes()
    assert len(body)==row['bytes'] and sha(body)==row['sha256'] and blob(body)==row['git_blob']
    actual=next(r for r in readback['exact_file_readback'] if r['path']==row['path'])
    assert actual['bytes']==len(body) and actual['sha256']==sha(body) and actual['blob']==blob(body)
admission=js(PUB/'ROOT_ADMISSION.json')
assert admission['candidate_seal_sha256']==source_receiving['seal']['sha256']
assert admission['independent_source_review']['seal_sha256']==prior_seal['sha256']
assert admission['plan']==js(PUB/'PLAN.json') and admission['plan']['expected_tree']==TREE
publication=js(PUB/'PUBLICATION_RECEIPT.json')
assert (publication['commit'],publication['tree'],publication['parent'])==(COMMIT,TREE,BASE)
publication_receiving=[record(p) for p in sorted(PUB.iterdir()) if p.is_file()]

run=js(RAW/'RUN.json'); jobs=js(RAW/'JOBS.json')['jobs']; commit=js(RAW/'COMMIT.json'); branch=js(RAW/'BRANCH.json')
assert (run['id'],run['run_attempt'],run['head_sha'],run['head_branch'],run['event'],run['status'],run['conclusion'])==(RUN,1,COMMIT,BRANCH,'push','completed','failure')
assert run['path']==pins['workflow_path'] and run['run_number']==1
assert len(jobs)==1 and (jobs[0]['id'],jobs[0]['run_id'],jobs[0]['status'],jobs[0]['conclusion'])==(137029396727,RUN,'completed','failure')
assert commit['sha']==COMMIT and commit['tree']['sha']==TREE and [r['sha'] for r in commit['parents']]==[BASE]
assert branch['ref']=='refs/heads/'+BRANCH and branch['object']['sha']==COMMIT
artifacts=js(RAW/'ARTIFACTS.json')['artifacts']; assert len(artifacts)==1
artifact=artifacts[0]; outer=(RAW/'PROVIDER_ARTIFACT.zip').read_bytes()
assert artifact['id']==14730880971 and artifact['workflow_run']['id']==RUN and artifact['workflow_run']['head_sha']==COMMIT
assert len(outer)==artifact['size_in_bytes']==26684 and artifact['digest']=='sha256:'+sha(outer)
assert sha(outer)=='56913b5c836f07dc52b5752a4cef5b87597faeb51921f559fe5a84be1050c3c6'

def zip_members(data,root):
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        infos=z.infolist(); names=[i.filename for i in infos]
        assert len(names)==len(set(names)) and z.testzip() is None
        for i in infos:
            p=PurePosixPath(i.filename)
            assert not i.is_dir() and not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename
            mode=(i.external_attr>>16)&0xffff
            assert not mode or stat.S_IFMT(mode) in (0,stat.S_IFREG)
            assert z.read(i)==(root/i.filename).read_bytes()
        return [{'path':i.filename,'bytes':i.file_size,'compressed_bytes':i.compress_size,'crc32':i.CRC} for i in infos]
outer_members=zip_members(outer,RAW/'artifact')
assert {r['path'] for r in outer_members}=={'DIAGNOSTIC.zip','ZIP_RECEIPT.json'}
zipreceipt=js(RAW/'artifact/ZIP_RECEIPT.json'); inner=(RAW/'artifact/DIAGNOSTIC.zip').read_bytes()
assert zipreceipt['archive']=={'bytes':len(inner),'sha256':sha(inner)}
assert len(inner)==52724 and sha(inner)=='8b29edecd70f7cc76c2f23a8666b6e569af2cbe0ac17cf0f7c05aa3e198ec245'
inner_members=zip_members(inner,RAW/'diagnostic')
assert len(inner_members)==zipreceipt['members']==37
manifest=js(RAW/'diagnostic/MANIFEST.json')
assert len(manifest['members'])==36 and sum(r['bytes'] for r in manifest['members'])==manifest['bytes']==370969
assert set(inventory(RAW/'diagnostic'))=={r['path'] for r in manifest['members']}|{'MANIFEST.json'}
assert {r['path'] for r in inner_members}==set(inventory(RAW/'diagnostic'))
for row in manifest['members']:
    b=(RAW/'diagnostic'/row['path']).read_bytes(); assert len(b)==row['bytes'] and sha(b)==row['sha256']

D=RAW/'diagnostic'
intent=js(D/'INTENT.json'); before=js(D/'SOURCE_BEFORE.json'); acquire=js(D/'GIT_ACQUIRE.json'); closed=js(D/'GIT_CLOSED.json')
assert intent['host_commit']==COMMIT and intent['host_tree']==TREE and intent['source_commit']==BASE and intent['source_tree']==BASE_TREE
assert intent['run_id']==RUN and intent['attempt']==1 and intent['fixed_modes']==['native','r2','audit']
for key,local in [('helper','compile_memory.py'),('adapter','compile_adapter.py'),('observed_profile_helper','observed_tool_profile.py')]:
    body=(SOURCE/local).read_bytes();assert intent[key]=={'bytes':len(body),'sha256':sha(body)}
assert before['source_commit']==BASE and before['source_tree']==BASE_TREE and before['members']==pins['product_source_pins']
assert before['tools']==intent['tools']
gitpin={'path':GIT_PATH,'bytes':4414792,'sha256':GIT_SHA}
assert intent['tools']['git']==gitpin
assert acquire['receiver_pid']==closed['receiver_pid']==3460
assert acquire['status']=='EXACT_GIT_HELD_FOR_THIS_OPERATION' and acquire['errors']==[]
assert acquire['aliases_opened']==acquire['aliases_executed']==0 and acquire['handles_inheritable'] is False
assert acquire['file_share_mode']=='READ_ONLY_NO_WRITE_OR_DELETE' and acquire['directory_share_mode']=='READ_WRITE_NO_DELETE'
assert acquire['directory_access']=='FILE_LIST_DIRECTORY|FILE_READ_ATTRIBUTES (0x81)'
assert [r['path'] for r in acquire['directories']]==PARENTS

cross=('st_ino','st_dev','st_nlink','st_size','st_mtime_ns','st_birthtime_ns','st_file_attributes','st_reparse_tag')
fields=(*cross,'st_mode','st_ctime_ns','st_atime_ns')
def stat_identity(row):
    assert row['status']=='OBSERVED' and all(type(row['fields'][k]) is int for k in fields)
    return {k:v for k,v in row['fields'].items() if k!='st_atime_ns'}
def native_identity(row):return {k:v for k,v in row.items() if k!='access_filetime'}
def same(a,b): assert stat_identity(a)==stat_identity(b)
def safe_directory(row):
    stat_identity(row)
    assert row['directory'] is True and row['symlink'] is False and row['reparse'] is False
def directory(row,baseline=None):
    safe_directory(row['stat']); assert row['native_file_type']==1
    assert row['native']['file_attributes']&0x10 and row['native']['reparse'] is False
    assert row['final_path']['status']=='OBSERVED' and row['final_path']['value']=='\\\\?\\'+row['path']
    if baseline is not None:
        assert row['path']==baseline['path'];same(row['stat'],baseline['stat'])
        assert native_identity(row['native'])==native_identity(baseline['native'])
def cross_check(path,fd):
    p=stat_identity(path); f=stat_identity(fd)
    assert all(path[k] is value and fd[k] is value for k,value in [('regular',True),('directory',False),('symlink',False),('reparse',False)])
    assert all(p[k]==f[k] for k in cross)
    assert p['st_mode']==stat.S_IFREG|(0o444 if p['st_file_attributes']&1 else 0o666)|0o111
    assert f['st_mode']==stat.S_IFREG|(0o444 if f['st_file_attributes']&1 else 0o666)
    assert p['st_ctime_ns']==p['st_birthtime_ns']
    assert p['st_file_attributes']&0x410==0 and f['st_file_attributes']&0x410==0
    assert p['st_reparse_tag']==f['st_reparse_tag']==0
    assert p['st_size']==f['st_size']==4414792 and p['st_nlink']==f['st_nlink']==4
for row in acquire['directories']:
    same(row['before'],row['held']['stat']);directory(row['held'])
baselines={r['path']:r['held'] for r in acquire['directories']}
observations=[]; first=None;last_tick=acquire['uptime_start_ms']
for i,path in enumerate(sorted(D.glob('GIT_OBSERVATION-*.json')),1):
    row=js(path)
    expected_label='initial-admission' if i==1 else f'command-{i//2:02d}-'+('before' if i%2==0 else 'after')
    assert row['sequence']==i and row['label']==expected_label
    assert row['receiver_pid']==3460 and row['run_id']==RUN and row['host_commit']==COMMIT and row['attempt']==1
    assert row['status']=='EXACT_HELD_GIT_METADATA_MATCH' and row['errors']==[] and row['handle_closed'] is False
    assert row['path']==GIT_PATH and row['native_file_type']==1 and row['native_file_type_last_error']==0
    assert last_tick<=row['uptime_start_ms']<=row['uptime_end_ms'];last_tick=row['uptime_end_ms']
    same(row['path_before'],row['path_final']);same(row['held_before'],row['held_after'])
    cross_check(row['path_before'],row['held_before']);cross_check(row['path_final'],row['held_after'])
    assert native_identity(row['native_before'])==native_identity(row['native_after'])
    for n in ['native_before','native_after']:
        v=row[n]; assert v['number_of_links']==4 and v['file_bytes']==4414792 and v['reparse'] is False and v['file_attributes']&0x410==0
        assert v['file_index']==row['held_before']['fields']['st_ino']
    for n in ['native_final_path_before','native_final_path_after']:
        assert row[n]['status']=='OBSERVED' and row[n]['value']=='\\\\?\\'+GIT_PATH
    assert [r['path'] for r in row['ancestors_before']]==list(reversed(PARENTS))
    assert [r['path'] for r in row['ancestors_final']]==list(reversed(PARENTS))
    for a,b in zip(row['ancestors_before'],row['ancestors_final']):safe_directory(a);safe_directory(b);same(a,b)
    for n in ['ancestor_handles_before','ancestor_handles_after']:
        assert [r['path'] for r in row[n]]==PARENTS
        for d in row[n]:directory(d,baselines[d['path']])
    if first:
        same(first['path_final'],row['path_before']);same(first['held_after'],row['held_before'])
        assert native_identity(first['native_after'])==native_identity(row['native_before'])
        for a,b in zip(first['ancestors_final'],row['ancestors_before']):same(a,b)
    else:first=row;same(acquire['target_before_open'],row['path_before'])
    links=row['hardlinks']
    assert links['status']=='COMPLETE' and links['winerror']==38 and links['close_succeeded'] is True
    assert links['recorded_names']==len(links['names'])==4 and set(links['names'])==ALIASES
    assert links['aliases_opened']==links['aliases_admitted']==0
    assert all(v['equal'] is True for v in row['comparisons'].values())
    assert row['hash_required'] is (i==1)
    if i==1:assert row['hash']=={'status':'EOF_OBSERVED','bytes_read':4414792,'matches_held_size':True,'sha256':GIT_SHA}
    else:assert 'hash' not in row
    observations.append({'sequence':i,'label':row['label'],'uptime_start_ms':row['uptime_start_ms'],'uptime_end_ms':row['uptime_end_ms'],
                         'all_raw_predicates_rederived':True,'hash_required':row['hash_required'],'artifact':record(path)})
assert len(observations)==13 and closed['git_calls']==6 and closed['observations']==13
assert closed['status']=='ACQUIRED_HANDLES_CLOSED' and closed['file_handle_closed'] is True and closed['errors']==[]
assert closed['terminal_rehash_complete'] is False
assert closed['directory_handles']==[{'path':p,'closed':True} for p in reversed(PARENTS)]

job=js(D/'native/job/measurement.json'); start=js(D/'native/STARTED.json'); result=js(D/'native/RESULT.json'); err=js(D/'ERROR.json')
command=js(D/'native/COMMAND_INTENT.json')['command']
assert job['command']==command and command[0]==intent['tools']['python']['path'] and command[-1]=='native'
assert start['pid']==result['pid']==job['root_pid']==7412 and start['parent_pid']==3460
assert start['mode']==result['mode']=='native' and job['exit_code']==0
assert result['status']=='CONTROLLED_DIAGNOSTIC_COMPLETE_NO_A4_AWARD'
assert err['error_type']=='ValueError' and err['error']=='native Job conjunction incomplete' and err['completed_workers']==[]
module_ast=ast.parse((SOURCE/'compile_memory.py').read_bytes())
qualifier=next(n for n in module_ast.body if isinstance(n,ast.FunctionDef) and n.name=='qualify_job')
expected=ast.literal_eval(next(n.value for n in qualifier.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='expected' for t in n.targets)))
failed={k:{'expected':v,'actual':job.get(k)} for k,v in expected.items() if type(job.get(k)) is not type(v) or job[k]!=v}
assert failed=={k:{'expected':1,'actual':2} for k in ['kernel_total_processes','creation_event_count','exit_event_count']}
assert job['observed_processes']==[
    {'pid':7412,'in_job':True,'image':intent['tools']['python']['path'],'image_sha256':intent['tools']['python']['sha256']},
    {'pid':6124,'in_job':True,'image':r'C:\Windows\System32\conhost.exe','image_sha256':'4670e2d339001988eace0219462dfaa750418fddf09c004adb28f13aa8a4df2e'}]
assert job['process_observation_failures']==[] and job['process_events']==[
    {'event':'NEW_PROCESS','pid':7412},{'event':'NEW_PROCESS','pid':6124},
    {'event':'EXIT_PROCESS','pid':7412},{'event':'EXIT_PROCESS','pid':6124},
    {'event':'ACTIVE_PROCESS_ZERO','pid':0}]
assert job['containment_status']=='ROOT_EXITED_AND_JOB_EMPTY' and job['cleanup_complete'] is True
assert job['kernel_terminated_processes']==0 and job['terminal_active_processes']==0
assert job['sampled_pid_census_complete'] is False and set(job['sampled_pids'])=={7412,6124}
assert job['baseline_subtracted_bytes']==0 and job['metric_admission']=='UNADMITTED_DIAGNOSTIC'
assert (D/'native/job/stdout.bin').read_bytes()==(D/'native/job/stderr.bin').read_bytes()==b''
assert result['requests']==result['retained_results']==4 and result['code_equivalence'] is True and result['compile_restored'] is True
assert result['adapter']['installed'] is False and result['adapter']['requests']==result['adapter']['cache_hits']==result['adapter']['native_compilations']==0
for i,row in enumerate(result['request_population'],1):
    relative=['skills/implementaudit/scripts/claim-run-rotation.py','skills/implementaudit/scripts/rotate-canonical-state.py'][(i-1)//2]
    filename=str(PureWindowsPath(intent['source_path'])/PureWindowsPath(relative))
    assert row['request']==i and row['occurrence']==(i-1)%2+1 and row['source']==PurePosixPath(relative).name
    assert row['source_pin']==pins['product_source_pins'][relative] and row['filename_sha256']==sha(filename.encode())
memory=[];previous_peak=0;previous_time=start['started_ns']
for i,path in enumerate(sorted((D/'native/native-memory').glob('*.json')),1):
    row=js(path)
    label='worker-before-source' if i==1 else 'worker-after-source' if i==10 else 'before-compile' if i%2==0 else 'after-compile'
    req=None if i in (1,10) else i//2
    assert row['pid']==7412 and row['sequence']==i and row['label']==label and row['request']==req
    assert previous_peak<=row['lifetime_peak_working_set_bytes'] and 0<row['working_set_bytes']<=row['lifetime_peak_working_set_bytes']
    assert previous_time<=row['observed_ns']<=result['completed_ns']
    assert row['unchanged_reference_limit_bytes']==67108864 and row['guard_invoked'] is False and row['award'] is None
    previous_peak=row['lifetime_peak_working_set_bytes'];previous_time=row['observed_ns'];memory.append(row)
assert len(memory)==result['native_records']==10 and previous_peak==result['last_lifetime_peak_working_set_bytes']==44859392
absent=['r2','audit','RESULT.json','SOURCE_AFTER.json']
assert all(not (D/name).exists() for name in absent)
for row in [intent,err,result,manifest,zipreceipt,acquire,closed]:
    for key in ['original_guard_changed','original_guard_invoked','original_28_method_order_changed','original_28_methods_invoked']:
        assert row[key] is False
    assert row['original_method_executions']==row['product_body_executions']==row['baseline_subtracted_bytes']==0
    assert row['original_guard_bytes']==67108864 and row['A4_07']=='UNKNOWN_NO_REPLAY' and row['frozen_R01_R09_contract_available'] is False

job_source=Path('/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b/scripts/r0039-windows-job.py')
job_source_record=record(job_source)
assert {k:job_source_record[k] for k in ['bytes','sha256']}==pins['product_source_pins']['scripts/r0039-windows-job.py']
log=(RAW/'JOB_LOG.txt').read_text()
for literal in ['Version: 20261116.370.1','Successfully set up CPython (3.12.10)',
                'ValueError: native Job conjunction incomplete','Process completed with exit code 1.',
                'Artifact ID 14730880971',sha(outer)]: assert literal in log
log_evidence=[{'line':i,'text':line} for i,line in enumerate(log.splitlines(),1)
              if any(token in line for token in ['Image: windows-2022','Version: 20261116.370.1',
                'Successfully set up CPython (3.12.10)','ValueError: native Job conjunction incomplete',
                'Process completed with exit code 1.','SHA256 digest of uploaded artifact zip','Artifact ID 14730880971'])]
contract_body=ROOT/'a4-contract-current-intake-20261122/ISSUE215_BODY.md'
contract_record=record(contract_body)
assert contract_record['bytes']==35566 and contract_record['sha256']=='40dbebcc34083f49a49af13e5c6ab50ffe6fbf5a99395d9594926e4668fd09f1'
contract_line=contract_body.read_text().splitlines()[339]
assert '60,000 ms' in contract_line and '201,326,592 bytes (192 MiB)' in contract_line
assert 'verified process/descendant accounting' in contract_line and 'zero baseline subtraction' in contract_line
assert 'Existing security checks and test deadlines remain' in contract_line

report={'schema':'dg18.a4.compiler-memory-r2.independent-native-receiving.v1',
    'disposition':'PASS_RECEIVING_AUTHENTIC_FAILED_DIAGNOSTIC_NO_ORIGINAL_AWARD',
    'reviewer':'/root/independent_review','authority':'NONE',
    'root_binding':{'generation':'G0045','receipt':'da78b456997516f38e8e8b048c221bec6e4c0c4b','current_native':'9be00b/0'},
    'raw_receiving':raw_receiving,'source_receiving':source_receiving,'prior_independent_review_receiving':prior_receiving,
    'publication_input_receiving':publication_receiving,'matching_four_additions':pins['changed_files'],
    'reviewed_tree_binding':{'commit':COMMIT,'tree':TREE,'sole_parent':BASE,'prior_independent_rederived_tree':prior_mech['rederived_host_tree']},
    'provider':{k:run[k] for k in ['id','run_attempt','head_sha','head_branch','path','status','conclusion','event','created_at','updated_at','html_url']},
    'job_steps':jobs[0],'artifact':artifact,'outer_zip_members':outer_members,'inner_zip_members':inner_members,
    'held_git':{'git_pin':gitpin,'receiver_pid':3460,'acquired_ancestor_paths':PARENTS,
                'raw_comparisons_independently_rederived':True,'observations':observations,'closed':closed,
                'stat_device':first['path_before']['fields']['st_dev'],'native_volume_serial':first['native_before']['volume_serial'],
                'identifiers_not_coerced_or_truncated':True,'terminal_hash_absent':True},
    'native_worker':{'started':start,'result':result,'job_measurement':job,'memory_records':memory,
                     'immediate_failed_conjuncts':failed,'later_single_image_population_predicate':False,
                     'later_single_image_predicate_was_not_reached':True,'job_source':job_source_record},
    'error':err,'absent_stages_and_bookends':absent,'log_evidence':log_evidence,
    'population_restriction_provenance':{
        'exactly_one_total_created_exited_and_observed_Python':'additional compile_memory.py:478-491 diagnostic predicate',
        'pinned_job_reconcile':'r0039-windows-job.py:42-88 permits positive reconciled totals with exactly one root lifetime',
        'actual_total_two_event_reconciliation':True,
        'current_Issue215_body':contract_record,
        'current_Issue215_body_receipt':record(ROOT/'a4-contract-current-intake-20261122/BODY_RECEIPT.json'),
        'current_Issue215_applicable_clause_line':340,
        'prospective_192_MiB_envelope_does_not_replace_preserved_A4_64_MiB_guard':True,
        'original_unavailable_R01_R09_contract_interpreted':False,
        'changed_population_or_future_original_admitted':False},
    'candidate_product_native_or_Git_execution_by_receiver':False,'source_or_provider_or_controller_mutation':False,
    'original_execution_or_award':False,'automatic_retry':False,
    'limits':['actual worker and raw Job observations are partial diagnostic evidence',
              'no R2 reuse comparison or audit refusal worker observation',
              'no final source/host bookend or held-Git terminal rehash',
              'no original 64 MiB guard or original methods invoked',
              'actual two-process population is not admitted by receiving']}
(OUT/'MECHANICAL_RECEIVING.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps({'status':report['disposition'],'raw_files':52,'raw_bytes':593930,'inner_members':37,
                  'native_worker_exit':job['exit_code'],'immediate_failed_conjuncts':failed,'memory_records':len(memory),
                  'last_raw_lifetime_peak_working_set_bytes':previous_peak,'git_calls':6,'git_observations':13,
                  'held_handles_closed':True,'terminal_rehash':False,'original_executions':0,'original_awards':0}))
