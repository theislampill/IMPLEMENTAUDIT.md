# A4 compiler-memory R2: focused independent source review

**Disposition: PASS for the focused pre-execution source review.** No further source revision is required by this review. The new allowance is restricted to fresh receiving of one exact installed Git file while its file and ancestor handles remain held. Generic single-link guards, compiler/audit behavior and original-method boundaries remain intact. The successor's new native acquisition and execution path remains **UNOBSERVED**; this review grants no execution admission or original A4 award.

Reviewer: `/root/a4_tool_profile_r2_review`; authority **NONE**. This is ordinary independent engineering review, not an internal `audit-assess` activation. The reviewer authored no candidate and made no candidate, provider or controller change. Review operations were source reads, hashes, AST/YAML checks, exact comparisons, local immutable-object decoding and read-only primary-documentation retrieval. No candidate module or qualification control was imported or executed; no Windows, Git, Job, protected or original operation ran. No nested agent was used.

## Exact packet and tree receiving

| Item | Independently received identity |
|---|---|
| Frozen source seal | **3,515 bytes**; SHA-256 `2a267be1bacd9c735c14a9e42e4014fbd66af90c004866eeb4a7e96889226788` |
| Payload | Exact **13 members / 162,777 bytes**; all sizes, SHA-256 values, Git blob IDs and modes match |
| Sole proposed parent | `51416b2f156b341c4a5f09029e2c6ceb5b30b1e7` |
| Parent tree | `9c3913ceaa95f3f36b0377fe2dba4a302afcba89`, **1,785 leaves** |
| Independently rederived new tree | `098ff67306e52878422712f2a9ba082e98e7c5fa`, **1,789 leaves** |
| Proposed branch | `pro/dg18-a4-compiler-memory-51416-20261121-02` |
| Exact source/workflow delta | Two sections, **ten hunks**, 34,380 bytes; SHA-256 `46b81e0fdcdbfb9031b087d87edfd165ed3b9bd862489e5d30cfdab659957bdc` |

The four additions are:

| Hosted addition | Bytes | SHA-256 |
|---|---:|---|
| `.github/workflows/dg18-a4-compiler-memory-r2.yml` | 5,224 | `15a9d3d11137a626ce0b306f77e72a8be30bbb674d4994775bbc3249162b5f13` |
| `handoff/pro-executor-results-20261115/dg18-a4-compiler-memory-r2/compile_memory.py` | 40,124 | `5b1c69db38ba68dfb436cbef190efa04d5a592e6b3fd0260346a0da138577a34` |
| Same directory, `compile_adapter.py` | 6,595 | `4baffb9fdadde5333a1bf535593d4aa794936578be297b1ce723e1f0bd1683b2` |
| Same directory, `observed_tool_profile.py` | 28,985 | `aa61123993614898f8d731352d04862a5a8fe9b77d1811f640e40870e8bf09b5` |

The complete base tree was reconstructed from existing immutable local objects, then only these four leaves were added. No Git process, history walk, fetch, object/index/ref mutation or provider call was used. All original leaves remain unchanged, and the two inherited workflow push filters do not select this new branch.

The nine-member old compiler packet, accepted metadata source packet, five-member independent native receiving packet and 29-member raw native evidence packet were all rehashed unchanged. Every `EVIDENCE_INPUTS.json` pin also matches, including Root's 2,670-byte native-profile adjudication. The adapter and inherited diagnostic control file remain byte-identical to the old compiler packet; the reused metadata helper remains byte-identical to the body that ran in the accepted metadata operation.

Mechanical receiving passed as **`9f1d99/0`**. Its complete result is `MECHANICAL_RECEIVING.json` (34,314 bytes, SHA-256 `f0352c55f49529978499faf56308a0f065046a9224c1adac65373fc725c96323`). Five Python files parse, the workflow parses, and the exact delta reconstructs. The reviewer did not rerun the author's controls.

## Fresh native admission and use lifetime

### One explicit allowance; generic guards preserved

`physical()` and `read_pinned()` are byte-identical to the prior compiler diagnostic and still reject nonregular, reparse/symlink and multiply linked ordinary inputs. `tool_paths()` continues to require the single-link physical Python installation. The only special executable spelling is `C:\Program Files\Git\ucrt64\bin\git.exe`; there is no search or fallback to `Git\bin`, mingw64, a returned alias, or another wrapper.

Historical native observations supply constraints, not a cached permission. Current admission requires the exact **4,414,792-byte** EOF and SHA-256 `9bf8ee81d79f38a11eaf7799499a634c46a718e009a4a9b2b20b115804643302`, ordinary disk-file type, exact final path, link count four through all recorded metadata routes, and complete EOF-terminated enumeration of the four unique fixed names. Returned aliases are neither opened nor executed.

The byte-identical metadata helper supplies the reviewed CPython 3.12.10 executable-mode/ctime mapping, bounded alias enumerator and raw-stat helpers. Its operation, provider binding and finalizer are not called. Full path-to-path, descriptor-to-descriptor and ancestor-to-ancestor comparisons still include complete mode and ctime; read-sensitive access time is the existing exclusion. Native volume serials remain separate from full stat-device values. Missing or differing observations refuse instead of guessing correspondence.

### Access and sharing are appropriate to the intended held-name path

Five ancestors are acquired root-first. The source requests directory access `0x81`, share `3` (read/write without delete), `OPEN_EXISTING`, and `BACKUP_SEMANTICS|OPEN_REPARSE_POINT`. The target requests `GENERIC_READ`, read-only sharing and `OPEN_REPARSE_POINT`. NULL security attributes make these handles noninheritable at creation. The directory path/type/final-name checks and same-API comparisons bracket acquisition; each held directory receives a baseline before later use.

Microsoft's [CreateFileW documentation](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilew) supports these directory flags, noninheritance and share-mode rules. The [MS-FSA sharing algorithm](https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-fsa/82b364ce-6d7b-422f-8d88-4db32eea809a), together with the [access-right constants](https://learn.microsoft.com/en-us/windows/win32/fileio/file-access-rights-constants), supports the important `0x81` choice: the directory list/data bit participates in delete-sharing conflicts; attributes-only access would not suffice. These are source/API conclusions, not a native test of this new directory-acquisition path.

Sharing does not freeze every attribute or extended-attribute operation. Exact repeated metadata comparisons remain necessary, and the source retains them. This review does not expand the claim to universal metadata immutability. Any observed drift or incompatible open refuses the operation.

`HeldGit` keeps the target and all acquired ancestors through the twelve direct Git commands and all three workers. Every Git command has before/after receiving; every later observation is compared to the live initial admission, not merely to its own internal pair. The terminal observation repeats the held-file hash before closure. Exact final-path and alias checks recur without opening the returned names.

PID and monotonically checked [native uptime](https://learn.microsoft.com/en-us/windows/win32/api/sysinfoapi/nf-sysinfoapi-gettickcount64) support continuity of this live receiver. Uptime is not treated as a unique boot identifier. The operational lifetime also depends on the same in-memory object and retained handles; nothing serializes this object into a reusable historical allowance.

## Acquisition failure, ownership and closure

`ADMISSION_INTENT.json` is written before construction/acquisition. The constructor obtains no target or ancestor file handles. Its failure therefore reaches the outer error record without an acquired file-handle population to release.

`__enter__()` places the complete acquisition sequence inside a `BaseException` cleanup boundary. Each successful ancestor open is registered before subsequent metadata checks. Target open is registered before CRT conversion. Before successful `open_osfhandle`, the native handle owns closure; after successful conversion, the descriptor owns closure, including a later binary-mode failure. This avoids relying on `__exit__()` for an entry operation that never succeeded.

On acquisition refusal, the current acquisition/error row is attempted, and `close()` runs in a `finally` even if that record write fails. Normal observation failures append their error to the partial row, and each observation record is attempted in a `finally`. A successfully entered receiver closes on both normal and exceptional exits.

Cleanup attempts the file owner and then all acquired ancestor handles in reverse order. A returned native-close failure or ordinary descriptor-close error is retained and does not skip later ancestors. Records distinguish no acquired file handle (`null`), successful closure, and closure failure. The normal-path `__exit__` refuses if cleanup is incomplete. The supervisor's successful terminal result is written only after the `with HeldGit(...)` scope exits successfully; it therefore cannot claim observed closure merely because the worker loop ended.

The retained lifecycle controls exercise callback-based pre-descriptor cleanup and continuation after a real Linux descriptor error plus a declared callback refusal. Those controls do not establish native Windows cleanup. Abrupt termination or a failure to write evidence can still leave missing/partial records; missing records must not be inferred as successful closure.

## Compiler, original-method and memory boundaries

**Sixteen inherited definitions are byte-identical:** `digest`, `canonical`, `write_json`, `unsafe`, `physical`, `read_pinned`, `require_windows`, `load_adapter`, `NativeMemory`, `compile_workload`, `audit_controls`, `environment`, `worker`, `qualify_job`, `finalize`, and `main`. Existing context fields and the product pins, source commit/tree, adapter pin, mode order and 64 MiB reference are also unchanged.

The worker sequence remains `native`, `r2`, `audit`. The two compilation workers compile the same two exact product bodies twice each and retain four code objects; they do not execute those product bodies. Each compilation worker retains ten native memory observations. The audit worker preserves the native hook/refusal and restoration checks. The adapter's exact-byte cache eligibility, filename behavior, audit-hit callback and native-compiler restoration are unchanged.

The pinned Job harness still starts the worker suspended, assigns it before resume, retains kill-on-close with no breakaway, and requires a complete one-process census and cleanup. The exact Job source body was independently received from the pinned parent and compared with the body inspected for containment/cleanup. Its explicit inherited-handle list is limited to the worker's three standard streams; held Git/ancestor handles are not added to that list.

The original **64 MiB guard is unchanged and uninvoked**. The original **28-method order is unchanged and none of those methods run**. No original test, product body, adapter cache allowance or raw-memory number is promoted to original A4 acceptance. Added helper definitions are parsed at worker startup, so their overhead remains within the raw worker lifetime peaks. The supervisor and live receiving work are outside each worker Job; no baseline is subtracted.

## Resource and retention bounds

| Surface | Reviewed bound and interpretation |
|---|---|
| Git target and handles | One fixed target; exactly five ancestors; no alias execution or fallback |
| Git commands and receiving | At most twelve commands, 26 receiving observations and two held hashes on the complete path |
| Hashing | Existing 64 KiB chunks and 16 MiB-plus-sentinel read cap; accepted hashes require exactly 4,414,792 bytes each, 8,829,584 bytes combined |
| Enumeration | Existing 32-name / 4,096-character limits; acceptance requires four exact unique names and completed enumeration/closure |
| Receiving record | 1 MiB; the finite metadata plus one maximum refusing name population fits the declared construction |
| Internal timing | 45-second cooperative observation checks; 420-second cooperative receiver deadline; direct Git timeout 30 seconds |
| Workers | Three sequential Jobs with 120-second diagnostic timeout; inherited containment/cleanup has its own bounded waits |
| External timing | Eight-minute execute step, one-minute independent finalizer, twelve-minute job |
| Retention | At most 128 pre-manifest files, 2 MiB per file and 8 MiB aggregate payload; exclusive archive/receipt and seven-day artifact retention |

The source-defined ordinary complete path produces 71 files before finalization, then its finalization intent brings the pre-manifest population to 72, within the 128-file cap. This count includes all 26 new observations, twenty worker memory records, three worker record sets and three Job record sets.

The internal deadlines are not additive promises that every operation completes within its nominal limit. The inherited Job may spend additional time observing termination/cleanup after its diagnostic timeout, and a cooperative check cannot interrupt a blocked native call. The external step/job timeouts bound that remaining lifetime. Partial capture requires the runner and finalizer/uploader to survive; the finalizer preserves existing bytes and does not infer absent observations, closure or worker completion.

The first-creation/attempt-1 workflow gate is preserved on a distinct branch and artifact namespace. Both checkouts and all three actions remain exactly pinned, with credential persistence, submodules and LFS disabled. Execute pins the helper and both dependencies; independent finalization pins the helper again and loads no native Git receiver or worker. Root retains the external full-tree/sole-parent, immutable-file and branch-absence gate.

## Qualification scope and return

The retained qualification record contains 28 admission/data/Linux lifecycle controls and four inherited compiler/audit controls, all bound to the exact frozen source hashes. The reviewer read their complete source and retained results. They test predicates, actual Linux refusals and portable cleanup behavior; they do not qualify new Windows directory sharing, target execution while held, successful Job execution or timeout recovery. No additional control execution was necessary for this source review.

The remaining native question is whether this exact fresh acquisition and held-use path interoperates with the intended Windows image and installed file. A changed digest, alias set, runtime, native error, observed metadata drift or incomplete cleanup must remain a refusal. Root may consider a separate admitted first attempt after its currentness/provider gates; this PASS itself grants no readiness or launch authority.

Root supplied G0044 currentness `526481/0`, receipt `dg16-dg18-recovery-20261119-b/G0044@3fb3e2d80b1575b3a4ec28cc196957f9ce498523`, and Results37 `04c060ca856d3b0865fec0eacb0c16391ce013bb`. After the reviewer's context boundary, Root supplied fresh currentness `6e3498/0` at 23:50:28 UTC under the same receipt and authorized only report readback, closing hashes and sealing. Root reported its intake `a94341/0` had verified all 13 payloads / 162,777 bytes; the target branch and runs remained absent at its preflight and no A4 R2 provider write had been issued. These are Root-supplied status facts, not new provider observations by this reviewer. This reviewer did not mint or change continuity. The historical queued run and all unrelated work were untouched. The authentic frozen R01–R09 body and locator remain unavailable; A4-07 remains `UNKNOWN_NO_REPLAY`. **New original awards: NONE. Original A4 remains unaccepted.**
