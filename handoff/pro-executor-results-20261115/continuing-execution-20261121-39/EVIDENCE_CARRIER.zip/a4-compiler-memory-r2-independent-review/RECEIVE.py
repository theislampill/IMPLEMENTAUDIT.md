#!/usr/bin/env python3
"""Read/hash/AST/YAML receiving only; no candidate import or native execution."""
import ast
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import yaml

ROOT = Path('/workspace/scratch/097486cde2dd')
SOURCE = ROOT / 'dg18-a4-compiler-memory-r2'
OLD = ROOT / 'dg18-a4-next'
HERE = Path(__file__).resolve().parent
BASE = '9c3913ceaa95f3f36b0377fe2dba4a302afcba89'
PARENT = '51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
EXPECTED = '098ff67306e52878422712f2a9ba082e98e7c5fa'

def digest(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def receive(path):
    before = path.lstat(); raw = path.read_bytes(); after = path.lstat()
    project = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and project(before) == project(after)
    return raw, {**digest(raw), 'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest(),
                 'mode': format(stat.S_IFREG | stat.S_IMODE(before.st_mode), 'o')}

def packet(path, name, seal_sha, count, size, exact=True):
    raw, identity = receive(path / name)
    assert identity['sha256'] == seal_sha
    data = json.loads(raw)
    if exact:
        assert {p.name for p in path.iterdir()} == {name, *(row['path'] for row in data['files'])}
    entries = []
    for row in data['files']:
        _, actual = receive(path / row['path'])
        assert all(actual[key] == row[key] for key in ('bytes', 'sha256', 'git_blob'))
        assert actual['mode'] == row.get('mode', '100644')
        entries.append({'path': row['path'], **actual})
    assert len(entries) == data['payload_count'] == count
    assert sum(row['bytes'] for row in entries) == data['payload_bytes'] == size
    return {'seal': identity, 'files': entries, 'payload_count': count, 'payload_bytes': size}

def main():
    source = packet(SOURCE, 'FROZEN_SEAL.json', '2a267be1bacd9c735c14a9e42e4014fbd66af90c004866eeb4a7e96889226788', 13, 162777)
    assert source['seal']['bytes'] == 3515
    old = packet(OLD, 'FROZEN_SEAL.json', '2ecaf2ba169f07ab34692b1f4644ed58ae2357a7f00d0bd3b2488a8035d17085', 9, 57967)
    profile = packet(ROOT / 'dg18-a4-tool-profile-r2', 'FROZEN_SEAL.json', '49a8176eda0d51b9208518b3db5a5418ab24b294d4ec5d75c4cacc1166fcb7b3', 12, 94459)
    native = packet(ROOT / 'a4-tool-profile-native-independent-receiving', 'SEAL.json', '23fd3d64e5bd32f272c0e4c2b24a5171817636f0b13019d3f12cdd4c68b2e4c8', 5, 47611)
    raw_native = packet(ROOT / 'a4-tool-profile-native-44960177535', 'RAW_SEAL.json', 'b25353cc50a485f449a455121bca39de456f30d73faeac5a445617c28f7a1011', 29, 207051, exact=False)
    evidence = json.loads((SOURCE / 'EVIDENCE_INPUTS.json').read_bytes())
    inputs = []
    for row in evidence['files']:
        _, actual = receive(Path(row['path']))
        assert all(actual[k] == row[k] for k in ('bytes', 'sha256', 'git_blob'))
        inputs.append({'role': row['role'], 'path': row['path'], **actual})
    assert (SOURCE / 'compile_adapter.py').read_bytes() == (OLD / 'compile_adapter.py').read_bytes()
    assert (SOURCE / 'qualify_diagnostic.py').read_bytes() == (OLD / 'qualify_diagnostic.py').read_bytes()
    assert (SOURCE / 'observed_tool_profile.py').read_bytes() == (ROOT / 'dg18-a4-tool-profile-r2/tool_profile.py').read_bytes()
    sources = {p.name: p.read_text() for p in SOURCE.glob('*.py')}
    trees = {name: ast.parse(text, filename=name) for name, text in sources.items()}
    old_text = (OLD / 'compile_memory.py').read_text()
    old_ast = ast.parse(old_text); new_ast = trees['compile_memory.py']
    defs = lambda t: {n.name: n for n in t.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    old_defs, new_defs = defs(old_ast), defs(new_ast)
    unchanged = []; changed = []
    for name, node in old_defs.items():
        before, after = ast.get_source_segment(old_text, node), ast.get_source_segment(sources['compile_memory.py'], new_defs[name])
        if before == after:
            assert ast.dump(node) == ast.dump(new_defs[name])
            unchanged.append({'name': name, **digest(before.encode())})
        else:
            changed.append(name)
    expected_unchanged = ['digest', 'canonical', 'write_json', 'unsafe', 'physical', 'read_pinned', 'require_windows',
                         'load_adapter', 'NativeMemory', 'compile_workload', 'audit_controls', 'environment',
                         'worker', 'qualify_job', 'finalize', 'main']
    assert [r['name'] for r in unchanged] == expected_unchanged
    assert changed == ['tool_paths', 'git', 'provider_binding', 'source_receiving', 'host_receiving', 'execute']
    added = sorted(set(new_defs) - set(old_defs))
    assert added == sorted(['load_observed_profile', 'native_identity', 'validate_git_metadata', 'HeldGit'])
    assignments = lambda t: {n.targets[0].id: n.value for n in t.body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)}
    old_assignments, new_assignments = assignments(old_ast), assignments(new_ast)
    constants = ['ADAPTER_PIN', 'MODES', 'REFERENCE_LIMIT', 'SOURCE_COMMIT', 'SOURCE_PINS', 'SOURCE_TREE']
    assert all(ast.dump(old_assignments[k]) == ast.dump(new_assignments[k]) for k in constants)
    context = lambda n: {ast.literal_eval(k): v for k, v in zip(n.keys, n.values)}
    old_context, new_context = context(old_assignments['CONTEXT']), context(new_assignments['CONTEXT'])
    assert all(ast.dump(v) == ast.dump(new_context[k]) for k, v in old_context.items())
    assert set(new_context) - set(old_context) == {'source_revision', 'tool_admission'}
    assert ast.literal_eval(new_assignments['REFERENCE_LIMIT']) == 67108864
    assert ast.literal_eval(new_assignments['MODES']) == ('native', 'r2', 'audit')
    delta = ''.join(''.join(difflib.unified_diff((OLD / name).read_text().splitlines(keepends=True),
                        (SOURCE / name).read_text().splitlines(keepends=True),
                        fromfile='frozen-r1/' + name, tofile='proposed-r2/' + name))
                    for name in ('compile_memory.py', 'workflow.yml'))
    assert delta.encode() == (SOURCE / 'SOURCE_DELTA.diff').read_bytes()
    controls = json.loads((SOURCE / 'LOCAL_QUALIFICATION.json').read_bytes())['checks']
    for name, pin in controls['tested_source_members'].items():
        _, actual = receive(SOURCE / name)
        assert all(actual[k] == pin[k] for k in ('bytes', 'sha256', 'git_blob'))
    assert len(controls['qualify_admission.py']['stdout']['controls']) == 28
    assert len(controls['qualify_diagnostic.py']['stdout']['controls']) == 4
    assert controls['qualify_admission.py']['exit_code'] == controls['qualify_diagnostic.py']['exit_code'] == 0
    # Reuse only the already-sealed reviewer's local Git object decoder. It has
    # no candidate import, automatic main call, native call, fetch, or Git process.
    object_reader = ROOT / 'a4-tool-profile-r2-independent-review/RECEIVE.py'
    object_pin = next(x for x in json.loads((object_reader.parent / 'SEAL.json').read_bytes())['files'] if x['path'] == object_reader.name)
    _, actual_reader = receive(object_reader)
    assert all(actual_reader[k] == object_pin[k] for k in ('bytes', 'sha256', 'git_blob'))
    spec = importlib.util.spec_from_file_location('review_object_reader', object_reader)
    helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    store = helper.LocalObjects()
    kind, commit = store.get(PARENT)
    assert kind == 'commit' and commit.splitlines()[0] == b'tree ' + BASE.encode()
    leaves = {}
    def visit(key, prefix=b''):
        kind, raw = store.get(key); assert kind == 'tree'
        for mode, name, child in helper.tree_entries(raw):
            path = prefix + name
            if mode == b'40000':
                visit(child, path + b'/')
            else:
                assert path not in leaves
                leaves[path] = mode, child
    visit(BASE)
    assert len(leaves) == 1785 and helper.rebuild(leaves) == BASE
    pins = json.loads((SOURCE / 'SOURCE_PINS.json').read_bytes())
    assert pins['sole_parent'] == PARENT and pins['source_tree'] == BASE and pins['expected_host_tree'] == EXPECTED
    additions = []
    for row in pins['changed_files']:
        _, actual = receive(SOURCE / row['local'])
        assert all(actual[k] == row[k] for k in ('bytes', 'sha256', 'git_blob', 'mode'))
        assert row['path'].encode() not in leaves
        leaves[row['path'].encode()] = row['mode'].encode(), row['git_blob']
        additions.append({'path': row['path'], **actual})
    assert len(additions) == 4 and len(leaves) == 1789 and helper.rebuild(leaves) == EXPECTED
    product = []
    for path, pin in pins['product_source_pins'].items():
        mode, key = leaves[path.encode()]
        kind, raw = store.get(key); assert kind == 'blob' and digest(raw) == pin
        product.append({'path': path, 'mode': mode.decode(), 'git_blob': key, **digest(raw)})
        if path == 'scripts/r0039-windows-job.py':
            assert raw == Path('/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b/scripts/r0039-windows-job.py').read_bytes()
    inherited = []
    for path, (mode, key) in leaves.items():
        if path.startswith(b'.github/workflows/') and path.decode() != pins['workflow_path']:
            kind, raw = store.get(key); assert kind == 'blob'
            inherited.append({'path': path.decode(), 'git_blob': key, 'on': yaml.load(raw, Loader=yaml.BaseLoader)['on']})
    workflow = yaml.load((SOURCE / 'workflow.yml').read_bytes(), Loader=yaml.BaseLoader)
    job = workflow['jobs']['compile-only-native-diagnostic']
    assert workflow['on']['push']['branches'] == [pins['branch']]
    assert workflow['on']['push']['paths'] == [x['path'] for x in pins['changed_files']]
    assert job['runs-on'] == 'windows-2022' and job['timeout-minutes'] == '12'
    execute, finalize, upload = job['steps'][3:]
    assert execute['timeout-minutes'] == '8' and finalize['timeout-minutes'] == '1'
    assert finalize['if'] == upload['if'] == 'always()'
    for step in job['steps'][:2]:
        assert step['with']['persist-credentials'] == 'false' and step['with']['submodules'] == step['with']['lfs'] == 'false'
    for name in ('compile_memory.py', 'compile_adapter.py', 'observed_tool_profile.py'):
        assert hashlib.sha256((SOURCE / name).read_bytes()).hexdigest() in execute['run']
    assert hashlib.sha256((SOURCE / 'compile_memory.py').read_bytes()).hexdigest() in finalize['run']
    result = {'schema': 'dg18.a4.compiler-memory-r2-independent-mechanical.v1', 'authority': 'NONE',
              'mechanical_receiving': 'PASS', 'source_packet': source, 'old_compiler_preserved': old,
              'profile_source_preserved': profile, 'native_receiving_preserved': native, 'raw_native_preserved': raw_native,
              'evidence_input_pins': inputs, 'syntax_files': sorted(trees), 'candidate_imports': 0, 'candidate_executions': 0,
              'source_delta': {**digest(delta.encode()), 'sections': 2, 'hunks': sum(x.startswith('@@ ') for x in delta.splitlines())},
              'byte_identical_inherited_definitions': unchanged, 'changed_existing_definitions': changed,
              'new_definitions': added, 'unchanged_constants': constants, 'all_existing_context_fields_preserved': True,
              'reported_control_counts': {'admission_data_and_Linux': 28, 'inherited_compiler_audit': 4, 'reviewer_controls_rerun': 0},
              'sole_parent': PARENT, 'base_tree': BASE, 'base_leaf_count': 1785, 'rederived_host_tree': EXPECTED,
              'new_leaf_count': 1789, 'only_additions': additions, 'product_body_pins': product,
              'inherited_workflow_triggers': inherited, 'workflow': workflow, 'local_object_decoder': actual_reader,
              'local_object_count': len(store.resolved), 'Git_processes': 0, 'commit_history_walked': False,
              'native_calls': 0, 'product_Job_original_executions': 0, 'provider_writes': 0,
              'Root_controller_calls': 0, 'new_original_awards': []}
    body = (json.dumps(result, sort_keys=True, indent=2) + '\n').encode()
    with (HERE / 'MECHANICAL_RECEIVING.json').open('xb') as stream:
        stream.write(body)
    print(json.dumps({'mechanical_receiving': 'PASS', 'payloads': 13, 'payload_bytes': 162777,
                      'old_compiler_payloads_preserved': 9, 'inherited_definitions_byte_identical': len(unchanged),
                      'delta_sections': 2, 'delta_hunks': result['source_delta']['hunks'], 'rederived_tree': EXPECTED,
                      'new_leaf_count': 1789, 'receipt': digest(body)}, indent=2))

if __name__ == '__main__':
    main()
