#!/usr/bin/env python3
"""Read-only exact Git object intake; writes only this candidate packet."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b')
BASE = '51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
OLD = Path('/workspace/scratch/097486cde2dd/dg17-full-family-r2')

def main():
    tree = json.loads((ROOT/'evidence/AUTHENTICATED_BASE_TREE.json').read_text())
    by_path = {r['path']: r for r in tree['entries']}
    inherited = json.loads((OLD/'AUTHENTICATED_SOURCE_TREE.json').read_text())['selected_entries']
    names = sorted({r['path'] for r in inherited} | {'skills/implementaudit/SKILL.md', 'scripts/verify-package.sh', 'scripts/check-validation-registry.sh', 'package/implementaudit-package.json'})
    rows = []
    for name in names:
        expected = by_path[name]
        command = ['/usr/bin/git', '-c', 'protocol.allow=never', '-C', str(REPO), 'show', BASE+':'+name]
        result = subprocess.run(command, capture_output=True, check=True)
        data = result.stdout
        blob = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        assert len(data) == expected['size'] and blob == expected['sha'], name
        for subdir in ('base', 'candidate'):
            path = ROOT/subdir/name
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('xb') as f: f.write(data)
            path.chmod(int(expected['mode'][-3:], 8))
        rows.append({'path':name, 'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest(), 'git_blob':blob, 'mode':expected['mode'], 'argv':command, 'exit':result.returncode, 'stderr_bytes':len(result.stderr)})
    for name, source in [
      ('ORIGINAL_ISSUE211.md', Path('/workspace/scratch/097486cde2dd/dg17-next/evidence/ORIGINAL_ISSUE211.md')),
      ('ROOT_M09_ACCEPTANCE.json', Path('/workspace/scratch/097486cde2dd/dg17-m09-root-r3/ROOT_DG17_M09_ACCEPTANCE.json')),
    ]:
        shutil.copyfile(source, ROOT/'evidence'/name)
    (ROOT/'evidence/SOURCE_INTAKE.json').write_text(json.dumps({'base_commit':BASE, 'base_tree':tree['tree'], 'source_count':len(rows), 'files':rows}, indent=2)+'\n')
    print(json.dumps({'received':len(rows), 'bytes':sum(r['bytes'] for r in rows), 'all_authenticated_git_blobs_match':True}))

if __name__ == '__main__': main()
