# Optional verified mutation step

Use this only for one already-authorized ordinary replacement when the owner
has selected one observational check to run before and after. It is a support
route of `scripts/apply-observed-mutation.sh`, not an additional governor or
control loop. The default mutation CLI is unchanged.

```text
bash scripts/apply-observed-mutation.sh --verified-step /absolute/contract.json
```

The initial support boundary is POSIX, Python 3.9 or later, `/usr/bin/bash`, an
ordinary run with no controller file, one replacement, and trusted declared
check commands. It does not sandbox hostile checks or same-principal writers,
contain escaped sessions, or qualify native stop behavior. It refuses Windows,
protected/controller routes, and non-replacement or multiple-step operations.

The unique-key JSON object has exactly these fields:

| Field | Value |
|---|---|
| `schema` | `implementaudit.verified-mutation-step-input.v1` |
| `repo_root` | Absolute real repository directory without symlink components |
| `run_root` | `.IMPLEMENTAUDIT/runs/<ordinary-claim>` relative to the repository |
| `phase`, `step` | Positive integers binding the actual phase authority |
| `source` | Repository-relative regular file outside `.git` and `.IMPLEMENTAUDIT` |
| `preimage`, `candidate` | Repository-relative complete regular files inside this run's `evidence/` |
| `evidence_name` | Fresh `verified-step-<lowercase-digits-and-hyphens>` directory name, at most 78 characters |
| `check` | Object described below |
| `baseline_expected_exit` | Integer from 0 through 125 |
| `preexisting_failure` | `null` for baseline zero; nonempty factual explanation for an explicitly admitted nonzero baseline |

The `check` object has exactly `argv`, `executable_sha256`, `inputs`,
`timeout_seconds`, and `output_limit`. `argv` is a nonempty direct argument
vector; its first element is an absolute regular executable. The executable
must match the SHA-256. `inputs` declares every immutable check input as
`{"path": "repository/relative/file", "bytes": 123, "sha256": "64 hex digits"}`;
declare the checker program and its immutable test data, but not the target
being changed. Check inputs must be nonempty, unique, and at most 32 files.
The caller owns a complete declaration of executable dependencies. The helper
does not infer interpreter/module/toolchain closure or promote declared hashes
to native environment qualification.

`timeout_seconds` is an integer from 1 through 30. `output_limit` is an integer
from 1024 through 1048576 bytes for each stream. The same argv and check inputs
run before and after. Checks must be observational; changing the target or
bound inputs refuses completion. Neither stdout text nor a caller-provided
verdict substitutes for the actual process exit and actual target bytes.

The helper retains its captured input contract and generates a one-row input
for the complete existing replacement preflight/apply paths. Preflight refuses
before checks if claim, authority, preimage, or custody is invalid. Actual
mutation is independently revalidated by the canonical consumer. A failed
baseline stops before replacement. A failed after check keeps the actual
mutation and returns failure; it does not silently roll back the target.

`receipt.json` and each process's `process.json`, `stdout.bin`, and `stderr.bin`
are written under the fresh evidence directory. A successful result has status
`VERIFIED_STEP` and `verified: true`; every refusal has `verified: false` and a
reason. None grants authority or phase/audit closure. A process records its
argv, minimal environment, PID, observed process group, exit, streams, deadline,
signals, direct-child reaping, and observed group state. An absent completion
receipt or incomplete capture is unresolved evidence. Timeout and overflow are
preserved even if subsequent signaling succeeds. Group absence is reported
only when observed; it does not prove absence of processes that escaped the
group. No automatic retry, compensation, overwrite, or resumption is provided.

The fresh evidence directory is intentionally retained on failure. Reusing an
existing evidence name refuses without writing into that directory. A later
owner decision must inspect the actual mutation transaction and target before
authorizing another operation. The helper changes no STATE/ROADMAP disposition
and performs none of the remaining phase or final-audit gates.
