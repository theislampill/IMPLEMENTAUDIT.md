#!/usr/bin/env python3
"""Ordinary support qualification, never a DG17 original/mutant witness.

Exercises the actual CLI's help/refusal and the full adapter's process/custody
functions. It never calls main with a valid mutation contract or launches a
claim, phase validator, preflight, or mutation consumer.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

def sha(data): return hashlib.sha256(data).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output = args.output.absolute()
    args.output.mkdir(parents=True, exist_ok=False)
    scripts = args.source_root.resolve()/'skills/implementaudit/scripts'
    python = Path(sys.executable).resolve()
    bash = Path('/usr/bin/bash')
    env = {'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'}
    rows = []
    def record(name, passed, details):
        rows.append({'name':name, 'pass':bool(passed), 'details':details})
        (args.output/'RESULT.json').write_text(json.dumps({'schema':'implementaudit.verified-step.support-qualification.v1', 'original_witnesses_executed':False, 'rows':rows}, indent=2)+'\n')
        if not passed: raise AssertionError(name)
    argv = [str(bash),str(scripts/'apply-observed-mutation.sh'),'--verified-step','--help']
    p = subprocess.run(argv, cwd=args.output, env=env, capture_output=True, timeout=10)
    (args.output/'cli-help.stdout').write_bytes(p.stdout)
    (args.output/'cli-help.stderr').write_bytes(p.stderr)
    record('actual-cli-help-dispatch',p.returncode==0 and b'--verified-step' in p.stdout,
           {'argv':argv,'exit':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr)})
    spec = importlib.util.spec_from_file_location('verified_mutation_step',scripts/'verified-mutation-step.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    record('full-product-module-load',True,{'path':str(spec.origin),'sha256':sha(Path(spec.origin).read_bytes())})
    def refuses(function, expected):
        try: function()
        except module.Refusal as error: return error.reason == expected
        return False
    record('duplicate-json-refused',refuses(lambda:module.strict_json(b'{"a":1,"a":2}'),'JSON_INVALID'),{})
    item = args.output/'regular.bin'
    item.write_bytes(b'bound input\n')
    bound = module.capture_file(item)
    record('actual-regular-file-capture',bound['sha256']==sha(item.read_bytes()) and bound['bytes']==12,{k:v for k,v in bound.items() if k!='data'})
    link = args.output/'link.bin'
    link.symlink_to(item.name)
    record('symlink-file-refused',refuses(lambda:module.capture_file(link),'INPUT_CUSTODY_UNSAFE'),{})
    item.write_bytes(b'changed input\n')
    record('bound-file-drift-refused',refuses(lambda:module.recheck({str(item):bound}),'INPUT_DRIFT'),{})
    process_root = args.output/'processes'
    process_root.mkdir()
    def run(name, code, timeout=3, limit=4096):
        return module.run_process([str(python),'-I','-B','-c',code],args.output,env,process_root/name,timeout,limit)
    normal = run('normal',"import sys; print('output'); print('diagnostic',file=sys.stderr)")
    record('actual-complete-process-capture',normal['complete'] and normal['returncode']==0 and normal['group_absent'] is True and normal['direct_child_reaped'] is True,
           normal)
    failed = run('nonzero','raise SystemExit(7)')
    record('nonzero-exit-preserved',failed['complete'] and failed['returncode']==7,failed)
    timed = run('timeout','import signal,time; signal.signal(signal.SIGTERM,signal.SIG_IGN); time.sleep(10)',timeout=0.2)
    record('deadline-signals-and-direct-child-reap',not timed['complete'] and timed['reason']=='TIMEOUT' and timed['direct_child_reaped'] is True and timed['group_absent'] is True and timed['signals']==['SIGTERM','SIGKILL'],timed)
    large = run('overflow',"import sys; sys.stdout.write('x'*200000); sys.stdout.flush()",limit=4096)
    record('bounded-output-refusal',not large['complete'] and large['reason']=='OUTPUT_LIMIT' and large['stdout']['bytes']<=4096 and large['stdout']['overflow'] is True,large)
    bad = args.output/'invalid-contract.json'
    bad.write_text('{"schema":"wrong"}\n')
    p = subprocess.run([str(bash),str(scripts/'apply-observed-mutation.sh'),'--verified-step',str(bad)],cwd=args.output,env=env,capture_output=True,timeout=10)
    (args.output/'cli-invalid.stdout').write_bytes(p.stdout)
    (args.output/'cli-invalid.stderr').write_bytes(p.stderr)
    decoded = json.loads(p.stdout)
    record('actual-cli-schema-refusal-before-work',p.returncode==64 and decoded['status']=='REFUSED' and decoded['reason']=='CONTRACT_SCHEMA_INVALID' and decoded['processes']==[],decoded)
    record('baseline-policy-rejects-unclassified-failure',refuses(lambda:module.baseline_policy(1,None),'BASELINE_CLASSIFICATION_REQUIRED'),{})
    record('baseline-policy-keeps-explicit-known-failure',module.baseline_policy(1,'Known arithmetic defect under this immutable check')=='KNOWN_PREEXISTING_FAILURE',{})
    record('baseline-policy-green',module.baseline_policy(0,None)=='PASS',{})
    # Constructed intake data only. The existing output must refuse before
    # any claim/phase consumer or check command can start.
    subject=args.output/'replay-intake'
    run=subject/'.IMPLEMENTAUDIT/runs/intake-only'
    (run/'evidence/inputs').mkdir(parents=True)
    (run/'phases').mkdir()
    for name in ('.claimed','STATE.md','ROADMAP.md','phases/phase-1.md'):
        (run/name).write_text('Constructed intake-only data; no actual claim.\n')
    for name in ('preimage','candidate','check-data'):
        (run/'evidence/inputs'/name).write_text('same bytes\n')
    (subject/'target.txt').write_text('same bytes\n')
    prior=run/'evidence/verified-step-existing'
    prior.mkdir()
    (prior/'sentinel').write_bytes(b'previous evidence remains exact\n')
    before={p.relative_to(prior).as_posix():sha(p.read_bytes()) for p in prior.rglob('*') if p.is_file()}
    pinpath=run/'evidence/inputs/check-data'
    contract={'schema':module.SCHEMA,'repo_root':str(subject),'run_root':run.relative_to(subject).as_posix(),
              'phase':1,'step':1,'source':'target.txt',
              'preimage':(run/'evidence/inputs/preimage').relative_to(subject).as_posix(),
              'candidate':(run/'evidence/inputs/candidate').relative_to(subject).as_posix(),
              'evidence_name':'verified-step-existing','baseline_expected_exit':0,'preexisting_failure':None,
              'check':{'argv':[str(python),'-I','-B','-c','raise SystemExit(99)'],
                       'executable_sha256':sha(python.read_bytes()),
                       'inputs':[{'path':pinpath.relative_to(subject).as_posix(),'bytes':pinpath.stat().st_size,'sha256':sha(pinpath.read_bytes())}],
                       'timeout_seconds':1,'output_limit':4096}}
    intake=run/'evidence/inputs/contract.json'
    intake.write_text(json.dumps(contract)+'\n')
    code,refusal=module.execute_contract(intake,scripts,bash)
    after={p.relative_to(prior).as_posix():sha(p.read_bytes()) for p in prior.rglob('*') if p.is_file()}
    record('existing-evidence-refuses-without-writing-or-launching',code==64 and not refusal['verified'] and refusal['processes']==[] and before==after and not (prior/'receipt.json').exists(),
           {'exit':code,'result':refusal,'before':before,'after':after})
    print(json.dumps({'status':'PASS_ORDINARY_SUPPORT_ONLY','checks':len(rows),'original_witnesses_executed':False,'output':str(args.output)}))

if __name__=='__main__': main()
