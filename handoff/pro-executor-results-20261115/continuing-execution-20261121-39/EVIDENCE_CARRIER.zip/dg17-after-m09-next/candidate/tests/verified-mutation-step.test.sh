#!/usr/bin/env bash
set -euo pipefail
repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
temp_root="$(mktemp -d)"
trap 'rm -rf -- "$temp_root"' EXIT
python3 -I -B "$repo_root/tests/verified_mutation_step_support.py" --source-root "$repo_root" --output "$temp_root/qualification"
