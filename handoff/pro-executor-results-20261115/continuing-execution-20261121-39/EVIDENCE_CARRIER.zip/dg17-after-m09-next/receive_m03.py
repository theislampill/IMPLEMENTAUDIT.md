#!/usr/bin/env python3
"""Read-only evidence verification and fresh oracle replay; no product execution.

For the independent receiver after Root's admitted operation. Review this code
against the immutable contract before use. A successful result is advisory;
Root alone may accept an original family.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent

def sha(data): return hashlib.sha256(data).hexdigest()

def verify_members(root,rows):
    for row in rows:
        path=root/row['path']
        if row.get('kind')=='symlink':
            if not path.is_symlink() or os.readlink(path)!=row['target']:
                raise ValueError('qualification symlink probe mismatch')
            continue
        if not path.is_relative_to(root) or '..' in Path(row['path']).parts or path.is_symlink() or not path.is_file():
            raise ValueError('unsafe evidence member')
        data=path.read_bytes()
        if len(data)!=row['bytes'] or sha(data)!=row['sha256']:
            raise ValueError('member mismatch: '+row['path'])
        if 'mode' in row and (path.stat().st_mode & 0o777)!=row['mode']:
            raise ValueError('member mode mismatch: '+row['path'])

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execution-root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    source=args.execution_root.resolve()
    output=args.output.absolute()
    if output.is_relative_to(ROOT): raise ValueError('receiver output must be disjoint from author packet')
    output.mkdir(parents=True,exist_ok=False)
    seal=json.loads((ROOT/'SEAL.json').read_text())
    verify_members(ROOT,seal['files'])
    execution_manifest=json.loads((source/'EXECUTION_MANIFEST.json').read_text())
    verify_members(source,execution_manifest['files'])
    start=json.loads((source/'START.json').read_text())
    if start['packet_seal_sha256']!=sha((ROOT/'SEAL.json').read_bytes()): raise ValueError('packet binding mismatch')
    matrix=json.loads((ROOT/'inputs/cases.json').read_text())
    result=json.loads((source/'RESULTS.json').read_text())
    if result['status']!='OBSERVED_EXPECTED_MATRIX': raise ValueError('actual execution did not report complete expected matrix')
    package_ids=json.loads((source/'PACKAGE_IDENTITIES.json').read_text())
    for variant,rows in package_ids.items(): verify_members(source/'packages'/variant,list(rows.values()))
    original_paths=package_ids['original']
    for variant in ('skip_baseline','skip_postcheck'):
        differing=[name for name,row in original_paths.items() if package_ids[variant].get(name)!=row]
        if differing!=['scripts/verified-mutation-step.py']: raise ValueError('sole mutation mismatch')
        expected=ROOT/'mutations'/variant/'verified-mutation-step.py'
        if (source/'packages'/variant/'scripts/verified-mutation-step.py').read_bytes()!=expected.read_bytes():
            raise ValueError('actual mutation differs from frozen source')
    rows=[]
    for variant,names in matrix['variant_cases'].items():
        if set(result['results'][variant])!=set(names): raise ValueError('operation population mismatch')
        for ident in names:
            place=source/'observations'/variant/ident
            received=place/'received-subject'
            manifest=json.loads((place/'RECEIVED_MANIFEST.json').read_text())
            verify_members(received,manifest['files'])
            observed=json.loads((place/'observation.json').read_text())
            fixture=json.loads((source/'fixtures'/f'{ident}.json').read_text())
            if observed['before_workplane']!=fixture['before_workplane']: raise ValueError('fixture pre-state changed')
            verify_members(received/fixture['run_relative'],fixture['run_inputs'])
            command=[sys.executable,'-I','-B',str(ROOT/'oracle.py'),'--cases',str(ROOT/'inputs/cases.json'),
                     '--case-id',ident,'--observation',str(place/'observation.json'),'--received-subject',str(received)]
            completed=subprocess.run(command,capture_output=True,timeout=20)
            label=variant+'-'+ident
            (output/(label+'.stdout')).write_bytes(completed.stdout)
            (output/(label+'.stderr')).write_bytes(completed.stderr)
            oracle=json.loads(completed.stdout)
            if oracle!=json.loads((place/'oracle.json').read_text()) or oracle!=result['results'][variant][ident]:
                raise ValueError('fresh independent oracle differs from actual oracle')
            expected='PASS' if variant=='original' else matrix['expected_mutation_observations'][variant][ident]
            actual=oracle['verdict'] if expected=='PASS' else oracle['counterexample']
            if actual!=expected or completed.returncode!=(0 if expected=='PASS' else 1):
                raise ValueError('frozen observation absent')
            rows.append({'variant':variant,'case':ident,'actual':actual,'oracle_command':command,
                         'oracle_returncode':completed.returncode,'stdout_sha256':sha(completed.stdout),
                         'stderr_sha256':sha(completed.stderr),'actual_process':observed['process']})
    originals=[r for r in rows if r['variant']=='original']
    variants=[r for r in rows if r['variant']!='original']
    if max(r['actual_process']['finished'] for r in originals)>min(r['actual_process']['started'] for r in variants):
        raise ValueError('a mutation preceded complete original passage')
    report={'status':'PASS_RECEIVED_MATRIX_ADVISORY_ONLY','packet_seal_sha256':sha((ROOT/'SEAL.json').read_bytes()),
            'execution_manifest_sha256':sha((source/'EXECUTION_MANIFEST.json').read_bytes()),
            'original_passes':len(originals),'exact_mutant_effects':sum(r['actual']!='PASS' for r in variants),
            'specificity_controls':sum(r['actual']=='PASS' for r in variants),'rows':rows,
            'original_or_mutant_product_execution_by_receiver':False,'award_authority':'ROOT_ONLY',
            'ceiling':'source-level ordinary mechanical sequencing and exact effects; no model/native-session/package/whole-loop claim'}
    (output/'RESULT.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='rows'}))

if __name__=='__main__': main()
