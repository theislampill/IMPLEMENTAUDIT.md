#!/usr/bin/env python3
"""Freeze prospective inputs and sole mutations; never invoke a consumer."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
BASE='51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'

def put(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream: stream.write(data)

def main():
    checker=b'''#!/usr/bin/env python3
"""Evaluate declared numeric examples against the actual supplied module."""
import json
from pathlib import Path
import runpy
import sys
definition=json.loads(Path(sys.argv[2]).read_text())
module=runpy.run_path(sys.argv[1])
function=module[definition['callable']]
observations=[{'input':row[0],'expected':row[1],'actual':function(row[0])} for row in definition['examples']]
failures=sum(row['actual']!=row['expected'] for row in observations)
print(json.dumps({'observations':observations,'failures':failures},sort_keys=True))
raise SystemExit(1 if failures else 0)
'''
    put(ROOT/'inputs/checker.py',checker)
    square_good='def square(value):\n    return value * value\n'
    square_repair='def square(value):\n    """Return the integer square."""\n    return value ** 2\n'
    square_bad='def square(value):\n    return value + 1\n'
    held_good='def k49(number):\n    return 3 * number + 2\n'
    held_repair='def k49(number):\n    return 2 + number * 3\n'
    held_bad='def k49(number):\n    return 3 * number + 3\n'
    seeds=[
      ('c01','work/q.py',square_good,square_repair,'square',[[-3,9],[0,0],[5,25]],0,None,'VERIFIED_STEP',None),
      ('c02','work/q.py',square_bad,square_repair,'square',[[-3,9],[0,0],[5,25]],0,None,'BASELINE_OUTCOME_MISMATCH',None),
      ('c03','work/q.py',square_good,square_bad,'square',[[-3,9],[0,0],[5,25]],0,None,'POSTCHECK_FAILED',None),
      ('c04','work/opaque/v19.py',held_bad,held_repair,'k49',[[-2,-4],[0,2],[7,23]],0,None,'BASELINE_OUTCOME_MISMATCH',None),
      ('c05','work/opaque/v19.py',held_good,held_bad,'k49',[[-2,-4],[0,2],[7,23]],0,None,'POSTCHECK_FAILED',None),
      ('c06','work/q.py',square_bad,square_repair,'square',[[-3,9],[0,0],[5,25]],1,'Known preexisting arithmetic defect: the fixed three integer examples fail before this authorized repair.','VERIFIED_STEP',None),
      ('c07','work/q.py',square_good,square_good,'square',[[-3,9],[0,0],[5,25]],0,None,'VERIFIED_STEP',None),
      ('c08','work/q.py',square_good,square_repair,'square',[[-3,9],[0,0],[5,25]],0,None,'CANONICAL_PREFLIGHT_REFUSED','def square'),
    ]
    cases=[]
    for ident,target,before,after,function,examples,expected,explanation,outcome,preimage in seeds:
        rows={'id':ident,'target':target,'before_hex':before.encode().hex(),'candidate_hex':after.encode().hex(),
              'preimage_hex':(preimage if preimage is not None else before).encode().hex(),
              'check_data':{'callable':function,'examples':examples},
              'baseline_expected_exit':expected,'preexisting_failure':explanation,
              'expected_outcome':outcome,
              'expected_before_check_exit':1 if before in {square_bad,held_bad} else 0,
              'expected_after_check_exit':1 if after in {square_bad,held_bad} else 0,
              'unrelated_file':'notes/unfinished-draft.txt','unrelated_hex':b'Preserve this unrelated draft byte for byte.\n'.hex()}
        cases.append(rows)
        phase=f'''# Constructed ordinary verified-step input; no executed verdicts

IMPLEMENTAUDIT_PHASE_START
Phase: 1 of 1 — Bounded callable update {ident}
Task: Apply one declared update while preserving the numeric example contract
Type: brownfield / reversible-local
Run root: RUN_ROOT_FROM_REAL_CLAIM
Baseline ref: {BASE}
Owner/source: skills/implementaudit/scripts/apply-observed-mutation.sh and verified-mutation-step.py
Audit object: One ordinary observed replacement with actual before and after checks
Depends on phases: none

## Current state excerpts

- The actual source is `{target}` and the complete declared candidate is supplied as a separate observed input.
- The checker and numeric examples are immutable inputs and run unchanged before and after the request.

## Work

- Submit the one declared replacement through the actual opt-in canonical CLI and retain all command and transaction evidence.

## Implementation steps (ordered)

- Step 1: Apply the declared callable update — target: {target}; change: use the complete preimage and candidate through the actual mutation consumer; verify: python3 checks/inspect_result.py {target} checks/examples.json; expected: the fixed numeric examples agree with actual callable results
  mutation-authority: {{"operation":"replace","source":"{target}","destination":null}}

## Scope boundaries

In scope: {target}
Mutation scope: {{"in":["{target}"],"out":["notes/unfinished-draft.txt","checks/inspect_result.py","checks/examples.json"]}}
Out of scope: notes/unfinished-draft.txt; checks/inspect_result.py; checks/examples.json; all unrelated work.

## STOP conditions (plan-specific)

- Stop if `.claimed` is absent or `checks/examples.json` differs from its frozen input digest; stop on an unexpected controller identity, preimage mismatch, or changed prospective source packet.
- Stop on an unclassified baseline failure or a failed post-check; retain actual effects and do not replay this operation.

## Acceptance criteria

- The real before and after command results obey the frozen baseline policy and after-success requirement.
- The exact target and unrelated file states match the frozen operation-specific outcome and every incomplete check refuses verified completion.

## Mandatory commands

- /usr/bin/python3.13 -I -B {ROOT}/oracle.py --cases {ROOT}/inputs/cases.json --case-id {ident} --observation RUN_ROOT_FROM_REAL_CLAIM/evidence/observation.json > RUN_ROOT_FROM_REAL_CLAIM/evidence/oracle.json 2>&1 — property: behavioral; scope: actual process order, exact ordinary mutation result and physical files; acceptance: non-textual; expected: exit 0 when the unchanged oracle agrees with the observed operation; coverage: full; capture: RUN_ROOT_FROM_REAL_CLAIM/evidence/oracle.json

## Evidence required

- Exact captured command argv, PID, exit, streams and process disposition, canonical transaction result, complete target before/after bytes, unchanged non-target state, and separate-process oracle.

## Rollback / defer path

Preserve failed process and mutation evidence. Restore only the owned disposable subject from its frozen setup snapshot between distinct admitted variants. No automatic retry or live project effect is authorized.

## Maintenance notes

- This constructed input has no controller, model, native-session, release, phase-closure, or audit-closure authority.

Markdown fallback: yes

## Prospective transcript anchors

IMPLEMENTAUDIT_PHASE_VERIFY
Status: pending actual consumer; no pass assertion.

AGENTS_UPDATE_DECISION
Decision: not warranted for this disposable witness.

CONTINUITY_DECISION
Decision: no controller in this fixture.

IMPLEMENTAUDIT_PHASE_DONE
Status: not executed; prospective schema anchor only.
'''
        put(ROOT/'inputs/phases'/f'{ident}.md',phase.encode())
    values={'schema':'dg17.m03.prospective-cases.v1','base_commit':BASE,'cases':cases,
            'variant_cases':{'original':[c['id'] for c in cases],'skip_baseline':['c02','c04','c08'],'skip_postcheck':['c03','c05','c02','c08']},
            'expected_original':'all eight PASS',
            'expected_mutation_observations':{'skip_baseline':{'c02':'BASELINE_BYPASS_EXACT_EFFECT','c04':'BASELINE_BYPASS_EXACT_EFFECT','c08':'PASS'},'skip_postcheck':{'c03':'POSTCHECK_BYPASS_EXACT_EFFECT','c05':'POSTCHECK_BYPASS_EXACT_EFFECT','c02':'PASS','c08':'PASS'}}}
    put(ROOT/'inputs/cases.json',(json.dumps(values,sort_keys=True,indent=2)+'\n').encode())
    source=(ROOT/'candidate/skills/implementaudit/scripts/verified-mutation-step.py').read_text()
    mutations=[]
    for variant,needle in [('skip_baseline','        baseline_gate()\n'),('skip_postcheck','        postcheck_gate()\n')]:
        assert source.count(needle)==1
        replacement='        pass  # '+variant+' sole omitted gate call\n'
        altered=source.replace(needle,replacement)
        path=ROOT/'mutations'/variant/'verified-mutation-step.py'
        put(path,altered.encode())
        mutations.append({'variant':variant,'owner':'skills/implementaudit/scripts/verified-mutation-step.py',
                          'removed':needle.rstrip('\n'),'replacement':replacement.rstrip('\n'),
                          'sha256':hashlib.sha256(altered.encode()).hexdigest(),
                          'original_sha256':hashlib.sha256(source.encode()).hexdigest()})
    put(ROOT/'inputs/MUTATIONS.json',(json.dumps(mutations,indent=2)+'\n').encode())
    print(json.dumps({'prospective_cases':len(cases),'mutants':len(mutations),'original_executed':False}))

if __name__=='__main__': main()
