#!/usr/bin/env python3
"""Evaluate declared numeric examples against the actual supplied module."""
import json
from pathlib import Path
import runpy
import sys
definition=json.loads(Path(sys.argv[2]).read_text())
module=runpy.run_path(sys.argv[1])
function=module[definition['callable']]
observations=[{'input':row[0],'expected':row[1],'actual':function(row[0])} for row in definition['examples']]
failures=sum(row['actual']!=row['expected'] for row in observations)
print(json.dumps({'observations':observations,'failures':failures},sort_keys=True))
raise SystemExit(1 if failures else 0)
