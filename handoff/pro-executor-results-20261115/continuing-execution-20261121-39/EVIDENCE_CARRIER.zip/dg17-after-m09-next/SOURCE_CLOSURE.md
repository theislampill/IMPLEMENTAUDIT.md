# Source and process closure

`evidence/SOURCE_INTAKE.json` records all 27 complete inherited files received
from the exact immutable Git objects. Each body matches the authenticated
recursive tree's blob identity and size. No target checkout source was edited.
The `base/` files remain exact; `candidate/` contains only the seven declared
source changes over that base. The proposed complete tree is independently
derived from all authenticated leaf objects and those explicit deltas; it is
not a published commit or Root integration result.

The actual entry is the complete canonical `apply-observed-mutation.sh` with a
three-line opt-in dispatch. The entire existing embedded Python body is
unchanged. The adapter invokes that full CLI's existing `--batch-preflight`
and `--batch-apply` routes for one replacement. The latter captures the full
maintained source body, launches its canonical single-row consumer, and
classifies the real live result. The adapter does not extract or replace an
authority function, synthesize a mutation result, or consume a saved result as
current execution.

The inherited runtime closure includes complete `validate-run-root.sh`,
`validate-phase.sh`, `check-authorization-binding.sh`,
`check-closure-surface.sh`, `check-evidence-anchor.sh`, `claim-run.sh`,
`read-canonical-pair.py`, and `canonical_custody.py`. In particular, the
canonical-pair reader's unconditional sibling load is included; POSIX is not
used as a reason to omit it. Full canonical templates and relevant owners are
also present. Existing helpers keep their own claim, identity, phase,
preimage, scope, transaction, and custody checks. The optional check inputs
are the complete frozen Python checker and numeric data, both pinned in each
actual runtime contract. The interpreter, Bash, and Git file identities are
recorded separately in `evidence/TOOLCHAIN.json`.

Before admission, actual product work is limited to support module loading,
CLI help/intake refusal, support subprocess/custody checks, one isolated
ordinary claim, and normal phase-spec validation. No original or mutant
verified-step operation, canonical mutation-authority check, batch preflight,
or batch apply has been invoked. Static source review supplies readiness for
those deferred stages; their actual execution remains part of the gated
prospective operation.

The original runner is a separate harness, and the oracle is a separate
process. The oracle checks independently received raw process files, literal
before/after numeric observations, live/received work-plane byte identities,
and actual canonical return envelopes. Its optional relocation parameter
changes only the evidence directory used for later independent receiving.
The receiver does not launch the product. Source hashes, input digests, raw
streams, actual PIDs/exits, each result, and the complete returned payload
manifest remain available to the independent reviewer and Root.

No host-model identity, protected Git/image profile, native stop/session,
installed-payload, whole phase, currentness, or closure claim is inferred from
these ordinary local processes. Full repository and package gates remain
explicitly unrun and open for any subsequent integration/shipping claim.
