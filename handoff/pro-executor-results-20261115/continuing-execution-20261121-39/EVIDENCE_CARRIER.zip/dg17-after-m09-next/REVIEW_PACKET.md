# M03 independent preexecution review packet

Disposition requested: full-family eligibility and prospective source readiness. Nothing in this packet is an original award.

## First decision

Review unchanged Issue211 line 603 together with lines 541–545 and 616–619, the concrete design, and the source delta. Decide whether the **new integrated ordinary source consumer** is eligible for the complete M03 Smoke A/B mutation family at its mechanical evidence layer. The old exact51416 survivor remains preserved. The source candidate is exact51416 plus seven explicit files, not unchanged51416. A source review PASS does not select that candidate or authorize original execution; Root must admit both the candidate and the operation.

The adapter is invoked through the existing canonical mutation CLI, performs a real canonical preflight, runs one pinned check, invokes the complete unchanged one-row canonical replacement consumer, and reruns the same check. The full embedded mutation body remains byte-identical. There is no extracted replacement authority function, synthetic transaction result, mock mutation, substitute child/model, or newly invented R0037 loop controller.

## Frozen prospective operation

| Input | Expected original behavior | Decisive paired variant |
|---|---|---|
| c01 | Correct source and behavior-preserving replacement: actual before and after checks pass; exact candidate lands | Positive original |
| c02 | Incorrect initial function with baseline exit 1 where 0 was admitted: stop before replacement | Omit baseline call: exact candidate lands and is incorrectly called verified |
| c03 | Correct initial function, wrong candidate: candidate lands, real after check exits 1, verified completion refused | Omit after-check call: exact wrong candidate is incorrectly called verified |
| c04 | Unfamiliar name/path/numeric transform with the same baseline-failure boundary | Omit baseline call: exact candidate lands and is incorrectly called verified |
| c05 | Unfamiliar name/path/numeric transform with the same failed-after-check boundary | Omit after-check call: exact wrong candidate is incorrectly called verified |
| c06 | Explicitly classified preexisting failure is allowed before the authorized repair; actual after check must pass | Boundary original |
| c07 | Identical candidate/preimage: actual checks surround canonical NO_CHANGE | Boundary original |
| c08 | Truncated preimage: canonical preflight refuses before any check or mutation | Both omitted-call variants must retain the exact refusal |

All eight original cases must pass before any mutation variant starts. The prospective paired population is c02/c04/c08 for omission A and c03/c05/c02/c08 for omission B: four exact counterexamples and three specificity controls. c02 is an additional specificity control for omission B because baseline refusal must still prevent mutation. The same immutable checker, cases, setup function, and oracle serve every variant. Each mutant changes only its one call in the full adapter module. No expected outcome can be tuned after an original result.

For the baseline counterexample, the paired original must actually observe its failing baseline; the mutated execution omits that baseline and produces the exact forbidden-by-verification target effect. Do not claim a baseline process ran in the mutant. For the post-check counterexample, the paired original actually observes its failing after check; the mutant omits that check and calls the same exact bad target verified. Do not invent an after-check process in the mutant. Both preserve all non-target entries and the actual canonical transaction result.

## Receiving and authority

Root's concrete command, **only after its independent gate**, is:

```text
/usr/bin/python3.13 -I -B /workspace/scratch/097486cde2dd/dg17-after-m09-next/run_m03.py --execute --root-admission-reference <actual-Root-decision>
```

The command argument records the real external gate; it is not an authorization token. The exclusive `execution-01` directory prevents implicit replay. It does not exist at freeze. A failure preserves all prior evidence and stops; an original failure leaves the mutants unexecuted. Setup uses isolated ordinary claims in disposable Git repositories, with read-only object alternates to the immutable base. No Root controller/custody or provider is in the write set.

The independent receiver uses a disjoint output directory and the sealed actual execution. `receive_m03.py` checks packet/return manifests and copies, verifies unchanged paired inputs and sole mutations, and reruns only the read-only variant-blind oracle against received post-state. It cannot launch an original or mutation consumer. Reviewers should independently inspect the decisive raw process/transaction bytes and their physical post-state; this author's receiver is a convenience, not independent authority. Root alone accepts and publishes.

## Actual ordinary qualification already performed

- All 27 inherited files authenticate to exact source Git blobs and sizes.
- Actual support qualification passes 15 checks, including CLI dispatch/refusal, full module load, strict input custody, bounded real subprocesses, timeout TERM/KILL, direct-child reaping/group observation, output overflow, and a preexisting-evidence refusal with no write or child launch.
- One isolated fixture's real Git initialization, exact base checkout, absence of controller refs, and actual ordinary claim succeeded. Its first normal phase validation refused generic STOP wording; that failed phase and all captures remain retained. Only the prospective STOP wording was then bound to `.claimed` and `checks/examples.json`; case requests and all expected outcomes stayed byte-identical. All eight normal phase-shape validations now pass.
- Static syntax and exact embedded-body/sole-mutation checks pass. No mutation-authority, batch preflight/apply, full verified-step operation, original witness, or mutant witness was invoked. Actual support/setup product execution is acknowledged; there is no “zero product code executed” claim.

## Material limitations and remaining gates

The initial feature supports ordinary POSIX operation with `/usr/bin/bash`, one replacement, and trusted declared observational check commands. It does not sandbox hostile checks, prove containment of escaped sessions, or protect against arbitrary same-principal writers. Its inner captures report actual group observations; outer harness captures prove direct-child return and record actual timeout signaling, with no broader cleanup claim. All setup fixtures, snapshots, and failed attempt files are retained and enumerable under `qualification/`; retention is not claimed as cleanup.

The complete original path and its canonical preflight/apply stages are deliberately unexecuted pending the gate. Package build, compressed budget, generated/archive parity, isolated installation, host activation, and the complete repository suite have **not** been qualified by this packet. Package-relevant source changed, so those broader triggered gates remain open; this packet does not waive them or infer native/model readiness. The mechanical M03 family must not become a P01 case, whole L3 phase, terminal clause, whole DG cell, or programme award. Existing M09/M12 and all prior accepted scopes and the 36/14/17 denominators remain unchanged.

## Review priorities

1. Full original-definition mapping and source-candidate admission, including the owner-authorized support-engineering distinction from a claimed source runtime RED.
2. Canonical authority/dependency closure, real CLI integration, immutable bindings, and no default-path change beyond the optional dispatch.
3. Baseline classification, failed-after-check effect preservation, exact full post-state/return shape, and absence of variant-label branches in the oracle.
4. Timeout/output/process custody, replay refusal, evidence preservation, and honest cleanup limits.
5. Frozen expectations, all originals before mutants, bounded independent receiving, and no inherited/extra award.
