#!/usr/bin/env python3
"""Seal this unexecuted candidate; derive virtual Git tree without Git writes."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import stat

ROOT=Path(__file__).resolve().parent

def sha(data): return hashlib.sha256(data).hexdigest()
def blob(data): return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def write(path,value): path.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')

def tree_hash(leaves):
    root={}
    for path,(mode,identity) in leaves.items():
        parts=path.split('/')
        node=root
        for part in parts[:-1]: node=node.setdefault(part,{})
        node[parts[-1]]=(mode,identity)
    def derive(node):
        raw=b''
        ordered=sorted(node.items(),key=lambda item:(item[0]+('/' if isinstance(item[1],dict) else '')).encode())
        for name,value in ordered:
            mode,identity=('40000',derive(value)) if isinstance(value,dict) else value
            raw+=mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(identity)
        return hashlib.sha1(b'tree '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    return derive(root)

def main():
    if (ROOT/'SEAL.json').exists() or (ROOT/'execution-01').exists(): raise ValueError('already sealed or executed')
    for relative in ['skills/implementaudit/scripts/verified-mutation-step.py','tests/verified-mutation-step.test.sh']:
        (ROOT/'candidate'/relative).chmod(0o755)
    auth=json.loads((ROOT/'evidence/AUTHENTICATED_BASE_TREE.json').read_text())
    leaves={r['path']:(r['mode'],r['sha']) for r in auth['entries'] if r['type']!='tree'}
    if tree_hash(leaves)!=auth['tree']: raise ValueError('full authenticated base tree derivation failed')
    entries={r['path']:r for r in auth['entries']}
    delta=[]
    patch=''
    for path in sorted((ROOT/'candidate').rglob('*')):
        if not path.is_file(): continue
        if path.is_symlink(): raise ValueError('source symlink')
        relative=path.relative_to(ROOT/'candidate').as_posix()
        data=path.read_bytes()
        mode='100755' if path.stat().st_mode & 0o111 else '100644'
        after=blob(data)
        before=entries.get(relative)
        if before and before['sha']==after and before['mode']==mode: continue
        old=(ROOT/'base'/relative).read_bytes() if before else b''
        if before and (blob(old)!=before['sha'] or len(old)!=before['size']): raise ValueError('base drift')
        leaves[relative]=(mode,after)
        delta.append({'path':relative,'before_blob':before['sha'] if before else None,
                      'after_blob':after,'bytes':len(data),'sha256':sha(data),'mode':mode})
        patch+=f'diff --git a/{relative} b/{relative}\n'
        if not before: patch+=f'new file mode {mode}\n'
        patch+=''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),data.decode().splitlines(keepends=True),
                      fromfile='a/'+relative if before else '/dev/null',tofile='b/'+relative))
    expected_paths={'skills/implementaudit/scripts/apply-observed-mutation.sh',
                    'skills/implementaudit/scripts/verified-mutation-step.py',
                    'skills/implementaudit/templates/PROTOCOL.md',
                    'skills/implementaudit/references/verified-mutation-step.md',
                    'scripts/verify-package.sh','tests/verified-mutation-step.test.sh',
                    'tests/verified_mutation_step_support.py'}
    if {r['path'] for r in delta}!=expected_paths: raise ValueError('unexpected product change population')
    for row in json.loads((ROOT/'evidence/SOURCE_INTAKE.json').read_text())['files']:
        data=(ROOT/'base'/row['path']).read_bytes()
        if len(data)!=row['bytes'] or sha(data)!=row['sha256'] or blob(data)!=row['git_blob']:
            raise ValueError('authenticated inherited source drift')
    original=(ROOT/'candidate/skills/implementaudit/scripts/verified-mutation-step.py').read_bytes()
    for row in json.loads((ROOT/'inputs/MUTATIONS.json').read_text()):
        expected=original.decode().replace(row['removed']+'\n',row['replacement']+'\n')
        actual=(ROOT/'mutations'/row['variant']/'verified-mutation-step.py').read_text()
        if expected!=actual or sha(actual.encode())!=row['sha256'] or sha(original)!=row['original_sha256']:
            raise ValueError('sole mutation changed')
    for path in [ROOT/'run_m03.py',ROOT/'receive_m03.py',ROOT/'oracle.py',ROOT/'prepare_inputs.py',ROOT/'freeze_packet.py']:
        ast.parse(path.read_text())
    proposed=tree_hash(leaves)
    source={'schema':'dg17.m03.prospective-source-delta.v1','base_commit':auth['commit'],'base_tree':auth['tree'],
            'proposed_tree':proposed,'tree_identity_kind':'PURE_GIT_OBJECT_DERIVATION_NOT_PUBLISHED_COMMIT',
            'source_selection':'EXACT_BASE_PLUS_SEVEN_EXPLICIT_FILES; ROOT_ADMISSION_REQUIRED',
            'changed_files':delta,'base_leaf_count':sum(r['type']!='tree' for r in auth['entries']),
            'candidate_leaf_count':len(leaves),'default_embedded_mutation_body_unchanged':True,
            'package_build_budget_install_host_qualification':'NOT_RUN_OPEN_TRIGGERED_GATES',
            'original_or_mutant_witnesses_executed':False}
    write(ROOT/'evidence/SOURCE_DELTA.json',source)
    (ROOT/'SOURCE.patch').write_text(patch)
    census=Path('/workspace/scratch/097486cde2dd/dg17-full-family/evidence/DG17_CURRENT_FRONTIER_RECOVERED_G0001.json')
    census_data=census.read_bytes()
    old=json.loads(census_data)
    matches=[]
    def find(value):
        if isinstance(value,dict):
            if value.get('id')=='M03': matches.append(value)
            for child in value.values(): find(child)
        elif isinstance(value,list):
            for child in value: find(child)
    find(old)
    write(ROOT/'evidence/SELECTION_CENSUS.json',{'source_path':str(census),'source_sha256':sha(census_data),
           'exact_M03_rows':matches,'Root_current_overlay':'M03 remains unaccepted; M09 now accepted by exact copied Root receipt. All other prior scopes remain preserved.',
           'denominators':{'cases':36,'mutation_families':14,'terminal_clauses':17},
           'new_awards':[],'historical_M03_actor_replay':False})
    ready={'schema':'dg17.m03.ready-for-independent-review.v1','status':'READY_FOR_INDEPENDENT_PREEXECUTION_SOURCE_REVIEW',
           'family':'M03','base_commit':auth['commit'],'proposed_tree':proposed,
           'Root_binding':{'generation':'G0044','receipt':'3fb3e2d80b1575b3a4ec28cc196957f9ce498523','current_native':'6b1793/0'},
           'source_changes':7,'inherited_authenticated_files':27,'ordinary_support_checks':15,
           'ordinary_setup':'actual isolated Git setup and ordinary claim succeeded; initial normal phase shape failure preserved; concrete STOP correction then all eight normal phase shapes passed',
           'original_execution_directory_absent':True,'original_cases':8,'prospective_exact_mutant_effects':4,'prospective_specificity_controls':3,
           'execution_allowed_by_packet':False,'next_gate':'INDEPENDENT_FULL_FAMILY_SOURCE_REVIEW_THEN_ROOT_CANDIDATE_AND_OPERATION_ADMISSION',
           'unsupported_claims':['unchanged51416','historicalM03replacement','model-or-native-session','wholeL3','case-or-terminal-award','package-or-host-qualified','full-process-escape-containment','programme-closure'],
           'retained_resources':['qualification/setup-01/subjects/c01','qualification/setup-01/snapshots/c01','qualification/phase-shape-02','qualification/support-final/replay-intake'],
           'cleanup':'retained enumerable fixture/evidence; direct-child captures only for setup harness; no unproved complete-cleanup claim'}
    write(ROOT/'READY.json',ready)
    files=[]
    for path in sorted(ROOT.rglob('*')):
        if path.is_symlink():
            # The ordinary symlink-refusal probe is retained as a typed link,
            # never followed for content or treated as source.
            files.append({'path':path.relative_to(ROOT).as_posix(),'kind':'symlink','target':path.readlink().as_posix()})
        elif path.is_file():
            data=path.read_bytes()
            files.append({'path':path.relative_to(ROOT).as_posix(),'kind':'regular','bytes':len(data),'sha256':sha(data),'mode':stat.S_IMODE(path.stat().st_mode)})
    seal={'schema':'dg17.m03.packet-seal.v1','status':ready['status'],'files':files,
          'regular_count':sum(r['kind']=='regular' for r in files),'symlink_probe_count':sum(r['kind']=='symlink' for r in files),
          'bytes':sum(r.get('bytes',0) for r in files),'original_execution':False,'Root_authority_retained':True}
    write(ROOT/'SEAL.json',seal)
    print(json.dumps({'status':ready['status'],'proposed_tree':proposed,'payloads':len(files),
                      'regular_count':seal['regular_count'],'symlink_probes':seal['symlink_probe_count'],
                      'bytes':seal['bytes'],'seal_bytes':(ROOT/'SEAL.json').stat().st_size,'seal_sha256':sha((ROOT/'SEAL.json').read_bytes())}))

if __name__=='__main__': main()
