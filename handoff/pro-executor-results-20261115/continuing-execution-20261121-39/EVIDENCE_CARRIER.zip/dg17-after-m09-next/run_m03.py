#!/usr/bin/env python3
"""Execute only after independent review and Root admission of this exact packet."""
import argparse
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
SOURCE_REPO=Path('/workspace/scratch/2678f1e431c3/recovery-repo-20261119-b')
BASE='51416b2f156b341c4a5f09029e2c6ceb5b30b1e7'
TREE='9c3913ceaa95f3f36b0377fe2dba4a302afcba89'
PYTHON='/usr/bin/python3.13'
BASH='/usr/bin/bash'
GIT='/usr/bin/git'

def sha(data): return hashlib.sha256(data).hexdigest()

def write_json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as stream: stream.write(json.dumps(value,sort_keys=True,indent=2)+'\n')

def verify_seal():
    seal=json.loads((ROOT/'SEAL.json').read_text())
    for item in seal['files']:
        path=ROOT/item['path']
        if item.get('kind')=='symlink':
            if not path.is_symlink() or os.readlink(path)!=item['target']:
                raise ValueError('sealed qualification symlink probe drift')
            continue
        if path.is_symlink() or not path.is_file(): raise ValueError('unsafe sealed member')
        data=path.read_bytes()
        if len(data)!=item['bytes'] or sha(data)!=item['sha256']:
            raise ValueError('sealed member drift: '+item['path'])
        if stat.S_IMODE(path.stat().st_mode)!=item['mode']: raise ValueError('sealed member mode drift')
    for row in json.loads((ROOT/'evidence/TOOLCHAIN.json').read_text())['tools']:
        data=Path(row['path']).read_bytes()
        if len(data)!=row['bytes'] or sha(data)!=row['sha256']: raise ValueError('native tool identity drift')
    return sha((ROOT/'SEAL.json').read_bytes())

def observe_tree(root):
    rows={}
    for path in sorted(root.rglob('*')):
        rel=path.relative_to(root)
        if rel.parts[0] in {'.git','.IMPLEMENTAUDIT'}: continue
        st=path.lstat()
        if stat.S_ISREG(st.st_mode):
            data=path.read_bytes()
            rows[rel.as_posix()]={'kind':'regular','bytes':len(data),'sha256':sha(data),'mode':stat.S_IMODE(st.st_mode)}
        elif stat.S_ISLNK(st.st_mode):
            rows[rel.as_posix()]={'kind':'symlink','target':os.readlink(path)}
        elif not stat.S_ISDIR(st.st_mode): rows[rel.as_posix()]={'kind':'unsupported'}
    return rows

def manifest(root):
    return [{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'mode':stat.S_IMODE(p.stat().st_mode)}
            for p in sorted(root.rglob('*')) if p.is_file() and not p.is_symlink()]

class Runner:
    def __init__(self,output):
        self.output=output
        (output/'tmp').mkdir()
        self.env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8',
                  'TMPDIR':str(output/'tmp'),'PYTHONDONTWRITEBYTECODE':'1',
                  'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null',
                  'IMPLEMENTAUDIT_BASE':'.IMPLEMENTAUDIT/runs'}
        self.sequence=0

    def command(self,argv,cwd,label,required=False):
        self.sequence+=1
        place=self.output/'processes'/f'{self.sequence:04d}-{label}'
        place.mkdir(parents=True)
        started=datetime.now(timezone.utc).isoformat()
        process=subprocess.Popen(argv,cwd=cwd,env=self.env,stdin=subprocess.DEVNULL,
                                 stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        status='EXITED'
        signals=[]
        try:
            out,err=process.communicate(timeout=55)
        except subprocess.TimeoutExpired:
            status='TIMEOUT_NO_RETRY'
            try: os.killpg(process.pid,signal.SIGTERM); signals.append('SIGTERM')
            except ProcessLookupError: pass
            try:
                out,err=process.communicate(timeout=2)
            except subprocess.TimeoutExpired:
                try: os.killpg(process.pid,signal.SIGKILL); signals.append('SIGKILL')
                except ProcessLookupError: pass
                out,err=process.communicate(timeout=2)
        (place/'stdout.bin').write_bytes(out)
        (place/'stderr.bin').write_bytes(err)
        record={'argv':argv,'cwd':str(cwd),'pid':process.pid,'started':started,
                'finished':datetime.now(timezone.utc).isoformat(),'returncode':process.returncode,
                'status':status,'signals':signals,'direct_child_reaped':process.returncode is not None,
                'stdout_bytes':len(out),'stdout_sha256':sha(out),
                'stderr_bytes':len(err),'stderr_sha256':sha(err),
                'capture_directory':place.relative_to(self.output).as_posix()}
        write_json(place/'process.json',record)
        if status!='EXITED' or (required and process.returncode!=0):
            raise RuntimeError('actual process stopped: '+label)
        return out,err,record

    def setup(self,case):
        subject=self.output/'subjects'/case['id']
        subject.mkdir(parents=True)
        self.command([GIT,'-c','init.templateDir=','init','--quiet',str(subject)],self.output,case['id']+'-git-init',True)
        common,_,_=self.command([GIT,'-C',str(SOURCE_REPO),'rev-parse','--path-format=absolute','--git-common-dir'],self.output,case['id']+'-objects',True)
        objects=Path(common.decode().strip())/'objects'
        (subject/'.git/objects/info/alternates').write_text(str(objects)+'\n')
        (subject/'.git/info').mkdir(exist_ok=True)
        (subject/'.git/info/sparse-checkout').write_text('/README.md\n/work/\n/checks/\n/notes/\n')
        self.command([GIT,'config','--local','core.sparseCheckout','true'],subject,case['id']+'-sparse',True)
        self.command([GIT,'config','--local','core.sparseCheckoutCone','false'],subject,case['id']+'-sparse-mode',True)
        self.command([GIT,'checkout','--quiet','--detach',BASE],subject,case['id']+'-baseline-checkout',True)
        identity,_,_=self.command([GIT,'rev-parse','HEAD','HEAD^{tree}'],subject,case['id']+'-identity',True)
        if identity.decode().splitlines()!=[BASE,TREE]: raise ValueError('fixture Git base drift')
        refs,_,_=self.command([GIT,'for-each-ref','--format=%(refname)','refs/implementaudit/'],subject,case['id']+'-ordinary-population',True)
        if refs: raise ValueError('unexpected controller/receipt population')
        for name,data in [(case['target'],bytes.fromhex(case['before_hex'])),
                          (case['unrelated_file'],bytes.fromhex(case['unrelated_hex'])),
                          ('checks/inspect_result.py',(ROOT/'inputs/checker.py').read_bytes()),
                          ('checks/examples.json',(json.dumps(case['check_data'],sort_keys=True,indent=2)+'\n').encode())]:
            path=subject/name
            path.parent.mkdir(parents=True,exist_ok=True)
            path.write_bytes(data)
            path.chmod(0o644)
        claim,_,claim_process=self.command([BASH,str(ROOT/'candidate/skills/implementaudit/scripts/claim-run.sh'),'m03-consumer-'+case['id']],subject,case['id']+'-actual-ordinary-claim',True)
        relative=claim.decode().strip()
        if '\n' in relative or not relative.startswith('.IMPLEMENTAUDIT/runs/'):
            raise ValueError('claim result shape')
        run=subject/relative
        if not run.is_dir() or (run/'.controller').exists(): raise ValueError('ordinary claim custody')
        for name in ('STATE.md','PROTOCOL.md','ROADMAP.md','THINKING.md','sidecars.md','tools.md','context.md'):
            shutil.copyfile(ROOT/'candidate/skills/implementaudit/templates'/name,run/name)
        (run/'STATE.md').write_text('# Constructed ordinary input\n\nStatus: unexecuted\nController: absent; no currentness assertion\nRun root: '+relative+'\n')
        (run/'ROADMAP.md').write_text('# Constructed ordinary input\n\n| Phase | Task |\n|---|---|\n| 1 | Apply the declared checked update |\n')
        (run/'phases').mkdir()
        phase=(ROOT/'inputs/phases'/f"{case['id']}.md").read_text()
        if phase.count('RUN_ROOT_FROM_REAL_CLAIM')!=4: raise ValueError('phase substitution count')
        (run/'phases/phase-1.md').write_text(phase.replace('RUN_ROOT_FROM_REAL_CLAIM',relative))
        inputs=run/'evidence/inputs'
        inputs.mkdir(parents=True)
        (inputs/'preimage.bin').write_bytes(bytes.fromhex(case['preimage_hex']))
        (inputs/'candidate.bin').write_bytes(bytes.fromhex(case['candidate_hex']))
        check_inputs=[]
        for name in ('checks/inspect_result.py','checks/examples.json'):
            data=(subject/name).read_bytes()
            check_inputs.append({'path':name,'bytes':len(data),'sha256':sha(data)})
        contract={'schema':'implementaudit.verified-mutation-step-input.v1','repo_root':str(subject),
                  'run_root':relative,'phase':1,'step':1,'source':case['target'],
                  'preimage':relative+'/evidence/inputs/preimage.bin','candidate':relative+'/evidence/inputs/candidate.bin',
                  'evidence_name':'verified-step-current','baseline_expected_exit':case['baseline_expected_exit'],
                  'preexisting_failure':case['preexisting_failure'],
                  'check':{'argv':[PYTHON,'-I','-B',str(subject/'checks/inspect_result.py'),str(subject/case['target']),str(subject/'checks/examples.json')],
                           'executable_sha256':sha(Path(PYTHON).read_bytes()),'inputs':check_inputs,
                           'timeout_seconds':5,'output_limit':65536}}
        write_json(inputs/'verified-step.json',contract)
        before=observe_tree(subject)
        run_files=manifest(run)
        snapshot=self.output/'snapshots'/case['id']
        snapshot.parent.mkdir(exist_ok=True)
        shutil.copytree(subject,snapshot)
        write_json(self.output/'fixtures'/f"{case['id']}.json",{'subject_root':str(subject),'run_relative':relative,
                    'claim_process':claim_process,'base_commit':BASE,'base_tree':TREE,'controller_population':[],
                    'before_workplane':before,'run_inputs':run_files,'contract_sha256':sha((inputs/'verified-step.json').read_bytes())})
        return subject,relative,before,run_files,snapshot

    def one(self,case,variant,fixture):
        subject,relative,before,run_files,snapshot=fixture
        if not subject.is_relative_to(self.output/'subjects'): raise ValueError('owned restore boundary')
        shutil.rmtree(subject)
        shutil.copytree(snapshot,subject)
        run=subject/relative
        if observe_tree(subject)!=before or manifest(run)!=run_files: raise ValueError('paired fixture drift')
        package=self.output/'packages'/variant
        command=[BASH,str(package/'scripts/apply-observed-mutation.sh'),'--verified-step',str(run/'evidence/inputs/verified-step.json')]
        out,err,process=self.command(command,subject,variant+'-'+case['id']+'-actual-cli')
        try: decoded=json.loads(out)
        except ValueError: decoded=None
        observation={'schema':'dg17.m03.actual-observation.v1','case_id':case['id'],
                     'subject_root':str(subject),'run_relative':relative,'before_workplane':before,
                     'after_workplane':observe_tree(subject),'process':process,
                     'raw_stdout':out.decode('utf-8'),'raw_stderr':err.decode('utf-8'),'decoded_stdout':decoded}
        write_json(run/'evidence/observation.json',observation)
        out,err,oracle_process=self.command([PYTHON,'-I','-B',str(ROOT/'oracle.py'),'--cases',str(ROOT/'inputs/cases.json'),
                                           '--case-id',case['id'],'--observation',relative+'/evidence/observation.json'],subject,variant+'-'+case['id']+'-oracle')
        verdict=json.loads(out)
        destination=self.output/'observations'/variant/case['id']
        destination.mkdir(parents=True)
        write_json(destination/'observation.json',observation)
        write_json(destination/'oracle.json',verdict)
        write_json(destination/'oracle-process.json',oracle_process)
        received=destination/'received-subject'
        received.mkdir()
        for name in observation['after_workplane']:
            source=subject/name
            target=received/name
            target.parent.mkdir(parents=True,exist_ok=True)
            if source.is_symlink(): target.symlink_to(os.readlink(source))
            else: shutil.copy2(source,target)
        shutil.copytree(run,received/relative)
        write_json(destination/'RECEIVED_MANIFEST.json',{'files':manifest(received)})
        return verdict

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute',action='store_true',required=True)
    parser.add_argument('--root-admission-reference',required=True,help='Actual external Root decision; this text does not create authorization.')
    args=parser.parse_args()
    seal_sha=verify_seal()
    output=ROOT/'execution-01'
    output.mkdir(exist_ok=False)
    runner=Runner(output)
    matrix=json.loads((ROOT/'inputs/cases.json').read_text())
    cases={row['id']:row for row in matrix['cases']}
    write_json(output/'START.json',{'packet_seal_sha256':seal_sha,'root_admission_reference':args.root_admission_reference,
               'base_commit':BASE,'prospective_source':json.loads((ROOT/'evidence/SOURCE_DELTA.json').read_text()),
               'original_family':'M03','award_authority':'ROOT_ONLY'})
    code=1
    result={'original':{},'skip_baseline':{},'skip_postcheck':{}}
    try:
        source=ROOT/'candidate/skills/implementaudit'
        packages={}
        for variant in matrix['variant_cases']:
            target=output/'packages'/variant
            shutil.copytree(source,target)
            if variant!='original':
                shutil.copyfile(ROOT/'mutations'/variant/'verified-mutation-step.py',target/'scripts/verified-mutation-step.py')
            packages[variant]={r['path']:r for r in manifest(target)}
        for variant in ('skip_baseline','skip_postcheck'):
            differences=[name for name,row in packages['original'].items() if packages[variant].get(name)!=row]
            if set(packages[variant])!=set(packages['original']) or differences!=['scripts/verified-mutation-step.py']:
                raise ValueError('sole mutation premise')
        write_json(output/'PACKAGE_IDENTITIES.json',packages)
        fixtures={name:runner.setup(case) for name,case in cases.items()}
        for variant,names in matrix['variant_cases'].items():
            for name in names:
                verdict=runner.one(cases[name],variant,fixtures[name])
                result[variant][name]=verdict
                if variant=='original':
                    if verdict['verdict']!='PASS': raise RuntimeError('original witness failed; mutants remain gated')
                else:
                    expected=matrix['expected_mutation_observations'][variant][name]
                    if expected=='PASS':
                        if verdict['verdict']!='PASS': raise RuntimeError('specificity control failed')
                    elif verdict['verdict']!='FAIL' or verdict['counterexample']!=expected:
                        raise RuntimeError('exact mutation discriminator absent')
        code=0
    except Exception as error:
        write_json(output/'STOP.json',{'type':type(error).__name__,'reason':str(error),'no_retry':True,'award':False})
    finally:
        write_json(output/'RESULTS.json',{'status':'OBSERVED_EXPECTED_MATRIX' if code==0 else 'STOPPED_PRESERVED',
                   'results':result,'direct_process_count':runner.sequence,'award':False})
        files=manifest(output)
        write_json(output/'EXECUTION_MANIFEST.json',{'files':files,'count':len(files),'bytes':sum(row['bytes'] for row in files)})
    return code

if __name__=='__main__': raise SystemExit(main())
