# M03 prospective verified mutation step

Status: ordinary support engineering; no original or mutant witness is authorized by this document.

## Selection and source boundary

Original Issue211 line 603 requires an independently removed or inverted L3 Smoke A or Smoke B. Lines 541–545 allow structural identity, topology, population, marker, and authority evidence; lines 616–619 require behavior derived from actual state rather than vocabulary. This candidate will execute both checks as real subprocesses around the existing canonical mutation consumer, receive its actual transaction result, and inspect actual post-state. It claims no model judgment, host activation, native session containment, whole L3 lifecycle, case, terminal clause, or programme closure.

The selected immutable base is 51416b2f156b341c4a5f09029e2c6ceb5b30b1e7, tree 9c3913ceaa95f3f36b0377fe2dba4a302afcba89. The prospective candidate is that exact base plus the explicit source patch in this packet. It is not unchanged 51416. Root must admit that candidate after independent review. The old M03 completed serial survivor and its unawarded disposition remain historical evidence; this new support feature neither erases the survivor nor retroactively changes its source.

The exact base's PROTOCOL Step 5 requires actual before-state evidence and Step 10 requires after-state comparison. Its `apply-observed-mutation.sh` already owns actual authority, preimage, replacement, transaction, and return classification. Its one-row replacement batch route invokes and validates the full canonical single mutation consumer. It does not execute Smoke A/B. `validate-phase.sh`, the cold-review validators, and the mini-audit test do not supply that execution either. No existing incomplete M01/M04, M10/M11, or P02 path will be relabeled as this family.

Issue211 F2 forbids adding an R0037 runtime owner merely to provide a test target. F3 requires exact RED before claiming a runtime repair. This feature is separately owner-authorized ordinary product support engineering: it adds an opt-in checked mutation operation to the existing mutation CLI. It introduces no loop owner and asserts no preexisting runtime RED from an absence of automation. Whether the prospective candidate can earn the original M03 family is reserved to independent review and Root admission.

## Chosen approach

1. Reusing a textual phase validator would only prove specification shape, not actual baseline and post-check behavior. Rejected.
2. Driving an actual model governor would require genuine effective model/version/configuration and route evidence that this lane cannot supply. Not substituted.
3. Add a narrow optional execution adapter to the actual canonical mutation CLI. Chosen with Root authorization. Existing default behavior and the complete embedded mutation body remain byte-identical. The adapter invokes the existing one-row replacement preflight/apply routes and retains their actual reports. It owns sequencing and verification evidence only.

## Supported product operation

`bash skills/implementaudit/scripts/apply-observed-mutation.sh --verified-step CONTRACT.json`

The initial version is explicitly limited to an ordinary POSIX run, one already-authorized replacement, and one owner-selected observational check rerun unchanged before and after the replacement. Controller/protected routes, Windows, batches of multiple replacements, and arbitrary shell command strings are refused. A prospective new output directory under the actual ordinary run root makes re-entry non-replaying. The helper is not a sandbox for hostile commands or same-principal writers.

The exact unique-key JSON contract binds:

- schema, absolute real repository root, contained ordinary run root, phase, step, one relative target, complete preimage and candidate files;
- a fresh evidence-directory name under that run's evidence directory;
- one direct argv, an absolute regular executable with SHA-256, bounded duration/output, and exact hashes of the check's immutable input files;
- the permitted baseline exit status; a nonzero value requires an explicit known-preexisting-failure explanation; post-check success always requires exit zero.

The adapter captures the contract once, refuses symlink or unstable inputs, and keeps the contract, check inputs, phase/run bindings, source scripts, and replacement inputs unchanged across transitions. It calls the full canonical batch preflight before running a check. A refused authority/preimage/custody result cannot launch the baseline or mutation. The immutable one-row batch input is retained in its own evidence directory and is passed to the unchanged canonical batch apply path only after baseline admission. That canonical path independently revalidates authority and invokes the full mutation consumer; its actual live row disposition and result must agree with exact source/candidate identities and the actual target bytes.

## Exact sequencing and failure semantics

| State | Actual observation | Next permitted effect |
|---|---|---|
| Intake | Schema, input custody, ordinary root, fresh evidence location | Capture contract; run canonical preflight |
| Preflight | Canonical success with one replace row and current claim/phase/preimage | Capture actual target and run Smoke A |
| Smoke A | Complete actual command capture, permitted exit, no target or bound-input drift | Invoke canonical one-row apply |
| Apply | Complete actual child capture, canonical completed row, exact landed bytes | Capture actual target and rerun the same check |
| Smoke B | Complete actual capture, exit zero, unchanged landed bytes and bound inputs | Emit `VERIFIED_STEP` receipt |
| Any refusal/failure | Original streams, status, stage, and observed effects retained | Stop; no retry or success receipt |

A failed baseline prevents the replacement. An explicitly classified preexisting baseline failure may admit an intended repair, but the after check must pass. A failed after check preserves the actual replacement and its transaction evidence, returns nonzero, and emits no verified completion. There is no automatic compensation, replay, phase completion, currentness assertion, or audit closure.

Every child runs with a minimal explicit environment and direct argv in the actual repository, a fresh process group, bounded stdout/stderr, and a deadline. Timeout/overflow initiates TERM then KILL within finite grace intervals; direct-child reaping, observed group presence/absence, stream EOF, and actual signals are recorded. Unproved group absence is not called cleanup. Escaping descendants and hostile same-principal behavior are outside this ordinary POSIX guarantee. Any uncertain child or partial capture blocks verified completion. The entire evidence directory remains retained for independent receiving; no failed attempt is overwritten.

## Complete-family prospective discriminator

Use a small real Python workload with a callable and three numeric assertions. The same pinned checker argv runs before and after the actual authorized replacement. Inputs contain no intended verdict or mutation identity. Renamed/unfamiliar modules, callable names, and data exercise the same predicate. The oracle sees exact input declarations and actual observations only, never variant labels.

The two sole mutations independently omit (A) the call to the complete baseline execution/admission function or (B) the call to the complete after-check execution/admission function. Each variant differs from the admitted source in exactly that one call. The frozen inputs and oracle are identical for all variants. A baseline-failure case exposes a real unauthorized-by-verification target replacement when A is bypassed. A bad-candidate case exposes a real failed postcondition being called verified when B is bypassed. Controls include a valid change, an explicitly classified preexisting failure repaired by the change, an exact no-change operation, and a canonical preimage refusal. The held-outs repeat the two decisive failures with unfamiliar names and numeric functions.

The independent receiver must corroborate actual argv/PID/exit/streams, canonical transaction result and actual target bytes, check order, preserved non-target files, exact sole source mutations, and every oracle outcome. Counts and award remain Root-owned. A missing predicate is GAP, not partial-family credit.

## Qualification, scope, and rollback

Before review: authenticate the entire inherited dependency closure, add the adapter and CLI dispatch with documentation/test-registry wiring, inspect syntax and source load behavior, exercise help/refusal entry paths, and qualify bounded process capture with distinct ordinary controls (normal exit, nonzero exit, timeout, descendant residue, output overflow, input drift, symlink/duplicate JSON refusal). Those are support checks, not original M03 witnesses. Do not invoke any frozen original or mutant case, canonical mutation-authority check, or apply operation before Root admission.

The write set is only this packet. No Root controller, historical checkout, provider, accepted packet, or source-of-truth object is modified. Root alone may select/integrate/publish the source candidate. Rollback is to decline the candidate; the immutable base and every prior receipt remain intact. Later execution uses exclusive disposable fixture/evidence roots and preserves all failures. Product/package/install qualification beyond this source adapter is explicitly unclaimed and remains a separate triggered gate.

## Current binding

Root controller dg16-dg18-recovery-20261119-b, G0044, receipt 3fb3e2d80b1575b3a4ec28cc196957f9ce498523, freshly required current by Root native 6b1793/0. This child has ordinary source authoring authority only. No controller or original execution authority is delegated.
