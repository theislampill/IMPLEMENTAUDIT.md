# Constructed ordinary input

| Phase | Task |
|---|---|
| 1 | Apply the declared checked update |
