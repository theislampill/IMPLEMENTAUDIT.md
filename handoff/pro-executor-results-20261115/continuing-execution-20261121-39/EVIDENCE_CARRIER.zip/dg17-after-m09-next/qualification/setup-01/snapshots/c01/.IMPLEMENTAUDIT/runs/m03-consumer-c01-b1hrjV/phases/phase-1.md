# Constructed ordinary verified-step input; no executed verdicts

IMPLEMENTAUDIT_PHASE_START
Phase: 1 of 1 — Bounded callable update c01
Task: Apply one declared update while preserving the numeric example contract
Type: brownfield / reversible-local
Run root: .IMPLEMENTAUDIT/runs/m03-consumer-c01-b1hrjV
Baseline ref: 51416b2f156b341c4a5f09029e2c6ceb5b30b1e7
Owner/source: skills/implementaudit/scripts/apply-observed-mutation.sh and verified-mutation-step.py
Audit object: One ordinary observed replacement with actual before and after checks
Depends on phases: none

## Current state excerpts

- The actual source is `work/q.py` and the complete declared candidate is supplied as a separate observed input.
- The checker and numeric examples are immutable inputs and run unchanged before and after the request.

## Work

- Submit the one declared replacement through the actual opt-in canonical CLI and retain all command and transaction evidence.

## Implementation steps (ordered)

- Step 1: Apply the declared callable update — target: work/q.py; change: use the complete preimage and candidate through the actual mutation consumer; verify: python3 checks/inspect_result.py work/q.py checks/examples.json; expected: the fixed numeric examples agree with actual callable results
  mutation-authority: {"operation":"replace","source":"work/q.py","destination":null}

## Scope boundaries

In scope: work/q.py
Mutation scope: {"in":["work/q.py"],"out":["notes/unfinished-draft.txt","checks/inspect_result.py","checks/examples.json"]}
Out of scope: notes/unfinished-draft.txt; checks/inspect_result.py; checks/examples.json; all unrelated work.

## STOP conditions (plan-specific)

- Stop on an absent actual claim, unexpected controller identity, preimage mismatch, verification-input drift, or a changed prospective source packet.
- Stop on an unclassified baseline failure or a failed post-check; retain actual effects and do not replay this operation.

## Acceptance criteria

- The real before and after command results obey the frozen baseline policy and after-success requirement.
- The exact target and unrelated file states match the frozen operation-specific outcome and every incomplete check refuses verified completion.

## Mandatory commands

- /usr/bin/python3.13 -I -B /workspace/scratch/097486cde2dd/dg17-after-m09-next/oracle.py --cases /workspace/scratch/097486cde2dd/dg17-after-m09-next/inputs/cases.json --case-id c01 --observation .IMPLEMENTAUDIT/runs/m03-consumer-c01-b1hrjV/evidence/observation.json > .IMPLEMENTAUDIT/runs/m03-consumer-c01-b1hrjV/evidence/oracle.json 2>&1 — property: behavioral; scope: actual process order, exact ordinary mutation result and physical files; acceptance: non-textual; expected: exit 0 when the unchanged oracle agrees with the observed operation; coverage: full; capture: .IMPLEMENTAUDIT/runs/m03-consumer-c01-b1hrjV/evidence/oracle.json

## Evidence required

- Exact captured command argv, PID, exit, streams and process disposition, canonical transaction result, complete target before/after bytes, unchanged non-target state, and separate-process oracle.

## Rollback / defer path

Preserve failed process and mutation evidence. Restore only the owned disposable subject from its frozen setup snapshot between distinct admitted variants. No automatic retry or live project effect is authorized.

## Maintenance notes

- This constructed input has no controller, model, native-session, release, phase-closure, or audit-closure authority.

Markdown fallback: yes

## Prospective transcript anchors

IMPLEMENTAUDIT_PHASE_VERIFY
Status: pending actual consumer; no pass assertion.

AGENTS_UPDATE_DECISION
Decision: not warranted for this disposable witness.

CONTINUITY_DECISION
Decision: no controller in this fixture.

IMPLEMENTAUDIT_PHASE_DONE
Status: not executed; prospective schema anchor only.
