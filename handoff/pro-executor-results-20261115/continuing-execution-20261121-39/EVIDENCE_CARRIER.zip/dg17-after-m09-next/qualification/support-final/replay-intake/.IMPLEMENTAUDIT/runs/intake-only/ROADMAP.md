Constructed intake-only data; no actual claim.
