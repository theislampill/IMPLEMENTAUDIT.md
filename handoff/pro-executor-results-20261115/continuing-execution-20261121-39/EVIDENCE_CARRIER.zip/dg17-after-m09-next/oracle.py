#!/usr/bin/env python3
"""Variant-blind oracle over actual captured processes and exact work-plane bytes.

No variant argument, mutation-source name, model judgment, or label-derived
verdict is consumed. It never launches a product or mutates the work plane.
"""
import argparse
import base64
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import stat

def sha(data): return hashlib.sha256(data).hexdigest()

def file_record(data,mode):
    return {'kind':'regular','bytes':len(data),'sha256':sha(data),'mode':mode}

def tree(root):
    result={}
    for path in sorted(root.rglob('*')):
        rel=path.relative_to(root)
        if rel.parts[0] in {'.git','.IMPLEMENTAUDIT'}: continue
        st=path.lstat()
        if stat.S_ISREG(st.st_mode):
            result[rel.as_posix()]=file_record(path.read_bytes(),stat.S_IMODE(st.st_mode))
        elif stat.S_ISLNK(st.st_mode):
            result[rel.as_posix()]={'kind':'symlink','target':os.readlink(path)}
        elif not stat.S_ISDIR(st.st_mode):
            result[rel.as_posix()]={'kind':'unsupported'}
    return result

def evaluate(case,observation,received_subject=None):
    checks={}
    def check(name,value): checks[name]=bool(value)
    original_repo=Path(observation['subject_root'])
    repo=Path(received_subject) if received_subject is not None else original_repo
    before=observation['before_workplane']
    after=observation['after_workplane']
    receipt=observation['decoded_stdout']
    expected=case['expected_outcome']
    old=bytes.fromhex(case['before_hex'])
    candidate=bytes.fromhex(case['candidate_hex'])
    check('live-after-equals-received-after',tree(repo)==after)
    check('fixed-target-before',before.get(case['target'])==file_record(old,0o644))
    check('fixed-unrelated-before',before.get(case['unrelated_file'])==file_record(bytes.fromhex(case['unrelated_hex']),0o644))
    unchanged={key:value for key,value in before.items() if key!=case['target']}
    actual_other={key:value for key,value in after.items() if key!=case['target']}
    exact_other=unchanged==actual_other
    check('all-other-workplane-entries-identical',exact_other)
    target_changed=expected in {'VERIFIED_STEP','POSTCHECK_FAILED'}
    expected_after=dict(before)
    expected_after[case['target']]=file_record(candidate if target_changed else old,0o644)
    check('exact-operation-specific-post-state',after==expected_after)
    check('outer-process-captured',observation['process']['status']=='EXITED' and observation['process']['pid']>0
          and observation['process']['stdout_sha256']==sha(observation['raw_stdout'].encode())
          and observation['process']['stderr_bytes']==len(observation['raw_stderr'].encode()))
    if not isinstance(receipt,dict):
        return {'verdict':'FAIL','checks':checks,'counterexample':None,'reason':'NO_PRODUCT_RECEIPT'}
    check('receipt-schema',receipt.get('schema')=='implementaudit.verified-mutation-step-result.v1')
    check('no-authority-or-closure',receipt.get('authority')=='NONE' and receipt.get('closure_claim') is False
          and receipt.get('automatic_retry') is False and receipt.get('automatic_compensation') is False)
    original_output=Path(receipt.get('evidence_directory',''))
    if not original_output.is_absolute() or not original_output.is_relative_to(original_repo):
        return {'verdict':'FAIL','checks':checks,'counterexample':None,'reason':'EVIDENCE_NOT_CONTAINED'}
    output=repo/original_output.relative_to(original_repo)
    run=repo/observation['run_relative']
    contained=output.is_absolute() and output.is_relative_to(run/'evidence') and not output.is_symlink()
    check('receipt-output-contained',contained)
    if not contained:
        return {'verdict':'FAIL','checks':checks,'counterexample':None,'reason':'EVIDENCE_NOT_CONTAINED'}
    check('receipt-file-equals-live-return',json.loads((output/'receipt.json').read_bytes())==receipt)
    contract_bytes=(run/'evidence/inputs/verified-step.json').read_bytes()
    contract=json.loads(contract_bytes)
    check('captured-contract-identical',(output/'contract.json').read_bytes()==contract_bytes
          and receipt.get('contract_sha256')==sha(contract_bytes))
    stages=[]
    captures={}
    process_valid=True
    previous=None
    for row in receipt.get('processes',[]):
        stage=row.get('stage')
        stages.append(stage)
        directory=output/row['directory']
        valid=directory.parent==output and directory.is_dir() and not directory.is_symlink()
        actual=json.loads((directory/'process.json').read_bytes())
        record={k:v for k,v in row.items() if k not in {'stage','directory'}}
        valid=valid and actual==record and row.get('complete') is True and row.get('reason') is None
        valid=valid and row.get('direct_child_reaped') is True and row.get('group_absent') is True
        valid=valid and type(row.get('pid')) is int and row['pid']>0 and row.get('signals')==[]
        start=datetime.fromisoformat(row['started'])
        finish=datetime.fromisoformat(row['finished'])
        valid=valid and start<=finish and (previous is None or previous<=start)
        previous=finish
        for stream in ('stdout','stderr'):
            data=(directory/(stream+'.bin')).read_bytes()
            value=row[stream]
            valid=valid and value['bytes']==len(data) and value['sha256']==sha(data)
            valid=valid and value['eof'] is True and value['overflow'] is False and value['observed_bytes']==len(data)
            captures[(stage,stream)]=data
        process_valid=process_valid and valid
    check('all-inner-processes-complete-and-independent-files-match',process_valid)
    expected_stages={'VERIFIED_STEP':['PREFLIGHT','BASELINE','MUTATION','POSTCHECK'],
                     'BASELINE_OUTCOME_MISMATCH':['PREFLIGHT','BASELINE'],
                     'POSTCHECK_FAILED':['PREFLIGHT','BASELINE','MUTATION','POSTCHECK'],
                     'CANONICAL_PREFLIGHT_REFUSED':['PREFLIGHT']}[expected]
    check('exact-required-command-order',stages==expected_stages)
    def check_shape(stage,expected_exit):
        matches=[r for r in receipt['processes'] if r['stage']==stage]
        if len(matches)!=1 or matches[0]['argv']!=contract['check']['argv'] or matches[0]['returncode']!=expected_exit:
            return False
        try:
            value=json.loads(captures[(stage,'stdout')])
            observations=value['observations']
            return (len(observations)==len(case['check_data']['examples'])
                    and [(r['input'],r['expected']) for r in observations]==[tuple(r) for r in case['check_data']['examples']]
                    and value['failures']==sum(r['actual']!=r['expected'] for r in observations)
                    and (1 if value['failures'] else 0)==expected_exit)
        except (ValueError,TypeError,KeyError):
            return False
    baseline_valid=check_shape('BASELINE',case['expected_before_check_exit']) if 'BASELINE' in stages else False
    post_valid=check_shape('POSTCHECK',case['expected_after_check_exit']) if 'POSTCHECK' in stages else False
    if 'BASELINE' in expected_stages:
        check('actual-baseline-check',baseline_valid)
        baseline=receipt.get('baseline')
        check('baseline-exit-and-classification',isinstance(baseline,dict)
              and baseline.get('actual_exit')==case['expected_before_check_exit']
              and baseline.get('expected_exit')==case['baseline_expected_exit']
              and baseline.get('preexisting_failure')==case['preexisting_failure']
              and baseline.get('classification')==('PASS' if case['baseline_expected_exit']==0 else 'KNOWN_PREEXISTING_FAILURE'))
    else:
        check('no-baseline-after-preflight-refusal',receipt.get('baseline') is None)
    if 'POSTCHECK' in expected_stages:
        check('actual-post-check',post_valid)
        check('post-check-receipt',receipt.get('postcheck',{}) is not None
              and receipt.get('postcheck',{}).get('actual_exit')==case['expected_after_check_exit']
              and receipt.get('postcheck',{}).get('expected_exit')==0)
    else:
        check('no-post-check-after-stop',receipt.get('postcheck') is None)
    preflight=receipt.get('preflight',{})
    check('actual-preflight-return',json.loads(captures[('PREFLIGHT','stdout')])==preflight
          and preflight.get('schema')=='implementaudit.replacement-batch-preflight.v1'
          and preflight.get('controller_identity') is None)
    if expected=='CANONICAL_PREFLIGHT_REFUSED':
        check('exact-preimage-refusal',preflight.get('status')=='REFUSED' and preflight.get('reason_code')=='PREIMAGE_DRIFT')
    else:
        check('actual-authority-observation',preflight.get('status')=='OBSERVATION_ONLY' and preflight.get('checked_rows')==1
              and preflight.get('reason_code')=='NONE' and preflight.get('rows',[{}])[0].get('source')==case['target'])
    canonical_good=False
    mutation=receipt.get('mutation')
    if isinstance(mutation,dict) and 'MUTATION' in stages:
        try:
            row=mutation['rows'][0]
            actual=row['decoded_result']
            raw=base64.b64decode(row['stdout']['data'],validate=True)
            canonical_good=(json.loads(captures[('MUTATION','stdout')])==mutation
                and mutation['schema']=='implementaudit.replacement-batch-apply.v1'
                and mutation['status']=='COMPLETED' and mutation['requested_rows']==1
                and mutation['attempted_rows']==1 and mutation['completed_rows']==1
                and len(mutation['rows'])==1 and row['disposition']=='COMPLETED'
                and row['dispatch_started'] is True and row['returncode']==0
                and row['stdout']['sha256']==sha(raw) and row['stdout']['byte_length']==len(raw)
                and json.loads(raw)==actual and actual['schema']=='implementaudit.observation_bound_mutation.v2'
                and actual['status']==('NO_CHANGE' if old==candidate else 'COMMITTED')
                and actual['reason_code']=='NONE' and actual['operation']=='replace'
                and actual['source_path']==case['target'] and actual['destination_path'] is None
                and actual['phase']==1 and actual['step']==1 and actual['residue']==[]
                and actual['claim_id']==preflight['claim_id']
                and actual['authority_binding_sha256']==preflight['rows'][0]['authority']['authority_binding_sha256'])
            for key,data in [('pre_identities',bytes.fromhex(case['preimage_hex'])),('candidate_identities',candidate),('post_identities',candidate)]:
                identities=actual[key]
                canonical_good=canonical_good and len(identities)==1 and identities[0]['path']==case['target']
                identity=identities[0]['identity']
                canonical_good=canonical_good and identity['kind']=='regular' and identity['byte_length']==len(data) and identity['sha256']==sha(data)
            canonical_good=canonical_good and (bool(actual['actual_effect_set'])==(old!=candidate))
        except (KeyError,ValueError,TypeError,IndexError):
            canonical_good=False
    if 'MUTATION' in expected_stages:
        check('actual-canonical-complete-result-and-exact-identities',canonical_good)
    else:
        check('no-mutation-after-stop',mutation is None and not (run/'mutation-transactions').exists())
    code=0 if expected=='VERIFIED_STEP' else (70 if expected=='POSTCHECK_FAILED' else 64)
    check('outer-status-exit-and-verification',observation['process']['returncode']==code
          and receipt.get('status')==('VERIFIED_STEP' if code==0 else 'REFUSED')
          and receipt.get('reason')==('NONE' if code==0 else expected)
          and receipt.get('verified')==(code==0))
    counterexample=None
    integrity_names=['live-after-equals-received-after','fixed-target-before','fixed-unrelated-before',
                     'all-other-workplane-entries-identical','outer-process-captured','receipt-schema',
                     'no-authority-or-closure','receipt-output-contained','receipt-file-equals-live-return',
                     'captured-contract-identical','all-inner-processes-complete-and-independent-files-match',
                     'actual-preflight-return','actual-authority-observation']
    common=(all(checks.get(name,False) for name in integrity_names) and canonical_good
            and after=={**before,case['target']:file_record(candidate,0o644)}
            and receipt.get('status')=='VERIFIED_STEP' and receipt.get('verified') is True
            and receipt.get('reason')=='NONE' and observation['process']['returncode']==0)
    if (common and expected=='BASELINE_OUTCOME_MISMATCH' and stages==['PREFLIGHT','MUTATION','POSTCHECK']
            and receipt.get('baseline') is None and post_valid):
        counterexample='BASELINE_BYPASS_EXACT_EFFECT'
    if (common and expected=='POSTCHECK_FAILED' and stages==['PREFLIGHT','BASELINE','MUTATION']
            and receipt.get('postcheck') is None and baseline_valid):
        counterexample='POSTCHECK_BYPASS_EXACT_EFFECT'
    return {'verdict':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'counterexample':counterexample,
            'observed_stages':stages,'expected_stages':expected_stages,
            'claim_ceiling':'ordinary actual process, authority, and exact file effects only'}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cases',type=Path,required=True)
    parser.add_argument('--case-id',required=True)
    parser.add_argument('--observation',type=Path,required=True)
    parser.add_argument('--received-subject',type=Path,
                        help='Read an immutable received copy of actual post-state; never re-execute the operation.')
    args=parser.parse_args()
    case=next(c for c in json.loads(args.cases.read_text())['cases'] if c['id']==args.case_id)
    observation=json.loads(args.observation.read_text())
    result=evaluate(case,observation,args.received_subject)
    print(json.dumps(result,sort_keys=True))
    return 0 if result['verdict']=='PASS' else 1

if __name__=='__main__': raise SystemExit(main())
