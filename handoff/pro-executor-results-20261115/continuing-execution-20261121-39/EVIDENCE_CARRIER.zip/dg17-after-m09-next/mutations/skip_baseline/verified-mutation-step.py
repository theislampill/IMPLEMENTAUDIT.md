#!/usr/bin/env python3
"""Opt-in ordinary POSIX check -> canonical replacement -> recheck adapter.

The actual mutation CLI remains the authority and transaction owner. This
module adds no controller, protected-route, model, native-session, or closure
authority. Check commands are trusted owner-selected commands, not sandboxed
untrusted code. Same-principal hostile writers and escaped sessions are outside
this ordinary local support contract.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import selectors
import signal
import stat
import subprocess
import sys
import time

SCHEMA = 'implementaudit.verified-mutation-step-input.v1'
RESULT_SCHEMA = 'implementaudit.verified-mutation-step-result.v1'
FILE_LIMIT = 8 * 1024 * 1024
STAGE_LIMIT = 1024 * 1024


class Refusal(Exception):
    def __init__(self, reason):
        self.reason = reason
        super().__init__(reason)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def strict_json(data):
    def members(pairs):
        value = {}
        for key, item in pairs:
            if key in value:
                raise ValueError('duplicate member')
            value[key] = item
        return value
    def invalid(_value):
        raise ValueError('non-integer JSON number')
    try:
        value = json.loads(data.decode('utf-8'), object_pairs_hook=members,
                           parse_constant=invalid, parse_float=invalid)
        json.dumps(value, ensure_ascii=False).encode('utf-8')
        return value
    except (ValueError, UnicodeError, RecursionError):
        raise Refusal('JSON_INVALID') from None


def safe_path(path, *, directory=False):
    path = Path(path)
    if not path.is_absolute() or '..' in path.parts:
        raise Refusal('INPUT_CUSTODY_UNSAFE')
    for parent in reversed(path.parents):
        if not stat.S_ISDIR(parent.lstat().st_mode):
            raise Refusal('INPUT_CUSTODY_UNSAFE')
    mode = path.lstat().st_mode
    if not (stat.S_ISDIR(mode) if directory else stat.S_ISREG(mode)):
        raise Refusal('INPUT_CUSTODY_UNSAFE')
    return path


def physical(st):
    return [st.st_dev, st.st_ino, st.st_mode, st.st_size,
            st.st_mtime_ns, st.st_ctime_ns, st.st_nlink]


def capture_file(path, limit=FILE_LIMIT):
    path = safe_path(path)
    before = path.lstat()
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        opened = os.fstat(fd)
        if not stat.S_ISREG(opened.st_mode) or physical(before) != physical(opened):
            raise Refusal('INPUT_CUSTODY_UNSAFE')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            data = stream.read(limit + 1)
        after = os.fstat(fd)
        current = path.lstat()
        if physical(opened) != physical(after) or physical(after) != physical(current):
            raise Refusal('INPUT_DRIFT')
        safe_path(path)
        if len(data) > limit:
            raise Refusal('INPUT_LIMIT')
        return {'data':data, 'bytes':len(data), 'sha256':digest(data), 'physical':physical(after)}
    finally:
        os.close(fd)


def public_capture(value):
    return {key:item for key,item in value.items() if key != 'data'}


def recheck(pins):
    for path, before in pins.items():
        try:
            after = capture_file(path, max(FILE_LIMIT, before['bytes']))
        except (OSError, Refusal):
            raise Refusal('INPUT_DRIFT') from None
        if public_capture(before) != public_capture(after):
            raise Refusal('INPUT_DRIFT')


def write_new(path, data):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=False, indent=2)+'\n').encode('utf-8')


def group_absent(pgid):
    try:
        os.killpg(pgid, 0)
        return False
    except ProcessLookupError:
        return True
    except PermissionError:
        return None


def run_process(argv, cwd, env, place, timeout, limit):
    """Bounded real process capture, with explicit uncertainty instead of success."""
    place.mkdir(parents=True, exist_ok=False)
    started = datetime.now(timezone.utc).isoformat()
    start = time.monotonic()
    result = {'argv':list(argv), 'cwd':str(cwd), 'environment':dict(env),
              'started':started, 'timeout_seconds':timeout, 'output_limit_per_stream':limit,
              'pid':None, 'observed_pgid':None, 'returncode':None,
              'direct_child_reaped':False, 'group_absent':None, 'signals':[],
              'signal_results':[], 'complete':False, 'reason':None}
    streams = {name:{'data':bytearray(), 'observed':0, 'overflow':False, 'eof':False}
               for name in ('stdout','stderr')}
    selector = selectors.DefaultSelector()
    process = None
    term_at = None
    kill_at = None
    def send(sig):
        result['signals'].append(sig.name)
        try:
            os.killpg(process.pid, sig)
            outcome = 'SENT'
        except ProcessLookupError:
            outcome = 'GROUP_ABSENT'
        except OSError:
            outcome = 'SIGNAL_FAILED'
        result['signal_results'].append({'signal':sig.name, 'outcome':outcome})
    try:
        process = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   start_new_session=True, close_fds=True)
        result['pid'] = process.pid
        try:
            result['observed_pgid'] = os.getpgid(process.pid)
        except ProcessLookupError:
            pass
        for name in streams:
            pipe = getattr(process, name)
            os.set_blocking(pipe.fileno(), False)
            selector.register(pipe, selectors.EVENT_READ, name)
        deadline = start + timeout
        while selector.get_map() or process.poll() is None:
            now = time.monotonic()
            if now >= deadline and result['reason'] is None:
                result['reason'] = 'TIMEOUT'
            if result['reason'] is not None and term_at is None:
                send(signal.SIGTERM)
                term_at = now
            if term_at is not None and now >= term_at + 0.2 and kill_at is None:
                if process.poll() is None or group_absent(process.pid) is not True:
                    send(signal.SIGKILL)
                kill_at = now
            if kill_at is not None and now >= kill_at + 0.5:
                break
            for key,_mask in selector.select(0.02):
                try:
                    chunk = os.read(key.fileobj.fileno(), 65536)
                except BlockingIOError:
                    continue
                stream = streams[key.data]
                if not chunk:
                    stream['eof'] = True
                    selector.unregister(key.fileobj)
                    key.fileobj.close()
                    continue
                stream['observed'] += len(chunk)
                remaining = max(0, limit-len(stream['data']))
                stream['data'].extend(chunk[:remaining])
                if len(chunk) > remaining:
                    stream['overflow'] = True
                    result['reason'] = result['reason'] or 'OUTPUT_LIMIT'
        if process.poll() is None:
            send(signal.SIGKILL)
        try:
            result['returncode'] = process.wait(timeout=0.5)
            result['direct_child_reaped'] = True
        except subprocess.TimeoutExpired:
            result['reason'] = result['reason'] or 'DIRECT_CHILD_UNREAPED'
        remaining_group = group_absent(process.pid)
        if remaining_group is not True:
            result['reason'] = result['reason'] or 'DESCENDANT_STATE_UNPROVED'
            if term_at is None:
                send(signal.SIGTERM)
            if kill_at is None:
                send(signal.SIGKILL)
        result['group_absent'] = group_absent(process.pid)
        if any(not row['eof'] for row in streams.values()):
            result['reason'] = result['reason'] or 'STREAM_CAPTURE_INCOMPLETE'
        result['complete'] = (result['reason'] is None and result['direct_child_reaped']
                              and result['group_absent'] is True)
    except OSError as error:
        result['reason'] = 'PROCESS_IO_UNAVAILABLE'
        result['exception_type'] = type(error).__name__
        result['errno'] = error.errno
        if process is not None:
            send(signal.SIGKILL)
            try:
                result['returncode'] = process.wait(timeout=0.5)
                result['direct_child_reaped'] = True
            except subprocess.TimeoutExpired:
                pass
            result['group_absent'] = group_absent(process.pid)
    finally:
        for key in list(selector.get_map().values()):
            key.fileobj.close()
        selector.close()
    for name,row in streams.items():
        data = bytes(row['data'])
        write_new(place/(name+'.bin'),data)
        result[name] = {'file':name+'.bin','bytes':len(data),'sha256':digest(data),
                        'observed_bytes':row['observed'],'overflow':row['overflow'],'eof':row['eof']}
    result['finished'] = datetime.now(timezone.utc).isoformat()
    result['elapsed_seconds'] = time.monotonic()-start
    write_new(place/'process.json',json_bytes(result))
    return result


def relative_name(value):
    if (not isinstance(value,str) or not value or '\\' in value
            or any(ord(c)<32 for c in value)):
        raise Refusal('CONTRACT_PATH_INVALID')
    path = PurePosixPath(value)
    if path.is_absolute() or any(p in ('','.','..') for p in value.split('/')):
        raise Refusal('CONTRACT_PATH_INVALID')
    return value


def baseline_policy(expected, explanation):
    if type(expected) is not int or not 0 <= expected <= 125:
        raise Refusal('BASELINE_EXIT_INVALID')
    if expected:
        if not isinstance(explanation,str) or not explanation.strip():
            raise Refusal('BASELINE_CLASSIFICATION_REQUIRED')
        return 'KNOWN_PREEXISTING_FAILURE'
    if explanation is not None:
        raise Refusal('BASELINE_CLASSIFICATION_INVALID')
    return 'PASS'


def validate_contract(value):
    fields = {'schema','repo_root','run_root','phase','step','source','preimage','candidate',
              'evidence_name','check','baseline_expected_exit','preexisting_failure'}
    if not isinstance(value,dict) or set(value) != fields or value['schema'] != SCHEMA:
        raise Refusal('CONTRACT_SCHEMA_INVALID')
    if os.name != 'posix':
        raise Refusal('PLATFORM_UNSUPPORTED')
    if (not isinstance(value['repo_root'],str) or not Path(value['repo_root']).is_absolute()
            or any(type(value[k]) is not int or value[k]<=0 for k in ('phase','step'))):
        raise Refusal('CONTRACT_SCHEMA_INVALID')
    repo = safe_path(Path(value['repo_root']),directory=True)
    for key in ('run_root','source','preimage','candidate'):
        relative_name(value[key])
    if (not value['run_root'].startswith('.IMPLEMENTAUDIT/runs/')
            or len(PurePosixPath(value['run_root']).parts)!=3
            or PurePosixPath(value['source']).parts[0] in {'.git','.IMPLEMENTAUDIT'}):
        raise Refusal('CONTRACT_PATH_INVALID')
    run = safe_path(repo/value['run_root'],directory=True)
    if (run/'.controller').exists() or (run/'.controller').is_symlink():
        raise Refusal('CONTROLLER_ROUTE_UNSUPPORTED')
    for key in ('preimage','candidate'):
        if not (repo/value[key]).is_relative_to(run/'evidence'):
            raise Refusal('REPLACEMENT_INPUT_OUTSIDE_RUN')
    if (not isinstance(value['evidence_name'],str)
            or not re.fullmatch(r'verified-step-[a-z0-9][a-z0-9-]{0,63}',value['evidence_name'])):
        raise Refusal('EVIDENCE_NAME_INVALID')
    check = value['check']
    if (not isinstance(check,dict) or set(check)!={'argv','executable_sha256','inputs','timeout_seconds','output_limit'}
            or not isinstance(check['argv'],list) or not check['argv'] or len(check['argv'])>128
            or any(not isinstance(a,str) or not a or '\0' in a or len(a)>4096 for a in check['argv'])
            or not Path(check['argv'][0]).is_absolute()
            or type(check['timeout_seconds']) is not int or not 1<=check['timeout_seconds']<=30
            or type(check['output_limit']) is not int or not 1024<=check['output_limit']<=STAGE_LIMIT
            or not isinstance(check['executable_sha256'],str)
            or not re.fullmatch(r'[0-9a-f]{64}',check['executable_sha256'])
            or not isinstance(check['inputs'],list) or not check['inputs'] or len(check['inputs'])>32):
        raise Refusal('CHECK_SCHEMA_INVALID')
    seen=set()
    for pin in check['inputs']:
        if (not isinstance(pin,dict) or set(pin)!={'path','bytes','sha256'}
                or type(pin['bytes']) is not int or not 0<=pin['bytes']<=FILE_LIMIT
                or not isinstance(pin['sha256'],str) or not re.fullmatch(r'[0-9a-f]{64}',pin['sha256'])):
            raise Refusal('CHECK_INPUT_INVALID')
        name=relative_name(pin['path'])
        if name in seen or name==value['source']:
            raise Refusal('CHECK_INPUT_INVALID')
        seen.add(name)
    baseline_policy(value['baseline_expected_exit'],value['preexisting_failure'])
    return repo,run


def execute_contract(path, script_dir, bash):
    result={'schema':RESULT_SCHEMA,'status':'REFUSED','reason':'NONE','verified':False,
            'stage':'INTAKE','processes':[],'baseline':None,'mutation':None,'postcheck':None,
            'authority':'NONE','closure_claim':False,'automatic_retry':False,
            'automatic_compensation':False,'evidence_directory':None}
    output=None
    code=64
    target=None
    try:
        contract_capture=capture_file(path,262144)
        contract=strict_json(contract_capture['data'])
        repo,run=validate_contract(contract)
        script_dir=safe_path(script_dir,directory=True)
        bash=safe_path(bash)
        pins={str(path):contract_capture}
        def pin(path,limit=FILE_LIMIT):
            record=capture_file(path,limit)
            pins[str(path)]=record
            return record
        for name in ('.claimed','STATE.md','ROADMAP.md',f"phases/phase-{contract['phase']}.md"):
            pin(run/name)
        source_names=sorted(p.name for p in script_dir.iterdir() if p.suffix in {'.sh','.py'})
        for name in source_names:
            pin(script_dir/name)
        pin(bash,32*1024*1024)
        executable=pin(Path(contract['check']['argv'][0]),32*1024*1024)
        if executable['sha256']!=contract['check']['executable_sha256']:
            raise Refusal('CHECK_EXECUTABLE_MISMATCH')
        for item in contract['check']['inputs']:
            got=pin(repo/item['path'])
            if got['bytes']!=item['bytes'] or got['sha256']!=item['sha256']:
                raise Refusal('CHECK_INPUT_MISMATCH')
        preimage=pin(repo/contract['preimage'])
        candidate=pin(repo/contract['candidate'])
        target=repo/contract['source']
        before=capture_file(target)
        safe_path(run/'evidence',directory=True)
        prospective=run/'evidence'/contract['evidence_name']
        prospective.mkdir(mode=0o700,exist_ok=False)
        output=prospective
        output_identity=physical(output.lstat())[:3]
        write_new(output/'contract.json',contract_capture['data'])
        result.update(evidence_directory=str(output),contract_sha256=contract_capture['sha256'],
                      target_before=public_capture(before),source_scripts=source_names,
                      bindings={name:public_capture(value) for name,value in pins.items()})
        (output/'tmp').mkdir(mode=0o700)
        env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8',
             'PYTHONDONTWRITEBYTECODE':'1','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null',
             'TMPDIR':str(output/'tmp'),'IMPLEMENTAUDIT_BASE':'.IMPLEMENTAUDIT/runs'}
        batch={'schema':'implementaudit.replacement-batch-preflight-input.v1','rows':[
               {key:contract[key] for key in ('step','source','preimage','candidate')}]}
        batch_path=output/'replacement.json'
        write_new(batch_path,json_bytes(batch))
        pin(batch_path)
        def check_bindings():
            recheck(pins)
            if sorted(p.name for p in script_dir.iterdir() if p.suffix in {'.sh','.py'})!=source_names:
                raise Refusal('SOURCE_POPULATION_DRIFT')
            safe_path(output,directory=True)
            if physical(output.lstat())[:3]!=output_identity:
                raise Refusal('EVIDENCE_CUSTODY_DRIFT')
            if (run/'.controller').exists() or (run/'.controller').is_symlink():
                raise Refusal('CONTROLLER_ROUTE_UNSUPPORTED')
        def invoke(stage,argv,timeout=45,limit=STAGE_LIMIT):
            result['stage']=stage
            check_bindings()
            place=output/(f"{len(result['processes'])+1:02d}-"+stage.lower())
            observed=run_process(argv,repo,env,place,timeout,limit)
            result['processes'].append({'stage':stage,'directory':place.name,**observed})
            if not observed['complete']:
                raise Refusal(stage+'_CAPTURE_'+str(observed['reason']))
            check_bindings()
            return observed,(place/'stdout.bin').read_bytes()
        base=[str(bash),str(script_dir/'apply-observed-mutation.sh'),
              '--repo-root',str(repo),'--run-root',contract['run_root'],
              '--phase',str(contract['phase'])]
        observed,raw=invoke('PREFLIGHT',base+['--batch-preflight',str(batch_path)])
        preflight=strict_json(raw)
        result['preflight']=preflight
        if (observed['returncode']!=0 or preflight.get('schema')!='implementaudit.replacement-batch-preflight.v1'
                or preflight.get('status')!='OBSERVATION_ONLY' or preflight.get('reason_code')!='NONE'
                or preflight.get('checked_rows')!=1 or preflight.get('controller_identity') is not None
                or preflight.get('rows',[{}])[0].get('source')!=contract['source']):
            raise Refusal('CANONICAL_PREFLIGHT_REFUSED')
        def baseline_gate():
            observed,_raw=invoke('BASELINE',contract['check']['argv'],contract['check']['timeout_seconds'],contract['check']['output_limit'])
            result['baseline']={'process_directory':result['processes'][-1]['directory'],
                                'actual_exit':observed['returncode'],
                                'expected_exit':contract['baseline_expected_exit'],
                                'classification':baseline_policy(contract['baseline_expected_exit'],contract['preexisting_failure']),
                                'preexisting_failure':contract['preexisting_failure']}
            if observed['returncode']!=contract['baseline_expected_exit']:
                raise Refusal('BASELINE_OUTCOME_MISMATCH')
            if public_capture(capture_file(target))!=public_capture(before):
                raise Refusal('BASELINE_CHANGED_TARGET')
        pass  # skip_baseline sole omitted gate call
        observed,raw=invoke('MUTATION',base+['--batch-apply',str(batch_path)])
        mutation=strict_json(raw)
        result['mutation']=mutation
        if (observed['returncode']!=0 or mutation.get('schema')!='implementaudit.replacement-batch-apply.v1'
                or mutation.get('status')!='COMPLETED' or mutation.get('attempted_rows')!=1
                or mutation.get('completed_rows')!=1 or mutation.get('batch_input_sha256')!=pins[str(batch_path)]['sha256']
                or len(mutation.get('rows',[]))!=1 or mutation['rows'][0].get('disposition')!='COMPLETED'
                or mutation['rows'][0].get('source')!=contract['source']
                or mutation['rows'][0].get('step')!=contract['step']):
            raise Refusal('CANONICAL_MUTATION_NOT_COMPLETED')
        landed=capture_file(target)
        result['target_landed']=public_capture(landed)
        if landed['data']!=candidate['data']:
            raise Refusal('LANDED_BYTES_MISMATCH')
        def postcheck_gate():
            observed,_raw=invoke('POSTCHECK',contract['check']['argv'],contract['check']['timeout_seconds'],contract['check']['output_limit'])
            result['postcheck']={'process_directory':result['processes'][-1]['directory'],
                                 'actual_exit':observed['returncode'],'expected_exit':0}
            if observed['returncode']!=0:
                raise Refusal('POSTCHECK_FAILED')
            if public_capture(capture_file(target))!=public_capture(landed):
                raise Refusal('POSTCHECK_CHANGED_TARGET')
        postcheck_gate()
        check_bindings()
        result.update(status='VERIFIED_STEP',reason='NONE',verified=True,stage='RECEIPT')
        code=0
    except Refusal as error:
        result.update(reason=error.reason,verified=False)
        code=70 if result['stage'] in {'MUTATION','POSTCHECK','RECEIPT'} else 64
    except (OSError,ValueError,TypeError,KeyError,IndexError) as error:
        result.update(reason='CUSTODY_OR_RESULT_UNAVAILABLE',verified=False,
                      exception_type=type(error).__name__)
        code=70 if result['stage'] in {'MUTATION','POSTCHECK','RECEIPT'} else 64
    if target is not None:
        try:
            result['target_observed_at_return']=public_capture(capture_file(target))
        except (Refusal,OSError):
            result['target_observed_at_return']=None
    if output is not None:
        try:
            safe_path(output,directory=True)
            if physical(output.lstat())[:3]!=output_identity:
                raise Refusal('EVIDENCE_CUSTODY_DRIFT')
            write_new(output/'receipt.json',json_bytes(result))
        except (OSError,Refusal):
            result.update(status='REFUSED',reason='RECEIPT_PUBLICATION_UNAVAILABLE',verified=False)
            code=70
    return code,result


def main():
    parser=argparse.ArgumentParser(description=__doc__,usage='apply-observed-mutation.sh --verified-step CONTRACT.json')
    parser.add_argument('contract',type=Path,metavar='CONTRACT.json')
    args=parser.parse_args()
    code,result=execute_contract(args.contract.absolute(),Path(__file__).resolve().parent,Path('/usr/bin/bash'))
    print(json.dumps(result,sort_keys=True,separators=(',',':')))
    return code


if __name__=='__main__':
    raise SystemExit(main())
