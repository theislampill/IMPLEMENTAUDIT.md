# Verified mutation step implementation plan

**Goal:** Prepare one reviewable prospective complete M03 family using an actual opt-in canonical CLI operation.

**Architecture:** Extend `apply-observed-mutation.sh` with an explicit first-argument dispatch into a small sibling Python adapter. Keep the full canonical embedded mutation body unchanged, invoke its existing replacement preflight and apply routes, and bind real checks and effects into a non-authoritative verified-step receipt.

**Tech stack:** Bash entrypoint; Python standard library on POSIX; unchanged canonical Git/claim/phase/mutation helpers.

**Spec:** DESIGN.md and unchanged original Issue211.

## Constraints and review focus

No original or mutant witness before independent review and Root gate. No integration, commit, provider write, Root controller mutation, model/host claim, or repeated accepted operation. No deletion of prior evidence. Exact source and fixture identity must be independently receivable. Review especially: command timeout/partial output, same-principal input drift, preexisting baseline classification, failed post-check after real effects, and malformed/replayed evidence roots. Qualification covers each without running the frozen original family.

## One bounded deliverable

- [x] Receive complete authentic base dependency closure and owner clauses; hash against the authenticated exact Git tree.
- [x] Create `skills/implementaudit/scripts/verified-mutation-step.py`; strict contract, canonical CLI calls, real command capture, immutable bindings, truthful failure and receipt states.
- [x] Add only opt-in dispatch to `apply-observed-mutation.sh`; add the owner reference and focused support test to the canonical registry. Do not alter the embedded mutation body.
- [x] Run narrowly scoped ordinary support qualification with actual CLI entry/help/refusals and process/custody controls; retain exact commands and every outcome.
- [x] Freeze all prospective original inputs, both one-call source mutations, variant-blind exact state/process oracle, runner, and independent receiving instructions. No invocation of the family.
- [ ] Derive proposed full-tree identity without repository writes; verify exact source diff and all packet members; seal the packet.
- [ ] Return READY_FOR_INDEPENDENT_SOURCE_REVIEW or exact GAP with no award. Root performs independent gate and source admission before original execution.

No commit step is authorized. Rollback is rejection/removal of this prospective local packet only after preserving its evidence; sealed predecessors remain untouched.
