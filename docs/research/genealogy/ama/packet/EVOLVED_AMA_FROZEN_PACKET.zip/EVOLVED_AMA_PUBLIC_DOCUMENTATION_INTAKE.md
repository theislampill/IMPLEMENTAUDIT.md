# Evolved-AMA — public-documentation intake

**Revision:** `AMA-2026-09-07-r1`

## Description suitable for public use

Autonomous Agents, Multi-Agent Systems and Agent-Oriented Software Engineering are established research traditions/fields with different ages, scopes and objects of study. EAA concerns an individual agent’s observation, decisions, goals, action, repair and bounded revision. EMAS concerns interactions, coordination, communication, commitments, organisations and collective failure. EAOSE concerns justified requirements, roles, models, implementations, evidence and engineering choices. The histories and source-scoped claims supporting these descriptions remain in the frozen constituent packets; this synthesis does not invent a new historical lineage.

**Evolved-AMA is an analytical composition of three frozen evolved studies.** It preserves all 278 inherited property rows and all 234 local source records, adds explicit guarded cross-lineage relations and counterexamples, and retains alternative configurations rather than imposing one “AMA mode”. Its full configuration family has not been demonstrated as universally superior or independently empirically validated.

The novelty search admitted **zero new AMA-E identities**. That does not erase the three inherited EAA and four inherited EMAS composition-induced rows, nor does it mean the result is only concatenation. New relational derivations, cross-level failure tests, tension resolutions/boundaries and configuration choices are retained without relabelling already inherited criteria as new properties. Any AMA-E property in a future revision would be an analytical deduction unless separately source-grounded and validated; novelty, evidence and capability would require separate accounting.

Conventional/non-agent implementations, agent-oriented analysis with conventional execution, single agents and mixed systems remain legitimate where their applicable requirements, rights and costs justify them. More agents, autonomy, communication, modelling or coordination are not maturity indicators by themselves. BDI, public commitments, FIPA, organisational models, human approval, decentralisation, swarms, debate, delegation, LLM agents and self-revision are not mandatory universal ingredients.

The practical boundary is that intention, obligation, authority, permission, capability, attempted action, performed action, observed effect and accepted outcome are not interchangeable. A legal conversation or coherent local plan does not automatically establish authorised external completion. Reflection, role prompts, source agreement and human approval likewise do not automatically supply assurance.

## Claims not supported by this packet

Do not say “AMA guarantees improvement”, “AMA proves agents outperform conventional engineering”, “234 sources independently validate AMA”, “20,152 relations are independent discoveries”, “pairwise consistency proves global validity”, “the whole system is formally proved”, or “general self-revision assurance is solved”. The inherited general self-revision, current FIPA equivalence and whole-method-benefit questions remain unresolved, and formal/contemporary results keep their specific model, version, population and access limits.

Do not imply any IMPLEMENTAUDIT adoption, target ownership, repository integration, release decision, Rockstar/RXX derivation or outside-trifecta superiority. This packet is an input to a later property-by-property comparison, not that comparison itself.

## Documentation trace

Use `EVOLVED_AMA_FROZEN_REPORT.md` for the synthesis; the property/source registers and original archives for frozen semantics and evidence; the matrix and directional ledger for pair classifications; the novelty ledger for rejected candidates; the counterexample/model/configuration ledgers for guarded application; and the completeness review, manifest and verification receipts for accounting/custody boundaries.
