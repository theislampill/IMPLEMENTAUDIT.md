#!/usr/bin/env python3
"""Read-only Evolved-AMA verifier. Standard library only; no network or corpus writes.
Usage: python verify_ama.py EXTRACTED_DIRECTORY --phase frozen
--tamper performs an in-memory negative test only; it never modifies files.
This verifies the stated structural/custody/finite-model obligations, not the
independent scholarly truth of every natural-language relation or source claim.
"""
from pathlib import Path
import argparse,collections,hashlib,itertools,json,sys,zipfile
F='EVOLVED_AMA_';ORDER=['EAA','EMAS','EAOSE']
EXPECTED={'EAA':('EAA-2026-09-06-r1','009b37693541d387a2d65c281815731a05423b31fae298a9c6c99ad069e87769',70,54),'EMAS':('EMAS-R1','84af391ed2c82514f0e22ff671a0945945dec608ffccfde485e2302374bab227',76,56),'EAOSE':('EAOSE-CANONICAL-R1-2026-09-07','17cf10e5bedfe8a52d0a85c81c318294a0d80e5ca8ad8f868e12b7a116b34b9a',132,124)}
REQUIRED=['FROZEN_REPORT.md','CONSTITUENT_PROPERTY_REGISTER.json','INTRA_CROSSWALK_MATRIX.json','DIRECTIONAL_RELATION_LEDGER.json','CONVERGENCE_AND_COMPOSITION_CLUSTERS.json','TENSION_LEDGER.json','COMPOSITION_INDUCED_PROPERTY_LEDGER.json','COMPOSITION_MODEL.json','ALTERNATIVE_CONFIGURATIONS.json','SHARED_SOURCE_IDENTITY_LEDGER.json','ANALYTICAL_COUNTEREXAMPLES.json','COMPLETENESS_AND_REVERSE_CONSISTENCY_REVIEW.md','INTER_CROSSWALK_INTAKE.md','INTER_CROSSWALK_INTAKE.json','PUBLIC_DOCUMENTATION_INTAKE.md','FROZEN_MANIFEST.json','VERIFICATION_RECEIPT.json']
LATE={'COMPLETENESS_AND_REVERSE_CONSISTENCY_REVIEW.md','FROZEN_MANIFEST.json','VERIFICATION_RECEIPT.json'}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def must(test,msg):
 if not test:raise AssertionError(msg)
def qp(l,x):return l+':'+x
def ordered_pair(x,y):return tuple(sorted([x,y],key=lambda k:(ORDER.index(k.split(':')[0]),k)))

def run(root,phase,tamper=None):
 checks=[];cache={};origp={};origs={};inputmeta={};within={}
 def read(name):
  if name not in cache:cache[name]=json.loads((root/(F+name+'.json')).read_text(encoding='utf-8'))
  return cache[name]
 def check(n,label,fn,boundary='Mechanical full-population/reference check; not independent scholarly validation.'):
  try:
   detail=fn();checks.append(dict(id=n,name=label,status='PASS',detail=detail,assurance_boundary=boundary))
  except Exception as e:checks.append(dict(id=n,name=label,status='FAIL',detail=f'{type(e).__name__}: {e}',assurance_boundary=boundary))
 def input_check():
  for l,(rev,h,np,ns) in EXPECTED.items():
   p=root/'constituents'/f'{l}.zip';must(sha(p)==h,l+' enclosing hash')
   with zipfile.ZipFile(p) as z:
    must(z.testzip() is None,l+' CRC');mf=[n for n in z.namelist() if n.endswith('FROZEN_MANIFEST.json')];must(len(mf)==1,l+' manifest unique')
    man=json.loads(z.read(mf[0]));must(man['revision']==rev,l+' internal revision');inv=man.get('inventory',man.get('payload_inventory',man.get('payloads')))
    must(set(z.namelist())==set([mf[0]]+[x['filename'] for x in inv]),l+' exact input members')
    for row in inv:
     b=z.read(row['filename']);must(len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],l+' input member bytes/hash '+row['filename'])
    pf=next(n for n in z.namelist() if n.endswith('PROPERTY_LEDGER.json'));sf=next(n for n in z.namelist() if n.endswith('SOURCE_TABLE.json'));cf=next(n for n in z.namelist() if n.endswith('COMPOSITION_MODEL.json'));vf=next(n for n in z.namelist() if n.endswith('RESEARCH_COVERAGE.json'))
    pt=json.loads(z.read(pf));st=json.loads(z.read(sf));ct=json.loads(z.read(cf));vt=json.loads(z.read(vf))
    must(len(pt['properties'])==np and len(st['sources'])==ns,l+' denominator');must(len(vt['families'])==10,l+' ten families')
    origp.update({qp(l,p['PROPERTY_ID']):p for p in pt['properties']});origs.update({qp(l,s['SOURCE_ID']):s for s in st['sources']});within.update({qp(l,r['RELATION_ID']):r for r in ct['relations']})
    counts={'properties':np,'sources':ns,'families':10,'relations':len(ct['relations']),'configurations':len(ct['alternative_configurations'])}
    if l=='EAA':
     counts.update(criticisms=len(pt['criticism_ledger']),tensions=len(pt['internal_tensions']),nodes=len(ct['nodes']),cases=len(ct['domain_case_tests']));must([counts[k] for k in ['relations','configurations','criticisms','tensions','nodes','cases']]==[62,6,13,10,12,14],'EAA auxiliary counts')
    elif l=='EMAS':
     g=vt['genealogy'];counts.update(criticisms=len(ct['criticism_ledger']),tensions=len(ct['internal_tensions']),genealogy_nodes=len(g['nodes']),genealogy_edges=len(g['edges']),evolution=len(vt['evolution_under_criticism']));must([counts[k] for k in ['relations','configurations','criticisms','tensions','genealogy_nodes','genealogy_edges','evolution']]==[61,6,24,10,25,25,17],'EMAS auxiliary counts')
    else:
     ce=json.loads(z.read(next(n for n in z.namelist() if n.endswith('CRITICAL_EVIDENCE.json'))));counts.update(criticisms=len(ce['criticisms']),tensions=len(ce['tensions']),cases=len(ce['cases']),induced=len(ct['composition_induced_property_ids']));must([counts[k] for k in ['relations','configurations','criticisms','tensions','cases','induced']]==[95,10,28,16,40,0],'EAOSE auxiliary counts')
    inputmeta[l]=dict(revision=rev,bytes=p.stat().st_size,sha256=h,counts=counts,integrity='PASS')
  return inputmeta
 check('R00','Original input hashes, exact payload inventories, revisions and all specified auxiliary populations',input_check)
 P=read('CONSTITUENT_PROPERTY_REGISTER')['property_by_key'];S=read('SOURCE_REGISTER')['source_by_key'];M=read('INTRA_CROSSWALK_MATRIX');R=read('DIRECTIONAL_RELATION_LEDGER');C=read('COUNTS');K=read('CONVERGENCE_AND_COMPOSITION_CLUSTERS');T=read('TENSION_LEDGER');E=read('COMPOSITION_INDUCED_PROPERTY_LEDGER');MD=read('COMPOSITION_MODEL');I=read('INTER_CROSSWALK_INTAKE');A=read('ALTERNATIVE_CONFIGURATIONS');X=read('ANALYTICAL_COUNTEREXAMPLES');SS=read('SHARED_SOURCE_IDENTITY_LEDGER');SP=read('SEMANTIC_PROFILES_AND_RULES');Q=read('COMPOSITION_QUESTION_ADJUDICATION');CE=read('CLAIM_EVIDENCE_LEDGER')
 if tamper=='remove_property':P.pop(next(iter(P)))
 elif tamper=='orphan_relation':R['relations'][0]['target_property']='EAOSE:EAOSE-C999'
 elif tamper=='conflate_permission_capability':MD['distinctions'].remove(['permission','capability'])
 elif tamper=='invent_emergence':E['composition_induced_properties'].append({'id':'AMA-E001','name':'Unaudited extra row'})
 elif tamper=='false_independence':SS['identities'][0]['independent_empirical_study_count']=2
 elif tamper=='duplicate_pair':M['pairs'][-1]=dict(M['pairs'][0])
 KEYS={l:sorted(k for k in origp if k.startswith(l+':')) for l in ORDER}
 PS=set(P);RS={r['relation_id']:r for r in R['relations']};KS={k['cluster_id']:k for k in K['clusters']};TS={t['id']:t for t in T['tensions']};NS={n['id']:n for n in E['rejected_candidates']};XS={x['id']:x for x in X['counterexamples']};SSS={g['id']:g for g in SS['identities']};FPS={f['id']:f for f in SP['profiles']};FAM={f['id']:f for f in SS['related_work_edition_programme_families']}
 expectedpairs={p for l,r in itertools.combinations(ORDER,2) for p in itertools.product(KEYS[l],KEYS[r])}
 observedpairs=[(p['left_property'],p['right_property']) for p in M['pairs']]
 perprop=collections.defaultdict(set)
 for r in R['relations']:
  perprop[r['source_property']].add(r['relation_id']);perprop[r['target_property']].add(r['relation_id'])
 def props():
  must(PS==set(origp) and len(P)==278,'property identity/population mismatch');must(C['properties']=={'EAA':70,'EMAS':76,'EAOSE':132},'per-lineage counts');return {'rows':len(P),'orphan_rows':len(PS^set(origp))}
 check('R01','All 278 inherited property rows and original denominators',props)
 def identities():
  for k,p in P.items():
   must(p['qualified_property_key']==k and p['constituent_id']==origp[k]['PROPERTY_ID'],'changed identity '+k);must(p['frozen_record']==origp[k],'changed raw frozen row '+k)
   must(p['name']==origp[k]['PROPERTY_NAME'] and p['disposition']==origp[k]['CURRENT_STATUS'] and p['examination_status']==origp[k]['EXAMINATION_STATUS'],'changed inherited field '+k)
   must(p['criterion']==origp[k][p['criterion_field']] and p['mechanism']==origp[k]['MECHANISM'],'criterion/mechanism changed '+k)
   fields={'trigger':'TRIGGER_OR_CONTEXT','non_trigger_or_cheap_path':'NON_TRIGGER_OR_CHEAP_PATH','authority':'ACTOR_AND_AUTHORITY_BOUNDARY','communication':'COMMUNICATION_OR_INTERACTION_REQUIREMENT','assumptions':'ASSUMPTION_SENSITIVITY','costs_and_failure_modes':'KNOWN_FAILURE_MODES','criticism':'IMPORTANT_CRITICISMS','output_or_postcondition':'OBSERVABLE_POSTCONDITION','unresolved_questions':'OPEN_QUESTIONS'}
   for normal,raw in fields.items():must(p[normal]==origp[k][raw],'normalised semantic drift '+k+' '+normal)
   must(p['evidence_ceiling']['frozen_partitions']==origp[k]['EVIDENCE_STRENGTH_PARTITIONS'],'evidence drift '+k)
   must(p['omission_or_retirement_condition']==origp[k][p['omission_field']],'omission drift '+k)
   if 'BEARER' in origp[k]:must(p['bearer']==origp[k]['BEARER'],'canonical bearer drift '+k)
  return 'Every raw property record equals the independently reopened canonical source row.'
 check('R02','No inherited identity, raw semantics, disposition or examination status changed',identities)
 check('R03','All 24,592 unique Cartesian cross-lineage pairs',lambda:(must(len(observedpairs)==24592 and len(set(observedpairs))==24592 and set(observedpairs)==expectedpairs,'pair universe'),dict(total=24592,universes={l+'_'+r:len(KEYS[l])*len(KEYS[r]) for l,r in itertools.combinations(ORDER,2)}))[1])
 def relations():
  must(len(RS)==len(R['relations'])==C['directional_relation_records'],'unique relation IDs/count');observed=collections.Counter()
  for p in M['pairs']:
   status=p['relation_status'];must(status in ['MATERIAL_RELATION','NO_MATERIAL_RELATION','UNRESOLVED_RELATION'],'unknown status');must(p['unresolved_flag']==(status=='UNRESOLVED_RELATION'),'unresolved flag');ids=p['directional_relation_ids'];must(len(ids)==len(set(ids)),'duplicate relation in pair')
   must(bool(ids)==(status=='MATERIAL_RELATION'),'material/ref agreement')
   for rid in ids:
    must(rid in RS,'orphan relation');r=RS[rid];must({r['source_property'],r['target_property']}=={p['left_property'],p['right_property']},'wrong pair endpoints '+rid);observed[rid]+=1
  must(set(observed)==set(RS) and all(n==1 for n in observed.values()),'unattached or multiply attached relation')
  for r in R['relations']:must(r['source_property'] in PS and r['target_property'] in PS and r['source_property'].split(':')[0]!=r['target_property'].split(':')[0],'bad relation endpoint')
  for k,p in P.items():must(set(p['ama_relation_ids'])==perprop[k],'reverse property relation index '+k)
  return {'relations':len(RS),'orphan_relations':0,'all_pair_and_property_reverse_indices_exact':True}
 check('R04','All directional references resolve in both pair and property indices',relations)
 def clusters():
  must(len(KS)==32,'cluster count');must(set(k for f in FPS.values() for k in f['member_keys'])==PS,'profile property coverage')
  for cid,k in KS.items():
   fs=[f for f in FPS.values() if f['cluster']==cid];expected={p for f in fs for p in f['member_keys']};must(set(k['member_properties'])==expected,'cluster reconstruction '+cid)
   must(set(k['relation_ids'])=={r['relation_id'] for r in R['relations'] if cid in r['cluster_ids']},'cluster relation reconstruction '+cid);must(not k['owner_derived_here'] and not k['ama_e_ids'],'owner or property invention')
  for key,p in P.items():must(set(p['cluster_ids'])=={k for k,v in KS.items() if key in v['member_properties']},'property cluster reverse '+key)
  must(len(K['one_to_many_composition_bundles'])==16,'bundle count')
  for b in K['one_to_many_composition_bundles']:must(set(b['participating_property_keys']+b['originating_criterion_keys'])<=PS and set(b['relation_ids'])<=set(RS) and not b['property_identity_created'],'bundle references')
  return {'clusters':32,'profiles':54,'one_to_many_bundles':16}
 check('R05','All convergence clusters, profiles and one-to-many bundles reconstruct',clusters)
 def tensions():
  must(len(TS)==24,'tension count')
  for tid,t in TS.items():
   must(set(t['property_keys'])==set(t['side_a_properties']+t['side_b_properties'])<=PS,'tension parents');must(t['scope_a'] and t['scope_b'] and t['failure_if_a_universalised'] and t['failure_if_b_universalised'] and t['bounded_synthesis'] and t['unresolved_remainder'],'missing two-sided tension content')
   must(set(t['relation_ids'])=={r['relation_id'] for r in R['relations'] if tid in r['tension_ids']},'tension reverse references')
  for k,p in P.items():must(set(p['tension_ids'])=={tid for tid,t in TS.items() if k in t['property_keys']},'property/tension reverse')
  return {'tensions':24,'hard_boundaries_not_forced_tradeoff':True}
 check('R06','Tensions and two-sided scopes, failures and bounded syntheses resolve',tensions)
 check('R07','Surviving AMA-E population and parent references',lambda:(must(E['composition_induced_properties']==[] and E['surviving_property_count']==0,'unexpected AMA-E population'),'Zero surviving AMA-E rows; no parent-reference assertion is fabricated.')[1])
 def ablation():
  must(len(NS)==20,'candidate count')
  for n in NS.values():
   ps=set(n['parent_properties']);must(ps<=PS and set(n['inherited_subsumers'])<=PS and set(n['parent_relation_ids'])<=set(RS),'candidate references')
   must({t['removed_parent'] for t in n['per_parent_removal_tests']}==ps,'parent removal coverage')
   must({t['removed_lineage'] for t in n['per_lineage_removal_tests']}=={p.split(':')[0] for p in ps},'lineage removal coverage')
   must(set(n['subsumption_tests_by_lineage'])==set(ORDER),'three subsumption tests');must(n['admitted_ama_e_id'] is None,'rejected candidate has admitted ID')
   for t in n['per_parent_removal_tests']:must(set(t['remaining_parent_keys'])==ps-{t['removed_parent']} and not t['surviving_new_property'],'parent ablation accounting')
   for t in n['per_lineage_removal_tests']:must(set(t['remaining_parents'])=={p for p in ps if not p.startswith(t['removed_lineage']+':')},'lineage ablation accounting')
  return '20 rejected hypotheses retain complete removal/subsumption accounting; survivor distinctness/minimality is not applicable, not a vacuous claim of 20 successful novelties.'
 check('R08','Candidate ablation and distinctness/minimality accounting',ablation,'Structural coverage plus documented analytical adjudication; no independent proof of every rejected natural-language hypothesis.')
 check('R09','No AMA-E renaming of an inherited property',lambda:(must(not E['composition_induced_properties'] and all(n['distinctness_adjudication'] and n['inherited_subsumers'] and n['decision'] in ['RELATION_ONLY_OR_INHERITED_SUBSUMPTION','REJECTED_UNSUPPORTED_ASSURANCE_STRENGTHENING'] for n in NS.values()),'novelty admission'),'Zero admitted identities; subsumption and unsupported-strengthening decisions are retained.')[1])
 def negative():
  sts={'NO_GENERAL_PROPERTY','REJECTED_OR_DISFAVOURED','SUPERSEDED_BY_STRONGER_FORM','UNRESOLVED','CEREMONY_NOT_GENERAL_PROPERTY','DUPLICATE_CANDIDATE','CONTESTED'};neg={k:v['CURRENT_STATUS'] for k,v in origp.items() if v['CURRENT_STATUS'] in sts}
  must(len(neg)==52 and all(k in P and P[k]['disposition']==v for k,v in neg.items()),'negative rows lost or relabelled');must(read('CONSTITUENT_PROPERTY_REGISTER')['negative_contested_unresolved_and_ancestral_retention']==neg,'negative reverse index');return {'retained_negative_contested_unresolved_duplicate_superseded_rows':52}
 check('R10','Negative, ceremonial, duplicate, superseded, contested and unresolved rows retained',negative)
 def sources():
  must(set(S)==set(origs) and len(S)==234,'source denominator');
  for k,s in S.items():must(s['frozen_source_record']==origs[k] and s['qualified_source_key']==k,'raw source altered '+k)
  for k,p in P.items():
   raw=origp[k];ss=set(raw.get('CANONICAL_SOURCE_IDS',[]))
   for field in ['PRIMARY_SOURCE_IDS','CRITICAL_SOURCE_IDS','EMPIRICAL_OR_CASE_SOURCE_IDS']:ss.update(raw.get(field,[]))
   must(set(p['source_ids'])=={qp(p['lineage'],s) for s in ss}<=set(S),'exact property-source binding '+k)
   for role,field in [('primary','PRIMARY_SOURCE_IDS'),('critical','CRITICAL_SOURCE_IDS'),('empirical_or_case','EMPIRICAL_OR_CASE_SOURCE_IDS')]:must(p['source_roles'][role]==[qp(p['lineage'],s) for s in raw.get(field,[])],'source role changed '+k)
  return {'EAA':54,'EMAS':56,'EAOSE':124,'total':234}
 check('R11','All 234 source rows exactly traceable to original frozen tables',sources)
 def independence():
  members=[s for g in SSS.values() for s in g['member_source_keys']];must(len(SSS)==214 and len(members)==len(set(members))==234 and set(members)==set(S),'identity population')
  must(sum(len(g['member_source_keys'])>1 for g in SSS.values())==20,'shared exact groups')
  for gid,g in SSS.items():
   must(g['independent_empirical_study_count'] is None and g['different_access_and_evidence_roles_preserved'],'false independence')
   for s in g['member_source_keys']:must(S[s]['shared_identity_id']==gid,'identity reverse')
  for f in FAM.values():must(set(f['member_source_keys'])<=set(S),'family sources')
  for sk,source in S.items():must(set(source['family_ids'])=={fid for fid,f in FAM.items() if sk in f['member_source_keys']},'source/family reverse')
  for k,p in P.items():
   must(set(p['shared_source_identity_ids'])=={S[s]['shared_identity_id'] for s in p['source_ids']},'property identity annotation '+k)
   must(set(p['source_family_ids'])=={f for s in p['source_ids'] for f in S[s]['family_ids']},'property family annotation '+k)
  return {'local_rows':234,'work_or_collection_edition_units':214,'exact_shared_groups':20,'related_families':10,'independent_study_count':None}
 check('R12','Shared source identity does not create false independent corroboration',independence)
 check('R13','Canonical AOSE population only; archival 66 roster excluded',lambda:(must(len(KEYS['EAOSE'])==132 and all(k.startswith('EAOSE:EAOSE-C') for k in KEYS['EAOSE']),'noncanonical row in denominator'),{'canonical_rows':132,'ancestry_added':0})[1])
 def scope():
  must(set(inputmeta)==set(ORDER),'outside input');must(all(k.split(':')[0] in ORDER for k in P) and all(k.split(':')[0] in ORDER for k in S),'outside property/source namespace');must(SS['fresh_external_access']==[],'unexpected external access')
  must({p.name for p in (root/'constituents').iterdir()}=={'EAA.zip','EMAS.zip','EAOSE.zip'},'outside constituent archive')
  return 'Only supplied EAA/EMAS/canonical EAOSE authorities and task-owned analytical output; scope statements prohibit target/adoption/ownership inference.'
 check('R14','No outside-trifecta corpus, property, source or target-adoption conclusion introduced',scope,'Verifies supplied corpus/namespace inventory and declared scope; not a claim to inspect unavailable external systems.')
 def intake():
  rows=I['rows'];ks=[r['global_qualified_key'] for r in rows];must(len(ks)==len(set(ks))==278 and set(ks)==PS,'intake identity/population');must(I['total_population']==I['inherited_population']+I['composition_induced_population']==278,'intake equation')
  required=['global_qualified_key','origin','name','disposition','examination_status','bearer','criterion','mechanism','trigger','non_trigger','dependencies','assumptions','authority','delegation','communication','capability','output_and_evidence','evidence_ceiling','costs_and_failure_modes','criticism','omission_or_retirement','source_ids','relation_ids','cluster_ids','tension_ids','composition_induced','later_inter_crosswalk_questions']
  for row in rows:
   p=P[row['global_qualified_key']];must(all(k in row for k in required),'missing intake field');must(row['disposition']==p['disposition'] and row['criterion']==p['criterion'] and row['mechanism']==p['mechanism'] and set(row['relation_ids'])==set(p['ama_relation_ids']),'intake drift')
   must(not row['composition_induced'] and not row['ama_composition_induced'],'inherited row became AMA-E')
  return {'inherited':278,'AMA_induced':0,'later_total':278,'favourable_only_filter':False}
 check('R15','Lossless later intake equals 278 plus actual AMA-E population',intake)
 def direction():
  voc=R['vocabulary']
  for r in R['relations']:
   must(r['relation_type'] in voc,'undefined relation type');rev=r['reverse_relation_id']
   if voc[r['relation_type']]['symmetric']:
    must(rev in RS,'missing symmetric reverse');rr=RS[rev];must(rr['source_property']==r['target_property'] and rr['target_property']==r['source_property'] and rr['relation_type']==r['relation_type'] and rr['reverse_relation_id']==r['relation_id'],'incorrect reverse')
   else:must(rev is None,'asymmetric relation incorrectly same-type mirrored')
  return {'all_oriented_records':len(RS),'symmetric_records_have_exact_reverse':True,'asymmetric_types_not_blindly_mirrored':True}
 check('R16','Symmetric and asymmetric directional records correct',direction)
 def arity():
  counter=collections.Counter()
  for n in NS.values():
   ls=[l for l in ORDER if any(p.startswith(l+':') for p in n['parent_properties'])];expected=('THREE_WAY_' if len(ls)==3 else 'PAIRWISE_')+'_'.join(ls);must(n['hypothesised_class']==expected,'hypothesis arity');counter[len(ls)]+=1
  must(counter=={3:16,2:4} and C['pairwise_induced_properties']==C['three_way_induced_properties']==0,'arity totals');return {'rejected_pairwise':4,'rejected_three_way':16,'surviving_pairwise':0,'surviving_three_way':0}
 check('R17','Pairwise/three-way arity distinguished from higher-order failure',arity)
 def model():
  nodes={n['id']:n for n in MD['nodes']};must(len(nodes)==38 and len(MD['edges'])==63,'model sizes')
  for n in nodes.values():must(set(n['inherited_property_keys'])<=PS,'node parents')
  for e in MD['edges']:
   ps=set(e['inherited_property_keys']);must(e['source_node'] in nodes and e['target_node'] in nodes and ps<=PS and set(e['relation_ids'])<=set(RS) and set(e['tension_ids'])<=set(TS),'edge references')
   for rid in e['relation_ids']:must(RS[rid]['source_property'] in ps and RS[rid]['target_property'] in ps,'edge relation mismatch')
  must(set(MD['non_serial_semantics'])=={'feedback','concurrency','interrupts','handoffs','invalidation','branch_points','termination'},'nonserial coverage');return {'nodes':38,'edges':63,'feedback_interrupt_concurrency_handoff_invalidation_branches_retirement':True}
 check('R18','Composition model agrees with relation/tension ledgers and remains non-serial',model)
 def report_counts():
  text=(root/(F+'FROZEN_REPORT.md')).read_text();expected={'MATERIAL_RELATIONS':C['pair_statuses']['MATERIAL_RELATION'],'NO_MATERIAL_RELATIONS':C['pair_statuses']['NO_MATERIAL_RELATION'],'UNRESOLVED_RELATIONS':0,'DIRECTIONAL_RELATION_RECORDS_TOTAL':len(RS),'CONVERGENCE_CLUSTERS':len(KS),'TENSIONS':len(TS),'ALTERNATIVE_CONFIGURATIONS':15,'ANALYTICAL_COUNTEREXAMPLES':24,'AMA_COMPOSITION_INDUCED_PROPERTIES':0,'REJECTED_EMERGENT_CANDIDATES':20,'LATER_INTER_CROSSWALK_PROPERTY_POPULATION':278}
  for k,v in expected.items():must(f'{k}: {v}\n' in text,'report count mismatch '+k)
  must(collections.Counter(p['relation_status'] for p in M['pairs'])=={k:v for k,v in C['pair_statuses'].items() if v},'status totals');return expected
 check('R19','Report counts equal independently reconstructed machine counts',report_counts)
 def distinction(pair,case=None):
  must(pair in MD['distinctions'],'missing typed distinction '+str(pair))
  if case:must(case in XS and XS[case]['local_satisfaction_warning'] and not XS[case]['new_ama_property_warranted'],'missing scoped counterexample')
  return {'distinct_concepts':pair,'counterexample':case,'test_type':'Typed non-equivalence plus exact unchanged constituent criteria and declared failure witness, not automated natural-language proof.'}
 check('R20','Intention is not public obligation',lambda:distinction(['intention','public_commitment'],'AMA-X002'))
 check('R21','Public obligation is not delegated authority',lambda:distinction(['public_commitment','delegated_authority'],'AMA-X001'))
 check('R22','Delegated authority is not operation permission',lambda:distinction(['delegated_authority','permission'],'AMA-X004'))
 check('R23','Permission is not actual capability',lambda:distinction(['permission','capability'],'AMA-X003'))
 check('R24','Capability/issuance are not executed action',lambda:(distinction(['capability','issued_action'],'AMA-X003'),distinction(['issued_action','execution'],'AMA-X006')))
 check('R25','Execution is not established external effect',lambda:distinction(['execution','external_effect'],'AMA-X001'))
 check('R26','Observed effect is not automatically accepted outcome',lambda:distinction(['external_effect','accepted_outcome'],'AMA-X024'))
 tests={}
 def finite_models():
  saved=read('ANALYTICAL_TEST_RESULTS');triples=list(itertools.product([0,1],repeat=3));fun=[lambda t:t[0]==t[1],lambda t:t[0]==t[2],lambda t:t[1]!=t[2]];solutions={}
  for n in [1,2,3]:
   for subset in itertools.combinations(range(3),n):solutions[str(subset)]=[list(t) for t in triples if all(fun[i](t) for i in subset)]
  must(solutions==saved['BINARY_TRIANGLE_EMPTY_JOIN']['all_subset_solutions'],'triangle result drift');must(not solutions['(0, 1, 2)'] and all(len(v)>0 for k,v in solutions.items() if k!='(0, 1, 2)'),'triangle logical test');tests['BINARY_TRIANGLE_EMPTY_JOIN']='PASS'
  edges={tuple(e) for e in saved['LEGAL_PATH_NOT_EVENTUAL_EXECUTION']['legal_edges']};must(('waiting','done') in edges and ('waiting','waiting') in edges,'liveness graph');tests['LEGAL_PATH_NOT_EVENTUAL_EXECUTION']='PASS'
  z=saved['REDUNDANT_COMMUNICATION_COST'];facts={'p'};many={x for _ in range(10) for x in facts};must(many==facts and (10-1)*z['per_message_cost']==z['extra_cost']==9 and z['decision_information_gain']==0,'communication calculation');tests['REDUNDANT_COMMUNICATION_COST']='PASS'
  z=saved['COMMON_RESOURCE_LOCAL_GAIN'];must(z['regeneration']-z['agents']*z['old_per_agent_extraction']==z['old_stock_delta']==1 and z['regeneration']-z['agents']*z['new_per_agent_extraction']==z['new_stock_delta']==-1,'resource calculation');tests['COMMON_RESOURCE_LOCAL_GAIN']='PASS'
  z=saved['DISJOINT_VALIDITY_WINDOWS'];ints=[z[k] for k in ['authority_interval','role_interval','goal_interval']];must(max(i[0] for i in ints)>=min(i[1] for i in ints) and all(x<y for x,y in ints),'interval intersection');tests['DISJOINT_VALIDITY_WINDOWS']='PASS'
  z=saved['CONTROL_COST_SUM'];must(sum(z['local_costs'])==z['total']==12 and z['total']-z['global_envelope']==z['overrun']==2,'cost sum');tests['CONTROL_COST_SUM']='PASS'
  return tests
 check('R27','Protocol legality is not eventual execution; all six finite models independently re-executed',finite_models,'Executable analytical witnesses, not empirical validation or a liveness theorem for arbitrary deployed systems.')
 check('R28','Local cooperation is not global adequacy',lambda:(distinction(['local_cooperation','global_adequacy'],'AMA-X005'),must('AMA-X012' in XS and tests.get('BINARY_TRIANGLE_EMPTY_JOIN')=='PASS','three-way witness'),{'global_failure_cases':['AMA-X005','AMA-X012','AMA-X015']})[-1])
 def ceilings():
  must(not MD['whole_configuration_family_empirically_validated'],'whole-family validation upgrade')
  for r in R['relations']:must(r['evidence_comparison']['no_independence_or_strength_upgrade'] and r['evidence_boundary'] and r['assumptions'],'relation ceiling absent')
  for q in CE['claims']:must(q['analytical'] and not q['whole_ama_empirically_validated'] and q['formal_assumptions'] and q['access_limits'],'claim ceiling upgrade')
  return 'All formal/environment/population/access ceilings preserved via exact frozen rows, relation references and analytical claim records. No proof/source rereading is implied.'
 check('R29','Formal guarantees and contemporary evidence stay assumption-bounded',ceilings)
 def unresolved():
  ks=['EAA:EAA-062','EMAS:EMAS-013','EAOSE:EAOSE-C119','EAOSE:EAOSE-C120'];ct=['EAA:EAA-042','EAOSE:EAOSE-C028','EAOSE:EAOSE-C037']
  must(all(P[k]['disposition']=='UNRESOLVED' for k in ks),'unresolved claim upgraded');must(all(P[k]['disposition']=='CONTESTED' for k in ct),'contested claim upgraded');return {'unresolved':ks,'contested':ct}
 check('R30','Unresolved self-revision/FIPA/whole-method and contested claims remain',unresolved)
 def configcheck():
  cfgs=A['configurations'];must(len(cfgs)==15 and len({c['id'] for c in cfgs})==15,'config population')
  for c in cfgs:
   must(not c['configuration_is_universal'] and set(c['required_mechanism_properties']+c['conditional_mechanism_properties'])<=PS,'invalid universal/config parents')
   for f in ['trigger','assumptions','authority_model','communication_model','evidence_requirements','failure_conditions','transition_and_reconfiguration_rules','omission_and_retirement_path']:must(c[f],'missing config field '+f)
  must('Conventional' in cfgs[0]['name'] and cfgs[0]['omitted_mechanisms'],'conventional branch missing');return {'configurations':15,'conventional_and_nonagent_branches':True,'universal_mode':False}
 check('R31','Conventional/non-agent configurations and legitimate omission remain',configcheck)
 check('R32','More communication/agent count is not treated as inherent improvement',lambda:(must(tests.get('REDUNDANT_COMMUNICATION_COST')=='PASS' and tests.get('CONTROL_COST_SUM')=='PASS','cost tests'),must(P['EMAS:EMAS-006']['disposition']=='REJECTED_OR_DISFAVOURED' and P['EMAS:EMAS-064']['disposition']=='REJECTED_OR_DISFAVOURED','negative count/communication claims lost'),'Counterexamples and negative propositions retained; no monotonic improvement guarantee.')[2])
 def classification():
  profile={k:set() for k in P}
  for f in FPS.values():
   for k in f['member_keys']:profile[k].add(f['id'])
  bridges={ordered_pair(b['source'],b['target']) for b in SP['hand_adjudicated_directional_bridges']}
  for p in M['pairs']:
   x,y=p['left_property'],p['right_property'];fs=profile[x]&profile[y];ss=set(P[x]['shared_source_identity_ids'])&set(P[y]['shared_source_identity_ids']);ff=set(P[x]['source_family_ids'])&set(P[y]['source_family_ids']);bb=(x,y) in bridges
   must(set(p['semantic_profile_intersection'])==fs and set(p['shared_source_identity_ids'])==ss and set(p['source_family_ids'])==ff,'pair evidence mismatch')
   material=bool(fs or ss or ff or bb);must((p['relation_status']=='MATERIAL_RELATION')==material,'classification mismatch')
  return {'pairs_independently_reclassified':24592,'profiles':len(FPS),'specific_bridge_judgements':len(SP['hand_adjudicated_directional_bridges']),'algorithm_not_title_similarity':True}
 check('R33','Every pair status independently reconstructed from disclosed semantic/source rules',classification,'Re-executes the classification rule for every pair; validates completeness and reproducibility, not independent scholarly correctness of all profile memberships.')
 def aliases():
  alias_count=0
  for r in R['relations']:
   def walk(v):
    nonlocal alias_count
    if isinstance(v,dict):
     for x in v.values():walk(x)
    elif isinstance(v,list):
     for x in v:walk(x)
    elif isinstance(v,str) and v.startswith(('@source.','@target.')):
     side,field=v[1:].split('.',1);must(field in P[r[side+'_property']],'alias unresolved '+v);alias_count+=1
   walk(r)
   must(set(r['cluster_ids'])<=set(KS) and set(r['tension_ids'])<=set(TS) and set(r['rejected_candidate_ids'])<=set(NS),'relation metadata reference')
   x,y=r['source_property'],r['target_property'];must(set(r['cluster_ids'])==set(P[x]['cluster_ids'])&set(P[y]['cluster_ids']),'relation cluster endpoint mismatch')
   must(set(r['tension_ids'])==set(P[x]['tension_ids'])&set(P[y]['tension_ids']),'relation tension endpoint mismatch')
  declared=set()
  for b in SP['hand_adjudicated_directional_bridges']:
   for rid in b['relation_ids']:
    rr=RS[rid];must(rr['relation_type']==b['type'] and rr['semantic_basis']==b['semantic_basis'] and {rr['source_property'],rr['target_property']}=={b['source'],b['target']},'specific bridge content mismatch')
    must(rr['trigger_and_scope_comparison']['joint_guard']==b['guard'],'specific bridge guard mismatch');declared.add(rid)
  must(declared=={r['relation_id'] for r in R['relations'] if r['derivation_origin']=='MANUALLY_ADJUDICATED_DIRECTIONAL_BRIDGE'},'bridge-record coverage')
  return {'endpoint_relative_field_aliases_resolved':alias_count}
 check('R34','All compact comparison aliases and relation metadata references resolve',aliases)
 def question_cases():
  must({q['question'] for q in Q['questions']}=={f'Q{i}' for i in range(1,17)},'Q coverage');must(len(XS)==24 and len(CE['claims'])==16,'case/claim counts')
  for q in Q['questions']:must(set(q['supporting_property_keys'])<=PS and set(q['relation_ids'])<=set(RS) and set(q['counterexample_ids'])<=set(XS) and q['rejected_candidate_id'] in NS,'Q refs')
  for x in XS.values():must(set(x['all_property_keys'])<=PS and set(x['relation_ids'])<=set(RS) and not x['empirical_validation'] and not x['new_ama_property_warranted'] and x['local_satisfaction_warning'],'case scope/references')
  for claim in CE['claims']:must(set(claim['supporting_inherited_properties'])<=PS and set(claim['source_ancestry'])<=set(S) and set(claim['shared_source_identity_ids'])<=set(SSS),'claim refs')
  return {'mandatory_questions':16,'counterexamples':24,'principal_claim_evidence_records':16}
 check('R35','All question, case and claim/evidence references and scope statements',question_cases)
 def origin_flags():
  expected={*[f'EAA:EAA-{i:03d}' for i in [67,68,69]],*[f'EMAS:EMAS-{i:03d}' for i in [71,72,73,74]]};observed={k for k,p in P.items() if p['constituent_composition_induced']};must(observed==expected,'constituent induced provenance');must(all(not p['ama_composition_induced'] for p in P.values()),'inherited AMA flag');return {'EAA_inherited_induced':3,'EMAS_inherited_induced':4,'canonical_EAOSE_induced':0,'new_AMA_induced':0,'legacy_raw_labels_not_overwritten':True}
 check('R36','Within-tradition induced provenance distinct from AMA-level novelty',origin_flags)
 def context():
  cx=read('CONSTITUENT_CONTEXT_INDEX')['within_lineage_relation_by_key'];must(set(cx)==set(within) and len(cx)==218,'within-lineage relation population')
  for k,v in cx.items():must(v['frozen_relation']==within[k],'changed within relation')
  for p in P.values():must(set(p['within_lineage_relation_ids'])<=set(cx),'unresolved inherited relation')
  return {'EAA_relations':62,'EMAS_relations':61,'EAOSE_relations':95,'total':218}
 check('R37','Original within-lineage relations and context remain resolvable',context)
 def inventory():
  req=[x for x in REQUIRED if phase=='frozen' or x not in LATE];missing=[x for x in req if not (root/(F+x)).is_file()];must(not missing,'missing '+str(missing))
  parsed=[]
  for p in root.rglob('*.json'):json.loads(p.read_text());parsed.append(str(p.relative_to(root)))
  return {'required_output_files':17,'required_in_this_phase':len(req),'all_visible_json_parsed':len(parsed)}
 check('R38','Required payload inventory and every output JSON parse',inventory)
 def docs():
  pub=(root/(F+'PUBLIC_DOCUMENTATION_INTAKE.md')).read_text();report=(root/(F+'FROZEN_REPORT.md')).read_text();must('zero new AMA-E' in pub and 'Conventional/non-agent' in pub and 'not' in pub,'public boundary');must('No fresh external research was used' in report and 'not an independently authored scholarly peer review' in report,'scope/review boundary');must('24,592' in report and 'not' in report,'review accounting');return 'Public documentation distinguishes established fields, analytical composition, no universal superiority, alternatives and no adoption.'
 check('R39','Public-documentation and report evidence/scope boundaries',docs)
 def manifest():
  if phase!='frozen':return 'DEFERRED_TO_FROZEN_PHASE; no archive custody is asserted by this prefreeze run.'
  man=read('FROZEN_MANIFEST');actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()};must(actual==set(man['exact_members']),'manifest exact members');must(man['revision']=='AMA-2026-09-07-r1','manifest revision')
  payloads=man['payload_inventory'];must({p['filename'] for p in payloads}==actual-{F+'FROZEN_MANIFEST.json'},'manifest excludes only itself')
  for x in payloads:
   p=root/x['filename'];must(p.stat().st_size==x['bytes'] and sha(p)==x['sha256'],'payload hash '+x['filename'])
  must(man['counts']==C,'manifest counts');return {'exact_members':len(actual),'hashed_payloads':len(payloads),'self_hash_policy':'Manifest excluded only from its own payload inventory.'}
 check('R40','Final exact-member manifest, payload bytes/hashes and revision',manifest,'Manifest checks are inapplicable before freeze; final enclosing ZIP integrity is separately verified after handles close.')
 failed=[c for c in checks if c['status']!='PASS']
 return dict(schema_version='1.0.0',revision='AMA-2026-09-07-r1',review_phase=phase,review_state='PASS' if not failed else 'FAIL',reviewer='Fresh read-only standard-library process, independent of the generator execution; same synthesis effort, not independent scholarly peer review.',tamper_test=tamper,corpus_mutated=False,check_count=len(checks),passed_checks=len(checks)-len(failed),failed_checks=failed,checks=checks,counts=C,analytical_tests=tests,input_verification=inputmeta,limitations=['A complete and reproducible classifier is not independent scholarly validation of every authored semantic profile or bridge.','Natural-language non-conflation checks enforce typed distinctions, exact frozen records and explicit counterexample boundaries; they are not a theorem prover for every sentence.','Custody and internal consistency do not establish whole-family empirical benefit or general self-revision assurance.','The source publications were not newly reaccessed; original access claims remain frozen and qualified.'])

def main():
 ap=argparse.ArgumentParser();ap.add_argument('root',type=Path);ap.add_argument('--phase',choices=['prefreeze','frozen'],default='frozen');ap.add_argument('--tamper',choices=['remove_property','orphan_relation','conflate_permission_capability','invent_emergence','false_independence','duplicate_pair']);args=ap.parse_args()
 try:result=run(args.root.resolve(),args.phase,args.tamper)
 except Exception as e:
  result={'review_state':'FAIL','fatal_error':f'{type(e).__name__}: {e}','corpus_mutated':False,'tamper_test':args.tamper}
 print(json.dumps(result,ensure_ascii=False,indent=2));return 0 if result['review_state']=='PASS' else 1
if __name__=='__main__':sys.exit(main())
