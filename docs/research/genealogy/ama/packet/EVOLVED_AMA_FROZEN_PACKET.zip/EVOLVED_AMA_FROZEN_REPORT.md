# Evolved-AMA — frozen intra-trifecta synthesis

**Revision:** `AMA-2026-09-07-r1`  
**Scope:** Evolved Autonomous Agents (EAA), Evolved Multi-Agent Systems (EMAS), and canonical Evolved Agent-Oriented Software Engineering (EAOSE), and only those frozen constituent corpora.  
**Research cut-off:** inherited from the three packets, no later than 7 September 2026.  
**Execution:** independent fourth-stage synthesis; separate fresh-process read-only consistency review. This is not independent scholarly or empirical validation of the constituent studies or of the composed family.

## 1. Finding

**Evolved-AMA is a guarded composition of distinct agency, interaction and engineering criteria, not a prescription for more autonomy or more agents.** Its central result is that an individual decision, an inter-party interaction and an engineering acceptance claim must be related at the actual point where one is used to justify another. The relation must preserve the relevant subject, principal, action, configuration, time, obligation and evidence. A valid description at one level does not automatically discharge the criterion at the next.

The inherited population is **278 properties**, without deletion or renumbering. The novelty search examined **20 candidate hypotheses**, including the sixteen mandatory three-way junctions and four pairwise extensions. **No distinct AMA-E property survives.** The proposed conditions are either already inherited, express an existing guarded relation bundle, or attempt an assurance strengthening unsupported by the frozen evidence. The later property-by-property intake therefore contains **278 + 0 = 278 rows**.

This is not a union-only result. AMA adds the explicit cross-lineage relation matrix, directional constraints and evidence dependencies, 32 convergence clusters, 16 one-to-many realisation bundles, 24 tensions, 24 analytical counterexamples, 15 guarded configurations, and a typed feedback/interrupt/reconfiguration model. These products specify what must be connected, which apparently attractive inferences fail, and when additional machinery should instead be omitted. New applications, derivations and failure witnesses are not silently promoted into new property identities.

EAA’s three internal composition-induced rows and EMAS’s four remain inherited rows with their original provenance. Canonical EAOSE’s final reconciliation admits zero distinct within-tradition induced properties. Its larger engineering scope does not subordinate the other lineages: an engineering criterion cannot substitute for the actual individual capability or public interaction evidence needed to establish it. Likewise, subsuming a proposed new AMA criterion does not erase the independently borne EAA or EMAS criteria that help realise it.

**Authority basis:** the exact frozen property records, source records and within-lineage relations included in `constituents/`; their qualified keys are resolvable through the property register, source register and constituent context index. The citation form `EAA:EAA-023` identifies a frozen property, not a new AMA property. `AMA-R…`, `AMA-K…`, `AMA-T…`, `AMA-N…` and `AMA-X…` identify analytical relations, clusters, tensions, rejected novelty hypotheses and constructed tests respectively.

## 2. Input custody and denominators

All three enclosing SHA-256 values match the controlling prompt. Each archive was closed/reopened, CRC-tested, checked against its internal revision and exact member inventory, and every manifest-listed payload byte count and SHA-256 was independently recalculated. Original archives are included unmodified. These checks establish identity and delivery integrity; they do not repeat every original publication reading or prove the scholarship of the inputs.

| Lineage | Internal revision | ZIP bytes | Properties | Source rows |
|---|---|---:|---:|---:|
| EAA | `EAA-2026-09-06-r1` | 412,040 | 70 | 54 |
| EMAS | `EMAS-R1` | 370,502 | 76 | 56 |
| EAOSE | `EAOSE-CANONICAL-R1-2026-09-07` | 3,728,163 | 132 | 124 |

**Exact enclosing hashes**

**EAA:** `009b37693541d387a2d65c281815731a05423b31fae298a9c6c99ad069e87769`  
**EMAS:** `84af391ed2c82514f0e22ff671a0945945dec608ffccfde485e2302374bab227`  
**EAOSE:** `17cf10e5bedfe8a52d0a85c81c318294a0d80e5ca8ad8f868e12b7a116b34b9a`  

The auxiliary populations were checked from content as well: EAA has 10 domain families, 12 nodes, 62 within-lineage relations, 6 configurations, 14 cases, 13 criticisms and 10 tensions; EMAS has 10 families, 25 genealogy nodes, 25 genealogy edges, 24 criticisms, 17 evolution transitions, 10 tensions, 61 relations and 6 configurations; canonical EAOSE has 10 families, 28 criticisms, 16 tensions, 40 cases, 95 relations and 10 configurations. The evidence-limited property counts are respectively 15, 14 and 71. Source records retain their original access and claim-scoped limits.

The unrecovered historical AOSE 66-row roster is an archival ancestry limitation, **not** an additional population. Nor are the 196 A/B reconciliation mappings or nested ancestor packets added to the canonical 132. Some canonical records retain an older `PROPERTY_KIND` containing “composition-induced”; the canonical origin/reconciliation remains controlling. The register preserves the literal legacy field while separately recording that canonical EAOSE contributes zero admitted induced identities. This prevents an inherited annotation from resurrecting a rejected novelty claim.

The exact denominators are not a claim that every row is an instruction to enact. Rejected universal propositions, ceremonial candidates, duplicates, superseded forms, contested claims and unresolved questions are part of what must survive comparison.

## 3. Complete pair universe and relation semantics

| Pair universe | Material | No material relation | Unresolved relation | Total |
|---|---:|---:|---:|---:|
| EAA × EMAS | 1,945 | 3,375 | 0 | 5,320 |
| EAA × EAOSE | 3,520 | 5,720 | 0 | 9,240 |
| EMAS × EAOSE | 3,713 | 6,319 | 0 | 10,032 |
| **Total** | **9,178** | **15,414** | **0** | **24,592** |

Every pair is stored explicitly. Pair classification combines **54 hand-authored multifactor semantic profiles**, **105 specific directional bridge judgements**, and frozen property-to-source bindings reconciled through shared identities/families. The profiles were authored from criteria, mechanisms, bearers, guards, authority boundaries, failure modes and evidence, not title similarity. The full Cartesian product was then exhaustively evaluated against those declared rules. This is reproducible pair-by-pair accounting; it is **not** a claim that 24,592 separate hand-written scholarly essays were produced.

There are 8,497 pairs with guarded semantic-profile convergence. There are 1,510 pairs with source-ancestry relationships, overlapping the semantic population; 678 material pairs have source ancestry alone. Two material pairs have only a specifically adjudicated bridge; other bridge pairs may overlap either population. The categories are not additive without taking their overlap into account.

The **20,152 directional records** include **16,994 oriented convergence-membership records**, **3,020 oriented source-ancestry records**, and **138 oriented records realising the 105 specific bridges**. Symmetric relations are deliberately exported in both directions with mutually checked reverse IDs. These numbers are not counts of independent causal findings, empirical confirmations or new obligations. The vocabulary distinguishes constraints, preconditions, scope, implementation correspondence, observation, handoff, analogy and intentional asymmetry from convergence.

`NO_MATERIAL_RELATION` means no direct guarded semantic/bridge/evidence relationship was identified under this explicitly recorded comparison scope. It does not prove the pair can never interact in a future configuration. Every no-material cell remains explicit and reconstructible. `UNRESOLVED_RELATION` concerns an indeterminate *relation classification*, not whether a constituent proposition is unresolved. No such indeterminate relation classification remains, while the unresolved FIPA, self-revision and whole-method propositions remain fully preserved.

Every material record compares the two bearers, authority/delegation, communication, trigger/non-trigger, assumptions, criticism, postcondition and evidence ceiling. Compact `@source.FIELD` and `@target.FIELD` aliases resolve through the endpoints to the exact property register. The underlying frozen row is always preserved. A reinforcement relation attached to a rejected candidate reinforces its adjudicated rejection or bounded mature form, not the rejected title’s universal proposition.

## 4. What the composition requires—and what it does not

### 4.1 Distinct states and judgements

The following are distinct, not interchangeable stages that always form one serial pipeline:

`intention ≠ public obligation ≠ delegated authority ≠ permission ≠ capability ≠ issued action ≠ executed action ≠ observed effect ≠ accepted outcome`.

An agent may intend something it owes nobody; owe something it cannot currently perform; possess technical capability without permission; issue an authorised attempt that fails; cause an effect that does not meet the stakeholder criterion; or observe the needed evidence without being the actor authorised and capable of accepting it. Correct role models, legal messages and consistent internal mental-state transitions do not remove these distinctions. [EAA:EAA-004, EAA:EAA-010, EAA:EAA-022, EAA:EAA-023; EMAS:EMAS-004, EMAS:EMAS-012, EMAS:EMAS-016, EMAS:EMAS-025, EMAS:EMAS-071; EAOSE:EAOSE-C002, EAOSE:EAOSE-C006, EAOSE:EAOSE-C007, EAOSE:EAOSE-C098, EAOSE:EAOSE-C106.]

For a **particular consequential dispatch**, the applicable authority, permission, capability, material prerequisites and obligations must refer to a compatible decision context. This does not require one universal central database, a consensus round before every action, or proof of all future effects. An authorised bounded experiment can proceed on warranted predictions and appropriately accepted risk. The separate **acceptance judgement** needs evidence suitable for the actual claim; an already-produced effect is not a universal precondition for making an attempt. A sufficient atomic interface or existing direct contract can discharge the relevant checks without an extra ceremony. [EAA:EAA-009, EAA:EAA-022, EAA:EAA-067; EMAS:EMAS-071, EMAS:EMAS-073; EAOSE:EAOSE-C068, EAOSE:EAOSE-C086, EAOSE:EAOSE-C098; canonical relation bundle EAOSE-RB01.]

### 4.2 Three distinct kinds of continuity

**Intention continuity** is about justified persistence or reconsideration of local work. **Public obligation continuity** is about which principals remain responsible to whom, under which activation and discharge conditions. **Evidence continuity** is about whether the assumptions supporting a claim remain valid after change. These can move differently: dropping a local goal does not release a promise; changing role holders does not erase it; repairing a plan can preserve its name but change its beneficiary; a version change can preserve the interface yet invalidate prior assurance. [EAA:EAA-013, EAA:EAA-015, EAA:EAA-055, EAA:EAA-069; EMAS:EMAS-026, EMAS:EMAS-040, EMAS:EMAS-072, EMAS:EMAS-074; EAOSE:EAOSE-C051, EAOSE:EAOSE-C103, EAOSE:EAOSE-C104, EAOSE:EAOSE-C105.]

The bounded response is selective: preserve, validly transfer, release, compensate, or explicitly report inability concerning a live obligation; reopen materially affected evidence; leave unrelated valid work alone. This is not automatic permission for a global rewrite or a universal full restart. If the dependency has disappeared, omission and retirement remain legitimate.

### 4.3 Coordination must have a consequential purpose

A team is not made adequate by agent count, message count, local cooperation or agreement alone. Coordination is warranted by actual information, resource, timing, incentive or obligation dependencies. Some dependencies can be removed rather than managed. A central or direct solution is legitimate when it has the same required information and powers; a comparison that secretly gives it unavailable rights is not fair. Conversely, a distributed design does not earn its cost merely by being decentralised. [EAA:EAA-020, EAA:EAA-047, EAA:EAA-048, EAA:EAA-057; EMAS:EMAS-001, EMAS:EMAS-005, EMAS:EMAS-006, EMAS:EMAS-019, EMAS:EMAS-028, EMAS:EMAS-064, EMAS:EMAS-065, EMAS:EMAS-073; EAOSE:EAOSE-C068, EAOSE:EAOSE-C116, EAOSE:EAOSE-C117.]

### 4.4 A feedback system, not a phase ladder

The composition model contains **38 typed nodes and 63 guarded edges**. Observations can update local state; effects feed evidence and diagnosis; repair changes means; adaptation invalidates dependent assumptions; reconfiguration changes responsibility bindings; human or governance interruption can prevent dispatch; retirement can remove obsolete machinery. Multiple agents, intentions and engineering activities can run concurrently under their relevant dependencies. Conventional implementations, individual agents, public-commitment systems and human-agent hybrids activate different subsets. No universal sequence “AOSE model → agent → MAS → optimisation” is adopted.

A model node names a concern or bearer, not a required module. A model edge backed only by within-lineage criteria is not falsely presented as a new cross-lineage theorem. Cross-level edges point to the actual relation ledger; their tension and assumption records remain part of the model’s meaning.

## 5. Answers to the sixteen mandatory composition questions

Each answer has a fuller machine-readable record, parent relations, candidate ablations, case references and source ancestry in `EVOLVED_AMA_COMPOSITION_QUESTION_ADJUDICATION.json`, `EVOLVED_AMA_COMPOSITION_INDUCED_PROPERTY_LEDGER.json` and `EVOLVED_AMA_CLAIM_EVIDENCE_LEDGER.json`.

### Q1. Consequential goal–authority–obligation–effect join

**Joint question/criterion.** Do not justify one consequential dispatch or acceptance by unrelated goal, scope, commitment, capability or effect records; the material bindings and claim-specific evidence must be compatible.

**Composition.** Local current action basis meets public interaction/obligation semantics and engineering acceptance. The composition exposes the join obligations and the distinction between permission to attempt and evidence to accept.

**Adjudication.** EAA-067 already excludes splicing individually valid facts into a nonexistent action basis; EMAS-071 already separates evidence, obligation, intervention and consequence. Canonical EAOSE-RB01 expressly applies C086/C002/C007/C058/C098/C067 to one subject/action/configuration/time/acceptance context. Renaming that existing bundle at AMA level creates no residual criterion.

**Guard and cheaper path.** Consequential cross-level action or acceptance with multiple sources of state, scope or effect. A single adequate atomic permission/action/result contract may establish the relevant relation without an extra join procedure.

**Trace:** EAA:EAA-010, EAA:EAA-022, EAA:EAA-067, EMAS:EMAS-025, EMAS:EMAS-071, EAOSE:EAOSE-C002, EAOSE:EAOSE-C007, EAOSE:EAOSE-C086, EAOSE:EAOSE-C098. Counterexamples: AMA-X001, AMA-X020, AMA-X024. Novelty record: `AMA-N001`. No AMA-E identity admitted.

### Q2. Cross-level intention and obligation continuity

**Joint question/criterion.** A private change of intention must not silently discharge, orphan or transfer a public obligation or persisting organisational responsibility.

**Composition.** Distinguish the local intention lifecycle from the public commitment lifecycle and the valid organisational transition between responsible principals.

**Adjudication.** C105 explicitly requires retaining, validly transferring, releasing, compensating or reporting inability for outstanding public obligations at reassignment; C051 already asks what happened to dependent obligations when intention changes. MAS persistence/alignment supplies the social mechanics. This is a new cross-level application, not a new property.

**Guard and cheaper path.** Intention withdrawal, loss of local relevance or changing role holder affects relied-on work. No public transition machinery is needed for a purely private goal with no dependent responsibility.

**Trace:** EAA:EAA-013, EAA:EAA-015, EMAS:EMAS-023, EMAS:EMAS-025, EMAS:EMAS-026, EMAS:EMAS-027, EAOSE:EAOSE-C051, EAOSE:EAOSE-C105. Counterexamples: AMA-X002, AMA-X009. Novelty record: `AMA-N002`. No AMA-E identity admitted.

### Q3. Delegation realised by an authorised capable executor

**Joint question/criterion.** A legitimate request, selected worker and role assignment must not be accepted as fulfilment unless the actual actor has the required capability and current permission, and performance is separately evidenced.

**Composition.** Join authority for delegation with task-allocation selection and the individual action interface; distinguish acceptance of an award from execution.

**Adjudication.** C007 is already the exact practical-ability/current-permission point-of-use criterion. EMAS-004/015/016 and EAA-004/021 distinguish its components. Adding the phrase delegation realisation is not a distinct bearer/criterion beyond those inherited requirements.

**Guard and cheaper path.** A task is awarded, delegated, rebound or dispatched under material capability/permission uncertainty. Direct constrained assignment and a sufficient operation contract can avoid negotiation and duplicate checking.

**Trace:** EAA:EAA-004, EAA:EAA-021, EAA:EAA-022, EMAS:EMAS-004, EMAS:EMAS-015, EMAS:EMAS-016, EMAS:EMAS-039, EAOSE:EAOSE-C006, EAOSE:EAOSE-C007, EAOSE:EAOSE-C098. Counterexamples: AMA-X003, AMA-X004. Novelty record: `AMA-N003`. No AMA-E identity admitted.

### Q4. Global sufficiency beyond local agency success

**Joint question/criterion.** Assess the required collective external outcome and joint feasibility separately from individual goal correctness, cooperation or local improvements.

**Composition.** Combine local conflict/evaluation mechanisms with joint resource/progress and engineering acceptance evidence; apply the selected system-level criterion to the composed behaviour.

**Adjudication.** EMAS-069 explicitly evaluates the final collective consequence and C085 explicitly preserves separate individual and collective assurance claims. C028 remains contested, not repaired by agreement. The proposed global criterion is already inherited.

**Guard and cheaper path.** A collective-success claim is inferred from local plans, scores, completed subtasks or cooperation. Use the smallest sufficient collective outcome test; neither full decentralised modelling nor a universal central planner is required.

**Trace:** EAA:EAA-012, EAA:EAA-034, EAA:EAA-045, EMAS:EMAS-020, EMAS:EMAS-056, EMAS:EMAS-061, EMAS:EMAS-069, EAOSE:EAOSE-C002, EAOSE:EAOSE-C085, EAOSE:EAOSE-C086. Counterexamples: AMA-X005, AMA-X015. Novelty record: `AMA-N004`. No AMA-E identity admitted.

### Q5. Public compliance without forced private-state inspection

**Joint question/criterion.** Keep justified private-state architecture distinct from the public compliance judgement; do not require an open observer to establish inaccessible sincerity.

**Composition.** Operationalise the individual mental-state model, then select public or justified private communication semantics according to the actual observation and cooperation assumptions.

**Adjudication.** EMAS-008 already supplies the opaque-participant public-effect criterion; EMAS-009 and C037 retain a guarded private-state branch. C036 rejects the unsupported universal public-compliance inference. This junction yields an intentional asymmetry, not a new invariant or universal commitment mandate.

**Guard and cheaper path.** The compliance observer and internal reasoning implementation have different access/trust boundaries. Use ordinary interfaces or public effects only where needed; internal BDI and closed justified mental-state semantics remain alternatives.

**Trace:** EAA:EAA-003, EAA:EAA-018, EMAS:EMAS-008, EMAS:EMAS-009, EMAS:EMAS-025, EAOSE:EAOSE-C036, EAOSE:EAOSE-C037. Counterexamples: AMA-X013. Novelty record: `AMA-N005`. No AMA-E identity admitted.

### Q6. Protocol possibility to actual fulfilment closure

**Joint question/criterion.** Do not infer eventual real-world fulfilment or accepted effect from a legal protocol-completion path, message acceptance or local interpreter conformance.

**Composition.** Place protocol semantics beside execution, scheduling/willingness assumptions, effect evidence and final acceptance, retaining each distinct claim.

**Adjudication.** The requested separation is explicit in EAA-023, EMAS-012/061/069 and C098; C023 already makes collective progress assumption-sensitive. The counterexample defeats an inference, not an uncovered property.

**Guard and cheaper path.** Protocol liveness or communication success is cited as external eventual completion. A sufficient atomic result may establish an effect; do not require additional acknowledgement layers where they add no consequential information.

**Trace:** EAA:EAA-023, EAA:EAA-036, EMAS:EMAS-011, EMAS:EMAS-012, EMAS:EMAS-061, EMAS:EMAS-069, EAOSE:EAOSE-C023, EAOSE:EAOSE-C098. Counterexamples: AMA-X006, AMA-X022. Novelty record: `AMA-N006`. No AMA-E identity admitted.

### Q7. Epistemic reachability of acceptance evidence

**Joint question/criterion.** Evidence needed by a consequential acceptance or intervention must be available in usable form to an authorised actor capable of making that decision in time, or the claim remains open.

**Composition.** Distinguish local observation adequacy and distributed provenance from the information, authority and practical ability of the actual consequential consumer.

**Adjudication.** C106 states the proposed criterion directly, including reachability, authority, capability, usability and legitimate omission. Calling it epistemic reachability changes terminology, not its property identity. Information privacy may make the condition infeasible; that is an exposed configuration failure, not an assurance theorem.

**Guard and cheaper path.** An acceptance or intervention depends on evidence held elsewhere, at training time only, or behind a disclosure boundary. One existing sufficient permitted evidence interface is enough; omit an unneeded handoff.

**Trace:** EAA:EAA-005, EAA:EAA-008, EMAS:EMAS-004, EMAS:EMAS-048, EMAS:EMAS-051, EMAS:EMAS-071, EAOSE:EAOSE-C106. Counterexamples: AMA-X007, AMA-X016. Novelty record: `AMA-N007`. No AMA-E identity admitted.

### Q8. Cross-level failure-attributed repair

**Joint question/criterion.** Diagnose a failure at the trace-supported individual, interaction, organisational, requirement, implementation or observation level before selecting an authorised repair.

**Composition.** Expand the individual failure hypothesis space using collective threat and progress information, then route the refutable diagnosis to the responsible engineering or execution consumer.

**Adjudication.** C101 already localises multi-agent failure across specification, alignment and verification/execution; EAA-068 already requires discriminating observations rather than undirected change. The crosswalk gives these criteria mutual scope and evidence routes, not a missing diagnostic property.

**Guard and cheaper path.** An adverse outcome is attributed to an individual agent or a system mechanism without discriminating trace evidence. Use a small decisive test; leave causes underdetermined rather than demand a complete causal model.

**Trace:** EAA:EAA-068, EMAS:EMAS-027, EMAS:EMAS-058, EMAS:EMAS-069, EAOSE:EAOSE-C067, EAOSE:EAOSE-C100, EAOSE:EAOSE-C101. Counterexamples: AMA-X005, AMA-X007, AMA-X019. Novelty record: `AMA-N008`. No AMA-E identity admitted.

### Q9. Cross-level task and assurance preserving repair

**Joint question/criterion.** A local repair may not be accepted as an adequate collective revision while invalidating material dependencies, live obligations or relied-on assurance without valid change and revalidation.

**Composition.** Task/scope preservation constrains means substitution, MAS adaptation checks partner/resource effects, and engineering revalidation/transition criteria settle affected claims and responsibilities.

**Adjudication.** EMAS-074 already requires dependency-coupled adaptation, while C103 and C105 already cover premise-sensitive assurance and obligation continuity. The useful one-to-many realisation is the relation bundle among inherited criteria; no additional invariant excludes a residual counterexample.

**Guard and cheaper path.** A local plan replacement affects shared resources, partner expectations, roles, effects or prior evidence. Keep the repair local when those dependencies truly do not change; revalidate only affected support.

**Trace:** EAA:EAA-024, EAA:EAA-069, EMAS:EMAS-059, EMAS:EMAS-074, EAOSE:EAOSE-C103, EAOSE:EAOSE-C105, EAOSE:EAOSE-C109. Counterexamples: AMA-X008, AMA-X024. Novelty record: `AMA-N009`. No AMA-E identity admitted.

### Q10. Cross-lineage regime handoff

**Joint question/criterion.** A regime transition must not carry an invalidated guarantee or orphaned obligation into a destination merely because that destination is structurally valid.

**Composition.** Use coherent local state, explicit changed-regime assumptions, compatible admission and valid live-work disposition before relying on the successor configuration.

**Adjudication.** EMAS-072 already names regime-change guards, guarantee invalidation and explicit handoff; C105 already rejects loss of predecessor obligations. EAA contributes concrete internal state/capability changes but not a residual new criterion.

**Guard and cheaper path.** Membership, protocol version, information, incentives, capabilities or fault assumptions change during live work. A compatible no-op transition can use existing evidence and direct binding; no universal handoff ceremony is implied.

**Trace:** EAA:EAA-038, EAA:EAA-055, EAA:EAA-067, EMAS:EMAS-040, EMAS:EMAS-063, EMAS:EMAS-072, EAOSE:EAOSE-C024, EAOSE:EAOSE-C103, EAOSE:EAOSE-C105. Counterexamples: AMA-X009, AMA-X020. Novelty record: `AMA-N010`. No AMA-E identity admitted.

### Q11. Smallest adequate agency/coordination architecture

**Joint question/criterion.** Choose a sufficiently capable, legitimate and cost-justified configuration, retaining conventional and smaller branches and removing machinery whose function disappears.

**Composition.** Compare local architectural complexity, actual interdependence and engineering method/runtime suitability against the same protected outcomes and disclosed costs.

**Adjudication.** EAA-020 is already named and defined as the smallest adequate architecture; EMAS-073 and C012/C068 already supply coordination and method selection/retirement. A cross-level configuration frontier is useful new composition metadata, not a new global-optimum theorem or property.

**Guard and cheaper path.** Architecture selection, growth of agency/coordination or retirement of now-unneeded mechanisms. An ordinary function, workflow, single agent or direct scheduler remains valid when it meets the same requirement.

**Trace:** EAA:EAA-020, EAA:EAA-057, EMAS:EMAS-001, EMAS:EMAS-019, EMAS:EMAS-073, EAOSE:EAOSE-C012, EAOSE:EAOSE-C013, EAOSE:EAOSE-C017, EAOSE:EAOSE-C068. Counterexamples: AMA-X023, AMA-X021. Novelty record: `AMA-N011`. No AMA-E identity admitted.

### Q12. Effective mixed human-agent decision authority

**Joint question/criterion.** A human approval, refusal, override, escalation or delegation must have the intended actual authority and feasible effect, with non-response and irreversible consequences distinguished.

**Composition.** Relate individual transfer/readiness mechanisms to mixed-population roles and the engineering intervention boundary; assess the specific decision rather than nominal human presence.

**Adjudication.** C110 and EMAS-068 already demand meaningful operational participation; EAA-038/039/040 explicitly cover transfer, readiness and revocation. The composition exposes timing/authority interactions but adds no uncovered human-approval criterion or assurance benefit.

**Guard and cheaper path.** A person is intended to approve, stop, resume, refuse or take over consequential work. Omit unhelpful approvals within adequate delegated scope; a tested direct stop/permission interface may suffice.

**Trace:** EAA:EAA-037, EAA:EAA-038, EAA:EAA-039, EAA:EAA-040, EMAS:EMAS-068, EAOSE:EAOSE-C006, EAOSE:EAOSE-C110. Counterexamples: AMA-X014, AMA-X022. Novelty record: `AMA-N012`. No AMA-E identity admitted.

### Q13. General self-revision assurance from three-level change controls

**Joint question/criterion.** Alleged strengthening: coupled reflection, collective adaptation and engineering method revision guarantee preserved justified objectives/authority and continual improvement across open-ended future changes.

**Composition.** The proposed derivation would need valid objective persistence, delegated scope, dependent-obligation preservation, evidence continuity and actual future consequence evaluation. Local conditional controls do not discharge the missing general premises.

**Adjudication.** Rejected as an unsupported strengthening, not declared mathematically impossible. EAA-062 is explicitly unresolved; EAA-070 concerns ideal rationality, accurate anticipation and predecessor utility within its formal model. The existing controls can constrain a bounded revision, but no frozen evidence establishes the alleged open-ended assurance.

**Guard and cheaper path.** A bounded mechanism result is promoted to general autonomous self-revision or automatic improvement. Retain explicit authorised change proposals and bounded evaluation against protected criteria; do not require autonomous self-modification.

**Trace:** EAA:EAA-054, EAA:EAA-062, EAA:EAA-070, EMAS:EMAS-074, EAOSE:EAOSE-C072, EAOSE:EAOSE-C103, EAOSE:EAOSE-C104, EAOSE:EAOSE-C113, EAOSE:EAOSE-C114. Counterexamples: AMA-X010, AMA-X015. Novelty record: `AMA-N013`. No AMA-E identity admitted.

### Q14. Generative multi-agent operational closure

**Joint question/criterion.** Generated roles, plans, protocols or lessons must have bounded operational interpretation, authority, provenance, responsiveness and claim-appropriate repeated evaluation before stronger effects are credited.

**Composition.** Combine observation-responsive tool use, actual collective mechanisms and engineering realisation/authority/temporal constraints; keep generated proposals distinct from enacted obligations and effects.

**Adjudication.** The candidate is a useful configuration and failure-path bundle, not one residual property. Its separate clauses are directly inherited: prompt-versus-role enforcement, tool authority, repeated/versioned evaluation, plan constraints and responsive waiting. Cross-lineage agreement does not upgrade preprints, benchmarks or implementations into whole-system evidence.

**Guard and cheaper path.** A generative component participates in local action, public interaction or engineering change. Use fixed plan libraries, ordinary services or one bounded agent when a generative collective adds no justified value.

**Trace:** EAA:EAA-052, EAA:EAA-053, EAA:EAA-054, EAA:EAA-055, EMAS:EMAS-048, EMAS:EMAS-066, EMAS:EMAS-067, EAOSE:EAOSE-C123, EAOSE:EAOSE-C124, EAOSE:EAOSE-C125, EAOSE:EAOSE-C128, EAOSE:EAOSE-C129, EAOSE:EAOSE-C130. Counterexamples: AMA-X016, AMA-X017, AMA-X018, AMA-X019. Novelty record: `AMA-N014`. No AMA-E identity admitted.

### Q15. Global compatibility beyond pairwise consistency

**Joint question/criterion.** Do not infer a globally compatible configuration or acceptance warrant solely from separately satisfiable pairwise projections.

**Composition.** Construct a finite triangle with x=y, x=z and y≠z: every proper constraint subset has a witness, but the full join is empty. Test the resulting global claim against already inherited compatible-support and actual feasibility criteria.

**Adjudication.** The example proves a higher-order failure possibility, not novelty. C086 already requires a composed configuration to supply compatible support; C079 already rejects compatibility-to-achievability. The full C061/EMAS-020 criteria do not pass globally just because their pairwise projections pass. No independent property remains.

**Guard and cheaper path.** A system guarantee is inferred from separate pairwise checks with independently chosen witnesses. Directly check the small actual joint condition; do not add global machinery where one adequate contract already establishes it.

**Trace:** EAA:EAA-067, EMAS:EMAS-020, EMAS:EMAS-043, EAOSE:EAOSE-C061, EAOSE:EAOSE-C079, EAOSE:EAOSE-C086. Counterexamples: AMA-X012, AMA-X020. Novelty record: `AMA-N015`. No AMA-E identity admitted.

### Q16. Composed control-cost and retirement envelope

**Joint question/criterion.** Individually useful reasoning, coordination and assurance must still fit the actual whole-task/lifecycle cost and obligation envelope; excess machinery may be simplified or retired.

**Composition.** Bring local reasoning cost, collective communication/integration burden and engineering lifecycle effort into the same declared comparison without assuming one universal additive scalar.

**Adjudication.** Whole-task and lifecycle accounting already include displaced burdens, and minimum adequate coordination/method retirement already permit simplification while preserving obligations. The 4+4+4>10 example exposes an omitted global budget, not a new criterion beyond those inherited.

**Guard and cheaper path.** Added agents, coordination or assurance consume a shared resource or displace costs to other phases/actors. Keep incomparable burdens visible and choose a cheaper adequate branch; do not minimise mechanism count at the expense of required outcomes.

**Trace:** EAA:EAA-026, EAA:EAA-048, EMAS:EMAS-006, EMAS:EMAS-028, EMAS:EMAS-065, EMAS:EMAS-073, EAOSE:EAOSE-C009, EAOSE:EAOSE-C057, EAOSE:EAOSE-C068, EAOSE:EAOSE-C117. Counterexamples: AMA-X011, AMA-X021, AMA-X023. Novelty record: `AMA-N016`. No AMA-E identity admitted.

## 6. Pairwise consistency with a genuine three-way failure

Let `x` be an individual-agent configuration choice, `y` an interaction binding and `z` an engineering realisation choice, each in `{0,1}`. They are deliberately abstract labels, not measured quantities. Define:

```text
R_AM(x,y) = (x = y)
R_AO(x,z) = (x = z)
R_MO(y,z) = (y ≠ z)
```

Every relation is nonempty. Each one-variable projection is `{0,1}`. Any two constraints admit two global triples:

| Constraints enforced | Compatible `(x,y,z)` assignments |
|---|---|
| `R_AM` and `R_AO` | `000`, `111` |
| `R_AM` and `R_MO` | `001`, `110` |
| `R_AO` and `R_MO` | `010`, `101` |
| All three | none |

The full natural join is empty: `x=y` and `x=z` imply `y=z`, contradicting the third relation. Removing any one lineage’s incident relations restores a satisfiable remaining pair. The fresh verifier enumerates all eight triples and every nonempty constraint subset; it does not merely trust a saved “pass” label.

This supplies **a genuine three-way failure witness**, not a genuinely new three-way property. A checker that separately approves each pair and concludes that the whole configuration is achievable is unsound. But canonical cross-view consistency, compatible compositional support and rejection of fragment-compatibility-as-goal-achievability already reject that inference. The counterexample does not claim that those stronger global inherited criteria were satisfied. [AMA-X012; AMA-N015; EAA:EAA-067; EMAS:EMAS-020, EMAS:EMAS-043; EAOSE:EAOSE-C061, EAOSE:EAOSE-C079, EAOSE:EAOSE-C086.]

Other executable tests distinguish a legal route to completion from eventual execution, redundant message volume from information gain, individual harvesting gains from collective sustainability, separately valid records from a common validity interval, and individually affordable controls from an affordable total. These are finite analytical constructions, not empirical estimates about deployed agents.

## 7. Counterexample coverage

The 24 records state exactly which narrow local checks pass, which composite conclusion fails, and which stronger inherited criterion already rejects it. They never assert that all 278 properties hold while the same full inherited criterion is violated. This distinction is essential to the novelty adjudication.

| Case | Constructed failure or invalid inference | Questions |
|---|---|---|
| `AMA-X001` | Executable local plan and legal interaction, but unauthorised consequential action | Q1, Q3 |
| `AMA-X002` | Local intention retired while public promise remains live | Q2 |
| `AMA-X003` | Legitimate assignment awarded to a materially incapable performer | Q3 |
| `AMA-X004` | Capable executor has no permission | Q3 |
| `AMA-X005` | Every local contribution completes, yet collective acceptance fails | Q4 |
| `AMA-X006` | A protocol always permits completion but participants never execute it | Q6 |
| `AMA-X007` | Correct evidence never reaches a consumer who can act | Q7 |
| `AMA-X008` | Task-preserving local repair consumes a resource promised to another team | Q9 |
| `AMA-X009` | Well-formed successor organisation loses a predecessor obligation | Q10 |
| `AMA-X010` | Reflection improves a proxy by changing the protected objective | Q13, Q14 |
| `AMA-X011` | More correct messages provide no new consequential information | Q16 |
| `AMA-X012` | Pairwise satisfiable views with an empty three-way join | Q15 |
| `AMA-X013` | Implemented private BDI states do not establish open public sincerity | Q5 |
| `AMA-X014` | Approval request arrives after the action can no longer be stopped | Q12 |
| `AMA-X015` | Individually improving harvest policies exhaust a shared stock | Q4, Q13 |
| `AMA-X016` | Training-time global information is unavailable to the deployed decision maker | Q7, Q14 |
| `AMA-X017` | Replicated approximate computation is called exact global optimisation | Q14 |
| `AMA-X018` | A pending plan generator blocks unrelated reactive duties | Q14 |
| `AMA-X019` | Several personas agree because they copied one unverified memory | Q14 |
| `AMA-X020` | All pairwise receipts are valid, but at incompatible epochs | Q1, Q15 |
| `AMA-X021` | Individually justified control costs exceed the total envelope | Q16 |
| `AMA-X022` | Safe local deferral leaves a deadline-dependent obligation unhandled | Q12, Q6 |
| `AMA-X023` | A conventional implementation satisfies the need without runtime agents | Q11 |
| `AMA-X024` | Nominally identical repair changes the beneficiary and discharges the wrong promise | Q1, Q9 |

The conventional-implementation case is a counterexample to a mandatory-agents inference, not a claim that the conventional branch is defective. Local willingness/fairness, privacy, field transfer and authority assumptions remain explicit in the other cases.

## 8. Tensions are retained, not averaged away

The ledger records why both sides can be locally justified, how each fails when universalised, its bounded synthesis, and what remains unresolved. Hard semantic or authority constraints are not treated as a tunable mean. The following table summarises the actual bounded results; the full two-sided failure analysis remains in each tension record.

| Tension | Bounded synthesis |
|---|---|
| `AMA-T001` — Autonomy versus legitimate authority | Keep hard authority limits and allow conditional means selection inside them; refusal, deferral and existing constrained interfaces are legitimate. No average autonomy score substitutes for permission. |
| `AMA-T002` — Local goal optimisation versus public and organisational obligations | Reconsider the local pursuit, then retain, transfer, release, compensate or report the dependent obligation through its valid transition semantics. |
| `AMA-T003` — Private intentional architecture versus publicly inspectable compliance | Separate the internal reasoning architecture from the external compliance criterion; disclose exactly where private-state assumptions are warranted. |
| `AMA-T004` — Decentralised control versus coordinated feasibility | Choose direct, central, distributed or dependency-eliminating mechanisms against the actual control boundary and joint constraints. |
| `AMA-T005` — Communication richness versus consequential cost | Keep mandatory obligation notifications and sufficient semantic bindings; optimise discretionary communication by its consequential value. |
| `AMA-T006` — Fast local response versus organisation-wide consistency | Check only material dependencies and use justified atomicity, stable contracts or bounded uncertainty; retain a feasible fallback rather than a universal synchronisation barrier. |
| `AMA-T007` — Intention persistence versus reconsideration cost and relevance | Use guarded event/deadline/value-based reconsideration; distinguish goal failure from plan failure and preserve dependent obligations. |
| `AMA-T008` — Flexible repair versus protocol and binding conformance | Permit substitutions within actual equivalence and authority; renegotiate or rebind explicitly when the social meaning changes. |
| `AMA-T009` — Adaptive improvement versus continuity of evidence | Trace affected premises, preserve independently valid evidence and reopen only the necessary acceptance/partner claims. |
| `AMA-T010` — Self-revision versus predecessor-governed acceptance | Identify the changed object, preserve or legitimately revise protected criteria under the predecessor decision boundary, and retain external consequence evidence. |
| `AMA-T011` — Role reassignment versus outstanding obligation preservation | Reconcile each affected live obligation into valid retention, transfer, release, compensation or explicit inability; neither structural validity nor message emission is enough. |
| `AMA-T012` — Specialisation versus substitution and replacement | Justify each specialisation by marginal contribution and test feasible substitutions with explicit capability, role and commitment compatibility. |
| `AMA-T013` — Agent count versus total coordination and assurance burden | Compare the smallest adequate configurations on matched or transparently unmatched budgets and complete relevant cost dimensions. |
| `AMA-T014` — Delegation versus verification and trust cost | Verify the material authority, capability and outcome boundaries, using adequate existing contracts and risk-limited trust rather than maximal surveillance. |
| `AMA-T015` — Cooperation assumptions versus strategic or adversarial behaviour | State the regime, test relevant deviations and hand off/revalidate when assumptions change; do not infer legitimacy from equilibrium. |
| `AMA-T016` — Human override versus useful agent independence | Make the specific approval/refusal/stop decision effective at the action boundary; define non-response and irreversible-effect handling without assuming human infallibility. |
| `AMA-T017` — Higher assurance versus open-ended generative behaviour | Use bounded symbolic/typed interfaces, actual authority checks and version-sensitive tests; expose the unsupported open-ended remainder. |
| `AMA-T018` — Legal protocol completion versus actual willingness and execution | Report possibility, assumed/established progress and accepted consequence separately; add the relevant liveness premises only when warranted. |
| `AMA-T019` — Implementation abstraction versus operating-environment validity | Validate only the mappings and environmental premises material to the claimed effect, preserving limits and alternative implementations. |
| `AMA-T020` — Resilience versus fault-model boundaries | Name the covered failures and exact preserved property; monitor material assumptions where possible and provide explicit degradation or suspension. |
| `AMA-T021` — Evidence reachability versus privacy and bounded disclosure | Use a sufficient permitted evidence interface, an entitled alternative consumer or an explicitly limited judgement; do not infer a fact from inability to inspect it. |
| `AMA-T022` — Cross-lineage convergence versus false independent corroboration | Retain all 234 local source records and exact access scopes while recording work/version and programme relationships; convergence improves interpretation, not automatic confidence. |
| `AMA-T023` — Risk-sensitive assurance versus control machinery cost | Tie each control to a material failure/consumer and assess cheaper substitutes; preserve the obligation while permitting machinery retirement. |
| `AMA-T024` — Useful lifecycle composition versus unsupported whole-method benefit | Retain conditional mechanism-level value, conventional exits and unresolved whole-method claims; do not turn this synthesis into a mandatory methodology mode. |

A public promise cannot manufacture a permission; an engineer cannot solve opaque-private-state access by merely drawing a sincerity check; and human approval after irreversible dispatch is not an effective override. These are non-entailments or infeasible configurations, not matters of finding the right average “balance.” Cooperation, formal proof and learning claims are also conditional on the actual participant, representation, scheduling, environment and fault regime.

## 9. Guarded alternative configurations

These fifteen configurations are overlapping alternatives, not a maturity ladder, a mandatory “AMA mode”, or fifteen architectures every implementation must instantiate. References to rejected properties constrain a choice; they do not require executing the rejected mechanism. Satisfaction/optimisation and argumentation/voting branches are explicitly one-of/conditional selections rather than accidental all-of mandates.

| Configuration | Trigger |
|---|---|
| `AMA-CFG001` — Conventional non-agent implementation | An ordinary function, service, workflow or controller meets the actual requirements and control distribution at lower or otherwise preferable justified cost. |
| `AMA-CFG002` — Agent-oriented analysis with conventional execution | Actor/goal/dependency analysis clarifies the requirements, while autonomous runtime agents do not earn their implementation cost. |
| `AMA-CFG003` — Single bounded reactive agent | Current observations are adequate for a timely bounded action without extensive hidden-state or long-horizon planning. |
| `AMA-CFG004` — Single deliberative or BDI plan-library agent | Persistent structured goals, reusable plans or non-local contingencies justify explicit deliberation and intention management. |
| `AMA-CFG005` — Reactive–deliberative or symbolic–learned hybrid | One task needs both timely reaction and slower planning or bounded learned capability. |
| `AMA-CFG006` — Direct cooperative multi-agent team | A small set of genuinely distinct capable participants has aligned goals and a manageable shared dependency. |
| `AMA-CFG007` — Public-commitment interaction among opaque principals | Independent participants need externally assessable conditional obligations without access to one another’s private mental state. |
| `AMA-CFG008` — Role- and organisation-based collective | Shared responsibilities, multiple role bindings or organisation-level constraints cannot be adequately captured by isolated local tasks. |
| `AMA-CFG009` — Adaptive or reconfigurable multi-agent organisation | Membership, capabilities, partner policies or organisational needs change in ways a static compatible arrangement cannot handle adequately. |
| `AMA-CFG010` — Mixed human–agent collaborative system | People have relevant knowledge, preference, legitimacy or decision rights that cannot be adequately delegated away. |
| `AMA-CFG011` — Higher-assurance bounded agent subset | Consequences and tractable assumptions justify formal checking, strong interfaces and targeted adversarial testing for a selected subset of behaviour. |
| `AMA-CFG012` — Bounded generative or LLM-agent configuration | Language-mediated variability or useful plan/tool generation earns its cost over fixed workflows, libraries and simpler agents in the declared task. |
| `AMA-CFG013` — Strategic allocation among independent participants | Distinct incentives, ownership or private information materially affect task allocation or cooperation. |
| `AMA-CFG014` — Distributed constraint or optimisation configuration | Distributed variable/resource ownership and explicit encoded joint constraints justify a selected DCSP/DCOP algorithm. |
| `AMA-CFG015` — Argumentation or collective-choice decision support | Participants must exchange reasons or aggregate preferences under a chosen public decision semantics rather than merely coordinate an already-agreed task. |

Each configuration record specifies required and conditional mechanisms, omitted mechanisms, assumptions, authority and communication models, evidence, failure conditions, transition/reconfiguration rules and an omission/retirement path. A configuration may omit BDI, public commitments, formal checking, LLM generation, a human approval loop, negotiation or an agent runtime when the selected task and rights do not justify them. A conventional branch is not automatically adequate either: hidden independent principals or unhandled commitments can invalidate it. [EAA:EAA-016–020; EMAS:EMAS-001, EMAS:EMAS-019, EMAS:EMAS-022, EMAS:EMAS-073; EAOSE:EAOSE-C012, EAOSE:EAOSE-C039, EAOSE:EAOSE-C068, EAOSE:EAOSE-C116, EAOSE:EAOSE-C117.]

## 10. Convergence, one-to-many realisation and no deletion

| Cluster | Concern | Inherited members |
|---|---|---:|
| `AMA-K001` | Boundaries and justified agency abstraction | 11 |
| `AMA-K002` | Operational mental-state and architecture semantics | 28 |
| `AMA-K003` | Authority, delegation, capability and dispatch | 41 |
| `AMA-K004` | Goals, intentions and lifecycle responsibility | 33 |
| `AMA-K005` | Observation, uncertainty and distributed knowledge | 25 |
| `AMA-K006` | Concurrency, temporal validity and coherent decision bases | 34 |
| `AMA-K007` | Communication meaning, identity and causal information | 32 |
| `AMA-K008` | Public commitments and obligation continuity | 35 |
| `AMA-K009` | Task allocation and dependency-directed coordination | 40 |
| `AMA-K010` | Teams, roles and organisations | 27 |
| `AMA-K011` | Strategic interaction and incentive limitations | 31 |
| `AMA-K012` | Local success versus global accepted consequences | 32 |
| `AMA-K013` | Norms, enforcement and external legitimacy | 36 |
| `AMA-K014` | Mixed human–agent authority and intervention | 38 |
| `AMA-K015` | Cross-level failure attribution | 27 |
| `AMA-K016` | Repair, uncertain effects and recovery | 40 |
| `AMA-K017` | Adaptation, regime change and revalidation | 44 |
| `AMA-K018` | Consequential evidence and acceptance consumers | 53 |
| `AMA-K019` | Assumption-bounded formal assurance | 53 |
| `AMA-K020` | Deployment, runtime monitoring and fallback | 54 |
| `AMA-K021` | Evaluation units, reproducibility and source independence | 30 |
| `AMA-K022` | Proportionate architecture, coordination and cost | 54 |
| `AMA-K023` | Learning, reward, partner change and transfer | 58 |
| `AMA-K024` | Memory, provenance and retention | 21 |
| `AMA-K025` | Bounded generative-agent compositions | 56 |
| `AMA-K026` | Privacy, security and untrusted communication | 38 |
| `AMA-K027` | Method assembly, lifecycle coverage and live consumers | 71 |
| `AMA-K028` | Reuse, historical identity and semantic translation | 30 |
| `AMA-K029` | Self-revision and predecessor-governed evaluation | 39 |
| `AMA-K030` | Resource-bounded reasoning and responsiveness | 39 |
| `AMA-K031` | Distributed decision procedures and their restricted conclusions | 45 |
| `AMA-K032` | Evidence ceilings and unresolved whole-system benefit | 50 |

Cluster membership records many-to-one convergence of a guarded concern. It does not claim every member is equivalent, that every pair in a broad cluster has the same direct mechanism, or that a common implementation owner has been derived. The 54 narrower semantic profiles carry the pair-level membership basis. A role, a public commitment and a local intention can share a continuity concern without becoming the same bearer.

The sixteen one-to-many bundles start from an inherited criterion and show one distributed realisation using individual, interaction and engineering contributions. Removing one contribution can break that *selected realisation*, but does not prove all three lineages are essential to a new property. A fused existing contract, a different organisation or a conventional mechanism may realise the criterion more cheaply. Each bundle includes its guard, missing-component failure witness and cheaper path. These are relation/configuration results; none creates an AMA-E identity.

## 11. Novelty search and distinctness results

| Candidate | Hypothesised arity | Result |
|---|---|---|
| `AMA-N001` — Consequential goal–authority–obligation–effect join | THREE WAY EAA EMAS EAOSE | Inherited criterion or relation-only result |
| `AMA-N002` — Cross-level intention and obligation continuity | THREE WAY EAA EMAS EAOSE | Inherited criterion or relation-only result |
| `AMA-N003` — Delegation realised by an authorised capable executor | THREE WAY EAA EMAS EAOSE | Inherited criterion or relation-only result |
| `AMA-N004` — Global sufficiency beyond local agency success | THREE WAY EAA EMAS EAOSE | Inherited criterion or relation-only result |
| `AMA-N005` — Public compliance without forced private-state inspection | THREE WAY EAA EMAS EAOSE | Inherited criterion or relation-only result |
| `AMA-N006` — Protocol possibility to actual fulfilment closure | THREE WAY EAA EMAS EAOSE | Inherited criterion or relation-only result |
| `AMA-N007` — Epistemic reachability of acceptance evidence | THREE WAY EAA EMAS EAOSE | Inherited criterion or relation-only result |
| `AMA-N008` — Cross-level failure-attributed repair | THREE WAY EAA EMAS EAOSE | Inherited criterion or relation-only result |
| `AMA-N009` — Cross-level task and assurance preserving repair | THREE WAY EAA EMAS EAOSE | Inherited criterion or relation-only result |
| `AMA-N010` — Cross-lineage regime handoff | THREE WAY EAA EMAS EAOSE | Inherited criterion or relation-only result |
| `AMA-N011` — Smallest adequate agency/coordination architecture | THREE WAY EAA EMAS EAOSE | Inherited criterion or relation-only result |
| `AMA-N012` — Effective mixed human-agent decision authority | THREE WAY EAA EMAS EAOSE | Inherited criterion or relation-only result |
| `AMA-N013` — General self-revision assurance from three-level change controls | THREE WAY EAA EMAS EAOSE | Unsupported general assurance strengthening |
| `AMA-N014` — Generative multi-agent operational closure | THREE WAY EAA EMAS EAOSE | Inherited criterion or relation-only result |
| `AMA-N015` — Global compatibility beyond pairwise consistency | THREE WAY EAA EMAS EAOSE | Inherited criterion or relation-only result |
| `AMA-N016` — Composed control-cost and retirement envelope | THREE WAY EAA EMAS EAOSE | Inherited criterion or relation-only result |
| `AMA-N017` — Pairwise action/conversation binding coherence | PAIRWISE EAA EMAS | Inherited criterion or relation-only result |
| `AMA-N018` — Pairwise source independence across analysis and collective evidence | PAIRWISE EMAS EAOSE | Inherited criterion or relation-only result |
| `AMA-N019` — Pairwise ideal self-modification theorem to engineering method assurance | PAIRWISE EAA EAOSE | Unsupported general assurance strengthening |
| `AMA-N020` — Pairwise obligation-aware retirement of collective machinery | PAIRWISE EMAS EAOSE | Inherited criterion or relation-only result |

For each hypothesis, the ledger retains exact parent IDs, relation IDs, the proposed composite bearer and criterion, derivation, counterexample, inherited subsumers, per-parent and per-lineage removal tests, trigger, cheaper path, cost/evidence limits and later comparison questions. The three lineage-specific subsumption checks explicitly ask whether the candidate is already covered. An ablation that removes the very inherited criterion from a hypothetical reduced corpus cannot make that criterion new in the full supplied corpus.

**Surviving AMA-E minimality tests are not applicable because the surviving population is zero.** This is not “twenty candidates passed novelty”; all twenty failed an admission gate. Sixteen are three-way hypotheses; four are pairwise. The self-revision assurance strengthenings fail support, not because the open question is declared impossible. The rest are useful relation/derivation/configuration findings without residual distinct property identity.

A composition-level failure, a new observational diagnosis, a new interface relation, a new configuration and a new empirically supported capability are different kinds of result. The search preserves these distinctions rather than treating any higher-order failure as evidence for a new property. Zero admitted identities is bounded to the examined frozen corpus and declared search; it does not disprove all possible future AMA discoveries.

## 12. Sources, independence and evidence ceilings

The local source denominator is **234**. Exact cross-lineage reconciliation identifies **20 shared work/edition groups**, each preserving both local records. The identity ledger therefore has **214 work-or-collection/edition units**, plus **10 related-version/programme/resource-family records**. None of these numbers is an independent-study count. Within-lineage dependence and version relationships are also preserved in the original source tables, coverage payloads and context index.

Examples matter. ReAct v3, τ-bench v1, AgentDojo v3, Agentless v2 and particular multi-agent failure-study versions remain exact-version identities where the frozen metadata matches. Earlier and later versions remain distinct records even when they belong to the same empirical programme. Repeated use of the DS1 validation report is not a second flight experiment. AAMAS proceedings metadata is collection/community evidence, not a system-performance study. The EAA metadata-only access to *Intention is Choice with Commitment* is not upgraded because canonical EAOSE records a broader access scope. Different FIPA documents and current-profile leads do not establish implementation equivalence. [AMA-SRC003, AMA-SRC006–020; source-family records AMA-SF001–010; full source-local locators in the source register.]

The sixteen main synthesis claims each have a claim/evidence record identifying supporting inherited criteria, shared ancestry, formal assumptions, source-local empirical populations, access/benchmark/version limits and analytical status. Every material pair relation also records the two evidence ceilings. There is no pooled effect size, invented independence count, new benchmark run, new deployment population or source-strength promotion. Model-relative validity, implementation correspondence, environmental validity and consequential acceptance remain separate burdens.

No fresh external research was used. All source-identity decisions were resolvable at the bounded frozen-metadata level, with ambiguous edition/snapshot/programme equivalence retained as a limit rather than silently settled. The constituent literature’s own unresolved claims are not resolved by cross-lineage agreement.

## 13. Active negative and unresolved findings

The register retains **52 rows** whose dispositions are rejected/disfavoured, no-general-property, ceremonial, duplicate, superseded, contested or unresolved. They are active comparative findings, not missing data. No rejected universal form is resurrected by the positive vocabulary of a relation. In particular, neither agent count nor autonomy, communication, modelling, decentralisation, a complete central model, representation-free reaction, reflection, proxy maximisation or human participation is a universal guarantee of adequacy.

The principal unresolved inherited questions remain:

**EAA:EAA-062 — general open-ended self-revision assurance.** Predecessor-governed assessment, external feedback, protected objectives, bounded authority, evidence continuity and recovery provide constraints; the narrow idealised EAA-070 result does not prove general assurance for mutable agents, organisations or methods. The question remains open rather than being declared impossible.

**EMAS:EMAS-013 — current FIPA profile and implementation equivalence.** Related standards-family evidence and implementation-correspondence criteria identify what must be checked; they do not establish the missing exact current profile/runtime equivalence.

**EAOSE:EAOSE-C119 and EAOSE:EAOSE-C120 — net lifecycle benefit and broader whole-method superiority.** Useful local mechanisms, published applications and coherent composition do not establish comparative benefit of the entire evolved configuration family or complete AOSE methodologies over competent conventional engineering. A particular configuration requires claim-appropriate comparison and complete relevant cost accounting.

The contested EAA-042 deference result, canonical EAOSE-C028 local-cooperation/global-adequacy issue and EAOSE-C037 mental-state-compliance boundary remain contested. Preserving a useful guarded branch is not a resolution of its universalised form. Contemporary generative-agent results remain bounded to the source version, task, tool, partner population, environment, evaluator and access scope recorded by the constituent study.

A further **AMA-level evidence limit** is that the assembled family is not itself empirically validated. This is not an additional inherited property row or an invented AMA-E identity. New field evidence could change later comparative conclusions, but this frozen synthesis does not supply it.

## 14. Verification and later intake

The separate read-only reviewer reconstructs the exact property/source populations from the included original ZIPs, tests all pair identities and statuses, re-evaluates the classification rules, validates all relation endpoints and reverse references, checks clusters/tensions/bundles, tests candidate parent/lineage coverage, re-executes the six finite analytical models, checks the 278-row intake and preserves the negative/evidence boundaries. It also checks the exact inventory and manifest payload hashes at freeze. The review is a fresh execution over saved bytes by the same synthesis effort; it is not an independently authored scholarly peer review or a proof of every natural-language judgement.

The final package is only published after close/reopen, CRC, exact-member, member-byte/hash, manifest and fresh-extraction/readback checks. The internal verification receipt describes payload and review checks. The detached publication receipt binds the final enclosing ZIP size and hash without attempting a self-referential ZIP hash inside the ZIP. Neither custody nor internal consistency is empirical validation.

The JSON intake exports **all 278 rows**, including the negative, contested and unresolved findings, together with their distinct bearers, exact criterion locators, mechanisms, trigger/non-trigger, authority/delegation, capability, communication, evidence, criticism, costs, retirement and AMA relations. The three EAA and four EMAS inherited induced origins remain separately flagged; `composition_induced` in the intake denotes new AMA-level identities, of which there are none.

This packet is prepared for **later property-by-property inter-crosswalking**. No outside-trifecta corpus was consulted; no outside-trifecta or IMPLEMENTAUDIT crosswalk, Rockstar/RXX derivation, target adoption, ownership derivation, release work or repository mutation occurred. Only task-owned local analysis and delivery artefacts were created. No future target is authorised to adopt a mechanism merely because it appears in this intake.

### Reproduce the structural/readback review

From an extracted packet directory, using standard-library Python:

```sh
python verify_ama.py . --phase frozen
```

The output is a JSON verification receipt. A PASS proves the enumerated structural, custody and executable-model checks at this revision, subject to the stated semantic/scholarly limits. The standalone script does not need network access or permission to mutate the corpus.

### Canonical accounting

```text
EAA_PROPERTY_ROWS_ACCOUNTED: 70/70
EMAS_PROPERTY_ROWS_ACCOUNTED: 76/76
EAOSE_PROPERTY_ROWS_ACCOUNTED: 132/132
TOTAL_INHERITED_PROPERTY_ROWS_ACCOUNTED: 278/278
ORPHAN_INHERITED_PROPERTY_ROWS: 0
EAA_SOURCE_ROWS_ACCOUNTED: 54/54
EMAS_SOURCE_ROWS_ACCOUNTED: 56/56
EAOSE_SOURCE_ROWS_ACCOUNTED: 124/124
TOTAL_SOURCE_ROWS_ACCOUNTED: 234/234
EAA_EMAS_PAIRS_ACCOUNTED: 5320/5320
EAA_EAOSE_PAIRS_ACCOUNTED: 9240/9240
EMAS_EAOSE_PAIRS_ACCOUNTED: 10032/10032
TOTAL_CROSS_LINEAGE_PAIRS_ACCOUNTED: 24592/24592
ORPHAN_CROSS_LINEAGE_PAIRS: 0
MATERIAL_RELATIONS: 9178
NO_MATERIAL_RELATIONS: 15414
UNRESOLVED_RELATIONS: 0
DIRECTIONAL_RELATION_RECORDS_TOTAL: 20152
CONVERGENCE_CLUSTERS: 32
ONE_TO_MANY_COMPOSITION_BUNDLES: 16
TENSIONS: 24
ALTERNATIVE_CONFIGURATIONS: 15
ANALYTICAL_COUNTEREXAMPLES: 24
EXECUTABLE_ANALYTICAL_TESTS: 6
AMA_COMPOSITION_INDUCED_PROPERTIES: 0
AMA_PAIRWISE_INDUCED_PROPERTIES: 0
AMA_THREE_WAY_INDUCED_PROPERTIES: 0
REJECTED_EMERGENT_CANDIDATES: 20
LATER_INTER_CROSSWALK_PROPERTY_POPULATION: 278
```
