# Evolved-AMA — later inter-crosswalk intake

**Revision:** `AMA-2026-09-07-r1`

This is a comparison intake, not an adoption, ownership or implementation decision. The machine-readable intake is authoritative for the full field set. It contains 278 inherited rows and zero new AMA-E rows. No inherited row was deduplicated.

## Field and authority contract

Each JSON row carries the globally qualified key, frozen criterion/mechanism and bearer, disposition/examination status, trigger/non-trigger, dependencies, assumptions, authority/delegation, communication/capability, output/evidence ceiling, cost/failure/criticism, retirement, source ancestry, relation/cluster/tension references and later questions. Exact full frozen records remain in the constituent register and included archives. Bearer annotations for EAA/EMAS supplement rather than rewrite their original criteria.

`composition_induced` is AMA-level only. `constituent_composition_induced` preserves the three EAA and four EMAS origins; the canonical EAOSE final adjudication is zero despite preserved historical labels in some raw fields.

Compare properties one by one. A shared concern or possible shared implementation does not delete the independent identity, bearer, authority boundary or evidence ceiling. All unfavourable, duplicate, superseded, contested and unresolved rows remain in the roster.

## Complete inherited roster

| Qualified key | Name | Disposition | Examination |
|---|---|---|---|
| `EAA:EAA-001` | Explicit agent–environment boundary | STRONGLY_RETAINED | EXAMINED |
| `EAA:EAA-002` | Task-relative autonomy dimensions | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-003` | Computational grounding of mental-state vocabulary | STRONGLY_RETAINED | EXAMINED |
| `EAA:EAA-004` | Capability is not delegated permission | STRONGLY_RETAINED | EXAMINED |
| `EAA:EAA-005` | Observation, stored belief and world state remain distinct | STRONGLY_RETAINED | EXAMINED |
| `EAA:EAA-006` | Decision-relevant freshness and change detection | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-007` | Adequate uncertainty representation rather than a complete world model | ASSUMPTION_SENSITIVE | EXAMINED |
| `EAA:EAA-008` | Actionable information gathering | CONTEXT_DEPENDENT | EXAMINED |
| `EAA:EAA-009` | Abstention, waiting or safe non-action | CONTEXT_DEPENDENT | EXAMINED |
| `EAA:EAA-010` | Usable goal and success semantics | STRONGLY_RETAINED | EXAMINED |
| `EAA:EAA-011` | Achievement and maintenance commitments are not interchangeable | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAA:EAA-012` | Concurrent-goal interference protection | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAA:EAA-013` | Conditional intention commitment | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-014` | Economical reconsideration scheduling | CONTEXT_DEPENDENT | EXAMINED |
| `EAA:EAA-015` | Retirement of obsolete, unreachable or exhausted goals | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-016` | Direct reactive control as a legitimate architecture branch | CONTEXT_DEPENDENT | EXAMINED |
| `EAA:EAA-017` | Model-based deliberation when anticipation earns its cost | CONTEXT_DEPENDENT | EXAMINED |
| `EAA:EAA-018` | Executable BDI and plan-library interpretation | CONTEXT_DEPENDENT | EXAMINED |
| `EAA:EAA-019` | Hybrid arbitration and interface coherence | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAA:EAA-020` | Smallest adequate architecture and credible simpler baseline | STRONGLY_RETAINED | EXAMINED |
| `EAA:EAA-021` | Ground actions in executable capabilities and affordances | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-022` | Recheck material action conditions at dispatch | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-023` | Distinguish issuance, acknowledgement and established effect | STRONGLY_RETAINED | EXAMINED |
| `EAA:EAA-024` | Bounded contingency handling and plan repair | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-025` | Irreversibility and retry/compensation boundary | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-026` | Explicit time and resource envelope | STRONGLY_RETAINED | EXAMINED |
| `EAA:EAA-027` | Anytime response or adequate deadline fallback | CONTEXT_DEPENDENT | EXAMINED |
| `EAA:EAA-028` | Metareasoning and value of computation | CONTEXT_DEPENDENT | EXAMINED |
| `EAA:EAA-029` | Separate learning from execution-state updates | STRONGLY_RETAINED | EXAMINED |
| `EAA:EAA-030` | Evidence-grounded persistent experience | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-031` | Selective retrieval, forgetting and memory retirement | CONTEXT_DEPENDENT | EXAMINED |
| `EAA:EAA-032` | Adaptation with continuity checks | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAA:EAA-033` | Protected exploration and constraint-aware learning | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAA:EAA-034` | Intended objective is not the measured proxy | STRONGLY_RETAINED | EXAMINED |
| `EAA:EAA-035` | Transfer and distribution-change evaluation | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-036` | Communication receipt, acceptance and action are separate | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-037` | Cost-aware clarification and mixed initiative | CONTEXT_DEPENDENT | EXAMINED |
| `EAA:EAA-038` | Conditional transfer of control | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAA:EAA-039` | Human readiness and safe handback conditions | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-040` | Operational revocation and interruption | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-041` | Learning-theoretic safe interruptibility | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAA:EAA-042` | Objective uncertainty as a conditional route to deference | CONTESTED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAA:EAA-043` | User autonomy, privacy and affected-party accountability | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-044` | Action-faithful explanation and calibrated reliance | CONTEXT_DEPENDENT | EXAMINED |
| `EAA:EAA-045` | Adequate independent outcome and policy oracle | STRONGLY_RETAINED | EXAMINED |
| `EAA:EAA-046` | Repeated trials, versions and reproducible conditions | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-047` | Resource-controlled comparison with credible baselines | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-048` | Whole-task cost and burden accounting | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-049` | Protected tests and deliberate failure exposure | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-050` | Monitor material assurance assumptions at runtime | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAA:EAA-051` | Bound formal claims to model and implementation obligations | STRONGLY_RETAINED | EXAMINED |
| `EAA:EAA-052` | Untrusted observations do not confer instruction authority | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-053` | Language-model reasoning–action feedback | CONTEXT_DEPENDENT | EXAMINED |
| `EAA:EAA-054` | External-feedback-anchored reflection | CONTEXT_DEPENDENT | EXAMINED |
| `EAA:EAA-055` | Re-evaluate consequential model and tool version changes | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAA:EAA-056` | Human-likeness as a general competence or consciousness proxy | NO_GENERAL_PROPERTY | EXAMINED |
| `EAA:EAA-057` | Maximum autonomy and persistence are always preferable | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAA:EAA-058` | A complete central world model is universally necessary | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAA:EAA-059` | Representation-free reaction is universally sufficient | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAA:EAA-060` | Proxy maximisation is sufficient objective fulfilment | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAA:EAA-061` | Mandatory continuous reflection | SUPERSEDED_BY_STRONGER_FORM | EXAMINED |
| `EAA:EAA-062` | General assurance for open-ended self-revision | UNRESOLVED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAA:EAA-063` | Belief/intention prompts without operational semantics | CEREMONY_NOT_GENERAL_PROPERTY | EXAMINED |
| `EAA:EAA-064` | Leaderboard success as deployment guarantee | NO_GENERAL_PROPERTY | EXAMINED |
| `EAA:EAA-065` | Verify completion before claiming completion | DUPLICATE_CANDIDATE | EXAMINED |
| `EAA:EAA-066` | Software–physical translation needs new obligations | STRONGLY_RETAINED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAA:EAA-067` | Coherent action basis across asynchronous state, goal and authority changes | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAA:EAA-068` | Failure-attributed revision rather than undirected self-change | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAA:EAA-069` | Goal- and scope-preserving plan repair | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAA:EAA-070` | Predecessor-criterion evaluation of self-modification | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EMAS:EMAS-001` | Interdependence-justified agent decomposition | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-002` | Explicit population and environment boundary | STRONGLY_RETAINED | EXAMINED |
| `EMAS:EMAS-003` | Explicit goal alignment and incentive regime | STRONGLY_RETAINED | EXAMINED |
| `EMAS:EMAS-004` | Separate information, capability, control and authority | STRONGLY_RETAINED | EXAMINED |
| `EMAS:EMAS-005` | Decentralisation inherently guarantees resilience | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EMAS:EMAS-006` | More agents automatically add capability | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EMAS:EMAS-007` | Layered communication contract | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-008` | Publicly verifiable communicative effects | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-009` | Private mental-state sincerity as a universal compliance test | ASSUMPTION_SENSITIVE | EXAMINED |
| `EMAS:EMAS-010` | Conversation identity and information causality | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-011` | Protocol enactability and completion possibility | CONTEXT_DEPENDENT | EXAMINED |
| `EMAS:EMAS-012` | Delivery, interpretation, acceptance and consequence are separate | STRONGLY_RETAINED | EXAMINED |
| `EMAS:EMAS-013` | Current FIPA profile and implementation equivalence | UNRESOLVED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EMAS:EMAS-014` | Performatives or role prompts constitute cooperation | CEREMONY_NOT_GENERAL_PROPERTY | EXAMINED |
| `EMAS:EMAS-015` | Capability- and cost-aware task allocation | CONTEXT_DEPENDENT | EXAMINED |
| `EMAS:EMAS-016` | Award, acceptance, execution and task completion are distinct | STRONGLY_RETAINED | EXAMINED |
| `EMAS:EMAS-017` | Marginal-cost bargaining improves global allocation under a stated regime | ASSUMPTION_SENSITIVE | EXAMINED |
| `EMAS:EMAS-018` | Partial global planning with revisable local views | CONTEXT_DEPENDENT | EXAMINED |
| `EMAS:EMAS-019` | Dependency elimination can substitute for coordination | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-020` | Shared-resource and temporal dependency constraints | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-021` | Conditional decommitment and recontracting | CONTEXT_DEPENDENT | EXAMINED |
| `EMAS:EMAS-022` | Negotiate every task | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EMAS:EMAS-023` | Joint-goal persistence with explicit reconsideration | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-024` | Partial SharedPlans and capability-directed collaboration | CONTEXT_DEPENDENT | EXAMINED |
| `EMAS:EMAS-025` | Public conditional commitments | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-026` | Commitment alignment and bounded delegation | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-027` | Team monitoring, notification and repair | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-028` | Selective decision-theoretic communication | CONTEXT_DEPENDENT | EXAMINED |
| `EMAS:EMAS-029` | Full mutual belief is mandatory for all cooperation | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EMAS:EMAS-030` | Strategic model and solution-concept selection | STRONGLY_RETAINED | EXAMINED |
| `EMAS:EMAS-031` | Incentive-compatible reporting mechanisms | ASSUMPTION_SENSITIVE | EXAMINED |
| `EMAS:EMAS-032` | Participation, budget and efficiency feasibility | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-033` | Equilibrium, welfare, fairness and legitimacy remain distinct | STRONGLY_RETAINED | EXAMINED |
| `EMAS:EMAS-034` | Deviation, collusion and opponent-shift testing | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-035` | Contract and coalition search scope limits | ASSUMPTION_SENSITIVE | EXAMINED |
| `EMAS:EMAS-036` | Couple organisational structure, function and norms | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-037` | Norm declaration, detection and enforcement are distinct | STRONGLY_RETAINED | EXAMINED |
| `EMAS:EMAS-038` | Select regimentation, enforcement or voluntary norm reasoning | CONTEXT_DEPENDENT | EXAMINED |
| `EMAS:EMAS-039` | Role adoption and capability/permission compatibility | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-040` | Organisational revision with continuity constraints | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EMAS:EMAS-041` | Computational institution versus external legitimacy | STRONGLY_RETAINED | EXAMINED |
| `EMAS:EMAS-042` | Role charts alone establish organisation | CEREMONY_NOT_GENERAL_PROPERTY | EXAMINED |
| `EMAS:EMAS-043` | Distributed constraint satisfaction under explicit transport and search assumptions | ASSUMPTION_SENSITIVE | EXAMINED |
| `EMAS:EMAS-044` | Exact DCOP quality versus structural resource cost | DOMAIN_SPECIFIC | EXAMINED |
| `EMAS:EMAS-045` | Privacy as a protocol-level disclosure property | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-046` | Argument acceptability relative to an explicit semantics | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EMAS:EMAS-047` | Voting with explicit domain and manipulation limits | ASSUMPTION_SENSITIVE | EXAMINED |
| `EMAS:EMAS-048` | Evidence provenance and dependence-aware aggregation | STRONGLY_RETAINED | EXAMINED |
| `EMAS:EMAS-049` | Consensus establishes factual truth | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EMAS:EMAS-050` | Non-stationarity-sensitive learning evaluation | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-051` | Centralised training with decentralised execution information contract | CONTEXT_DEPENDENT | EXAMINED |
| `EMAS:EMAS-052` | Collective credit assignment and reward alignment | ASSUMPTION_SENSITIVE | EXAMINED |
| `EMAS:EMAS-053` | Local-to-joint value factorisation under representational restrictions | ASSUMPTION_SENSITIVE | EXAMINED |
| `EMAS:EMAS-054` | Unseen-partner and cross-play evaluation | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-055` | Emergent conventions are evaluated, not presumed legitimate norms | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-056` | Individual policy improvement guarantees collective progress | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EMAS:EMAS-057` | Explicit simulation-to-deployment transfer claim | STRONGLY_RETAINED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EMAS:EMAS-058` | Failure, deception and common-mode threat model | STRONGLY_RETAINED | EXAMINED |
| `EMAS:EMAS-059` | Recovery from abandoned obligations | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EMAS:EMAS-060` | Risk-limited trust and reputation | USEFUL_BUT_EASILY_GAMED | EXAMINED |
| `EMAS:EMAS-061` | Collective progress separate from local compliance | STRONGLY_RETAINED | EXAMINED |
| `EMAS:EMAS-062` | Coordination-layer failure and fallback | CONTEXT_DEPENDENT | EXAMINED |
| `EMAS:EMAS-063` | Open membership and version-compatible admission | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EMAS:EMAS-064` | Unrestricted communication guarantees robustness | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EMAS:EMAS-065` | Matched-budget and credible simpler baselines | STRONGLY_RETAINED | EXAMINED |
| `EMAS:EMAS-066` | Mechanism-level translation of LLM collectives | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-067` | Multi-seed, task, population and version evaluation | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EMAS:EMAS-068` | Mixed human-agent participation and decision boundaries | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EMAS:EMAS-069` | End-to-end collective consequence evaluation | STRONGLY_RETAINED | EXAMINED |
| `EMAS:EMAS-070` | Deployment, adoption and causal benefit are separate evidence | STRONGLY_RETAINED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EMAS:EMAS-071` | Observation–obligation–action closure | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EMAS:EMAS-072` | Regime-change guards and explicit handoff | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EMAS:EMAS-073` | Minimum adequate coordination with omission and retirement | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EMAS:EMAS-074` | Dependency-coupled adaptation | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EMAS:EMAS-075` | Fault-model-specific replicated optimisation | DOMAIN_SPECIFIC | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EMAS:EMAS-076` | Norm-aware plan augmentation and deliberation | DOMAIN_SPECIFIC | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C001` | Affected-stakeholder validation | STRONGLY_RETAINED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C002` | Stakeholder-goal to observable-acceptance correspondence | STRONGLY_RETAINED | EXAMINED |
| `EAOSE:EAOSE-C003` | Stakeholder validation is distinct from implementation verification | STRONGLY_RETAINED | EXAMINED |
| `EAOSE:EAOSE-C004` | Dependency vulnerability and accountability | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C005` | Goal conflict and alternative analysis | USEFUL_BUT_EASILY_GAMED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C006` | Delegation distinguished from authority | STRONGLY_RETAINED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C007` | Effective capability and permission checks | STRONGLY_RETAINED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C008` | Security-constraint and threat-to-test traceability | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C009` | Non-functional constraints and adverse consequences | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAOSE:EAOSE-C010` | Modular requirements views and explicit interfaces | CONTEXT_DEPENDENT | EXAMINED |
| `EAOSE:EAOSE-C011` | A complete goal diagram proves complete requirements | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAOSE:EAOSE-C012` | Agent-paradigm suitability decision | STRONGLY_RETAINED | EXAMINED |
| `EAOSE:EAOSE-C013` | Agent-oriented analysis without mandatory agent runtime | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C014` | Explicit autonomy and refusal boundaries | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C015` | Every active component should be an agent | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAOSE:EAOSE-C016` | More autonomy is inherently beneficial | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAOSE:EAOSE-C017` | Single-agent and workflow substitution tests | CONTEXT_DEPENDENT | EXAMINED |
| `EAOSE:EAOSE-C018` | Increasing agent count necessarily improves results | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAOSE:EAOSE-C019` | Mental-state labels establish intelligence | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAOSE:EAOSE-C020` | Role responsibilities, permissions, activities and protocols | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C021` | Many-to-many role-to-agent allocation | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C022` | Organisation-level rules supplement local role contracts | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C023` | Collective safety and liveness obligations | ASSUMPTION_SENSITIVE | EXAMINED |
| `EAOSE:EAOSE-C024` | Capability-constrained dynamic organisation | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C025` | Explicit dynamic role binding | CONTEXT_DEPENDENT | EXAMINED |
| `EAOSE:EAOSE-C026` | Holonic decomposition | DOMAIN_SPECIFIC | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C027` | Local cooperation as adaptive-system design principle | DOMAIN_SPECIFIC | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C028` | Local cooperation as a certificate of global adequacy | CONTESTED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C029` | Norm specification, violation and recovery | CONTEXT_DEPENDENT | EXAMINED |
| `EAOSE:EAOSE-C030` | Negotiation and task-allocation procedure | CONTEXT_DEPENDENT | EXAMINED |
| `EAOSE:EAOSE-C031` | Agent, organisation and environment separation | CONTEXT_DEPENDENT | EXAMINED |
| `EAOSE:EAOSE-C032` | Static cooperative organisation as a universal premise | SUPERSEDED_BY_STRONGER_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C033` | Interaction contract with defined semantics | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C034` | Content and ontology alignment | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C035` | Observable social commitments | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C036` | Private mental-state semantics as open compliance criterion | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAOSE:EAOSE-C037` | Private mental states as the basis of communication compliance | CONTESTED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C038` | Local protocol conformance and information causality | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C039` | Fault, timeout and compensation semantics | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C040` | Protocol evolution and mixed-version compatibility | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C041` | Interaction identity and authentication | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAOSE:EAOSE-C042` | Communication uncertainty, correlation and delivery handling | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAOSE:EAOSE-C043` | ACL syntax guarantees semantic interoperability | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAOSE:EAOSE-C044` | Explicit environment and effect interfaces | STRONGLY_RETAINED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C045` | Engineered environment artefacts | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C046` | Problem-matched internal architecture, including guarded BDI design | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C047` | Explicit plan failure and goal persistence semantics | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C048` | Goal completion checked against consequences | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C049` | Capability and plan modularity | CONTEXT_DEPENDENT | EXAMINED |
| `EAOSE:EAOSE-C050` | Belief provenance, revision and observational uncertainty | ASSUMPTION_SENSITIVE | EXAMINED |
| `EAOSE:EAOSE-C051` | Intention retention and bounded reconsideration | CONTEXT_DEPENDENT | EXAMINED |
| `EAOSE:EAOSE-C052` | Authorised goal adoption, maintenance and abandonment | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAOSE:EAOSE-C053` | Reactive–deliberative arbitration | CONTEXT_DEPENDENT | EXAMINED |
| `EAOSE:EAOSE-C054` | Interference among concurrent intentions | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C055` | Uncertainty-aware decision and abstention policy | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C056` | Explicit temporal feasibility for goals, plans and actions | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C057` | Resource budgets and termination conditions | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAOSE:EAOSE-C058` | Design-to-implementation correspondence | STRONGLY_RETAINED | EXAMINED |
| `EAOSE:EAOSE-C059` | Qualified model transformation trust | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C060` | Explicit manual and platform obligations | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C061` | Cross-view and metamodel consistency checking | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C062` | Knowledge and task modelling as distinct engineering views | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C063` | Lifecycle scope and method suitability | STRONGLY_RETAINED | EXAMINED |
| `EAOSE:EAOSE-C064` | Semantic compatibility of method fragments | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C065` | Work-product prerequisites and consistency | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAOSE:EAOSE-C066` | Executable prescriptions and work-product consumers | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C067` | Consumer-directed cross-view and operational feedback | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C068` | Proportionate admission, assembly and retirement of method machinery | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C069` | Comparison beyond feature checklists | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAOSE:EAOSE-C070` | Learnability and modelling burden | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C071` | Scoped reuse of engineering assets | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C072` | Method revision under declared authority | CONTEXT_DEPENDENT | EXAMINED |
| `EAOSE:EAOSE-C073` | One mandatory serial lifecycle | CEREMONY_NOT_GENERAL_PROPERTY | EXAMINED |
| `EAOSE:EAOSE-C074` | Union of all methods as a superior method | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAOSE:EAOSE-C075` | Method quality equals named-phase or diagram count | CEREMONY_NOT_GENERAL_PROPERTY | EXAMINED |
| `EAOSE:EAOSE-C076` | Named-method observance as assurance | CEREMONY_NOT_GENERAL_PROPERTY | EXAMINED |
| `EAOSE:EAOSE-C077` | Universally exhaustive methodology artefacts | CEREMONY_NOT_GENERAL_PROPERTY | EXAMINED |
| `EAOSE:EAOSE-C078` | One mandatory methodology fits every agent system | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAOSE:EAOSE-C079` | A consistent fragment composition guarantees achievable goals | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAOSE:EAOSE-C080` | Requirements-to-behaviour traceability | USEFUL_BUT_EASILY_BUREAUCRATISED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C081` | Bounded programme model checking | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C082` | Explicit model and environment assumptions for formal assurance | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C083` | Operating-environment and abstraction validity | STRONGLY_RETAINED | EXAMINED |
| `EAOSE:EAOSE-C084` | Validated percept–belief and action–effect mappings | STRONGLY_RETAINED | EXAMINED |
| `EAOSE:EAOSE-C085` | Assure both individual behaviour and collective outcomes | STRONGLY_RETAINED | EXAMINED |
| `EAOSE:EAOSE-C086` | Explicit compositional assurance assumptions | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C087` | Agent-level test oracles | USEFUL_BUT_EASILY_GAMED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C088` | Adversarial integration and discriminating perturbation testing | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C089` | Risk-proportionate test adequacy | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAOSE:EAOSE-C090` | Simulation validity and transfer limits | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C091` | Explanation fidelity and human interpretation | CONTEXT_DEPENDENT | EXAMINED |
| `EAOSE:EAOSE-C092` | All-path testing as the only adequate assurance | SUPERSEDED_BY_STRONGER_FORM | EXAMINED |
| `EAOSE:EAOSE-C093` | Exhaustive testing guarantees unrestricted autonomous behaviour | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAOSE:EAOSE-C094` | Code generation as an assurance certificate | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAOSE:EAOSE-C095` | Complete models guarantee correct implementation | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAOSE:EAOSE-C096` | Model checking certifies the deployed system without correspondence evidence | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAOSE:EAOSE-C097` | Agent agreement as an independent correctness oracle | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAOSE:EAOSE-C098` | Independent action-effect verification | STRONGLY_RETAINED | EXAMINED |
| `EAOSE:EAOSE-C099` | Runtime conformance monitoring | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C100` | Operational trace correlation | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C101` | Trace-grounded multi-agent failure localisation | CONTEXT_DEPENDENT | EXAMINED |
| `EAOSE:EAOSE-C102` | Versioned reproducible deployment configuration | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C103` | Selective premise-sensitive revalidation of assurance and requirements | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C104` | Authorised adaptation boundaries | STRONGLY_RETAINED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C105` | Valid continuity or resolution of obligations across operational transitions | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C106` | Consequential evidence reaches an authorised capable consumer | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C107` | Deployment and legacy-integration obligations | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C108` | Deployment topology and trust-boundary design | CONTEXT_DEPENDENT | EXAMINED |
| `EAOSE:EAOSE-C109` | Idempotency and uncertain-effect reconciliation | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAOSE:EAOSE-C110` | Human participation and effective intervention | CONTEXT_DEPENDENT | EXAMINED |
| `EAOSE:EAOSE-C111` | Accountability and evidence custody | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| `EAOSE:EAOSE-C112` | Design-method support implies a complete operational lifecycle | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAOSE:EAOSE-C113` | Unmonitored self-modification as authorised evolution | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAOSE:EAOSE-C114` | Observation plus self-revision guarantees improvement | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAOSE:EAOSE-C115` | Distinguish model, demonstration, prototype and deployment | STRONGLY_RETAINED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C116` | Realistic cost-and-quality comparative baselines | STRONGLY_RETAINED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C117` | Training, integration and maintenance cost accounting | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C118` | Comparison-unit and evidence-independence accounting | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C119` | Whole Evolved-AOSE configuration-family net lifecycle benefit | UNRESOLVED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C120` | Broad whole-AOSE-method superiority over conventional engineering | UNRESOLVED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C121` | Platform popularity as evidence of method effectiveness | NO_GENERAL_PROPERTY | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C122` | Documented continuity rather than rebranding | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C123` | LLM role prompts are not role-contract enforcement | STRONGLY_RETAINED | EXAMINED |
| `EAOSE:EAOSE-C124` | Stochastic and version-sensitive regression evaluation | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C125` | Tool-use authority separated from generated intention | STRONGLY_RETAINED | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C126` | Untrusted-input and prompt-injection containment | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C127` | Memory provenance and update semantics | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C128` | Bounded symbolic–learned hybrid design | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C129` | Generated plans remain subject to executable constraints | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C130` | Preserve responsiveness during long-running plan generation | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| `EAOSE:EAOSE-C131` | A role prompt is a formal role contract | REJECTED_OR_DISFAVOURED | EXAMINED |
| `EAOSE:EAOSE-C132` | Role prompts alone constitute AOSE | REJECTED_OR_DISFAVOURED | EXAMINED |

## Population equation
`INHERITED_AMA_PROPERTY_ROWS = 278`  
`AMA_COMPOSITION_INDUCED_PROPERTY_ROWS = 0`  
`LATER_INTER_CROSSWALK_POPULATION = 278`
## Later questions
For each row, establish whether the compared criterion has the same bearer, trigger, authority and accepted consequence rather than only a similar title. Determine what existing mechanism can realise it under the actual assumptions and what should be omitted. Preserve criticism and source dependence; do not promote a benchmark, model, source reuse or analytical convergence into a stronger deployment claim. No target owner is derived here.
The present synthesis consulted no outside-trifecta corpus and made no IMPLEMENTAUDIT, Rockstar/RXX, adoption or mutation decision.
