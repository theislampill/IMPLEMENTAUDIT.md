# EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PUBLIC_DOCUMENTATION_INTAKE

Revision EAOSE-R1-2026-09-07; cut-off 2026-09-07. **Established tradition:** Agent-Oriented Software Engineering. **Analytical product:** Evolved Agent-Oriented Software Engineering; this compound label is not claimed as an established historical school.

## Introduction suitable for public documentation

Agent-Oriented Software Engineering studies how agents and their interactions can support requirements analysis, design, implementation and the engineering of working systems. Its history connects agent programming and practical reasoning with actor/goal requirements, role-oriented organisation, knowledge engineering, modelling and formal verification. Gaia, Tropos, MaSE/O-MaSE, Prometheus and other methods address different engineering problems rather than forming one universally interchangeable method. [EAOSE-S014] [EAOSE-S002] [EAOSE-S003] [EAOSE-S006] [EAOSE-S007] [EAOSE-S008]

Criticism has sharpened the field's central distinctions: agent abstractions need a problem-specific justification; models do not prove implemented consequences; private intentions do not establish public compliance; and richer processes or popular frameworks do not establish whole-lifecycle benefit. The evolved account presented here is a conditional synthesis of mechanisms that survive those criticisms, with explicit alternatives, costs and limits. Its full 113-candidate denominator includes rejected and unresolved claims as well as retained mechanisms. [EAOSE-S015] [EAOSE-S023] [EAOSE-S036] [EAOSE-S061]

## Evolution and composition

The synthesis preserves validated stakeholder concerns, justified control boundaries, meaningful roles and interactions, qualified implementation correspondence, proportionate assurance, and operational feedback. It distinguishes internal decisions, public obligations, technical permissions, issued actions and observed consequences. Different configurations suit conventional software, deliberative agents, stable organisations, independent principals, adaptive systems and bounded generative hybrids. The selection is not a mandatory union of every named method.

End-to-end acceptance is an analytical composition obligation, not a new academic theorem. Change-triggered revalidation and branch-sensitive selection are subsumed by inherited mechanisms rather than imposed as additional controls. One mechanism may serve several concerns; useful documents and meetings are retained for their consumers, not their ceremonial presence. No adoption by any real host system is established.

## Citation-ready factual claims

**PC01.** AOP is a programming paradigm, not by itself a complete AOSE engineering lifecycle. **Source:** [EAOSE-S001]. **Locator:** Definition of AOP, comparison with object-oriented programming, AGENT0 discussion. **Limit:** Mental-state programming vocabulary is an abstraction; no empirical inference of intelligence or consciousness is warranted.

**PC02.** The original Gaia paper models roles through responsibilities, permissions, activities and protocols within a bounded organisational scope. **Source:** [EAOSE-S002]. **Locator:** Opening scope restrictions; analysis role and interaction models; design agent, service and acquaintance models. **Limit:** Original scope assumes comparatively stable cooperative organisations; later dynamic capabilities must not be retroactively attributed.

**PC03.** Tropos links actor/goal/dependency requirements concepts with later development views; a requirements goal is not automatically an implemented or validated goal. **Source:** [EAOSE-S003]. **Locator:** Method overview, early/late requirements, architectural and detailed design; actor and goal examples. **Limit:** Conceptual lifecycle argument and examples are not a controlled comparison or automatic validation of stakeholders.

**PC04.** The inspected O-MaSE process explicitly leaves several management, deployment, testing and evaluation concerns outside its scope. **Source:** [EAOSE-S008]. **Locator:** Introduction pp.245–247; metamodel, method fragments and process-construction guidance. **Limit:** Explicitly excludes management, deployment, testing and evaluation from its presented development process; implementation and organisational assumptions remain.

**PC05.** Prometheus provides related specification, architecture and detailed-design guidance while leaving sensor/effector engineering outside its core. **Source:** [EAOSE-S006]. **Locator:** System specification, architectural design and detailed design; introductory exclusions; iterative relationships. **Limit:** Sensor/effector engineering excluded; illustrative design support is not field-validated full lifecycle coverage.

**PC06.** Public communication obligations cannot be established merely by assuming inaccessible private mental states. **Source:** [EAOSE-S023]. **Locator:** Mentalistic versus social semantics; observable public commitments and heterogeneity. **Limit:** Critique concerns open interaction compliance, not the uselessness of private BDI reasoning.

**PC07.** The Comma developer study gives a mixed task-level time comparison, not uniform or whole-lifecycle superiority. **Source:** [EAOSE-S061]. **Locator:** Sections 4–5; Figures 7–10 and Table 5, visually inspected. **Limit:** 34 graduate students; better initial modelling but slower first modification; self-reported time, outlier removal and multiple contrasts. No whole-lifecycle superiority.

**PC08.** The industrial BDI business-process report describes a prototype and semantic migration work, not a production-wide comparative ROI result. **Source:** [EAOSE-S052]. **Locator:** Section 4.3 prototype development and platform migration; lessons learned. **Limit:** Three-month prototype, up to four modellers and ten scenarios; semantic differences and missing version support reported. Not a production-wide ROI study.

**PC09.** EMAS has a documented history bringing together AOSE, DALT and ProMAS workshop streams. **Source:** [EAOSE-S017]. **Locator:** History and past-edition list. **Limit:** Institutional continuity is not measured adoption, tool maintenance or benefit.

**PC10.** Current norm-aware BDI work demonstrates an example while leaving automation and larger-system evaluation as future work. **Source:** [EAOSE-S089]. **Locator:** All three pages; norm/goal-plan transformation, public-transport example and future work; page-1 screenshot. **Limit:** Jason example, not comparative deployment evidence. Norms can be knowingly violated; hard security permissions are a different construct. Automatic transformation, dynamic norms and larger-system overhead remain future work.

**PC11.** The 2026 multi-level explanation prototype implements implementation/design levels; its proposed domain level is not credited as implemented. **Source:** [EAOSE-S090]. **Locator:** All three pages; implementation/design/domain levels, mapping functions, implemented prototype and future work; page-1 screenshot. **Limit:** Prototype implements implementation and design levels, not the proposed domain level. Focus is individual BDI agents. Collective explanation and LLM transfer are not demonstrated; no comparative user benefit is established here.

**PC12.** AgentDojo is a prompt-injection evaluation environment, not a production-prevalence survey or proof of universal defence. **Source:** [EAOSE-S042]. **Locator:** Threat model; task and security-case construction; attacks, defences and limitations. **Limit:** 97 tasks and 629 security cases in the inspected version; benchmark vulnerability is not a population incidence rate or proof all defences fail.

## Strongest properties and limits

The clearest surviving distinctions concern legitimate requirements, justified abstractions, responsibility and permission, specified interactions, design/code correspondence and actual acceptance evidence. Their exact mature forms and conditions are in the canonical ledger. Formal checking, holons, BDI internals, commitment protocols, rich goal models and learned hybrids remain conditional choices, not universal obligations.

Provenance and formal validity are not comparative effectiveness. Classroom/model examples are not field deployment. DS1 supplies specific operational evidence; Daimler is a prototype. Related editions and repeated cases do not establish replication. The source table gives claim-specific access, empirical units and formal assumptions. Whole-method net benefit remains EAOSE-061 (UNRESOLVED).

## Caricatures and ceremonies to avoid

Do not reduce AOSE to “put several agents in a chat”, “use beliefs and goals as variable names”, “draw all the diagrams”, “generate code”, or “add a human approval step”. Those practices can have useful functions, but their presence alone establishes neither the engineering mechanism nor the intended consequence. Simplification must preserve a real consumer and failure boundary; deleting useful evidence is not maturity.

## Suggested page outline

1. What AOSE engineers, and what the evolved label means.
2. Plural genealogy and the problems addressed by major methods.
3. Strong surviving distinctions, with operating mechanisms and cheap alternatives.
4. Conditional configurations and real communication/action interfaces.
5. Criticism, adverse evidence and unresolved method-level benefit.
6. Contemporary symbolic and learned-agent engineering without rebranding.
7. Full candidate ledger, evidence boundaries and source locators.
8. Explicitly separate any later host-specific adoption evidence from this neutral research.

## Claims not to make

Do not invent a founding school called Evolved AOSE; infer influence from shared terminology; describe a venue merger as methodological consensus; claim that agents, autonomy or agent count always improve software; call model generation, a proof or a benchmark reward a deployment certificate; infer economic superiority from a selected case; equate catalogue availability with maintenance or adoption; credit unimplemented future features; treat related editions as independent replication; or imply this research establishes a host system's use of any property.

## Current frontier

The inspected current work spans logical communication realisation, timed and norm-aware BDI, explanation, learned-agent failures, adversarial tools and realistic evaluation. It does not settle comparative lifecycle benefit, global adequacy under changing assumptions, or affordable assurance of opaque changing components. Published proposals and benchmark progress should be described at their actual evidential level, not as a completed revolution. [EAOSE-S037] [EAOSE-S041] [EAOSE-S042] [EAOSE-S045] [EAOSE-S051] [EAOSE-S085] [EAOSE-S088] [EAOSE-S089] [EAOSE-S090]


## Source-link definitions

[EAOSE-S001]: https://www.researchgate.net/publication/222482819_Agent-Oriented_Programming/fulltext/0e603da7f0c46d4f0aa42e1d/Agent-Oriented-Programming.pdf
[EAOSE-S002]: https://www.cs.ox.ac.uk/people/michael.wooldridge/pubs/jaamas2000b.pdf
[EAOSE-S003]: https://www.researchgate.net/publication/225198353_Tropos_An_Agent-Oriented_Software_Development_Methodology
[EAOSE-S004]: https://link.springer.com/article/10.1023/B:AGNT.0000018806.20944.ef
[EAOSE-S005]: https://www.cs.utoronto.ca/~eric/ieeeexp/ieeeexp2.html
[EAOSE-S006]: https://michaelwinikoff.com/wp-content/uploads/2019/05/aamas02-aose-ws.pdf
[EAOSE-S007]: https://www.researchgate.net/publication/220344738_MULTIAGENT_SYSTEMS_ENGINEERING
[EAOSE-S008]: https://www.researchgate.net/publication/220608212_O-MaSE_A_customisable_approach_to_designing_and_building_complex_adaptive_multi-agent_systems
[EAOSE-S009]: https://ceur-ws.org/Vol-627/fipa_5.pdf
[EAOSE-S010]: https://winikoff.github.io/pdf/aois2003.pdf
[EAOSE-S011]: https://ceur-ws.org/Vol-627/fipa_6.pdf
[EAOSE-S012]: https://lia.disi.unibo.it/~ao/pubs/pdf/volumes/eumas2006/Republications/15.pdf
[EAOSE-S013]: https://www.researchgate.net/publication/237490469_From_Requirements_to_Code_with_the_PASSI_Methodology
[EAOSE-S014]: https://www.cs.ox.ac.uk/people/michael.wooldridge/pubs/aose2000a.pdf
[EAOSE-S015]: https://www.cs.ox.ac.uk/people/michael.wooldridge/pubs/agents98.pdf
[EAOSE-S016]: https://onlinelibrary.wiley.com/doi/abs/10.1002/9780470050118.ecse006
[EAOSE-S017]: https://emas.in.tu-clausthal.de/
[EAOSE-S018]: https://emas-workshop.github.io/2026/
[EAOSE-S019]: https://aamas.csc.liv.ac.uk/Proceedings/aamas2026/forms/contents.htm
[EAOSE-S020]: https://arxiv.org/html/2006.08820v1
[EAOSE-S021]: https://doi.org/10.1145/367211.367250
[EAOSE-S022]: https://doi.org/10.1145/958961.958963
[EAOSE-S023]: https://www.csc2.ncsu.edu/faculty/mpsingh/papers/mas/computer-acl-98.pdf
[EAOSE-S024]: https://jmvidal.cse.sc.edu/822/papers/Rep_Agent_Protocols.pdf
[EAOSE-S025]: https://ppgia.pucpr.br/~fabricio/ftp/Aulas/Mestrado/AS/Aula3/SC00061G_FIPA_ACL.pdf
[EAOSE-S026]: https://www.chrismitchell.net/sfac.pdf
[EAOSE-S027]: https://arxiv.org/html/2203.00086v1
[EAOSE-S028]: https://www.ifaamas.org/Proceedings/aamas2025/pdfs/p2426.pdf
[EAOSE-S029]: https://intranet.csc.liv.ac.uk/~matt/pubs/mcapl11.pdf
[EAOSE-S030]: https://www.ijcai.org/Proceedings/15/Papers/599.pdf
[EAOSE-S031]: https://www.ifaamas.org/Proceedings/aamas2017/pdfs/p260.pdf
[EAOSE-S032]: https://arxiv.org/html/2108.08117v1
[EAOSE-S033]: https://helios2.mi.parisdescartes.fr/~moraitis/webpapers/Moraitis-IJAOSE22.pdf
[EAOSE-S034]: https://www.researchgate.net/publication/225470190_An_Empirical_Evaluation_of_the_i_Framework_in_a_Model-Based_Software_Generation_Environment
[EAOSE-S035]: https://arxiv.org/html/2503.13657v3
[EAOSE-S036]: https://arxiv.org/html/2407.01502v1
[EAOSE-S037]: https://pure.manchester.ac.uk/ws/files/1825510647/EMAS2025_Roadmap.pdf
[EAOSE-S038]: https://www.eecis.udel.edu/~decker/courses/889a/daimler.pdf
[EAOSE-S039]: https://www.researchgate.net/publication/216702294_ASPECS_an_Agent-oriented_Software_Process_for_Engineering_Complex_Systems_How_to_design_agent_societies_under_a_holonic_perspective
[EAOSE-S040]: https://lia.disi.unibo.it/corsi/2007-2008/SMA-LS/papers/9/bernon2004a.pdf
[EAOSE-S041]: https://arxiv.org/html/2406.12045v1
[EAOSE-S042]: https://arxiv.org/html/2406.13352v1
[EAOSE-S043]: https://webspace.science.uu.nl/~dalpi001/papers/ali-chop-dalp-gior-mylo-souz-10-istar.pdf
[EAOSE-S044]: https://emas-workshop.github.io/2026/papers/041_ARARA_A_LLM-based_Multi-Agent_Development_Framework_for_Conv.pdf
[EAOSE-S045]: https://emas-workshop.github.io/2026/papers/015_Ex-Plan_Explaining_BDI_Agent_Behaviour_Through_Contrastive_P.pdf
[EAOSE-S046]: https://www.ifaamas.org/Proceedings/aamas2018/pdfs/p2054.pdf
[EAOSE-S047]: https://www.jot.fm/issues/issue_2010_07/article5.pdf
[EAOSE-S048]: https://www.researchgate.net/publication/2713293_Analysis_and_design_of_multiagent_systems_using_MAS-CommonKADS
[EAOSE-S049]: https://www.researchgate.net/publication/47529129_SECURE_TROPOS_A_SECURITY-ORIENTED_EXTENSION_OF_THE_TROPOS_METHODOLOGY
[EAOSE-S050]: https://arxiv.org/html/2006.05619v1
[EAOSE-S051]: https://arxiv.org/html/2205.00979v2
[EAOSE-S052]: https://www.ifaamas.org/Proceedings/aamas08/proceedings/pdf/industrial_application_track/AAMAS08_IndTrack_16.pdf
[EAOSE-S053]: https://faculty.sites.iastate.edu/tesfatsi/archive/tesfatsi/jennings.pdf
[EAOSE-S054]: https://www.researchgate.net/publication/221419145_A_Goal-Oriented_Software_Testing_Methodology
[EAOSE-S055]: https://ii.tudelft.nl/~joostb/files/mates2010_final.pdf
[EAOSE-S056]: https://ai.jpl.nasa.gov/public/documents/papers/rax-results-isairas99.pdf
[EAOSE-S057]: https://arxiv.org/html/2304.03442v2
[EAOSE-S058]: https://sourceforge.net/projects/ingenias/files/INGENIAS%20Development%20Kit/
[EAOSE-S059]: https://sourceforge.net/projects/ptk/
[EAOSE-S060]: https://github.com/ls-cnr/AgentFactory
[EAOSE-S061]: https://ifaamas.org/Proceedings/aamas2012/papers/3F_4.pdf
[EAOSE-S062]: https://www.ijcai.org/Proceedings/73/Papers/027B.pdf
[EAOSE-S063]: https://cdn.aaai.org/ICMAS/1995/ICMAS95-042.pdf
[EAOSE-S064]: https://link.springer.com/chapter/10.1007/BFb0031846
[EAOSE-S065]: https://www.reidgsmith.com/The_Contract_Net_Protocol_Dec-1980.pdf
[EAOSE-S066]: https://jmvidal.cse.sc.edu/library/cohen90a.pdf
[EAOSE-S067]: https://www.researchgate.net/publication/251518239_Multi-agent_oriented_programming_with_JaCaMo
[EAOSE-S068]: https://www.researchgate.net/publication/221456372_MOISE_Towards_a_Structural_Functional_and_Deontic_model_for_MAS_organization
[EAOSE-S069]: https://mmi.tudelft.nl/pub/koen/GOAL_JAL.pdf
[EAOSE-S070]: https://www.ifaamas.org/Proceedings/aamas2014/aamas/p933.pdf
[EAOSE-S071]: https://www.ijcai.org/proceedings/2017/0065.pdf
[EAOSE-S072]: https://www.staff.science.uu.nl/~dalpi001/papers/mora-dalp-nguy-sien-14-aose.pdf
[EAOSE-S073]: https://www.emse.fr/~boissier/enseignement/defiia/up5/pdf/Bratman-PlansPracticalResoning.pdf
[EAOSE-S074]: https://maxapress.com/data/article/ker/preview/pdf/S026988891800005X.pdf
[EAOSE-S075]: https://arxiv.org/html/2308.08155v2
[EAOSE-S076]: https://arxiv.org/html/2308.00352v6
[EAOSE-S077]: https://arxiv.org/html/2307.07924v5
[EAOSE-S078]: https://arxiv.org/html/2210.03629v3
[EAOSE-S079]: https://docs.langchain.com/oss/python/langgraph/persistence
[EAOSE-S080]: https://docs.langchain.com/oss/python/langgraph/interrupts
[EAOSE-S081]: https://microsoft.github.io/autogen/stable/user-guide/agentchat-user-guide/tutorial/termination.html
[EAOSE-S082]: https://cdn.aaai.org/ICMAS/1996/ICMAS96-005.pdf
[EAOSE-S083]: https://www.cs.vu.nl/~wai/Papers/IJCIS97.DESIRE10.pdf
[EAOSE-S084]: https://conf.researchr.org/home/icse-2026/agent-2026
[EAOSE-S085]: https://emas.in.tu-clausthal.de/2025/assets/pdfs/emas2025-14.pdf
[EAOSE-S086]: https://link.springer.com/chapter/10.1007/978-3-032-18011-7_12
[EAOSE-S087]: https://www.cs.toronto.edu/~jenhork/Papers/Horkoff_PoEM_2009l.pdf
[EAOSE-S088]: https://aamas.csc.liv.ac.uk/Proceedings/aamas2026/pdfs/SAXY3841.pdf
[EAOSE-S089]: https://aamas.csc.liv.ac.uk/Proceedings/aamas2026/pdfs/SEJS3352.pdf
[EAOSE-S090]: https://aamas.csc.liv.ac.uk/Proceedings/aamas2026/pdfs/ZIQG2381.pdf
