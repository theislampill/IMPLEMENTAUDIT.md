# EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_SYNTHESIS_INTAKE

Revision EAOSE-R1-2026-09-07; cut-off 2026-09-07. Lane **7.3**, provisional trifecta **#7 — Autonomous Agents / Multi-Agent Systems / Agent-Oriented Software Engineering**. The grouping is organisational, not an established scholarly methodology.

**SIBLING_CORPORA_NOT_CONSULTED**  
**CROSS_TRIFECTA_SYNTHESIS_NOT_PERFORMED**

## Frozen research identity

Canonical population **113**, examined **113/113**. Retain all IDs and dispositions during later integration, including duplicates and unfavourable findings. The full export is `PROPERTY_LEDGER.synthesis_export`; every entry has a globally unique key, mechanism, trigger, inputs, outputs, cost, assumptions, conflicts, evidence and omission/retirement conditions. The exact older count-only 66-row roster was not recovered; the current denominator must not be described as an exact restoration of that file.

## Within-tradition synthesis

AOSE contributes a conditional engineering account linking legitimate stakeholder concerns, justified agency, responsibilities and interaction, internal/executable design, assurance and live evolution. Its objects are not only internal representations: it addresses social obligations, permissions, actual resource effects and external acceptance. Models and criteria make distinctions; operative mechanisms establish evidence, communicate it to consumers and enable authorised action. Neither function can be assumed from the other's existence.

The composition preserves conventional, deliberative, stable-organisational, open-principal, adaptive and generative-hybrid configurations. Formal assurance, security and live-operation overlays are orthogonal, triggered by actual consequences and boundaries. See the composition model for guarded relations, loops, interrupts, external interfaces and revision constraints. No one-control-per-property rule follows.

The end-to-end witness (EAOSE-079) is an analytical composition obligation; consumer closure (EAOSE-081) is conditional. Change-triggered revalidation (EAOSE-080) and branch-sensitive selection (EAOSE-113) are aliases of inherited operative content, not mandatory new controls or scientifically established novel properties.

## Native concepts and dependence model

Actor/goal/dependency requirements, roles and many-to-many allocations, public commitments, information-causal protocols, beliefs/goals/plans, method fragments, model/code correspondence and goal-related assurance are the principal engineering concepts. Their sources include documented imports and shared ancestry; later synthesis must preserve those genealogical distinctions rather than count every overlap as independently invented.

Dependency relations matter more than name equality. A role criterion needs a justified allocation and authority boundary; a protocol model needs local realisation; a programme proof needs environmental/implementation correspondence; an observation needs an appropriate acceptance consumer; a change needs impact analysis and treatment of outstanding obligations. Alternative mechanisms may provide the same function, and one mechanism may address several source concerns.

## Evidence boundary

Provenance and formal validity are not comparative effectiveness. Classroom/model examples are not field deployment. DS1 supplies specific operational evidence; Daimler is a prototype. Related editions and repeated cases do not establish replication. The source table gives claim-specific access, empirical units and formal assumptions. Whole-method net benefit remains EAOSE-061 (UNRESOLVED). The whole composed method is not empirically validated against a conventional alternative. Source access limitations, case specificity, proof assumptions, common benchmarks and mutable provider/documentation versions travel with the export. Retention is not an adoption mandate.

## Questions for the Autonomous Agents lane

How do its definitions distinguish observation, belief, goal, intention, action capability and delegated authority? Which architectural invariants require the engineering mappings captured here, and which are merely analogous vocabulary? Under which environmental and resource assumptions do persistence, reconsideration and reactive handling operate? What separate evidence supports the transition from an internal success condition to a real effect? These are questions for the unread lane, not answers inferred from its title.

## Questions for the Multi-Agent Systems lane

Which collective guarantees assume cooperation, stable membership, shared semantics or particular timing? How do its roles, norms, commitments, allocation and protocol concepts map to concrete engineering artefacts and deployment boundaries? Which formal collective results require assumption and implementation witnesses this lane can supply? Which interactions concern independently authoritative principals rather than components under one controller? Shared primary sources must not be counted as independent replication.

## Later reconciliation tests

Test semantic equivalence by mechanism, trigger and postcondition, not label. Test complementarity by input/output compatibility and abstraction level. Test redundancy before creating another control. Preserve incompatible assumptions as guarded alternatives. Check what new obligations arise at the composed interfaces, without manufacturing novelty. Allow selection, substitution, omission and retirement when a cheaper adequate mechanism exists. Never erase a source candidate's rejected or unresolved history to make a combined denominator look cleaner.

## Complete globally unique key registry

| Global key | Candidate | Disposition | Operative export / omission reference |
| --- | --- | --- | --- |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-001 | Affected-stakeholder validation | STRONGLY_RETAINED | PROPERTY_LEDGER.synthesis_export[EAOSE-001]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-002 | Dependency vulnerability and accountability | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-002]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-003 | Goal-to-acceptance operationalisation | STRONGLY_RETAINED | PROPERTY_LEDGER.synthesis_export[EAOSE-003]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-004 | Goal conflict and alternative analysis | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-004]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-005 | Delegation distinguished from authority | STRONGLY_RETAINED | PROPERTY_LEDGER.synthesis_export[EAOSE-005]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-006 | Requirements-to-behaviour traceability | USEFUL_BUT_EASILY_BUREAUCRATISED | PROPERTY_LEDGER.synthesis_export[EAOSE-006]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-007 | Agent-paradigm suitability decision | STRONGLY_RETAINED | PROPERTY_LEDGER.synthesis_export[EAOSE-007]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-008 | Agent-oriented analysis without mandatory agent runtime | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-008]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-009 | Explicit autonomy and refusal boundaries | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-009]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-010 | Every active component should be an agent | REJECTED_OR_DISFAVOURED | PROPERTY_LEDGER.synthesis_export[EAOSE-010]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-011 | More autonomy is inherently beneficial | REJECTED_OR_DISFAVOURED | PROPERTY_LEDGER.synthesis_export[EAOSE-011]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-012 | Role responsibilities, permissions, activities and protocols | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-012]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-013 | Effective capability and permission checks | STRONGLY_RETAINED | PROPERTY_LEDGER.synthesis_export[EAOSE-013]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-014 | Many-to-many role-to-agent allocation | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-014]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-015 | Collective safety and liveness obligations | ASSUMPTION_SENSITIVE | PROPERTY_LEDGER.synthesis_export[EAOSE-015]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-016 | Capability-constrained dynamic organisation | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-016]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-017 | Explicit environment and effect interfaces | STRONGLY_RETAINED | PROPERTY_LEDGER.synthesis_export[EAOSE-017]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-018 | Holonic decomposition | DOMAIN_SPECIFIC | PROPERTY_LEDGER.synthesis_export[EAOSE-018]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-019 | Interaction contract with defined semantics | STRONGLY_RETAINED | PROPERTY_LEDGER.synthesis_export[EAOSE-019]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-020 | Content and ontology alignment | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-020]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-021 | Observable social commitments | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-021]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-022 | Private mental-state semantics as open compliance criterion | REJECTED_OR_DISFAVOURED | PROPERTY_LEDGER.synthesis_export[EAOSE-022]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-023 | Local protocol conformance and information causality | ASSUMPTION_SENSITIVE | PROPERTY_LEDGER.synthesis_export[EAOSE-023]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-024 | Explicit dynamic role binding | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-024]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-025 | Fault, timeout and compensation semantics | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-025]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-026 | Protocol evolution and mixed-version compatibility | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-026]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-027 | BDI internal design where deliberation warrants it | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-027]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-028 | Explicit plan failure and goal persistence semantics | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-028]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-029 | Capability and plan modularity | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-029]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-030 | Design-to-implementation correspondence | STRONGLY_RETAINED | PROPERTY_LEDGER.synthesis_export[EAOSE-030]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-031 | Qualified model transformation trust | ASSUMPTION_SENSITIVE | PROPERTY_LEDGER.synthesis_export[EAOSE-031]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-032 | Explicit manual and platform obligations | STRONGLY_RETAINED | PROPERTY_LEDGER.synthesis_export[EAOSE-032]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-033 | Goal completion checked against consequences | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-033]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-034 | Lifecycle scope and method suitability | STRONGLY_RETAINED | PROPERTY_LEDGER.synthesis_export[EAOSE-034]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-035 | Semantic compatibility of method fragments | ASSUMPTION_SENSITIVE | PROPERTY_LEDGER.synthesis_export[EAOSE-035]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-036 | Work-product prerequisites and consistency | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-036]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-037 | Comparison beyond feature checklists | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-037]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-038 | Learnability and modelling burden | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-038]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-039 | Consumer-driven minimal representations | STRONGLY_RETAINED | PROPERTY_LEDGER.synthesis_export[EAOSE-039]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-040 | One mandatory serial lifecycle | CEREMONY_NOT_GENERAL_PROPERTY | PROPERTY_LEDGER.synthesis_export[EAOSE-040]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-041 | Union of all methods as a superior method | REJECTED_OR_DISFAVOURED | PROPERTY_LEDGER.synthesis_export[EAOSE-041]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-042 | Stakeholder goal validation restated | DUPLICATE_CANDIDATE | PROPERTY_LEDGER.synthesis_export[EAOSE-042]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-043 | Bounded programme model checking | ASSUMPTION_SENSITIVE | PROPERTY_LEDGER.synthesis_export[EAOSE-043]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-044 | Environment and abstraction validation | STRONGLY_RETAINED | PROPERTY_LEDGER.synthesis_export[EAOSE-044]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-045 | Agent-level test oracles | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-045]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-046 | Collective and adversarial integration testing | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-046]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-047 | Risk-proportionate test adequacy | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-047]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-048 | Simulation validity and transfer limits | ASSUMPTION_SENSITIVE | PROPERTY_LEDGER.synthesis_export[EAOSE-048]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-049 | Runtime conformance monitoring | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-049]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-050 | Explanation fidelity and human interpretation | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-050]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-051 | Versioned reproducible deployment configuration | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-051]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-052 | Operational trace correlation | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-052]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-053 | Change-impact traceability and reassurance | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-053]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-054 | Authorised adaptation boundaries | STRONGLY_RETAINED | PROPERTY_LEDGER.synthesis_export[EAOSE-054]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-055 | Recovery, retirement and obligation discharge | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-055]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-056 | Operational handoff with an actual consumer | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-056]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-057 | Method revision under declared authority | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-057]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-058 | Distinguish model, demonstration, prototype and deployment | STRONGLY_RETAINED | PROPERTY_LEDGER.synthesis_export[EAOSE-058]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-059 | Realistic cost-and-quality comparative baselines | STRONGLY_RETAINED | PROPERTY_LEDGER.synthesis_export[EAOSE-059]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-060 | Training, integration and maintenance cost accounting | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-060]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-061 | Whole-method net benefit over conventional engineering | UNRESOLVED | PROPERTY_LEDGER.synthesis_export[EAOSE-061]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-062 | Platform popularity as evidence of method effectiveness | NO_GENERAL_PROPERTY | PROPERTY_LEDGER.synthesis_export[EAOSE-062]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-063 | LLM role prompts are not role-contract enforcement | STRONGLY_RETAINED | PROPERTY_LEDGER.synthesis_export[EAOSE-063]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-064 | Stochastic and version-sensitive regression evaluation | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-064]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-065 | Tool-use authority separated from generated intention | STRONGLY_RETAINED | PROPERTY_LEDGER.synthesis_export[EAOSE-065]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-066 | Memory provenance and update semantics | ASSUMPTION_SENSITIVE | PROPERTY_LEDGER.synthesis_export[EAOSE-066]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-067 | Untrusted-input and prompt-injection containment | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-067]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-068 | Trace-grounded multi-agent failure localisation | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-068]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-069 | Single-agent and workflow substitution tests | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-069]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-070 | Agent agreement as an independent correctness oracle | REJECTED_OR_DISFAVOURED | PROPERTY_LEDGER.synthesis_export[EAOSE-070]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-071 | Unmonitored self-modification as authorised evolution | REJECTED_OR_DISFAVOURED | PROPERTY_LEDGER.synthesis_export[EAOSE-071]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-072 | Independent action-effect verification | STRONGLY_RETAINED | PROPERTY_LEDGER.synthesis_export[EAOSE-072]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-073 | Bounded symbolic–learned hybrid design | ASSUMPTION_SENSITIVE | PROPERTY_LEDGER.synthesis_export[EAOSE-073]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-074 | Documented continuity rather than rebranding | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-074]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-075 | Modular requirements views and explicit interfaces | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-075]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-076 | Code generation as an assurance certificate | REJECTED_OR_DISFAVOURED | PROPERTY_LEDGER.synthesis_export[EAOSE-076]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-077 | Local cooperation as adaptive-system design principle | DOMAIN_SPECIFIC | PROPERTY_LEDGER.synthesis_export[EAOSE-077]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-078 | All-path testing as the only adequate assurance | SUPERSEDED_BY_STRONGER_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-078]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-079 | End-to-end obligation-to-effect witness | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-079]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-080 | Assumption-change evidence invalidation | DUPLICATE_CANDIDATE | PROPERTY_LEDGER.synthesis_export[EAOSE-080]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-081 | Consumer-closed lifecycle composition | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-081]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-082 | Explicit temporal feasibility for goals, plans and actions | ASSUMPTION_SENSITIVE | PROPERTY_LEDGER.synthesis_export[EAOSE-082]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-083 | Security-constraint and threat-to-test traceability | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-083]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-084 | Local cooperation as a certificate of global adequacy | CONTESTED | PROPERTY_LEDGER.synthesis_export[EAOSE-084]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-085 | Norm specification, violation and recovery | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-085]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-086 | Belief provenance, revision and observational uncertainty | ASSUMPTION_SENSITIVE | PROPERTY_LEDGER.synthesis_export[EAOSE-086]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-087 | Intention retention and bounded reconsideration | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-087]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-088 | Authorised goal adoption, maintenance and abandonment | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-088]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-089 | Reactive–deliberative arbitration | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-089]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-090 | Negotiation and task-allocation procedure | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-090]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-091 | Interaction identity and authentication | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-091]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-092 | Engineered environment artefacts | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-092]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-093 | Agent, organisation and environment separation | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-093]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-094 | Cross-view and metamodel consistency checking | ASSUMPTION_SENSITIVE | PROPERTY_LEDGER.synthesis_export[EAOSE-094]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-095 | Uncertainty-aware decision and abstention policy | ASSUMPTION_SENSITIVE | PROPERTY_LEDGER.synthesis_export[EAOSE-095]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-096 | Communication uncertainty, correlation and delivery handling | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-096]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-097 | Human participation and effective intervention | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-097]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-098 | Accountability and evidence custody | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-098]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-099 | Non-functional constraints and adverse consequences | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-099]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-100 | Explicit compositional assurance assumptions | ASSUMPTION_SENSITIVE | PROPERTY_LEDGER.synthesis_export[EAOSE-100]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-101 | Scoped reuse of engineering assets | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-101]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-102 | Deployment topology and trust-boundary design | CONTEXT_DEPENDENT | PROPERTY_LEDGER.synthesis_export[EAOSE-102]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-103 | Idempotency and uncertain-effect reconciliation | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-103]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-104 | Resource budgets and termination conditions | RETAINED_IN_EVOLVED_FORM | PROPERTY_LEDGER.synthesis_export[EAOSE-104]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-105 | Mental-state labels establish intelligence | REJECTED_OR_DISFAVOURED | PROPERTY_LEDGER.synthesis_export[EAOSE-105]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-106 | Role prompts alone constitute AOSE | REJECTED_OR_DISFAVOURED | PROPERTY_LEDGER.synthesis_export[EAOSE-106]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-107 | One mandatory methodology fits every agent system | REJECTED_OR_DISFAVOURED | PROPERTY_LEDGER.synthesis_export[EAOSE-107]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-108 | Complete models guarantee correct implementation | REJECTED_OR_DISFAVOURED | PROPERTY_LEDGER.synthesis_export[EAOSE-108]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-109 | ACL syntax guarantees semantic interoperability | REJECTED_OR_DISFAVOURED | PROPERTY_LEDGER.synthesis_export[EAOSE-109]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-110 | Model checking certifies the deployed system without correspondence evidence | REJECTED_OR_DISFAVOURED | PROPERTY_LEDGER.synthesis_export[EAOSE-110]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-111 | Increasing agent count necessarily improves results | REJECTED_OR_DISFAVOURED | PROPERTY_LEDGER.synthesis_export[EAOSE-111]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-112 | Universally exhaustive methodology artefacts | CEREMONY_NOT_GENERAL_PROPERTY | PROPERTY_LEDGER.synthesis_export[EAOSE-112]; DOMAIN_PROFILE and evidence in properties |
| EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-113 | Branch-sensitive method selection restated as a new control | DUPLICATE_CANDIDATE | PROPERTY_LEDGER.synthesis_export[EAOSE-113]; DOMAIN_PROFILE and evidence in properties |

## Adoption and authority boundary

This intake authorises no target mutation, routing, new owner, agent count, repository change or release. A later crosswalk must use actual target evidence and preserve this frozen lineage and denominator. Research readiness means a stable, evidence-qualified corpus and verified handoff, not endorsement of the provisional grouping or a claim that cross-trifecta synthesis has already succeeded.


## Source-link definitions

[EAOSE-S001]: https://www.researchgate.net/publication/222482819_Agent-Oriented_Programming/fulltext/0e603da7f0c46d4f0aa42e1d/Agent-Oriented-Programming.pdf
[EAOSE-S002]: https://www.cs.ox.ac.uk/people/michael.wooldridge/pubs/jaamas2000b.pdf
[EAOSE-S003]: https://www.researchgate.net/publication/225198353_Tropos_An_Agent-Oriented_Software_Development_Methodology
[EAOSE-S004]: https://link.springer.com/article/10.1023/B:AGNT.0000018806.20944.ef
[EAOSE-S005]: https://www.cs.utoronto.ca/~eric/ieeeexp/ieeeexp2.html
[EAOSE-S006]: https://michaelwinikoff.com/wp-content/uploads/2019/05/aamas02-aose-ws.pdf
[EAOSE-S007]: https://www.researchgate.net/publication/220344738_MULTIAGENT_SYSTEMS_ENGINEERING
[EAOSE-S008]: https://www.researchgate.net/publication/220608212_O-MaSE_A_customisable_approach_to_designing_and_building_complex_adaptive_multi-agent_systems
[EAOSE-S009]: https://ceur-ws.org/Vol-627/fipa_5.pdf
[EAOSE-S010]: https://winikoff.github.io/pdf/aois2003.pdf
[EAOSE-S011]: https://ceur-ws.org/Vol-627/fipa_6.pdf
[EAOSE-S012]: https://lia.disi.unibo.it/~ao/pubs/pdf/volumes/eumas2006/Republications/15.pdf
[EAOSE-S013]: https://www.researchgate.net/publication/237490469_From_Requirements_to_Code_with_the_PASSI_Methodology
[EAOSE-S014]: https://www.cs.ox.ac.uk/people/michael.wooldridge/pubs/aose2000a.pdf
[EAOSE-S015]: https://www.cs.ox.ac.uk/people/michael.wooldridge/pubs/agents98.pdf
[EAOSE-S016]: https://onlinelibrary.wiley.com/doi/abs/10.1002/9780470050118.ecse006
[EAOSE-S017]: https://emas.in.tu-clausthal.de/
[EAOSE-S018]: https://emas-workshop.github.io/2026/
[EAOSE-S019]: https://aamas.csc.liv.ac.uk/Proceedings/aamas2026/forms/contents.htm
[EAOSE-S020]: https://arxiv.org/html/2006.08820v1
[EAOSE-S021]: https://doi.org/10.1145/367211.367250
[EAOSE-S022]: https://doi.org/10.1145/958961.958963
[EAOSE-S023]: https://www.csc2.ncsu.edu/faculty/mpsingh/papers/mas/computer-acl-98.pdf
[EAOSE-S024]: https://jmvidal.cse.sc.edu/822/papers/Rep_Agent_Protocols.pdf
[EAOSE-S025]: https://ppgia.pucpr.br/~fabricio/ftp/Aulas/Mestrado/AS/Aula3/SC00061G_FIPA_ACL.pdf
[EAOSE-S026]: https://www.chrismitchell.net/sfac.pdf
[EAOSE-S027]: https://arxiv.org/html/2203.00086v1
[EAOSE-S028]: https://www.ifaamas.org/Proceedings/aamas2025/pdfs/p2426.pdf
[EAOSE-S029]: https://intranet.csc.liv.ac.uk/~matt/pubs/mcapl11.pdf
[EAOSE-S030]: https://www.ijcai.org/Proceedings/15/Papers/599.pdf
[EAOSE-S031]: https://www.ifaamas.org/Proceedings/aamas2017/pdfs/p260.pdf
[EAOSE-S032]: https://arxiv.org/html/2108.08117v1
[EAOSE-S033]: https://helios2.mi.parisdescartes.fr/~moraitis/webpapers/Moraitis-IJAOSE22.pdf
[EAOSE-S034]: https://www.researchgate.net/publication/225470190_An_Empirical_Evaluation_of_the_i_Framework_in_a_Model-Based_Software_Generation_Environment
[EAOSE-S035]: https://arxiv.org/html/2503.13657v3
[EAOSE-S036]: https://arxiv.org/html/2407.01502v1
[EAOSE-S037]: https://pure.manchester.ac.uk/ws/files/1825510647/EMAS2025_Roadmap.pdf
[EAOSE-S038]: https://www.eecis.udel.edu/~decker/courses/889a/daimler.pdf
[EAOSE-S039]: https://www.researchgate.net/publication/216702294_ASPECS_an_Agent-oriented_Software_Process_for_Engineering_Complex_Systems_How_to_design_agent_societies_under_a_holonic_perspective
[EAOSE-S040]: https://lia.disi.unibo.it/corsi/2007-2008/SMA-LS/papers/9/bernon2004a.pdf
[EAOSE-S041]: https://arxiv.org/html/2406.12045v1
[EAOSE-S042]: https://arxiv.org/html/2406.13352v1
[EAOSE-S043]: https://webspace.science.uu.nl/~dalpi001/papers/ali-chop-dalp-gior-mylo-souz-10-istar.pdf
[EAOSE-S044]: https://emas-workshop.github.io/2026/papers/041_ARARA_A_LLM-based_Multi-Agent_Development_Framework_for_Conv.pdf
[EAOSE-S045]: https://emas-workshop.github.io/2026/papers/015_Ex-Plan_Explaining_BDI_Agent_Behaviour_Through_Contrastive_P.pdf
[EAOSE-S046]: https://www.ifaamas.org/Proceedings/aamas2018/pdfs/p2054.pdf
[EAOSE-S047]: https://www.jot.fm/issues/issue_2010_07/article5.pdf
[EAOSE-S048]: https://www.researchgate.net/publication/2713293_Analysis_and_design_of_multiagent_systems_using_MAS-CommonKADS
[EAOSE-S049]: https://www.researchgate.net/publication/47529129_SECURE_TROPOS_A_SECURITY-ORIENTED_EXTENSION_OF_THE_TROPOS_METHODOLOGY
[EAOSE-S050]: https://arxiv.org/html/2006.05619v1
[EAOSE-S051]: https://arxiv.org/html/2205.00979v2
[EAOSE-S052]: https://www.ifaamas.org/Proceedings/aamas08/proceedings/pdf/industrial_application_track/AAMAS08_IndTrack_16.pdf
[EAOSE-S053]: https://faculty.sites.iastate.edu/tesfatsi/archive/tesfatsi/jennings.pdf
[EAOSE-S054]: https://www.researchgate.net/publication/221419145_A_Goal-Oriented_Software_Testing_Methodology
[EAOSE-S055]: https://ii.tudelft.nl/~joostb/files/mates2010_final.pdf
[EAOSE-S056]: https://ai.jpl.nasa.gov/public/documents/papers/rax-results-isairas99.pdf
[EAOSE-S057]: https://arxiv.org/html/2304.03442v2
[EAOSE-S058]: https://sourceforge.net/projects/ingenias/files/INGENIAS%20Development%20Kit/
[EAOSE-S059]: https://sourceforge.net/projects/ptk/
[EAOSE-S060]: https://github.com/ls-cnr/AgentFactory
[EAOSE-S061]: https://ifaamas.org/Proceedings/aamas2012/papers/3F_4.pdf
[EAOSE-S062]: https://www.ijcai.org/Proceedings/73/Papers/027B.pdf
[EAOSE-S063]: https://cdn.aaai.org/ICMAS/1995/ICMAS95-042.pdf
[EAOSE-S064]: https://link.springer.com/chapter/10.1007/BFb0031846
[EAOSE-S065]: https://www.reidgsmith.com/The_Contract_Net_Protocol_Dec-1980.pdf
[EAOSE-S066]: https://jmvidal.cse.sc.edu/library/cohen90a.pdf
[EAOSE-S067]: https://www.researchgate.net/publication/251518239_Multi-agent_oriented_programming_with_JaCaMo
[EAOSE-S068]: https://www.researchgate.net/publication/221456372_MOISE_Towards_a_Structural_Functional_and_Deontic_model_for_MAS_organization
[EAOSE-S069]: https://mmi.tudelft.nl/pub/koen/GOAL_JAL.pdf
[EAOSE-S070]: https://www.ifaamas.org/Proceedings/aamas2014/aamas/p933.pdf
[EAOSE-S071]: https://www.ijcai.org/proceedings/2017/0065.pdf
[EAOSE-S072]: https://www.staff.science.uu.nl/~dalpi001/papers/mora-dalp-nguy-sien-14-aose.pdf
[EAOSE-S073]: https://www.emse.fr/~boissier/enseignement/defiia/up5/pdf/Bratman-PlansPracticalResoning.pdf
[EAOSE-S074]: https://maxapress.com/data/article/ker/preview/pdf/S026988891800005X.pdf
[EAOSE-S075]: https://arxiv.org/html/2308.08155v2
[EAOSE-S076]: https://arxiv.org/html/2308.00352v6
[EAOSE-S077]: https://arxiv.org/html/2307.07924v5
[EAOSE-S078]: https://arxiv.org/html/2210.03629v3
[EAOSE-S079]: https://docs.langchain.com/oss/python/langgraph/persistence
[EAOSE-S080]: https://docs.langchain.com/oss/python/langgraph/interrupts
[EAOSE-S081]: https://microsoft.github.io/autogen/stable/user-guide/agentchat-user-guide/tutorial/termination.html
[EAOSE-S082]: https://cdn.aaai.org/ICMAS/1996/ICMAS96-005.pdf
[EAOSE-S083]: https://www.cs.vu.nl/~wai/Papers/IJCIS97.DESIRE10.pdf
[EAOSE-S084]: https://conf.researchr.org/home/icse-2026/agent-2026
[EAOSE-S085]: https://emas.in.tu-clausthal.de/2025/assets/pdfs/emas2025-14.pdf
[EAOSE-S086]: https://link.springer.com/chapter/10.1007/978-3-032-18011-7_12
[EAOSE-S087]: https://www.cs.toronto.edu/~jenhork/Papers/Horkoff_PoEM_2009l.pdf
[EAOSE-S088]: https://aamas.csc.liv.ac.uk/Proceedings/aamas2026/pdfs/SAXY3841.pdf
[EAOSE-S089]: https://aamas.csc.liv.ac.uk/Proceedings/aamas2026/pdfs/SEJS3352.pdf
[EAOSE-S090]: https://aamas.csc.liv.ac.uk/Proceedings/aamas2026/pdfs/ZIQG2381.pdf
