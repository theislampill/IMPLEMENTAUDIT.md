# EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_AUDIT_INTAKE

Revision EAOSE-R1-2026-09-07. Cut-off 2026-09-07. Frozen population: **113**; examined: **113/113**; mandatory families unexamined: **0**. This is an intake for a later audit of an unspecified real system, not an assessment of any repository or an authorisation to mutate one.

## Decision contract

For each candidate, legitimate outcomes include **already addressed**, **inapplicable**, **a simpler mechanism is sufficient**, **evidence insufficient**, or **a contextually warranted gap**. A property is not a mandate for a named tool, dedicated owner, artefact or agent. Audit the mature mechanism under its actual trigger and assumptions. Counterclaims and duplicate records are not additional controls.

Provenance and formal validity are not comparative effectiveness. Classroom/model examples are not field deployment. DS1 supplies specific operational evidence; Daimler is a prototype. Related editions and repeated cases do not establish replication. The source table gives claim-specific access, empirical units and formal assumptions. Whole-method net benefit remains EAOSE-061 (UNRESOLVED).

The exact earlier count-only 66-row roster remains unrecovered. This intake uses the reconciled 113-candidate corpus, not a claim of exact archival restoration. Complete common fields, ten-dimensional profiles, sources, criticisms and relations resolve in [EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) and [EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_SOURCE_TABLE.json](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_SOURCE_TABLE.json).

## Disposition accounting

| Disposition | Count |
| --- | --- |
| ASSUMPTION_SENSITIVE | 13 |
| CEREMONY_NOT_GENERAL_PROPERTY | 2 |
| CONTESTED | 1 |
| CONTEXT_DEPENDENT | 26 |
| DOMAIN_SPECIFIC | 2 |
| DUPLICATE_CANDIDATE | 3 |
| NO_GENERAL_PROPERTY | 1 |
| REJECTED_OR_DISFAVOURED | 14 |
| RETAINED_IN_EVOLVED_FORM | 30 |
| STRONGLY_RETAINED | 18 |
| SUPERSEDED_BY_STRONGER_FORM | 1 |
| UNRESOLVED | 1 |
| USEFUL_BUT_EASILY_BUREAUCRATISED | 1 |

## Every crosswalk-worthy candidate

### EAOSE-001 — Affected-stakeholder validation

**Status:** STRONGLY_RETAINED. **Mature form:** Elicit and challenge the set of affected actors, including people who do not operate or purchase the system; validate goals with those actors or explicitly qualified representatives.

**Controlled failure:** A complete diagram can omit an affected non-user; consultation can be tokenistic.

**Trigger:** Several parties can be helped, harmed or made dependent by the system. **Non-trigger / cheap path:** For a genuinely single-party local task, a short agreed requirement and counterexample review can replace an actor diagram.

**Prerequisites and consumer:** Access to affected parties or a disclosed representation limit; a boundary that can be revised. Requirements engineer and affected participants; the sponsor cannot silently speak for all parties.

**Evidence needed:** A challenged actor inventory and acceptance criteria expose omissions and unresolved disagreement. **Evidence boundary:** Retained as a strong engineering distinction within its trigger; the strength is not a claim of universally strong comparative field evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-001].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C01; A complete diagram can omit an affected non-user; consultation can be tokenistic. **Conflicts/tensions:** T01.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire a separate actor model when the same validated concerns are maintained in a cheaper live requirements representation.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S003] [EAOSE-S005] [EAOSE-S034] [EAOSE-S043]

### EAOSE-002 — Dependency vulnerability and accountability

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Describe each material dependence by depender, dependee, needed result/resource and exposure if it is not delivered; connect failure to a decision or fallback.

**Controlled failure:** Dependency pictures can be mistaken for enforceable commitments or universal accountability.

**Trigger:** Requirements depend on another actor's cooperation, availability or resources. **Non-trigger / cheap path:** An ordinary interface contract is sufficient when it names the real dependency and its failure response.

**Prerequisites and consumer:** Identifiable actors and dependent result; no assumption that a dependency creates a promise. Requirements/design participants exchange dependency and vulnerability information; the dependee must accept any proposed commitment.

**Evidence needed:** A dependency failure can be traced to affected goals and an authorised response, rather than an unexplained broken edge. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-002].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C01; Dependency pictures can be mistaken for enforceable commitments or universal accountability. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Drop a dedicated dependency artefact when no consequential dependence remains or its information has a maintained consumer elsewhere.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S003] [EAOSE-S005] [EAOSE-S043]

### EAOSE-003 — Goal-to-acceptance operationalisation

**Status:** STRONGLY_RETAINED. **Mature form:** Translate selected stakeholder objectives into observable acceptance and prohibited-outcome conditions; challenge AND/OR refinements as hypotheses about sufficiency.

**Controlled failure:** Good measurable proxies may omit consent, harm or long-term effects; goal satisfaction can be gamed.

**Trigger:** A system is to be accepted as satisfying a stakeholder goal. **Non-trigger / cheap path:** A small executable example plus a human acceptance decision may suffice; not every concern needs a formal goal tree.

**Prerequisites and consumer:** A declared observer, relevant environment and criterion; stakeholder authority for trade-offs. Stakeholders author/approve the acceptance meaning; testers produce evidence; implementers cannot redefine success after a failure.

**Evidence needed:** Accepted evidence distinguishes a completed local action from achievement of the intended goal. **Evidence boundary:** Retained as a strong engineering distinction within its trigger; the strength is not a claim of universally strong comparative field evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-003].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C01, C12; Good measurable proxies may omit consent, harm or long-term effects; goal satisfaction can be gamed. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire a derived metric if it no longer represents the goal; retain or replace the underlying acceptance question.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S003] [EAOSE-S054] [EAOSE-S041]

### EAOSE-004 — Goal conflict and alternative analysis

**Status:** CONTEXT_DEPENDENT. **Mature form:** Expose conflicting goals and compare feasible alternatives under explicit priorities, hard constraints and uncertainty; revise choices when those assumptions change.

**Controlled failure:** Uncalibrated softgoal links can masquerade as quantitative evidence; hidden weights predetermine the outcome.

**Trigger:** Different actors or qualities cannot all be maximised together. **Non-trigger / cheap path:** Direct stakeholder choice is cheaper when a single transparent trade-off suffices.

**Prerequisites and consumer:** A legitimate preference/constraint source; alternatives not restricted to the designer's favourite architecture. Affected stakeholders decide protected values; analysts communicate consequences and uncertainty.

**Evidence needed:** The selected option and reasons change intelligibly when a material preference or feasibility premise changes. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-004].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C01; Uncalibrated softgoal links can masquerade as quantitative evidence; hidden weights predetermine the outcome. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Omit elaborate ranking after a binding constraint makes only one adequately justified option feasible.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S003] [EAOSE-S005] [EAOSE-S043] [EAOSE-S034]

### EAOSE-005 — Delegation distinguished from authority

**Status:** STRONGLY_RETAINED. **Mature form:** Separate a request, an assignment, a commitment and an authorisation; check who can create, transfer or revoke obligations and operational powers.

**Controlled failure:** Mental intention, capability and normative obligation can each be mistaken for permission.

**Trigger:** One actor acts or promises on behalf of another. **Non-trigger / cheap path:** A direct approved call inside one trust boundary may avoid a delegation protocol while retaining permission checks.

**Prerequisites and consumer:** Identified principal and scope; externally meaningful authority, not merely a role label. Principal grants or withholds powers; delegate acts within scope; counterpart receives the public obligation where relevant.

**Evidence needed:** An action or obligation can be linked to valid standing, scope and revocation state. **Evidence boundary:** Retained as a strong engineering distinction within its trigger; the strength is not a claim of universally strong comparative field evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-005].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C04, C20, C25; Mental intention, capability and normative obligation can each be mistaken for permission. **Conflicts/tensions:** T12.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Remove delegated credentials and transfer/discharge live obligations when delegation ends.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S023] [EAOSE-S049] [EAOSE-S041] [EAOSE-S050]

### EAOSE-006 — Requirements-to-behaviour traceability

**Status:** USEFUL_BUT_EASILY_BUREAUCRATISED. **Mature form:** Maintain decision-relevant links among requirements, design choices, implementation and evidence, including non-identity mappings and rejected alternatives.

**Controlled failure:** Stale or mechanically generated links can create expensive false assurance.

**Trigger:** Changes or acceptance decisions require knowing which implemented behaviour supports which concern. **Non-trigger / cheap path:** A compact requirement-to-test mapping may replace a traceability tool or exhaustive graph.

**Prerequisites and consumer:** Stable referenceable artefacts and an actual change/acceptance consumer. Engineers maintain links that testers and operators use; link creation cannot certify link truth.

**Evidence needed:** A changed requirement identifies potentially affected behaviour/evidence and unexplained gaps. **Evidence boundary:** Useful traceability can become bureaucracy if links are stale or lack a real decision consumer.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-006].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C09; Stale or mechanically generated links can create expensive false assurance. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire unused links whose risk or consumer disappears; preserve remaining warranted correspondences.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S003] [EAOSE-S007] [EAOSE-S054] [EAOSE-S052] [EAOSE-S032]

### EAOSE-007 — Agent-paradigm suitability decision

**Status:** STRONGLY_RETAINED. **Mature form:** Compare agent and non-agent designs against fixed needs, control distribution, interaction, adaptation, expertise and cost; retain an ordinary-software exit.

**Controlled failure:** Benchmarks may conflate extra computation, different tools and multiple agents; autonomy adds coordination burden.

**Trigger:** An agent abstraction or extra autonomous participant is proposed. **Non-trigger / cheap path:** Use objects, services, actors, a workflow or a central controller when they satisfy the needs more simply.

**Prerequisites and consumer:** Comparable requirements and explicit implementation/operating assumptions. Architect and stakeholders decide; framework availability does not decide suitability.

**Evidence needed:** The chosen agent boundary has a stated advantage or necessity, or the non-agent alternative is selected. **Evidence boundary:** Retained as a strong engineering distinction within its trigger; the strength is not a claim of universally strong comparative field evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-007].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C02; Benchmarks may conflate extra computation, different tools and multiple agents; autonomy adds coordination burden. **Conflicts/tensions:** T02, T14.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Revisit when requirements, trust distribution or available simpler mechanisms change; no recurring ceremony absent such a trigger.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S015] [EAOSE-S053] [EAOSE-S036] [EAOSE-S044]

### EAOSE-008 — Agent-oriented analysis without mandatory agent runtime

**Status:** CONTEXT_DEPENDENT. **Mature form:** Use actor/goal/dependency analysis as an engineering view without forcing those actors into autonomous runtime agents.

**Controlled failure:** Agent terminology can obscure an ordinary service design; dropping the runtime can also lose genuinely needed autonomy.

**Trigger:** Social requirements are useful but runtime autonomy is unnecessary or unsuitable. **Non-trigger / cheap path:** A conventional requirements method may suffice if it captures the same dependency and responsibility distinctions.

**Prerequisites and consumer:** A mapping from conceptual actors to actual people/software, not a one-to-one identity assumption. Requirements analysts supply intent; implementers choose a justified execution architecture.

**Evidence needed:** Stakeholder concepts remain traceable in a conventional implementation without invented agent processes. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-008].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** record-specific objection; Agent terminology can obscure an ordinary service design; dropping the runtime can also lose genuinely needed autonomy. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Discard agent-specific notation if it adds no distinction beyond the maintained conventional model.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S003] [EAOSE-S048] [EAOSE-S015]

### EAOSE-009 — Explicit autonomy and refusal boundaries

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Specify which decisions are delegated to the component, which it may refuse or defer, and which require another actor; distinguish autonomy from unrestricted power.

**Controlled failure:** An autonomy declaration can be unenforced; refusal can cause liveness failure if no fallback exists.

**Trigger:** A component selects actions rather than merely executing an already approved sequence. **Non-trigger / cheap path:** Deterministic constrained execution is sufficient when discretion contributes no value.

**Prerequisites and consumer:** Principal-approved scope, bounded resources and enforceable action interfaces. Principal sets bounds; agent chooses within them; operator handles escalation outside them.

**Evidence needed:** Tests show both permitted discretion and refusal/escalation on out-of-scope requests. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-009].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C02; An autonomy declaration can be unenforced; refusal can cause liveness failure if no fallback exists. **Conflicts/tensions:** T02.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Reduce autonomy when its benefit disappears; retire obsolete discretionary permissions.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S001] [EAOSE-S015] [EAOSE-S053] [EAOSE-S041] [EAOSE-S042]

### EAOSE-012 — Role responsibilities, permissions, activities and protocols

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Model a role's responsibilities, permissions, activities and interactions distinctly, and retain their relationship when allocating implementation agents.

**Controlled failure:** A named role can be mistaken for enforcement; permissions can be confused with capabilities.

**Trigger:** Recurring organisational responsibilities need explicit engineering interpretation. **Non-trigger / cheap path:** A small interface/responsibility record can carry the same semantics without the Gaia notation.

**Prerequisites and consumer:** A chosen organisational model and explicit safety/liveness meaning; original Gaia's stable-cooperative scope must be checked. Designers propose roles; principals authorise permissions; implementers realise activities and protocols.

**Evidence needed:** Each role obligation has a plausible implementation, interaction and authority basis. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-012].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C03; A named role can be mistaken for enforcement; permissions can be confused with capabilities. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire roles that no longer distinguish responsibilities; merge representations without erasing still-live obligations.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S002] [EAOSE-S007] [EAOSE-S008]

### EAOSE-013 — Effective capability and permission checks

**Status:** STRONGLY_RETAINED. **Mature form:** Check both the practical ability and current permission to perform a consequential operation at the point of use.

**Controlled failure:** Design-time permissions may be stale; valid credentials do not prove competence or successful effects.

**Trigger:** A role or agent may be allocated work it cannot or may no longer perform. **Non-trigger / cheap path:** A conventional access-control and capability check may suffice; no specialised agent registry is required.

**Prerequisites and consumer:** Known operation/resource scope; current credentials and resource availability. Resource owner authorises; scheduler/agent checks capability; enforcement belongs at the effectful interface.

**Evidence needed:** An incapable or unauthorised actor is not silently treated as a valid fulfiller. **Evidence boundary:** Retained as a strong engineering distinction within its trigger; the strength is not a claim of universally strong comparative field evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-013].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C04; Design-time permissions may be stale; valid credentials do not prove competence or successful effects. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Revoke obsolete powers and remove capability declarations when the resource or actor is retired.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S008] [EAOSE-S049] [EAOSE-S041] [EAOSE-S050]

### EAOSE-014 — Many-to-many role-to-agent allocation

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Treat role-to-agent allocation as an explicit many-to-many mapping, with replication and multi-role conflicts analysed rather than assuming one role per process.

**Controlled failure:** Replicated role holders can perform the same external action twice or hold inconsistent commitments.

**Trigger:** One agent fulfils several roles or several agents may fulfil one role. **Non-trigger / cheap path:** A one-to-one mapping is acceptable when justified; no replication is required.

**Prerequisites and consumer:** Responsibilities and shared-state/effect semantics must remain coherent under the allocation. Organisational designer and implementer agree allocation; resource owner controls exclusive effects.

**Evidence needed:** Responsibilities are neither lost nor accidentally duplicated by implementation cardinality. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-014].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C03; Replicated role holders can perform the same external action twice or hold inconsistent commitments. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Simplify the mapping when scale or fault tolerance no longer warrants multiple holders.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S002] [EAOSE-S008] [EAOSE-S052]

### EAOSE-015 — Collective safety and liveness obligations

**Status:** ASSUMPTION_SENSITIVE. **Mature form:** Express collective safety and progress obligations and identify scheduling, fairness, cooperation and resource assumptions needed to obtain them.

**Controlled failure:** Deadlock, starvation and strategic non-cooperation can invalidate liveness despite locally correct code.

**Trigger:** Correct local agents do not by themselves establish a required system-level property. **Non-trigger / cheap path:** A central invariant or simpler serial execution may discharge the obligation more cheaply.

**Prerequisites and consumer:** Defined global property, observable state and non-circular assumptions about agents/environment. System designer owns the collective claim; individual agents supply only their local guarantees.

**Evidence needed:** Evidence addresses the stated global invariant or progress condition under declared assumptions. **Evidence boundary:** The mechanism or guarantee depends materially on declared semantics, models or environmental assumptions; transferring it needs additional evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-015].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C03; Deadlock, starvation and strategic non-cooperation can invalidate liveness despite locally correct code. **Conflicts/tensions:** T13.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Remove a global control only when the underlying shared hazard/progress dependency disappears or is discharged by a simpler design.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S002] [EAOSE-S038] [EAOSE-S029]

### EAOSE-016 — Capability-constrained dynamic organisation

**Status:** CONTEXT_DEPENDENT. **Mature form:** Permit organisational reconfiguration only through capability-, goal- and constraint-aware reassignment and explicit admission/departure rules.

**Controlled failure:** Thrashing, temporary coverage gaps and inconsistent memberships may defeat the intended adaptation.

**Trigger:** Membership, resources or responsibilities change at runtime. **Non-trigger / cheap path:** Keep a stable organisation when changes are rare and a controlled redeployment is cheaper.

**Prerequisites and consumer:** A method supporting change, current capabilities, preserved obligations and a justified transition protocol. Authorised organisational controller or participating principals approve changes; not every agent has reorganisation rights.

**Evidence needed:** A reconfiguration leaves each live obligation fulfilled, transferred or explicitly unresolved. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-016].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C03; Thrashing, temporary coverage gaps and inconsistent memberships may defeat the intended adaptation. **Conflicts/tensions:** T06.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Disable automated reorganisation when stable manual change meets the need more safely or cheaply.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S008] [EAOSE-S002]

### EAOSE-017 — Explicit environment and effect interfaces

**Status:** STRONGLY_RETAINED. **Mature form:** Define observations, hidden/environmental state, action interfaces and effect feedback at the engineering boundary.

**Controlled failure:** A perfect internal model may still have wrong sensors, stale state or unmodelled effects.

**Trigger:** The system interacts with an independently changing software or physical environment. **Non-trigger / cheap path:** A narrow input/output contract is sufficient for an isolated deterministic computation.

**Prerequisites and consumer:** Relevant environment assumptions and a means to observe consequential effects or record uncertainty. Environment/resource owner defines affordances; agent observes and acts only through available interfaces.

**Evidence needed:** The engineer can distinguish stale belief, attempted action and observed external change. **Evidence boundary:** Retained as a strong engineering distinction within its trigger; the strength is not a claim of universally strong comparative field evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-017].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** record-specific objection; A perfect internal model may still have wrong sensors, stale state or unmodelled effects. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire unused environment detail; retain every interface needed to discriminate consequential failure.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S006] [EAOSE-S008] [EAOSE-S056] [EAOSE-S029] [EAOSE-S051]

### EAOSE-018 — Holonic decomposition

**Status:** DOMAIN_SPECIFIC. **Mature form:** Decompose a selected complex organisation into holons with explicit levels, internal organisation and external responsibilities.

**Controlled failure:** Hierarchy can duplicate authority, add communication cost or obscure cross-cutting interactions.

**Trigger:** Recursive organisational units genuinely simplify a system's structure or scaling problem. **Non-trigger / cheap path:** Flat roles, modules or services are sufficient when hierarchy adds no useful boundary.

**Prerequisites and consumer:** An ASPECS-like holonic model and consistent responsibilities across levels. Architect chooses hierarchy; each level must have real functional and authority meaning.

**Evidence needed:** Cross-level responsibilities remain explicit rather than hidden by nesting. **Evidence boundary:** Preserved for its specific domain/assumption class, not exported as a universal obligation.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-018].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C03; Hierarchy can duplicate authority, add communication cost or obscure cross-cutting interactions. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Flatten a level when it has no independent obligation, decision or encapsulation purpose.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S039] [EAOSE-S015]

### EAOSE-019 — Interaction contract with defined semantics

**Status:** STRONGLY_RETAINED. **Mature form:** Specify permitted communicative acts, information/state transitions and externally assessable interaction meaning, then relate them to local behaviour.

**Controlled failure:** UML notation, prose and message envelopes can each be syntactically correct yet semantically incompatible.

**Trigger:** Multiple independently implemented participants must interoperate or coordinate. **Non-trigger / cheap path:** A simple typed API with explicit pre/postconditions may suffice.

**Prerequisites and consumer:** Chosen protocol semantics, failure model and counterpart agreement. Protocol designers and participating principals agree meaning; implementers realise it without silently changing obligations.

**Evidence needed:** Exchanged messages and actions can be checked against the specified interaction, including unexpected paths. **Evidence boundary:** Retained as a strong engineering distinction within its trigger; the strength is not a claim of universally strong comparative field evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-019].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C05; UML notation, prose and message envelopes can each be syntactically correct yet semantically incompatible. **Conflicts/tensions:** T04.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire protocol machinery when one accountable component can satisfy the same interaction need directly.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S007] [EAOSE-S023] [EAOSE-S024] [EAOSE-S088] [EAOSE-S025] [EAOSE-S052]

### EAOSE-020 — Content and ontology alignment

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Align referents, units, data interpretation and ontology versions in addition to transport and message syntax.

**Controlled failure:** Identical field names may encode different units, identities or commitments.

**Trigger:** Heterogeneous agents exchange content whose meanings can differ. **Non-trigger / cheap path:** An agreed small schema and worked examples may replace a large ontology.

**Prerequisites and consumer:** Shared domain interpretation and handling of unknown/changed terms. Domain experts and counterpart engineers agree meanings; senders cannot impose interpretation merely by a field name.

**Evidence needed:** The same exchanged values denote compatible entities and constraints at both ends. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-020].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C05; Identical field names may encode different units, identities or commitments. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire unused vocabulary and mappings while preserving live protocol compatibility.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S025] [EAOSE-S023] [EAOSE-S026]

### EAOSE-021 — Observable social commitments

**Status:** CONTEXT_DEPENDENT. **Mature form:** Model public conditional commitments between principals with explicit creation, discharge, cancellation and violation semantics.

**Controlled failure:** Recording an obligation does not enforce it or guarantee successful performance; modification may be costly.

**Trigger:** Independent parties need assessable obligations without exposing or trusting each other's private mental state. **Non-trigger / cheap path:** A conventional contract/state record may be adequate where its semantics and lifecycle are clear.

**Prerequisites and consumer:** Identified parties, public events/conditions and agreed institutional meaning. A principal incurs an obligation through an authorised act; counterpart and monitors assess its public lifecycle.

**Evidence needed:** Participants can assess whether the defined commitment holds, is discharged or is violated. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-021].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C04; Recording an obligation does not enforce it or guarantee successful performance; modification may be costly. **Conflicts/tensions:** T07.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Discharge or validly transfer commitments before retirement; omit a dedicated commitment calculus for simple closed interactions.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S023] [EAOSE-S043] [EAOSE-S027]

### EAOSE-023 — Local protocol conformance and information causality

**Status:** ASSUMPTION_SENSITIVE. **Mature form:** Check local enactments against information-causality and protocol constraints, including adapters that realise declared communications on a selected infrastructure.

**Controlled failure:** Correct local message causality does not ensure cooperation, authorisation, delivery fairness or business success.

**Trigger:** Protocol participants act asynchronously or use different implementation platforms. **Non-trigger / cheap path:** Direct shared-state or ordinary request-response implementation can suffice if its semantics discharge the same obligations.

**Prerequisites and consumer:** Well-defined protocol, keys, bindings and adapter semantics; correspondence to actual messages. Each participant controls its local behaviour; a protocol adapter constrains only its specified layer.

**Evidence needed:** Local traces obey the relevant dependencies; unresolved global or external-effect claims remain separate. **Evidence boundary:** The mechanism or guarantee depends materially on declared semantics, models or environmental assumptions; transferring it needs additional evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-023].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C05; Correct local message causality does not ensure cooperation, authorisation, delivery fairness or business success. **Conflicts/tensions:** T04.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Omit specialised protocol adapters when a simpler verified interface meets the same semantics.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S027] [EAOSE-S028] [EAOSE-S088] [EAOSE-S023]

### EAOSE-024 — Explicit dynamic role binding

**Status:** CONTEXT_DEPENDENT. **Mature form:** Bind protocol roles to concrete principals explicitly, including rebinding and lifetime rules rather than fixing unknown participants implicitly.

**Controlled failure:** A role name alone may hide impersonation, stale binding or orphaned obligations.

**Trigger:** Open protocols admit participants dynamically or continue across replacements. **Non-trigger / cheap path:** Static named participants are sufficient in a genuinely closed stable system.

**Prerequisites and consumer:** Identity and protocol instance scope; valid transfer of live obligations and information dependencies. Participating principals or authorised organisational service establish the binding.

**Evidence needed:** Each message/commitment is attributable to the role holder valid for that instance and time. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-024].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C05; A role name alone may hide impersonation, stale binding or orphaned obligations. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire dynamic binding machinery when membership is fixed and lifecycle transfer is unnecessary.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S027] [EAOSE-S008]

### EAOSE-025 — Fault, timeout and compensation semantics

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Define distinct responses to failure, timeout and ambiguous outcome, including bounded retry, compensation, reconciliation or human escalation.

**Controlled failure:** Blind retries duplicate effects; compensation may be irreversible, unauthorised or insufficient.

**Trigger:** Actions or interactions may fail, partially succeed or remain unobserved. **Non-trigger / cheap path:** A fail-fast result is sufficient when no external partial effect or live obligation remains.

**Prerequisites and consumer:** Failure semantics, effect visibility and authority for compensation; timeout is not proof no effect occurred. Executor reports uncertainty; resource owner authorises compensating action; operator resolves unobservable outcomes.

**Evidence needed:** A failure ends in a known safe/accepted state, a transferred obligation or explicitly unresolved status. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-025].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C05; Blind retries duplicate effects; compensation may be irreversible, unauthorised or insufficient. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire recovery paths only when the corresponding failure mode is eliminated or handled at another proved boundary.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S007] [EAOSE-S056] [EAOSE-S052] [EAOSE-S041]

### EAOSE-026 — Protocol evolution and mixed-version compatibility

**Status:** CONTEXT_DEPENDENT. **Mature form:** Version interaction semantics and manage compatibility while old and new participants or live protocol instances coexist.

**Controlled failure:** Syntactic schema compatibility may hide changed obligations or cancellation semantics.

**Trigger:** A protocol/schema changes without stopping every participant and obligation. **Non-trigger / cheap path:** Stop, drain and redeploy a small closed system when live migration adds unnecessary risk.

**Prerequisites and consumer:** Version identity, compatibility rules and treatment of in-flight state. Counterparts agree evolution; deployers cannot silently reinterpret prior commitments.

**Evidence needed:** Mixed versions either interoperate within declared rules or fail/transition explicitly. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-026].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C05, C15; Syntactic schema compatibility may hide changed obligations or cancellation semantics. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Remove compatibility support only after old instances and dependent participants are retired or migrated.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S032] [EAOSE-S050] [EAOSE-S052]

### EAOSE-027 — BDI internal design where deliberation warrants it

**Status:** CONTEXT_DEPENDENT. **Mature form:** Use beliefs, goals, plans and intentions as internal design concepts when persistent deliberation and alternative means are useful.

**Controlled failure:** Calling text a belief or a plan does not implement BDI semantics; deliberation increases assurance complexity.

**Trigger:** A component must choose among plans and persist or reconsider under changing observations. **Non-trigger / cheap path:** A finite-state controller, rule set or workflow may be easier when deliberation is unnecessary.

**Prerequisites and consumer:** A selected BDI semantics, perception/action interface and justified goal authority. Engineer designs deliberation; principal supplies legitimate objectives; agent chooses permitted means.

**Evidence needed:** Plan choice and goal/intentional state can be related to implementation and tests. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-027].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C06; Calling text a belief or a plan does not implement BDI semantics; deliberation increases assurance complexity. **Conflicts/tensions:** T07.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire BDI machinery when simpler control supplies equivalent required behaviour with lower cost.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S001] [EAOSE-S006] [EAOSE-S046] [EAOSE-S030] [EAOSE-S031]

### EAOSE-028 — Explicit plan failure and goal persistence semantics

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Specify plan applicability, failure propagation, fallback and persistence of the underlying goal rather than equating one failed plan with goal abandonment.

**Controlled failure:** Platform migration can change XOR, context and maintenance-goal semantics even when names match.

**Trigger:** An agent has alternative means or long-lived goals under uncertain action outcomes. **Non-trigger / cheap path:** A single explicit error return is enough for a one-shot operation with no continuing goal.

**Prerequisites and consumer:** Language-specific failure and goal semantics; available fallback and bounded retries. Agent runtime handles plan events; principal or permitted policy decides abandoning the goal.

**Evidence needed:** Tests distinguish plan failure, alternative-plan selection, goal success and authorised abandonment. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-028].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C06; Platform migration can change XOR, context and maintenance-goal semantics even when names match. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Remove obsolete fallbacks when their failure conditions or resources no longer exist.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S046] [EAOSE-S006] [EAOSE-S030] [EAOSE-S052]

### EAOSE-029 — Capability and plan modularity

**Status:** CONTEXT_DEPENDENT. **Mature form:** Encapsulate related plans/capabilities with explicit interfaces and controlled access to context, events and goal reasoning.

**Controlled failure:** Encapsulation can hide relevant failure assumptions or induce duplicated belief state.

**Trigger:** Large BDI code bases or reused capabilities have hidden coupling. **Non-trigger / cheap path:** A small readable plan library may need no extra module layer.

**Prerequisites and consumer:** Clear interface and scope of beliefs/events; compatibility with runtime selection and failure semantics. Capability author defines interface; caller must satisfy preconditions rather than reach into hidden state.

**Evidence needed:** Changes within a module do not silently alter unrelated goal selection or failure behaviour. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-029].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** record-specific objection; Encapsulation can hide relevant failure assumptions or induce duplicated belief state. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Merge modules that merely add indirection without protecting a real change or reasoning boundary.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S006] [EAOSE-S046] [EAOSE-S033]

### EAOSE-030 — Design-to-implementation correspondence

**Status:** STRONGLY_RETAINED. **Mature form:** Establish how the selected design's responsibilities, interactions and internal state correspond to actual implementation behaviour, including manual code.

**Controlled failure:** A faithful implementation can implement a wrong model; an attractive model may not constrain the code.

**Trigger:** Implementation, generation or migration changes the representation of the design. **Non-trigger / cheap path:** A small reviewed mapping plus targeted tests may be sufficient for a simple implementation.

**Prerequisites and consumer:** Defined model semantics, runtime semantics and observable behaviours. Designers and implementers agree the mapping; testers check consequences independently of syntactic agreement.

**Evidence needed:** A design obligation has an identified implementation realisation and evidence of relevant behaviour. **Evidence boundary:** Retained as a strong engineering distinction within its trigger; the strength is not a claim of universally strong comparative field evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-030].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C07, C24; A faithful implementation can implement a wrong model; an attractive model may not constrain the code. **Conflicts/tensions:** T05.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire redundant mapping documents when equivalent live tests/interfaces carry the same evidence and consumers.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S007] [EAOSE-S013] [EAOSE-S033] [EAOSE-S088] [EAOSE-S090] [EAOSE-S052]

### EAOSE-031 — Qualified model transformation trust

**Status:** ASSUMPTION_SENSITIVE. **Mature form:** Qualify transformations by supported constructs, semantic preservation claims, manual additions and target-runtime assumptions; test or prove the relevant mappings.

**Controlled failure:** Generation may preserve syntax while changing ordering, permissions or goal completion; trusted compiler alone cannot validate requirements.

**Trigger:** Code or executable artefacts are generated from a model. **Non-trigger / cheap path:** Manual implementation with explicit correspondence may be cheaper for small or rapidly changing models.

**Prerequisites and consumer:** Stable metamodel, transformation version and target semantics; unsupported cases detected. Transformation engineer claims only covered mappings; application engineer remains responsible for domain omissions.

**Evidence needed:** Generated output satisfies the stated mapped obligations or exposes unsupported semantics. **Evidence boundary:** The mechanism or guarantee depends materially on declared semantics, models or environmental assumptions; transferring it needs additional evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-031].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C07; Generation may preserve syntax while changing ordering, permissions or goal completion; trusted compiler alone cannot validate requirements. **Conflicts/tensions:** T04, T05.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire a generator when its validation and maintenance cost outweighs reliable manual implementation.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S011] [EAOSE-S013] [EAOSE-S033] [EAOSE-S088] [EAOSE-S089] [EAOSE-S052] [EAOSE-S020]

### EAOSE-032 — Explicit manual and platform obligations

**Status:** STRONGLY_RETAINED. **Mature form:** List which semantic and lifecycle obligations a platform/tool performs and which remain with engineers, operators or counterpart systems.

**Controlled failure:** Catalogues and demos are mistaken for complete lifecycle support or current maintenance.

**Trigger:** A method or framework is selected, especially with generators or abstractions that hide work. **Non-trigger / cheap path:** A concise responsibility/feature-boundary note is enough; no exhaustive checklist if the missing obligations are clear.

**Prerequisites and consumer:** Actual version-specific behaviour, not vendor or methodology-name inference. Tool provides documented facilities; engineers retain unsupported application, security and operating duties.

**Evidence needed:** No relevant obligation is credited merely because a framework exists or an artefact was generated. **Evidence boundary:** Retained as a strong engineering distinction within its trigger; the strength is not a claim of universally strong comparative field evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-032].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C07; Catalogues and demos are mistaken for complete lifecycle support or current maintenance. **Conflicts/tensions:** T05.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire a boundary note only when the obligation disappears or its replacement is explicitly verified.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S006] [EAOSE-S013] [EAOSE-S054] [EAOSE-S089] [EAOSE-S008] [EAOSE-S050] [EAOSE-S058] [EAOSE-S059] [EAOSE-S060]

### EAOSE-033 — Goal completion checked against consequences

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Define goal-achievement conditions independently of a plan's last statement, including maintenance and abandonment where supported.

**Controlled failure:** Belief-based success can be wrong about the environment; maintenance goals differ from one-time achievement.

**Trigger:** An internal goal is declared achieved after an action or conversation. **Non-trigger / cheap path:** An ordinary postcondition check is sufficient for a deterministic local goal.

**Prerequisites and consumer:** Goal semantics, effect observation and authority to change/abandon objectives. Agent detects evidence; acceptance authority remains with the relevant principal/tester.

**Evidence needed:** Goal lifecycle transitions reflect the declared success condition, not merely exhausted steps. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-033].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C06, C12; Belief-based success can be wrong about the environment; maintenance goals differ from one-time achievement. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire persistent monitoring only after the maintenance obligation has legitimately ended.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S046] [EAOSE-S056] [EAOSE-S041] [EAOSE-S045]

### EAOSE-034 — Lifecycle scope and method suitability

**Status:** STRONGLY_RETAINED. **Mature form:** Select and describe a method by its actual lifecycle scope, assumptions and usable prescriptions; add explicit complementary mechanisms for uncovered stages.

**Controlled failure:** More phase names or diagrams need not yield usable guidance; some original methods stop before operations/testing.

**Trigger:** A named methodology is considered for a concrete engineering endeavour. **Non-trigger / cheap path:** A smaller situational method is sufficient when it addresses all relevant obligations with less overhead.

**Prerequisites and consumer:** Problem profile, lifecycle needs and inspected method boundaries. Engineering lead and users of method outputs select scope; brand does not authorise claims of completeness.

**Evidence needed:** Requirements, construction, assurance and operation have an explicit coverage argument with justified omissions. **Evidence boundary:** Retained as a strong engineering distinction within its trigger; the strength is not a claim of universally strong comparative field evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-034].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C08; More phase names or diagrams need not yield usable guidance; some original methods stop before operations/testing. **Conflicts/tensions:** T03.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Remove a phase artefact when its purpose no longer exists, not merely to shorten a checklist.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S008] [EAOSE-S009] [EAOSE-S010] [EAOSE-S012]

### EAOSE-035 — Semantic compatibility of method fragments

**Status:** ASSUMPTION_SENSITIVE. **Mature form:** Compose method fragments only after reconciling concepts, artefacts, pre/postconditions, control assumptions and transformation obligations.

**Controlled failure:** A union of fragments can duplicate tasks, conflict on goal/role meanings or leave semantic gaps.

**Trigger:** Elements of different methods are combined or replaced. **Non-trigger / cheap path:** One coherent existing method may be cheaper than a tailored hybrid.

**Prerequisites and consumer:** Explicit fragment interfaces, compatible semantic meanings and resolved ownership of transitions. Method engineer assembles; downstream artefact consumers validate usability and consistency.

**Evidence needed:** A fragment's output actually supplies the assumptions its successor or concurrent consumer needs. **Evidence boundary:** The mechanism or guarantee depends materially on declared semantics, models or environmental assumptions; transferring it needs additional evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-035].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C08; A union of fragments can duplicate tasks, conflict on goal/role meanings or leave semantic gaps. **Conflicts/tensions:** T03.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Drop incompatible or unused fragments; do not preserve them merely because a source tradition contains them.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S008] [EAOSE-S012] [EAOSE-S047] [EAOSE-S009] [EAOSE-S052]

### EAOSE-036 — Work-product prerequisites and consistency

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Make prerequisites and consistency relationships among work products explicit, allowing iterations and concurrency where those relations permit.

**Controlled failure:** A document marked complete can remain unusable; rigid ordering can suppress necessary feedback.

**Trigger:** Several engineering activities depend on evolving models or decisions. **Non-trigger / cheap path:** A short dependency note or shared working representation may suffice.

**Prerequisites and consumer:** Identifiable inputs, producers, consumers and criteria for sufficient rather than exhaustive detail. Engineers exchange artefacts whose meaning and readiness are understood by actual consumers.

**Evidence needed:** An activity does not consume an obsolete or semantically incompatible prerequisite unnoticed. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-036].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C08; A document marked complete can remain unusable; rigid ordering can suppress necessary feedback. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire unused work products and refresh dependency rules when method fragments change.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S008] [EAOSE-S012] [EAOSE-S047] [EAOSE-S009]

### EAOSE-037 — Comparison beyond feature checklists

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Compare methods using usable decisions, task performance, assumptions, learning, tooling and total cost rather than counting mentioned features.

**Controlled failure:** Advocate-authored matrices and tiny convenience studies overstate superiority.

**Trigger:** A method is selected, taught, purchased or claimed superior. **Non-trigger / cheap path:** A bounded pilot on the actual task may be more informative than an encyclopaedic comparison matrix.

**Prerequisites and consumer:** Comparable task and operationalisation of outcomes; disclose developer expertise and source affiliation. Evaluators report strengths and omissions; decision-makers interpret applicability.

**Evidence needed:** Selection reasons remain defensible when feature counts are replaced by observed utility and cost. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-037].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C09; Advocate-authored matrices and tiny convenience studies overstate superiority. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire comparisons whose versions, task setting or decision relevance are obsolete.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S010] [EAOSE-S020] [EAOSE-S033] [EAOSE-S034] [EAOSE-S036]

### EAOSE-038 — Learnability and modelling burden

**Status:** CONTEXT_DEPENDENT. **Mature form:** Assess whether intended engineers and stakeholders can learn, understand and maintain the selected models and method at acceptable cost.

**Controlled failure:** Simplification can lose necessary distinctions; large expressive diagrams may exclude stakeholders.

**Trigger:** Expressive notation, large models or specialised tools are introduced. **Non-trigger / cheap path:** A simpler representation or training-limited subset may be adequate.

**Prerequisites and consumer:** Representative users/tasks; distinguish familiarity from semantic adequacy. Method adopter funds training; model consumers report comprehension and maintenance burden.

**Evidence needed:** Users can perform the consequential modelling/review/change task, not merely recognise notation. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-038].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C09; Simplification can lose necessary distinctions; large expressive diagrams may exclude stakeholders. **Conflicts/tensions:** T01.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Remove unused notation or specialised machinery after checking that protected distinctions remain available.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S006] [EAOSE-S033] [EAOSE-S034] [EAOSE-S047]

### EAOSE-039 — Consumer-driven minimal representations

**Status:** STRONGLY_RETAINED. **Mature form:** Keep a representation or ceremony only when an actual decision, coordination or assurance consumer needs what it establishes.

**Controlled failure:** Minimalism can become under-documentation; consumer preferences can overlook excluded stakeholders.

**Trigger:** A model, meeting, review or record is proposed or repeatedly maintained. **Non-trigger / cheap path:** Use the cheapest adequate representation, reuse an existing one, or do nothing when no protected failure is live.

**Prerequisites and consumer:** Identified consumer and failure; cheap alternatives checked for semantic loss. Consumer determines needed evidence; producer is not entitled to demand work merely because a template exists.

**Evidence needed:** Removing an artefact either demonstrably loses a needed capability or is accepted without loss. **Evidence boundary:** Retained as a strong engineering distinction within its trigger; the strength is not a claim of universally strong comparative field evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-039].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C09; Minimalism can become under-documentation; consumer preferences can overlook excluded stakeholders. **Conflicts/tensions:** T01, T03.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire when the consumer, risk or dependency disappears; preserve externally owed records where obligations remain.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S008] [EAOSE-S012] [EAOSE-S032] [EAOSE-S010] [EAOSE-S034]

### EAOSE-043 — Bounded programme model checking

**Status:** ASSUMPTION_SENSITIVE. **Mature form:** Model-check selected properties over explicit agent/interpreter/environment models and state the scope of the guarantee.

**Controlled failure:** State explosion, wrong abstractions and unmodelled external behaviour remain; tool output alone is not deployment acceptance.

**Trigger:** A consequential finite/bounded behaviour space or suitable abstraction can be formally analysed. **Non-trigger / cheap path:** Testing, static checks or simpler deterministic design may be more proportionate.

**Prerequisites and consumer:** Sound model/semantics, valid abstraction, model-checker assumptions and implementation correspondence. Verifier produces a bounded result; system acceptor must assess assumptions beyond that result.

**Evidence needed:** The named property holds or a counterexample is found within the stated model and bounds. **Evidence boundary:** The mechanism or guarantee depends materially on declared semantics, models or environmental assumptions; transferring it needs additional evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-043].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C10; State explosion, wrong abstractions and unmodelled external behaviour remain; tool output alone is not deployment acceptance. **Conflicts/tensions:** T02, T08.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire a particular proof obligation only when the property or relied-on implementation/model is no longer relevant.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S029] [EAOSE-S056]

### EAOSE-044 — Environment and abstraction validation

**Status:** STRONGLY_RETAINED. **Mature form:** Validate that abstractions, environmental assumptions, sensor/effect mappings and test conditions adequately represent the intended operating setting.

**Controlled failure:** Simulation agreement can conceal unmodelled timing, users, failures or action effects.

**Trigger:** Formal, simulation or benchmark evidence is used to support real operation. **Non-trigger / cheap path:** A direct representative effect test may suffice for a narrow well-observed environment.

**Prerequisites and consumer:** Identified abstraction relation, operating envelope and independent environmental observations. Domain expert/operator validates assumptions; theorem author cannot warrant the actual environment merely by stipulation.

**Evidence needed:** Acceptance states which environmental conditions are established and which remain unknown. **Evidence boundary:** Retained as a strong engineering distinction within its trigger; the strength is not a claim of universally strong comparative field evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-044].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C10; Simulation agreement can conceal unmodelled timing, users, failures or action effects. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Revisit when the operating envelope changes; remove obsolete model detail when it has no bearing on the claim.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S029] [EAOSE-S056] [EAOSE-S051] [EAOSE-S041]

### EAOSE-045 — Agent-level test oracles

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Define oracles for goal, action, protocol and prohibited-outcome behaviour; use independent observations and qualified human judgement where automation is insufficient.

**Controlled failure:** Final-state metrics can reward an unauthorised path; LLM judges can share biases with the system.

**Trigger:** Agent output or behaviour needs a pass/fail or acceptance decision. **Non-trigger / cheap path:** Simple deterministic assertions are sufficient when they capture the actual success and harm conditions.

**Prerequisites and consumer:** Requirement semantics, observable outputs/effects and a disclosed uncertainty policy. Test designer sets oracle before judging results; system under test cannot be sole unquestioned judge.

**Evidence needed:** Tests discriminate relevant failures including apparently successful but prohibited behaviour. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-045].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C12; Final-state metrics can reward an unauthorised path; LLM judges can share biases with the system. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire an oracle when its requirement changes or it is shown to miss a material failure; replace it rather than merely add tests.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S054] [EAOSE-S046] [EAOSE-S041]

### EAOSE-046 — Collective and adversarial integration testing

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Test interactions, interleavings, faults and non-cooperative behaviour in addition to isolated agent functions.

**Controlled failure:** Toy success traces omit rare schedules, hidden coordination errors and strategic participants.

**Trigger:** Several agents/environment components jointly realise an obligation or share a hazard. **Non-trigger / cheap path:** A conventional integration test may suffice; no adversarial MAS simulation is needed without a relevant threat.

**Prerequisites and consumer:** Declared joint property, fault/adversary model and observable system consequences. Integration tester exercises boundaries; participants do not certify the collective result by mutual agreement alone.

**Evidence needed:** Specified fault/interleaving cases produce acceptable outcomes or clearly exposed failures. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-046].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C12, C19; Toy success traces omit rare schedules, hidden coordination errors and strategic participants. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Remove redundant tests after showing another layer covers the same relevant failure assumptions.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S007] [EAOSE-S056] [EAOSE-S035] [EAOSE-S042]

### EAOSE-047 — Risk-proportionate test adequacy

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Choose test adequacy against the relevant goal-plan choices, failure recovery, interleavings and risks; do not require all paths by default or equate line coverage with sufficiency.

**Controlled failure:** All-path counts can be infeasible, while all-edges coverage can miss behaviour interactions.

**Trigger:** Agent branching and recovery create many possible behaviours. **Non-trigger / cheap path:** Use cheaper edge, condition, scenario, property-based or risk-focused criteria when they address the claim.

**Prerequisites and consumer:** Declared adequacy criterion and limits; coverage is not proof of absence of faults. Assurance engineer explains why the selected coverage is informative for the consumer.

**Evidence needed:** Reported coverage names its denominator and omissions; adverse cases can change the criterion. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-047].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C11; All-path counts can be infeasible, while all-edges coverage can miss behaviour interactions. **Conflicts/tensions:** T08.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire low-value coverage targets when they do not discriminate relevant defects, retaining the assurance obligation.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S030] [EAOSE-S031]

### EAOSE-048 — Simulation validity and transfer limits

**Status:** ASSUMPTION_SENSITIVE. **Mature form:** Separate validity of a simulation/model from evidence about a deployment; test the transfer assumptions explicitly.

**Controlled failure:** Idealised users, timing, tools or cooperation can reverse outcomes in deployment.

**Trigger:** Simulated performance or agent-based modelling informs implementation or operational decisions. **Non-trigger / cheap path:** Use a direct small deployment trial when it is safe and more informative; simulation may be unnecessary.

**Prerequisites and consumer:** Representative dynamics, parameter basis and a declared target setting. Simulator/model author reports limits; operational decision-maker authorises transfer based on evidence.

**Evidence needed:** Claims remain conditional on calibrated features and do not silently become production success rates. **Evidence boundary:** The mechanism or guarantee depends materially on declared semantics, models or environmental assumptions; transferring it needs additional evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-048].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C13; Idealised users, timing, tools or cooperation can reverse outcomes in deployment. **Conflicts/tensions:** T08.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire a simulator for a decision if it cannot represent the distinguishing failure or relevant environment.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S020] [EAOSE-S038] [EAOSE-S057] [EAOSE-S056] [EAOSE-S041]

### EAOSE-049 — Runtime conformance monitoring

**Status:** CONTEXT_DEPENDENT. **Mature form:** Monitor selected observable runtime obligations and route violations/uncertainty to a permitted response.

**Controlled failure:** Incomplete logs, delayed detection and alert fatigue can defeat monitoring; observation alone is not control.

**Trigger:** Long-lived, adaptive or open operation may depart from design assumptions. **Non-trigger / cheap path:** Periodic inspection or an existing infrastructure monitor may suffice for slowly changing low-risk behaviour.

**Prerequisites and consumer:** Observable events, monitor semantics and a real response consumer. Monitor detects; operator/principal decides permitted intervention unless a bounded automatic response is authorised.

**Evidence needed:** A detected relevant violation changes a decision, action or explicitly accepted risk. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-049].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C14; Incomplete logs, delayed detection and alert fatigue can defeat monitoring; observation alone is not control. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire monitors with no live hazard or consumer; preserve required evidence through alternate means.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S043] [EAOSE-S032] [EAOSE-S056] [EAOSE-S045] [EAOSE-S050]

### EAOSE-050 — Explanation fidelity and human interpretation

**Status:** CONTEXT_DEPENDENT. **Mature form:** Produce explanations grounded in actual decision/trace semantics and at the abstraction level the recipient can use; distinguish causal evidence from plausible narrative.

**Controlled failure:** Ex-Plan cannot recover unlogged choices; 2026 multi-level work leaves domain-level implementation future; fluent accounts may mislead.

**Trigger:** A user, designer or operator needs to understand a consequential decision or debug behaviour. **Non-trigger / cheap path:** A clear state/error message or direct evidence may suffice; a narrative is not always needed.

**Prerequisites and consumer:** Relevant logged events, valid mappings and recipient/task understanding. Explanation system reports support and omissions; user retains judgement; implementer cannot invent missing causes.

**Evidence needed:** Explanation claims correspond to logged/modelled events and help the relevant user task under evaluation. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-050].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C14; Ex-Plan cannot recover unlogged choices; 2026 multi-level work leaves domain-level implementation future; fluent accounts may mislead. **Conflicts/tensions:** T09.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire explanations that add confidence without decision value or fidelity; preserve a simpler truthful account.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S045] [EAOSE-S055] [EAOSE-S090]

### EAOSE-051 — Versioned reproducible deployment configuration

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Identify deployment-relevant code, plans, prompts, models, dependencies, policies and environment configuration so evidence can be interpreted and changes controlled.

**Controlled failure:** A package version alone misses prompt, remote-model, tool-policy or environment changes.

**Trigger:** A result or live system depends on mutable implementation/configuration components. **Non-trigger / cheap path:** A small versioned configuration and test environment record may suffice.

**Prerequisites and consumer:** Version identity and access to relevant artefacts; disclose remotely mutable dependencies. Deployer/operator manages configuration; assessor knows what version evidence concerns.

**Evidence needed:** A reported behaviour/evaluation can be tied to a sufficiently specified deployed configuration. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-051].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C15, C24; A package version alone misses prompt, remote-model, tool-policy or environment changes. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire obsolete deployable versions after live obligations, retention needs and rollback dependencies are resolved.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S032] [EAOSE-S050] [EAOSE-S052] [EAOSE-S056]

### EAOSE-052 — Operational trace correlation

**Status:** CONTEXT_DEPENDENT. **Mature form:** Correlate requirement-relevant decisions, messages, attempts and effects using identifiers adequate to reconstruct an interaction without conflating concurrent instances.

**Controlled failure:** Missing events, spoofed provenance and partial clocks can create false causal narratives.

**Trigger:** Failures, assurance or accountability require tracing distributed execution. **Non-trigger / cheap path:** A single ordered trace is enough for one process; do not build distributed tracing without need.

**Prerequisites and consumer:** Trustworthy event meaning, correlation scope, clock/order assumptions and data minimisation. Components emit evidence; operators/testers use it; logs do not authorise the actions they describe.

**Evidence needed:** An observed effect can be related to its request/attempt and relevant configuration or labelled uncorrelated. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-052].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C14; Missing events, spoofed provenance and partial clocks can create false causal narratives. **Conflicts/tensions:** T09.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Remove logging with no protected decision or retention duty; retain minimal required correlation.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S032] [EAOSE-S050] [EAOSE-S056] [EAOSE-S090] [EAOSE-S035] [EAOSE-S045]

### EAOSE-053 — Change-impact traceability and reassurance

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Trace a change to the claims and evidence whose premises it affects, then re-evaluate the affected support while preserving independent valid evidence.

**Controlled failure:** Blind full re-audits waste effort; incomplete dependency models miss invalidated evidence.

**Trigger:** Requirements, semantics, implementation, permissions, membership, model or environment assumptions change. **Non-trigger / cheap path:** No revalidation is needed for a proved irrelevant change; a targeted regression may suffice.

**Prerequisites and consumer:** Dependency information and the distinction between invalidated support and falsified conclusion. Authorised change owner and assurance consumer decide scope; successor implementation does not warrant itself.

**Evidence needed:** Affected claims are re-supported, narrowed, suspended or withdrawn; independent warrants are not erased. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-053].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C15; Blind full re-audits waste effort; incomplete dependency models miss invalidated evidence. **Conflicts/tensions:** T06.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire obsolete evidence after replacement and required retention; do not re-run unchanged irrelevant work.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S032] [EAOSE-S043] [EAOSE-S052] [EAOSE-S051]

### EAOSE-054 — Authorised adaptation boundaries

**Status:** STRONGLY_RETAINED. **Mature form:** Bound permitted adaptation by object, trigger, authorised actor and preserved constraints; evaluate changes before accepting revised behaviour at the relevant boundary.

**Controlled failure:** Useful adaptation can still be unauthorised; narrow monitoring may miss destabilising global effects.

**Trigger:** A system can reorganise, learn, replace plans/policies or change its own operation. **Non-trigger / cheap path:** Manual authorised redeployment is sufficient where automation adds little value.

**Prerequisites and consumer:** Defined change scope, safety/authority constraints and credible before/after evidence. Principal defines change rights; adaptive component exercises only delegated revisions; external acceptor handles expanded scope.

**Evidence needed:** A revision stays within authority and its changed assumptions/effects are evaluated. **Evidence boundary:** Retained as a strong engineering distinction within its trigger; the strength is not a claim of universally strong comparative field evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-054].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C15, C16; Useful adaptation can still be unauthorised; narrow monitoring may miss destabilising global effects. **Conflicts/tensions:** T02, T06.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Revoke adaptation rights whose benefit/risk basis disappears; preserve continuity of outstanding obligations.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S043] [EAOSE-S056] [EAOSE-S050] [EAOSE-S051]

### EAOSE-055 — Recovery, retirement and obligation discharge

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Before recovery or retirement, identify live responsibilities, commitments, credentials, retained evidence and unfinished effects, then discharge or validly transfer them.

**Controlled failure:** State deletion, credential revocation or role rebinding can strand commitments and ambiguous effects.

**Trigger:** An agent, service, role, model or protocol instance stops, is replaced or loses authority. **Non-trigger / cheap path:** A simple termination is sufficient when no live external obligation or retained state remains.

**Prerequisites and consumer:** An inventory of live obligations and an accepting successor or explicit unresolved decision. Current responsible principal and authorised successor agree transfer; disappearing process is not discharge.

**Evidence needed:** No obligation is silently treated as fulfilled merely because its implementation ended. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-055].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C15, C25; State deletion, credential revocation or role rebinding can strand commitments and ambiguous effects. **Conflicts/tensions:** T06.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire the mechanism after all obligations and retention/transfer conditions are genuinely closed.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S056] [EAOSE-S027] [EAOSE-S050] [EAOSE-S052]

### EAOSE-056 — Operational handoff with an actual consumer

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Deliver engineering/operating information to a named functional consumer who can use it to accept, run, recover or change the system.

**Controlled failure:** A document transfer can be mistaken for operational readiness; excessive paperwork can obscure missing knowledge.

**Trigger:** Work crosses development, testing, operation or affected-user boundaries. **Non-trigger / cheap path:** A direct conversation plus maintained configuration may be adequate in a small team.

**Prerequisites and consumer:** Required information, receiving capability and authority; no separate person is inherently required. Producer supplies usable evidence; receiver can question and refuse an inadequate handoff.

**Evidence needed:** The receiver can perform the relevant consequential task with the supplied information. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-056].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C15; A document transfer can be mistaken for operational readiness; excessive paperwork can obscure missing knowledge. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire separate handoff artefacts when the same participants and representation provide equivalent continuity.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S012] [EAOSE-S032] [EAOSE-S056] [EAOSE-S008] [EAOSE-S010]

### EAOSE-057 — Method revision under declared authority

**Status:** CONTEXT_DEPENDENT. **Mature form:** Treat a change to the engineering method itself as a proposal with declared authority, affected assumptions and evaluation criteria.

**Controlled failure:** Self-application can become circular or bureaucratic; method improvement is not automatic performance gain.

**Trigger:** Method fragments, acceptance rules or modelling conventions are revised. **Non-trigger / cheap path:** Minor editorial changes need only consistency checking; do not manufacture a meta-process for every edit.

**Prerequisites and consumer:** A distinction between changing a method and approving its outputs; identified acceptance authority. Method adopter approves revisions; a new method cannot prove its own legitimacy merely by passing its own changed test.

**Evidence needed:** Revisions state what changed, why, what evidence applies and which continuity obligations remain. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-057].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C08, C16; Self-application can become circular or bureaucratic; method improvement is not automatic performance gain. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire old method rules only after their obligations and downstream consumers are reconciled.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S008] [EAOSE-S012] [EAOSE-S047] [EAOSE-S032] [EAOSE-S037]

### EAOSE-058 — Distinguish model, demonstration, prototype and deployment

**Status:** STRONGLY_RETAINED. **Mature form:** Classify each supporting result as model, demonstration, prototype, experiment or deployment and preserve the actual unit and setting.

**Controlled failure:** Case labels and marketing language invite overgeneralisation.

**Trigger:** A source is used to justify maturity, adoption or effectiveness. **Non-trigger / cheap path:** A concise evidence label and locator may be sufficient.

**Prerequisites and consumer:** Readable source and accurate description of what was actually run or observed. Researcher/evaluator reports class; decision-maker does not upgrade it by rhetoric.

**Evidence needed:** An industrially authored simulation is not counted as deployment; one flight experiment is not a population frequency. **Evidence boundary:** Retained as a strong engineering distinction within its trigger; the strength is not a claim of universally strong comparative field evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-058].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C13, C17, C26; Case labels and marketing language invite overgeneralisation. **Conflicts/tensions:** T14.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire obsolete evidence labels only through corrected provenance, not favourable reinterpretation.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S010] [EAOSE-S033] [EAOSE-S038] [EAOSE-S052] [EAOSE-S056] [EAOSE-S036] [EAOSE-S037] [EAOSE-S058] [EAOSE-S059] [EAOSE-S060]

### EAOSE-059 — Realistic cost-and-quality comparative baselines

**Status:** STRONGLY_RETAINED. **Mature form:** Compare against credible non-agent/single-agent/workflow alternatives with task quality, resource use and uncertainty controlled or disclosed.

**Controlled failure:** Ablations can change several things at once; matched models do not imply matched compute.

**Trigger:** A mechanism or multi-agent design is claimed to improve engineering or outcomes. **Non-trigger / cheap path:** A modest paired pilot or ablation may be enough for a local decision.

**Prerequisites and consumer:** Comparable tasks, model/tool budgets, expertise and measurable success criteria. Evaluator selects meaningful baselines; stakeholder decides cost-quality trade-off.

**Evidence needed:** The claimed advantage is separated from extra computation, tool changes and unfair comparator restrictions. **Evidence boundary:** Retained as a strong engineering distinction within its trigger; the strength is not a claim of universally strong comparative field evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-059].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C02, C17; Ablations can change several things at once; matched models do not imply matched compute. **Conflicts/tensions:** T14.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire comparisons when changed tasks or versions invalidate their decision relevance.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S020] [EAOSE-S036] [EAOSE-S044] [EAOSE-S010] [EAOSE-S033]

### EAOSE-060 — Training, integration and maintenance cost accounting

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Include training, modelling, integration, testing, operation, migration and retirement effort when assessing a method's cost.

**Controlled failure:** Self-reported time, author tooling and omitted maintenance can reverse initial results.

**Trigger:** A method is defended on saved coding/modelling time or lower operating burden. **Non-trigger / cheap path:** A bounded cost record for the affected phase is enough when the claim is explicitly phase-limited.

**Prerequisites and consumer:** Defined payer/time horizon and disclosed unmeasured costs. Adopter and operators account for costs; one team's convenience cannot conceal another's transferred burden.

**Evidence needed:** Cost claims state included/excluded work and do not equate fewer glue-code lines with net benefit. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-060].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C17; Self-reported time, author tooling and omitted maintenance can reverse initial results. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Stop collecting cost detail that cannot affect the decision, while preserving declared accounting limits.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S010] [EAOSE-S032] [EAOSE-S052] [EAOSE-S033] [EAOSE-S036]

### EAOSE-063 — LLM role prompts are not role-contract enforcement

**Status:** STRONGLY_RETAINED. **Mature form:** Require any claimed runtime role obligation to have an operational realisation beyond a natural-language role prompt.

**Controlled failure:** Persuasive role-playing can obscure missing permissions, state and collective obligations.

**Trigger:** LLM participants are assigned roles with permissions, responsibilities or acceptance duties. **Non-trigger / cheap path:** Use a prompt as a soft behavioural hint when no enforceable obligation is being claimed.

**Prerequisites and consumer:** Explicit runtime boundary and evidence for any stronger guarantee. Engineer implements enforcement; principal grants authority; generated role text cannot do either.

**Evidence needed:** Role constraints are tested at the relevant action/protocol boundary or explicitly labelled unenforced. **Evidence boundary:** Retained as a strong engineering distinction within its trigger; the strength is not a claim of universally strong comparative field evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-063].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C18, C20; Persuasive role-playing can obscure missing permissions, state and collective obligations. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Remove role-enforcement machinery for purely presentational personas without consequential obligations.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S035] [EAOSE-S044] [EAOSE-S085] [EAOSE-S041] [EAOSE-S042]

### EAOSE-064 — Stochastic and version-sensitive regression evaluation

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Evaluate repeated runs and regressions under identified model, prompt, tool, policy and environment versions, retaining variance and failures.

**Controlled failure:** Temperature zero does not establish deterministic service behaviour; small benchmarks miss deployment shifts.

**Trigger:** Learned/stochastic behaviour or remote updates affect outcomes. **Non-trigger / cheap path:** Deterministic checks suffice for deterministic components; local sampling should match the claim and risk.

**Prerequisites and consumer:** Representative task distribution, reproducible configuration and independent oracle. Evaluator controls tests; provider updates do not automatically inherit prior evidence.

**Evidence needed:** Results state repetitions, variance/uncertainty and version scope rather than a single successful demonstration. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-064].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C12, C19; Temperature zero does not establish deterministic service behaviour; small benchmarks miss deployment shifts. **Conflicts/tensions:** T10.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire tests only when their requirement or failure model disappears; refresh obsolete benchmarks rather than accumulating scores.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S041] [EAOSE-S036] [EAOSE-S044] [EAOSE-S035]

### EAOSE-065 — Tool-use authority separated from generated intention

**Status:** STRONGLY_RETAINED. **Mature form:** Treat generated plans/tool calls as proposals checked against external permissions, schemas and consequential-action constraints.

**Controlled failure:** Valid JSON can encode a harmful or unauthorised operation; model agreement cannot grant authority.

**Trigger:** A learned agent can select or construct an effectful operation. **Non-trigger / cheap path:** An ordinary validated API call behind access control is sufficient; no special agent governor is assumed.

**Prerequisites and consumer:** Identified principal, enforceable interface and validated operation arguments. Principal/resource owner authorises; model proposes; executor checks; observer establishes effects.

**Evidence needed:** Untrusted or out-of-scope generated intent cannot silently become an authorised action. **Evidence boundary:** Retained as a strong engineering distinction within its trigger; the strength is not a claim of universally strong comparative field evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-065].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C16, C20; Valid JSON can encode a harmful or unauthorised operation; model agreement cannot grant authority. **Conflicts/tensions:** T12.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Remove unused tool powers and revoke scopes whose legitimate task need has ended.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S041] [EAOSE-S042] [EAOSE-S049] [EAOSE-S050]

### EAOSE-066 — Memory provenance and update semantics

**Status:** ASSUMPTION_SENSITIVE. **Mature form:** Make memory entries, retrieval, update, forgetting and provenance meaningful for the selected agent architecture; distinguish stored narrative from verified fact.

**Controlled failure:** Fabricated reflections and copied errors can acquire spurious authority through repeated retrieval.

**Trigger:** Persistent or shared learned-agent memory influences future decisions. **Non-trigger / cheap path:** Short-lived explicit state may suffice when long-term retrieval adds no value.

**Prerequisites and consumer:** Source/age/ownership semantics and authority for storing or deleting sensitive state. Memory maintainer controls update policy; agent treats retrieved content according to its trust and relevance.

**Evidence needed:** A consequential remembered claim can be traced to evidence or labelled uncertain; stale/conflicting entries have a response. **Evidence boundary:** The mechanism or guarantee depends materially on declared semantics, models or environmental assumptions; transferring it needs additional evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-066].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C14, C21; Fabricated reflections and copied errors can acquire spurious authority through repeated retrieval. **Conflicts/tensions:** T09.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Forget or archive entries whose purpose or retention basis ends, preserving legally/operationally owed evidence where applicable.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S057] [EAOSE-S045]

### EAOSE-067 — Untrusted-input and prompt-injection containment

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Keep untrusted retrieved/messages/tool content from silently becoming instructions or authority; test realistic prompt-injection paths and permitted disclosures/actions.

**Controlled failure:** Prompt-only defences can fail; benchmark success is not universal immunity.

**Trigger:** LLM agents consume attacker-influenced content while possessing tools or private data. **Non-trigger / cheap path:** No injection-specific machinery is needed for a non-generative parser with a validated narrow grammar and no instruction-following exposure.

**Prerequisites and consumer:** Threat model, trust separation and controllable tool/data interfaces. Trusted application defines policy; external content is data unless explicitly authorised otherwise.

**Evidence needed:** Adversarial content does not obtain unauthorised disclosure/action in the tested scope, with residual cases retained. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-067].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C20; Prompt-only defences can fail; benchmark success is not universal immunity. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire inaccessible tool/data paths and obsolete defences after re-evaluating the remaining threat model.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S042] [EAOSE-S041]

### EAOSE-068 — Trace-grounded multi-agent failure localisation

**Status:** CONTEXT_DEPENDENT. **Mature form:** Localise multi-agent failures using trace-supported distinctions among specification, inter-agent alignment and verification/execution problems.

**Controlled failure:** Annotation disagreement, incomplete traces and benchmark selection limit inference.

**Trigger:** A multi-agent run fails and diagnosis can change a repair or evaluation. **Non-trigger / cheap path:** A simple error report suffices when the fault is already isolated.

**Prerequisites and consumer:** Adequate traces and explicit uncertainty; taxonomy categories are not automatically causal explanations. Analyst diagnoses; authorised engineer repairs; agents' self-reports remain evidence to assess.

**Evidence needed:** The diagnosis points to a testable defect hypothesis and avoids blaming every failure on the model or coordination. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-068].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C14, C19; Annotation disagreement, incomplete traces and benchmark selection limit inference. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire categories that do not discriminate repair decisions; retain raw evidence needed to revisit classification.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S035] [EAOSE-S045]

### EAOSE-069 — Single-agent and workflow substitution tests

**Status:** CONTEXT_DEPENDENT. **Mature form:** Ablate extra participants and orchestration against a simpler agent or workflow while holding useful capabilities and resource assumptions explicit.

**Controlled failure:** Removing agents may also remove tools or compute, making the ablation uninterpretable.

**Trigger:** A multi-agent design is being justified on quality, robustness or cost. **Non-trigger / cheap path:** Omit multi-agent execution when the simpler baseline meets the same needs.

**Prerequisites and consumer:** Comparable tasks, tools, memory and disclosed compute; preserve authority boundaries during substitution. Architect/evaluator tests alternatives; no rule requires minimising agent count regardless of need.

**Evidence needed:** An extra participant has attributable value or is removed; null/adverse outcomes are retained. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-069].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C02, C19; Removing agents may also remove tools or compute, making the ablation uninterpretable. **Conflicts/tensions:** T10.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Revisit when task distribution or components change; retire unnecessary coordination.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S036] [EAOSE-S044] [EAOSE-S035]

### EAOSE-072 — Independent action-effect verification

**Status:** STRONGLY_RETAINED. **Mature form:** Assess consequential action results using observations that do not merely repeat the actor's success claim; preserve uncertain or prohibited-path outcomes.

**Controlled failure:** A database target state may omit a forbidden path; observer correlation or staleness can still mislead.

**Trigger:** An agent claims to have changed an external object or discharged an obligation. **Non-trigger / cheap path:** Direct return-value checking suffices only when that return reliably establishes the relevant effect.

**Prerequisites and consumer:** A credible observer/effect interface and appropriate acceptance authority. Actor attempts; environment/observer provides evidence; authorised consumer accepts or disputes.

**Evidence needed:** Attempt, execution acknowledgement, observed effect and accepted outcome are not silently substituted. **Evidence boundary:** Retained as a strong engineering distinction within its trigger; the strength is not a claim of universally strong comparative field evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-072].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C12; A database target state may omit a forbidden path; observer correlation or staleness can still mislead. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire extra observation only when another warranted mechanism establishes the same consequential postcondition.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S041] [EAOSE-S042] [EAOSE-S056] [EAOSE-S035]

### EAOSE-073 — Bounded symbolic–learned hybrid design

**Status:** ASSUMPTION_SENSITIVE. **Mature form:** Use learned components within explicitly specified symbolic/programmatic interfaces, with constraints, evidence and fallback matched to their stochastic behaviour.

**Controlled failure:** Symbolic wrappers can be incomplete; deterministic components can still consume wrong model outputs.

**Trigger:** Language understanding, proposal generation or adaptation helps a system whose obligations cannot be left wholly implicit. **Non-trigger / cheap path:** A deterministic or purely symbolic component is preferable when it satisfies the task adequately.

**Prerequisites and consumer:** Clear boundary, validated schemas, permissions, evaluation and behaviour-change assumptions. Engineer selects hybrid role; model does not define the authority or acceptance contract.

**Evidence needed:** Learned outputs remain bounded inputs to accountable execution and assurance. **Evidence boundary:** The mechanism or guarantee depends materially on declared semantics, models or environmental assumptions; transferring it needs additional evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-073].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** record-specific objection; Symbolic wrappers can be incomplete; deterministic components can still consume wrong model outputs. **Conflicts/tensions:** T10.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Remove the learned component when its cost, variance or attack surface exceeds its demonstrated task benefit.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S028] [EAOSE-S037] [EAOSE-S051] [EAOSE-S044] [EAOSE-S042]

### EAOSE-074 — Documented continuity rather than rebranding

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Classify modern uses of agent concepts by documented inheritance, explicit import, convergence or analogy rather than treating all branding as historical continuity.

**Controlled failure:** A citation can show awareness without derivation; community continuity does not identify every framework's ancestry.

**Trigger:** A new framework or hybrid is described as AOSE's descendant or replacement. **Non-trigger / cheap path:** Describe mechanisms directly when no ancestry claim is needed.

**Prerequisites and consumer:** Readable documentary evidence for influence; shared vocabulary alone is insufficient. Researcher records genealogical claim and limit; implementer need not adopt a tradition to share a mechanism.

**Evidence needed:** Historical relations are no stronger than the cited evidence permits. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-074].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C18, C26; A citation can show awareness without derivation; community continuity does not identify every framework's ancestry. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Withdraw an unsupported ancestry edge when its evidence fails; preserve the mechanism comparison separately.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S017] [EAOSE-S018] [EAOSE-S037] [EAOSE-S045] [EAOSE-S084] [EAOSE-S085] [EAOSE-S088] [EAOSE-S089] [EAOSE-S090] [EAOSE-S044] [EAOSE-S057]

### EAOSE-075 — Modular requirements views and explicit interfaces

**Status:** CONTEXT_DEPENDENT. **Mature form:** Partition large requirements models into views with explicit interfaces and cross-view consistency responsibilities.

**Controlled failure:** Modularity can hide omitted stakeholders or inconsistent goal refinements.

**Trigger:** A full actor/goal diagram becomes difficult for its users to understand or maintain. **Non-trigger / cheap path:** Keep one small model when splitting would only add navigation and synchronisation costs.

**Prerequisites and consumer:** Defined shared concepts, interface goals/dependencies and validated consumers. Requirements team partitions; affected participants can still see relevant cross-boundary effects.

**Evidence needed:** Users can reason locally without losing consequential inter-view dependencies. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-075].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C01, C09; Modularity can hide omitted stakeholders or inconsistent goal refinements. **Conflicts/tensions:** T01.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Merge views whose interfaces cost more than the comprehension benefit; retain necessary distinctions.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S034] [EAOSE-S003]

### EAOSE-077 — Local cooperation as adaptive-system design principle

**Status:** DOMAIN_SPECIFIC. **Mature form:** For a suitable cooperative adaptive system, design local detection and repair of non-cooperative situations and evaluate the resulting collective behaviour.

**Controlled failure:** Local repair can oscillate or fail to achieve global adequacy; strategic participants violate the intended assumptions.

**Trigger:** The task admits local cooperation-driven organisation and can tolerate the specified adaptation dynamics. **Non-trigger / cheap path:** Stable organisation, explicit allocation or central optimisation may be simpler or more predictable.

**Prerequisites and consumer:** Meaningful local non-cooperation criteria; cooperative assumptions and observable global objectives. Designer selects local rules; participating agents adapt within their delegated scope.

**Evidence needed:** Local repairs are realised and collective effects tested rather than assumed from the label cooperative. **Evidence boundary:** Preserved for its specific domain/assumption class, not exported as a universal obligation.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-077].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C03, C23; Local repair can oscillate or fail to achieve global adequacy; strategic participants violate the intended assumptions. **Conflicts/tensions:** T13.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire adaptation rules with no measurable contribution or unacceptable stability/assurance cost.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S040]

### EAOSE-079 — End-to-end obligation-to-effect witness

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Compose a claim-specific witness linking legitimate requirement, allocated obligation, authority, implemented behaviour, observed effect and acceptance; test the joins, not just each artefact.

**Controlled failure:** Every local artefact may pass while their composition concerns different objects, versions or obligations.

**Trigger:** Several engineering levels jointly support a consequential end-to-end claim. **Non-trigger / cheap path:** A direct requirement-to-effect test plus an ordinary permission check may instantiate the whole witness; no chain of extra documents is necessary.

**Prerequisites and consumer:** Consistent referents, configuration and time scope across evidence; independent assessment of model validity and actual effect. Stakeholder, engineer, executor, observer and acceptor are functional roles and may be partly co-located; no role can silently confer another's authority.

**Evidence needed:** No missing semantic or authority bridge is concealed by locally complete records; uncertainty is retained where a bridge lacks evidence. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-079].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C25; Every local artefact may pass while their composition concerns different objects, versions or obligations. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Collapse redundant representations or omit unneeded levels while preserving the actual end-to-end claim and its warranted links.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S003] [EAOSE-S023] [EAOSE-S054] [EAOSE-S056] [EAOSE-S041] [EAOSE-S052]

### EAOSE-081 — Consumer-closed lifecycle composition

**Status:** CONTEXT_DEPENDENT. **Mature form:** Close lifecycle interfaces by identifying who can consume a model, test result, failure or change signal and take the next warranted action; permit omission when no such action is needed.

**Controlled failure:** A consumer can be overloaded or lack authority; forced ownership can create bureaucracy and delay.

**Trigger:** Otherwise coherent fragments produce outputs that no capable, authorised consumer uses. **Non-trigger / cheap path:** One engineer and one shared artefact may close all interfaces; no new owner or document per property.

**Prerequisites and consumer:** A real consequential decision, receiving capability and valid authority; burden proportional to risk. Producer and consumer negotiate usable evidence; affected parties remain represented where their concerns matter.

**Evidence needed:** Evidence changes acceptance, execution, correction, justified risk acceptance or retirement rather than accumulating unused. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-081].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C09, C25; A consumer can be overloaded or lack authority; forced ownership can create bureaucracy and delay. **Conflicts/tensions:** T03.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire interfaces whose decisions/dependencies disappear or whose function is already supplied by a simpler interaction.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S008] [EAOSE-S012] [EAOSE-S032] [EAOSE-S056] [EAOSE-S090] [EAOSE-S010] [EAOSE-S034]

### EAOSE-082 — Explicit temporal feasibility for goals, plans and actions

**Status:** ASSUMPTION_SENSITIVE. **Mature form:** Include task, scheduling, reasoning, communication and environmental timing assumptions when assessing whether goals and actions can meet deadlines.

**Controlled failure:** RT-BDI v2 excludes plan-search/loop costs and delays external reaction; treating its model as unrestricted hard real time is unwarranted.

**Trigger:** Timeliness is part of success or safety, not merely a performance preference. **Non-trigger / cheap path:** Ordinary timeout or measured service-level tests suffice for soft deadlines; avoid hard-real-time claims without their prerequisites.

**Prerequisites and consumer:** Timing model, resource/scheduler semantics, bounded costs and actual platform evidence. Timing engineer and operator establish budgets; agent intention does not make a deadline feasible.

**Evidence needed:** Claimed deadlines specify excluded costs and the operating assumptions under which evidence applies. **Evidence boundary:** The mechanism or guarantee depends materially on declared semantics, models or environmental assumptions; transferring it needs additional evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-082].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C22; RT-BDI v2 excludes plan-search/loop costs and delays external reaction; treating its model as unrestricted hard real time is unwarranted. **Conflicts/tensions:** T08.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire specialised scheduling proofs when no hard temporal obligation remains, retaining relevant responsiveness tests.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S051] [EAOSE-S056]

### EAOSE-083 — Security-constraint and threat-to-test traceability

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Trace selected security constraints and threats from requirements through design and implementation to meaningful tests and residual risks.

**Controlled failure:** A complete security model can miss a real adversary, unsafe tool surface or implementation divergence.

**Trigger:** The system handles protected resources, data or adversarial interactions. **Non-trigger / cheap path:** Conventional threat modelling and access-control tests may be sufficient.

**Prerequisites and consumer:** Identified assets, adversary capabilities, trust boundaries and testable constraints. Asset owner sets protection duties; engineers implement and test them; attacker input has no authority.

**Evidence needed:** A security requirement has an operational control and evidence or an explicitly unresolved gap. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-083].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C16, C20; A complete security model can miss a real adversary, unsafe tool surface or implementation divergence. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire controls only when the asset/threat exposure ends or another justified mechanism supersedes them.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S049] [EAOSE-S047] [EAOSE-S042]

### EAOSE-085 — Norm specification, violation and recovery

**Status:** CONTEXT_DEPENDENT. **Mature form:** Represent obligations, prohibitions and permissions with their subjects, activation, deadline, fulfilment, violation and recovery semantics; distinguish violable social norms from non-delegable access controls. Norm-aware BDI planning can consider conformity and violation consequences, but must not rewrite an externally imposed permission into a preference.

**Controlled failure:** Conflicting norms, unverifiable fulfilment, dynamic norm changes and incentives can defeat local conformity. The 2026 Jason example demonstrates a mechanism, not scalable or globally compliant deployment.

**Trigger:** Open organisations or applications with consequential social obligations, sanctions or rules whose violation must remain visible. **Non-trigger / cheap path:** A hard access rule or a simple externally enforced contract may need no autonomous normative reasoning. A conventional policy table can suffice.

**Prerequisites and consumer:** Identifiable norm authority, interpretation, applicable subjects, observable events and authorised recovery; distinguish soft valuations from hard constraints. Norm issuers and affected principals establish obligations; agents decide only within delegated discretion; monitors and responsible parties consume violation evidence.

**Evidence needed:** The applicable norm, responsible subject and fulfilment or violation outcome can be established for a concrete interaction, including unresolved evidence. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-085].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C18, C23; Conflicting norms, unverifiable fulfilment, dynamic norm changes and incentives can defeat local conformity. The 2026 Jason example demonstrates a mechanism, not scalable or globally compliant deployment. **Conflicts/tensions:** T07, T13.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire autonomous norm reasoning when the applicable rules no longer vary or are fully enforced by a cheaper mechanism; retain unresolved obligations until discharged.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S068] [EAOSE-S089] [EAOSE-S023] [EAOSE-S040] [EAOSE-S085]

### EAOSE-086 — Belief provenance, revision and observational uncertainty

**Status:** ASSUMPTION_SENSITIVE. **Mature form:** Associate decision-relevant beliefs with observations or derivations, update and defeat conditions, and unresolved uncertainty. Do not promote an agent's stored belief into an external fact simply because it has a symbolic label or a fluent explanation.

**Controlled failure:** Unlogged derivations, ambiguous sensors and learned summaries break reconstruction; provenance does not prove truth. Full provenance can be expensive and privacy-sensitive.

**Trigger:** Agents whose observations become stale, conflict or are derived from fallible models. **Non-trigger / cheap path:** A deterministic local computation over immutable, validated input may require only ordinary input checks rather than a belief-provenance subsystem.

**Prerequisites and consumer:** Observable input boundaries, update policy, relevant freshness criteria and a way to distinguish absence from falsity. Agent designers define belief-update semantics; operators or dependent decision-makers consume the stated evidence and uncertainty; external facts are not determined by the agent.

**Evidence needed:** A consequential belief can be traced to an inspected observation or derivation and revised or withheld when its support fails. **Evidence boundary:** The mechanism or guarantee depends materially on declared semantics, models or environmental assumptions; transferring it needs additional evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-086].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C06, C21; Unlogged derivations, ambiguous sensors and learned summaries break reconstruction; provenance does not prove truth. Full provenance can be expensive and privacy-sensitive. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Drop fine-grained provenance where input immutability and trusted validation remove the failure mode, while preserving information required by consequential consumers.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S001] [EAOSE-S063] [EAOSE-S069] [EAOSE-S057] [EAOSE-S045]

### EAOSE-087 — Intention retention and bounded reconsideration

**Status:** CONTEXT_DEPENDENT. **Mature form:** Retain an adopted intention long enough to coordinate useful action, with explicit reconsideration when achievement, impossibility, irrelevance or competing obligations warrant it; account for the cost of reconsideration itself.

**Controlled failure:** Overcommitment wastes resources; excessive reconsideration thrashes. Philosophical and formal motivation does not establish an optimal policy in every environment.

**Trigger:** Long-lived, interruptible or resource-bounded goal pursuit where continual replanning or blind persistence causes harm. **Non-trigger / cheap path:** A one-shot deterministic operation may need no persistent intention state; a standard job lifecycle can implement the necessary persistence.

**Prerequisites and consumer:** Defined achievement and abandonment conditions, observation of relevant changes, resource bounds and authority to change commitments. Agent designers choose reconsideration policy within stakeholder priorities; the acting agent cannot silently abandon public commitments merely by dropping an internal intention.

**Evidence needed:** The system can explain why pursuit continued, was suspended or was abandoned, and what happened to dependent obligations. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-087].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C06, C22; Overcommitment wastes resources; excessive reconsideration thrashes. Philosophical and formal motivation does not establish an optimal policy in every environment. **Conflicts/tensions:** T11.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Replace intention machinery with a simpler job-state model when reconsideration has no substantive role; discharge public obligations separately.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S066] [EAOSE-S073] [EAOSE-S063] [EAOSE-S051] [EAOSE-S052]

### EAOSE-088 — Authorised goal adoption, maintenance and abandonment

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Define who can introduce, delegate, activate, maintain, complete or abandon each goal; distinguish achievement from maintenance goals and successful procedure termination from satisfaction of the required state.

**Controlled failure:** Platform goal semantics can differ across apparently similar languages. Norm valuation or internal deletion does not waive an external duty.

**Trigger:** Multiple goal sources, maintenance requirements, delegated tasks or behaviour that persists after a request changes. **Non-trigger / cheap path:** For one fixed authorised objective, an ordinary precondition, task and postcondition may be adequate.

**Prerequisites and consumer:** Goal semantics, authority source, completion evidence, conflict handling and treatment of dependent goals and social obligations. Stakeholders or authorised controllers establish goal authority; agents select means within that authority; acceptance belongs to the relevant consumer.

**Evidence needed:** Each active goal has a legitimate origin and explicit lifecycle state, with satisfaction or abandonment justified by the appropriate evidence. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-088].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C06; Platform goal semantics can differ across apparently similar languages. Norm valuation or internal deletion does not waive an external duty. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire goal-management machinery when objectives are fixed and a simpler state machine preserves the required distinctions.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S069] [EAOSE-S046] [EAOSE-S066] [EAOSE-S089] [EAOSE-S052] [EAOSE-S041]

### EAOSE-089 — Reactive–deliberative arbitration

**Status:** CONTEXT_DEPENDENT. **Mature form:** Specify priority, interruption, resumption and arbitration between reactive handlers and deliberative plans rather than assuming their coexistence yields a coherent controller.

**Controlled failure:** Reactive starvation, deliberative blocking and omitted reasoning overhead defeat informal timeliness claims; not every BDI implementation is pre-emptive.

**Trigger:** Urgent events can arrive during planning or multiple behaviours compete for shared resources. **Non-trigger / cheap path:** A purely reactive controller or a sequential job processor may dominate where goals do not require deliberative persistence.

**Prerequisites and consumer:** Event semantics, shared-resource policy, interruption points, maximum tolerable delay and recovery from partially executed plans. Designers and relevant safety or operations authorities establish precedence; the runtime executes the specified arbitration rather than inventing authority.

**Evidence needed:** A triggered urgent event is handled within the declared scope, with the interrupted task and effects accounted for. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-089].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C06, C22; Reactive starvation, deliberative blocking and omitted reasoning overhead defeat informal timeliness claims; not every BDI implementation is pre-emptive. **Conflicts/tensions:** T11.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Remove the hybrid layer when one control style satisfies requirements more simply; retain explicit interruption semantics if external effects persist.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S063] [EAOSE-S046] [EAOSE-S073] [EAOSE-S051] [EAOSE-S056]

### EAOSE-090 — Negotiation and task-allocation procedure

**Status:** CONTEXT_DEPENDENT. **Mature form:** Separate announcement, eligibility, bids or proposals, selection, commitment and subsequent performance in distributed task allocation; declare what information and incentives the procedure assumes.

**Controlled failure:** Strategic bidding, stale capacity, non-delivery and communication overhead can invalidate cooperative assumptions. A simulation is not industrial outcome evidence.

**Trigger:** Work or resources must be allocated among independently capable participants with locally held information. **Non-trigger / cheap path:** Static assignment or a central scheduler is preferable when information and authority are centralised and negotiation adds no benefit.

**Prerequisites and consumer:** Task identity, evaluation criteria, participant capabilities, cost of messages, failure handling and enforceable assignment semantics. The allocating principal specifies selection authority; participants control their offers within protocol rules; recipients consume allocation and performance evidence.

**Evidence needed:** The awarded task, responsible performer, accepted terms and actual result can be distinguished and checked. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-090].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C03; Strategic bidding, stale capacity, non-delivery and communication overhead can invalidate cooperative assumptions. A simulation is not industrial outcome evidence. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Replace negotiation with direct assignment when the uncertainty or decentralisation that justified it disappears.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S065] [EAOSE-S038] [EAOSE-S082] [EAOSE-S015]

### EAOSE-091 — Interaction identity and authentication

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Bind consequential messages, role claims and requests to an authenticated principal or appropriately scoped capability; distinguish transport identity, application identity and authority for the particular action.

**Controlled failure:** FIPA message structure alone does not authenticate identity. Shared credentials, replay and ambiguous principal mapping undermine accountability.

**Trigger:** Heterogeneous, open or remote interactions in which impersonation or mistaken attribution matters. **Non-trigger / cheap path:** A genuinely closed trusted execution boundary may use ordinary process identity; do not impose public-key infrastructure without a relevant threat.

**Prerequisites and consumer:** Trust anchors, credential lifecycle, message integrity, identity-to-authority mapping and revocation behaviour. Security administrators or legitimate principals establish identity and authority; agents cannot grant trust merely by accepting a name in an ACL field.

**Evidence needed:** A consequential request has a verifiable origin and action-specific authority or is treated as untrusted. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-091].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C04, C20; FIPA message structure alone does not authenticate identity. Shared credentials, replay and ambiguous principal mapping undermine accountability. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Simplify identity machinery when trust boundaries contract, but retain controls for remaining remote or consequential interfaces.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S026] [EAOSE-S049] [EAOSE-S025] [EAOSE-S050]

### EAOSE-092 — Engineered environment artefacts

**Status:** CONTEXT_DEPENDENT. **Mature form:** Make shared environment resources explicit engineered artefacts with observable properties, operations and access boundaries rather than encoding every shared resource as an agent's private belief.

**Controlled failure:** A resource-oriented API can expose dangerous mutations; artefact abstractions do not automatically enforce security or atomicity.

**Trigger:** Several agents interact through persistent resources, tools or coordination artefacts. **Non-trigger / cheap path:** Ordinary service interfaces, data structures or databases are adequate when they expose the necessary state and operations.

**Prerequisites and consumer:** Defined artefact semantics, concurrency and access policy, ownership of external effects and links to agent observations. Resource owners establish operations and permissions; agents invoke them within authority; operators observe actual resource state.

**Evidence needed:** The state and effects of a shared resource can be inspected independently of any one agent's narrative. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-092].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** record-specific objection; A resource-oriented API can expose dangerous mutations; artefact abstractions do not automatically enforce security or atomicity. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire a specialised artefact layer when conventional interfaces preserve the same distinctions at lower cost.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S074] [EAOSE-S050]

### EAOSE-093 — Agent, organisation and environment separation

**Status:** CONTEXT_DEPENDENT. **Mature form:** Separate agent-internal behaviour, organisational constraints and environment-resource behaviour where they have different change and authority boundaries; maintain explicit interfaces between these dimensions.

**Controlled failure:** Separate modules can still share hidden state; administrative APIs may bypass organisational constraints. Conceptual dimensions are not automatically separate security domains.

**Trigger:** Systems where roles, norms, resource operations and individual plans evolve independently. **Non-trigger / cheap path:** A small cohesive programme may keep these concerns together when the distinctions remain clear and modular separation adds no value.

**Prerequisites and consumer:** Consistent conceptual boundaries, mappings among dimensions and an implementation that respects the intended interfaces. Agent, organisation and resource designers may be the same person, but their authority and change obligations are distinguished; operators consume the composed behaviour.

**Evidence needed:** An organisational or resource change has identifiable effects on agent behaviour rather than silently changing several meanings at once. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-093].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** record-specific objection; Separate modules can still share hidden state; administrative APIs may bypass organisational constraints. Conceptual dimensions are not automatically separate security domains. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Collapse unnecessary modules when interfaces are stable and a simpler representation remains semantically adequate.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S074] [EAOSE-S068] [EAOSE-S050] [EAOSE-S037]

### EAOSE-094 — Cross-view and metamodel consistency checking

**Status:** ASSUMPTION_SENSITIVE. **Mature form:** Check that requirements, roles, interactions and internal designs agree under declared mapping and metamodel semantics; use counterexamples to locate inconsistencies rather than treating syntactic validity as consistency.

**Controlled failure:** A checker can faithfully prove consistency of inadequate abstractions; prototype evaluations and random instances do not establish industrial scaling or model/code faithfulness.

**Trigger:** Multiple views or generated artefacts describe overlapping behaviours and inconsistent assumptions could survive local review. **Non-trigger / cheap path:** One unambiguous representation with executable tests may need no separate cross-view checker.

**Prerequisites and consumer:** Defined semantics for both views, correspondence rules, bounded analysis model and readable counterexamples. Modellers and implementers resolve inconsistencies; a checker reports consequences of its formalisation, not which stakeholder requirement is legitimate.

**Evidence needed:** A checked consistency claim states the views, versions, mapping and scope; detected conflicts have a responsible decision-maker. **Evidence boundary:** The mechanism or guarantee depends materially on declared semantics, models or environmental assumptions; transferring it needs additional evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-094].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C01, C07, C24; A checker can faithfully prove consistency of inadequate abstractions; prototype evaluations and random instances do not establish industrial scaling or model/code faithfulness. **Conflicts/tensions:** T05.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire redundant views or specialised checkers when a smaller representation provides equivalent assurance.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S011] [EAOSE-S070] [EAOSE-S071] [EAOSE-S034] [EAOSE-S052]

### EAOSE-095 — Uncertainty-aware decision and abstention policy

**Status:** ASSUMPTION_SENSITIVE. **Mature form:** Represent decision-relevant uncertainty and define when to gather evidence, choose a robust action, defer or abstain; do not equate a plausible plan or high model score with sufficient evidence for a consequential act.

**Controlled failure:** Uncalibrated scores, unavailable humans, distribution shift and badly specified thresholds can defeat the policy. This is an analytical integration of assurance boundaries, not a uniquely AOSE theorem.

**Trigger:** Partial observations, uncertain consequences, stochastic components or material model/environment mismatch. **Non-trigger / cheap path:** Deterministic validated inputs and reversible low-consequence actions may justify a simpler direct policy.

**Prerequisites and consumer:** A declared consequence model, risk or acceptability threshold, feasible alternatives and a legitimate consumer of abstention or escalation. Stakeholders establish tolerable consequences and delegated discretion; agents choose only within that boundary; humans are not assumed to be infallible or always available.

**Evidence needed:** The decision records what uncertainty mattered and why action or abstention met the applicable criterion. **Evidence boundary:** The mechanism or guarantee depends materially on declared semantics, models or environmental assumptions; transferring it needs additional evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-095].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C06, C21, C22; Uncalibrated scores, unavailable humans, distribution shift and badly specified thresholds can defeat the policy. This is an analytical integration of assurance boundaries, not a uniquely AOSE theorem. **Conflicts/tensions:** T11.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Simplify when uncertainty and consequence diminish; retain an explicit failure outcome rather than fabricating confidence.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S029] [EAOSE-S056] [EAOSE-S051] [EAOSE-S041] [EAOSE-S044]

### EAOSE-096 — Communication uncertainty, correlation and delivery handling

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Treat message sending, receiving, correlation, ordering, duplication and timeout as different events; define which information enables each local action and how uncertain delivery is resolved.

**Controlled failure:** A correct logical act can fail through its adapter or transport. Arrival order is not necessarily causal order; timeouts establish uncertainty, not proof of non-execution.

**Trigger:** Asynchronous or failure-prone communication and heterogeneous implementations. **Non-trigger / cheap path:** Reliable in-process calls can use ordinary call semantics if the actual boundary satisfies those assumptions.

**Prerequisites and consumer:** Message and conversation identity, declared transport guarantees, protocol preconditions and recovery rules. Protocol designers define meaningful exchanges; infrastructure operators establish transport guarantees; endpoints own local conformance.

**Evidence needed:** An observed conversation can be matched to its participants and protocol instance, with missing, duplicate or out-of-order events handled explicitly. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-096].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C05, C24; A correct logical act can fail through its adapter or transport. Arrival order is not necessarily causal order; timeouts establish uncertainty, not proof of non-execution. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Remove unnecessary messaging machinery when a simpler call or workflow genuinely provides the required guarantees.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S025] [EAOSE-S027] [EAOSE-S088] [EAOSE-S026] [EAOSE-S052]

### EAOSE-097 — Human participation and effective intervention

**Status:** CONTEXT_DEPENDENT. **Mature form:** Provide meaningful participation and intervention to affected or responsible humans, including what they observe, decide and can actually stop or change; separate consultation, approval and cancellation of ongoing effects.

**Controlled failure:** Approval fatigue, unavailable operators, restarted nodes and already-issued external actions can make nominal oversight ineffective.

**Trigger:** High-consequence delegation, contested requirements or operational exceptions outside authorised autonomy. **Non-trigger / cheap path:** Low-risk, fully specified reversible operations may not need human approval at every step; prior policy can be sufficient.

**Prerequisites and consumer:** Identifiable decision rights, understandable evidence, workable response times and tested intervention semantics. Affected participants validate relevant needs; authorised operators approve or interrupt within their rights; the agent cannot manufacture approval from conversational agreement.

**Evidence needed:** A human decision reaches the execution boundary and its effect or inability to halt an action is observable. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-097].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C16; Approval fatigue, unavailable operators, restarted nodes and already-issued external actions can make nominal oversight ineffective. **Conflicts/tensions:** T12.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Remove redundant approval steps when risk and authority are covered by a cheaper validated control, while retaining an exception route where needed.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S056] [EAOSE-S075] [EAOSE-S080] [EAOSE-S041]

### EAOSE-098 — Accountability and evidence custody

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Preserve attributable evidence of consequential decisions, communications and effects for the parties entitled to examine them, with integrity, access and retention boundaries proportionate to the stakes.

**Controlled failure:** Incomplete logs, unrecorded reasoning, forged narratives and over-retention undermine accountability or privacy. Auditability is not proof that the decision was right.

**Trigger:** Disputed obligations, externally consequential actions or failures requiring explanation and remedy. **Non-trigger / cheap path:** Ephemeral low-risk calculations may need only ordinary diagnostic information; do not log everything by default.

**Prerequisites and consumer:** Event identity, provenance, appropriate access, integrity protection, retention purpose and privacy constraints. Responsible principals and authorised reviewers consume evidence; custody does not itself confer authority to change the underlying obligations.

**Evidence needed:** A relevant action can be attributed and its supporting evidence inspected or explicitly reported unavailable without silent alteration. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-098].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C04, C14; Incomplete logs, unrecorded reasoning, forged narratives and over-retention undermine accountability or privacy. Auditability is not proof that the decision was right. **Conflicts/tensions:** T09.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire evidence when its legitimate purpose and outstanding obligations end, subject to applicable retention requirements not invented by this study.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S023] [EAOSE-S049] [EAOSE-S056] [EAOSE-S050] [EAOSE-S045]

### EAOSE-099 — Non-functional constraints and adverse consequences

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Treat latency, resource use, safety, privacy, security and adverse stakeholder consequences as requirements with explicit acceptance and conflict rules, not as optional additions to task success.

**Controlled failure:** Proxy metrics omit affected parties; averaging can hide catastrophic failures. A norm-aware planner's willingness to violate a soft norm does not authorise violating a hard access boundary.

**Trigger:** Task achievement can cause material cost or harm, or service qualities determine acceptability. **Non-trigger / cheap path:** A narrow low-risk computation can use a small explicit quality budget rather than a full assurance programme.

**Prerequisites and consumer:** Stakeholder participation, measurable or evaluable criteria, hard-versus-negotiable distinction and evidence suited to each constraint. Legitimate stakeholders and responsible authorities set constraints; agents cannot trade away non-delegable limits merely because a utility score improves.

**Evidence needed:** A successful task is accepted only under the applicable consequence and quality constraints, with unresolved trade-offs exposed. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-099].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C12, C20, C23; Proxy metrics omit affected parties; averaging can hide catastrophic failures. A norm-aware planner's willingness to violate a soft norm does not authorise violating a hard access boundary. **Conflicts/tensions:** T13.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Simplify controls when the relevant exposure disappears, not merely because the main task score remains high.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S049] [EAOSE-S003] [EAOSE-S085] [EAOSE-S041] [EAOSE-S042] [EAOSE-S089]

### EAOSE-100 — Explicit compositional assurance assumptions

**Status:** ASSUMPTION_SENSITIVE. **Mature form:** State the assumptions each component or proof needs from other agents, protocols and the environment, and show that the composed configuration supplies compatible support before transferring a guarantee.

**Controlled failure:** Mutually circular assumptions, hidden shared resources and unmodelled timing invalidate naïve composition. This row does not claim a universal automatic proof rule.

**Trigger:** Local analyses or independent components are combined into a consequential system. **Non-trigger / cheap path:** Direct system-level tests and a small architecture may be cheaper than a formal assume–guarantee calculus, while still requiring explicit critical assumptions.

**Prerequisites and consumer:** Compatible semantics, identified interfaces, sound correspondence obligations and avoidance of circular unsupported assumptions. Designers and assurance decision-makers discharge composition obligations; one component cannot certify an unexamined peer or environment.

**Evidence needed:** Each claimed system guarantee identifies its local warrants and environmental assumptions, including any obligation not established. **Evidence boundary:** The mechanism or guarantee depends materially on declared semantics, models or environmental assumptions; transferring it needs additional evidence.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-100].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C10, C25; Mutually circular assumptions, hidden shared resources and unmodelled timing invalidate naïve composition. This row does not claim a universal automatic proof rule. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire redundant formal machinery when a simpler justified system argument supplies the same assurance.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S029] [EAOSE-S083] [EAOSE-S023] [EAOSE-S051] [EAOSE-S056]

### EAOSE-101 — Scoped reuse of engineering assets

**Status:** CONTEXT_DEPENDENT. **Mature form:** Reuse method fragments, patterns, protocol or design assets only with their scope, prerequisites, semantics and prior evidence visible; revalidate altered assumptions.

**Controlled failure:** Superficial similarity, stale platform mappings and omitted tacit expertise can reverse expected savings.

**Trigger:** Repeated engineering problems with a genuinely shared structure or stable platform. **Non-trigger / cheap path:** A one-off simple solution may cost less than discovering, adapting and governing a reusable asset.

**Prerequisites and consumer:** Asset identity and version, semantic contract, known limitations and responsibility for adaptation. Method engineers or developers select and adapt assets; prior authorship does not authorise reuse outside the evidence boundary.

**Evidence needed:** The reused asset's assumptions and adaptations are documented to the degree required by its actual consumers. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-101].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C08; Superficial similarity, stale platform mappings and omitted tacit expertise can reverse expected savings. **Conflicts/tensions:** No independent named tension; inspect prerequisites and selected composition interfaces.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire assets whose consumers disappear or whose adaptation cost exceeds a local replacement.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S012] [EAOSE-S013] [EAOSE-S047] [EAOSE-S061] [EAOSE-S052]

### EAOSE-102 — Deployment topology and trust-boundary design

**Status:** CONTEXT_DEPENDENT. **Mature form:** Choose deployment boundaries and communication mechanisms according to locality, trust, failure isolation, resource constraints and organisational control, rather than mapping each conceptual role to a separate process.

**Controlled failure:** Shared infrastructure can create correlated failure; decentralised labels can hide central authority. Transport adapters need correspondence evidence.

**Trigger:** Distribution changes what can fail, who controls state or which guarantees interactions can rely on. **Non-trigger / cheap path:** A single process or conventional service can be the correct deployment for several conceptual roles.

**Prerequisites and consumer:** A topology model, identity and authority boundaries, resource and transport assumptions, and a mapping from conceptual interactions to actual channels. Architects and infrastructure owners establish deployable boundaries; principals retain the responsibilities that process layout does not erase.

**Evidence needed:** Each consequential interaction has an actual path and trust/failure boundary consistent with its specified semantics. **Evidence boundary:** Useful only when the stated context, consumer and costs justify it; a simpler or different configuration can legitimately omit it.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-102].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C05, C24; Shared infrastructure can create correlated failure; decentralised labels can hide central authority. Transport adapters need correspondence evidence. **Conflicts/tensions:** T04.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Consolidate or simplify deployment when independent failure or control boundaries are no longer needed.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S053] [EAOSE-S074] [EAOSE-S088] [EAOSE-S026] [EAOSE-S050]

### EAOSE-103 — Idempotency and uncertain-effect reconciliation

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** On retries, resumed executions or uncertain responses, distinguish not-issued, issued, acknowledged and externally completed effects; use idempotent operations, deduplication, status reconciliation or compensation according to the external contract.

**Controlled failure:** A checkpointer is not an exactly-once guarantee; code before an interrupt may replay. Compensation may be impossible or harmful after irreversible effects.

**Trigger:** Tool calls or distributed actions can outlive a timeout, interruption or process restart. **Non-trigger / cheap path:** A pure computation or an atomic in-process operation with no surviving external effect may need no extra deduplication mechanism.

**Prerequisites and consumer:** Effect identity, external status evidence, retry contract, appropriate storage and authority for compensation. Implementers and external resource owners establish effect semantics; operators resolve ambiguous outcomes within their authority.

**Evidence needed:** A retry cannot silently produce an unrecognised duplicate consequence; uncertain outcomes remain explicit until reconciled. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-103].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C15, C25; A checkpointer is not an exactly-once guarantee; code before an interrupt may replay. Compensation may be impossible or harmful after irreversible effects. **Conflicts/tensions:** T12.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Remove the extra mechanism only when the external effect or relevant retry/restart possibility disappears.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S080] [EAOSE-S056] [EAOSE-S027] [EAOSE-S041]

### EAOSE-104 — Resource budgets and termination conditions

**Status:** RETAINED_IN_EVOLVED_FORM. **Mature form:** Bound computation, messages, tokens, retries, elapsed time or other relevant resources and define what termination means for goals, obligations and already-issued effects.

**Controlled failure:** Token limits may depend on reported usage; checks after a response cannot prevent all overshoot. Stopping a conversation does not cancel remote effects.

**Trigger:** Autonomous or conversational loops can continue indefinitely or consume unacceptable resources. **Non-trigger / cheap path:** A statically bounded operation may need only ordinary timeout and cost limits.

**Prerequisites and consumer:** Measured resource units, reporting reliability, stopping points, incomplete-result semantics and treatment of pending actions. The responsible principal sets budgets; the runtime enforces the supported limits; an agent cannot declare success simply because a budget ended.

**Evidence needed:** Termination has a recorded reason and reconciles unresolved work rather than confusing stopped execution with achieved goals. **Evidence boundary:** Retained with the stated trigger, operating boundary, cheap path and criticisms; do not impose the historical artefact unchanged.

**Domain profile:** `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json → properties[PROPERTY_ID=EAOSE-104].DOMAIN_PROFILE` (all ten dimensions; shared models resolve in the same file). **Criticism:** C22; Token limits may depend on reported usage; checks after a response cannot prevent all overshoot. Stopping a conversation does not cancel remote effects. **Conflicts/tensions:** T10, T11.

**Anti-ceremony / retirement:** Presence of an artefact, model, agent or tool does not establish the protected property. Retire specialised budgeting where ordinary bounded execution provides equivalent protection.

**Neutral audit questions:** Does the stated trigger exist in this system? What existing mechanism, including a conventional or simpler one, supplies the mature function? Who legitimately consumes the evidence and can act on it? What supports the stated postcondition under current versions and assumptions? Is the defensible outcome already addressed, inapplicable, simpler sufficient, evidence insufficient or a genuinely warranted gap? [EAOSE-S073] [EAOSE-S081] [EAOSE-S075] [EAOSE-S044] [EAOSE-S035]

## Non-retained, duplicate, contested and unresolved candidates

**EAOSE-010 — Every active component should be an agent (REJECTED_OR_DISFAVOURED).** The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. Reject the prescription; ordinary components remain legitimate. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [].

**EAOSE-011 — More autonomy is inherently beneficial (REJECTED_OR_DISFAVOURED).** The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. Reject; choose bounded discretion or central control where coordination and predictability dominate. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [].

**EAOSE-022 — Private mental-state semantics as open compliance criterion (REJECTED_OR_DISFAVOURED).** The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. Reject as a general public compliance criterion; use observable contractual/protocol conditions. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [].

**EAOSE-040 — One mandatory serial lifecycle (CEREMONY_NOT_GENERAL_PROPERTY).** The universal artefact/ordering requirement has no independent general property; preserve functional alternatives instead. Reject as a general requirement; use actual prerequisite relations and iterations. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [].

**EAOSE-041 — Union of all methods as a superior method (REJECTED_OR_DISFAVOURED).** The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. Reject; select a compatible subset with explicit interfaces and omissions. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [].

**EAOSE-042 — Stakeholder goal validation restated (DUPLICATE_CANDIDATE).** Preserve the candidate identity and history, but link it to already represented operative content and count no additional independent retained mechanism. Use the single mechanism described by 001. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [{"RELATION": "DUPLICATE_OF", "PROPERTY_IDS": ["EAOSE-001"]}].

**EAOSE-061 — Whole-method net benefit over conventional engineering (UNRESOLVED).** The question has been researched and remains unsettled in the inspected corpus; neither universal benefit nor absence of all useful benefit is established. Use narrower supported mechanism claims and local trials; do not presume system-level superiority. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [].

**EAOSE-062 — Platform popularity as evidence of method effectiveness (NO_GENERAL_PROPERTY).** The claimed general evidential implication does not hold; availability/popularity is not comparative method effectiveness. Reject the inference; examine actual use, scope, costs and results. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [].

**EAOSE-070 — Agent agreement as an independent correctness oracle (REJECTED_OR_DISFAVOURED).** The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. Reject as a general oracle; use external evidence or genuinely independent validated checks. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [].

**EAOSE-071 — Unmonitored self-modification as authorised evolution (REJECTED_OR_DISFAVOURED).** The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. Reject; use authorised bounded adaptation and independent acceptance conditions. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [].

**EAOSE-076 — Code generation as an assurance certificate (REJECTED_OR_DISFAVOURED).** The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. Reject; require model validation, qualified transformation and implementation/environment evidence. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [].

**EAOSE-078 — All-path testing as the only adequate assurance (SUPERSEDED_BY_STRONGER_FORM).** Preserve the earlier candidate and its useful warning; replace the universal prescription with the stronger qualified adequacy criterion. Superseded by declared risk- and property-sensitive adequacy in 047, with proofs and other testing where appropriate. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [{"RELATION": "SUPERSEDED_BY", "PROPERTY_IDS": ["EAOSE-047"]}].

**EAOSE-080 — Assumption-change evidence invalidation (DUPLICATE_CANDIDATE).** Preserve the candidate identity and history, but link it to already represented operative content and count no additional independent retained mechanism. Use 053 once, with selective dependency propagation; do not create a second mandatory revalidation control. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [{"RELATION": "DUPLICATE_OF", "PROPERTY_IDS": ["EAOSE-053"]}].

**EAOSE-084 — Local cooperation as a certificate of global adequacy (CONTESTED).** Retain the stronger claim as contested because the local mechanism does not itself discharge the global guarantee under all relevant conditions. Do not accept the certificate without a suitable theorem and validated premises or adequate collective evidence. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [].

**EAOSE-105 — Mental-state labels establish intelligence (REJECTED_OR_DISFAVOURED).** The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. Terminology can remain useful as a modelling convention without any anthropomorphic inference. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [].

**EAOSE-106 — Role prompts alone constitute AOSE (REJECTED_OR_DISFAVOURED).** The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. A useful role prompt may be an adequate local implementation aid without a full methodology claim. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [].

**EAOSE-107 — One mandatory methodology fits every agent system (REJECTED_OR_DISFAVOURED).** The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. Use a small conventional method or a tailored AOSE configuration where sufficient. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [].

**EAOSE-108 — Complete models guarantee correct implementation (REJECTED_OR_DISFAVOURED).** The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. A smaller adequate model with tested implementation may be sufficient. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [].

**EAOSE-109 — ACL syntax guarantees semantic interoperability (REJECTED_OR_DISFAVOURED).** The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. A simpler shared API contract can establish the necessary agreement without adopting ACL machinery. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [].

**EAOSE-110 — Model checking certifies the deployed system without correspondence evidence (REJECTED_OR_DISFAVOURED).** The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. Model checking can be valuable for a bounded claim without a universal certificate. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [].

**EAOSE-111 — Increasing agent count necessarily improves results (REJECTED_OR_DISFAVOURED).** The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. One component, one agent or a workflow remains a legitimate outcome. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [].

**EAOSE-112 — Universally exhaustive methodology artefacts (CEREMONY_NOT_GENERAL_PROPERTY).** The universal artefact/ordering requirement has no independent general property; preserve functional alternatives instead. A short shared record, executable specification or direct observation can replace a larger ritual where it meets the same need. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [].

**EAOSE-113 — Branch-sensitive method selection restated as a new control (DUPLICATE_CANDIDATE).** Preserve the candidate identity and history, but link it to already represented operative content and count no additional independent retained mechanism. Use the existing selection decision; do not introduce a second approval ritual merely because the composition has a new name. Ask whether the target actually asserts this overclaim; do not infer an unmet control merely from its absence. Duplicate/supersession links: [{"RELATION": "DUPLICATE_OF", "PROPERTY_IDS": ["EAOSE-007", "EAOSE-034", "EAOSE-039", "EAOSE-069"]}].

## Evidence the later target must supply

A later audit must establish its actual stakeholder and authority boundary, selected configuration, implementation semantics, environmental assumptions, operating observations, versions, costs and acceptance meaning. Strong formal support is not field validation. A published prototype or flight case is not representative effectiveness for another target. Learned-component, open-principal and physical-world transfers require their own evidence. The research identifies questions and mechanisms; it does not answer these target facts.


## Source-link definitions

[EAOSE-S001]: https://www.researchgate.net/publication/222482819_Agent-Oriented_Programming/fulltext/0e603da7f0c46d4f0aa42e1d/Agent-Oriented-Programming.pdf
[EAOSE-S002]: https://www.cs.ox.ac.uk/people/michael.wooldridge/pubs/jaamas2000b.pdf
[EAOSE-S003]: https://www.researchgate.net/publication/225198353_Tropos_An_Agent-Oriented_Software_Development_Methodology
[EAOSE-S004]: https://link.springer.com/article/10.1023/B:AGNT.0000018806.20944.ef
[EAOSE-S005]: https://www.cs.utoronto.ca/~eric/ieeeexp/ieeeexp2.html
[EAOSE-S006]: https://michaelwinikoff.com/wp-content/uploads/2019/05/aamas02-aose-ws.pdf
[EAOSE-S007]: https://www.researchgate.net/publication/220344738_MULTIAGENT_SYSTEMS_ENGINEERING
[EAOSE-S008]: https://www.researchgate.net/publication/220608212_O-MaSE_A_customisable_approach_to_designing_and_building_complex_adaptive_multi-agent_systems
[EAOSE-S009]: https://ceur-ws.org/Vol-627/fipa_5.pdf
[EAOSE-S010]: https://winikoff.github.io/pdf/aois2003.pdf
[EAOSE-S011]: https://ceur-ws.org/Vol-627/fipa_6.pdf
[EAOSE-S012]: https://lia.disi.unibo.it/~ao/pubs/pdf/volumes/eumas2006/Republications/15.pdf
[EAOSE-S013]: https://www.researchgate.net/publication/237490469_From_Requirements_to_Code_with_the_PASSI_Methodology
[EAOSE-S014]: https://www.cs.ox.ac.uk/people/michael.wooldridge/pubs/aose2000a.pdf
[EAOSE-S015]: https://www.cs.ox.ac.uk/people/michael.wooldridge/pubs/agents98.pdf
[EAOSE-S016]: https://onlinelibrary.wiley.com/doi/abs/10.1002/9780470050118.ecse006
[EAOSE-S017]: https://emas.in.tu-clausthal.de/
[EAOSE-S018]: https://emas-workshop.github.io/2026/
[EAOSE-S019]: https://aamas.csc.liv.ac.uk/Proceedings/aamas2026/forms/contents.htm
[EAOSE-S020]: https://arxiv.org/html/2006.08820v1
[EAOSE-S021]: https://doi.org/10.1145/367211.367250
[EAOSE-S022]: https://doi.org/10.1145/958961.958963
[EAOSE-S023]: https://www.csc2.ncsu.edu/faculty/mpsingh/papers/mas/computer-acl-98.pdf
[EAOSE-S024]: https://jmvidal.cse.sc.edu/822/papers/Rep_Agent_Protocols.pdf
[EAOSE-S025]: https://ppgia.pucpr.br/~fabricio/ftp/Aulas/Mestrado/AS/Aula3/SC00061G_FIPA_ACL.pdf
[EAOSE-S026]: https://www.chrismitchell.net/sfac.pdf
[EAOSE-S027]: https://arxiv.org/html/2203.00086v1
[EAOSE-S028]: https://www.ifaamas.org/Proceedings/aamas2025/pdfs/p2426.pdf
[EAOSE-S029]: https://intranet.csc.liv.ac.uk/~matt/pubs/mcapl11.pdf
[EAOSE-S030]: https://www.ijcai.org/Proceedings/15/Papers/599.pdf
[EAOSE-S031]: https://www.ifaamas.org/Proceedings/aamas2017/pdfs/p260.pdf
[EAOSE-S032]: https://arxiv.org/html/2108.08117v1
[EAOSE-S033]: https://helios2.mi.parisdescartes.fr/~moraitis/webpapers/Moraitis-IJAOSE22.pdf
[EAOSE-S034]: https://www.researchgate.net/publication/225470190_An_Empirical_Evaluation_of_the_i_Framework_in_a_Model-Based_Software_Generation_Environment
[EAOSE-S035]: https://arxiv.org/html/2503.13657v3
[EAOSE-S036]: https://arxiv.org/html/2407.01502v1
[EAOSE-S037]: https://pure.manchester.ac.uk/ws/files/1825510647/EMAS2025_Roadmap.pdf
[EAOSE-S038]: https://www.eecis.udel.edu/~decker/courses/889a/daimler.pdf
[EAOSE-S039]: https://www.researchgate.net/publication/216702294_ASPECS_an_Agent-oriented_Software_Process_for_Engineering_Complex_Systems_How_to_design_agent_societies_under_a_holonic_perspective
[EAOSE-S040]: https://lia.disi.unibo.it/corsi/2007-2008/SMA-LS/papers/9/bernon2004a.pdf
[EAOSE-S041]: https://arxiv.org/html/2406.12045v1
[EAOSE-S042]: https://arxiv.org/html/2406.13352v1
[EAOSE-S043]: https://webspace.science.uu.nl/~dalpi001/papers/ali-chop-dalp-gior-mylo-souz-10-istar.pdf
[EAOSE-S044]: https://emas-workshop.github.io/2026/papers/041_ARARA_A_LLM-based_Multi-Agent_Development_Framework_for_Conv.pdf
[EAOSE-S045]: https://emas-workshop.github.io/2026/papers/015_Ex-Plan_Explaining_BDI_Agent_Behaviour_Through_Contrastive_P.pdf
[EAOSE-S046]: https://www.ifaamas.org/Proceedings/aamas2018/pdfs/p2054.pdf
[EAOSE-S047]: https://www.jot.fm/issues/issue_2010_07/article5.pdf
[EAOSE-S048]: https://www.researchgate.net/publication/2713293_Analysis_and_design_of_multiagent_systems_using_MAS-CommonKADS
[EAOSE-S049]: https://www.researchgate.net/publication/47529129_SECURE_TROPOS_A_SECURITY-ORIENTED_EXTENSION_OF_THE_TROPOS_METHODOLOGY
[EAOSE-S050]: https://arxiv.org/html/2006.05619v1
[EAOSE-S051]: https://arxiv.org/html/2205.00979v2
[EAOSE-S052]: https://www.ifaamas.org/Proceedings/aamas08/proceedings/pdf/industrial_application_track/AAMAS08_IndTrack_16.pdf
[EAOSE-S053]: https://faculty.sites.iastate.edu/tesfatsi/archive/tesfatsi/jennings.pdf
[EAOSE-S054]: https://www.researchgate.net/publication/221419145_A_Goal-Oriented_Software_Testing_Methodology
[EAOSE-S055]: https://ii.tudelft.nl/~joostb/files/mates2010_final.pdf
[EAOSE-S056]: https://ai.jpl.nasa.gov/public/documents/papers/rax-results-isairas99.pdf
[EAOSE-S057]: https://arxiv.org/html/2304.03442v2
[EAOSE-S058]: https://sourceforge.net/projects/ingenias/files/INGENIAS%20Development%20Kit/
[EAOSE-S059]: https://sourceforge.net/projects/ptk/
[EAOSE-S060]: https://github.com/ls-cnr/AgentFactory
[EAOSE-S061]: https://ifaamas.org/Proceedings/aamas2012/papers/3F_4.pdf
[EAOSE-S062]: https://www.ijcai.org/Proceedings/73/Papers/027B.pdf
[EAOSE-S063]: https://cdn.aaai.org/ICMAS/1995/ICMAS95-042.pdf
[EAOSE-S064]: https://link.springer.com/chapter/10.1007/BFb0031846
[EAOSE-S065]: https://www.reidgsmith.com/The_Contract_Net_Protocol_Dec-1980.pdf
[EAOSE-S066]: https://jmvidal.cse.sc.edu/library/cohen90a.pdf
[EAOSE-S067]: https://www.researchgate.net/publication/251518239_Multi-agent_oriented_programming_with_JaCaMo
[EAOSE-S068]: https://www.researchgate.net/publication/221456372_MOISE_Towards_a_Structural_Functional_and_Deontic_model_for_MAS_organization
[EAOSE-S069]: https://mmi.tudelft.nl/pub/koen/GOAL_JAL.pdf
[EAOSE-S070]: https://www.ifaamas.org/Proceedings/aamas2014/aamas/p933.pdf
[EAOSE-S071]: https://www.ijcai.org/proceedings/2017/0065.pdf
[EAOSE-S072]: https://www.staff.science.uu.nl/~dalpi001/papers/mora-dalp-nguy-sien-14-aose.pdf
[EAOSE-S073]: https://www.emse.fr/~boissier/enseignement/defiia/up5/pdf/Bratman-PlansPracticalResoning.pdf
[EAOSE-S074]: https://maxapress.com/data/article/ker/preview/pdf/S026988891800005X.pdf
[EAOSE-S075]: https://arxiv.org/html/2308.08155v2
[EAOSE-S076]: https://arxiv.org/html/2308.00352v6
[EAOSE-S077]: https://arxiv.org/html/2307.07924v5
[EAOSE-S078]: https://arxiv.org/html/2210.03629v3
[EAOSE-S079]: https://docs.langchain.com/oss/python/langgraph/persistence
[EAOSE-S080]: https://docs.langchain.com/oss/python/langgraph/interrupts
[EAOSE-S081]: https://microsoft.github.io/autogen/stable/user-guide/agentchat-user-guide/tutorial/termination.html
[EAOSE-S082]: https://cdn.aaai.org/ICMAS/1996/ICMAS96-005.pdf
[EAOSE-S083]: https://www.cs.vu.nl/~wai/Papers/IJCIS97.DESIRE10.pdf
[EAOSE-S084]: https://conf.researchr.org/home/icse-2026/agent-2026
[EAOSE-S085]: https://emas.in.tu-clausthal.de/2025/assets/pdfs/emas2025-14.pdf
[EAOSE-S086]: https://link.springer.com/chapter/10.1007/978-3-032-18011-7_12
[EAOSE-S087]: https://www.cs.toronto.edu/~jenhork/Papers/Horkoff_PoEM_2009l.pdf
[EAOSE-S088]: https://aamas.csc.liv.ac.uk/Proceedings/aamas2026/pdfs/SAXY3841.pdf
[EAOSE-S089]: https://aamas.csc.liv.ac.uk/Proceedings/aamas2026/pdfs/SEJS3352.pdf
[EAOSE-S090]: https://aamas.csc.liv.ac.uk/Proceedings/aamas2026/pdfs/ZIQG2381.pdf
