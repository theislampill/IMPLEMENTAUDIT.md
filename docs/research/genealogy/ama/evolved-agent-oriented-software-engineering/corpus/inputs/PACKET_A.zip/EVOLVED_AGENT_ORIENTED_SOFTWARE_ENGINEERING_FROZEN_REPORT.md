# Evolved Agent-Oriented Software Engineering

**Revision:** EAOSE-R1-2026-09-07 · **Research cut-off:** 2026-09-07 · **State:** FROZEN (bounded evidence and judgements; archive verification is external).

## Research judgement and reading contract

**Evolved Agent-Oriented Software Engineering is a conditional engineering synthesis, not a newly discovered historical school or a universal agent-development methodology.** The established subject is the engineering of systems in which agents and their interactions are useful analysis, design or implementation abstractions. Its strongest surviving contribution is not a requirement to maximise agency. It is a family of ways to connect reasons, responsibilities, interaction and autonomous behaviour while exposing where those connections still depend on human judgement, implementation work or environmental assumptions. Historical methodological arguments, formal models, empirical comparisons and recent engineering papers support different parts of that account; none should be silently substituted for another. [EAOSE-S014] [EAOSE-S015] [EAOSE-S037] [EAOSE-S053]

The result is a system of selectable configurations with explicit interfaces, not the union of all attractive features. A conventional workflow is a legitimate outcome when it meets the same requirements more simply. A deliberative agent can be useful without a dynamic organisation. Public commitments can constrain a system whose participants have different internal architectures. A model-driven method can support construction without supplying a complete operational lifecycle. A learned component can be placed inside a bounded engineering configuration without treating its generated intentions as permissions or its reported success as an observed effect. These are this study's composition judgements, grounded in the distinctions reconstructed below rather than asserted as academic consensus.

The frozen corpus contains **113 examined candidate records**. Ninety have a retained disposition, always subject to their trigger, assumptions and cost. The rest include rejected universal claims, ceremonial prescriptions, duplicates, a superseded testing prescription, a contested global-cooperation claim and the unresolved claim of whole-method net benefit. A retained status is not a confidence percentage, a finding of universal empirical superiority, a mandate for a new control, or evidence that any particular target already implements the mechanism.

The canonical sources have durable `EAOSE-S` identifiers. Bracketed source identifiers link to the exact works; the source table records inspected sections, versions and access limits. A selected-full-text record means the declared sections were inspected, not that every page, theorem, programme and experimental result was independently verified. A metadata-only record supports its bibliographic identity, not technical details that were inaccessible. Empirical and formal evidence records are separate. There is no pooled effect size, unreported study denominator or claim of independent replication inferred from multiple editions.

## Candidate reconciliation and the archival boundary

The surviving 72-row register was preserved in full and reconciled by its mechanisms, triggers, failure conditions and composition rules—not merely by similar names. A same-lane working-history reconstruction also recovered an 84-row roster with substantive candidates absent from that register. Those identifiers are preserved as EAOSE-001–084, but their source warrants and judgements were reassessed. Twenty-eight distinct mechanisms or claims from the 72-row register required additional records, EAOSE-085–112. The separate branch-sensitive selection proposal is retained as a duplicate record, EAOSE-113. Thus **84 + 28 + 1 = 113** describes the adjudicated record construction, not an assumption made before research.

All 72 and 84 input occurrences have explicit destinations in the property ledger. One broad input can map to several records when it combines mechanisms with different prerequisites; multiple inputs can map to one record when they express the same operative distinction. Exact duplicate candidates already carrying preserved identities remain visible rather than being deleted. The full denominator therefore includes records that should not become operational requirements. The three composition proposals are separately adjudicated, and their occurrence count is not added blindly to either input population.

**The earlier reported count of 66 does not have a recovered content roster.** Searches and same-lane recovery did not establish those 66 row identities. This report does not pretend that the first 66 of the 84 are that earlier population, invent 66 placeholders, or certify a row-for-row restoration that the available evidence cannot support. The archival issue remains `UNRESOLVED_ARCHIVAL_PROVENANCE`, with the retrieval work and its exact limit recorded. The frozen canonical denominator is the independently examined, bounded candidate corpus, not certification of every previous execution claim. The recovered 84-row input is a reconstructed roster, not a byte-identical earlier full ledger. This distinction matters to anyone later reconciling historical files.

## What AOSE is engineering

An agent architecture, an agent programming language, an AOSE methodology, a runtime platform and an agent application are different units of analysis. Shoham's AOP supplies a programming perspective; BDI foundations supply a way to organise practical reasoning; Gaia, Tropos, MaSE, Prometheus and other methods supply different engineering views and prescriptions. A platform can be mature while a method's comparative benefit remains uncertain. Conversely, a method can provide useful requirements concepts even when the implementation uses conventional software. Asking a coding assistant to write a programme is not by itself the same subject as engineering the assistant as a dependable agent system. [EAOSE-S001] [EAOSE-S002] [EAOSE-S003] [EAOSE-S006] [EAOSE-S007] [EAOSE-S063]

The engineering object is also not confined to an agent's internal information processing. Requirements concern affected people and institutions. Roles allocate responsibility and permission. Communication can create publicly meaningful commitments or exchange information needed for action. Resource operations change shared state or the external world. Operators need to know what happened, which assumptions remain valid and what they are authorised and able to change. These relations require an account of participation, communication and operation as well as representation. The relevant literature supplies distinct mechanisms for those problems; this study does not pretend they are automatically implemented whenever an object is called an agent. [EAOSE-S005] [EAOSE-S023] [EAOSE-S032] [EAOSE-S049] [EAOSE-S050] [EAOSE-S074]

## A plural genealogy rather than a progress ladder

The field has several intersecting ancestries. Concurrent actors are an important neighbouring abstraction, but that alone does not establish documentary influence on every later agent method. Contract Net makes distributed allocation an explicit communication procedure. Practical-reasoning work gives persistence and reconsideration distinct roles under limited resources. BDI and AOP provide internal architectural and programming abstractions. Knowledge-engineering approaches such as MAS-CommonKADS and DESIRE bring task, expertise and compositional specification concerns. Organisational requirements work asks why actors depend on one another and what exposes them to failure. Object-oriented modelling and process engineering supply imported notations and development structures. These are not one original invention renamed repeatedly. [EAOSE-S062] [EAOSE-S065] [EAOSE-S066] [EAOSE-S073] [EAOSE-S048] [EAOSE-S083] [EAOSE-S005]

Gaia's role-oriented analysis is a real contribution, but its original assumptions should not be enlarged retrospectively. The original paper's relatively stable cooperative organisation is different from arbitrary open membership or strategic behaviour. MaSE and O-MaSE connect concrete engineering artefacts and then make organisation and process customisation more explicit. Prometheus offers pragmatic internal-design guidance. Tropos carries actor/goal/dependency reasoning across development activities, with later work on security, testing and adaptation. Their different starting points remain relevant selection conditions, not defects erased by declaring a winner. [EAOSE-S002] [EAOSE-S007] [EAOSE-S008] [EAOSE-S006] [EAOSE-S003] [EAOSE-S043] [EAOSE-S049] [EAOSE-S054]

PASSI, INGENIAS, Agent OPEN and subsequent situational method engineering develop different answers to construction and process composition. Cassiopeia, ADELFE and ASPECS preserve bottom-up, cooperative and recursive organisational possibilities. AUML and FIPA address interaction representation and message structure, while commitment and information-protocol approaches focus on the meaning and local realisation of social interaction. These branches are related, but their artefacts cannot be merged simply because they all use words such as role, goal or protocol. The typed genealogy near the end distinguishes documentary imports from convergent problem solving and mere analogy. [EAOSE-S013] [EAOSE-S011] [EAOSE-S012] [EAOSE-S047] [EAOSE-S082] [EAOSE-S040] [EAOSE-S039] [EAOSE-S024] [EAOSE-S025] [EAOSE-S023] [EAOSE-S027]

The EMAS trajectory is a documented institutional convergence of AOSE, DALT and ProMAS, not evidence that one universally accepted method emerged. Its official history distinguishes the 2012 origin discussions and first 2013 workshop. Current programmes and primary research continue symbolic language, organisation, assurance and learned-agent work together. This continuity matters because an account that starts AOSE with LLM role prompts erases both its earlier mechanisms and its longstanding criticisms. [EAOSE-S017] [EAOSE-S018] [EAOSE-S019] [EAOSE-S037] [EAOSE-S084]

## What criticism changes, rather than merely decorates

The criticisms are not an appendix that leaves every candidate intact. The field's early warnings about unsuitable agent boundaries support rejection of agents-everywhere and more-autonomy-is-better claims. The communication critique rejects private mental states as a sufficient public compliance criterion without rejecting internal mental-state reasoning. Model and tooling criticism narrows what code generation, diagram completeness and fragment availability can establish. Testability work changes the adequacy criterion rather than yielding the conclusion that meaningful testing is impossible. The composition consequently contains real omissions, substitutions and rejected sufficient-condition claims. [EAOSE-S015] [EAOSE-S023] [EAOSE-S030] [EAOSE-S031] [EAOSE-S052]

The empirical record also changes the verdict. The Comma study is an important comparison against a non-agent modelling approach, but the result is not uniformly favourable across tasks: the initial modelling and first modification have opposite time advantages. Its educational sample and study design do not identify whole-lifecycle industrial benefit. The model-driven simulation study also reports task-dependent results rather than a universal gain. Other inspected studies provide exploratory comparisons, limited classroom experience, prototypes or narrow human evaluations. The exact units, comparators, sample information and threats are recorded once in the source table's empirical records. **EAOSE-061 remains unresolved**, rather than being accepted through enthusiasm or rejected merely because the evidence is limited. [EAOSE-S061] [EAOSE-S020] [EAOSE-S010] [EAOSE-S033] [EAOSE-S055]

Deployment evidence is valuable without proving a complete method superior. The Daimler prototype exposes semantic and tooling work during migration; it must not be renamed a production-wide effectiveness study. DS1 supplies actual operational and recovery evidence, including anomalies and decisions about changes, but is not a controlled AOSE-method comparison. A manufacturing simulation can demonstrate a useful design without becoming a field frequency estimate. These distinctions protect both negative and positive evidence from exaggeration. [EAOSE-S052] [EAOSE-S056] [EAOSE-S038]

## Current engineering: continuity, translation and genuinely changed assumptions

Modern learned components alter important engineering assumptions. Their behaviour can vary across attempts, prompts, tools and provider versions. A role description need not enforce a responsibility. Retrieved text can carry an attack rather than authority. A final task reward can omit an intermediate policy condition. Several agents can share a backend, training influences or orchestration defects, so agreement need not be independent confirmation. The relevant recent failure and evaluation work motivates versioned evaluation, effect checks, adversarial testing and architecture ablation, while leaving general comparative benefit unsettled. [EAOSE-S035] [EAOSE-S036] [EAOSE-S041] [EAOSE-S042]

ReAct, AutoGen, MetaGPT, ChatDev and Generative Agents are examined for their actual mechanisms and application evidence, not automatically declared descendants of every historical AOSE school. Explicit contemporary work on roles and community engineering agendas supplies documentary evidence where it exists. Elsewhere the proper relation may be convergence or an analytical translation. Software-writing collaboration, a model's internal plan and a methodology for constructing agent systems remain separate questions. [EAOSE-S075] [EAOSE-S076] [EAOSE-S077] [EAOSE-S078] [EAOSE-S057] [EAOSE-S085] [EAOSE-S037]

Current symbolic work is equally important to the result. Peach refines the connection between logical communication and its concrete realisation. Norm-aware BDI makes it particularly clear that a social norm can be reasoned about as violable; that is not the same thing as permission to invoke a forbidden resource operation. Multi-level explanation distinguishes implementation, design and proposed domain interpretation, and its implementation scope must not be inflated. These findings refine inherited interactions and composition obligations rather than automatically adding a newly named property for each paper. [EAOSE-S088] [EAOSE-S089] [EAOSE-S090]

## Evidential and practical meaning of the composed system

The composition has four coupled kinds of state: private deliberative state, social/organisational state, actual operative state and evidential state. An agent can believe a goal is complete while a public commitment remains unfulfilled. A principal can authorise an operation that fails to execute. A correct programme can act on a stale observation. A correct external effect can still fail the legitimate acceptance criterion. The engineering system therefore needs appropriate mappings and evidence between these states, not an assumption that they are identical.

The smallest coherent form is a justified concern and acceptance meaning, an appropriate control and authority boundary, adequate evidence about consequential behaviour, and an actor who can use that evidence to accept, correct, constrain or stop the work. These functions may be served by one person, one small programme and one shared representation. No particular diagram, agent count or workflow engine is implied. Richer forms become justified when independent principals, persistent intentions, dynamic membership, uncertain effects, high consequences or learned behaviour introduce additional distinctions that a cheaper form does not preserve.

This is not a mandatory serial lifecycle. Requirements inquiry can change a design; design can expose an impossible requirement; runtime evidence can invalidate an assumption; a human can interrupt an authorised plan; independently acting participants can communicate concurrently; a change can require selective revalidation while leaving adequate independent evidence intact. The machine-readable composition model records these loops, alternatives, constraints and communication/action relations with guards and residual obligations.

The retained end-to-end witness, EAOSE-079, is an analytical obligation to make the relevant evidence compatible across those boundaries. It does not prescribe a single universal proof object or require direct observation when an adequate alternative warrant exists. EAOSE-081 adds a conditional operational question: does consequential information reach someone or something authorised and able to use it? This is different from merely storing a true statement. Both are composition judgements, not claims of new academic discovery or proven economic benefit.

The two other proposed controls do not survive as distinct operative additions. Assumption-change evidence invalidation, EAOSE-080, is subsumed by change-impact traceability and reassurance, EAOSE-053. Branch-sensitive method selection, EAOSE-113, is subsumed by justified abstraction choice, lifecycle scope, proportional representation and substitution tests. Their identities are retained so the reconciliation does not erase the proposal history, but the system must not charge users twice for the same mechanism.

Finally, self-revision is bounded. The actor changing a goal, protocol, deployed component or method must have legitimate authority for that change and must evaluate affected evidence and outstanding obligations. The existence of a mutation API or an internally preferred new rule is not sufficient. A changed assumption removes support only to the extent that the support depended on it; it does not logically falsify every downstream claim. Conversely, a new version cannot inherit an old guarantee merely by keeping the same name. These are explicit analytical composition rules, informed by the inspected method-engineering and operational work, not attributed wholesale to every historical method. [EAOSE-S008] [EAOSE-S012] [EAOSE-S032] [EAOSE-S043] [EAOSE-S050] [EAOSE-S056]

## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_TIMELINE

| Date / inspected edition | Branch | Source IDs |
| --- | --- | --- |
| 1973 | Actor formalism | [EAOSE-S062] |
| 1980 (earlier formulations acknowledged) | Contract Net | [EAOSE-S065] [EAOSE-S082] |
| 1988–1995 | Practical reasoning, commitment and BDI foundations | [EAOSE-S073] [EAOSE-S066] [EAOSE-S063] |
| 1993 | Agent-oriented programming | [EAOSE-S001] [EAOSE-S014] |
| 1996 inspected formulation; earlier i* work acknowledged by Tropos | Actor/dependency requirements ancestry | [EAOSE-S005] [EAOSE-S003] [EAOSE-S034] [EAOSE-S087] |
| 1996 | BDI design methodology | [EAOSE-S064] [EAOSE-S006] [EAOSE-S070] [EAOSE-S071] |
| 1996 | Cassiopeia/team design | [EAOSE-S082] [EAOSE-S065] |
| 1997 workshop / 1998 proceedings | MAS-CommonKADS | [EAOSE-S048] |
| 1997 | DESIRE | [EAOSE-S083] |
| 1998 | Engineering and communication criticism | [EAOSE-S015] [EAOSE-S023] |
| 2000; 2003 extension metadata | Gaia | [EAOSE-S002] [EAOSE-S022] |
| 2000–2002 | AUML and FIPA | [EAOSE-S024] [EAOSE-S025] [EAOSE-S026] [EAOSE-S023] [EAOSE-S027] |
| 2001; 2010 customisable form | MaSE to O-MaSE | [EAOSE-S007] [EAOSE-S008] [EAOSE-S009] |
| 2002 | Prometheus | [EAOSE-S006] [EAOSE-S010] [EAOSE-S046] [EAOSE-S070] [EAOSE-S071] |
| 2002 report; 2004 article; 2007–2014 extensions | Tropos and descendants | [EAOSE-S003] [EAOSE-S004] [EAOSE-S043] [EAOSE-S049] [EAOSE-S054] [EAOSE-S072] |
| 2002 | MOISE+ | [EAOSE-S068] [EAOSE-S074] [EAOSE-S089] |
| 2004 inspected method | ADELFE | [EAOSE-S040] |
| 2005 inspected formulations; 2009 ASPECS; 2010 INGENIAS process | Model-driven and process-engineering branches | [EAOSE-S011] [EAOSE-S012] [EAOSE-S013] [EAOSE-S039] [EAOSE-S047] [EAOSE-S058] [EAOSE-S059] |
| 2006–2017 | Language verification, testing and model consistency | [EAOSE-S069] [EAOSE-S029] [EAOSE-S054] [EAOSE-S030] [EAOSE-S031] [EAOSE-S070] [EAOSE-S071] |
| 2012 Dagstuhl origin; first EMAS 2013 | AOSE, DALT and ProMAS to EMAS | [EAOSE-S017] [EAOSE-S018] [EAOSE-S019] [EAOSE-S037] [EAOSE-S084] |
| 2012; 2022–2026 | Commitment and information-protocol engineering | [EAOSE-S061] [EAOSE-S027] [EAOSE-S028] [EAOSE-S088] |
| 2013 publication; 2019–2021 inspected refinements | Multidimensional programming and MAS operations | [EAOSE-S067] [EAOSE-S074] [EAOSE-S050] [EAOSE-S032] |
| 2022–2026 | Continuing model-driven, temporal, normative and explanatory BDI work | [EAOSE-S033] [EAOSE-S051] [EAOSE-S045] [EAOSE-S089] [EAOSE-S090] |
| 2023–2026 | Generative and conversational hybrids | [EAOSE-S075] [EAOSE-S076] [EAOSE-S077] [EAOSE-S078] [EAOSE-S057] [EAOSE-S035] [EAOSE-S036] [EAOSE-S041] [EAOSE-S042] [EAOSE-S085] [EAOSE-S086] [EAOSE-S044] |


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_GENEALOGY

### G01 — Actor formalism

**Problem and contribution.** Modular concurrent computation and communication. Actors supply a neighbouring computational abstraction.

**Limits and evolution.** An actor is not automatically an autonomous goal-directed agent; no direct influence on every later AOSE method is inferred. Useful non-agent/adjacent architectural comparator; resemblance is not documentary derivation. [EAOSE-S062]

### G02 — Contract Net

**Problem and contribution.** Distributed problem solvers possess different information and capabilities. Task announcement, bidding and awarding organise allocation.

**Limits and evolution.** Cooperation and truthful/useful information cannot be assumed for arbitrary strategic parties. Documented import into agent-oriented interaction and bottom-up team design; still conditional rather than universal. [EAOSE-S065] [EAOSE-S082]

### G03 — Practical reasoning, commitment and BDI foundations

**Problem and contribution.** Action needs persistence under limited reasoning resources as well as response to change. Intention, persistent goals, reconsideration and belief–desire–intention organisation.

**Limits and evolution.** Formal/conceptual models differ; mental-state vocabulary is not intelligence or authority evidence. Later BDI methods/languages turn selected concepts into executable design and verification mechanisms. [EAOSE-S073] [EAOSE-S066] [EAOSE-S063]

### G04 — Agent-oriented programming

**Problem and contribution.** Programming interacting components through higher-level mental-state abstractions. Shoham formulates AOP with agent state and communication semantics.

**Limits and evolution.** A programming paradigm is not a complete software-engineering lifecycle. An antecedent to agent engineering, not the origin of every requirements or organisational method. [EAOSE-S001] [EAOSE-S014]

### G05 — Actor/dependency requirements ancestry

**Problem and contribution.** Conventional process descriptions can omit actors' reasons and vulnerabilities. Actor, goal and dependency modelling for organisational analysis.

**Limits and evolution.** Model completeness and legitimacy depend on participation and interpretation. Tropos explicitly adopts this requirements vocabulary; empirical criticism motivates modularity and interactive evaluation. [EAOSE-S005] [EAOSE-S003] [EAOSE-S034] [EAOSE-S087]

### G06 — BDI design methodology

**Problem and contribution.** Connect agent architecture to design rather than programming ad hoc. Kinny–Georgeff–Rao methodology is documented at abstract/metadata level in this corpus.

**Limits and evolution.** Full chapter was inaccessible; no invented detailed procedure or effect claim. Later inspected Prometheus and BDI design/consistency work provide substantive mechanisms without replacing the missing text. [EAOSE-S064] [EAOSE-S006] [EAOSE-S070] [EAOSE-S071]

### G07 — Cassiopeia/team design

**Problem and contribution.** Develop cooperating teams from available behaviours and interactions. Elementary, relational and organisational behaviours support a bottom-up organisational design; Contract Net is explicitly used.

**Limits and evolution.** Simulation/team example does not establish a universal global guarantee. Preserved as an alternative organisational design trajectory rather than erased by top-down methods. [EAOSE-S082] [EAOSE-S065]

### G08 — MAS-CommonKADS

**Problem and contribution.** Extend knowledge-engineering models to interacting agents. Agent, task, expertise, organisation, coordination, communication and design views extend CommonKADS.

**Limits and evolution.** Knowledge modelling and coverage do not establish industrial superiority or mandatory agent runtime. Documented knowledge-engineering import; supplies a plural ancestry alongside OO and BDI traditions. [EAOSE-S048]

### G09 — DESIRE

**Problem and contribution.** Specify complex interacting reasoning tasks compositionally. Task, knowledge, information and control composition with explicit interfaces.

**Limits and evolution.** The worked electricity-network specification is not a method-level comparative trial. A formal knowledge-based branch; its composition obligations remain relevant to later assurance. [EAOSE-S083]

### G10 — Engineering and communication criticism

**Problem and contribution.** Agent hype and private-state communication claims outrun engineering warrant. Pitfalls analysis and a public/social account of communication challenge universal agency and compliance inferences.

**Limits and evolution.** These criticisms do not refute all autonomy or internal mental-state modelling. Later commitment-oriented engineering and explicit suitability decisions preserve the useful core while narrowing claims. [EAOSE-S015] [EAOSE-S023]

### G11 — Gaia

**Problem and contribution.** Analyse and design systems as organisations of roles and interactions. Roles express responsibilities, permissions, activities and protocols; design maps roles into agent types and services.

**Limits and evolution.** Original scope includes relatively stable cooperative organisations; full 2003 extension text was not obtained. Explicit OO/Fusion import in the original; adaptive/holonic methods are alternatives and extensions under changed assumptions, not automatic supersession. [EAOSE-S002] [EAOSE-S022]

### G12 — AUML and FIPA

**Problem and contribution.** Specify interaction patterns and interoperable agent messaging. UML-based interaction representation and standardised ACL message structure.

**Limits and evolution.** Diagram syntax and ACL structure do not establish shared semantics, authentication, authority or deployed conformance. Security work, social commitments and information-based protocols address distinct gaps rather than one universal replacement. [EAOSE-S024] [EAOSE-S025] [EAOSE-S026] [EAOSE-S023] [EAOSE-S027]

### G13 — MaSE to O-MaSE

**Problem and contribution.** Provide concrete analysis/design guidance and then support adaptive organisational designs and process tailoring. MaSE connects goals, roles, conversations and agent classes; O-MaSE combines an organisational metamodel and customisable process components.

**Limits and evolution.** The inspected O-MaSE process excludes management, deployment, testing and evaluation; do not credit implicit full-lifecycle coverage. Explicit extension from MaSE; situational composition and operational supplements remain separate obligations. [EAOSE-S007] [EAOSE-S008] [EAOSE-S009]

### G14 — Prometheus

**Problem and contribution.** Provide pragmatic guidance for developing intelligent agents, including internal design. System specification, architectural design and detailed design are related iteratively, with percepts/actions, capabilities and plans.

**Limits and evolution.** Sensor and effector engineering are outside the described core; method/tool presence does not eliminate manual judgement. Preserves an executable BDI-oriented branch, subsequently supported by consistency and language work rather than a mandatory universal method. [EAOSE-S006] [EAOSE-S010] [EAOSE-S046] [EAOSE-S070] [EAOSE-S071]

### G15 — Tropos and descendants

**Problem and contribution.** Carry actor/goal/dependency reasoning from early requirements into system development. Early and late requirements, architectural/detailed design and implementation with related goal-based analyses.

**Limits and evolution.** Requirements semantics do not automatically become executable goals or acceptance evidence. Secure Tropos, goal-oriented testing and socio-technical/adaptive directions explicitly extend or refine it; later accounts are not independent replications. [EAOSE-S003] [EAOSE-S004] [EAOSE-S043] [EAOSE-S049] [EAOSE-S054] [EAOSE-S072]

### G16 — MOISE+

**Problem and contribution.** Represent organisation beyond either structure or goals alone. Structural, functional and deontic dimensions relate roles, collective goals and normative obligations.

**Limits and evolution.** Specification of a norm does not make violation impossible or imply trusted participants. Feeds the multidimensional organisation/programming trajectory; norm-aware BDI is a related contemporary branch, not claimed to descend from every MOISE mechanism. [EAOSE-S068] [EAOSE-S074] [EAOSE-S089]

### G17 — ADELFE

**Problem and contribution.** Engineer adaptive systems through cooperative local interactions. A cooperative-design principle and development method support systems whose organisation can emerge or adapt.

**Limits and evolution.** Local non-cooperation resolution is not a blanket certificate of global goal satisfaction in arbitrary open environments. Retained as a domain-specific alternative; the stronger global-certificate candidate remains contested. [EAOSE-S040]

### G18 — Model-driven and process-engineering branches

**Problem and contribution.** Bridge requirements, design, code and reusable engineering work. PASSI provides a requirements-to-code process; INGENIAS supplies metamodel/process views; Agent OPEN offers process components; ASPECS explicitly combines PASSI/RIO into holonic engineering.

**Limits and evolution.** Similar artefact names do not establish compatible semantics or maintained tools; the inspected dates are not asserted as the first appearance of each name. Situational method engineering and later ASEME extend the operational choices; tool catalogues establish availability only. [EAOSE-S011] [EAOSE-S012] [EAOSE-S013] [EAOSE-S039] [EAOSE-S047] [EAOSE-S058] [EAOSE-S059]

### G19 — Language verification, testing and model consistency

**Problem and contribution.** Agent autonomy complicates test oracles, path coverage and design correspondence. GOAL and AIL/AJPF provide bounded formal reasoning; goal-oriented testing and design consistency checking connect different engineering views.

**Limits and evolution.** Formal validity depends on represented semantics and environmental assumptions; test criteria differ. Testability revisited narrows overbroad all-path conclusions; integration and runtime evidence remain complementary. [EAOSE-S069] [EAOSE-S029] [EAOSE-S054] [EAOSE-S030] [EAOSE-S031] [EAOSE-S070] [EAOSE-S071]

### G20 — AOSE, DALT and ProMAS to EMAS

**Problem and contribution.** Unify a research venue across methodology, languages/tools and programming of MAS. Official history documents the merging workshop trajectory.

**Limits and evolution.** Institutional convergence is not proof of one accepted methodology or mature industrial adoption. EMAS 2025/2026 and AAMAS/AGENT 2026 preserve both symbolic and learned engineering concerns. [EAOSE-S017] [EAOSE-S018] [EAOSE-S019] [EAOSE-S037] [EAOSE-S084]

### G21 — Commitment and information-protocol engineering

**Problem and contribution.** Engineering open interactions needs public obligations and independently realisable local behaviour. Comma models commitments; Pippi instantiates protocols; BSPL/SARL and Peach connect protocol semantics to concrete execution.

**Limits and evolution.** Comma evidence is mixed across modelling tasks; adapters and deployment assumptions remain obligations. A continuing branch rather than a universal replacement of BDI internals or conventional interfaces. [EAOSE-S061] [EAOSE-S027] [EAOSE-S028] [EAOSE-S088]

### G22 — Multidimensional programming and MAS operations

**Problem and contribution.** Agent, organisation and environment concerns need explicit interfaces and operational maintenance. JaCaMo-related dimensions, resource-oriented management and MAS DevOps extend design concerns into live operation.

**Limits and evolution.** The 2013 paper has abstract-only access; detailed claims use 2019/2020/2021 texts. Resource-management security is explicitly incomplete in the prototype. Operational scope is expanded by documented proposals, not retrospectively attributed to all AOSE methods. [EAOSE-S067] [EAOSE-S074] [EAOSE-S050] [EAOSE-S032]

### G23 — Continuing model-driven, temporal, normative and explanatory BDI work

**Problem and contribution.** Improve executable engineering and observable behaviour without abandoning symbolic agent foundations. ASEME, real-time BDI, contrastive and multi-level explanation, and norm-aware BDI develop distinct mechanisms.

**Limits and evolution.** Classroom/prototype evidence, excluded timing costs, unimplemented explanation levels and demonstrative norm examples constrain claims. Shows that contemporary AOSE is not synonymous with LLM orchestration. [EAOSE-S033] [EAOSE-S051] [EAOSE-S045] [EAOSE-S089] [EAOSE-S090]

### G24 — Generative and conversational hybrids

**Problem and contribution.** Learned components enable flexible tool use and communication but add stochastic and authority-boundary failures. ReAct, AutoGen, MetaGPT, ChatDev and Generative Agents offer different architectural patterns; current critical work explicitly revisits AOSE roles and evaluation.

**Limits and evolution.** No general documentary AOSE ancestry is asserted for every framework; role prompts are not enforcement, benchmarks are not lifecycle evidence. MAST, τ-bench, AgentDojo, cost-aware evaluation and explicit roles criticism refine the engineering agenda rather than certify the hybrids. [EAOSE-S075] [EAOSE-S076] [EAOSE-S077] [EAOSE-S078] [EAOSE-S057] [EAOSE-S035] [EAOSE-S036] [EAOSE-S041] [EAOSE-S042] [EAOSE-S085] [EAOSE-S086] [EAOSE-S044]

### Material relationships

| Edge | From → to | Type | Documentary basis and limit |
| --- | --- | --- | --- |
| GE01 | G01 → G04 | ONLY_ANALOGOUS | Both concern communicating software units, but actor semantics and AOP mental-state abstractions differ. No direct causal influence asserted. [EAOSE-S062] [EAOSE-S001] |
| GE02 | G02 → G07 | DOCUMENTED_IMPORT | The team-design work explicitly uses Contract Net. Import of an allocation mechanism, not identity of entire methods. [EAOSE-S082] [EAOSE-S065] |
| GE03 | G03 → G06 | DOCUMENTED_INFLUENCE | BDI architecture is explicit in the methodology title/abstract. Detailed chapter procedures inaccessible. [EAOSE-S064] |
| GE04 | G03 → G14 | DOCUMENTED_IMPORT | Prometheus develops intelligent-agent internal structures associated with BDI-style design. Not every implementation must use the same BDI language. [EAOSE-S006] [EAOSE-S063] |
| GE05 | G05 → G15 | DOCUMENTED_IMPORT | Tropos explicitly adopts actor/goal/dependency requirements concepts. Does not prove every Tropos contribution originated in i*. [EAOSE-S003] [EAOSE-S005] |
| GE06 | G05 → G19 | CRITICISM_AND_RESPONSE | Modelling and evaluation limitations motivate explicit goal evaluation and testing. Shared response concerns do not imply one linear causal succession among every paper. [EAOSE-S034] [EAOSE-S054] [EAOSE-S087] |
| GE07 | G10 → G21 | DOCUMENTED_INFLUENCE | Commitment-oriented engineering explicitly develops publicly meaningful social interaction. Internal mental-state reasoning remains a valid alternative for a different problem. [EAOSE-S023] [EAOSE-S061] |
| GE08 | G11 → G13 | CONVERGENT_DEVELOPMENT | Both organise agents through role/interaction models; O-MaSE explicitly extends MaSE. No unsupported Gaia-to-MaSE derivation asserted. [EAOSE-S002] [EAOSE-S007] [EAOSE-S008] |
| GE09 | G13 → G18 | SHARED_ANCESTRY | Process/component tailoring is shared with broader situational method engineering. Names or feature overlap alone do not establish interchangeable fragments. [EAOSE-S008] [EAOSE-S012] [EAOSE-S047] |
| GE10 | G15 → G18 | DOCUMENTED_IMPORT | Secure Tropos is explicitly mined for reusable process fragments. Extraction does not prove arbitrary assembly compatibility. [EAOSE-S047] |
| GE11 | G15 → G19 | EXPLICIT_EXTENSION | Goal-oriented testing is a documented Tropos-related extension. Generated tests still need meaningful oracles. [EAOSE-S054] [EAOSE-S072] |
| GE12 | G14 → G19 | EXPLICIT_EXTENSION | Design/protocol consistency research addresses agent design models and their checking. The formal checker does not certify deployed behaviour. [EAOSE-S070] [EAOSE-S071] |
| GE13 | G16 → G22 | DOCUMENTED_IMPORT | The multidimensional programming account relates organisational and environment dimensions. Full 2013 text not read; detailed claim uses inspected later primary texts. [EAOSE-S074] [EAOSE-S067] |
| GE14 | G18 → G23 | CONVERGENT_DEVELOPMENT | ASEME and other model-driven methods address model-to-execution correspondence. No unsupported single ancestry chain inferred. [EAOSE-S033] [EAOSE-S011] [EAOSE-S013] |
| GE15 | G19 → G20 | DOCUMENTED_INFLUENCE | Official EMAS history documents convergence of AOSE, DALT and ProMAS workshop streams. A venue merger is not a proof or unified methodology. [EAOSE-S017] |
| GE16 | G20 → G23 | EXPLICIT_EXTENSION | Current proceedings retain engineering of symbolic agents, norms and explanations. Venue continuity is not empirical replication. [EAOSE-S018] [EAOSE-S045] [EAOSE-S089] [EAOSE-S090] |
| GE17 | G20 → G24 | HYBRIDISATION | Current primary community and roles work explicitly brings AOSE concerns to learned-agent systems. No inheritance claimed for each framework without its own evidence. [EAOSE-S037] [EAOSE-S084] [EAOSE-S085] |
| GE18 | G21 → G23 | CONVERGENT_DEVELOPMENT | Public commitments and norm-aware internal planning address related but distinct obligations. A public contract is not reducible to an internal utility weight. [EAOSE-S023] [EAOSE-S089] |
| GE19 | G22 → G24 | DOMAIN_TRANSLATION | Versioning, observation and operational assurance questions apply to modern learned components with new failure modes. This is a researcher-labelled translation, not proof the frameworks historically imported MAS DevOps. [EAOSE-S032] [EAOSE-S035] [EAOSE-S041] [EAOSE-S079] [EAOSE-S080] |
| GE20 | G04 → G24 | ONLY_ANALOGOUS | Both use agent and role language in programming/construction. Terminological resemblance is not sufficient documentary ancestry. [EAOSE-S001] [EAOSE-S075] [EAOSE-S076] [EAOSE-S077] |
| GE21 | G07 → G17 | CONVERGENT_DEVELOPMENT | Bottom-up team organisation and cooperative adaptation both take interactions seriously. No direct derivation or universal equivalence asserted. [EAOSE-S082] [EAOSE-S040] |
| GE22 | G09 → G19 | SHARED_ANCESTRY | Compositional specification and language verification share formal software-engineering concerns. Do not infer direct transmission from conceptual similarity alone. [EAOSE-S083] [EAOSE-S029] [EAOSE-S069] |


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_SCOPE_AND_CARICATURES

AOSE is not agent-oriented programming alone, a platform, a particular multi-agent application, or a practice of asking software-writing agents to produce code. Goal models are not implemented goals; roles are not processes; capability is not permission; a public commitment is not an internal intention; a logical message is not automatically a transported or interpreted event. These are analytical boundaries whose source-grounded mechanisms and counterclaims are preserved separately in the ledger.

The corpus includes OO and knowledge-engineering imports, requirements and organisational schools, internal design, interaction, model-driven development, verification, method engineering, operation and modern translations. It does not independently reconstruct the entire Autonomous Agents or Multi-Agent Systems lanes, establish a target's adoption, or claim exhaustive retrieval of every publication. Source access limits are retained rather than used to invent procedures. A method's stated scope is not necessarily a defect: missing work matters only when the selected system requires it and no adequate alternative supplies it.


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER

The full denominator is **113**, examined **113/113**. All identities and dispositions follow. Detailed records, including all common fields and domain profiles, are in [EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json). None of the non-retained records is silently removed.

| Primary disposition | Count |
| --- | --- |
| ASSUMPTION_SENSITIVE | 13 |
| CEREMONY_NOT_GENERAL_PROPERTY | 2 |
| CONTESTED | 1 |
| CONTEXT_DEPENDENT | 26 |
| DOMAIN_SPECIFIC | 2 |
| DUPLICATE_CANDIDATE | 3 |
| NO_GENERAL_PROPERTY | 1 |
| REJECTED_OR_DISFAVOURED | 14 |
| RETAINED_IN_EVOLVED_FORM | 30 |
| STRONGLY_RETAINED | 18 |
| SUPERSEDED_BY_STRONGER_FORM | 1 |
| UNRESOLVED | 1 |
| USEFUL_BUT_EASILY_BUREAUCRATISED | 1 |

| Property ID | Candidate | Primary disposition |
| --- | --- | --- |
| [EAOSE-001](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Affected-stakeholder validation | STRONGLY_RETAINED |
| [EAOSE-002](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Dependency vulnerability and accountability | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-003](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Goal-to-acceptance operationalisation | STRONGLY_RETAINED |
| [EAOSE-004](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Goal conflict and alternative analysis | CONTEXT_DEPENDENT |
| [EAOSE-005](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Delegation distinguished from authority | STRONGLY_RETAINED |
| [EAOSE-006](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Requirements-to-behaviour traceability | USEFUL_BUT_EASILY_BUREAUCRATISED |
| [EAOSE-007](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Agent-paradigm suitability decision | STRONGLY_RETAINED |
| [EAOSE-008](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Agent-oriented analysis without mandatory agent runtime | CONTEXT_DEPENDENT |
| [EAOSE-009](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Explicit autonomy and refusal boundaries | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-010](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Every active component should be an agent | REJECTED_OR_DISFAVOURED |
| [EAOSE-011](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | More autonomy is inherently beneficial | REJECTED_OR_DISFAVOURED |
| [EAOSE-012](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Role responsibilities, permissions, activities and protocols | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-013](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Effective capability and permission checks | STRONGLY_RETAINED |
| [EAOSE-014](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Many-to-many role-to-agent allocation | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-015](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Collective safety and liveness obligations | ASSUMPTION_SENSITIVE |
| [EAOSE-016](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Capability-constrained dynamic organisation | CONTEXT_DEPENDENT |
| [EAOSE-017](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Explicit environment and effect interfaces | STRONGLY_RETAINED |
| [EAOSE-018](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Holonic decomposition | DOMAIN_SPECIFIC |
| [EAOSE-019](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Interaction contract with defined semantics | STRONGLY_RETAINED |
| [EAOSE-020](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Content and ontology alignment | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-021](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Observable social commitments | CONTEXT_DEPENDENT |
| [EAOSE-022](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Private mental-state semantics as open compliance criterion | REJECTED_OR_DISFAVOURED |
| [EAOSE-023](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Local protocol conformance and information causality | ASSUMPTION_SENSITIVE |
| [EAOSE-024](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Explicit dynamic role binding | CONTEXT_DEPENDENT |
| [EAOSE-025](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Fault, timeout and compensation semantics | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-026](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Protocol evolution and mixed-version compatibility | CONTEXT_DEPENDENT |
| [EAOSE-027](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | BDI internal design where deliberation warrants it | CONTEXT_DEPENDENT |
| [EAOSE-028](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Explicit plan failure and goal persistence semantics | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-029](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Capability and plan modularity | CONTEXT_DEPENDENT |
| [EAOSE-030](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Design-to-implementation correspondence | STRONGLY_RETAINED |
| [EAOSE-031](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Qualified model transformation trust | ASSUMPTION_SENSITIVE |
| [EAOSE-032](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Explicit manual and platform obligations | STRONGLY_RETAINED |
| [EAOSE-033](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Goal completion checked against consequences | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-034](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Lifecycle scope and method suitability | STRONGLY_RETAINED |
| [EAOSE-035](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Semantic compatibility of method fragments | ASSUMPTION_SENSITIVE |
| [EAOSE-036](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Work-product prerequisites and consistency | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-037](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Comparison beyond feature checklists | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-038](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Learnability and modelling burden | CONTEXT_DEPENDENT |
| [EAOSE-039](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Consumer-driven minimal representations | STRONGLY_RETAINED |
| [EAOSE-040](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | One mandatory serial lifecycle | CEREMONY_NOT_GENERAL_PROPERTY |
| [EAOSE-041](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Union of all methods as a superior method | REJECTED_OR_DISFAVOURED |
| [EAOSE-042](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Stakeholder goal validation restated | DUPLICATE_CANDIDATE |
| [EAOSE-043](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Bounded programme model checking | ASSUMPTION_SENSITIVE |
| [EAOSE-044](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Environment and abstraction validation | STRONGLY_RETAINED |
| [EAOSE-045](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Agent-level test oracles | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-046](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Collective and adversarial integration testing | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-047](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Risk-proportionate test adequacy | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-048](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Simulation validity and transfer limits | ASSUMPTION_SENSITIVE |
| [EAOSE-049](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Runtime conformance monitoring | CONTEXT_DEPENDENT |
| [EAOSE-050](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Explanation fidelity and human interpretation | CONTEXT_DEPENDENT |
| [EAOSE-051](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Versioned reproducible deployment configuration | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-052](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Operational trace correlation | CONTEXT_DEPENDENT |
| [EAOSE-053](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Change-impact traceability and reassurance | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-054](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Authorised adaptation boundaries | STRONGLY_RETAINED |
| [EAOSE-055](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Recovery, retirement and obligation discharge | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-056](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Operational handoff with an actual consumer | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-057](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Method revision under declared authority | CONTEXT_DEPENDENT |
| [EAOSE-058](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Distinguish model, demonstration, prototype and deployment | STRONGLY_RETAINED |
| [EAOSE-059](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Realistic cost-and-quality comparative baselines | STRONGLY_RETAINED |
| [EAOSE-060](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Training, integration and maintenance cost accounting | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-061](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Whole-method net benefit over conventional engineering | UNRESOLVED |
| [EAOSE-062](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Platform popularity as evidence of method effectiveness | NO_GENERAL_PROPERTY |
| [EAOSE-063](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | LLM role prompts are not role-contract enforcement | STRONGLY_RETAINED |
| [EAOSE-064](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Stochastic and version-sensitive regression evaluation | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-065](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Tool-use authority separated from generated intention | STRONGLY_RETAINED |
| [EAOSE-066](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Memory provenance and update semantics | ASSUMPTION_SENSITIVE |
| [EAOSE-067](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Untrusted-input and prompt-injection containment | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-068](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Trace-grounded multi-agent failure localisation | CONTEXT_DEPENDENT |
| [EAOSE-069](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Single-agent and workflow substitution tests | CONTEXT_DEPENDENT |
| [EAOSE-070](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Agent agreement as an independent correctness oracle | REJECTED_OR_DISFAVOURED |
| [EAOSE-071](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Unmonitored self-modification as authorised evolution | REJECTED_OR_DISFAVOURED |
| [EAOSE-072](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Independent action-effect verification | STRONGLY_RETAINED |
| [EAOSE-073](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Bounded symbolic–learned hybrid design | ASSUMPTION_SENSITIVE |
| [EAOSE-074](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Documented continuity rather than rebranding | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-075](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Modular requirements views and explicit interfaces | CONTEXT_DEPENDENT |
| [EAOSE-076](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Code generation as an assurance certificate | REJECTED_OR_DISFAVOURED |
| [EAOSE-077](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Local cooperation as adaptive-system design principle | DOMAIN_SPECIFIC |
| [EAOSE-078](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | All-path testing as the only adequate assurance | SUPERSEDED_BY_STRONGER_FORM |
| [EAOSE-079](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | End-to-end obligation-to-effect witness | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-080](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Assumption-change evidence invalidation | DUPLICATE_CANDIDATE |
| [EAOSE-081](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Consumer-closed lifecycle composition | CONTEXT_DEPENDENT |
| [EAOSE-082](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Explicit temporal feasibility for goals, plans and actions | ASSUMPTION_SENSITIVE |
| [EAOSE-083](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Security-constraint and threat-to-test traceability | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-084](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Local cooperation as a certificate of global adequacy | CONTESTED |
| [EAOSE-085](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Norm specification, violation and recovery | CONTEXT_DEPENDENT |
| [EAOSE-086](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Belief provenance, revision and observational uncertainty | ASSUMPTION_SENSITIVE |
| [EAOSE-087](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Intention retention and bounded reconsideration | CONTEXT_DEPENDENT |
| [EAOSE-088](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Authorised goal adoption, maintenance and abandonment | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-089](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Reactive–deliberative arbitration | CONTEXT_DEPENDENT |
| [EAOSE-090](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Negotiation and task-allocation procedure | CONTEXT_DEPENDENT |
| [EAOSE-091](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Interaction identity and authentication | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-092](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Engineered environment artefacts | CONTEXT_DEPENDENT |
| [EAOSE-093](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Agent, organisation and environment separation | CONTEXT_DEPENDENT |
| [EAOSE-094](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Cross-view and metamodel consistency checking | ASSUMPTION_SENSITIVE |
| [EAOSE-095](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Uncertainty-aware decision and abstention policy | ASSUMPTION_SENSITIVE |
| [EAOSE-096](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Communication uncertainty, correlation and delivery handling | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-097](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Human participation and effective intervention | CONTEXT_DEPENDENT |
| [EAOSE-098](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Accountability and evidence custody | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-099](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Non-functional constraints and adverse consequences | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-100](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Explicit compositional assurance assumptions | ASSUMPTION_SENSITIVE |
| [EAOSE-101](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Scoped reuse of engineering assets | CONTEXT_DEPENDENT |
| [EAOSE-102](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Deployment topology and trust-boundary design | CONTEXT_DEPENDENT |
| [EAOSE-103](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Idempotency and uncertain-effect reconciliation | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-104](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Resource budgets and termination conditions | RETAINED_IN_EVOLVED_FORM |
| [EAOSE-105](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Mental-state labels establish intelligence | REJECTED_OR_DISFAVOURED |
| [EAOSE-106](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Role prompts alone constitute AOSE | REJECTED_OR_DISFAVOURED |
| [EAOSE-107](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | One mandatory methodology fits every agent system | REJECTED_OR_DISFAVOURED |
| [EAOSE-108](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Complete models guarantee correct implementation | REJECTED_OR_DISFAVOURED |
| [EAOSE-109](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | ACL syntax guarantees semantic interoperability | REJECTED_OR_DISFAVOURED |
| [EAOSE-110](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Model checking certifies the deployed system without correspondence evidence | REJECTED_OR_DISFAVOURED |
| [EAOSE-111](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Increasing agent count necessarily improves results | REJECTED_OR_DISFAVOURED |
| [EAOSE-112](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Universally exhaustive methodology artefacts | CEREMONY_NOT_GENERAL_PROPERTY |
| [EAOSE-113](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json) | Branch-sensitive method selection restated as a new control | DUPLICATE_CANDIDATE |

The ledger preserves 72 R72 input rows and 84 reconstructed prior roster identities with semantic destinations. Multi-target mappings separate distinct operative conditions; aliases do not add independent mechanisms. The count-only earlier 66 roster is not identity-certified.

## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_DOMAIN_MODELS

### DM-O1: Requirements and social dependencies

**Objects and inputs.** Affected people and institutions, their goals, dependencies, resources, constraints and proposed delegations; requirements actors are not automatically runtime agents. Interviews, observations, existing practices, affected-party objections and explicit representation limits.

**Operation.** Challenge actor completeness; distinguish need, proposed solution and authority; examine dependencies and conflicting goals; translate selected outcomes into acceptance and prohibited-consequence conditions. Iterate when participation or evidence changes the problem.

**Who decides and acts.** Affected parties and legitimate decision-makers choose priorities; engineers analyse alternatives; testers and operators challenge whether the criteria are observable and usable.

**Observable output and limits.** A validated or explicitly contested requirements boundary, meaningful acceptance conditions and accountable dependencies rather than a decorative actor graph. An internally complete diagram can exclude the harmed non-user. A short jointly examined requirement and dependency record may be sufficient; softgoal arithmetic is not empirical measurement. [EAOSE-S003] [EAOSE-S005] [EAOSE-S034] [EAOSE-S043] [EAOSE-S049] [EAOSE-S087]

### DM-O2: Agent-paradigm selection

**Objects and inputs.** Alternative allocations of control, knowledge and responsibility: objects, services, actors, workflows, central controllers and agents. Fixed stakeholder needs, actual autonomy and interaction requirements, trust distribution, expertise, platform constraints and operating costs.

**Operation.** Specify what discretion or distributed control adds; compare a non-agent and a smaller-agent alternative; retain the analysis view without the runtime where appropriate. Reopen only on relevant changed assumptions.

**Who decides and acts.** Architects and stakeholders choose the smallest adequate configuration; framework availability and terminology have no selection authority.

**Observable output and limits.** A justified agent boundary or a legitimate conventional-software exit, with costs and excluded claims explicit. Extra compute, tools and repeated attempts can masquerade as a benefit of agent count. A conventional workflow that meets the same requirements is not a failed AOSE outcome. [EAOSE-S015] [EAOSE-S036] [EAOSE-S044] [EAOSE-S053]

### DM-O3: Organisational decomposition and allocation

**Objects and inputs.** Roles, responsibilities, permissions, capabilities, organisations, norms and actual agents; distinguish conceptual allocation from processes and identities. Collective goals, dependencies, legitimate authority, participant capabilities, membership stability and failure assumptions.

**Operation.** Allocate responsibilities and permissions; validate many-to-many role mappings; check collective safety/liveness separately; choose stable, capability-adaptive, holonic or cooperation-based organisation only under its assumptions; account for outstanding obligations during change.

**Who decides and acts.** Organisational principals establish duties and powers; allocators bind capable participants; agents do not obtain authority merely by announcing a role.

**Observable output and limits.** A live responsibility and permission mapping, collective obligations and explicit reconfiguration or retirement semantics. Two role holders may each be locally correct while duplicating an external action. One process can hold several roles; a static table can replace a dynamic organisation service. [EAOSE-S002] [EAOSE-S008] [EAOSE-S039] [EAOSE-S040] [EAOSE-S068] [EAOSE-S089]

### DM-O4: Interaction engineering

**Objects and inputs.** Conversation instances, identities, messages, content meanings, information dependencies and public commitments; mental intention, message receipt and contract fulfilment are different states. Participating principals, authority and trust, task dependencies, transport guarantees and observable effects.

**Operation.** Choose an interaction semantics; map global obligations or information causality to local actions; specify correlation, failure, timeouts, retries and binding; test heterogeneous implementations and adapters rather than relying on diagram syntax.

**Who decides and acts.** Principals establish commitments and accepted meanings; protocol engineers specify rules; endpoint and transport implementers realise them; monitors or counterparties assess observed interactions.

**Observable output and limits.** A specified and realised interaction whose local actions, public meaning and external consequences can be distinguished. Private beliefs cannot by themselves establish public compliance. An ordinary API with explicit semantics may be sufficient; ACL syntax or a successful send is not interoperability evidence. [EAOSE-S023] [EAOSE-S024] [EAOSE-S025] [EAOSE-S026] [EAOSE-S027] [EAOSE-S028] [EAOSE-S088]

### DM-O5: Internal design and implementation correspondence

**Objects and inputs.** Beliefs, observations, goals, intentions, plans, capabilities, events, resource artefacts and executable code; these are method-specific, not mandatory for every component. Requirements, agent responsibilities, interaction contracts, environment interfaces and exact language/platform semantics.

**Operation.** Define goal adoption, persistence, reconsideration and abandonment; design event/plan arbitration; map models to code; identify what transformations enforce and what remains manual; validate cross-view consistency and actual effects.

**Who decides and acts.** Designers select internal mechanisms; implementers establish semantic mappings; users or authorised consumers judge whether execution fulfils the requirement.

**Observable output and limits.** Executable behaviour linked to a qualified design, including failure, timing, observation and external-effect boundaries. Generated syntax can preserve the wrong semantics. A straightforward state machine or job processor can implement a simpler adequate control policy. [EAOSE-S001] [EAOSE-S006] [EAOSE-S013] [EAOSE-S046] [EAOSE-S051] [EAOSE-S052] [EAOSE-S063] [EAOSE-S066] [EAOSE-S069] [EAOSE-S070] [EAOSE-S071] [EAOSE-S073]

### DM-O6: Methodology comparison and semantic composition

**Objects and inputs.** Method fragments, work products, prerequisites, transformations, decision consumers and lifecycle scope. Problem context, needed decisions, available skills and tooling, method assumptions and evidence of use.

**Operation.** Compare usable prescriptions rather than phase mentions; select compatible fragments; discharge input/output and conceptual-mapping obligations; preserve parallel work and iteration; omit representations with no remaining consumer, while ensuring their function is covered.

**Who decides and acts.** Method engineers and actual users of the process select, tailor and revise it; no separate authority or role is mandated for every fragment.

**Observable output and limits.** An executable, bounded engineering configuration with manual obligations, compatible artefacts and retirement conditions. An encyclopaedic union can be impossible to execute. A single small method, a conventional process, or one shared record may dominate an elaborate combination. [EAOSE-S008] [EAOSE-S009] [EAOSE-S010] [EAOSE-S011] [EAOSE-S012] [EAOSE-S033] [EAOSE-S047] [EAOSE-S061]

### DM-O7: Verification and validation

**Objects and inputs.** Claims, abstract models, implementations, environments, test oracles, execution traces and acceptance evidence. Stakeholder acceptance conditions, hazards and failure modes, formal assumptions, realistic test settings and observable outcomes.

**Operation.** Validate requirements and abstraction; select programme, protocol, integration, adversarial and runtime analyses appropriate to the risk; state bounded guarantees; challenge oracles and transfer; distinguish stopped work, local success and accepted consequences.

**Who decides and acts.** Verification authors establish formal results; testers generate evidence; responsible acceptance actors judge environmental and goal correspondence; operators detect assumption change.

**Observable output and limits.** A qualified assurance argument with counterexamples, evidence limits and live obligations, not a universal certificate. Exhaustive path testing can be infeasible while structural criteria remain useful. Strong proofs can coexist with poor external validity; a targeted test may be cheaper and more appropriate than a larger formal model. [EAOSE-S029] [EAOSE-S030] [EAOSE-S031] [EAOSE-S041] [EAOSE-S042] [EAOSE-S054] [EAOSE-S056] [EAOSE-S069] [EAOSE-S083]

### DM-O8: Deployment, operation and evolution

**Objects and inputs.** Deployed versions, identities and permissions, live responsibilities, goals, configuration, logs, external resources and outstanding effects. A deployable implementation, operations constraints, handoff consumers, change proposals, observations and recovery capabilities.

**Operation.** Establish actual topology and authority; correlate operational evidence; detect drift; revalidate affected warrants after changes; control adaptation and method revision; reconcile effects on retry or restart; transfer or discharge obligations on retirement.

**Who decides and acts.** Engineers, operators, principals and affected users exchange actionable information; they may overlap but must have actual ability and authority for their decisions.

**Observable output and limits.** A maintained relation between requirements, running behaviour and evidence, with explicit unknowns and safe handling of outstanding work. A design method may not prescribe operation. A management API is not a safe-change policy; replay can repeat side effects. Conventional versioning, logs and runbooks may provide the needed mechanisms. [EAOSE-S032] [EAOSE-S050] [EAOSE-S051] [EAOSE-S052] [EAOSE-S056] [EAOSE-S079] [EAOSE-S080] [EAOSE-S081]

### DM-O9: Adoption, cost and failure evidence

**Objects and inputs.** Engineering teams, tasks, studies, tools, programmes and measured outcomes; separate a language, platform, methodology and application. Primary comparative or field reports, adverse findings, sample and setting details, baselines, lifecycle costs and shared-source information.

**Operation.** Classify model, simulation, demonstration, prototype and deployment; compare relevant costs and quality; examine sampling, expertise, confounding, multiple comparisons and unreported outcomes; do not multiply evidence by counting repeated accounts of one case.

**Who decides and acts.** Researchers disclose the study; engineering decision-makers judge transfer; a tool catalogue or workshop programme cannot establish causal benefit.

**Observable output and limits.** Claim-specific evidence partitions, explicit limits and a justified adoption question rather than a universal benefit score. Student modelling performance does not identify whole-lifecycle industrial ROI. One useful mechanism can survive weak evidence for the complete named method. [EAOSE-S010] [EAOSE-S020] [EAOSE-S033] [EAOSE-S034] [EAOSE-S035] [EAOSE-S036] [EAOSE-S038] [EAOSE-S052] [EAOSE-S055] [EAOSE-S056] [EAOSE-S061]

### DM-O10: Modern translations and hybrids

**Objects and inputs.** Learned or remotely updated decision components, prompts, memory, tools, symbolic controllers, conversational teams and operational evaluations. Documented AOSE imports, current framework semantics, versioned components, realistic baselines and observed failures.

**Operation.** Distinguish inherited concepts from convergence or analogy; bound tool authority; test stochastic and version-dependent behaviour, adversarial input and effect reconciliation; compare single-agent and conventional alternatives; preserve symbolic/learned interface obligations.

**Who decides and acts.** Principals authorise actions; framework users integrate and evaluate; model providers may change behaviour but cannot silently authorise the user's system to expand scope.

**Observable output and limits.** A qualified modern engineering configuration and continuity claim, not a role-prompt rebranding of the entire historical tradition. Correlated outputs are not independent verification; temperature zero is not proof of invariant behaviour; benchmark rewards can omit consent; provider updates can invalidate evaluation support. [EAOSE-S035] [EAOSE-S036] [EAOSE-S037] [EAOSE-S041] [EAOSE-S042] [EAOSE-S044] [EAOSE-S057] [EAOSE-S075] [EAOSE-S076] [EAOSE-S077] [EAOSE-S078] [EAOSE-S084] [EAOSE-S085] [EAOSE-S088] [EAOSE-S089] [EAOSE-S090]

### Method comparison: prescriptions are not phase checkboxes

| Method | Scope | Usable prescription | Uncovered/manual obligation | Selection and cost | Sources |
| --- | --- | --- | --- | --- | --- |
| Gaia | Organisational analysis/design; original stable cooperative scope | Roles, interactions, responsibilities and design allocation | Exact 2003 extension procedures not credited from metadata; implementation/operation remain separate | Role/dependency representation can be compact; dynamic/open settings need additional assumptions | [EAOSE-S002] [EAOSE-S022] |
| Tropos / i* ancestry | Early organisational requirements through development views | Actors, goals, dependencies, alternative reasoning and design linkage | Human requirement validation and implementation correspondence remain; later testing/security are documented extensions | Rich views help expose dependencies but can burden comprehension and modularity | [EAOSE-S003] [EAOSE-S005] [EAOSE-S034] [EAOSE-S043] [EAOSE-S049] [EAOSE-S054] [EAOSE-S072] [EAOSE-S087] |
| MaSE | Goal/role/conversation analysis and agent-system design | Concrete artefacts and transition toward implementation models | Conversation/code correspondence and deployment assumptions still require work | Useful prescriptions are not proof of comparative lifecycle superiority | [EAOSE-S007] [EAOSE-S010] |
| O-MaSE | Customisable analysis/design/construction with organisational metamodel | Capabilities, roles and process components tailored to context | Inspected process excludes management, deployment, testing and evaluation; do not silently claim full lifecycle | Fragment tailoring costs depend on semantic compatibility and expertise | [EAOSE-S008] [EAOSE-S009] |
| Prometheus | System specification, architectural and detailed agent design | Percepts/actions, capabilities, plans and iterative elaboration | Sensor/effector engineering excluded; platform-specific manual semantics remain | Pragmatic internal-design guidance, not a mandate for BDI in every component | [EAOSE-S006] [EAOSE-S010] [EAOSE-S046] |
| PASSI | Requirements-to-code multi-view development including deployment representation | Agent identification, societies, implementation and reusable construction work | Deployment models do not automatically establish operational assurance; code generation remains qualified | Model transformations and reusable assets must justify their maintenance burden | [EAOSE-S013] [EAOSE-S059] |
| INGENIAS | Metamodel/process-centred agent engineering in the inspected standardised process account | Related views and work products with tool-supported modelling/transformation | Catalogue presence does not certify maintenance or semantic preservation; no inaccessible origin detail invented | Use consistent views where their consumers justify them; a smaller model may suffice | [EAOSE-S011] [EAOSE-S058] |
| Agent OPEN | Process framework and situational method composition | Reusable process components and explicit work-product relationships | Availability of a fragment is not automatic semantic compatibility or a complete assembly | Requires method-engineering skill; no universal mandatory sequence inferred | [EAOSE-S012] [EAOSE-S047] |
| MAS-CommonKADS | Knowledge-engineering extension for multiple interacting agents | Agent, task, expertise, organisation, coordination and communication views | Analysis coverage is not proof of the real-world goals or complete runtime validation | Knowledge-heavy domains may benefit; agent runtime remains a separate selection question | [EAOSE-S048] |
| DESIRE | Compositional formal specification of interacting reasoning tasks | Task, information and control composition with explicit interfaces | Assumptions and deployed correspondence remain outside a specification alone | Formal composition can be valuable where its modelling costs are justified | [EAOSE-S083] |
| Cassiopeia | Bottom-up team organisation in the inspected soccer-team design | Elementary, relational and organisational behaviour; Contract Net import | Simulation and local design do not establish global adequacy in arbitrary environments | An alternative organisational construction route, not a required supplement to every top-down method | [EAOSE-S082] [EAOSE-S065] |
| ADELFE | Adaptive cooperative system design | Local cooperation and handling non-cooperative situations | Global success and strategic participant assumptions require separate examination | Domain-specific choice; no universal global certificate retained | [EAOSE-S040] |
| ASPECS | Holonic engineering of complex systems; explicit PASSI/RIO hybrid | Recursive organisational modelling and corresponding process | Holons and recursive decomposition are not universally warranted | Choose when recursive problem structure offsets added modelling and assurance costs | [EAOSE-S039] |
| ASEME | Model-driven multi-level agent engineering | Analysis/design transformations and executable architecture | Classroom and application evidence do not certify semantic trust or general net benefit | Tool-supported construction is conditional on qualified mappings and manual responsibilities | [EAOSE-S033] |
| Commitment / information-protocol engineering | Public interaction and independently realisable protocols | Commitments, pattern-based modelling, binding and information-causal local behaviour | Private-state compliance, transport equivalence and effect fulfilment are separate concerns | Comma has mixed task-level comparison; newer protocol/language mechanisms are not whole-lifecycle benefit trials | [EAOSE-S023] [EAOSE-S061] [EAOSE-S027] [EAOSE-S028] [EAOSE-S088] |
| BDI languages and verification | Agent-internal design and bounded programme analysis | Goal semantics, intention persistence, plan failure, reasoning and consistency/model checking | Formal model, interpreter and environment correspondences remain explicit obligations | A state machine can dominate for simpler behaviour; exhaustive paths are not the only test criterion | [EAOSE-S063] [EAOSE-S066] [EAOSE-S069] [EAOSE-S029] [EAOSE-S030] [EAOSE-S031] [EAOSE-S046] [EAOSE-S070] [EAOSE-S071] |
| Multidimensional programming / MAS DevOps | Agent, environment, organisation and operational interfaces | Resource abstractions, live management, versioning and development–operation feedback | A management prototype is not an authorised safe-change policy; a position paper is not measured effectiveness | Operational functions may use conventional tooling; no dedicated platform is mandated | [EAOSE-S074] [EAOSE-S050] [EAOSE-S032] |
| Modern conversational/generative frameworks | Framework-specific architectural and application scope | Reason/action loops, role-based coordination, memory and tool interaction | Natural-language roles do not enforce contracts; selected applications and mutable docs do not establish complete AOSE coverage | Ablate against single-agent/workflow alternatives and account for versions, uncertainty and resource costs | [EAOSE-S075] [EAOSE-S076] [EAOSE-S077] [EAOSE-S078] [EAOSE-S057] [EAOSE-S035] [EAOSE-S036] [EAOSE-S041] [EAOSE-S042] [EAOSE-S085] |


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_CEREMONY_STRIPPING_LEDGER

Every retained record has an examined minimal adequate alternative and retirement condition. The full structured ledger also names the protected failure, consumer, prerequisites and simplification costs. Simplification is a design choice that must preserve the relevant function, not a preference for fewer diagrams at any price.

| Property | Minimal adequate alternative / non-trigger | Retirement or omission |
| --- | --- | --- |
| EAOSE-001 | For a genuinely single-party local task, a short agreed requirement and counterexample review can replace an actor diagram. | Retire a separate actor model when the same validated concerns are maintained in a cheaper live requirements representation. |
| EAOSE-002 | An ordinary interface contract is sufficient when it names the real dependency and its failure response. | Drop a dedicated dependency artefact when no consequential dependence remains or its information has a maintained consumer elsewhere. |
| EAOSE-003 | A small executable example plus a human acceptance decision may suffice; not every concern needs a formal goal tree. | Retire a derived metric if it no longer represents the goal; retain or replace the underlying acceptance question. |
| EAOSE-004 | Direct stakeholder choice is cheaper when a single transparent trade-off suffices. | Omit elaborate ranking after a binding constraint makes only one adequately justified option feasible. |
| EAOSE-005 | A direct approved call inside one trust boundary may avoid a delegation protocol while retaining permission checks. | Remove delegated credentials and transfer/discharge live obligations when delegation ends. |
| EAOSE-006 | A compact requirement-to-test mapping may replace a traceability tool or exhaustive graph. | Retire unused links whose risk or consumer disappears; preserve remaining warranted correspondences. |
| EAOSE-007 | Use objects, services, actors, a workflow or a central controller when they satisfy the needs more simply. | Revisit when requirements, trust distribution or available simpler mechanisms change; no recurring ceremony absent such a trigger. |
| EAOSE-008 | A conventional requirements method may suffice if it captures the same dependency and responsibility distinctions. | Discard agent-specific notation if it adds no distinction beyond the maintained conventional model. |
| EAOSE-009 | Deterministic constrained execution is sufficient when discretion contributes no value. | Reduce autonomy when its benefit disappears; retire obsolete discretionary permissions. |
| EAOSE-012 | A small interface/responsibility record can carry the same semantics without the Gaia notation. | Retire roles that no longer distinguish responsibilities; merge representations without erasing still-live obligations. |
| EAOSE-013 | A conventional access-control and capability check may suffice; no specialised agent registry is required. | Revoke obsolete powers and remove capability declarations when the resource or actor is retired. |
| EAOSE-014 | A one-to-one mapping is acceptable when justified; no replication is required. | Simplify the mapping when scale or fault tolerance no longer warrants multiple holders. |
| EAOSE-015 | A central invariant or simpler serial execution may discharge the obligation more cheaply. | Remove a global control only when the underlying shared hazard/progress dependency disappears or is discharged by a simpler design. |
| EAOSE-016 | Keep a stable organisation when changes are rare and a controlled redeployment is cheaper. | Disable automated reorganisation when stable manual change meets the need more safely or cheaply. |
| EAOSE-017 | A narrow input/output contract is sufficient for an isolated deterministic computation. | Retire unused environment detail; retain every interface needed to discriminate consequential failure. |
| EAOSE-018 | Flat roles, modules or services are sufficient when hierarchy adds no useful boundary. | Flatten a level when it has no independent obligation, decision or encapsulation purpose. |
| EAOSE-019 | A simple typed API with explicit pre/postconditions may suffice. | Retire protocol machinery when one accountable component can satisfy the same interaction need directly. |
| EAOSE-020 | An agreed small schema and worked examples may replace a large ontology. | Retire unused vocabulary and mappings while preserving live protocol compatibility. |
| EAOSE-021 | A conventional contract/state record may be adequate where its semantics and lifecycle are clear. | Discharge or validly transfer commitments before retirement; omit a dedicated commitment calculus for simple closed interactions. |
| EAOSE-023 | Direct shared-state or ordinary request-response implementation can suffice if its semantics discharge the same obligations. | Omit specialised protocol adapters when a simpler verified interface meets the same semantics. |
| EAOSE-024 | Static named participants are sufficient in a genuinely closed stable system. | Retire dynamic binding machinery when membership is fixed and lifecycle transfer is unnecessary. |
| EAOSE-025 | A fail-fast result is sufficient when no external partial effect or live obligation remains. | Retire recovery paths only when the corresponding failure mode is eliminated or handled at another proved boundary. |
| EAOSE-026 | Stop, drain and redeploy a small closed system when live migration adds unnecessary risk. | Remove compatibility support only after old instances and dependent participants are retired or migrated. |
| EAOSE-027 | A finite-state controller, rule set or workflow may be easier when deliberation is unnecessary. | Retire BDI machinery when simpler control supplies equivalent required behaviour with lower cost. |
| EAOSE-028 | A single explicit error return is enough for a one-shot operation with no continuing goal. | Remove obsolete fallbacks when their failure conditions or resources no longer exist. |
| EAOSE-029 | A small readable plan library may need no extra module layer. | Merge modules that merely add indirection without protecting a real change or reasoning boundary. |
| EAOSE-030 | A small reviewed mapping plus targeted tests may be sufficient for a simple implementation. | Retire redundant mapping documents when equivalent live tests/interfaces carry the same evidence and consumers. |
| EAOSE-031 | Manual implementation with explicit correspondence may be cheaper for small or rapidly changing models. | Retire a generator when its validation and maintenance cost outweighs reliable manual implementation. |
| EAOSE-032 | A concise responsibility/feature-boundary note is enough; no exhaustive checklist if the missing obligations are clear. | Retire a boundary note only when the obligation disappears or its replacement is explicitly verified. |
| EAOSE-033 | An ordinary postcondition check is sufficient for a deterministic local goal. | Retire persistent monitoring only after the maintenance obligation has legitimately ended. |
| EAOSE-034 | A smaller situational method is sufficient when it addresses all relevant obligations with less overhead. | Remove a phase artefact when its purpose no longer exists, not merely to shorten a checklist. |
| EAOSE-035 | One coherent existing method may be cheaper than a tailored hybrid. | Drop incompatible or unused fragments; do not preserve them merely because a source tradition contains them. |
| EAOSE-036 | A short dependency note or shared working representation may suffice. | Retire unused work products and refresh dependency rules when method fragments change. |
| EAOSE-037 | A bounded pilot on the actual task may be more informative than an encyclopaedic comparison matrix. | Retire comparisons whose versions, task setting or decision relevance are obsolete. |
| EAOSE-038 | A simpler representation or training-limited subset may be adequate. | Remove unused notation or specialised machinery after checking that protected distinctions remain available. |
| EAOSE-039 | Use the cheapest adequate representation, reuse an existing one, or do nothing when no protected failure is live. | Retire when the consumer, risk or dependency disappears; preserve externally owed records where obligations remain. |
| EAOSE-043 | Testing, static checks or simpler deterministic design may be more proportionate. | Retire a particular proof obligation only when the property or relied-on implementation/model is no longer relevant. |
| EAOSE-044 | A direct representative effect test may suffice for a narrow well-observed environment. | Revisit when the operating envelope changes; remove obsolete model detail when it has no bearing on the claim. |
| EAOSE-045 | Simple deterministic assertions are sufficient when they capture the actual success and harm conditions. | Retire an oracle when its requirement changes or it is shown to miss a material failure; replace it rather than merely add tests. |
| EAOSE-046 | A conventional integration test may suffice; no adversarial MAS simulation is needed without a relevant threat. | Remove redundant tests after showing another layer covers the same relevant failure assumptions. |
| EAOSE-047 | Use cheaper edge, condition, scenario, property-based or risk-focused criteria when they address the claim. | Retire low-value coverage targets when they do not discriminate relevant defects, retaining the assurance obligation. |
| EAOSE-048 | Use a direct small deployment trial when it is safe and more informative; simulation may be unnecessary. | Retire a simulator for a decision if it cannot represent the distinguishing failure or relevant environment. |
| EAOSE-049 | Periodic inspection or an existing infrastructure monitor may suffice for slowly changing low-risk behaviour. | Retire monitors with no live hazard or consumer; preserve required evidence through alternate means. |
| EAOSE-050 | A clear state/error message or direct evidence may suffice; a narrative is not always needed. | Retire explanations that add confidence without decision value or fidelity; preserve a simpler truthful account. |
| EAOSE-051 | A small versioned configuration and test environment record may suffice. | Retire obsolete deployable versions after live obligations, retention needs and rollback dependencies are resolved. |
| EAOSE-052 | A single ordered trace is enough for one process; do not build distributed tracing without need. | Remove logging with no protected decision or retention duty; retain minimal required correlation. |
| EAOSE-053 | No revalidation is needed for a proved irrelevant change; a targeted regression may suffice. | Retire obsolete evidence after replacement and required retention; do not re-run unchanged irrelevant work. |
| EAOSE-054 | Manual authorised redeployment is sufficient where automation adds little value. | Revoke adaptation rights whose benefit/risk basis disappears; preserve continuity of outstanding obligations. |
| EAOSE-055 | A simple termination is sufficient when no live external obligation or retained state remains. | Retire the mechanism after all obligations and retention/transfer conditions are genuinely closed. |
| EAOSE-056 | A direct conversation plus maintained configuration may be adequate in a small team. | Retire separate handoff artefacts when the same participants and representation provide equivalent continuity. |
| EAOSE-057 | Minor editorial changes need only consistency checking; do not manufacture a meta-process for every edit. | Retire old method rules only after their obligations and downstream consumers are reconciled. |
| EAOSE-058 | A concise evidence label and locator may be sufficient. | Retire obsolete evidence labels only through corrected provenance, not favourable reinterpretation. |
| EAOSE-059 | A modest paired pilot or ablation may be enough for a local decision. | Retire comparisons when changed tasks or versions invalidate their decision relevance. |
| EAOSE-060 | A bounded cost record for the affected phase is enough when the claim is explicitly phase-limited. | Stop collecting cost detail that cannot affect the decision, while preserving declared accounting limits. |
| EAOSE-063 | Use a prompt as a soft behavioural hint when no enforceable obligation is being claimed. | Remove role-enforcement machinery for purely presentational personas without consequential obligations. |
| EAOSE-064 | Deterministic checks suffice for deterministic components; local sampling should match the claim and risk. | Retire tests only when their requirement or failure model disappears; refresh obsolete benchmarks rather than accumulating scores. |
| EAOSE-065 | An ordinary validated API call behind access control is sufficient; no special agent governor is assumed. | Remove unused tool powers and revoke scopes whose legitimate task need has ended. |
| EAOSE-066 | Short-lived explicit state may suffice when long-term retrieval adds no value. | Forget or archive entries whose purpose or retention basis ends, preserving legally/operationally owed evidence where applicable. |
| EAOSE-067 | No injection-specific machinery is needed for a non-generative parser with a validated narrow grammar and no instruction-following exposure. | Retire inaccessible tool/data paths and obsolete defences after re-evaluating the remaining threat model. |
| EAOSE-068 | A simple error report suffices when the fault is already isolated. | Retire categories that do not discriminate repair decisions; retain raw evidence needed to revisit classification. |
| EAOSE-069 | Omit multi-agent execution when the simpler baseline meets the same needs. | Revisit when task distribution or components change; retire unnecessary coordination. |
| EAOSE-072 | Direct return-value checking suffices only when that return reliably establishes the relevant effect. | Retire extra observation only when another warranted mechanism establishes the same consequential postcondition. |
| EAOSE-073 | A deterministic or purely symbolic component is preferable when it satisfies the task adequately. | Remove the learned component when its cost, variance or attack surface exceeds its demonstrated task benefit. |
| EAOSE-074 | Describe mechanisms directly when no ancestry claim is needed. | Withdraw an unsupported ancestry edge when its evidence fails; preserve the mechanism comparison separately. |
| EAOSE-075 | Keep one small model when splitting would only add navigation and synchronisation costs. | Merge views whose interfaces cost more than the comprehension benefit; retain necessary distinctions. |
| EAOSE-077 | Stable organisation, explicit allocation or central optimisation may be simpler or more predictable. | Retire adaptation rules with no measurable contribution or unacceptable stability/assurance cost. |
| EAOSE-079 | A direct requirement-to-effect test plus an ordinary permission check may instantiate the whole witness; no chain of extra documents is necessary. | Collapse redundant representations or omit unneeded levels while preserving the actual end-to-end claim and its warranted links. |
| EAOSE-081 | One engineer and one shared artefact may close all interfaces; no new owner or document per property. | Retire interfaces whose decisions/dependencies disappear or whose function is already supplied by a simpler interaction. |
| EAOSE-082 | Ordinary timeout or measured service-level tests suffice for soft deadlines; avoid hard-real-time claims without their prerequisites. | Retire specialised scheduling proofs when no hard temporal obligation remains, retaining relevant responsiveness tests. |
| EAOSE-083 | Conventional threat modelling and access-control tests may be sufficient. | Retire controls only when the asset/threat exposure ends or another justified mechanism supersedes them. |
| EAOSE-085 | A hard access rule or a simple externally enforced contract may need no autonomous normative reasoning. A conventional policy table can suffice. | Retire autonomous norm reasoning when the applicable rules no longer vary or are fully enforced by a cheaper mechanism; retain unresolved obligations until discharged. |
| EAOSE-086 | A deterministic local computation over immutable, validated input may require only ordinary input checks rather than a belief-provenance subsystem. | Drop fine-grained provenance where input immutability and trusted validation remove the failure mode, while preserving information required by consequential consumers. |
| EAOSE-087 | A one-shot deterministic operation may need no persistent intention state; a standard job lifecycle can implement the necessary persistence. | Replace intention machinery with a simpler job-state model when reconsideration has no substantive role; discharge public obligations separately. |
| EAOSE-088 | For one fixed authorised objective, an ordinary precondition, task and postcondition may be adequate. | Retire goal-management machinery when objectives are fixed and a simpler state machine preserves the required distinctions. |
| EAOSE-089 | A purely reactive controller or a sequential job processor may dominate where goals do not require deliberative persistence. | Remove the hybrid layer when one control style satisfies requirements more simply; retain explicit interruption semantics if external effects persist. |
| EAOSE-090 | Static assignment or a central scheduler is preferable when information and authority are centralised and negotiation adds no benefit. | Replace negotiation with direct assignment when the uncertainty or decentralisation that justified it disappears. |
| EAOSE-091 | A genuinely closed trusted execution boundary may use ordinary process identity; do not impose public-key infrastructure without a relevant threat. | Simplify identity machinery when trust boundaries contract, but retain controls for remaining remote or consequential interfaces. |
| EAOSE-092 | Ordinary service interfaces, data structures or databases are adequate when they expose the necessary state and operations. | Retire a specialised artefact layer when conventional interfaces preserve the same distinctions at lower cost. |
| EAOSE-093 | A small cohesive programme may keep these concerns together when the distinctions remain clear and modular separation adds no value. | Collapse unnecessary modules when interfaces are stable and a simpler representation remains semantically adequate. |
| EAOSE-094 | One unambiguous representation with executable tests may need no separate cross-view checker. | Retire redundant views or specialised checkers when a smaller representation provides equivalent assurance. |
| EAOSE-095 | Deterministic validated inputs and reversible low-consequence actions may justify a simpler direct policy. | Simplify when uncertainty and consequence diminish; retain an explicit failure outcome rather than fabricating confidence. |
| EAOSE-096 | Reliable in-process calls can use ordinary call semantics if the actual boundary satisfies those assumptions. | Remove unnecessary messaging machinery when a simpler call or workflow genuinely provides the required guarantees. |
| EAOSE-097 | Low-risk, fully specified reversible operations may not need human approval at every step; prior policy can be sufficient. | Remove redundant approval steps when risk and authority are covered by a cheaper validated control, while retaining an exception route where needed. |
| EAOSE-098 | Ephemeral low-risk calculations may need only ordinary diagnostic information; do not log everything by default. | Retire evidence when its legitimate purpose and outstanding obligations end, subject to applicable retention requirements not invented by this study. |
| EAOSE-099 | A narrow low-risk computation can use a small explicit quality budget rather than a full assurance programme. | Simplify controls when the relevant exposure disappears, not merely because the main task score remains high. |
| EAOSE-100 | Direct system-level tests and a small architecture may be cheaper than a formal assume–guarantee calculus, while still requiring explicit critical assumptions. | Retire redundant formal machinery when a simpler justified system argument supplies the same assurance. |
| EAOSE-101 | A one-off simple solution may cost less than discovering, adapting and governing a reusable asset. | Retire assets whose consumers disappear or whose adaptation cost exceeds a local replacement. |
| EAOSE-102 | A single process or conventional service can be the correct deployment for several conceptual roles. | Consolidate or simplify deployment when independent failure or control boundaries are no longer needed. |
| EAOSE-103 | A pure computation or an atomic in-process operation with no surviving external effect may need no extra deduplication mechanism. | Remove the extra mechanism only when the external effect or relevant retry/restart possibility disappears. |
| EAOSE-104 | A statically bounded operation may need only ordinary timeout and cost limits. | Retire specialised budgeting where ordinary bounded execution provides equivalent protection. |


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_CRITICISM_LEDGER

### C01 — `EAOSE-001`, `EAOSE-002`, `EAOSE-003`, `EAOSE-004`, `EAOSE-075`, `EAOSE-094`

**Strongest objection.** An apparently complete actor/goal model can be internally coherent but exclude affected people or encode unsupported preferences.

**Evidence.** The i* evaluation reports understandability and modularity difficulties; Tropos evolution and interactive goal evaluation retain human interpretation and participation. Missing-stakeholder counterexample is our analytical test, not a reported incidence estimate. [EAOSE-S003] [EAOSE-S034] [EAOSE-S043] [EAOSE-S087]

**Response and judgement.** Retain stakeholder and acceptance validation, narrow claims for diagram completeness and support modular views only when interfaces remain explicit. Goal models are inquiry instruments, not evidence that all needs or legitimate authority have been captured.

**Residual uncertainty.** No procedure here guarantees complete stakeholder discovery; representation limits and contested priorities remain live.

### C02 — `EAOSE-007`, `EAOSE-009`, `EAOSE-010`, `EAOSE-011`, `EAOSE-059`, `EAOSE-069`, `EAOSE-111`, `EAOSE-113`

**Strongest objection.** Agent abstractions can add coordination, unpredictability and cost without solving a problem that simpler software cannot solve.

**Evidence.** Historical pitfalls and modern cost-aware evaluation criticise unjustified complexity. ARARA compares selected architectures but not identical total computation, so it cannot establish universal multi-agent advantage. [EAOSE-S015] [EAOSE-S036] [EAOSE-S044] [EAOSE-S053]

**Response and judgement.** Keep an explicit conventional-software exit and single-agent substitution test; reject monotonic autonomy and agent-count claims. Select agency for a justified allocation of control, knowledge or adaptation, not a label or trend.

**Residual uncertainty.** Comparative advantage remains task-, backend-, expertise- and cost-sensitive.

### C03 — `EAOSE-012`, `EAOSE-014`, `EAOSE-015`, `EAOSE-016`, `EAOSE-018`, `EAOSE-077`, `EAOSE-084`, `EAOSE-090`

**Strongest objection.** Stable cooperative organisation assumptions do not transfer automatically to dynamic, recursive or strategically non-cooperative systems.

**Evidence.** Original Gaia states a bounded application class. O-MaSE, ASPECS and ADELFE offer different mechanisms rather than a universal successor. Manufacturing evidence inspected is simulation-based. [EAOSE-S002] [EAOSE-S008] [EAOSE-S038] [EAOSE-S039] [EAOSE-S040]

**Response and judgement.** Preserve stable roles, capability-driven reorganisation, holonic decomposition and local cooperation as conditional alternatives. Do not infer global adequacy from local cooperation or from the existence of an allocation policy.

**Residual uncertainty.** Collective guarantees require assumptions about participants, environment and timing not established by a role model alone.

### C04 — `EAOSE-005`, `EAOSE-013`, `EAOSE-021`, `EAOSE-022`, `EAOSE-091`, `EAOSE-098`

**Strongest objection.** Mental-state semantics or an ACL sender field cannot establish public compliance, authenticated identity or actual authority.

**Evidence.** Singh's critique targets the engineering use of private mental states for open communication. FIPA specifies structure; the security paper addresses additional protections. [EAOSE-S023] [EAOSE-S025] [EAOSE-S026] [EAOSE-S049]

**Response and judgement.** Separate intention, public commitment, identity and action-specific permission; prefer public evidence for publicly accountable obligations. Reject private mental state as a sufficient open-system compliance criterion; retain mental-state models for appropriate internal reasoning.

**Residual uncertainty.** Even public commitments require interpretable events, legitimate parties and adequate evidence of fulfilment.

### C05 — `EAOSE-019`, `EAOSE-020`, `EAOSE-023`, `EAOSE-024`, `EAOSE-025`, `EAOSE-026`, `EAOSE-096`, `EAOSE-102`, `EAOSE-109`

**Strongest objection.** Global interaction syntax does not by itself yield compatible local behaviour or reliable transport realisation.

**Evidence.** Pippi addresses instantiation and binding; BSPL/SARL and Peach expose implementation mappings. The industrial prototype reports semantic migration problems. [EAOSE-S023] [EAOSE-S025] [EAOSE-S027] [EAOSE-S028] [EAOSE-S052] [EAOSE-S088]

**Response and judgement.** Require an explicit local mapping and transport assumptions; check correlation, binding, ordering and effects under the selected protocol semantics. Interaction correctness is layered and version-specific, not guaranteed by well-formed messages.

**Residual uncertainty.** Adapter correctness, mixed-version evolution and failure assumptions can remain unproved in a deployment.

### C06 — `EAOSE-027`, `EAOSE-028`, `EAOSE-033`, `EAOSE-086`, `EAOSE-087`, `EAOSE-088`, `EAOSE-089`, `EAOSE-095`

**Strongest objection.** Persistent goal pursuit risks blind commitment, whereas continual reconsideration can consume resources and undermine useful continuity.

**Evidence.** Intention and resource-bounded reasoning supply distinct theoretical concerns. Language extensions and the industrial migration show concrete goal and failure-semantics differences. [EAOSE-S030] [EAOSE-S031] [EAOSE-S046] [EAOSE-S051] [EAOSE-S052] [EAOSE-S066] [EAOSE-S073]

**Response and judgement.** Preserve intention retention, reconsideration and goal lifecycle as separate mechanisms; test the chosen platform's actual behaviour. A plan that finishes is not necessarily a fulfilled goal; abandoning an intention does not discharge a public obligation.

**Residual uncertainty.** No universally optimal reconsideration or reactive–deliberative policy follows from the inspected works.

### C07 — `EAOSE-030`, `EAOSE-031`, `EAOSE-032`, `EAOSE-076`, `EAOSE-094`, `EAOSE-108`

**Strongest objection.** Model generation can preserve syntax while changing or omitting the behaviour on which a requirement depends.

**Evidence.** PASSI, INGENIAS and ASEME prescribe transformations; consistency-checking work gives bounded analyses. The Daimler prototype exposes platform-semantic migration work; student MDD results vary by task. [EAOSE-S011] [EAOSE-S013] [EAOSE-S020] [EAOSE-S033] [EAOSE-S052] [EAOSE-S070] [EAOSE-S071]

**Response and judgement.** Retain transformation and consistency tools with explicit semantics and manual obligations; reject generation as an assurance certificate. Generated code may be valuable without closing model adequacy or deployed-consequence obligations.

**Residual uncertainty.** Production-scale benefit and cross-platform semantic preservation require evidence beyond prototype or classroom tasks.

### C08 — `EAOSE-034`, `EAOSE-035`, `EAOSE-036`, `EAOSE-040`, `EAOSE-041`, `EAOSE-057`, `EAOSE-101`, `EAOSE-107`, `EAOSE-112`

**Strongest objection.** Method fragments are not interchangeable merely because they have similar artefact names; a union can have incompatible assumptions and unusable sequencing.

**Evidence.** O-MaSE and Agent OPEN make context and fragments explicit. Secure Tropos extraction identifies work-product prerequisites; platform migration illustrates nontrivial semantic adaptation. [EAOSE-S008] [EAOSE-S009] [EAOSE-S012] [EAOSE-S047] [EAOSE-S052]

**Response and judgement.** Compose only compatible fragments, preserve iteration and human decisions, and reject one mandatory serial or universal methodology. A smaller coherent method is a legitimate result; tailoring must preserve substantive responsibilities rather than simply delete work.

**Residual uncertainty.** Fragment repositories do not establish that arbitrary assemblies are economical or complete.

### C09 — `EAOSE-006`, `EAOSE-037`, `EAOSE-038`, `EAOSE-039`, `EAOSE-075`, `EAOSE-081`, `EAOSE-112`

**Strongest objection.** Expressiveness and artefact richness can increase learning and maintenance burdens or obscure what a consumer actually needs.

**Evidence.** The i* study reports modelling difficulties; ASEME evaluates a limited teaching task. Comma improves some initial modelling measures but is slower on the first modification. [EAOSE-S010] [EAOSE-S033] [EAOSE-S034] [EAOSE-S047] [EAOSE-S061]

**Response and judgement.** Retain model richness only where it enables a consequential distinction or action; require cheaper alternatives and retirement conditions. Model size, method phase coverage and document count are not quality metrics.

**Residual uncertainty.** The least burdensome adequate representation depends on users, changes and the costs of lost tacit coordination.

### C10 — `EAOSE-043`, `EAOSE-044`, `EAOSE-100`, `EAOSE-110`

**Strongest objection.** A valid formal result can be inapplicable because the environment, timing or implementation violates the model assumptions.

**Evidence.** Agent-language model checking and GOAL verification have explicit semantics. DS1 operational events and the timed-BDI exclusions show correspondence and environment burdens. [EAOSE-S029] [EAOSE-S051] [EAOSE-S056] [EAOSE-S069] [EAOSE-S083]

**Response and judgement.** State the model, guarantee, assumptions and implementation obligations separately; reject an unqualified deployment certificate. Strong bounded formal reasoning and weak external validity can coexist.

**Residual uncertainty.** This study does not independently re-prove every theorem or certify any deployed implementation.

### C11 — `EAOSE-047`, `EAOSE-078`

**Strongest objection.** Treating exhaustive path testing as the only adequate criterion can make assurance appear impossible and crowd out useful structural testing.

**Evidence.** The earlier BDI testability argument and the revisited analysis differ in criteria and treatment of failure. Path infeasibility does not imply that all meaningful testing is infeasible. [EAOSE-S030] [EAOSE-S031]

**Response and judgement.** Supersede the universal all-path obligation with risk-proportionate structural, failure and consequence-oriented assurance. Keep the computational warning, reject its inflation into abandonment of testing or a universal coverage demand.

**Residual uncertainty.** Structural coverage is still not a complete oracle for goal achievement or environmental validity.

### C12 — `EAOSE-003`, `EAOSE-033`, `EAOSE-045`, `EAOSE-046`, `EAOSE-064`, `EAOSE-072`, `EAOSE-099`

**Strongest objection.** A convenient automated oracle can reward a final state while omitting consent, intermediate violations or the real stakeholder objective.

**Evidence.** τ-bench's authors identify limitations of final-state and string-based evaluation; goal-derived tests require domain-specific oracle construction. MAST observes failures not reducible to final answer format. [EAOSE-S035] [EAOSE-S041] [EAOSE-S054]

**Response and judgement.** Separate task, policy, authority and effect evidence; combine appropriate automated checks with human or external observation where necessary. A benchmark score is evidence for its declared reward, not a universal task-success certificate.

**Residual uncertainty.** Some consequences are delayed or unobservable, and human evaluation can also be biased.

### C13 — `EAOSE-048`, `EAOSE-058`, `EAOSE-061`, `EAOSE-084`

**Strongest objection.** Demonstrations, simulations, prototypes and deployed operations answer different questions; conflating them exaggerates maturity.

**Evidence.** Manufacturing and generative-agent examples are simulations; Daimler is a prototype; DS1 is a flight demonstration with reported incidents. None is a controlled comparison of an entire AOSE methodology. [EAOSE-S020] [EAOSE-S038] [EAOSE-S052] [EAOSE-S056] [EAOSE-S057]

**Response and judgement.** Classify each case and restrict transfer; retain useful mechanisms without claiming representative deployment benefit. Existence of an operating example is not a frequency estimate or a method-level causal effect.

**Residual uncertainty.** Longitudinal comparative industrial evidence remains limited in the inspected corpus.

### C14 — `EAOSE-049`, `EAOSE-050`, `EAOSE-052`, `EAOSE-066`, `EAOSE-068`, `EAOSE-098`

**Strongest objection.** Logs and explanations can omit decisive causes; plausible explanation is not faithful reconstruction or demonstrated human understanding.

**Evidence.** Ex-Plan explicitly cannot recover unlogged derivations and tie-breaks. The 2026 multi-level framework implements only two proposed levels. The earlier human study has a small, specific setting. [EAOSE-S035] [EAOSE-S045] [EAOSE-S055] [EAOSE-S090]

**Response and judgement.** Keep provenance, trace correlation and user evaluation distinct; mark unavailable explanatory information rather than generating a causal story. Explanation mechanisms are conditional aids, not operational safety certificates.

**Residual uncertainty.** Collective causal attribution and human decision benefit at scale remain unsettled.

### C15 — `EAOSE-026`, `EAOSE-051`, `EAOSE-053`, `EAOSE-054`, `EAOSE-055`, `EAOSE-056`, `EAOSE-080`, `EAOSE-103`

**Strongest objection.** Methods that end at design or implementation cannot silently be credited with operational change, safe upgrades or recovery.

**Evidence.** O-MaSE explicitly omits several lifecycle areas; MAS DevOps proposes an operational extension. Jacamo-rest exposes management but does not address security. LangGraph restart semantics can replay effects. [EAOSE-S032] [EAOSE-S050] [EAOSE-S052] [EAOSE-S056] [EAOSE-S079] [EAOSE-S080]

**Response and judgement.** Add explicitly labelled lifecycle and external-effect obligations; track affected warrants after change; transfer or discharge pending responsibilities. An operational extension is useful but must not be attributed retroactively to every historical method.

**Residual uncertainty.** The complete composition's operational cost has not been measured in a representative comparative study.

### C16 — `EAOSE-054`, `EAOSE-057`, `EAOSE-065`, `EAOSE-071`, `EAOSE-083`, `EAOSE-097`

**Strongest objection.** Capability to mutate a system or pause a computation is not authority to change it or assurance that external action has stopped.

**Evidence.** Jacamo-rest has management operations but an explicit security gap; DS1 withheld an insufficiently tested patch; interrupts can resume by re-executing code. [EAOSE-S049] [EAOSE-S050] [EAOSE-S056] [EAOSE-S080]

**Response and judgement.** Keep permission, ability, approval, execution and consequence separate; changes to the method itself require predecessor-authorised evaluation. Self-revision is not self-authorising and nominal human approval is not automatically effective control.

**Residual uncertainty.** Human availability, response latency, irreversible effects and organisational legitimacy remain external assumptions.

### C17 — `EAOSE-058`, `EAOSE-059`, `EAOSE-060`, `EAOSE-061`, `EAOSE-062`

**Strongest objection.** Comparative studies can favour a method on a narrow task without showing lower total lifecycle cost or general superiority.

**Evidence.** Comma's first modelling exercise and first modification point in different directions. MDD classroom effects vary by task; small convenience samples, self-report and learning effects limit transfer. [EAOSE-S010] [EAOSE-S020] [EAOSE-S033] [EAOSE-S034] [EAOSE-S036] [EAOSE-S037] [EAOSE-S061]

**Response and judgement.** Retain measured results with units and validity threats; leave whole-method net benefit unresolved rather than treating lack of proof as proof of no value. EAOSE-061 remains UNRESOLVED; methodology adoption and platform popularity are not substitutes for comparative evidence.

**Residual uncertainty.** Representative, longitudinal, independently replicated cost-and-quality comparisons are still needed.

### C18 — `EAOSE-063`, `EAOSE-074`, `EAOSE-085`, `EAOSE-106`

**Strongest objection.** Role-labelled LLM collaboration may borrow language without importing AOSE's responsibilities, interaction semantics and lifecycle obligations.

**Evidence.** The roles critique explicitly relates modern frameworks to AOSE, but proposes rather than universally validates an alternative. AGENT and EMAS acknowledge the field's heritage; that does not prove each framework's descent. [EAOSE-S037] [EAOSE-S075] [EAOSE-S076] [EAOSE-S077] [EAOSE-S084] [EAOSE-S085] [EAOSE-S086]

**Response and judgement.** Classify documented imports, convergence and analogy separately; inspect actual engineering mechanisms and avoid rebranding claims. A role prompt can be useful without constituting a role contract or complete AOSE process.

**Residual uncertainty.** Which historical mechanisms improve modern engineering at acceptable cost remains an empirical question.

### C19 — `EAOSE-046`, `EAOSE-064`, `EAOSE-068`, `EAOSE-069`, `EAOSE-070`, `EAOSE-111`

**Strongest objection.** Several interacting models can share errors, amplify coordination failures and consume more resources than the baseline.

**Evidence.** MAST analyses failure traces; τ-bench examines reliability over repeated attempts; ARARA uses selected architectures with one execution per query. A shared backend is not independent evidence. [EAOSE-S035] [EAOSE-S036] [EAOSE-S041] [EAOSE-S044] [EAOSE-S075]

**Response and judgement.** Use failure localisation, repeated evaluations and ablations; reject consensus as an independent oracle or agent count as a monotonic benefit. Modern multi-agent architecture is a conditional design choice, not an evaluation methodology.

**Residual uncertainty.** Benchmark-family overlap, backend changes and unequal resources complicate external validity.

### C20 — `EAOSE-005`, `EAOSE-063`, `EAOSE-065`, `EAOSE-067`, `EAOSE-083`, `EAOSE-091`, `EAOSE-099`

**Strongest objection.** Untrusted content can be interpreted as instructions, crossing an authority boundary that a role prompt or helpful goal does not enforce.

**Evidence.** AgentDojo supplies an adversarial benchmark, not production prevalence; τ-bench's policy tasks and Secure Tropos clarify requirements and threat distinctions. [EAOSE-S041] [EAOSE-S042] [EAOSE-S049] [EAOSE-S050]

**Response and judgement.** Separate data from authority at tool boundaries; test attacks and failure handling under the chosen threat model; do not claim prompt-level immunity. Containment is a layered engineering requirement with residual risk, not a universal solved property.

**Residual uncertainty.** Novel attacks, tool privileges and changed providers can invalidate previous evidence.

### C21 — `EAOSE-066`, `EAOSE-070`, `EAOSE-086`, `EAOSE-095`

**Strongest objection.** A generated memory or socially plausible narrative may be mistaken for grounded state or independent confirmation.

**Evidence.** Generative Agents studies a sandbox and believability; Ex-Plan exposes unlogged information limits. Neither establishes truth of arbitrary generated recollections. [EAOSE-S045] [EAOSE-S057]

**Response and judgement.** Retain source-aware memory and uncertainty where consequential; separate believability, consistency and factual grounding. Memory is an engineered state representation with update and provenance obligations, not a trustworthy autobiographical record by default.

**Residual uncertainty.** Evaluation of long-horizon memory under real changes and adversarial inputs remains incomplete.

### C22 — `EAOSE-082`, `EAOSE-087`, `EAOSE-089`, `EAOSE-095`, `EAOSE-104`

**Strongest objection.** Timing or termination claims can omit reasoning overhead, delayed reactions, resource-reporting failures or already-issued actions.

**Evidence.** Timed-BDI work excludes plan search and BDI-loop costs and delays external reaction. AutoGen termination checks have defined boundaries; resource-bounded reasoning motivates explicit metacost. [EAOSE-S051] [EAOSE-S056] [EAOSE-S073] [EAOSE-S081]

**Response and judgement.** State covered costs and scheduling assumptions, budget reasoning and recovery, and distinguish conversation termination from effect cancellation. No unrestricted hard-real-time or cost ceiling follows from the inspected models or framework options.

**Residual uncertainty.** Worst-case analysis of learned remote components and unbounded environments may require narrower autonomy or different architectures.

### C23 — `EAOSE-077`, `EAOSE-084`, `EAOSE-085`, `EAOSE-099`

**Strongest objection.** Local cooperation or norm conformity does not by itself certify global adequacy; some norms are intentionally violable whereas permission boundaries may be hard.

**Evidence.** ADELFE uses cooperative local interactions for adaptation. Norm-aware BDI explicitly reasons about violation and consequences; MOISE+ separates organisational dimensions. [EAOSE-S040] [EAOSE-S068] [EAOSE-S089]

**Response and judgement.** Keep ADELFE domain-specific; preserve the global-certificate claim as contested; distinguish social norm valuation from hard security enforcement. The conditions under which local mechanisms yield the required collective outcome must be established, not assumed.

**Residual uncertainty.** Global consequences, strategic participants and conflicting normative authorities remain challenging.

### C24 — `EAOSE-030`, `EAOSE-051`, `EAOSE-094`, `EAOSE-096`, `EAOSE-102`

**Strongest objection.** Separating logical communication from a transport can improve reuse while introducing adapter and finalisation obligations.

**Evidence.** Peach supplies an operational model and alternatives for communication realisation; it does not certify every transport, trust arrangement or deployment. [EAOSE-S027] [EAOSE-S028] [EAOSE-S052] [EAOSE-S088]

**Response and judgement.** Treat pending communicative acts, finalised messages and external effects as distinct; qualify correspondence through adapters and versions. New language mechanisms refine inherited interaction and mapping properties rather than justify a novel universal control.

**Residual uncertainty.** Implementation conformance and performance under realistic faults remain deployment-specific obligations.

### C25 — `EAOSE-005`, `EAOSE-055`, `EAOSE-079`, `EAOSE-080`, `EAOSE-081`, `EAOSE-100`, `EAOSE-103`, `EAOSE-113`

**Strongest objection.** The proposed evolved composition risks merely restating generic good engineering, duplicating controls or implying global proof from local checks.

**Evidence.** This is an adversarial researcher objection grounded in the different scopes and adverse cases above, not an empirical refutation of a field-recognised Evolved school. [EAOSE-S003] [EAOSE-S008] [EAOSE-S012] [EAOSE-S023] [EAOSE-S032] [EAOSE-S041] [EAOSE-S052] [EAOSE-S056] [EAOSE-S080]

**Response and judgement.** Retain the end-to-end obligation-to-effect relation as analytical; merge change-triggered revalidation into EAOSE-053 and branch-sensitive selection into existing selection mechanisms. Make consumer closure conditional and permit one mechanism to serve several concerns. Composition is a conditional relational account, not a novel theorem, mandatory checklist or empirically established superior method.

**Residual uncertainty.** Its net benefit and adequacy in a particular target remain unproven until that target supplies evidence.

### C26 — `EAOSE-058`, `EAOSE-062`, `EAOSE-074`

**Strongest objection.** Bibliographic existence, a project catalogue or a familiar name can be mistaken for inspected semantics, maintenance or independent evidence.

**Evidence.** Several canonical entries have only metadata or abstract access; AgentFactory here is a name-colliding JADE thesis tool, not evidence about the established Agent Factory platform. Multiple editions and same-programme reports are related records. [EAOSE-S004] [EAOSE-S016] [EAOSE-S017] [EAOSE-S018] [EAOSE-S019] [EAOSE-S021] [EAOSE-S022] [EAOSE-S058] [EAOSE-S059] [EAOSE-S060] [EAOSE-S064] [EAOSE-S067] [EAOSE-S086]

**Response and judgement.** Preserve exact access levels and edition relations, do not use inaccessible details as warrants, and do not count related reports as replications. Source verification is claim-specific; an explicit access limit is not a substantive negative result about the method.

**Residual uncertainty.** Unavailable texts may contain relevant nuance; this corpus does not claim exhaustive retrieval or present maintenance certification.


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_EVOLUTION_UNDER_CRITICISM

| Criticism | Transition | Actual changed mechanism or claim |
| --- | --- | --- |
| C01 | REFINED | Retain stakeholder and acceptance validation, narrow claims for diagram completeness and support modular views only when interfaces remain explicit. |
| C02 | NARROWED | Keep an explicit conventional-software exit and single-agent substitution test; reject monotonic autonomy and agent-count claims. |
| C03 | DOMAIN_SPECIFIC | Preserve stable roles, capability-driven reorganisation, holonic decomposition and local cooperation as conditional alternatives. |
| C04 | REPLACED | Separate intention, public commitment, identity and action-specific permission; prefer public evidence for publicly accountable obligations. |
| C05 | REFINED | Require an explicit local mapping and transport assumptions; check correlation, binding, ordering and effects under the selected protocol semantics. |
| C06 | REFINED | Preserve intention retention, reconsideration and goal lifecycle as separate mechanisms; test the chosen platform's actual behaviour. |
| C07 | NARROWED | Retain transformation and consistency tools with explicit semantics and manual obligations; reject generation as an assurance certificate. |
| C08 | REFINED | Compose only compatible fragments, preserve iteration and human decisions, and reject one mandatory serial or universal methodology. |
| C09 | NARROWED | Retain model richness only where it enables a consequential distinction or action; require cheaper alternatives and retirement conditions. |
| C10 | NARROWED | State the model, guarantee, assumptions and implementation obligations separately; reject an unqualified deployment certificate. |
| C11 | REPLACED | Supersede the universal all-path obligation with risk-proportionate structural, failure and consequence-oriented assurance. |
| C12 | REFINED | Separate task, policy, authority and effect evidence; combine appropriate automated checks with human or external observation where necessary. |
| C13 | NARROWED | Classify each case and restrict transfer; retain useful mechanisms without claiming representative deployment benefit. |
| C14 | REFINED | Keep provenance, trace correlation and user evaluation distinct; mark unavailable explanatory information rather than generating a causal story. |
| C15 | HYBRIDISED | Add explicitly labelled lifecycle and external-effect obligations; track affected warrants after change; transfer or discharge pending responsibilities. |
| C16 | REFINED | Keep permission, ability, approval, execution and consequence separate; changes to the method itself require predecessor-authorised evaluation. |
| C17 | STILL_CONTESTED | Retain measured results with units and validity threats; leave whole-method net benefit unresolved rather than treating lack of proof as proof of no value. |
| C18 | HYBRIDISED | Classify documented imports, convergence and analogy separately; inspect actual engineering mechanisms and avoid rebranding claims. |
| C19 | NARROWED | Use failure localisation, repeated evaluations and ablations; reject consensus as an independent oracle or agent count as a monotonic benefit. |
| C20 | REFINED | Separate data from authority at tool boundaries; test attacks and failure handling under the chosen threat model; do not claim prompt-level immunity. |
| C21 | NARROWED | Retain source-aware memory and uncertainty where consequential; separate believability, consistency and factual grounding. |
| C22 | NARROWED | State covered costs and scheduling assumptions, budget reasoning and recovery, and distinguish conversation termination from effect cancellation. |
| C23 | DOMAIN_SPECIFIC | Keep ADELFE domain-specific; preserve the global-certificate claim as contested; distinguish social norm valuation from hard security enforcement. |
| C24 | REFINED | Treat pending communicative acts, finalised messages and external effects as distinct; qualify correspondence through adapters and versions. |
| C25 | REFINED | Retain the end-to-end obligation-to-effect relation as analytical; merge change-triggered revalidation into EAOSE-053 and branch-sensitive selection into existing selection mechanisms. Make consumer closure conditional and permit one mechanism to serve several concerns. |
| C26 | REFINED | Preserve exact access levels and edition relations, do not use inaccessible details as warrants, and do not count related reports as replications. |


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_INTERNAL_TENSIONS

### T01: Expressive social models versus Learnable, maintainable representations

`EAOSE-001`, `EAOSE-038`, `EAOSE-039`, `EAOSE-075`. **Costs:** Omitted affected parties and dependencies; Model complexity and stale diagrams.

**Discriminator.** Use richer views when they change a consequential decision; simplify when a tested cheaper view preserves it. **Possible composition:** Modular requirements views with explicit interfaces. **Failure:** Fragmentation hides cross-view conflicts. Selection requires local evidence; the synthesis does not establish a universal optimum. [EAOSE-S003] [EAOSE-S034] [EAOSE-S087]

### T02: Useful autonomy versus Predictable bounded behaviour

`EAOSE-007`, `EAOSE-009`, `EAOSE-043`, `EAOSE-054`. **Costs:** Central bottleneck and inflexibility; Larger behaviour space and assurance cost.

**Discriminator.** Prefer autonomous choice for actual distributed knowledge/control; prefer constrained workflow when its fixed policy is adequate. **Possible composition:** Bounded discretion inside explicit authority and consequence checks. **Failure:** An apparent bound is not enforced at the tool boundary. Selection requires local evidence; the synthesis does not establish a universal optimum. [EAOSE-S015] [EAOSE-S029] [EAOSE-S053] [EAOSE-S041]

### T03: Lifecycle completeness versus Operational burden

`EAOSE-034`, `EAOSE-035`, `EAOSE-039`, `EAOSE-081`, `EAOSE-112`. **Costs:** Unowned deployment or recovery work; Method machinery with no consumer.

**Discriminator.** Add a fragment only to close a needed decision or action; test input/output compatibility and consumer ability. **Possible composition:** A minimal method plus triggered specialised fragments. **Failure:** Deletion removes tacit coordination; union creates contradictions. Selection requires local evidence; the synthesis does not establish a universal optimum. [EAOSE-S008] [EAOSE-S012] [EAOSE-S032] [EAOSE-S047]

### T04: Interoperable semantics versus Platform-specific leverage

`EAOSE-019`, `EAOSE-023`, `EAOSE-031`, `EAOSE-102`. **Costs:** Translation and transport costs; Lock-in and hidden semantic drift.

**Discriminator.** Use a standard or abstract protocol where independent endpoints need it; native platform features where their assumptions remain valid. **Possible composition:** Explicit adapters with conformance tests. **Failure:** Syntax or method names conceal changed goal/protocol meaning. Selection requires local evidence; the synthesis does not establish a universal optimum. [EAOSE-S025] [EAOSE-S028] [EAOSE-S052] [EAOSE-S088]

### T05: Automation of construction versus Trust in semantic correspondence

`EAOSE-030`, `EAOSE-031`, `EAOSE-032`, `EAOSE-076`, `EAOSE-094`. **Costs:** Manual errors and effort; Transformation bugs and false confidence.

**Discriminator.** Automate repeatable well-specified mappings; retain manual work where semantic judgement is not encoded. **Possible composition:** Generated skeletons plus qualified manual obligations and targeted checks. **Failure:** Manual edits invalidate generator assumptions. Selection requires local evidence; the synthesis does not establish a universal optimum. [EAOSE-S011] [EAOSE-S013] [EAOSE-S020] [EAOSE-S052] [EAOSE-S071]

### T06: Adaptive organisation versus Continuity of obligations

`EAOSE-016`, `EAOSE-053`, `EAOSE-054`, `EAOSE-055`. **Costs:** Rigid capacity allocation; Orphaned duties and stale warrants.

**Discriminator.** Permit membership/goal change only with capability and outstanding-obligation checks appropriate to its consequences. **Possible composition:** Controlled reallocation with effect reconciliation. **Failure:** Every local reallocation passes but collective liveness fails. Selection requires local evidence; the synthesis does not establish a universal optimum. [EAOSE-S008] [EAOSE-S027] [EAOSE-S050] [EAOSE-S056]

### T07: Internal deliberative freedom versus Public accountability

`EAOSE-021`, `EAOSE-022`, `EAOSE-027`, `EAOSE-085`. **Costs:** Rigid prescription may block negotiation; Private intentions cannot prove compliance.

**Discriminator.** Use mental-state models internally; publicly interpretable commitments for independent principals. **Possible composition:** BDI action selection constrained by public interaction and authority boundaries. **Failure:** Dropping an intention is mistaken for cancellation of a commitment. Selection requires local evidence; the synthesis does not establish a universal optimum. [EAOSE-S023] [EAOSE-S063] [EAOSE-S066] [EAOSE-S089]

### T08: Strong formal claims versus Environmental realism and tractability

`EAOSE-043`, `EAOSE-047`, `EAOSE-048`, `EAOSE-082`. **Costs:** Abstract result misses real failure; Exhaustive analysis becomes infeasible.

**Discriminator.** Select a bounded formal claim and validate its consequential assumptions; use empirical checks for what the model does not establish. **Possible composition:** Formal constraints plus realistic fault and consequence tests. **Failure:** Simulation validates its own assumptions rather than the deployment. Selection requires local evidence; the synthesis does not establish a universal optimum. [EAOSE-S029] [EAOSE-S030] [EAOSE-S031] [EAOSE-S051] [EAOSE-S056]

### T09: Explainability and accountability versus Privacy, storage and performance

`EAOSE-050`, `EAOSE-052`, `EAOSE-066`, `EAOSE-098`. **Costs:** Unattributable or unexplainable failure; Excessive retained data and misleading stories.

**Discriminator.** Record evidence needed by legitimate consumers, with retention and access boundaries; explicitly mark unavailable causes. **Possible composition:** Layered trace and explanation views. **Failure:** A high-level explanation invents the unlogged causal link. Selection requires local evidence; the synthesis does not establish a universal optimum. [EAOSE-S045] [EAOSE-S055] [EAOSE-S090]

### T10: Collective specialisation versus Cost and reliable evaluation

`EAOSE-064`, `EAOSE-069`, `EAOSE-073`, `EAOSE-104`, `EAOSE-111`. **Costs:** A single agent lacks relevant capability; Extra calls and correlated errors.

**Discriminator.** Ablate under relevant cost/quality constraints; retain extra agents only for supported advantage or necessary responsibility boundaries. **Possible composition:** Bounded symbolic control with learned proposals and separate consequence evidence. **Failure:** Repeated shared-model agreement is treated as independent verification. Selection requires local evidence; the synthesis does not establish a universal optimum. [EAOSE-S035] [EAOSE-S036] [EAOSE-S041] [EAOSE-S044] [EAOSE-S075]

### T11: Intention persistence versus Timely revision and reaction

`EAOSE-087`, `EAOSE-089`, `EAOSE-095`, `EAOSE-104`. **Costs:** Thrashing and lost coordination; Blind persistence or missed urgent events.

**Discriminator.** Set reconsideration/interruption conditions by environment change and the cost of delayed or repeated reasoning. **Possible composition:** Persistent plans with defined reactive interrupts. **Failure:** Unaccounted planning cost defeats the nominal timing bound. Selection requires local evidence; the synthesis does not establish a universal optimum. [EAOSE-S066] [EAOSE-S073] [EAOSE-S046] [EAOSE-S051]

### T12: Human authorisation versus Operational speed and effective control

`EAOSE-005`, `EAOSE-065`, `EAOSE-097`, `EAOSE-103`. **Costs:** Excessive approval burden; Unapproved or uncancellable effects.

**Discriminator.** Use prior bounded delegation for routine cases; live intervention only where meaningful and timely, with pending-effect semantics. **Possible composition:** Policy authorisation plus exceptional human decision. **Failure:** Approval happens after an irreversible effect or restarts duplicate it. Selection requires local evidence; the synthesis does not establish a universal optimum. [EAOSE-S041] [EAOSE-S056] [EAOSE-S080]

### T13: Local cooperation and norm flexibility versus Global constraints and hard permissions

`EAOSE-015`, `EAOSE-077`, `EAOSE-084`, `EAOSE-085`, `EAOSE-099`. **Costs:** Overconstraint defeats adaptation; Local choices can violate collective or non-delegable duties.

**Discriminator.** Use cooperation/violable norms only where their consequences are acceptable; enforce hard authority boundaries independently. **Possible composition:** Local adaptation inside externally justified constraints. **Failure:** A penalty weight makes a forbidden action appear economically preferable. Selection requires local evidence; the synthesis does not establish a universal optimum. [EAOSE-S040] [EAOSE-S068] [EAOSE-S089]

### T14: Useful innovation versus Justified transfer and evidence limits

`EAOSE-007`, `EAOSE-058`, `EAOSE-059`, `EAOSE-061`. **Costs:** Overcaution rejects useful mechanisms; Novel labels overstate demonstrated benefit.

**Discriminator.** Accept mechanism-specific evidence for a bounded use while withholding global method superiority. **Possible composition:** Explicit conditional adoption hypothesis with a conventional baseline. **Failure:** A successful pilot is promoted into a universal method mandate. Selection requires local evidence; the synthesis does not establish a universal optimum. [EAOSE-S010] [EAOSE-S020] [EAOSE-S036] [EAOSE-S037] [EAOSE-S061]


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_COMPOSED_SYSTEM

The composed system connects four kinds of state without conflating them: private beliefs/goals/plans, social roles/commitments/authority, actual resources/effects, and evidential assumptions/versions/warrants. The engineering operation is the creation and maintenance of justified mappings among these states. A mapping can be implemented by one shared artefact or several interoperable mechanisms; the research does not prescribe one owner or control per property.

The minimal configuration needs a legitimate acceptance meaning, a justified control boundary, adequate evidence of consequential behaviour and an actor capable and authorised to use that evidence. Specialised formalisms enter only when they protect a distinction this cheaper form cannot adequately preserve. Local success, communication success, authorisation and stakeholder acceptance are separate predicates. Their conjunction is not automatically established by validating any one component.

### C0 — Conventional-software exit

**Select when:** Fixed or centrally controlled behaviour satisfies the same legitimate needs without useful agent-specific discretion. **Omit/substitute:** Objects, services, actors, workflows or a central controller may replace an agent runtime. Actor/goal analysis can be retained without agent processes.

**Cost and incompatible assumption:** Loss of justified local autonomy must be tested, not assumed harmless. Choosing AOSE analysis does not mandate agent implementation.

**Supporting properties:** `EAOSE-001`, `EAOSE-003`, `EAOSE-007`, `EAOSE-008`, `EAOSE-030`, `EAOSE-039`, `EAOSE-044`, `EAOSE-059`, `EAOSE-072`.

### C1 — Deliberative agent engineering

**Select when:** Persistent objectives, partial knowledge and meaningful means selection warrant a deliberative architecture. **Omit/substitute:** Use a job lifecycle or state machine when it preserves the needed persistence/failure semantics more simply.

**Cost and incompatible assumption:** Plan interactions, reconsideration and observation can complicate assurance. Private intentions are neither public commitments nor permissions.

**Supporting properties:** `EAOSE-017`, `EAOSE-027`, `EAOSE-028`, `EAOSE-029`, `EAOSE-030`, `EAOSE-033`, `EAOSE-043`, `EAOSE-047`, `EAOSE-086`, `EAOSE-087`, `EAOSE-088`, `EAOSE-089`, `EAOSE-104`.

### C2 — Stable cooperative organisation

**Select when:** Relatively stable participants and cooperative responsibilities fit an explicit role organisation. **Omit/substitute:** A static responsibility table and shared implementation may be sufficient; roles are not processes.

**Cost and incompatible assumption:** Collective obligations and many-to-many mappings must be checked. Stable/cooperative assumptions do not cover arbitrary membership or strategic misbehaviour.

**Supporting properties:** `EAOSE-012`, `EAOSE-013`, `EAOSE-014`, `EAOSE-015`, `EAOSE-019`, `EAOSE-020`, `EAOSE-025`, `EAOSE-030`, `EAOSE-046`.

### C3 — Open-principal interaction engineering

**Select when:** Independent principals require publicly meaningful obligations, communication semantics and local realisation. **Omit/substitute:** A conventional explicit API/contract can suffice; use commitments or information-based protocols only for their additional functions.

**Cost and incompatible assumption:** Identity, interpretation, binding and uncertain effects add overhead. Observed syntax, private belief or willingness to cooperate does not establish compliance.

**Supporting properties:** `EAOSE-005`, `EAOSE-019`, `EAOSE-020`, `EAOSE-021`, `EAOSE-023`, `EAOSE-024`, `EAOSE-025`, `EAOSE-026`, `EAOSE-055`, `EAOSE-085`, `EAOSE-091`, `EAOSE-096`, `EAOSE-098`, `EAOSE-102`, `EAOSE-103`.

### C4 — Adaptive or recursive organisational alternatives

**Select when:** Changing capabilities/membership, recursive structure or cooperative local adaptation is an actual problem. **Omit/substitute:** Choose capability-driven organisation, holons or local cooperation by their assumptions; they are not all mandatory or interchangeable.

**Cost and incompatible assumption:** Reconfiguration can orphan obligations; local adaptation may fail collectively. Adaptation is not self-authorisation or a global success certificate.

**Supporting properties:** `EAOSE-015`, `EAOSE-016`, `EAOSE-018`, `EAOSE-024`, `EAOSE-053`, `EAOSE-054`, `EAOSE-055`, `EAOSE-077`, `EAOSE-084`, `EAOSE-085`.

### C5 — Bounded generative hybrid

**Select when:** Learned language/reasoning behaviour contributes a justified capability not adequately supplied by a simpler alternative. **Omit/substitute:** Compare single-agent and workflow alternatives; use symbolic constraints and separate effect evidence where warranted.

**Cost and incompatible assumption:** Correlated errors, provider/version changes, adversarial input and evaluation cost. Role prompts, temperature zero, agent consensus and a successful tool call are not general assurance.

**Supporting properties:** `EAOSE-003`, `EAOSE-005`, `EAOSE-013`, `EAOSE-030`, `EAOSE-044`, `EAOSE-063`, `EAOSE-064`, `EAOSE-065`, `EAOSE-066`, `EAOSE-067`, `EAOSE-068`, `EAOSE-069`, `EAOSE-072`, `EAOSE-073`, `EAOSE-095`, `EAOSE-097`, `EAOSE-099`, `EAOSE-103`, `EAOSE-104`.

### Real communication and operation

**IF1 — Affected stakeholders ↔ requirements engineers and legitimate decision-makers.** Needs, objections, dependencies, alternatives and acceptance meaning. Approve, contest or revise requirements; this changes the accepted engineering objective, not automatically the software. Evidence: Participation/representation limits and reasoned acceptance decisions. (`EAOSE-001`, `EAOSE-002`, `EAOSE-003`, `EAOSE-004`, `EAOSE-099`).

**IF2 — Principals ↔ agents, counterparties and resource owners.** Delegations, commitments, credentials, requests and revocations. Create or discharge obligations and permit or refuse resource operations according to actual authority. Evidence: Interpretable events, authenticated requests and action-specific permissions. (`EAOSE-005`, `EAOSE-013`, `EAOSE-021`, `EAOSE-085`, `EAOSE-091`).

**IF3 — Executable agents/controllers ↔ environment resources and external services.** Observations, commands, acknowledgements and status queries. Change real resources or relationships; sending a command and achieving its consequence are distinct. Evidence: Qualified external observation, trusted state or other adequate warrants, with uncertainty preserved. (`EAOSE-017`, `EAOSE-072`, `EAOSE-092`, `EAOSE-096`, `EAOSE-103`).

**IF4 — Engineers and evaluators ↔ operators and acceptance consumers.** Versioned implementations, assumptions, traces, tests, limitations and recovery instructions. Deploy, accept, reject, constrain, recover, revalidate or retire within legitimate authority. Evidence: Usable handoff and demonstrated ability to act; paperwork alone is insufficient. (`EAOSE-030`, `EAOSE-044`, `EAOSE-051`, `EAOSE-053`, `EAOSE-054`, `EAOSE-055`, `EAOSE-056`, `EAOSE-081`, `EAOSE-097`).

### Feedback, interruption and revision

Iterative requirements and design inquiry; concurrent local agents and public interactions where selected; feedback from effects and operational observations; human interruption; assumption-triggered revalidation. There is no universal forced serial pipeline.

**Triggers.** Changed requirements, public obligations, membership, goals, permissions, protocol or tool versions, learned model, observed environment, or the engineering method itself.

**Actors.** The legitimate principal/method authority and capable engineering/operating actors; authority is not invented by the successor method.

**Process.** Identify affected warrants and outstanding effects; evaluate the proposed change under existing authority and acceptance; preserve unaffected adequate evidence; accept, reject or narrow the change; reconcile live responsibilities.

**Continuity.** Invalidate support whose assumptions changed, not every claim indiscriminately. A changed assumption can remove one warrant while another remains sufficient.

**Prohibition.** No automatic permission expansion, unsupported self-certification, hidden cancellation of commitments or replay of irreversible effects.

### Composition-induced candidates

**CI1 — Cross-level conformance and acceptance: RETAINED_AS_ANALYTICAL_COMPOSITION_OBLIGATION.** The conjunction of stakeholder legitimacy, public obligation, authority, executable correspondence and actual consequence needs compatible support; no single local model establishes the whole relation. Not a claim of scientific novelty or empirically measured net benefit. `EAOSE-079`.

**CI2 — Change-triggered revalidation: SUBSUMED_DUPLICATE.** The operative mechanism already appears in change-impact traceability and reassurance. Changed assumptions invalidate affected support, not necessarily the claim itself; independent adequate warrants may survive. `EAOSE-080`, `EAOSE-053`.

**CI3 — Branch-sensitive method selection: SUBSUMED_DUPLICATE.** Configuration selection, scope, cheap alternatives and substitution already supply the mechanism. Preserve the synthesis proposal but add no independent mandatory control. `EAOSE-113`, `EAOSE-007`, `EAOSE-034`, `EAOSE-039`, `EAOSE-069`.

No additional independently warranted universal property manufactured. EAOSE-081 remains a conditional analytical consumer-closure constraint; EAOSE-100 and EAOSE-103 are inherited/imported mechanisms, not novel discoveries. Peach refines communication/adapter relations; norm-aware BDI requires a soft-norm/hard-permission distinction; multi-level explanation refines consumer and mapping obligations without crediting an unimplemented domain level.

### Precise relational account

Every relation below is an explicitly guarded analytical composition grounded in the named primary mechanisms, not a field-tested theorem about the whole system. Complete assumptions, new costs, sources and unresolved obligations are in the composition JSON. `ALIAS_OF` means the source mechanisms supply the content of the destination duplicate; it is not a new operational requirement.

| Relation | From → to | Type | Guard and operative connection |
| --- | --- | --- | --- |
| CR001 | EAOSE-001,EAOSE-002,EAOSE-004 → EAOSE-003 | ENABLES | Several affected parties or dependencies determine success. Participants and requirements engineers turn challenged needs and dependencies into explicit acceptance and conflict decisions. |
| CR002 | EAOSE-003,EAOSE-099 → EAOSE-007 | CONSTRAINS | Architecture is being selected. Choose the agent boundary against the same acceptance and adverse-consequence criteria as the conventional alternative. |
| CR003 | EAOSE-007 → EAOSE-008,EAOSE-069 | ALTERNATIVE_TO | Agent-specific discretion or communication is unnecessary. Retain useful requirements analysis but select a workflow, service or single-agent implementation. |
| CR004 | EAOSE-007,EAOSE-034,EAOSE-039 → EAOSE-113 | ALIAS_OF | The named branch-sensitive proposal is considered. The inherited selection and proportionality mechanisms supply the operative content; preserve the duplicate as research history. |
| CR005 | EAOSE-003,EAOSE-005 → EAOSE-012,EAOSE-088 | COMMUNICATES_TO | Requirements imply organisational responsibilities or executable goals. Legitimate principals communicate selected duties and goal authority to designers and acting agents; models do not grant permissions by themselves. |
| CR006 | EAOSE-012,EAOSE-013 → EAOSE-014 | REQUIRES | Conceptual roles are allocated to actual participants. Allocate only to agents with the necessary capability and current permission; one role may have several holders and vice versa. |
| CR007 | EAOSE-014,EAOSE-015 → EAOSE-016,EAOSE-024 | CONSTRAINS | Membership or role binding changes during operation. Rebind roles while preserving collective safety/liveness and outstanding obligations, rather than just changing names. |
| CR008 | EAOSE-018 → EAOSE-012,EAOSE-014 | REFINES | Recursive holonic organisation is justified. Apply responsibilities and allocation across holonic boundaries rather than mandate holons for every application. |
| CR009 | EAOSE-077 → EAOSE-016 | ALTERNATIVE_TO | Local cooperative adaptation addresses a different organisational problem. Choose an ADELFE-style cooperative design instead of assuming a central capability allocator is universally necessary. |
| CR010 | EAOSE-015,EAOSE-100 → EAOSE-084 | CONSTRAINS | A global adequacy certificate is inferred from local cooperation. Require the missing global assumptions and evidence; the stronger claim remains contested. |
| CR011 | EAOSE-012,EAOSE-085 → EAOSE-019,EAOSE-021 | COMMUNICATES_TO | Social duties are realised through interactions. Principals make applicable duties and commitments publicly interpretable in conversation contracts; norm violations remain distinct from inaccessible private intentions. |
| CR012 | EAOSE-021 → EAOSE-022 | CONFLICTS_WITH | Public compliance is judged for independent principals. Observable commitment evidence rejects private belief as a sufficient public compliance criterion. |
| CR013 | EAOSE-020,EAOSE-091 → EAOSE-019 | REQUIRES | Heterogeneous or open endpoints communicate consequentially. Establish content meanings, identity and action authority in addition to message shape. |
| CR014 | EAOSE-019,EAOSE-023,EAOSE-024 → EAOSE-096 | ACTS_THROUGH | Logical interactions are implemented asynchronously. Map protocol instances and information dependencies into correlated sends, receives and local enablement. |
| CR015 | EAOSE-096,EAOSE-102 → EAOSE-030 | PROVIDES_EVIDENCE_FOR | A protocol is mapped to concrete channels or adapters. Inspect that actual messages and local operations implement the intended interaction rather than only an abstract communicative act. |
| CR016 | EAOSE-025,EAOSE-096 → EAOSE-103 | ENABLES | A timeout, crash or interruption leaves action outcome uncertain. Classify outstanding effects before retry, deduplicate or compensate under the external resource contract. |
| CR017 | EAOSE-103 → EAOSE-072 | PROVIDES_EVIDENCE_FOR | A resumed or retried action claims success. Use external status and effect identity to establish the result rather than treating retry completion as a new independent success. |
| CR018 | EAOSE-005,EAOSE-009,EAOSE-013,EAOSE-091 → EAOSE-065 | CONSTRAINS | A generated plan or agent message requests a tool action. The resource owner or tool boundary checks the actual principal and scope regardless of fluent intention or role label. |
| CR019 | EAOSE-065,EAOSE-067 → EAOSE-019,EAOSE-072 | CONSTRAINS | Untrusted inputs influence interaction or action. Treat retrieved messages and tool outputs as data unless separately authorised; test the boundary and actual effects. |
| CR020 | EAOSE-017,EAOSE-086 → EAOSE-027,EAOSE-088 | PROVIDES_EVIDENCE_FOR | Deliberative goal pursuit depends on observed state. Update beliefs from qualified observations and distinguish adopted goals from current environmental facts. |
| CR021 | EAOSE-027,EAOSE-087,EAOSE-088 → EAOSE-028,EAOSE-029 | ENABLES | A BDI-style internal design is selected. Design modular plans, goal failure and persistence with deliberate retention, reconsideration and abandonment semantics. |
| CR022 | EAOSE-028,EAOSE-029,EAOSE-089 → EAOSE-030 | ACTS_THROUGH | Reactive events and plans become executable behaviour. Implement the chosen failure, modularity and arbitration semantics, identifying manual work and interrupted partial effects. |
| CR023 | EAOSE-085 → EAOSE-028,EAOSE-088 | REFINES | Violable social norms legitimately affect plan selection. Use norm-aware goals/plans and valued consequences without silently changing hard permission constraints. |
| CR024 | EAOSE-099,EAOSE-013 → EAOSE-085 | CONSTRAINS | Hard limits coexist with norm valuation. External principals distinguish non-delegable permissions from norms whose violation can be reasoned about within the domain. |
| CR025 | EAOSE-082,EAOSE-104 → EAOSE-087,EAOSE-089,EAOSE-095 | CONSTRAINS | Planning, reaction or uncertainty resolution consumes bounded resources. Budget deliberation and observation as well as task execution; choose a narrower controller when excluded costs defeat the claim. |
| CR026 | EAOSE-092,EAOSE-093 → EAOSE-017,EAOSE-102 | REFINES | Environment resources and organisation have independently changing semantics. Expose resource operations and organisational constraints through explicit interfaces, without making every resource an agent. |
| CR027 | EAOSE-034,EAOSE-038,EAOSE-060 → EAOSE-035,EAOSE-036,EAOSE-101 | CONSTRAINS | Method components or reusable assets are selected. Match scope, skill, costs and input/output prerequisites before composition or reuse. |
| CR028 | EAOSE-035,EAOSE-036 → EAOSE-094 | REQUIRES | Multiple method views describe overlapping behaviour. Align concepts and mapping rules; use explicit inconsistency analysis or a cheaper direct check where adequate. |
| CR029 | EAOSE-031,EAOSE-032,EAOSE-094 → EAOSE-030 | PROVIDES_EVIDENCE_FOR | Construction uses generation or model transformations. Check specified transformations and the remaining manual obligations against executable semantics. |
| CR030 | EAOSE-030,EAOSE-044 → EAOSE-076,EAOSE-108 | CONFLICTS_WITH | Generation or complete models are offered as sufficient delivery proof. Require model adequacy and executable correspondence rather than treating artefact completeness as a certificate. |
| CR031 | EAOSE-003,EAOSE-030,EAOSE-044 → EAOSE-045,EAOSE-046 | ENABLES | Testing must evaluate agents and their collective effects. Derive appropriate oracles and integration/adversarial scenarios from legitimate goals, real interfaces and environmental assumptions. |
| CR032 | EAOSE-043,EAOSE-100 → EAOSE-044 | REQUIRES | A formal claim is transferred to operation. Expose the assumed component/environment relation and discharge it with appropriate external evidence. |
| CR033 | EAOSE-043 → EAOSE-110 | CONFLICTS_WITH | The formal model is treated as the entire deployed system. Reject the unqualified certificate while preserving the bounded result. |
| CR034 | EAOSE-047 → EAOSE-078 | SUPERSEDES | All-path coverage is proposed as the only adequate criterion. Select justified structural/failure/consequence criteria, retaining the earlier complexity warning without its universal prescription. |
| CR035 | EAOSE-048,EAOSE-058 → EAOSE-059,EAOSE-061 | PROVIDES_EVIDENCE_FOR | A case or benchmark is used in a method-effectiveness claim. Classify its actual setting, unit, comparator and limits before drawing a conditional benefit conclusion. |
| CR036 | EAOSE-058,EAOSE-059 → EAOSE-062 | CONFLICTS_WITH | Popularity or a tool listing is treated as proof of method benefit. Require outcomes and relevant comparisons rather than availability or venue presence. |
| CR037 | EAOSE-049,EAOSE-051,EAOSE-052 → EAOSE-045,EAOSE-053 | FEEDBACK_TO | Runtime observations reveal a defect or changed behaviour. Correlate the observation with requirements and versions; improve tests and re-evaluate affected warrants. |
| CR038 | EAOSE-050,EAOSE-052,EAOSE-086,EAOSE-098 → EAOSE-097 | COMMUNICATES_TO | A person must understand or intervene in a consequential decision. Provide attributable, appropriately abstracted evidence and explicitly mark unlogged or unimplemented explanatory levels. |
| CR039 | EAOSE-054,EAOSE-097 → EAOSE-051,EAOSE-055 | CONSTRAINS | A live change, interruption or retirement is proposed. An authorised actor determines change scope and disposition of outstanding work; the operator validates actual stop or transfer semantics. |
| CR040 | EAOSE-053 → EAOSE-080 | ALIAS_OF | The separate assumption-change proposal is considered. Use the inherited change-impact mechanism; invalidate affected support, preserve independent adequate warrants and retain the duplicate research identity. |
| CR041 | EAOSE-053,EAOSE-054 → EAOSE-006,EAOSE-003,EAOSE-030,EAOSE-064 | FEEDBACK_TO | A requirement, goal, capability, protocol, model or environment changes materially. Revisit affected mappings, acceptance and evaluations rather than rerunning all work or accepting stale evidence. |
| CR042 | EAOSE-056,EAOSE-081 → EAOSE-049,EAOSE-054,EAOSE-055 | COMMUNICATES_TO | Engineering results must guide real operation. Give the operator or responsible principal the information, resources and authority needed for monitoring, change and retirement decisions. |
| CR043 | EAOSE-057 → EAOSE-034,EAOSE-035,EAOSE-039 | FEEDBACK_TO | The engineering method itself is proposed for revision. A legitimate method decision-maker evaluates the change under existing authority and acceptance criteria; the successor method does not authorise itself. |
| CR044 | EAOSE-063,EAOSE-065,EAOSE-066,EAOSE-067 → EAOSE-073 | REQUIRES | A learned component is combined with symbolic interaction/control. Specify prompt-role limits, memory semantics and action authority across the learned/symbolic boundary. |
| CR045 | EAOSE-064,EAOSE-068,EAOSE-069,EAOSE-104 → EAOSE-073 | PROVIDES_EVIDENCE_FOR | A generative hybrid is evaluated or changed. Use versioned repeated tests, localised failure traces, relevant ablations and actual cost limits; do not use agreement as independence. |
| CR046 | EAOSE-064,EAOSE-072 → EAOSE-070 | CONFLICTS_WITH | Agreement or self-reported task completion is used as the oracle. Require relevant independent observation or justified evidence, not merely more correlated answers. |
| CR047 | EAOSE-074 → EAOSE-106 | CONSTRAINS | A framework claims AOSE continuity. Use documentary inheritance and actual mechanisms, not the presence of role names or software-writing agents. |
| CR048 | EAOSE-003,EAOSE-005,EAOSE-013,EAOSE-019,EAOSE-030,EAOSE-044,EAOSE-072 → EAOSE-079 | PROVIDES_EVIDENCE_FOR | The selected configuration claims a legitimate accepted consequence. Join compatible evidence for the required meaning, obligation, authority, implementation and observed result; omit inapplicable links explicitly rather than force every mechanism. |
| CR049 | EAOSE-079 → EAOSE-053,EAOSE-055 | FEEDBACK_TO | A claimed end-to-end result is contradicted or unsupported. Identify the failed or missing relation, reopen only affected warrants and handle outstanding effects instead of declaring generic system failure or replaying accepted work. |
| CR050 | EAOSE-036,EAOSE-039,EAOSE-056 → EAOSE-081 | ENABLES | Several lifecycle fragments must compose operationally. Ensure each consequential output reaches a capable and authorised consumer or is omitted as unnecessary; shared people and artefacts can serve several functions. |
| CR051 | EAOSE-081 → EAOSE-079 | ENABLES | Acceptance depends on evidence crossing engineering/operating boundaries. Close the communication-to-action interfaces so an established distinction can actually influence authorised operation and acceptance. |
| CR052 | EAOSE-007,EAOSE-009 → EAOSE-010,EAOSE-011,EAOSE-111 | CONFLICTS_WITH | Universal agency, autonomy or agent-count superiority is asserted. Counterexample and baseline reasoning reject the universal while preserving justified configurations. |
| CR053 | EAOSE-027 → EAOSE-105 | CONFLICTS_WITH | Mental-state naming is promoted into intelligence evidence. Keep the implemented semantics separate from anthropomorphic capability claims. |
| CR054 | EAOSE-034,EAOSE-035,EAOSE-039 → EAOSE-040,EAOSE-041,EAOSE-107,EAOSE-112 | CONFLICTS_WITH | Serial, unioned or exhaustive universal methods are proposed. Require executable scope and consumed functions, not universal artefact/phase compliance. |
| CR055 | EAOSE-001 → EAOSE-042 | ALIAS_OF | Stakeholder validation is restated as a second property. Preserve the duplicate identity without a second operational obligation. |
| CR056 | EAOSE-026,EAOSE-051 → EAOSE-096,EAOSE-103 | CONSTRAINS | A protocol or component version changes while work is in flight. Check mixed-version interpretation, message/effect identity and responsibility for old obligations before accepting the new configuration. |
| CR057 | EAOSE-082 → EAOSE-015 | CONSTRAINS | Collective liveness includes deadlines. Include timing and resource assumptions in collective guarantees rather than proving eventual progress only. |
| CR058 | EAOSE-083 → EAOSE-003,EAOSE-045,EAOSE-046,EAOSE-065 | REFINES | Security constraints are material requirements. Trace threats and security goals into permission boundaries and test evidence, keeping unexamined threats explicit. |
| CR059 | EAOSE-095 → EAOSE-009,EAOSE-097,EAOSE-104 | ALTERNATIVE_TO | Evidence is insufficient for a consequential action. Gather information, act conservatively, defer or abstain under authorised limits instead of blindly proceeding or assuming a human is always available. |
| CR060 | EAOSE-033,EAOSE-045,EAOSE-072 → EAOSE-003,EAOSE-079 | PROVIDES_EVIDENCE_FOR | A plan or task reports completion. Check actual consequences against the legitimate acceptance criterion, not only the internal goal flag. |
| CR061 | EAOSE-037,EAOSE-058 → EAOSE-059,EAOSE-060,EAOSE-061 | CONSTRAINS | Methods are compared for a decision. Use usable prescriptions and measured costs/quality rather than a phase-name feature count. |
| CR062 | EAOSE-054,EAOSE-057 → EAOSE-071 | CONFLICTS_WITH | A system proposes unmonitored self-modification. Existing authority and change evaluation govern the successor; ability to rewrite is not permission to do so. |
| CR063 | EAOSE-075 → EAOSE-001,EAOSE-006,EAOSE-094 | ENABLES | Large requirements models need modular views. Split representations only with explicit shared meanings and checked interfaces. |
| CR064 | EAOSE-090 → EAOSE-014,EAOSE-019,EAOSE-021 | ACTS_THROUGH | Distributed task allocation is justified. Announcements and bids lead to authorised assignment and, where appropriate, accepted public commitments; subsequent fulfilment is separately checked. |
| CR065 | EAOSE-019,EAOSE-020,EAOSE-091 → EAOSE-109 | CONFLICTS_WITH | Well-formed ACL is presented as semantic interoperability. Require the content, identity and local execution evidence appropriate to the interaction instead. |

### Discriminating cases

**A01 — Favourable (ANALYTICAL).** A service involves several independent firms whose obligations change through messages.

**Judgement:** C3 exposes who owes what, when duties activate and which observed event fulfils them; a private plan is not sufficient public evidence. **Boundary:** Use commitment/protocol mechanisms only if a simpler contract cannot capture the needed flexibility. [EAOSE-S023] [EAOSE-S027] [EAOSE-S061]

**A02 — Non-trigger (ANALYTICAL).** A deterministic local workflow meets the same requirements with no useful independent discretion.

**Judgement:** C0 is selected; neither extra agents nor a complete named methodology is required. **Boundary:** The composed system must permit this outcome without treating it as a defect. [EAOSE-S015] [EAOSE-S036] [EAOSE-S053]

**A03 — Missing actor (ANALYTICAL).** A complete goal diagram excludes a non-user harmed by the system.

**Judgement:** Model completeness does not satisfy EAOSE-001 or EAOSE-003; reopen the requirements boundary. **Boundary:** Adding more goal nodes inside the unchanged actor boundary cannot repair the omission. [EAOSE-S003] [EAOSE-S034] [EAOSE-S087]

**A04 — Collective conflict (ANALYTICAL).** Two competing agents implement one conceptual role and both perform a supposedly single external operation.

**Judgement:** Local role conformance does not establish collective adequacy; allocation, effect identity and reconciliation are needed. **Boundary:** Do not solve the problem by insisting every role always has one process; that is only one possible design. [EAOSE-S002] [EAOSE-S008] [EAOSE-S027] [EAOSE-S080]

**A05 — Semantic migration (PUBLISHED_CASE_WITH_ANALYTICAL_APPLICATION).** The Daimler prototype moves between platforms with different goal and process semantics.

**Judgement:** Preserve the reported migration burden as adverse evidence against syntax-only portability; check the changed mappings. **Boundary:** This is a prototype lesson, not a controlled production ROI estimate. [EAOSE-S052]

**A06 — Lifecycle gap (ANALYTICAL_FROM_DOCUMENTED_SCOPE).** A design method provides excellent models but no operational-change prescription.

**Judgement:** Do not credit unprovided lifecycle work; use an explicitly selected operational extension and a capable consumer. **Boundary:** O-MaSE scope is not itself a defect in every use; the gap becomes consequential only for a deployment needing those functions. [EAOSE-S008] [EAOSE-S032]

**A07 — Evidence mismatch (ANALYTICAL).** A toy MAS completes its demonstration and is declared superior to conventional engineering.

**Judgement:** The demonstration supports feasibility only; preserve the comparative claim as unresolved without a relevant baseline and costs. **Boundary:** Do not treat the absence of comparative proof as proof that every mechanism is worthless. [EAOSE-S010] [EAOSE-S020] [EAOSE-S033] [EAOSE-S036]

**A08 — Failed oracle (ANALYTICAL_FROM_PUBLISHED_LIMITATION).** The final database state is correct but required consent was not established.

**Judgement:** The task reward does not settle the authority/policy claim; require the missing evidence or refuse acceptance. **Boundary:** The τ-bench limitation is not an allegation that every rewarded trace in its dataset violated consent. [EAOSE-S041]

**A09 — Authorised recovery (PUBLISHED_CASE_WITH_ANALYTICAL_APPLICATION).** DS1 experiences operational anomalies; an insufficiently tested patch is withheld and a revised scenario is authorised.

**Judgement:** Operational recovery preserves change authority and evidence, rather than treating diagnostic capability as permission to deploy. **Boundary:** A recovered experiment is not failure-free operation or universal AOSE method superiority. [EAOSE-S056]

**A10 — Comparative confounding (ANALYTICAL_FROM_PUBLISHED_LIMITATION).** A multi-agent recommender outperforms a selected baseline with different orchestration cost and only one run per query.

**Judgement:** Record the reported comparison without attributing all benefit to multiple agents or inferring repeated reliability. **Boundary:** Same backend and temperature zero do not settle equal resource use or general determinism. [EAOSE-S044] [EAOSE-S036]

**A11 — Missing observation (ANALYTICAL_FROM_PUBLISHED_LIMITATION).** An explanation requests the reason for an unlogged plan-selection tie-break.

**Judgement:** Return an explicit evidence limit; a plausible reconstructed story is not faithful explanation. **Boundary:** The existence of a high-level explanation interface does not supply missing events. [EAOSE-S045] [EAOSE-S090]

**A12 — Changed timing assumption (ANALYTICAL_FROM_PUBLISHED_ASSUMPTIONS).** Plan search or a remote tool adds delay excluded by a timed-BDI model.

**Judgement:** Narrow or revalidate the deadline claim; do not treat a theorem under the old timing model as falsified or as still applicable. **Boundary:** Account for omitted reasoning/reactive costs or select a less autonomous implementation. [EAOSE-S051]

**A13 — Adversarial transfer (ANALYTICAL).** A cooperative adaptive organisation admits a strategic participant.

**Judgement:** The previous cooperation assumption is no longer sufficient for global adequacy; select additional public constraints or a different configuration. **Boundary:** Do not dismiss the adverse case as not really an agent system; examine the actual invalidated assumption. [EAOSE-S040] [EAOSE-S023]

**A14 — Untrusted input (ANALYTICAL_FROM_ADVERSARIAL_BENCHMARK).** A tool response contains instructions to perform an unauthorised action.

**Judgement:** Treat the content as untrusted data and test enforcement at the actual action boundary; role prompts alone are insufficient. **Boundary:** A benchmarked defence is bounded by its attacks, tools and version. [EAOSE-S042] [EAOSE-S041]

**A15 — Changed provider (ANALYTICAL).** A remotely updated learned component retains its model label while changing behaviour.

**Judgement:** Identify version uncertainty and re-evaluate affected evidence; do not silently reuse old evaluations as proof. **Boundary:** Some independent constraints can remain valid, so do not blindly invalidate every system claim. [EAOSE-S032] [EAOSE-S035] [EAOSE-S041]

**A16 — Cheap adequate form (ANALYTICAL).** One engineer operates a low-risk service and a single live record supplies requirements, tests and recovery information.

**Judgement:** Consumer closure can be satisfied without one document, control, meeting or owner per property. **Boundary:** The shared representation must still support the real decisions and not merely carry many labels. [EAOSE-S008] [EAOSE-S012] [EAOSE-S032]

**A17 — Persistence conflict (ANALYTICAL).** An agent continually replans and never finishes, or retains an obsolete intention despite changed obligations.

**Judgement:** Choose explicit reconsideration/abandonment criteria and account for dependent public duties. **Boundary:** Neither maximal persistence nor maximal responsiveness is the universal optimum. [EAOSE-S066] [EAOSE-S073] [EAOSE-S046]

**A18 — Authority mismatch (ANALYTICAL).** A protocol trace is correct but the acting credential has been revoked.

**Judgement:** Protocol conformance does not establish current permission; the action must be refused or reauthorised as appropriate. **Boundary:** Successful syntax, identity and intention each leave an action-specific authority question. [EAOSE-S023] [EAOSE-S026] [EAOSE-S049]

**A19 — Replay (ANALYTICAL_FROM_IMPLEMENTATION_SEMANTICS).** Code before an interrupt performs a non-idempotent action and is replayed after resumption.

**Judgement:** Checkpoint persistence does not ensure exactly-once external effect; use the appropriate effect identity or reconciliation strategy. **Boundary:** Do not assert compensation is always possible after an irreversible action. [EAOSE-S080]

**A20 — Norm versus permission (ANALYTICAL_FROM_CURRENT_PRIMARY_WORK).** A norm-aware planner assigns a low cost to violating a social rule and also has access to a forbidden operation.

**Judgement:** A legitimately violable norm may enter plan valuation, but that does not authorise violation of a hard permission boundary. **Boundary:** The 2026 example is not a universal policy-enforcement or global-compliance certificate. [EAOSE-S089] [EAOSE-S049]

**A21 — Communication realisation (ANALYTICAL_FROM_CURRENT_PRIMARY_WORK).** A logical communicative act is pending but its adapter has not finalised the actual message.

**Judgement:** Do not advance public obligations or claim an observed external consequence solely from the pending internal state. **Boundary:** Peach's model must be mapped to the actual transport and failure assumptions. [EAOSE-S088]

**A22 — Unimplemented abstraction level (ANALYTICAL_FROM_CURRENT_PRIMARY_WORK).** A prototype has implementation/design explanations and a proposed domain-level account.

**Judgement:** Do not credit the future domain level as implemented or as user-validated acceptance evidence. **Boundary:** Use existing evidence at its actual level, or obtain the missing domain interpretation separately. [EAOSE-S090]

**A23 — Competing adequate warrants (ANALYTICAL).** A source of runtime evidence is invalidated by a change, but a separate applicable proof or trusted external check remains.

**Judgement:** Invalidate the affected support and reassess sufficiency; do not automatically declare the claim false or rerun all accepted work. **Boundary:** The surviving warrant must genuinely address the same claim and current assumptions. [EAOSE-S029] [EAOSE-S032] [EAOSE-S056]

**A24 — Unsupported integration novelty (ANALYTICAL).** The same mechanism is renamed after composition and assigned a new compulsory reviewer.

**Judgement:** Preserve provenance as an alias and remove duplicated operative burden unless a distinct trigger or failure justifies it. **Boundary:** EAOSE-080 and EAOSE-113 retain candidate identities without inflating independently retained mechanisms. [EAOSE-S008] [EAOSE-S012] [EAOSE-S047]

These case adjudications are tests of the proposed composition and its claims, not new empirical experiments. Published incidents and paper limitations are identified separately from constructed scenarios.

## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_HYBRIDISATION_AND_EXTERNAL_RELATIONS

Native AOSE contributions include actor/goal-linked development, role/interaction methods and agent-specific design correspondence. Documented imports include knowledge engineering, OO/process modelling, practical reasoning and selected formal methods. Shared foundations such as distributed communication and configuration discipline should not be relabelled uniquely AOSE. The typed genealogy distinguishes those relations from convergence and analogy.

The modern symbolic–learned branch is an explicit translation problem: learned proposals, memories and natural-language plans need interpretable interfaces to authority, public obligations and external effects. A symbolic wrapper is not automatically sufficient, and a learned component is not disqualified merely for being stochastic. Selection depends on the relevant evidence, cost and consequence. Source-supported overlap with Autonomous Agents and Multi-Agent Systems is exported for later reconciliation; no sibling corpus was consulted and no cross-trifecta synthesis is asserted. [EAOSE-S028] [EAOSE-S037] [EAOSE-S041] [EAOSE-S042] [EAOSE-S085]


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_STRONGEST_SURVIVING_PROPERTIES

The strongest retained distinctions are conditionally strong engineering judgements, not uniform field-effect estimates. In particular: legitimate requirements and acceptance; justified abstraction; effective capability/permission; meaningful interactions; model/code correspondence; adequate environmental evidence; controlled change; realistic comparisons; and independent consequence checks. The complete strongly retained set is below; all other retained statuses remain in the denominator and intakes.

| ID | Strongly retained distinction |
| --- | --- |
| EAOSE-001 | Affected-stakeholder validation |
| EAOSE-003 | Goal-to-acceptance operationalisation |
| EAOSE-005 | Delegation distinguished from authority |
| EAOSE-007 | Agent-paradigm suitability decision |
| EAOSE-013 | Effective capability and permission checks |
| EAOSE-017 | Explicit environment and effect interfaces |
| EAOSE-019 | Interaction contract with defined semantics |
| EAOSE-030 | Design-to-implementation correspondence |
| EAOSE-032 | Explicit manual and platform obligations |
| EAOSE-034 | Lifecycle scope and method suitability |
| EAOSE-039 | Consumer-driven minimal representations |
| EAOSE-044 | Environment and abstraction validation |
| EAOSE-054 | Authorised adaptation boundaries |
| EAOSE-058 | Distinguish model, demonstration, prototype and deployment |
| EAOSE-059 | Realistic cost-and-quality comparative baselines |
| EAOSE-063 | LLM role prompts are not role-contract enforcement |
| EAOSE-065 | Tool-use authority separated from generated intention |
| EAOSE-072 | Independent action-effect verification |


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_CONTEXT_SPECIFIC_PROPERTIES

BDI, commitments, dynamic or holonic organisation, cooperation-based adaptation, formal checking, explanation, runtime monitoring, detailed traceability and generative hybrids are not universal requirements. Their per-record trigger, prerequisite and cheaper alternative are part of the property, not optional footnotes. A selected domain-specific mechanism may be strongly useful without transferring to another environment.

| ID | Candidate | Qualification |
| --- | --- | --- |
| EAOSE-004 | Goal conflict and alternative analysis | CONTEXT_DEPENDENT |
| EAOSE-006 | Requirements-to-behaviour traceability | USEFUL_BUT_EASILY_BUREAUCRATISED |
| EAOSE-008 | Agent-oriented analysis without mandatory agent runtime | CONTEXT_DEPENDENT |
| EAOSE-015 | Collective safety and liveness obligations | ASSUMPTION_SENSITIVE |
| EAOSE-016 | Capability-constrained dynamic organisation | CONTEXT_DEPENDENT |
| EAOSE-018 | Holonic decomposition | DOMAIN_SPECIFIC |
| EAOSE-021 | Observable social commitments | CONTEXT_DEPENDENT |
| EAOSE-023 | Local protocol conformance and information causality | ASSUMPTION_SENSITIVE |
| EAOSE-024 | Explicit dynamic role binding | CONTEXT_DEPENDENT |
| EAOSE-026 | Protocol evolution and mixed-version compatibility | CONTEXT_DEPENDENT |
| EAOSE-027 | BDI internal design where deliberation warrants it | CONTEXT_DEPENDENT |
| EAOSE-029 | Capability and plan modularity | CONTEXT_DEPENDENT |
| EAOSE-031 | Qualified model transformation trust | ASSUMPTION_SENSITIVE |
| EAOSE-035 | Semantic compatibility of method fragments | ASSUMPTION_SENSITIVE |
| EAOSE-038 | Learnability and modelling burden | CONTEXT_DEPENDENT |
| EAOSE-043 | Bounded programme model checking | ASSUMPTION_SENSITIVE |
| EAOSE-048 | Simulation validity and transfer limits | ASSUMPTION_SENSITIVE |
| EAOSE-049 | Runtime conformance monitoring | CONTEXT_DEPENDENT |
| EAOSE-050 | Explanation fidelity and human interpretation | CONTEXT_DEPENDENT |
| EAOSE-052 | Operational trace correlation | CONTEXT_DEPENDENT |
| EAOSE-057 | Method revision under declared authority | CONTEXT_DEPENDENT |
| EAOSE-066 | Memory provenance and update semantics | ASSUMPTION_SENSITIVE |
| EAOSE-068 | Trace-grounded multi-agent failure localisation | CONTEXT_DEPENDENT |
| EAOSE-069 | Single-agent and workflow substitution tests | CONTEXT_DEPENDENT |
| EAOSE-073 | Bounded symbolic–learned hybrid design | ASSUMPTION_SENSITIVE |
| EAOSE-075 | Modular requirements views and explicit interfaces | CONTEXT_DEPENDENT |
| EAOSE-077 | Local cooperation as adaptive-system design principle | DOMAIN_SPECIFIC |
| EAOSE-081 | Consumer-closed lifecycle composition | CONTEXT_DEPENDENT |
| EAOSE-082 | Explicit temporal feasibility for goals, plans and actions | ASSUMPTION_SENSITIVE |
| EAOSE-085 | Norm specification, violation and recovery | CONTEXT_DEPENDENT |
| EAOSE-086 | Belief provenance, revision and observational uncertainty | ASSUMPTION_SENSITIVE |
| EAOSE-087 | Intention retention and bounded reconsideration | CONTEXT_DEPENDENT |
| EAOSE-089 | Reactive–deliberative arbitration | CONTEXT_DEPENDENT |
| EAOSE-090 | Negotiation and task-allocation procedure | CONTEXT_DEPENDENT |
| EAOSE-092 | Engineered environment artefacts | CONTEXT_DEPENDENT |
| EAOSE-093 | Agent, organisation and environment separation | CONTEXT_DEPENDENT |
| EAOSE-094 | Cross-view and metamodel consistency checking | ASSUMPTION_SENSITIVE |
| EAOSE-095 | Uncertainty-aware decision and abstention policy | ASSUMPTION_SENSITIVE |
| EAOSE-097 | Human participation and effective intervention | CONTEXT_DEPENDENT |
| EAOSE-100 | Explicit compositional assurance assumptions | ASSUMPTION_SENSITIVE |
| EAOSE-101 | Scoped reuse of engineering assets | CONTEXT_DEPENDENT |
| EAOSE-102 | Deployment topology and trust-boundary design | CONTEXT_DEPENDENT |


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_REJECTED_OR_SUPERSEDED_PRACTICES

| ID | Candidate | Disposition and reason |
| --- | --- | --- |
| EAOSE-010 | Every active component should be an agent | REJECTED_OR_DISFAVOURED: The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. |
| EAOSE-011 | More autonomy is inherently beneficial | REJECTED_OR_DISFAVOURED: The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. |
| EAOSE-022 | Private mental-state semantics as open compliance criterion | REJECTED_OR_DISFAVOURED: The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. |
| EAOSE-040 | One mandatory serial lifecycle | CEREMONY_NOT_GENERAL_PROPERTY: The universal artefact/ordering requirement has no independent general property; preserve functional alternatives instead. |
| EAOSE-041 | Union of all methods as a superior method | REJECTED_OR_DISFAVOURED: The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. |
| EAOSE-042 | Stakeholder goal validation restated | DUPLICATE_CANDIDATE: Preserve the candidate identity and history, but link it to already represented operative content and count no additional independent retained mechanism. |
| EAOSE-061 | Whole-method net benefit over conventional engineering | UNRESOLVED: The question has been researched and remains unsettled in the inspected corpus; neither universal benefit nor absence of all useful benefit is established. |
| EAOSE-062 | Platform popularity as evidence of method effectiveness | NO_GENERAL_PROPERTY: The claimed general evidential implication does not hold; availability/popularity is not comparative method effectiveness. |
| EAOSE-070 | Agent agreement as an independent correctness oracle | REJECTED_OR_DISFAVOURED: The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. |
| EAOSE-071 | Unmonitored self-modification as authorised evolution | REJECTED_OR_DISFAVOURED: The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. |
| EAOSE-076 | Code generation as an assurance certificate | REJECTED_OR_DISFAVOURED: The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. |
| EAOSE-078 | All-path testing as the only adequate assurance | SUPERSEDED_BY_STRONGER_FORM: Preserve the earlier candidate and its useful warning; replace the universal prescription with the stronger qualified adequacy criterion. |
| EAOSE-080 | Assumption-change evidence invalidation | DUPLICATE_CANDIDATE: Preserve the candidate identity and history, but link it to already represented operative content and count no additional independent retained mechanism. |
| EAOSE-084 | Local cooperation as a certificate of global adequacy | CONTESTED: Retain the stronger claim as contested because the local mechanism does not itself discharge the global guarantee under all relevant conditions. |
| EAOSE-105 | Mental-state labels establish intelligence | REJECTED_OR_DISFAVOURED: The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. |
| EAOSE-106 | Role prompts alone constitute AOSE | REJECTED_OR_DISFAVOURED: The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. |
| EAOSE-107 | One mandatory methodology fits every agent system | REJECTED_OR_DISFAVOURED: The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. |
| EAOSE-108 | Complete models guarantee correct implementation | REJECTED_OR_DISFAVOURED: The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. |
| EAOSE-109 | ACL syntax guarantees semantic interoperability | REJECTED_OR_DISFAVOURED: The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. |
| EAOSE-110 | Model checking certifies the deployed system without correspondence evidence | REJECTED_OR_DISFAVOURED: The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. |
| EAOSE-111 | Increasing agent count necessarily improves results | REJECTED_OR_DISFAVOURED: The universal or sufficient-condition claim is not warranted; its rejection does not reject all bounded uses of the underlying mechanism. |
| EAOSE-112 | Universally exhaustive methodology artefacts | CEREMONY_NOT_GENERAL_PROPERTY: The universal artefact/ordering requirement has no independent general property; preserve functional alternatives instead. |
| EAOSE-113 | Branch-sensitive method selection restated as a new control | DUPLICATE_CANDIDATE: Preserve the candidate identity and history, but link it to already represented operative content and count no additional independent retained mechanism. |


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_CURRENT_STATE_AND_RESEARCH_FRONTIER

Current AOSE research is plural. The inspected 2026 work includes protocol-to-transport realisation, norm-aware BDI, timing models, model-driven engineering, explanation, modern role criticism and learned-agent evaluation. These sources establish continuing problems and mechanisms, not a single converged solution or current maintenance of every older toolkit. [EAOSE-S018] [EAOSE-S019] [EAOSE-S037] [EAOSE-S044] [EAOSE-S045] [EAOSE-S051] [EAOSE-S085] [EAOSE-S088] [EAOSE-S089] [EAOSE-S090]

The research frontier is not only how to make an agent reason better. It includes requirement and oracle validity, model/implementation correspondence, public accountability, meaningful human intervention, operational change, realistic resource accounting and evidence of comparative lifecycle benefit. Learned or remotely updated components add reliability and version concerns, while symbolic approaches retain limits of their own. Framework documentation in this corpus is a dated implementation-semantic snapshot; catalogue availability and paper publication do not certify production readiness.


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_ADVERSARIAL_SYNTHESIS_VERDICT

**The conditional core survives; the universal amalgam does not.** It is coherent to demand compatible evidence between legitimate concerns, appropriate autonomy, social/technical authority, executable behaviour and actual consequences. It is not coherent to infer that each concern requires its own agent, control, owner or artefact, or that combining every named methodology produces a usable method.

The strongest objection is that much of the evolved core is shared good engineering rather than a unique AOSE discovery. That objection changes the export: shared mechanisms retain provenance but are not claimed as novel or exclusively agent-oriented. AOSE-specific design and interaction mechanisms remain selectable when autonomy and organisation make them useful. A second objection is cost: richer modelling, verification and observation can burden a system more than they improve it. Cheap paths, substitution, omission and retirement are therefore mandatory parts of the analytical records, not an assumption that more machinery is mature.

The combined system has not been empirically shown superior to a coherent conventional engineering method. Nor does it guarantee stakeholder completeness, correct environmental models, strategic cooperation, immutable provider behaviour or faithful explanation of unobserved causes. Those limits are represented in retained assumptions, contested and unresolved candidates, and the configuration guards. The research delivers a stable and auditable conditional synthesis, not a deployment certificate or evidence of adoption.


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_OPEN_QUESTIONS_AND_EVIDENCE_LIMITS

The remaining questions are examined uncertainties, not unexamined original-prompt families. They include comparative whole-lifecycle benefit; transfer of local organisation and verification claims to open, strategic or timed environments; affordable assurance of long-lived learned components; effective and faithful explanation across abstraction levels; and the adequacy of evidence when important effects or assumptions cannot be observed directly.

The exact older **66-row roster was not recovered**. Its count-only report is not canonical authority. All recoverable R72 and reconstructed84 content is reconciled, but exact restoration of the missing earlier identities remains unverified. Later researchers must preserve this distinction rather than turn the independently established 113-candidate corpus into a claim that the earlier file was restored.

Provenance and formal validity are not comparative effectiveness. Classroom/model examples are not field deployment. DS1 supplies specific operational evidence; Daimler is a prototype. Related editions and repeated cases do not establish replication. The source table gives claim-specific access, empirical units and formal assumptions. Whole-method net benefit remains EAOSE-061 (UNRESOLVED).

| Access-limit record | Actual access | Consequence |
| --- | --- | --- |
| EAOSE-S004 | ABSTRACT_AND_METADATA_ONLY | Publisher full text not inspected; detailed mechanisms supported by S003 and S072, not inferred from this abstract. |
| EAOSE-S016 | ABSTRACT_AND_METADATA_ONLY | Full entry inaccessible; not used as substitute for primary method descriptions. |
| EAOSE-S021 | METADATA_ONLY_ACCESS_LIMIT | No full-text substantive claims credited; S053 supplies inspected agent-based engineering argument. |
| EAOSE-S022 | METADATA_ONLY_ACCESS_LIMIT | Full article could not be retrieved from publisher, Southampton, author or mirror attempts; no uninspected theorem, procedure or empirical result credited. |
| EAOSE-S058 | CATALOGUE_ONLY | Availability does not establish ongoing maintenance, safety, adoption or effectiveness. |
| EAOSE-S059 | CATALOGUE_ONLY | Not a runtime/toolchain test or proof of present support. |
| EAOSE-S060 | README_ONLY | Name collision: this is not the established Agent Factory AOP platform. No platform-continuity claim is based on this entry. |
| EAOSE-S064 | ABSTRACT_AND_METADATA_ONLY | Full chapter inaccessible; precise procedures not reconstructed beyond inspected abstract and documented later accounts. |
| EAOSE-S067 | ABSTRACT_AND_METADATA_ONLY | Full paper request-only; detailed dimension treatment instead grounded in S050 and S074. |
| EAOSE-S086 | ABSTRACT_AND_METADATA_ONLY | Related publication of S085, not independent empirical replication; full published text not inspected. |

### Requirement-by-requirement audit

The full audit is `RESEARCH_COVERAGE.requirements_audit`. Evidence-limited satisfaction means the question was examined and the unavailable or unresolved evidence is explicit; it does not mean that evidence was obtained. In particular A03 is **not** successful exact restoration of the missing 66-row roster.

| Item | Controlling requirement | Disposition | Concrete result |
| --- | --- | --- | --- |
| R01 | Established subject and analytical label, lane 7.3 and independence | SATISFIED | AOSE is the established tradition; Evolved is analytical. No sibling corpus, requester repository or target-specific adoption is used. |
| R02 | Complete tradition study rather than a proposal or reading list | SATISFIED | Substantive reconstruction, adjudication, operating system and intakes are delivered, not promised. |
| R03 | Origins, foundations, schools, failures, responses, derivatives and open questions | SATISFIED_WITH_DECLARED_EVIDENCE_LIMIT | Plural history with documented/imported/inferred relationships and branch-specific limits; selected inaccessible originals are explicit. |
| R04 | Current-year and prior-two-to-five-year source duty | SATISFIED | Current primary studies and proceedings through 2026-09-07 are examined, with version/publication/event dates distinguished. |
| R05 | Source acquisition: exact works, locators, access levels and roles | SATISFIED_WITH_DECLARED_EVIDENCE_LIMIT | Ninety exact work/document records; source access is not falsely homogenised into full-text verification. |
| R06 | Do not use snippets or inaccessible detail as evidence | SATISFIED_WITH_DECLARED_EVIDENCE_LIMIT | Technical claims use declared inspected sections; metadata entries are limited to identity and accessible information. |
| R07 | Keep evidence roles and strengths separate | SATISFIED | Theory, provenance, comparative, field, replication, contrary findings and transfer are not averaged. |
| R08 | Named methods: Gaia, Tropos, MaSE/O-MaSE, Prometheus, PASSI, INGENIAS, Agent OPEN | SATISFIED_WITH_DECLARED_EVIDENCE_LIMIT | All named methodologies are examined with actual scope, prescriptions, manual obligations, cost and evidence limits. |
| R09 | Other material methods and model/language/protocol branches | SATISFIED_WITH_DECLARED_EVIDENCE_LIMIT | Actor/AOP/BDI, knowledge-based approaches, Cassiopeia, DESIRE, ADELFE, ASPECS, ASEME, AUML, FIPA, commitments, protocols and platforms are treated without forced equivalence. |
| R-O1 | Mandatory domain family O1: Which actors and dependencies are missing; how are conflicting stakeholder goals translated to legitimate observable acceptance? | SATISFIED | Family-specific models, candidate dispositions, criticism, source inspection and recency links are present. |
| R-O2 | Mandatory domain family O2: When do agent abstractions add useful control or knowledge boundaries, and when do conventional or single-agent designs dominate? | SATISFIED | Family-specific models, candidate dispositions, criticism, source inspection and recency links are present. |
| R-O3 | Mandatory domain family O3: How do roles, capabilities, norms and many-to-many mappings preserve collective obligations under stable or changing membership? | SATISFIED_WITH_DECLARED_EVIDENCE_LIMIT | Family-specific models, candidate dispositions, criticism, source inspection and recency links are present. |
| R-O4 | Mandatory domain family O4: How do public meanings, commitments and information dependencies become compatible local and transported interactions? | SATISFIED | Family-specific models, candidate dispositions, criticism, source inspection and recency links are present. |
| R-O5 | Mandatory domain family O5: How do beliefs, goals, intentions, plans and resource operations map to executable behaviour, including manual, reactive and failure semantics? | SATISFIED_WITH_DECLARED_EVIDENCE_LIMIT | Family-specific models, candidate dispositions, criticism, source inspection and recency links are present. |
| R-O6 | Mandatory domain family O6: Which lifecycle prescriptions, tools and method fragments compose semantically and economically, rather than merely sharing labels? | SATISFIED_WITH_DECLARED_EVIDENCE_LIMIT | Family-specific models, candidate dispositions, criticism, source inspection and recency links are present. |
| R-O7 | Mandatory domain family O7: Which formal, test, simulation and runtime evidence supports individual and collective claims, and where do oracles or environmental assumptions fail? | SATISFIED | Family-specific models, candidate dispositions, criticism, source inspection and recency links are present. |
| R-O8 | Mandatory domain family O8: Who deploys, observes, changes, recovers and retires the actual system, and how are authority, effects and evidence preserved? | SATISFIED_WITH_DECLARED_EVIDENCE_LIMIT | Family-specific models, candidate dispositions, criticism, source inspection and recency links are present. |
| R-O9 | Mandatory domain family O9: What was modelled, simulated, demonstrated, prototyped or deployed, what did it cost, and which adverse/null/comparative evidence changes the judgement? | SATISFIED_WITH_DECLARED_EVIDENCE_LIMIT | Family-specific models, candidate dispositions, criticism, source inspection and recency links are present. |
| R-O10 | Mandatory domain family O10: Which current engineering mechanisms document AOSE inheritance, which merely converge, and how do learned/stochastic/provider changes alter the obligations? | SATISFIED_WITH_DECLARED_EVIDENCE_LIMIT | Family-specific models, candidate dispositions, criticism, source inspection and recency links are present. |
| R20 | Recover concepts and operating relationships before extraction | SATISFIED | The report reconstructs what each method lets actors distinguish and do; properties are not isolated slogans. |
| R21 | Dated typed genealogy with documentary support | SATISFIED_WITH_DECLARED_EVIDENCE_LIMIT | Every edge carries a type, source basis and limit. Analogy and convergence are not mislabelled influence. |
| R22 | Stable IDs and complete candidate denominator including negative/duplicate/unresolved records | SATISFIED | All 113 canonical records are enumerated; inherited recoverable identities preserved; statuses sum to denominator. |
| R23 | No predetermined population total | SATISFIED | 84 recoverable records plus 28 semantically distinct additions and one duplicate proposal record; raw occurrence counts are not summed. |
| R24 | Every common property field and all ten domain profile dimensions | SATISFIED | Mandatory fields and resolvable domain profiles carry mechanisms, triggers, costs, authority, postconditions and limits. |
| R25 | One primary disposition and a distinct subject kind | SATISFIED | Each candidate has exactly one recognised primary disposition; duplicate and unresolved records remain counted. |
| R26 | No unexamined candidate or mandatory family in the frozen corpus | SATISFIED | Every identified candidate and original mandatory family is examined or examined with a disclosed evidence limit. Examined uncertainty is not called solved. |
| R27 | Criticism and negative evidence can change judgement | SATISFIED | Twenty-six criticisms produce actual narrowing, rejection, supersession, domain restrictions and unresolved benefit. |
| R28 | Evolution under criticism with actual mechanism changes | SATISFIED | Transitions and changed assumptions are explicit; a renamed method is not automatically an improvement. |
| R29 | Ceremony stripping for every retained mechanism | SATISFIED | Every retained record has a consumer, cheap path, fuller trigger, simplification cost and retirement/omission condition. |
| R30 | Empirical units, comparators, samples, outcomes and validity threats | SATISFIED_WITH_DECLARED_EVIDENCE_LIMIT | Eighteen evidence records distinguish modelling tasks, demonstrations, prototypes, flight, human studies and benchmarks; no pooled or invented effect. |
| R31 | Formal model, guarantee, assumptions and implementation obligations | SATISFIED_WITH_DECLARED_EVIDENCE_LIMIT | Nine formal/semantic evidence records keep model validity separate from deployed correspondence and independent proof replay. |
| R32 | Shared sources/programmes are not independent replication | SATISFIED_WITH_DECLARED_EVIDENCE_LIMIT | Related editions and the Daimler example are explicitly grouped; exact benchmark overlap remains unknown where not reported. |
| R33 | Substantive composed system and nonempty machine model | SATISFIED | Conditional configuration system with state, actors, evidence, action, consequences, feedback and qualified relations, not a list or forced serial pipeline. |
| R34 | All relation fields and significant guarded dependencies/alternatives | SATISFIED | Every relation has endpoints, type, guard, assumptions, mechanism, new cost, evidence status and residual obligation. |
| R35 | Communication and operation, not internal information processing alone | SATISFIED | Participants exchange requirements and obligations; operations change real resources; external evidence establishes consequences only within scope. |
| R36 | Distinction, authority, ability, action and consequence kept separate | SATISFIED | No one layer silently certifies another; consumer closure does not confer authority or prove truth. |
| R37 | Self-revision only where warranted and not self-authorising | SATISFIED | Method/behaviour change is evaluated under legitimate existing authority; unaffected adequate evidence is preserved. |
| R38 | Smallest coherent form and triggers for richer forms | SATISFIED | Conventional exit, alternative agent configurations and overlays are explicit; no one-control/owner/artefact-per-property rule. |
| R39 | Required discriminating cases and adversarial scenarios | SATISFIED | All six specified cases plus favourable, non-trigger, conflicting, changed-assumption and failed-observation cases are adjudicated; analytical tests are labelled. |
| R40 | Internal tensions with discriminators, hybrids and failures | SATISFIED | Fourteen tensions specify protected values, costs, selection evidence, possible hybrids and failure modes. |
| R41 | Adversarial synthesis verdict and claims not warranted | SATISFIED | Conditional core survives; universal method benefit, global guarantees, rebranding and unnecessary controls are rejected or withheld. |
| R42 | All exact report section labels in required order | SATISFIED | Required sequence rendered explicitly and all property IDs/dispositions enumerated. |
| R43 | Property ledger JSON envelope and counts | SATISFIED | Schema, lineage, cut-off, totals, examined population and disposition counts are machine checked. |
| R44 | Source table JSON envelope and mandatory fields | SATISFIED | Exact identities, roles, access, locators, property back-references and evidence limits are checked. |
| R45 | Composition JSON envelope and interfaces | SATISFIED | Nodes, relations, alternatives, external interfaces, revision boundaries and unresolved obligations present and linked. |
| R46 | Coverage JSON and decision-oriented saturation | SATISFIED | Declared scope and performed acquisition records; no fixed source/count/time stopping quota claimed. |
| R47 | Complete neutral audit intake for all crosswalk-worthy records | SATISFIED | Mature forms, triggers, costs, evidence, consumer, criticism, anti-ceremony, domain and neutral questions; non-retained records separately enumerated. |
| R48 | Audit outcomes may be already addressed/inapplicable/simpler/evidence insufficient | SATISFIED | Questions do not presuppose a defect or mandate a named tool, new owner or target-specific change. |
| R49 | Public documentation intake with genealogy, claims, limits and outline | SATISFIED | Standalone neutral public account with source IDs and locators; no requester repository name. |
| R50 | Later AMA synthesis intake with global keys and complete interfaces | SATISFIED | All 113 keys export mechanisms, required inputs, outputs, costs, assumptions, conflicts and selection/retirement conditions. |
| R51 | Sibling questions without importing or answering sibling findings | SATISFIED | SIBLING_CORPORA_NOT_CONSULTED and CROSS_TRIFECTA_SYNTHESIS_NOT_PERFORMED; no cross-trifecta adoption claim. |
| R52 | Freeze exact eight payloads and non-circular manifest | SATISFIED | Final packaging uses eight payloads plus manifest, no raw copyrighted sources or unrelated/private material; enclosing hash is external. |
| R53 | Parse, count, resolve, close, reopen and hash exact membership | SATISFIED | Final validator must pass before these files are presented as packaged and reopen-verified; archive readback does not certify scholarly universality. |
| R54 | Final state and evidence limits remain truthful | SATISFIED_WITH_DECLARED_EVIDENCE_LIMIT | FROZEN means stable bounded research and verified delivery; exact missing 66-row identity restoration is not claimed. |
| A01 | OWNER ANDON: preserve and reconcile all surviving R72 and recovered prior content | SATISFIED | Every R72 row and recovered84 identity has a destination and retained provenance; no accepted input is silently dropped. |
| A02 | OWNER ANDON: determine canonical denominator by semantic adjudication | SATISFIED | 113 candidate records, not 66,72,138 or a predetermined total; input aliases do not inflate distinct retained mechanisms. |
| A03 | OWNER ANDON: exact earlier reported 66 population row-for-row restoration | SATISFIED_WITH_DECLARED_EVIDENCE_LIMIT | Investigated but not identity-certified: only the count report survives, not its row roster. This request is closed as an explicit examined archival evidence limit, NOT as successful exact restoration. |
| A04 | OWNER ANDON: reassess three composition proposals and search additional obligations | SATISFIED | CI1 retained analytically, CI2 and CI3 subsumed; additional inherited/interface obligations are not manufactured as novel discoveries. |

### Bibliographic inventory and inspection locators

**EAOSE-S001. Agent-oriented programming** — Yoav Shoham. 1993; Artificial Intelligence 60, pp.51–92. **Access:** SELECTED_FULL_TEXT. **Inspected:** Definition of AOP, comparison with object-oriented programming, AGENT0 discussion. **Limit:** Mental-state programming vocabulary is an abstraction; no empirical inference of intelligence or consciousness is warranted. [EAOSE-S001]

**EAOSE-S002. The Gaia Methodology for Agent-Oriented Analysis and Design** — Michael Wooldridge; Nicholas R. Jennings; David Kinny. 2000; Autonomous Agents and Multi-Agent Systems, author PDF. **Access:** SELECTED_FULL_TEXT. **Inspected:** Opening scope restrictions; analysis role and interaction models; design agent, service and acquaintance models. **Limit:** Original scope assumes comparatively stable cooperative organisations; later dynamic capabilities must not be retroactively attributed. [EAOSE-S002]

**EAOSE-S003. Tropos: An Agent-Oriented Software Development Methodology** — Paolo Bresciani; Anna Perini; Paolo Giorgini; Fausto Giunchiglia; John Mylopoulos. 2002-12; Technical-report/manuscript copy; typeset January 2003; distinct from 2004 journal edition. **Access:** SELECTED_FULL_TEXT. **Inspected:** Method overview, early/late requirements, architectural and detailed design; actor and goal examples. **Limit:** Conceptual lifecycle argument and examples are not a controlled comparison or automatic validation of stakeholders. [EAOSE-S003]

**EAOSE-S004. Tropos: An Agent-Oriented Software Development Methodology** — Paolo Bresciani; Anna Perini; Paolo Giorgini; Fausto Giunchiglia; John Mylopoulos. 2004; Published journal edition, DOI 10.1023/B:AGNT.0000018806.20944.ef. **Access:** ABSTRACT_AND_METADATA_ONLY. **Inspected:** Publisher title, authors, date and abstract. **Limit:** Publisher full text not inspected; detailed mechanisms supported by S003 and S072, not inferred from this abstract. [EAOSE-S004]

**EAOSE-S005. Modelling the Organization: New Concepts and Tools for Re-Engineering** — Eric S. K. Yu; John Mylopoulos; Yves Lesperance. 1996; Author HTML preceding revised IEEE Expert article AI Models for Business Process Reengineering, August 1996, pp.16–23. **Access:** SELECTED_FULL_TEXT. **Inspected:** Opening edition note; strategic dependency and strategic rationale sections; organisational vulnerabilities. **Limit:** Exact inspected title differs from published revision; diagrams do not establish stakeholder completeness. [EAOSE-S005]

**EAOSE-S006. Prometheus: A Methodology for Developing Intelligent Agents** — Lin Padgham; Michael Winikoff. 2002; AOSE workshop paper, 12-page author copy. **Access:** SELECTED_FULL_TEXT. **Inspected:** System specification, architectural design and detailed design; introductory exclusions; iterative relationships. **Limit:** Sensor/effector engineering excluded; illustrative design support is not field-validated full lifecycle coverage. [EAOSE-S006]

**EAOSE-S007. Multiagent Systems Engineering** — Scott A. DeLoach; Mark F. Wood; Clint H. Sparkman. 2001; MaSE journal paper, author-uploaded full text. **Access:** SELECTED_FULL_TEXT. **Inspected:** Capturing goals, use cases, refining roles; agent classes, conversations, assembling agents and system design. **Limit:** Later O-MaSE criticism of fixed organisation is not a claim MaSE offered dynamic reorganisation. [EAOSE-S007]

**EAOSE-S008. O-MaSE: a customisable approach to designing and building complex, adaptive multi-agent systems** — Scott A. DeLoach; Juan C. Garcia-Ojeda. 2010; International Journal of Agent-Oriented Software Engineering, pp.244 onward. **Access:** SELECTED_FULL_TEXT. **Inspected:** Introduction pp.245–247; metamodel, method fragments and process-construction guidance. **Limit:** Explicitly excludes management, deployment, testing and evaluation from its presented development process; implementation and organisational assumptions remain. [EAOSE-S008]

**EAOSE-S009. The O-MaSE Process: a Standard View** — Juan C. Garcia-Ojeda; Scott A. DeLoach. 2010; CEUR Workshop Proceedings 627. **Access:** SELECTED_FULL_TEXT. **Inspected:** Process overview, work products and activity dependencies. **Limit:** A standardised description of a process is not a universal mandatory sequence or industrial effectiveness test. [EAOSE-S009]

**EAOSE-S010. Comparing Agent-Oriented Methodologies** — Hoa Khanh Dam; Michael Winikoff. 2003; AOIS paper, eight-page author copy. **Access:** SELECTED_FULL_TEXT. **Inspected:** Introduction and study approach; MaSE, Prometheus and Tropos comparison; conclusion. **Limit:** Five summer studentships and designer consultation; authors expressly deny statistical significance. Not a controlled whole-method trial. [EAOSE-S010]

**EAOSE-S011. Applying Process Document Standarization to INGENIAS** — Alma Gómez-Rodríguez; Juan C. González-Moreno. 2010; CEUR Workshop Proceedings 627; title spelling preserved. **Access:** SELECTED_FULL_TEXT. **Inspected:** INGENIAS process, model views, activities, artefacts and code-generation discussion. **Limit:** Process documentation and tools do not certify semantic preservation of arbitrary generated systems. [EAOSE-S011]

**EAOSE-S012. Agent OPEN** — Brian Henderson-Sellers. 2005; 2006 EUMAS republication of original 2005 work. **Access:** SELECTED_FULL_TEXT. **Inspected:** OPEN extension, process-component selection and agent-specific additions. **Limit:** A fragment library needs situational assembly; neither mandatory total adoption nor net benefit follows. [EAOSE-S012]

**EAOSE-S013. From Requirements to Code with the PASSI Methodology** — Massimo Cossentino. 2005; Book chapter, author full-text upload. **Access:** SELECTED_FULL_TEXT. **Inspected:** Requirements, society, implementation, code reuse and deployment models; iterative process. **Limit:** Transformation and reused code still depend on target semantics and manually supplied domain behaviour. [EAOSE-S013]

**EAOSE-S014. Agent-Oriented Software Engineering: The State of the Art** — Michael Wooldridge; Paolo Ciancarini. 2000; AOSE 2000 manuscript; proceedings publication 2001. **Access:** SELECTED_FULL_TEXT. **Inspected:** Definitions; object-oriented and knowledge-engineering branches; AAII, Cassiopeia, DESIRE and methodology discussion. **Limit:** Used to organise genealogy, with load-bearing mechanisms traced to primary works; not evidence of present maintenance or comparative superiority. [EAOSE-S014]

**EAOSE-S015. Pitfalls of Agent-Oriented Development** — Michael Wooldridge; Nicholas R. Jennings. 1998; Agents conference paper, seven-page author PDF. **Access:** SELECTED_FULL_TEXT. **Inspected:** Political, management, conceptual, analysis/design and implementation pitfalls. **Limit:** Experienced author criticism, not a prevalence survey or controlled causal study. [EAOSE-S015]

**EAOSE-S016. Agent-Oriented Software Engineering** — Anna Perini. 2008-06-13; Encyclopedia reference entry, DOI 10.1002/9780470050118.ecse006. **Access:** ABSTRACT_AND_METADATA_ONLY. **Inspected:** Publisher abstract, first-publication date and bibliography. **Limit:** Full entry inaccessible; not used as substitute for primary method descriptions. [EAOSE-S016]

**EAOSE-S017. Engineering Multi-Agent Systems: workshop history** — EMAS organisers. 2026-09-07; Official site snapshot; founding 2012, first workshop 2013. **Access:** WEB_PAGE_INSPECTED. **Inspected:** History and past-edition list. **Limit:** Institutional continuity is not measured adoption, tool maintenance or benefit. [EAOSE-S017]

**EAOSE-S018. EMAS 2026 workshop** — EMAS 2026 organisers. 2026; Official programme snapshot at cut-off. **Access:** WEB_PAGE_INSPECTED. **Inspected:** Workshop scope and papers/programme links. **Limit:** A programme establishes presented work, not replication or mature deployment. [EAOSE-S018]

**EAOSE-S019. AAMAS 2026 proceedings and table of contents** — IFAAMAS. 2026; 25th conference; ISBN 979-8-4007-2317-9. **Access:** WEB_PAGE_INSPECTED. **Inspected:** Proceedings front matter; targeted engineering, protocol, verification and demonstration entries. **Limit:** Targeted navigation, not a claim to have read every proceedings paper. [EAOSE-S019]

**EAOSE-S020. Quantitatively Assessing the Benefits of Model-driven Development in Agent-based Modeling and Simulation** — Fernando Santos; Ingrid Nunes; Ana L. C. Bazzan. 2020; arXiv:2006.08820v1. **Access:** SELECTED_FULL_TEXT. **Inspected:** Study design, traffic/disease tasks, feature-quality tables and statistical analysis. **Limit:** 31 students; effects differ by domain; educational sample and specific transformation/language comparison limit transfer. [EAOSE-S020]

**EAOSE-S021. An agent-based approach for building complex software systems** — Nicholas R. Jennings. 2001; DOI 10.1145/367211.367250. **Access:** METADATA_ONLY_ACCESS_LIMIT. **Inspected:** Title, author and publication identity cross-checked; DOI retrieval blocked. **Limit:** No full-text substantive claims credited; S053 supplies inspected agent-based engineering argument. [EAOSE-S021]

**EAOSE-S022. Developing multiagent systems: The Gaia methodology** — Franco Zambonelli; Nicholas R. Jennings; Michael Wooldridge. 2003; ACM TOSEM, DOI 10.1145/958961.958963. **Access:** METADATA_ONLY_ACCESS_LIMIT. **Inspected:** Publisher/institutional identity; extension relation triangulated from later author works. **Limit:** Full article could not be retrieved from publisher, Southampton, author or mirror attempts; no uninspected theorem, procedure or empirical result credited. [EAOSE-S022]

**EAOSE-S023. Agent Communication Languages: Rethinking the Principles** — Munindar P. Singh. 1998; IEEE Computer author copy. **Access:** SELECTED_FULL_TEXT. **Inspected:** Mentalistic versus social semantics; observable public commitments and heterogeneity. **Limit:** Critique concerns open interaction compliance, not the uselessness of private BDI reasoning. [EAOSE-S023]

**EAOSE-S024. Representing Agent Interaction Protocols in UML** — James Odell; H. Van Dyke Parunak; Bernhard Bauer. 2000; Manuscript carries 1999 copyright; distinct from Extending UML for Agents. **Access:** SELECTED_FULL_TEXT. **Inspected:** Protocol representation and levels of interaction modelling. **Limit:** Diagram expressiveness is not enforcement, shared ontology or a proof of heterogeneous implementation conformance. [EAOSE-S024]

**EAOSE-S025. FIPA ACL Message Structure Specification** — Foundation for Intelligent Physical Agents. 2002-12-03; SC00061G. **Access:** SELECTED_FULL_TEXT. **Inspected:** Message-parameter definitions including sender/receiver, ontology, protocol, conversation and reply correlation. **Limit:** Inspected copy specifies an envelope. Conformance does not itself supply authentication, common referents or economic benefit. [EAOSE-S025]

**EAOSE-S026. Securing FIPA Agent Communication** — Niklas Borselius; Chris J. Mitchell. 2003; Seven-page author paper. **Access:** SELECTED_FULL_TEXT. **Inspected:** Threat discussion, cryptographic protection and infrastructure assumptions. **Limit:** Appropriate key/trust infrastructure is assumed; proposal is not a universal security guarantee. [EAOSE-S026]

**EAOSE-S027. Pippi: Practical Protocol Instantiation** — Samuel H. Christie V; Amit K. Chopra; Munindar P. Singh. 2022; arXiv:2203.00086v1; AAMAS 2022. **Access:** SELECTED_FULL_TEXT. **Inspected:** Information protocols, dynamic role binding, enactment and evaluation. **Limit:** Protocol-level causality and binding do not grant authority, authenticate principals or prove business success. [EAOSE-S027]

**EAOSE-S028. Interaction Protocols in an Imperative Agent-Oriented Programming Language: the case of BSPL and SARL** — Matteo Baldoni; Cristina Baroglio; Stéphane Galland; Roberto Micalizio; Fatma Outay; Stefano Tedeschi. 2025; AAMAS extended abstract, pp.2426–2427. **Access:** FULL_TEXT_SHORT_WORK. **Inspected:** Introduction, adapter generation and transformation rules. **Limit:** Two-page contribution; no broad independent effectiveness or arbitrary translation-correctness result. [EAOSE-S028]

**EAOSE-S029. Model checking agent programming languages** — Louise A. Dennis; Michael Fisher; Matthew P. Webster; Rafael H. Bordini. 2011; Accepted 2 May 2011; DOI 10.1007/s10515-011-0088-x; later journal issue. **Access:** SELECTED_FULL_TEXT. **Inspected:** Verification architecture; AIL/AJPF in sections 4.3–4.4; examples and limitations. **Limit:** Selected architecture/assumptions inspected; proofs and experiments not independently rerun. Model, interpreter and environment correspondence remain obligations. [EAOSE-S029]

**EAOSE-S030. On the Testability of BDI Agent Systems (Extended Abstract)** — Michael Winikoff; Stephen Cranefield. 2015; IJCAI extended abstract of 2014 JAIR article, DOI 10.1613/jair.4458. **Access:** SELECTED_FULL_TEXT. **Inspected:** Goal-plan trees, all-path adequacy, failure handling and example analysis. **Limit:** Inspected edition is the extended abstract; path-count growth does not establish that every useful test criterion is infeasible. [EAOSE-S030]

**EAOSE-S031. BDI Agent Testability Revisited** — Michael Winikoff. 2017; AAMAS JAAMAS extended abstract, pp.260–261. **Access:** FULL_TEXT_SHORT_WORK. **Inspected:** All-edges criterion; procedural programs with exception handling; conclusions. **Limit:** Changes comparator/adequacy criterion, not a refutation of earlier path-count calculations. Not deployment validation. [EAOSE-S031]

**EAOSE-S032. DevOps for Multi-Agent Systems** — Timotheus Kampik; Cleber J. Amaral; Jomi F. Hübner. 2021; arXiv:2108.08117v1. **Access:** SELECTED_FULL_TEXT. **Inspected:** Development/operation integration proposal and challenges. **Limit:** Position paper, not a controlled DevOps benefit study; operational extensions must be labelled additions. [EAOSE-S032]

**EAOSE-S033. The ASEME methodology** — Nikolaos I. Spanoudakis; Pavlos Moraitis. 2022; IJAOSE 7(2), pp.79–107. **Access:** SELECTED_FULL_TEXT. **Inspected:** Method architecture and transformations; practical applications; section 5.1 educational exercise. **Limit:** Football exercise involved 28 students and 19 questionnaires after a two-hour exercise; not a randomised whole-method superiority trial. [EAOSE-S033]

**EAOSE-S034. An Empirical Evaluation of the i* Framework in a Model-Based Software Generation Environment** — Hugo Estrada; Alicia Martínez; Hugo Rebollar; Oscar Pastor; John Mylopoulos. 2006; Author-uploaded conference paper. **Access:** SELECTED_FULL_TEXT. **Inspected:** Case-study design, modelling problems, size/understandability and modularity observations. **Limit:** Three teams of 3, 3 and 2 analysts on different projects; no randomised conventional-engineering comparator. [EAOSE-S034]

**EAOSE-S035. Why Do Multi-Agent LLM Systems Fail?** — Mert Cemri; Melissa Z. Pan; Shuyi Yang; Lakshya A. Agrawal; Bhavya Chopra; Rishabh Tiwari; Kurt Keutzer; Aditya Parameswaran; Dan Klein; Kannan Ramchandran; Matei Zaharia; Joseph E. Gonzalez; Ion Stoica. 2025-10-26; arXiv:2503.13657v3. **Access:** SELECTED_FULL_TEXT. **Inspected:** MAST construction, human annotation, expanded corpus and limitations. **Limit:** 150 initial human-inspected traces are distinct from the expanded 1600+ corpus; benchmark/framework observations are not production prevalence estimates. [EAOSE-S035]

**EAOSE-S036. AI Agents That Matter** — Sayash Kapoor; Benedikt Stroebl; Zachary S. Siegel; Nitya Nadgir; Arvind Narayanan. 2024; arXiv:2407.01502v1. **Access:** SELECTED_FULL_TEXT. **Inspected:** Cost/accuracy trade-offs, benchmark construction, reproducibility and evaluation examples. **Limit:** Criticism and examined benchmarks do not measure all AOSE methods or establish universal single-agent superiority. [EAOSE-S036]

**EAOSE-S037. Engineering the Next Generation of Multi-agent Systems: A Community Roadmap from EMAS 2025** — Sebastian Rodriguez; Akhila Bairy; Matteo Baldoni; Patrick Benjamin; Constantin Blessing; Nicolas Brandstetter; Amit K. Chopra; Thomas Clemen; Louise A. Dennis; Ahmad Esmaeili; Lu Feng; Angelo Ferrando; Zahra Ghorrati; Victor Guillet; Önder Gürcan; Soham Hans; James Herber; Viviana Mascardi; Marcel Mauri; Jörg P. Müller; John Thangarajah; Rafał Tyl; Yi Yang. 2026; Accepted 2026 chapter; EMAS 2025 event; DOI 10.1007/978-3-032-18011-7_14. **Access:** SELECTED_FULL_TEXT. **Inspected:** Sections 3–6; workshop method, participant/elicitation limits, challenges and roadmap. **Limit:** Self-selected workshop participants; a community agenda is neither a population survey nor evidence that proposed integration works. [EAOSE-S037]

**EAOSE-S038. Self-Organizing Manufacturing Control: An Industrial Application of Agent Technology** — Stefan Bussmann; Klaus Schild. 2000; ICMAS author paper. **Access:** SELECTED_FULL_TEXT. **Inspected:** Auction mechanism, manufacturing assumptions and simulation/evaluation sections. **Limit:** An industrial problem and authorship do not convert simulation into a production deployment or lifecycle cost comparison. [EAOSE-S038]

**EAOSE-S039. ASPECS: an Agent-oriented Software Process for Engineering Complex Systems** — Massimo Cossentino; Vincent Hilaire; Ambra Molesini; Valeria Seidita. 2009; Online 2009; later journal volume; author full-text copy. **Access:** SELECTED_FULL_TEXT. **Inspected:** PASSI/RIO combination; holonic levels; requirements, society and implementation phases. **Limit:** Holonic decomposition is a selected organisational architecture, not mandatory in all AOSE systems. [EAOSE-S039]

**EAOSE-S040. ADELFE: A Methodology for Adaptive Multi-Agent Systems Engineering** — Carole Bernon; Marie-Pierre Gleizes; Sylvain Peyruqueou; Gauthier Picard. 2004; ESAW 2003 proceedings chapter, author/teaching copy. **Access:** SELECTED_FULL_TEXT. **Inspected:** Adaptive cooperation, non-cooperative situations, process; final discussion pp.324–325. **Limit:** Local cooperative repair is a design principle for selected systems, not a supplied universal global-convergence proof. [EAOSE-S040]

**EAOSE-S041. τ-bench: A Benchmark for Tool-Agent-User Interaction in Real-World Domains** — Shunyu Yao; Noah Shinn; Pedram Razavi; Karthik Narasimhan. 2024; arXiv:2406.12045v1. **Access:** SELECTED_FULL_TEXT. **Inspected:** Section 3 task/reward definition; evaluation setup and reliability measures. **Limit:** Retail/airline simulations; final database and substring checks may miss consent violations, explicitly acknowledged. Not live-business outcome frequency. [EAOSE-S041]

**EAOSE-S042. AgentDojo: A Dynamic Environment to Evaluate Prompt Injection Attacks and Defenses for LLM Agents** — Edoardo Debenedetti; Jie Zhang; Mislav Balunović; Luca Beurer-Kellner; Marc Fischer; Florian Tramèr. 2024; arXiv:2406.13352v1. **Access:** SELECTED_FULL_TEXT. **Inspected:** Threat model; task and security-case construction; attacks, defences and limitations. **Limit:** 97 tasks and 629 security cases in the inspected version; benchmark vulnerability is not a population incidence rate or proof all defences fail. [EAOSE-S042]

**EAOSE-S043. The Evolution of Tropos** — Raian Ali; Amit K. Chopra; Fabiano Dalpiaz; Paolo Giorgini; John Mylopoulos; Vítor E. Silva Souza. 2010; iStar workshop paper, author PDF. **Access:** SELECTED_FULL_TEXT. **Inspected:** Goal models, socio-technical/commitment developments and adaptive systems directions. **Limit:** An extension agenda is not established deployment-wide effectiveness; relation to original Tropos is explicit. [EAOSE-S043]

**EAOSE-S044. ARARA: A LLM-based Multi-Agent Development Framework for Conversational Recommender Systems** — Fillipe Santos; Juliano Soares; Sildolfo Gomes; Julio Cesar dos Reis; Marcelo S. Reis. 2026; EMAS 2026 workshop paper. **Access:** SELECTED_FULL_TEXT. **Inspected:** Framework sections; section 4 setup; section 5 results; Figure 2; section 4.2 one-run design. **Limit:** Matched backends and memory, not equal computation; one execution per query; satisfaction is a relevance-based proxy, not a human user study. [EAOSE-S044]

**EAOSE-S045. Ex-Plan: Explaining BDI Agent Behaviour Through Contrastive Plan Analysis** — Curtis Davies; Babak Esfandiari. 2026; EMAS 2026 workshop paper. **Access:** SELECTED_FULL_TEXT. **Inspected:** Architecture, three MicroASL scenarios, section 5.1 limitations. **Limit:** Scripted scenarios, not a human trial; explanations cannot reconstruct unlogged derivations or tie-breaks. [EAOSE-S045]

**EAOSE-S046. AgentSpeak(ER): An Extension of AgentSpeak(L) improving Encapsulation and Reasoning about Goals** — Alessandro Ricci; Rafael H. Bordini; Jomi F. Hübner; Rem Collier. 2018; AAMAS extended abstract, pp.2054–2056. **Access:** FULL_TEXT_SHORT_WORK. **Inspected:** Motivation, plan encapsulation and integrated reactive/goal behaviour. **Limit:** Language proposal, not proof that all platforms share its failure or goal semantics. [EAOSE-S046]

**EAOSE-S047. Using a Situational Method Engineering Approach to Identify Reusable Method Fragments from the Secure TROPOS Methodology** — Graham Low; Haralambos Mouratidis; Brian Henderson-Sellers. 2010; Journal of Object Technology article. **Access:** SELECTED_FULL_TEXT. **Inspected:** Fragment extraction, process components, security work products and assembly discussion. **Limit:** Extracted fragments retain semantic prerequisites; availability is not automatic compatibility or lower cost. [EAOSE-S047]

**EAOSE-S048. Analysis and Design of Multiagent Systems using MAS-CommonKADS** — Carlos A. Iglesias; Mercedes Garijo; José C. González; Juan R. Velasco. 1997; ATAL workshop 1997, proceedings 1998; DOI 10.1007/BFb0026768. **Access:** SELECTED_FULL_TEXT. **Inspected:** CommonKADS extension, agent/task/expertise/organisation/coordination/communication/design models. **Limit:** Knowledge-engineering import, not replacement of requirements or an independently demonstrated universal method. [EAOSE-S048]

**EAOSE-S049. Secure Tropos: a Security-Oriented Extension of the Tropos Methodology** — Haralambos Mouratidis; Paolo Giorgini. 2007; DOI 10.1142/S0218194007003240. **Access:** SELECTED_FULL_TEXT. **Inspected:** Security constraints, secure dependencies, design and testing linkage. **Limit:** A model exposes selected threats; omitted threat actors, incorrect assumptions and implementation drift remain. [EAOSE-S049]

**EAOSE-S050. Towards Jacamo-rest: A Resource-Oriented Abstraction for Managing Multi-Agent Systems** — Cleber J. Amaral; Jomi F. Hübner; Timotheus Kampik. 2020-06-10; arXiv:2006.05619v1. **Access:** SELECTED_FULL_TEXT. **Inspected:** Agent/environment/organisation resources, REST management, discussion of ongoing work. **Limit:** Security is not addressed by this prototype; externally callable operations do not establish authorised safe evolution. [EAOSE-S050]

**EAOSE-S051. Real-Time BDI Agents: A Model and Its Implementation** — Riccardo Traldi; Francesco Bruschetti; Mirko Robol; Davide Calvaresi; Marco Roveri; Paolo Giorgini. 2026-03-05; arXiv:2205.00979v2; v1 was 2022. **Access:** SELECTED_FULL_TEXT. **Inspected:** Section 4 scheduling/implementation assumptions and evaluation. **Limit:** Plan search and BDI-loop costs excluded; external reactions delayed until scheduled tasks finish. Not unrestricted hard-real-time certification. [EAOSE-S051]

**EAOSE-S052. BDI-Agents for Agile Goal-Oriented Business Processes** — Birgit Burmeister; Michael Arnold; Felicia Copaciu; Giovanni Rimassa. 2008; AAMAS industrial track. **Access:** SELECTED_FULL_TEXT. **Inspected:** Section 4.3 prototype development and platform migration; lessons learned. **Limit:** Three-month prototype, up to four modellers and ten scenarios; semantic differences and missing version support reported. Not a production-wide ROI study. [EAOSE-S052]

**EAOSE-S053. On agent-based software engineering** — Nicholas R. Jennings. 2000; Artificial Intelligence; DOI 10.1016/S0004-3702(99)00107-1. **Access:** SELECTED_FULL_TEXT. **Inspected:** Abstraction, decomposition and organisation; section 5 trade-offs. **Limit:** Conceptual engineering rationale, not a theorem of agent superiority; autonomy complicates predictable composition. [EAOSE-S053]

**EAOSE-S054. A Goal-Oriented Software Testing Methodology** — Cu Duy Nguyen; Anna Perini; Paolo Tonella. 2007; AOSE 2007 workshop; published 2008 DOI 10.1007/978-3-540-79488-2_5. **Access:** SELECTED_FULL_TEXT. **Inspected:** Goal-to-test derivation, test skeletons and oracle construction. **Limit:** Domain-specific oracle content still requires engineering judgement; generated tests are not stakeholder validation. [EAOSE-S054]

**EAOSE-S055. Do you get it? User-evaluated explainable BDI agents** — Joost Broekens; Maaike Harbers; Koen Hindriks; Karel van den Bosch; Catholijn Jonker; John-Jules Meyer. 2010; MATES author paper. **Access:** SELECTED_FULL_TEXT. **Inspected:** Explanation algorithms and user study; n=30; results and limitations. **Limit:** Ten participants per explanation condition in a pancake scenario; ratings are not demonstrated operational safety or faithfulness of unlogged causes. [EAOSE-S055]

**EAOSE-S056. Validating the DS1 Remote Agent Experiment** — P. Pandurang Nayak; Douglas E. Bernard; Gregory Dorais; Edward B. Gamble Jr.; Bob Kanefsky; James Kurien; William Millar; Nicola Muscettola; Kanna Rajan; Nicolas Rouquette; Benjamin D. Smith; William Taylor; Yu-wen Tung. 1999; ISAI-RAS primary flight-validation report. **Access:** SELECTED_FULL_TEXT. **Inspected:** Layered validation; section 5 May 1999 flight events and recovery decisions. **Limit:** Actual spacecraft demonstration, not whole-AOSE methodology comparison. Race/deadlock and confirmation mismatch qualify success; untested patch was not uplinked. [EAOSE-S056]

**EAOSE-S057. Generative Agents: Interactive Simulacra of Human Behavior** — Joon Sung Park; Joseph C. O'Brien; Carrie J. Cai; Meredith Ringel Morris; Percy Liang; Michael S. Bernstein. 2023; arXiv:2304.03442v2. **Access:** SELECTED_FULL_TEXT. **Inspected:** Memory, reflection, planning and sandbox evaluation. **Limit:** A 25-agent simulation and believability evaluations do not validate real populations or anthropological claims. [EAOSE-S057]

**EAOSE-S058. INGENIAS Development Kit file catalogue** — INGENIAS project maintainers. 2026-09-07; Catalogue snapshot, not a release certification. **Access:** CATALOGUE_ONLY. **Inspected:** Visible download/version listing. **Limit:** Availability does not establish ongoing maintenance, safety, adoption or effectiveness. [EAOSE-S058]

**EAOSE-S059. PASSI ToolKit project catalogue** — PASSI ToolKit project maintainers. 2026-09-07; Catalogue snapshot. **Access:** CATALOGUE_ONLY. **Inspected:** Project description and available files. **Limit:** Not a runtime/toolchain test or proof of present support. [EAOSE-S059]

**EAOSE-S060. AgentFactory: pattern-centric JADE development thesis tool** — ls-cnr/AgentFactory maintainers. 2026-09-07; Repository README snapshot. **Access:** README_ONLY. **Inspected:** README purpose and JADE relation. **Limit:** Name collision: this is not the established Agent Factory AOP platform. No platform-continuity claim is based on this entry. [EAOSE-S060]

**EAOSE-S061. Comma: A Commitment-Based Business Modeling Methodology and its Empirical Evaluation** — Pankaj R. Telang; Munindar P. Singh. 2012; AAMAS full paper. **Access:** SELECTED_FULL_TEXT. **Inspected:** Sections 4–5; Figures 7–10 and Table 5, visually inspected. **Limit:** 34 graduate students; better initial modelling but slower first modification; self-reported time, outlier removal and multiple contrasts. No whole-lifecycle superiority. [EAOSE-S061]

**EAOSE-S062. A Universal Modular ACTOR Formalism for Artificial Intelligence** — Carl Hewitt; Peter Bishop; Richard Steiger. 1973; IJCAI original paper. **Access:** SELECTED_FULL_TEXT. **Inspected:** Actor/message/computation formulation. **Limit:** Historical neighbouring foundation. Actor and AOSE agent abstractions overlap but are not identical; no direct influence edge without documentary support. [EAOSE-S062]

**EAOSE-S063. BDI Agents: From Theory to Practice** — Anand S. Rao; Michael P. Georgeff. 1995; ICMAS primary paper. **Access:** SELECTED_FULL_TEXT. **Inspected:** Belief, desire, intention architecture and practical reasoning implementation. **Limit:** Architectural background relevant to AOSE design; not evidence every application needs BDI. [EAOSE-S063]

**EAOSE-S064. A Methodology and Modelling Technique for Systems of BDI Agents** — David Kinny; Michael Georgeff; Anand Rao. 1996; MAAMAW proceedings; DOI 10.1007/BFb0031846; later online record. **Access:** ABSTRACT_AND_METADATA_ONLY. **Inspected:** Publisher abstract and bibliographic identity. **Limit:** Full chapter inaccessible; precise procedures not reconstructed beyond inspected abstract and documented later accounts. [EAOSE-S064]

**EAOSE-S065. The Contract Net Protocol: High-Level Communication and Control in a Distributed Problem Solver** — Reid G. Smith. 1980; IEEE Transactions on Computers author copy. **Access:** SELECTED_FULL_TEXT. **Inspected:** Task announcement, bidding, award and termination; applicability. **Limit:** Earlier 1977/1978 formulations exist; 1980 is not asserted to be the first-ever invention. Protocol is not strategic truthfulness or fair allocation by itself. [EAOSE-S065]

**EAOSE-S066. Intention is Choice with Commitment** — Philip R. Cohen; Hector J. Levesque. 1990; Artificial Intelligence; DOI 10.1016/0004-3702(90)90055-5. **Access:** SELECTED_FULL_TEXT. **Inspected:** Intention/persistent-goal definitions; achievement, impossibility and irrelevance conditions. **Limit:** Formal model under stated modal assumptions; selected definitions inspected, not every proof independently checked or a runtime prescription for all agents. [EAOSE-S066]

**EAOSE-S067. Multi-agent oriented programming with JaCaMo** — Olivier Boissier; Rafael H. Bordini; Jomi F. Hübner; Alessandro Ricci; Andrea Santi. 2013; Science of Computer Programming article; earlier online publication. **Access:** ABSTRACT_AND_METADATA_ONLY. **Inspected:** Abstract, authors and component integration claim. **Limit:** Full paper request-only; detailed dimension treatment instead grounded in S050 and S074. [EAOSE-S067]

**EAOSE-S068. MOISE+: Towards a Structural, Functional, and Deontic Model for MAS Organization** — Jomi F. Hübner; Jaime S. Sichman; Olivier Boissier. 2002; AAMAS; DOI 10.1145/544741.544858. **Access:** SELECTED_FULL_TEXT. **Inspected:** Structural, functional and deontic specifications and their relationship. **Limit:** Normative model does not make violations impossible or establish strategic cooperation in every open setting. [EAOSE-S068]

**EAOSE-S069. A verification framework for agent programming with declarative goals** — Frank S. de Boer; Koen V. Hindriks; Wiebe van der Hoek; John-Jules Ch. Meyer. 2006; Article-in-press copy printed 24 January 2006; DOI 10.1016/j.jal.2005.12.014. **Access:** SELECTED_FULL_TEXT. **Inspected:** GOAL, goals-to-be versus goals-to-do, commitment strategy, semantics and verification example. **Limit:** Copy has 2005 copyright but 2006 print date; journal issue date not inferred. Selected semantics, not independent proof replay or environment validation. [EAOSE-S069]

**EAOSE-S070. Checking Consistency of Agent Designs Against Interaction Protocols for Early-Phase Defect Location** — Yoosef Abushark; John Thangarajah; Tim Miller; James Harland. 2014; AAMAS pp.933 onward. **Access:** SELECTED_FULL_TEXT. **Inspected:** Design/protocol consistency construction and scope. **Limit:** Static consistency depends on the modelling semantics; not proof that deployment observations satisfy the model. [EAOSE-S070]

**EAOSE-S071. Agent Design Consistency Checking via Planning** — Nitin Yadav; John Thangarajah; Sebastian Sardina. 2017; IJCAI paper 65. **Access:** SELECTED_FULL_TEXT. **Inspected:** Planning-based consistency analysis and evaluation. **Limit:** Bounded formal/design analysis, not a lifecycle effectiveness or deployment assurance result. [EAOSE-S071]

**EAOSE-S072. The Tropos Software Engineering Methodology** — Mirko Morandini; Fabiano Dalpiaz; Cu Duy Nguyen; Alberto Siena. 2014; Author book-chapter manuscript. **Access:** SELECTED_FULL_TEXT. **Inspected:** Introduction, method/language models, testing extensions and iterations. **Limit:** A retrospective by method researchers; improvements are not independent replications of the original methodology. [EAOSE-S072]

**EAOSE-S073. Plans and Resource-Bounded Practical Reasoning** — Michael E. Bratman; David J. Israel; Martha E. Pollack. 1988; Author/teaching copy; original publication 1988; copy/reprint date not equated with origin. **Access:** SELECTED_FULL_TEXT. **Inspected:** Resource-bounded planning and intention/reconsideration discussion. **Limit:** Conceptual computational/practical-reasoning foundation; no direct inference of consciousness or guaranteed performance. [EAOSE-S073]

**EAOSE-S074. Dimensions in Programming Multi-Agent Systems** — Olivier Boissier; Rafael H. Bordini; Jomi F. Hübner; Alessandro Ricci. 2019; Knowledge Engineering Review; online 2018; manuscript copy. **Access:** SELECTED_FULL_TEXT. **Inspected:** Agent, environment, organisation and interaction dimensions; integration challenges. **Limit:** Separating concerns does not remove cross-dimensional consistency costs; not an automatic assurance mechanism. [EAOSE-S074]

**EAOSE-S075. AutoGen: Enabling Next-Gen LLM Applications via Multi-Agent Conversation** — Qingyun Wu; Gagan Bansal; Jieyu Zhang; Yiran Wu; Beibin Li; Erkang Zhu; Li Jiang; Xiaoyun Zhang; Shaokun Zhang; Jiale Liu; Ahmed Awadallah; Ryen W. White; Doug Burger; Chi Wang. 2023-10-03; arXiv:2308.08155v2. **Access:** SELECTED_FULL_TEXT. **Inspected:** Sections 2–3; conversable agents, conversation programming, six applications and baseline qualifications. **Limit:** Mixes frameworks, prompts, tools and model backends. Shorter glue code and selected task gains are not whole-AOSE productivity or total-cost proof. [EAOSE-S075]

**EAOSE-S076. MetaGPT: Meta Programming for A Multi-Agent Collaborative Framework** — Sirui Hong; Mingchen Zhuge; Jiaqi Chen; Xiawu Zheng; Yuheng Cheng; Ceyao Zhang; Jinlin Wang; Zili Wang; Steven Ka Shing Yau; Zijuan Lin; Liyang Zhou; Chenyu Ran; Lingfeng Xiao; Chenglin Wu. 2024-10-21; arXiv:2308.00352v6; original submission 2023. **Access:** SELECTED_FULL_TEXT. **Inspected:** SOP-style software-development roles, communication and experimental scope. **Limit:** Software generation is the application here; a named role or SOP does not supply full agent-system lifecycle methodology. [EAOSE-S076]

**EAOSE-S077. ChatDev: Communicative Agents for Software Development** — Chen Qian; Wei Liu; Hongzhang Liu; Nuo Chen; Yufan Dang; Jiahao Li; Cheng Yang; Weize Chen; Yusheng Su; Xin Cong; Juyuan Xu; Dahai Li; Zhiyuan Liu; Maosong Sun. 2024-06-05; arXiv:2307.07924v5; original submission 2023. **Access:** SELECTED_FULL_TEXT. **Inspected:** Chat-chain phases, communicative roles, software-development experiments and limitations. **Limit:** Engineering software with agents is not identical to engineering agent systems; benchmark artefacts do not prove operational maintainability. [EAOSE-S077]

**EAOSE-S078. ReAct: Synergizing Reasoning and Acting in Language Models** — Shunyu Yao; Jeffrey Zhao; Dian Yu; Nan Du; Izhak Shafran; Karthik Narasimhan; Yuan Cao. 2023; arXiv:2210.03629v3; first submission 2022. **Access:** SELECTED_FULL_TEXT. **Inspected:** Reason/action interleaving; knowledge and interactive benchmark evaluation; limitations. **Limit:** An execution pattern, not a complete AOSE methodology or proof natural-language traces are faithful causal explanations. [EAOSE-S078]

**EAOSE-S079. LangGraph persistence documentation** — LangChain maintainers. 2026-09-07; Unversioned documentation snapshot; durable-execution URL redirected here. **Access:** WEB_PAGE_INSPECTED. **Inspected:** Checkpointing, threads and persistence discussion. **Limit:** No release-version pin established; persisted graph state does not itself guarantee durable external effects or correct business outcomes. [EAOSE-S079]

**EAOSE-S080. LangGraph interrupts documentation** — LangChain maintainers. 2026-09-07; Unversioned documentation snapshot. **Access:** WEB_PAGE_INSPECTED. **Inspected:** Side effects called before interrupt must be idempotent; subgraph restart semantics. **Limit:** Node re-execution may repeat effects. Moving an effect after approval alone is not a crash-safe exactly-once guarantee; that stronger inference is rejected. [EAOSE-S080]

**EAOSE-S081. AutoGen AgentChat termination documentation** — Microsoft AutoGen maintainers. 2026-09-07; stable documentation snapshot, not a pinned release audit. **Access:** WEB_PAGE_INSPECTED. **Inspected:** TerminationCondition, max-message/token/time/external conditions and reset behaviour. **Limit:** Conditions checked after responses; token limits rely on reported usage; stopping a conversation is not proving success or cancelling all external effects. [EAOSE-S081]

**EAOSE-S082. Agent Oriented Design of a Soccer Robot Team** — Anne Collinot; Alexis Drogoul; Philippe Benhamou. 1996; ICMAS Cassiopeia paper. **Access:** SELECTED_FULL_TEXT. **Inspected:** Elementary, relational and organisational behaviours; designer-dependent mapping; simulation section. **Limit:** Contract Net use is documented. Simulation findings do not establish successful physical deployment or that every interaction can be designed bottom-up. [EAOSE-S082]

**EAOSE-S083. DESIRE: Modelling Multi-Agent Systems in a Compositional Formal Framework** — Frances M. T. Brazier; Barbara M. Dunin-Keplicz; Nick R. Jennings; Jan Treur. 1997; Author manuscript for IJCIS 6(1). **Access:** SELECTED_FULL_TEXT. **Inspected:** Introduction; task, knowledge and information/control composition; electricity-network example. **Limit:** Formal specification of an operational-system example is not a controlled cost/benefit study or proof all deployed behaviours conform. [EAOSE-S083]

**EAOSE-S084. AGENT 2026 workshop at ICSE** — AGENT 2026 organisers. 2026; Official programme and About section, snapshot at cut-off. **Access:** WEB_PAGE_INSPECTED. **Inspected:** About text explicitly relating current agent engineering to AOSE; programme. **Limit:** Documented institutional/intellectual acknowledgement does not establish inheritance by every modern framework or efficacy. [EAOSE-S084]

**EAOSE-S085. Towards Engineering LLM-Enhanced Multi-Agent Systems: A Critical Examination of Roles** — Tansu Zafer Asici; Önder Gürcan; Geylani Kardas. 2025; EMAS 2025 workshop manuscript. **Access:** SELECTED_FULL_TEXT. **Inspected:** Sections 2–5; role specification and realisation; Figure 5; proposed run-time roles. **Limit:** Explicit AOSE import, but proposed first-class role architecture is not empirically shown superior in all settings; alternatives have costs. [EAOSE-S085]

**EAOSE-S086. Towards Engineering LLM-Enhanced Multi-Agent Systems: A Critical Examination of Roles** — Tansu Zafer Asici; Önder Gürcan; Geylani Kardas. 2026-02-14; Published chapter pp.200–220; DOI 10.1007/978-3-032-18011-7_12. **Access:** ABSTRACT_AND_METADATA_ONLY. **Inspected:** Publisher first-online date, authors, abstract and chapter identity. **Limit:** Related publication of S085, not independent empirical replication; full published text not inspected. [EAOSE-S086]

**EAOSE-S087. Evaluating Goal Achievement in Enterprise Modeling: An Interactive Procedure and Experiences** — Jennifer Horkoff; Eric Yu. 2009; PoEM author manuscript. **Access:** SELECTED_FULL_TEXT. **Inspected:** Interactive evaluation procedure; case experiences and conclusion. **Limit:** Human judgement, stakeholder engagement and training remain necessary; case experiences are not a controlled methodology comparison. [EAOSE-S087]

**EAOSE-S088. Peach: Program Each Agent and Communicate Howsoever** — Amit K. Chopra; Samuel H. Christie V; Munindar P. Singh. 2026; AAMAS 2026 pp.1022–1030; DOI 10.65109/SAXY3841. **Access:** SELECTED_FULL_TEXT. **Inspected:** Introduction; sections 6.2–6.3 operational rules, pp.1027–1029; page-6 screenshot. **Limit:** Communicative-act/transport separation and adapters are specified under their operational model. No general claim about arbitrary transport, security models or lifecycle cost is supported. [EAOSE-S088]

**EAOSE-S089. Engineering Norm-aware BDI Agents** — Michael Winikoff; Frank Dignum; Sebastian Rodriguez; John Thangarajah. 2026; AAMAS extended abstract pp.3307–3309; DOI 10.65109/SEJS3352. **Access:** FULL_TEXT_SHORT_WORK. **Inspected:** All three pages; norm/goal-plan transformation, public-transport example and future work; page-1 screenshot. **Limit:** Jason example, not comparative deployment evidence. Norms can be knowingly violated; hard security permissions are a different construct. Automatic transformation, dynamic norms and larger-system overhead remain future work. [EAOSE-S089]

**EAOSE-S090. A Multi-level Explainability Framework for Engineering and Understanding BDI Agents** — Elena Yan; Samuele Burattini; Jomi F. Hübner; Alessandro Ricci. 2026; AAMAS JAAMAS-track paper pp.4191–4193; DOI 10.65109/ZIQG2381. **Access:** FULL_TEXT_SHORT_WORK. **Inspected:** All three pages; implementation/design/domain levels, mapping functions, implemented prototype and future work; page-1 screenshot. **Limit:** Prototype implements implementation and design levels, not the proposed domain level. Focus is individual BDI agents. Collective explanation and LLM transfer are not demonstrated; no comparative user benefit is established here. [EAOSE-S090]



## Source-link definitions

[EAOSE-S001]: https://www.researchgate.net/publication/222482819_Agent-Oriented_Programming/fulltext/0e603da7f0c46d4f0aa42e1d/Agent-Oriented-Programming.pdf
[EAOSE-S002]: https://www.cs.ox.ac.uk/people/michael.wooldridge/pubs/jaamas2000b.pdf
[EAOSE-S003]: https://www.researchgate.net/publication/225198353_Tropos_An_Agent-Oriented_Software_Development_Methodology
[EAOSE-S004]: https://link.springer.com/article/10.1023/B:AGNT.0000018806.20944.ef
[EAOSE-S005]: https://www.cs.utoronto.ca/~eric/ieeeexp/ieeeexp2.html
[EAOSE-S006]: https://michaelwinikoff.com/wp-content/uploads/2019/05/aamas02-aose-ws.pdf
[EAOSE-S007]: https://www.researchgate.net/publication/220344738_MULTIAGENT_SYSTEMS_ENGINEERING
[EAOSE-S008]: https://www.researchgate.net/publication/220608212_O-MaSE_A_customisable_approach_to_designing_and_building_complex_adaptive_multi-agent_systems
[EAOSE-S009]: https://ceur-ws.org/Vol-627/fipa_5.pdf
[EAOSE-S010]: https://winikoff.github.io/pdf/aois2003.pdf
[EAOSE-S011]: https://ceur-ws.org/Vol-627/fipa_6.pdf
[EAOSE-S012]: https://lia.disi.unibo.it/~ao/pubs/pdf/volumes/eumas2006/Republications/15.pdf
[EAOSE-S013]: https://www.researchgate.net/publication/237490469_From_Requirements_to_Code_with_the_PASSI_Methodology
[EAOSE-S014]: https://www.cs.ox.ac.uk/people/michael.wooldridge/pubs/aose2000a.pdf
[EAOSE-S015]: https://www.cs.ox.ac.uk/people/michael.wooldridge/pubs/agents98.pdf
[EAOSE-S016]: https://onlinelibrary.wiley.com/doi/abs/10.1002/9780470050118.ecse006
[EAOSE-S017]: https://emas.in.tu-clausthal.de/
[EAOSE-S018]: https://emas-workshop.github.io/2026/
[EAOSE-S019]: https://aamas.csc.liv.ac.uk/Proceedings/aamas2026/forms/contents.htm
[EAOSE-S020]: https://arxiv.org/html/2006.08820v1
[EAOSE-S021]: https://doi.org/10.1145/367211.367250
[EAOSE-S022]: https://doi.org/10.1145/958961.958963
[EAOSE-S023]: https://www.csc2.ncsu.edu/faculty/mpsingh/papers/mas/computer-acl-98.pdf
[EAOSE-S024]: https://jmvidal.cse.sc.edu/822/papers/Rep_Agent_Protocols.pdf
[EAOSE-S025]: https://ppgia.pucpr.br/~fabricio/ftp/Aulas/Mestrado/AS/Aula3/SC00061G_FIPA_ACL.pdf
[EAOSE-S026]: https://www.chrismitchell.net/sfac.pdf
[EAOSE-S027]: https://arxiv.org/html/2203.00086v1
[EAOSE-S028]: https://www.ifaamas.org/Proceedings/aamas2025/pdfs/p2426.pdf
[EAOSE-S029]: https://intranet.csc.liv.ac.uk/~matt/pubs/mcapl11.pdf
[EAOSE-S030]: https://www.ijcai.org/Proceedings/15/Papers/599.pdf
[EAOSE-S031]: https://www.ifaamas.org/Proceedings/aamas2017/pdfs/p260.pdf
[EAOSE-S032]: https://arxiv.org/html/2108.08117v1
[EAOSE-S033]: https://helios2.mi.parisdescartes.fr/~moraitis/webpapers/Moraitis-IJAOSE22.pdf
[EAOSE-S034]: https://www.researchgate.net/publication/225470190_An_Empirical_Evaluation_of_the_i_Framework_in_a_Model-Based_Software_Generation_Environment
[EAOSE-S035]: https://arxiv.org/html/2503.13657v3
[EAOSE-S036]: https://arxiv.org/html/2407.01502v1
[EAOSE-S037]: https://pure.manchester.ac.uk/ws/files/1825510647/EMAS2025_Roadmap.pdf
[EAOSE-S038]: https://www.eecis.udel.edu/~decker/courses/889a/daimler.pdf
[EAOSE-S039]: https://www.researchgate.net/publication/216702294_ASPECS_an_Agent-oriented_Software_Process_for_Engineering_Complex_Systems_How_to_design_agent_societies_under_a_holonic_perspective
[EAOSE-S040]: https://lia.disi.unibo.it/corsi/2007-2008/SMA-LS/papers/9/bernon2004a.pdf
[EAOSE-S041]: https://arxiv.org/html/2406.12045v1
[EAOSE-S042]: https://arxiv.org/html/2406.13352v1
[EAOSE-S043]: https://webspace.science.uu.nl/~dalpi001/papers/ali-chop-dalp-gior-mylo-souz-10-istar.pdf
[EAOSE-S044]: https://emas-workshop.github.io/2026/papers/041_ARARA_A_LLM-based_Multi-Agent_Development_Framework_for_Conv.pdf
[EAOSE-S045]: https://emas-workshop.github.io/2026/papers/015_Ex-Plan_Explaining_BDI_Agent_Behaviour_Through_Contrastive_P.pdf
[EAOSE-S046]: https://www.ifaamas.org/Proceedings/aamas2018/pdfs/p2054.pdf
[EAOSE-S047]: https://www.jot.fm/issues/issue_2010_07/article5.pdf
[EAOSE-S048]: https://www.researchgate.net/publication/2713293_Analysis_and_design_of_multiagent_systems_using_MAS-CommonKADS
[EAOSE-S049]: https://www.researchgate.net/publication/47529129_SECURE_TROPOS_A_SECURITY-ORIENTED_EXTENSION_OF_THE_TROPOS_METHODOLOGY
[EAOSE-S050]: https://arxiv.org/html/2006.05619v1
[EAOSE-S051]: https://arxiv.org/html/2205.00979v2
[EAOSE-S052]: https://www.ifaamas.org/Proceedings/aamas08/proceedings/pdf/industrial_application_track/AAMAS08_IndTrack_16.pdf
[EAOSE-S053]: https://faculty.sites.iastate.edu/tesfatsi/archive/tesfatsi/jennings.pdf
[EAOSE-S054]: https://www.researchgate.net/publication/221419145_A_Goal-Oriented_Software_Testing_Methodology
[EAOSE-S055]: https://ii.tudelft.nl/~joostb/files/mates2010_final.pdf
[EAOSE-S056]: https://ai.jpl.nasa.gov/public/documents/papers/rax-results-isairas99.pdf
[EAOSE-S057]: https://arxiv.org/html/2304.03442v2
[EAOSE-S058]: https://sourceforge.net/projects/ingenias/files/INGENIAS%20Development%20Kit/
[EAOSE-S059]: https://sourceforge.net/projects/ptk/
[EAOSE-S060]: https://github.com/ls-cnr/AgentFactory
[EAOSE-S061]: https://ifaamas.org/Proceedings/aamas2012/papers/3F_4.pdf
[EAOSE-S062]: https://www.ijcai.org/Proceedings/73/Papers/027B.pdf
[EAOSE-S063]: https://cdn.aaai.org/ICMAS/1995/ICMAS95-042.pdf
[EAOSE-S064]: https://link.springer.com/chapter/10.1007/BFb0031846
[EAOSE-S065]: https://www.reidgsmith.com/The_Contract_Net_Protocol_Dec-1980.pdf
[EAOSE-S066]: https://jmvidal.cse.sc.edu/library/cohen90a.pdf
[EAOSE-S067]: https://www.researchgate.net/publication/251518239_Multi-agent_oriented_programming_with_JaCaMo
[EAOSE-S068]: https://www.researchgate.net/publication/221456372_MOISE_Towards_a_Structural_Functional_and_Deontic_model_for_MAS_organization
[EAOSE-S069]: https://mmi.tudelft.nl/pub/koen/GOAL_JAL.pdf
[EAOSE-S070]: https://www.ifaamas.org/Proceedings/aamas2014/aamas/p933.pdf
[EAOSE-S071]: https://www.ijcai.org/proceedings/2017/0065.pdf
[EAOSE-S072]: https://www.staff.science.uu.nl/~dalpi001/papers/mora-dalp-nguy-sien-14-aose.pdf
[EAOSE-S073]: https://www.emse.fr/~boissier/enseignement/defiia/up5/pdf/Bratman-PlansPracticalResoning.pdf
[EAOSE-S074]: https://maxapress.com/data/article/ker/preview/pdf/S026988891800005X.pdf
[EAOSE-S075]: https://arxiv.org/html/2308.08155v2
[EAOSE-S076]: https://arxiv.org/html/2308.00352v6
[EAOSE-S077]: https://arxiv.org/html/2307.07924v5
[EAOSE-S078]: https://arxiv.org/html/2210.03629v3
[EAOSE-S079]: https://docs.langchain.com/oss/python/langgraph/persistence
[EAOSE-S080]: https://docs.langchain.com/oss/python/langgraph/interrupts
[EAOSE-S081]: https://microsoft.github.io/autogen/stable/user-guide/agentchat-user-guide/tutorial/termination.html
[EAOSE-S082]: https://cdn.aaai.org/ICMAS/1996/ICMAS96-005.pdf
[EAOSE-S083]: https://www.cs.vu.nl/~wai/Papers/IJCIS97.DESIRE10.pdf
[EAOSE-S084]: https://conf.researchr.org/home/icse-2026/agent-2026
[EAOSE-S085]: https://emas.in.tu-clausthal.de/2025/assets/pdfs/emas2025-14.pdf
[EAOSE-S086]: https://link.springer.com/chapter/10.1007/978-3-032-18011-7_12
[EAOSE-S087]: https://www.cs.toronto.edu/~jenhork/Papers/Horkoff_PoEM_2009l.pdf
[EAOSE-S088]: https://aamas.csc.liv.ac.uk/Proceedings/aamas2026/pdfs/SAXY3841.pdf
[EAOSE-S089]: https://aamas.csc.liv.ac.uk/Proceedings/aamas2026/pdfs/SEJS3352.pdf
[EAOSE-S090]: https://aamas.csc.liv.ac.uk/Proceedings/aamas2026/pdfs/ZIQG2381.pdf
