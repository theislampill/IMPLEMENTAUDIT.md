# Evolved Agent-Oriented Software Engineering — audit intake

Revision `EAOSE-2026-09-07-R1` · cut-off `2026-09-07` · lineage `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING`.

## Purpose and permitted outcomes

This is an intake for a later independent audit of an unspecified real system, not an assessment of a known repository. A question may be answered **already addressed**, **inapplicable**, **a simpler mechanism is sufficient**, **evidence insufficient**, or **a genuine candidate improvement remains**. No question presupposes a defect or authorises mutation. One mechanism may answer several questions; the source property count is not a control count.

The frozen corpus contains **83 / 83 examined candidates**, ten examined mandatory families and **62 exact-work/edition source records**. There are 65 favourable/conditional primary dispositions, one contested record, 16 rejection/ceremony/duplicate/supersession/no-general-property records and one unresolved claim. Thus 66 records have conditional audit questions and 17 are exported as boundaries rather than unconditional obligations. The whole-method superiority question, EAOSE-062, remains unresolved.

## Scope and evidence partitions

The corpus reconstructs requirements/social dependencies, abstraction selection, organisation, protocols, agent-internal design, method engineering, verification/validation, deployment/evolution, adoption evidence and contemporary translations. Its historical branches include i*/Tropos, Gaia, MaSE/O-MaSE, Prometheus, PASSI/Agile PASSI, INGENIAS, Agent OPEN, ADELFE, ASPECS, MAS-CommonKADS, interaction/commitment engineering and BDI/platform work. Source locators and material access limits travel with the packet.

Theory, historical provenance, specification, local comparison, field experience, independent replication and transfer are separate partitions. In particular, formal protocol and decision-code results can have strong theory but weak demonstrated environment/implementation transfer. The industrial programme and application survey support reported use but not whole-method causal benefit. Modern benchmarks and failures support their configured task findings, not every deployment. The two new composition mechanisms are analytical and have no independent field trial.

A later target must supply its actual requirements, legitimate actors and delegation, implementation/version bindings, observable effects, operating assumptions and costs. Where these are unavailable, the result is evidence insufficient, not automatic failure or satisfaction. Current provider behaviour, prices and platform versions must be checked at the target's own audit date rather than borrowed from historical studies.

## Complete denominator and dispositions

| Disposition | Count |
| --- | --- |
| ASSUMPTION_SENSITIVE | 9 |
| CEREMONY_NOT_GENERAL_PROPERTY | 2 |
| CONTESTED | 1 |
| CONTEXT_DEPENDENT | 11 |
| DOMAIN_SPECIFIC | 3 |
| DUPLICATE_CANDIDATE | 3 |
| NO_GENERAL_PROPERTY | 1 |
| REJECTED_OR_DISFAVOURED | 9 |
| RETAINED_IN_EVOLVED_FORM | 32 |
| STRONGLY_RETAINED | 7 |
| SUPERSEDED_BY_STRONGER_FORM | 1 |
| UNRESOLVED | 1 |
| USEFUL_BUT_EASILY_BUREAUCRATISED | 1 |
| USEFUL_BUT_EASILY_GAMED | 2 |

| ID | Name | Disposition |
| --- | --- | --- |
| EAOSE-001 | Affected-actor discovery and validation | RETAINED_IN_EVOLVED_FORM |
| EAOSE-002 | Separate stakeholder goals, runtime goals and acceptance conditions | STRONGLY_RETAINED |
| EAOSE-003 | Dependency and delegation vulnerability analysis | RETAINED_IN_EVOLVED_FORM |
| EAOSE-004 | Explicit goal conflict and alternative rationale | USEFUL_BUT_EASILY_GAMED |
| EAOSE-005 | Security constraints and delegation authority | RETAINED_IN_EVOLVED_FORM |
| EAOSE-006 | Revalidate goals when operating assumptions change | RETAINED_IN_EVOLVED_FORM |
| EAOSE-007 | A complete goal diagram proves complete requirements | REJECTED_OR_DISFAVOURED |
| EAOSE-008 | Justify the semantic fit of agency | STRONGLY_RETAINED |
| EAOSE-009 | Decouple agent-oriented analysis from runtime commitment | CONTEXT_DEPENDENT |
| EAOSE-010 | Bound delegated autonomy by capabilities and constraints | RETAINED_IN_EVOLVED_FORM |
| EAOSE-011 | Lifecycle cost and non-agent comparator | RETAINED_IN_EVOLVED_FORM |
| EAOSE-012 | Every active component should be an agent | REJECTED_OR_DISFAVOURED |
| EAOSE-013 | Role contracts separate responsibilities, permissions and activities | RETAINED_IN_EVOLVED_FORM |
| EAOSE-014 | Separate safety from progress obligations | STRONGLY_RETAINED |
| EAOSE-015 | Explicit many-to-many role-to-agent binding | RETAINED_IN_EVOLVED_FORM |
| EAOSE-016 | Organisation-level rules supplement local role contracts | RETAINED_IN_EVOLVED_FORM |
| EAOSE-017 | Capability-based dynamic reassignment | ASSUMPTION_SENSITIVE |
| EAOSE-018 | Environment and shared resources as engineered objects | RETAINED_IN_EVOLVED_FORM |
| EAOSE-019 | Static cooperative organisation as a universal premise | SUPERSEDED_BY_STRONGER_FORM |
| EAOSE-020 | Interaction specifications with explicit meaning and enactment | RETAINED_IN_EVOLVED_FORM |
| EAOSE-021 | Shared content and ontology interpretation | RETAINED_IN_EVOLVED_FORM |
| EAOSE-022 | Global-to-local protocol correspondence | ASSUMPTION_SENSITIVE |
| EAOSE-023 | Public commitment semantics for open interaction | CONTEXT_DEPENDENT |
| EAOSE-024 | Private mental states as the basis of communication compliance | CONTESTED |
| EAOSE-025 | Specified exceptional interaction and recovery | RETAINED_IN_EVOLVED_FORM |
| EAOSE-026 | Versioned protocol compatibility | RETAINED_IN_EVOLVED_FORM |
| EAOSE-027 | FIPA message compliance guarantees full interoperability | REJECTED_OR_DISFAVOURED |
| EAOSE-028 | Select an agent-internal architecture to match the decision problem | CONTEXT_DEPENDENT |
| EAOSE-029 | Percept-to-belief and action-to-effect correspondence | STRONGLY_RETAINED |
| EAOSE-030 | Plan applicability, achievement and failure conditions | RETAINED_IN_EVOLVED_FORM |
| EAOSE-031 | Interference among concurrent intentions | ASSUMPTION_SENSITIVE |
| EAOSE-032 | Semantics-aware model transformation | ASSUMPTION_SENSITIVE |
| EAOSE-033 | Explicit manual completion and integration duties | RETAINED_IN_EVOLVED_FORM |
| EAOSE-034 | Bidirectional design–implementation traceability | USEFUL_BUT_EASILY_BUREAUCRATISED |
| EAOSE-035 | Generated syntax establishes behavioural correctness | REJECTED_OR_DISFAVOURED |
| EAOSE-036 | Semantic compatibility of method fragments | ASSUMPTION_SENSITIVE |
| EAOSE-037 | Executable prescriptions and work-product consumers | RETAINED_IN_EVOLVED_FORM |
| EAOSE-038 | Iterative cross-view feedback rather than mandatory phase order | RETAINED_IN_EVOLVED_FORM |
| EAOSE-039 | Proportional method assembly and retirement | RETAINED_IN_EVOLVED_FORM |
| EAOSE-040 | Context-checked pattern reuse | CONTEXT_DEPENDENT |
| EAOSE-041 | Learnability and tool-maintenance fit | CONTEXT_DEPENDENT |
| EAOSE-042 | Method quality equals named-phase or diagram count | CEREMONY_NOT_GENERAL_PROPERTY |
| EAOSE-043 | Stakeholder validation is distinct from implementation verification | STRONGLY_RETAINED |
| EAOSE-044 | Assure both individual behaviour and collective outcomes | STRONGLY_RETAINED |
| EAOSE-045 | Explicit model and environment assumptions for formal assurance | ASSUMPTION_SENSITIVE |
| EAOSE-046 | Implementation-level decision-code verification | DOMAIN_SPECIFIC |
| EAOSE-047 | Design-to-protocol consistency checks | ASSUMPTION_SENSITIVE |
| EAOSE-048 | Oracle adequacy and false-success tests | USEFUL_BUT_EASILY_GAMED |
| EAOSE-049 | Simulation-to-deployment validity | ASSUMPTION_SENSITIVE |
| EAOSE-050 | Discriminating fault and perturbation testing | RETAINED_IN_EVOLVED_FORM |
| EAOSE-051 | Runtime observations linked to assurance claims | RETAINED_IN_EVOLVED_FORM |
| EAOSE-052 | Exhaustive testing guarantees unrestricted autonomous behaviour | REJECTED_OR_DISFAVOURED |
| EAOSE-053 | Deployment and legacy-integration obligations | RETAINED_IN_EVOLVED_FORM |
| EAOSE-054 | Versioned implementation and configuration evidence | RETAINED_IN_EVOLVED_FORM |
| EAOSE-055 | Operational feedback to maintained engineering models | RETAINED_IN_EVOLVED_FORM |
| EAOSE-056 | Authorised evolution within explicit revision boundaries | RETAINED_IN_EVOLVED_FORM |
| EAOSE-057 | Selective assurance revalidation after change | RETAINED_IN_EVOLVED_FORM |
| EAOSE-058 | Retirement preserves or resolves outstanding obligations | CONTEXT_DEPENDENT |
| EAOSE-059 | Design-method support implies a complete operational lifecycle | REJECTED_OR_DISFAVOURED |
| EAOSE-060 | Separate demonstrated mechanism, deployment and comparative benefit | STRONGLY_RETAINED |
| EAOSE-061 | Cost attribution and source non-independence | RETAINED_IN_EVOLVED_FORM |
| EAOSE-062 | Whole-method superiority over conventional engineering | UNRESOLVED |
| EAOSE-063 | Popularity, venue participation or framework maturity proves benefit | NO_GENERAL_PROPERTY |
| EAOSE-064 | Named-method observance as assurance | CEREMONY_NOT_GENERAL_PROPERTY |
| EAOSE-065 | Documented continuity rather than retrospective rebranding | RETAINED_IN_EVOLVED_FORM |
| EAOSE-066 | Cost-aware and repeatable stochastic evaluation | RETAINED_IN_EVOLVED_FORM |
| EAOSE-067 | Generated plans remain subject to executable constraints | ASSUMPTION_SENSITIVE |
| EAOSE-068 | Tool authority is enforced outside untrusted generated instructions | RETAINED_IN_EVOLVED_FORM |
| EAOSE-069 | Memory and retrieved-content provenance boundaries | CONTEXT_DEPENDENT |
| EAOSE-070 | Regression after model, prompt or remote-service changes | RETAINED_IN_EVOLVED_FORM |
| EAOSE-071 | Cross-agent trace correlation for diagnosis | CONTEXT_DEPENDENT |
| EAOSE-072 | A role prompt is a formal role contract | REJECTED_OR_DISFAVOURED |
| EAOSE-073 | Criterion–authority–effect coupling | RETAINED_IN_EVOLVED_FORM |
| EAOSE-074 | Evidence continuity through change as a separate new property | DUPLICATE_CANDIDATE |
| EAOSE-075 | Purposeful retirement of method machinery as a separate new property | DUPLICATE_CANDIDATE |
| EAOSE-076 | Obligation-preserving organisational reconfiguration | CONTEXT_DEPENDENT |
| EAOSE-077 | Hierarchical organisational decomposition | DOMAIN_SPECIFIC |
| EAOSE-078 | Cooperation-driven self-organisation | DOMAIN_SPECIFIC |
| EAOSE-079 | Knowledge and task modelling as distinct engineering views | CONTEXT_DEPENDENT |
| EAOSE-080 | A consistent fragment composition guarantees achievable goals | REJECTED_OR_DISFAVOURED |
| EAOSE-081 | Counterexample propagation as a distinct new control | DUPLICATE_CANDIDATE |
| EAOSE-082 | Observation plus self-revision guarantees improvement | REJECTED_OR_DISFAVOURED |
| EAOSE-083 | Preserve responsiveness during long-running plan generation | CONTEXT_DEPENDENT |

## Shared domain profiles

Each complete property profile combines its application below with the ten-dimensional family profile here. These references resolve within this intake as well as the JSON. A dimension about an irrelevant runtime architecture is a non-applicability question, not a demand to invent one.

### DOMAIN-PROFILE-O1 — Requirements and social dependencies

**METHODOLOGY_AND_LIFECYCLE_SCOPE —** Early organisational inquiry, requirements negotiation and later revalidation; not automatic requirements generation.

**STAKEHOLDER_GOAL_AND_REQUIREMENT_SEMANTICS —** Distinguish affected actors, desired outcomes, soft qualities, tasks, dependencies and runtime goals. An acceptance observation is a separate translation.

**AGENT_ABSTRACTION_JUSTIFICATION —** Intentional/social analysis can be useful without selecting an autonomous runtime.

**ROLE_ORGANISATION_AND_AGENT_MAPPING —** Map real stakeholders and delegated responsibilities before assigning implementation roles. A stakeholder is not necessarily a software agent.

**INTERACTION_SPECIFICATION_AND_PROTOCOL_SEMANTICS —** Dependency agreements and validation exchanges require understood terms and participation; diagram edges do not obtain consent.

**DESIGN_TO_IMPLEMENTATION_CORRESPONDENCE —** Carry consequential requirements into constraints, executable choices and evidence without equating their representations.

**VERIFICATION_VALIDATION_AND_TEST_ORACLE —** Use stakeholder challenge, conflict examples and outcome criteria. A structurally complete graph cannot serve as its own external oracle.

**TOOL_SUPPORT_AND_MANUAL_OBLIGATIONS —** Editors/checkers organise models; analysts still discover actors, elicit meaning and negotiate disputed priorities.

**DEPLOYMENT_EVOLUTION_AND_TRACEABILITY —** Changed needs, resources or evidence reopen affected mappings; do not require a complete organisational remodel for every edit.

**COMPARATIVE_EVIDENCE_COST_AND_NON_AGENT_ALTERNATIVE —** Compare improved decisions against modelling/negotiation cost; ordinary requirements practices may supply the same function.

### DOMAIN-PROFILE-O2 — Agent-paradigm selection

**METHODOLOGY_AND_LIFECYCLE_SCOPE —** Architecture selection and periodic reassessment across construction, operation and maintenance.

**STAKEHOLDER_GOAL_AND_REQUIREMENT_SEMANTICS —** Hold the required consequences and constraints stable enough to compare alternative designs rather than rewarding a changed task.

**AGENT_ABSTRACTION_JUSTIFICATION —** Justify agency by delegated discretion, situated choices, interaction or organisational semantics; distribution and message passing alone are insufficient.

**ROLE_ORGANISATION_AND_AGENT_MAPPING —** Count conceptual roles separately from runtime entities and justify control boundaries rather than maximising agent count.

**INTERACTION_SPECIFICATION_AND_PROTOCOL_SEMANTICS —** Compare negotiated or information-dependent interactions with conventional calls, events, actors and workflows.

**DESIGN_TO_IMPLEMENTATION_CORRESPONDENCE —** Check whether the chosen implementation actually provides the discretion or accountability invoked by its agent description.

**VERIFICATION_VALIDATION_AND_TEST_ORACLE —** Evaluate representative outcomes, failure modes and lifecycle cost against an appropriate non-agent baseline.

**TOOL_SUPPORT_AND_MANUAL_OBLIGATIONS —** Include expertise, platform operation, debugging and vendor dependence; a theoretically expressive abstraction may be impractical for a team.

**DEPLOYMENT_EVOLUTION_AND_TRACEABILITY —** Reassess when the task becomes simpler, coordination changes, or operating cost overwhelms the original justification.

**COMPARATIVE_EVIDENCE_COST_AND_NON_AGENT_ALTERNATIVE —** Allow a controller, workflow, object/service design or mixed system to dominate on the declared criteria. No universal AOSE productivity result is assumed.

### DOMAIN-PROFILE-O3 — Organisational decomposition

**METHODOLOGY_AND_LIFECYCLE_SCOPE —** Analysis, architectural decomposition, role instantiation and guarded organisational change.

**STAKEHOLDER_GOAL_AND_REQUIREMENT_SEMANTICS —** Collective goals and constraints are allocated without assuming that their conjunction follows from individually successful agents.

**AGENT_ABSTRACTION_JUSTIFICATION —** Organisation is useful when responsibility and coordinated discretion matter; a role model does not demand one process per role.

**ROLE_ORGANISATION_AND_AGENT_MAPPING —** Use a relation B between agents and roles, plus capabilities, multiplicity and incompatibility constraints. Many-to-many binding needs explicit fulfilment semantics.

**INTERACTION_SPECIFICATION_AND_PROTOCOL_SEMANTICS —** Role contracts consume protocols and may create public obligations that outlive a particular assignment.

**DESIGN_TO_IMPLEMENTATION_CORRESPONDENCE —** Bind conceptual permissions and responsibilities to actual resources and behaviours; structural membership does not enforce compliance.

**VERIFICATION_VALIDATION_AND_TEST_ORACLE —** Check both safety and progress under capability, cooperation, fairness and environment assumptions; distinguish static feasibility from continuity.

**TOOL_SUPPORT_AND_MANUAL_OBLIGATIONS —** Model/tool support does not certify capability reports or automatically settle conflicting authority.

**DEPLOYMENT_EVOLUTION_AND_TRACEABILITY —** Reconfiguration must inspect live work and obligations; static cooperative designs remain a legitimate branch where their assumptions hold.

**COMPARATIVE_EVIDENCE_COST_AND_NON_AGENT_ALTERNATIVE —** Dynamic assignment and hierarchy introduce observation and coordination costs. Prefer a flat/static mapping where sufficient; self-organisation is not a default.

### DOMAIN-PROFILE-O4 — Interaction engineering

**METHODOLOGY_AND_LIFECYCLE_SCOPE —** Protocol analysis, local realisation, integration testing and evolution across independent participants.

**STAKEHOLDER_GOAL_AND_REQUIREMENT_SEMANTICS —** An interaction must serve a stakeholder dependency or goal and specify what counts as its consequential completion.

**AGENT_ABSTRACTION_JUSTIFICATION —** Open interaction permits private decision procedures; a global script can be unnecessarily restrictive.

**ROLE_ORGANISATION_AND_AGENT_MAPPING —** Distinguish protocol roles from process instances, public principals and private internal states.

**INTERACTION_SPECIFICATION_AND_PROTOCOL_SEMANTICS —** Specify content interpretation, information availability, correlation, exceptional outcomes and, where appropriate, debtor–creditor commitments.

**DESIGN_TO_IMPLEMENTATION_CORRESPONDENCE —** Check global/local correspondence, adapters and platform bindings under explicit delivery and observation assumptions.

**VERIFICATION_VALIDATION_AND_TEST_ORACLE —** Use permitted/forbidden traces, completion conditions, failure injections and externally grounded effect evidence; schema compliance is only one layer.

**TOOL_SUPPORT_AND_MANUAL_OBLIGATIONS —** AUML, finite-state/Petri-net and information-protocol tools offer different analyses; programmers still realise communications and domain meaning.

**DEPLOYMENT_EVOLUTION_AND_TRACEABILITY —** Version changes and in-flight conversations need compatibility or a deliberately coordinated transition.

**COMPARATIVE_EVIDENCE_COST_AND_NON_AGENT_ALTERNATIVE —** Formal/open protocols pay off when autonomy or heterogeneity warrants them. A direct call or small agreed state machine may be adequate.

### DOMAIN-PROFILE-O5 — Internal design and implementation

**METHODOLOGY_AND_LIFECYCLE_SCOPE —** Agent-internal design, transformation, coding, integration and change-impact analysis.

**STAKEHOLDER_GOAL_AND_REQUIREMENT_SEMANTICS —** Beliefs represent information, desires/goals represent objectives and intentions concern commitments to activity; none is identical to external truth or legitimate stakeholder approval.

**AGENT_ABSTRACTION_JUSTIFICATION —** BDI is one architectural branch; reactive, imperative and conventional implementations remain alternatives.

**ROLE_ORGANISATION_AND_AGENT_MAPPING —** Internal plan/capability structures implement role duties but do not replace collective allocation.

**INTERACTION_SPECIFICATION_AND_PROTOCOL_SEMANTICS —** Message reception, internal events, tool actions and externally visible commitments need explicit correspondence.

**DESIGN_TO_IMPLEMENTATION_CORRESPONDENCE —** Describe what a generator preserves, what programmers complete, and which percept/action bindings remain outside it.

**VERIFICATION_VALIDATION_AND_TEST_ORACLE —** Check contexts, false success, failure handling, concurrency and grounded effects; compilation does not establish achievement.

**TOOL_SUPPORT_AND_MANUAL_OBLIGATIONS —** Language semantics and runtime support must be checked at the actual binding/version; natural-language descriptions still require human interpretation.

**DEPLOYMENT_EVOLUTION_AND_TRACEABILITY —** Manual changes, model changes and remote plan generation can invalidate different parts of the assurance argument.

**COMPARATIVE_EVIDENCE_COST_AND_NON_AGENT_ALTERNATIVE —** Use direct behaviours or handwritten code where modelling/generation cost exceeds benefit; preserve critical correspondence without insisting on every diagram.

### DOMAIN-PROFILE-O6 — Method comparison and composition

**METHODOLOGY_AND_LIFECYCLE_SCOPE —** Method selection, situational assembly, enactment, reuse and retirement across the lifecycle actually needed.

**STAKEHOLDER_GOAL_AND_REQUIREMENT_SEMANTICS —** Do not equate goal, task, role or requirement labels across metamodels without matching their semantics.

**AGENT_ABSTRACTION_JUSTIFICATION —** A methodology is optional machinery for engineering agency, not proof that agency is needed.

**ROLE_ORGANISATION_AND_AGENT_MAPPING —** Method actors are engineers/analysts/testers and consumers of artefacts; these are not automatically runtime agents.

**INTERACTION_SPECIFICATION_AND_PROTOCOL_SEMANTICS —** Fragments communicate through understood work products and decisions; matching file formats or diagram names is insufficient.

**DESIGN_TO_IMPLEMENTATION_CORRESPONDENCE —** Check producer/consumer and transformation obligations between fragments, including what remains manual.

**VERIFICATION_VALIDATION_AND_TEST_ORACLE —** Evaluate executable guidance, internal consistency and actual decision usefulness separately from demonstrated effectiveness.

**TOOL_SUPPORT_AND_MANUAL_OBLIGATIONS —** Account for training, tool support, omitted task definitions and the cost of maintaining additional views.

**DEPLOYMENT_EVOLUTION_AND_TRACEABILITY —** Feedback may revisit any affected view; retain dependency ordering without prescribing a universal waterfall or iteration count.

**COMPARATIVE_EVIDENCE_COST_AND_NON_AGENT_ALTERNATIVE —** A small coherent method can be preferable to maximal lifecycle coverage. Select, substitute, omit or retire according to live consumers and protected obligations.

### DOMAIN-PROFILE-O7 — Verification, validation and test oracles

**METHODOLOGY_AND_LIFECYCLE_SCOPE —** Requirements validation, design analysis, unit/agent/collective testing, formal verification and runtime assurance.

**STAKEHOLDER_GOAL_AND_REQUIREMENT_SEMANTICS —** Distinguish doing the specified thing from specifying an acceptable thing; a goal-completion flag is not the entire acceptance oracle.

**AGENT_ABSTRACTION_JUSTIFICATION —** Autonomy and adaptation enlarge behaviours to examine; formalisation or constrained autonomy may be justified rather than assumed.

**ROLE_ORGANISATION_AND_AGENT_MAPPING —** Agent correctness and collective correctness have different subjects and assumptions.

**INTERACTION_SPECIFICATION_AND_PROTOCOL_SEMANTICS —** Protocol/model checks constrain traces, but private state, asynchronous failure and external effects can remain outside the proof.

**DESIGN_TO_IMPLEMENTATION_CORRESPONDENCE —** Model-checking a decision program narrows one gap; libraries, observation mappings and deployment may remain unverified.

**VERIFICATION_VALIDATION_AND_TEST_ORACLE —** State the guarantee, model, oracle, coverage, environment assumptions and residual uncertainty. Simulation and mutation scores are bounded evidence.

**TOOL_SUPPORT_AND_MANUAL_OBLIGATIONS —** Proof/checking tools require sound encodings and interpretable counterexamples; test engineers still choose meaningful oracles.

**DEPLOYMENT_EVOLUTION_AND_TRACEABILITY —** Monitor invalid assumptions and revalidate impacted claims; neither all-path testing nor continuous observation is automatically feasible.

**COMPARATIVE_EVIDENCE_COST_AND_NON_AGENT_ALTERNATIVE —** Use the cheapest adequate test/analysis for the consequence at issue; high-assurance branches require more evidence, not merely more test cases.

### DOMAIN-PROFILE-O8 — Deployment and evolution

**METHODOLOGY_AND_LIFECYCLE_SCOPE —** Integration, deployment configuration, operation, incident response, controlled change and retirement.

**STAKEHOLDER_GOAL_AND_REQUIREMENT_SEMANTICS —** Keep accepted goals and constraints meaningful after release; operational success cannot silently redefine acceptance.

**AGENT_ABSTRACTION_JUSTIFICATION —** An agent runtime adds coordination and monitoring obligations but does not remove conventional operational engineering.

**ROLE_ORGANISATION_AND_AGENT_MAPPING —** Engineers, operators, affected users and authorised decision makers exchange responsibility without assuming they are identical.

**INTERACTION_SPECIFICATION_AND_PROTOCOL_SEMANTICS —** Observe actual peer versions, active conversations, unfinished work and external-service effects.

**DESIGN_TO_IMPLEMENTATION_CORRESPONDENCE —** Associate deployed code, models, prompts and interfaces with evaluated configurations and consequential design decisions.

**VERIFICATION_VALIDATION_AND_TEST_ORACLE —** Use change-impact evidence, replay/regression where meaningful and targeted new observation; preserve unaffected evidence only with a dependency argument.

**TOOL_SUPPORT_AND_MANUAL_OBLIGATIONS —** Design tools alone may not support operations. Deployment bindings and observation limits need explicit engineering completion.

**DEPLOYMENT_EVOLUTION_AND_TRACEABILITY —** Permitted adaptation has a boundary; changes to goals, policies or acceptance require distinct approval and preservation of live obligations.

**COMPARATIVE_EVIDENCE_COST_AND_NON_AGENT_ALTERNATIVE —** Prefer a coordinated upgrade or planned drain where it avoids permanent adaptation machinery. Cheap continuity is valid; unobserved drift is not.

### DOMAIN-PROFILE-O9 — Adoption and comparative evidence

**METHODOLOGY_AND_LIFECYCLE_SCOPE —** Evaluation of engineering claims, reported applications, method adoption and total cost; not an application runtime model.

**STAKEHOLDER_GOAL_AND_REQUIREMENT_SEMANTICS —** Define the claimed benefit and comparison task before counting adoption or improvement.

**AGENT_ABSTRACTION_JUSTIFICATION —** Agent applications, platforms and full methodologies are different units of analysis.

**ROLE_ORGANISATION_AND_AGENT_MAPPING —** Research participants and reporting organisations matter as study units; no runtime role mapping is required for a bibliographic evidence judgement.

**INTERACTION_SPECIFICATION_AND_PROTOCOL_SEMANTICS —** Identify shared industrial programmes, papers, datasets and evaluators; repeated descriptions are not independent replications.

**DESIGN_TO_IMPLEMENTATION_CORRESPONDENCE —** Attributed benefit must identify the intervention actually used, including tools and conventional process components.

**VERIFICATION_VALIDATION_AND_TEST_ORACLE —** Inspect sample, comparator, outcome measure, uncertainty and validity threats. A case demonstrates possibility, not population frequency.

**TOOL_SUPPORT_AND_MANUAL_OBLIGATIONS —** Costs include training, modelling, execution and maintenance; missing costs remain missing rather than zero.

**DEPLOYMENT_EVOLUTION_AND_TRACEABILITY —** Longitudinal maintenance and operational outcomes are separate from a demonstration or deployment announcement.

**COMPARATIVE_EVIDENCE_COST_AND_NON_AGENT_ALTERNATIVE —** Keep whole-method superiority unresolved without suitable comparative evidence; absence of strong comparison does not erase narrower useful mechanisms.

### DOMAIN-PROFILE-O10 — Modern translations and learned components

**METHODOLOGY_AND_LIFECYCLE_SCOPE —** Engineering of learned, tool-using and hybrid agents, including evaluation, security, deployment and regression.

**STAKEHOLDER_GOAL_AND_REQUIREMENT_SEMANTICS —** Generated goals/plans are proposals, not automatic stakeholder requirements; an evaluation score is a chosen oracle.

**AGENT_ABSTRACTION_JUSTIFICATION —** Classical agency and current LLM use overlap but neither implies documented historical inheritance from the other.

**ROLE_ORGANISATION_AND_AGENT_MAPPING —** Role prompts are behavioural inputs, not automatically enforceable obligations; human owners and affected parties remain external participants.

**INTERACTION_SPECIFICATION_AND_PROTOCOL_SEMANTICS —** Tool outputs, memory and peer text may be untrusted; explicit interface meaning and authority must survive language generation.

**DESIGN_TO_IMPLEMENTATION_CORRESPONDENCE —** Parsers, guardrails and generators establish different guarantees; admit only executable capabilities whose effects can be checked.

**VERIFICATION_VALIDATION_AND_TEST_ORACLE —** Evaluate stochastic runs, configurations, costs, failures and grounded outcomes. Trace judges and model-based graders are fallible measurement instruments.

**TOOL_SUPPORT_AND_MANUAL_OBLIGATIONS —** Inspect documented integrations such as Jason/JaCaMo or AgentSpeak-based generation, without claiming every framework inherits AOSE.

**DEPLOYMENT_EVOLUTION_AND_TRACEABILITY —** Model/provider/prompt/tool changes can trigger regression. Slow generation needs cancellation/resumption and stale-state handling when concurrent duties matter.

**COMPARATIVE_EVIDENCE_COST_AND_NON_AGENT_ALTERNATIVE —** Compare with fixed workflows, prewritten plans and non-agent baselines; small prototypes and coding benchmarks do not establish broad lifecycle superiority.

### DOMAIN-PROFILE-COMPOSITION — Coupled engineering decisions

**METHODOLOGY_AND_LIFECYCLE_SCOPE —** Within-tradition analytical synthesis across requirements, authority, enactment, evidence and change; not a newly discovered academic methodology.

**STAKEHOLDER_GOAL_AND_REQUIREMENT_SEMANTICS —** A criterion must remain tied to the affected stakeholder need when used to accept an action or outcome.

**AGENT_ABSTRACTION_JUSTIFICATION —** The minimal configuration may use conventional software; composition does not require increasing autonomy.

**ROLE_ORGANISATION_AND_AGENT_MAPPING —** Authority to decide, capability to act and responsibility for live obligations remain distinct across role holders.

**INTERACTION_SPECIFICATION_AND_PROTOCOL_SEMANTICS —** Communicate disputed criteria, permitted actions, observed effects and outstanding obligations to the decision they can change.

**DESIGN_TO_IMPLEMENTATION_CORRESPONDENCE —** Join consequential mappings across views rather than inferring correctness from each view independently.

**VERIFICATION_VALIDATION_AND_TEST_ORACLE —** Test counterexamples in which individually plausible views jointly permit a wrong decision. Analytical tests do not constitute empirical validation.

**TOOL_SUPPORT_AND_MANUAL_OBLIGATIONS —** Reuse existing records and checks; do not create a new control for every named synthesis relation.

**DEPLOYMENT_EVOLUTION_AND_TRACEABILITY —** Reconfiguration and evidence change are evaluated against predecessor obligations; method machinery can be retired without deleting its protected function.

**COMPARATIVE_EVIDENCE_COST_AND_NON_AGENT_ALTERNATIVE —** Only two distinct composition-induced candidates are retained here; duplicate feedback/change/retirement labels remain counted but not extra obligations.

## Conditional crosswalk questions

The mature form and its trigger are hypotheses to test against evidence. The minimal alternative may already be supplied by ordinary engineering practice. Source IDs establish the external research basis; they do not answer the target question.

### EAOSE-001 — Affected-actor discovery and validation

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-001

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Identify beneficiaries, dependants, resource holders and adversely affected actors; have their actual concerns challenge the chosen system boundary rather than treating a complete drawing as a census.

**Controlled failure —** Actor modelling provides a vocabulary, not an algorithm guaranteeing discovery; the analyst can exclude inconvenient participants.

**Trigger —** The system redistributes work, information, discretion or consequences among people or organisations.

**Non-trigger / cheap path —** A small stakeholder discussion and explicit exclusions can suffice; do not draw a full organisational model for a self-contained utility.

**Prerequisites —** property inputs: None, subject to the stated absence explanation.. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. Actor modelling provides a vocabulary, not an algorithm guaranteeing discovery; the analyst can exclude inconvenient participants.. absence reason: This is a boundary/selection inquiry or independently posed candidate; it has no mandatory earlier property in this corpus..

**Domain profile —** DOMAIN-PROFILE-O1 above; candidate application: Affected-actor discovery and validation. Relevant actor concerns and disputed exclusions are recorded and can change requirements.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Relevant actor concerns and disputed exclusions are recorded and can change requirements. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Requirements analyst with affected actors and the legitimate requirements decision maker. boundary: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them..

**Communication / operation —** content: Identify beneficiaries, dependants, resource holders and adversely affected actors; have their actual concerns challenge the chosen system boundary rather than treating a complete drawing as a census.. consumer: Requirements analyst with affected actors and the legitimate requirements decision maker. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-01. local analytical objection: Actor modelling provides a vocabulary, not an algorithm guaranteeing discovery; the analyst can exclude inconvenient participants.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Relevant actor concerns and disputed exclusions are recorded and can change requirements.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A small stakeholder discussion and explicit exclusions can suffice; do not draw a full organisational model for a self-contained utility.. ledger id: CS-001.

**Conflicts / alternatives —** tension ids: T-01. relation ids: REL-031. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: None, subject to the stated absence explanation.. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-01. analytical limit: Actor modelling provides a vocabulary, not an algorithm guaranteeing discovery; the analyst can exclude inconvenient participants... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Relevant actor concerns and disputed exclusions are recorded and can change requirements. — from the failure boundary — Actor modelling provides a vocabulary, not an algorithm guaranteeing discovery; the analyst can exclude inconvenient participants.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S004; AOSE-S010; AOSE-S038; AOSE-S059; AOSE-S060]

### EAOSE-002 — Separate stakeholder goals, runtime goals and acceptance conditions

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-002

**Disposition —** STRONGLY_RETAINED

**Mature form —** Relate but do not identify a desired stakeholder outcome, an agent goal representation and the observation used to judge achievement; expose the translation and its counterexamples.

**Controlled failure —** A test can faithfully encode the wrong need; acceptance judgements may remain partly human.

**Trigger —** A goal is decomposed, delegated or made executable.

**Non-trigger / cheap path —** One requirement with a direct test is enough where the mapping is trivial.

**Prerequisites —** property inputs: EAOSE-001. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. A test can faithfully encode the wrong need; acceptance judgements may remain partly human..

**Domain profile —** DOMAIN-PROFILE-O1 above; candidate application: Separate stakeholder goals, runtime goals and acceptance conditions. A runtime success flag alone cannot discharge an unobserved external outcome.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: A runtime success flag alone cannot discharge an unobserved external outcome. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Requirements analyst with affected actors and the legitimate requirements decision maker. boundary: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them..

**Communication / operation —** content: Relate but do not identify a desired stakeholder outcome, an agent goal representation and the observation used to judge achievement; expose the translation and its counterexamples.. consumer: Requirements analyst with affected actors and the legitimate requirements decision maker. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-01. local analytical objection: A test can faithfully encode the wrong need; acceptance judgements may remain partly human.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: A runtime success flag alone cannot discharge an unobserved external outcome.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: One requirement with a direct test is enough where the mapping is trivial.. ledger id: CS-002.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-031. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: strong distinction or conditional argument. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-07. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-01. analytical limit: A test can faithfully encode the wrong need; acceptance judgements may remain partly human... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — A runtime success flag alone cannot discharge an unobserved external outcome. — from the failure boundary — A test can faithfully encode the wrong need; acceptance judgements may remain partly human.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S004; AOSE-S012; AOSE-S031; AOSE-S059; AOSE-S060]

### EAOSE-003 — Dependency and delegation vulnerability analysis

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-003

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Specify who relies on whom for a goal, task, resource or quality; examine willingness, ability, alternatives and consequences of non-delivery before relying on delegation.

**Controlled failure —** A dependency edge neither obtains consent nor supplies capacity; adding dependencies can centralise hidden risk.

**Trigger —** A requirement depends on another actor outside the requester’s immediate control.

**Non-trigger / cheap path —** Use a direct agreement or ordinary interface contract for one stable dependency.

**Prerequisites —** property inputs: EAOSE-001; EAOSE-002. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. A dependency edge neither obtains consent nor supplies capacity; adding dependencies can centralise hidden risk..

**Domain profile —** DOMAIN-PROFILE-O1 above; candidate application: Dependency and delegation vulnerability analysis. Critical dependencies have an accepted reliance basis or an explicit unresolved exposure.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Critical dependencies have an accepted reliance basis or an explicit unresolved exposure. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Requirements analyst with affected actors and the legitimate requirements decision maker. boundary: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them..

**Communication / operation —** content: Specify who relies on whom for a goal, task, resource or quality; examine willingness, ability, alternatives and consequences of non-delivery before relying on delegation.. consumer: Requirements analyst with affected actors and the legitimate requirements decision maker. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-01. local analytical objection: A dependency edge neither obtains consent nor supplies capacity; adding dependencies can centralise hidden risk.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Critical dependencies have an accepted reliance basis or an explicit unresolved exposure.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Use a direct agreement or ordinary interface contract for one stable dependency.. ledger id: CS-003.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: None, subject to the stated absence explanation.. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-01. analytical limit: A dependency edge neither obtains consent nor supplies capacity; adding dependencies can centralise hidden risk... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Critical dependencies have an accepted reliance basis or an explicit unresolved exposure. — from the failure boundary — A dependency edge neither obtains consent nor supplies capacity; adding dependencies can centralise hidden risk.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S010; AOSE-S004; AOSE-S038; AOSE-S059; AOSE-S060]

### EAOSE-004 — Explicit goal conflict and alternative rationale

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-004

**Disposition —** USEFUL_BUT_EASILY_GAMED

**Mature form —** Compare alternative means against conflicting goals and qualities, preserve who judges trade-offs, and distinguish qualitative contribution from measured satisfaction.

**Controlled failure —** Qualitative labels and weights can rationalise a predetermined choice; graph arithmetic does not establish stakeholder preference.

**Trigger —** Different stakeholders or feasible designs favour incompatible outcomes.

**Non-trigger / cheap path —** Document the concrete choice and decisive evidence without elaborate softgoal scoring when it is clear.

**Prerequisites —** property inputs: EAOSE-001; EAOSE-002. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. Qualitative labels and weights can rationalise a predetermined choice; graph arithmetic does not establish stakeholder preference..

**Domain profile —** DOMAIN-PROFILE-O1 above; candidate application: Explicit goal conflict and alternative rationale. The chosen alternative has a revisitable rationale and unresolved conflicts are visible.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: The chosen alternative has a revisitable rationale and unresolved conflicts are visible. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Requirements analyst with affected actors and the legitimate requirements decision maker. boundary: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them..

**Communication / operation —** content: Compare alternative means against conflicting goals and qualities, preserve who judges trade-offs, and distinguish qualitative contribution from measured satisfaction.. consumer: Requirements analyst with affected actors and the legitimate requirements decision maker. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-01. local analytical objection: Qualitative labels and weights can rationalise a predetermined choice; graph arithmetic does not establish stakeholder preference.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: The chosen alternative has a revisitable rationale and unresolved conflicts are visible.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Document the concrete choice and decisive evidence without elaborate softgoal scoring when it is clear.. ledger id: CS-004.

**Conflicts / alternatives —** tension ids: T-01. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: None, subject to the stated absence explanation.. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-01. analytical limit: Qualitative labels and weights can rationalise a predetermined choice; graph arithmetic does not establish stakeholder preference... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — The chosen alternative has a revisitable rationale and unresolved conflicts are visible. — from the failure boundary — Qualitative labels and weights can rationalise a predetermined choice; graph arithmetic does not establish stakeholder preference.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S004; AOSE-S010; AOSE-S034; AOSE-S060]

### EAOSE-005 — Security constraints and delegation authority

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-005

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Carry security constraints from stakeholder concerns to roles, plans and interactions; distinguish permission, trust and actual capability, and test disallowed actions as well as permitted ones.

**Controlled failure —** Security-goal models need enforcement and threat assumptions; declared trust is not evidence of trustworthy behaviour.

**Trigger —** An agent receives privileged data, delegated resources or power to affect another actor.

**Non-trigger / cheap path —** Use an existing narrow access-control boundary with an explicit caller contract when sufficient.

**Prerequisites —** property inputs: EAOSE-001; EAOSE-003. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. Security-goal models need enforcement and threat assumptions; declared trust is not evidence of trustworthy behaviour..

**Domain profile —** DOMAIN-PROFILE-O1 above; candidate application: Security constraints and delegation authority. An intended action is not admitted solely because it advances a goal or appears in a plan.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: An intended action is not admitted solely because it advances a goal or appears in a plan. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Requirements analyst with affected actors and the legitimate requirements decision maker. boundary: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them..

**Communication / operation —** content: Carry security constraints from stakeholder concerns to roles, plans and interactions; distinguish permission, trust and actual capability, and test disallowed actions as well as permitted ones.. consumer: Requirements analyst with affected actors and the legitimate requirements decision maker. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-01; CR-14. local analytical objection: Security-goal models need enforcement and threat assumptions; declared trust is not evidence of trustworthy behaviour.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: An intended action is not admitted solely because it advances a goal or appears in a plan.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Use an existing narrow access-control boundary with an explicit caller contract when sufficient.. ledger id: CS-005.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-002. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: None, subject to the stated absence explanation.. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-01; CR-14. analytical limit: Security-goal models need enforcement and threat assumptions; declared trust is not evidence of trustworthy behaviour... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — An intended action is not admitted solely because it advances a goal or appears in a plan. — from the failure boundary — Security-goal models need enforcement and threat assumptions; declared trust is not evidence of trustworthy behaviour.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S038; AOSE-S021; AOSE-S043]

### EAOSE-006 — Revalidate goals when operating assumptions change

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-006

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Use changed context, conflict or failed outcome evidence to reopen the affected goal, constraint and acceptance mapping rather than merely adjusting code until an old test passes.

**Controlled failure —** Continuous reopening can prevent delivery; a changed goal still requires legitimate acceptance rather than unilateral runtime preference.

**Trigger —** Stakeholders, environmental conditions or the meaning of success materially change.

**Non-trigger / cheap path —** No new requirements exercise for a change shown not to affect meaning or consequences.

**Prerequisites —** property inputs: EAOSE-002; EAOSE-003. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. Continuous reopening can prevent delivery; a changed goal still requires legitimate acceptance rather than unilateral runtime preference..

**Domain profile —** DOMAIN-PROFILE-O1 above; candidate application: Revalidate goals when operating assumptions change. Affected requirements receive an explicit retained, revised or withdrawn judgement.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Affected requirements receive an explicit retained, revised or withdrawn judgement. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Requirements analyst with affected actors and the legitimate requirements decision maker. boundary: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them..

**Communication / operation —** content: Use changed context, conflict or failed outcome evidence to reopen the affected goal, constraint and acceptance mapping rather than merely adjusting code until an old test passes.. consumer: Requirements analyst with affected actors and the legitimate requirements decision maker. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-01. local analytical objection: Continuous reopening can prevent delivery; a changed goal still requires legitimate acceptance rather than unilateral runtime preference.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Affected requirements receive an explicit retained, revised or withdrawn judgement.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: No new requirements exercise for a change shown not to affect meaning or consequences.. ledger id: CS-006.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-07; EV-12. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-01. analytical limit: Continuous reopening can prevent delivery; a changed goal still requires legitimate acceptance rather than unilateral runtime preference... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Affected requirements receive an explicit retained, revised or withdrawn judgement. — from the failure boundary — Continuous reopening can prevent delivery; a changed goal still requires legitimate acceptance rather than unilateral runtime preference.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S004; AOSE-S029; AOSE-S031; AOSE-S057; AOSE-S059]

### EAOSE-008 — Justify the semantic fit of agency

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-008

**Disposition —** STRONGLY_RETAINED

**Mature form —** Select agent abstractions when delegated control, situated choice, interaction or organisation clarifies consequential decisions; compare the actual design with objects, services, actors, workflows or a controller.

**Controlled failure —** Autonomy and distribution can also be engineered with conventional constructs; fit is not a universal productivity theorem.

**Trigger —** The engineer is choosing the modelling or execution paradigm.

**Non-trigger / cheap path —** Retain a conventional design where it meets the same requirements with less complexity.

**Prerequisites —** property inputs: None, subject to the stated absence explanation.. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win. Autonomy and distribution can also be engineered with conventional constructs; fit is not a universal productivity theorem.. absence reason: This is a boundary/selection inquiry or independently posed candidate; it has no mandatory earlier property in this corpus..

**Domain profile —** DOMAIN-PROFILE-O2 above; candidate application: Justify the semantic fit of agency. The rationale identifies a semantic benefit and costs rather than a fashionable component label.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: The rationale identifies a semantic benefit and costs rather than a fashionable component label. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Architect and responsible engineering/product decision makers. boundary: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win..

**Communication / operation —** content: Select agent abstractions when delegated control, situated choice, interaction or organisation clarifies consequential decisions; compare the actual design with objects, services, actors, workflows or a controller.. consumer: Architect and responsible engineering/product decision makers. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-02; CR-17. local analytical objection: Autonomy and distribution can also be engineered with conventional constructs; fit is not a universal productivity theorem.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: The rationale identifies a semantic benefit and costs rather than a fashionable component label.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Retain a conventional design where it meets the same requirements with less complexity.. ledger id: CS-008.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-005; REL-030. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: strong distinction or conditional argument. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-14; EV-15. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-02; CR-17. analytical limit: Autonomy and distribution can also be engineered with conventional constructs; fit is not a universal productivity theorem... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — The rationale identifies a semantic benefit and costs rather than a fashionable component label. — from the failure boundary — Autonomy and distribution can also be engineered with conventional constructs; fit is not a universal productivity theorem.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S033; AOSE-S013; AOSE-S055; AOSE-S047; AOSE-S060; AOSE-S061]

### EAOSE-009 — Decouple agent-oriented analysis from runtime commitment

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-009

**Disposition —** CONTEXT_DEPENDENT

**Mature form —** Preserve useful actor, goal and responsibility analysis while allowing its realisation in non-agent software; separately justify an agent runtime or a full branded methodology.

**Controlled failure —** Translation can erase intentional or organisational semantics; the implementation must still satisfy the selected requirements.

**Trigger —** Organisational analysis is valuable but runtime autonomy is unnecessary or existing infrastructure dominates.

**Non-trigger / cheap path —** Use a conventional implementation and retain only decision-relevant analysis.

**Prerequisites —** property inputs: EAOSE-002; EAOSE-008. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win. Translation can erase intentional or organisational semantics; the implementation must still satisfy the selected requirements..

**Domain profile —** DOMAIN-PROFILE-O2 above; candidate application: Decouple agent-oriented analysis from runtime commitment. No framework or complete method is required merely because an actor-goal model was useful.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: No framework or complete method is required merely because an actor-goal model was useful. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Architect and responsible engineering/product decision makers. boundary: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win..

**Communication / operation —** content: Preserve useful actor, goal and responsibility analysis while allowing its realisation in non-agent software; separately justify an agent runtime or a full branded methodology.. consumer: Architect and responsible engineering/product decision makers. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-02. local analytical objection: Translation can erase intentional or organisational semantics; the implementation must still satisfy the selected requirements.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: No framework or complete method is required merely because an actor-goal model was useful.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Use a conventional implementation and retain only decision-relevant analysis.. ledger id: CS-009.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-005; REL-030. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: None, subject to the stated absence explanation.. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-02. analytical limit: Translation can erase intentional or organisational semantics; the implementation must still satisfy the selected requirements... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — No framework or complete method is required merely because an actor-goal model was useful. — from the failure boundary — Translation can erase intentional or organisational semantics; the implementation must still satisfy the selected requirements.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S004; AOSE-S041; AOSE-S017; AOSE-S059; AOSE-S060]

### EAOSE-010 — Bound delegated autonomy by capabilities and constraints

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-010

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Define the choices a component may make, the capabilities it actually has and conditions requiring external decision; leave implementation choice open inside that envelope.

**Controlled failure —** An envelope expressed only in prose may not constrain execution; overly narrow bounds eliminate the useful adaptation.

**Trigger —** Behaviour is selected at runtime rather than completely prescribed by a caller.

**Non-trigger / cheap path —** A deterministic function or explicit approval can replace autonomous selection when variability adds no value.

**Prerequisites —** property inputs: EAOSE-005; EAOSE-008. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win. An envelope expressed only in prose may not constrain execution; overly narrow bounds eliminate the useful adaptation..

**Domain profile —** DOMAIN-PROFILE-O2 above; candidate application: Bound delegated autonomy by capabilities and constraints. Runtime choice cannot silently expand the authority or resources originally delegated.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Runtime choice cannot silently expand the authority or resources originally delegated. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Architect and responsible engineering/product decision makers. boundary: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win..

**Communication / operation —** content: Define the choices a component may make, the capabilities it actually has and conditions requiring external decision; leave implementation choice open inside that envelope.. consumer: Architect and responsible engineering/product decision makers. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-02; CR-14. local analytical objection: An envelope expressed only in prose may not constrain execution; overly narrow bounds eliminate the useful adaptation.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Runtime choice cannot silently expand the authority or resources originally delegated.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A deterministic function or explicit approval can replace autonomous selection when variability adds no value.. ledger id: CS-010.

**Conflicts / alternatives —** tension ids: T-02. relation ids: REL-002. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: None, subject to the stated absence explanation.. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-02; CR-14. analytical limit: An envelope expressed only in prose may not constrain execution; overly narrow bounds eliminate the useful adaptation... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Runtime choice cannot silently expand the authority or resources originally delegated. — from the failure boundary — An envelope expressed only in prose may not constrain execution; overly narrow bounds eliminate the useful adaptation.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S012; AOSE-S005; AOSE-S038; AOSE-S016]

### EAOSE-011 — Lifecycle cost and non-agent comparator

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-011

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Compare end-to-end task quality, engineering effort, training, operations and change cost under comparable requirements, including a simpler non-agent solution where plausible.

**Controlled failure —** Historical baselines, bundled tools and expert teams confound attribution; a benchmark winner is not a lifecycle winner.

**Trigger —** A deployment or methodology choice is justified by claimed benefit.

**Non-trigger / cheap path —** For a reversible small choice, a short measured spike or reasoned cost screen is adequate.

**Prerequisites —** property inputs: EAOSE-008. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win. Historical baselines, bundled tools and expert teams confound attribution; a benchmark winner is not a lifecycle winner..

**Domain profile —** DOMAIN-PROFILE-O2 above; candidate application: Lifecycle cost and non-agent comparator. The decision distinguishes architectural capability from evidenced incremental benefit.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: The decision distinguishes architectural capability from evidenced incremental benefit. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Architect and responsible engineering/product decision makers. boundary: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win..

**Communication / operation —** content: Compare end-to-end task quality, engineering effort, training, operations and change cost under comparable requirements, including a simpler non-agent solution where plausible.. consumer: Architect and responsible engineering/product decision makers. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-02; CR-10; CR-17. local analytical objection: Historical baselines, bundled tools and expert teams confound attribution; a benchmark winner is not a lifecycle winner.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: The decision distinguishes architectural capability from evidenced incremental benefit.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: For a reversible small choice, a short measured spike or reasoned cost screen is adequate.. ledger id: CS-011.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-005; REL-030. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-01; EV-03; EV-04; EV-14; EV-15. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: reported and context-bound, not causal attribution. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-02; CR-10; CR-17. analytical limit: Historical baselines, bundled tools and expert teams confound attribution; a benchmark winner is not a lifecycle winner... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — The decision distinguishes architectural capability from evidenced incremental benefit. — from the failure boundary — Historical baselines, bundled tools and expert teams confound attribution; a benchmark winner is not a lifecycle winner.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S047; AOSE-S048; AOSE-S061]

### EAOSE-013 — Role contracts separate responsibilities, permissions and activities

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-013

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Specify what a role must preserve or achieve, what resources it may use, what it does internally and which interactions it participates in; keep these distinct from an implementation identity.

**Controlled failure —** Gaia permissions primarily concern resources; they must not be inflated into all forms of real-world authorisation.

**Trigger —** Several participants must coordinate around differentiated responsibilities.

**Non-trigger / cheap path —** A compact responsibility/interface table is sufficient for a small stable arrangement.

**Prerequisites —** property inputs: EAOSE-002; EAOSE-005. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. Gaia permissions primarily concern resources; they must not be inflated into all forms of real-world authorisation..

**Domain profile —** DOMAIN-PROFILE-O3 above; candidate application: Role contracts separate responsibilities, permissions and activities. Every consequential role has interpretable obligations and access boundaries.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Every consequential role has interpretable obligations and access boundaries. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Organisation designer; operators or delegated organisational controller for permitted runtime changes. boundary: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity..

**Communication / operation —** content: Specify what a role must preserve or achieve, what resources it may use, what it does internally and which interactions it participates in; keep these distinct from an implementation identity.. consumer: Organisation designer; operators or delegated organisational controller for permitted runtime changes. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-03. local analytical objection: Gaia permissions primarily concern resources; they must not be inflated into all forms of real-world authorisation.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Every consequential role has interpretable obligations and access boundaries.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A compact responsibility/interface table is sufficient for a small stable arrangement.. ledger id: CS-013.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-002; REL-006. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: None, subject to the stated absence explanation.. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-03. analytical limit: Gaia permissions primarily concern resources; they must not be inflated into all forms of real-world authorisation... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Every consequential role has interpretable obligations and access boundaries. — from the failure boundary — Gaia permissions primarily concern resources; they must not be inflated into all forms of real-world authorisation.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S001; AOSE-S015; AOSE-S039]

### EAOSE-014 — Separate safety from progress obligations

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-014

**Disposition —** STRONGLY_RETAINED

**Mature form —** Distinguish forbidden states or effects from required progress, including the assumptions and deadlines under which progress is expected.

**Controlled failure —** Liveness under fairness is not a real-time response guarantee; safety can depend on environmental abstraction.

**Trigger —** Correctness includes both avoiding harm and eventually doing useful work.

**Non-trigger / cheap path —** A direct invariant plus bounded completion test may suffice without temporal logic.

**Prerequisites —** property inputs: EAOSE-002; EAOSE-013. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. Liveness under fairness is not a real-time response guarantee; safety can depend on environmental abstraction..

**Domain profile —** DOMAIN-PROFILE-O3 above; candidate application: Separate safety from progress obligations. A system that does nothing safely is not misclassified as meeting its progress requirement.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: A system that does nothing safely is not misclassified as meeting its progress requirement. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Organisation designer; operators or delegated organisational controller for permitted runtime changes. boundary: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity..

**Communication / operation —** content: Distinguish forbidden states or effects from required progress, including the assumptions and deadlines under which progress is expected.. consumer: Organisation designer; operators or delegated organisational controller for permitted runtime changes. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-03. local analytical objection: Liveness under fairness is not a real-time response guarantee; safety can depend on environmental abstraction.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: A system that does nothing safely is not misclassified as meeting its progress requirement.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A direct invariant plus bounded completion test may suffice without temporal logic.. ledger id: CS-014.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-006. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: strong distinction or conditional argument. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: EV-13. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-03. analytical limit: Liveness under fairness is not a real-time response guarantee; safety can depend on environmental abstraction... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — A system that does nothing safely is not misclassified as meeting its progress requirement. — from the failure boundary — Liveness under fairness is not a real-time response guarantee; safety can depend on environmental abstraction.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S001; AOSE-S023; AOSE-S037]

### EAOSE-015 — Explicit many-to-many role-to-agent binding

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-015

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Record how role responsibilities are fulfilled by concrete agents, including multiplicity, shared work and incompatible assignments; test collective coverage rather than assuming one role equals one process.

**Controlled failure —** Multiplicity of role holders is not itself a design for collective fulfilment. Original Gaia explicitly leaves the collective-realisation case unelaborated; replication can duplicate action or induce mutual waiting.

**Trigger —** Roles are shared, combined, replicated or reassigned.

**Non-trigger / cheap path —** One documented binding is enough for a fixed single-provider role.

**Prerequisites —** property inputs: EAOSE-013; EAOSE-014. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. Multiplicity of role holders is not itself a design for collective fulfilment. Original Gaia explicitly leaves the collective-realisation case unelaborated; replication can duplicate action or induce mutual waiting..

**Domain profile —** DOMAIN-PROFILE-O3 above; candidate application: Explicit many-to-many role-to-agent binding. Each required obligation has a viable assignment without accidental gaps or conflicting execution.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Each required obligation has a viable assignment without accidental gaps or conflicting execution. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Organisation designer; operators or delegated organisational controller for permitted runtime changes. boundary: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity..

**Communication / operation —** content: Record how role responsibilities are fulfilled by concrete agents, including multiplicity, shared work and incompatible assignments; test collective coverage rather than assuming one role equals one process.. consumer: Organisation designer; operators or delegated organisational controller for permitted runtime changes. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-03. local analytical objection: Multiplicity of role holders is not itself a design for collective fulfilment. Original Gaia explicitly leaves the collective-realisation case unelaborated; replication can duplicate action or induce mutual waiting.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Each required obligation has a viable assignment without accidental gaps or conflicting execution.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: One documented binding is enough for a fixed single-provider role.. ledger id: CS-015.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-006. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: None, subject to the stated absence explanation.. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-03. analytical limit: Multiplicity of role holders is not itself a design for collective fulfilment. Original Gaia explicitly leaves the collective-realisation case unelaborated; replication can duplicate action or induce mutual waiting... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Each required obligation has a viable assignment without accidental gaps or conflicting execution. — from the failure boundary — Multiplicity of role holders is not itself a design for collective fulfilment. Original Gaia explicitly leaves the collective-realisation case unelaborated; replication can duplicate action or induce mutual waiting.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S001; AOSE-S015; AOSE-S016; AOSE-S009]

### EAOSE-016 — Organisation-level rules supplement local role contracts

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-016

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Represent constraints on collective structure, coordination and responsibility that cannot be inferred from isolated role descriptions; check them when roles are instantiated.

**Controlled failure —** Organisational rules may be descriptive rather than enforced; a single institutional agent can create a bottleneck.

**Trigger —** Local correctness permits an invalid collective organisation.

**Non-trigger / cheap path —** An ordinary shared invariant or configuration rule can replace a separate organisation model.

**Prerequisites —** property inputs: EAOSE-013; EAOSE-015. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. Organisational rules may be descriptive rather than enforced; a single institutional agent can create a bottleneck..

**Domain profile —** DOMAIN-PROFILE-O3 above; candidate application: Organisation-level rules supplement local role contracts. A locally permitted assignment can be refused when it violates a collective constraint.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: A locally permitted assignment can be refused when it violates a collective constraint. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Organisation designer; operators or delegated organisational controller for permitted runtime changes. boundary: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity..

**Communication / operation —** content: Represent constraints on collective structure, coordination and responsibility that cannot be inferred from isolated role descriptions; check them when roles are instantiated.. consumer: Organisation designer; operators or delegated organisational controller for permitted runtime changes. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-03. local analytical objection: Organisational rules may be descriptive rather than enforced; a single institutional agent can create a bottleneck.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: A locally permitted assignment can be refused when it violates a collective constraint.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: An ordinary shared invariant or configuration rule can replace a separate organisation model.. ledger id: CS-016.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-006. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: moderate with a bounded access limitation. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: None, subject to the stated absence explanation.. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-03. analytical limit: Organisational rules may be descriptive rather than enforced; a single institutional agent can create a bottleneck... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — A locally permitted assignment can be refused when it violates a collective constraint. — from the failure boundary — Organisational rules may be descriptive rather than enforced; a single institutional agent can create a bottleneck.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S014; AOSE-S016; AOSE-S009; AOSE-S044]

### EAOSE-017 — Capability-based dynamic reassignment

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-017

**Disposition —** ASSUMPTION_SENSITIVE

**Mature form —** Separate roles from the changing capability inventory and use an explicit assignment relation to reconfigure participants while retaining the required organisational function.

**Controlled failure —** Capabilities may be misreported or stale; feasible local reassignment need not preserve outstanding interactions.

**Trigger —** Membership, capabilities or failure conditions change during operation.

**Non-trigger / cheap path —** Static assignment or operator-controlled reassignment when the organisation is stable.

**Prerequisites —** property inputs: EAOSE-010; EAOSE-015; EAOSE-016. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. Capabilities may be misreported or stale; feasible local reassignment need not preserve outstanding interactions..

**Domain profile —** DOMAIN-PROFILE-O3 above; candidate application: Capability-based dynamic reassignment. A reassigned role has capability evidence and satisfies the current structural constraints.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: A reassigned role has capability evidence and satisfies the current structural constraints. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Organisation designer; operators or delegated organisational controller for permitted runtime changes. boundary: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity..

**Communication / operation —** content: Separate roles from the changing capability inventory and use an explicit assignment relation to reconfigure participants while retaining the required organisational function.. consumer: Organisation designer; operators or delegated organisational controller for permitted runtime changes. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-03. local analytical objection: Capabilities may be misreported or stale; feasible local reassignment need not preserve outstanding interactions.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: A reassigned role has capability evidence and satisfies the current structural constraints.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Static assignment or operator-controlled reassignment when the organisation is stable.. ledger id: CS-017.

**Conflicts / alternatives —** tension ids: T-06. relation ids: REL-008; REL-026; REL-223. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: None, subject to the stated absence explanation.. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-03. analytical limit: Capabilities may be misreported or stale; feasible local reassignment need not preserve outstanding interactions... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — A reassigned role has capability evidence and satisfies the current structural constraints. — from the failure boundary — Capabilities may be misreported or stale; feasible local reassignment need not preserve outstanding interactions.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S016; AOSE-S009]

### EAOSE-018 — Environment and shared resources as engineered objects

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-018

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Model the resources, artefacts, percepts and actions through which agents affect their environment; assign implementation and assurance duties at those boundaries.

**Controlled failure —** An environment model can omit dynamics or hide authority; shared artefacts can introduce contention.

**Trigger —** Important effects pass through shared resources, sensors or external services.

**Non-trigger / cheap path —** A tested ordinary API with explicit preconditions and effects is adequate.

**Prerequisites —** property inputs: EAOSE-005; EAOSE-010. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. An environment model can omit dynamics or hide authority; shared artefacts can introduce contention..

**Domain profile —** DOMAIN-PROFILE-O3 above; candidate application: Environment and shared resources as engineered objects. Reasoning correctness is not used to excuse an untested sensor, resource or actuator boundary.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Reasoning correctness is not used to excuse an untested sensor, resource or actuator boundary. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Organisation designer; operators or delegated organisational controller for permitted runtime changes. boundary: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity..

**Communication / operation —** content: Model the resources, artefacts, percepts and actions through which agents affect their environment; assign implementation and assurance duties at those boundaries.. consumer: Organisation designer; operators or delegated organisational controller for permitted runtime changes. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-14. local analytical objection: An environment model can omit dynamics or hide authority; shared artefacts can introduce contention.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Reasoning correctness is not used to excuse an untested sensor, resource or actuator boundary.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A tested ordinary API with explicit preconditions and effects is adequate.. ledger id: CS-018.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-002. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: EV-13. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-14. analytical limit: An environment model can omit dynamics or hide authority; shared artefacts can introduce contention... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Reasoning correctness is not used to excuse an untested sensor, resource or actuator boundary. — from the failure boundary — An environment model can omit dynamics or hide authority; shared artefacts can introduce contention.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S007; AOSE-S018; AOSE-S030; AOSE-S044]

### EAOSE-020 — Interaction specifications with explicit meaning and enactment

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-020

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** State participants, messages, information dependencies and social effects separately from optional presentation order; identify what counts as permitted interaction and completion.

**Controlled failure —** Sequence diagrams can overconstrain autonomous choices or leave exceptional paths unspecified.

**Trigger —** Independently implemented components must coordinate.

**Non-trigger / cheap path —** A simple request/response contract with failure cases may suffice.

**Prerequisites —** property inputs: EAOSE-003; EAOSE-013. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Sequence diagrams can overconstrain autonomous choices or leave exceptional paths unspecified..

**Domain profile —** DOMAIN-PROFILE-O4 above; candidate application: Interaction specifications with explicit meaning and enactment. Both implementers can explain the same observed interaction and its obligations.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Both implementers can explain the same observed interaction and its obligations. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Protocol designers, implementers and the principals participating in an interaction. boundary: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning..

**Communication / operation —** content: State participants, messages, information dependencies and social effects separately from optional presentation order; identify what counts as permitted interaction and completion.. consumer: Protocol designers, implementers and the principals participating in an interaction. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-04. local analytical objection: Sequence diagrams can overconstrain autonomous choices or leave exceptional paths unspecified.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Both implementers can explain the same observed interaction and its obligations.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A simple request/response contract with failure cases may suffice.. ledger id: CS-020.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: FR-06.. empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: EV-13. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-04. analytical limit: Sequence diagrams can overconstrain autonomous choices or leave exceptional paths unspecified... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Both implementers can explain the same observed interaction and its obligations. — from the failure boundary — Sequence diagrams can overconstrain autonomous choices or leave exceptional paths unspecified.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S020; AOSE-S021; AOSE-S037; AOSE-S043]

### EAOSE-021 — Shared content and ontology interpretation

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-021

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Agree message structure, content language, domain terms, identities and conversation correlation; verify the interpretation at receiving implementations rather than merely validating syntax.

**Controlled failure —** Matching schemas can still conceal differing units, time horizons or institutional meaning.

**Trigger —** Different components exchange semantically significant data.

**Non-trigger / cheap path —** A shared typed schema and a few interpretation tests suffice when meaning is unambiguous.

**Prerequisites —** property inputs: EAOSE-020. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Matching schemas can still conceal differing units, time horizons or institutional meaning..

**Domain profile —** DOMAIN-PROFILE-O4 above; candidate application: Shared content and ontology interpretation. A valid message is interpreted consistently with its declared protocol and domain context.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: A valid message is interpreted consistently with its declared protocol and domain context. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Protocol designers, implementers and the principals participating in an interaction. boundary: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning..

**Communication / operation —** content: Agree message structure, content language, domain terms, identities and conversation correlation; verify the interpretation at receiving implementations rather than merely validating syntax.. consumer: Protocol designers, implementers and the principals participating in an interaction. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-04. local analytical objection: Matching schemas can still conceal differing units, time horizons or institutional meaning.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: A valid message is interpreted consistently with its declared protocol and domain context.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A shared typed schema and a few interpretation tests suffice when meaning is unambiguous.. ledger id: CS-021.

**Conflicts / alternatives —** tension ids: T-04. relation ids: REL-032. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: None, subject to the stated absence explanation.. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-04. analytical limit: Matching schemas can still conceal differing units, time horizons or institutional meaning... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — A valid message is interpreted consistently with its declared protocol and domain context. — from the failure boundary — Matching schemas can still conceal differing units, time horizons or institutional meaning.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S039; AOSE-S043; AOSE-S041]

### EAOSE-022 — Global-to-local protocol correspondence

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-022

**Disposition —** ASSUMPTION_SENSITIVE

**Mature form —** Check that local send/receive behaviours collectively realise the intended global interaction, with explicit asynchronous and information-availability assumptions.

**Controlled failure —** Syntax-preserving projection need not preserve behaviour; reliable-delivery or complete-information assumptions may fail.

**Trigger —** A global protocol is projected or compiled into independently executing agents.

**Non-trigger / cheap path —** Joint contract tests can be adequate for a short bounded exchange.

**Prerequisites —** property inputs: EAOSE-020; EAOSE-021. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Syntax-preserving projection need not preserve behaviour; reliable-delivery or complete-information assumptions may fail..

**Domain profile —** DOMAIN-PROFILE-O4 above; candidate application: Global-to-local protocol correspondence. Permitted global runs are realisable and invalid local combinations are detected under the stated model.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Permitted global runs are realisable and invalid local combinations are detected under the stated model. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Protocol designers, implementers and the principals participating in an interaction. boundary: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning..

**Communication / operation —** content: Check that local send/receive behaviours collectively realise the intended global interaction, with explicit asynchronous and information-availability assumptions.. consumer: Protocol designers, implementers and the principals participating in an interaction. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-04; CR-05. local analytical objection: Syntax-preserving projection need not preserve behaviour; reliable-delivery or complete-information assumptions may fail.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Permitted global runs are realisable and invalid local combinations are detected under the stated model.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Joint contract tests can be adequate for a short bounded exchange.. ledger id: CS-022.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-032. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: strong distinction or conditional argument. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: FR-01.. empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-06; EV-13. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-04; CR-05. analytical limit: Syntax-preserving projection need not preserve behaviour; reliable-delivery or complete-information assumptions may fail... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Permitted global runs are realisable and invalid local combinations are detected under the stated model. — from the failure boundary — Syntax-preserving projection need not preserve behaviour; reliable-delivery or complete-information assumptions may fail.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S015; AOSE-S020; AOSE-S037; AOSE-S036; AOSE-S054]

### EAOSE-023 — Public commitment semantics for open interaction

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-023

**Disposition —** CONTEXT_DEPENDENT

**Mature form —** Represent a commitment by debtor, creditor, condition and consequent; track its lifecycle from public evidence while allowing each party private implementation choices.

**Controlled failure —** Observable messages need not establish actual delivery; commitments do not compel compliance or settle contested institutions.

**Trigger —** Independent parties need accountable interaction without access to one another’s internal beliefs.

**Non-trigger / cheap path —** A conventional explicit service agreement may suffice; closed cooperative internals need not use commitments.

**Prerequisites —** property inputs: EAOSE-003; EAOSE-005; EAOSE-020. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Observable messages need not establish actual delivery; commitments do not compel compliance or settle contested institutions..

**Domain profile —** DOMAIN-PROFILE-O4 above; candidate application: Public commitment semantics for open interaction. Parties can contest or establish fulfilment from agreed public events rather than alleged private intention.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Parties can contest or establish fulfilment from agreed public events rather than alleged private intention. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Protocol designers, implementers and the principals participating in an interaction. boundary: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning..

**Communication / operation —** content: Represent a commitment by debtor, creditor, condition and consequent; track its lifecycle from public evidence while allowing each party private implementation choices.. consumer: Protocol designers, implementers and the principals participating in an interaction. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-04; CR-14. local analytical objection: Observable messages need not establish actual delivery; commitments do not compel compliance or settle contested institutions.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Parties can contest or establish fulfilment from agreed public events rather than alleged private intention.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A conventional explicit service agreement may suffice; closed cooperative internals need not use commitments.. ledger id: CS-023.

**Conflicts / alternatives —** tension ids: T-06; T-07. relation ids: REL-010; REL-032; REL-222. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: FR-01.. empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-05; EV-13. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-04; CR-14. analytical limit: Observable messages need not establish actual delivery; commitments do not compel compliance or settle contested institutions... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Parties can contest or establish fulfilment from agreed public events rather than alleged private intention. — from the failure boundary — Observable messages need not establish actual delivery; commitments do not compel compliance or settle contested institutions.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S021; AOSE-S037; AOSE-S045]

### EAOSE-024 — Private mental states as the basis of communication compliance

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-024

**Disposition —** CONTESTED

**Mature form —** Use mental-state semantics to reason about specified cooperative agents, but do not infer publicly enforceable compliance from inaccessible or untrusted private beliefs.

**Controlled failure —** Singh’s objection targets open compliance; it does not show that BDI reasoning inside a controlled agent is useless.

**Trigger —** The claimed meaning of a message depends on beliefs or intentions attributed to its sender.

**Non-trigger / cheap path —** Use public commitments or operational interface conditions for heterogeneous open participants.

**Prerequisites —** property inputs: EAOSE-020; EAOSE-023. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Singh’s objection targets open compliance; it does not show that BDI reasoning inside a controlled agent is useless..

**Domain profile —** DOMAIN-PROFILE-O4 above; candidate application: Private mental states as the basis of communication compliance. The communication claim states whether private-state assumptions are checked, stipulated or unavailable.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: The communication claim states whether private-state assumptions are checked, stipulated or unavailable. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Protocol designers, implementers and the principals participating in an interaction. boundary: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning..

**Communication / operation —** content: Use mental-state semantics to reason about specified cooperative agents, but do not infer publicly enforceable compliance from inaccessible or untrusted private beliefs.. consumer: Protocol designers, implementers and the principals participating in an interaction. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-04. local analytical objection: Singh’s objection targets open compliance; it does not show that BDI reasoning inside a controlled agent is useless.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: The communication claim states whether private-state assumptions are checked, stipulated or unavailable.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Use public commitments or operational interface conditions for heterogeneous open participants.. ledger id: CS-024.

**Conflicts / alternatives —** tension ids: T-07. relation ids: REL-010; REL-222. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: None, subject to the stated absence explanation.. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-04. analytical limit: Singh’s objection targets open compliance; it does not show that BDI reasoning inside a controlled agent is useless... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — The communication claim states whether private-state assumptions are checked, stipulated or unavailable. — from the failure boundary — Singh’s objection targets open compliance; it does not show that BDI reasoning inside a controlled agent is useless.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S033; AOSE-S012; AOSE-S021]

### EAOSE-025 — Specified exceptional interaction and recovery

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-025

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Treat timeouts, refusals, unavailable services, duplicates and malformed messages as specified outcomes with bounded recovery or escalation, not invisible departures from the happy path.

**Controlled failure —** Retries can duplicate effects; timeouts do not prove that a remote effect did not occur.

**Trigger —** Communication or delegated work can fail or be delayed.

**Non-trigger / cheap path —** Use a simple fail-and-report policy where retry or compensation would add risk.

**Prerequisites —** property inputs: EAOSE-020; EAOSE-021. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Retries can duplicate effects; timeouts do not prove that a remote effect did not occur..

**Domain profile —** DOMAIN-PROFILE-O4 above; candidate application: Specified exceptional interaction and recovery. An exceptional exchange reaches a known state without fabricating completion.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: An exceptional exchange reaches a known state without fabricating completion. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Protocol designers, implementers and the principals participating in an interaction. boundary: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning..

**Communication / operation —** content: Treat timeouts, refusals, unavailable services, duplicates and malformed messages as specified outcomes with bounded recovery or escalation, not invisible departures from the happy path.. consumer: Protocol designers, implementers and the principals participating in an interaction. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-05. local analytical objection: Retries can duplicate effects; timeouts do not prove that a remote effect did not occur.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: An exceptional exchange reaches a known state without fabricating completion.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Use a simple fail-and-report policy where retry or compensation would add risk.. ledger id: CS-025.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-08; EV-09. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-05. analytical limit: Retries can duplicate effects; timeouts do not prove that a remote effect did not occur... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — An exceptional exchange reaches a known state without fabricating completion. — from the failure boundary — Retries can duplicate effects; timeouts do not prove that a remote effect did not occur.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S015; AOSE-S039; AOSE-S035; AOSE-S050]

### EAOSE-026 — Versioned protocol compatibility

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-026

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Identify which protocol and interpretation versions peers enact; constrain rollout or supply a checked adapter where supported behaviours or message meaning change.

**Controlled failure —** Version labels alone do not prove compatibility; an adapter can preserve fields while changing commitments.

**Trigger —** Peers may run mixed versions or interfaces evolve independently.

**Non-trigger / cheap path —** An atomic coordinated upgrade can avoid a permanent compatibility layer.

**Prerequisites —** property inputs: EAOSE-021; EAOSE-022; EAOSE-025. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Version labels alone do not prove compatibility; an adapter can preserve fields while changing commitments..

**Domain profile —** DOMAIN-PROFILE-O4 above; candidate application: Versioned protocol compatibility. A mixed-version interaction is either supported by evidence or explicitly refused.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: A mixed-version interaction is either supported by evidence or explicitly refused. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Protocol designers, implementers and the principals participating in an interaction. boundary: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning..

**Communication / operation —** content: Identify which protocol and interpretation versions peers enact; constrain rollout or supply a checked adapter where supported behaviours or message meaning change.. consumer: Protocol designers, implementers and the principals participating in an interaction. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-05. local analytical objection: Version labels alone do not prove compatibility; an adapter can preserve fields while changing commitments.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: A mixed-version interaction is either supported by evidence or explicitly refused.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: An atomic coordinated upgrade can avoid a permanent compatibility layer.. ledger id: CS-026.

**Conflicts / alternatives —** tension ids: T-04. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: None, subject to the stated absence explanation.. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-05. analytical limit: Version labels alone do not prove compatibility; an adapter can preserve fields while changing commitments... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — A mixed-version interaction is either supported by evidence or explicitly refused. — from the failure boundary — Version labels alone do not prove compatibility; an adapter can preserve fields while changing commitments.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S029; AOSE-S036; AOSE-S043]

### EAOSE-028 — Select an agent-internal architecture to match the decision problem

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-028

**Disposition —** CONTEXT_DEPENDENT

**Mature form —** Choose and document BDI, reactive, imperative or another supported internal architecture according to required choice, failure handling and available engineering expertise.

**Controlled failure —** A method’s support for BDI does not make BDI obligatory or sufficient for every autonomous component.

**Trigger —** An agent’s internal decision mechanism is being designed.

**Non-trigger / cheap path —** A direct state machine or ordinary behaviour implementation may be sufficient.

**Prerequisites —** property inputs: EAOSE-008; EAOSE-010; EAOSE-018. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. A method’s support for BDI does not make BDI obligatory or sufficient for every autonomous component..

**Domain profile —** DOMAIN-PROFILE-O5 above; candidate application: Select an agent-internal architecture to match the decision problem. Internal concepts have an implementation interpretation rather than merely anthropomorphic labels.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Internal concepts have an implementation interpretation rather than merely anthropomorphic labels. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Agent designer, programmer and boundary-integration engineer. boundary: May implement approved capabilities; model/code generation does not expand authorised effects..

**Communication / operation —** content: Choose and document BDI, reactive, imperative or another supported internal architecture according to required choice, failure handling and available engineering expertise.. consumer: Agent designer, programmer and boundary-integration engineer. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-06. local analytical objection: A method’s support for BDI does not make BDI obligatory or sufficient for every autonomous component.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Internal concepts have an implementation interpretation rather than merely anthropomorphic labels.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A direct state machine or ordinary behaviour implementation may be sufficient.. ledger id: CS-028.

**Conflicts / alternatives —** tension ids: T-02; T-07. relation ids: REL-005. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: None, subject to the stated absence explanation.. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-06. analytical limit: A method’s support for BDI does not make BDI obligatory or sufficient for every autonomous component... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Internal concepts have an implementation interpretation rather than merely anthropomorphic labels. — from the failure boundary — A method’s support for BDI does not make BDI obligatory or sufficient for every autonomous component.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S012; AOSE-S007; AOSE-S033; AOSE-S036; AOSE-S041]

### EAOSE-029 — Percept-to-belief and action-to-effect correspondence

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-029

**Disposition —** STRONGLY_RETAINED

**Mature form —** Validate the mappings from environmental observations to beliefs and from selected actions to external effects, separately from the correctness of deliberation.

**Controlled failure —** Ground beliefs may be wrong; successful tool return can occur without the intended external consequence.

**Trigger —** Correct decisions depend on sensors, tools, actuators or state-estimation assumptions.

**Non-trigger / cheap path —** Direct boundary tests and observable effect checks may suffice.

**Prerequisites —** property inputs: EAOSE-018; EAOSE-028. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. Ground beliefs may be wrong; successful tool return can occur without the intended external consequence..

**Domain profile —** DOMAIN-PROFILE-O5 above; candidate application: Percept-to-belief and action-to-effect correspondence. A correct internal belief update or action request is not mistaken for a correct measurement or achieved effect.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: A correct internal belief update or action request is not mistaken for a correct measurement or achieved effect. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Agent designer, programmer and boundary-integration engineer. boundary: May implement approved capabilities; model/code generation does not expand authorised effects..

**Communication / operation —** content: Validate the mappings from environmental observations to beliefs and from selected actions to external effects, separately from the correctness of deliberation.. consumer: Agent designer, programmer and boundary-integration engineer. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-06; CR-18. local analytical objection: Ground beliefs may be wrong; successful tool return can occur without the intended external consequence.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: A correct internal belief update or action request is not mistaken for a correct measurement or achieved effect.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Direct boundary tests and observable effect checks may suffice.. ledger id: CS-029.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: strong distinction or conditional argument. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: FR-02; FR-03.. empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-07; EV-11; EV-13; EV-16. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-06; CR-18. analytical limit: Ground beliefs may be wrong; successful tool return can occur without the intended external consequence... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — A correct internal belief update or action request is not mistaken for a correct measurement or achieved effect. — from the failure boundary — Ground beliefs may be wrong; successful tool return can occur without the intended external consequence.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S007; AOSE-S012; AOSE-S023; AOSE-S030; AOSE-S031; AOSE-S056; AOSE-S062]

### EAOSE-030 — Plan applicability, achievement and failure conditions

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-030

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Make explicit when a plan is applicable, what success means, when it fails or is abandoned and how alternatives are selected; test false-success and inapplicable-plan cases.

**Controlled failure —** Plan libraries can be incomplete and contexts stale; goal persistence can waste resources or conflict with changed needs.

**Trigger —** An agent selects among plans or persists with an intention.

**Non-trigger / cheap path —** A single guarded action with a failure result is enough for a simple task.

**Prerequisites —** property inputs: EAOSE-002; EAOSE-028; EAOSE-029. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. Plan libraries can be incomplete and contexts stale; goal persistence can waste resources or conflict with changed needs..

**Domain profile —** DOMAIN-PROFILE-O5 above; candidate application: Plan applicability, achievement and failure conditions. A plan is neither selected outside its context nor treated as successful solely because its steps terminated.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: A plan is neither selected outside its context nor treated as successful solely because its steps terminated. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Agent designer, programmer and boundary-integration engineer. boundary: May implement approved capabilities; model/code generation does not expand authorised effects..

**Communication / operation —** content: Make explicit when a plan is applicable, what success means, when it fails or is abandoned and how alternatives are selected; test false-success and inapplicable-plan cases.. consumer: Agent designer, programmer and boundary-integration engineer. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-06. local analytical objection: Plan libraries can be incomplete and contexts stale; goal persistence can waste resources or conflict with changed needs.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: A plan is neither selected outside its context nor treated as successful solely because its steps terminated.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A single guarded action with a failure result is enough for a simple task.. ledger id: CS-030.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-023. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: FR-05.. empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-07; EV-13. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-06. analytical limit: Plan libraries can be incomplete and contexts stale; goal persistence can waste resources or conflict with changed needs... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — A plan is neither selected outside its context nor treated as successful solely because its steps terminated. — from the failure boundary — Plan libraries can be incomplete and contexts stale; goal persistence can waste resources or conflict with changed needs.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S007; AOSE-S012; AOSE-S031; AOSE-S049]

### EAOSE-031 — Interference among concurrent intentions

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-031

**Disposition —** ASSUMPTION_SENSITIVE

**Mature form —** Analyse or test resource, belief and goal interference among simultaneously active intentions; state scheduler and environment assumptions.

**Controlled failure —** Serialisation may miss deadlines; exhaustive interleavings can be infeasible and concurrency models omit physical effects.

**Trigger —** Plans overlap in time or manipulate shared state.

**Non-trigger / cheap path —** Serialise a small critical region when this preserves required responsiveness.

**Prerequisites —** property inputs: EAOSE-014; EAOSE-018; EAOSE-030. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. Serialisation may miss deadlines; exhaustive interleavings can be infeasible and concurrency models omit physical effects..

**Domain profile —** DOMAIN-PROFILE-O5 above; candidate application: Interference among concurrent intentions. An individually valid plan cannot silently invalidate another plan’s relied-on preconditions.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: An individually valid plan cannot silently invalidate another plan’s relied-on preconditions. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Agent designer, programmer and boundary-integration engineer. boundary: May implement approved capabilities; model/code generation does not expand authorised effects..

**Communication / operation —** content: Analyse or test resource, belief and goal interference among simultaneously active intentions; state scheduler and environment assumptions.. consumer: Agent designer, programmer and boundary-integration engineer. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-06; CR-16. local analytical objection: Serialisation may miss deadlines; exhaustive interleavings can be infeasible and concurrency models omit physical effects.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: An individually valid plan cannot silently invalidate another plan’s relied-on preconditions.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Serialise a small critical region when this preserves required responsiveness.. ledger id: CS-031.

**Conflicts / alternatives —** tension ids: T-02; T-10. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: strong distinction or conditional argument. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: FR-03; FR-04.. empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-06; EV-11; EV-13. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-06; CR-16. analytical limit: Serialisation may miss deadlines; exhaustive interleavings can be infeasible and concurrency models omit physical effects... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — An individually valid plan cannot silently invalidate another plan’s relied-on preconditions. — from the failure boundary — Serialisation may miss deadlines; exhaustive interleavings can be infeasible and concurrency models omit physical effects.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S012; AOSE-S024; AOSE-S030; AOSE-S054; AOSE-S056]

### EAOSE-032 — Semantics-aware model transformation

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-032

**Disposition —** ASSUMPTION_SENSITIVE

**Mature form —** State the source and target semantics and the property preserved by a transformation; validate its assumptions and inspect the generated/manual boundary.

**Controlled failure —** Correct generation can implement wrong requirements; formal preservation need not cover libraries, deployment or remote services.

**Trigger —** Models generate code, protocol adapters or executable plans.

**Non-trigger / cheap path —** Hand implementation with focused correspondence tests is sufficient where generation has no benefit.

**Prerequisites —** property inputs: EAOSE-022; EAOSE-028; EAOSE-030. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. Correct generation can implement wrong requirements; formal preservation need not cover libraries, deployment or remote services..

**Domain profile —** DOMAIN-PROFILE-O5 above; candidate application: Semantics-aware model transformation. A transformation claim identifies precisely what preservation has been established.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: A transformation claim identifies precisely what preservation has been established. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Agent designer, programmer and boundary-integration engineer. boundary: May implement approved capabilities; model/code generation does not expand authorised effects..

**Communication / operation —** content: State the source and target semantics and the property preserved by a transformation; validate its assumptions and inspect the generated/manual boundary.. consumer: Agent designer, programmer and boundary-integration engineer. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-05. local analytical objection: Correct generation can implement wrong requirements; formal preservation need not cover libraries, deployment or remote services.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: A transformation claim identifies precisely what preservation has been established.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Hand implementation with focused correspondence tests is sufficient where generation has no benefit.. ledger id: CS-032.

**Conflicts / alternatives —** tension ids: T-04; T-05. relation ids: REL-013. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: strong distinction or conditional argument. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: FR-01; FR-05; FR-06.. empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-06; EV-13. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-05. analytical limit: Correct generation can implement wrong requirements; formal preservation need not cover libraries, deployment or remote services... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — A transformation claim identifies precisely what preservation has been established. — from the failure boundary — Correct generation can implement wrong requirements; formal preservation need not cover libraries, deployment or remote services.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S018; AOSE-S037; AOSE-S036; AOSE-S049; AOSE-S054]

### EAOSE-033 — Explicit manual completion and integration duties

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-033

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Identify code, environmental bindings, exception handling and tests left to programmers after modelling or generation; assign and review those duties.

**Controlled failure —** A checklist can conceal absent implementation expertise; generated percentage is not quality or effort saved.

**Trigger —** A methodology or tool produces only part of the executable system.

**Non-trigger / cheap path —** A short generated/manual boundary note is adequate when remaining work is small.

**Prerequisites —** property inputs: EAOSE-029; EAOSE-032. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. A checklist can conceal absent implementation expertise; generated percentage is not quality or effort saved..

**Domain profile —** DOMAIN-PROFILE-O5 above; candidate application: Explicit manual completion and integration duties. Generated coverage does not cause unimplemented obligations to disappear from acceptance.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Generated coverage does not cause unimplemented obligations to disappear from acceptance. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Agent designer, programmer and boundary-integration engineer. boundary: May implement approved capabilities; model/code generation does not expand authorised effects..

**Communication / operation —** content: Identify code, environmental bindings, exception handling and tests left to programmers after modelling or generation; assign and review those duties.. consumer: Agent designer, programmer and boundary-integration engineer. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-07. local analytical objection: A checklist can conceal absent implementation expertise; generated percentage is not quality or effort saved.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Generated coverage does not cause unimplemented obligations to disappear from acceptance.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A short generated/manual boundary note is adequate when remaining work is small.. ledger id: CS-033.

**Conflicts / alternatives —** tension ids: T-05. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-02; EV-11. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-07. analytical limit: A checklist can conceal absent implementation expertise; generated percentage is not quality or effort saved... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Generated coverage does not cause unimplemented obligations to disappear from acceptance. — from the failure boundary — A checklist can conceal absent implementation expertise; generated percentage is not quality or effort saved.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S039; AOSE-S008; AOSE-S007; AOSE-S018; AOSE-S056]

### EAOSE-034 — Bidirectional design–implementation traceability

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-034

**Disposition —** USEFUL_BUT_EASILY_BUREAUCRATISED

**Mature form —** Link consequential requirements and design choices to their executable realisations and evidence; follow a defect back to the affected decision as well as forward from a requirement to code.

**Controlled failure —** Link coverage can be high while meaning is stale; maintaining unused links becomes a cost without a consumer.

**Trigger —** Several representations or teams can drift apart during development or change.

**Non-trigger / cheap path —** Stable names, tests and a few explicit links may suffice instead of a trace repository.

**Prerequisites —** property inputs: EAOSE-002; EAOSE-032; EAOSE-033. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. Link coverage can be high while meaning is stale; maintaining unused links becomes a cost without a consumer..

**Domain profile —** DOMAIN-PROFILE-O5 above; candidate application: Bidirectional design–implementation traceability. A changed or failing implementation identifies the relevant claim and responsible decision.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: A changed or failing implementation identifies the relevant claim and responsible decision. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Agent designer, programmer and boundary-integration engineer. boundary: May implement approved capabilities; model/code generation does not expand authorised effects..

**Communication / operation —** content: Link consequential requirements and design choices to their executable realisations and evidence; follow a defect back to the affected decision as well as forward from a requirement to code.. consumer: Agent designer, programmer and boundary-integration engineer. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-07; CR-15. local analytical objection: Link coverage can be high while meaning is stale; maintaining unused links becomes a cost without a consumer.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: A changed or failing implementation identifies the relevant claim and responsible decision.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Stable names, tests and a few explicit links may suffice instead of a trace repository.. ledger id: CS-034.

**Conflicts / alternatives —** tension ids: T-01; T-05. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-06; EV-07. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-07; CR-15. analytical limit: Link coverage can be high while meaning is stale; maintaining unused links becomes a cost without a consumer... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — A changed or failing implementation identifies the relevant claim and responsible decision. — from the failure boundary — Link coverage can be high while meaning is stale; maintaining unused links becomes a cost without a consumer.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S004; AOSE-S018; AOSE-S031; AOSE-S054; AOSE-S059]

### EAOSE-036 — Semantic compatibility of method fragments

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-036

**Disposition —** ASSUMPTION_SENSITIVE

**Mature form —** Compose fragments through explicit concept, work-product and dependency mappings; check that their actor, goal, role and lifecycle assumptions can coexist.

**Controlled failure —** Metamodel compatibility is necessary but not proof that the combined method is feasible, usable or effective.

**Trigger —** A tailored method imports guidance or artefacts from different methodologies.

**Non-trigger / cheap path —** Use one coherent lightweight method where its scope suffices.

**Prerequisites —** property inputs: EAOSE-002; EAOSE-013; EAOSE-032. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Metamodel compatibility is necessary but not proof that the combined method is feasible, usable or effective..

**Domain profile —** DOMAIN-PROFILE-O6 above; candidate application: Semantic compatibility of method fragments. A fragment’s required input has the meaning its producer actually supplies.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: A fragment’s required input has the meaning its producer actually supplies. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Method engineer or team accountable for the actual work-product consumers. boundary: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations..

**Communication / operation —** content: Compose fragments through explicit concept, work-product and dependency mappings; check that their actor, goal, role and lifecycle assumptions can coexist.. consumer: Method engineer or team accountable for the actual work-product consumers. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-07. local analytical objection: Metamodel compatibility is necessary but not proof that the combined method is feasible, usable or effective.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: A fragment’s required input has the meaning its producer actually supplies.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Use one coherent lightweight method where its scope suffices.. ledger id: CS-036.

**Conflicts / alternatives —** tension ids: T-03. relation ids: REL-015. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-02. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-07. analytical limit: Metamodel compatibility is necessary but not proof that the combined method is feasible, usable or effective... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — A fragment’s required input has the meaning its producer actually supplies. — from the failure boundary — Metamodel compatibility is necessary but not proof that the combined method is feasible, usable or effective.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S003; AOSE-S009; AOSE-S017; AOSE-S008; AOSE-S022]

### EAOSE-037 — Executable prescriptions and work-product consumers

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-037

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Define who performs each method task, with which inputs, what decision or work product it yields and who consumes it; treat a named lifecycle phase as insufficient guidance.

**Controlled failure —** Detailed instructions can be wrong for the context and can suppress expert judgement.

**Trigger —** A method claims to support an engineering concern.

**Non-trigger / cheap path —** A direct decision rule or established team practice is enough if it supplies the needed result.

**Prerequisites —** property inputs: EAOSE-036. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Detailed instructions can be wrong for the context and can suppress expert judgement..

**Domain profile —** DOMAIN-PROFILE-O6 above; candidate application: Executable prescriptions and work-product consumers. Practitioners can execute the prescription and recognise its relevant result.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Practitioners can execute the prescription and recognise its relevant result. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Method engineer or team accountable for the actual work-product consumers. boundary: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations..

**Communication / operation —** content: Define who performs each method task, with which inputs, what decision or work product it yields and who consumes it; treat a named lifecycle phase as insufficient guidance.. consumer: Method engineer or team accountable for the actual work-product consumers. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-07. local analytical objection: Detailed instructions can be wrong for the context and can suppress expert judgement.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Practitioners can execute the prescription and recognise its relevant result.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A direct decision rule or established team practice is enough if it supplies the needed result.. ledger id: CS-037.

**Conflicts / alternatives —** tension ids: T-03. relation ids: REL-015. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: None, subject to the stated absence explanation.. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-07. analytical limit: Detailed instructions can be wrong for the context and can suppress expert judgement... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Practitioners can execute the prescription and recognise its relevant result. — from the failure boundary — Detailed instructions can be wrong for the context and can suppress expert judgement.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S003; AOSE-S017; AOSE-S046; AOSE-S033]

### EAOSE-038 — Iterative cross-view feedback rather than mandatory phase order

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-038

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Permit implementation, testing and operational evidence to revise earlier models; retain only ordering constraints required by dependencies, not a universal linear lifecycle.

**Controlled failure —** Unbounded iteration can hide indecision; some safety or contractual prerequisites genuinely must precede action.

**Trigger —** Later work reveals missing constraints or invalid assumptions.

**Non-trigger / cheap path —** A small stable task may complete in one pass; no artificial iteration count is required.

**Prerequisites —** property inputs: EAOSE-034; EAOSE-037. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Unbounded iteration can hide indecision; some safety or contractual prerequisites genuinely must precede action..

**Domain profile —** DOMAIN-PROFILE-O6 above; candidate application: Iterative cross-view feedback rather than mandatory phase order. A counterexample can reach the model or requirement that made it possible.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: A counterexample can reach the model or requirement that made it possible. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Method engineer or team accountable for the actual work-product consumers. boundary: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations..

**Communication / operation —** content: Permit implementation, testing and operational evidence to revise earlier models; retain only ordering constraints required by dependencies, not a universal linear lifecycle.. consumer: Method engineer or team accountable for the actual work-product consumers. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-07. local analytical objection: Unbounded iteration can hide indecision; some safety or contractual prerequisites genuinely must precede action.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: A counterexample can reach the model or requirement that made it possible.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A small stable task may complete in one pass; no artificial iteration count is required.. ledger id: CS-038.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-02; EV-07. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-07. analytical limit: Unbounded iteration can hide indecision; some safety or contractual prerequisites genuinely must precede action... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — A counterexample can reach the model or requirement that made it possible. — from the failure boundary — Unbounded iteration can hide indecision; some safety or contractual prerequisites genuinely must precede action.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S007; AOSE-S039; AOSE-S003; AOSE-S008; AOSE-S031; AOSE-S059]

### EAOSE-039 — Proportional method assembly and retirement

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-039

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Select, simplify or retire artefacts and tasks according to a live failure risk, consumer and dependency; preserve the protected obligation when replacing the machinery.

**Controlled failure —** Rarely used preventive controls can still matter; apparent lack of use is not sufficient retirement evidence.

**Trigger —** A method is tailored, becomes costly or contains work with no current decision use.

**Non-trigger / cheap path —** Omit unused machinery; retain a smaller evidence or coordination mechanism when adequate.

**Prerequisites —** property inputs: EAOSE-036; EAOSE-037; EAOSE-038. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Rarely used preventive controls can still matter; apparent lack of use is not sufficient retirement evidence..

**Domain profile —** DOMAIN-PROFILE-O6 above; candidate application: Proportional method assembly and retirement. Every retained task has a live function and every removed task leaves no unaddressed relied-on obligation.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Every retained task has a live function and every removed task leaves no unaddressed relied-on obligation. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Method engineer or team accountable for the actual work-product consumers. boundary: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations..

**Communication / operation —** content: Select, simplify or retire artefacts and tasks according to a live failure risk, consumer and dependency; preserve the protected obligation when replacing the machinery.. consumer: Method engineer or team accountable for the actual work-product consumers. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-07; CR-15. local analytical objection: Rarely used preventive controls can still matter; apparent lack of use is not sufficient retirement evidence.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Every retained task has a live function and every removed task leaves no unaddressed relied-on obligation.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Omit unused machinery; retain a smaller evidence or coordination mechanism when adequate.. ledger id: CS-039.

**Conflicts / alternatives —** tension ids: T-01; T-03. relation ids: REL-005; REL-015. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-02. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-07; CR-15. analytical limit: Rarely used preventive controls can still matter; apparent lack of use is not sufficient retirement evidence... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Every retained task has a live function and every removed task leaves no unaddressed relied-on obligation. — from the failure boundary — Rarely used preventive controls can still matter; apparent lack of use is not sufficient retirement evidence.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S008; AOSE-S003; AOSE-S017; AOSE-S046; AOSE-S060]

### EAOSE-040 — Context-checked pattern reuse

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-040

**Disposition —** CONTEXT_DEPENDENT

**Mature form —** Reuse an interaction, knowledge or implementation pattern only after checking its role, environment and semantic assumptions; retain the obligation to validate the instantiated result.

**Controlled failure —** Reuse can carry hidden platform assumptions or obsolete constraints; reusable code quantity does not measure net engineering benefit.

**Trigger —** A prior fragment appears to solve a recurring design problem.

**Non-trigger / cheap path —** Implement the small local behaviour directly when adaptation costs exceed reuse benefit.

**Prerequisites —** property inputs: EAOSE-021; EAOSE-032; EAOSE-036. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Reuse can carry hidden platform assumptions or obsolete constraints; reusable code quantity does not measure net engineering benefit..

**Domain profile —** DOMAIN-PROFILE-O6 above; candidate application: Context-checked pattern reuse. The reused pattern has an explicit applicability argument and tested adaptation points.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: The reused pattern has an explicit applicability argument and tested adaptation points. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Method engineer or team accountable for the actual work-product consumers. boundary: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations..

**Communication / operation —** content: Reuse an interaction, knowledge or implementation pattern only after checking its role, environment and semantic assumptions; retain the obligation to validate the instantiated result.. consumer: Method engineer or team accountable for the actual work-product consumers. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-07; CR-18. local analytical objection: Reuse can carry hidden platform assumptions or obsolete constraints; reusable code quantity does not measure net engineering benefit.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: The reused pattern has an explicit applicability argument and tested adaptation points.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Implement the small local behaviour directly when adaptation costs exceed reuse benefit.. ledger id: CS-040.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-02; EV-05; EV-16. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-07; CR-18. analytical limit: Reuse can carry hidden platform assumptions or obsolete constraints; reusable code quantity does not measure net engineering benefit... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — The reused pattern has an explicit applicability argument and tested adaptation points. — from the failure boundary — Reuse can carry hidden platform assumptions or obsolete constraints; reusable code quantity does not measure net engineering benefit.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S039; AOSE-S008; AOSE-S045; AOSE-S041; AOSE-S062]

### EAOSE-041 — Learnability and tool-maintenance fit

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-041

**Disposition —** CONTEXT_DEPENDENT

**Mature form —** Assess whether the intended team can learn, execute and maintain the selected method and toolchain, including manual work and integration with ordinary engineering tools.

**Controlled failure —** Familiar tools can lack required semantics; an old successful tool version does not establish current support.

**Trigger —** A method’s expressive power is being weighed against practical delivery constraints.

**Non-trigger / cheap path —** Use a smaller language subset or familiar tooling without claiming it preserves every richer semantic feature.

**Prerequisites —** property inputs: EAOSE-011; EAOSE-036; EAOSE-039. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Familiar tools can lack required semantics; an old successful tool version does not establish current support..

**Domain profile —** DOMAIN-PROFILE-O6 above; candidate application: Learnability and tool-maintenance fit. The chosen process has an achievable skills and maintenance burden.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: The chosen process has an achievable skills and maintenance burden. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Method engineer or team accountable for the actual work-product consumers. boundary: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations..

**Communication / operation —** content: Assess whether the intended team can learn, execute and maintain the selected method and toolchain, including manual work and integration with ordinary engineering tools.. consumer: Method engineer or team accountable for the actual work-product consumers. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-07; CR-15. local analytical objection: Familiar tools can lack required semantics; an old successful tool version does not establish current support.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: The chosen process has an achievable skills and maintenance burden.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Use a smaller language subset or familiar tooling without claiming it preserves every richer semantic feature.. ledger id: CS-041.

**Conflicts / alternatives —** tension ids: T-01; T-04. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-01; EV-07. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-07; CR-15. analytical limit: Familiar tools can lack required semantics; an old successful tool version does not establish current support... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — The chosen process has an achievable skills and maintenance burden. — from the failure boundary — Familiar tools can lack required semantics; an old successful tool version does not establish current support.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S002; AOSE-S025; AOSE-S034; AOSE-S046; AOSE-S031; AOSE-S044]

### EAOSE-043 — Stakeholder validation is distinct from implementation verification

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-043

**Disposition —** STRONGLY_RETAINED

**Mature form —** Obtain a judgement that the specified behaviour addresses the relevant needs, in addition to checking that code conforms to the specification.

**Controlled failure —** Stakeholders may disagree or miss consequences; participation cannot guarantee correctness.

**Trigger —** A system is proposed for acceptance or material change.

**Non-trigger / cheap path —** A direct demonstration and discussion can validate a small transparent requirement.

**Prerequisites —** property inputs: EAOSE-001; EAOSE-002. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Stakeholders may disagree or miss consequences; participation cannot guarantee correctness..

**Domain profile —** DOMAIN-PROFILE-O7 above; candidate application: Stakeholder validation is distinct from implementation verification. Conformance evidence is not reported as independent validation of stakeholder relevance.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Conformance evidence is not reported as independent validation of stakeholder relevance. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Communication / operation —** content: Obtain a judgement that the specified behaviour addresses the relevant needs, in addition to checking that code conforms to the specification.. consumer: Tester, verification engineer and accountable acceptance decision maker. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-06; CR-08. local analytical objection: Stakeholders may disagree or miss consequences; participation cannot guarantee correctness.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Conformance evidence is not reported as independent validation of stakeholder relevance.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A direct demonstration and discussion can validate a small transparent requirement.. ledger id: CS-043.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-031; REL-033. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: strong distinction or conditional argument. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-05; EV-07. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-06; CR-08. analytical limit: Stakeholders may disagree or miss consequences; participation cannot guarantee correctness... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Conformance evidence is not reported as independent validation of stakeholder relevance. — from the failure boundary — Stakeholders may disagree or miss consequences; participation cannot guarantee correctness.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S004; AOSE-S010; AOSE-S031; AOSE-S045; AOSE-S059]

### EAOSE-044 — Assure both individual behaviour and collective outcomes

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-044

**Disposition —** STRONGLY_RETAINED

**Mature form —** Combine component evidence with tests or analyses of interactions and shared outcomes; retain separate claims for each level.

**Controlled failure —** Collective scenarios remain incomplete and can hide strategic or environmental behaviour.

**Trigger —** Several agents or services jointly realise a requirement.

**Non-trigger / cheap path —** For one non-interacting component, collective assurance is not a separate activity.

**Prerequisites —** property inputs: EAOSE-014; EAOSE-022; EAOSE-029. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Collective scenarios remain incomplete and can hide strategic or environmental behaviour..

**Domain profile —** DOMAIN-PROFILE-O7 above; candidate application: Assure both individual behaviour and collective outcomes. Locally passing agents are not assumed to establish a correct system.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Locally passing agents are not assumed to establish a correct system. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Communication / operation —** content: Combine component evidence with tests or analyses of interactions and shared outcomes; retain separate claims for each level.. consumer: Tester, verification engineer and accountable acceptance decision maker. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-06. local analytical objection: Collective scenarios remain incomplete and can hide strategic or environmental behaviour.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Locally passing agents are not assumed to establish a correct system.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: For one non-interacting component, collective assurance is not a separate activity.. ledger id: CS-044.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: strong distinction or conditional argument. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: FR-04.. empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-08; EV-13. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-06. analytical limit: Collective scenarios remain incomplete and can hide strategic or environmental behaviour... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Locally passing agents are not assumed to establish a correct system. — from the failure boundary — Collective scenarios remain incomplete and can hide strategic or environmental behaviour.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S039; AOSE-S015; AOSE-S023; AOSE-S050]

### EAOSE-045 — Explicit model and environment assumptions for formal assurance

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-045

**Disposition —** ASSUMPTION_SENSITIVE

**Mature form —** State the transition model, property, environmental alphabet, fairness or consistency conditions and abstraction boundary attached to a verification result.

**Controlled failure —** Proof strength can coexist with poor model validity; environmental events omitted from the alphabet remain uncontrolled.

**Trigger —** A proof or model-checking result supports acceptance.

**Non-trigger / cheap path —** Use bounded tests instead when formalisation costs exceed its decision value, while retaining uncertainty.

**Prerequisites —** property inputs: EAOSE-014; EAOSE-029; EAOSE-044. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Proof strength can coexist with poor model validity; environmental events omitted from the alphabet remain uncontrolled..

**Domain profile —** DOMAIN-PROFILE-O7 above; candidate application: Explicit model and environment assumptions for formal assurance. A proof over a finite or abstract model is not presented as a theorem about unrestricted deployment.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: A proof over a finite or abstract model is not presented as a theorem about unrestricted deployment. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Communication / operation —** content: State the transition model, property, environmental alphabet, fairness or consistency conditions and abstraction boundary attached to a verification result.. consumer: Tester, verification engineer and accountable acceptance decision maker. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-06. local analytical objection: Proof strength can coexist with poor model validity; environmental events omitted from the alphabet remain uncontrolled.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: A proof over a finite or abstract model is not presented as a theorem about unrestricted deployment.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Use bounded tests instead when formalisation costs exceed its decision value, while retaining uncertainty.. ledger id: CS-045.

**Conflicts / alternatives —** tension ids: T-02. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: strong distinction or conditional argument. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: FR-01; FR-02; FR-03; FR-05.. empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: EV-13. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-06. analytical limit: Proof strength can coexist with poor model validity; environmental events omitted from the alphabet remain uncontrolled... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — A proof over a finite or abstract model is not presented as a theorem about unrestricted deployment. — from the failure boundary — Proof strength can coexist with poor model validity; environmental events omitted from the alphabet remain uncontrolled.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S023; AOSE-S030; AOSE-S037; AOSE-S049]

### EAOSE-046 — Implementation-level decision-code verification

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-046

**Disposition —** DOMAIN_SPECIFIC

**Mature form —** Verify the executable rational decision component where the language and checker permit it, and separately discharge environment, continuous-control and abstraction obligations.

**Controlled failure —** Native libraries, numerical control, sensors and real-time deployment can remain outside the checker.

**Trigger —** Consequential agent decision code has suitable semantics and tractable state space.

**Non-trigger / cheap path —** Review, testing and restricted behaviour can be more proportionate for low-risk or unsupported implementations.

**Prerequisites —** property inputs: EAOSE-029; EAOSE-032; EAOSE-045. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Native libraries, numerical control, sensors and real-time deployment can remain outside the checker..

**Domain profile —** DOMAIN-PROFILE-O7 above; candidate application: Implementation-level decision-code verification. The abstract-design-to-decision-code gap is reduced without claiming the entire cyber-physical system has been proved.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: The abstract-design-to-decision-code gap is reduced without claiming the entire cyber-physical system has been proved. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Communication / operation —** content: Verify the executable rational decision component where the language and checker permit it, and separately discharge environment, continuous-control and abstraction obligations.. consumer: Tester, verification engineer and accountable acceptance decision maker. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-06. local analytical objection: Native libraries, numerical control, sensors and real-time deployment can remain outside the checker.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: The abstract-design-to-decision-code gap is reduced without claiming the entire cyber-physical system has been proved.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Review, testing and restricted behaviour can be more proportionate for low-risk or unsupported implementations.. ledger id: CS-046.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: strong distinction or conditional argument. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: FR-02.. empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: EV-13. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-06. analytical limit: Native libraries, numerical control, sensors and real-time deployment can remain outside the checker... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — The abstract-design-to-decision-code gap is reduced without claiming the entire cyber-physical system has been proved. — from the failure boundary — Native libraries, numerical control, sensors and real-time deployment can remain outside the checker.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S023]

### EAOSE-047 — Design-to-protocol consistency checks

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-047

**Disposition —** ASSUMPTION_SENSITIVE

**Mature form —** Check whether the detailed agent design supports the required interactions and whether its local choices violate the protocol constraints.

**Controlled failure —** The inspected design/protocol checker explicitly admits false positives and lacks an unconditional sound-and-complete claim because designs are partial; filtering a discrepancy requires inspecting the omitted plan semantics.

**Trigger —** Agent design and interaction specification are maintained as separate views.

**Non-trigger / cheap path —** A few explicit cross-view scenario checks can be adequate for a small design.

**Prerequisites —** property inputs: EAOSE-022; EAOSE-030; EAOSE-034. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. The inspected design/protocol checker explicitly admits false positives and lacks an unconditional sound-and-complete claim because designs are partial; filtering a discrepancy requires inspecting the omitted plan semantics..

**Domain profile —** DOMAIN-PROFILE-O7 above; candidate application: Design-to-protocol consistency checks. Inconsistent design choices are exposed before being mistaken for valid realisations.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Inconsistent design choices are exposed before being mistaken for valid realisations. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Communication / operation —** content: Check whether the detailed agent design supports the required interactions and whether its local choices violate the protocol constraints.. consumer: Tester, verification engineer and accountable acceptance decision maker. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-05. local analytical objection: The inspected design/protocol checker explicitly admits false positives and lacks an unconditional sound-and-complete claim because designs are partial; filtering a discrepancy requires inspecting the omitted plan semantics.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Inconsistent design choices are exposed before being mistaken for valid realisations.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A few explicit cross-view scenario checks can be adequate for a small design.. ledger id: CS-047.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: conditional defect-location rationale; not an unconditional sound/complete checker guarantee. scope: Partial design/protocol representations and reported false-positive limitations.. formal result ids: FR-06.. empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-06. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-05. analytical limit: The inspected design/protocol checker explicitly admits false positives and lacks an unconditional sound-and-complete claim because designs are partial; filtering a discrepancy requires inspecting the omitted plan semantics... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Inconsistent design choices are exposed before being mistaken for valid realisations. — from the failure boundary — The inspected design/protocol checker explicitly admits false positives and lacks an unconditional sound-and-complete claim because designs are partial; filtering a discrepancy requires inspecting the omitted plan semantics.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S054; AOSE-S007; AOSE-S015]

### EAOSE-048 — Oracle adequacy and false-success tests

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-048

**Disposition —** USEFUL_BUT_EASILY_GAMED

**Mature form —** Define what evidence would distinguish success, failure and uncertainty; challenge the oracle with false-success, omitted-condition and mutation cases.

**Controlled failure —** Mutation score, judge agreement and benchmark accuracy can reward proxies; equivalent mutants and incomplete requirements need judgement.

**Trigger —** Autonomous or stochastic behaviour lacks one obvious expected trace.

**Non-trigger / cheap path —** A simple exact assertion is sufficient for deterministic, fully specified output.

**Prerequisites —** property inputs: EAOSE-002; EAOSE-029; EAOSE-043. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Mutation score, judge agreement and benchmark accuracy can reward proxies; equivalent mutants and incomplete requirements need judgement..

**Domain profile —** DOMAIN-PROFILE-O7 above; candidate application: Oracle adequacy and false-success tests. A passing test has an interpretable claim boundary and known undetected cases.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: A passing test has an interpretable claim boundary and known undetected cases. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Communication / operation —** content: Define what evidence would distinguish success, failure and uncertainty; challenge the oracle with false-success, omitted-condition and mutation cases.. consumer: Tester, verification engineer and accountable acceptance decision maker. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-08; CR-17; CR-18. local analytical objection: Mutation score, judge agreement and benchmark accuracy can reward proxies; equivalent mutants and incomplete requirements need judgement.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: A passing test has an interpretable claim boundary and known undetected cases.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A simple exact assertion is sufficient for deterministic, fully specified output.. ledger id: CS-048.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-033. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: FR-04.. empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-07; EV-08; EV-14; EV-15; EV-16. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-08; CR-17; CR-18. analytical limit: Mutation score, judge agreement and benchmark accuracy can reward proxies; equivalent mutants and incomplete requirements need judgement... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — A passing test has an interpretable claim boundary and known undetected cases. — from the failure boundary — Mutation score, judge agreement and benchmark accuracy can reward proxies; equivalent mutants and incomplete requirements need judgement.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S031; AOSE-S024; AOSE-S048; AOSE-S050; AOSE-S061; AOSE-S062]

### EAOSE-049 — Simulation-to-deployment validity

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-049

**Disposition —** ASSUMPTION_SENSITIVE

**Mature form —** Identify which environmental dynamics, workloads and interactions a simulation represents; test material mismatches before transferring its conclusions to deployment.

**Controlled failure —** A richer simulator can still share the designer’s mistaken assumptions and conceal rare or strategic behaviours.

**Trigger —** Simulation evidence is used for an operational decision.

**Non-trigger / cheap path —** A small direct field test or conservative restriction can suffice when representative simulation is unavailable.

**Prerequisites —** property inputs: EAOSE-018; EAOSE-029; EAOSE-045. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. A richer simulator can still share the designer’s mistaken assumptions and conceal rare or strategic behaviours..

**Domain profile —** DOMAIN-PROFILE-O7 above; candidate application: Simulation-to-deployment validity. The evidence states what was simulated and what remains untested in the real setting.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: The evidence states what was simulated and what remains untested in the real setting. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Communication / operation —** content: Identify which environmental dynamics, workloads and interactions a simulation represents; test material mismatches before transferring its conclusions to deployment.. consumer: Tester, verification engineer and accountable acceptance decision maker. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-06. local analytical objection: A richer simulator can still share the designer’s mistaken assumptions and conceal rare or strategic behaviours.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: The evidence states what was simulated and what remains untested in the real setting.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A small direct field test or conservative restriction can suffice when representative simulation is unavailable.. ledger id: CS-049.

**Conflicts / alternatives —** tension ids: T-08. relation ids: REL-033. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: strong distinction or conditional argument. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: FR-03.. empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: EV-13. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-06. analytical limit: A richer simulator can still share the designer’s mistaken assumptions and conceal rare or strategic behaviours... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — The evidence states what was simulated and what remains untested in the real setting. — from the failure boundary — A richer simulator can still share the designer’s mistaken assumptions and conceal rare or strategic behaviours.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S012; AOSE-S022; AOSE-S030]

### EAOSE-050 — Discriminating fault and perturbation testing

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-050

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Inject or construct relevant faults at agent, interaction, tool and environment boundaries, compare with a baseline and inspect how errors propagate.

**Controlled failure —** Synthetic faults are not incidence estimates; stochastic variance and instrumentation overhead can confound effects.

**Trigger —** A known failure class or dependence could invalidate a consequential requirement.

**Non-trigger / cheap path —** One targeted adverse case is preferable to an undirected stress campaign when it discriminates the decision.

**Prerequisites —** property inputs: EAOSE-025; EAOSE-044; EAOSE-048; EAOSE-049. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Synthetic faults are not incidence estimates; stochastic variance and instrumentation overhead can confound effects..

**Domain profile —** DOMAIN-PROFILE-O7 above; candidate application: Discriminating fault and perturbation testing. The result identifies a controlled perturbation and its observed effect, not merely a final score.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: The result identifies a controlled perturbation and its observed effect, not merely a final score. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Communication / operation —** content: Inject or construct relevant faults at agent, interaction, tool and environment boundaries, compare with a baseline and inspect how errors propagate.. consumer: Tester, verification engineer and accountable acceptance decision maker. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-08. local analytical objection: Synthetic faults are not incidence estimates; stochastic variance and instrumentation overhead can confound effects.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: The result identifies a controlled perturbation and its observed effect, not merely a final score.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: One targeted adverse case is preferable to an undirected stress campaign when it discriminates the decision.. ledger id: CS-050.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-033. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-07; EV-08; EV-09. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-08. analytical limit: Synthetic faults are not incidence estimates; stochastic variance and instrumentation overhead can confound effects... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — The result identifies a controlled perturbation and its observed effect, not merely a final score. — from the failure boundary — Synthetic faults are not incidence estimates; stochastic variance and instrumentation overhead can confound effects.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S031; AOSE-S035; AOSE-S050]

### EAOSE-051 — Runtime observations linked to assurance claims

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-051

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Collect observations that can confirm, challenge or suspend specific behavioural claims; distinguish a recorded event from a correct interpretation or achieved outcome.

**Controlled failure —** Monitoring can miss events, disclose sensitive data or add overhead; a dashboard without response duties is ceremony.

**Trigger —** Relevant behaviour or assumptions cannot be fully established before deployment.

**Non-trigger / cheap path —** Observe a small set of consequential boundaries rather than logging every internal step.

**Prerequisites —** property inputs: EAOSE-029; EAOSE-034; EAOSE-044; EAOSE-048. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Monitoring can miss events, disclose sensitive data or add overhead; a dashboard without response duties is ceremony..

**Domain profile —** DOMAIN-PROFILE-O7 above; candidate application: Runtime observations linked to assurance claims. A failed observation has a defined consumer and can change an operational or engineering decision.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: A failed observation has a defined consumer and can change an operational or engineering decision. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Communication / operation —** content: Collect observations that can confirm, challenge or suspend specific behavioural claims; distinguish a recorded event from a correct interpretation or achieved outcome.. consumer: Tester, verification engineer and accountable acceptance decision maker. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-08; CR-15. local analytical objection: Monitoring can miss events, disclose sensitive data or add overhead; a dashboard without response duties is ceremony.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: A failed observation has a defined consumer and can change an operational or engineering decision.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Observe a small set of consequential boundaries rather than logging every internal step.. ledger id: CS-051.

**Conflicts / alternatives —** tension ids: T-08. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-08; EV-09. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-08; CR-15. analytical limit: Monitoring can miss events, disclose sensitive data or add overhead; a dashboard without response duties is ceremony... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — A failed observation has a defined consumer and can change an operational or engineering decision. — from the failure boundary — Monitoring can miss events, disclose sensitive data or add overhead; a dashboard without response duties is ceremony.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S029; AOSE-S035; AOSE-S044; AOSE-S050]

### EAOSE-053 — Deployment and legacy-integration obligations

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-053

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Carry responsibility for configuration, resource access, existing services, operational ownership and failure handling beyond design and code generation.

**Controlled failure —** Adding an agent middleware layer can increase interoperability and maintenance burden; platform deployment is not service readiness.

**Trigger —** An agent application enters an existing operational environment.

**Non-trigger / cheap path —** Reuse an established deployment process and explicit interface contract where adequate.

**Prerequisites —** property inputs: EAOSE-025; EAOSE-029; EAOSE-033. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. Adding an agent middleware layer can increase interoperability and maintenance burden; platform deployment is not service readiness..

**Domain profile —** DOMAIN-PROFILE-O8 above; candidate application: Deployment and legacy-integration obligations. The deployment has responsible operators and tested integration boundaries rather than only runnable agent code.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: The deployment has responsible operators and tested integration boundaries rather than only runnable agent code. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Engineers, operators, affected users and authorised change/retirement decision makers. boundary: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules..

**Communication / operation —** content: Carry responsibility for configuration, resource access, existing services, operational ownership and failure handling beyond design and code generation.. consumer: Engineers, operators, affected users and authorised change/retirement decision makers. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-09. local analytical objection: Adding an agent middleware layer can increase interoperability and maintenance burden; platform deployment is not service readiness.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: The deployment has responsible operators and tested integration boundaries rather than only runnable agent code.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Reuse an established deployment process and explicit interface contract where adequate.. ledger id: CS-053.

**Conflicts / alternatives —** tension ids: T-03. relation ids: REL-034. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-03. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: reported and context-bound, not causal attribution. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-09. analytical limit: Adding an agent middleware layer can increase interoperability and maintenance burden; platform deployment is not service readiness... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — The deployment has responsible operators and tested integration boundaries rather than only runnable agent code. — from the failure boundary — Adding an agent middleware layer can increase interoperability and maintenance burden; platform deployment is not service readiness.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S039; AOSE-S026; AOSE-S029; AOSE-S044]

### EAOSE-054 — Versioned implementation and configuration evidence

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-054

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Identify the code, models, tool adapters, dependencies, configuration and evaluation conditions to which an assurance claim applies.

**Controlled failure —** External services may change despite stable names; a hash proves identity, not correctness or reproducibility of stochastic output.

**Trigger —** A result must be reproduced, compared, rolled out or used after a change.

**Non-trigger / cheap path —** One build identifier and configuration snapshot can suffice for a small fixed system.

**Prerequisites —** property inputs: EAOSE-026; EAOSE-034; EAOSE-048; EAOSE-053. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. External services may change despite stable names; a hash proves identity, not correctness or reproducibility of stochastic output..

**Domain profile —** DOMAIN-PROFILE-O8 above; candidate application: Versioned implementation and configuration evidence. Evidence can be associated with the actual evaluated configuration rather than an unspecified product name.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Evidence can be associated with the actual evaluated configuration rather than an unspecified product name. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Engineers, operators, affected users and authorised change/retirement decision makers. boundary: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules..

**Communication / operation —** content: Identify the code, models, tool adapters, dependencies, configuration and evaluation conditions to which an assurance claim applies.. consumer: Engineers, operators, affected users and authorised change/retirement decision makers. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-09; CR-15. local analytical objection: External services may change despite stable names; a hash proves identity, not correctness or reproducibility of stochastic output.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Evidence can be associated with the actual evaluated configuration rather than an unspecified product name.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: One build identifier and configuration snapshot can suffice for a small fixed system.. ledger id: CS-054.

**Conflicts / alternatives —** tension ids: T-09. relation ids: REL-034. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-09; EV-12; EV-14. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-09; CR-15. analytical limit: External services may change despite stable names; a hash proves identity, not correctness or reproducibility of stochastic output... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Evidence can be associated with the actual evaluated configuration rather than an unspecified product name. — from the failure boundary — External services may change despite stable names; a hash proves identity, not correctness or reproducibility of stochastic output.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S029; AOSE-S035; AOSE-S036; AOSE-S048; AOSE-S057]

### EAOSE-055 — Operational feedback to maintained engineering models

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-055

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Route observed failures, changing use and resource constraints to the requirements, role, protocol or plan assumptions that need revision; retain only models with a live maintenance consumer.

**Controlled failure —** Correlational traces do not by themselves establish root cause; automatic synchronisation can overwrite a sound specification with faulty behaviour.

**Trigger —** The deployed system behaves differently from its engineering assumptions.

**Non-trigger / cheap path —** A short incident-to-requirement link can replace continuous model synchronisation.

**Prerequisites —** property inputs: EAOSE-006; EAOSE-034; EAOSE-051; EAOSE-054. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. Correlational traces do not by themselves establish root cause; automatic synchronisation can overwrite a sound specification with faulty behaviour..

**Domain profile —** DOMAIN-PROFILE-O8 above; candidate application: Operational feedback to maintained engineering models. Operational lessons can change design and acceptance rather than accumulating as disconnected logs.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Operational lessons can change design and acceptance rather than accumulating as disconnected logs. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Engineers, operators, affected users and authorised change/retirement decision makers. boundary: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules..

**Communication / operation —** content: Route observed failures, changing use and resource constraints to the requirements, role, protocol or plan assumptions that need revision; retain only models with a live maintenance consumer.. consumer: Engineers, operators, affected users and authorised change/retirement decision makers. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-09. local analytical objection: Correlational traces do not by themselves establish root cause; automatic synchronisation can overwrite a sound specification with faulty behaviour.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Operational lessons can change design and acceptance rather than accumulating as disconnected logs.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A short incident-to-requirement link can replace continuous model synchronisation.. ledger id: CS-055.

**Conflicts / alternatives —** tension ids: T-08. relation ids: REL-034. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-07; EV-09. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-09. analytical limit: Correlational traces do not by themselves establish root cause; automatic synchronisation can overwrite a sound specification with faulty behaviour... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Operational lessons can change design and acceptance rather than accumulating as disconnected logs. — from the failure boundary — Correlational traces do not by themselves establish root cause; automatic synchronisation can overwrite a sound specification with faulty behaviour.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S029; AOSE-S031; AOSE-S035]

### EAOSE-056 — Authorised evolution within explicit revision boundaries

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-056

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Specify which goals, assignments, plans or interfaces may change at runtime, who may approve broader revision and which obligations remain invariant.

**Controlled failure —** A policy can authorise harmful changes if its own premise is wrong; runtime governance cannot create external consent.

**Trigger —** A system adapts or a team changes an autonomous component after acceptance.

**Non-trigger / cheap path —** Disable dynamic adaptation or require an ordinary reviewed release where that is adequate.

**Prerequisites —** property inputs: EAOSE-005; EAOSE-006; EAOSE-010; EAOSE-017; EAOSE-054. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. A policy can authorise harmful changes if its own premise is wrong; runtime governance cannot create external consent..

**Domain profile —** DOMAIN-PROFILE-O8 above; candidate application: Authorised evolution within explicit revision boundaries. Adaptive choice does not silently acquire authority to redefine its own acceptance conditions.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Adaptive choice does not silently acquire authority to redefine its own acceptance conditions. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Engineers, operators, affected users and authorised change/retirement decision makers. boundary: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules..

**Communication / operation —** content: Specify which goals, assignments, plans or interfaces may change at runtime, who may approve broader revision and which obligations remain invariant.. consumer: Engineers, operators, affected users and authorised change/retirement decision makers. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-09; CR-14. local analytical objection: A policy can authorise harmful changes if its own premise is wrong; runtime governance cannot create external consent.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Adaptive choice does not silently acquire authority to redefine its own acceptance conditions.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Disable dynamic adaptation or require an ordinary reviewed release where that is adequate.. ledger id: CS-056.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-020; REL-034. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-12. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-09; CR-14. analytical limit: A policy can authorise harmful changes if its own premise is wrong; runtime governance cannot create external consent... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Adaptive choice does not silently acquire authority to redefine its own acceptance conditions. — from the failure boundary — A policy can authorise harmful changes if its own premise is wrong; runtime governance cannot create external consent.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S009; AOSE-S016; AOSE-S029; AOSE-S038; AOSE-S057]

### EAOSE-057 — Selective assurance revalidation after change

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-057

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Trace a change to the claims, assumptions and evidence it affects; retain unaffected evidence, narrow conditional claims and re-establish or withdraw those whose justification no longer applies.

**Controlled failure —** Dependency maps can omit indirect effects; indiscriminate reuse and indiscriminate invalidation are both failures.

**Trigger —** Code, environment, goals, protocols or underlying services change.

**Non-trigger / cheap path —** A direct impact judgement is enough for a small change; unchanged justified claims do not require blanket retesting.

**Prerequisites —** property inputs: EAOSE-006; EAOSE-034; EAOSE-045; EAOSE-054; EAOSE-055; EAOSE-056. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. Dependency maps can omit indirect effects; indiscriminate reuse and indiscriminate invalidation are both failures..

**Domain profile —** DOMAIN-PROFILE-O8 above; candidate application: Selective assurance revalidation after change. Each relied-on affected claim has an explicit retained, narrowed, reassessed or withdrawn status.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Each relied-on affected claim has an explicit retained, narrowed, reassessed or withdrawn status. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Engineers, operators, affected users and authorised change/retirement decision makers. boundary: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules..

**Communication / operation —** content: Trace a change to the claims, assumptions and evidence it affects; retain unaffected evidence, narrow conditional claims and re-establish or withdraw those whose justification no longer applies.. consumer: Engineers, operators, affected users and authorised change/retirement decision makers. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-09; CR-15. local analytical objection: Dependency maps can omit indirect effects; indiscriminate reuse and indiscriminate invalidation are both failures.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Each relied-on affected claim has an explicit retained, narrowed, reassessed or withdrawn status.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A direct impact judgement is enough for a small change; unchanged justified claims do not require blanket retesting.. ledger id: CS-057.

**Conflicts / alternatives —** tension ids: T-09. relation ids: REL-020; REL-034. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-06; EV-07; EV-12. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-09; CR-15. analytical limit: Dependency maps can omit indirect effects; indiscriminate reuse and indiscriminate invalidation are both failures... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Each relied-on affected claim has an explicit retained, narrowed, reassessed or withdrawn status. — from the failure boundary — Dependency maps can omit indirect effects; indiscriminate reuse and indiscriminate invalidation are both failures.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S029; AOSE-S031; AOSE-S054; AOSE-S057]

### EAOSE-058 — Retirement preserves or resolves outstanding obligations

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-058

**Disposition —** CONTEXT_DEPENDENT

**Mature form —** Before removing an agent, service or interface, identify unfinished commitments and dependent work; complete, transfer with valid authority, release or explicitly report inability to fulfil them.

**Controlled failure —** Transfer can require another party’s agreement; compensating action may be impossible or inadequate.

**Trigger —** A component, capability or protocol is withdrawn while others may still rely on it.

**Non-trigger / cheap path —** Immediate removal is sufficient when there are demonstrably no live obligations or dependencies.

**Prerequisites —** property inputs: EAOSE-003; EAOSE-023; EAOSE-025; EAOSE-053; EAOSE-056. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. Transfer can require another party’s agreement; compensating action may be impossible or inadequate..

**Domain profile —** DOMAIN-PROFILE-O8 above; candidate application: Retirement preserves or resolves outstanding obligations. Retirement does not falsely convert an outstanding obligation into successful completion.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Retirement does not falsely convert an outstanding obligation into successful completion. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Engineers, operators, affected users and authorised change/retirement decision makers. boundary: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules..

**Communication / operation —** content: Before removing an agent, service or interface, identify unfinished commitments and dependent work; complete, transfer with valid authority, release or explicitly report inability to fulfil them.. consumer: Engineers, operators, affected users and authorised change/retirement decision makers. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-09; CR-14. local analytical objection: Transfer can require another party’s agreement; compensating action may be impossible or inadequate.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Retirement does not falsely convert an outstanding obligation into successful completion.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Immediate removal is sufficient when there are demonstrably no live obligations or dependencies.. ledger id: CS-058.

**Conflicts / alternatives —** tension ids: T-06. relation ids: REL-008; REL-034. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-05; EV-13. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-09; CR-14. analytical limit: Transfer can require another party’s agreement; compensating action may be impossible or inadequate... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Retirement does not falsely convert an outstanding obligation into successful completion. — from the failure boundary — Transfer can require another party’s agreement; compensating action may be impossible or inadequate.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S023; AOSE-S037; AOSE-S029; AOSE-S045]

### EAOSE-060 — Separate demonstrated mechanism, deployment and comparative benefit

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-060

**Disposition —** STRONGLY_RETAINED

**Mature form —** Classify evidence by what its unit and design establish: formal result, illustrative model, implemented prototype, operational use or controlled comparison; do not promote one category into another.

**Controlled failure —** Overly strict demands for controlled trials can obscure useful field learning; evidence can justify conditional action without proving superiority.

**Trigger —** A method, platform or application is being justified by published evidence.

**Non-trigger / cheap path —** A short claim–evidence statement is enough for an uncontroversial local choice.

**Prerequisites —** property inputs: None, subject to the stated absence explanation.. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can classify reported evidence and limitations; cannot substitute application counts for causal authorisation or adoption decisions. Overly strict demands for controlled trials can obscure useful field learning; evidence can justify conditional action without proving superiority.. absence reason: This is a boundary/selection inquiry or independently posed candidate; it has no mandatory earlier property in this corpus..

**Domain profile —** DOMAIN-PROFILE-O9 above; candidate application: Separate demonstrated mechanism, deployment and comparative benefit. A deployed application is not reported as a causal test of an entire named methodology.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: A deployed application is not reported as a causal test of an entire named methodology. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Evaluator and reader making a benefit/adoption judgement. boundary: Can classify reported evidence and limitations; cannot substitute application counts for causal authorisation or adoption decisions..

**Communication / operation —** content: Classify evidence by what its unit and design establish: formal result, illustrative model, implemented prototype, operational use or controlled comparison; do not promote one category into another.. consumer: Evaluator and reader making a benefit/adoption judgement. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-10; CR-17; CR-18. local analytical objection: Overly strict demands for controlled trials can obscure useful field learning; evidence can justify conditional action without proving superiority.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: A deployed application is not reported as a causal test of an entire named methodology.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A short claim–evidence statement is enough for an uncontroversial local choice.. ledger id: CS-060.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-021. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: strong distinction or conditional argument. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-01; EV-03; EV-04; EV-05; EV-15; EV-16. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: reported and context-bound, not causal attribution. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-10; CR-17; CR-18. analytical limit: Overly strict demands for controlled trials can obscure useful field learning; evidence can justify conditional action without proving superiority... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — A deployed application is not reported as a causal test of an entire named methodology. — from the failure boundary — Overly strict demands for controlled trials can obscure useful field learning; evidence can justify conditional action without proving superiority.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S045; AOSE-S046; AOSE-S061; AOSE-S062]

### EAOSE-061 — Cost attribution and source non-independence

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-061

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Record comparison units, denominators, training, tool bundles and shared datasets or industrial programmes; separate independent replications from repeated reports of the same case.

**Controlled failure —** Missing cost data, selection and publication bias limit both positive and negative generalisation.

**Trigger —** Several studies or large reported gains support a general engineering-benefit claim.

**Non-trigger / cheap path —** A transparent single-case rationale can support a narrow reversible decision without inventing generality.

**Prerequisites —** property inputs: EAOSE-011; EAOSE-060. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can classify reported evidence and limitations; cannot substitute application counts for causal authorisation or adoption decisions. Missing cost data, selection and publication bias limit both positive and negative generalisation..

**Domain profile —** DOMAIN-PROFILE-O9 above; candidate application: Cost attribution and source non-independence. Reported benefit is bounded by the comparator, setting and dependence structure of the evidence.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Reported benefit is bounded by the comparator, setting and dependence structure of the evidence. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Evaluator and reader making a benefit/adoption judgement. boundary: Can classify reported evidence and limitations; cannot substitute application counts for causal authorisation or adoption decisions..

**Communication / operation —** content: Record comparison units, denominators, training, tool bundles and shared datasets or industrial programmes; separate independent replications from repeated reports of the same case.. consumer: Evaluator and reader making a benefit/adoption judgement. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-10; CR-17. local analytical objection: Missing cost data, selection and publication bias limit both positive and negative generalisation.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Reported benefit is bounded by the comparator, setting and dependence structure of the evidence.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A transparent single-case rationale can support a narrow reversible decision without inventing generality.. ledger id: CS-061.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-021. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-01; EV-03; EV-04; EV-05; EV-14; EV-15. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: reported and context-bound, not causal attribution. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-10; CR-17. analytical limit: Missing cost data, selection and publication bias limit both positive and negative generalisation... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Reported benefit is bounded by the comparator, setting and dependence structure of the evidence. — from the failure boundary — Missing cost data, selection and publication bias limit both positive and negative generalisation.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S045; AOSE-S048; AOSE-S061]

### EAOSE-065 — Documented continuity rather than retrospective rebranding

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-065

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Trace explicit imports of agent, organisation, protocol or programming semantics into modern systems; label shared problems or similar vocabulary as convergence unless transmission is documented.

**Controlled failure —** A citation proves acquaintance rather than semantic fidelity; absence of explicit citation does not prove independence.

**Trigger —** A modern agent framework is described as inheriting established AOSE.

**Non-trigger / cheap path —** Describe the actual mechanism without claiming an ancestry that cannot be established.

**Prerequisites —** property inputs: None, subject to the stated absence explanation.. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. A citation proves acquaintance rather than semantic fidelity; absence of explicit citation does not prove independence.. absence reason: This is a boundary/selection inquiry or independently posed candidate; it has no mandatory earlier property in this corpus..

**Domain profile —** DOMAIN-PROFILE-O10 above; candidate application: Documented continuity rather than retrospective rebranding. Historical inheritance, documented hybridisation and analogy remain distinguishable.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Historical inheritance, documented hybridisation and analogy remain distinguishable. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Hybrid-system engineer, operator, task owner and affected principals. boundary: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation..

**Communication / operation —** content: Trace explicit imports of agent, organisation, protocol or programming semantics into modern systems; label shared problems or similar vocabulary as convergence unless transmission is documented.. consumer: Hybrid-system engineer, operator, task owner and affected principals. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-11. local analytical objection: A citation proves acquaintance rather than semantic fidelity; absence of explicit citation does not prove independence.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Historical inheritance, documented hybridisation and analogy remain distinguishable.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Describe the actual mechanism without claiming an ancestry that cannot be established.. ledger id: CS-065.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-022. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: moderate with a bounded access limitation. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-11. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-11. analytical limit: A citation proves acquaintance rather than semantic fidelity; absence of explicit citation does not prove independence... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Historical inheritance, documented hybridisation and analogy remain distinguishable. — from the failure boundary — A citation proves acquaintance rather than semantic fidelity; absence of explicit citation does not prove independence.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S005; AOSE-S028; AOSE-S036; AOSE-S051; AOSE-S052; AOSE-S056]

### EAOSE-066 — Cost-aware and repeatable stochastic evaluation

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-066

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Evaluate repeated executions with declared model/configuration, task distribution, budget and uncertainty; compare simpler baselines rather than reporting only best-run task success.

**Controlled failure —** Benchmarks can be contaminated or overfit; model aliases and changing services can defeat exact repeatability.

**Trigger —** Learned or remote components vary across executions or consume material inference resources.

**Non-trigger / cheap path —** An exact deterministic regression is sufficient for a component with no relevant stochasticity.

**Prerequisites —** property inputs: EAOSE-011; EAOSE-048; EAOSE-054; EAOSE-061. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. Benchmarks can be contaminated or overfit; model aliases and changing services can defeat exact repeatability..

**Domain profile —** DOMAIN-PROFILE-O10 above; candidate application: Cost-aware and repeatable stochastic evaluation. Claims separate task success, variability, cost and generalisation to unseen work.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Claims separate task success, variability, cost and generalisation to unseen work. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Hybrid-system engineer, operator, task owner and affected principals. boundary: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation..

**Communication / operation —** content: Evaluate repeated executions with declared model/configuration, task distribution, budget and uncertainty; compare simpler baselines rather than reporting only best-run task success.. consumer: Hybrid-system engineer, operator, task owner and affected principals. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-08; CR-16; CR-17. local analytical objection: Benchmarks can be contaminated or overfit; model aliases and changing services can defeat exact repeatability.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Claims separate task success, variability, cost and generalisation to unseen work.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: An exact deterministic regression is sufficient for a component with no relevant stochasticity.. ledger id: CS-066.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-08; EV-09; EV-11; EV-14; EV-15. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-08; CR-16; CR-17. analytical limit: Benchmarks can be contaminated or overfit; model aliases and changing services can defeat exact repeatability... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Claims separate task success, variability, cost and generalisation to unseen work. — from the failure boundary — Benchmarks can be contaminated or overfit; model aliases and changing services can defeat exact repeatability.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S048; AOSE-S047; AOSE-S050; AOSE-S035; AOSE-S056; AOSE-S061]

### EAOSE-067 — Generated plans remain subject to executable constraints

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-067

**Disposition —** ASSUMPTION_SENSITIVE

**Mature form —** Require generated candidate plans to meet the selected language semantics, applicability and authority constraints before execution; distinguish formal strategy synthesis from language-model suggestion.

**Controlled failure —** Validation can check only the encoded constraints; learned grounding and environmental action models can remain wrong.

**Trigger —** A planner or learned model generates or revises executable behaviour.

**Non-trigger / cheap path —** Keep a verified finite plan library or require manual selection when generation offers no justified benefit.

**Prerequisites —** property inputs: EAOSE-005; EAOSE-030; EAOSE-032; EAOSE-045; EAOSE-056. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. Validation can check only the encoded constraints; learned grounding and environmental action models can remain wrong..

**Domain profile —** DOMAIN-PROFILE-O10 above; candidate application: Generated plans remain subject to executable constraints. Plausible natural-language plans are not treated as executable specifications or accepted proofs.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Plausible natural-language plans are not treated as executable specifications or accepted proofs. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Hybrid-system engineer, operator, task owner and affected principals. boundary: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation..

**Communication / operation —** content: Require generated candidate plans to meet the selected language semantics, applicability and authority constraints before execution; distinguish formal strategy synthesis from language-model suggestion.. consumer: Hybrid-system engineer, operator, task owner and affected principals. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-11; CR-16; CR-18. local analytical objection: Validation can check only the encoded constraints; learned grounding and environmental action models can remain wrong.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Plausible natural-language plans are not treated as executable specifications or accepted proofs.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Keep a verified finite plan library or require manual selection when generation offers no justified benefit.. ledger id: CS-067.

**Conflicts / alternatives —** tension ids: T-02; T-10. relation ids: REL-022; REL-023. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: strong distinction or conditional argument. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: FR-05.. empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-07; EV-11; EV-12; EV-13; EV-16. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-11; CR-16; CR-18. analytical limit: Validation can check only the encoded constraints; learned grounding and environmental action models can remain wrong... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Plausible natural-language plans are not treated as executable specifications or accepted proofs. — from the failure boundary — Validation can check only the encoded constraints; learned grounding and environmental action models can remain wrong.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S049; AOSE-S052; AOSE-S031; AOSE-S037; AOSE-S057; AOSE-S056; AOSE-S062]

### EAOSE-068 — Tool authority is enforced outside untrusted generated instructions

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-068

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Treat model-generated tool requests and retrieved instructions as proposals crossing a privilege boundary; enforce allowed operations and arguments independently of prompt compliance.

**Controlled failure —** A narrow authorised call can still be harmful or based on false data; wrappers require their own correctness and threat analysis.

**Trigger —** A learned agent can invoke tools or consume untrusted external content.

**Non-trigger / cheap path —** Read-only tools, a narrow deterministic adapter or explicit approval can eliminate unnecessary delegated power.

**Prerequisites —** property inputs: EAOSE-005; EAOSE-010; EAOSE-029; EAOSE-056. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. A narrow authorised call can still be harmful or based on false data; wrappers require their own correctness and threat analysis..

**Domain profile —** DOMAIN-PROFILE-O10 above; candidate application: Tool authority is enforced outside untrusted generated instructions. Persuasive or injected text cannot itself widen tool permissions.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Persuasive or injected text cannot itself widen tool permissions. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Hybrid-system engineer, operator, task owner and affected principals. boundary: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation..

**Communication / operation —** content: Treat model-generated tool requests and retrieved instructions as proposals crossing a privilege boundary; enforce allowed operations and arguments independently of prompt compliance.. consumer: Hybrid-system engineer, operator, task owner and affected principals. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-11; CR-14. local analytical objection: A narrow authorised call can still be harmful or based on false data; wrappers require their own correctness and threat analysis.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Persuasive or injected text cannot itself widen tool permissions.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Read-only tools, a narrow deterministic adapter or explicit approval can eliminate unnecessary delegated power.. ledger id: CS-068.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-022. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-09; EV-10. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-11; CR-14. analytical limit: A narrow authorised call can still be harmful or based on false data; wrappers require their own correctness and threat analysis... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Persuasive or injected text cannot itself widen tool permissions. — from the failure boundary — A narrow authorised call can still be harmful or based on false data; wrappers require their own correctness and threat analysis.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S038; AOSE-S053; AOSE-S035]

### EAOSE-069 — Memory and retrieved-content provenance boundaries

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-069

**Disposition —** CONTEXT_DEPENDENT

**Mature form —** Distinguish instructions, observations and stored interpretations; preserve origin and revision context where later action relies on memory, and prevent recalled content from automatically becoming authority.

**Controlled failure —** The inspected evidence is stronger for untrusted tool outputs than for long-term memory governance; privacy, staleness and poisoning need separate validation.

**Trigger —** A learned agent reuses prior or externally retrieved information across tasks or sessions.

**Non-trigger / cheap path —** No persistent memory, or a small typed state record, may be safer and cheaper.

**Prerequisites —** property inputs: EAOSE-029; EAOSE-054; EAOSE-068. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. The inspected evidence is stronger for untrusted tool outputs than for long-term memory governance; privacy, staleness and poisoning need separate validation..

**Domain profile —** DOMAIN-PROFILE-O10 above; candidate application: Memory and retrieved-content provenance boundaries. A recalled assertion can be checked against its origin and does not silently override a trusted constraint.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: A recalled assertion can be checked against its origin and does not silently override a trusted constraint. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Hybrid-system engineer, operator, task owner and affected principals. boundary: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation..

**Communication / operation —** content: Distinguish instructions, observations and stored interpretations; preserve origin and revision context where later action relies on memory, and prevent recalled content from automatically becoming authority.. consumer: Hybrid-system engineer, operator, task owner and affected principals. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-11; CR-18. local analytical objection: The inspected evidence is stronger for untrusted tool outputs than for long-term memory governance; privacy, staleness and poisoning need separate validation.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: A recalled assertion can be checked against its origin and does not silently override a trusted constraint.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: No persistent memory, or a small typed state record, may be safer and cheaper.. ledger id: CS-069.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-08; EV-09; EV-10; EV-16. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-11; CR-18. analytical limit: The inspected evidence is stronger for untrusted tool outputs than for long-term memory governance; privacy, staleness and poisoning need separate validation... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — A recalled assertion can be checked against its origin and does not silently override a trusted constraint. — from the failure boundary — The inspected evidence is stronger for untrusted tool outputs than for long-term memory governance; privacy, staleness and poisoning need separate validation.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S053; AOSE-S050; AOSE-S035; AOSE-S062]

### EAOSE-070 — Regression after model, prompt or remote-service changes

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-070

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Treat material changes to models, prompts, tools and remote dependencies as changes to an evaluated configuration; reassess affected behaviour rather than inheriting old benchmark claims unchanged.

**Controlled failure —** Providers may not expose meaningful versions; repeat testing reduces but does not eliminate stochastic uncertainty.

**Trigger —** A learned component or externally controlled dependency is updated.

**Non-trigger / cheap path —** No blanket rerun when a documented impact analysis shows the relevant behaviour unaffected.

**Prerequisites —** property inputs: EAOSE-054; EAOSE-057; EAOSE-066. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. Providers may not expose meaningful versions; repeat testing reduces but does not eliminate stochastic uncertainty..

**Domain profile —** DOMAIN-PROFILE-O10 above; candidate application: Regression after model, prompt or remote-service changes. The assurance statement identifies the configuration actually evaluated and the residual uncertainty of remote drift.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: The assurance statement identifies the configuration actually evaluated and the residual uncertainty of remote drift. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Hybrid-system engineer, operator, task owner and affected principals. boundary: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation..

**Communication / operation —** content: Treat material changes to models, prompts, tools and remote dependencies as changes to an evaluated configuration; reassess affected behaviour rather than inheriting old benchmark claims unchanged.. consumer: Hybrid-system engineer, operator, task owner and affected principals. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-11; CR-16. local analytical objection: Providers may not expose meaningful versions; repeat testing reduces but does not eliminate stochastic uncertainty.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: The assurance statement identifies the configuration actually evaluated and the residual uncertainty of remote drift.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: No blanket rerun when a documented impact analysis shows the relevant behaviour unaffected.. ledger id: CS-070.

**Conflicts / alternatives —** tension ids: T-09. relation ids: REL-022; REL-023. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-08; EV-09; EV-11; EV-12; EV-14. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-11; CR-16. analytical limit: Providers may not expose meaningful versions; repeat testing reduces but does not eliminate stochastic uncertainty... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — The assurance statement identifies the configuration actually evaluated and the residual uncertainty of remote drift. — from the failure boundary — Providers may not expose meaningful versions; repeat testing reduces but does not eliminate stochastic uncertainty.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S048; AOSE-S035; AOSE-S029; AOSE-S050; AOSE-S057; AOSE-S056]

### EAOSE-071 — Cross-agent trace correlation for diagnosis

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-071

**Disposition —** CONTEXT_DEPENDENT

**Mature form —** Link agent steps, sends/receives, tool calls and model invocations to task and configuration identifiers so an observed failure can be located across boundaries.

**Controlled failure —** Trace completeness, privacy, storage and instrumentation cost matter; missing spans and varying runs can mislead diagnosis.

**Trigger —** Distributed or stochastic execution obscures where a requirement was lost.

**Non-trigger / cheap path —** A local error report is enough when one component and one direct effect make the failure unambiguous.

**Prerequisites —** property inputs: EAOSE-021; EAOSE-051; EAOSE-054; EAOSE-066. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. Trace completeness, privacy, storage and instrumentation cost matter; missing spans and varying runs can mislead diagnosis..

**Domain profile —** DOMAIN-PROFILE-O10 above; candidate application: Cross-agent trace correlation for diagnosis. An investigator can relate an outcome to the relevant interaction without treating correlation as a causal proof.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: An investigator can relate an outcome to the relevant interaction without treating correlation as a causal proof. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Hybrid-system engineer, operator, task owner and affected principals. boundary: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation..

**Communication / operation —** content: Link agent steps, sends/receives, tool calls and model invocations to task and configuration identifiers so an observed failure can be located across boundaries.. consumer: Hybrid-system engineer, operator, task owner and affected principals. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-11; CR-15. local analytical objection: Trace completeness, privacy, storage and instrumentation cost matter; missing spans and varying runs can mislead diagnosis.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: An investigator can relate an outcome to the relevant interaction without treating correlation as a causal proof.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A local error report is enough when one component and one direct effect make the failure unambiguous.. ledger id: CS-071.

**Conflicts / alternatives —** tension ids: T-09. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-08; EV-09. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-11; CR-15. analytical limit: Trace completeness, privacy, storage and instrumentation cost matter; missing spans and varying runs can mislead diagnosis... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — An investigator can relate an outcome to the relevant interaction without treating correlation as a causal proof. — from the failure boundary — Trace completeness, privacy, storage and instrumentation cost matter; missing spans and varying runs can mislead diagnosis.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S035; AOSE-S050]

### EAOSE-073 — Criterion–authority–effect coupling

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-073

**Disposition —** RETAINED_IN_EVOLVED_FORM

**Mature form —** Join requirement relevance, permitted action and evidence of consequence at the same consequential decision; a defect in any view can block or reopen conclusions in the others. Before acting, distinguish warranted predictions and authorised experiments from the observations required for subsequent outcome acceptance; uncertainty is not silently converted into success.

**Controlled failure —** The relation is an analytical engineering constraint, not a new academic theorem or automatic causal-attribution mechanism; complete evidence may be unavailable.

**Trigger —** Separate correct-looking goal, permission and outcome judgements can jointly admit an unjustified action or acceptance.

**Non-trigger / cheap path —** One direct contract and result check suffice when all three distinctions are already coupled transparently.

**Prerequisites —** property inputs: EAOSE-002; EAOSE-005; EAOSE-023; EAOSE-029; EAOSE-043; EAOSE-048. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power. The relation is an analytical engineering constraint, not a new academic theorem or automatic causal-attribution mechanism; complete evidence may be unavailable..

**Domain profile —** DOMAIN-PROFILE-COMPOSITION above; candidate application: Criterion–authority–effect coupling. No goal, permission or observed benefit substitutes for either of the other two; a counterexample propagates to the affected decision.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: No goal, permission or observed benefit substitutes for either of the other two; a counterexample propagates to the affected decision. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: The actual consumer of the consequential engineering or operational decision. boundary: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power..

**Communication / operation —** content: Join requirement relevance, permitted action and evidence of consequence at the same consequential decision; a defect in any view can block or reopen conclusions in the others.. consumer: The actual consumer of the consequential engineering or operational decision. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-01; CR-12; CR-14; CR-18. local analytical objection: The relation is an analytical engineering constraint, not a new academic theorem or automatic causal-attribution mechanism; complete evidence may be unavailable.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: No goal, permission or observed benefit substitutes for either of the other two; a counterexample propagates to the affected decision.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: One direct contract and result check suffice when all three distinctions are already coupled transparently.. ledger id: CS-073.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: REL-002. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: analytical counterexample-supported need for a relation; no published theorem or comparative validation of this synthesis. scope: Individually plausible component views can jointly admit the stated failure; net value remains context-sensitive.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-07; EV-13. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-01; CR-12; CR-14; CR-18. analytical limit: The relation is an analytical engineering constraint, not a new academic theorem or automatic causal-attribution mechanism; complete evidence may be unavailable... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — No goal, permission or observed benefit substitutes for either of the other two; a counterexample propagates to the affected decision. — from the failure boundary — The relation is an analytical engineering constraint, not a new academic theorem or automatic causal-attribution mechanism; complete evidence may be unavailable.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S004; AOSE-S038; AOSE-S021; AOSE-S031; AOSE-S037; AOSE-S059; AOSE-S060]

### EAOSE-076 — Obligation-preserving organisational reconfiguration

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-076

**Disposition —** CONTEXT_DEPENDENT

**Mature form —** At a role reassignment, reconcile outstanding public obligations with capability, authority and protocol state; retain, validly transfer, release, compensate or report inability instead of silently orphaning the obligation.

**Controlled failure —** This interaction obligation is an analytical synthesis, not a demonstrated general implementation; consent, partial observation and irreversible effects can block safe transfer.

**Trigger —** An adaptive organisation changes role holders while interactions or commitments remain live.

**Non-trigger / cheap path —** Drain in-flight work before reconfiguration, or retain a static assignment when continuity cannot be established.

**Prerequisites —** property inputs: EAOSE-015; EAOSE-017; EAOSE-023; EAOSE-025; EAOSE-056; EAOSE-058; EAOSE-073. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power. This interaction obligation is an analytical synthesis, not a demonstrated general implementation; consent, partial observation and irreversible effects can block safe transfer..

**Domain profile —** DOMAIN-PROFILE-COMPOSITION above; candidate application: Obligation-preserving organisational reconfiguration. A structurally valid new organisation does not erase the commitments created by its predecessor configuration.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: A structurally valid new organisation does not erase the commitments created by its predecessor configuration. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: The actual consumer of the consequential engineering or operational decision. boundary: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power..

**Communication / operation —** content: At a role reassignment, reconcile outstanding public obligations with capability, authority and protocol state; retain, validly transfer, release, compensate or report inability instead of silently orphaning the obligation.. consumer: The actual consumer of the consequential engineering or operational decision. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-03; CR-12; CR-14. local analytical objection: This interaction obligation is an analytical synthesis, not a demonstrated general implementation; consent, partial observation and irreversible effects can block safe transfer.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: A structurally valid new organisation does not erase the commitments created by its predecessor configuration.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Drain in-flight work before reconfiguration, or retain a static assignment when continuity cannot be established.. ledger id: CS-076.

**Conflicts / alternatives —** tension ids: T-06. relation ids: REL-008. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: analytical counterexample-supported need for a relation; no published theorem or comparative validation of this synthesis. scope: Individually plausible component views can jointly admit the stated failure; net value remains context-sensitive.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-05; EV-13. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-03; CR-12; CR-14. analytical limit: This interaction obligation is an analytical synthesis, not a demonstrated general implementation; consent, partial observation and irreversible effects can block safe transfer... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — A structurally valid new organisation does not erase the commitments created by its predecessor configuration. — from the failure boundary — This interaction obligation is an analytical synthesis, not a demonstrated general implementation; consent, partial observation and irreversible effects can block safe transfer.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S016; AOSE-S009; AOSE-S021; AOSE-S037; AOSE-S045]

### EAOSE-077 — Hierarchical organisational decomposition

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-077

**Disposition —** DOMAIN_SPECIFIC

**Mature form —** Use explicitly modelled nested organisations and service/interaction boundaries when the problem is sufficiently nearly decomposable; preserve constraints across levels.

**Controlled failure —** ASPECS hierarchy is not a universal architecture; nesting adds abstraction and coordination cost and can misfit dense cross-cutting dependencies.

**Trigger —** A system’s structure and coordination genuinely benefit from hierarchical or holonic decomposition.

**Non-trigger / cheap path —** A flat organisation is sufficient when nesting adds no explanatory or operational value.

**Prerequisites —** property inputs: EAOSE-013; EAOSE-016; EAOSE-036. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. ASPECS hierarchy is not a universal architecture; nesting adds abstraction and coordination cost and can misfit dense cross-cutting dependencies..

**Domain profile —** DOMAIN-PROFILE-O3 above; candidate application: Hierarchical organisational decomposition. Cross-level obligations and boundaries are represented, not hidden by the hierarchy.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Cross-level obligations and boundaries are represented, not hidden by the hierarchy. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Organisation designer; operators or delegated organisational controller for permitted runtime changes. boundary: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity..

**Communication / operation —** content: Use explicitly modelled nested organisations and service/interaction boundaries when the problem is sufficiently nearly decomposable; preserve constraints across levels.. consumer: Organisation designer; operators or delegated organisational controller for permitted runtime changes. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-13. local analytical objection: ASPECS hierarchy is not a universal architecture; nesting adds abstraction and coordination cost and can misfit dense cross-cutting dependencies.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Cross-level obligations and boundaries are represented, not hidden by the hierarchy.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A flat organisation is sufficient when nesting adds no explanatory or operational value.. ledger id: CS-077.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: None, subject to the stated absence explanation.. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-13. analytical limit: ASPECS hierarchy is not a universal architecture; nesting adds abstraction and coordination cost and can misfit dense cross-cutting dependencies... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Cross-level obligations and boundaries are represented, not hidden by the hierarchy. — from the failure boundary — ASPECS hierarchy is not a universal architecture; nesting adds abstraction and coordination cost and can misfit dense cross-cutting dependencies.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S022]

### EAOSE-078 — Cooperation-driven self-organisation

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-078

**Disposition —** DOMAIN_SPECIFIC

**Mature form —** For an AMAS-style problem, identify non-cooperative situations and local behaviours intended to restore cooperative interaction; judge collective adequacy externally rather than assuming a globally prescribed plan.

**Controlled failure —** Local cooperation cannot be transferred into a universal guarantee of a desired global function; strategic agents or incompatible objectives invalidate the branch.

**Trigger —** The application genuinely needs emergence under poorly specified, changing interactions and meets the cooperative branch assumptions.

**Non-trigger / cheap path —** Use known-goal organisation or a central algorithm when the function is already sufficiently specified.

**Prerequisites —** property inputs: EAOSE-008; EAOSE-018; EAOSE-044; EAOSE-049. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. Local cooperation cannot be transferred into a universal guarantee of a desired global function; strategic agents or incompatible objectives invalidate the branch..

**Domain profile —** DOMAIN-PROFILE-O3 above; candidate application: Cooperation-driven self-organisation. Local adaptation is assessed against an explicit external adequacy judgement and its boundaries.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Local adaptation is assessed against an explicit external adequacy judgement and its boundaries. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Organisation designer; operators or delegated organisational controller for permitted runtime changes. boundary: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity..

**Communication / operation —** content: For an AMAS-style problem, identify non-cooperative situations and local behaviours intended to restore cooperative interaction; judge collective adequacy externally rather than assuming a globally prescribed plan.. consumer: Organisation designer; operators or delegated organisational controller for permitted runtime changes. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-13. local analytical objection: Local cooperation cannot be transferred into a universal guarantee of a desired global function; strategic agents or incompatible objectives invalidate the branch.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Local adaptation is assessed against an explicit external adequacy judgement and its boundaries.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Use known-goal organisation or a central algorithm when the function is already sufficiently specified.. ledger id: CS-078.

**Conflicts / alternatives —** tension ids: T-08. relation ids: REL-026; REL-223. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: None, subject to the stated absence explanation.. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-13. analytical limit: Local cooperation cannot be transferred into a universal guarantee of a desired global function; strategic agents or incompatible objectives invalidate the branch... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Local adaptation is assessed against an explicit external adequacy judgement and its boundaries. — from the failure boundary — Local cooperation cannot be transferred into a universal guarantee of a desired global function; strategic agents or incompatible objectives invalidate the branch.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S040; AOSE-S016]

### EAOSE-079 — Knowledge and task modelling as distinct engineering views

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-079

**Disposition —** CONTEXT_DEPENDENT

**Mature form —** Distinguish domain knowledge, inference structure, task control and problem-solving methods, then bind them to agent capabilities and interfaces.

**Controlled failure —** Knowledge acquisition and multiple views can be expensive; task labels do not validate the knowledge or algorithm.

**Trigger —** Knowledge-intensive reasoning is difficult to engineer as undifferentiated code or beliefs.

**Non-trigger / cheap path —** A direct typed representation and small algorithm are enough for simple reasoning.

**Prerequisites —** property inputs: EAOSE-002; EAOSE-028; EAOSE-040. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. Knowledge acquisition and multiple views can be expensive; task labels do not validate the knowledge or algorithm..

**Domain profile —** DOMAIN-PROFILE-O1 above; candidate application: Knowledge and task modelling as distinct engineering views. Reusable inference patterns have an explicit task and domain interpretation.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Reusable inference patterns have an explicit task and domain interpretation. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Requirements analyst with affected actors and the legitimate requirements decision maker. boundary: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them..

**Communication / operation —** content: Distinguish domain knowledge, inference structure, task control and problem-solving methods, then bind them to agent capabilities and interfaces.. consumer: Requirements analyst with affected actors and the legitimate requirements decision maker. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-13. local analytical objection: Knowledge acquisition and multiple views can be expensive; task labels do not validate the knowledge or algorithm.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Reusable inference patterns have an explicit task and domain interpretation.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: A direct typed representation and small algorithm are enough for simple reasoning.. ledger id: CS-079.

**Conflicts / alternatives —** tension ids: None, subject to the stated absence explanation.. relation ids: None, subject to the stated absence explanation.. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: absent for this precise mature mechanism in the inspected corpus. evidence ids: None, subject to the stated absence explanation.. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-13. analytical limit: Knowledge acquisition and multiple views can be expensive; task labels do not validate the knowledge or algorithm... transferability: strength: bounded by the declared domain and method assumptions. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Reusable inference patterns have an explicit task and domain interpretation. — from the failure boundary — Knowledge acquisition and multiple views can be expensive; task labels do not validate the knowledge or algorithm.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S041; AOSE-S018]

### EAOSE-083 — Preserve responsiveness during long-running plan generation

**Global key —** EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-083

**Disposition —** CONTEXT_DEPENDENT

**Mature form —** Suspend the intention waiting for generated plans rather than the whole agent reasoning loop, where the runtime supports this; preserve the ability to handle unrelated events while a slow or failed generation call is outstanding.

**Controlled failure —** Non-blocking scheduling does not ensure hard real-time response, resource fairness or semantic validity of a late result; cancellation and stale-state handling still need design.

**Trigger —** Remote or computationally slow plan generation threatens the response time of other responsibilities assigned to the same agent.

**Non-trigger / cheap path —** Use a prewritten plan or synchronous execution when no concurrent response obligation exists and the delay is acceptable.

**Prerequisites —** property inputs: EAOSE-010; EAOSE-025; EAOSE-031; EAOSE-067. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. Non-blocking scheduling does not ensure hard real-time response, resource fairness or semantic validity of a late result; cancellation and stale-state handling still need design..

**Domain profile —** DOMAIN-PROFILE-O10 above; candidate application: Preserve responsiveness during long-running plan generation. Waiting for a plan does not by itself disable every unrelated reactive obligation; the wait has an explicit failure or resumption path.

**Evidence needed —** Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment. Criterion: Waiting for a plan does not by itself disable every unrelated reactive obligation; the wait has an explicit failure or resumption path. Establish the target’s actual version/configuration and environmental premise; preserve adverse results and absence of adequate observations.

**Consumer and authority —** actors: Hybrid-system engineer, operator, task owner and affected principals. boundary: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation..

**Communication / operation —** content: Suspend the intention waiting for generated plans rather than the whole agent reasoning loop, where the runtime supports this; preserve the ability to handle unrelated events while a slow or failed generation call is outstanding.. consumer: Hybrid-system engineer, operator, task owner and affected principals. minimal channel: Use the existing decision, model, executable check, interface or human exchange that carries this meaning. No extra message, meeting or document is required solely by the property ID..

**Criticism and limits —** ledger ids: CR-11; CR-16. local analytical objection: Non-blocking scheduling does not ensure hard real-time response, resource fairness or semantic validity of a late result; cancellation and stale-state handling still need design.. attribution: Ledger entries distinguish sourced objections from the researcher’s adversarial strengthening..

**Anti-ceremony boundary —** required function: Waiting for a plan does not by itself disable every unrelated reactive obligation; the wait has an explicit failure or resumption path.. not sufficient: The named model, tool, phase, agent role or trace exists.. minimal adequate alternative: Use a prewritten plan or synchronous execution when no concurrent response obligation exists and the delay is acceptable.. ledger id: CS-083.

**Conflicts / alternatives —** tension ids: T-10. relation ids: REL-023. boundary: No separately indexed conflict is implied when these arrays are empty; the candidate’s own criticism and non-trigger still apply..

**Evidence partitions —** historical provenance: strength: strong for inspected source identity and documented concepts. scope: Does not establish that this exact mature wording existed historically... theory and mechanism: strength: moderate conceptual rationale; no general theorem asserted. scope: The candidate’s semantic distinction or declared formal model only; actual environmental premises and broad effectiveness are separate.. formal result ids: None, subject to the stated absence explanation... empirical comparison: strength: bounded/indirect; mixed where applicable. evidence ids: EV-09; EV-11. scope: Only the linked evidence unit’s actual intervention, sample and comparator; do not assign its entire effect to every property... field or deployment: strength: weak or absent for this precise property; examples/prototypes are not representative deployment. scope: Consult evidence units for simulation, prototype, production and survey distinctions... independent replication: strength: absent as a demonstrated independent replication of this exact mature claim. scope: Source editions and shared cases/datasets are recorded separately; absence here is not a claim that no replication exists anywhere... contrary evidence: strength: material assumptions, counterexamples and/or reported null/critical findings are preserved. criticism ids: CR-11; CR-16. analytical limit: Non-blocking scheduling does not ensure hard real-time response, resource fairness or semantic validity of a late result; cancellation and stale-state handling still need design... transferability: strength: assumption-sensitive; weak for unvalidated modern/operational transfers. required new claim: A later system must establish its own trigger, capability, authority, observation relation and adequate cost/benefit; no target adoption follows...

**Neutral audit questions.** In this system, where, if anywhere, does the stated trigger occur? Which existing mechanism supplies the required function, and what observation supports that conclusion? Does the stated cheaper path already satisfy the same requirement? Who may make the relevant decision or intervene, and what remains outside that authority? What evidence could reveal the candidate-specific failure rather than merely show that a named artefact exists? What cost or harm would make adding or retaining this machinery unjustified?

**Candidate-specific discriminating question —** Can the actual record distinguish the claimed result — Waiting for a plan does not by itself disable every unrelated reactive obligation; the wait has an explicit failure or resumption path. — from the failure boundary — Non-blocking scheduling does not ensure hard real-time response, resource fairness or semantic validity of a late result; cancellation and stale-state handling still need design.? An answer may establish sufficiency, non-applicability or uncertainty rather than a required change.

[AOSE-S056; AOSE-S035]

## Non-retained and unresolved records: not unconditional audit obligations

### EAOSE-007 — A complete goal diagram proves complete requirements

**Disposition —** REJECTED_OR_DISFAVOURED

**Reason —** Reject the universal inference through the missing-actor counterexample; no allegation is made that all goal-method authors assert it.

**Protected limit —** Models can be internally complete over an incorrectly chosen boundary.

**Substitution / supersession —** property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity..

**Neutral question.** Is anyone using this rejected, duplicate or unresolved claim as evidence or as a mandatory requirement? Where not, no remediation is implied. Where so, test the precise claim against its disposition and source limits rather than importing a new control by default.

[AOSE-S004; AOSE-S010; AOSE-S031]

### EAOSE-012 — Every active component should be an agent

**Disposition —** REJECTED_OR_DISFAVOURED

**Reason —** Reject activity alone as a universal reason for agentisation; preserve cases in which autonomous choice genuinely matters.

**Protected limit —** Rejecting this universal does not prohibit agents in domains where interaction or autonomous choice is genuinely useful.

**Substitution / supersession —** property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity..

**Neutral question.** Is anyone using this rejected, duplicate or unresolved claim as evidence or as a mandatory requirement? Where not, no remediation is implied. Where so, test the precise claim against its disposition and source limits rather than importing a new control by default.

[AOSE-S033; AOSE-S025; AOSE-S047]

### EAOSE-019 — Static cooperative organisation as a universal premise

**Disposition —** SUPERSEDED_BY_STRONGER_FORM

**Reason —** Supersede the universal static premise with guarded models; a stable cooperative implementation remains valid within its declared scope.

**Protected limit —** An extension named open does not support arbitrary adversaries; adaptive branches retain their own preconditions.

**Substitution / supersession —** property ids: EAOSE-016; EAOSE-017. explanation: Supersede the universal static premise with guarded models; a stable cooperative implementation remains valid within its declared scope..

**Neutral question.** Is anyone using this rejected, duplicate or unresolved claim as evidence or as a mandatory requirement? Where not, no remediation is implied. Where so, test the precise claim against its disposition and source limits rather than importing a new control by default.

[AOSE-S001; AOSE-S014; AOSE-S016; AOSE-S009; AOSE-S040]

### EAOSE-027 — FIPA message compliance guarantees full interoperability

**Disposition —** REJECTED_OR_DISFAVOURED

**Reason —** Reject full interoperability from message structure; the standard’s own limitations and public-meaning distinctions support the narrower judgement.

**Protected limit —** The standard intentionally separates fields and referenced semantics; this rejection does not negate its useful common structure.

**Substitution / supersession —** property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity..

**Neutral question.** Is anyone using this rejected, duplicate or unresolved claim as evidence or as a mandatory requirement? Where not, no remediation is implied. Where so, test the precise claim against its disposition and source limits rather than importing a new control by default.

[AOSE-S043; AOSE-S039; AOSE-S021]

### EAOSE-035 — Generated syntax establishes behavioural correctness

**Disposition —** REJECTED_OR_DISFAVOURED

**Reason —** Reject syntax as behavioural assurance, while preserving actual bounded transformation results.

**Protected limit —** This rejection preserves valid bounded transformation theorems; it targets their unwarranted extension.

**Substitution / supersession —** property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity..

**Neutral question.** Is anyone using this rejected, duplicate or unresolved claim as evidence or as a mandatory requirement? Where not, no remediation is implied. Where so, test the precise claim against its disposition and source limits rather than importing a new control by default.

[AOSE-S037; AOSE-S036; AOSE-S031; AOSE-S054]

### EAOSE-042 — Method quality equals named-phase or diagram count

**Disposition —** CEREMONY_NOT_GENERAL_PROPERTY

**Reason —** Classify phase/diagram counting as ceremony when treated as a general quality property; the artefacts may still perform useful work.

**Protected limit —** Some documents protect genuine coordination; removing them indiscriminately is the opposite error.

**Substitution / supersession —** property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity..

**Neutral question.** Is anyone using this rejected, duplicate or unresolved claim as evidence or as a mandatory requirement? Where not, no remediation is implied. Where so, test the precise claim against its disposition and source limits rather than importing a new control by default.

[AOSE-S002; AOSE-S046; AOSE-S008]

### EAOSE-052 — Exhaustive testing guarantees unrestricted autonomous behaviour

**Disposition —** REJECTED_OR_DISFAVOURED

**Reason —** Reject unrestricted exhaustive-testing claims, not finite exhaustive checks or bounded model checking within actual assumptions.

**Protected limit —** Combinatorial path arguments do not prove every agent untestable; restriction and compositional reasoning can change tractability.

**Substitution / supersession —** property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity..

**Neutral question.** Is anyone using this rejected, duplicate or unresolved claim as evidence or as a mandatory requirement? Where not, no remediation is implied. Where so, test the precise claim against its disposition and source limits rather than importing a new control by default.

[AOSE-S024; AOSE-S030; AOSE-S048]

### EAOSE-059 — Design-method support implies a complete operational lifecycle

**Disposition —** REJECTED_OR_DISFAVOURED

**Reason —** Reject the inference from good design or code to a completed operational lifecycle.

**Protected limit —** A method may intentionally have a narrow scope; this is not a failure unless broader coverage is claimed.

**Substitution / supersession —** property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity..

**Neutral question.** Is anyone using this rejected, duplicate or unresolved claim as evidence or as a mandatory requirement? Where not, no remediation is implied. Where so, test the precise claim against its disposition and source limits rather than importing a new control by default.

[AOSE-S001; AOSE-S002; AOSE-S046; AOSE-S029]

### EAOSE-062 — Whole-method superiority over conventional engineering

**Disposition —** UNRESOLVED

**Reason —** Keep UNRESOLVED after examining relevant positive, null and critical evidence. The corpus supports use and local results, not a general causal ranking of whole methods.

**Protected limit —** Positive vendor cases and fragment experiments are not null evidence, but neither remove confounding or establish representative lifecycle superiority.

**Substitution / supersession —** property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity..

**Neutral question.** Is anyone using this rejected, duplicate or unresolved claim as evidence or as a mandatory requirement? Where not, no remediation is implied. Where so, test the precise claim against its disposition and source limits rather than importing a new control by default.

[AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S045; AOSE-S046; AOSE-S047; AOSE-S048; AOSE-S061; AOSE-S062]

### EAOSE-063 — Popularity, venue participation or framework maturity proves benefit

**Disposition —** NO_GENERAL_PROPERTY

**Reason —** Reject a general benefit property from popularity/maturity labels while preserving descriptive adoption information.

**Protected limit —** Low visibility also does not establish uselessness; proprietary adoption and nomenclature changes distort proxies.

**Substitution / supersession —** property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity..

**Neutral question.** Is anyone using this rejected, duplicate or unresolved claim as evidence or as a mandatory requirement? Where not, no remediation is implied. Where so, test the precise claim against its disposition and source limits rather than importing a new control by default.

[AOSE-S025; AOSE-S042; AOSE-S044; AOSE-S005]

### EAOSE-064 — Named-method observance as assurance

**Disposition —** CEREMONY_NOT_GENERAL_PROPERTY

**Reason —** Classify method observance itself as ceremony, not a benefit-producing invariant. Keep whatever evidence/coordination function the observance actually serves.

**Protected limit —** A recognised method can aid communication and training; the ceremonial error is substituting its name for its function.

**Substitution / supersession —** property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity..

**Neutral question.** Is anyone using this rejected, duplicate or unresolved claim as evidence or as a mandatory requirement? Where not, no remediation is implied. Where so, test the precise claim against its disposition and source limits rather than importing a new control by default.

[AOSE-S002; AOSE-S008; AOSE-S046]

### EAOSE-072 — A role prompt is a formal role contract

**Disposition —** REJECTED_OR_DISFAVOURED

**Reason —** Reject equivalence between a role prompt and a formally interpreted/enforced role contract; do not deny the prompt’s narrower behavioural usefulness.

**Protected limit —** A prompt can still usefully guide behaviour; the rejected claim is semantic and assurance equivalence.

**Substitution / supersession —** property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity..

**Neutral question.** Is anyone using this rejected, duplicate or unresolved claim as evidence or as a mandatory requirement? Where not, no remediation is implied. Where so, test the precise claim against its disposition and source limits rather than importing a new control by default.

[AOSE-S001; AOSE-S013; AOSE-S036; AOSE-S050; AOSE-S053]

### EAOSE-074 — Evidence continuity through change as a separate new property

**Disposition —** DUPLICATE_CANDIDATE

**Reason —** Keep the ancestry proposal as a duplicate of EAOSE-057. No additional trigger, operation or independent consumer was found beyond selective revalidation.

**Protected limit —** No inspected evidence establishes a distinct trigger or additional operation beyond the strengthened change-impact mechanism.

**Substitution / supersession —** property ids: EAOSE-057. explanation: Keep the ancestry proposal as a duplicate of EAOSE-057. No additional trigger, operation or independent consumer was found beyond selective revalidation..

**Neutral question.** Is anyone using this rejected, duplicate or unresolved claim as evidence or as a mandatory requirement? Where not, no remediation is implied. Where so, test the precise claim against its disposition and source limits rather than importing a new control by default.

[AOSE-S029; AOSE-S031; AOSE-S054]

### EAOSE-075 — Purposeful retirement of method machinery as a separate new property

**Disposition —** DUPLICATE_CANDIDATE

**Reason —** Keep the ancestry proposal as a duplicate of EAOSE-039. Method retirement is one outcome of tailoring; operational agent retirement remains separate.

**Protected limit —** Retiring operational agents with live commitments is different and remains EAOSE-058; do not collapse these subjects.

**Substitution / supersession —** property ids: EAOSE-039. explanation: Keep the ancestry proposal as a duplicate of EAOSE-039. Method retirement is one outcome of tailoring; operational agent retirement remains separate..

**Neutral question.** Is anyone using this rejected, duplicate or unresolved claim as evidence or as a mandatory requirement? Where not, no remediation is implied. Where so, test the precise claim against its disposition and source limits rather than importing a new control by default.

[AOSE-S008; AOSE-S003; AOSE-S017; AOSE-S046]

### EAOSE-080 — A consistent fragment composition guarantees achievable goals

**Disposition —** REJECTED_OR_DISFAVOURED

**Reason —** Reject joint success from consistent fragment composition. The capacity counterexample separates semantic compatibility from feasibility.

**Protected limit —** A stronger theorem can establish a bounded guarantee when its actual assumptions hold; the general inference remains invalid.

**Substitution / supersession —** property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity..

**Neutral question.** Is anyone using this rejected, duplicate or unresolved claim as evidence or as a mandatory requirement? Where not, no remediation is implied. Where so, test the precise claim against its disposition and source limits rather than importing a new control by default.

[AOSE-S003; AOSE-S009; AOSE-S022; AOSE-S037]

### EAOSE-081 — Counterexample propagation as a distinct new control

**Disposition —** DUPLICATE_CANDIDATE

**Reason —** Keep as a duplicate of existing traceability, iterative feedback and coupled-decision mechanisms, not another office or artefact.

**Protected limit —** A link must actually influence the consumer; duplicate disposition does not mean feedback can be omitted.

**Substitution / supersession —** property ids: EAOSE-034; EAOSE-038; EAOSE-073. explanation: Keep as a duplicate of existing traceability, iterative feedback and coupled-decision mechanisms, not another office or artefact..

**Neutral question.** Is anyone using this rejected, duplicate or unresolved claim as evidence or as a mandatory requirement? Where not, no remediation is implied. Where so, test the precise claim against its disposition and source limits rather than importing a new control by default.

[AOSE-S031; AOSE-S054; AOSE-S004]

### EAOSE-082 — Observation plus self-revision guarantees improvement

**Disposition —** REJECTED_OR_DISFAVOURED

**Reason —** Reject automatic improvement from observation plus self-revision; the changed-score counterexample defeats the universal inference.

**Protected limit —** This is an analytical objection to an inference, not a claim that all adaptation fails or that the cited authors assert automatic improvement.

**Substitution / supersession —** property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity..

**Neutral question.** Is anyone using this rejected, duplicate or unresolved claim as evidence or as a mandatory requirement? Where not, no remediation is implied. Where so, test the precise claim against its disposition and source limits rather than importing a new control by default.

[AOSE-S029; AOSE-S035; AOSE-S048; AOSE-S050; AOSE-S057; AOSE-S062]

## Handoff and completion boundary

All 83 IDs are preserved. The audit has not been conducted; only its neutral intake is complete. A later finding must name actual target evidence and a target-scoped disposition. External research is not mutation authority, no sibling results are assumed, and a host system is not described as having adopted anything in this intake.
