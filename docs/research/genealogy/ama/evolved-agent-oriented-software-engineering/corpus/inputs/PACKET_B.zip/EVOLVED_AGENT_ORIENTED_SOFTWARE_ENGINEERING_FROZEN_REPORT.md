# Evolved Agent-Oriented Software Engineering

## Research judgement

**Agent-Oriented Software Engineering (AOSE) is a plural engineering tradition, not a synonym for an agent runtime, a modelling notation, a multi-agent demonstration, or the use of a coding assistant.** The useful object of this study is the engineering relationship between stakeholder needs, delegated decisions, implemented interactions and defensible evidence of their consequences. The literature supplies several competing ways to construct that relationship. It does not supply evidence that selecting the agent paradigm, or completing a named methodology, universally improves software engineering. [AOSE-S013; AOSE-S033; AOSE-S055; AOSE-S058]

The strongest surviving core is therefore conditional but substantive. Engineers need to distinguish desired outcomes from runtime goal states; role responsibilities from role holders; available capabilities from permitted effects; messages from their interpreted interaction meaning; generated representations from their realised behaviour; and verified models from validated environmental premises. These distinctions matter because the wrong substitution can admit a consequentially wrong decision even when a diagram, local implementation or test looks correct. The property ledger records both the distinction and the inquiry, communication or intervention required to make it operational.

The composed system developed here uses those mechanisms together. Its ordinary engineering loop has no universal first-to-last phase order. Requirements inquiry, design, implementation and assurance may proceed concurrently where their dependencies permit. A failed assumption, prohibited action, inconsistent interaction or falsely successful outcome can interrupt the corresponding decision and return evidence to the view that needs revision. Some corrections concern code; others concern the meaning of a requirement, an authority boundary, an observation, or the choice to use agents at all. A mature method must permit these different corrections rather than forcing every failure into another implementation patch.

Two distinct composition-induced properties survive the present adjudication. **EAOSE-073, criterion–authority–effect coupling**, requires those views to constrain the same consequential decision, rather than merely coexist as separate records. **EAOSE-076, obligation-preserving organisational reconfiguration**, addresses the gap between a structurally valid new role assignment and the commitments or in-flight interactions inherited from the old one. Both are explicitly **researcher analytical syntheses** grounded in the component mechanisms. Neither is presented as an established named academic result or as an empirically validated superior methodology.

Three attractive synthesis labels do not warrant extra independent controls. Evidence continuity through change is the operative retain/narrow/reassess/withdraw judgement already preserved in EAOSE-057. Purposeful retirement of method machinery belongs within proportional method assembly and retirement, EAOSE-039. Counterexample propagation is already operative in traceability, iterative feedback and the coupled decision relation. Their proposed additional IDs remain in the denominator as duplicates. This is a substantive reduction in machinery, not an omission of their functions.

The current literature also yielded a distinct **native**, rather than composition-induced, mechanism: EAOSE-083, preserving responsiveness during slow plan generation. Suspending the waiting intention rather than blocking the complete reasoning loop can preserve the opportunity to handle unrelated events. It does not prove that a returned plan is fresh, that scheduling is fair, or that a hard deadline is met. The candidate therefore remains contextual. [AOSE-S056, §3.2]

## Scope, independence and the meaning of this freeze

The analytical label is `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING`; the property prefix is `EAOSE`. “Evolved” names this criticism-tested within-tradition composition, not a historical school. The study is independently useful even if the proposed later Autonomous Agents / Multi-Agent Systems / AOSE grouping is never adopted. No sibling Evolved corpus was consulted, no requester repository was inspected, and no target architecture, change, adoption or release is inferred.

The research cut-off is **7 September 2026**. This revision contains **83 examined candidates**, including adverse, duplicate, superseded, ceremonial, contested and unresolved dispositions. It reconstructs the population from freshly accessible evidence rather than inheriting the earlier reported 66. Inspection of the recoverable ancestry found no usable property or source ledger; its composition addendum supplied hypotheses to reassess, not authority. Consequently this is not “66 plus 17”, nor a claim to have preserved unknown old ID assignments. The present IDs and dispositions are stable within this named frozen revision.

Completeness is bounded by the declared questions and candidate population. The ten mandatory domain families have been examined, including current work, relevant negative findings and alternatives. Formal results and studies have been assessed at the level actually inspected; source-specific access limits are retained. For example, extended Gaia’s full article, the complete reference-work entry, and the full EMAS community-roadmap chapter were not available through the bounded lawful retrieval paths used here. Their accessible material supports only the narrower claims recorded in the source table. Independently accessible primary work supports the relevant organisational, scope and current-engineering analyses; missing pages have not been reconstructed from abstracts.

The freeze stabilises evidence, interpretation and scope. It does not turn an unresolved empirical question into a solved one. In particular, **EAOSE-062 remains UNRESOLVED: the inspected evidence does not establish general whole-method superiority**. There is positive field evidence and some local comparative evidence; there are also null findings, weak baselines, different interventions, and substantial transfer limits. The correct conclusion is neither “AOSE never works” nor “AOSE is the superior software-engineering paradigm”.

## How the evidence is used

Every exact work or materially distinct inspected edition has a source ID. The 62 source records distinguish bibliographic dates, versions and access levels. Source-table locators identify the passage supporting an antecedent mechanism, historical relationship, result or limitation. The ledger’s source-to-claim bindings show which candidate uses that evidence. A binding does not mean that the source author proposed the complete mature wording in this packet. The mature extraction, negative inference tests and composition are the researcher’s adjudications.

Historical provenance, definitions, formal results, standards, comparisons, field reports, failures and researcher interpretation are different evidence roles. A theorem establishes a conditional relation in its model. A standard prescribes a layer of representation or behaviour. A deployed application demonstrates that some implementation was used. A controlled exercise compares the specified interventions in its sample. None automatically becomes another kind of evidence. These roles are kept separate in every property’s evidence partitions rather than averaged into a percentage.

The central quantitative evidence summaries are in the evidence-unit register below and in JSON. They preserve the study unit, sample, comparison, setting, measures and validity threats. An industrial programme described in several publications is not several independent replications. The two inspected MAST versions are distinct editions of one research programme. ProgramDev/ChatDev reuse also matters when interpreting later fault-injection evidence. Repeated trials within a benchmark estimate something about that configuration and sample; they do not establish a population rate for deployed agents.

No new human-subject experiment, model-checking rerun, benchmark rerun or industrial deployment was conducted in this study. The new discriminating cases are explicitly analytical. They test whether the composed account admits a counterexample or makes an unwarranted inference. This can justify narrowing a claim or recognising a missing interaction obligation; it cannot identify the net productivity effect of adopting the resulting system.

## Reconstruction: several engineering problems, not one line of progress

### From programming abstractions to a development discipline

The transition into AOSE was not simply the addition of messages to objects. The inspected AOP formulation asks when intentional vocabulary is useful and supplies restricted programming semantics; it does not make every active object an agent or define an entire development lifecycle. The broader engineering argument concerns the fit of abstractions to complex, distributed decision problems. Even a prominent early advocacy article explicitly declined a silver-bullet claim and noted the absence of quantitative project-comparison evidence. These are important limits within the founding discussion, not only later scepticism. [AOSE-S033, §§1.1–1.3; AOSE-S055, opening and complexity argument]

The practical consequence is a selection question: what consequential decision becomes easier to specify, realise, coordinate or evaluate by using agency? An object can encapsulate state; an actor can process messages; a service can expose a contract; a workflow can sequence decisions; a controller can centralise a policy. An agent-oriented design needs to explain the additional delegated choice or social/organisational meaning that matters in the actual problem. These are analytical comparators, not claims that the alternatives lack all autonomy or that their expressiveness is categorically disjoint.

Knowledge engineering contributes another ancestry. MAS-CommonKADS treats domain knowledge, inference and tasks as engineering objects alongside agents and their coordination. This is not the same organising principle as beginning with a goal-dependency model or a role hierarchy. Its survival in the synthesis is conditional: separate knowledge views are valuable when their consumer can use them to construct or challenge a capability. For a small direct algorithm, imposing several expertise/task artefacts can be an unnecessary cost. [AOSE-S041, §3]

### Requirements-first and organisation-first methods

The requirements branch asks why the software is being built and who depends on whom. The inspected 1995 cooperating-agents paper relates strategic organisational reasoning to action/state requirements iteratively, providing an earlier verified anchor than Tropos. Tropos carries an actor/goal orientation through early and late requirements and design. Later language consolidation and security-oriented extensions address different weaknesses; a consistent modelling vocabulary does not discover all actors, while a security model does not implement its own permissions. [AOSE-S059; AOSE-S004; AOSE-S034; AOSE-S038]

The organisation-oriented branch asks how collective duties are allocated and coordinated. Original Gaia’s roles separate responsibilities, permissions, activities and protocols, but its declared stable/cooperative domain and subsequent implementation boundary must remain visible. A role’s identity is not an implementation identity. Multiplicity also does not solve collective fulfilment by itself: several capable holders can duplicate an irreversible action or each wait for another to act. The mature extraction therefore asks who actually fulfils the collective obligation under the chosen binding, rather than checking role membership alone. [AOSE-S001, §§3–4 and note 3]

MaSE and O-MaSE supply a different route through goal/role/conversation and organisational/process models. O-MaSE’s customisation concerns method construction as well as organisational design. Its default illustrative process is not evidence of a mandatory universal waterfall. The known-function capability-assignment approach and ADELFE’s cooperative-emergence approach also have different premises. Treating them as interchangeable examples of adaptation would lose precisely the assumptions engineers need to select between them. [AOSE-S015; AOSE-S003; AOSE-S009; AOSE-S016; AOSE-S040]

### Detailed design, executable artefacts and the manual boundary

Prometheus, PASSI and INGENIAS all contribute more than labels for phases, but they do not make identical commitments. Prometheus provides agent-specific design guidance, including perceptions and actions. PASSI connects familiar use-case-oriented work with society, implementation, code and deployment views. INGENIAS makes coordinated views and model-driven development explicit. Their useful mechanisms cannot be evaluated by counting how many lifecycle boxes appear in an overview. What matters is whether an engineer can produce the next meaningful decision or executable result, and whether the transformation preserves the relevant semantics. [AOSE-S007; AOSE-S039; AOSE-S018; AOSE-S046]

Generation does not remove the manual boundary. The programmer may still supply domain functions, percept processing, tool bindings, error handling and interpretation of generated structures. Those duties need not always produce another document, but they must remain visible to whoever decides whether the implementation is complete. A generated percentage measures something different from correctness, engineering effort saved or long-term maintenance cost.

A similar distinction applies to detailed design consistency. The inspected protocol-checking paper analyses partial designs and explicitly limits an unconditional sound-and-complete interpretation. Its output can be a valuable defect-location lead while still requiring investigation. The evolved disposition is not to discard such a tool because it lacks an absolute guarantee. It is to prevent its useful local evidence from being promoted into a stronger assurance claim than it supports. [AOSE-S054, §3.4]

### Interaction is not simply message transport

Interaction engineering contains competing semantic choices. AUML provides modelling levels; FIPA’s message-structure specification defines a representation layer; public commitment accounts seek externally meaningful obligations; information protocols constrain enactment through information dependencies. These mechanisms can complement one another, but their guarantees do not automatically compose. [AOSE-S020; AOSE-S043; AOSE-S021; AOSE-S037]

A public commitment does not force a participant to comply. A message announcing completion may be false, may refer to a different event, or may use an institutionally disputed meaning. Conversely, private BDI reasoning can remain useful inside a participant even when private mental states are unsuitable as a public compliance criterion. The coherent hybrid is a defined public boundary with potentially heterogeneous internals, not a fiction that all peers share one observable mental architecture.

The generation and language-translation results are important precisely because they specify narrower correspondences. A protocol synthesis theorem can depend on a consistent specification and its information model. Liveness there is not a guarantee that an independent participant will cooperate or that a physical good will be delivered by a deadline. Engineers still need to connect the permitted interaction to locally implemented behaviour and externally grounded completion. [AOSE-S037, §6; AOSE-S036, §2]

### Method engineering is not collecting every method’s best-looking feature

Agent OPEN, O-MaSE, Agile PASSI and related methodological analysis make tailored development a serious engineering concern. Their relevance is not a licence to merge every diagram with the same name. A fragment consumes something with a meaning, not merely a file. Its required actor, state, goal or role semantics may differ from those produced by another fragment. The assembled method can therefore be inconsistent, hard to execute, or unnecessarily expensive despite appearing comprehensive. [AOSE-S017; AOSE-S003; AOSE-S008; AOSE-S046]

The same reasoning supports retirement. A model, review or trace should survive because it still protects a live distinction, intervention, coordination dependency or assurance claim. It need not survive because it appears in a brand’s process. But rare use is not sufficient evidence of uselessness: a failover model may matter only when an unusual failure occurs. The relevant question is what would lose its warrant or practical support if the artefact disappeared, and whether a cheaper substitute preserves that function.

This is why the synthesis merges purposeful retirement into proportional method assembly instead of constructing a separate retirement bureaucracy. It also preserves the difference between retiring method machinery and retiring an operational agent with outstanding commitments. The latter changes ongoing external relations and may require valid transfer, release or explicit acknowledgement of inability.

## Assurance and evidence: where the strongest claims stop

An assurance claim should identify its subject, property, assumptions, configuration, evidence and observation relation. This tuple is an analytical reporting device in this packet, not a newly attributed AOSE formalism. It prevents several recurrent substitutions: a validated need is not a verified program; a verified decision program is not a validated sensor; a successful test is not every possible run; and a correct local plan is not a correct collective interaction.

The formal and testing literature demonstrates multiple ways to reduce particular uncertainties. Decision-code verification narrows the model-to-program gap. Dynamic-environment models make some environmental variation explicit. Plan-generation logic provides conditional strategy/plan relationships. Behaviour-driven and mutation-based testing can expose inadequate success conditions. These are not redundant methods, and neither are they components of one automatically composable proof. Each brings its own model, oracle and implementation obligation. [AOSE-S023; AOSE-S030; AOSE-S049; AOSE-S031]

The testability analysis is likewise bounded. It concerns the growth of paths in specified goal/plan structures, including failure handling, rather than a theorem that no autonomous system can ever be tested usefully. Restricted exhaustive tests, formal models, targeted faults, simulation and operational observation all remain possible. Their application is a cost-and-consequence decision. The unacceptable move is to turn finite selected evidence into unrestricted behavioural coverage. [AOSE-S024]

The adoption evidence prevents equally broad conclusions in both directions. Industrial reports and the application survey demonstrate more than pure laboratory speculation. But bundled platforms, experienced teams, conventional process hybrids, historical baselines and self-selection make general attribution difficult. The healthcare modelling comparison supplies a narrower empirical test and includes non-significant time/difficulty findings. Those outcomes must remain visible rather than being reduced to a slogan that the social method is simply better. [AOSE-S026; AOSE-S042; AOSE-S045; evidence units EV-03 to EV-05]

The resulting unresolved question is exact: **what, under a well-defined comparison and over a relevant lifecycle, is the causal engineering benefit of adopting an AOSE methodology as a whole rather than a competent alternative?** This is not the question whether an agent can work, whether a platform was used, or whether a particular modelling mechanism can help. The inspected corpus cannot settle the whole-method claim. A frozen corpus can preserve that examined uncertainty without making the rest of its mechanisms unavailable.

## Current continuity without rebranding

EMAS provides documented institutional continuity: its formation brought together AOSE, DALT and ProMAS. This is distinct from the earlier formation of AAMAS. Current workshop and roadmap material shows continued work on classical, learned and hybrid agents, but a research venue establishes activity rather than consensus or effectiveness. [AOSE-S028; AOSE-S006; AOSE-S005; AOSE-S051]

Some contemporary work has an explicit technical inheritance. ChatBDI connects learned language handling with Jason/JaCaMo and established agent communication concepts. The plan-generation work extends AgentSpeak-related reasoning, while the self-evolving agent proposal separates an evolution module from ordinary deliberation. Those are documented architectural relationships. They do not establish that every LLM multi-agent framework descends from AOSE, nor that the inherited abstractions preserve their guarantees when the component becomes stochastic or remotely updated. [AOSE-S052; AOSE-S056; AOSE-S057]

Other modern work provides relevant criticism or convergent engineering evidence. Fixed workflow baselines question how much autonomy a particular task needs. Cost-aware evaluation questions whether task accuracy alone captures value. Failure taxonomies, stateful prompt-injection benchmarks and trace/fault-injection tooling expose ways that role instructions, local reasoning and apparent completion can fail to produce the intended collective result. The synthesis uses those findings as bounded evidence about engineering learned agents, not as proof that any one classical methodology would have prevented every failure. [AOSE-S047; AOSE-S048; AOSE-S050; AOSE-S053; AOSE-S035]

The changed obligations are concrete. Generated output needs an admissible meaning and capability boundary; tool-returned text cannot silently become authority; repeated runs need their configurations and costs; provider changes can invalidate prior evidence; and an outstanding generation call can interfere with other responsibilities. Memory provenance is retained only as an explicitly assumption-sensitive modern translation. The reviewed observability work does not establish a general memory-fault solution, and the packet does not manufacture one.

These current forms reinforce rather than remove the central distinctions. A role prompt is not a formal role contract. A generated goal is not an accepted stakeholder goal. A parsed plan is not a correct plan. A trace is not causal omniscience. A self-revision that improves its own score is not automatically an authorised improvement in externally accepted outcomes.

The final late-source review made two further corrections. Yu’s software-versus-world argument supplies a direct historical antecedent for agent-oriented analysis without an agent runtime; it is not a novel exemption invented by this synthesis. The code-centric framework comparison and the preliminary BDI–LLM study expose different measurement limitations. Their actual configurations and local/null outcomes are preserved in EV-15 and EV-16, rather than used to force either a positive or negative verdict on AOSE as a whole. [AOSE-S060, §§1–3,6; AOSE-S061, §§3–5; AOSE-S062, §§4–9]


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_TIMELINE

Dates distinguish the original publication, workshop and later inspected edition. This is a plural chronology, not a ladder on which every later method replaces every earlier one. Bibliographic source locators, access levels and attribution limits are in the source table.

| Node | Date / interval | Branch | Sources |
| --- | --- | --- | --- |
| G-01 | Precursors; 1993 founding formulation inspected | Agent-oriented programming / object and AI imports | AOSE-S033, AOSE-S011, AOSE-S013 |
| G-02 | 1995; 1999 elaboration; 2016 core language | i* / actor-goal requirements | AOSE-S059, AOSE-S010, AOSE-S034, AOSE-S060 |
| G-03 | 1995 | Practical BDI | AOSE-S012 |
| G-04 | 1997 workshop / 1998 publication | MAS-CommonKADS | AOSE-S041 |
| G-05 | 1999 predecessor identified; 2000 article inspected | Original Gaia | AOSE-S001 |
| G-06 | 2001 | MaSE | AOSE-S015 |
| G-07 | 2002 | Tropos | AOSE-S004, AOSE-S038 |
| G-08 | 2002 | Prometheus | AOSE-S007, AOSE-S054 |
| G-09 | 2002 original; 2006 agile derivative | PASSI / Agile PASSI | AOSE-S039, AOSE-S008 |
| G-10 | 2003; 2004 methodological exposition | INGENIAS | AOSE-S018, AOSE-S019 |
| G-11 | 2003 | Extended Gaia | AOSE-S014, AOSE-S016 |
| G-12 | 2005–2010 | Agent OPEN / O-MaSE method engineering | AOSE-S003, AOSE-S009, AOSE-S017, AOSE-S046 |
| G-13 | 2003 workshop / 2004 publication | ADELFE / AMAS | AOSE-S040, AOSE-S016 |
| G-14 | 2009 online / 2010 final | ASPECS | AOSE-S022 |
| G-15 | 1998 critique; 2000/2001 modelling; 2002 standard | Interaction-language branches | AOSE-S021, AOSE-S020, AOSE-S043 |
| G-16 | 2015 empirical study; 2020 generation; 2025 language translation | Commitment and information-protocol engineering | AOSE-S045, AOSE-S037, AOSE-S036 |
| G-17 | 2014–2016; 2022; 2023; 2025 | Verification, testability and requirements testing | AOSE-S023, AOSE-S024, AOSE-S030, AOSE-S031, AOSE-S049, AOSE-S054 |
| G-18 | 2003; 2006; 2012/2014; 2015 | Comparative and industrial evidence | AOSE-S002, AOSE-S026, AOSE-S042, AOSE-S045, AOSE-S025, AOSE-S061 |
| G-19 | 2013 merger; 2018 report; 2026 activity | Engineering Multi-Agent Systems community | AOSE-S028, AOSE-S027, AOSE-S005, AOSE-S006, AOSE-S051 |
| G-20 | 2021; current platform documentation | Deployment/environment/organisation integration | AOSE-S029, AOSE-S044 |
| G-21 | 2024–2026 | Learned and hybrid agent engineering | AOSE-S035, AOSE-S047, AOSE-S048, AOSE-S050, AOSE-S052, AOSE-S053, AOSE-S056, AOSE-S057, AOSE-S062 |
| G-22 | 2026-09-07 analytical freeze | Evolved AOSE (this study) | AOSE-S003, AOSE-S004, AOSE-S009, AOSE-S021, AOSE-S031, AOSE-S037, AOSE-S038, AOSE-S045, AOSE-S059 |
| G-23 | Platform bindings inspected in 2023–2026 work and current documentation | Executable language and platform bindings: Jason, SARL and JaCaMo | AOSE-S031, AOSE-S036, AOSE-S044, AOSE-S052 |
| G-24 | Pre-AOSE foundations, as documented by Gaia 2000 and AOSE 2001 accounts | Object-oriented and FUSION software-engineering imports | AOSE-S001, AOSE-S013, AOSE-S055 |
| G-25 | Established software operations practices explicitly imported in the 2021 proposal | Conventional deployment, testing and DevOps practices | AOSE-S029 |


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_GENEALOGY

The machine-readable graph separates documented imports/extensions from shared ancestry, translations, analogy and unresolved relationships. Its nodes are branches or problem clusters rather than a claim of one founder per method. An edge labelled as unresolved is deliberately not evidence of descent.

### G-01 — Agent-oriented programming / object and AI imports

**Problem and mechanism —** Give intentional computational abstractions a usable programming meaning. Mental-state specialisation and restricted AGENT0 execution.

**Contribution —** Separates an intentional description from its useful semantic role.

**Limit and reception —** AOP is not a whole lifecycle methodology; claimed coining in 1989 is a later first-person recollection. AOP informs later AOSE; object methods and agent messages must not be caricatured as categorically incapable/capable of refusal.

[AOSE-S033; AOSE-S011; AOSE-S013]

### G-02 — i* / actor-goal requirements

**Problem and mechanism —** Understand strategic dependency and vulnerability before prescribing system behaviour. Actor/dependency and rationale views; iterative relation to action/state requirements.

**Contribution —** Makes organisational reasons and responsibilities discussable without fixing an agent runtime.

**Limit and reception —** Modelling language does not guarantee discovery or stakeholder validity. Tropos reuses this requirements orientation; iStar 2.0 addresses variant proliferation.

[AOSE-S059; AOSE-S010; AOSE-S034; AOSE-S060]

### G-03 — Practical BDI

**Problem and mechanism —** Reason and act under incomplete information and bounded deliberation. Beliefs, desires/goals, intentions and plan choices with commitment policies.

**Contribution —** Connects formal mental-state concepts and executable architectures.

**Limit and reception —** Beliefs are not world truth; historical OASIS account describes testing rather than an independently verified universal benefit. Prometheus and later agent verification/hybrid work reuse BDI concepts.

[AOSE-S012]

### G-04 — MAS-CommonKADS

**Problem and mechanism —** Extend knowledge-system engineering to multiple interacting agents. Separate task/expertise, agent, organisational, coordination, communication and design views.

**Contribution —** Imports knowledge/inference and structured communication modelling.

**Limit and reception —** Knowledge acquisition and view consistency remain real effort. Preserves a knowledge-engineering ancestry not reducible to goal-first methods.

[AOSE-S041]

### G-05 — Original Gaia

**Problem and mechanism —** Move from requirements to organisational analysis and design. Roles, responsibilities, permissions, activities, interactions and concrete agent/service views.

**Contribution —** Agent-specific organisational abstractions with an acknowledged OO/FUSION import.

**Limit and reception —** Stable cooperative organisation; direct service implementation outside the method; collective fulfilment not fully elaborated. Later organisational extension and independent adaptive methods address different limitations.

[AOSE-S001]

### G-06 — MaSE

**Problem and mechanism —** Systematic multi-agent analysis and design. Goals/use cases, roles, agent classes and conversation/state models through deployment.

**Contribution —** Links system analysis to agents and conversations with tool-oriented guidance.

**Limit and reception —** Conversations and implementation need checked semantics; full operational evolution is not inferred from a deployment stage. O-MaSE refines organisational modelling and customisable method construction.

[AOSE-S015]

### G-07 — Tropos

**Problem and mechanism —** Retain intentional requirements throughout development. Early/late requirements and architectural/detailed design using actor/goal dependencies.

**Contribution —** Connects organisational reasons with system realisation.

**Limit and reception —** Examples are not a controlled whole-method comparison; security and other concerns motivate extensions. Secure Tropos adds security-oriented concepts; goal-centred continuity survives with validation limits.

[AOSE-S004; AOSE-S038]

### G-08 — Prometheus

**Problem and mechanism —** Give developers detailed, usable agent-specific design guidance. System specification, architectural and detailed views, often realised with BDI concepts.

**Contribution —** Explicit attention to perceptions/actions and iterative design correspondence.

**Limit and reception —** Plan and boundary semantics still need implementation and testing. Later protocol checks and testing work target concrete model/behaviour gaps.

[AOSE-S007; AOSE-S054]

### G-09 — PASSI / Agile PASSI

**Problem and mechanism —** Engineer implemented agents with familiar software models; reduce process burden for rapid robotic development. Use-case-first views, society, implementation, code and deployment; tailored fragments in the agile derivative.

**Contribution —** Shows platform-aware process guidance and a documented smaller hybrid.

**Limit and reception —** Code generation leaves manual work; reuse/prototype measures are not a comparative productivity proof. Agile derivative is a scoped process change, not evidence that all original steps are universally obsolete.

[AOSE-S039; AOSE-S008]

### G-10 — INGENIAS

**Problem and mechanism —** Coordinate multiple agent engineering views and model-driven support. Integrated metamodel/views and development environment, extending MESSAGE-related work.

**Contribution —** Makes cross-view modelling and generation explicit engineering concerns.

**Limit and reception —** 2003 source access is abstract-limited; 2004 primary exposition supplies mechanisms. Retained as a model-driven branch; no current tool-maintenance claim is inferred from age or publication.

[AOSE-S018; AOSE-S019]

### G-11 — Extended Gaia

**Problem and mechanism —** Explicitly model more demanding organisational structures and interactions. Organisation-oriented extension of the earlier method.

**Contribution —** Documented extension broadens its conceptual treatment.

**Limit and reception —** Full primary text was not recovered; detailed internal claims are not invented. Later O-MaSE/organisation work supplies separately inspected dynamic-assignment mechanisms.

[AOSE-S014; AOSE-S016]

### G-12 — Agent OPEN / O-MaSE method engineering

**Problem and mechanism —** Avoid a single monolithic process for differing project contexts. Reusable process fragments, metamodel alignment and construction guidelines.

**Contribution —** Makes tailoring an engineering activity with semantic obligations.

**Limit and reception —** Missing fragment definitions or matching metamodels do not prove a usable combined process. Used here as support for proportional assembly, not a mandatory union of every method.

[AOSE-S003; AOSE-S009; AOSE-S017; AOSE-S046]

### G-13 — ADELFE / AMAS

**Problem and mechanism —** Build cooperative adaptive systems where global function is not simply prescribed. Adequacy/environment analysis and local responses to non-cooperative situations.

**Contribution —** A distinct emergence-oriented process with imported modelling/process tools.

**Limit and reception —** Cooperation and environmental assumptions are not universal; global adequacy still needs evaluation. Known-function organisation allocation is a contextual alternative rather than a strict replacement.

[AOSE-S040; AOSE-S016]

### G-14 — ASPECS

**Problem and mechanism —** Engineer complex systems through nested organisations. Holonic organisational modelling and services; documented PASSI/RIO hybrid.

**Contribution —** Supports cross-level modelling where nearly decomposable structure helps.

**Limit and reception —** Hierarchy can misfit cross-cutting relations; automotive example is simulation, not production evidence. Retained as a guarded structural refinement.

[AOSE-S022]

### G-15 — Interaction-language branches

**Problem and mechanism —** Express multi-party interaction without confusing internal intention, message structure and public meaning. Mental-state ACL critique, AUML multi-level protocol views and FIPA message fields.

**Contribution —** Separates concerns later often collapsed into a middleware badge.

**Limit and reception —** Neither notation nor structure ensures interoperable enactment or discharge. Commitment/information protocols and design checkers refine distinct parts of the problem.

[AOSE-S021; AOSE-S020; AOSE-S043]

### G-16 — Commitment and information-protocol engineering

**Problem and mechanism —** Support flexible public interaction among independently implemented agents. Commitment lifecycles, asynchronous information dependencies, bounded generation and language mappings.

**Contribution —** Provides formal and empirical evidence of different kinds rather than one universal result.

**Limit and reception —** Formal liveness is model-bounded; student healthcare modelling is not clinical deployment; short language paper is not full lifecycle validation. Preserved as an open-interaction alternative with heterogeneous internals.

[AOSE-S045; AOSE-S037; AOSE-S036]

### G-17 — Verification, testability and requirements testing

**Problem and mechanism —** Close specified design/code gaps without confusing model proof with external adequacy. Decision-code checking, environment models, partial-design defect location, BDD and generated-plan analysis.

**Contribution —** Makes several previously implicit assurance gaps explicit.

**Limit and reception —** Distinct models and benchmarks are not one combined deployment guarantee. Current learned components increase the need to state assumptions and oracles.

[AOSE-S023; AOSE-S024; AOSE-S030; AOSE-S031; AOSE-S049; AOSE-S054]

### G-18 — Comparative and industrial evidence

**Problem and mechanism —** Determine whether engineering mechanisms are used and pay off. Student comparison, vendor field reports, application survey and a modelling experiment.

**Contribution —** Establishes some practical use and bounded comparisons while exposing attribution limits.

**Limit and reception —** Applications, platforms and whole methods are different units; effects and denominators cannot be pooled casually. Whole-method superiority remains unresolved in the inspected evidence.

[AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S045; AOSE-S025; AOSE-S061]

### G-19 — Engineering Multi-Agent Systems community

**Problem and mechanism —** Bring modelling, programming and engineering concerns into a common research forum. EMAS merges AOSE, DALT and ProMAS; later workshops discuss classical and learned/hybrid systems.

**Contribution —** Documented institutional continuity, distinct from the 2002 formation of AAMAS.

**Limit and reception —** A venue or roadmap demonstrates activity, not consensus or effectiveness. Current proposals include lifecycle, protocols and hybrid agent design.

[AOSE-S028; AOSE-S027; AOSE-S005; AOSE-S006; AOSE-S051]

### G-20 — Deployment/environment/organisation integration

**Problem and mechanism —** Connect agent development to deployed systems and operational feedback. DevOps-oriented lifecycle proposal and agent/environment/organisation programming integration.

**Contribution —** Documents imports and platform semantics relevant beyond design diagrams.

**Limit and reception —** Proposal is not proof that tests establish safety; tool news is not a complete latest-version audit. Used here for explicitly labelled operational extensions and selective revalidation.

[AOSE-S029; AOSE-S044]

### G-21 — Learned and hybrid agent engineering

**Problem and mechanism —** Use language/generation while handling stochasticity, untrusted inputs and operational change. Fixed baselines, cost-aware evaluation, failure analysis, stateful injection tests, observability and BDI integrations.

**Contribution —** Documented BDI descendants coexist with convergent modern engineering work.

**Limit and reception —** Small prototypes, shared datasets and remote changes constrain generalisation. Plan-generation responsiveness is a native current mechanism; general self-evolution stability remains unestablished.

[AOSE-S035; AOSE-S047; AOSE-S048; AOSE-S050; AOSE-S052; AOSE-S053; AOSE-S056; AOSE-S057; AOSE-S062]

### G-22 — Evolved AOSE (this study)

**Problem and mechanism —** Compose criticism-tested mechanisms without inventing a historical school. Guarded requirement–authority–effect decisions, lifecycle feedback and alternative implementations.

**Contribution —** Two retained composition-induced mechanisms with duplicates/rejections preserved.

**Limit and reception —** Analytical cases test coherence, not empirical whole-method superiority. Ready for an independent later reconciliation; no sibling output consulted.

[AOSE-S003; AOSE-S004; AOSE-S009; AOSE-S021; AOSE-S031; AOSE-S037; AOSE-S038; AOSE-S045; AOSE-S059]

### G-23 — Executable language and platform bindings: Jason, SARL and JaCaMo

**Problem and mechanism —** Realise agent designs and protocols in executable languages and environmental/organisational services. Language-specific plan/behaviour semantics, protocol translations and platform integration.

**Contribution —** Makes the manual and generated binding an inspectable engineering object.

**Limit and reception —** These platforms are alternatives; a binding does not imply all share semantics or are LLM-based. BDD testing, protocol generation and BDI–LLM integrations use particular bindings. No platform-maintenance census is claimed.

[AOSE-S031; AOSE-S036; AOSE-S044; AOSE-S052]

### G-24 — Object-oriented and FUSION software-engineering imports

**Problem and mechanism —** Structure software components and development artefacts before and alongside agent abstractions. Object models and analysis/design concepts reused or contrasted in AOSE.

**Contribution —** Provides actual imported modelling ancestry; this is distinct from a claim of AGENT0-to-Gaia derivation.

**Limit and reception —** Original FUSION monograph is not independently inspected; this node supports only imports explicitly documented by the inspected AOSE papers. Agent methods adapt these ideas for discretion and social interaction without proving objects incapable of equivalent implementations.

[AOSE-S001; AOSE-S013; AOSE-S055]

### G-25 — Conventional deployment, testing and DevOps practices

**Problem and mechanism —** Bridge design/implementation with repeatable deployment and operating feedback. Version/configuration control, test/deployment automation and feedback as discussed in the EMAS DevOps proposal.

**Contribution —** Identifies an external import rather than inventing full operational coverage in every original AOSE method.

**Limit and reception —** No general DevOps history, benefit theorem or independent study is supplied by this source. Agent engineering proposal with particular autonomy/testing challenges.

[AOSE-S029]

### Material historical relationships

**GE-01 — G-24 → G-05 (DOCUMENTED_IMPORT).** Gaia explicitly imports and contrasts object-oriented/FUSION modelling ideas. This edge does not assert a direct AGENT0-to-Gaia derivation. A documented relationship does not establish comparative superiority. [AOSE-S001; AOSE-S013; AOSE-S033]

**GE-02 — G-02 → G-07 (DOCUMENTED_INFLUENCE).** Tropos explicitly adopts i*-style actor/goal requirements concepts. A documented relationship does not establish comparative superiority. [AOSE-S004; AOSE-S010; AOSE-S059]

**GE-03 — G-03 → G-08 (DOCUMENTED_IMPORT).** Prometheus connects detailed agent design with BDI concepts rather than requiring every AOSE branch to be BDI. A documented relationship does not establish comparative superiority. [AOSE-S007; AOSE-S012]

**GE-04 — G-06 → G-12 (EXPLICIT_EXTENSION).** O-MaSE presents itself as a customisable organisational evolution of MaSE. A documented relationship does not establish comparative superiority. [AOSE-S009; AOSE-S015; AOSE-S016]

**GE-05 — G-05 → G-11 (EXPLICIT_EXTENSION).** Extended Gaia is explicitly an organisational extension; full details remain access-limited. A documented relationship does not establish comparative superiority. [AOSE-S014; AOSE-S001]

**GE-06 — G-09 → G-12 (SHARED_ANCESTRY).** Agile PASSI and configurable Agent OPEN/O-MaSE approaches draw on method-fragment/tailoring ideas. No direct Agile-PASSI-to-O-MaSE transmission is inferred; the agile hybrid is documented within G-09. A documented relationship does not establish comparative superiority. [AOSE-S008; AOSE-S003]

**GE-07 — G-09 → G-14 (HYBRIDISATION).** ASPECS documents PASSI and RIO antecedents for its organisational/service approach. A documented relationship does not establish comparative superiority. [AOSE-S022]

**GE-08 — G-04 → G-10 (SHARED_ANCESTRY).** Both inherit knowledge/agent modelling concerns; no direct MAS-CommonKADS-to-INGENIAS derivation is asserted. Shared ancestry does not establish direct influence. [AOSE-S018; AOSE-S041]

**GE-09 — G-15 → G-16 (CRITICISM_AND_RESPONSE).** Public commitments and information-oriented enactment address the open-compliance limitations of private mental-state accounts. A documented relationship does not establish comparative superiority. [AOSE-S021; AOSE-S037; AOSE-S045]

**GE-10 — G-08 → G-17 (EXPLICIT_EXTENSION).** The consistency checker explicitly consumes Prometheus/PDT agent designs. A documented relationship does not establish comparative superiority. [AOSE-S054; AOSE-S007]

**GE-11 — G-03 → G-17 (EXPLICIT_EXTENSION).** BDI decision/program models are the explicit subjects of verification and testability work. A documented relationship does not establish comparative superiority. [AOSE-S012; AOSE-S023; AOSE-S024; AOSE-S030; AOSE-S049]

**GE-12 — G-12 → G-22 (DOCUMENTED_IMPORT).** This study explicitly imports method-tailoring mechanisms, while marking its own composition as analytical. A documented relationship does not establish comparative superiority. [AOSE-S003; AOSE-S009; AOSE-S017]

**GE-13 — G-13 → G-12 (ONLY_ANALOGOUS).** Both adapt development to context, but cooperative emergence and fragment tailoring operate on different objects. Vocabulary similarity is not evidence of derivation or semantic equivalence. [AOSE-S040; AOSE-S003]

**GE-14 — G-05 → G-12 (CRITICISM_AND_RESPONSE).** Organisation-based engineering contrasts static/design limitations with explicit organisational and capability models; not every such mechanism is attributed to Gaia. A documented relationship does not establish comparative superiority. [AOSE-S001; AOSE-S016]

**GE-15 — G-18 → G-22 (CRITICISM_AND_RESPONSE).** Comparative evidence limits constrain rather than establish this analytical composition’s effectiveness. A documented relationship does not establish comparative superiority. [AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S045]

**GE-16 — G-25 → G-20 (DOCUMENTED_IMPORT).** The DevOps/EMAS proposal explicitly imports operational software practices; the forum itself is not the source of those practices. A documented relationship does not establish comparative superiority. [AOSE-S029; AOSE-S028]

**GE-17 — G-19 → G-21 (UNRESOLVED_RELATIONSHIP).** Current EMAS materials document forum continuity and inclusion of classical, learned and hybrid agents. They do not demonstrate direct historical derivation for each modern framework. A documented relationship does not establish comparative superiority. [AOSE-S005; AOSE-S051]

**GE-18 — G-03 → G-21 (EXPLICIT_EXTENSION).** ChatBDI and the plan-generation/self-evolution papers explicitly use BDI or AgentSpeak-related architectures. A documented relationship does not establish comparative superiority. [AOSE-S052; AOSE-S056; AOSE-S057]

**GE-19 — G-16 → G-23 (DOMAIN_TRANSLATION).** The BSPL–SARL paper explicitly translates interaction specifications into a particular executable agent language. This translation is not in itself an LLM hybrid. A documented relationship does not establish comparative superiority. [AOSE-S036; AOSE-S037]

**GE-20 — G-20 → G-21 (CONVERGENT_DEVELOPMENT).** Modern trace/fault-injection work and prior lifecycle engineering confront similar operational gaps; direct historical derivation is not inferred. A documented relationship does not establish comparative superiority. [AOSE-S029; AOSE-S035]

**GE-21 — G-07 → G-22 (DOCUMENTED_IMPORT).** The current synthesis deliberately uses requirements distinctions; its combination is the researcher’s responsibility, not an established Tropos theorem. A documented relationship does not establish comparative superiority. [AOSE-S004; AOSE-S059]

**GE-22 — G-16 → G-22 (DOCUMENTED_IMPORT).** Public-obligation semantics inform the analytical reconfiguration burden without supplying a universal transfer theorem. A documented relationship does not establish comparative superiority. [AOSE-S037; AOSE-S045]

**GE-23 — G-17 → G-22 (DOCUMENTED_IMPORT).** Assurance/model-grounding distinctions constrain the composed decision, without composing incompatible formal guarantees. A documented relationship does not establish comparative superiority. [AOSE-S023; AOSE-S030; AOSE-S031; AOSE-S054]

**GE-24 — G-01 → G-21 (UNRESOLVED_RELATIONSHIP).** For modern frameworks without documentary linkage, conceptual resemblance does not establish direct AOSE descent. This is an explicit unresolved historical relation, not an unexamined mandatory family. [AOSE-S033; AOSE-S047; AOSE-S050]

**GE-25 — G-23 → G-21 (EXPLICIT_EXTENSION).** ChatBDI explicitly integrates generated communication/plans with Jason/JaCaMo. This establishes one documented contemporary continuation, not ancestry for all agent frameworks. A small demonstrator does not establish comparative lifecycle superiority. [AOSE-S052]


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_SCOPE_AND_CARICATURES

The unit of inquiry is an engineering mechanism in its lifecycle and organisational context. AOP supplies programming abstractions; MAS supplies interaction and collective-system concerns; AOSE asks how engineers construct and maintain justified systems using such abstractions. These are intersecting bodies of work, not exclusive compartments. No sibling synthesis was used to decide their findings. [AOSE-S013; AOSE-S033; AOSE-S055]

A method is not a runtime. A modelling language is not a procedure for discovering the right model. An application using agents does not establish which engineering method caused its outcomes. A current coding-agent framework may be relevant without having documented AOSE ancestry. These distinctions control inclusion and evidence classification rather than exclude inconvenient overlap.

The following caricatures are rejected: every active component should be an agent; one role means one process; a completed goal graph establishes stakeholder completeness; generated syntax establishes protocol meaning; a private belief proves external fulfilment; every published lifecycle diagram must be instantiated; more agents or more phases imply greater maturity; a successful demonstration proves a whole methodology. The adverse candidates remain individually counted.

| Method / branch | Actual engineering emphasis | Manual boundary / selection limit | Sources |
| --- | --- | --- | --- |
| i* / Tropos | Strategic actors, goals, dependencies; early/late requirements through design | Analysts must validate meanings and transformations, not equate world actors with runtime agents. | AOSE-S004, AOSE-S010, AOSE-S034, AOSE-S059, AOSE-S060 |
| Gaia / extended Gaia | Role responsibilities, permissions, activities, protocols and organisation | Original static/cooperative scope is explicit; extended article access is bounded; collective-role fulfilment is not supplied by naming multiple holders. | AOSE-S001, AOSE-S014 |
| MaSE / O-MaSE | Goal/task refinement, agent classes and conversations; configurable organisational process | Known capabilities and method-fragment consistency need actual enactment; a default process is not a universal lifecycle ordering. | AOSE-S003, AOSE-S009, AOSE-S015, AOSE-S016 |
| Prometheus | System specification, architecture and detailed agent/internal design | Iterative design and tool support leave percept/action grounding and manual realisation obligations. | AOSE-S007, AOSE-S054 |
| PASSI / Agile PASSI | Requirements-to-implementation models, code reuse, deployment model; situational lighter process | Reuse/prototype feasibility is not causal cost reduction. Agile tailoring changes process rather than making every original view mandatory. | AOSE-S008, AOSE-S039 |
| INGENIAS | Metamodel/views, design guidance and model-driven implementation | Tool-generated artefacts preserve only specified mappings; design rationale and manual duties do not disappear. | AOSE-S018, AOSE-S019, AOSE-S046 |
| Agent OPEN | Reusable process/task support with situational method assembly | Available task detail and consumer fit matter more than counting fragments; omitted source appendix is not invented. | AOSE-S017 |
| ADELFE / ASPECS / MAS-CommonKADS | Cooperation-driven emergence; hierarchical organisations/services; knowledge/task modelling | Different assumptions: unknown emergent solution, near-decomposable organisation, or knowledge-intensive task. They are alternatives, not a mandatory combined stack. | AOSE-S022, AOSE-S040, AOSE-S041 |
| AUML / commitments / information protocols | Conversation views, public obligations, global-to-local enactment | Ordering, public meaning, delivery assumptions and implementation semantics differ; no universal notation wins. | AOSE-S020, AOSE-S021, AOSE-S036, AOSE-S037, AOSE-S043, AOSE-S045 |


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER

The complete denominator is **83**, and all **83** candidates are examined. Exactly one primary disposition is assigned per candidate. Examination does not imply retention; retention does not imply universal obligation or measured effect. The complete records, ten-field domain profiles, evidence partitions, criticisms, cheap paths and relationships are in [EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json](EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_PROPERTY_LEDGER.json).

| Primary disposition | Count |
| --- | --- |
| ASSUMPTION_SENSITIVE | 9 |
| CEREMONY_NOT_GENERAL_PROPERTY | 2 |
| CONTESTED | 1 |
| CONTEXT_DEPENDENT | 11 |
| DOMAIN_SPECIFIC | 3 |
| DUPLICATE_CANDIDATE | 3 |
| NO_GENERAL_PROPERTY | 1 |
| REJECTED_OR_DISFAVOURED | 9 |
| RETAINED_IN_EVOLVED_FORM | 32 |
| STRONGLY_RETAINED | 7 |
| SUPERSEDED_BY_STRONGER_FORM | 1 |
| UNRESOLVED | 1 |
| USEFUL_BUT_EASILY_BUREAUCRATISED | 1 |
| USEFUL_BUT_EASILY_GAMED | 2 |

| ID | Candidate | Primary disposition | Family |
| --- | --- | --- | --- |
| EAOSE-001 | Affected-actor discovery and validation | RETAINED_IN_EVOLVED_FORM | O1 |
| EAOSE-002 | Separate stakeholder goals, runtime goals and acceptance conditions | STRONGLY_RETAINED | O1 |
| EAOSE-003 | Dependency and delegation vulnerability analysis | RETAINED_IN_EVOLVED_FORM | O1 |
| EAOSE-004 | Explicit goal conflict and alternative rationale | USEFUL_BUT_EASILY_GAMED | O1 |
| EAOSE-005 | Security constraints and delegation authority | RETAINED_IN_EVOLVED_FORM | O1 |
| EAOSE-006 | Revalidate goals when operating assumptions change | RETAINED_IN_EVOLVED_FORM | O1 |
| EAOSE-007 | A complete goal diagram proves complete requirements | REJECTED_OR_DISFAVOURED | O1 |
| EAOSE-008 | Justify the semantic fit of agency | STRONGLY_RETAINED | O2 |
| EAOSE-009 | Decouple agent-oriented analysis from runtime commitment | CONTEXT_DEPENDENT | O2 |
| EAOSE-010 | Bound delegated autonomy by capabilities and constraints | RETAINED_IN_EVOLVED_FORM | O2 |
| EAOSE-011 | Lifecycle cost and non-agent comparator | RETAINED_IN_EVOLVED_FORM | O2 |
| EAOSE-012 | Every active component should be an agent | REJECTED_OR_DISFAVOURED | O2 |
| EAOSE-013 | Role contracts separate responsibilities, permissions and activities | RETAINED_IN_EVOLVED_FORM | O3 |
| EAOSE-014 | Separate safety from progress obligations | STRONGLY_RETAINED | O3 |
| EAOSE-015 | Explicit many-to-many role-to-agent binding | RETAINED_IN_EVOLVED_FORM | O3 |
| EAOSE-016 | Organisation-level rules supplement local role contracts | RETAINED_IN_EVOLVED_FORM | O3 |
| EAOSE-017 | Capability-based dynamic reassignment | ASSUMPTION_SENSITIVE | O3 |
| EAOSE-018 | Environment and shared resources as engineered objects | RETAINED_IN_EVOLVED_FORM | O3 |
| EAOSE-019 | Static cooperative organisation as a universal premise | SUPERSEDED_BY_STRONGER_FORM | O3 |
| EAOSE-020 | Interaction specifications with explicit meaning and enactment | RETAINED_IN_EVOLVED_FORM | O4 |
| EAOSE-021 | Shared content and ontology interpretation | RETAINED_IN_EVOLVED_FORM | O4 |
| EAOSE-022 | Global-to-local protocol correspondence | ASSUMPTION_SENSITIVE | O4 |
| EAOSE-023 | Public commitment semantics for open interaction | CONTEXT_DEPENDENT | O4 |
| EAOSE-024 | Private mental states as the basis of communication compliance | CONTESTED | O4 |
| EAOSE-025 | Specified exceptional interaction and recovery | RETAINED_IN_EVOLVED_FORM | O4 |
| EAOSE-026 | Versioned protocol compatibility | RETAINED_IN_EVOLVED_FORM | O4 |
| EAOSE-027 | FIPA message compliance guarantees full interoperability | REJECTED_OR_DISFAVOURED | O4 |
| EAOSE-028 | Select an agent-internal architecture to match the decision problem | CONTEXT_DEPENDENT | O5 |
| EAOSE-029 | Percept-to-belief and action-to-effect correspondence | STRONGLY_RETAINED | O5 |
| EAOSE-030 | Plan applicability, achievement and failure conditions | RETAINED_IN_EVOLVED_FORM | O5 |
| EAOSE-031 | Interference among concurrent intentions | ASSUMPTION_SENSITIVE | O5 |
| EAOSE-032 | Semantics-aware model transformation | ASSUMPTION_SENSITIVE | O5 |
| EAOSE-033 | Explicit manual completion and integration duties | RETAINED_IN_EVOLVED_FORM | O5 |
| EAOSE-034 | Bidirectional design–implementation traceability | USEFUL_BUT_EASILY_BUREAUCRATISED | O5 |
| EAOSE-035 | Generated syntax establishes behavioural correctness | REJECTED_OR_DISFAVOURED | O5 |
| EAOSE-036 | Semantic compatibility of method fragments | ASSUMPTION_SENSITIVE | O6 |
| EAOSE-037 | Executable prescriptions and work-product consumers | RETAINED_IN_EVOLVED_FORM | O6 |
| EAOSE-038 | Iterative cross-view feedback rather than mandatory phase order | RETAINED_IN_EVOLVED_FORM | O6 |
| EAOSE-039 | Proportional method assembly and retirement | RETAINED_IN_EVOLVED_FORM | O6 |
| EAOSE-040 | Context-checked pattern reuse | CONTEXT_DEPENDENT | O6 |
| EAOSE-041 | Learnability and tool-maintenance fit | CONTEXT_DEPENDENT | O6 |
| EAOSE-042 | Method quality equals named-phase or diagram count | CEREMONY_NOT_GENERAL_PROPERTY | O6 |
| EAOSE-043 | Stakeholder validation is distinct from implementation verification | STRONGLY_RETAINED | O7 |
| EAOSE-044 | Assure both individual behaviour and collective outcomes | STRONGLY_RETAINED | O7 |
| EAOSE-045 | Explicit model and environment assumptions for formal assurance | ASSUMPTION_SENSITIVE | O7 |
| EAOSE-046 | Implementation-level decision-code verification | DOMAIN_SPECIFIC | O7 |
| EAOSE-047 | Design-to-protocol consistency checks | ASSUMPTION_SENSITIVE | O7 |
| EAOSE-048 | Oracle adequacy and false-success tests | USEFUL_BUT_EASILY_GAMED | O7 |
| EAOSE-049 | Simulation-to-deployment validity | ASSUMPTION_SENSITIVE | O7 |
| EAOSE-050 | Discriminating fault and perturbation testing | RETAINED_IN_EVOLVED_FORM | O7 |
| EAOSE-051 | Runtime observations linked to assurance claims | RETAINED_IN_EVOLVED_FORM | O7 |
| EAOSE-052 | Exhaustive testing guarantees unrestricted autonomous behaviour | REJECTED_OR_DISFAVOURED | O7 |
| EAOSE-053 | Deployment and legacy-integration obligations | RETAINED_IN_EVOLVED_FORM | O8 |
| EAOSE-054 | Versioned implementation and configuration evidence | RETAINED_IN_EVOLVED_FORM | O8 |
| EAOSE-055 | Operational feedback to maintained engineering models | RETAINED_IN_EVOLVED_FORM | O8 |
| EAOSE-056 | Authorised evolution within explicit revision boundaries | RETAINED_IN_EVOLVED_FORM | O8 |
| EAOSE-057 | Selective assurance revalidation after change | RETAINED_IN_EVOLVED_FORM | O8 |
| EAOSE-058 | Retirement preserves or resolves outstanding obligations | CONTEXT_DEPENDENT | O8 |
| EAOSE-059 | Design-method support implies a complete operational lifecycle | REJECTED_OR_DISFAVOURED | O8 |
| EAOSE-060 | Separate demonstrated mechanism, deployment and comparative benefit | STRONGLY_RETAINED | O9 |
| EAOSE-061 | Cost attribution and source non-independence | RETAINED_IN_EVOLVED_FORM | O9 |
| EAOSE-062 | Whole-method superiority over conventional engineering | UNRESOLVED | O9 |
| EAOSE-063 | Popularity, venue participation or framework maturity proves benefit | NO_GENERAL_PROPERTY | O9 |
| EAOSE-064 | Named-method observance as assurance | CEREMONY_NOT_GENERAL_PROPERTY | O9 |
| EAOSE-065 | Documented continuity rather than retrospective rebranding | RETAINED_IN_EVOLVED_FORM | O10 |
| EAOSE-066 | Cost-aware and repeatable stochastic evaluation | RETAINED_IN_EVOLVED_FORM | O10 |
| EAOSE-067 | Generated plans remain subject to executable constraints | ASSUMPTION_SENSITIVE | O10 |
| EAOSE-068 | Tool authority is enforced outside untrusted generated instructions | RETAINED_IN_EVOLVED_FORM | O10 |
| EAOSE-069 | Memory and retrieved-content provenance boundaries | CONTEXT_DEPENDENT | O10 |
| EAOSE-070 | Regression after model, prompt or remote-service changes | RETAINED_IN_EVOLVED_FORM | O10 |
| EAOSE-071 | Cross-agent trace correlation for diagnosis | CONTEXT_DEPENDENT | O10 |
| EAOSE-072 | A role prompt is a formal role contract | REJECTED_OR_DISFAVOURED | O10 |
| EAOSE-073 | Criterion–authority–effect coupling | RETAINED_IN_EVOLVED_FORM | COMPOSITION |
| EAOSE-074 | Evidence continuity through change as a separate new property | DUPLICATE_CANDIDATE | COMPOSITION |
| EAOSE-075 | Purposeful retirement of method machinery as a separate new property | DUPLICATE_CANDIDATE | COMPOSITION |
| EAOSE-076 | Obligation-preserving organisational reconfiguration | CONTEXT_DEPENDENT | COMPOSITION |
| EAOSE-077 | Hierarchical organisational decomposition | DOMAIN_SPECIFIC | O3 |
| EAOSE-078 | Cooperation-driven self-organisation | DOMAIN_SPECIFIC | O3 |
| EAOSE-079 | Knowledge and task modelling as distinct engineering views | CONTEXT_DEPENDENT | O1 |
| EAOSE-080 | A consistent fragment composition guarantees achievable goals | REJECTED_OR_DISFAVOURED | O7 |
| EAOSE-081 | Counterexample propagation as a distinct new control | DUPLICATE_CANDIDATE | COMPOSITION |
| EAOSE-082 | Observation plus self-revision guarantees improvement | REJECTED_OR_DISFAVOURED | COMPOSITION |
| EAOSE-083 | Preserve responsiveness during long-running plan generation | CONTEXT_DEPENDENT | O10 |

The 66 conditional audit entries comprise 65 favourable/conditional dispositions plus the contested private-state compliance candidate. Seventeen entries are limitation, rejection, duplicate, supersession, ceremony or unresolved records. This partition has no relationship to the unverified earlier denominator of 66. A single adequate implementation can address multiple retained concerns.


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_DOMAIN_MODELS

These models supply the ten required domain-profile dimensions and make the relationships operational. They are explicitly analytical reconstructions of source mechanisms, not a claim that the literature contains one uniform metamodel.

### DM-O1 — Requirements and social dependencies

**Objects and relations —** A requirement view contains actors A, candidate goals G, constraints C and dependency tuples (depender, dependee, dependum, condition). A separate relation links each accepted goal to runtime realisations and an acceptance observation. Unknown actors and disputed goals remain visible; absence from A is not evidence of irrelevance.

**Decision procedure —** Accept a boundary provisionally only after a credible actor-discovery and challenge process. Reject a proposed realisation when it changes a goal meaning or delegates beyond the relevant permission; unresolved preferences require the legitimate stakeholder decision, not automatic graph arithmetic.

**Feedback and failure —** An unmet consequence can falsify an acceptance translation, a plan, or the original requirement. Route the observation to the implicated view; the existence of a passing internal goal flag does not close the inquiry.

**Property population —** EAOSE-001, EAOSE-002, EAOSE-003, EAOSE-004, EAOSE-005, EAOSE-006, EAOSE-007, EAOSE-079

**Methodology and lifecycle scope —** Early organisational inquiry, requirements negotiation and later revalidation; not automatic requirements generation.

**Stakeholder goal and requirement semantics —** Distinguish affected actors, desired outcomes, soft qualities, tasks, dependencies and runtime goals. An acceptance observation is a separate translation.

**Agent abstraction justification —** Intentional/social analysis can be useful without selecting an autonomous runtime.

**Role organisation and agent mapping —** Map real stakeholders and delegated responsibilities before assigning implementation roles. A stakeholder is not necessarily a software agent.

**Interaction specification and protocol semantics —** Dependency agreements and validation exchanges require understood terms and participation; diagram edges do not obtain consent.

**Design to implementation correspondence —** Carry consequential requirements into constraints, executable choices and evidence without equating their representations.

**Verification validation and test oracle —** Use stakeholder challenge, conflict examples and outcome criteria. A structurally complete graph cannot serve as its own external oracle.

**Tool support and manual obligations —** Editors/checkers organise models; analysts still discover actors, elicit meaning and negotiate disputed priorities.

**Deployment evolution and traceability —** Changed needs, resources or evidence reopen affected mappings; do not require a complete organisational remodel for every edit.

**Comparative evidence cost and non agent alternative —** Compare improved decisions against modelling/negotiation cost; ordinary requirements practices may supply the same function.

[AOSE-S004; AOSE-S010; AOSE-S038; AOSE-S059; AOSE-S060]

### DM-O2 — Agent-paradigm selection

**Objects and relations —** Treat design selection as a comparison of candidate implementations against a common task envelope: needed decisions, allowed discretion, distributed information, quality bounds and lifecycle resource budget. Agency is a semantic design choice, not an ontological reward for a sufficiently complicated component.

**Decision procedure —** Select the least burdensome candidate meeting the actual requirements with adequate evidence. Greater autonomy is valuable only where it improves relevant choices or relations; an agent-oriented analysis can survive a decision against an agent runtime.

**Feedback and failure —** A new baseline, integration cost or predictable repeated failure can reopen abstraction choice without repudiating every agent-oriented concept.

**Property population —** EAOSE-008, EAOSE-009, EAOSE-010, EAOSE-011, EAOSE-012

**Methodology and lifecycle scope —** Architecture selection and periodic reassessment across construction, operation and maintenance.

**Stakeholder goal and requirement semantics —** Hold the required consequences and constraints stable enough to compare alternative designs rather than rewarding a changed task.

**Agent abstraction justification —** Justify agency by delegated discretion, situated choices, interaction or organisational semantics; distribution and message passing alone are insufficient.

**Role organisation and agent mapping —** Count conceptual roles separately from runtime entities and justify control boundaries rather than maximising agent count.

**Interaction specification and protocol semantics —** Compare negotiated or information-dependent interactions with conventional calls, events, actors and workflows.

**Design to implementation correspondence —** Check whether the chosen implementation actually provides the discretion or accountability invoked by its agent description.

**Verification validation and test oracle —** Evaluate representative outcomes, failure modes and lifecycle cost against an appropriate non-agent baseline.

**Tool support and manual obligations —** Include expertise, platform operation, debugging and vendor dependence; a theoretically expressive abstraction may be impractical for a team.

**Deployment evolution and traceability —** Reassess when the task becomes simpler, coordination changes, or operating cost overwhelms the original justification.

**Comparative evidence cost and non agent alternative —** Allow a controller, workflow, object/service design or mixed system to dominate on the declared criteria. No universal AOSE productivity result is assumed.

[AOSE-S033; AOSE-S055; AOSE-S025; AOSE-S047; AOSE-S048; AOSE-S060; AOSE-S061]

### DM-O3 — Organisational decomposition

**Objects and relations —** The organisation model has roles R, agents A, capability relation K, assignment relation B⊆A×R, resource permissions and collective constraints. Safety predicates exclude forbidden combinations; progress claims require stated conditions. A separate live-obligation state records effects already owed, not merely roles currently assigned.

**Decision procedure —** Approve a binding only if capabilities and collective constraints support its responsibilities. For a change, structural validity alone is insufficient when previous interactions remain live; preserve, discharge or explicitly contest those obligations.

**Feedback and failure —** Failed capability, duplicate action or a leaving participant can interrupt ordinary execution. An organisation may have no feasible replacement; explicit inability is preferable to declaring reassignment successful.

**Property population —** EAOSE-013, EAOSE-014, EAOSE-015, EAOSE-016, EAOSE-017, EAOSE-018, EAOSE-019, EAOSE-077, EAOSE-078

**Methodology and lifecycle scope —** Analysis, architectural decomposition, role instantiation and guarded organisational change.

**Stakeholder goal and requirement semantics —** Collective goals and constraints are allocated without assuming that their conjunction follows from individually successful agents.

**Agent abstraction justification —** Organisation is useful when responsibility and coordinated discretion matter; a role model does not demand one process per role.

**Role organisation and agent mapping —** Use a relation B between agents and roles, plus capabilities, multiplicity and incompatibility constraints. Many-to-many binding needs explicit fulfilment semantics.

**Interaction specification and protocol semantics —** Role contracts consume protocols and may create public obligations that outlive a particular assignment.

**Design to implementation correspondence —** Bind conceptual permissions and responsibilities to actual resources and behaviours; structural membership does not enforce compliance.

**Verification validation and test oracle —** Check both safety and progress under capability, cooperation, fairness and environment assumptions; distinguish static feasibility from continuity.

**Tool support and manual obligations —** Model/tool support does not certify capability reports or automatically settle conflicting authority.

**Deployment evolution and traceability —** Reconfiguration must inspect live work and obligations; static cooperative designs remain a legitimate branch where their assumptions hold.

**Comparative evidence cost and non agent alternative —** Dynamic assignment and hierarchy introduce observation and coordination costs. Prefer a flat/static mapping where sufficient; self-organisation is not a default.

[AOSE-S001; AOSE-S009; AOSE-S014; AOSE-S016; AOSE-S022; AOSE-S040; AOSE-S044]

### DM-O4 — Interaction engineering

**Objects and relations —** Keep three related views: messages and content; local information/behaviour; public interaction meaning. A commitment C(debtor, creditor, antecedent, consequent) does not specify the debtor’s internal reasoning or guarantee discharge. Projection/generation establishes only its stated correspondence within its model.

**Decision procedure —** Select ordering constraints only when required by information, business meaning or safety. Test whether independently implemented participants can enact the same commitments or completion criteria, including rejection and timeouts.

**Feedback and failure —** A received message may show only a claim of delivery. An unexpected or incompatible exchange must reach the protocol/interpretation decision rather than being repaired only by accepting more input.

**Property population —** EAOSE-020, EAOSE-021, EAOSE-022, EAOSE-023, EAOSE-024, EAOSE-025, EAOSE-026, EAOSE-027

**Methodology and lifecycle scope —** Protocol analysis, local realisation, integration testing and evolution across independent participants.

**Stakeholder goal and requirement semantics —** An interaction must serve a stakeholder dependency or goal and specify what counts as its consequential completion.

**Agent abstraction justification —** Open interaction permits private decision procedures; a global script can be unnecessarily restrictive.

**Role organisation and agent mapping —** Distinguish protocol roles from process instances, public principals and private internal states.

**Interaction specification and protocol semantics —** Specify content interpretation, information availability, correlation, exceptional outcomes and, where appropriate, debtor–creditor commitments.

**Design to implementation correspondence —** Check global/local correspondence, adapters and platform bindings under explicit delivery and observation assumptions.

**Verification validation and test oracle —** Use permitted/forbidden traces, completion conditions, failure injections and externally grounded effect evidence; schema compliance is only one layer.

**Tool support and manual obligations —** AUML, finite-state/Petri-net and information-protocol tools offer different analyses; programmers still realise communications and domain meaning.

**Deployment evolution and traceability —** Version changes and in-flight conversations need compatibility or a deliberately coordinated transition.

**Comparative evidence cost and non agent alternative —** Formal/open protocols pay off when autonomy or heterogeneity warrants them. A direct call or small agreed state machine may be adequate.

[AOSE-S020; AOSE-S021; AOSE-S036; AOSE-S037; AOSE-S043; AOSE-S045; AOSE-S054]

### DM-O5 — Internal design and implementation

**Objects and relations —** For a BDI branch, separate world state W, observations O, belief state B, goal/intention state I, plan selection and enacted effects. The maps W→O→B and chosen action→W are engineering obligations distinct from logical properties of deliberation. For other architectures retain the boundary obligations without inventing beliefs or intentions.

**Decision procedure —** A plan must have an applicable context and a defensible achievement/failure criterion. A generated representation is accepted only for the preservation actually established, with manual/external dependencies separately tested.

**Feedback and failure —** Concurrent intentions can invalidate one another’s contexts. A failed effect may require fixing a sensor binding rather than deliberation; a delayed generated plan may be stale even if well formed.

**Property population —** EAOSE-028, EAOSE-029, EAOSE-030, EAOSE-031, EAOSE-032, EAOSE-033, EAOSE-034, EAOSE-035

**Methodology and lifecycle scope —** Agent-internal design, transformation, coding, integration and change-impact analysis.

**Stakeholder goal and requirement semantics —** Beliefs represent information, desires/goals represent objectives and intentions concern commitments to activity; none is identical to external truth or legitimate stakeholder approval.

**Agent abstraction justification —** BDI is one architectural branch; reactive, imperative and conventional implementations remain alternatives.

**Role organisation and agent mapping —** Internal plan/capability structures implement role duties but do not replace collective allocation.

**Interaction specification and protocol semantics —** Message reception, internal events, tool actions and externally visible commitments need explicit correspondence.

**Design to implementation correspondence —** Describe what a generator preserves, what programmers complete, and which percept/action bindings remain outside it.

**Verification validation and test oracle —** Check contexts, false success, failure handling, concurrency and grounded effects; compilation does not establish achievement.

**Tool support and manual obligations —** Language semantics and runtime support must be checked at the actual binding/version; natural-language descriptions still require human interpretation.

**Deployment evolution and traceability —** Manual changes, model changes and remote plan generation can invalidate different parts of the assurance argument.

**Comparative evidence cost and non agent alternative —** Use direct behaviours or handwritten code where modelling/generation cost exceeds benefit; preserve critical correspondence without insisting on every diagram.

[AOSE-S007; AOSE-S012; AOSE-S018; AOSE-S023; AOSE-S031; AOSE-S033; AOSE-S039; AOSE-S049; AOSE-S056]

### DM-O6 — Method comparison and composition

**Objects and relations —** Represent a method fragment by input meanings, actor competence, decision procedure, output meaning, consumer and preconditions. A composition connects actual outputs to compatible inputs and records unresolved semantic gaps. A runnable composition is not thereby a jointly feasible system or an empirically superior method.

**Decision procedure —** Use a fragment only when its consumer needs the distinction or intervention it provides. Full form is triggered by actual complexity/risk, not by a method brand. Retire it only after checking relied-on assurance and coordination functions.

**Feedback and failure —** A failed implementation, stale model or unused work product can reopen fragment selection. Removing a low-frequency preventive task requires a risk argument, not a usage counter.

**Property population —** EAOSE-036, EAOSE-037, EAOSE-038, EAOSE-039, EAOSE-040, EAOSE-041, EAOSE-042

**Methodology and lifecycle scope —** Method selection, situational assembly, enactment, reuse and retirement across the lifecycle actually needed.

**Stakeholder goal and requirement semantics —** Do not equate goal, task, role or requirement labels across metamodels without matching their semantics.

**Agent abstraction justification —** A methodology is optional machinery for engineering agency, not proof that agency is needed.

**Role organisation and agent mapping —** Method actors are engineers/analysts/testers and consumers of artefacts; these are not automatically runtime agents.

**Interaction specification and protocol semantics —** Fragments communicate through understood work products and decisions; matching file formats or diagram names is insufficient.

**Design to implementation correspondence —** Check producer/consumer and transformation obligations between fragments, including what remains manual.

**Verification validation and test oracle —** Evaluate executable guidance, internal consistency and actual decision usefulness separately from demonstrated effectiveness.

**Tool support and manual obligations —** Account for training, tool support, omitted task definitions and the cost of maintaining additional views.

**Deployment evolution and traceability —** Feedback may revisit any affected view; retain dependency ordering without prescribing a universal waterfall or iteration count.

**Comparative evidence cost and non agent alternative —** A small coherent method can be preferable to maximal lifecycle coverage. Select, substitute, omit or retire according to live consumers and protected obligations.

[AOSE-S002; AOSE-S003; AOSE-S008; AOSE-S009; AOSE-S017; AOSE-S034; AOSE-S046]

### DM-O7 — Verification, validation and test oracles

**Objects and relations —** An assurance claim is (subject, property, assumptions, configuration, evidence, observation relation). A proof may establish model⊨property under assumptions; it does not establish that the deployed world satisfies those assumptions. An empirical result samples behaviours under a defined oracle and cannot inherit a universal quantifier.

**Decision procedure —** Accept only the claim matched by the evidence type. Combine checks when they address different gaps; do not average a proof, a demonstration and stakeholder approval into a single confidence number.

**Feedback and failure —** An oracle contradiction, assumption change or mismatched configuration invalidates or narrows the affected assurance claim. A false positive in a partial-model checker warrants investigation, not automatic defect attribution.

**Property population —** EAOSE-043, EAOSE-044, EAOSE-045, EAOSE-046, EAOSE-047, EAOSE-048, EAOSE-049, EAOSE-050, EAOSE-051, EAOSE-052, EAOSE-080

**Methodology and lifecycle scope —** Requirements validation, design analysis, unit/agent/collective testing, formal verification and runtime assurance.

**Stakeholder goal and requirement semantics —** Distinguish doing the specified thing from specifying an acceptable thing; a goal-completion flag is not the entire acceptance oracle.

**Agent abstraction justification —** Autonomy and adaptation enlarge behaviours to examine; formalisation or constrained autonomy may be justified rather than assumed.

**Role organisation and agent mapping —** Agent correctness and collective correctness have different subjects and assumptions.

**Interaction specification and protocol semantics —** Protocol/model checks constrain traces, but private state, asynchronous failure and external effects can remain outside the proof.

**Design to implementation correspondence —** Model-checking a decision program narrows one gap; libraries, observation mappings and deployment may remain unverified.

**Verification validation and test oracle —** State the guarantee, model, oracle, coverage, environment assumptions and residual uncertainty. Simulation and mutation scores are bounded evidence.

**Tool support and manual obligations —** Proof/checking tools require sound encodings and interpretable counterexamples; test engineers still choose meaningful oracles.

**Deployment evolution and traceability —** Monitor invalid assumptions and revalidate impacted claims; neither all-path testing nor continuous observation is automatically feasible.

**Comparative evidence cost and non agent alternative —** Use the cheapest adequate test/analysis for the consequence at issue; high-assurance branches require more evidence, not merely more test cases.

[AOSE-S023; AOSE-S024; AOSE-S030; AOSE-S031; AOSE-S035; AOSE-S049; AOSE-S053; AOSE-S054; AOSE-S062]

### DM-O8 — Deployment and evolution

**Objects and relations —** Keep an operational configuration C and a set of claims indexed to C and their relied-on assumptions. For a change Δ, classify each affected claim as retain, narrow, reassess or withdraw. This is a selective engineering judgement, not a universal automatic dependency solver.

**Decision procedure —** Authorise the change at the level it affects: implementation choices inside an envelope are different from changing the envelope or goal. An agent retirement must account for ongoing responsibilities, not merely delete a process.

**Feedback and failure —** Incident observations can trigger a code fix, a model correction, a narrowed claim or requirement renegotiation. The successor configuration does not certify itself merely by changing its score definition.

**Property population —** EAOSE-053, EAOSE-054, EAOSE-055, EAOSE-056, EAOSE-057, EAOSE-058, EAOSE-059

**Methodology and lifecycle scope —** Integration, deployment configuration, operation, incident response, controlled change and retirement.

**Stakeholder goal and requirement semantics —** Keep accepted goals and constraints meaningful after release; operational success cannot silently redefine acceptance.

**Agent abstraction justification —** An agent runtime adds coordination and monitoring obligations but does not remove conventional operational engineering.

**Role organisation and agent mapping —** Engineers, operators, affected users and authorised decision makers exchange responsibility without assuming they are identical.

**Interaction specification and protocol semantics —** Observe actual peer versions, active conversations, unfinished work and external-service effects.

**Design to implementation correspondence —** Associate deployed code, models, prompts and interfaces with evaluated configurations and consequential design decisions.

**Verification validation and test oracle —** Use change-impact evidence, replay/regression where meaningful and targeted new observation; preserve unaffected evidence only with a dependency argument.

**Tool support and manual obligations —** Design tools alone may not support operations. Deployment bindings and observation limits need explicit engineering completion.

**Deployment evolution and traceability —** Permitted adaptation has a boundary; changes to goals, policies or acceptance require distinct approval and preservation of live obligations.

**Comparative evidence cost and non agent alternative —** Prefer a coordinated upgrade or planned drain where it avoids permanent adaptation machinery. Cheap continuity is valid; unobserved drift is not.

[AOSE-S029; AOSE-S031; AOSE-S035; AOSE-S044; AOSE-S050; AOSE-S057]

### DM-O9 — Adoption and comparative evidence

**Objects and relations —** The evidence unit is a study or a distinct application/experiment within it, with intervention, setting, sample, comparator, measures and uncertainty. Maintain a shared-origin relation between editions, datasets and programmes. Source count and citation count cannot stand in for replication.

**Decision procedure —** Assign a claim only the evidence role its study can support. Separate conceptual plausibility, reported field use, measured local differences and causal generalisation.

**Feedback and failure —** A newly recovered null result or confounded baseline can narrow a benefit claim without changing a formal theorem or a documented historical relationship.

**Property population —** EAOSE-060, EAOSE-061, EAOSE-062, EAOSE-063, EAOSE-064

**Methodology and lifecycle scope —** Evaluation of engineering claims, reported applications, method adoption and total cost; not an application runtime model.

**Stakeholder goal and requirement semantics —** Define the claimed benefit and comparison task before counting adoption or improvement.

**Agent abstraction justification —** Agent applications, platforms and full methodologies are different units of analysis.

**Role organisation and agent mapping —** Research participants and reporting organisations matter as study units; no runtime role mapping is required for a bibliographic evidence judgement.

**Interaction specification and protocol semantics —** Identify shared industrial programmes, papers, datasets and evaluators; repeated descriptions are not independent replications.

**Design to implementation correspondence —** Attributed benefit must identify the intervention actually used, including tools and conventional process components.

**Verification validation and test oracle —** Inspect sample, comparator, outcome measure, uncertainty and validity threats. A case demonstrates possibility, not population frequency.

**Tool support and manual obligations —** Costs include training, modelling, execution and maintenance; missing costs remain missing rather than zero.

**Deployment evolution and traceability —** Longitudinal maintenance and operational outcomes are separate from a demonstration or deployment announcement.

**Comparative evidence cost and non agent alternative —** Keep whole-method superiority unresolved without suitable comparative evidence; absence of strong comparison does not erase narrower useful mechanisms.

[AOSE-S002; AOSE-S025; AOSE-S026; AOSE-S042; AOSE-S045; AOSE-S048; AOSE-S050; AOSE-S061; AOSE-S062]

### DM-O10 — Modern translations and learned components

**Objects and relations —** A learned component is a versioned, possibly stochastic mapping embedded in a wider engineered system. Separate prompt/input authority, generated proposal, admitted action, observed effect and assessment. A trace is evidence of a run, not a complete account of unobserved alternatives or causal responsibility.

**Decision procedure —** Use explicit delegation and admissible capabilities outside untrusted text. Generate plans only when the benefit over a prewritten plan justifies semantic checks, latency and operational cost.

**Feedback and failure —** A provider change, prompt injection, incoherent output or delayed result can interrupt execution. Rejection and fallback are legitimate outcomes; a successful next run does not erase the failed one.

**Property population —** EAOSE-065, EAOSE-066, EAOSE-067, EAOSE-068, EAOSE-069, EAOSE-070, EAOSE-071, EAOSE-072, EAOSE-083

**Methodology and lifecycle scope —** Engineering of learned, tool-using and hybrid agents, including evaluation, security, deployment and regression.

**Stakeholder goal and requirement semantics —** Generated goals/plans are proposals, not automatic stakeholder requirements; an evaluation score is a chosen oracle.

**Agent abstraction justification —** Classical agency and current LLM use overlap but neither implies documented historical inheritance from the other.

**Role organisation and agent mapping —** Role prompts are behavioural inputs, not automatically enforceable obligations; human owners and affected parties remain external participants.

**Interaction specification and protocol semantics —** Tool outputs, memory and peer text may be untrusted; explicit interface meaning and authority must survive language generation.

**Design to implementation correspondence —** Parsers, guardrails and generators establish different guarantees; admit only executable capabilities whose effects can be checked.

**Verification validation and test oracle —** Evaluate stochastic runs, configurations, costs, failures and grounded outcomes. Trace judges and model-based graders are fallible measurement instruments.

**Tool support and manual obligations —** Inspect documented integrations such as Jason/JaCaMo or AgentSpeak-based generation, without claiming every framework inherits AOSE.

**Deployment evolution and traceability —** Model/provider/prompt/tool changes can trigger regression. Slow generation needs cancellation/resumption and stale-state handling when concurrent duties matter.

**Comparative evidence cost and non agent alternative —** Compare with fixed workflows, prewritten plans and non-agent baselines; small prototypes and coding benchmarks do not establish broad lifecycle superiority.

[AOSE-S005; AOSE-S035; AOSE-S047; AOSE-S048; AOSE-S050; AOSE-S051; AOSE-S052; AOSE-S053; AOSE-S056; AOSE-S057; AOSE-S062]

### DM-COMPOSITION — Coupled engineering decisions

**Objects and relations —** Compose a relation among requirement relevance R(d), permitted-and-capable enactment A(d), and defensible consequence evidence E(d) for decision d. This is a cross-view constraint, not a claim that all three are decidable or sufficient for every real-world approval. Separately, reconfiguration must map prior live obligations into the successor organisation or report a justified non-transfer. The pre-action and post-action uses of evidence are different: a prediction may justify a bounded experiment, while only subsequent appropriate evidence can support an outcome claim.

**Decision procedure —** A contradiction in one view can block or reopen the corresponding decision in the others. Structural compatibility is not goal feasibility; observation plus self-revision is not guaranteed improvement.

**Feedback and failure —** Counterexamples propagate through existing traceability and review loops. A mechanism already subsumed by change-impact analysis or tailoring is not counted again merely because composition makes it salient.

**Property population —** EAOSE-073, EAOSE-074, EAOSE-075, EAOSE-076, EAOSE-081, EAOSE-082

**Methodology and lifecycle scope —** Within-tradition analytical synthesis across requirements, authority, enactment, evidence and change; not a newly discovered academic methodology.

**Stakeholder goal and requirement semantics —** A criterion must remain tied to the affected stakeholder need when used to accept an action or outcome.

**Agent abstraction justification —** The minimal configuration may use conventional software; composition does not require increasing autonomy.

**Role organisation and agent mapping —** Authority to decide, capability to act and responsibility for live obligations remain distinct across role holders.

**Interaction specification and protocol semantics —** Communicate disputed criteria, permitted actions, observed effects and outstanding obligations to the decision they can change.

**Design to implementation correspondence —** Join consequential mappings across views rather than inferring correctness from each view independently.

**Verification validation and test oracle —** Test counterexamples in which individually plausible views jointly permit a wrong decision. Analytical tests do not constitute empirical validation.

**Tool support and manual obligations —** Reuse existing records and checks; do not create a new control for every named synthesis relation.

**Deployment evolution and traceability —** Reconfiguration and evidence change are evaluated against predecessor obligations; method machinery can be retired without deleting its protected function.

**Comparative evidence cost and non agent alternative —** Only two distinct composition-induced candidates are retained here; duplicate feedback/change/retirement labels remain counted but not extra obligations.

[AOSE-S003; AOSE-S004; AOSE-S009; AOSE-S021; AOSE-S031; AOSE-S037; AOSE-S038; AOSE-S045; AOSE-S059]


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_CEREMONY_STRIPPING_LEDGER

Every candidate has an explicit stripping entry, including non-retained labels. The test is functional: what discrimination, coordination, action or evidence would disappear? A rarely used preventive model may still be necessary; a frequently produced diagram may have no consumer. A simpler adequate alternative does not mean that every representation should always be simplified.

### CS-001 — EAOSE-001

**Artefact / ritual / brand —** Affected-actor discovery and validation treated as a named deliverable or compliance item

**Protected function and failure —** Relevant actor concerns and disputed exclusions are recorded and can change requirements. Failure boundary: Actor modelling provides a vocabulary, not an algorithm guaranteeing discovery; the analyst can exclude inconvenient participants.

**Consumer and prerequisites —** Requirements analyst with affected actors and the legitimate requirements decision maker property inputs: None, subject to the stated absence explanation.. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. Actor modelling provides a vocabulary, not an algorithm guaranteeing discovery; the analyst can exclude inconvenient participants.. absence reason: This is a boundary/selection inquiry or independently posed candidate; it has no mandatory earlier property in this corpus..

**Minimal adequate alternative —** A small stakeholder discussion and explicit exclusions can suffice; do not draw a full organisational model for a self-contained utility.

**Fuller-form trigger —** The system redistributes work, information, discretion or consequences among people or organisations.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Relevant actor concerns and disputed exclusions are recorded and can change requirements.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain a discover-and-challenge activity, not an exhaustive actor census. The absent-stakeholder counterexample defeats the stronger completeness claim.

### CS-002 — EAOSE-002

**Artefact / ritual / brand —** Separate stakeholder goals, runtime goals and acceptance conditions treated as a named deliverable or compliance item

**Protected function and failure —** A runtime success flag alone cannot discharge an unobserved external outcome. Failure boundary: A test can faithfully encode the wrong need; acceptance judgements may remain partly human.

**Consumer and prerequisites —** Requirements analyst with affected actors and the legitimate requirements decision maker property inputs: EAOSE-001. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. A test can faithfully encode the wrong need; acceptance judgements may remain partly human..

**Minimal adequate alternative —** One requirement with a direct test is enough where the mapping is trivial.

**Fuller-form trigger —** A goal is decomposed, delegated or made executable.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A runtime success flag alone cannot discharge an unobserved external outcome.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain the distinction strongly: runtime goal satisfaction and accepted stakeholder consequence have different truth conditions. No productivity theorem is implied.

### CS-003 — EAOSE-003

**Artefact / ritual / brand —** Dependency and delegation vulnerability analysis treated as a named deliverable or compliance item

**Protected function and failure —** Critical dependencies have an accepted reliance basis or an explicit unresolved exposure. Failure boundary: A dependency edge neither obtains consent nor supplies capacity; adding dependencies can centralise hidden risk.

**Consumer and prerequisites —** Requirements analyst with affected actors and the legitimate requirements decision maker property inputs: EAOSE-001; EAOSE-002. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. A dependency edge neither obtains consent nor supplies capacity; adding dependencies can centralise hidden risk..

**Minimal adequate alternative —** Use a direct agreement or ordinary interface contract for one stable dependency.

**Fuller-form trigger —** A requirement depends on another actor outside the requester’s immediate control.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Critical dependencies have an accepted reliance basis or an explicit unresolved exposure.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain dependencies as vulnerabilities to investigate, not as presumed consent or reliable delivery.

### CS-004 — EAOSE-004

**Artefact / ritual / brand —** Explicit goal conflict and alternative rationale treated as a named deliverable or compliance item

**Protected function and failure —** The chosen alternative has a revisitable rationale and unresolved conflicts are visible. Failure boundary: Qualitative labels and weights can rationalise a predetermined choice; graph arithmetic does not establish stakeholder preference.

**Consumer and prerequisites —** Requirements analyst with affected actors and the legitimate requirements decision maker property inputs: EAOSE-001; EAOSE-002. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. Qualitative labels and weights can rationalise a predetermined choice; graph arithmetic does not establish stakeholder preference..

**Minimal adequate alternative —** Document the concrete choice and decisive evidence without elaborate softgoal scoring when it is clear.

**Fuller-form trigger —** Different stakeholders or feasible designs favour incompatible outcomes.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: The chosen alternative has a revisitable rationale and unresolved conflicts are visible.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain contribution/conflict analysis but mark it gameable because qualitative judgements can encode preferences without validating them.

### CS-005 — EAOSE-005

**Artefact / ritual / brand —** Security constraints and delegation authority treated as a named deliverable or compliance item

**Protected function and failure —** An intended action is not admitted solely because it advances a goal or appears in a plan. Failure boundary: Security-goal models need enforcement and threat assumptions; declared trust is not evidence of trustworthy behaviour.

**Consumer and prerequisites —** Requirements analyst with affected actors and the legitimate requirements decision maker property inputs: EAOSE-001; EAOSE-003. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. Security-goal models need enforcement and threat assumptions; declared trust is not evidence of trustworthy behaviour..

**Minimal adequate alternative —** Use an existing narrow access-control boundary with an explicit caller contract when sufficient.

**Fuller-form trigger —** An agent receives privileged data, delegated resources or power to affect another actor.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: An intended action is not admitted solely because it advances a goal or appears in a plan.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain security/authority mapping with a separately realised enforcement boundary; a trusted label is not trustworthy execution.

### CS-006 — EAOSE-006

**Artefact / ritual / brand —** Revalidate goals when operating assumptions change treated as a named deliverable or compliance item

**Protected function and failure —** Affected requirements receive an explicit retained, revised or withdrawn judgement. Failure boundary: Continuous reopening can prevent delivery; a changed goal still requires legitimate acceptance rather than unilateral runtime preference.

**Consumer and prerequisites —** Requirements analyst with affected actors and the legitimate requirements decision maker property inputs: EAOSE-002; EAOSE-003. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. Continuous reopening can prevent delivery; a changed goal still requires legitimate acceptance rather than unilateral runtime preference..

**Minimal adequate alternative —** No new requirements exercise for a change shown not to affect meaning or consequences.

**Fuller-form trigger —** Stakeholders, environmental conditions or the meaning of success materially change.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Affected requirements receive an explicit retained, revised or withdrawn judgement.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Extend iterative requirements reasoning to material operating changes, not continuous unbounded re-elicitation. Runtime revision cannot unilaterally redefine acceptance.

### CS-007 — EAOSE-007

**Artefact / ritual / brand —** A complete goal diagram proves complete requirements treated as a named deliverable or compliance item

**Protected function and failure —** Diagram completeness is never reported as demonstrated completeness of real needs. Failure boundary: Models can be internally complete over an incorrectly chosen boundary.

**Consumer and prerequisites —** Requirements analyst with affected actors and the legitimate requirements decision maker property inputs: EAOSE-001; EAOSE-002. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. Models can be internally complete over an incorrectly chosen boundary..

**Minimal adequate alternative —** Ask an omitted-actor or false-success question before adding any diagram.

**Fuller-form trigger —** A model is offered as sufficient acceptance evidence.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Diagram completeness is never reported as demonstrated completeness of real needs.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Reject the universal inference through the missing-actor counterexample; no allegation is made that all goal-method authors assert it.

### CS-008 — EAOSE-008

**Artefact / ritual / brand —** Justify the semantic fit of agency treated as a named deliverable or compliance item

**Protected function and failure —** The rationale identifies a semantic benefit and costs rather than a fashionable component label. Failure boundary: Autonomy and distribution can also be engineered with conventional constructs; fit is not a universal productivity theorem.

**Consumer and prerequisites —** Architect and responsible engineering/product decision makers property inputs: None, subject to the stated absence explanation.. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win. Autonomy and distribution can also be engineered with conventional constructs; fit is not a universal productivity theorem.. absence reason: This is a boundary/selection inquiry or independently posed candidate; it has no mandatory earlier property in this corpus..

**Minimal adequate alternative —** Retain a conventional design where it meets the same requirements with less complexity.

**Fuller-form trigger —** The engineer is choosing the modelling or execution paradigm.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: The rationale identifies a semantic benefit and costs rather than a fashionable component label.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain the comparative semantic-fit question strongly; agency is an optional abstraction with discriminable costs and alternatives.

### CS-009 — EAOSE-009

**Artefact / ritual / brand —** Decouple agent-oriented analysis from runtime commitment treated as a named deliverable or compliance item

**Protected function and failure —** No framework or complete method is required merely because an actor-goal model was useful. Failure boundary: Translation can erase intentional or organisational semantics; the implementation must still satisfy the selected requirements.

**Consumer and prerequisites —** Architect and responsible engineering/product decision makers property inputs: EAOSE-002; EAOSE-008. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win. Translation can erase intentional or organisational semantics; the implementation must still satisfy the selected requirements..

**Minimal adequate alternative —** Use a conventional implementation and retain only decision-relevant analysis.

**Fuller-form trigger —** Organisational analysis is valuable but runtime autonomy is unnecessary or existing infrastructure dominates.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: No framework or complete method is required merely because an actor-goal model was useful.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain conditionally because removing an agent runtime can preserve some requirements while losing others; the translation needs evidence.

### CS-010 — EAOSE-010

**Artefact / ritual / brand —** Bound delegated autonomy by capabilities and constraints treated as a named deliverable or compliance item

**Protected function and failure —** Runtime choice cannot silently expand the authority or resources originally delegated. Failure boundary: An envelope expressed only in prose may not constrain execution; overly narrow bounds eliminate the useful adaptation.

**Consumer and prerequisites —** Architect and responsible engineering/product decision makers property inputs: EAOSE-005; EAOSE-008. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win. An envelope expressed only in prose may not constrain execution; overly narrow bounds eliminate the useful adaptation..

**Minimal adequate alternative —** A deterministic function or explicit approval can replace autonomous selection when variability adds no value.

**Fuller-form trigger —** Behaviour is selected at runtime rather than completely prescribed by a caller.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Runtime choice cannot silently expand the authority or resources originally delegated.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain discretion within explicit capabilities and constraints. This is not a demand that every choice be pre-scripted.

### CS-011 — EAOSE-011

**Artefact / ritual / brand —** Lifecycle cost and non-agent comparator treated as a named deliverable or compliance item

**Protected function and failure —** The decision distinguishes architectural capability from evidenced incremental benefit. Failure boundary: Historical baselines, bundled tools and expert teams confound attribution; a benchmark winner is not a lifecycle winner.

**Consumer and prerequisites —** Architect and responsible engineering/product decision makers property inputs: EAOSE-008. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win. Historical baselines, bundled tools and expert teams confound attribution; a benchmark winner is not a lifecycle winner..

**Minimal adequate alternative —** For a reversible small choice, a short measured spike or reasoned cost screen is adequate.

**Fuller-form trigger —** A deployment or methodology choice is justified by claimed benefit.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: The decision distinguishes architectural capability from evidenced incremental benefit.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain lifecycle/non-agent comparison as the evidential burden for claimed advantage; missing cost data is not zero cost.

### CS-012 — EAOSE-012

**Artefact / ritual / brand —** Every active component should be an agent treated as a named deliverable or compliance item

**Protected function and failure —** Agent count is not used as a maturity measure. Failure boundary: Rejecting this universal does not prohibit agents in domains where interaction or autonomous choice is genuinely useful.

**Consumer and prerequisites —** Architect and responsible engineering/product decision makers property inputs: EAOSE-008. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win. Rejecting this universal does not prohibit agents in domains where interaction or autonomous choice is genuinely useful..

**Minimal adequate alternative —** Keep a function, service, workflow or ordinary actor.

**Fuller-form trigger —** Agent proliferation is proposed without a distinct responsibility or choice problem.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Agent count is not used as a maturity measure.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Reject activity alone as a universal reason for agentisation; preserve cases in which autonomous choice genuinely matters.

### CS-013 — EAOSE-013

**Artefact / ritual / brand —** Role contracts separate responsibilities, permissions and activities treated as a named deliverable or compliance item

**Protected function and failure —** Every consequential role has interpretable obligations and access boundaries. Failure boundary: Gaia permissions primarily concern resources; they must not be inflated into all forms of real-world authorisation.

**Consumer and prerequisites —** Organisation designer; operators or delegated organisational controller for permitted runtime changes property inputs: EAOSE-002; EAOSE-005. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. Gaia permissions primarily concern resources; they must not be inflated into all forms of real-world authorisation..

**Minimal adequate alternative —** A compact responsibility/interface table is sufficient for a small stable arrangement.

**Fuller-form trigger —** Several participants must coordinate around differentiated responsibilities.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Every consequential role has interpretable obligations and access boundaries.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain separate responsibilities, permissions, private activities and interactions, without upgrading resource permissions into a universal authority theory.

### CS-014 — EAOSE-014

**Artefact / ritual / brand —** Separate safety from progress obligations treated as a named deliverable or compliance item

**Protected function and failure —** A system that does nothing safely is not misclassified as meeting its progress requirement. Failure boundary: Liveness under fairness is not a real-time response guarantee; safety can depend on environmental abstraction.

**Consumer and prerequisites —** Organisation designer; operators or delegated organisational controller for permitted runtime changes property inputs: EAOSE-002; EAOSE-013. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. Liveness under fairness is not a real-time response guarantee; safety can depend on environmental abstraction..

**Minimal adequate alternative —** A direct invariant plus bounded completion test may suffice without temporal logic.

**Fuller-form trigger —** Correctness includes both avoiding harm and eventually doing useful work.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A system that does nothing safely is not misclassified as meeting its progress requirement.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain safety/progress separation strongly because avoiding a bad state and eventually producing a good one are not equivalent; deadlines require extra assumptions.

### CS-015 — EAOSE-015

**Artefact / ritual / brand —** Explicit many-to-many role-to-agent binding treated as a named deliverable or compliance item

**Protected function and failure —** Each required obligation has a viable assignment without accidental gaps or conflicting execution. Failure boundary: Multiplicity of role holders is not itself a design for collective fulfilment. Original Gaia explicitly leaves the collective-realisation case unelaborated; replication can duplicate action or induce mutual waiting.

**Consumer and prerequisites —** Organisation designer; operators or delegated organisational controller for permitted runtime changes property inputs: EAOSE-013; EAOSE-014. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. Multiplicity of role holders is not itself a design for collective fulfilment. Original Gaia explicitly leaves the collective-realisation case unelaborated; replication can duplicate action or induce mutual waiting..

**Minimal adequate alternative —** One documented binding is enough for a fixed single-provider role.

**Fuller-form trigger —** Roles are shared, combined, replicated or reassigned.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Each required obligation has a viable assignment without accidental gaps or conflicting execution.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain explicit mapping and fulfilment semantics. Do not attribute a complete collective-role solution to original Gaia, which leaves that case open.

### CS-016 — EAOSE-016

**Artefact / ritual / brand —** Organisation-level rules supplement local role contracts treated as a named deliverable or compliance item

**Protected function and failure —** A locally permitted assignment can be refused when it violates a collective constraint. Failure boundary: Organisational rules may be descriptive rather than enforced; a single institutional agent can create a bottleneck.

**Consumer and prerequisites —** Organisation designer; operators or delegated organisational controller for permitted runtime changes property inputs: EAOSE-013; EAOSE-015. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. Organisational rules may be descriptive rather than enforced; a single institutional agent can create a bottleneck..

**Minimal adequate alternative —** An ordinary shared invariant or configuration rule can replace a separate organisation model.

**Fuller-form trigger —** Local correctness permits an invalid collective organisation.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A locally permitted assignment can be refused when it violates a collective constraint.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain collective organisation constraints, but require an actual consumer or enforcement/checking mechanism rather than treating a diagram as compliance.

### CS-017 — EAOSE-017

**Artefact / ritual / brand —** Capability-based dynamic reassignment treated as a named deliverable or compliance item

**Protected function and failure —** A reassigned role has capability evidence and satisfies the current structural constraints. Failure boundary: Capabilities may be misreported or stale; feasible local reassignment need not preserve outstanding interactions.

**Consumer and prerequisites —** Organisation designer; operators or delegated organisational controller for permitted runtime changes property inputs: EAOSE-010; EAOSE-015; EAOSE-016. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. Capabilities may be misreported or stale; feasible local reassignment need not preserve outstanding interactions..

**Minimal adequate alternative —** Static assignment or operator-controlled reassignment when the organisation is stable.

**Fuller-form trigger —** Membership, capabilities or failure conditions change during operation.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A reassigned role has capability evidence and satisfies the current structural constraints.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain conditionally on capability knowledge, feasible assignments and appropriate organisational assumptions; combine with continuity when live obligations exist.

### CS-018 — EAOSE-018

**Artefact / ritual / brand —** Environment and shared resources as engineered objects treated as a named deliverable or compliance item

**Protected function and failure —** Reasoning correctness is not used to excuse an untested sensor, resource or actuator boundary. Failure boundary: An environment model can omit dynamics or hide authority; shared artefacts can introduce contention.

**Consumer and prerequisites —** Organisation designer; operators or delegated organisational controller for permitted runtime changes property inputs: EAOSE-005; EAOSE-010. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. An environment model can omit dynamics or hide authority; shared artefacts can introduce contention..

**Minimal adequate alternative —** A tested ordinary API with explicit preconditions and effects is adequate.

**Fuller-form trigger —** Important effects pass through shared resources, sensors or external services.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Reasoning correctness is not used to excuse an untested sensor, resource or actuator boundary.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain environment/resources as engineered boundaries. A framework’s environment layer does not prove faithful sensing or effects.

### CS-019 — EAOSE-019

**Artefact / ritual / brand —** Static cooperative organisation as a universal premise treated as a named deliverable or compliance item

**Protected function and failure —** The selected method states rather than silently strengthens its organisational assumptions. Failure boundary: An extension named open does not support arbitrary adversaries; adaptive branches retain their own preconditions.

**Consumer and prerequisites —** Organisation designer; operators or delegated organisational controller for permitted runtime changes property inputs: EAOSE-015; EAOSE-016; EAOSE-017. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. An extension named open does not support arbitrary adversaries; adaptive branches retain their own preconditions..

**Minimal adequate alternative —** Keep the original simpler branch when its assumptions are actually stable.

**Fuller-form trigger —** An original closed-world method is transferred to dynamic, open or competing participants.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: The selected method states rather than silently strengthens its organisational assumptions.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Supersede the universal static premise with guarded models; a stable cooperative implementation remains valid within its declared scope.

### CS-020 — EAOSE-020

**Artefact / ritual / brand —** Interaction specifications with explicit meaning and enactment treated as a named deliverable or compliance item

**Protected function and failure —** Both implementers can explain the same observed interaction and its obligations. Failure boundary: Sequence diagrams can overconstrain autonomous choices or leave exceptional paths unspecified.

**Consumer and prerequisites —** Protocol designers, implementers and the principals participating in an interaction property inputs: EAOSE-003; EAOSE-013. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Sequence diagrams can overconstrain autonomous choices or leave exceptional paths unspecified..

**Minimal adequate alternative —** A simple request/response contract with failure cases may suffice.

**Fuller-form trigger —** Independently implemented components must coordinate.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Both implementers can explain the same observed interaction and its obligations.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain interaction meaning and enactment while allowing different notations and partial orders; do not force all autonomous interaction into a global sequence.

### CS-021 — EAOSE-021

**Artefact / ritual / brand —** Shared content and ontology interpretation treated as a named deliverable or compliance item

**Protected function and failure —** A valid message is interpreted consistently with its declared protocol and domain context. Failure boundary: Matching schemas can still conceal differing units, time horizons or institutional meaning.

**Consumer and prerequisites —** Protocol designers, implementers and the principals participating in an interaction property inputs: EAOSE-020. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Matching schemas can still conceal differing units, time horizons or institutional meaning..

**Minimal adequate alternative —** A shared typed schema and a few interpretation tests suffice when meaning is unambiguous.

**Fuller-form trigger —** Different components exchange semantically significant data.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A valid message is interpreted consistently with its declared protocol and domain context.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain shared interpretation as an integration obligation distinct from schema validation; domain terms can disagree despite identical fields.

### CS-022 — EAOSE-022

**Artefact / ritual / brand —** Global-to-local protocol correspondence treated as a named deliverable or compliance item

**Protected function and failure —** Permitted global runs are realisable and invalid local combinations are detected under the stated model. Failure boundary: Syntax-preserving projection need not preserve behaviour; reliable-delivery or complete-information assumptions may fail.

**Consumer and prerequisites —** Protocol designers, implementers and the principals participating in an interaction property inputs: EAOSE-020; EAOSE-021. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Syntax-preserving projection need not preserve behaviour; reliable-delivery or complete-information assumptions may fail..

**Minimal adequate alternative —** Joint contract tests can be adequate for a short bounded exchange.

**Fuller-form trigger —** A global protocol is projected or compiled into independently executing agents.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Permitted global runs are realisable and invalid local combinations are detected under the stated model.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain a correspondence claim only under the source/target and delivery assumptions actually analysed.

### CS-023 — EAOSE-023

**Artefact / ritual / brand —** Public commitment semantics for open interaction treated as a named deliverable or compliance item

**Protected function and failure —** Parties can contest or establish fulfilment from agreed public events rather than alleged private intention. Failure boundary: Observable messages need not establish actual delivery; commitments do not compel compliance or settle contested institutions.

**Consumer and prerequisites —** Protocol designers, implementers and the principals participating in an interaction property inputs: EAOSE-003; EAOSE-005; EAOSE-020. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Observable messages need not establish actual delivery; commitments do not compel compliance or settle contested institutions..

**Minimal adequate alternative —** A conventional explicit service agreement may suffice; closed cooperative internals need not use commitments.

**Fuller-form trigger —** Independent parties need accountable interaction without access to one another’s internal beliefs.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Parties can contest or establish fulfilment from agreed public events rather than alleged private intention.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain public commitments where independently controlled participants need meaningful public obligations; a simple closed call may not need this machinery.

### CS-024 — EAOSE-024

**Artefact / ritual / brand —** Private mental states as the basis of communication compliance treated as a named deliverable or compliance item

**Protected function and failure —** The communication claim states whether private-state assumptions are checked, stipulated or unavailable. Failure boundary: Singh’s objection targets open compliance; it does not show that BDI reasoning inside a controlled agent is useless.

**Consumer and prerequisites —** Protocol designers, implementers and the principals participating in an interaction property inputs: EAOSE-020; EAOSE-023. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Singh’s objection targets open compliance; it does not show that BDI reasoning inside a controlled agent is useless..

**Minimal adequate alternative —** Use public commitments or operational interface conditions for heterogeneous open participants.

**Fuller-form trigger —** The claimed meaning of a message depends on beliefs or intentions attributed to its sender.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: The communication claim states whether private-state assumptions are checked, stipulated or unavailable.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Preserve the contest between private mental-state and public social accounts at the correct boundary. Open compliance is the objection, not internal BDI reasoning itself.

### CS-025 — EAOSE-025

**Artefact / ritual / brand —** Specified exceptional interaction and recovery treated as a named deliverable or compliance item

**Protected function and failure —** An exceptional exchange reaches a known state without fabricating completion. Failure boundary: Retries can duplicate effects; timeouts do not prove that a remote effect did not occur.

**Consumer and prerequisites —** Protocol designers, implementers and the principals participating in an interaction property inputs: EAOSE-020; EAOSE-021. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Retries can duplicate effects; timeouts do not prove that a remote effect did not occur..

**Minimal adequate alternative —** Use a simple fail-and-report policy where retry or compensation would add risk.

**Fuller-form trigger —** Communication or delegated work can fail or be delayed.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: An exceptional exchange reaches a known state without fabricating completion.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain exceptional outcomes as part of interaction semantics; bounded recovery is not a promise that every failure can be reversed.

### CS-026 — EAOSE-026

**Artefact / ritual / brand —** Versioned protocol compatibility treated as a named deliverable or compliance item

**Protected function and failure —** A mixed-version interaction is either supported by evidence or explicitly refused. Failure boundary: Version labels alone do not prove compatibility; an adapter can preserve fields while changing commitments.

**Consumer and prerequisites —** Protocol designers, implementers and the principals participating in an interaction property inputs: EAOSE-021; EAOSE-022; EAOSE-025. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Version labels alone do not prove compatibility; an adapter can preserve fields while changing commitments..

**Minimal adequate alternative —** An atomic coordinated upgrade can avoid a permanent compatibility layer.

**Fuller-form trigger —** Peers may run mixed versions or interfaces evolve independently.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A mixed-version interaction is either supported by evidence or explicitly refused.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain version compatibility as an explicitly analytical lifecycle translation of interaction and deployment requirements, not an original universal AOSE standard.

### CS-027 — EAOSE-027

**Artefact / ritual / brand —** FIPA message compliance guarantees full interoperability treated as a named deliverable or compliance item

**Protected function and failure —** Standard compliance is reported at the layer it establishes, not as an end-to-end guarantee. Failure boundary: The standard intentionally separates fields and referenced semantics; this rejection does not negate its useful common structure.

**Consumer and prerequisites —** Protocol designers, implementers and the principals participating in an interaction property inputs: EAOSE-020; EAOSE-021. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. The standard intentionally separates fields and referenced semantics; this rejection does not negate its useful common structure..

**Minimal adequate alternative —** Test the actual cross-implementation interaction and resulting effects.

**Fuller-form trigger —** A standards or middleware badge is offered as a complete integration argument.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Standard compliance is reported at the layer it establishes, not as an end-to-end guarantee.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Reject full interoperability from message structure; the standard’s own limitations and public-meaning distinctions support the narrower judgement.

### CS-028 — EAOSE-028

**Artefact / ritual / brand —** Select an agent-internal architecture to match the decision problem treated as a named deliverable or compliance item

**Protected function and failure —** Internal concepts have an implementation interpretation rather than merely anthropomorphic labels. Failure boundary: A method’s support for BDI does not make BDI obligatory or sufficient for every autonomous component.

**Consumer and prerequisites —** Agent designer, programmer and boundary-integration engineer property inputs: EAOSE-008; EAOSE-010; EAOSE-018. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. A method’s support for BDI does not make BDI obligatory or sufficient for every autonomous component..

**Minimal adequate alternative —** A direct state machine or ordinary behaviour implementation may be sufficient.

**Fuller-form trigger —** An agent’s internal decision mechanism is being designed.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Internal concepts have an implementation interpretation rather than merely anthropomorphic labels.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain architecture choice contextually: BDI, imperative/reactive behaviour and ordinary implementation make different commitments.

### CS-029 — EAOSE-029

**Artefact / ritual / brand —** Percept-to-belief and action-to-effect correspondence treated as a named deliverable or compliance item

**Protected function and failure —** A correct internal belief update or action request is not mistaken for a correct measurement or achieved effect. Failure boundary: Ground beliefs may be wrong; successful tool return can occur without the intended external consequence.

**Consumer and prerequisites —** Agent designer, programmer and boundary-integration engineer property inputs: EAOSE-018; EAOSE-028. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. Ground beliefs may be wrong; successful tool return can occur without the intended external consequence..

**Minimal adequate alternative —** Direct boundary tests and observable effect checks may suffice.

**Fuller-form trigger —** Correct decisions depend on sensors, tools, actuators or state-estimation assumptions.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A correct internal belief update or action request is not mistaken for a correct measurement or achieved effect.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain grounding strongly. A correct inference from a false belief or a successfully requested but ineffective action cannot establish external achievement.

### CS-030 — EAOSE-030

**Artefact / ritual / brand —** Plan applicability, achievement and failure conditions treated as a named deliverable or compliance item

**Protected function and failure —** A plan is neither selected outside its context nor treated as successful solely because its steps terminated. Failure boundary: Plan libraries can be incomplete and contexts stale; goal persistence can waste resources or conflict with changed needs.

**Consumer and prerequisites —** Agent designer, programmer and boundary-integration engineer property inputs: EAOSE-002; EAOSE-028; EAOSE-029. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. Plan libraries can be incomplete and contexts stale; goal persistence can waste resources or conflict with changed needs..

**Minimal adequate alternative —** A single guarded action with a failure result is enough for a simple task.

**Fuller-form trigger —** An agent selects among plans or persists with an intention.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A plan is neither selected outside its context nor treated as successful solely because its steps terminated.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain explicit applicability and success/failure conditions; termination and success are not synonymous.

### CS-031 — EAOSE-031

**Artefact / ritual / brand —** Interference among concurrent intentions treated as a named deliverable or compliance item

**Protected function and failure —** An individually valid plan cannot silently invalidate another plan’s relied-on preconditions. Failure boundary: Serialisation may miss deadlines; exhaustive interleavings can be infeasible and concurrency models omit physical effects.

**Consumer and prerequisites —** Agent designer, programmer and boundary-integration engineer property inputs: EAOSE-014; EAOSE-018; EAOSE-030. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. Serialisation may miss deadlines; exhaustive interleavings can be infeasible and concurrency models omit physical effects..

**Minimal adequate alternative —** Serialise a small critical region when this preserves required responsiveness.

**Fuller-form trigger —** Plans overlap in time or manipulate shared state.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: An individually valid plan cannot silently invalidate another plan’s relied-on preconditions.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain interference examination under stated scheduler/resource/environment models; complete interleaving coverage may be infeasible.

### CS-032 — EAOSE-032

**Artefact / ritual / brand —** Semantics-aware model transformation treated as a named deliverable or compliance item

**Protected function and failure —** A transformation claim identifies precisely what preservation has been established. Failure boundary: Correct generation can implement wrong requirements; formal preservation need not cover libraries, deployment or remote services.

**Consumer and prerequisites —** Agent designer, programmer and boundary-integration engineer property inputs: EAOSE-022; EAOSE-028; EAOSE-030. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. Correct generation can implement wrong requirements; formal preservation need not cover libraries, deployment or remote services..

**Minimal adequate alternative —** Hand implementation with focused correspondence tests is sufficient where generation has no benefit.

**Fuller-form trigger —** Models generate code, protocol adapters or executable plans.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A transformation claim identifies precisely what preservation has been established.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain semantics-preserving transformation only for the declared property and mapping, not all stakeholder, platform or environmental claims.

### CS-033 — EAOSE-033

**Artefact / ritual / brand —** Explicit manual completion and integration duties treated as a named deliverable or compliance item

**Protected function and failure —** Generated coverage does not cause unimplemented obligations to disappear from acceptance. Failure boundary: A checklist can conceal absent implementation expertise; generated percentage is not quality or effort saved.

**Consumer and prerequisites —** Agent designer, programmer and boundary-integration engineer property inputs: EAOSE-029; EAOSE-032. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. A checklist can conceal absent implementation expertise; generated percentage is not quality or effort saved..

**Minimal adequate alternative —** A short generated/manual boundary note is adequate when remaining work is small.

**Fuller-form trigger —** A methodology or tool produces only part of the executable system.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Generated coverage does not cause unimplemented obligations to disappear from acceptance.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain manual completion as real work. Generation percentages neither erase responsibilities nor establish saved effort.

### CS-034 — EAOSE-034

**Artefact / ritual / brand —** Bidirectional design–implementation traceability treated as a named deliverable or compliance item

**Protected function and failure —** A changed or failing implementation identifies the relevant claim and responsible decision. Failure boundary: Link coverage can be high while meaning is stale; maintaining unused links becomes a cost without a consumer.

**Consumer and prerequisites —** Agent designer, programmer and boundary-integration engineer property inputs: EAOSE-002; EAOSE-032; EAOSE-033. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. Link coverage can be high while meaning is stale; maintaining unused links becomes a cost without a consumer..

**Minimal adequate alternative —** Stable names, tests and a few explicit links may suffice instead of a trace repository.

**Fuller-form trigger —** Several representations or teams can drift apart during development or change.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A changed or failing implementation identifies the relevant claim and responsible decision.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain consumer-linked bidirectional traceability but flag bureaucratisation: link completeness without maintained meaning has little assurance value.

### CS-035 — EAOSE-035

**Artefact / ritual / brand —** Generated syntax establishes behavioural correctness treated as a named deliverable or compliance item

**Protected function and failure —** The assurance claim does not exceed the checked semantics. Failure boundary: This rejection preserves valid bounded transformation theorems; it targets their unwarranted extension.

**Consumer and prerequisites —** Agent designer, programmer and boundary-integration engineer property inputs: EAOSE-029; EAOSE-032; EAOSE-034. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. This rejection preserves valid bounded transformation theorems; it targets their unwarranted extension..

**Minimal adequate alternative —** State its narrower guarantee and test or verify the missing correspondence.

**Fuller-form trigger —** A successful generator or compiler is offered as end-to-end assurance.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: The assurance claim does not exceed the checked semantics.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Reject syntax as behavioural assurance, while preserving actual bounded transformation results.

### CS-036 — EAOSE-036

**Artefact / ritual / brand —** Semantic compatibility of method fragments treated as a named deliverable or compliance item

**Protected function and failure —** A fragment’s required input has the meaning its producer actually supplies. Failure boundary: Metamodel compatibility is necessary but not proof that the combined method is feasible, usable or effective.

**Consumer and prerequisites —** Method engineer or team accountable for the actual work-product consumers property inputs: EAOSE-002; EAOSE-013; EAOSE-032. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Metamodel compatibility is necessary but not proof that the combined method is feasible, usable or effective..

**Minimal adequate alternative —** Use one coherent lightweight method where its scope suffices.

**Fuller-form trigger —** A tailored method imports guidance or artefacts from different methodologies.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A fragment’s required input has the meaning its producer actually supplies.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain fragment composition conditional on semantic and operational fit; compatible metamodels are necessary in some compositions but insufficient for success.

### CS-037 — EAOSE-037

**Artefact / ritual / brand —** Executable prescriptions and work-product consumers treated as a named deliverable or compliance item

**Protected function and failure —** Practitioners can execute the prescription and recognise its relevant result. Failure boundary: Detailed instructions can be wrong for the context and can suppress expert judgement.

**Consumer and prerequisites —** Method engineer or team accountable for the actual work-product consumers property inputs: EAOSE-036. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Detailed instructions can be wrong for the context and can suppress expert judgement..

**Minimal adequate alternative —** A direct decision rule or established team practice is enough if it supplies the needed result.

**Fuller-form trigger —** A method claims to support an engineering concern.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Practitioners can execute the prescription and recognise its relevant result.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain usable decision prescriptions and consumers, not maximal procedural detail or replacement of all expert judgement.

### CS-038 — EAOSE-038

**Artefact / ritual / brand —** Iterative cross-view feedback rather than mandatory phase order treated as a named deliverable or compliance item

**Protected function and failure —** A counterexample can reach the model or requirement that made it possible. Failure boundary: Unbounded iteration can hide indecision; some safety or contractual prerequisites genuinely must precede action.

**Consumer and prerequisites —** Method engineer or team accountable for the actual work-product consumers property inputs: EAOSE-034; EAOSE-037. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Unbounded iteration can hide indecision; some safety or contractual prerequisites genuinely must precede action..

**Minimal adequate alternative —** A small stable task may complete in one pass; no artificial iteration count is required.

**Fuller-form trigger —** Later work reveals missing constraints or invalid assumptions.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A counterexample can reach the model or requirement that made it possible.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain feedback and necessary dependency order, not a universal serial lifecycle or a fixed number of iterations.

### CS-039 — EAOSE-039

**Artefact / ritual / brand —** Proportional method assembly and retirement treated as a named deliverable or compliance item

**Protected function and failure —** Every retained task has a live function and every removed task leaves no unaddressed relied-on obligation. Failure boundary: Rarely used preventive controls can still matter; apparent lack of use is not sufficient retirement evidence.

**Consumer and prerequisites —** Method engineer or team accountable for the actual work-product consumers property inputs: EAOSE-036; EAOSE-037; EAOSE-038. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Rarely used preventive controls can still matter; apparent lack of use is not sufficient retirement evidence..

**Minimal adequate alternative —** Omit unused machinery; retain a smaller evidence or coordination mechanism when adequate.

**Fuller-form trigger —** A method is tailored, becomes costly or contains work with no current decision use.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Every retained task has a live function and every removed task leaves no unaddressed relied-on obligation.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain selection, simplification and retirement as one proportional tailoring mechanism. A rare-event control may still have a live function.

### CS-040 — EAOSE-040

**Artefact / ritual / brand —** Context-checked pattern reuse treated as a named deliverable or compliance item

**Protected function and failure —** The reused pattern has an explicit applicability argument and tested adaptation points. Failure boundary: Reuse can carry hidden platform assumptions or obsolete constraints; reusable code quantity does not measure net engineering benefit.

**Consumer and prerequisites —** Method engineer or team accountable for the actual work-product consumers property inputs: EAOSE-021; EAOSE-032; EAOSE-036. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Reuse can carry hidden platform assumptions or obsolete constraints; reusable code quantity does not measure net engineering benefit..

**Minimal adequate alternative —** Implement the small local behaviour directly when adaptation costs exceed reuse benefit.

**Fuller-form trigger —** A prior fragment appears to solve a recurring design problem.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: The reused pattern has an explicit applicability argument and tested adaptation points.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain reuse only with checked applicability; adaptation may cost more than direct construction.

### CS-041 — EAOSE-041

**Artefact / ritual / brand —** Learnability and tool-maintenance fit treated as a named deliverable or compliance item

**Protected function and failure —** The chosen process has an achievable skills and maintenance burden. Failure boundary: Familiar tools can lack required semantics; an old successful tool version does not establish current support.

**Consumer and prerequisites —** Method engineer or team accountable for the actual work-product consumers property inputs: EAOSE-011; EAOSE-036; EAOSE-039. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Familiar tools can lack required semantics; an old successful tool version does not establish current support..

**Minimal adequate alternative —** Use a smaller language subset or familiar tooling without claiming it preserves every richer semantic feature.

**Fuller-form trigger —** A method’s expressive power is being weighed against practical delivery constraints.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: The chosen process has an achievable skills and maintenance burden.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain local learnability/tool-maintenance assessment, not a popularity ranking or a claim that every old tool is obsolete.

### CS-042 — EAOSE-042

**Artefact / ritual / brand —** Method quality equals named-phase or diagram count treated as a named deliverable or compliance item

**Protected function and failure —** A smaller coherent method can be selected over a larger checklist. Failure boundary: Some documents protect genuine coordination; removing them indiscriminately is the opposite error.

**Consumer and prerequisites —** Method engineer or team accountable for the actual work-product consumers property inputs: EAOSE-037; EAOSE-039. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Some documents protect genuine coordination; removing them indiscriminately is the opposite error..

**Minimal adequate alternative —** Test one consequential engineering task against the proposed method.

**Fuller-form trigger —** A methodology comparison rewards labels rather than operative support.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A smaller coherent method can be selected over a larger checklist.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Classify phase/diagram counting as ceremony when treated as a general quality property; the artefacts may still perform useful work.

### CS-043 — EAOSE-043

**Artefact / ritual / brand —** Stakeholder validation is distinct from implementation verification treated as a named deliverable or compliance item

**Protected function and failure —** Conformance evidence is not reported as independent validation of stakeholder relevance. Failure boundary: Stakeholders may disagree or miss consequences; participation cannot guarantee correctness.

**Consumer and prerequisites —** Tester, verification engineer and accountable acceptance decision maker property inputs: EAOSE-001; EAOSE-002. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Stakeholders may disagree or miss consequences; participation cannot guarantee correctness..

**Minimal adequate alternative —** A direct demonstration and discussion can validate a small transparent requirement.

**Fuller-form trigger —** A system is proposed for acceptance or material change.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Conformance evidence is not reported as independent validation of stakeholder relevance.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain requirements validation versus conformance verification strongly. Neither supplies the other’s predicate.

### CS-044 — EAOSE-044

**Artefact / ritual / brand —** Assure both individual behaviour and collective outcomes treated as a named deliverable or compliance item

**Protected function and failure —** Locally passing agents are not assumed to establish a correct system. Failure boundary: Collective scenarios remain incomplete and can hide strategic or environmental behaviour.

**Consumer and prerequisites —** Tester, verification engineer and accountable acceptance decision maker property inputs: EAOSE-014; EAOSE-022; EAOSE-029. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Collective scenarios remain incomplete and can hide strategic or environmental behaviour..

**Minimal adequate alternative —** For one non-interacting component, collective assurance is not a separate activity.

**Fuller-form trigger —** Several agents or services jointly realise a requirement.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Locally passing agents are not assumed to establish a correct system.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain agent/collective assurance separation strongly; local correctness does not settle incompatible joint actions.

### CS-045 — EAOSE-045

**Artefact / ritual / brand —** Explicit model and environment assumptions for formal assurance treated as a named deliverable or compliance item

**Protected function and failure —** A proof over a finite or abstract model is not presented as a theorem about unrestricted deployment. Failure boundary: Proof strength can coexist with poor model validity; environmental events omitted from the alphabet remain uncontrolled.

**Consumer and prerequisites —** Tester, verification engineer and accountable acceptance decision maker property inputs: EAOSE-014; EAOSE-029; EAOSE-044. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Proof strength can coexist with poor model validity; environmental events omitted from the alphabet remain uncontrolled..

**Minimal adequate alternative —** Use bounded tests instead when formalisation costs exceed its decision value, while retaining uncertainty.

**Fuller-form trigger —** A proof or model-checking result supports acceptance.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A proof over a finite or abstract model is not presented as a theorem about unrestricted deployment.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain formal guarantees with model, assumptions and abstraction relation explicit; proofs remain valuable without being inflated into field validation.

### CS-046 — EAOSE-046

**Artefact / ritual / brand —** Implementation-level decision-code verification treated as a named deliverable or compliance item

**Protected function and failure —** The abstract-design-to-decision-code gap is reduced without claiming the entire cyber-physical system has been proved. Failure boundary: Native libraries, numerical control, sensors and real-time deployment can remain outside the checker.

**Consumer and prerequisites —** Tester, verification engineer and accountable acceptance decision maker property inputs: EAOSE-029; EAOSE-032; EAOSE-045. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Native libraries, numerical control, sensors and real-time deployment can remain outside the checker..

**Minimal adequate alternative —** Review, testing and restricted behaviour can be more proportionate for low-risk or unsupported implementations.

**Fuller-form trigger —** Consequential agent decision code has suitable semantics and tractable state space.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: The abstract-design-to-decision-code gap is reduced without claiming the entire cyber-physical system has been proved.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain decision-program verification as a domain-specific assurance technique, not a universal economical prerequisite or a complete environment proof.

### CS-047 — EAOSE-047

**Artefact / ritual / brand —** Design-to-protocol consistency checks treated as a named deliverable or compliance item

**Protected function and failure —** Inconsistent design choices are exposed before being mistaken for valid realisations. Failure boundary: The inspected design/protocol checker explicitly admits false positives and lacks an unconditional sound-and-complete claim because designs are partial; filtering a discrepancy requires inspecting the omitted plan semantics.

**Consumer and prerequisites —** Tester, verification engineer and accountable acceptance decision maker property inputs: EAOSE-022; EAOSE-030; EAOSE-034. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. The inspected design/protocol checker explicitly admits false positives and lacks an unconditional sound-and-complete claim because designs are partial; filtering a discrepancy requires inspecting the omitted plan semantics..

**Minimal adequate alternative —** A few explicit cross-view scenario checks can be adequate for a small design.

**Fuller-form trigger —** Agent design and interaction specification are maintained as separate views.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Inconsistent design choices are exposed before being mistaken for valid realisations.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain partial-design consistency analysis as conditional defect location; the inspected checker explicitly prevents an unconditional sound/complete interpretation.

### CS-048 — EAOSE-048

**Artefact / ritual / brand —** Oracle adequacy and false-success tests treated as a named deliverable or compliance item

**Protected function and failure —** A passing test has an interpretable claim boundary and known undetected cases. Failure boundary: Mutation score, judge agreement and benchmark accuracy can reward proxies; equivalent mutants and incomplete requirements need judgement.

**Consumer and prerequisites —** Tester, verification engineer and accountable acceptance decision maker property inputs: EAOSE-002; EAOSE-029; EAOSE-043. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Mutation score, judge agreement and benchmark accuracy can reward proxies; equivalent mutants and incomplete requirements need judgement..

**Minimal adequate alternative —** A simple exact assertion is sufficient for deterministic, fully specified output.

**Fuller-form trigger —** Autonomous or stochastic behaviour lacks one obvious expected trace.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A passing test has an interpretable claim boundary and known undetected cases.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain oracle examination but mark it gameable: a score can be optimised while its intended external meaning is lost.

### CS-049 — EAOSE-049

**Artefact / ritual / brand —** Simulation-to-deployment validity treated as a named deliverable or compliance item

**Protected function and failure —** The evidence states what was simulated and what remains untested in the real setting. Failure boundary: A richer simulator can still share the designer’s mistaken assumptions and conceal rare or strategic behaviours.

**Consumer and prerequisites —** Tester, verification engineer and accountable acceptance decision maker property inputs: EAOSE-018; EAOSE-029; EAOSE-045. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. A richer simulator can still share the designer’s mistaken assumptions and conceal rare or strategic behaviours..

**Minimal adequate alternative —** A small direct field test or conservative restriction can suffice when representative simulation is unavailable.

**Fuller-form trigger —** Simulation evidence is used for an operational decision.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: The evidence states what was simulated and what remains untested in the real setting.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain simulation only with a declared transfer argument; reproducing a model’s behaviour does not establish that model’s environmental assumptions.

### CS-050 — EAOSE-050

**Artefact / ritual / brand —** Discriminating fault and perturbation testing treated as a named deliverable or compliance item

**Protected function and failure —** The result identifies a controlled perturbation and its observed effect, not merely a final score. Failure boundary: Synthetic faults are not incidence estimates; stochastic variance and instrumentation overhead can confound effects.

**Consumer and prerequisites —** Tester, verification engineer and accountable acceptance decision maker property inputs: EAOSE-025; EAOSE-044; EAOSE-048; EAOSE-049. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Synthetic faults are not incidence estimates; stochastic variance and instrumentation overhead can confound effects..

**Minimal adequate alternative —** One targeted adverse case is preferable to an undirected stress campaign when it discriminates the decision.

**Fuller-form trigger —** A known failure class or dependence could invalidate a consequential requirement.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: The result identifies a controlled perturbation and its observed effect, not merely a final score.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain targeted adverse-case tests where consequences warrant them; no finite injected-fault collection is treated as complete coverage.

### CS-051 — EAOSE-051

**Artefact / ritual / brand —** Runtime observations linked to assurance claims treated as a named deliverable or compliance item

**Protected function and failure —** A failed observation has a defined consumer and can change an operational or engineering decision. Failure boundary: Monitoring can miss events, disclose sensitive data or add overhead; a dashboard without response duties is ceremony.

**Consumer and prerequisites —** Tester, verification engineer and accountable acceptance decision maker property inputs: EAOSE-029; EAOSE-034; EAOSE-044; EAOSE-048. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Monitoring can miss events, disclose sensitive data or add overhead; a dashboard without response duties is ceremony..

**Minimal adequate alternative —** Observe a small set of consequential boundaries rather than logging every internal step.

**Fuller-form trigger —** Relevant behaviour or assumptions cannot be fully established before deployment.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A failed observation has a defined consumer and can change an operational or engineering decision.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain observations tied to a claim and response; logs are not omniscience and need not all be collected.

### CS-052 — EAOSE-052

**Artefact / ritual / brand —** Exhaustive testing guarantees unrestricted autonomous behaviour treated as a named deliverable or compliance item

**Protected function and failure —** Testing claims state their behavioural and environmental scope. Failure boundary: Combinatorial path arguments do not prove every agent untestable; restriction and compositional reasoning can change tractability.

**Consumer and prerequisites —** Tester, verification engineer and accountable acceptance decision maker property inputs: EAOSE-045; EAOSE-048; EAOSE-049. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Combinatorial path arguments do not prove every agent untestable; restriction and compositional reasoning can change tractability..

**Minimal adequate alternative —** A finite exhaustive test remains valid for its actually finite, enumerated model.

**Fuller-form trigger —** A demonstration or finite test suite is used to guarantee every autonomous response.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Testing claims state their behavioural and environmental scope.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Reject unrestricted exhaustive-testing claims, not finite exhaustive checks or bounded model checking within actual assumptions.

### CS-053 — EAOSE-053

**Artefact / ritual / brand —** Deployment and legacy-integration obligations treated as a named deliverable or compliance item

**Protected function and failure —** The deployment has responsible operators and tested integration boundaries rather than only runnable agent code. Failure boundary: Adding an agent middleware layer can increase interoperability and maintenance burden; platform deployment is not service readiness.

**Consumer and prerequisites —** Engineers, operators, affected users and authorised change/retirement decision makers property inputs: EAOSE-025; EAOSE-029; EAOSE-033. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. Adding an agent middleware layer can increase interoperability and maintenance burden; platform deployment is not service readiness..

**Minimal adequate alternative —** Reuse an established deployment process and explicit interface contract where adequate.

**Fuller-form trigger —** An agent application enters an existing operational environment.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: The deployment has responsible operators and tested integration boundaries rather than only runnable agent code.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain deployment/interface completion without inventing whole-lifecycle support in each historical method.

### CS-054 — EAOSE-054

**Artefact / ritual / brand —** Versioned implementation and configuration evidence treated as a named deliverable or compliance item

**Protected function and failure —** Evidence can be associated with the actual evaluated configuration rather than an unspecified product name. Failure boundary: External services may change despite stable names; a hash proves identity, not correctness or reproducibility of stochastic output.

**Consumer and prerequisites —** Engineers, operators, affected users and authorised change/retirement decision makers property inputs: EAOSE-026; EAOSE-034; EAOSE-048; EAOSE-053. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. External services may change despite stable names; a hash proves identity, not correctness or reproducibility of stochastic output..

**Minimal adequate alternative —** One build identifier and configuration snapshot can suffice for a small fixed system.

**Fuller-form trigger —** A result must be reproduced, compared, rolled out or used after a change.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Evidence can be associated with the actual evaluated configuration rather than an unspecified product name.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain a correspondence between evaluated and operated configurations; no particular version-control product is prescribed.

### CS-055 — EAOSE-055

**Artefact / ritual / brand —** Operational feedback to maintained engineering models treated as a named deliverable or compliance item

**Protected function and failure —** Operational lessons can change design and acceptance rather than accumulating as disconnected logs. Failure boundary: Correlational traces do not by themselves establish root cause; automatic synchronisation can overwrite a sound specification with faulty behaviour.

**Consumer and prerequisites —** Engineers, operators, affected users and authorised change/retirement decision makers property inputs: EAOSE-006; EAOSE-034; EAOSE-051; EAOSE-054. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. Correlational traces do not by themselves establish root cause; automatic synchronisation can overwrite a sound specification with faulty behaviour..

**Minimal adequate alternative —** A short incident-to-requirement link can replace continuous model synchronisation.

**Fuller-form trigger —** The deployed system behaves differently from its engineering assumptions.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Operational lessons can change design and acceptance rather than accumulating as disconnected logs.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain operational evidence reaching engineering/stakeholder decisions, not a self-contained monitoring ritual.

### CS-056 — EAOSE-056

**Artefact / ritual / brand —** Authorised evolution within explicit revision boundaries treated as a named deliverable or compliance item

**Protected function and failure —** Adaptive choice does not silently acquire authority to redefine its own acceptance conditions. Failure boundary: A policy can authorise harmful changes if its own premise is wrong; runtime governance cannot create external consent.

**Consumer and prerequisites —** Engineers, operators, affected users and authorised change/retirement decision makers property inputs: EAOSE-005; EAOSE-006; EAOSE-010; EAOSE-017; EAOSE-054. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. A policy can authorise harmful changes if its own premise is wrong; runtime governance cannot create external consent..

**Minimal adequate alternative —** Disable dynamic adaptation or require an ordinary reviewed release where that is adequate.

**Fuller-form trigger —** A system adapts or a team changes an autonomous component after acceptance.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Adaptive choice does not silently acquire authority to redefine its own acceptance conditions.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain a distinct revision authority boundary as an analytical lifecycle strengthening; self-application is not self-authorisation.

### CS-057 — EAOSE-057

**Artefact / ritual / brand —** Selective assurance revalidation after change treated as a named deliverable or compliance item

**Protected function and failure —** Each relied-on affected claim has an explicit retained, narrowed, reassessed or withdrawn status. Failure boundary: Dependency maps can omit indirect effects; indiscriminate reuse and indiscriminate invalidation are both failures.

**Consumer and prerequisites —** Engineers, operators, affected users and authorised change/retirement decision makers property inputs: EAOSE-006; EAOSE-034; EAOSE-045; EAOSE-054; EAOSE-055; EAOSE-056. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. Dependency maps can omit indirect effects; indiscriminate reuse and indiscriminate invalidation are both failures..

**Minimal adequate alternative —** A direct impact judgement is enough for a small change; unchanged justified claims do not require blanket retesting.

**Fuller-form trigger —** Code, environment, goals, protocols or underlying services change.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Each relied-on affected claim has an explicit retained, narrowed, reassessed or withdrawn status.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain selective revalidation as the operative evidence-continuity mechanism. Preservation, narrowing, reassessment and withdrawal depend on actual change impact.

### CS-058 — EAOSE-058

**Artefact / ritual / brand —** Retirement preserves or resolves outstanding obligations treated as a named deliverable or compliance item

**Protected function and failure —** Retirement does not falsely convert an outstanding obligation into successful completion. Failure boundary: Transfer can require another party’s agreement; compensating action may be impossible or inadequate.

**Consumer and prerequisites —** Engineers, operators, affected users and authorised change/retirement decision makers property inputs: EAOSE-003; EAOSE-023; EAOSE-025; EAOSE-053; EAOSE-056. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. Transfer can require another party’s agreement; compensating action may be impossible or inadequate..

**Minimal adequate alternative —** Immediate removal is sufficient when there are demonstrably no live obligations or dependencies.

**Fuller-form trigger —** A component, capability or protocol is withdrawn while others may still rely on it.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Retirement does not falsely convert an outstanding obligation into successful completion.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain operational retirement contextually and analytically; process termination alone does not discharge ongoing duties.

### CS-059 — EAOSE-059

**Artefact / ritual / brand —** Design-method support implies a complete operational lifecycle treated as a named deliverable or compliance item

**Protected function and failure —** Lifecycle gaps are stated rather than hidden by a broad methodology name. Failure boundary: A method may intentionally have a narrow scope; this is not a failure unless broader coverage is claimed.

**Consumer and prerequisites —** Engineers, operators, affected users and authorised change/retirement decision makers property inputs: EAOSE-037; EAOSE-053; EAOSE-055. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. A method may intentionally have a narrow scope; this is not a failure unless broader coverage is claimed..

**Minimal adequate alternative —** Supplement it with existing operational practices and label the documented import.

**Fuller-form trigger —** A method is represented as complete because it reaches implementation.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Lifecycle gaps are stated rather than hidden by a broad methodology name.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Reject the inference from good design or code to a completed operational lifecycle.

### CS-060 — EAOSE-060

**Artefact / ritual / brand —** Separate demonstrated mechanism, deployment and comparative benefit treated as a named deliverable or compliance item

**Protected function and failure —** A deployed application is not reported as a causal test of an entire named methodology. Failure boundary: Overly strict demands for controlled trials can obscure useful field learning; evidence can justify conditional action without proving superiority.

**Consumer and prerequisites —** Evaluator and reader making a benefit/adoption judgement property inputs: None, subject to the stated absence explanation.. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can classify reported evidence and limitations; cannot substitute application counts for causal authorisation or adoption decisions. Overly strict demands for controlled trials can obscure useful field learning; evidence can justify conditional action without proving superiority.. absence reason: This is a boundary/selection inquiry or independently posed candidate; it has no mandatory earlier property in this corpus..

**Minimal adequate alternative —** A short claim–evidence statement is enough for an uncontroversial local choice.

**Fuller-form trigger —** A method, platform or application is being justified by published evidence.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A deployed application is not reported as a causal test of an entire named methodology.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain evidence-role separation strongly: conceptual mechanism, adoption and comparative benefit are different claims.

### CS-061 — EAOSE-061

**Artefact / ritual / brand —** Cost attribution and source non-independence treated as a named deliverable or compliance item

**Protected function and failure —** Reported benefit is bounded by the comparator, setting and dependence structure of the evidence. Failure boundary: Missing cost data, selection and publication bias limit both positive and negative generalisation.

**Consumer and prerequisites —** Evaluator and reader making a benefit/adoption judgement property inputs: EAOSE-011; EAOSE-060. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can classify reported evidence and limitations; cannot substitute application counts for causal authorisation or adoption decisions. Missing cost data, selection and publication bias limit both positive and negative generalisation..

**Minimal adequate alternative —** A transparent single-case rationale can support a narrow reversible decision without inventing generality.

**Fuller-form trigger —** Several studies or large reported gains support a general engineering-benefit claim.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Reported benefit is bounded by the comparator, setting and dependence structure of the evidence.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain unit, baseline and shared-origin discipline; repeated versions or case descriptions cannot become independent replications.

### CS-062 — EAOSE-062

**Artefact / ritual / brand —** Whole-method superiority over conventional engineering treated as a named deliverable or compliance item

**Protected function and failure —** The frozen corpus distinguishes useful mechanisms from unresolved universal or broad comparative superiority. Failure boundary: Positive vendor cases and fragment experiments are not null evidence, but neither remove confounding or establish representative lifecycle superiority.

**Consumer and prerequisites —** Evaluator and reader making a benefit/adoption judgement property inputs: EAOSE-011; EAOSE-060; EAOSE-061. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can classify reported evidence and limitations; cannot substitute application counts for causal authorisation or adoption decisions. Positive vendor cases and fragment experiments are not null evidence, but neither remove confounding or establish representative lifecycle superiority..

**Minimal adequate alternative —** Choose a guarded mechanism on a local business case without claiming whole-method dominance.

**Fuller-form trigger —** An organisation seeks a general superiority claim rather than a local mechanism or application argument.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: The frozen corpus distinguishes useful mechanisms from unresolved universal or broad comparative superiority.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Keep UNRESOLVED after examining relevant positive, null and critical evidence. The corpus supports use and local results, not a general causal ranking of whole methods.

### CS-063 — EAOSE-063

**Artefact / ritual / brand —** Popularity, venue participation or framework maturity proves benefit treated as a named deliverable or compliance item

**Protected function and failure —** A popularity fact is not converted into causal engineering effectiveness. Failure boundary: Low visibility also does not establish uselessness; proprietary adoption and nomenclature changes distort proxies.

**Consumer and prerequisites —** Evaluator and reader making a benefit/adoption judgement property inputs: EAOSE-060; EAOSE-061. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can classify reported evidence and limitations; cannot substitute application counts for causal authorisation or adoption decisions. Low visibility also does not establish uselessness; proprietary adoption and nomenclature changes distort proxies..

**Minimal adequate alternative —** Use it as a discovery or support-risk signal, then examine the actual capability and costs.

**Fuller-form trigger —** Visibility or popularity is offered as the decisive outcome measure.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A popularity fact is not converted into causal engineering effectiveness.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Reject a general benefit property from popularity/maturity labels while preserving descriptive adoption information.

### CS-064 — EAOSE-064

**Artefact / ritual / brand —** Named-method observance as assurance treated as a named deliverable or compliance item

**Protected function and failure —** A method badge neither authorises action nor proves the resulting system correct. Failure boundary: A recognised method can aid communication and training; the ceremonial error is substituting its name for its function.

**Consumer and prerequisites —** Evaluator and reader making a benefit/adoption judgement property inputs: EAOSE-037; EAOSE-039; EAOSE-060. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can classify reported evidence and limitations; cannot substitute application counts for causal authorisation or adoption decisions. A recognised method can aid communication and training; the ceremonial error is substituting its name for its function..

**Minimal adequate alternative —** Inspect the consequential mechanism directly and accept an adequate unnamed equivalent.

**Fuller-form trigger —** Method compliance is used to close an unresolved engineering question.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A method badge neither authorises action nor proves the resulting system correct.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Classify method observance itself as ceremony, not a benefit-producing invariant. Keep whatever evidence/coordination function the observance actually serves.

### CS-065 — EAOSE-065

**Artefact / ritual / brand —** Documented continuity rather than retrospective rebranding treated as a named deliverable or compliance item

**Protected function and failure —** Historical inheritance, documented hybridisation and analogy remain distinguishable. Failure boundary: A citation proves acquaintance rather than semantic fidelity; absence of explicit citation does not prove independence.

**Consumer and prerequisites —** Hybrid-system engineer, operator, task owner and affected principals property inputs: None, subject to the stated absence explanation.. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. A citation proves acquaintance rather than semantic fidelity; absence of explicit citation does not prove independence.. absence reason: This is a boundary/selection inquiry or independently posed candidate; it has no mandatory earlier property in this corpus..

**Minimal adequate alternative —** Describe the actual mechanism without claiming an ancestry that cannot be established.

**Fuller-form trigger —** A modern agent framework is described as inheriting established AOSE.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Historical inheritance, documented hybridisation and analogy remain distinguishable.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain explicit documentary continuity tests: some BDI hybrids are documented descendants, while other modern work is convergence or unresolved ancestry.

### CS-066 — EAOSE-066

**Artefact / ritual / brand —** Cost-aware and repeatable stochastic evaluation treated as a named deliverable or compliance item

**Protected function and failure —** Claims separate task success, variability, cost and generalisation to unseen work. Failure boundary: Benchmarks can be contaminated or overfit; model aliases and changing services can defeat exact repeatability.

**Consumer and prerequisites —** Hybrid-system engineer, operator, task owner and affected principals property inputs: EAOSE-011; EAOSE-048; EAOSE-054; EAOSE-061. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. Benchmarks can be contaminated or overfit; model aliases and changing services can defeat exact repeatability..

**Minimal adequate alternative —** An exact deterministic regression is sufficient for a component with no relevant stochasticity.

**Fuller-form trigger —** Learned or remote components vary across executions or consume material inference resources.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Claims separate task success, variability, cost and generalisation to unseen work.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain configuration-linked repeats, cost and appropriate baselines; repeated runs do not repair an invalid oracle or establish real-world prevalence.

### CS-067 — EAOSE-067

**Artefact / ritual / brand —** Generated plans remain subject to executable constraints treated as a named deliverable or compliance item

**Protected function and failure —** Plausible natural-language plans are not treated as executable specifications or accepted proofs. Failure boundary: Validation can check only the encoded constraints; learned grounding and environmental action models can remain wrong.

**Consumer and prerequisites —** Hybrid-system engineer, operator, task owner and affected principals property inputs: EAOSE-005; EAOSE-030; EAOSE-032; EAOSE-045; EAOSE-056. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. Validation can check only the encoded constraints; learned grounding and environmental action models can remain wrong..

**Minimal adequate alternative —** Keep a verified finite plan library or require manual selection when generation offers no justified benefit.

**Fuller-form trigger —** A planner or learned model generates or revises executable behaviour.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Plausible natural-language plans are not treated as executable specifications or accepted proofs.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain generated-plan constraints under language, capability and context assumptions; syntax and model grading are insufficient by themselves.

### CS-068 — EAOSE-068

**Artefact / ritual / brand —** Tool authority is enforced outside untrusted generated instructions treated as a named deliverable or compliance item

**Protected function and failure —** Persuasive or injected text cannot itself widen tool permissions. Failure boundary: A narrow authorised call can still be harmful or based on false data; wrappers require their own correctness and threat analysis.

**Consumer and prerequisites —** Hybrid-system engineer, operator, task owner and affected principals property inputs: EAOSE-005; EAOSE-010; EAOSE-029; EAOSE-056. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. A narrow authorised call can still be harmful or based on false data; wrappers require their own correctness and threat analysis..

**Minimal adequate alternative —** Read-only tools, a narrow deterministic adapter or explicit approval can eliminate unnecessary delegated power.

**Fuller-form trigger —** A learned agent can invoke tools or consume untrusted external content.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Persuasive or injected text cannot itself widen tool permissions.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain authority separation from untrusted prompts/tool data. Behavioural instructions may help, but cannot be the only basis for consequential permissions.

### CS-069 — EAOSE-069

**Artefact / ritual / brand —** Memory and retrieved-content provenance boundaries treated as a named deliverable or compliance item

**Protected function and failure —** A recalled assertion can be checked against its origin and does not silently override a trusted constraint. Failure boundary: The inspected evidence is stronger for untrusted tool outputs than for long-term memory governance; privacy, staleness and poisoning need separate validation.

**Consumer and prerequisites —** Hybrid-system engineer, operator, task owner and affected principals property inputs: EAOSE-029; EAOSE-054; EAOSE-068. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. The inspected evidence is stronger for untrusted tool outputs than for long-term memory governance; privacy, staleness and poisoning need separate validation..

**Minimal adequate alternative —** No persistent memory, or a small typed state record, may be safer and cheaper.

**Fuller-form trigger —** A learned agent reuses prior or externally retrieved information across tasks or sessions.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A recalled assertion can be checked against its origin and does not silently override a trusted constraint.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain memory provenance contextually as a modern transfer judgement, not a directly validated universal AOSE memory architecture.

### CS-070 — EAOSE-070

**Artefact / ritual / brand —** Regression after model, prompt or remote-service changes treated as a named deliverable or compliance item

**Protected function and failure —** The assurance statement identifies the configuration actually evaluated and the residual uncertainty of remote drift. Failure boundary: Providers may not expose meaningful versions; repeat testing reduces but does not eliminate stochastic uncertainty.

**Consumer and prerequisites —** Hybrid-system engineer, operator, task owner and affected principals property inputs: EAOSE-054; EAOSE-057; EAOSE-066. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. Providers may not expose meaningful versions; repeat testing reduces but does not eliminate stochastic uncertainty..

**Minimal adequate alternative —** No blanket rerun when a documented impact analysis shows the relevant behaviour unaffected.

**Fuller-form trigger —** A learned component or externally controlled dependency is updated.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: The assurance statement identifies the configuration actually evaluated and the residual uncertainty of remote drift.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain regression after material remote/model/prompt/interface change, with explicit residual uncertainty when versions or distributions are opaque.

### CS-071 — EAOSE-071

**Artefact / ritual / brand —** Cross-agent trace correlation for diagnosis treated as a named deliverable or compliance item

**Protected function and failure —** An investigator can relate an outcome to the relevant interaction without treating correlation as a causal proof. Failure boundary: Trace completeness, privacy, storage and instrumentation cost matter; missing spans and varying runs can mislead diagnosis.

**Consumer and prerequisites —** Hybrid-system engineer, operator, task owner and affected principals property inputs: EAOSE-021; EAOSE-051; EAOSE-054; EAOSE-066. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. Trace completeness, privacy, storage and instrumentation cost matter; missing spans and varying runs can mislead diagnosis..

**Minimal adequate alternative —** A local error report is enough when one component and one direct effect make the failure unambiguous.

**Fuller-form trigger —** Distributed or stochastic execution obscures where a requirement was lost.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: An investigator can relate an outcome to the relevant interaction without treating correlation as a causal proof.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain correlated tracing where distributed diagnosis needs it; it does not itself establish causation or justify maximal data retention.

### CS-072 — EAOSE-072

**Artefact / ritual / brand —** A role prompt is a formal role contract treated as a named deliverable or compliance item

**Protected function and failure —** Role instructions are classified as behavioural inputs, with separately established enforcement and evidence. Failure boundary: A prompt can still usefully guide behaviour; the rejected claim is semantic and assurance equivalence.

**Consumer and prerequisites —** Hybrid-system engineer, operator, task owner and affected principals property inputs: EAOSE-013; EAOSE-015; EAOSE-020; EAOSE-068. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. A prompt can still usefully guide behaviour; the rejected claim is semantic and assurance equivalence..

**Minimal adequate alternative —** Use a small explicit contract and independent permission/test boundary when consequences warrant it.

**Fuller-form trigger —** Prompt text is offered as sufficient organisational or safety assurance.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Role instructions are classified as behavioural inputs, with separately established enforcement and evidence.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Reject equivalence between a role prompt and a formally interpreted/enforced role contract; do not deny the prompt’s narrower behavioural usefulness.

### CS-073 — EAOSE-073

**Artefact / ritual / brand —** Criterion–authority–effect coupling treated as a named deliverable or compliance item

**Protected function and failure —** No goal, permission or observed benefit substitutes for either of the other two; a counterexample propagates to the affected decision. Failure boundary: The relation is an analytical engineering constraint, not a new academic theorem or automatic causal-attribution mechanism; complete evidence may be unavailable.

**Consumer and prerequisites —** The actual consumer of the consequential engineering or operational decision property inputs: EAOSE-002; EAOSE-005; EAOSE-023; EAOSE-029; EAOSE-043; EAOSE-048. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power. The relation is an analytical engineering constraint, not a new academic theorem or automatic causal-attribution mechanism; complete evidence may be unavailable..

**Minimal adequate alternative —** One direct contract and result check suffice when all three distinctions are already coupled transparently.

**Fuller-form trigger —** Separate correct-looking goal, permission and outcome judgements can jointly admit an unjustified action or acceptance.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: No goal, permission or observed benefit substitutes for either of the other two; a counterexample propagates to the affected decision.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain as distinct analytical composition because cross-view contradiction changes the same consequential decision; three independently stored judgements do not ensure this operation.

### CS-074 — EAOSE-074

**Artefact / ritual / brand —** Evidence continuity through change as a separate new property treated as a named deliverable or compliance item

**Protected function and failure —** Evidence continuity is retained without double-counting the mechanism or its burden. Failure boundary: No inspected evidence establishes a distinct trigger or additional operation beyond the strengthened change-impact mechanism.

**Consumer and prerequisites —** The actual consumer of the consequential engineering or operational decision property inputs: EAOSE-057. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power. No inspected evidence establishes a distinct trigger or additional operation beyond the strengthened change-impact mechanism..

**Minimal adequate alternative —** Use the same claim–dependency analysis and evidence record as EAOSE-057.

**Fuller-form trigger —** The ancestry label is proposed as another independent property.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Evidence continuity is retained without double-counting the mechanism or its burden.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Keep the ancestry proposal as a duplicate of EAOSE-057. No additional trigger, operation or independent consumer was found beyond selective revalidation.

### CS-075 — EAOSE-075

**Artefact / ritual / brand —** Purposeful retirement of method machinery as a separate new property treated as a named deliverable or compliance item

**Protected function and failure —** A preventive control is not removed merely because it is rarely used, and an unused ritual is not kept merely because it is branded. Failure boundary: Retiring operational agents with live commitments is different and remains EAOSE-058; do not collapse these subjects.

**Consumer and prerequisites —** The actual consumer of the consequential engineering or operational decision property inputs: EAOSE-039. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power. Retiring operational agents with live commitments is different and remains EAOSE-058; do not collapse these subjects..

**Minimal adequate alternative —** One proportionality decision can select, substitute or retire the machinery.

**Fuller-form trigger —** The ancestry label is proposed as an independent composition-induced control.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A preventive control is not removed merely because it is rarely used, and an unused ritual is not kept merely because it is branded.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Keep the ancestry proposal as a duplicate of EAOSE-039. Method retirement is one outcome of tailoring; operational agent retirement remains separate.

### CS-076 — EAOSE-076

**Artefact / ritual / brand —** Obligation-preserving organisational reconfiguration treated as a named deliverable or compliance item

**Protected function and failure —** A structurally valid new organisation does not erase the commitments created by its predecessor configuration. Failure boundary: This interaction obligation is an analytical synthesis, not a demonstrated general implementation; consent, partial observation and irreversible effects can block safe transfer.

**Consumer and prerequisites —** The actual consumer of the consequential engineering or operational decision property inputs: EAOSE-015; EAOSE-017; EAOSE-023; EAOSE-025; EAOSE-056; EAOSE-058; EAOSE-073. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power. This interaction obligation is an analytical synthesis, not a demonstrated general implementation; consent, partial observation and irreversible effects can block safe transfer..

**Minimal adequate alternative —** Drain in-flight work before reconfiguration, or retain a static assignment when continuity cannot be established.

**Fuller-form trigger —** An adaptive organisation changes role holders while interactions or commitments remain live.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A structurally valid new organisation does not erase the commitments created by its predecessor configuration.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain contextually as a new analytical composition obligation: feasible role assignment plus valid protocol components can still orphan predecessor obligations.

### CS-077 — EAOSE-077

**Artefact / ritual / brand —** Hierarchical organisational decomposition treated as a named deliverable or compliance item

**Protected function and failure —** Cross-level obligations and boundaries are represented, not hidden by the hierarchy. Failure boundary: ASPECS hierarchy is not a universal architecture; nesting adds abstraction and coordination cost and can misfit dense cross-cutting dependencies.

**Consumer and prerequisites —** Organisation designer; operators or delegated organisational controller for permitted runtime changes property inputs: EAOSE-013; EAOSE-016; EAOSE-036. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. ASPECS hierarchy is not a universal architecture; nesting adds abstraction and coordination cost and can misfit dense cross-cutting dependencies..

**Minimal adequate alternative —** A flat organisation is sufficient when nesting adds no explanatory or operational value.

**Fuller-form trigger —** A system’s structure and coordination genuinely benefit from hierarchical or holonic decomposition.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Cross-level obligations and boundaries are represented, not hidden by the hierarchy.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain hierarchy/holonic decomposition only in its structural domain; flat or cross-cutting systems may not benefit.

### CS-078 — EAOSE-078

**Artefact / ritual / brand —** Cooperation-driven self-organisation treated as a named deliverable or compliance item

**Protected function and failure —** Local adaptation is assessed against an explicit external adequacy judgement and its boundaries. Failure boundary: Local cooperation cannot be transferred into a universal guarantee of a desired global function; strategic agents or incompatible objectives invalidate the branch.

**Consumer and prerequisites —** Organisation designer; operators or delegated organisational controller for permitted runtime changes property inputs: EAOSE-008; EAOSE-018; EAOSE-044; EAOSE-049. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. Local cooperation cannot be transferred into a universal guarantee of a desired global function; strategic agents or incompatible objectives invalidate the branch..

**Minimal adequate alternative —** Use known-goal organisation or a central algorithm when the function is already sufficiently specified.

**Fuller-form trigger —** The application genuinely needs emergence under poorly specified, changing interactions and meets the cooperative branch assumptions.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Local adaptation is assessed against an explicit external adequacy judgement and its boundaries.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain cooperative self-organisation only under its AMAS-style premises and external adequacy test; not as guaranteed emergence of any desired global function.

### CS-079 — EAOSE-079

**Artefact / ritual / brand —** Knowledge and task modelling as distinct engineering views treated as a named deliverable or compliance item

**Protected function and failure —** Reusable inference patterns have an explicit task and domain interpretation. Failure boundary: Knowledge acquisition and multiple views can be expensive; task labels do not validate the knowledge or algorithm.

**Consumer and prerequisites —** Requirements analyst with affected actors and the legitimate requirements decision maker property inputs: EAOSE-002; EAOSE-028; EAOSE-040. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. Knowledge acquisition and multiple views can be expensive; task labels do not validate the knowledge or algorithm..

**Minimal adequate alternative —** A direct typed representation and small algorithm are enough for simple reasoning.

**Fuller-form trigger —** Knowledge-intensive reasoning is difficult to engineer as undifferentiated code or beliefs.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Reusable inference patterns have an explicit task and domain interpretation.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain task/expertise views when knowledge-intensive engineering warrants their acquisition and maintenance cost.

### CS-080 — EAOSE-080

**Artefact / ritual / brand —** A consistent fragment composition guarantees achievable goals treated as a named deliverable or compliance item

**Protected function and failure —** Method compatibility is not silently promoted to joint behavioural or economic success. Failure boundary: A stronger theorem can establish a bounded guarantee when its actual assumptions hold; the general inference remains invalid.

**Consumer and prerequisites —** Tester, verification engineer and accountable acceptance decision maker property inputs: EAOSE-036; EAOSE-044; EAOSE-045. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. A stronger theorem can establish a bounded guarantee when its actual assumptions hold; the general inference remains invalid..

**Minimal adequate alternative —** Use a small feasibility or counterexample check on the actual combined obligations.

**Fuller-form trigger —** Semantic method integration is presented as automatic system-level adequacy.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Method compatibility is not silently promoted to joint behavioural or economic success.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Reject joint success from consistent fragment composition. The capacity counterexample separates semantic compatibility from feasibility.

### CS-081 — EAOSE-081

**Artefact / ritual / brand —** Counterexample propagation as a distinct new control treated as a named deliverable or compliance item

**Protected function and failure —** Feedback remains part of the composed system without another independently counted mechanism. Failure boundary: A link must actually influence the consumer; duplicate disposition does not mean feedback can be omitted.

**Consumer and prerequisites —** The actual consumer of the consequential engineering or operational decision property inputs: EAOSE-034; EAOSE-038; EAOSE-073. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power. A link must actually influence the consumer; duplicate disposition does not mean feedback can be omitted..

**Minimal adequate alternative —** Reuse the existing test-to-requirement or design-to-protocol link.

**Fuller-form trigger —** A separate feedback office or artefact is proposed solely to rename these existing loops.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Feedback remains part of the composed system without another independently counted mechanism.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Keep as a duplicate of existing traceability, iterative feedback and coupled-decision mechanisms, not another office or artefact.

### CS-082 — EAOSE-082

**Artefact / ritual / brand —** Observation plus self-revision guarantees improvement treated as a named deliverable or compliance item

**Protected function and failure —** A successor cannot validate its own changed acceptance rule solely by succeeding under that rule. Failure boundary: This is an analytical objection to an inference, not a claim that all adaptation fails or that the cited authors assert automatic improvement.

**Consumer and prerequisites —** The actual consumer of the consequential engineering or operational decision property inputs: EAOSE-048; EAOSE-056; EAOSE-057; EAOSE-073. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power. This is an analytical objection to an inference, not a claim that all adaptation fails or that the cited authors assert automatic improvement..

**Minimal adequate alternative —** Use bounded reviewed changes and a stable acceptance comparison; leave unresolved trade-offs explicit.

**Fuller-form trigger —** A feedback loop is treated as self-authorising evidence of maturity or eventual correctness.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: A successor cannot validate its own changed acceptance rule solely by succeeding under that rule.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Reject automatic improvement from observation plus self-revision; the changed-score counterexample defeats the universal inference.

### CS-083 — EAOSE-083

**Artefact / ritual / brand —** Preserve responsiveness during long-running plan generation treated as a named deliverable or compliance item

**Protected function and failure —** Waiting for a plan does not by itself disable every unrelated reactive obligation; the wait has an explicit failure or resumption path. Failure boundary: Non-blocking scheduling does not ensure hard real-time response, resource fairness or semantic validity of a late result; cancellation and stale-state handling still need design.

**Consumer and prerequisites —** Hybrid-system engineer, operator, task owner and affected principals property inputs: EAOSE-010; EAOSE-025; EAOSE-031; EAOSE-067. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. Non-blocking scheduling does not ensure hard real-time response, resource fairness or semantic validity of a late result; cancellation and stale-state handling still need design..

**Minimal adequate alternative —** Use a prewritten plan or synchronous execution when no concurrent response obligation exists and the delay is acceptable.

**Fuller-form trigger —** Remote or computationally slow plan generation threatens the response time of other responsibilities assigned to the same agent.

**Simplification cost —** Check whether simplification loses the candidate’s specific discrimination or intervention: Waiting for a plan does not by itself disable every unrelated reactive obligation; the wait has an explicit failure or resumption path.

**Omission / retirement —** Omit when the trigger is absent; retire or substitute when its risk, consumer and dependencies no longer require it. A retained preventive function must remain adequately supported. Retain contextually as a newly examined native mechanism from current BDI generation work. Isolating a wait is distinct from concurrency correctness and does not guarantee deadlines.


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_CRITICISM_LEDGER

Objections are allowed to change retention, trigger, evidence classification or composition. The entries separate the source’s actual result from the stronger analytical counterexample used here. No source is credited with every criticism of the mature synthesis.

### CR-01 — Actor/goal requirements

**Affected candidates —** EAOSE-001; EAOSE-002; EAOSE-003; EAOSE-004; EAOSE-005; EAOSE-006; EAOSE-007; EAOSE-073

**Objection —** Internal model completeness can conceal an excluded affected actor or a mistranslated success condition.

**Evidence and attribution —** Sources provide explicit dependency/requirement distinctions; the false-success example in the testing work challenges an insufficient condition. Complete stakeholder discovery is not proved.

**Response —** Keep validation and semantic mapping distinct from diagram completion; allow a consequential objection to reopen the boundary.

**Present judgement —** Retain actor inquiry and distinct goal/acceptance meanings; reject EAOSE-007. Qualitative trade-off modelling remains gameable.

**Residual uncertainty —** Whose account resolves contested needs, and what excluded voices remain inaccessible, require case-specific investigation.

**Source locators —** source id: AOSE-S004. locators: §§2–5; figure 2 and figure 3, journal p.369.; source id: AOSE-S010. locators: §§2.1–2.2; §3; references Yu95a and Yu97a.; source id: AOSE-S059. locators: Introduction; i* and ALBERT model discussion; banking example; references.; source id: AOSE-S031. locators: Method and toolchain sections; evaluation/discussion.

### CR-02 — Universal agent advantage

**Affected candidates —** EAOSE-008; EAOSE-009; EAOSE-010; EAOSE-011; EAOSE-012; EAOSE-063

**Objection —** Intentional descriptions can be coherent but useless, and fixed workflows can meet some tasks more simply.

**Evidence and attribution —** Primary AOP/engineering arguments explicitly bound usefulness; a software-repair baseline supplies a modern domain-specific comparison.

**Response —** Compare semantic fit and full costs, allowing agent-oriented analysis with non-agent implementation.

**Present judgement —** Reject universal agentisation and benefit from popularity; retain the selection test, not a guaranteed winning architecture.

**Residual uncertainty —** No one benchmark settles the architecture choice for open or changing organisations.

**Source locators —** source id: AOSE-S033. locators: §§1.1–1.3; AGENT0 sections.; source id: AOSE-S055. locators: p.35 opening; pp.36–40 complexity, abstraction, decomposition and interactions.; source id: AOSE-S047. locators: Approach; experimental setup; results; limitations.; source id: AOSE-S048. locators: Cost/accuracy, benchmark design and reproducibility sections.

### CR-03 — Stable versus changing organisations

**Affected candidates —** EAOSE-013; EAOSE-014; EAOSE-015; EAOSE-016; EAOSE-017; EAOSE-019; EAOSE-076

**Objection —** A static cooperative role design does not cover changing capabilities, strategic participants or outstanding work during reassignment.

**Evidence and attribution —** Original Gaia declares boundaries and acknowledges the unelaborated collective role case. Organisational methods introduce different assignment assumptions.

**Response —** Use explicit guarded alternatives and distinguish assignment feasibility from continuity of incurred obligations.

**Present judgement —** Universal static assumptions are superseded, not static designs themselves. Dynamic reassignment is assumption-sensitive; EAOSE-076 is an analytical composition burden.

**Residual uncertainty —** Open membership, dishonest capability claims and non-transferable commitments can prevent successful reconfiguration.

**Source locators —** source id: AOSE-S001. locators: Author PDF pp.2–3, Domain Characteristics and §2; §§3–4; figures 1–5; §§4.2–4.3, 6.2 and 7; note 3.; source id: AOSE-S009. locators: §1; methodology framework and process-construction sections; Discussion/future work, pp.274–275.; source id: AOSE-S014. locators: Publisher abstract and article opening, pp.317–319.; source id: AOSE-S016. locators: Introduction; §2; organisation metamodel sections.

### CR-04 — Communication semantics

**Affected candidates —** EAOSE-020; EAOSE-021; EAOSE-022; EAOSE-023; EAOSE-024; EAOSE-027; EAOSE-072

**Objection —** Inaccessible private mental states cannot generally provide public evidence of compliance; syntactic interoperability leaves meaning and effects unsettled.

**Evidence and attribution —** Singh offers the open-systems criticism. The standard itself identifies interoperability limitations; formal synthesis addresses a narrower model.

**Response —** Use public commitments or information constraints where appropriate, while retaining BDI internally where useful.

**Present judgement —** EAOSE-024 remains contested by context; reject the standard-badge and role-prompt equivalences.

**Residual uncertainty —** Observed utterances may not establish physical delivery, and institutions can disagree on discharge.

**Source locators —** source id: AOSE-S021. locators: pp.42–45: perspectives, agency and compliance.; source id: AOSE-S037. locators: §§3–5; §6 definitions 19–21 and theorems 1–3; §7.; source id: AOSE-S043. locators: §2, printed p.2, specification lines 72–98; Table 1.

### CR-05 — Transformation and incomplete design

**Affected candidates —** EAOSE-022; EAOSE-025; EAOSE-026; EAOSE-032; EAOSE-035; EAOSE-047

**Objection —** Generated syntax or partial design consistency can be mistaken for guaranteed deployed protocol behaviour.

**Evidence and attribution —** Transformations have explicit semantics; the early-phase checker discusses lack of unconditional soundness/completeness for partial designs.

**Response —** Identify the exact preserved property, manual boundary, false positives and environment assumptions; use tests or stronger proofs for the remaining claim.

**Present judgement —** Reject EAOSE-035; retain correspondence and early defect location under bounded assumptions, not as universal certificates.

**Residual uncertainty —** Libraries, adapters, version mixtures and transport faults can violate the abstraction relation.

**Source locators —** source id: AOSE-S036. locators: §2; Fig.1; transformation rule (1), pp.2426–2427.; source id: AOSE-S037. locators: §§3–5; §6 definitions 19–21 and theorems 1–3; §7.; source id: AOSE-S054. locators: §3.2–3.4; §4; Table 1, pp.933–940.

### CR-06 — Autonomy and verification

**Affected candidates —** EAOSE-028; EAOSE-029; EAOSE-030; EAOSE-031; EAOSE-043; EAOSE-044; EAOSE-045; EAOSE-046; EAOSE-049

**Objection —** A formal decision model can be correct while beliefs, actuators or the environment are wrong; exhaustive behaviour testing may be impractical.

**Evidence and attribution —** Code/model verification distinguishes its environment assumptions; testability analysis examines bounded goal-plan paths rather than every real-world behaviour.

**Response —** Choose constrained models, separate boundary validation and combine agent/collective evidence without inflating the guarantee.

**Present judgement —** Retain strong distinctions but keep formal techniques assumption-sensitive or domain-specific. Do not infer a universal impossibility or complete physical assurance.

**Residual uncertainty —** External validity, real-time constraints and learned behaviour remain separate obligations.

**Source locators —** source id: AOSE-S012. locators: pp.312–315: introduction, environment and dynamic constraints; Implementation and OASIS application, pp.316–319.; source id: AOSE-S023. locators: Abstract and verification architecture sections; Examples and concluding limitations.; source id: AOSE-S024. locators: Trace-counting model and discussion.; source id: AOSE-S030. locators: Verification framework and case studies; Masthead; §§III–IV; footnote 4.; source id: AOSE-S049. locators: §2 concurrent game models and incomplete information; strategy/plan-generation construction.

### CR-07 — Method fragmentation and burden

**Affected candidates —** EAOSE-033; EAOSE-034; EAOSE-036; EAOSE-037; EAOSE-038; EAOSE-039; EAOSE-040; EAOSE-041; EAOSE-042; EAOSE-064; EAOSE-075; EAOSE-080

**Objection —** More diagrams or phases can increase learning/maintenance cost without executable guidance or compatible semantics.

**Evidence and attribution —** Method-comparison and tailoring work identify different guidance/tool strengths; Agile PASSI changes the process for a narrower need.

**Response —** Compose understood fragments, preserve their inputs/consumers, and allow a smaller method or omission.

**Present judgement —** Reject ceremony and joint-success inferences; retain proportional tailoring, including retirement, without a new retirement office.

**Residual uncertainty —** Fragment consistency is not measured usability; expertise and tool availability can dominate local cost.

**Source locators —** source id: AOSE-S002. locators: §§3–5 and figure 4, PDF p.6.; source id: AOSE-S003. locators: §3.1, PDF p.3; §3.1 and work-product dependencies.; source id: AOSE-S008. locators: Original PASSI and Agile PASSI process sections.; source id: AOSE-S017. locators: §§1–5; Agent OPEN sections; Appendix, PDF pp.13–14.; source id: AOSE-S046. locators: Introduction; methodology/process/tool distinctions; concluding discussion.

### CR-08 — Testing and oracle validity

**Affected candidates —** EAOSE-043; EAOSE-048; EAOSE-050; EAOSE-051; EAOSE-052; EAOSE-066

**Objection —** A high score can reward a weak oracle, omit critical failures or count correlated runs as independent evidence.

**Evidence and attribution —** Testability, mutation-based examples, fault injection and failure taxonomies expose different limits; none covers every behaviour.

**Response —** Use relevant negative cases, explicit oracles and configuration-labelled repeats; distinguish code coverage, mutation score, task utility and safety.

**Present judgement —** Keep useful testing and runtime observations; reject unrestricted exhaustive-testing claims. Oracle adequacy remains gameable.

**Residual uncertainty —** Real deployment distributions and rare failure frequencies are not established by the reviewed toy or benchmark cases.

**Source locators —** source id: AOSE-S024. locators: Trace-counting model and discussion.; source id: AOSE-S031. locators: Method and toolchain sections; evaluation/discussion.; source id: AOSE-S035. locators: §II-A–C; §III; §V.; source id: AOSE-S050. locators: §§3–5; Table 1; Appendices A, G–H.; source id: AOSE-S053. locators: §§1–3; attack/defence evaluation and limitations.

### CR-09 — Lifecycle gaps and self-revision

**Affected candidates —** EAOSE-053; EAOSE-054; EAOSE-055; EAOSE-056; EAOSE-057; EAOSE-058; EAOSE-059; EAOSE-074; EAOSE-082

**Objection —** Design completion does not ensure operational change is controlled, and a self-modifier can optimise its own revised acceptance criterion.

**Evidence and attribution —** DevOps-oriented work proposes lifecycle integration; contemporary self-evolution remains a limited prototype rather than a general stability result.

**Response —** Add explicitly labelled lifecycle translations, selective revalidation and external revision boundaries rather than claiming all original methods already did this.

**Present judgement —** Reject EAOSE-059 and EAOSE-082. Preserve evidence continuity within EAOSE-057, not as a separate new property.

**Residual uncertainty —** Partially observed drift and non-versioned external services can leave residual uncertainty despite regression.

**Source locators —** source id: AOSE-S029. locators: §§4–5.; source id: AOSE-S031. locators: Method and toolchain sections; evaluation/discussion.; source id: AOSE-S035. locators: §II-A–C; §III; §V.; source id: AOSE-S057. locators: §§2–4.

### CR-10 — Adoption and causal attribution

**Affected candidates —** EAOSE-011; EAOSE-060; EAOSE-061; EAOSE-062; EAOSE-063

**Objection —** Applications and tool success are often used to assert whole-method superiority without an appropriate comparator.

**Evidence and attribution —** Industrial reports show real use; survey, student and vendor cases have different units and validity threats. The studies are not interchangeable replications.

**Response —** Partition field existence, local comparative results and causal generality; retain null and contrary outcomes alongside positive reports.

**Present judgement —** Whole-method superiority remains EAOSE-062 UNRESOLVED. Neither no use nor universal superiority is justified.

**Residual uncertainty —** Representative longitudinal cost/benefit comparisons with competent conventional alternatives remain missing from this inspected corpus.

**Source locators —** source id: AOSE-S002. locators: §§3–5 and figure 4, PDF p.6.; source id: AOSE-S025. locators: §§2–3; §§4.1–4.2.; source id: AOSE-S026. locators: §1; §5.1–5.2; §§6–7.; source id: AOSE-S042. locators: §4 data collection and maturity classification; results and limitations.; source id: AOSE-S045. locators: Background: Commitments; Methods: Part Two; Results, hypotheses H1–H4; Discussion.

### CR-11 — Learned-component translations

**Affected candidates —** EAOSE-065; EAOSE-067; EAOSE-068; EAOSE-069; EAOSE-070; EAOSE-071; EAOSE-072; EAOSE-083

**Objection —** Fluent role/plan text can conceal untrusted instructions, semantic mistakes, remote drift and latency.

**Evidence and attribution —** Documented BDI integrations state translation/injection limitations; benchmark and trace work supplies bounded failure observations.

**Response —** Preserve admissible actions, independent authority, grounded evaluation and runtime responsiveness where needed; label memory provenance as a transfer judgement.

**Present judgement —** Reject role-prompt equivalence. Retain bounded hybrid obligations without claiming stochastic components inherit classical guarantees automatically.

**Residual uncertainty —** Prompt changes, attack adaptations and provider opacity limit reproducibility and security transfer.

**Source locators —** source id: AOSE-S035. locators: §II-A–C; §III; §V.; source id: AOSE-S050. locators: §§3–5; Table 1; Appendices A, G–H.; source id: AOSE-S052. locators: §2; Fig.1; §3 conclusions, pp.2541–2543.; source id: AOSE-S053. locators: §§1–3; attack/defence evaluation and limitations.; source id: AOSE-S056. locators: §§3–4; §3.2 concurrency; §5 setup, metrics and Table 1; §6.; source id: AOSE-S057. locators: §§2–4.

### CR-12 — Composed system

**Affected candidates —** EAOSE-073; EAOSE-074; EAOSE-075; EAOSE-076; EAOSE-080; EAOSE-081; EAOSE-082

**Objection —** A coherent union of views may still permit an unjustified action, orphan an obligation, duplicate machinery or conceal incompatible goals.

**Evidence and attribution —** The counterexamples here are analytical constructions grounded in the distinctions of the component mechanisms, not observed validations of the new synthesis.

**Response —** Use one cross-view consequential-decision relation and a guarded live-obligation transition; merge duplicate continuity, retirement and feedback candidates.

**Present judgement —** Retain EAOSE-073 and contextual EAOSE-076 as analytical composition-induced properties; reject the two guarantee inferences and preserve three duplicates in the denominator.

**Residual uncertainty —** The net cost and comparative value of these composed configurations have not been empirically established.

**Source locators —** source id: AOSE-S003. locators: §3.1, PDF p.3; §3.1 and work-product dependencies.; source id: AOSE-S009. locators: §1; methodology framework and process-construction sections; Discussion/future work, pp.274–275.; source id: AOSE-S031. locators: Method and toolchain sections; evaluation/discussion.; source id: AOSE-S037. locators: §§3–5; §6 definitions 19–21 and theorems 1–3; §7.; source id: AOSE-S038. locators: Security concepts and extended development process sections.; source id: AOSE-S045. locators: Background: Commitments; Methods: Part Two; Results, hypotheses H1–H4; Discussion.; source id: AOSE-S059. locators: Introduction; i* and ALBERT model discussion; banking example; references.

### CR-13 — Specialised branches

**Affected candidates —** EAOSE-077; EAOSE-078; EAOSE-079

**Objection —** Hierarchy, cooperative emergence and knowledge-intensive multi-view modelling can be inappropriate outside their problem assumptions.

**Evidence and attribution —** ASPECS, ADELFE and MAS-CommonKADS describe different problem structures; organisation-based engineering explicitly contrasts known-function assignment with cooperative emergence.

**Response —** Keep specialised branches with discriminators instead of importing all views or claiming one universal organisation.

**Present judgement —** EAOSE-077/078 are domain-specific; EAOSE-079 contextual. Their exclusion from a configuration need not be a deficiency.

**Residual uncertainty —** Cross-cutting dependencies, strategic behaviour and knowledge-acquisition costs may defeat their advantages.

**Source locators —** source id: AOSE-S016. locators: Introduction; §2; organisation metamodel sections.; source id: AOSE-S022. locators: §§1–2; §§3–7.; source id: AOSE-S040. locators: §§2–3; AMAS adequacy and environment characterisation; behaviour/interaction design sections.; source id: AOSE-S041. locators: §3: agent, task, expertise, organisation, coordination, communication and design models.

### CR-14 — Authority, capability and accountability

**Affected candidates —** EAOSE-005; EAOSE-010; EAOSE-018; EAOSE-023; EAOSE-056; EAOSE-058; EAOSE-068; EAOSE-073; EAOSE-076

**Objection —** A permitted model action may lack actual authority or capability, and observed benefit cannot retrospectively authorise it.

**Evidence and attribution —** Security, resource-permission and commitment mechanisms distinguish relevant concepts; the complete cross-view judgement is this study’s analytical strengthening.

**Response —** Keep the principal, decision boundary, enforcement point and external effect separate; require consent for transfers where the obligation semantics demands it.

**Present judgement —** Retain the distinctions without presenting them as a universal legal rule or an automatic governance engine.

**Residual uncertainty —** The real system must supply its own legitimate authority basis and evidence of capacity.

**Source locators —** source id: AOSE-S001. locators: Author PDF pp.2–3, Domain Characteristics and §2; §§3–4; figures 1–5; §§4.2–4.3, 6.2 and 7; note 3.; source id: AOSE-S021. locators: pp.42–45: perspectives, agency and compliance.; source id: AOSE-S038. locators: Security concepts and extended development process sections.; source id: AOSE-S045. locators: Background: Commitments; Methods: Part Two; Results, hypotheses H1–H4; Discussion.; source id: AOSE-S053. locators: §§1–3; attack/defence evaluation and limitations.

### CR-15 — Measurement and administrative overhead

**Affected candidates —** EAOSE-034; EAOSE-039; EAOSE-041; EAOSE-051; EAOSE-054; EAOSE-057; EAOSE-071; EAOSE-075

**Objection —** Trace coverage, observability and process evidence can become costly proxies that do not improve decisions.

**Evidence and attribution —** Sources bound guidance, cost and diagnostic claims. That unused links or intrusive instrumentation may be counterproductive is an explicitly analytical objection.

**Response —** Use consumer-linked traces and proportionate collection; replace the mechanism when simpler evidence is adequate.

**Present judgement —** Traceability remains easily bureaucratised; diagnostic tracing is contextual, not an always-on maximal-recording obligation.

**Residual uncertainty —** The right retention, privacy and instrumentation trade-off is not measured for all domains in the corpus.

**Source locators —** source id: AOSE-S002. locators: §§3–5 and figure 4, PDF p.6.; source id: AOSE-S035. locators: §II-A–C; §III; §V.; source id: AOSE-S046. locators: Introduction; methodology/process/tool distinctions; concluding discussion.; source id: AOSE-S048. locators: Cost/accuracy, benchmark design and reproducibility sections.

### CR-16 — Latency and stale generated decisions

**Affected candidates —** EAOSE-031; EAOSE-066; EAOSE-067; EAOSE-070; EAOSE-083

**Objection —** Non-blocking plan generation can preserve the loop yet return a stale or resource-starving decision.

**Evidence and attribution —** The generation paper recommends intention suspension; its small evaluation does not establish a hard-real-time response guarantee.

**Response —** Keep unrelated event handling available where required, then check completion, cancellation and late-result applicability under current state.

**Present judgement —** EAOSE-083 is retained contextually as a native documented mechanism, not a new composition discovery or universal scheduler guarantee.

**Residual uncertainty —** Fairness, resource exhaustion and deadline evidence must be supplied by the particular runtime/application.

**Source locators —** source id: AOSE-S035. locators: §II-A–C; §III; §V.; source id: AOSE-S056. locators: §§3–4; §3.2 concurrency; §5 setup, metrics and Table 1; §6.

### CR-17 — Contemporary code-centric framework comparison

**Affected candidates —** EAOSE-008; EAOSE-011; EAOSE-048; EAOSE-060; EAOSE-061; EAOSE-062; EAOSE-066

**Objection —** A common backend does not isolate architecture when tools, prompts and workflows differ; a metric label can conceal a different denominator.

**Evidence and attribution —** Table 3 defines the vulnerability measure as TP/(TP+FP); the experiments compare configured systems with different default toolsets.

**Response —** Preserve configured task/cost outcomes and the actual measure definition. Do not reinterpret the result as universal architectural or whole-method superiority.

**Present judgement —** EAOSE-062 remains unresolved; evidence classification, comparative baselines and oracle scrutiny are strengthened without a new candidate.

**Residual uncertainty —** Independent repetitions, alternative competent configurations and lifecycle effort could change the comparative judgement.

**Source locators —** source id: AOSE-S061. locators: §§3.2–3.4, Tables 2–3; §4; §5.2; §3.4 Table 3; evaluation metric description; §4 and §§5.1–5.2.

### CR-18 — BDI–LLM oracle and reuse limits

**Affected candidates —** EAOSE-029; EAOSE-040; EAOSE-048; EAOSE-060; EAOSE-062; EAOSE-067; EAOSE-069; EAOSE-073; EAOSE-082

**Objection —** Named-belief existence can refute a malformed success claim without establishing the belief’s truth, and a plan library can add machinery without a measured accuracy gain.

**Evidence and attribution —** The tiered verifier and preliminary seeded/non-seeded comparison expose distinct representation, grounding and effect questions. Later policy/provenance modules are explicitly future work.

**Response —** Treat typed or named beliefs as internal evidence only; add the appropriate external criterion. Retain reuse only under its cost and applicability conditions.

**Present judgement —** No universal improvement from iteration or seeded plans; no demonstrated memory-provenance deployment benefit. The criterion/effect distinction remains necessary.

**Residual uncertainty —** The local null comparison is not statistical equivalence or proof that BDI lacks value; independent ablation and outcome-sensitive oracles remain needed.

**Source locators —** source id: AOSE-S062. locators: §§4.4–4.7 and 5; §§6–7, Table 2 (PDF p.7 rendered); §§8.2–8.4 and 9.


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_EVOLUTION_UNDER_CRITICISM

A transition must alter a mechanism, assumption, scope or evidential claim. Renaming and adding more diagrams are not improvements in themselves. Preservation of a narrower branch is often more warranted than replacement by a maximal synthesis.

### EU-01 — NARROWED

**Properties —** EAOSE-008, EAOSE-009, EAOSE-012, EAOSE-028

**Original problem —** Give intentional computational abstractions a usable programming meaning.

**Changed mechanism or assumption —** Keep useful intentional abstraction and implementation semantics, not universal agentisation or a whole lifecycle claim.

**Residual uncertainty —** Semantic fit is not demonstrated economic superiority.

[AOSE-S033; AOSE-S011; AOSE-S013]

### EU-02 — REFINED

**Properties —** EAOSE-001, EAOSE-002, EAOSE-003, EAOSE-004, EAOSE-007

**Original problem —** Understand strategic dependency and vulnerability before prescribing system behaviour.

**Changed mechanism or assumption —** Requirements views support strategic inquiry; core language consistency and external validation address different problems.

**Residual uncertainty —** No notation supplies an exhaustive stakeholder discovery procedure.

[AOSE-S059; AOSE-S010; AOSE-S034; AOSE-S060]

### EU-03 — NARROWED

**Properties —** EAOSE-013, EAOSE-014, EAOSE-015, EAOSE-019

**Original problem —** Move from requirements to organisational analysis and design.

**Changed mechanism or assumption —** Original static/cooperative design remains a branch; do not inherit it as a premise for all later systems.

**Residual uncertainty —** Collective fulfilment and open adversarial participation need further mechanisms.

[AOSE-S001]

### EU-04 — GENERALISED

**Properties —** EAOSE-016, EAOSE-017, EAOSE-036, EAOSE-037, EAOSE-039

**Original problem —** Avoid a single monolithic process for differing project contexts.

**Changed mechanism or assumption —** Organisational and method-engineering approaches separate configurable assignments/process fragments from one fixed method.

**Residual uncertainty —** Capability knowledge and semantic compatibility do not prove live continuity or benefit.

[AOSE-S003; AOSE-S009; AOSE-S017; AOSE-S046]

### EU-05 — REFINED

**Properties —** EAOSE-005, EAOSE-006, EAOSE-034

**Original problem —** Retain intentional requirements throughout development.

**Changed mechanism or assumption —** Security and iterative requirements/implementation relationships become explicit concerns rather than late labels.

**Residual uncertainty —** Enforcement and changed-goal legitimacy still need actual evidence.

[AOSE-S004; AOSE-S038]

### EU-06 — HYBRIDISED

**Properties —** EAOSE-033, EAOSE-038, EAOSE-039, EAOSE-040

**Original problem —** Engineer implemented agents with familiar software models; reduce process burden for rapid robotic development.

**Changed mechanism or assumption —** Agile PASSI changes the process through selected reusable fragments for rapid development.

**Residual uncertainty —** Demonstrated feasibility and reuse do not establish a universal faster method.

[AOSE-S039; AOSE-S008]

### EU-07 — STILL_CONTESTED

**Properties —** EAOSE-020, EAOSE-021, EAOSE-023, EAOSE-024, EAOSE-027

**Original problem —** Express multi-party interaction without confusing internal intention, message structure and public meaning.

**Changed mechanism or assumption —** Public-obligation and information-based mechanisms address limitations of private-state compliance while preserving internal alternatives.

**Residual uncertainty —** Public observations and institutional meaning remain contestable.

[AOSE-S021; AOSE-S020; AOSE-S043]

### EU-08 — REFINED

**Properties —** EAOSE-022, EAOSE-025, EAOSE-032

**Original problem —** Support flexible public interaction among independently implemented agents.

**Changed mechanism or assumption —** Bounded protocol generation and implementation mappings give specific preservation obligations rather than universal interoperability.

**Residual uncertainty —** A model theorem cannot ensure independent actors cooperate or deliver physical effects.

[AOSE-S045; AOSE-S037; AOSE-S036]

### EU-09 — NARROWED

**Properties —** EAOSE-029, EAOSE-043, EAOSE-044, EAOSE-045, EAOSE-046, EAOSE-047, EAOSE-048, EAOSE-049, EAOSE-052

**Original problem —** Close specified design/code gaps without confusing model proof with external adequacy.

**Changed mechanism or assumption —** Separate the subject of assurance, the oracle and the environmental premise; partial-model checks stay conditional.

**Residual uncertainty —** No composed guarantee spans all verified code, stochastic models and uncontrolled environments.

[AOSE-S023; AOSE-S024; AOSE-S030; AOSE-S031; AOSE-S049; AOSE-S054]

### EU-10 — HYBRIDISED

**Properties —** EAOSE-053, EAOSE-054, EAOSE-055, EAOSE-056, EAOSE-057, EAOSE-059

**Original problem —** Connect agent development to deployed systems and operational feedback.

**Changed mechanism or assumption —** Operational software practices extend design-focused methods; selective evidence handling is this study’s explicit lifecycle interpretation.

**Residual uncertainty —** Actual long-term adoption/cost evidence remains limited.

[AOSE-S029; AOSE-S044]

### EU-11 — STILL_CONTESTED

**Properties —** EAOSE-011, EAOSE-060, EAOSE-061, EAOSE-062, EAOSE-063

**Original problem —** Determine whether engineering mechanisms are used and pay off.

**Changed mechanism or assumption —** Keep positive field existence and local/null comparisons while declining an unsupported whole-method ranking.

**Residual uncertainty —** Representative independent longitudinal comparisons remain an open research question.

[AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S045; AOSE-S025; AOSE-S061]

### EU-12 — DOMAIN_SPECIFIC

**Properties —** EAOSE-077

**Original problem —** Engineer complex systems through nested organisations.

**Changed mechanism or assumption —** Preserve nested organisation where structural assumptions warrant it.

**Residual uncertainty —** Hierarchy need not fit dense cross-cutting coordination.

[AOSE-S022]

### EU-13 — DOMAIN_SPECIFIC

**Properties —** EAOSE-078

**Original problem —** Build cooperative adaptive systems where global function is not simply prescribed.

**Changed mechanism or assumption —** Preserve cooperation-driven adaptation as an alternative to prescribed-function allocation.

**Residual uncertainty —** Local repair does not guarantee every desired global consequence.

[AOSE-S040; AOSE-S016]

### EU-14 — PRESERVED

**Properties —** EAOSE-079

**Original problem —** Extend knowledge-system engineering to multiple interacting agents.

**Changed mechanism or assumption —** Keep separate task/expertise reasoning where it has a consumer, without mandatory knowledge-model proliferation.

**Residual uncertainty —** Acquisition and maintenance costs may outweigh value.

[AOSE-S041]

### EU-15 — HYBRIDISED

**Properties —** EAOSE-065, EAOSE-066, EAOSE-067, EAOSE-068, EAOSE-069, EAOSE-070, EAOSE-071, EAOSE-072, EAOSE-083

**Original problem —** Use language/generation while handling stochasticity, untrusted inputs and operational change.

**Changed mechanism or assumption —** Documented BDI integrations retain explicit capabilities and add learned language/plans; new testing and operational limits are examined.

**Residual uncertainty —** Stochastic transfer, security and remote drift remain bounded; non-blocking wait is not full scheduling assurance.

[AOSE-S035; AOSE-S047; AOSE-S048; AOSE-S050; AOSE-S052; AOSE-S053; AOSE-S056; AOSE-S057; AOSE-S062]

### EU-16 — REFINED

**Properties —** EAOSE-073, EAOSE-076

**Original problem —** Compose criticism-tested mechanisms without inventing a historical school.

**Changed mechanism or assumption —** Analytical composition adds a shared consequential-decision constraint and guarded obligation continuity at reconfiguration.

**Residual uncertainty —** Net benefit is not empirically demonstrated; the two added relations are not academic consensus.

[AOSE-S003; AOSE-S004; AOSE-S009; AOSE-S021; AOSE-S031; AOSE-S037; AOSE-S038; AOSE-S045; AOSE-S059]

### EU-17 — REPLACED

**Properties —** EAOSE-074, EAOSE-075, EAOSE-081

**Original problem —** Compose criticism-tested mechanisms without inventing a historical school.

**Changed mechanism or assumption —** Duplicate synthesis labels resolve to existing revalidation, tailoring and feedback mechanisms without extra controls.

**Residual uncertainty —** A future distinct trigger would require a new candidate, not renaming.

[AOSE-S003; AOSE-S004; AOSE-S009; AOSE-S021; AOSE-S031; AOSE-S037; AOSE-S038; AOSE-S045; AOSE-S059]

### EU-18 — REJECTED

**Properties —** EAOSE-080, EAOSE-082

**Original problem —** Compose criticism-tested mechanisms without inventing a historical school.

**Changed mechanism or assumption —** Counterexamples reject compatibility-to-success and feedback-to-improvement guarantees.

**Residual uncertainty —** This does not refute actual conditional theorems or useful bounded adaptation.

[AOSE-S003; AOSE-S004; AOSE-S009; AOSE-S021; AOSE-S031; AOSE-S037; AOSE-S038; AOSE-S045; AOSE-S059]


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_INTERNAL_TENSIONS

A selection discriminator is supplied for each tension; “balance” is not used as a resolution. A hybrid can fail through conflicting assumptions or the cost of maintaining multiple views.

### T-01 — Expressiveness versus Learnability and decision cost

**Properties —** EAOSE-001; EAOSE-004; EAOSE-034; EAOSE-039; EAOSE-041

**Context favouring first —** Interdependent goals and disputed delegation need richer views.

**Context favouring second —** Small stable task has a direct consumer and unambiguous result.

**Discriminator —** Does the extra view change a consequential decision that the simpler form cannot support?

**Hybrid and status —** Keep a minimal shared vocabulary with selected detailed views; analytical configuration rather than universal method.

**Hybrid failure —** Two representations drift or the team cannot interpret their relation.

**Costs —** Both branches retain their own training, semantic and assurance costs; no free balance is inferred.

**Uncertainty —** No universally optimal diagram set or granularity.

[AOSE-S002; AOSE-S034; AOSE-S046]

### T-02 — Autonomous flexibility versus Predictable assurance

**Properties —** EAOSE-010; EAOSE-028; EAOSE-031; EAOSE-045; EAOSE-067

**Context favouring first —** Changing contexts require genuine runtime choices.

**Context favouring second —** High consequence or tight timing requires a small verifiable choice envelope.

**Discriminator —** Can the permitted decision space and effect boundary be validated at acceptable cost?

**Hybrid and status —** Constrain actions and verify/check selected internal decisions while leaving benign implementation choices open.

**Hybrid failure —** Verified controller encloses an unvalidated learned or physical boundary.

**Costs —** Both branches retain their own training, semantic and assurance costs; no free balance is inferred.

**Uncertainty —** Guarantees remain model- and environment-bounded.

[AOSE-S023; AOSE-S024; AOSE-S030; AOSE-S056]

### T-03 — Lifecycle coverage versus Operational burden

**Properties —** EAOSE-036; EAOSE-037; EAOSE-039; EAOSE-053

**Context favouring first —** Multiple teams and long-lived evolution need explicit handoffs.

**Context favouring second —** A short-lived, contained task does not need every named phase.

**Discriminator —** Which live risk or consumer depends on each work product?

**Hybrid and status —** Tailored fragments with actual consumers; no mandatory maximal methodology.

**Hybrid failure —** A omitted phase hides a real duty rather than removing ceremony.

**Costs —** Both branches retain their own training, semantic and assurance costs; no free balance is inferred.

**Uncertainty —** Operational cost can be under-recorded.

[AOSE-S003; AOSE-S008; AOSE-S017; AOSE-S029]

### T-04 — Standardised meaning versus Platform-specific leverage

**Properties —** EAOSE-021; EAOSE-026; EAOSE-032; EAOSE-041

**Context favouring first —** Heterogeneous peers and long-lived integration demand shared semantics.

**Context favouring second —** A controlled platform enables useful automation and lower local cost.

**Discriminator —** Will the generated/platform-specific behaviour remain equivalent at the external boundary?

**Hybrid and status —** Versioned adapters plus external conformance/meaning tests.

**Hybrid failure —** Adapter preserves fields but alters commitments or timing.

**Costs —** Both branches retain their own training, semantic and assurance costs; no free balance is inferred.

**Uncertainty —** No standard badge proves the integration.

[AOSE-S036; AOSE-S043; AOSE-S044]

### T-05 — Generation efficiency versus Semantic trust

**Properties —** EAOSE-032; EAOSE-033; EAOSE-034; EAOSE-035

**Context favouring first —** Repeated well-defined structures justify a verified or checked transformation.

**Context favouring second —** Small or unusual behaviour is cheaper to implement directly.

**Discriminator —** What property is preserved, and is its manual boundary smaller than a handwritten solution’s review burden?

**Hybrid and status —** Generate boilerplate while separately validating the code with consequential semantics.

**Hybrid failure —** Generated-code percentage becomes a proxy for correctness or effort saved.

**Costs —** Both branches retain their own training, semantic and assurance costs; no free balance is inferred.

**Uncertainty —** Comparative benefit depends on tooling and task repetition.

[AOSE-S008; AOSE-S018; AOSE-S037; AOSE-S054]

### T-06 — Reconfiguration freedom versus Continuity of obligations

**Properties —** EAOSE-017; EAOSE-023; EAOSE-058; EAOSE-076

**Context favouring first —** Changing capability or failure makes reassignment necessary.

**Context favouring second —** Live non-transferable obligations require stability or draining.

**Discriminator —** Can successor authority, capacity and protocol state jointly sustain the old obligation?

**Hybrid and status —** Drain or validly transfer only the affected work; keep the rest operating.

**Hybrid failure —** Formal reassignment or compensation cannot restore an irreversible external effect.

**Costs —** Both branches retain their own training, semantic and assurance costs; no free balance is inferred.

**Uncertainty —** Consent and partial observation can block safe transition.

[AOSE-S009; AOSE-S016; AOSE-S037; AOSE-S045]

### T-07 — Public accountability versus Private deliberative autonomy

**Properties —** EAOSE-023; EAOSE-024; EAOSE-028

**Context favouring first —** Open participants need observable commitment conditions.

**Context favouring second —** Controlled BDI agents permit useful mental-state reasoning.

**Discriminator —** Who can observe the state used to judge compliance, and why is it credible?

**Hybrid and status —** Public commitments at the boundary, heterogeneous internals behind it.

**Hybrid failure —** A message about intention is mistaken for actual discharge.

**Costs —** Both branches retain their own training, semantic and assurance costs; no free balance is inferred.

**Uncertainty —** Institutional interpretation can remain contested.

[AOSE-S012; AOSE-S021; AOSE-S037]

### T-08 — Adaptive response versus Stable external adequacy

**Properties —** EAOSE-049; EAOSE-051; EAOSE-055; EAOSE-078; EAOSE-082

**Context favouring first —** Unexpected contexts require local feedback and adjustment.

**Context favouring second —** Consequences are serious or evaluation rules can be gamed.

**Discriminator —** Is the successor judged under a defensible external criterion, not just a self-chosen score?

**Hybrid and status —** Bounded adaptation plus externally authorised revision of goals/constraints.

**Hybrid failure —** The loop optimises a proxy while damaging an omitted stakeholder.

**Costs —** Both branches retain their own training, semantic and assurance costs; no free balance is inferred.

**Uncertainty —** No general convergence or autonomous improvement result.

[AOSE-S040; AOSE-S048; AOSE-S057]

### T-09 — Observability and evidence continuity versus Privacy, overhead and provider opacity

**Properties —** EAOSE-054; EAOSE-057; EAOSE-070; EAOSE-071

**Context favouring first —** Distributed failures cannot be located with local errors.

**Context favouring second —** Single component and direct effect make broad tracing redundant.

**Discriminator —** Which observation is needed for a live claim, and what does collection itself cost or expose?

**Hybrid and status —** Selective configuration-linked traces and targeted regression.

**Hybrid failure —** Missing spans or intrusive instrumentation mislead interpretation.

**Costs —** Both branches retain their own training, semantic and assurance costs; no free balance is inferred.

**Uncertainty —** Trace sufficiency and remote drift are not universally decidable.

[AOSE-S035; AOSE-S048; AOSE-S050]

### T-10 — Responsiveness versus Simple execution and fresh decisions

**Properties —** EAOSE-031; EAOSE-067; EAOSE-083

**Context favouring first —** Long-running generation coexists with urgent independent events.

**Context favouring second —** Synchronous execution has no competing duty and predictable delay.

**Discriminator —** Can the runtime suspend one wait while fairly servicing the others and rejecting stale results?

**Hybrid and status —** Non-blocking wait with explicit cancellation/context recheck.

**Hybrid failure —** More concurrency introduces interference, starvation or stale plan enactment.

**Costs —** Both branches retain their own training, semantic and assurance costs; no free balance is inferred.

**Uncertainty —** Recommendation is not a hard-real-time guarantee.

[AOSE-S035; AOSE-S056]


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_COMPOSED_SYSTEM

### Purpose, environment and real operation

The system’s purpose is to connect accepted needs to justified implementation and defensible evidence of consequences. Its environment includes affected people, independently controlled participants, software and possibly physical resources, uncertain observations and changes over time. It cannot assume cooperative peers, truthful sensors, legitimate goals or a feasible replacement actor merely because a diagram names them.

The objects being changed are not only internal representations. Engineers choose executable capabilities, configure deployed processes and interfaces, bind roles, negotiate dependencies, enforce or withhold permissions, execute interactions, test resource effects and retire implementations. Stakeholders accept, contest or revise requirements within their actual authority. Operators supply observations and perform permitted operational interventions. Models and traces carry distinctions to those decisions; their existence does not perform the intervention or prove its outcome.

A smallest coherent configuration uses a credible statement of required consequences, the relevant affected actors and permissions, a justified implementation choice, tests or observations adequate for the claim, and a way to reopen decisions when a relevant premise changes. These can be a few shared records, conversations and executable checks. The configuration does not require an agent runtime, a separate owner per property, a role hierarchy, a modelling suite or a new approval ceremony.

### Control topology: coupled decisions, not a serial pipeline

Requirements inquiry, protocol/internal design, implementation and assurance can proceed concurrently when their dependencies are available. A local result can enable another activity without settling the complete case. A contradiction is routed to the view capable of resolving it: an excluded stakeholder reopens requirements; a forbidden action reopens the authority or design decision; an implementation counterexample reopens correspondence; a failed external effect reopens both the acceptance translation and the enactment under test. Changes invalidate only affected claims unless a shared premise has wider reach.

The temporal distinction matters. Before action, legitimate authority, actual capability and bounded expected-effect evidence can justify a proposed action or a controlled experiment. Effects that have not yet occurred cannot be demanded as observations at that point. After action, outcome acceptance uses appropriate observations, not the earlier expectation. The same criterion–authority–effect relationship therefore has different consumers and evidence requirements at the two decisions. It does not prohibit all action under uncertainty or claim that every outcome is decidable.

### Why two composition-induced properties survive

**EAOSE-073: criterion–authority–effect coupling.** Requirements relevance alone permits the useful but forbidden action; authority alone permits irrelevant or ineffective work; an observed benefit alone cannot establish that the action was permissible or caused that benefit. The distinct property is the relation at the consequential decision: a defect in one view can withhold or reopen a conclusion in another. Its added content is not three files kept side by side. The supporting component mechanisms remain separately traceable, and an existing direct contract can already provide the coupling. This is an analytical composition supported by discriminating counterexamples, not a new theorem or measured method advantage.

**EAOSE-076: obligation-preserving organisational reconfiguration.** A new role assignment can be structurally valid while leaving a promise, unfinished interaction or duty incurred under the old assignment without a permitted way to fulfil it. Combining organisational bindings with interaction obligations and lifecycle change creates a transition obligation absent from a snapshot role check. The transition must preserve fulfilment, legitimately transfer responsibility, obtain an accepted discharge or explicitly report the unresolved obligation. Compensation is not automatically discharge. Some obligations cannot be transferred and some settings have no feasible successor. The property is therefore contextual, not a promise that every reconfiguration can succeed.

**EAOSE-074 and EAOSE-075 do not add distinct mechanisms.** Evidence continuity is already selective revalidation (EAOSE-057): retaining, narrowing, reassessing or withdrawing claims in response to changed dependencies. Purposeful method retirement is already part of proportional method assembly (EAOSE-039), which must preserve consequential consumers and preventive functions. Their new names do not create new obligations.

The explicit search beyond those three proposals produced EAOSE-076; rejected the inference from compatible fragments to achievable requirements (EAOSE-080); identified counterexample propagation as already present in traceability, iteration and the coupled decision (EAOSE-081); and rejected guaranteed improvement from observation plus self-revision (EAOSE-082). The further native mechanism EAOSE-083 is responsiveness during slow generation, not an emergent property of this synthesis.

### Guarded alternatives and practical economy

The configurations below are alternatives with entry/exit conditions. They may share mechanisms, but combining them requires explicit compatibility. A cooperative emergent approach cannot simply inherit the known-capability assumptions of an allocation method. Open commitment semantics need not expose or standardise private BDI reasoning. Stronger verification does not compensate for a false environment model. Richer operational monitoring can add cost, privacy exposure and ambiguous evidence; it is justified by an actual consumer.

#### CFG-MIN — Smallest coherent engineering form

**Select when —** Few consequential choices and a sufficiently stable task; no open negotiation or dynamic reorganisation requirement.

**Mechanisms —** EAOSE-001; EAOSE-002; EAOSE-005; EAOSE-008; EAOSE-029; EAOSE-039; EAOSE-043; EAOSE-054; EAOSE-057; EAOSE-073

**Operative form —** A stakeholder/acceptance statement; explicit permitted capabilities; a chosen implementation (possibly conventional); grounded tests/results; a small change-impact decision. One record or conversation plus executable checks may discharge several concerns.

**Omit or substitute —** No mandatory agent runtime, goal editor, BDI library, role hierarchy, generated code or continuous trace store.

**Exit / richer-form trigger —** Independent obligations, dynamic roles, safety-critical reasoning, stochastic generation or distributed failure cannot be handled adequately by the simple form.

#### CFG-BDI — Controlled deliberative agents

**Select when —** Goals, plan alternatives and failure handling justify a BDI branch with a sufficiently understood environment.

**Mechanisms —** EAOSE-010; EAOSE-013; EAOSE-014; EAOSE-028; EAOSE-029; EAOSE-030; EAOSE-031; EAOSE-044; EAOSE-045; EAOSE-046

**Operative form —** Agent-level deliberation has explicit plan contexts and effects; collective testing and environmental grounding remain separate. Formal checking is added when its model and cost fit.

**Omit or substitute —** Use imperative/reactive behaviour when BDI adds no leverage; public commitments can coexist at the boundary without forcing common internals.

**Exit / richer-form trigger —** Unknown or strategic peers invalidate cooperative mental-state assumptions; slow learned plans trigger CFG-HYBRID constraints.

#### CFG-OPEN — Open interaction with public obligations

**Select when —** Independent parties retain internal autonomy but need compatible public meaning and completion evidence.

**Mechanisms —** EAOSE-020; EAOSE-021; EAOSE-022; EAOSE-023; EAOSE-025; EAOSE-026; EAOSE-032; EAOSE-073

**Operative form —** Specify commitments/information dependencies, realise local behaviours and check message interpretation plus externally meaningful discharge. Refusal/noncompliance are possible outcomes.

**Omit or substitute —** A direct call or agreed state machine can suffice in a controlled closed setting; do not impose a central total order solely for diagram neatness.

**Exit / richer-form trigger —** Changing role holders with live obligations also requires CFG-RECONFIG; disputed institutional semantics may prevent automated adjudication.

#### CFG-RECONFIG — Known-function adaptive organisation

**Select when —** Capabilities or members change but collective duties remain sufficiently specified.

**Mechanisms —** EAOSE-015; EAOSE-016; EAOSE-017; EAOSE-054; EAOSE-056; EAOSE-058; EAOSE-076

**Operative form —** Observe relevant capability and obligation state; reconcile the old work with successor assignment. Drain, valid transfer, release, compensation or explicit inability are alternatives.

**Omit or substitute —** Static assignment or planned drain can be cheaper and safer; no automatic optimiser is mandatory.

**Exit / richer-form trigger —** Unknown global function and cooperative emergence require a different branch; partial observations can forbid a confident transition.

#### CFG-AMAS — Cooperation-driven emergent adaptation

**Select when —** The ADELFE-style adequacy and cooperation assumptions fit an incompletely prescribed, changing function.

**Mechanisms —** EAOSE-018; EAOSE-049; EAOSE-055; EAOSE-078

**Operative form —** Engineer local responses to non-cooperative situations and evaluate collective adequacy under stated environmental conditions.

**Omit or substitute —** Use a known-goal organisation or central algorithm when the desired function is already sufficiently specified.

**Exit / richer-form trigger —** Strategic refusal, incompatible objectives or unacceptable external effects defeat the cooperative premise; no guarantee is rescued by relabelling them adaptation.

#### CFG-HYBRID — Constrained learned-plan/tool-use integration

**Select when —** Language interpretation or generated plans provide demonstrated task value worth stochasticity, latency and maintenance cost.

**Mechanisms —** EAOSE-010; EAOSE-029; EAOSE-030; EAOSE-056; EAOSE-066; EAOSE-067; EAOSE-068; EAOSE-069; EAOSE-070; EAOSE-071; EAOSE-083

**Operative form —** Treat learned output as a proposal within declared capabilities; separate untrusted inputs from authority; validate syntax, semantic applicability and grounded outcomes. Keep unrelated responsibilities responsive where runtime support permits.

**Omit or substitute —** Prewritten plans, a fixed workflow, a deterministic classifier or no model call may dominate. Memory/trace machinery is conditional, not mandatory.

**Exit / richer-form trigger —** Opaque drift, injection risk, unacceptable delay or unvalidated self-revision warrants restriction, fallback or retirement rather than automatic greater autonomy.

#### CFG-SPECIAL — Optional structural/knowledge refinements

**Select when —** Nearly decomposable organisation or knowledge-intensive reasoning has an actual consumer for additional views.

**Mechanisms —** EAOSE-040; EAOSE-077; EAOSE-079

**Operative form —** Nest organisational boundaries or separate expertise/task views only where the selected core cannot express the relevant decision adequately.

**Omit or substitute —** Flat structures, typed data and direct algorithms remain legitimate alternatives.

**Exit / richer-form trigger —** Cross-cutting coupling or model maintenance makes the extra abstraction more costly than useful.

### Principal composition relations

The complete JSON contains all guarded relations, including candidate dependency links. The principal relations below carry the substantive communication, operation, constraints, alternatives and feedback. Even where components are source-grounded, a relation marked analytical is not recoded as a published empirical result.

#### REL-001 — COMMUNICATES_TO

**Endpoints —** EAOSE-001, EAOSE-002, EAOSE-003, EAOSE-004 → EAOSE-073

**Guard —** A consequential requirement, exclusion or trade-off is disputed.

**Mechanism —** Bring the stakeholder meaning and dependency at issue to the action/acceptance decision; a complete goal view cannot settle permission or effect.

**Shared assumptions —** Affected concerns can be represented or explicitly recorded as disputed.

**Incompatible assumptions —** Closed analyst-only model treated as a complete stakeholder census.

**New cost or failure —** Participation and translation cost; unresolved disputes can block action.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** The legitimate decision maker and inaccessible affected actors remain case-specific.

[AOSE-S004; AOSE-S010; AOSE-S059]

#### REL-002 — CONSTRAINS

**Endpoints —** EAOSE-005, EAOSE-010, EAOSE-013, EAOSE-018 → EAOSE-073

**Guard —** An action changes resources or external relations.

**Mechanism —** A desired consequence must be enacted only through an available and permitted capability; model permission is checked against the actual boundary.

**Shared assumptions —** An identifiable principal controls the relevant delegation.

**Incompatible assumptions —** Runtime goals automatically authorise new tools or resources.

**New cost or failure —** Overconstraint can remove useful discretion.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** The packet supplies no real-system authority basis.

[AOSE-S001; AOSE-S038; AOSE-S053]

#### REL-003 — PROVIDES_EVIDENCE_FOR

**Endpoints —** EAOSE-029, EAOSE-043, EAOSE-048, EAOSE-051 → EAOSE-073

**Guard —** A completion or benefit is claimed.

**Mechanism —** Ground the observed result and its oracle; distinguish an internal success report, an authorised attempt and the achieved consequence.

**Shared assumptions —** The observation relation is known to the degree claimed.

**Incompatible assumptions —** Self-report or favourable score is conclusive external success.

**New cost or failure —** Additional observation can be costly or unavailable.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** Causal attribution may remain uncertain despite verified occurrence.

[AOSE-S023; AOSE-S031; AOSE-S035]

#### REL-004 — FEEDBACK_TO

**Endpoints —** EAOSE-073 → EAOSE-006, EAOSE-034, EAOSE-038, EAOSE-055

**Guard —** A criterion, permission or consequence contradicts another view.

**Mechanism —** Interrupt the disputed decision and reopen only the affected requirement, binding, implementation or assurance claim rather than repairing a proxy score alone.

**Shared assumptions —** Relevant links or accountable human judgement can locate the affected decision.

**Incompatible assumptions —** Later phases are forbidden to revisit earlier assumptions.

**New cost or failure —** Feedback can create oscillation or prevent closure.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** Stable decision criteria and an authorised resolution of trade-offs are required.

[AOSE-S031; AOSE-S038; AOSE-S054; AOSE-S059]

#### REL-005 — CONSTRAINS

**Endpoints —** EAOSE-008, EAOSE-011 → EAOSE-009, EAOSE-028, EAOSE-039

**Guard —** Selecting a paradigm or methodology configuration.

**Mechanism —** Choose agent modelling, runtime and process machinery separately against the actual decision problem and lifecycle cost.

**Shared assumptions —** Alternative tasks and quality demands are comparable.

**Incompatible assumptions —** More autonomous entities necessarily mean a better design.

**New cost or failure —** Fair baselines and total-cost measurement take effort.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** Comparative results do not establish universal ranking.

[AOSE-S033; AOSE-S055; AOSE-S047; AOSE-S048]

#### REL-006 — CONSTRAINS

**Endpoints —** EAOSE-013, EAOSE-014, EAOSE-016 → EAOSE-015

**Guard —** Binding roles to concrete participants.

**Mechanism —** Require responsibility coverage, permissions and collective constraints under the chosen multiplicity; role membership alone is insufficient.

**Shared assumptions —** Responsibilities and relevant capacity are explicit.

**Incompatible assumptions —** One role is necessarily one process; membership implies collective achievement.

**New cost or failure —** Multiplicity analysis and conflict resolution can be expensive.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** No general solver or complete capability oracle is supplied.

[AOSE-S001; AOSE-S009; AOSE-S016]

#### REL-007 — ENABLES

**Endpoints —** EAOSE-015, EAOSE-017, EAOSE-023, EAOSE-025 → EAOSE-076

**Guard —** Role holders change while public obligations or interactions remain live.

**Mechanism —** Combine successor capacity and authority with the predecessor obligation state; accept only a valid continuation, discharge or explicit non-transfer.

**Shared assumptions —** The relevant obligation state can be reconstructed sufficiently for the claim.

**Incompatible assumptions —** A new valid assignment erases earlier commitments.

**New cost or failure —** Draining, consent, compensation and blocked reassignment are possible costs.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** Partial observation and non-transferable duties may prevent a successful transition.

[AOSE-S009; AOSE-S016; AOSE-S021; AOSE-S037; AOSE-S045]

#### REL-008 — CONSTRAINS

**Endpoints —** EAOSE-076 → EAOSE-017, EAOSE-058

**Guard —** Adaptive reassignment or agent retirement.

**Mechanism —** Keep, validly transfer, release, compensate or report inability for outstanding obligations before presenting the new assignment or retirement as complete.

**Shared assumptions —** The institution defines permitted obligation transitions.

**Incompatible assumptions —** Capability reassignment alone establishes obligation transfer.

**New cost or failure —** Continuity may force a slower or static configuration.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** Compensation cannot necessarily undo irreversible effects.

[AOSE-S009; AOSE-S016; AOSE-S045]

#### REL-009 — ENABLES

**Endpoints —** EAOSE-020, EAOSE-021 → EAOSE-022, EAOSE-032

**Guard —** Generating or checking local interaction implementations.

**Mechanism —** Supply source meaning and information assumptions before making a preservation claim.

**Shared assumptions —** Source and target semantics are explicit.

**Incompatible assumptions —** Matching syntax establishes message meaning.

**New cost or failure —** Formalisation and adapter maintenance.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** Properties outside the chosen semantics remain unproved.

[AOSE-S020; AOSE-S036; AOSE-S037; AOSE-S043]

#### REL-010 — ALTERNATIVE_TO

**Endpoints —** EAOSE-023 → EAOSE-024

**Guard —** Independent participants need public compliance criteria.

**Mechanism —** Use public commitments rather than private mental-state attribution at the interaction boundary; internal BDI need not be removed.

**Shared assumptions —** An agreed public meaning and observation relation exist.

**Incompatible assumptions —** Hidden private beliefs are directly enforceable facts for arbitrary participants.

**New cost or failure —** Institutional and observation disputes remain.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** Neither representation guarantees compliant actors.

[AOSE-S021; AOSE-S037; AOSE-S045]

#### REL-011 — ENABLES

**Endpoints —** EAOSE-024 → EAOSE-028, EAOSE-030

**Guard —** Cooperative or controlled internal reasoning is being engineered.

**Mechanism —** Mental-state semantics can support internal deliberation without serving as the public evidence of compliance.

**Shared assumptions —** The implemented reasoning semantics matches the model.

**Incompatible assumptions —** Criticism of open mental-state compliance invalidates all BDI internals.

**New cost or failure —** Maintaining different internal and public views can introduce translation errors.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** Open participants may not share the same internal architecture.

[AOSE-S012; AOSE-S021; AOSE-S033]

#### REL-012 — PROVIDES_EVIDENCE_FOR

**Endpoints —** EAOSE-028, EAOSE-029, EAOSE-030, EAOSE-031, EAOSE-033 → EAOSE-044

**Guard —** An agent-level or collective correctness claim.

**Mechanism —** Provide internal behaviour and boundary evidence, then separately check the collective interaction rather than infer it by conjunction.

**Shared assumptions —** The checked configurations are those deployed or explicitly related.

**Incompatible assumptions —** All individually correct agents imply a correct MAS.

**New cost or failure —** Interleavings and environmental behaviour enlarge the assurance burden.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** Emergent outcomes and omitted disturbances remain bounded by the test/model scope.

[AOSE-S007; AOSE-S023; AOSE-S024; AOSE-S030; AOSE-S031]

#### REL-013 — CONSTRAINS

**Endpoints —** EAOSE-032 → EAOSE-035

**Guard —** A generation claim is presented as end-to-end correctness.

**Mechanism —** Narrow the claim to the proven preservation and explicit manual/environmental obligations.

**Shared assumptions —** The transformation’s stated preconditions hold.

**Incompatible assumptions —** Compilation success implies stakeholder success.

**New cost or failure —** Narrow assurance can disappoint expectations of automation.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** No additional guarantee follows merely from generation coverage.

[AOSE-S036; AOSE-S037; AOSE-S054]

#### REL-014 — FEEDBACK_TO

**Endpoints —** EAOSE-034, EAOSE-047, EAOSE-048 → EAOSE-038

**Guard —** A design inconsistency or false-success case is found.

**Mechanism —** Follow the counterexample through existing links to the requirement or model needing correction.

**Shared assumptions —** Links preserve semantic relevance, not just file identity.

**Incompatible assumptions —** A feedback diagram alone causes a decision to change.

**New cost or failure —** Stale links and noisy defect reports waste effort.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** The human or automated consumer must actually resolve the contradiction.

[AOSE-S031; AOSE-S054; AOSE-S059]

#### REL-015 — CONSTRAINS

**Endpoints —** EAOSE-036, EAOSE-037, EAOSE-039 → EAOSE-080

**Guard —** Compatible fragments are claimed to ensure a successful system.

**Mechanism —** Require separate feasibility, behavioural and cost evidence; method-level type compatibility cannot supply it.

**Shared assumptions —** Fragment inputs/outputs are meaningfully described.

**Incompatible assumptions —** A well-formed method entails jointly achievable goals.

**New cost or failure —** Additional system-level checks remain necessary.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** There may be no feasible design satisfying all selected constraints.

[AOSE-S003; AOSE-S009; AOSE-S046]

#### REL-016 — SUPERSEDES

**Endpoints —** EAOSE-039 → EAOSE-075, EAOSE-042, EAOSE-064

**Guard —** A separate retirement control or branded observance is proposed.

**Mechanism —** Use the same live-risk, consumer and dependency judgement for selection, simplification and retirement; do not duplicate the method burden.

**Shared assumptions —** Relied-on functions can be identified.

**Incompatible assumptions —** Infrequent use proves a preventive control useless.

**New cost or failure —** Simplification can remove latent protection.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** A later target must supply evidence for the particular omission.

[AOSE-S003; AOSE-S008; AOSE-S017; AOSE-S046]

#### REL-017 — ENABLES

**Endpoints —** EAOSE-054, EAOSE-056 → EAOSE-057

**Guard —** Code, model, goal, prompt, provider or protocol changes.

**Mechanism —** Identify the changed configuration and authority boundary so affected assurance can be retained, narrowed, reassessed or withdrawn.

**Shared assumptions —** The claim’s dependencies are known sufficiently for selective retention.

**Incompatible assumptions —** All old evidence remains valid after arbitrary change.

**New cost or failure —** Incomplete dependency knowledge can require broader retesting.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** Opaque remote updates may force residual uncertainty or restricted use.

[AOSE-S029; AOSE-S031; AOSE-S035; AOSE-S057]

#### REL-018 — SUPERSEDES

**Endpoints —** EAOSE-057 → EAOSE-074

**Guard —** Evidence continuity is nominated as a new composition property.

**Mechanism —** Keep its operative retain/narrow/reassess/withdraw function inside selective revalidation and preserve this duplicate ID only for ancestry.

**Shared assumptions —** Same trigger and intervention as the existing mechanism.

**Incompatible assumptions —** New name entails a new independent obligation.

**New cost or failure —** No extra control is justified by the duplicate.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** A future genuinely distinct mechanism would require a new adjudicated candidate.

[AOSE-S029; AOSE-S031; AOSE-S054]

#### REL-019 — FEEDBACK_TO

**Endpoints —** EAOSE-051, EAOSE-055, EAOSE-071 → EAOSE-057, EAOSE-006

**Guard —** Operational observations contradict requirements or prior assumptions.

**Mechanism —** Use correlated evidence to reopen affected claims and, when necessary, the requirement interpretation.

**Shared assumptions —** Observed traces can be related to a configuration and consequence.

**Incompatible assumptions —** Instrumentation sees every cause or all possible behaviours.

**New cost or failure —** Privacy, storage, missing spans and perturbation overhead.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** Correlation alone does not settle causal attribution.

[AOSE-S029; AOSE-S031; AOSE-S035; AOSE-S050]

#### REL-020 — CONSTRAINS

**Endpoints —** EAOSE-056, EAOSE-057 → EAOSE-082

**Guard —** An adaptive loop claims automatic improvement.

**Mechanism —** Assess the successor against an authorised comparison and predecessor obligations, not only its own revised success condition.

**Shared assumptions —** Acceptance changes are distinguishable from implementation changes.

**Incompatible assumptions —** Self-selected score improvement is sufficient external benefit.

**New cost or failure —** Review can slow adaptation.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** No general convergence or economic improvement theorem is established.

[AOSE-S029; AOSE-S048; AOSE-S057]

#### REL-021 — CONSTRAINS

**Endpoints —** EAOSE-060, EAOSE-061 → EAOSE-062, EAOSE-063

**Guard —** A whole-method superiority or maturity claim is made.

**Mechanism —** Require the right intervention, independent units, comparator and measures; retain unresolved status where the corpus cannot identify causal benefit.

**Shared assumptions —** Reported study details are not replaced by guessed denominators.

**Incompatible assumptions —** Number of papers, users or applications equals effect size.

**New cost or failure —** Evidence collection may be expensive or incomplete.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** Whole-method superiority remains explicitly unresolved.

[AOSE-S002; AOSE-S025; AOSE-S026; AOSE-S042; AOSE-S045]

#### REL-022 — CONSTRAINS

**Endpoints —** EAOSE-065 → EAOSE-067, EAOSE-068, EAOSE-070

**Guard —** A modern framework claims classical guarantees or inheritance.

**Mechanism —** Trace the documented connection and re-establish stochastic, authority and change assumptions instead of inheriting them by branding.

**Shared assumptions —** Historical relationship and operative transfer are separately assessed.

**Incompatible assumptions —** All LLM agents are direct AOSE descendants.

**New cost or failure —** Tracing and revalidation cost.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** No complete ancestry census of modern frameworks is claimed.

[AOSE-S035; AOSE-S052; AOSE-S053; AOSE-S056; AOSE-S057]

#### REL-023 — CONSTRAINS

**Endpoints —** EAOSE-067, EAOSE-070, EAOSE-030 → EAOSE-083

**Guard —** Generated plans return after a non-blocking wait.

**Mechanism —** Recheck admissibility and current context before resuming; responsiveness alone cannot legitimise a stale plan.

**Shared assumptions —** The runtime exposes wait/resume and current-context semantics.

**Incompatible assumptions —** A plan valid at request time remains valid indefinitely.

**New cost or failure —** Cancellation and resumption complexity.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** Hard deadlines, fairness and resource limits require application evidence.

[AOSE-S056; AOSE-S035]

#### REL-024 — ENABLES

**Endpoints —** EAOSE-083 → EAOSE-031, EAOSE-025

**Guard —** A slow plan-generation request coexists with other obligations.

**Mechanism —** Suspend only the waiting intention where supported, leaving unrelated event handling and failure paths available.

**Shared assumptions —** The scheduler can isolate the wait.

**Incompatible assumptions —** Whole-loop blocking is harmless despite response obligations.

**New cost or failure —** More concurrency can introduce interference and late effects.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** No unconditional real-time guarantee follows.

[AOSE-S056]

#### REL-025 — REFINES

**Endpoints —** EAOSE-077 → EAOSE-015, EAOSE-016

**Guard —** Nearly decomposable structure justifies nested organisations.

**Mechanism —** Carry responsibility and interaction constraints across explicit hierarchy boundaries.

**Shared assumptions —** Cross-level semantics are defined.

**Incompatible assumptions —** Every system is nearly decomposable or benefits from hierarchy.

**New cost or failure —** Layering and cross-cutting coordination burden.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** Dense dependencies may favour a flat design.

[AOSE-S022]

#### REL-026 — ALTERNATIVE_TO

**Endpoints —** EAOSE-078 → EAOSE-017

**Guard —** Global function is not prescribed in the same way as known-goal capability allocation.

**Mechanism —** Select cooperative-emergence or organisation-allocation assumptions explicitly; do not pretend they solve the same problem under identical premises.

**Shared assumptions —** The chosen branch’s function and cooperation assumptions are credible.

**Incompatible assumptions —** Strategic conflict can be treated as guaranteed cooperative self-repair.

**New cost or failure —** External adequacy is harder to judge when outcomes emerge.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** ADELFE-style local cooperation is not a universal global correctness guarantee.

[AOSE-S016; AOSE-S040]

#### REL-027 — ENABLES

**Endpoints —** EAOSE-079 → EAOSE-028, EAOSE-040

**Guard —** Knowledge-intensive task/inference structure warrants separate views.

**Mechanism —** Use explicit knowledge and task models to guide capabilities and context-checked reuse.

**Shared assumptions —** Domain knowledge is validated independently of the model labels.

**Incompatible assumptions —** Task naming establishes the truth of expertise.

**New cost or failure —** Knowledge acquisition and model maintenance.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** For a simple algorithm, direct coding may dominate.

[AOSE-S041; AOSE-S018]

#### REL-028 — SUPERSEDES

**Endpoints —** EAOSE-034, EAOSE-038, EAOSE-073 → EAOSE-081

**Guard —** Counterexample propagation is offered as an additional control.

**Mechanism —** Retain the existing semantic feedback routes without double-counting a renamed operation.

**Shared assumptions —** The same counterexample reaches an actual decision consumer.

**Incompatible assumptions —** New feedback artefact is necessary just because feedback is important.

**New cost or failure —** None beyond keeping the original routes usable.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** A dormant link still needs correction; duplicate status is not permission to omit feedback.

[AOSE-S004; AOSE-S031; AOSE-S054]

#### REL-029 — SUPERSEDES

**Endpoints —** EAOSE-016, EAOSE-017 → EAOSE-019

**Guard —** The design is open or dynamically reorganising.

**Mechanism —** Replace the universal static premise with a guarded organisation model, without rejecting static cooperative configurations in their proper scope.

**Shared assumptions —** Openness and adaptation requirements have been established.

**Incompatible assumptions —** Original Gaia already guarantees arbitrary open-system adaptation.

**New cost or failure —** Richer models and monitoring introduce cost.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** The broad open-system guarantee remains unwarranted.

[AOSE-S001; AOSE-S009; AOSE-S014; AOSE-S016]

#### REL-030 — CONSTRAINS

**Endpoints —** EAOSE-008, EAOSE-009, EAOSE-011 → EAOSE-012

**Guard —** Every active component is nominated as an agent.

**Mechanism —** Demand semantic leverage and a fair simpler alternative before accepting the classification as an engineering choice.

**Shared assumptions —** The task can be compared without changing requirements.

**Incompatible assumptions —** Activity alone makes agency the best abstraction.

**New cost or failure —** Some abstraction judgements remain expert and qualitative.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** No universal ranking is produced.

[AOSE-S033; AOSE-S055]

#### REL-031 — CONSTRAINS

**Endpoints —** EAOSE-001, EAOSE-002, EAOSE-043 → EAOSE-007

**Guard —** Model completion is offered as complete requirements validation.

**Mechanism —** Use independent affected-actor and acceptance challenges rather than self-certification of the model boundary.

**Shared assumptions —** An independent challenge is possible.

**Incompatible assumptions —** All relevant needs must already appear in the graph.

**New cost or failure —** Participation and elicitation can remain incomplete.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** Explicit unknowns are required where coverage cannot be established.

[AOSE-S010; AOSE-S031; AOSE-S059]

#### REL-032 — CONSTRAINS

**Endpoints —** EAOSE-021, EAOSE-022, EAOSE-023 → EAOSE-027, EAOSE-072

**Guard —** A middleware badge or prompt role is offered as a complete interaction contract.

**Mechanism —** Separate structure, meaning, enforcement and realised consequences; accept only supported equivalences.

**Shared assumptions —** The claimed assurance layer is identifiable.

**Incompatible assumptions —** Language fluency or conformant fields enforce collective obligations.

**New cost or failure —** Additional integration and boundary tests.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** No full guarantee can be inferred without the missing layers.

[AOSE-S021; AOSE-S036; AOSE-S043; AOSE-S053]

#### REL-033 — CONSTRAINS

**Endpoints —** EAOSE-043, EAOSE-048, EAOSE-049, EAOSE-050 → EAOSE-052

**Guard —** All autonomous behaviours are claimed exhaustively tested.

**Mechanism —** Narrow the tested population and oracle; retain formal or sampling guarantees only within their actual assumptions.

**Shared assumptions —** A behaviour/model scope can be stated.

**Incompatible assumptions —** A demonstration covers every deployed state.

**New cost or failure —** Residual uncertainty and explicit exclusions remain.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** Unbounded learned/environmental behaviour is not covered by a finite test claim.

[AOSE-S024; AOSE-S030; AOSE-S031]

#### REL-034 — CONSTRAINS

**Endpoints —** EAOSE-053, EAOSE-054, EAOSE-055, EAOSE-056, EAOSE-057, EAOSE-058 → EAOSE-059

**Guard —** Design/implementation coverage is treated as operational lifecycle completion.

**Mechanism —** Require the actual deployment, handoff, observation and change mechanisms rather than inheriting coverage from phase labels.

**Shared assumptions —** Lifecycle responsibility boundaries are explicit.

**Incompatible assumptions —** An implementation diagram supplies a deployment process.

**New cost or failure —** Operational extensions cost work.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** This packet does not certify any particular method toolchain as complete.

[AOSE-S029; AOSE-S035; AOSE-S039]

#### REL-220 — REQUIRES

**Endpoints —** EAOSE-045, EAOSE-046 → EAOSE-029, EAOSE-032

**Guard —** A verified abstract model or decision-code result is being used to support a deployed-effect claim.

**Mechanism —** Establish the relevant model/code and observation/action correspondence before transferring that claim. A proof about deliberation alone may still stand without claiming the external effect.

**Shared assumptions —** The transferred claim identifies its model, executable subject and environmental boundary.

**Incompatible assumptions —** A model theorem by itself supplies true sensors, reliable actuation or a correct generated binding.

**New cost or failure —** Additional boundary analysis or tests; transfer may remain impossible.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** The environment relation can be incomplete or opaque; retain the narrower formal result.

[AOSE-S023; AOSE-S030; AOSE-S031]

#### REL-221 — ACTS_THROUGH

**Endpoints —** EAOSE-013, EAOSE-015, EAOSE-020 → EAOSE-028, EAOSE-029, EAOSE-033

**Guard —** A conceptual role or interaction is to be realised by an executable agent.

**Mechanism —** Responsibilities become operative through actual behaviour/plan code, resource permissions, message handling and percept/action bindings; manual completion and external effects remain distinct from the role diagram.

**Shared assumptions —** A selected runtime can realise the relevant behaviour and its external resource access.

**Incompatible assumptions —** Assigning a role name grants capability or permission.

**New cost or failure —** Binding maintenance, manual errors and platform-specific dependence.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** A conventional implementation may realise the same role; no BDI runtime is universally required.

[AOSE-S001; AOSE-S007; AOSE-S039]

#### REL-222 — CONFLICTS_WITH

**Endpoints —** EAOSE-024 → EAOSE-023

**Guard —** In an open setting, hidden private mental states are presented as sufficient publicly checkable compliance evidence.

**Mechanism —** Public-commitment compliance cannot simultaneously depend only on inaccessible internal states. Select public evidence at this boundary while allowing private BDI reasoning internally.

**Shared assumptions —** Peers require an externally assessable interpretation of fulfilment.

**Incompatible assumptions —** Private-state attribution and public evidence are treated as the same observation.

**New cost or failure —** Maintaining internal and public views can add mapping and dispute costs.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** This conflict concerns the sufficiency claim, not the compatibility of BDI internals with public protocols.

[AOSE-S021; AOSE-S037; AOSE-S045]

#### REL-223 — CONFLICTS_WITH

**Endpoints —** EAOSE-017 → EAOSE-078

**Guard —** One proposed configuration simultaneously relies on a known prescribed global function/capability allocation and on a cooperative-emergence rationale that does not supply that function in the same way.

**Mechanism —** Expose the incompatible premises and select or explicitly bridge the models; importing both labels cannot prove the unknown allocation objective available.

**Shared assumptions —** The application must state what is prescribed versus discovered through local cooperation.

**Incompatible assumptions —** An unknown global adequacy condition is silently used as a known assignment objective.

**New cost or failure —** A bridge may require a new adequacy oracle or narrower scope.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** Some mixed systems are possible; no universal incompatibility of all cooperation and allocation is asserted.

[AOSE-S016; AOSE-S040]

#### REL-224 — SHARES_ANCESTRY_WITH

**Endpoints —** EAOSE-028, EAOSE-030 → EAOSE-046

**Guard —** Combining BDI design and BDI decision-code assurance.

**Mechanism —** Record common intentional-agent models and language/runtime semantics rather than count design and verification descriptions as independent evidence for the whole method.

**Shared assumptions —** The particular design and assurance model refer to compatible BDI concepts.

**Incompatible assumptions —** Shared vocabulary alone proves semantic identity for all BDI languages.

**New cost or failure —** Semantic comparison and common-source tracking.

**Evidence status —** ANALYTICAL_COMPOSITION; component evidence does not prove the whole relation effective

**Unresolved obligation —** Different language editions and environmental abstractions can prevent direct composition.

[AOSE-S012; AOSE-S023; AOSE-S033]

### Discriminating cases

Cases labelled analytical are constructed tests of the reasoning, not observations of a deployed system. Published cases keep their original scope and evidence units.

#### AC-01 — Complete goal graph, missing affected stakeholder

**Type —** ANALYTICAL_CONFLICT

**Properties —** EAOSE-001; EAOSE-002; EAOSE-007; EAOSE-073

**Setup —** A scheduling model includes managers and agents but excludes workers whose rest constraints the schedule changes. Every declared goal has a trace and test.

**Discriminating test —** Add the affected actor’s constraint; ask whether the same output is still acceptable.

**Result of analysis —** Structural completeness over the old actor set cannot settle the new conflict. The requirement boundary, not only scheduling code, must be reopened.

**Effect on judgement —** Reject EAOSE-007; preserve a real challenge route in REL-001/004.

**Evidence boundary —** Analytical counterexample/walkthrough unless explicitly identified as a published case; not a new empirical experiment.

[Analytical judgement; no empirical source asserted]

#### AC-02 — One role, several competing executors

**Type —** ANALYTICAL_CONFLICT

**Properties —** EAOSE-013; EAOSE-015; EAOSE-016; EAOSE-017; EAOSE-076

**Setup —** Two agents independently fulfil the same purchase role and both order the last required component. Both locally satisfy their role condition.

**Discriminating test —** Check the collective one-order constraint and each incurred supplier obligation.

**Result of analysis —** Membership and local success do not establish collective fulfilment. Assignment and interaction constraints require correction; existing orders do not disappear.

**Effect on judgement —** Narrow multiplicity claims and support a separate live-obligation reconfiguration burden.

**Evidence boundary —** Analytical counterexample/walkthrough unless explicitly identified as a published case; not a new empirical experiment.

[Analytical judgement; no empirical source asserted]

#### AC-03 — Generated fields, wrong protocol meaning

**Type —** ANALYTICAL_FAILED_OBSERVATION

**Properties —** EAOSE-021; EAOSE-022; EAOSE-032; EAOSE-035

**Setup —** A generated adapter maps a completion field to a message while one peer interprets completion as shipment and the other as delivery. Compilation and schema checks pass.

**Discriminating test —** Compare the intended commitment consequent with the event each endpoint records.

**Result of analysis —** Syntax preservation leaves a semantic mismatch. Accepting the shipment message as delivery is unjustified.

**Effect on judgement —** Reject EAOSE-035; preserve explicit source/target and effect correspondence.

**Evidence boundary —** Analytical counterexample/walkthrough unless explicitly identified as a published case; not a new empirical experiment.

[Analytical judgement; no empirical source asserted]

#### AC-04 — Excellent design, ungoverned operating change

**Type —** ANALYTICAL_CHANGED_ASSUMPTION

**Properties —** EAOSE-053; EAOSE-054; EAOSE-056; EAOSE-057; EAOSE-059; EAOSE-070

**Setup —** The deployed model/provider changes without updating a previously tested configuration. Design diagrams remain correct-looking.

**Discriminating test —** Ask which acceptance and permission claims depend on the changed behaviour.

**Result of analysis —** Some evidence can remain applicable, some must narrow or be reassessed; design completion cannot settle operational adequacy.

**Effect on judgement —** Reject EAOSE-059; merge separate evidence-continuity proposal into EAOSE-057.

**Evidence boundary —** Analytical counterexample/walkthrough unless explicitly identified as a published case; not a new empirical experiment.

[Analytical judgement; no empirical source asserted]

#### AC-05 — Successful toy MAS without a comparator

**Type —** ANALYTICAL_EVIDENCE_LIMIT

**Properties —** EAOSE-011; EAOSE-060; EAOSE-061; EAOSE-062

**Setup —** A demonstration reaches its goal ten times and has polished diagrams. No conventional baseline or engineering-cost record exists.

**Discriminating test —** Distinguish observed feasibility from method-caused productivity or maintenance benefit.

**Result of analysis —** The demonstration supports its sampled behaviour only; whole-method superiority remains unresolved.

**Effect on judgement —** Do not upgrade EAOSE-062 or treat application success as a methodology trial.

**Evidence boundary —** Analytical counterexample/walkthrough unless explicitly identified as a published case; not a new empirical experiment.

[Analytical judgement; no empirical source asserted]

#### AC-06 — Conventional workflow is sufficient

**Type —** ANALYTICAL_NON_TRIGGER

**Properties —** EAOSE-008; EAOSE-009; EAOSE-011; EAOSE-012; EAOSE-039

**Setup —** A deterministic approval workflow has stable inputs, one authoritative policy and no beneficial autonomous negotiation.

**Discriminating test —** Implement the same acceptance conditions with a small workflow and compare relevant cost/failure surface.

**Result of analysis —** Agent-oriented stakeholder/role analysis may remain useful; a runtime MAS and elaborate method are not mandatory.

**Effect on judgement —** Reject universal agentisation; CFG-MIN permits conventional software.

**Evidence boundary —** Analytical counterexample/walkthrough unless explicitly identified as a published case; not a new empirical experiment.

[Analytical judgement; no empirical source asserted]

#### AC-07 — Coupled but unauthorised useful action

**Type —** ANALYTICAL_ADVERSARIAL

**Properties —** EAOSE-005; EAOSE-029; EAOSE-048; EAOSE-073

**Setup —** An agent discovers a genuinely beneficial resource change and the measured outcome improves, but the action exceeds its delegated permission.

**Discriminating test —** Hold goal relevance and benefit fixed while varying authorisation.

**Result of analysis —** The action remains unjustified by the available authority claim. Conversely, permission alone cannot prove benefit.

**Effect on judgement —** EAOSE-073 does work beyond storing three independent model fields: one view can block the consequential decision.

**Evidence boundary —** Analytical counterexample/walkthrough unless explicitly identified as a published case; not a new empirical experiment.

[Analytical judgement; no empirical source asserted]

#### AC-08 — Valid reallocation orphans a live commitment

**Type —** ANALYTICAL_CHANGED_CONFIGURATION

**Properties —** EAOSE-017; EAOSE-023; EAOSE-058; EAOSE-076

**Setup —** An organisation replaces a role holder with a capable new agent. A creditor’s live commitment remains addressed to the previous principal and a message is in flight.

**Discriminating test —** Check authority to transfer, knowledge of the commitment, local protocol state and creditor conditions.

**Result of analysis —** The new assignment can be structurally feasible yet unable to continue or transfer that commitment. Drain, release, authorised transfer or explicit inability are required alternatives.

**Effect on judgement —** Retain contextual EAOSE-076; distinguish it from ordinary method retirement and evidence revalidation.

**Evidence boundary —** Analytical counterexample/walkthrough unless explicitly identified as a published case; not a new empirical experiment.

[Analytical judgement; no empirical source asserted]

#### AC-09 — Unused model with a live rare-event consumer

**Type —** ANALYTICAL_NON_TRIGGER_FOR_RETIREMENT

**Properties —** EAOSE-039; EAOSE-057; EAOSE-075

**Setup —** A model has not been consulted recently but supplies an assumption needed for a high-consequence failover claim.

**Discriminating test —** Remove the model and ask whether a cheaper source still supports the relied-on claim.

**Result of analysis —** Usage frequency alone cannot justify retirement. Replacement is acceptable only if the protected function survives.

**Effect on judgement —** Retirement belongs in proportional tailoring, not a separate bureaucracy.

**Evidence boundary —** Analytical counterexample/walkthrough unless explicitly identified as a published case; not a new empirical experiment.

[Analytical judgement; no empirical source asserted]

#### AC-10 — Compatible fragments, impossible combined goal

**Type —** ANALYTICAL_COMPOSITION_CONFLICT

**Properties —** EAOSE-036; EAOSE-045; EAOSE-080

**Setup —** Two fragments use the same role and resource semantics, but their required allocations jointly exceed available capacity.

**Discriminating test —** Evaluate simultaneous feasibility rather than work-product type compatibility.

**Result of analysis —** A well-typed method can prescribe an infeasible system.

**Effect on judgement —** Reject EAOSE-080; do not confuse method coherence with system adequacy.

**Evidence boundary —** Analytical counterexample/walkthrough unless explicitly identified as a published case; not a new empirical experiment.

[Analytical judgement; no empirical source asserted]

#### AC-11 — Incomplete observation and self-selected success

**Type —** ANALYTICAL_FAILED_OBSERVATION

**Properties —** EAOSE-048; EAOSE-051; EAOSE-056; EAOSE-082

**Setup —** A runtime changes its evaluator to stop counting failures it cannot repair; its new score rises.

**Discriminating test —** Compare the same externally accepted outcomes under the predecessor and successor configurations.

**Result of analysis —** The local increase does not establish improvement or permission to revise the objective.

**Effect on judgement —** Reject EAOSE-082; stable comparison and authorised objective revision remain distinct.

**Evidence boundary —** Analytical counterexample/walkthrough unless explicitly identified as a published case; not a new empirical experiment.

[Analytical judgement; no empirical source asserted]

#### AC-12 — Simple authorised action with direct outcome

**Type —** ANALYTICAL_FAVOURABLE

**Properties —** EAOSE-002; EAOSE-005; EAOSE-029; EAOSE-039; EAOSE-073

**Setup —** One approved utility updates a known resource under a clear condition, with a direct post-update check and a rollback or explicit failure result.

**Discriminating test —** Ask whether the goal, permission and effect are already joined in the one decision.

**Result of analysis —** They are; no extra agent, role hierarchy or coupling document is needed.

**Effect on judgement —** CFG-MIN demonstrates a genuinely cheap adequate path rather than universal machinery growth.

**Evidence boundary —** Analytical counterexample/walkthrough unless explicitly identified as a published case; not a new empirical experiment.

[Analytical judgement; no empirical source asserted]

#### AC-13 — Late generated plan during urgent events

**Type —** ANALYTICAL_CHANGED_ASSUMPTION

**Properties —** EAOSE-030; EAOSE-031; EAOSE-067; EAOSE-083

**Setup —** A remote generation request stalls while a different intention must service an urgent event; its eventual plan assumes an obsolete resource state.

**Discriminating test —** Check independent event handling, wait cancellation and current plan applicability.

**Result of analysis —** Suspending only the waiting intention can preserve responsiveness, but a late plan still needs rejection or revalidation.

**Effect on judgement —** Keep EAOSE-083 distinct from interference analysis; no hard-real-time result is inferred.

**Evidence boundary —** Analytical counterexample/walkthrough unless explicitly identified as a published case; not a new empirical experiment.

[Analytical judgement; no empirical source asserted]

#### AC-14 — Published false-success testing case

**Type —** PUBLISHED_CASE_INTERPRETATION

**Properties —** EAOSE-002; EAOSE-030; EAOSE-043; EAOSE-048

**Setup —** The requirements-testing paper uses a mutated behaviour to expose a missing converse/success condition.

**Discriminating test —** Follow EV-07 and the paper’s example rather than treating coverage alone as adequacy.

**Result of analysis —** An executable test translation still needs an adequate acceptance condition and grounded percept mapping.

**Effect on judgement —** Supports oracle and semantic-distinction refinement; not a new empirical replication.

**Evidence boundary —** Analytical counterexample/walkthrough unless explicitly identified as a published case; not a new empirical experiment.

[AOSE-S031]

#### AC-15 — Published partial-design checker

**Type —** PUBLISHED_CASE_INTERPRETATION

**Properties —** EAOSE-022; EAOSE-032; EAOSE-047

**Setup —** A design/protocol inconsistency checker analyses partial agent designs.

**Discriminating test —** Respect its explicit partial-design qualifications and EV-06 evaluation scope.

**Result of analysis —** An inconsistency is a useful investigation lead, not automatically a deployed-code defect or a complete assurance certificate.

**Effect on judgement —** EAOSE-047 stays assumption-sensitive.

**Evidence boundary —** Analytical counterexample/walkthrough unless explicitly identified as a published case; not a new empirical experiment.

[AOSE-S054]

#### AC-16 — Open commitment with private BDI internally

**Type —** ANALYTICAL_FAVOURABLE_HYBRID

**Properties —** EAOSE-023; EAOSE-024; EAOSE-028; EAOSE-030

**Setup —** Two participants agree public commitment conditions while one uses BDI and the other an ordinary imperative implementation.

**Discriminating test —** Check the public enactment/discharge conditions without requiring identical private architectures.

**Result of analysis —** The combination is coherent when public interpretation and observation agree; internal beliefs do not become publicly proven facts.

**Effect on judgement —** Preserves an alternative/hybrid rather than forcing mental-state and social semantics into one undifferentiated model.

**Evidence boundary —** Analytical counterexample/walkthrough unless explicitly identified as a published case; not a new empirical experiment.

[Analytical judgement; no empirical source asserted]

### Revision of the method itself

Method fragments, model granularity and evidence requirements can be reconsidered when their consumers, risk or operating conditions change. That is not unlimited self-authorisation. Changing the acceptance rule is itself a consequential change; the successor rule cannot establish its own legitimacy merely by accepting itself. Bounded implementation adaptation within a delegated envelope is different from revising the goal, permission, public commitment or success criterion. The synthesis preserves uncertainty and rejected alternatives rather than erasing them when a new version appears.


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_HYBRIDISATION_AND_EXTERNAL_RELATIONS

Native and imported mechanisms remain distinguishable. Object/FUSION modelling, knowledge engineering, requirements analysis, situational method engineering, formal verification and operational software practices are documented imports or shared foundations where the primary sources say so. The composition does not claim that AOSE invented all of them. [AOSE-S001; AOSE-S013; AOSE-S017; AOSE-S018; AOSE-S029; AOSE-S041]

There are also real within-field hybrids: Agile PASSI’s changed process, ASPECS’s PASSI/RIO ancestry, protocol-to-language translations, and BDI/LLM integrations. Each changes a particular mechanism or boundary. Matching words such as role, goal, plan or agent do not establish semantic identity or historical transmission. The current corpus therefore exports source identity, abstraction level, trigger and limitation along with the mechanism. [AOSE-S008; AOSE-S022; AOSE-S036; AOSE-S052; AOSE-S056]

For later Autonomous Agents and Multi-Agent Systems reconciliation, this lane supplies engineering obligations rather than sibling conclusions. Agent-internal capabilities, public obligations, dynamic organisations and environment assumptions are documented intersections. Whether a sibling property is equivalent, complementary or incompatible remains to be tested against that independent corpus. **SIBLING_CORPORA_NOT_CONSULTED. CROSS_TRIFECTA_SYNTHESIS_NOT_PERFORMED.** No target adoption follows.


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_STRONGEST_SURVIVING_PROPERTIES

“Strong” here refers primarily to the importance of the distinction and its counterexample-resistant engineering rationale, not a measured effect size. These seven have the primary disposition STRONGLY_RETAINED; all retain triggers and evidence boundaries.

**EAOSE-002 — Separate stakeholder goals, runtime goals and acceptance conditions.** Relate but do not identify a desired stakeholder outcome, an agent goal representation and the observation used to judge achievement; expose the translation and its counterexamples. Cheaper path: One requirement with a direct test is enough where the mapping is trivial. [AOSE-S004; AOSE-S012; AOSE-S031; AOSE-S059; AOSE-S060]

**EAOSE-008 — Justify the semantic fit of agency.** Select agent abstractions when delegated control, situated choice, interaction or organisation clarifies consequential decisions; compare the actual design with objects, services, actors, workflows or a controller. Cheaper path: Retain a conventional design where it meets the same requirements with less complexity. [AOSE-S033; AOSE-S013; AOSE-S055; AOSE-S047; AOSE-S060; AOSE-S061]

**EAOSE-014 — Separate safety from progress obligations.** Distinguish forbidden states or effects from required progress, including the assumptions and deadlines under which progress is expected. Cheaper path: A direct invariant plus bounded completion test may suffice without temporal logic. [AOSE-S001; AOSE-S023; AOSE-S037]

**EAOSE-029 — Percept-to-belief and action-to-effect correspondence.** Validate the mappings from environmental observations to beliefs and from selected actions to external effects, separately from the correctness of deliberation. Cheaper path: Direct boundary tests and observable effect checks may suffice. [AOSE-S007; AOSE-S012; AOSE-S023; AOSE-S030; AOSE-S031; AOSE-S056; AOSE-S062]

**EAOSE-043 — Stakeholder validation is distinct from implementation verification.** Obtain a judgement that the specified behaviour addresses the relevant needs, in addition to checking that code conforms to the specification. Cheaper path: A direct demonstration and discussion can validate a small transparent requirement. [AOSE-S004; AOSE-S010; AOSE-S031; AOSE-S045; AOSE-S059]

**EAOSE-044 — Assure both individual behaviour and collective outcomes.** Combine component evidence with tests or analyses of interactions and shared outcomes; retain separate claims for each level. Cheaper path: For one non-interacting component, collective assurance is not a separate activity. [AOSE-S039; AOSE-S015; AOSE-S023; AOSE-S050]

**EAOSE-060 — Separate demonstrated mechanism, deployment and comparative benefit.** Classify evidence by what its unit and design establish: formal result, illustrative model, implemented prototype, operational use or controlled comparison; do not promote one category into another. Cheaper path: A short claim–evidence statement is enough for an uncontroversial local choice. [AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S045; AOSE-S046; AOSE-S061; AOSE-S062]

The broader retained core includes explicit role/interaction correspondence, manual implementation duties, method-fragment compatibility, scoped runtime evidence, selective change-impact revalidation and proportional tailoring. These do not demand maximal formality. Their concrete cost and comparative effectiveness remain separate from the claim that a particular substitution is invalid.


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_CONTEXT_SPECIFIC_PROPERTIES

### CONTEXT_DEPENDENT

**EAOSE-009 — Decouple agent-oriented analysis from runtime commitment.** Trigger: Organisational analysis is valuable but runtime autonomy is unnecessary or existing infrastructure dominates. Limit: Retain conditionally because removing an agent runtime can preserve some requirements while losing others; the translation needs evidence. Alternative: Use a conventional implementation and retain only decision-relevant analysis.

**EAOSE-023 — Public commitment semantics for open interaction.** Trigger: Independent parties need accountable interaction without access to one another’s internal beliefs. Limit: Retain public commitments where independently controlled participants need meaningful public obligations; a simple closed call may not need this machinery. Alternative: A conventional explicit service agreement may suffice; closed cooperative internals need not use commitments.

**EAOSE-028 — Select an agent-internal architecture to match the decision problem.** Trigger: An agent’s internal decision mechanism is being designed. Limit: Retain architecture choice contextually: BDI, imperative/reactive behaviour and ordinary implementation make different commitments. Alternative: A direct state machine or ordinary behaviour implementation may be sufficient.

**EAOSE-040 — Context-checked pattern reuse.** Trigger: A prior fragment appears to solve a recurring design problem. Limit: Retain reuse only with checked applicability; adaptation may cost more than direct construction. Alternative: Implement the small local behaviour directly when adaptation costs exceed reuse benefit.

**EAOSE-041 — Learnability and tool-maintenance fit.** Trigger: A method’s expressive power is being weighed against practical delivery constraints. Limit: Retain local learnability/tool-maintenance assessment, not a popularity ranking or a claim that every old tool is obsolete. Alternative: Use a smaller language subset or familiar tooling without claiming it preserves every richer semantic feature.

**EAOSE-058 — Retirement preserves or resolves outstanding obligations.** Trigger: A component, capability or protocol is withdrawn while others may still rely on it. Limit: Retain operational retirement contextually and analytically; process termination alone does not discharge ongoing duties. Alternative: Immediate removal is sufficient when there are demonstrably no live obligations or dependencies.

**EAOSE-069 — Memory and retrieved-content provenance boundaries.** Trigger: A learned agent reuses prior or externally retrieved information across tasks or sessions. Limit: Retain memory provenance contextually as a modern transfer judgement, not a directly validated universal AOSE memory architecture. Alternative: No persistent memory, or a small typed state record, may be safer and cheaper.

**EAOSE-071 — Cross-agent trace correlation for diagnosis.** Trigger: Distributed or stochastic execution obscures where a requirement was lost. Limit: Retain correlated tracing where distributed diagnosis needs it; it does not itself establish causation or justify maximal data retention. Alternative: A local error report is enough when one component and one direct effect make the failure unambiguous.

**EAOSE-076 — Obligation-preserving organisational reconfiguration.** Trigger: An adaptive organisation changes role holders while interactions or commitments remain live. Limit: Retain contextually as a new analytical composition obligation: feasible role assignment plus valid protocol components can still orphan predecessor obligations. Alternative: Drain in-flight work before reconfiguration, or retain a static assignment when continuity cannot be established.

**EAOSE-079 — Knowledge and task modelling as distinct engineering views.** Trigger: Knowledge-intensive reasoning is difficult to engineer as undifferentiated code or beliefs. Limit: Retain task/expertise views when knowledge-intensive engineering warrants their acquisition and maintenance cost. Alternative: A direct typed representation and small algorithm are enough for simple reasoning.

**EAOSE-083 — Preserve responsiveness during long-running plan generation.** Trigger: Remote or computationally slow plan generation threatens the response time of other responsibilities assigned to the same agent. Limit: Retain contextually as a newly examined native mechanism from current BDI generation work. Isolating a wait is distinct from concurrency correctness and does not guarantee deadlines. Alternative: Use a prewritten plan or synchronous execution when no concurrent response obligation exists and the delay is acceptable.

### ASSUMPTION_SENSITIVE

**EAOSE-017 — Capability-based dynamic reassignment.** Trigger: Membership, capabilities or failure conditions change during operation. Limit: Retain conditionally on capability knowledge, feasible assignments and appropriate organisational assumptions; combine with continuity when live obligations exist. Alternative: Static assignment or operator-controlled reassignment when the organisation is stable.

**EAOSE-022 — Global-to-local protocol correspondence.** Trigger: A global protocol is projected or compiled into independently executing agents. Limit: Retain a correspondence claim only under the source/target and delivery assumptions actually analysed. Alternative: Joint contract tests can be adequate for a short bounded exchange.

**EAOSE-031 — Interference among concurrent intentions.** Trigger: Plans overlap in time or manipulate shared state. Limit: Retain interference examination under stated scheduler/resource/environment models; complete interleaving coverage may be infeasible. Alternative: Serialise a small critical region when this preserves required responsiveness.

**EAOSE-032 — Semantics-aware model transformation.** Trigger: Models generate code, protocol adapters or executable plans. Limit: Retain semantics-preserving transformation only for the declared property and mapping, not all stakeholder, platform or environmental claims. Alternative: Hand implementation with focused correspondence tests is sufficient where generation has no benefit.

**EAOSE-036 — Semantic compatibility of method fragments.** Trigger: A tailored method imports guidance or artefacts from different methodologies. Limit: Retain fragment composition conditional on semantic and operational fit; compatible metamodels are necessary in some compositions but insufficient for success. Alternative: Use one coherent lightweight method where its scope suffices.

**EAOSE-045 — Explicit model and environment assumptions for formal assurance.** Trigger: A proof or model-checking result supports acceptance. Limit: Retain formal guarantees with model, assumptions and abstraction relation explicit; proofs remain valuable without being inflated into field validation. Alternative: Use bounded tests instead when formalisation costs exceed its decision value, while retaining uncertainty.

**EAOSE-047 — Design-to-protocol consistency checks.** Trigger: Agent design and interaction specification are maintained as separate views. Limit: Retain partial-design consistency analysis as conditional defect location; the inspected checker explicitly prevents an unconditional sound/complete interpretation. Alternative: A few explicit cross-view scenario checks can be adequate for a small design.

**EAOSE-049 — Simulation-to-deployment validity.** Trigger: Simulation evidence is used for an operational decision. Limit: Retain simulation only with a declared transfer argument; reproducing a model’s behaviour does not establish that model’s environmental assumptions. Alternative: A small direct field test or conservative restriction can suffice when representative simulation is unavailable.

**EAOSE-067 — Generated plans remain subject to executable constraints.** Trigger: A planner or learned model generates or revises executable behaviour. Limit: Retain generated-plan constraints under language, capability and context assumptions; syntax and model grading are insufficient by themselves. Alternative: Keep a verified finite plan library or require manual selection when generation offers no justified benefit.

### DOMAIN_SPECIFIC

**EAOSE-046 — Implementation-level decision-code verification.** Trigger: Consequential agent decision code has suitable semantics and tractable state space. Limit: Retain decision-program verification as a domain-specific assurance technique, not a universal economical prerequisite or a complete environment proof. Alternative: Review, testing and restricted behaviour can be more proportionate for low-risk or unsupported implementations.

**EAOSE-077 — Hierarchical organisational decomposition.** Trigger: A system’s structure and coordination genuinely benefit from hierarchical or holonic decomposition. Limit: Retain hierarchy/holonic decomposition only in its structural domain; flat or cross-cutting systems may not benefit. Alternative: A flat organisation is sufficient when nesting adds no explanatory or operational value.

**EAOSE-078 — Cooperation-driven self-organisation.** Trigger: The application genuinely needs emergence under poorly specified, changing interactions and meets the cooperative branch assumptions. Limit: Retain cooperative self-organisation only under its AMAS-style premises and external adequacy test; not as guaranteed emergence of any desired global function. Alternative: Use known-goal organisation or a central algorithm when the function is already sufficiently specified.

### USEFUL_BUT_EASILY_GAMED

**EAOSE-004 — Explicit goal conflict and alternative rationale.** Trigger: Different stakeholders or feasible designs favour incompatible outcomes. Limit: Retain contribution/conflict analysis but mark it gameable because qualitative judgements can encode preferences without validating them. Alternative: Document the concrete choice and decisive evidence without elaborate softgoal scoring when it is clear.

**EAOSE-048 — Oracle adequacy and false-success tests.** Trigger: Autonomous or stochastic behaviour lacks one obvious expected trace. Limit: Retain oracle examination but mark it gameable: a score can be optimised while its intended external meaning is lost. Alternative: A simple exact assertion is sufficient for deterministic, fully specified output.

### USEFUL_BUT_EASILY_BUREAUCRATISED

**EAOSE-034 — Bidirectional design–implementation traceability.** Trigger: Several representations or teams can drift apart during development or change. Limit: Retain consumer-linked bidirectional traceability but flag bureaucratisation: link completeness without maintained meaning has little assurance value. Alternative: Stable names, tests and a few explicit links may suffice instead of a trace repository.

### CONTESTED

**EAOSE-024 — Private mental states as the basis of communication compliance.** Trigger: The claimed meaning of a message depends on beliefs or intentions attributed to its sender. Limit: Preserve the contest between private mental-state and public social accounts at the correct boundary. Open compliance is the objection, not internal BDI reasoning itself. Alternative: Use public commitments or operational interface conditions for heterogeneous open participants.


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_REJECTED_OR_SUPERSEDED_PRACTICES

**EAOSE-007 — A complete goal diagram proves complete requirements (REJECTED_OR_DISFAVOURED).** Reject the universal inference through the missing-actor counterexample; no allegation is made that all goal-method authors assert it. 

**EAOSE-012 — Every active component should be an agent (REJECTED_OR_DISFAVOURED).** Reject activity alone as a universal reason for agentisation; preserve cases in which autonomous choice genuinely matters. 

**EAOSE-019 — Static cooperative organisation as a universal premise (SUPERSEDED_BY_STRONGER_FORM).** Supersede the universal static premise with guarded models; a stable cooperative implementation remains valid within its declared scope. Supersede the universal static premise with guarded models; a stable cooperative implementation remains valid within its declared scope.

**EAOSE-027 — FIPA message compliance guarantees full interoperability (REJECTED_OR_DISFAVOURED).** Reject full interoperability from message structure; the standard’s own limitations and public-meaning distinctions support the narrower judgement. 

**EAOSE-035 — Generated syntax establishes behavioural correctness (REJECTED_OR_DISFAVOURED).** Reject syntax as behavioural assurance, while preserving actual bounded transformation results. 

**EAOSE-042 — Method quality equals named-phase or diagram count (CEREMONY_NOT_GENERAL_PROPERTY).** Classify phase/diagram counting as ceremony when treated as a general quality property; the artefacts may still perform useful work. 

**EAOSE-052 — Exhaustive testing guarantees unrestricted autonomous behaviour (REJECTED_OR_DISFAVOURED).** Reject unrestricted exhaustive-testing claims, not finite exhaustive checks or bounded model checking within actual assumptions. 

**EAOSE-059 — Design-method support implies a complete operational lifecycle (REJECTED_OR_DISFAVOURED).** Reject the inference from good design or code to a completed operational lifecycle. 

**EAOSE-063 — Popularity, venue participation or framework maturity proves benefit (NO_GENERAL_PROPERTY).** Reject a general benefit property from popularity/maturity labels while preserving descriptive adoption information. 

**EAOSE-064 — Named-method observance as assurance (CEREMONY_NOT_GENERAL_PROPERTY).** Classify method observance itself as ceremony, not a benefit-producing invariant. Keep whatever evidence/coordination function the observance actually serves. 

**EAOSE-072 — A role prompt is a formal role contract (REJECTED_OR_DISFAVOURED).** Reject equivalence between a role prompt and a formally interpreted/enforced role contract; do not deny the prompt’s narrower behavioural usefulness. 

**EAOSE-074 — Evidence continuity through change as a separate new property (DUPLICATE_CANDIDATE).** Keep the ancestry proposal as a duplicate of EAOSE-057. No additional trigger, operation or independent consumer was found beyond selective revalidation. Keep the ancestry proposal as a duplicate of EAOSE-057. No additional trigger, operation or independent consumer was found beyond selective revalidation.

**EAOSE-075 — Purposeful retirement of method machinery as a separate new property (DUPLICATE_CANDIDATE).** Keep the ancestry proposal as a duplicate of EAOSE-039. Method retirement is one outcome of tailoring; operational agent retirement remains separate. Keep the ancestry proposal as a duplicate of EAOSE-039. Method retirement is one outcome of tailoring; operational agent retirement remains separate.

**EAOSE-080 — A consistent fragment composition guarantees achievable goals (REJECTED_OR_DISFAVOURED).** Reject joint success from consistent fragment composition. The capacity counterexample separates semantic compatibility from feasibility. 

**EAOSE-081 — Counterexample propagation as a distinct new control (DUPLICATE_CANDIDATE).** Keep as a duplicate of existing traceability, iterative feedback and coupled-decision mechanisms, not another office or artefact. Keep as a duplicate of existing traceability, iterative feedback and coupled-decision mechanisms, not another office or artefact.

**EAOSE-082 — Observation plus self-revision guarantees improvement (REJECTED_OR_DISFAVOURED).** Reject automatic improvement from observation plus self-revision; the changed-score counterexample defeats the universal inference. 

Rejected generalisations are not attributed indiscriminately to all historical authors. Superseding a universal static-organisation assumption does not prohibit a suitable static design. Rejecting ceremony does not destroy useful documents, meetings or formal models. Duplicate candidate IDs preserve the research denominator while preventing multiple purported controls from being imposed for one mechanism.


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_CURRENT_STATE_AND_RESEARCH_FRONTIER

Current-year coverage includes the active EMAS research setting, bounded roadmap material, BDI/LLM integrations, plan generation and self-evolution, failure/observability work, security evaluation and a preliminary null reuse result. Their dates, versions and access levels are explicit in the source table. Activity does not establish consensus, deployed maturity or net benefit. [AOSE-S005; AOSE-S035; AOSE-S051; AOSE-S057; AOSE-S062]

The important changed engineering boundary is not merely that language is now natural-language. Components can be learned, stochastic, opaque, remotely updated and exposed to untrusted tool content. Consequently the relevant engineering question is what remains fixed, observable, enforceable and comparable when a generated plan, memory item or external response changes. The corpus retains guarded generation, capability/authority separation, configuration-sensitive evaluation, source-sensitive memory and late-result handling. None is represented as a universally solved guarantee. [AOSE-S048; AOSE-S050; AOSE-S052; AOSE-S053; AOSE-S056]

The evidence units below centralise study denominators and validity threats. They are not pooled into a single effect estimate: their units, interventions, settings and comparison questions are materially different.

### Formal result and transfer register

These records state the model, guarantee, assumptions and implementation obligations separately. Formal results are not pooled into a combined theorem.

#### FR-01

**Sources —** AOSE-S037

**Properties —** EAOSE-022; EAOSE-023; EAOSE-032; EAOSE-045

**Model —** Clouseau events, commitments, capabilities and completion conditions mapped to asynchronous BSPL message histories.

**Guarantee or analysis —** Theorem 1 establishes the specified run/history correspondence. Theorems 2 and 3 give safety and liveness for a consistent specification.

**Assumptions —** Use the paper’s event, information-determinacy, consistency and completion semantics; global observations and asynchronous histories are related by the defined yield relation.

**Implementation obligation —** Real messages and domain events must instantiate the specified semantics; physical effects and independently chosen compliance need additional evidence.

**Excluded inference —** No forced cooperation, physical delivery guarantee or wall-clock deadline follows from model liveness.

**Locator —** §§3–6; definitions 19–21; theorems 1–3; §7

#### FR-02

**Sources —** AOSE-S023

**Properties —** EAOSE-029; EAOSE-045; EAOSE-046

**Model —** Executable rational decision logic checked through the agent verification architecture, with separate environment/continuous-control abstractions.

**Guarantee or analysis —** A property of the checked decision component is assessed over the explored formal/executable state model.

**Assumptions —** The interpreter/model correspondence, property specification and selected environmental possibilities must hold; state-space bounds matter.

**Implementation obligation —** Establish the actual deployed version and the abstraction relation to sensors, actions and lower-level controllers.

**Excluded inference —** Decision-code verification does not prove sensor correctness, unknown physical dynamics or an unmodelled implementation boundary.

**Locator —** Verification architecture; examples and concluding limitations

#### FR-03

**Sources —** AOSE-S030

**Properties —** EAOSE-029; EAOSE-031; EAOSE-045; EAOSE-049

**Model —** Environment-enabled CAN with finite nondeterministic environmental states/dynamics, bigraph execution and PRISM-compatible temporal properties.

**Guarantee or analysis —** Explores behaviour over the specified finite environment model rather than a few selected simulations.

**Assumptions —** Symbolic environment alphabet and consistent states; cycle-level dynamics; full perception of the current model state. Footnote 4 explicitly excludes partial observability.

**Implementation obligation —** Justify the real-to-symbolic sensor mapping and cycle abstraction. Actions change the modelled environment, with belief updates through subsequent perception.

**Excluded inference —** The paper’s all-environments wording is relative to this model; it is not every possible physical environment, partial observation or real-time schedule.

**Locator —** Masthead; §§III–IV; footnote 4; §V UAV illustration

#### FR-04

**Sources —** AOSE-S024

**Properties —** EAOSE-031; EAOSE-044; EAOSE-048; EAOSE-052

**Model —** Trace-counting analysis of bounded goal-plan structures with plan failure and alternative handling.

**Guarantee or analysis —** Shows that these structures can yield execution-path populations too large for routine exhaustive testing.

**Assumptions —** The selected goal/plan shape, branching and failure assumptions determine the count.

**Implementation obligation —** Identify whether the actual program fits that model and whether abstraction or property-specific reduction changes the test obligation.

**Excluded inference —** No universal impossibility of useful testing or every finite exhaustive check; an extended abstract is not an independent replication of the full result.

**Locator —** Trace-counting model and discussion

#### FR-05

**Sources —** AOSE-S049

**Properties —** EAOSE-030; EAOSE-032; EAOSE-045; EAOSE-067

**Model —** Concurrent game models, including incomplete-information equivalence classes, with ATL coalition strategy conditions used for BDI plan generation.

**Guarantee or analysis —** Supplies a formal route from modelled strategic ability to plan construction under the selected semantics.

**Assumptions —** Action availability, transition function, observations/indistinguishability and coalition strategy semantics must match the problem.

**Implementation obligation —** A generated plan must be realised in the selected BDI language and its abstract actions related to the environment.

**Excluded inference —** This is not an LLM-generation experiment and does not establish true action models or unbounded real-world success.

**Locator —** §2 definitions 1–4; strategy and plan-generation construction

#### FR-06

**Sources —** AOSE-S054

**Properties —** EAOSE-020; EAOSE-032; EAOSE-047

**Model —** Partial Prometheus design and AUML protocol views transformed into Petri-net trace representations.

**Guarantee or analysis —** Detects specified design/protocol inconsistencies and supplies trace-based diagnostic information.

**Assumptions —** The design/protocol views and transformation scope are partial; missing detail affects interpretation of apparent inconsistencies.

**Implementation obligation —** Complete/refine relevant views and separately check actual code/message realisation.

**Excluded inference —** The source does not support unconditional soundness/completeness or deployed-code correctness.

**Locator —** §§3.2–3.4; §4; Table 1

### EV-01 — Method exercise and questionnaire

**Setting —** Student summer project and methodology-designer responses

**Sample / denominator —** Five methods selected; published comparison focuses on three. Twelve of sixteen invited designer responses.

**Comparison —** MaSE, Prometheus and Tropos in the reported comparison

**Measures —** Usability/guidance and coverage judgements

**Outcome —** Comparative differences and author/student disagreement; authors do not present a statistically significant experiment.

**Uncertainty and validity threats —** Small selected sample, participant expertise and author involvement in Prometheus.

**Evidence role —** EMPIRICAL_COMPARISON

**Shared origin —** DAM_WINIKOFF_SUMMER_2002_2003

**Replication —** No independent replication inferred from multiple descriptions.

[AOSE-S002]

### EV-02 — Agile PASSI demonstrator

**Setting —** Robotics prototype

**Sample / denominator —** Seven agents on three LAN-connected machines; roughly 5,000 lines; reported 45–50% reuse.

**Comparison —** No controlled original-PASSI versus Agile-PASSI productivity experiment

**Measures —** Generated/reused implementation and process feasibility

**Outcome —** Illustrates a lighter assembled process with manual completion.

**Uncertainty and validity threats —** Reuse proportion is not causal effort savings; prototype is not long-term deployment evidence.

**Evidence role —** FIELD_OR_DEPLOYMENT_EVIDENCE

**Shared origin —** AGILE_PASSI_ROBOTICS

**Replication —** No independent replication inferred from multiple descriptions.

[AOSE-S008]

### EV-03 — Vendor-authored industrial programme

**Setting —** Bundled agent platform and conventional enterprise practices

**Sample / denominator —** Fifteen reported applications: thirteen production, two pending; six logistics projects support one productivity calculation.

**Comparison —** Historical function-point baselines, not randomised comparable projects

**Measures —** Reported output per person-day and reuse-related measures

**Outcome —** Supports industrial feasibility and favourable local reports. The body/abstract use differing percentage summaries; no single blended effect is endorsed.

**Uncertainty and validity threats —** Vendor authorship, team/tool/process confounding, baseline selection and modified process combinations preclude whole-method attribution.

**Evidence role —** FIELD_OR_DEPLOYMENT_EVIDENCE

**Shared origin —** BENFIELD_AGENTIS_PROGRAMME

**Replication —** No independent replication inferred from multiple descriptions.

[AOSE-S026]

### EV-04 — Application survey

**Setting —** 2012 solicitation plus AAMAS application-paper collection

**Sample / denominator —** 103 nominations + 99 papers; 152 distinct applications; 89 fact sheets; 46 classified operational.

**Comparison —** No non-agent application population comparator

**Measures —** Application category and reported maturity

**Outcome —** Documents a nonzero and diverse application base, not universal or representative method adoption.

**Uncertainty and validity threats —** Self-selection, incomplete responses, repeated case literature, missing comparable cost and application/method unit mismatch.

**Evidence role —** FIELD_OR_DEPLOYMENT_EVIDENCE

**Shared origin —** MULLER_FISCHER_SURVEY_2012

**Replication —** No independent replication inferred from multiple descriptions.

[AOSE-S042]

### EV-05 — Controlled modelling exercise

**Setting —** Healthcare-process modelling by computer-science graduate students

**Sample / denominator —** 47 participants in approximately balanced groups; two phases using supplied exemplars.

**Comparison —** Comma versus authors’ Traditional-HL7 process representation

**Measures —** Flexibility proxy, modelling errors, time and reported difficulty

**Outcome —** First-phase tests support flexibility/error differences at the stated 10% threshold, not significant time/difficulty improvement.

**Uncertainty and validity threats —** Small task, graduate rather than clinical professional sample, author exemplars/ratings, liberal threshold and proxy outcomes; no patient outcomes.

**Evidence role —** EMPIRICAL_COMPARISON

**Shared origin —** COMMA_HEALTHCARE_47

**Replication —** No independent replication inferred from multiple descriptions.

[AOSE-S045]

### EV-06 — Early-phase defect-location evaluation

**Setting —** Prometheus designs against AUML protocols

**Sample / denominator —** Three designs and two protocols

**Comparison —** Expected consistency cases, not deployed-code assurance or industrial controlled comparison

**Measures —** Detected inconsistencies and trace construction

**Outcome —** Demonstrates defect-location machinery with partial-design qualifications.

**Uncertainty and validity threats —** Partial representations can produce false positives and do not support unconditional sound-and-complete behavioural claims.

**Evidence role —** EMPIRICAL_COMPARISON

**Shared origin —** PROMETHEUS_PROTOCOL_CONSISTENCY

**Replication —** No independent replication inferred from multiple descriptions.

[AOSE-S054]

### EV-07 — Worked testing/mutation example

**Setting —** SARL behaviour-driven requirements testing

**Sample / denominator —** Illustrative implementation; no representative industrial sample claimed

**Comparison —** Original and deliberately modified code

**Measures —** Line coverage, mutation score and test strength; false-success cases

**Outcome —** Reported 87% line coverage, 92% mutation score and 95% test strength illustrate distinct measures; a converse condition can still be missing.

**Uncertainty and validity threats —** Metrics concern this example; sensor-to-belief grounding and user need validity remain external.

**Evidence role —** EMPIRICAL_COMPARISON

**Shared origin —** SARL_BDD_2023

**Replication —** No independent replication inferred from multiple descriptions.

[AOSE-S031]

### EV-08 — Failure-trace study and expanded edition

**Setting —** LLM multi-agent frameworks

**Sample / denominator —** Early expert corpus: over 150 traces, five frameworks, six experts. Expanded version: 1,642 traces across seven frameworks, with judge-assisted labelling.

**Comparison —** Framework cases and selected interventions, not whole-AOSE methods

**Measures —** Fourteen failure modes in three categories; annotation agreement and task outcomes

**Outcome —** Expert/judge agreement and targeted improvements support a useful bounded taxonomy, not universal failure rates.

**Uncertainty and validity threats —** Versions are one research programme; benchmark selection, fallible judge labels and shared tasks limit prevalence and transfer.

**Evidence role —** INCIDENT_OR_FAILURE_EVIDENCE

**Shared origin —** MAST_2025_V1_V3

**Replication —** No independent replication inferred from multiple descriptions.

[AOSE-S032; AOSE-S050]

### EV-09 — Instrumentation/fault-injection demonstration

**Setting —** LLM MAS software engineering; demo and ChatDev

**Sample / denominator —** Thirty ProgramDev tasks and five repetitions per condition in the reported validation.

**Comparison —** Configured injected faults and comparison conditions

**Measures —** Traces and observed task/failure outcomes

**Outcome —** Supports observability and selected perturbations at agent/message/tool/model boundaries.

**Uncertainty and validity threats —** Shared ProgramDev setting with related MAST work; memory perturbation and automated causal diagnosis not established.

**Evidence role —** EMPIRICAL_COMPARISON

**Shared origin —** PROGRAMDEV_CHATDEV_REUSED_SETTING

**Replication —** No independent replication inferred from multiple descriptions.

[AOSE-S035]

### EV-10 — Security/utility benchmark

**Setting —** Stateful tool-use tasks and untrusted tool outputs

**Sample / denominator —** Initial suite: 97 tasks and 629 security test cases.

**Comparison —** Specified attack/defence and model configurations

**Measures —** User-task utility and attacker success against environment state

**Outcome —** Shows bounded prompt-injection vulnerabilities and defence trade-offs.

**Uncertainty and validity threats —** Artificial suite and evolving attacks/configurations do not identify real-world failure prevalence or a universal defence.

**Evidence role —** INCIDENT_OR_FAILURE_EVIDENCE

**Shared origin —** AGENTDOJO_2024

**Replication —** No independent replication inferred from multiple descriptions.

[AOSE-S053]

### EV-11 — Hybrid plan-generation experiment

**Setting —** JaKtA grid world

**Sample / denominator —** Four models, five runs each (20 runs).

**Comparison —** Selected model configurations and generated plans

**Measures —** Syntactic correctness, semantic alignment and task success

**Outcome —** Distinguishes executable-looking plans from semantically aligned and successful ones.

**Uncertainty and validity threats —** Small artificial setting; manual semantic descriptions, model evaluation choices and no broad lifecycle or deadline validation.

**Evidence role —** EMPIRICAL_COMPARISON

**Shared origin —** GENAI_BDI_ECAI_2025

**Replication —** No independent replication inferred from multiple descriptions.

[AOSE-S056]

### EV-12 — Architecture/prototype report

**Setting —** Deliveroo.js-inspired self-evolving agent

**Sample / denominator —** Preliminary qualitative example; no complete comparative sample supplied.

**Comparison —** No robust whole-method or stable self-evolution comparator

**Measures —** Illustrative knowledge/goal/action evolution

**Outcome —** Proposes a separate evolution module and discusses inheritance/stability limitations.

**Uncertainty and validity threats —** Prototype feasibility cannot establish convergence, safe authorisation or comparative cost.

**Evidence role —** FIELD_OR_DEPLOYMENT_EVIDENCE

**Shared origin —** SELF_EVOLVING_BDI_2026

**Replication —** No independent replication inferred from multiple descriptions.

[AOSE-S057]

### EV-13 — Formal constructions and bounded tool/model demonstrations

**Setting —** Decision code, dynamic environment models, information protocols and ATL games

**Sample / denominator —** Theorems/model analyses, not a common statistical sample

**Comparison —** Specified formal semantics and property definitions

**Measures —** Conditional correctness/correspondence/safety/liveness

**Outcome —** Strongest conclusions are conditional on their respective models, encodings and grounding obligations.

**Uncertainty and validity threats —** Do not combine incompatible model guarantees; no theorem by itself establishes real-world premises or economic benefit.

**Evidence role —** FORMAL_OR_THEORETICAL_RESULT

**Shared origin —** DISTINCT_FORMAL_MODELS_NOT_REPLICATIONS

**Replication —** No independent replication inferred from multiple descriptions.

[AOSE-S023; AOSE-S030; AOSE-S037; AOSE-S049]

### EV-14 — Baseline/evaluation investigations

**Setting —** LLM-assisted software tasks

**Sample / denominator —** Version-specific benchmark experiments; not a representative AOSE lifecycle sample

**Comparison —** Simpler workflow and cost-aware alternatives

**Measures —** Task success, cost and reproducibility

**Outcome —** Makes simpler alternatives and evaluation design material to engineering judgement.

**Uncertainty and validity threats —** Software repair is not all agent engineering; cost, prompts and benchmark versions matter.

**Evidence role —** EMPIRICAL_COMPARISON

**Shared origin —** MODERN_AGENT_BASELINES

**Replication —** No independent replication inferred from multiple descriptions.

[AOSE-S047; AOSE-S048]

### EV-15 — Configured framework benchmark comparison

**Setting —** Code-centric software development, vulnerability detection and repair

**Sample / denominator —** Seven frameworks; reported benchmark sizes 1,200 SRDD tasks, 115 vulnerability instances and 300 SWE-bench Lite issues.

**Comparison —** Common DeepSeek-v3.1 backend and 100-step limit; framework-specific default tools and adapted prompts.

**Measures —** Task-specific quality, vulnerability precision-form measure, repair rate, steps, corrections, token usage and reported cost.

**Outcome —** Reports task/cost trade-offs, not a whole-method ranking. The measure called Accuracy is TP/(TP+FP), not conventional overall accuracy.

**Uncertainty and validity threats —** Preprint; configuration confounding and evaluator proxies. Benchmark membership is not a denominator of independent replications; no robust repeated-run distribution is inferred.

**Evidence role —** EMPIRICAL_COMPARISON

**Shared origin —** YIN_FRAMEWORK_COMPARISON_2025

**Replication —** No independent replication inferred from multiple descriptions.

[AOSE-S061]

### EV-16 — Preliminary BDI–LLM plan-seeding comparison

**Setting —** GAIA level-1 benchmark, Qwen3-8B via vLLM; GAIA here is not the Gaia AOSE method.

**Sample / denominator —** 53 questions. Simulation: 3 rounds with 8-way parallelism, 7/53 correct in any round. Seeded: 52 initial plans, single pass 5/53. Non-seeded: single pass 5/53.

**Comparison —** Seeded versus non-seeded single-pass configurations; multi-round simulation has a different attempt budget.

**Measures —** Raw answer accuracy and qualitative trace analysis.

**Outcome —** Same raw single-pass accuracy; authors report qualitative reasoning differences. No general equality or causal benefit is established.

**Uncertainty and validity threats —** Small technical-report evaluation, no full architectural ablation, exact-match limitations, retrieval/tool failures, and no independent replication. Proposed future policy/provenance modules were not evaluated.

**Evidence role —** EMPIRICAL_COMPARISON

**Shared origin —** LAWTON_BDI_LLM_2026

**Replication —** No independent replication inferred from multiple descriptions.

[AOSE-S062]


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_ADVERSARIAL_SYNTHESIS_VERDICT

**Verdict: a coherent conditional core survives; an unconditional winning methodology does not.** The strongest objection to unification is that the methods assume different kinds of organisation, knowledge, cooperation and control, and that their evidence does not measure one common intervention. This objection changes the synthesis: it has guarded alternatives rather than a mandatory union, explicit non-agent configurations, narrow formal guarantees and a retained unresolved whole-method benefit claim.

A second objection is cost. A cross-view relation can become a bureaucracy that delays useful low-risk action. That objection changes the minimum form: an already adequate contract, implementation and result check can supply several functions, and method machinery can be retired when its actual consumers and dependencies no longer require it. Nothing here requires a separate artefact or decision maker for every property.

A third objection is epistemic closure. A system may produce consistent beliefs, compliant messages and an internally favourable score while missing the external consequence. That objection preserves the oracle and grounding boundaries; it rejects guaranteed success from generated syntax, standard compliance, compatible fragments or self-revision. Authorised experimentation under uncertainty remains possible, but uncertainty cannot be labelled success.

A fourth objection is the supposed novelty of composition. Two inherited proposals collapse into existing revalidation and tailoring mechanisms, and another feedback candidate is a duplicate. The two surviving composition-induced properties require a relation not supplied by isolated component snapshots. This is sufficient for a distinct analytical candidate, not evidence of novel academic priority or positive deployment return.

The system has not been empirically validated as a package. Its current justification is a sourced reconstruction of component mechanisms plus explicit discriminating arguments and guarded alternatives. A future well-designed comparison can strengthen, narrow or reject parts of it. That future uncertainty does not make the present examined corpus unfinished.


## EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING_OPEN_QUESTIONS_AND_EVIDENCE_LIMITS

### Unresolved and bounded claims

**UCO-01 — EXAMINED_UNRESOLVED.** Net cost and comparative benefit of the composed configurations Required evidence: Representative, independent lifecycle comparisons with competent alternatives and measured modelling, execution, incident and maintenance costs. Related: EAOSE-011, EAOSE-062, EAOSE-073, EAOSE-076.

**UCO-02 — EXAMINED_CONTEXT_BOUNDARY.** Safe reconfiguration with partial observation, disputed meaning or non-transferable obligations Required evidence: The selected institution/implementation must establish the obligation state and permitted transfer/discharge relation, or decline the transition. Related: EAOSE-017, EAOSE-023, EAOSE-076.

**UCO-03 — EXAMINED_ASSUMPTION_LIMIT.** Grounding and assurance across opaque learned or physical boundaries Required evidence: Case-specific observation/implementation relations and uncertainty bounds; formal proofs cannot supply unknown premises. Related: EAOSE-029, EAOSE-045, EAOSE-070.

**EAOSE-062 remains UNRESOLVED.** The evidence needed is an appropriately scoped comparison of coherent methodologies or configurations, with competent alternative implementations and lifecycle costs, benefits and uncertainty. Existing positive cases, local comparisons and modern task benchmarks are preserved but do not settle that question.

**NF-01 — The inspected evidence does not settle universal whole-method superiority.** Selected method exercises, developer reports, self-selected application surveys and task benchmarks use different interventions and comparators. Not inferred: No useful AOSE mechanism exists, or no future decisive comparison is possible. [AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S045; AOSE-S047; AOSE-S061; AOSE-S062]

**NF-02 — No general deployability/maintenance guarantee follows from successful analysis and code generation.** Original method scope, manual transformation boundaries and operational extensions are distinct. Not inferred: Every original methodology wholly ignores deployment. [AOSE-S001; AOSE-S018; AOSE-S029; AOSE-S039]

**NF-03 — Neither a standard badge nor a role prompt establishes shared meaning and fulfilled obligations.** Message syntax, public semantics, actual capabilities and observed effects occupy distinct engineering boundaries. Not inferred: Standards or natural-language role descriptions have no use. [AOSE-S021; AOSE-S037; AOSE-S043; AOSE-S052]

**NF-04 — No independent field validation of this newly composed Evolved system was found or claimed.** These are current analytical constructions tested with explicit counterexamples, not pre-existing deployed methodologies. Not inferred: Logical discriminating examples measure actual cost savings. [Analytical judgement; no empirical source asserted]

**NF-05 — No representative failure-rate or active-maintenance census of named AOSE methodologies is established.** Primary failure analyses and application studies are examined, but selected sources do not yield a representative longitudinal denominator. Not inferred: No industrial failures occurred or an old publication implies a defunct platform. [AOSE-S025; AOSE-S026; AOSE-S042; AOSE-S050; AOSE-S035]

**NF-06 — The newest inspected plan-seeding comparison supplies a local null raw-accuracy result.** EV-16 records actual configurations, attempt budgets and outcome denominators. Not inferred: Statistical equivalence, no qualitative difference, or a verdict against all BDI. [AOSE-S062]

### Source-access limits

**AOSE-S014.** Publisher/author record inspected; lawful author-copy retrieval returned an access error. Bounded opening/abstract only; original Gaia and separate organisation-method primary papers supply their own narrower claims. Do not assign inaccessible methods, locators, experiment details or comparative results to this source.

**AOSE-S017.** The authorised Agent OPEN reprint is readable but its appendix is abridged for copyright reasons. The omitted detailed task definitions are not invented or claimed inspected. Do not assign inaccessible methods, locators, experiment details or comparative results to this source.

**AOSE-S019.** Publisher abstract inspected and alternate author-sharing copy checked. A title/content mismatch in that copy was excluded; the distinct full 2004 exposition is not represented as this 2003 text. Do not assign inaccessible methods, locators, experiment details or comparative results to this source.

**AOSE-S051.** Publisher abstract and public appendix inspected; a fresh lawful full-copy attempt did not expose the chapter. Workshop scenarios are not treated as real deployments. Do not assign inaccessible methods, locators, experiment details or comparative results to this source.

**AOSE-S058.** Reference-work identity and abstract inspected; full publisher text remained unavailable in the bounded attempt. Mechanisms are established from original methods, not invented from this entry. Do not assign inaccessible methods, locators, experiment details or comparative results to this source.

### Bounded completeness and freeze accounting

Revision **EAOSE-2026-09-07-R1**, cut-off **2026-09-07**: 83 candidates examined; ten of ten mandatory families examined; 62 exact-work/edition source records; 18 criticism entries; 83 ceremony entries; 18 evolution tracks; 10 internal tensions; 16 discriminating cases; 224 guarded composition relations; 7 configurations. No mandatory family or candidate is NOT_EXAMINED. Access limitations and researched uncertainty remain explicit.

The full JSON and all three intakes preserve the same IDs, primary dispositions and evidence boundaries. The manifest records exact payload bytes and hashes. Archive integrity is a separate delivery check, not proof that every academic judgement is infallible. The external delivery receipt supplies the enclosing ZIP’s hash without a circular dependency.

### Source register

Exact URLs/DOIs, inspected locators, supported IDs and access levels are in the source-table JSON. The list below is a navigation aid, not a substitute for those claim bindings.

**AOSE-S001** — Michael Wooldridge, Nicholas R. Jennings, David Kinny. *The Gaia Methodology for Agent-Oriented Analysis and Design*. 2000-09. Published work unless otherwise stated. Access: FULL_AUTHOR_COPY_AND_PUBLISHER_METADATA.

**AOSE-S002** — Khanh Hoa Dam, Michael Winikoff. *Comparing Agent-Oriented Methodologies*. 2003. Published work unless otherwise stated. Access: FULL_AUTHOR_PDF.

**AOSE-S003** — Juan C. García-Ojeda, Scott A. DeLoach. *The O-MaSE Process: a Standard View*. 2010. Published work unless otherwise stated. Access: FULL_PDF.

**AOSE-S004** — Jaelson Castro, Manuel Kolp, John Mylopoulos. *Towards requirements-driven information systems engineering: the Tropos project*. 2002. Published work unless otherwise stated. Access: FULL_AUTHOR_PDF.

**AOSE-S005** — EMAS 2026 organisers. *14th International Workshop on Engineering Multi-Agent Systems (EMAS 2026)*. 2026. Published work unless otherwise stated. Access: FULL_HTML.

**AOSE-S006** — IFAAMAS. *International Foundation for Autonomous Agents and Multiagent Systems: institutional history*. 2026 (accessed). Published work unless otherwise stated. Access: FULL_HTML.

**AOSE-S007** — Lin Padgham, Michael Winikoff. *Prometheus: A Methodology for Developing Intelligent Agents*. 2002. Published work unless otherwise stated. Access: FULL_AUTHOR_PDF.

**AOSE-S008** — Antonio Chella, Massimo Cossentino, Luca Sabatucci, Valeria Seidita. *Agile PASSI: An agile process for designing agents*. 2006-03. Published work unless otherwise stated. Access: FULL_INSTITUTIONAL_PDF.

**AOSE-S009** — Scott A. DeLoach, Juan Carlos García-Ojeda. *O-MaSE: a customisable approach to designing and building complex, adaptive multi-agent systems*. 2010-11. Published work unless otherwise stated. Access: FULL_AUTHOR_UPLOADED_TEXT.

**AOSE-S010** — Eric Yu. *Strategic Modelling for Enterprise Integration*. 1999. Exact work or author version identified in access notes. Access: FULL_AUTHOR_PDF.

**AOSE-S011** — Yoav Shoham. *Software Agents in Academia and Industry: Stanford seminar abstract*. 1995-01-13. Exact work or author version identified in access notes. Access: FULL_HTML.

**AOSE-S012** — Anand S. Rao, Michael P. Georgeff. *BDI Agents: From Theory to Practice*. 1995. Exact work or author version identified in access notes. Access: FULL_PDF.

**AOSE-S013** — Michael Wooldridge, Paolo Ciancarini. *Agent-Oriented Software Engineering: The State of the Art*. 2000 (workshop); 2001 (proceedings). Exact work or author version identified in access notes. Access: FULL_AUTHOR_PDF.

**AOSE-S014** — Franco Zambonelli, Nicholas R. Jennings, Michael Wooldridge. *Developing Multiagent Systems: The Gaia Methodology*. 2003-07. Exact work or author version identified in access notes. Access: PUBLISHER_ABSTRACT_AND_PRIMARY_TEXT_PREVIEW.

**AOSE-S015** — Scott A. DeLoach, Mark F. Wood, Clint H. Sparkman. *Multiagent Systems Engineering*. 2001. Exact work or author version identified in access notes. Access: FULL_AUTHOR_UPLOADED_TEXT.

**AOSE-S016** — Scott A. DeLoach. *Engineering Organization-Based Multiagent Systems*. 2006. Identified publication; inspected copy specified below. Access: FULL_AUTHOR_COPY.

**AOSE-S017** — Brian Henderson-Sellers. *Creating a Comprehensive Agent-Oriented Methodology – Using Method Engineering and the OPEN Metamodel*. 2005 (chapter); 2006 (authorised reprint). Exact work or author version identified in access notes. Access: AUTHORISED_REPRINT_WITH_ABRIDGED_APPENDIX.

**AOSE-S018** — Jorge J. Gómez-Sanz, Juan Pavón. *Methodologies for Developing Multi-Agent Systems*. 2004-04-28. Exact work or author version identified in access notes. Access: FULL_PDF.

**AOSE-S019** — Juan Pavón, Jorge J. Gómez-Sanz. *Agent Oriented Software Engineering with INGENIAS*. 2003. Exact work or author version identified in access notes. Access: PUBLISHER_ABSTRACT_ONLY.

**AOSE-S020** — James Odell, H. Van Dyke Parunak, Bernhard Bauer. *Representing Agent Interaction Protocols in UML*. 2000 (workshop); 2001 (proceedings). Exact work or author version identified in access notes. Access: FULL_AUTHOR_PDF.

**AOSE-S021** — Munindar P. Singh. *Agent Communication Languages: Rethinking the Principles*. 1998-12. Exact work or author version identified in access notes. Access: FULL_AUTHOR_PDF.

**AOSE-S022** — Massimo Cossentino, Nicolas Gaud, Vincent Hilaire, Stéphane Galland, Abderrafiâa Koukam. *ASPECS: an agent-oriented software process for engineering complex systems*. 2009-06-07 (online); 2010 (volume). Exact work or author version identified in access notes. Access: FULL_AUTHOR_UPLOADED_MANUSCRIPT_AND_PUBLISHER_METADATA.

**AOSE-S023** — Louise A. Dennis, Michael Fisher, Nicholas K. Lincoln, Alexei Lisitsa, Sandor M. Veres. *Practical verification of decision-making in agent-based autonomous systems*. 2014 (online); 2016 (volume). Exact work or author version identified in access notes. Access: FULL_AUTHOR_HOSTED_PUBLISHER_PDF.

**AOSE-S024** — Michael Winikoff, Stephen Cranefield. *On the Testability of BDI Agent Systems (Extended Abstract)*. 2015. Exact work or author version identified in access notes. Access: FULL_PROCEEDINGS_PDF.

**AOSE-S025** — Michael Winikoff. *Challenges and Directions for Engineering Multi-agent Systems*. 2012-08-29 (paper); 2012-09-07 (arXiv v1). Exact work or author version identified in access notes. Access: FULL_PDF.

**AOSE-S026** — Steve S. Benfield, Jim Hendrickson, Daniel Galanti. *Making a Strong Business Case for Multiagent Technology*. 2006-05. Exact work or author version identified in access notes. Access: FULL_AUTHOR_UPLOADED_TEXT.

**AOSE-S027** — Viviana Mascardi, Danny Weyns, Alessandro Ricci, EMAS 2018 workshop contributors (full byline in source). *Engineering Multi-Agent Systems: State of Affairs and the Road Ahead*. 2019. Exact work or author version identified in access notes. Access: FULL_AUTHOR_UPLOADED_TEXT.

**AOSE-S028** — EMAS workshop organisers. *Engineering Multi-Agent Systems workshop series history*. 2026 (accessed). Exact work or author version identified in access notes. Access: FULL_HTML.

**AOSE-S029** — Timotheus Kampik, Cleber Jorge Amaral, Jomi Fred Hübner. *Developer Operations and Engineering Multi-Agent Systems*. 2021-08-18. arXiv:2108.08117v1. Access: FULL_HTML.

**AOSE-S030** — Blair Archibald, Muffy Calder, Michele Sevegnani, Mengwei Xu. *Verifying BDI Agents in Dynamic Environments*. 2022. Exact work or author version identified in access notes. Access: FULL_PDF.

**AOSE-S031** — Sebastian Rodriguez, John Thangarajah, Michael Winikoff. *A Behaviour-Driven Approach for Testing Requirements via User and System Stories in Agent Systems*. 2023-05. Exact work or author version identified in access notes. Access: FULL_PROCEEDINGS_PDF.

**AOSE-S032** — Mert Cemri, Melissa Z. Pan, Shuyi Yang, Lakshya A. Agrawal, Bhavya Chopra, Rishabh Tiwari, Kurt Keutzer, Aditya Parameswaran, Dan Klein, Kannan Ramchandran, Matei Zaharia, Joseph E. Gonzalez, Ion Stoica. *Why Do Multi-Agent LLM Systems Fail?*. 2025-03-17. arXiv:2503.13657v1. Access: FULL_HTML.

**AOSE-S033** — Yoav Shoham. *Agent-oriented programming*. 1993. Identified publication; inspected copy specified below. Access: FULL_AUTHOR_PAPER_REPRINT.

**AOSE-S034** — Fabiano Dalpiaz, Xavier Franch, Jennifer Horkoff. *iStar 2.0 Language Guide*. 2016-06-16. arXiv:1605.07767v3; v1 2016-05-25. Access: FULL_TEXT_HTML.

**AOSE-S035** — Zahra Seyedghorban, Egor Klimov, Arie van Deursen, Annibale Panichella, Burcu Kulahcioglu Ozkan. *Observability and Fault Injection for LLM-Based Multi-Agent Systems in Software Engineering*. 2026-08-25. arXiv:2608.24271v1; inspected author version of ICST 2026 paper. Access: FULL_TEXT_HTML.

**AOSE-S036** — Matteo Baldoni, Cristina Baroglio, Stéphane Galland, Roberto Micalizio, Fatma Outay, Stefano Tedeschi. *Interaction Protocols in an Imperative Agent-Oriented Programming Language: the case of BSPL and SARL*. 2025-05. Identified publication; inspected copy specified below. Access: FULL_PAPER.

**AOSE-S037** — Munindar P. Singh, Amit K. Chopra. *Clouseau: Generating Communication Protocols from Commitments*. 2020. Identified publication; inspected copy specified below. Access: FULL_AUTHOR_COPY.

**AOSE-S038** — Haralambos Mouratidis, Paolo Giorgini. *Secure Tropos: A Security-Oriented Extension of the Tropos Methodology*. 2007. Identified publication; inspected copy specified below. Access: FULL_AUTHOR_PAPER_REPRINT.

**AOSE-S039** — Massimo Cossentino, Colin Potts. *A CASE tool supported methodology for the design of multi-agent systems*. 2002-06. Identified publication; inspected copy specified below. Access: FULL_AUTHOR_PAPER_REPRINT.

**AOSE-S040** — Carole Bernon, Valérie Camps, Marie-Pierre Gleizes, Gauthier Picard. *Designing Agents’ Behaviors and Interactions within the Framework of ADELFE Methodology*. 2004. Identified publication; inspected copy specified below. Access: FULL_PAPER.

**AOSE-S041** — Carlos A. Iglesias, Mercedes Garijo, José Carlos González, Juan Ramón Velasco. *Analysis and Design of Multiagent Systems Using MAS-CommonKADS*. 1998. Identified publication; inspected copy specified below. Access: FULL_AUTHOR_PAPER_REPRINT.

**AOSE-S042** — Jörg P. Müller, Klaus Fischer. *Application Impact of Multiagent Systems and Technologies: A Survey*. 2014. Identified publication; inspected copy specified below. Access: FULL_AUTHOR_PAPER_REPRINT.

**AOSE-S043** — Foundation for Intelligent Physical Agents. *FIPA ACL Message Structure Specification*. 2002-12-03. SC00061G, standard dated 3 December 2002. Access: FULL_STANDARD_VIA_UNIVERSITY_MIRROR.

**AOSE-S044** — JaCaMo project maintainers. *JaCaMo project: Multi-Agent Oriented Programming and platform scope*. undated; inspected 2026-09-07. Web-page state accessed 2026-09-07; no claim that displayed release is latest. Access: CURRENT_OFFICIAL_PAGE.

**AOSE-S045** — Pankaj R. Telang, Anup K. Kalia, Munindar P. Singh. *Modeling Healthcare Processes Using Commitments: An Empirical Evaluation*. 2015-11-05. Identified publication; inspected copy specified below. Access: FULL_PUBLISHER_HTML.

**AOSE-S046** — Jorge J. Gómez-Sanz, Rubén Fuentes-Fernández. *Understanding Agent-Oriented Software Engineering methodologies*. 2015. Identified publication; inspected copy specified below. Access: AUTHOR_MANUSCRIPT_AND_PUBLISHER_METADATA.

**AOSE-S047** — Chunqiu Steven Xia, Yinlin Deng, Soren Dunn, Lingming Zhang. *Agentless: Demystifying LLM-based Software Engineering Agents*. 2024-10-29. arXiv:2407.01489v2; first version July 2024. Access: FULL_TEXT_HTML.

**AOSE-S048** — Sayash Kapoor, Benedikt Stroebl, Zachary S. Siegel, Nitya Nadgir, Arvind Narayanan. *AI Agents That Matter*. 2024-07-01. arXiv:2407.01502v1. Access: FULL_TEXT_HTML.

**AOSE-S049** — Dylan Léveillé. *Generating Plans for Belief-Desire-Intention (BDI) Agents Using Alternating-Time Temporal Logic (ATL)*. 2025-09-17. arXiv:2509.15238v1 / EPTCS 428. Access: FULL_TEXT_HTML_AND_PDF.

**AOSE-S050** — Mert Cemri, Melissa Z. Pan, Shuyi Yang, Lakshya A Agrawal, Bhavya Chopra, Rishabh Tiwari, Kurt Keutzer, Aditya Parameswaran, Dan Klein, Kannan Ramchandran, Matei Zaharia, Joseph E. Gonzalez, Ion Stoica. *Why Do Multi-Agent LLM Systems Fail?*. 2025-10-26. arXiv:2503.13657v3; preserves earlier v1 as S032. Access: FULL_TEXT_HTML.

**AOSE-S051** — Sebastian Rodriguez, Akhila Bairy, Matteo Baldoni, Patrick Benjamin, Constantin Blessing, Nicolas Brandstetter, Amit K. Chopra, Thomas Clemen, Louise A. Dennis, Ahmad Esmaeili, Lu Feng, Angelo Ferrando, Zahra Ghorrati, Victor Guillet, Önder Gürcan, Soham Hans, James Herber, Viviana Mascardi, Marcel Mauri, Jörg P. Müller, John Thangarajah, Rafał Tyl, Yi Yang. *Engineering the Next Generation of Multi-agent Systems: A Community Roadmap from EMAS 2025*. 2026-02-14. EMAS 2025 proceedings, LNCS 16407, published 2026. Access: ABSTRACT_METADATA_AND_PUBLIC_APPENDIX.

**AOSE-S052** — Andrea Gatti, Viviana Mascardi, Angelo Ferrando. *ChatBDI: Think BDI, Talk LLM*. 2025-05. Identified publication; inspected copy specified below. Access: FULL_PAPER.

**AOSE-S053** — Edoardo Debenedetti, Jie Zhang, Mislav Balunović, Luca Beurer-Kellner, Marc Fischer, Florian Tramèr. *AgentDojo: A Dynamic Environment to Evaluate Prompt Injection Attacks and Defenses for LLM Agents*. 2024. arXiv:2406.13352v3. Access: FULL_TEXT_HTML.

**AOSE-S054** — Yoosef Abushark, John Thangarajah, Tim Miller, James Harland. *Checking Consistency of Agent Designs Against Interaction Protocols for Early-Phase Defect Location*. 2014-05. Identified publication; inspected copy specified below. Access: FULL_PAPER.

**AOSE-S055** — Nicholas R. Jennings. *An agent-based approach for building complex software systems*. 2001-04. Identified publication; inspected copy specified below. Access: FULL_PAPER_VIA_UNIVERSITY_MIRROR.

**AOSE-S056** — Giovanni Ciatto, Gianluca Aguzzi, Riccardo Battistini, Martina Baiardi, Samuele Burattini, Alessandro Ricci. *Exploiting GenAI for Plan Generation in BDI Agents*. 2025-10. ECAI 2025, FAIA 413, pp.3495–3502; later publisher HTML accessed in 2026. Access: FULL_PUBLISHER_HTML_AND_INSTITUTIONAL_METADATA.

**AOSE-S057** — Marco Robol, Paolo Giorgini. *Self-Evolving Software Agents*. 2026-04-29. arXiv:2604.27264v1, AAMAS 2026 extended abstract. Access: FULL_TEXT_HTML.

**AOSE-S058** — Anna Perini. *Agent-Oriented Software Engineering*. 2008-06-13. Identified publication; inspected copy specified below. Access: PUBLISHER_ABSTRACT_AND_REFERENCES.

**AOSE-S059** — Eric Yu, Philippe Du Bois, Eric Dubois, John Mylopoulos. *From Organization Models to System Requirements: A “Cooperating Agents” Approach*. 1995. Identified publication; inspected copy specified below. Access: FULL_AUTHOR_COPY.

**AOSE-S060** — Eric Yu. *Agent-Oriented Modelling: Software Versus the World*. 2002. AOSE 2001 workshop; LNCS 2222 (2002), pp.206–225. DOI 10.1007/3-540-70657-7_14.. Access: FULL_AUTHOR_COPY.

**AOSE-S061** — Zhuowen Yin, Cuifeng Gao, Chunsong Fan, Wenzhang Yang, Yinxing Xue, Lijun Zhang. *A Comprehensive Empirical Evaluation of Agent Frameworks on Code-centric Software Engineering Tasks*. 2025-11-02. arXiv:2511.00872v1. Access: FULL_PREPRINT_HTML.

**AOSE-S062** — Christopher Lawton, David Sacharny, Thomas C. Henderson. *A Self-Aware BDI Agent for LLM-Driven Reasoning: Architecture, Design, and Preliminary Evaluation*. 2026-05-15. University of Utah technical report UUCS-26-001. Access: FULL_AUTHOR_COPY.

