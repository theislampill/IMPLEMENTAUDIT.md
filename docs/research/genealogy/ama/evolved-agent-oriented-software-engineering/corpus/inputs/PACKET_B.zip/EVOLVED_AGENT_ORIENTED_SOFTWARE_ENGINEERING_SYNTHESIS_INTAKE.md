# Evolved Agent-Oriented Software Engineering — later-synthesis intake

Revision `EAOSE-2026-09-07-R1` · cut-off `2026-09-07` · lane 7.3.

**SIBLING_CORPORA_NOT_CONSULTED**

**CROSS_TRIFECTA_SYNTHESIS_NOT_PERFORMED**

The provisional grouping is **#7 — Autonomous Agents / Multi-Agent Systems / Agent-Oriented Software Engineering**. It is an organisational label for future research reconciliation, not an established scholarly methodology. This packet supplies only the AOSE lane and makes no claim about findings in unread sibling corpora.

## Frozen identity and denominator

The lineage is `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING`. All 83 candidate IDs and dispositions must be preserved during later integration, including duplicates, rejected generalisations and EAOSE-062 (UNRESOLVED). Globally unique keys take the form `EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-001`. Do not renumber or silently drop unfavourable records. The 62 source records include materially distinct editions; those are not automatically independent evidence.

| Disposition | Count |
| --- | --- |
| ASSUMPTION_SENSITIVE | 9 |
| CEREMONY_NOT_GENERAL_PROPERTY | 2 |
| CONTESTED | 1 |
| CONTEXT_DEPENDENT | 11 |
| DOMAIN_SPECIFIC | 3 |
| DUPLICATE_CANDIDATE | 3 |
| NO_GENERAL_PROPERTY | 1 |
| REJECTED_OR_DISFAVOURED | 9 |
| RETAINED_IN_EVOLVED_FORM | 32 |
| STRONGLY_RETAINED | 7 |
| SUPERSEDED_BY_STRONGER_FORM | 1 |
| UNRESOLVED | 1 |
| USEFUL_BUT_EASILY_BUREAUCRATISED | 1 |
| USEFUL_BUT_EASILY_GAMED | 2 |

## Within-tradition result

The system connects accepted needs, role/interaction responsibilities, actual implementation and outcome evidence through guarded, revisable decisions. It does not impose a maximal named methodology or require an agent runtime. Alternative configurations cover a minimum form, BDI detail, open interactions, changing organisations, stronger assurance, knowledge-intensive or cooperative-emergent settings, and learned components as warranted by their assumptions. The machine model supplies exact guards and relations rather than a forced serial pipeline.

EAOSE-073 and EAOSE-076 are distinct analytical composition mechanisms: cross-view criterion–authority–effect coupling, and continuity of incurred obligations during organisational reconfiguration. EAOSE-074 and EAOSE-075 are duplicates of existing revalidation/tailoring functions. EAOSE-081 is duplicate feedback; EAOSE-080 and EAOSE-082 reject unwarranted guarantees. EAOSE-083 is a sourced native responsiveness mechanism, not an invention of the composition.

## Native concepts and abstraction levels

Keep strategic actors and stakeholder goals separate from runtime agents and implemented goals. Keep role obligations separate from role holders and process instances. Keep internal beliefs/intentions separate from external truth and public commitments. Keep protocol meaning separate from transport syntax and individual control flow. Keep metamodel/process fragments separate from runtime components. Keep evidence classification separate from operative authority.

The practical question for a later merge is not whether two records use the same word. It is whether their trigger, object, intervention, observable and assumptions coincide. Semantic equivalence can justify shared implementation without deleting distinct history or criticism. Complementarity can create a new relation; incompatibility can require selection rather than combination.

## Required inputs, produced constraints and feedback

Inputs include affected stakeholders’ purposes and constraints; genuine authority/capabilities; organisation and interaction models; executable/versioned bindings; and observations with known or disputed grounding. Outputs include architecture choices, constrained role/agent mappings, permitted interactions, evidence-scoped acceptance or rejection, changed-assumption notices and justified omission/retirement decisions. These outputs are not target-mutation authority.

For action selection, criterion, permission/capability and bounded prediction are coupled. For outcome acceptance, actual appropriate observations replace prediction as the relevant evidence. Unknown consequences can warrant controlled inquiry, not a pre-certified success claim. Current evidence is retained, narrowed or re-established according to changed dependencies rather than either discarded wholesale or inherited blindly.

## Reconciliation questions for the Autonomous Agents lane

Does the independent lane use autonomy as a capability, a behavioural property, an authority relation or an architectural pattern, and which AOSE selection/permission boundaries does it address? Do its goals, plans, beliefs and observations have the same semantics as those consumed by AOSE’s design-to-implementation relations? Which guarantees concern deliberation only, and what must connect them to environmental observation and effect? Where learned or self-revising mechanisms are proposed, what authorises the change and what evidence remains applicable? These are questions, not inferred sibling answers.

## Reconciliation questions for the Multi-Agent Systems lane

Are roles, organisations, protocols, commitments and capabilities defined at the same level as the AOSE engineering artefacts? Does a collective result require cooperation, fairness, truthful capabilities, reliable delivery or a shared institution that the engineering setting cannot assume? Does a dynamic organisation mechanism preserve live obligations or only find a valid new assignment? Which interaction and assurance mechanisms are common sources rather than independent confirmations? Can one existing coordination mechanism satisfy several concerns without inventing a new control per property? Again, the sibling corpus has not been consulted.

## Tests required at the later reconciliation boundary

Test semantic equivalence, complementarity and redundancy with actual definitions and counterexamples. Check abstraction levels, source/data independence, prerequisites, incompatible assumptions and failure costs. Test selection, substitution, omission and retirement—not only addition. A combined formal claim must establish compatible models and environmental relations; a shared word or matching diagram is not a proof. New composition-induced properties require a distinct trigger and failure prevented by the interaction, not simply a new name for existing feedback.

## Configurations and unresolved boundaries

### CFG-MIN — Smallest coherent engineering form

**Selection —** Few consequential choices and a sufficiently stable task; no open negotiation or dynamic reorganisation requirement.

**Mechanisms —** EAOSE-001, EAOSE-002, EAOSE-005, EAOSE-008, EAOSE-029, EAOSE-039, EAOSE-043, EAOSE-054, EAOSE-057, EAOSE-073

**Form —** A stakeholder/acceptance statement; explicit permitted capabilities; a chosen implementation (possibly conventional); grounded tests/results; a small change-impact decision. One record or conversation plus executable checks may discharge several concerns.

**Omit / substitute —** No mandatory agent runtime, goal editor, BDI library, role hierarchy, generated code or continuous trace store.

**Exit trigger —** Independent obligations, dynamic roles, safety-critical reasoning, stochastic generation or distributed failure cannot be handled adequately by the simple form.

### CFG-BDI — Controlled deliberative agents

**Selection —** Goals, plan alternatives and failure handling justify a BDI branch with a sufficiently understood environment.

**Mechanisms —** EAOSE-010, EAOSE-013, EAOSE-014, EAOSE-028, EAOSE-029, EAOSE-030, EAOSE-031, EAOSE-044, EAOSE-045, EAOSE-046

**Form —** Agent-level deliberation has explicit plan contexts and effects; collective testing and environmental grounding remain separate. Formal checking is added when its model and cost fit.

**Omit / substitute —** Use imperative/reactive behaviour when BDI adds no leverage; public commitments can coexist at the boundary without forcing common internals.

**Exit trigger —** Unknown or strategic peers invalidate cooperative mental-state assumptions; slow learned plans trigger CFG-HYBRID constraints.

### CFG-OPEN — Open interaction with public obligations

**Selection —** Independent parties retain internal autonomy but need compatible public meaning and completion evidence.

**Mechanisms —** EAOSE-020, EAOSE-021, EAOSE-022, EAOSE-023, EAOSE-025, EAOSE-026, EAOSE-032, EAOSE-073

**Form —** Specify commitments/information dependencies, realise local behaviours and check message interpretation plus externally meaningful discharge. Refusal/noncompliance are possible outcomes.

**Omit / substitute —** A direct call or agreed state machine can suffice in a controlled closed setting; do not impose a central total order solely for diagram neatness.

**Exit trigger —** Changing role holders with live obligations also requires CFG-RECONFIG; disputed institutional semantics may prevent automated adjudication.

### CFG-RECONFIG — Known-function adaptive organisation

**Selection —** Capabilities or members change but collective duties remain sufficiently specified.

**Mechanisms —** EAOSE-015, EAOSE-016, EAOSE-017, EAOSE-054, EAOSE-056, EAOSE-058, EAOSE-076

**Form —** Observe relevant capability and obligation state; reconcile the old work with successor assignment. Drain, valid transfer, release, compensation or explicit inability are alternatives.

**Omit / substitute —** Static assignment or planned drain can be cheaper and safer; no automatic optimiser is mandatory.

**Exit trigger —** Unknown global function and cooperative emergence require a different branch; partial observations can forbid a confident transition.

### CFG-AMAS — Cooperation-driven emergent adaptation

**Selection —** The ADELFE-style adequacy and cooperation assumptions fit an incompletely prescribed, changing function.

**Mechanisms —** EAOSE-018, EAOSE-049, EAOSE-055, EAOSE-078

**Form —** Engineer local responses to non-cooperative situations and evaluate collective adequacy under stated environmental conditions.

**Omit / substitute —** Use a known-goal organisation or central algorithm when the desired function is already sufficiently specified.

**Exit trigger —** Strategic refusal, incompatible objectives or unacceptable external effects defeat the cooperative premise; no guarantee is rescued by relabelling them adaptation.

### CFG-HYBRID — Constrained learned-plan/tool-use integration

**Selection —** Language interpretation or generated plans provide demonstrated task value worth stochasticity, latency and maintenance cost.

**Mechanisms —** EAOSE-010, EAOSE-029, EAOSE-030, EAOSE-056, EAOSE-066, EAOSE-067, EAOSE-068, EAOSE-069, EAOSE-070, EAOSE-071, EAOSE-083

**Form —** Treat learned output as a proposal within declared capabilities; separate untrusted inputs from authority; validate syntax, semantic applicability and grounded outcomes. Keep unrelated responsibilities responsive where runtime support permits.

**Omit / substitute —** Prewritten plans, a fixed workflow, a deterministic classifier or no model call may dominate. Memory/trace machinery is conditional, not mandatory.

**Exit trigger —** Opaque drift, injection risk, unacceptable delay or unvalidated self-revision warrants restriction, fallback or retirement rather than automatic greater autonomy.

### CFG-SPECIAL — Optional structural/knowledge refinements

**Selection —** Nearly decomposable organisation or knowledge-intensive reasoning has an actual consumer for additional views.

**Mechanisms —** EAOSE-040, EAOSE-077, EAOSE-079

**Form —** Nest organisational boundaries or separate expertise/task views only where the selected core cannot express the relevant decision adequately.

**Omit / substitute —** Flat structures, typed data and direct algorithms remain legitimate alternatives.

**Exit trigger —** Cross-cutting coupling or model maintenance makes the extra abstraction more costly than useful.

The major relations and complete 224-edge model are in the composition JSON; all relation records include a guard, shared/incompatible assumptions, mechanism, added cost/failure and evidence status. Do not import a relation as an unconditional control. EAOSE-062 and UCO-01/02/03 remain researched uncertainties or contextual limits, not unexamined work.

## Complete property interface export

Every frozen ID is exported, including limit-only candidates. The full ten-field domain profile and evidence partitions resolve in the ledger through the named property. Inputs are logical/semantic dependencies, not necessarily new artefacts, owners or pipeline stages.

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-001

**Name / disposition —** Affected-actor discovery and validation — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** CRITERION_AND_INQUIRY_COUPLING; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Identify beneficiaries, dependants, resource holders and adversely affected actors; have their actual concerns challenge the chosen system boundary rather than treating a complete drawing as a census.

**Trigger —** The system redistributes work, information, discretion or consequences among people or organisations.

**Required inputs —** property inputs: None, subject to the stated absence explanation.. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. Actor modelling provides a vocabulary, not an algorithm guaranteeing discovery; the analyst can exclude inconvenient participants.. absence reason: This is a boundary/selection inquiry or independently posed candidate; it has no mandatory earlier property in this corpus..

**Produced constraints / evidence —** criterion: Relevant actor concerns and disputed exclusions are recorded and can change requirements.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Requirements analyst with affected actors and the legitimate requirements decision maker. boundary: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them..

**Cost / assumption failure —** Actor modelling provides a vocabulary, not an algorithm guaranteeing discovery; the analyst can exclude inconvenient participants.

**Substitution / omission / retirement —** A small stakeholder discussion and explicit exclusions can suffice; do not draw a full organisational model for a self-contained utility. A small stakeholder discussion and explicit exclusions can suffice; do not draw a full organisational model for a self-contained utility.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-001; REL-031; REL-035; REL-036; REL-038; REL-040; REL-110. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Relevant actor concerns and disputed exclusions are recorded and can change requirements. Operation: Identify beneficiaries, dependants, resource holders and adversely affected actors; have their actual concerns challenge the chosen system boundary rather than treating a complete drawing as a census. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S004; AOSE-S010; AOSE-S038; AOSE-S059; AOSE-S060. critical: AOSE-S004; AOSE-S010; AOSE-S059. empirical or case: None, subject to the stated absence explanation.. boundary: Retain a discover-and-challenge activity, not an exhaustive actor census. The absent-stakeholder counterexample defeats the stronger completeness claim..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-002

**Name / disposition —** Separate stakeholder goals, runtime goals and acceptance conditions — STRONGLY_RETAINED

**Kind / lineage class —** SEMANTIC_DISTINCTION; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Relate but do not identify a desired stakeholder outcome, an agent goal representation and the observation used to judge achievement; expose the translation and its counterexamples.

**Trigger —** A goal is decomposed, delegated or made executable.

**Required inputs —** property inputs: EAOSE-001. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. A test can faithfully encode the wrong need; acceptance judgements may remain partly human..

**Produced constraints / evidence —** criterion: A runtime success flag alone cannot discharge an unobserved external outcome.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Requirements analyst with affected actors and the legitimate requirements decision maker. boundary: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them..

**Cost / assumption failure —** A test can faithfully encode the wrong need; acceptance judgements may remain partly human.

**Substitution / omission / retirement —** One requirement with a direct test is enough where the mapping is trivial. One requirement with a direct test is enough where the mapping is trivial.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-001; REL-031; REL-035; REL-037; REL-039; REL-042; REL-044; REL-049; REL-051; REL-081; REL-092; REL-095; REL-111; REL-124; REL-193; REL-213. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A runtime success flag alone cannot discharge an unobserved external outcome. Operation: Relate but do not identify a desired stakeholder outcome, an agent goal representation and the observation used to judge achievement; expose the translation and its counterexamples. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S004; AOSE-S012; AOSE-S031; AOSE-S059; AOSE-S060. critical: AOSE-S004; AOSE-S031; AOSE-S059. empirical or case: AOSE-S031. boundary: Retain the distinction strongly: runtime goal satisfaction and accepted stakeholder consequence have different truth conditions. No productivity theorem is implied..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-003

**Name / disposition —** Dependency and delegation vulnerability analysis — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Specify who relies on whom for a goal, task, resource or quality; examine willingness, ability, alternatives and consequences of non-delivery before relying on delegation.

**Trigger —** A requirement depends on another actor outside the requester’s immediate control.

**Required inputs —** property inputs: EAOSE-001; EAOSE-002. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. A dependency edge neither obtains consent nor supplies capacity; adding dependencies can centralise hidden risk..

**Produced constraints / evidence —** criterion: Critical dependencies have an accepted reliance basis or an explicit unresolved exposure.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Requirements analyst with affected actors and the legitimate requirements decision maker. boundary: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them..

**Cost / assumption failure —** A dependency edge neither obtains consent nor supplies capacity; adding dependencies can centralise hidden risk.

**Substitution / omission / retirement —** Use a direct agreement or ordinary interface contract for one stable dependency. Use a direct agreement or ordinary interface contract for one stable dependency.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-001; REL-036; REL-037; REL-041; REL-043; REL-062; REL-067; REL-160. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Critical dependencies have an accepted reliance basis or an explicit unresolved exposure. Operation: Specify who relies on whom for a goal, task, resource or quality; examine willingness, ability, alternatives and consequences of non-delivery before relying on delegation. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S010; AOSE-S004; AOSE-S038; AOSE-S059; AOSE-S060. critical: AOSE-S004; AOSE-S010; AOSE-S059. empirical or case: None, subject to the stated absence explanation.. boundary: Retain dependencies as vulnerabilities to investigate, not as presumed consent or reliable delivery..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-004

**Name / disposition —** Explicit goal conflict and alternative rationale — USEFUL_BUT_EASILY_GAMED

**Kind / lineage class —** DECISION_CRITERION; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Compare alternative means against conflicting goals and qualities, preserve who judges trade-offs, and distinguish qualitative contribution from measured satisfaction.

**Trigger —** Different stakeholders or feasible designs favour incompatible outcomes.

**Required inputs —** property inputs: EAOSE-001; EAOSE-002. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. Qualitative labels and weights can rationalise a predetermined choice; graph arithmetic does not establish stakeholder preference..

**Produced constraints / evidence —** criterion: The chosen alternative has a revisitable rationale and unresolved conflicts are visible.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Requirements analyst with affected actors and the legitimate requirements decision maker. boundary: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them..

**Cost / assumption failure —** Qualitative labels and weights can rationalise a predetermined choice; graph arithmetic does not establish stakeholder preference.

**Substitution / omission / retirement —** Document the concrete choice and decisive evidence without elaborate softgoal scoring when it is clear. Document the concrete choice and decisive evidence without elaborate softgoal scoring when it is clear.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-001; REL-038; REL-039. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: The chosen alternative has a revisitable rationale and unresolved conflicts are visible. Operation: Compare alternative means against conflicting goals and qualities, preserve who judges trade-offs, and distinguish qualitative contribution from measured satisfaction. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S004; AOSE-S010; AOSE-S034; AOSE-S060. critical: AOSE-S004; AOSE-S010. empirical or case: None, subject to the stated absence explanation.. boundary: Retain contribution/conflict analysis but mark it gameable because qualitative judgements can encode preferences without validating them..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-005

**Name / disposition —** Security constraints and delegation authority — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Carry security constraints from stakeholder concerns to roles, plans and interactions; distinguish permission, trust and actual capability, and test disallowed actions as well as permitted ones.

**Trigger —** An agent receives privileged data, delegated resources or power to affect another actor.

**Required inputs —** property inputs: EAOSE-001; EAOSE-003. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. Security-goal models need enforcement and threat assumptions; declared trust is not evidence of trustworthy behaviour..

**Produced constraints / evidence —** criterion: An intended action is not admitted solely because it advances a goal or appears in a plan.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Requirements analyst with affected actors and the legitimate requirements decision maker. boundary: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them..

**Cost / assumption failure —** Security-goal models need enforcement and threat assumptions; declared trust is not evidence of trustworthy behaviour.

**Substitution / omission / retirement —** Use an existing narrow access-control boundary with an explicit caller contract when sufficient. Use an existing narrow access-control boundary with an explicit caller contract when sufficient.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-002; REL-040; REL-041; REL-046; REL-050; REL-060; REL-068; REL-149; REL-174; REL-179; REL-194. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: An intended action is not admitted solely because it advances a goal or appears in a plan. Operation: Carry security constraints from stakeholder concerns to roles, plans and interactions; distinguish permission, trust and actual capability, and test disallowed actions as well as permitted ones. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S038; AOSE-S021; AOSE-S043. critical: AOSE-S021; AOSE-S038. empirical or case: None, subject to the stated absence explanation.. boundary: Retain security/authority mapping with a separately realised enforcement boundary; a trusted label is not trustworthy execution..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-006

**Name / disposition —** Revalidate goals when operating assumptions change — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Use changed context, conflict or failed outcome evidence to reopen the affected goal, constraint and acceptance mapping rather than merely adjusting code until an old test passes.

**Trigger —** Stakeholders, environmental conditions or the meaning of success materially change.

**Required inputs —** property inputs: EAOSE-002; EAOSE-003. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. Continuous reopening can prevent delivery; a changed goal still requires legitimate acceptance rather than unilateral runtime preference..

**Produced constraints / evidence —** criterion: Affected requirements receive an explicit retained, revised or withdrawn judgement.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Requirements analyst with affected actors and the legitimate requirements decision maker. boundary: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them..

**Cost / assumption failure —** Continuous reopening can prevent delivery; a changed goal still requires legitimate acceptance rather than unilateral runtime preference.

**Substitution / omission / retirement —** No new requirements exercise for a change shown not to affect meaning or consequences. No new requirements exercise for a change shown not to affect meaning or consequences.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-004; REL-019; REL-042; REL-043; REL-145; REL-150; REL-154. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Affected requirements receive an explicit retained, revised or withdrawn judgement. Operation: Use changed context, conflict or failed outcome evidence to reopen the affected goal, constraint and acceptance mapping rather than merely adjusting code until an old test passes. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S004; AOSE-S029; AOSE-S031; AOSE-S057; AOSE-S059. critical: AOSE-S004; AOSE-S031; AOSE-S059. empirical or case: AOSE-S031; AOSE-S057. boundary: Extend iterative requirements reasoning to material operating changes, not continuous unbounded re-elicitation. Runtime revision cannot unilaterally redefine acceptance..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-007

**Name / disposition —** A complete goal diagram proves complete requirements — REJECTED_OR_DISFAVOURED

**Kind / lineage class —** OVERGENERALISATION; ADVERSARIAL_GENERALISATION_TEST; not necessarily asserted by the cited authors

**Mechanism —** Examined claim: infer that every affected need is correct and covered from structural completeness of a goal model. Reject the inference; use actor validation and adversarial outcomes instead.

**Trigger —** A model is offered as sufficient acceptance evidence.

**Required inputs —** property inputs: EAOSE-001; EAOSE-002. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. Models can be internally complete over an incorrectly chosen boundary..

**Produced constraints / evidence —** criterion: Diagram completeness is never reported as demonstrated completeness of real needs.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Requirements analyst with affected actors and the legitimate requirements decision maker. boundary: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them..

**Cost / assumption failure —** Models can be internally complete over an incorrectly chosen boundary.

**Substitution / omission / retirement —** Ask an omitted-actor or false-success question before adding any diagram. Ask an omitted-actor or false-success question before adding any diagram.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-031. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Diagram completeness is never reported as demonstrated completeness of real needs. Operation: Examined claim: infer that every affected need is correct and covered from structural completeness of a goal model. Reject the inference; use actor validation and adversarial outcomes instead. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S004; AOSE-S010; AOSE-S031. critical: AOSE-S004; AOSE-S010; AOSE-S031. empirical or case: AOSE-S031. boundary: Reject the universal inference through the missing-actor counterexample; no allegation is made that all goal-method authors assert it..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-008

**Name / disposition —** Justify the semantic fit of agency — STRONGLY_RETAINED

**Kind / lineage class —** SELECTION_CRITERION; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Select agent abstractions when delegated control, situated choice, interaction or organisation clarifies consequential decisions; compare the actual design with objects, services, actors, workflows or a controller.

**Trigger —** The engineer is choosing the modelling or execution paradigm.

**Required inputs —** property inputs: None, subject to the stated absence explanation.. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win. Autonomy and distribution can also be engineered with conventional constructs; fit is not a universal productivity theorem.. absence reason: This is a boundary/selection inquiry or independently posed candidate; it has no mandatory earlier property in this corpus..

**Produced constraints / evidence —** criterion: The rationale identifies a semantic benefit and costs rather than a fashionable component label.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Architect and responsible engineering/product decision makers. boundary: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win..

**Cost / assumption failure —** Autonomy and distribution can also be engineered with conventional constructs; fit is not a universal productivity theorem.

**Substitution / omission / retirement —** Retain a conventional design where it meets the same requirements with less complexity. Retain a conventional design where it meets the same requirements with less complexity.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-005; REL-030; REL-045; REL-047; REL-048; REL-076; REL-209. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: The rationale identifies a semantic benefit and costs rather than a fashionable component label. Operation: Select agent abstractions when delegated control, situated choice, interaction or organisation clarifies consequential decisions; compare the actual design with objects, services, actors, workflows or a controller. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S033; AOSE-S013; AOSE-S055; AOSE-S047; AOSE-S060; AOSE-S061. critical: AOSE-S033; AOSE-S047; AOSE-S055; AOSE-S061. empirical or case: AOSE-S047; AOSE-S061. boundary: Retain the comparative semantic-fit question strongly; agency is an optional abstraction with discriminable costs and alternatives..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-009

**Name / disposition —** Decouple agent-oriented analysis from runtime commitment — CONTEXT_DEPENDENT

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Preserve useful actor, goal and responsibility analysis while allowing its realisation in non-agent software; separately justify an agent runtime or a full branded methodology.

**Trigger —** Organisational analysis is valuable but runtime autonomy is unnecessary or existing infrastructure dominates.

**Required inputs —** property inputs: EAOSE-002; EAOSE-008. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win. Translation can erase intentional or organisational semantics; the implementation must still satisfy the selected requirements..

**Produced constraints / evidence —** criterion: No framework or complete method is required merely because an actor-goal model was useful.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Architect and responsible engineering/product decision makers. boundary: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win..

**Cost / assumption failure —** Translation can erase intentional or organisational semantics; the implementation must still satisfy the selected requirements.

**Substitution / omission / retirement —** Use a conventional implementation and retain only decision-relevant analysis. Use a conventional implementation and retain only decision-relevant analysis.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-005; REL-030; REL-044; REL-045. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: No framework or complete method is required merely because an actor-goal model was useful. Operation: Preserve useful actor, goal and responsibility analysis while allowing its realisation in non-agent software; separately justify an agent runtime or a full branded methodology. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S004; AOSE-S041; AOSE-S017; AOSE-S059; AOSE-S060. critical: None, subject to the stated absence explanation.. empirical or case: None, subject to the stated absence explanation.. boundary: Retain conditionally because removing an agent runtime can preserve some requirements while losing others; the translation needs evidence..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-010

**Name / disposition —** Bound delegated autonomy by capabilities and constraints — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Define the choices a component may make, the capabilities it actually has and conditions requiring external decision; leave implementation choice open inside that envelope.

**Trigger —** Behaviour is selected at runtime rather than completely prescribed by a caller.

**Required inputs —** property inputs: EAOSE-005; EAOSE-008. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win. An envelope expressed only in prose may not constrain execution; overly narrow bounds eliminate the useful adaptation..

**Produced constraints / evidence —** criterion: Runtime choice cannot silently expand the authority or resources originally delegated.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Architect and responsible engineering/product decision makers. boundary: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win..

**Cost / assumption failure —** An envelope expressed only in prose may not constrain execution; overly narrow bounds eliminate the useful adaptation.

**Substitution / omission / retirement —** A deterministic function or explicit approval can replace autonomous selection when variability adds no value. A deterministic function or explicit approval can replace autonomous selection when variability adds no value.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-002; REL-046; REL-047; REL-057; REL-061; REL-077; REL-151; REL-180; REL-216. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Runtime choice cannot silently expand the authority or resources originally delegated. Operation: Define the choices a component may make, the capabilities it actually has and conditions requiring external decision; leave implementation choice open inside that envelope. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S012; AOSE-S005; AOSE-S038; AOSE-S016. critical: AOSE-S038. empirical or case: None, subject to the stated absence explanation.. boundary: Retain discretion within explicit capabilities and constraints. This is not a demand that every choice be pre-scripted..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-011

**Name / disposition —** Lifecycle cost and non-agent comparator — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** EVIDENCE_AND_SELECTION_CRITERION; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Compare end-to-end task quality, engineering effort, training, operations and change cost under comparable requirements, including a simpler non-agent solution where plausible.

**Trigger —** A deployment or methodology choice is justified by claimed benefit.

**Required inputs —** property inputs: EAOSE-008. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win. Historical baselines, bundled tools and expert teams confound attribution; a benchmark winner is not a lifecycle winner..

**Produced constraints / evidence —** criterion: The decision distinguishes architectural capability from evidenced incremental benefit.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Architect and responsible engineering/product decision makers. boundary: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win..

**Cost / assumption failure —** Historical baselines, bundled tools and expert teams confound attribution; a benchmark winner is not a lifecycle winner.

**Substitution / omission / retirement —** For a reversible small choice, a short measured spike or reasoned cost screen is adequate. For a reversible small choice, a short measured spike or reasoned cost screen is adequate.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-005; REL-030; REL-048; REL-107; REL-165; REL-167; REL-170. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: The decision distinguishes architectural capability from evidenced incremental benefit. Operation: Compare end-to-end task quality, engineering effort, training, operations and change cost under comparable requirements, including a simpler non-agent solution where plausible. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S047; AOSE-S048; AOSE-S061. critical: AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S047; AOSE-S048; AOSE-S061. empirical or case: AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S047; AOSE-S048; AOSE-S061. boundary: Retain lifecycle/non-agent comparison as the evidential burden for claimed advantage; missing cost data is not zero cost..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-012

**Name / disposition —** Every active component should be an agent — REJECTED_OR_DISFAVOURED

**Kind / lineage class —** OVERGENERALISATION; ADVERSARIAL_GENERALISATION_TEST; not necessarily asserted by the cited authors

**Mechanism —** Examined universal claim: replace all active components with agents. Reject it because a coherent intentional description can add no useful predictive or engineering leverage.

**Trigger —** Agent proliferation is proposed without a distinct responsibility or choice problem.

**Required inputs —** property inputs: EAOSE-008. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win. Rejecting this universal does not prohibit agents in domains where interaction or autonomous choice is genuinely useful..

**Produced constraints / evidence —** criterion: Agent count is not used as a maturity measure.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Architect and responsible engineering/product decision makers. boundary: May select an implementation within accepted requirements; cannot alter the task solely to make a favoured paradigm win..

**Cost / assumption failure —** Rejecting this universal does not prohibit agents in domains where interaction or autonomous choice is genuinely useful.

**Substitution / omission / retirement —** Keep a function, service, workflow or ordinary actor. Keep a function, service, workflow or ordinary actor.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-030. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Agent count is not used as a maturity measure. Operation: Examined universal claim: replace all active components with agents. Reject it because a coherent intentional description can add no useful predictive or engineering leverage. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S033; AOSE-S025; AOSE-S047. critical: AOSE-S033; AOSE-S047. empirical or case: AOSE-S047. boundary: Reject activity alone as a universal reason for agentisation; preserve cases in which autonomous choice genuinely matters..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-013

**Name / disposition —** Role contracts separate responsibilities, permissions and activities — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Specify what a role must preserve or achieve, what resources it may use, what it does internally and which interactions it participates in; keep these distinct from an implementation identity.

**Trigger —** Several participants must coordinate around differentiated responsibilities.

**Required inputs —** property inputs: EAOSE-002; EAOSE-005. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. Gaia permissions primarily concern resources; they must not be inflated into all forms of real-world authorisation..

**Produced constraints / evidence —** criterion: Every consequential role has interpretable obligations and access boundaries.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Organisation designer; operators or delegated organisational controller for permitted runtime changes. boundary: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity..

**Cost / assumption failure —** Gaia permissions primarily concern resources; they must not be inflated into all forms of real-world authorisation.

**Substitution / omission / retirement —** A compact responsibility/interface table is sufficient for a small stable arrangement. A compact responsibility/interface table is sufficient for a small stable arrangement.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-002; REL-006; REL-049; REL-050; REL-052; REL-053; REL-055; REL-063; REL-096; REL-206; REL-221. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Every consequential role has interpretable obligations and access boundaries. Operation: Specify what a role must preserve or achieve, what resources it may use, what it does internally and which interactions it participates in; keep these distinct from an implementation identity. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S001; AOSE-S015; AOSE-S039. critical: AOSE-S001. empirical or case: None, subject to the stated absence explanation.. boundary: Retain separate responsibilities, permissions, private activities and interactions, without upgrading resource permissions into a universal authority theory..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-014

**Name / disposition —** Separate safety from progress obligations — STRONGLY_RETAINED

**Kind / lineage class —** SEMANTIC_DISTINCTION; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Distinguish forbidden states or effects from required progress, including the assumptions and deadlines under which progress is expected.

**Trigger —** Correctness includes both avoiding harm and eventually doing useful work.

**Required inputs —** property inputs: EAOSE-002; EAOSE-013. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. Liveness under fairness is not a real-time response guarantee; safety can depend on environmental abstraction..

**Produced constraints / evidence —** criterion: A system that does nothing safely is not misclassified as meeting its progress requirement.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Organisation designer; operators or delegated organisational controller for permitted runtime changes. boundary: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity..

**Cost / assumption failure —** Liveness under fairness is not a real-time response guarantee; safety can depend on environmental abstraction.

**Substitution / omission / retirement —** A direct invariant plus bounded completion test may suffice without temporal logic. A direct invariant plus bounded completion test may suffice without temporal logic.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-006; REL-051; REL-052; REL-054; REL-084; REL-112; REL-115. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A system that does nothing safely is not misclassified as meeting its progress requirement. Operation: Distinguish forbidden states or effects from required progress, including the assumptions and deadlines under which progress is expected. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S001; AOSE-S023; AOSE-S037. critical: AOSE-S001. empirical or case: None, subject to the stated absence explanation.. boundary: Retain safety/progress separation strongly because avoiding a bad state and eventually producing a good one are not equivalent; deadlines require extra assumptions..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-015

**Name / disposition —** Explicit many-to-many role-to-agent binding — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Record how role responsibilities are fulfilled by concrete agents, including multiplicity, shared work and incompatible assignments; test collective coverage rather than assuming one role equals one process.

**Trigger —** Roles are shared, combined, replicated or reassigned.

**Required inputs —** property inputs: EAOSE-013; EAOSE-014. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. Multiplicity of role holders is not itself a design for collective fulfilment. Original Gaia explicitly leaves the collective-realisation case unelaborated; replication can duplicate action or induce mutual waiting..

**Produced constraints / evidence —** criterion: Each required obligation has a viable assignment without accidental gaps or conflicting execution.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Organisation designer; operators or delegated organisational controller for permitted runtime changes. boundary: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity..

**Cost / assumption failure —** Multiplicity of role holders is not itself a design for collective fulfilment. Original Gaia explicitly leaves the collective-realisation case unelaborated; replication can duplicate action or induce mutual waiting.

**Substitution / omission / retirement —** One documented binding is enough for a fixed single-provider role. One documented binding is enough for a fixed single-provider role.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-006; REL-007; REL-025; REL-053; REL-054; REL-056; REL-058; REL-199; REL-221. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Each required obligation has a viable assignment without accidental gaps or conflicting execution. Operation: Record how role responsibilities are fulfilled by concrete agents, including multiplicity, shared work and incompatible assignments; test collective coverage rather than assuming one role equals one process. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S001; AOSE-S015; AOSE-S016; AOSE-S009. critical: AOSE-S001; AOSE-S009; AOSE-S016. empirical or case: None, subject to the stated absence explanation.. boundary: Retain explicit mapping and fulfilment semantics. Do not attribute a complete collective-role solution to original Gaia, which leaves that case open..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-016

**Name / disposition —** Organisation-level rules supplement local role contracts — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Represent constraints on collective structure, coordination and responsibility that cannot be inferred from isolated role descriptions; check them when roles are instantiated.

**Trigger —** Local correctness permits an invalid collective organisation.

**Required inputs —** property inputs: EAOSE-013; EAOSE-015. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. Organisational rules may be descriptive rather than enforced; a single institutional agent can create a bottleneck..

**Produced constraints / evidence —** criterion: A locally permitted assignment can be refused when it violates a collective constraint.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Organisation designer; operators or delegated organisational controller for permitted runtime changes. boundary: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity..

**Cost / assumption failure —** Organisational rules may be descriptive rather than enforced; a single institutional agent can create a bottleneck.

**Substitution / omission / retirement —** An ordinary shared invariant or configuration rule can replace a separate organisation model. An ordinary shared invariant or configuration rule can replace a separate organisation model.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-006; REL-025; REL-029; REL-055; REL-056; REL-059; REL-207. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A locally permitted assignment can be refused when it violates a collective constraint. Operation: Represent constraints on collective structure, coordination and responsibility that cannot be inferred from isolated role descriptions; check them when roles are instantiated. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S014; AOSE-S016; AOSE-S009; AOSE-S044. critical: AOSE-S009; AOSE-S014; AOSE-S016. empirical or case: None, subject to the stated absence explanation.. boundary: Retain collective organisation constraints, but require an actual consumer or enforcement/checking mechanism rather than treating a diagram as compliance..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-017

**Name / disposition —** Capability-based dynamic reassignment — ASSUMPTION_SENSITIVE

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Separate roles from the changing capability inventory and use an explicit assignment relation to reconfigure participants while retaining the required organisational function.

**Trigger —** Membership, capabilities or failure conditions change during operation.

**Required inputs —** property inputs: EAOSE-010; EAOSE-015; EAOSE-016. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. Capabilities may be misreported or stale; feasible local reassignment need not preserve outstanding interactions..

**Produced constraints / evidence —** criterion: A reassigned role has capability evidence and satisfies the current structural constraints.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Organisation designer; operators or delegated organisational controller for permitted runtime changes. boundary: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity..

**Cost / assumption failure —** Capabilities may be misreported or stale; feasible local reassignment need not preserve outstanding interactions.

**Substitution / omission / retirement —** Static assignment or operator-controlled reassignment when the organisation is stable. Static assignment or operator-controlled reassignment when the organisation is stable.

**Conflicts and relation references —** conflict or alternative ids: REL-026; REL-223. all relation ids: REL-007; REL-008; REL-026; REL-029; REL-057; REL-058; REL-059; REL-152; REL-200; REL-223. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A reassigned role has capability evidence and satisfies the current structural constraints. Operation: Separate roles from the changing capability inventory and use an explicit assignment relation to reconfigure participants while retaining the required organisational function. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S016; AOSE-S009. critical: AOSE-S009; AOSE-S016. empirical or case: None, subject to the stated absence explanation.. boundary: Retain conditionally on capability knowledge, feasible assignments and appropriate organisational assumptions; combine with continuity when live obligations exist..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-018

**Name / disposition —** Environment and shared resources as engineered objects — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Model the resources, artefacts, percepts and actions through which agents affect their environment; assign implementation and assurance duties at those boundaries.

**Trigger —** Important effects pass through shared resources, sensors or external services.

**Required inputs —** property inputs: EAOSE-005; EAOSE-010. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. An environment model can omit dynamics or hide authority; shared artefacts can introduce contention..

**Produced constraints / evidence —** criterion: Reasoning correctness is not used to excuse an untested sensor, resource or actuator boundary.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Organisation designer; operators or delegated organisational controller for permitted runtime changes. boundary: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity..

**Cost / assumption failure —** An environment model can omit dynamics or hide authority; shared artefacts can introduce contention.

**Substitution / omission / retirement —** A tested ordinary API with explicit preconditions and effects is adequate. A tested ordinary API with explicit preconditions and effects is adequate.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-002; REL-060; REL-061; REL-078; REL-079; REL-085; REL-127; REL-210. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Reasoning correctness is not used to excuse an untested sensor, resource or actuator boundary. Operation: Model the resources, artefacts, percepts and actions through which agents affect their environment; assign implementation and assurance duties at those boundaries. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S007; AOSE-S018; AOSE-S030; AOSE-S044. critical: None, subject to the stated absence explanation.. empirical or case: None, subject to the stated absence explanation.. boundary: Retain environment/resources as engineered boundaries. A framework’s environment layer does not prove faithful sensing or effects..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-019

**Name / disposition —** Static cooperative organisation as a universal premise — SUPERSEDED_BY_STRONGER_FORM

**Kind / lineage class —** SCOPE_ASSUMPTION; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Retain a static cooperative design only as a guarded branch; replace its use as a universal premise with explicit openness, capability and organisational-change analysis.

**Trigger —** An original closed-world method is transferred to dynamic, open or competing participants.

**Required inputs —** property inputs: EAOSE-015; EAOSE-016; EAOSE-017. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. An extension named open does not support arbitrary adversaries; adaptive branches retain their own preconditions..

**Produced constraints / evidence —** criterion: The selected method states rather than silently strengthens its organisational assumptions.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Organisation designer; operators or delegated organisational controller for permitted runtime changes. boundary: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity..

**Cost / assumption failure —** An extension named open does not support arbitrary adversaries; adaptive branches retain their own preconditions.

**Substitution / omission / retirement —** Keep the original simpler branch when its assumptions are actually stable. Keep the original simpler branch when its assumptions are actually stable.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-029. duplicate or supersession: property ids: EAOSE-016; EAOSE-017. explanation: Supersede the universal static premise with guarded models; a stable cooperative implementation remains valid within its declared scope...

**Criteria versus operation —** Criterion: The selected method states rather than silently strengthens its organisational assumptions. Operation: Retain a static cooperative design only as a guarded branch; replace its use as a universal premise with explicit openness, capability and organisational-change analysis. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S001; AOSE-S014; AOSE-S016; AOSE-S009; AOSE-S040. critical: AOSE-S001; AOSE-S009; AOSE-S014; AOSE-S016. empirical or case: None, subject to the stated absence explanation.. boundary: Supersede the universal static premise with guarded models; a stable cooperative implementation remains valid within its declared scope..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-020

**Name / disposition —** Interaction specifications with explicit meaning and enactment — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** State participants, messages, information dependencies and social effects separately from optional presentation order; identify what counts as permitted interaction and completion.

**Trigger —** Independently implemented components must coordinate.

**Required inputs —** property inputs: EAOSE-003; EAOSE-013. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Sequence diagrams can overconstrain autonomous choices or leave exceptional paths unspecified..

**Produced constraints / evidence —** criterion: Both implementers can explain the same observed interaction and its obligations.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Protocol designers, implementers and the principals participating in an interaction. boundary: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning..

**Cost / assumption failure —** Sequence diagrams can overconstrain autonomous choices or leave exceptional paths unspecified.

**Substitution / omission / retirement —** A simple request/response contract with failure cases may suffice. A simple request/response contract with failure cases may suffice.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-009; REL-062; REL-063; REL-064; REL-065; REL-069; REL-070; REL-071; REL-221. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Both implementers can explain the same observed interaction and its obligations. Operation: State participants, messages, information dependencies and social effects separately from optional presentation order; identify what counts as permitted interaction and completion. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S020; AOSE-S021; AOSE-S037; AOSE-S043. critical: AOSE-S021; AOSE-S037; AOSE-S043. empirical or case: None, subject to the stated absence explanation.. boundary: Retain interaction meaning and enactment while allowing different notations and partial orders; do not force all autonomous interaction into a global sequence..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-021

**Name / disposition —** Shared content and ontology interpretation — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Agree message structure, content language, domain terms, identities and conversation correlation; verify the interpretation at receiving implementations rather than merely validating syntax.

**Trigger —** Different components exchange semantically significant data.

**Required inputs —** property inputs: EAOSE-020. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Matching schemas can still conceal differing units, time horizons or institutional meaning..

**Produced constraints / evidence —** criterion: A valid message is interpreted consistently with its declared protocol and domain context.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Protocol designers, implementers and the principals participating in an interaction. boundary: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning..

**Cost / assumption failure —** Matching schemas can still conceal differing units, time horizons or institutional meaning.

**Substitution / omission / retirement —** A shared typed schema and a few interpretation tests suffice when meaning is unambiguous. A shared typed schema and a few interpretation tests suffice when meaning is unambiguous.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-009; REL-032; REL-064; REL-066; REL-072; REL-073; REL-104; REL-189. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A valid message is interpreted consistently with its declared protocol and domain context. Operation: Agree message structure, content language, domain terms, identities and conversation correlation; verify the interpretation at receiving implementations rather than merely validating syntax. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S039; AOSE-S043; AOSE-S041. critical: AOSE-S043. empirical or case: None, subject to the stated absence explanation.. boundary: Retain shared interpretation as an integration obligation distinct from schema validation; domain terms can disagree despite identical fields..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-022

**Name / disposition —** Global-to-local protocol correspondence — ASSUMPTION_SENSITIVE

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Check that local send/receive behaviours collectively realise the intended global interaction, with explicit asynchronous and information-availability assumptions.

**Trigger —** A global protocol is projected or compiled into independently executing agents.

**Required inputs —** property inputs: EAOSE-020; EAOSE-021. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Syntax-preserving projection need not preserve behaviour; reliable-delivery or complete-information assumptions may fail..

**Produced constraints / evidence —** criterion: Permitted global runs are realisable and invalid local combinations are detected under the stated model.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Protocol designers, implementers and the principals participating in an interaction. boundary: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning..

**Cost / assumption failure —** Syntax-preserving projection need not preserve behaviour; reliable-delivery or complete-information assumptions may fail.

**Substitution / omission / retirement —** Joint contract tests can be adequate for a short bounded exchange. Joint contract tests can be adequate for a short bounded exchange.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-009; REL-032; REL-065; REL-066; REL-074; REL-087; REL-113; REL-121. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Permitted global runs are realisable and invalid local combinations are detected under the stated model. Operation: Check that local send/receive behaviours collectively realise the intended global interaction, with explicit asynchronous and information-availability assumptions. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S015; AOSE-S020; AOSE-S037; AOSE-S036; AOSE-S054. critical: AOSE-S036; AOSE-S037; AOSE-S054. empirical or case: AOSE-S054. boundary: Retain a correspondence claim only under the source/target and delivery assumptions actually analysed..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-023

**Name / disposition —** Public commitment semantics for open interaction — CONTEXT_DEPENDENT

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Represent a commitment by debtor, creditor, condition and consequent; track its lifecycle from public evidence while allowing each party private implementation choices.

**Trigger —** Independent parties need accountable interaction without access to one another’s internal beliefs.

**Required inputs —** property inputs: EAOSE-003; EAOSE-005; EAOSE-020. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Observable messages need not establish actual delivery; commitments do not compel compliance or settle contested institutions..

**Produced constraints / evidence —** criterion: Parties can contest or establish fulfilment from agreed public events rather than alleged private intention.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Protocol designers, implementers and the principals participating in an interaction. boundary: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning..

**Cost / assumption failure —** Observable messages need not establish actual delivery; commitments do not compel compliance or settle contested institutions.

**Substitution / omission / retirement —** A conventional explicit service agreement may suffice; closed cooperative internals need not use commitments. A conventional explicit service agreement may suffice; closed cooperative internals need not use commitments.

**Conflicts and relation references —** conflict or alternative ids: REL-010; REL-222. all relation ids: REL-007; REL-010; REL-032; REL-067; REL-068; REL-069; REL-161; REL-195; REL-201; REL-222. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Parties can contest or establish fulfilment from agreed public events rather than alleged private intention. Operation: Represent a commitment by debtor, creditor, condition and consequent; track its lifecycle from public evidence while allowing each party private implementation choices. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S021; AOSE-S037; AOSE-S045. critical: AOSE-S021; AOSE-S037; AOSE-S045. empirical or case: AOSE-S045. boundary: Retain public commitments where independently controlled participants need meaningful public obligations; a simple closed call may not need this machinery..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-024

**Name / disposition —** Private mental states as the basis of communication compliance — CONTESTED

**Kind / lineage class —** SEMANTIC_ALTERNATIVE; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Use mental-state semantics to reason about specified cooperative agents, but do not infer publicly enforceable compliance from inaccessible or untrusted private beliefs.

**Trigger —** The claimed meaning of a message depends on beliefs or intentions attributed to its sender.

**Required inputs —** property inputs: EAOSE-020; EAOSE-023. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Singh’s objection targets open compliance; it does not show that BDI reasoning inside a controlled agent is useless..

**Produced constraints / evidence —** criterion: The communication claim states whether private-state assumptions are checked, stipulated or unavailable.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Protocol designers, implementers and the principals participating in an interaction. boundary: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning..

**Cost / assumption failure —** Singh’s objection targets open compliance; it does not show that BDI reasoning inside a controlled agent is useless.

**Substitution / omission / retirement —** Use public commitments or operational interface conditions for heterogeneous open participants. Use public commitments or operational interface conditions for heterogeneous open participants.

**Conflicts and relation references —** conflict or alternative ids: REL-010; REL-222. all relation ids: REL-010; REL-011; REL-070; REL-222. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: The communication claim states whether private-state assumptions are checked, stipulated or unavailable. Operation: Use mental-state semantics to reason about specified cooperative agents, but do not infer publicly enforceable compliance from inaccessible or untrusted private beliefs. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S033; AOSE-S012; AOSE-S021. critical: AOSE-S021. empirical or case: None, subject to the stated absence explanation.. boundary: Preserve the contest between private mental-state and public social accounts at the correct boundary. Open compliance is the objection, not internal BDI reasoning itself..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-025

**Name / disposition —** Specified exceptional interaction and recovery — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Treat timeouts, refusals, unavailable services, duplicates and malformed messages as specified outcomes with bounded recovery or escalation, not invisible departures from the happy path.

**Trigger —** Communication or delegated work can fail or be delayed.

**Required inputs —** property inputs: EAOSE-020; EAOSE-021. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Retries can duplicate effects; timeouts do not prove that a remote effect did not occur..

**Produced constraints / evidence —** criterion: An exceptional exchange reaches a known state without fabricating completion.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Protocol designers, implementers and the principals participating in an interaction. boundary: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning..

**Cost / assumption failure —** Retries can duplicate effects; timeouts do not prove that a remote effect did not occur.

**Substitution / omission / retirement —** Use a simple fail-and-report policy where retry or compensation would add risk. Use a simple fail-and-report policy where retry or compensation would add risk.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-007; REL-024; REL-071; REL-072; REL-075; REL-130; REL-138; REL-162; REL-202; REL-217. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: An exceptional exchange reaches a known state without fabricating completion. Operation: Treat timeouts, refusals, unavailable services, duplicates and malformed messages as specified outcomes with bounded recovery or escalation, not invisible departures from the happy path. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S015; AOSE-S039; AOSE-S035; AOSE-S050. critical: None, subject to the stated absence explanation.. empirical or case: AOSE-S035; AOSE-S050. boundary: Retain exceptional outcomes as part of interaction semantics; bounded recovery is not a promise that every failure can be reversed..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-026

**Name / disposition —** Versioned protocol compatibility — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Identify which protocol and interpretation versions peers enact; constrain rollout or supply a checked adapter where supported behaviours or message meaning change.

**Trigger —** Peers may run mixed versions or interfaces evolve independently.

**Required inputs —** property inputs: EAOSE-021; EAOSE-022; EAOSE-025. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. Version labels alone do not prove compatibility; an adapter can preserve fields while changing commitments..

**Produced constraints / evidence —** criterion: A mixed-version interaction is either supported by evidence or explicitly refused.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Protocol designers, implementers and the principals participating in an interaction. boundary: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning..

**Cost / assumption failure —** Version labels alone do not prove compatibility; an adapter can preserve fields while changing commitments.

**Substitution / omission / retirement —** An atomic coordinated upgrade can avoid a permanent compatibility layer. An atomic coordinated upgrade can avoid a permanent compatibility layer.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-073; REL-074; REL-075; REL-141. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A mixed-version interaction is either supported by evidence or explicitly refused. Operation: Identify which protocol and interpretation versions peers enact; constrain rollout or supply a checked adapter where supported behaviours or message meaning change. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S029; AOSE-S036; AOSE-S043. critical: AOSE-S036. empirical or case: None, subject to the stated absence explanation.. boundary: Retain version compatibility as an explicitly analytical lifecycle translation of interaction and deployment requirements, not an original universal AOSE standard..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-027

**Name / disposition —** FIPA message compliance guarantees full interoperability — REJECTED_OR_DISFAVOURED

**Kind / lineage class —** OVERGENERALISATION; ADVERSARIAL_GENERALISATION_TEST; not necessarily asserted by the cited authors

**Mechanism —** Reject the inference from conformant message structure to shared domain meaning, protocol behaviour, security or business fulfilment.

**Trigger —** A standards or middleware badge is offered as a complete integration argument.

**Required inputs —** property inputs: EAOSE-020; EAOSE-021. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning. The standard intentionally separates fields and referenced semantics; this rejection does not negate its useful common structure..

**Produced constraints / evidence —** criterion: Standard compliance is reported at the layer it establishes, not as an end-to-end guarantee.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Protocol designers, implementers and the principals participating in an interaction. boundary: Each principal controls its permitted actions; public commitments do not confer control over another participant’s private reasoning..

**Cost / assumption failure —** The standard intentionally separates fields and referenced semantics; this rejection does not negate its useful common structure.

**Substitution / omission / retirement —** Test the actual cross-implementation interaction and resulting effects. Test the actual cross-implementation interaction and resulting effects.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-032. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Standard compliance is reported at the layer it establishes, not as an end-to-end guarantee. Operation: Reject the inference from conformant message structure to shared domain meaning, protocol behaviour, security or business fulfilment. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S043; AOSE-S039; AOSE-S021. critical: AOSE-S021; AOSE-S043. empirical or case: None, subject to the stated absence explanation.. boundary: Reject full interoperability from message structure; the standard’s own limitations and public-meaning distinctions support the narrower judgement..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-028

**Name / disposition —** Select an agent-internal architecture to match the decision problem — CONTEXT_DEPENDENT

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Choose and document BDI, reactive, imperative or another supported internal architecture according to required choice, failure handling and available engineering expertise.

**Trigger —** An agent’s internal decision mechanism is being designed.

**Required inputs —** property inputs: EAOSE-008; EAOSE-010; EAOSE-018. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. A method’s support for BDI does not make BDI obligatory or sufficient for every autonomous component..

**Produced constraints / evidence —** criterion: Internal concepts have an implementation interpretation rather than merely anthropomorphic labels.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Agent designer, programmer and boundary-integration engineer. boundary: May implement approved capabilities; model/code generation does not expand authorised effects..

**Cost / assumption failure —** A method’s support for BDI does not make BDI obligatory or sufficient for every autonomous component.

**Substitution / omission / retirement —** A direct state machine or ordinary behaviour implementation may be sufficient. A direct state machine or ordinary behaviour implementation may be sufficient.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-005; REL-011; REL-012; REL-027; REL-076; REL-077; REL-078; REL-080; REL-082; REL-088; REL-214; REL-221; REL-224. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Internal concepts have an implementation interpretation rather than merely anthropomorphic labels. Operation: Choose and document BDI, reactive, imperative or another supported internal architecture according to required choice, failure handling and available engineering expertise. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S012; AOSE-S007; AOSE-S033; AOSE-S036; AOSE-S041. critical: AOSE-S012. empirical or case: None, subject to the stated absence explanation.. boundary: Retain architecture choice contextually: BDI, imperative/reactive behaviour and ordinary implementation make different commitments..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-029

**Name / disposition —** Percept-to-belief and action-to-effect correspondence — STRONGLY_RETAINED

**Kind / lineage class —** CORRESPONDENCE_OBLIGATION; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Validate the mappings from environmental observations to beliefs and from selected actions to external effects, separately from the correctness of deliberation.

**Trigger —** Correct decisions depend on sensors, tools, actuators or state-estimation assumptions.

**Required inputs —** property inputs: EAOSE-018; EAOSE-028. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. Ground beliefs may be wrong; successful tool return can occur without the intended external consequence..

**Produced constraints / evidence —** criterion: A correct internal belief update or action request is not mistaken for a correct measurement or achieved effect.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Agent designer, programmer and boundary-integration engineer. boundary: May implement approved capabilities; model/code generation does not expand authorised effects..

**Cost / assumption failure —** Ground beliefs may be wrong; successful tool return can occur without the intended external consequence.

**Substitution / omission / retirement —** Direct boundary tests and observable effect checks may suffice. Direct boundary tests and observable effect checks may suffice.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-003; REL-012; REL-079; REL-080; REL-083; REL-090; REL-114; REL-116; REL-118; REL-125; REL-128; REL-134; REL-139; REL-181; REL-183; REL-196; REL-220; REL-221. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A correct internal belief update or action request is not mistaken for a correct measurement or achieved effect. Operation: Validate the mappings from environmental observations to beliefs and from selected actions to external effects, separately from the correctness of deliberation. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S007; AOSE-S012; AOSE-S023; AOSE-S030; AOSE-S031; AOSE-S056; AOSE-S062. critical: AOSE-S012; AOSE-S023; AOSE-S030; AOSE-S062. empirical or case: AOSE-S031; AOSE-S056; AOSE-S062. boundary: Retain grounding strongly. A correct inference from a false belief or a successfully requested but ineffective action cannot establish external achievement..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-030

**Name / disposition —** Plan applicability, achievement and failure conditions — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Make explicit when a plan is applicable, what success means, when it fails or is abandoned and how alternatives are selected; test false-success and inapplicable-plan cases.

**Trigger —** An agent selects among plans or persists with an intention.

**Required inputs —** property inputs: EAOSE-002; EAOSE-028; EAOSE-029. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. Plan libraries can be incomplete and contexts stale; goal persistence can waste resources or conflict with changed needs..

**Produced constraints / evidence —** criterion: A plan is neither selected outside its context nor treated as successful solely because its steps terminated.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Agent designer, programmer and boundary-integration engineer. boundary: May implement approved capabilities; model/code generation does not expand authorised effects..

**Cost / assumption failure —** Plan libraries can be incomplete and contexts stale; goal persistence can waste resources or conflict with changed needs.

**Substitution / omission / retirement —** A single guarded action with a failure result is enough for a simple task. A single guarded action with a failure result is enough for a simple task.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-011; REL-012; REL-023; REL-081; REL-082; REL-083; REL-086; REL-089; REL-122; REL-175; REL-224. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A plan is neither selected outside its context nor treated as successful solely because its steps terminated. Operation: Make explicit when a plan is applicable, what success means, when it fails or is abandoned and how alternatives are selected; test false-success and inapplicable-plan cases. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S007; AOSE-S012; AOSE-S031; AOSE-S049. critical: AOSE-S012; AOSE-S049. empirical or case: AOSE-S031. boundary: Retain explicit applicability and success/failure conditions; termination and success are not synonymous..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-031

**Name / disposition —** Interference among concurrent intentions — ASSUMPTION_SENSITIVE

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Analyse or test resource, belief and goal interference among simultaneously active intentions; state scheduler and environment assumptions.

**Trigger —** Plans overlap in time or manipulate shared state.

**Required inputs —** property inputs: EAOSE-014; EAOSE-018; EAOSE-030. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. Serialisation may miss deadlines; exhaustive interleavings can be infeasible and concurrency models omit physical effects..

**Produced constraints / evidence —** criterion: An individually valid plan cannot silently invalidate another plan’s relied-on preconditions.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Agent designer, programmer and boundary-integration engineer. boundary: May implement approved capabilities; model/code generation does not expand authorised effects..

**Cost / assumption failure —** Serialisation may miss deadlines; exhaustive interleavings can be infeasible and concurrency models omit physical effects.

**Substitution / omission / retirement —** Serialise a small critical region when this preserves required responsiveness. Serialise a small critical region when this preserves required responsiveness.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-012; REL-024; REL-084; REL-085; REL-086; REL-218. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: An individually valid plan cannot silently invalidate another plan’s relied-on preconditions. Operation: Analyse or test resource, belief and goal interference among simultaneously active intentions; state scheduler and environment assumptions. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S012; AOSE-S024; AOSE-S030; AOSE-S054; AOSE-S056. critical: AOSE-S012; AOSE-S024; AOSE-S030; AOSE-S056. empirical or case: AOSE-S054; AOSE-S056. boundary: Retain interference examination under stated scheduler/resource/environment models; complete interleaving coverage may be infeasible..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-032

**Name / disposition —** Semantics-aware model transformation — ASSUMPTION_SENSITIVE

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** State the source and target semantics and the property preserved by a transformation; validate its assumptions and inspect the generated/manual boundary.

**Trigger —** Models generate code, protocol adapters or executable plans.

**Required inputs —** property inputs: EAOSE-022; EAOSE-028; EAOSE-030. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. Correct generation can implement wrong requirements; formal preservation need not cover libraries, deployment or remote services..

**Produced constraints / evidence —** criterion: A transformation claim identifies precisely what preservation has been established.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Agent designer, programmer and boundary-integration engineer. boundary: May implement approved capabilities; model/code generation does not expand authorised effects..

**Cost / assumption failure —** Correct generation can implement wrong requirements; formal preservation need not cover libraries, deployment or remote services.

**Substitution / omission / retirement —** Hand implementation with focused correspondence tests is sufficient where generation has no benefit. Hand implementation with focused correspondence tests is sufficient where generation has no benefit.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-009; REL-013; REL-087; REL-088; REL-089; REL-091; REL-093; REL-097; REL-105; REL-119; REL-176; REL-220. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A transformation claim identifies precisely what preservation has been established. Operation: State the source and target semantics and the property preserved by a transformation; validate its assumptions and inspect the generated/manual boundary. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S018; AOSE-S037; AOSE-S036; AOSE-S049; AOSE-S054. critical: AOSE-S036; AOSE-S037; AOSE-S054. empirical or case: AOSE-S054. boundary: Retain semantics-preserving transformation only for the declared property and mapping, not all stakeholder, platform or environmental claims..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-033

**Name / disposition —** Explicit manual completion and integration duties — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Identify code, environmental bindings, exception handling and tests left to programmers after modelling or generation; assign and review those duties.

**Trigger —** A methodology or tool produces only part of the executable system.

**Required inputs —** property inputs: EAOSE-029; EAOSE-032. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. A checklist can conceal absent implementation expertise; generated percentage is not quality or effort saved..

**Produced constraints / evidence —** criterion: Generated coverage does not cause unimplemented obligations to disappear from acceptance.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Agent designer, programmer and boundary-integration engineer. boundary: May implement approved capabilities; model/code generation does not expand authorised effects..

**Cost / assumption failure —** A checklist can conceal absent implementation expertise; generated percentage is not quality or effort saved.

**Substitution / omission / retirement —** A short generated/manual boundary note is adequate when remaining work is small. A short generated/manual boundary note is adequate when remaining work is small.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-012; REL-090; REL-091; REL-094; REL-140; REL-221. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Generated coverage does not cause unimplemented obligations to disappear from acceptance. Operation: Identify code, environmental bindings, exception handling and tests left to programmers after modelling or generation; assign and review those duties. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S039; AOSE-S008; AOSE-S007; AOSE-S018; AOSE-S056. critical: AOSE-S008. empirical or case: AOSE-S008; AOSE-S056. boundary: Retain manual completion as real work. Generation percentages neither erase responsibilities nor establish saved effort..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-034

**Name / disposition —** Bidirectional design–implementation traceability — USEFUL_BUT_EASILY_BUREAUCRATISED

**Kind / lineage class —** ENGINEERING_MECHANISM; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Link consequential requirements and design choices to their executable realisations and evidence; follow a defect back to the affected decision as well as forward from a requirement to code.

**Trigger —** Several representations or teams can drift apart during development or change.

**Required inputs —** property inputs: EAOSE-002; EAOSE-032; EAOSE-033. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. Link coverage can be high while meaning is stale; maintaining unused links becomes a cost without a consumer..

**Produced constraints / evidence —** criterion: A changed or failing implementation identifies the relevant claim and responsible decision.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Agent designer, programmer and boundary-integration engineer. boundary: May implement approved capabilities; model/code generation does not expand authorised effects..

**Cost / assumption failure —** Link coverage can be high while meaning is stale; maintaining unused links becomes a cost without a consumer.

**Substitution / omission / retirement —** Stable names, tests and a few explicit links may suffice instead of a trace repository. Stable names, tests and a few explicit links may suffice instead of a trace repository.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-004; REL-014; REL-028; REL-092; REL-093; REL-094; REL-099; REL-123; REL-135; REL-142; REL-146; REL-155. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A changed or failing implementation identifies the relevant claim and responsible decision. Operation: Link consequential requirements and design choices to their executable realisations and evidence; follow a defect back to the affected decision as well as forward from a requirement to code. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S004; AOSE-S018; AOSE-S031; AOSE-S054; AOSE-S059. critical: None, subject to the stated absence explanation.. empirical or case: AOSE-S031; AOSE-S054. boundary: Retain consumer-linked bidirectional traceability but flag bureaucratisation: link completeness without maintained meaning has little assurance value..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-035

**Name / disposition —** Generated syntax establishes behavioural correctness — REJECTED_OR_DISFAVOURED

**Kind / lineage class —** OVERGENERALISATION; ADVERSARIAL_GENERALISATION_TEST; not necessarily asserted by the cited authors

**Mechanism —** Reject syntactic generation or compilation as sufficient proof of protocol, goal, environmental or stakeholder correctness.

**Trigger —** A successful generator or compiler is offered as end-to-end assurance.

**Required inputs —** property inputs: EAOSE-029; EAOSE-032; EAOSE-034. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May implement approved capabilities; model/code generation does not expand authorised effects. This rejection preserves valid bounded transformation theorems; it targets their unwarranted extension..

**Produced constraints / evidence —** criterion: The assurance claim does not exceed the checked semantics.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Agent designer, programmer and boundary-integration engineer. boundary: May implement approved capabilities; model/code generation does not expand authorised effects..

**Cost / assumption failure —** This rejection preserves valid bounded transformation theorems; it targets their unwarranted extension.

**Substitution / omission / retirement —** State its narrower guarantee and test or verify the missing correspondence. State its narrower guarantee and test or verify the missing correspondence.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-013. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: The assurance claim does not exceed the checked semantics. Operation: Reject syntactic generation or compilation as sufficient proof of protocol, goal, environmental or stakeholder correctness. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S037; AOSE-S036; AOSE-S031; AOSE-S054. critical: AOSE-S036; AOSE-S037; AOSE-S054. empirical or case: AOSE-S031; AOSE-S054. boundary: Reject syntax as behavioural assurance, while preserving actual bounded transformation results..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-036

**Name / disposition —** Semantic compatibility of method fragments — ASSUMPTION_SENSITIVE

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Compose fragments through explicit concept, work-product and dependency mappings; check that their actor, goal, role and lifecycle assumptions can coexist.

**Trigger —** A tailored method imports guidance or artefacts from different methodologies.

**Required inputs —** property inputs: EAOSE-002; EAOSE-013; EAOSE-032. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Metamodel compatibility is necessary but not proof that the combined method is feasible, usable or effective..

**Produced constraints / evidence —** criterion: A fragment’s required input has the meaning its producer actually supplies.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Method engineer or team accountable for the actual work-product consumers. boundary: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations..

**Cost / assumption failure —** Metamodel compatibility is necessary but not proof that the combined method is feasible, usable or effective.

**Substitution / omission / retirement —** Use one coherent lightweight method where its scope suffices. Use one coherent lightweight method where its scope suffices.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-015; REL-095; REL-096; REL-097; REL-098; REL-101; REL-106; REL-108; REL-208. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A fragment’s required input has the meaning its producer actually supplies. Operation: Compose fragments through explicit concept, work-product and dependency mappings; check that their actor, goal, role and lifecycle assumptions can coexist. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S003; AOSE-S009; AOSE-S017; AOSE-S008; AOSE-S022. critical: AOSE-S003; AOSE-S008; AOSE-S017. empirical or case: AOSE-S008. boundary: Retain fragment composition conditional on semantic and operational fit; compatible metamodels are necessary in some compositions but insufficient for success..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-037

**Name / disposition —** Executable prescriptions and work-product consumers — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Define who performs each method task, with which inputs, what decision or work product it yields and who consumes it; treat a named lifecycle phase as insufficient guidance.

**Trigger —** A method claims to support an engineering concern.

**Required inputs —** property inputs: EAOSE-036. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Detailed instructions can be wrong for the context and can suppress expert judgement..

**Produced constraints / evidence —** criterion: Practitioners can execute the prescription and recognise its relevant result.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Method engineer or team accountable for the actual work-product consumers. boundary: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations..

**Cost / assumption failure —** Detailed instructions can be wrong for the context and can suppress expert judgement.

**Substitution / omission / retirement —** A direct decision rule or established team practice is enough if it supplies the needed result. A direct decision rule or established team practice is enough if it supplies the needed result.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-015; REL-098; REL-100; REL-102. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Practitioners can execute the prescription and recognise its relevant result. Operation: Define who performs each method task, with which inputs, what decision or work product it yields and who consumes it; treat a named lifecycle phase as insufficient guidance. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S003; AOSE-S017; AOSE-S046; AOSE-S033. critical: AOSE-S003; AOSE-S017; AOSE-S046. empirical or case: None, subject to the stated absence explanation.. boundary: Retain usable decision prescriptions and consumers, not maximal procedural detail or replacement of all expert judgement..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-038

**Name / disposition —** Iterative cross-view feedback rather than mandatory phase order — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Permit implementation, testing and operational evidence to revise earlier models; retain only ordering constraints required by dependencies, not a universal linear lifecycle.

**Trigger —** Later work reveals missing constraints or invalid assumptions.

**Required inputs —** property inputs: EAOSE-034; EAOSE-037. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Unbounded iteration can hide indecision; some safety or contractual prerequisites genuinely must precede action..

**Produced constraints / evidence —** criterion: A counterexample can reach the model or requirement that made it possible.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Method engineer or team accountable for the actual work-product consumers. boundary: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations..

**Cost / assumption failure —** Unbounded iteration can hide indecision; some safety or contractual prerequisites genuinely must precede action.

**Substitution / omission / retirement —** A small stable task may complete in one pass; no artificial iteration count is required. A small stable task may complete in one pass; no artificial iteration count is required.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-004; REL-014; REL-028; REL-099; REL-100; REL-103. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A counterexample can reach the model or requirement that made it possible. Operation: Permit implementation, testing and operational evidence to revise earlier models; retain only ordering constraints required by dependencies, not a universal linear lifecycle. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S007; AOSE-S039; AOSE-S003; AOSE-S008; AOSE-S031; AOSE-S059. critical: AOSE-S003; AOSE-S008. empirical or case: AOSE-S008; AOSE-S031. boundary: Retain feedback and necessary dependency order, not a universal serial lifecycle or a fixed number of iterations..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-039

**Name / disposition —** Proportional method assembly and retirement — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Select, simplify or retire artefacts and tasks according to a live failure risk, consumer and dependency; preserve the protected obligation when replacing the machinery.

**Trigger —** A method is tailored, becomes costly or contains work with no current decision use.

**Required inputs —** property inputs: EAOSE-036; EAOSE-037; EAOSE-038. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Rarely used preventive controls can still matter; apparent lack of use is not sufficient retirement evidence..

**Produced constraints / evidence —** criterion: Every retained task has a live function and every removed task leaves no unaddressed relied-on obligation.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Method engineer or team accountable for the actual work-product consumers. boundary: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations..

**Cost / assumption failure —** Rarely used preventive controls can still matter; apparent lack of use is not sufficient retirement evidence.

**Substitution / omission / retirement —** Omit unused machinery; retain a smaller evidence or coordination mechanism when adequate. Omit unused machinery; retain a smaller evidence or coordination mechanism when adequate.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-005; REL-015; REL-016; REL-101; REL-102; REL-103; REL-109. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Every retained task has a live function and every removed task leaves no unaddressed relied-on obligation. Operation: Select, simplify or retire artefacts and tasks according to a live failure risk, consumer and dependency; preserve the protected obligation when replacing the machinery. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S008; AOSE-S003; AOSE-S017; AOSE-S046; AOSE-S060. critical: AOSE-S003; AOSE-S008; AOSE-S017; AOSE-S046. empirical or case: AOSE-S008. boundary: Retain selection, simplification and retirement as one proportional tailoring mechanism. A rare-event control may still have a live function..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-040

**Name / disposition —** Context-checked pattern reuse — CONTEXT_DEPENDENT

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Reuse an interaction, knowledge or implementation pattern only after checking its role, environment and semantic assumptions; retain the obligation to validate the instantiated result.

**Trigger —** A prior fragment appears to solve a recurring design problem.

**Required inputs —** property inputs: EAOSE-021; EAOSE-032; EAOSE-036. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Reuse can carry hidden platform assumptions or obsolete constraints; reusable code quantity does not measure net engineering benefit..

**Produced constraints / evidence —** criterion: The reused pattern has an explicit applicability argument and tested adaptation points.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Method engineer or team accountable for the actual work-product consumers. boundary: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations..

**Cost / assumption failure —** Reuse can carry hidden platform assumptions or obsolete constraints; reusable code quantity does not measure net engineering benefit.

**Substitution / omission / retirement —** Implement the small local behaviour directly when adaptation costs exceed reuse benefit. Implement the small local behaviour directly when adaptation costs exceed reuse benefit.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-027; REL-104; REL-105; REL-106; REL-215. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: The reused pattern has an explicit applicability argument and tested adaptation points. Operation: Reuse an interaction, knowledge or implementation pattern only after checking its role, environment and semantic assumptions; retain the obligation to validate the instantiated result. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S039; AOSE-S008; AOSE-S045; AOSE-S041; AOSE-S062. critical: AOSE-S008; AOSE-S062. empirical or case: AOSE-S008; AOSE-S045; AOSE-S062. boundary: Retain reuse only with checked applicability; adaptation may cost more than direct construction..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-041

**Name / disposition —** Learnability and tool-maintenance fit — CONTEXT_DEPENDENT

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Assess whether the intended team can learn, execute and maintain the selected method and toolchain, including manual work and integration with ordinary engineering tools.

**Trigger —** A method’s expressive power is being weighed against practical delivery constraints.

**Required inputs —** property inputs: EAOSE-011; EAOSE-036; EAOSE-039. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Familiar tools can lack required semantics; an old successful tool version does not establish current support..

**Produced constraints / evidence —** criterion: The chosen process has an achievable skills and maintenance burden.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Method engineer or team accountable for the actual work-product consumers. boundary: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations..

**Cost / assumption failure —** Familiar tools can lack required semantics; an old successful tool version does not establish current support.

**Substitution / omission / retirement —** Use a smaller language subset or familiar tooling without claiming it preserves every richer semantic feature. Use a smaller language subset or familiar tooling without claiming it preserves every richer semantic feature.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-107; REL-108; REL-109. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: The chosen process has an achievable skills and maintenance burden. Operation: Assess whether the intended team can learn, execute and maintain the selected method and toolchain, including manual work and integration with ordinary engineering tools. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S002; AOSE-S025; AOSE-S034; AOSE-S046; AOSE-S031; AOSE-S044. critical: AOSE-S002; AOSE-S046. empirical or case: AOSE-S002; AOSE-S031. boundary: Retain local learnability/tool-maintenance assessment, not a popularity ranking or a claim that every old tool is obsolete..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-042

**Name / disposition —** Method quality equals named-phase or diagram count — CEREMONY_NOT_GENERAL_PROPERTY

**Kind / lineage class —** CEREMONIAL_PROXY; ADVERSARIAL_GENERALISATION_TEST; not necessarily asserted by the cited authors

**Mechanism —** Reject counting phases, models or documents as evidence of usable lifecycle coverage; assess prescriptions, consumers, semantics and results instead.

**Trigger —** A methodology comparison rewards labels rather than operative support.

**Required inputs —** property inputs: EAOSE-037; EAOSE-039. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations. Some documents protect genuine coordination; removing them indiscriminately is the opposite error..

**Produced constraints / evidence —** criterion: A smaller coherent method can be selected over a larger checklist.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Method engineer or team accountable for the actual work-product consumers. boundary: Can tailor process machinery only while preserving live requirements, coordination and assurance obligations..

**Cost / assumption failure —** Some documents protect genuine coordination; removing them indiscriminately is the opposite error.

**Substitution / omission / retirement —** Test one consequential engineering task against the proposed method. Test one consequential engineering task against the proposed method.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-016. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A smaller coherent method can be selected over a larger checklist. Operation: Reject counting phases, models or documents as evidence of usable lifecycle coverage; assess prescriptions, consumers, semantics and results instead. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S002; AOSE-S046; AOSE-S008. critical: AOSE-S002; AOSE-S008; AOSE-S046. empirical or case: AOSE-S002; AOSE-S008. boundary: Classify phase/diagram counting as ceremony when treated as a general quality property; the artefacts may still perform useful work..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-043

**Name / disposition —** Stakeholder validation is distinct from implementation verification — STRONGLY_RETAINED

**Kind / lineage class —** ASSURANCE_DISTINCTION; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Obtain a judgement that the specified behaviour addresses the relevant needs, in addition to checking that code conforms to the specification.

**Trigger —** A system is proposed for acceptance or material change.

**Required inputs —** property inputs: EAOSE-001; EAOSE-002. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Stakeholders may disagree or miss consequences; participation cannot guarantee correctness..

**Produced constraints / evidence —** criterion: Conformance evidence is not reported as independent validation of stakeholder relevance.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Cost / assumption failure —** Stakeholders may disagree or miss consequences; participation cannot guarantee correctness.

**Substitution / omission / retirement —** A direct demonstration and discussion can validate a small transparent requirement. A direct demonstration and discussion can validate a small transparent requirement.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-003; REL-031; REL-033; REL-110; REL-111; REL-126; REL-197. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Conformance evidence is not reported as independent validation of stakeholder relevance. Operation: Obtain a judgement that the specified behaviour addresses the relevant needs, in addition to checking that code conforms to the specification. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S004; AOSE-S010; AOSE-S031; AOSE-S045; AOSE-S059. critical: AOSE-S031. empirical or case: AOSE-S031; AOSE-S045. boundary: Retain requirements validation versus conformance verification strongly. Neither supplies the other’s predicate..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-044

**Name / disposition —** Assure both individual behaviour and collective outcomes — STRONGLY_RETAINED

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Combine component evidence with tests or analyses of interactions and shared outcomes; retain separate claims for each level.

**Trigger —** Several agents or services jointly realise a requirement.

**Required inputs —** property inputs: EAOSE-014; EAOSE-022; EAOSE-029. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Collective scenarios remain incomplete and can hide strategic or environmental behaviour..

**Produced constraints / evidence —** criterion: Locally passing agents are not assumed to establish a correct system.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Cost / assumption failure —** Collective scenarios remain incomplete and can hide strategic or environmental behaviour.

**Substitution / omission / retirement —** For one non-interacting component, collective assurance is not a separate activity. For one non-interacting component, collective assurance is not a separate activity.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-012; REL-112; REL-113; REL-114; REL-117; REL-131; REL-136; REL-211. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Locally passing agents are not assumed to establish a correct system. Operation: Combine component evidence with tests or analyses of interactions and shared outcomes; retain separate claims for each level. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S039; AOSE-S015; AOSE-S023; AOSE-S050. critical: AOSE-S023. empirical or case: AOSE-S050. boundary: Retain agent/collective assurance separation strongly; local correctness does not settle incompatible joint actions..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-045

**Name / disposition —** Explicit model and environment assumptions for formal assurance — ASSUMPTION_SENSITIVE

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** State the transition model, property, environmental alphabet, fairness or consistency conditions and abstraction boundary attached to a verification result.

**Trigger —** A proof or model-checking result supports acceptance.

**Required inputs —** property inputs: EAOSE-014; EAOSE-029; EAOSE-044. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Proof strength can coexist with poor model validity; environmental events omitted from the alphabet remain uncontrolled..

**Produced constraints / evidence —** criterion: A proof over a finite or abstract model is not presented as a theorem about unrestricted deployment.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Cost / assumption failure —** Proof strength can coexist with poor model validity; environmental events omitted from the alphabet remain uncontrolled.

**Substitution / omission / retirement —** Use bounded tests instead when formalisation costs exceed its decision value, while retaining uncertainty. Use bounded tests instead when formalisation costs exceed its decision value, while retaining uncertainty.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-115; REL-116; REL-117; REL-120; REL-129; REL-156; REL-177; REL-220. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A proof over a finite or abstract model is not presented as a theorem about unrestricted deployment. Operation: State the transition model, property, environmental alphabet, fairness or consistency conditions and abstraction boundary attached to a verification result. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S023; AOSE-S030; AOSE-S037; AOSE-S049. critical: AOSE-S023; AOSE-S030; AOSE-S049. empirical or case: None, subject to the stated absence explanation.. boundary: Retain formal guarantees with model, assumptions and abstraction relation explicit; proofs remain valuable without being inflated into field validation..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-046

**Name / disposition —** Implementation-level decision-code verification — DOMAIN_SPECIFIC

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Verify the executable rational decision component where the language and checker permit it, and separately discharge environment, continuous-control and abstraction obligations.

**Trigger —** Consequential agent decision code has suitable semantics and tractable state space.

**Required inputs —** property inputs: EAOSE-029; EAOSE-032; EAOSE-045. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Native libraries, numerical control, sensors and real-time deployment can remain outside the checker..

**Produced constraints / evidence —** criterion: The abstract-design-to-decision-code gap is reduced without claiming the entire cyber-physical system has been proved.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Cost / assumption failure —** Native libraries, numerical control, sensors and real-time deployment can remain outside the checker.

**Substitution / omission / retirement —** Review, testing and restricted behaviour can be more proportionate for low-risk or unsupported implementations. Review, testing and restricted behaviour can be more proportionate for low-risk or unsupported implementations.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-118; REL-119; REL-120; REL-220; REL-224. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: The abstract-design-to-decision-code gap is reduced without claiming the entire cyber-physical system has been proved. Operation: Verify the executable rational decision component where the language and checker permit it, and separately discharge environment, continuous-control and abstraction obligations. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S023. critical: AOSE-S023. empirical or case: None, subject to the stated absence explanation.. boundary: Retain decision-program verification as a domain-specific assurance technique, not a universal economical prerequisite or a complete environment proof..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-047

**Name / disposition —** Design-to-protocol consistency checks — ASSUMPTION_SENSITIVE

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Check whether the detailed agent design supports the required interactions and whether its local choices violate the protocol constraints.

**Trigger —** Agent design and interaction specification are maintained as separate views.

**Required inputs —** property inputs: EAOSE-022; EAOSE-030; EAOSE-034. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. The inspected design/protocol checker explicitly admits false positives and lacks an unconditional sound-and-complete claim because designs are partial; filtering a discrepancy requires inspecting the omitted plan semantics..

**Produced constraints / evidence —** criterion: Inconsistent design choices are exposed before being mistaken for valid realisations.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Cost / assumption failure —** The inspected design/protocol checker explicitly admits false positives and lacks an unconditional sound-and-complete claim because designs are partial; filtering a discrepancy requires inspecting the omitted plan semantics.

**Substitution / omission / retirement —** A few explicit cross-view scenario checks can be adequate for a small design. A few explicit cross-view scenario checks can be adequate for a small design.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-014; REL-121; REL-122; REL-123. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Inconsistent design choices are exposed before being mistaken for valid realisations. Operation: Check whether the detailed agent design supports the required interactions and whether its local choices violate the protocol constraints. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S054; AOSE-S007; AOSE-S015. critical: AOSE-S054. empirical or case: AOSE-S054. boundary: Retain partial-design consistency analysis as conditional defect location; the inspected checker explicitly prevents an unconditional sound/complete interpretation..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-048

**Name / disposition —** Oracle adequacy and false-success tests — USEFUL_BUT_EASILY_GAMED

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Define what evidence would distinguish success, failure and uncertainty; challenge the oracle with false-success, omitted-condition and mutation cases.

**Trigger —** Autonomous or stochastic behaviour lacks one obvious expected trace.

**Required inputs —** property inputs: EAOSE-002; EAOSE-029; EAOSE-043. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Mutation score, judge agreement and benchmark accuracy can reward proxies; equivalent mutants and incomplete requirements need judgement..

**Produced constraints / evidence —** criterion: A passing test has an interpretable claim boundary and known undetected cases.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Cost / assumption failure —** Mutation score, judge agreement and benchmark accuracy can reward proxies; equivalent mutants and incomplete requirements need judgement.

**Substitution / omission / retirement —** A simple exact assertion is sufficient for deterministic, fully specified output. A simple exact assertion is sufficient for deterministic, fully specified output.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-003; REL-014; REL-033; REL-124; REL-125; REL-126; REL-132; REL-137; REL-143; REL-171; REL-198. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A passing test has an interpretable claim boundary and known undetected cases. Operation: Define what evidence would distinguish success, failure and uncertainty; challenge the oracle with false-success, omitted-condition and mutation cases. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S031; AOSE-S024; AOSE-S048; AOSE-S050; AOSE-S061; AOSE-S062. critical: AOSE-S024; AOSE-S031; AOSE-S050; AOSE-S061; AOSE-S062. empirical or case: AOSE-S031; AOSE-S048; AOSE-S050; AOSE-S061; AOSE-S062. boundary: Retain oracle examination but mark it gameable: a score can be optimised while its intended external meaning is lost..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-049

**Name / disposition —** Simulation-to-deployment validity — ASSUMPTION_SENSITIVE

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Identify which environmental dynamics, workloads and interactions a simulation represents; test material mismatches before transferring its conclusions to deployment.

**Trigger —** Simulation evidence is used for an operational decision.

**Required inputs —** property inputs: EAOSE-018; EAOSE-029; EAOSE-045. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. A richer simulator can still share the designer’s mistaken assumptions and conceal rare or strategic behaviours..

**Produced constraints / evidence —** criterion: The evidence states what was simulated and what remains untested in the real setting.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Cost / assumption failure —** A richer simulator can still share the designer’s mistaken assumptions and conceal rare or strategic behaviours.

**Substitution / omission / retirement —** A small direct field test or conservative restriction can suffice when representative simulation is unavailable. A small direct field test or conservative restriction can suffice when representative simulation is unavailable.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-033; REL-127; REL-128; REL-129; REL-133; REL-212. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: The evidence states what was simulated and what remains untested in the real setting. Operation: Identify which environmental dynamics, workloads and interactions a simulation represents; test material mismatches before transferring its conclusions to deployment. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S012; AOSE-S022; AOSE-S030. critical: AOSE-S012; AOSE-S030. empirical or case: None, subject to the stated absence explanation.. boundary: Retain simulation only with a declared transfer argument; reproducing a model’s behaviour does not establish that model’s environmental assumptions..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-050

**Name / disposition —** Discriminating fault and perturbation testing — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Inject or construct relevant faults at agent, interaction, tool and environment boundaries, compare with a baseline and inspect how errors propagate.

**Trigger —** A known failure class or dependence could invalidate a consequential requirement.

**Required inputs —** property inputs: EAOSE-025; EAOSE-044; EAOSE-048; EAOSE-049. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Synthetic faults are not incidence estimates; stochastic variance and instrumentation overhead can confound effects..

**Produced constraints / evidence —** criterion: The result identifies a controlled perturbation and its observed effect, not merely a final score.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Cost / assumption failure —** Synthetic faults are not incidence estimates; stochastic variance and instrumentation overhead can confound effects.

**Substitution / omission / retirement —** One targeted adverse case is preferable to an undirected stress campaign when it discriminates the decision. One targeted adverse case is preferable to an undirected stress campaign when it discriminates the decision.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-033; REL-130; REL-131; REL-132; REL-133. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: The result identifies a controlled perturbation and its observed effect, not merely a final score. Operation: Inject or construct relevant faults at agent, interaction, tool and environment boundaries, compare with a baseline and inspect how errors propagate. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S031; AOSE-S035; AOSE-S050. critical: AOSE-S031; AOSE-S035; AOSE-S050. empirical or case: AOSE-S031; AOSE-S035; AOSE-S050. boundary: Retain targeted adverse-case tests where consequences warrant them; no finite injected-fault collection is treated as complete coverage..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-051

**Name / disposition —** Runtime observations linked to assurance claims — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Collect observations that can confirm, challenge or suspend specific behavioural claims; distinguish a recorded event from a correct interpretation or achieved outcome.

**Trigger —** Relevant behaviour or assumptions cannot be fully established before deployment.

**Required inputs —** property inputs: EAOSE-029; EAOSE-034; EAOSE-044; EAOSE-048. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Monitoring can miss events, disclose sensitive data or add overhead; a dashboard without response duties is ceremony..

**Produced constraints / evidence —** criterion: A failed observation has a defined consumer and can change an operational or engineering decision.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Cost / assumption failure —** Monitoring can miss events, disclose sensitive data or add overhead; a dashboard without response duties is ceremony.

**Substitution / omission / retirement —** Observe a small set of consequential boundaries rather than logging every internal step. Observe a small set of consequential boundaries rather than logging every internal step.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-003; REL-019; REL-134; REL-135; REL-136; REL-137; REL-147; REL-190. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A failed observation has a defined consumer and can change an operational or engineering decision. Operation: Collect observations that can confirm, challenge or suspend specific behavioural claims; distinguish a recorded event from a correct interpretation or achieved outcome. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S029; AOSE-S035; AOSE-S044; AOSE-S050. critical: AOSE-S035; AOSE-S050. empirical or case: AOSE-S035; AOSE-S050. boundary: Retain observations tied to a claim and response; logs are not omniscience and need not all be collected..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-052

**Name / disposition —** Exhaustive testing guarantees unrestricted autonomous behaviour — REJECTED_OR_DISFAVOURED

**Kind / lineage class —** OVERGENERALISATION; ADVERSARIAL_GENERALISATION_TEST; not necessarily asserted by the cited authors

**Mechanism —** Reject an unrestricted exhaustive-testing guarantee; use tractable scoped verification, representative testing and explicit residual uncertainty instead.

**Trigger —** A demonstration or finite test suite is used to guarantee every autonomous response.

**Required inputs —** property inputs: EAOSE-045; EAOSE-048; EAOSE-049. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. Combinatorial path arguments do not prove every agent untestable; restriction and compositional reasoning can change tractability..

**Produced constraints / evidence —** criterion: Testing claims state their behavioural and environmental scope.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Cost / assumption failure —** Combinatorial path arguments do not prove every agent untestable; restriction and compositional reasoning can change tractability.

**Substitution / omission / retirement —** A finite exhaustive test remains valid for its actually finite, enumerated model. A finite exhaustive test remains valid for its actually finite, enumerated model.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-033. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Testing claims state their behavioural and environmental scope. Operation: Reject an unrestricted exhaustive-testing guarantee; use tractable scoped verification, representative testing and explicit residual uncertainty instead. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S024; AOSE-S030; AOSE-S048. critical: AOSE-S024. empirical or case: AOSE-S048. boundary: Reject unrestricted exhaustive-testing claims, not finite exhaustive checks or bounded model checking within actual assumptions..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-053

**Name / disposition —** Deployment and legacy-integration obligations — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Carry responsibility for configuration, resource access, existing services, operational ownership and failure handling beyond design and code generation.

**Trigger —** An agent application enters an existing operational environment.

**Required inputs —** property inputs: EAOSE-025; EAOSE-029; EAOSE-033. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. Adding an agent middleware layer can increase interoperability and maintenance burden; platform deployment is not service readiness..

**Produced constraints / evidence —** criterion: The deployment has responsible operators and tested integration boundaries rather than only runnable agent code.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Engineers, operators, affected users and authorised change/retirement decision makers. boundary: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules..

**Cost / assumption failure —** Adding an agent middleware layer can increase interoperability and maintenance burden; platform deployment is not service readiness.

**Substitution / omission / retirement —** Reuse an established deployment process and explicit interface contract where adequate. Reuse an established deployment process and explicit interface contract where adequate.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-034; REL-138; REL-139; REL-140; REL-144; REL-163. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: The deployment has responsible operators and tested integration boundaries rather than only runnable agent code. Operation: Carry responsibility for configuration, resource access, existing services, operational ownership and failure handling beyond design and code generation. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S039; AOSE-S026; AOSE-S029; AOSE-S044. critical: AOSE-S029. empirical or case: AOSE-S026. boundary: Retain deployment/interface completion without inventing whole-lifecycle support in each historical method..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-054

**Name / disposition —** Versioned implementation and configuration evidence — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Identify the code, models, tool adapters, dependencies, configuration and evaluation conditions to which an assurance claim applies.

**Trigger —** A result must be reproduced, compared, rolled out or used after a change.

**Required inputs —** property inputs: EAOSE-026; EAOSE-034; EAOSE-048; EAOSE-053. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. External services may change despite stable names; a hash proves identity, not correctness or reproducibility of stochastic output..

**Produced constraints / evidence —** criterion: Evidence can be associated with the actual evaluated configuration rather than an unspecified product name.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Engineers, operators, affected users and authorised change/retirement decision makers. boundary: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules..

**Cost / assumption failure —** External services may change despite stable names; a hash proves identity, not correctness or reproducibility of stochastic output.

**Substitution / omission / retirement —** One build identifier and configuration snapshot can suffice for a small fixed system. One build identifier and configuration snapshot can suffice for a small fixed system.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-017; REL-034; REL-141; REL-142; REL-143; REL-144; REL-148; REL-153; REL-157; REL-172; REL-184; REL-186; REL-191. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Evidence can be associated with the actual evaluated configuration rather than an unspecified product name. Operation: Identify the code, models, tool adapters, dependencies, configuration and evaluation conditions to which an assurance claim applies. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S029; AOSE-S035; AOSE-S036; AOSE-S048; AOSE-S057. critical: AOSE-S029; AOSE-S035; AOSE-S048; AOSE-S057. empirical or case: AOSE-S035; AOSE-S048; AOSE-S057. boundary: Retain a correspondence between evaluated and operated configurations; no particular version-control product is prescribed..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-055

**Name / disposition —** Operational feedback to maintained engineering models — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Route observed failures, changing use and resource constraints to the requirements, role, protocol or plan assumptions that need revision; retain only models with a live maintenance consumer.

**Trigger —** The deployed system behaves differently from its engineering assumptions.

**Required inputs —** property inputs: EAOSE-006; EAOSE-034; EAOSE-051; EAOSE-054. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. Correlational traces do not by themselves establish root cause; automatic synchronisation can overwrite a sound specification with faulty behaviour..

**Produced constraints / evidence —** criterion: Operational lessons can change design and acceptance rather than accumulating as disconnected logs.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Engineers, operators, affected users and authorised change/retirement decision makers. boundary: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules..

**Cost / assumption failure —** Correlational traces do not by themselves establish root cause; automatic synchronisation can overwrite a sound specification with faulty behaviour.

**Substitution / omission / retirement —** A short incident-to-requirement link can replace continuous model synchronisation. A short incident-to-requirement link can replace continuous model synchronisation.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-004; REL-019; REL-034; REL-145; REL-146; REL-147; REL-148; REL-158. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Operational lessons can change design and acceptance rather than accumulating as disconnected logs. Operation: Route observed failures, changing use and resource constraints to the requirements, role, protocol or plan assumptions that need revision; retain only models with a live maintenance consumer. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S029; AOSE-S031; AOSE-S035. critical: AOSE-S029; AOSE-S031; AOSE-S035. empirical or case: AOSE-S031; AOSE-S035. boundary: Retain operational evidence reaching engineering/stakeholder decisions, not a self-contained monitoring ritual..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-056

**Name / disposition —** Authorised evolution within explicit revision boundaries — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Specify which goals, assignments, plans or interfaces may change at runtime, who may approve broader revision and which obligations remain invariant.

**Trigger —** A system adapts or a team changes an autonomous component after acceptance.

**Required inputs —** property inputs: EAOSE-005; EAOSE-006; EAOSE-010; EAOSE-017; EAOSE-054. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. A policy can authorise harmful changes if its own premise is wrong; runtime governance cannot create external consent..

**Produced constraints / evidence —** criterion: Adaptive choice does not silently acquire authority to redefine its own acceptance conditions.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Engineers, operators, affected users and authorised change/retirement decision makers. boundary: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules..

**Cost / assumption failure —** A policy can authorise harmful changes if its own premise is wrong; runtime governance cannot create external consent.

**Substitution / omission / retirement —** Disable dynamic adaptation or require an ordinary reviewed release where that is adequate. Disable dynamic adaptation or require an ordinary reviewed release where that is adequate.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-017; REL-020; REL-034; REL-149; REL-150; REL-151; REL-152; REL-153; REL-159; REL-164; REL-178; REL-182; REL-203. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Adaptive choice does not silently acquire authority to redefine its own acceptance conditions. Operation: Specify which goals, assignments, plans or interfaces may change at runtime, who may approve broader revision and which obligations remain invariant. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S009; AOSE-S016; AOSE-S029; AOSE-S038; AOSE-S057. critical: AOSE-S029; AOSE-S038; AOSE-S057. empirical or case: AOSE-S057. boundary: Retain a distinct revision authority boundary as an analytical lifecycle strengthening; self-application is not self-authorisation..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-057

**Name / disposition —** Selective assurance revalidation after change — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Trace a change to the claims, assumptions and evidence it affects; retain unaffected evidence, narrow conditional claims and re-establish or withdraw those whose justification no longer applies.

**Trigger —** Code, environment, goals, protocols or underlying services change.

**Required inputs —** property inputs: EAOSE-006; EAOSE-034; EAOSE-045; EAOSE-054; EAOSE-055; EAOSE-056. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. Dependency maps can omit indirect effects; indiscriminate reuse and indiscriminate invalidation are both failures..

**Produced constraints / evidence —** criterion: Each relied-on affected claim has an explicit retained, narrowed, reassessed or withdrawn status.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Engineers, operators, affected users and authorised change/retirement decision makers. boundary: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules..

**Cost / assumption failure —** Dependency maps can omit indirect effects; indiscriminate reuse and indiscriminate invalidation are both failures.

**Substitution / omission / retirement —** A direct impact judgement is enough for a small change; unchanged justified claims do not require blanket retesting. A direct impact judgement is enough for a small change; unchanged justified claims do not require blanket retesting.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-017; REL-018; REL-019; REL-020; REL-034; REL-154; REL-155; REL-156; REL-157; REL-158; REL-159; REL-187. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Each relied-on affected claim has an explicit retained, narrowed, reassessed or withdrawn status. Operation: Trace a change to the claims, assumptions and evidence it affects; retain unaffected evidence, narrow conditional claims and re-establish or withdraw those whose justification no longer applies. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S029; AOSE-S031; AOSE-S054; AOSE-S057. critical: AOSE-S029; AOSE-S031; AOSE-S057. empirical or case: AOSE-S031; AOSE-S054; AOSE-S057. boundary: Retain selective revalidation as the operative evidence-continuity mechanism. Preservation, narrowing, reassessment and withdrawal depend on actual change impact..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-058

**Name / disposition —** Retirement preserves or resolves outstanding obligations — CONTEXT_DEPENDENT

**Kind / lineage class —** ENGINEERING_MECHANISM; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Before removing an agent, service or interface, identify unfinished commitments and dependent work; complete, transfer with valid authority, release or explicitly report inability to fulfil them.

**Trigger —** A component, capability or protocol is withdrawn while others may still rely on it.

**Required inputs —** property inputs: EAOSE-003; EAOSE-023; EAOSE-025; EAOSE-053; EAOSE-056. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. Transfer can require another party’s agreement; compensating action may be impossible or inadequate..

**Produced constraints / evidence —** criterion: Retirement does not falsely convert an outstanding obligation into successful completion.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Engineers, operators, affected users and authorised change/retirement decision makers. boundary: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules..

**Cost / assumption failure —** Transfer can require another party’s agreement; compensating action may be impossible or inadequate.

**Substitution / omission / retirement —** Immediate removal is sufficient when there are demonstrably no live obligations or dependencies. Immediate removal is sufficient when there are demonstrably no live obligations or dependencies.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-008; REL-034; REL-160; REL-161; REL-162; REL-163; REL-164; REL-204. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Retirement does not falsely convert an outstanding obligation into successful completion. Operation: Before removing an agent, service or interface, identify unfinished commitments and dependent work; complete, transfer with valid authority, release or explicitly report inability to fulfil them. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S023; AOSE-S037; AOSE-S029; AOSE-S045. critical: AOSE-S029; AOSE-S045. empirical or case: AOSE-S045. boundary: Retain operational retirement contextually and analytically; process termination alone does not discharge ongoing duties..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-059

**Name / disposition —** Design-method support implies a complete operational lifecycle — REJECTED_OR_DISFAVOURED

**Kind / lineage class —** OVERGENERALISATION; ADVERSARIAL_GENERALISATION_TEST; not necessarily asserted by the cited authors

**Mechanism —** Reject extrapolating analysis or code-generation support into deployment, monitoring, maintenance and retirement support without explicit prescriptions and evidence.

**Trigger —** A method is represented as complete because it reaches implementation.

**Required inputs —** property inputs: EAOSE-037; EAOSE-053; EAOSE-055. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules. A method may intentionally have a narrow scope; this is not a failure unless broader coverage is claimed..

**Produced constraints / evidence —** criterion: Lifecycle gaps are stated rather than hidden by a broad methodology name.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Engineers, operators, affected users and authorised change/retirement decision makers. boundary: Implementation adaptation inside an envelope differs from changing goals, permission, external commitments or acceptance rules..

**Cost / assumption failure —** A method may intentionally have a narrow scope; this is not a failure unless broader coverage is claimed.

**Substitution / omission / retirement —** Supplement it with existing operational practices and label the documented import. Supplement it with existing operational practices and label the documented import.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-034. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Lifecycle gaps are stated rather than hidden by a broad methodology name. Operation: Reject extrapolating analysis or code-generation support into deployment, monitoring, maintenance and retirement support without explicit prescriptions and evidence. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S001; AOSE-S002; AOSE-S046; AOSE-S029. critical: AOSE-S029. empirical or case: AOSE-S002. boundary: Reject the inference from good design or code to a completed operational lifecycle..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-060

**Name / disposition —** Separate demonstrated mechanism, deployment and comparative benefit — STRONGLY_RETAINED

**Kind / lineage class —** EVIDENCE_DISTINCTION; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Classify evidence by what its unit and design establish: formal result, illustrative model, implemented prototype, operational use or controlled comparison; do not promote one category into another.

**Trigger —** A method, platform or application is being justified by published evidence.

**Required inputs —** property inputs: None, subject to the stated absence explanation.. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can classify reported evidence and limitations; cannot substitute application counts for causal authorisation or adoption decisions. Overly strict demands for controlled trials can obscure useful field learning; evidence can justify conditional action without proving superiority.. absence reason: This is a boundary/selection inquiry or independently posed candidate; it has no mandatory earlier property in this corpus..

**Produced constraints / evidence —** criterion: A deployed application is not reported as a causal test of an entire named methodology.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Evaluator and reader making a benefit/adoption judgement. boundary: Can classify reported evidence and limitations; cannot substitute application counts for causal authorisation or adoption decisions..

**Cost / assumption failure —** Overly strict demands for controlled trials can obscure useful field learning; evidence can justify conditional action without proving superiority.

**Substitution / omission / retirement —** A short claim–evidence statement is enough for an uncontroversial local choice. A short claim–evidence statement is enough for an uncontroversial local choice.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-021; REL-166; REL-168. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A deployed application is not reported as a causal test of an entire named methodology. Operation: Classify evidence by what its unit and design establish: formal result, illustrative model, implemented prototype, operational use or controlled comparison; do not promote one category into another. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S045; AOSE-S046; AOSE-S061; AOSE-S062. critical: AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S045; AOSE-S061; AOSE-S062. empirical or case: AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S045; AOSE-S061; AOSE-S062. boundary: Retain evidence-role separation strongly: conceptual mechanism, adoption and comparative benefit are different claims..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-061

**Name / disposition —** Cost attribution and source non-independence — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** EVIDENCE_METHOD; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Record comparison units, denominators, training, tool bundles and shared datasets or industrial programmes; separate independent replications from repeated reports of the same case.

**Trigger —** Several studies or large reported gains support a general engineering-benefit claim.

**Required inputs —** property inputs: EAOSE-011; EAOSE-060. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can classify reported evidence and limitations; cannot substitute application counts for causal authorisation or adoption decisions. Missing cost data, selection and publication bias limit both positive and negative generalisation..

**Produced constraints / evidence —** criterion: Reported benefit is bounded by the comparator, setting and dependence structure of the evidence.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Evaluator and reader making a benefit/adoption judgement. boundary: Can classify reported evidence and limitations; cannot substitute application counts for causal authorisation or adoption decisions..

**Cost / assumption failure —** Missing cost data, selection and publication bias limit both positive and negative generalisation.

**Substitution / omission / retirement —** A transparent single-case rationale can support a narrow reversible decision without inventing generality. A transparent single-case rationale can support a narrow reversible decision without inventing generality.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-021; REL-165; REL-166; REL-169; REL-173. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Reported benefit is bounded by the comparator, setting and dependence structure of the evidence. Operation: Record comparison units, denominators, training, tool bundles and shared datasets or industrial programmes; separate independent replications from repeated reports of the same case. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S045; AOSE-S048; AOSE-S061. critical: AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S045; AOSE-S061. empirical or case: AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S045; AOSE-S048; AOSE-S061. boundary: Retain unit, baseline and shared-origin discipline; repeated versions or case descriptions cannot become independent replications..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-062

**Name / disposition —** Whole-method superiority over conventional engineering — UNRESOLVED

**Kind / lineage class —** COMPARATIVE_EFFECTIVENESS_CLAIM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Examine the causal claim that a complete AOSE methodology outperforms competent conventional engineering across relevant lifecycle outcomes; preserve uncertainty because the inspected evidence does not identify that general effect.

**Trigger —** An organisation seeks a general superiority claim rather than a local mechanism or application argument.

**Required inputs —** property inputs: EAOSE-011; EAOSE-060; EAOSE-061. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can classify reported evidence and limitations; cannot substitute application counts for causal authorisation or adoption decisions. Positive vendor cases and fragment experiments are not null evidence, but neither remove confounding or establish representative lifecycle superiority..

**Produced constraints / evidence —** criterion: The frozen corpus distinguishes useful mechanisms from unresolved universal or broad comparative superiority.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Evaluator and reader making a benefit/adoption judgement. boundary: Can classify reported evidence and limitations; cannot substitute application counts for causal authorisation or adoption decisions..

**Cost / assumption failure —** Positive vendor cases and fragment experiments are not null evidence, but neither remove confounding or establish representative lifecycle superiority.

**Substitution / omission / retirement —** Choose a guarded mechanism on a local business case without claiming whole-method dominance. Choose a guarded mechanism on a local business case without claiming whole-method dominance.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-021; REL-167; REL-168; REL-169. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: The frozen corpus distinguishes useful mechanisms from unresolved universal or broad comparative superiority. Operation: Examine the causal claim that a complete AOSE methodology outperforms competent conventional engineering across relevant lifecycle outcomes; preserve uncertainty because the inspected evidence does not identify that general effect. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S045; AOSE-S046; AOSE-S047; AOSE-S048; AOSE-S061; AOSE-S062. critical: AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S045; AOSE-S061; AOSE-S062. empirical or case: AOSE-S002; AOSE-S026; AOSE-S042; AOSE-S045; AOSE-S047; AOSE-S048; AOSE-S061; AOSE-S062. boundary: Keep UNRESOLVED after examining relevant positive, null and critical evidence. The corpus supports use and local results, not a general causal ranking of whole methods..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-063

**Name / disposition —** Popularity, venue participation or framework maturity proves benefit — NO_GENERAL_PROPERTY

**Kind / lineage class —** PROXY_CLAIM; ADVERSARIAL_GENERALISATION_TEST; not necessarily asserted by the cited authors

**Mechanism —** Reject treating adoption proxies, downloads, conference activity or a mature runtime as sufficient evidence that a methodology is effective for a target.

**Trigger —** Visibility or popularity is offered as the decisive outcome measure.

**Required inputs —** property inputs: EAOSE-060; EAOSE-061. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can classify reported evidence and limitations; cannot substitute application counts for causal authorisation or adoption decisions. Low visibility also does not establish uselessness; proprietary adoption and nomenclature changes distort proxies..

**Produced constraints / evidence —** criterion: A popularity fact is not converted into causal engineering effectiveness.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Evaluator and reader making a benefit/adoption judgement. boundary: Can classify reported evidence and limitations; cannot substitute application counts for causal authorisation or adoption decisions..

**Cost / assumption failure —** Low visibility also does not establish uselessness; proprietary adoption and nomenclature changes distort proxies.

**Substitution / omission / retirement —** Use it as a discovery or support-risk signal, then examine the actual capability and costs. Use it as a discovery or support-risk signal, then examine the actual capability and costs.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-021. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A popularity fact is not converted into causal engineering effectiveness. Operation: Reject treating adoption proxies, downloads, conference activity or a mature runtime as sufficient evidence that a methodology is effective for a target. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S025; AOSE-S042; AOSE-S044; AOSE-S005. critical: AOSE-S025; AOSE-S042. empirical or case: AOSE-S042. boundary: Reject a general benefit property from popularity/maturity labels while preserving descriptive adoption information..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-064

**Name / disposition —** Named-method observance as assurance — CEREMONY_NOT_GENERAL_PROPERTY

**Kind / lineage class —** CEREMONIAL_PROXY; ADVERSARIAL_GENERALISATION_TEST; not necessarily asserted by the cited authors

**Mechanism —** Reject conformity to a methodology name as a substitute for satisfying its relevant semantic, evidence and coordination obligations.

**Trigger —** Method compliance is used to close an unresolved engineering question.

**Required inputs —** property inputs: EAOSE-037; EAOSE-039; EAOSE-060. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can classify reported evidence and limitations; cannot substitute application counts for causal authorisation or adoption decisions. A recognised method can aid communication and training; the ceremonial error is substituting its name for its function..

**Produced constraints / evidence —** criterion: A method badge neither authorises action nor proves the resulting system correct.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Evaluator and reader making a benefit/adoption judgement. boundary: Can classify reported evidence and limitations; cannot substitute application counts for causal authorisation or adoption decisions..

**Cost / assumption failure —** A recognised method can aid communication and training; the ceremonial error is substituting its name for its function.

**Substitution / omission / retirement —** Inspect the consequential mechanism directly and accept an adequate unnamed equivalent. Inspect the consequential mechanism directly and accept an adequate unnamed equivalent.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-016. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A method badge neither authorises action nor proves the resulting system correct. Operation: Reject conformity to a methodology name as a substitute for satisfying its relevant semantic, evidence and coordination obligations. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S002; AOSE-S008; AOSE-S046. critical: AOSE-S002; AOSE-S008; AOSE-S046. empirical or case: AOSE-S002; AOSE-S008. boundary: Classify method observance itself as ceremony, not a benefit-producing invariant. Keep whatever evidence/coordination function the observance actually serves..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-065

**Name / disposition —** Documented continuity rather than retrospective rebranding — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** PROVENANCE_CRITERION; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Trace explicit imports of agent, organisation, protocol or programming semantics into modern systems; label shared problems or similar vocabulary as convergence unless transmission is documented.

**Trigger —** A modern agent framework is described as inheriting established AOSE.

**Required inputs —** property inputs: None, subject to the stated absence explanation.. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. A citation proves acquaintance rather than semantic fidelity; absence of explicit citation does not prove independence.. absence reason: This is a boundary/selection inquiry or independently posed candidate; it has no mandatory earlier property in this corpus..

**Produced constraints / evidence —** criterion: Historical inheritance, documented hybridisation and analogy remain distinguishable.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Hybrid-system engineer, operator, task owner and affected principals. boundary: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation..

**Cost / assumption failure —** A citation proves acquaintance rather than semantic fidelity; absence of explicit citation does not prove independence.

**Substitution / omission / retirement —** Describe the actual mechanism without claiming an ancestry that cannot be established. Describe the actual mechanism without claiming an ancestry that cannot be established.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-022. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Historical inheritance, documented hybridisation and analogy remain distinguishable. Operation: Trace explicit imports of agent, organisation, protocol or programming semantics into modern systems; label shared problems or similar vocabulary as convergence unless transmission is documented. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S005; AOSE-S028; AOSE-S036; AOSE-S051; AOSE-S052; AOSE-S056. critical: AOSE-S052; AOSE-S056. empirical or case: AOSE-S056. boundary: Retain explicit documentary continuity tests: some BDI hybrids are documented descendants, while other modern work is convergence or unresolved ancestry..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-066

**Name / disposition —** Cost-aware and repeatable stochastic evaluation — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Evaluate repeated executions with declared model/configuration, task distribution, budget and uncertainty; compare simpler baselines rather than reporting only best-run task success.

**Trigger —** Learned or remote components vary across executions or consume material inference resources.

**Required inputs —** property inputs: EAOSE-011; EAOSE-048; EAOSE-054; EAOSE-061. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. Benchmarks can be contaminated or overfit; model aliases and changing services can defeat exact repeatability..

**Produced constraints / evidence —** criterion: Claims separate task success, variability, cost and generalisation to unseen work.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Hybrid-system engineer, operator, task owner and affected principals. boundary: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation..

**Cost / assumption failure —** Benchmarks can be contaminated or overfit; model aliases and changing services can defeat exact repeatability.

**Substitution / omission / retirement —** An exact deterministic regression is sufficient for a component with no relevant stochasticity. An exact deterministic regression is sufficient for a component with no relevant stochasticity.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-170; REL-171; REL-172; REL-173; REL-188; REL-192. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Claims separate task success, variability, cost and generalisation to unseen work. Operation: Evaluate repeated executions with declared model/configuration, task distribution, budget and uncertainty; compare simpler baselines rather than reporting only best-run task success. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S048; AOSE-S047; AOSE-S050; AOSE-S035; AOSE-S056; AOSE-S061. critical: AOSE-S035; AOSE-S050; AOSE-S056; AOSE-S061. empirical or case: AOSE-S048; AOSE-S047; AOSE-S050; AOSE-S035; AOSE-S056; AOSE-S061. boundary: Retain configuration-linked repeats, cost and appropriate baselines; repeated runs do not repair an invalid oracle or establish real-world prevalence..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-067

**Name / disposition —** Generated plans remain subject to executable constraints — ASSUMPTION_SENSITIVE

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Require generated candidate plans to meet the selected language semantics, applicability and authority constraints before execution; distinguish formal strategy synthesis from language-model suggestion.

**Trigger —** A planner or learned model generates or revises executable behaviour.

**Required inputs —** property inputs: EAOSE-005; EAOSE-030; EAOSE-032; EAOSE-045; EAOSE-056. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. Validation can check only the encoded constraints; learned grounding and environmental action models can remain wrong..

**Produced constraints / evidence —** criterion: Plausible natural-language plans are not treated as executable specifications or accepted proofs.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Hybrid-system engineer, operator, task owner and affected principals. boundary: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation..

**Cost / assumption failure —** Validation can check only the encoded constraints; learned grounding and environmental action models can remain wrong.

**Substitution / omission / retirement —** Keep a verified finite plan library or require manual selection when generation offers no justified benefit. Keep a verified finite plan library or require manual selection when generation offers no justified benefit.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-022; REL-023; REL-174; REL-175; REL-176; REL-177; REL-178; REL-219. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Plausible natural-language plans are not treated as executable specifications or accepted proofs. Operation: Require generated candidate plans to meet the selected language semantics, applicability and authority constraints before execution; distinguish formal strategy synthesis from language-model suggestion. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S049; AOSE-S052; AOSE-S031; AOSE-S037; AOSE-S057; AOSE-S056; AOSE-S062. critical: AOSE-S052; AOSE-S056; AOSE-S057; AOSE-S062. empirical or case: AOSE-S031; AOSE-S057; AOSE-S056; AOSE-S062. boundary: Retain generated-plan constraints under language, capability and context assumptions; syntax and model grading are insufficient by themselves..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-068

**Name / disposition —** Tool authority is enforced outside untrusted generated instructions — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Treat model-generated tool requests and retrieved instructions as proposals crossing a privilege boundary; enforce allowed operations and arguments independently of prompt compliance.

**Trigger —** A learned agent can invoke tools or consume untrusted external content.

**Required inputs —** property inputs: EAOSE-005; EAOSE-010; EAOSE-029; EAOSE-056. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. A narrow authorised call can still be harmful or based on false data; wrappers require their own correctness and threat analysis..

**Produced constraints / evidence —** criterion: Persuasive or injected text cannot itself widen tool permissions.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Hybrid-system engineer, operator, task owner and affected principals. boundary: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation..

**Cost / assumption failure —** A narrow authorised call can still be harmful or based on false data; wrappers require their own correctness and threat analysis.

**Substitution / omission / retirement —** Read-only tools, a narrow deterministic adapter or explicit approval can eliminate unnecessary delegated power. Read-only tools, a narrow deterministic adapter or explicit approval can eliminate unnecessary delegated power.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-022; REL-179; REL-180; REL-181; REL-182; REL-185. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Persuasive or injected text cannot itself widen tool permissions. Operation: Treat model-generated tool requests and retrieved instructions as proposals crossing a privilege boundary; enforce allowed operations and arguments independently of prompt compliance. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S038; AOSE-S053; AOSE-S035. critical: AOSE-S035; AOSE-S038; AOSE-S053. empirical or case: AOSE-S053; AOSE-S035. boundary: Retain authority separation from untrusted prompts/tool data. Behavioural instructions may help, but cannot be the only basis for consequential permissions..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-069

**Name / disposition —** Memory and retrieved-content provenance boundaries — CONTEXT_DEPENDENT

**Kind / lineage class —** ENGINEERING_MECHANISM; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Distinguish instructions, observations and stored interpretations; preserve origin and revision context where later action relies on memory, and prevent recalled content from automatically becoming authority.

**Trigger —** A learned agent reuses prior or externally retrieved information across tasks or sessions.

**Required inputs —** property inputs: EAOSE-029; EAOSE-054; EAOSE-068. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. The inspected evidence is stronger for untrusted tool outputs than for long-term memory governance; privacy, staleness and poisoning need separate validation..

**Produced constraints / evidence —** criterion: A recalled assertion can be checked against its origin and does not silently override a trusted constraint.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Hybrid-system engineer, operator, task owner and affected principals. boundary: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation..

**Cost / assumption failure —** The inspected evidence is stronger for untrusted tool outputs than for long-term memory governance; privacy, staleness and poisoning need separate validation.

**Substitution / omission / retirement —** No persistent memory, or a small typed state record, may be safer and cheaper. No persistent memory, or a small typed state record, may be safer and cheaper.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-183; REL-184; REL-185. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A recalled assertion can be checked against its origin and does not silently override a trusted constraint. Operation: Distinguish instructions, observations and stored interpretations; preserve origin and revision context where later action relies on memory, and prevent recalled content from automatically becoming authority. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S053; AOSE-S050; AOSE-S035; AOSE-S062. critical: AOSE-S035; AOSE-S050; AOSE-S053; AOSE-S062. empirical or case: AOSE-S053; AOSE-S050; AOSE-S035; AOSE-S062. boundary: Retain memory provenance contextually as a modern transfer judgement, not a directly validated universal AOSE memory architecture..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-070

**Name / disposition —** Regression after model, prompt or remote-service changes — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** ENGINEERING_MECHANISM; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Treat material changes to models, prompts, tools and remote dependencies as changes to an evaluated configuration; reassess affected behaviour rather than inheriting old benchmark claims unchanged.

**Trigger —** A learned component or externally controlled dependency is updated.

**Required inputs —** property inputs: EAOSE-054; EAOSE-057; EAOSE-066. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. Providers may not expose meaningful versions; repeat testing reduces but does not eliminate stochastic uncertainty..

**Produced constraints / evidence —** criterion: The assurance statement identifies the configuration actually evaluated and the residual uncertainty of remote drift.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Hybrid-system engineer, operator, task owner and affected principals. boundary: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation..

**Cost / assumption failure —** Providers may not expose meaningful versions; repeat testing reduces but does not eliminate stochastic uncertainty.

**Substitution / omission / retirement —** No blanket rerun when a documented impact analysis shows the relevant behaviour unaffected. No blanket rerun when a documented impact analysis shows the relevant behaviour unaffected.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-022; REL-023; REL-186; REL-187; REL-188. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: The assurance statement identifies the configuration actually evaluated and the residual uncertainty of remote drift. Operation: Treat material changes to models, prompts, tools and remote dependencies as changes to an evaluated configuration; reassess affected behaviour rather than inheriting old benchmark claims unchanged. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S048; AOSE-S035; AOSE-S029; AOSE-S050; AOSE-S057; AOSE-S056. critical: AOSE-S035; AOSE-S050; AOSE-S056; AOSE-S057. empirical or case: AOSE-S048; AOSE-S035; AOSE-S050; AOSE-S057; AOSE-S056. boundary: Retain regression after material remote/model/prompt/interface change, with explicit residual uncertainty when versions or distributions are opaque..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-071

**Name / disposition —** Cross-agent trace correlation for diagnosis — CONTEXT_DEPENDENT

**Kind / lineage class —** ENGINEERING_MECHANISM; CRITICISM_TESTED_EXTRACTION_WITH_EXPLICIT_ANALYTICAL_TRANSLATION

**Mechanism —** Link agent steps, sends/receives, tool calls and model invocations to task and configuration identifiers so an observed failure can be located across boundaries.

**Trigger —** Distributed or stochastic execution obscures where a requirement was lost.

**Required inputs —** property inputs: EAOSE-021; EAOSE-051; EAOSE-054; EAOSE-066. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. Trace completeness, privacy, storage and instrumentation cost matter; missing spans and varying runs can mislead diagnosis..

**Produced constraints / evidence —** criterion: An investigator can relate an outcome to the relevant interaction without treating correlation as a causal proof.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Hybrid-system engineer, operator, task owner and affected principals. boundary: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation..

**Cost / assumption failure —** Trace completeness, privacy, storage and instrumentation cost matter; missing spans and varying runs can mislead diagnosis.

**Substitution / omission / retirement —** A local error report is enough when one component and one direct effect make the failure unambiguous. A local error report is enough when one component and one direct effect make the failure unambiguous.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-019; REL-189; REL-190; REL-191; REL-192. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: An investigator can relate an outcome to the relevant interaction without treating correlation as a causal proof. Operation: Link agent steps, sends/receives, tool calls and model invocations to task and configuration identifiers so an observed failure can be located across boundaries. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S035; AOSE-S050. critical: AOSE-S035; AOSE-S050. empirical or case: AOSE-S035; AOSE-S050. boundary: Retain correlated tracing where distributed diagnosis needs it; it does not itself establish causation or justify maximal data retention..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-072

**Name / disposition —** A role prompt is a formal role contract — REJECTED_OR_DISFAVOURED

**Kind / lineage class —** FALSE_EQUIVALENCE; ADVERSARIAL_GENERALISATION_TEST; not necessarily asserted by the cited authors

**Mechanism —** Reject identifying a natural-language role instruction with an enforced role model, authority boundary or verified interaction specification.

**Trigger —** Prompt text is offered as sufficient organisational or safety assurance.

**Required inputs —** property inputs: EAOSE-013; EAOSE-015; EAOSE-020; EAOSE-068. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. A prompt can still usefully guide behaviour; the rejected claim is semantic and assurance equivalence..

**Produced constraints / evidence —** criterion: Role instructions are classified as behavioural inputs, with separately established enforcement and evidence.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Hybrid-system engineer, operator, task owner and affected principals. boundary: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation..

**Cost / assumption failure —** A prompt can still usefully guide behaviour; the rejected claim is semantic and assurance equivalence.

**Substitution / omission / retirement —** Use a small explicit contract and independent permission/test boundary when consequences warrant it. Use a small explicit contract and independent permission/test boundary when consequences warrant it.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-032. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Role instructions are classified as behavioural inputs, with separately established enforcement and evidence. Operation: Reject identifying a natural-language role instruction with an enforced role model, authority boundary or verified interaction specification. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S001; AOSE-S013; AOSE-S036; AOSE-S050; AOSE-S053. critical: AOSE-S050; AOSE-S053. empirical or case: AOSE-S050; AOSE-S053. boundary: Reject equivalence between a role prompt and a formally interpreted/enforced role contract; do not deny the prompt’s narrower behavioural usefulness..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-073

**Name / disposition —** Criterion–authority–effect coupling — RETAINED_IN_EVOLVED_FORM

**Kind / lineage class —** COMPOSITION_INDUCED_MECHANISM; ANALYTICAL_WITHIN_TRADITION_COMPOSITION

**Mechanism —** Join requirement relevance, permitted action and evidence of consequence at the same consequential decision; a defect in any view can block or reopen conclusions in the others. Before acting, distinguish warranted predictions and authorised experiments from the observations required for subsequent outcome acceptance; uncertainty is not silently converted into success.

**Trigger —** Separate correct-looking goal, permission and outcome judgements can jointly admit an unjustified action or acceptance.

**Required inputs —** property inputs: EAOSE-002; EAOSE-005; EAOSE-023; EAOSE-029; EAOSE-043; EAOSE-048. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power. The relation is an analytical engineering constraint, not a new academic theorem or automatic causal-attribution mechanism; complete evidence may be unavailable..

**Produced constraints / evidence —** criterion: No goal, permission or observed benefit substitutes for either of the other two; a counterexample propagates to the affected decision.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: The actual consumer of the consequential engineering or operational decision. boundary: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power..

**Cost / assumption failure —** The relation is an analytical engineering constraint, not a new academic theorem or automatic causal-attribution mechanism; complete evidence may be unavailable.

**Substitution / omission / retirement —** One direct contract and result check suffice when all three distinctions are already coupled transparently. One direct contract and result check suffice when all three distinctions are already coupled transparently.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-001; REL-002; REL-003; REL-004; REL-028; REL-193; REL-194; REL-195; REL-196; REL-197; REL-198; REL-205. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: No goal, permission or observed benefit substitutes for either of the other two; a counterexample propagates to the affected decision. Operation: Join requirement relevance, permitted action and evidence of consequence at the same consequential decision; a defect in any view can block or reopen conclusions in the others. Before acting, distinguish warranted predictions and authorised experiments from the observations required for subsequent outcome acceptance; uncertainty is not silently converted into success. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S004; AOSE-S038; AOSE-S021; AOSE-S031; AOSE-S037; AOSE-S059; AOSE-S060. critical: AOSE-S004; AOSE-S021; AOSE-S031; AOSE-S037; AOSE-S038; AOSE-S059. empirical or case: AOSE-S031. boundary: Retain as distinct analytical composition because cross-view contradiction changes the same consequential decision; three independently stored judgements do not ensure this operation..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-074

**Name / disposition —** Evidence continuity through change as a separate new property — DUPLICATE_CANDIDATE

**Kind / lineage class —** COMPOSITION_CANDIDATE; DUPLICATE_ANALYTICAL_CANDIDATE

**Mechanism —** The useful retain/narrow/reassess/withdraw mechanism is already captured by selective assurance revalidation in EAOSE-057; preserve this proposal as a duplicate rather than inventing an additional control.

**Trigger —** The ancestry label is proposed as another independent property.

**Required inputs —** property inputs: EAOSE-057. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power. No inspected evidence establishes a distinct trigger or additional operation beyond the strengthened change-impact mechanism..

**Produced constraints / evidence —** criterion: Evidence continuity is retained without double-counting the mechanism or its burden.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: The actual consumer of the consequential engineering or operational decision. boundary: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power..

**Cost / assumption failure —** No inspected evidence establishes a distinct trigger or additional operation beyond the strengthened change-impact mechanism.

**Substitution / omission / retirement —** Use the same claim–dependency analysis and evidence record as EAOSE-057. Use the same claim–dependency analysis and evidence record as EAOSE-057.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-018. duplicate or supersession: property ids: EAOSE-057. explanation: Keep the ancestry proposal as a duplicate of EAOSE-057. No additional trigger, operation or independent consumer was found beyond selective revalidation...

**Criteria versus operation —** Criterion: Evidence continuity is retained without double-counting the mechanism or its burden. Operation: The useful retain/narrow/reassess/withdraw mechanism is already captured by selective assurance revalidation in EAOSE-057; preserve this proposal as a duplicate rather than inventing an additional control. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S029; AOSE-S031; AOSE-S054. critical: AOSE-S029; AOSE-S031. empirical or case: AOSE-S031; AOSE-S054. boundary: Keep the ancestry proposal as a duplicate of EAOSE-057. No additional trigger, operation or independent consumer was found beyond selective revalidation..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-075

**Name / disposition —** Purposeful retirement of method machinery as a separate new property — DUPLICATE_CANDIDATE

**Kind / lineage class —** COMPOSITION_CANDIDATE; DUPLICATE_ANALYTICAL_CANDIDATE

**Mechanism —** The consumer, risk and dependency test for removing method machinery is subsumed by EAOSE-039; preserve retirement as part of tailoring rather than a new mandatory retirement bureaucracy.

**Trigger —** The ancestry label is proposed as an independent composition-induced control.

**Required inputs —** property inputs: EAOSE-039. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power. Retiring operational agents with live commitments is different and remains EAOSE-058; do not collapse these subjects..

**Produced constraints / evidence —** criterion: A preventive control is not removed merely because it is rarely used, and an unused ritual is not kept merely because it is branded.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: The actual consumer of the consequential engineering or operational decision. boundary: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power..

**Cost / assumption failure —** Retiring operational agents with live commitments is different and remains EAOSE-058; do not collapse these subjects.

**Substitution / omission / retirement —** One proportionality decision can select, substitute or retire the machinery. One proportionality decision can select, substitute or retire the machinery.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-016. duplicate or supersession: property ids: EAOSE-039. explanation: Keep the ancestry proposal as a duplicate of EAOSE-039. Method retirement is one outcome of tailoring; operational agent retirement remains separate...

**Criteria versus operation —** Criterion: A preventive control is not removed merely because it is rarely used, and an unused ritual is not kept merely because it is branded. Operation: The consumer, risk and dependency test for removing method machinery is subsumed by EAOSE-039; preserve retirement as part of tailoring rather than a new mandatory retirement bureaucracy. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S008; AOSE-S003; AOSE-S017; AOSE-S046. critical: AOSE-S003; AOSE-S008; AOSE-S017; AOSE-S046. empirical or case: AOSE-S008. boundary: Keep the ancestry proposal as a duplicate of EAOSE-039. Method retirement is one outcome of tailoring; operational agent retirement remains separate..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-076

**Name / disposition —** Obligation-preserving organisational reconfiguration — CONTEXT_DEPENDENT

**Kind / lineage class —** COMPOSITION_INDUCED_MECHANISM; ANALYTICAL_WITHIN_TRADITION_COMPOSITION

**Mechanism —** At a role reassignment, reconcile outstanding public obligations with capability, authority and protocol state; retain, validly transfer, release, compensate or report inability instead of silently orphaning the obligation.

**Trigger —** An adaptive organisation changes role holders while interactions or commitments remain live.

**Required inputs —** property inputs: EAOSE-015; EAOSE-017; EAOSE-023; EAOSE-025; EAOSE-056; EAOSE-058; EAOSE-073. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power. This interaction obligation is an analytical synthesis, not a demonstrated general implementation; consent, partial observation and irreversible effects can block safe transfer..

**Produced constraints / evidence —** criterion: A structurally valid new organisation does not erase the commitments created by its predecessor configuration.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: The actual consumer of the consequential engineering or operational decision. boundary: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power..

**Cost / assumption failure —** This interaction obligation is an analytical synthesis, not a demonstrated general implementation; consent, partial observation and irreversible effects can block safe transfer.

**Substitution / omission / retirement —** Drain in-flight work before reconfiguration, or retain a static assignment when continuity cannot be established. Drain in-flight work before reconfiguration, or retain a static assignment when continuity cannot be established.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-007; REL-008; REL-199; REL-200; REL-201; REL-202; REL-203; REL-204; REL-205. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A structurally valid new organisation does not erase the commitments created by its predecessor configuration. Operation: At a role reassignment, reconcile outstanding public obligations with capability, authority and protocol state; retain, validly transfer, release, compensate or report inability instead of silently orphaning the obligation. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S016; AOSE-S009; AOSE-S021; AOSE-S037; AOSE-S045. critical: AOSE-S009; AOSE-S016; AOSE-S021; AOSE-S037; AOSE-S045. empirical or case: AOSE-S045. boundary: Retain contextually as a new analytical composition obligation: feasible role assignment plus valid protocol components can still orphan predecessor obligations..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-077

**Name / disposition —** Hierarchical organisational decomposition — DOMAIN_SPECIFIC

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Use explicitly modelled nested organisations and service/interaction boundaries when the problem is sufficiently nearly decomposable; preserve constraints across levels.

**Trigger —** A system’s structure and coordination genuinely benefit from hierarchical or holonic decomposition.

**Required inputs —** property inputs: EAOSE-013; EAOSE-016; EAOSE-036. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. ASPECS hierarchy is not a universal architecture; nesting adds abstraction and coordination cost and can misfit dense cross-cutting dependencies..

**Produced constraints / evidence —** criterion: Cross-level obligations and boundaries are represented, not hidden by the hierarchy.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Organisation designer; operators or delegated organisational controller for permitted runtime changes. boundary: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity..

**Cost / assumption failure —** ASPECS hierarchy is not a universal architecture; nesting adds abstraction and coordination cost and can misfit dense cross-cutting dependencies.

**Substitution / omission / retirement —** A flat organisation is sufficient when nesting adds no explanatory or operational value. A flat organisation is sufficient when nesting adds no explanatory or operational value.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-025; REL-206; REL-207; REL-208. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Cross-level obligations and boundaries are represented, not hidden by the hierarchy. Operation: Use explicitly modelled nested organisations and service/interaction boundaries when the problem is sufficiently nearly decomposable; preserve constraints across levels. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S022. critical: AOSE-S022. empirical or case: None, subject to the stated absence explanation.. boundary: Retain hierarchy/holonic decomposition only in its structural domain; flat or cross-cutting systems may not benefit..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-078

**Name / disposition —** Cooperation-driven self-organisation — DOMAIN_SPECIFIC

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** For an AMAS-style problem, identify non-cooperative situations and local behaviours intended to restore cooperative interaction; judge collective adequacy externally rather than assuming a globally prescribed plan.

**Trigger —** The application genuinely needs emergence under poorly specified, changing interactions and meets the cooperative branch assumptions.

**Required inputs —** property inputs: EAOSE-008; EAOSE-018; EAOSE-044; EAOSE-049. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity. Local cooperation cannot be transferred into a universal guarantee of a desired global function; strategic agents or incompatible objectives invalidate the branch..

**Produced constraints / evidence —** criterion: Local adaptation is assessed against an explicit external adequacy judgement and its boundaries.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Organisation designer; operators or delegated organisational controller for permitted runtime changes. boundary: Allocation authority is bounded by actual resources and accepted obligations; membership is not consent or capacity..

**Cost / assumption failure —** Local cooperation cannot be transferred into a universal guarantee of a desired global function; strategic agents or incompatible objectives invalidate the branch.

**Substitution / omission / retirement —** Use known-goal organisation or a central algorithm when the function is already sufficiently specified. Use known-goal organisation or a central algorithm when the function is already sufficiently specified.

**Conflicts and relation references —** conflict or alternative ids: REL-026; REL-223. all relation ids: REL-026; REL-209; REL-210; REL-211; REL-212; REL-223. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Local adaptation is assessed against an explicit external adequacy judgement and its boundaries. Operation: For an AMAS-style problem, identify non-cooperative situations and local behaviours intended to restore cooperative interaction; judge collective adequacy externally rather than assuming a globally prescribed plan. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S040; AOSE-S016. critical: AOSE-S016; AOSE-S040. empirical or case: None, subject to the stated absence explanation.. boundary: Retain cooperative self-organisation only under its AMAS-style premises and external adequacy test; not as guaranteed emergence of any desired global function..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-079

**Name / disposition —** Knowledge and task modelling as distinct engineering views — CONTEXT_DEPENDENT

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Distinguish domain knowledge, inference structure, task control and problem-solving methods, then bind them to agent capabilities and interfaces.

**Trigger —** Knowledge-intensive reasoning is difficult to engineer as undifferentiated code or beliefs.

**Required inputs —** property inputs: EAOSE-002; EAOSE-028; EAOSE-040. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them. Knowledge acquisition and multiple views can be expensive; task labels do not validate the knowledge or algorithm..

**Produced constraints / evidence —** criterion: Reusable inference patterns have an explicit task and domain interpretation.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Requirements analyst with affected actors and the legitimate requirements decision maker. boundary: Participants supply needs, exclusions and priorities; software does not acquire permission merely by representing them..

**Cost / assumption failure —** Knowledge acquisition and multiple views can be expensive; task labels do not validate the knowledge or algorithm.

**Substitution / omission / retirement —** A direct typed representation and small algorithm are enough for simple reasoning. A direct typed representation and small algorithm are enough for simple reasoning.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-027; REL-213; REL-214; REL-215. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Reusable inference patterns have an explicit task and domain interpretation. Operation: Distinguish domain knowledge, inference structure, task control and problem-solving methods, then bind them to agent capabilities and interfaces. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S041; AOSE-S018. critical: AOSE-S041. empirical or case: None, subject to the stated absence explanation.. boundary: Retain task/expertise views when knowledge-intensive engineering warrants their acquisition and maintenance cost..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-080

**Name / disposition —** A consistent fragment composition guarantees achievable goals — REJECTED_OR_DISFAVOURED

**Kind / lineage class —** COMPOSITION_OVERCLAIM; ADVERSARIAL_GENERALISATION_TEST; not necessarily asserted by the cited authors

**Mechanism —** Reject the inference from compatible artefact types and coherent models to a feasible, live or effective combined system; examine resources, conflicting constraints and reachable outcomes separately.

**Trigger —** Semantic method integration is presented as automatic system-level adequacy.

**Required inputs —** property inputs: EAOSE-036; EAOSE-044; EAOSE-045. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit. A stronger theorem can establish a bounded guarantee when its actual assumptions hold; the general inference remains invalid..

**Produced constraints / evidence —** criterion: Method compatibility is not silently promoted to joint behavioural or economic success.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Tester, verification engineer and accountable acceptance decision maker. boundary: May establish the precise evidence claim inspected; a checker or score cannot grant acceptance outside its remit..

**Cost / assumption failure —** A stronger theorem can establish a bounded guarantee when its actual assumptions hold; the general inference remains invalid.

**Substitution / omission / retirement —** Use a small feasibility or counterexample check on the actual combined obligations. Use a small feasibility or counterexample check on the actual combined obligations.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-015. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Method compatibility is not silently promoted to joint behavioural or economic success. Operation: Reject the inference from compatible artefact types and coherent models to a feasible, live or effective combined system; examine resources, conflicting constraints and reachable outcomes separately. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S003; AOSE-S009; AOSE-S022; AOSE-S037. critical: AOSE-S003; AOSE-S009; AOSE-S037. empirical or case: None, subject to the stated absence explanation.. boundary: Reject joint success from consistent fragment composition. The capacity counterexample separates semantic compatibility from feasibility..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-081

**Name / disposition —** Counterexample propagation as a distinct new control — DUPLICATE_CANDIDATE

**Kind / lineage class —** COMPOSITION_CANDIDATE; DUPLICATE_ANALYTICAL_CANDIDATE

**Mechanism —** Passing a discovered inconsistency or false-success case back to its requirement is already operative in EAOSE-034, EAOSE-038 and the coupled decision relation EAOSE-073.

**Trigger —** A separate feedback office or artefact is proposed solely to rename these existing loops.

**Required inputs —** property inputs: EAOSE-034; EAOSE-038; EAOSE-073. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power. A link must actually influence the consumer; duplicate disposition does not mean feedback can be omitted..

**Produced constraints / evidence —** criterion: Feedback remains part of the composed system without another independently counted mechanism.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: The actual consumer of the consequential engineering or operational decision. boundary: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power..

**Cost / assumption failure —** A link must actually influence the consumer; duplicate disposition does not mean feedback can be omitted.

**Substitution / omission / retirement —** Reuse the existing test-to-requirement or design-to-protocol link. Reuse the existing test-to-requirement or design-to-protocol link.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-028. duplicate or supersession: property ids: EAOSE-034; EAOSE-038; EAOSE-073. explanation: Keep as a duplicate of existing traceability, iterative feedback and coupled-decision mechanisms, not another office or artefact...

**Criteria versus operation —** Criterion: Feedback remains part of the composed system without another independently counted mechanism. Operation: Passing a discovered inconsistency or false-success case back to its requirement is already operative in EAOSE-034, EAOSE-038 and the coupled decision relation EAOSE-073. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S031; AOSE-S054; AOSE-S004. critical: AOSE-S031. empirical or case: AOSE-S031; AOSE-S054. boundary: Keep as a duplicate of existing traceability, iterative feedback and coupled-decision mechanisms, not another office or artefact..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-082

**Name / disposition —** Observation plus self-revision guarantees improvement — REJECTED_OR_DISFAVOURED

**Kind / lineage class —** COMPOSITION_OVERCLAIM; ADVERSARIAL_GENERALISATION_TEST; not necessarily asserted by the cited authors

**Mechanism —** Reject automatic improvement from coupling monitoring with autonomous revision; observations may be incomplete and local score improvements can degrade external requirements.

**Trigger —** A feedback loop is treated as self-authorising evidence of maturity or eventual correctness.

**Required inputs —** property inputs: EAOSE-048; EAOSE-056; EAOSE-057; EAOSE-073. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power. This is an analytical objection to an inference, not a claim that all adaptation fails or that the cited authors assert automatic improvement..

**Produced constraints / evidence —** criterion: A successor cannot validate its own changed acceptance rule solely by succeeding under that rule.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: The actual consumer of the consequential engineering or operational decision. boundary: Can reject, defer or reopen the decision within legitimate authority; the synthesis itself grants no operative power..

**Cost / assumption failure —** This is an analytical objection to an inference, not a claim that all adaptation fails or that the cited authors assert automatic improvement.

**Substitution / omission / retirement —** Use bounded reviewed changes and a stable acceptance comparison; leave unresolved trade-offs explicit. Use bounded reviewed changes and a stable acceptance comparison; leave unresolved trade-offs explicit.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-020. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: A successor cannot validate its own changed acceptance rule solely by succeeding under that rule. Operation: Reject automatic improvement from coupling monitoring with autonomous revision; observations may be incomplete and local score improvements can degrade external requirements. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S029; AOSE-S035; AOSE-S048; AOSE-S050; AOSE-S057; AOSE-S062. critical: AOSE-S029; AOSE-S035; AOSE-S057; AOSE-S062. empirical or case: AOSE-S035; AOSE-S048; AOSE-S050; AOSE-S057; AOSE-S062. boundary: Reject automatic improvement from observation plus self-revision; the changed-score counterexample defeats the universal inference..

### EVOLVED_AGENT_ORIENTED_SOFTWARE_ENGINEERING::EAOSE-083

**Name / disposition —** Preserve responsiveness during long-running plan generation — CONTEXT_DEPENDENT

**Kind / lineage class —** ENGINEERING_MECHANISM; NATIVE_OR_DOCUMENTED_IMPORT_AS_CLASSIFIED_IN_GENEALOGY

**Mechanism —** Suspend the intention waiting for generated plans rather than the whole agent reasoning loop, where the runtime supports this; preserve the ability to handle unrelated events while a slow or failed generation call is outstanding.

**Trigger —** Remote or computationally slow plan generation threatens the response time of other responsibilities assigned to the same agent.

**Required inputs —** property inputs: EAOSE-010; EAOSE-025; EAOSE-031; EAOSE-067. interpretation: Guarded informational/semantic dependencies, not a mandatory serial pipeline; equivalent adequate inputs may substitute.. other preconditions: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation. Non-blocking scheduling does not ensure hard real-time response, resource fairness or semantic validity of a late result; cancellation and stale-state handling still need design..

**Produced constraints / evidence —** criterion: Waiting for a plan does not by itself disable every unrelated reactive obligation; the wait has an explicit failure or resumption path.. how to examine: Inspect the actual decision/behaviour/evidence at the trigger; challenge it with the candidate criticism and relevant analytical cases. An artefact’s presence alone is not fulfilment..

**Consumer and authority —** actors: Hybrid-system engineer, operator, task owner and affected principals. boundary: Learned components propose or execute only within established delegation; untrusted inputs cannot redefine that delegation..

**Cost / assumption failure —** Non-blocking scheduling does not ensure hard real-time response, resource fairness or semantic validity of a late result; cancellation and stale-state handling still need design.

**Substitution / omission / retirement —** Use a prewritten plan or synchronous execution when no concurrent response obligation exists and the delay is acceptable. Use a prewritten plan or synchronous execution when no concurrent response obligation exists and the delay is acceptable.

**Conflicts and relation references —** conflict or alternative ids: None, subject to the stated absence explanation.. all relation ids: REL-023; REL-024; REL-216; REL-217; REL-218; REL-219. duplicate or supersession: property ids: None, subject to the stated absence explanation.. explanation: No exact duplicate or supersession is adjudicated for this candidate; overlap alone is not identity...

**Criteria versus operation —** Criterion: Waiting for a plan does not by itself disable every unrelated reactive obligation; the wait has an explicit failure or resumption path. Operation: Suspend the intention waiting for generated plans rather than the whole agent reasoning loop, where the runtime supports this; preserve the ability to handle unrelated events while a slow or failed generation call is outstanding. The criterion does not itself authorise action, and enacted operation does not itself prove the effect.

**Evidence / source IDs —** primary: AOSE-S056; AOSE-S035. critical: AOSE-S035; AOSE-S056. empirical or case: AOSE-S056; AOSE-S035. boundary: Retain contextually as a newly examined native mechanism from current BDI generation work. Isolating a wait is distinct from concurrency correctness and does not guarantee deadlines..

## Preservation and later authority

The independent lane is ready as an external research input, not as a target adoption decision. A later crosswalk must be a new artefact with its own evidence, scope and authority. It may share implementations, decline inapplicable mechanisms, prefer cheaper sufficient alternatives or identify genuinely new interaction obligations. It must preserve this freeze’s denominator, source identities, criticism and uncertainty. No cross-trifecta synthesis has been performed here.
