# Agent-Oriented Software Engineering: public-documentation intake

Revision `EAOSE-2026-09-07-R1` · research cut-off `2026-09-07`.

## Introduction to the established tradition

Agent-Oriented Software Engineering (AOSE) studies how engineers use agents and their interactions as abstractions for requirements, analysis, design, construction and evaluation. Its history draws on agent-oriented programming, object-oriented and knowledge-based engineering, goal/actor requirements and distributed interaction. It is not identical to a particular framework or the use of an automated coding assistant. [AOSE-S013; AOSE-S033; AOSE-S055; AOSE-S058]

The field has several material branches rather than one universal method: i*/Tropos emphasises actors, goals and dependencies; Gaia emphasises roles and organisations; MaSE/O-MaSE, Prometheus, PASSI and INGENIAS provide different design/development relationships; Agent OPEN and related work address situational method construction. Interaction, commitment, verification and deployment research examine additional engineering boundaries. The later EMAS community brings several earlier engineering/programming traditions into a shared research setting. This institutional continuity is not a claim that every current agent framework descends directly from a particular methodology. [AOSE-S001; AOSE-S004; AOSE-S007; AOSE-S009; AOSE-S017; AOSE-S018; AOSE-S028; AOSE-S039]

## Evolution under criticism

The recurring criticism is not simply “agents are difficult”. Expressive models can be difficult to learn and maintain; completed diagrams can lack decision guidance; a method can cover design while leaving operating change underspecified; private mental states need not provide public compliance evidence; and a generated implementation can preserve a representation while missing the intended meaning. The source-grounded response is selective: narrower scopes, explicit manual boundaries, semantically compatible method fragments, stronger local analysis, public interaction semantics where useful and operational extensions. These are changes in mechanisms and assumptions, not a claim that each later method is universally better. [AOSE-S002; AOSE-S021; AOSE-S025; AOSE-S029; AOSE-S046; AOSE-S054]

Reported industrial use and some local comparisons establish that agent engineering is more than a purely hypothetical activity. They do not isolate the benefit of an entire named method from teams, platforms, conventional practices or application selection. Modern code-centric comparisons and BDI/LLM prototypes add useful task evidence, but the general whole-method superiority question remains unresolved. [AOSE-S026; AOSE-S042; AOSE-S045; AOSE-S047; AOSE-S061; AOSE-S062]

## The analytical Evolved AOSE composition

“Evolved Agent-Oriented Software Engineering” is this study’s analytical label, not an established school or academic consensus. It combines criticism-tested mechanisms into a conditional engineering system. Its core connects accepted stakeholder purposes, legitimate and feasible action, implementation correspondence and evidence of actual consequences. Requirements, design, implementation, testing and operations can proceed through guarded loops and feedback; the system is not a mandatory serial pipeline.

The smallest coherent form can be modest: an accepted requirement/constraint statement, clear permissions and capabilities, a justified implementation, an adequate result test and a change-impact decision. A conventional workflow or service implementation remains allowed. Agent-oriented analysis does not itself require an agent runtime; this distinction has a direct historical antecedent in Yu’s software-versus-world argument. [AOSE-S060, §§1–3,6]

Two distinct composition mechanisms survive the present analysis. **Criterion–authority–effect coupling** makes a defect in one view consequential for the associated decision in another. **Obligation-preserving organisational reconfiguration** asks what happens to already-incurred duties when role holders or organisations change. These are the researcher’s analytical constructions, tested with explicit counterexamples; they are not independently validated whole methods. Evidence continuity is retained within selective revalidation, and purposeful retirement within proportional method tailoring, rather than multiplied into extra controls.

Before an action, evidence may support a bounded prediction or authorised experiment. After the action, appropriate observations are needed for an outcome claim. The composition does not pretend that future effects can be observed beforehand, that uncertainty forbids all inquiry, or that an internally successful score proves an external result.

## Strongest properties and common caricatures

The strongest distinctions include stakeholder goals versus runtime goals and acceptance criteria; role contracts versus role holders; available capability versus permitted use; model/code correspondence versus compilation; local versus collective assurance; and evidence role versus generalised benefit. These are useful because confusing either side can admit a materially wrong decision. Their practical payoff is conditional on a real trigger, consumer and adequate implementation, not on the presence of a diagram or brand.

Caricatures to reject include “make everything an agent”, “one role means one process”, “a complete goal graph proves that everyone affected was represented”, “generated code proves protocol correctness”, “the standard guarantees interoperability”, “more lifecycle phases means a better method”, and “feedback guarantees improvement”. Rejecting these does not reject agents, documents, standards, formal methods or feedback where they serve actual functions.

## Citation-ready factual claims

Use the following claims at their stated granularity. Source IDs resolve to titles, authors, dates, versions, URLs/DOIs, inspected locators and access limits in the source-table JSON. Do not turn an antecedent or example into a whole-method result.

| Claim ID | Factual claim | Sources | Locator / boundary |
| --- | --- | --- | --- |
| PUB-01 | Shoham’s inspected 1993 paper gives agent-oriented programming a restricted computational formulation; it is not a complete software-engineering lifecycle. | AOSE-S033 | AOP formulation and AGENT0 discussion; AOSE-S011 is a later first-person recollection for the earlier coining claim. |
| PUB-02 | The original Gaia article models roles using responsibilities, permissions, activities and protocols, with an explicitly bounded organisational setting. | AOSE-S001 | §§3–4, 6–7; note 3 for the collective-role case. |
| PUB-03 | Tropos connects actor/goal requirements analysis with later architectural and detailed design concerns. | AOSE-S004 | §§2–5; requirement/design models. |
| PUB-04 | Agent-oriented modelling of actors in the world does not require every represented actor to be implemented as an agent. | AOSE-S060 | §§1–3 and 6. |
| PUB-05 | O-MaSE develops a customisable method using organisational concepts and process fragments, rather than requiring one universal process order. | AOSE-S003; AOSE-S009 | Metamodel/process construction and default-process discussion. |
| PUB-06 | Private mental-state semantics face a public-compliance difficulty in open interaction; social approaches address a different engineering object. | AOSE-S021 | Open systems and social semantics argument. |
| PUB-07 | Decision-code verification and partial design checking have different subjects and assumptions; neither alone validates every deployed environmental premise. | AOSE-S023; AOSE-S054 | Verification model/method and conclusion; partial-design checker §3.4. |
| PUB-08 | The field has reported industrial applications, but application counts and bundled developer reports do not isolate whole-method effects. | AOSE-S026; AOSE-S042 | Industrial application/productivity sections; survey collection and maturity classification. See EV-03/04. |
| PUB-09 | EMAS formed by bringing together AOSE, DALT and ProMAS; that is distinct from AAMAS’s earlier origins. | AOSE-S028; AOSE-S006 | Official history pages. |
| PUB-10 | Some BDI/LLM work explicitly extends existing agent-language/platform mechanisms; this does not establish ancestry for every modern framework. | AOSE-S052; AOSE-S056 | Architecture/integration sections; source 056 §3.2. |
| PUB-11 | The inspected code-centric framework study’s vulnerability metric is labelled Accuracy but defined with a precision-form denominator. | AOSE-S061 | §3.4, Table 3. Do not call it conventional overall accuracy. |
| PUB-12 | The preliminary BDI/LLM report does not show a raw-accuracy gain for its seeded versus non-seeded single-pass comparison. | AOSE-S062 | §7, Table 2; §8 limitations. See EV-16; no general equivalence inferred. |

## Current frontier and evidence limits

Learned and remotely updated components change the engineering obligations around configuration, repeated evaluation, untrusted inputs, plan admissibility and memory. Current primary work supplies implementations, failure categories, benchmarks and small studies. These are useful but heterogeneous. They do not show that a role prompt enforces a formal contract or that generated plans retain every guarantee of a classical agent architecture. [AOSE-S035; AOSE-S048; AOSE-S050; AOSE-S052; AOSE-S053; AOSE-S056; AOSE-S057; AOSE-S062]

Some exact sources are only partially accessible in this corpus: the extended Gaia article, the abridged Agent OPEN appendix, the original 2003 INGENIAS work, the community-roadmap chapter and the reference-work entry. Claims are restricted to their inspected material and are supplemented by distinct accessible primary works, not imaginary missing pages. The source table records those limits. No independent field validation of the present Evolved composition is claimed.

## Suggested page outline

Open with the established field and its problem, then present its plural genealogy. Explain the key engineering distinctions before summarising the major methods. Follow with criticism and documented changes, the conditional composed system, examples and non-trigger cases. End with evidence partitions, current frontiers and the full source/ledger links. Keep the complete 83-candidate denominator accessible; a public introduction is not a substitute for it.

## Claims not to make

Do not invent a founder, origin date, consensus or accepted school for the analytical Evolved label. Do not turn a formal guarantee into an environmental guarantee, a standard into adoption, adoption into benefit, a selected case into a population effect, or a task benchmark into lifecycle superiority. Do not identify the GAIA benchmark with the Gaia methodology. Do not equate popularity with maturity or publication age with abandonment. Do not claim that an unspecified host has adopted or implemented these findings. Do not present the two composition mechanisms as established academic novelty or proven net improvements.

## Publication boundary

This intake is complete as a documentation aid. The frozen research contains 83 examined candidates, including rejected and unresolved claims. It is independent of any host system and remains useful without a later cross-tradition synthesis. Public exposition should preserve that distinction.
