# Evolved-SSS — Later inter-crosswalk intake

Revision `SSS-2026-09-06-r1`. Population: **235 inherited + 0 SSS-induced = 235**.

This is a complete individual-property reading index, not a retained-only export. The matching JSON row is the full machine-readable intake. Its source/authority/evidence/criticism and relation indices must travel together. Full exact original records and frozen archive locators are in the constituent register. Crosswalk-worthiness annotations do not filter the denominator. There is no target-owner or adoption decision.

For ESA and ESPLE, the displayed criterion is the explicitly labelled exact mechanism projection because a separate generic criterion field was not present. Domain profiles and original property-specific descriptions remain in the register.

## ESA:ESA-001

**Consequence-bound architectural significance**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Consequential software structures and decisions, at a declared scope rather than a fixed diagram granularity.

**Criterion / operative mechanism:** Identify decisions whose cross-cutting consequences, dependency reach, qualities or change costs justify architectural treatment; state why each is significant rather than relying on job title or diagram level.

**Trigger:** A decision can change a stakeholder outcome beyond its local implementation or would be costly to reverse.

**Non-trigger / cheaper path:** Handle genuinely local, reversible choices within ordinary design and code review; do not create an architectural record for every edit.

**Authority:** Design participants and those accountable for affected product/operating concerns. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Explain the consequential choice and affected interests to the people who decide or bear its consequences; unresolved disagreement remains visible. Specific subject: Consequence-bound architectural significance.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Handle genuinely local, reversible choices within ordinary design and code review; do not create an architectural record for every edit.", "reopening_condition_not_equated_with_retirement": "Reopen classification when the change becomes local/reversible or newly affects external commitments.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S002`, `ESA:ESA-S010`.

**Clusters:** `SSS-K001`. **Tensions:** None. **Directional references:** 15 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/0`.

## ESA:ESA-002

**Stakeholder concerns connected to decisions**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Stakeholder concerns related to system-wide and boundary-level choices.

**Criterion / operative mechanism:** Connect each material concern to an architectural question, a scenario or constraint and the decision that consumes it; expose conflicts and missing participation.

**Trigger:** Different users, maintainers, operators or sponsors bear materially different consequences.

**Non-trigger / cheaper path:** For a small shared-understanding team, discuss the few consequential concerns directly and retain only what later action needs.

**Authority:** Those making trade-offs and those who will bear their consequences; elicitors facilitate rather than acquire unilateral authority. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Explain the consequential choice and affected interests to the people who decide or bear its consequences; unresolved disagreement remains visible. Specific subject: Stakeholder concerns connected to decisions.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "For a small shared-understanding team, discuss the few consequential concerns directly and retain only what later action needs.", "reopening_condition_not_equated_with_retirement": "Reopen when stakeholders, operating conditions or commitments change, or an omitted concern is discovered.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S011`, `ESA:ESA-S017`, `ESA:ESA-S020`, `ESA:ESA-S021`.

**Clusters:** `SSS-K001`, `SSS-K022`, `SSS-K034`. **Tensions:** None. **Directional references:** 51 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/1`.

## ESA:ESA-003

**Architecture, description and belief distinguished**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Intended architecture, architecture description and realised software/configuration as separate referents.

**Criterion / operative mechanism:** Keep intended structure, its representation and claims about the actual system distinguishable; attach a basis and observation scope to assertions of correspondence.

**Trigger:** A decision depends on a diagram, repository model, recovered graph or architect’s account being true of the real system.

**Non-trigger / cheaper path:** Inspect the relevant code/configuration/execution directly when the system is small; a separate comprehensive model is unnecessary.

**Authority:** Implementers, reviewers and operators relying on architectural claims. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Explain the consequential choice and affected interests to the people who decide or bear its consequences; unresolved disagreement remains visible. Specific subject: Architecture, description and belief distinguished.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Inspect the relevant code/configuration/execution directly when the system is small; a separate comprehensive model is unnecessary.", "reopening_condition_not_equated_with_retirement": "Reopen correspondence after configuration, interface, deployment or model changes.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S002`, `ESA:ESA-S011`, `ESA:ESA-S045`, `ESA:ESA-S026`.

**Clusters:** `SSS-K002`, `SSS-K007`, `SSS-K029`. **Tensions:** None. **Directional references:** 62 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/2`.

## ESA:ESA-004

**Conceptual integrity without mandatory centralisation**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** System concepts and cross-component behavioural commitments.

**Criterion / operative mechanism:** Keep the user-visible and developer-facing concepts and essential invariants coherent across decisions, while allowing local variation that does not damage them.

**Trigger:** Independent decisions would expose incompatible meanings or behaviours to common consumers.

**Non-trigger / cheaper path:** Use shared examples and a small vocabulary in one team; do not impose a chief architect or one technology solely to look unified.

**Authority:** People responsible for shared interfaces and product coherence, with local teams retaining bounded design discretion. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Explain the consequential choice and affected interests to the people who decide or bear its consequences; unresolved disagreement remains visible. Specific subject: Conceptual integrity without mandatory centralisation.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use shared examples and a small vocabulary in one team; do not impose a chief architect or one technology solely to look unified.", "reopening_condition_not_equated_with_retirement": "Reopen the shared concept when domains diverge or maintaining uniformity costs more than explicit translation.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S008`, `ESA:ESA-S010`, `ESA:ESA-S025`, `ESA:ESA-S041`, `ESA:ESA-S039`.

**Clusters:** `SSS-K010`, `SSS-K030`. **Tensions:** `SSS-T002`. **Directional references:** 58 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/3`.

## ESA:ESA-005

**Accountable authority for consequential trade-offs**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Consequential decisions and commitments at organisational/software interfaces.

**Criterion / operative mechanism:** Make it clear who can accept a consequential trade-off, who must be consulted and who can execute it; neither identifying a concern nor holding a meeting grants permission to act.

**Trigger:** A change alters commitments or transfers risk/cost across roles, teams or external parties.

**Non-trigger / cheaper path:** Existing role agreements and a direct decision conversation may suffice; do not invent a new approval body.

**Authority:** Trade-off decision makers, implementers and affected consumers; authority is supplied by the real context, not this ledger. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Explain the consequential choice and affected interests to the people who decide or bear its consequences; unresolved disagreement remains visible. Specific subject: Accountable authority for consequential trade-offs.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Existing role agreements and a direct decision conversation may suffice; do not invent a new approval body.", "reopening_condition_not_equated_with_retirement": "Reopen when responsibility, exposure or the original decision mandate changes.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S017`, `ESA:ESA-S020`, `ESA:ESA-S035`, `ESA:ESA-S030`, `ESA:ESA-S031`.

**Clusters:** `SSS-K009`, `SSS-K021`, `SSS-K022`. **Tensions:** None. **Directional references:** 59 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/4`.

## ESA:ESA-006

**Architecture as an unrestricted important-decisions label**

**Disposition:** `NO_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Definitional boundary between architecture and other consequential work.

**Criterion / operative mechanism:** Candidate shorthand groups salient decisions, but without a scope or consequence test it does not determine what architectural work should occur.

**Trigger:** The label is used to claim authority over all important engineering or business matters.

**Non-trigger / cheaper path:** Use the consequence-bound criterion in ESA-001 and state the architectural object.

**Authority:** Researchers and practitioners choosing the scope of an architectural inquiry. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Explain the consequential choice and affected interests to the people who decide or bear its consequences; unresolved disagreement remains visible. Specific subject: Architecture as an unrestricted important-decisions label.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use the consequence-bound criterion in ESA-001 and state the architectural object.", "reopening_condition_not_equated_with_retirement": "Reconsider only with a discriminating definition, not a new slogan.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S002`, `ESA:ESA-S010`.

**Clusters:** `SSS-K001`, `SSS-K027`. **Tensions:** None. **Directional references:** 35 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/5`.

## ESA:ESA-007

**Change-oriented information hiding**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Module responsibilities and design-knowledge boundaries, not deployment units.

**Criterion / operative mechanism:** Place knowledge of a plausibly varying design decision behind an interface whose clients need not depend on that decision; separate stable obligations from hidden choices.

**Trigger:** A likely change currently propagates through clients that need only the stable service or invariant.

**Non-trigger / cheaper path:** Keep a straightforward local implementation where the variation is unlikely or the extra boundary costs more than the expected change.

**Authority:** Module designers and dependent implementers/maintainers. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Producer and consumer exchange the obligations and hidden assumptions that affect composition; communicate changed semantics, not merely changed signatures. Specific subject: Change-oriented information hiding.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Keep a straightforward local implementation where the variation is unlikely or the extra boundary costs more than the expected change.", "reopening_condition_not_equated_with_retirement": "Reopen the boundary when the actual change pattern or performance needs contradict its original rationale.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S001`, `ESA:ESA-S006`, `ESA:ESA-S026`.

**Clusters:** `SSS-K004`, `SSS-K005`, `SSS-K030`. **Tensions:** None. **Directional references:** 72 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/6`.

## ESA:ESA-008

**Semantic interface assumptions made testable**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Semantic contracts at component, service or connector boundaries.

**Criterion / operative mechanism:** Express consequential assumptions about state, control, ordering, data meaning, faults and side effects at the interface; check the assumptions actually relied on by both sides.

**Trigger:** Parts are composed, reused or replaced and nominal signatures do not capture their operating expectations.

**Non-trigger / cheaper path:** Use concrete examples, assertions or focused integration tests for a narrow local interface; a full formal contract is not mandatory.

**Authority:** Both sides of the interface and integration reviewers; no side may silently expand the other’s obligations. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Producer and consumer exchange the obligations and hidden assumptions that affect composition; communicate changed semantics, not merely changed signatures. Specific subject: Semantic interface assumptions made testable.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use concrete examples, assertions or focused integration tests for a narrow local interface; a full formal contract is not mandatory.", "reopening_condition_not_equated_with_retirement": "Reopen on changed error, state, timing or version semantics, even if the signature is unchanged.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S026`, `ESA:ESA-S015`, `ESA:ESA-S035`.

**Clusters:** `SSS-K003`, `SSS-K012`, `SSS-K019`, `SSS-K020`, `SSS-K022`, `SSS-K029`. **Tensions:** `SSS-T005`. **Directional references:** 121 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/7`.

## ESA:ESA-009

**Connectors as explicit interaction mechanisms**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Runtime and logical interaction relations, at the level required by the concern.

**Criterion / operative mechanism:** Model or inspect the actual interaction mechanism—call, event, stream, shared store or protocol—and its control/data consequences instead of treating an arrow as self-explanatory.

**Trigger:** Interaction semantics affect coupling, performance, consistency, failure handling or allowed composition.

**Non-trigger / cheaper path:** Name and test a simple direct call; do not create a connector abstraction or framework when ordinary language captures the needed semantics.

**Authority:** Component authors, protocol designers and integration/operations staff. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Producer and consumer exchange the obligations and hidden assumptions that affect composition; communicate changed semantics, not merely changed signatures. Specific subject: Connectors as explicit interaction mechanisms.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Name and test a simple direct call; do not create a connector abstraction or framework when ordinary language captures the needed semantics.", "reopening_condition_not_equated_with_retirement": "Reopen when transport, synchrony, multiplicity or shared-resource behaviour changes.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S002`, `ESA:ESA-S004`, `ESA:ESA-S015`, `ESA:ESA-S026`.

**Clusters:** `SSS-K003`, `SSS-K013`, `SSS-K019`. **Tensions:** None. **Directional references:** 62 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/8`.

## ESA:ESA-010

**Dependency kinds and uses relations distinguished**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Typed relationships between software responsibilities, runtime units and work items.

**Criterion / operative mechanism:** Distinguish compile/import, invocation, data, correctness, deployment and change dependencies; choose the relation that can answer the architectural question.

**Trigger:** A dependency graph is being used to infer independence, change impact or coordination needs.

**Non-trigger / cheaper path:** Inspect the few relevant dependencies manually; do not build a global graph when a local semantic explanation suffices.

**Authority:** Analysts and engineers making impact or boundary decisions from dependency evidence. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Producer and consumer exchange the obligations and hidden assumptions that affect composition; communicate changed semantics, not merely changed signatures. Specific subject: Dependency kinds and uses relations distinguished.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Inspect the few relevant dependencies manually; do not build a global graph when a local semantic explanation suffices.", "reopening_condition_not_equated_with_retirement": "Reopen when generated code, configuration, shared data or usage introduces a different dependency kind.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S006`, `ESA:ESA-S045`, `ESA:ESA-S031`, `ESA:ESA-S005`, `ESA:ESA-S026`.

**Clusters:** `SSS-K004`. **Tensions:** None. **Directional references:** 31 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/9`.

## ESA:ESA-011

**Demonstrated containment rather than nominal isolation**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Fault, state and change-containment boundaries across components or deployments.

**Criterion / operative mechanism:** Demonstrate the claimed containment property under the relevant fault or change, including shared state, resources and management channels; distinguish naming a boundary from enforcing it.

**Trigger:** A design relies on independent failure, deployment, access or change behaviour.

**Non-trigger / cheaper path:** Do not claim independence where it is unnecessary; a coordinated shared unit can be the simpler honest design.

**Authority:** Engineers and operators relying on independence for a specific quality or change. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Producer and consumer exchange the obligations and hidden assumptions that affect composition; communicate changed semantics, not merely changed signatures. Specific subject: Demonstrated containment rather than nominal isolation.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Do not claim independence where it is unnecessary; a coordinated shared unit can be the simpler honest design.", "reopening_condition_not_equated_with_retirement": "Reopen after a shared dependency, privileged path or workload undermines the containment assumptions.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S026`, `ESA:ESA-S035`, `ESA:ESA-S056`, `ESA:ESA-S054`.

**Clusters:** `SSS-K004`. **Tensions:** None. **Directional references:** 43 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/10`.

## ESA:ESA-012

**Coordination-aware boundary placement**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Logical, team and deployment boundary choices, which need not coincide.

**Criterion / operative mechanism:** Place boundaries by considering change coupling, communication, translation and operation costs together; compare local and distributed alternatives.

**Trigger:** A boundary can reduce change propagation but creates a material coordination or runtime burden.

**Non-trigger / cheaper path:** Keep collaborating responsibilities in a coherent local module/deployment when independent operation has no demonstrated consumer.

**Authority:** Component teams and those accountable for end-to-end delivery and operation. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Producer and consumer exchange the obligations and hidden assumptions that affect composition; communicate changed semantics, not merely changed signatures. Specific subject: Coordination-aware boundary placement.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Keep collaborating responsibilities in a coherent local module/deployment when independent operation has no demonstrated consumer.", "reopening_condition_not_equated_with_retirement": "Reopen when teams, release cadence, scaling or semantic coupling stop matching the boundary rationale.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S001`, `ESA:ESA-S031`, `ESA:ESA-S039`, `ESA:ESA-S026`, `ESA:ESA-S037`, `ESA:ESA-S060`.

**Clusters:** `SSS-K010`, `SSS-K021`, `SSS-K026`. **Tensions:** None. **Directional references:** 62 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/11`.

## ESA:ESA-013

**Commonality and variability within an architectural family**

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Architecture of related program families, shared assets and variation boundaries.

**Criterion / operative mechanism:** Identify common and varying obligations across a genuine set of related systems, then arrange abstractions and uses relations to support required variants or subsets.

**Trigger:** Multiple related products or configurations have known shared structure and deliberate variation.

**Non-trigger / cheaper path:** Build the single required system directly when a family is speculative; defer variation points with no credible consumer.

**Authority:** Family/product architects and developers selecting valid members; economic product-line decisions remain a later interface. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Producer and consumer exchange the obligations and hidden assumptions that affect composition; communicate changed semantics, not merely changed signatures. Specific subject: Commonality and variability within an architectural family.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Build the single required system directly when a family is speculative; defer variation points with no credible consumer.", "reopening_condition_not_equated_with_retirement": "Reopen when a new family member changes commonality or invalidates permitted combinations.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S006`, `ESA:ESA-S064`, `ESA:ESA-S007`, `ESA:ESA-S066`.

**Clusters:** `SSS-K005`, `SSS-K021`, `SSS-K030`. **Tensions:** `SSS-T004`, `SSS-T006`. **Directional references:** 89 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/12`.

## ESA:ESA-014

**Measurable quality-attribute scenarios**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Quality requirements at the system or affected architectural element.

**Criterion / operative mechanism:** Express a quality concern through stimulus, source, environment, affected artefact, response and response measure, tailoring detail to the decision being made.

**Trigger:** A quality term such as fast, secure, usable or modifiable must discriminate between designs.

**Non-trigger / cheaper path:** A short, concrete example with an observable acceptable response can suffice; do not fill six empty boxes ceremonially.

**Authority:** Stakeholders, designers, evaluators and testers consuming a shared condition. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Supply stimuli, environment, responses and limits to designers and evaluators; tell affected stakeholders which scenarios were omitted or traded off. Specific subject: Measurable quality-attribute scenarios.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "A short, concrete example with an observable acceptable response can suffice; do not fill six empty boxes ceremonially.", "reopening_condition_not_equated_with_retirement": "Reopen on changed demand, environment, acceptance criteria or evidence that the measure misses the concern.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S016`, `ESA:ESA-S017`, `ESA:ESA-S061`.

**Clusters:** `SSS-K006`, `SSS-K034`. **Tensions:** None. **Directional references:** 38 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/13`.

## ESA:ESA-015

**Scenario population and selection validity**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Scenario population, sampling and prioritisation at evaluation scope.

**Criterion / operative mechanism:** Examine which users, operating states, changes and adverse cases the scenario set represents; add decision-changing omissions and preserve uncertainty rather than treating prioritisation as completeness.

**Trigger:** An evaluation or design claim depends on a selected set of scenarios.

**Non-trigger / cheaper path:** Use a few explicit favourable, adverse and boundary cases for a small decision, with limits stated; avoid exhaustive catalogues with no consumer.

**Authority:** Evaluators and affected participants, including dissenting or absent-user representatives where warranted. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Supply stimuli, environment, responses and limits to designers and evaluators; tell affected stakeholders which scenarios were omitted or traded off. Specific subject: Scenario population and selection validity.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use a few explicit favourable, adverse and boundary cases for a small decision, with limits stated; avoid exhaustive catalogues with no consumer.", "reopening_condition_not_equated_with_retirement": "Reopen when a new user, failure, workload or change pattern could reverse the decision.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S017`, `ESA:ESA-S020`, `ESA:ESA-S021`, `ESA:ESA-S023`, `ESA:ESA-S060`.

**Clusters:** `SSS-K006`, `SSS-K015`, `SSS-K018`, `SSS-K033`. **Tensions:** `SSS-T016`. **Directional references:** 118 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/14`.

## ESA:ESA-016

**Tactics tied to explanatory quality models**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Architectural tactic acting on performance, availability, security, modifiability or other modelled qualities.

**Criterion / operative mechanism:** Connect a tactic to the model parameters it changes and to the response sought; account for interactions, overhead and assumptions that make the causal explanation plausible.

**Trigger:** A structural or behavioural intervention is proposed to improve a quality attribute.

**Non-trigger / cheaper path:** Use a targeted prototype or direct simplification instead of a tactic taxonomy when it answers the causal question more cheaply.

**Authority:** Designers selecting interventions and evaluators testing their consequences. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Supply stimuli, environment, responses and limits to designers and evaluators; tell affected stakeholders which scenarios were omitted or traded off. Specific subject: Tactics tied to explanatory quality models.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use a targeted prototype or direct simplification instead of a tactic taxonomy when it answers the causal question more cheaply.", "reopening_condition_not_equated_with_retirement": "Reopen when workload, failure independence or model calibration no longer supports the tactic.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S016`, `ESA:ESA-S024`, `ESA:ESA-S026`, `ESA:ESA-S061`.

**Clusters:** `SSS-K006`. **Tensions:** None. **Directional references:** 22 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/15`.

## ESA:ESA-017

**Explicit interacting-quality trade-offs and constraints**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Multi-quality architectural alternatives and external constraints.

**Criterion / operative mechanism:** Separate hard constraints from preferences, compare effects on multiple concerns and make the chosen sacrifice explicit; do not aggregate away unacceptable consequences.

**Trigger:** Improving one response can worsen another or transfer cost to a different stakeholder.

**Non-trigger / cheaper path:** Eliminate dominated or infeasible options through a brief explicit comparison when elaborate utility modelling adds no decision value.

**Authority:** Affected stakeholders and authorised trade-off decision makers. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Supply stimuli, environment, responses and limits to designers and evaluators; tell affected stakeholders which scenarios were omitted or traded off. Specific subject: Explicit interacting-quality trade-offs and constraints.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Eliminate dominated or infeasible options through a brief explicit comparison when elaborate utility modelling adds no decision value.", "reopening_condition_not_equated_with_retirement": "Reopen when a hard limit is violated, a preference changes or a formerly omitted consequence becomes material.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S016`, `ESA:ESA-S020`, `ESA:ESA-S022`, `ESA:ESA-S061`.

**Clusters:** `SSS-K006`, `SSS-K011`, `SSS-K026`, `SSS-K034`. **Tensions:** `SSS-T006`. **Directional references:** 86 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/16`.

## ESA:ESA-018

**Representative workload and failure observations**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Empirical evidence about realised architectural behaviour, not just models.

**Criterion / operative mechanism:** Validate important predictions against observations whose workload, faults, configuration and measurement boundary are representative of the decision; distinguish the measurement from the whole quality claim.

**Trigger:** A prototype, benchmark, trace or field observation is being used to accept an architecture.

**Non-trigger / cheaper path:** Use the smallest representative experiment or inspect existing evidence; do not run a broad benchmark suite unrelated to the risk.

**Authority:** Testers, operators and decision makers relying on measured outcomes. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Supply stimuli, environment, responses and limits to designers and evaluators; tell affected stakeholders which scenarios were omitted or traded off. Specific subject: Representative workload and failure observations.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use the smallest representative experiment or inspect existing evidence; do not run a broad benchmark suite unrelated to the risk.", "reopening_condition_not_equated_with_retirement": "Reopen after load, hardware, dependencies or telemetry changes, or when production contradicts the prediction.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S016`, `ESA:ESA-S020`, `ESA:ESA-S054`, `ESA:ESA-S048`, `ESA:ESA-S061`.

**Clusters:** `SSS-K006`, `SSS-K014`, `SSS-K015`, `SSS-K018`, `SSS-K020`, `SSS-K025`, `SSS-K033`. **Tensions:** None. **Directional references:** 154 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/17`.

## ESA:ESA-019

**Independent maximisation of every quality**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** An inadmissible general optimisation claim over architectural qualities.

**Criterion / operative mechanism:** Independent maximisation ignores interaction and feasibility; it is not retained as an engineering rule.

**Trigger:** A proposal claims every quality improves without defining resource, stakeholder or environmental boundaries.

**Non-trigger / cheaper path:** Use ESA-017 to compare constrained alternatives and identify any genuine dominated option.

**Authority:** Anyone interpreting a multi-quality improvement claim. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Supply stimuli, environment, responses and limits to designers and evaluators; tell affected stakeholders which scenarios were omitted or traded off. Specific subject: Independent maximisation of every quality.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use ESA-017 to compare constrained alternatives and identify any genuine dominated option.", "reopening_condition_not_equated_with_retirement": "Reconsider a local all-better result only with a complete declared comparison and measurement boundary.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S016`, `ESA:ESA-S020`, `ESA:ESA-S022`, `ESA:ESA-S061`.

**Clusters:** `SSS-K006`. **Tensions:** None. **Directional references:** 11 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/18`.

## ESA:ESA-020

**Concern-selected views and viewpoints**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Architecture descriptions and viewpoint conventions at concern-specific abstraction levels.

**Criterion / operative mechanism:** Select viewpoints by the concerns and decisions they enable, then create only the views needed to communicate or analyse those concerns.

**Trigger:** One representation obscures materially different structural, runtime, deployment or development questions.

**Non-trigger / cheaper path:** A single annotated sketch or direct walkthrough may suffice when it answers every consequential question at hand.

**Authority:** Description authors and the actual stakeholders or analysts using each view. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** The model author or extractor supplies relation definitions and mappings; the consumer receives both checked correspondences and known omissions. Specific subject: Concern-selected views and viewpoints.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "A single annotated sketch or direct walkthrough may suffice when it answers every consequential question at hand.", "reopening_condition_not_equated_with_retirement": "Reopen or retire views when their concern, consumer or decision disappears or a cheaper representation suffices.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S003`, `ESA:ESA-S011`, `ESA:ESA-S014`, `ESA:ESA-S012`, `ESA:ESA-S013`, `ESA:ESA-S010`.

**Clusters:** `SSS-K007`, `SSS-K008`, `SSS-K032`. **Tensions:** `SSS-T003`, `SSS-T007`. **Directional references:** 66 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/19`.

## ESA:ESA-021

**Correspondence between views and realisation**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Cross-view and description–implementation relations, not visual layout similarity.

**Criterion / operative mechanism:** Identify how entities and relations in different views correspond, then check consequential consistency and the link to implementation/configuration/operation.

**Trigger:** A decision combines claims from several views or uses a model as evidence about implementation.

**Non-trigger / cheaper path:** Check a small set of named correspondences manually rather than maintain a universal metamodel.

**Authority:** Design, deployment, development and evaluation participants relying on combined descriptions. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** The model author or extractor supplies relation definitions and mappings; the consumer receives both checked correspondences and known omissions. Specific subject: Correspondence between views and realisation.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Check a small set of named correspondences manually rather than maintain a universal metamodel.", "reopening_condition_not_equated_with_retirement": "Reopen after mapping, model or implementation changes that affect a relied-upon correspondence.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S003`, `ESA:ESA-S011`, `ESA:ESA-S045`, `ESA:ESA-S026`.

**Clusters:** `SSS-K002`, `SSS-K007`, `SSS-K015`, `SSS-K017`, `SSS-K029`, `SSS-K032`. **Tensions:** `SSS-T007`. **Directional references:** 116 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/20`.

## ESA:ESA-022

**Formal architectural descriptions with bounded guarantees**

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Formal component/connector/configuration or behaviour models.

**Criterion / operative mechanism:** Use a formal description when a consequential property can be expressed and analysed under a tractable model; keep the guarantee, assumptions and implementation mapping explicit.

**Trigger:** An interaction/configuration property justifies stronger analysis than informal review or testing alone.

**Non-trigger / cheaper path:** A focused protocol model, contract or ordinary test can dominate a whole-system ADL when it answers the risk.

**Authority:** Modellers, verification specialists and engineers responsible for implementing the model’s assumptions. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** The model author or extractor supplies relation definitions and mappings; the consumer receives both checked correspondences and known omissions. Specific subject: Formal architectural descriptions with bounded guarantees.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "A focused protocol model, contract or ordinary test can dominate a whole-system ADL when it answers the risk.", "reopening_condition_not_equated_with_retirement": "Reopen on changed semantics, topology, implementation mapping or environment assumptions.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S014`, `ESA:ESA-S015`.

**Clusters:** `SSS-K007`, `SSS-K015`, `SSS-K017`. **Tensions:** `SSS-T008`. **Directional references:** 82 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/21`.

## ESA:ESA-023

**Mandatory complete 4+1 documentation**

**Disposition:** `CEREMONY_NOT_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** An unconditional documentation ritual rather than a system property.

**Criterion / operative mechanism:** Completing a prescribed view set regardless of its consumers is ceremony, not a generally useful mechanism.

**Trigger:** A review treats the existence of all five views as evidence of architectural adequacy.

**Non-trigger / cheaper path:** Select views through ESA-020; omit views that add no needed distinction or communication.

**Authority:** Documentation consumers and reviewers, not a template’s nominal owner. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** The model author or extractor supplies relation definitions and mappings; the consumer receives both checked correspondences and known omissions. Specific subject: Mandatory complete 4+1 documentation.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Select views through ESA-020; omit views that add no needed distinction or communication.", "reopening_condition_not_equated_with_retirement": "Retire mandatory views when no external obligation or actual consumer needs them.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S003`.

**Clusters:** `SSS-K008`, `SSS-K032`. **Tensions:** None. **Directional references:** 25 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/22`.

## ESA:ESA-024

**Triangulated architecture reconstruction with uncertainty**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Inferred architectural structures and behaviours from realised artefacts.

**Criterion / operative mechanism:** Combine appropriate static, configuration, dynamic and human evidence to reconstruct only the architectural facts needed; label extraction scope, ambiguity and unobserved behaviour.

**Trigger:** Reliable architectural knowledge is missing or an existing description is suspect.

**Non-trigger / cheaper path:** Inspect the relevant implementation paths with an experienced maintainer before building an automated whole-system reconstruction.

**Authority:** Maintainers, migration designers and reviewers who need specific missing knowledge. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** The model author or extractor supplies relation definitions and mappings; the consumer receives both checked correspondences and known omissions. Specific subject: Triangulated architecture reconstruction with uncertainty.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Inspect the relevant implementation paths with an experienced maintainer before building an automated whole-system reconstruction.", "reopening_condition_not_equated_with_retirement": "Reopen when new artefacts, traces or domain testimony contradict the recovered structure.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S045`, `ESA:ESA-S014`, `ESA:ESA-S026`, `ESA:ESA-S047`, `ESA:ESA-S046`, `ESA:ESA-S063`.

**Clusters:** `SSS-K007`, `SSS-K032`. **Tensions:** `SSS-T003`. **Directional references:** 56 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/23`.

## ESA:ESA-025

**Styles and patterns as conditional mechanisms**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Component-and-connector styles and recurring architectural solution structures.

**Criterion / operative mechanism:** Use a style or pattern as a conditional mechanism with an explicit problem, constraints and trade-offs; document purposeful hybrids and their interaction obligations.

**Trigger:** A recurring architectural problem matches the style’s assumptions closely enough to reduce design or analysis effort.

**Non-trigger / cheaper path:** Use a direct design without a pattern label when the pattern adds indirection or excludes a better local arrangement.

**Authority:** Designers and reviewers selecting, combining or declining architectural mechanisms. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** The model author or extractor supplies relation definitions and mappings; the consumer receives both checked correspondences and known omissions. Specific subject: Styles and patterns as conditional mechanisms.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use a direct design without a pattern label when the pattern adds indirection or excludes a better local arrangement.", "reopening_condition_not_equated_with_retirement": "Reopen or remove the pattern when its motivating problem vanishes or its constraints prevent the desired qualities.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S004`, `ESA:ESA-S014`, `ESA:ESA-S034`, `ESA:ESA-S026`, `ESA:ESA-S037`, `ESA:ESA-S039`.

**Clusters:** `SSS-K016`, `SSS-K027`. **Tensions:** None. **Directional references:** 49 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/24`.

## ESA:ESA-026

**Comparison with feasible alternatives and no change**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Architectural alternatives and decision counterfactuals.

**Criterion / operative mechanism:** Compare feasible architectural options, including retaining the present design or a smaller intervention, against the same concerns and assumptions; expose excluded options.

**Trigger:** A consequential investment or restructuring is being justified.

**Non-trigger / cheaper path:** Use a short explicit comparison when one option is plainly dominated; do not fabricate many alternatives for a form.

**Authority:** Design sponsors, implementers and stakeholders accepting costs or foregone options. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Designers and evaluators exchange alternatives, assumptions and decisive observations; risk identification is not an approval mandate. Specific subject: Comparison with feasible alternatives and no change.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use a short explicit comparison when one option is plainly dominated; do not fabricate many alternatives for a form.", "reopening_condition_not_equated_with_retirement": "Reopen when an excluded option becomes feasible or evidence changes the comparison.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S019`, `ESA:ESA-S020`, `ESA:ESA-S022`, `ESA:ESA-S010`, `ESA:ESA-S037`, `ESA:ESA-S039`, `ESA:ESA-S061`.

**Clusters:** `SSS-K011`, `SSS-K023`, `SSS-K028`. **Tensions:** `SSS-T004`. **Directional references:** 68 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/25`.

## ESA:ESA-027

**Change-scenario architectural evaluation**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Architecture under prospective functional or quality-related modifications.

**Criterion / operative mechanism:** Walk representative modifications through an architecture, identify affected elements and interacting scenarios, and compare the resulting burdens across alternatives.

**Trigger:** Modifiability or the consequences of planned change are material and can be expressed as concrete scenarios.

**Non-trigger / cheaper path:** Walk a single realistic change through the current code and a proposed alternative if a full workshop is unnecessary.

**Authority:** Evaluators and maintainers choosing a design or restructuring. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Designers and evaluators exchange alternatives, assumptions and decisive observations; risk identification is not an approval mandate. Specific subject: Change-scenario architectural evaluation.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Walk a single realistic change through the current code and a proposed alternative if a full workshop is unnecessary.", "reopening_condition_not_equated_with_retirement": "Reopen when actual changes differ materially from the scenario population.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S019`, `ESA:ESA-S023`.

**Clusters:** `SSS-K004`, `SSS-K031`. **Tensions:** None. **Directional references:** 53 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/26`.

## ESA:ESA-028

**Multi-quality risk and sensitivity evaluation**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Multi-quality evaluation of an architectural candidate.

**Criterion / operative mechanism:** Bring business/mission drivers, architecture and quality scenarios into a structured review to identify assumptions, risks, sensitivity points and trade-offs that need a decision.

**Trigger:** Several consequential qualities interact and missing assumptions justify a facilitated multi-stakeholder review.

**Non-trigger / cheaper path:** Use a focused risk/assumption review with the necessary participants for a small decision; the full event structure is not mandatory.

**Authority:** Stakeholders, evaluation facilitators and people authorised to accept or mitigate the identified risks. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Designers and evaluators exchange alternatives, assumptions and decisive observations; risk identification is not an approval mandate. Specific subject: Multi-quality risk and sensitivity evaluation.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use a focused risk/assumption review with the necessary participants for a small decision; the full event structure is not mandatory.", "reopening_condition_not_equated_with_retirement": "Reopen non-risks and trade-offs when the assumptions or operating scenario change.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S020`, `ESA:ESA-S021`, `ESA:ESA-S023`.

**Clusters:** `SSS-K006`, `SSS-K033`. **Tensions:** `SSS-T012`. **Directional references:** 60 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/27`.

## ESA:ESA-029

**Economic evaluation with uncertainty and dependency**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Architectural investment alternatives, costs and stakeholder preference models.

**Criterion / operative mechanism:** Establish feasible options and hard constraints first, then explore plausible costs, utilities, dependencies and sensitivity rather than treating one estimated ratio as an objective answer.

**Trigger:** Several acceptable alternatives compete for constrained resources and economic consequences may change the choice.

**Non-trigger / cheaper path:** Use cost ranges, break-even reasoning or dominance checks when a detailed utility model adds unjustified precision.

**Authority:** Budget/benefit decision makers and affected stakeholders; the model advises rather than owns the decision. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Designers and evaluators exchange alternatives, assumptions and decisive observations; risk identification is not an approval mandate. Specific subject: Economic evaluation with uncertainty and dependency.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use cost ranges, break-even reasoning or dominance checks when a detailed utility model adds unjustified precision.", "reopening_condition_not_equated_with_retirement": "Reopen when costs, utility judgements, dependencies or opportunity costs cross a decision-changing boundary.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S022`, `ESA:ESA-S061`.

**Clusters:** `SSS-K011`, `SSS-K026`, `SSS-K031`, `SSS-K033`. **Tensions:** None. **Directional references:** 92 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/28`.

## ESA:ESA-030

**Targeted prototypes and calibrated analytic models**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Prototype, simulation or analytic model tied to a real architectural decision.

**Criterion / operative mechanism:** Choose a focused prototype, simulation or analytic model for the uncertainty at hand; calibrate it where possible and distinguish omitted behaviour from demonstrated behaviour.

**Trigger:** A consequential prediction cannot be judged adequately by reasoning or existing observations alone.

**Non-trigger / cheaper path:** Use a small experiment or direct inspection of the uncertain mechanism rather than a production-like prototype of everything.

**Authority:** Designers and evaluators responsible for uncertainty reduction, not for treating an experiment as automatic release authority. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Designers and evaluators exchange alternatives, assumptions and decisive observations; risk identification is not an approval mandate. Specific subject: Targeted prototypes and calibrated analytic models.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use a small experiment or direct inspection of the uncertain mechanism rather than a production-like prototype of everything.", "reopening_condition_not_equated_with_retirement": "Reopen when the operating regime or implementation diverges from what the prototype represented.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S016`, `ESA:ESA-S020`, `ESA:ESA-S024`, `ESA:ESA-S008`, `ESA:ESA-S054`, `ESA:ESA-S061`.

**Clusters:** `SSS-K006`, `SSS-K015`, `SSS-K018`. **Tensions:** None. **Directional references:** 76 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/29`.

## ESA:ESA-031

**Review success as a guarantee of operating quality**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Inference from evaluation process completion to realised performance or correctness.

**Criterion / operative mechanism:** A review can establish that a process occurred and risks were considered; it cannot by itself guarantee the real system under unexamined conditions.

**Trigger:** An approval, risk list or completed workshop is used as conclusive evidence that the system will meet its qualities.

**Non-trigger / cheaper path:** Keep the review’s actual conclusions and obtain the missing representative evidence through ESA-018.

**Authority:** People accepting a design or relying on its review status. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Designers and evaluators exchange alternatives, assumptions and decisive observations; risk identification is not an approval mandate. Specific subject: Review success as a guarantee of operating quality.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Keep the review’s actual conclusions and obtain the missing representative evidence through ESA-018.", "reopening_condition_not_equated_with_retirement": "Reject the inference whenever a necessary assumption or observation is absent; reconsider only the narrower supported claim.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S020`, `ESA:ESA-S021`, `ESA:ESA-S023`, `ESA:ESA-S054`.

**Clusters:** `SSS-K007`, `SSS-K018`, `SSS-K033`. **Tensions:** None. **Directional references:** 66 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/30`.

## ESA:ESA-032

**Recoverable decision rationale for later consumers**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Architectural decision knowledge linked to structures, constraints and evidence.

**Criterion / operative mechanism:** Preserve the context, selected option, significant alternatives, consequences and assumptions that a future actor needs to understand or revise a consequential decision.

**Trigger:** A decision is non-obvious, likely to recur or needs to survive turnover and distributed work.

**Non-trigger / cheaper path:** A short linked note or direct shared understanding can suffice for a local reversible decision; do not record all reasoning exhaustively.

**Authority:** Current decision participants and later maintainers, reviewers or successors. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** People making and inheriting decisions need the relevant context, consequences and exceptions; use existing communication channels when adequate. Specific subject: Recoverable decision rationale for later consumers.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "A short linked note or direct shared understanding can suffice for a local reversible decision; do not record all reasoning exhaustively.", "reopening_condition_not_equated_with_retirement": "Reopen when an assumption, excluded alternative or accepted consequence changes materially.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S009`, `ESA:ESA-S027`, `ESA:ESA-S028`, `ESA:ESA-S029`.

**Clusters:** `SSS-K008`. **Tensions:** None. **Directional references:** 20 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/31`.

## ESA:ESA-033

**Decision ageing, supersession and reopening**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Time-indexed architectural decisions and their dependency links.

**Criterion / operative mechanism:** Keep a decision’s status and reopening conditions visible; distinguish superseding it from erasing the evidence that once justified it.

**Trigger:** Architectural choices outlive their original workload, team, dependency or business assumptions.

**Non-trigger / cheaper path:** Update a short status/link at the affected decision; no periodic meeting is needed when nothing decision-relevant has changed.

**Authority:** Maintainers and authorised decision revisers; a record itself does not grant revision authority. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** People making and inheriting decisions need the relevant context, consequences and exceptions; use existing communication channels when adequate. Specific subject: Decision ageing, supersession and reopening.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Update a short status/link at the affected decision; no periodic meeting is needed when nothing decision-relevant has changed.", "reopening_condition_not_equated_with_retirement": "The stated assumption or consequence changes, a better option appears, or the decision is no longer consequential.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S020`, `ESA:ESA-S029`, `ESA:ESA-S027`.

**Clusters:** `SSS-K008`, `SSS-K014`, `SSS-K015`, `SSS-K023`. **Tensions:** None. **Directional references:** 122 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/32`.

## ESA:ESA-034

**Socio-technical coordination of consequential dependencies**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Coupling between software/work dependencies and human communication.

**Criterion / operative mechanism:** Identify consequential technical/work dependencies and arrange adequate communication across the people who must coordinate them; test the actual coordination problem rather than copying an organisation chart.

**Trigger:** Cross-team dependencies cause misunderstandings, delay or incompatible changes.

**Non-trigger / cheaper path:** Use a direct conversation or temporary collaboration when a lasting team or system reorganisation would cost more.

**Authority:** Teams and organisational decision makers able to alter coordination arrangements. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** People making and inheriting decisions need the relevant context, consequences and exceptions; use existing communication channels when adequate. Specific subject: Socio-technical coordination of consequential dependencies.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use a direct conversation or temporary collaboration when a lasting team or system reorganisation would cost more.", "reopening_condition_not_equated_with_retirement": "Reopen when work dependencies, team membership, sites or communication channels change.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S030`, `ESA:ESA-S031`, `ESA:ESA-S032`.

**Clusters:** `SSS-K010`, `SSS-K021`, `SSS-K022`. **Tensions:** None. **Directional references:** 49 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/33`.

## ESA:ESA-035

**Distributed decisions constrained by shared consequences**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Architectural decision allocation across component, product and team boundaries.

**Criterion / operative mechanism:** Allow local choices inside explicit shared contracts and escalate or negotiate only decisions that change cross-boundary consequences; preserve a way to resolve conflicts.

**Trigger:** Multiple teams need autonomy but share users, data, quality limits or release obligations.

**Non-trigger / cheaper path:** A single team’s common understanding can replace formal delegation structures; avoid review boards for isolated implementation choices.

**Authority:** Local teams and those accountable for shared constraints; delegation is contextual rather than asserted by the method. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** People making and inheriting decisions need the relevant context, consequences and exceptions; use existing communication channels when adequate. Specific subject: Distributed decisions constrained by shared consequences.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "A single team’s common understanding can replace formal delegation structures; avoid review boards for isolated implementation choices.", "reopening_condition_not_equated_with_retirement": "Reopen the allocation when dependency reach or local decision capability changes.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S010`, `ESA:ESA-S033`, `ESA:ESA-S036`, `ESA:ESA-S030`, `ESA:ESA-S031`, `ESA:ESA-S039`, `ESA:ESA-S060`.

**Clusters:** `SSS-K009`, `SSS-K010`, `SSS-K019`, `SSS-K021`, `SSS-K022`. **Tensions:** `SSS-T002`, `SSS-T013`. **Directional references:** 95 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/34`.

## ESA:ESA-036

**Deterministic organisational mirroring**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Claimed necessary relationship between organisational and software structures.

**Criterion / operative mechanism:** No deterministic rule mapping an organisation chart to software architecture is admitted; communication and technical structures influence each other under contingent conditions.

**Trigger:** A reorganisation is asserted to guarantee a desired architecture or every structural similarity is treated as inevitable.

**Non-trigger / cheaper path:** Investigate the actual dependency/coordination mechanisms through ESA-034.

**Authority:** Organisational designers and architects considering a socio-technical intervention. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** People making and inheriting decisions need the relevant context, consequences and exceptions; use existing communication channels when adequate. Specific subject: Deterministic organisational mirroring.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Investigate the actual dependency/coordination mechanisms through ESA-034.", "reopening_condition_not_equated_with_retirement": "Revisit a bounded causal hypothesis only with new discriminating evidence, not rhetorical invocation of a law.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S030`, `ESA:ESA-S031`, `ESA:ESA-S032`.

**Clusters:** `SSS-K010`, `SSS-K027`. **Tensions:** None. **Directional references:** 38 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/35`.

## ESA:ESA-037

**Documentation quantity as architectural evidence**

**Disposition:** `CEREMONY_NOT_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Documentation volume as a candidate architectural quality indicator.

**Criterion / operative mechanism:** Document quantity alone is not retained as a proxy for architectural knowledge, correctness or maintenance value.

**Trigger:** Page counts, completed templates or a large repository of records are used as assurance.

**Non-trigger / cheaper path:** Ask a real consumer to recover a needed decision or check a correspondence using the smallest adequate material.

**Authority:** Document authors, maintainers and the users of their explanations. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** People making and inheriting decisions need the relevant context, consequences and exceptions; use existing communication channels when adequate. Specific subject: Documentation quantity as architectural evidence.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Ask a real consumer to recover a needed decision or check a correspondence using the smallest adequate material.", "reopening_condition_not_equated_with_retirement": "Retire content whose consumer and decision relevance have disappeared, subject to genuine record-retention obligations.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S009`, `ESA:ESA-S029`, `ESA:ESA-S027`, `ESA:ESA-S041`.

**Clusters:** `SSS-K008`, `SSS-K032`. **Tensions:** None. **Directional references:** 25 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/36`.

## ESA:ESA-038

**Conformance to a justified, mapped baseline**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Intended constraints mapped to realised static or dynamic architectural relationships.

**Criterion / operative mechanism:** Check a declared, justified architectural constraint against appropriately extracted or observed relationships; attach the relevant baseline, mapping and evidence to each finding.

**Trigger:** A system depends on a structural or behavioural restriction that implementation changes might violate.

**Non-trigger / cheaper path:** Use a focused code/configuration review or small dependency check; a universal conformance framework is unnecessary.

**Authority:** Constraint owners, implementers and reviewers able to accept or revise the affected design. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** A finding reaches someone able to judge the continuing baseline and actual effect; explain extraction scope before requesting a correction. Specific subject: Conformance to a justified, mapped baseline.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use a focused code/configuration review or small dependency check; a universal conformance framework is unnecessary.", "reopening_condition_not_equated_with_retirement": "Reopen when the baseline’s rationale, extraction scope or relevant system relation changes.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S045`, `ESA:ESA-S002`, `ESA:ESA-S026`, `ESA:ESA-S048`, `ESA:ESA-S046`.

**Clusters:** `SSS-K002`, `SSS-K007`, `SSS-K012`, `SSS-K030`. **Tensions:** `SSS-T001`, `SSS-T009`. **Directional references:** 89 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/37`.

## ESA:ESA-039

**Adjudication of drift and authorised improvement**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Deviations between intended, documented and realised architectures over time.

**Criterion / operative mechanism:** For a deviation, decide whether the implementation is harmful, the model is stale, the change is authorised improvement or evidence is insufficient; revise the correct object.

**Trigger:** A realised relationship departs from an architectural baseline.

**Non-trigger / cheaper path:** Explain and update a simple obsolete rule directly when the improvement and authority are clear; do not force a rollback to satisfy a metric.

**Authority:** Maintainers, evaluators and authorised architecture decision makers. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** A finding reaches someone able to judge the continuing baseline and actual effect; explain extraction scope before requesting a correction. Specific subject: Adjudication of drift and authorised improvement.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Explain and update a simple obsolete rule directly when the improvement and authority are clear; do not force a rollback to satisfy a metric.", "reopening_condition_not_equated_with_retirement": "Reopen when new evidence changes whether the deviation harms a still-valid obligation.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S002`, `ESA:ESA-S020`, `ESA:ESA-S045`, `ESA:ESA-S041`, `ESA:ESA-S048`, `ESA:ESA-S046`.

**Clusters:** `SSS-K009`, `SSS-K012`, `SSS-K014`, `SSS-K030`. **Tensions:** `SSS-T001`, `SSS-T005`. **Directional references:** 84 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/38`.

## ESA:ESA-040

**Architectural smells as defeasible risk indicators**

**Disposition:** `USEFUL_BUT_EASILY_GAMED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Potential architectural risk indicators extracted from code, graphs or review text.

**Criterion / operative mechanism:** Use a smell or detector output to prioritise investigation, then connect it to actual quality, invariant or change burden before prescribing repair.

**Trigger:** There are enough suspected structural problems that triage may save investigation effort.

**Non-trigger / cheaper path:** Investigate a concrete recurring failure directly; skip a detector when its noise costs more than manual diagnosis.

**Authority:** Maintainers and reviewers selecting what to investigate or repair. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** A finding reaches someone able to judge the continuing baseline and actual effect; explain extraction scope before requesting a correction. Specific subject: Architectural smells as defeasible risk indicators.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Investigate a concrete recurring failure directly; skip a detector when its noise costs more than manual diagnosis.", "reopening_condition_not_equated_with_retirement": "Reopen on detector/version/domain changes or evidence that its flagged patterns are benign or missed harms dominate.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S046`, `ESA:ESA-S047`, `ESA:ESA-S048`.

**Clusters:** `SSS-K016`. **Tensions:** None. **Directional references:** 23 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/39`.

## ESA:ESA-041

**Recovered structure as a substitute for intended rationale**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Distinction between recovered architecture and missing design rationale.

**Criterion / operative mechanism:** Recovered structure cannot by itself establish the stakeholders, alternatives or rationale behind it; inferred intent must be labelled and corroborated.

**Trigger:** A recovered graph or generated description is treated as a replacement for absent decision history.

**Non-trigger / cheaper path:** Retain observed facts, ask a knowledgeable participant or state the intent as unresolved rather than manufacture it.

**Authority:** Maintainers and researchers reconstructing why decisions were made. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** A finding reaches someone able to judge the continuing baseline and actual effect; explain extraction scope before requesting a correction. Specific subject: Recovered structure as a substitute for intended rationale.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Retain observed facts, ask a knowledgeable participant or state the intent as unresolved rather than manufacture it.", "reopening_condition_not_equated_with_retirement": "Reconsider an inferred rationale when contemporary records or participants provide evidence.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S045`, `ESA:ESA-S026`, `ESA:ESA-S027`.

**Clusters:** `SSS-K008`. **Tensions:** None. **Directional references:** 15 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/40`.

## ESA:ESA-042

**Zero deviations from a historical architecture**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Historical model compliance as an unconditional architectural objective.

**Criterion / operative mechanism:** Zero departures from any historical model is not admitted as a general quality requirement.

**Trigger:** A historical rule is enforced despite changed requirements or evidence that its violation is an improvement.

**Non-trigger / cheaper path:** Adjudicate the rule and change through ESA-038/039, preserving the current protected obligation.

**Authority:** Reviewers and maintainers choosing whether the implementation or baseline should change. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** A finding reaches someone able to judge the continuing baseline and actual effect; explain extraction scope before requesting a correction. Specific subject: Zero deviations from a historical architecture.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Adjudicate the rule and change through ESA-038/039, preserving the current protected obligation.", "reopening_condition_not_equated_with_retirement": "Retire or revise the obsolete rule once its relevant obligation has changed or disappeared.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S002`, `ESA:ESA-S045`, `ESA:ESA-S041`, `ESA:ESA-S048`, `ESA:ESA-S046`.

**Clusters:** `SSS-K009`, `SSS-K012`, `SSS-K030`. **Tensions:** None. **Directional references:** 38 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/41`.

## ESA:ESA-043

**Architecture debt distinguished from mere imperfection**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Architecture-level compromises and their temporal costs.

**Criterion / operative mechanism:** Identify the specific structural compromise, its current benefit, the future work or recurring penalty it may cause and the plausible cost of remedy; distinguish observed interest from a prediction.

**Trigger:** A known architectural choice is causing or credibly expected to cause recurring change/operation burden.

**Non-trigger / cheaper path:** Leave a harmless imperfection alone; use an ordinary defect or planned enhancement description when debt adds no explanatory value.

**Authority:** Maintainers and resource decision makers comparing remediation with other investments. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Observations reach the people or bounded controller selecting a change; commands and post-change effects must not be confused with model updates. Specific subject: Architecture debt distinguished from mere imperfection.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Leave a harmless imperfection alone; use an ordinary defect or planned enhancement description when debt adds no explanatory value.", "reopening_condition_not_equated_with_retirement": "Reopen when interest materialises, the affected feature retires or repair becomes cheaper/more costly.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S049`, `ESA:ESA-S050`, `ESA:ESA-S056`.

**Clusters:** `SSS-K011`, `SSS-K016`, `SSS-K031`. **Tensions:** None. **Directional references:** 71 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/42`.

## ESA:ESA-044

**Incremental migration with coexistence and compatibility**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Sequences and coexistence states between architectural configurations.

**Criterion / operative mechanism:** Plan migration steps that preserve required behaviour and compatibility while old and new structures coexist; include routing/data transitions and an explicit end to temporary arrangements.

**Trigger:** A consequential replacement must proceed while service or development continues.

**Non-trigger / cheaper path:** A direct replacement or brief planned outage may be safer and cheaper for a small, low-exposure system.

**Authority:** Migration engineers, operators and stakeholders accepting continuity or interruption costs. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Observations reach the people or bounded controller selecting a change; commands and post-change effects must not be confused with model updates. Specific subject: Incremental migration with coexistence and compatibility.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "A direct replacement or brief planned outage may be safer and cheaper for a small, low-exposure system.", "reopening_condition_not_equated_with_retirement": "Reopen when transition risk, compatibility needs or the feasibility of safe reversal changes.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S040`, `ESA:ESA-S051`, `ESA:ESA-S026`, `ESA:ESA-S050`, `ESA:ESA-S060`.

**Clusters:** `SSS-K013`, `SSS-K023`. **Tensions:** None. **Directional references:** 73 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/43`.

## ESA:ESA-045

**Revisable fitness functions and continuous evaluation**

**Disposition:** `USEFUL_BUT_EASILY_GAMED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Continuous or periodic checks on selected architectural properties.

**Criterion / operative mechanism:** Use maintained checks to detect changes in selected architectural characteristics, and periodically challenge whether the checks still measure the concern and preserve competing constraints.

**Trigger:** Repeated changes threaten a sufficiently observable characteristic and feedback can influence decisions.

**Non-trigger / cheaper path:** A manual review or occasional targeted test is adequate when changes are infrequent or the property is poorly automatable.

**Authority:** Developers, operators and reviewers who can respond to findings; a check does not acquire independent authority. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Observations reach the people or bounded controller selecting a change; commands and post-change effects must not be confused with model updates. Specific subject: Revisable fitness functions and continuous evaluation.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "A manual review or occasional targeted test is adequate when changes are infrequent or the property is poorly automatable.", "reopening_condition_not_equated_with_retirement": "Reopen or retire the check when the concern, valid baseline, measurement or consumer changes.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S043`, `ESA:ESA-S044`, `ESA:ESA-S020`, `ESA:ESA-S054`, `ESA:ESA-S062`.

**Clusters:** `SSS-K014`, `SSS-K015`. **Tensions:** None. **Directional references:** 70 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/44`.

## ESA:ESA-046

**Architecture-based observation and runtime adaptation**

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Runtime architectural configurations, monitors, model and control actions.

**Criterion / operative mechanism:** Observe the running system, interpret observations in an architecture model, choose among allowed changes and execute them through available effectors; keep system-specific translation explicit.

**Trigger:** Operating variation warrants runtime reconfiguration and appropriate actions are available.

**Non-trigger / cheaper path:** Use a stable configuration, an operator procedure or a simple established controller when architecture-level adaptation adds no value.

**Authority:** Runtime controllers within delegated limits, with engineers/operators responsible for those limits and failures. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Observations reach the people or bounded controller selecting a change; commands and post-change effects must not be confused with model updates. Specific subject: Architecture-based observation and runtime adaptation.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use a stable configuration, an operator procedure or a simple established controller when architecture-level adaptation adds no value.", "reopening_condition_not_equated_with_retirement": "Reopen when sensors, strategy, model mapping or available actions change or become invalid.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S051`, `ESA:ESA-S052`, `ESA:ESA-S053`, `ESA:ESA-S054`, `ESA:ESA-S055`.

**Clusters:** `SSS-K014`, `SSS-K020`. **Tensions:** `SSS-T010`. **Directional references:** 58 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/45`.

## ESA:ESA-047

**Constrained adaptation and post-change assurance**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Admissible architectural transition set and post-change system state.

**Criterion / operative mechanism:** Constrain allowed changes by the relevant system and external obligations, then assess the actual post-change state; local metric improvement is evidence for only that metric.

**Trigger:** Runtime or automated changes can violate an invariant, external commitment or competing quality.

**Non-trigger / cheaper path:** Keep a known-safe static choice or require operator judgement when the admissible change envelope cannot be adequately established.

**Authority:** Delegating engineers/owners and bounded controllers/operators; a optimiser cannot grant itself new commitments. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Observations reach the people or bounded controller selecting a change; commands and post-change effects must not be confused with model updates. Specific subject: Constrained adaptation and post-change assurance.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Keep a known-safe static choice or require operator judgement when the admissible change envelope cannot be adequately established.", "reopening_condition_not_equated_with_retirement": "Reopen or stop using the policy when assumptions, observations or external constraints no longer support it.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S015`, `ESA:ESA-S052`, `ESA:ESA-S053`, `ESA:ESA-S054`, `ESA:ESA-S055`, `ESA:ESA-S061`.

**Clusters:** `SSS-K019`, `SSS-K020`. **Tensions:** `SSS-T010`, `SSS-T014`. **Directional references:** 54 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/46`.

## ESA:ESA-048

**Self-authorisation through local metric improvement**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Self-authorisation claim for metric-driven architectural change.

**Criterion / operative mechanism:** An improved local objective neither authorises an architectural change nor establishes its external consequences.

**Trigger:** A controller or decision-support tool treats its own score as sufficient permission and proof of success.

**Non-trigger / cheaper path:** Apply independently established constraints and observe the actual consequences through ESA-047.

**Authority:** Engineers and operators interpreting automated recommendations or actions. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Observations reach the people or bounded controller selecting a change; commands and post-change effects must not be confused with model updates. Specific subject: Self-authorisation through local metric improvement.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Apply independently established constraints and observe the actual consequences through ESA-047.", "reopening_condition_not_equated_with_retirement": "Reconsider only a bounded delegation with independently justified constraints; the objective cannot justify its own expansion.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S052`, `ESA:ESA-S053`, `ESA:ESA-S054`, `ESA:ESA-S056`, `ESA:ESA-S061`.

**Clusters:** `SSS-K009`, `SSS-K020`. **Tensions:** None. **Directional references:** 53 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/47`.

## ESA:ESA-049

**Investment in future flexibility proportionate to change hypotheses**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Architectural options, abstraction/variation points and temporal cost of change.

**Criterion / operative mechanism:** Invest in flexibility when a credible change family and its expected cost justify the present complexity; preserve simpler reversible choices where evidence is weak.

**Trigger:** A proposed abstraction, extension point or distributed boundary is justified primarily by future changes.

**Non-trigger / cheaper path:** Defer the extension or implement the currently needed case directly when later change is tolerable.

**Authority:** Designers and investment decision makers accepting current complexity for future capability. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Observations reach the people or bounded controller selecting a change; commands and post-change effects must not be confused with model updates. Specific subject: Investment in future flexibility proportionate to change hypotheses.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Defer the extension or implement the currently needed case directly when later change is tolerable.", "reopening_condition_not_equated_with_retirement": "Reopen when predicted changes fail to occur, new changes emerge or the flexibility premium becomes disproportionate.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S001`, `ESA:ESA-S006`, `ESA:ESA-S008`, `ESA:ESA-S010`, `ESA:ESA-S037`, `ESA:ESA-S041`, `ESA:ESA-S039`.

**Clusters:** `SSS-K005`, `SSS-K011`, `SSS-K023`, `SSS-K028`, `SSS-K031`. **Tensions:** None. **Directional references:** 78 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/48`.

## ESA:ESA-050

**Microservices conditional on deployment and operating needs**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Service decomposition and deployment topology, distinct from source-code modularity.

**Criterion / operative mechanism:** Select independent deployments where workload, release, failure or ownership needs warrant their distributed-system and operational costs; validate data and interaction independence.

**Trigger:** Different parts genuinely need separate release/scaling or bounded operational control and teams can support it.

**Non-trigger / cheaper path:** Use a modular monolith or shared deployment when releases, scaling, permissions and operations largely move together.

**Authority:** Service teams and end-to-end operators/stakeholders accepting the distribution trade-off. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Translate the specific style, platform or domain constraint into obligations understood by implementers and affected consumers; labels alone communicate too little. Specific subject: Microservices conditional on deployment and operating needs.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use a modular monolith or shared deployment when releases, scaling, permissions and operations largely move together.", "reopening_condition_not_equated_with_retirement": "Reopen when independence is not used, coupling dominates or operating capability no longer supports the architecture.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S036`, `ESA:ESA-S001`, `ESA:ESA-S026`, `ESA:ESA-S037`, `ESA:ESA-S039`, `ESA:ESA-S060`.

**Clusters:** `SSS-K016`, `SSS-K026`. **Tensions:** None. **Directional references:** 46 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/49`.

## ESA:ESA-051

**Modular monoliths and justified consolidation**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Logical modules within a deployment and transitions from distributed to consolidated structure.

**Criterion / operative mechanism:** Preserve useful logical boundaries inside a shared deployment, or consolidate services whose separation adds costs without a needed independent capability.

**Trigger:** Shared release, scale, trust or operations make independent deployment unnecessary or harmful.

**Non-trigger / cheaper path:** A simple unlayered local application may suffice when even internal abstraction has no change or comprehension consumer.

**Authority:** Application teams and operators accountable for shared deployment consequences. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Translate the specific style, platform or domain constraint into obligations understood by implementers and affected consumers; labels alone communicate too little. Specific subject: Modular monoliths and justified consolidation.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "A simple unlayered local application may suffice when even internal abstraction has no change or comprehension consumer.", "reopening_condition_not_equated_with_retirement": "Reopen when parts acquire genuinely different scaling, release, fault or authority needs.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S001`, `ESA:ESA-S037`, `ESA:ESA-S038`, `ESA:ESA-S039`, `ESA:ESA-S036`.

**Clusters:** `SSS-K013`, `SSS-K016`, `SSS-K023`, `SSS-K026`. **Tensions:** `SSS-T015`. **Directional references:** 95 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/50`.

## ESA:ESA-052

**Serverless architecture with provider and workload boundaries**

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Function, platform and external-service composition in a serverless deployment.

**Criterion / operative mechanism:** Model provider-managed execution and service dependencies, including data locality, lifecycle, communication, resource and failure assumptions relevant to the workload.

**Trigger:** A design delegates execution/resource management to a serverless platform.

**Non-trigger / cheaper path:** Use a simpler long-running process or managed service when latency, state or steady demand makes function decomposition costly.

**Authority:** Application teams and provider-facing operators; provider controls constrain what the application can observe or change. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Translate the specific style, platform or domain constraint into obligations understood by implementers and affected consumers; labels alone communicate too little. Specific subject: Serverless architecture with provider and workload boundaries.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use a simpler long-running process or managed service when latency, state or steady demand makes function decomposition costly.", "reopening_condition_not_equated_with_retirement": "Reopen when provider semantics, workload shape, data movement or pricing/contract assumptions change.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S057`, `ESA:ESA-S035`, `ESA:ESA-S061`.

**Clusters:** `SSS-K026`. **Tensions:** None. **Directional references:** 27 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/51`.

## ESA:ESA-053

**Architecture for learned components and data dependencies**

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Learned components embedded in data, software and organisational processes.

**Criterion / operative mechanism:** Include training/serving data, model behaviour, undeclared consumers and feedback paths in architectural reasoning; treat distribution and model changes as potential contract changes.

**Trigger:** Learned components influence consequential system outputs or are reused by downstream consumers.

**Non-trigger / cheaper path:** A deterministic rule or isolated advisory component may be simpler when learning adds no justified capability.

**Authority:** Model, data, application and operations participants responsible for affected system consequences. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Translate the specific style, platform or domain constraint into obligations understood by implementers and affected consumers; labels alone communicate too little. Specific subject: Architecture for learned components and data dependencies.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "A deterministic rule or isolated advisory component may be simpler when learning adds no justified capability.", "reopening_condition_not_equated_with_retirement": "Reopen after data-distribution, model, consumer or feedback changes, even when ordinary interfaces are unchanged.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S056`, `ESA:ESA-S008`.

**Clusters:** `SSS-K025`. **Tensions:** None. **Directional references:** 49 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/52`.

## ESA:ESA-054

**Evidence-checked AI assistance for architectural work**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** AI-produced architectural representations, options, risk analyses and boundary proposals.

**Criterion / operative mechanism:** Use generated alternatives, descriptions or risk suggestions as candidates; independently check their evidence, semantics, metrics and fit to the actual system before relying on them.

**Trigger:** AI assistance could reduce search/drafting effort and adequate validation is available.

**Non-trigger / cheaper path:** Use direct human analysis, deterministic extraction or established checks when verification costs exceed the assistance benefit.

**Authority:** Human or otherwise authorised reviewers who retain decision responsibility; generated text has no operative mandate. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Translate the specific style, platform or domain constraint into obligations understood by implementers and affected consumers; labels alone communicate too little. Specific subject: Evidence-checked AI assistance for architectural work.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use direct human analysis, deterministic extraction or established checks when verification costs exceed the assistance benefit.", "reopening_condition_not_equated_with_retirement": "Reopen when model, retrieval corpus, prompt, requirement scope or validation evidence changes.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S059`, `ESA:ESA-S062`, `ESA:ESA-S063`.

**Clusters:** `SSS-K015`, `SSS-K024`, `SSS-K033`. **Tensions:** `SSS-T011`. **Directional references:** 114 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/53`.

## ESA:ESA-055

**Sustainability as an explicitly bounded architectural concern**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Architectural choices affecting operational and lifecycle resource consequences.

**Criterion / operative mechanism:** Declare the sustainability concern and system/lifecycle boundary, then evaluate architectural alternatives against measurable impacts and competing constraints rather than assuming a fashionable deployment is greener.

**Trigger:** Energy, emissions, resource use or longer-term maintainability are material stakeholder concerns.

**Non-trigger / cheaper path:** Use a targeted operational measurement or omit a specialised control when its impact is negligible and its own cost dominates.

**Authority:** Stakeholders setting impact priorities and engineers able to measure and alter relevant mechanisms. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Translate the specific style, platform or domain constraint into obligations understood by implementers and affected consumers; labels alone communicate too little. Specific subject: Sustainability as an explicitly bounded architectural concern.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use a targeted operational measurement or omit a specialised control when its impact is negligible and its own cost dominates.", "reopening_condition_not_equated_with_retirement": "Reopen when workload, energy supply, lifecycle scope or external costs change the impact comparison.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S058`, `ESA:ESA-S061`.

**Clusters:** `SSS-K011`, `SSS-K026`. **Tensions:** None. **Directional references:** 52 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/54`.

## ESA:ESA-056

**Proportional governance and retirement of controls**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Architecture methods and governance arrangements applied to a particular system.

**Criterion / operative mechanism:** Keep only the architectural control, artefact or coordination mechanism whose consumer and avoided risk justify its cost; choose the smallest coherent arrangement and retire obsolete controls.

**Trigger:** Architecture work imposes review, documentation, modelling or coordination cost.

**Non-trigger / cheaper path:** No extra intervention is appropriate when existing shared understanding and ordinary engineering already address the concern adequately.

**Authority:** Those using and funding architectural work, with affected stakeholders participating in trade-offs. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Translate the specific style, platform or domain constraint into obligations understood by implementers and affected consumers; labels alone communicate too little. Specific subject: Proportional governance and retirement of controls.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "No extra intervention is appropriate when existing shared understanding and ordinary engineering already address the concern adequately.", "reopening_condition_not_equated_with_retirement": "Retire when the risk, consumer or dependency disappears; strengthen when credible harm exceeds the cheap path’s capability.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S003`, `ESA:ESA-S009`, `ESA:ESA-S010`, `ESA:ESA-S017`, `ESA:ESA-S037`, `ESA:ESA-S041`, `ESA:ESA-S042`, `ESA:ESA-S039`.

**Clusters:** `SSS-K011`, `SSS-K023`, `SSS-K026`, `SSS-K028`, `SSS-K032`. **Tensions:** `SSS-T012`. **Directional references:** 105 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/55`.

## ESA:ESA-057

**Service and REST constraints distinguished from labels**

**Disposition:** `SUPERSEDED_BY_STRONGER_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Superseded umbrella over architectural styles and reference-model concepts.

**Criterion / operative mechanism:** The useful warning is retained through separate REST constraints (ESA-065) and service interaction/effect contracts (ESA-066), whose assumptions and consumers differ.

**Trigger:** A design relies on “service-oriented” or “RESTful” as if the word alone establishes interoperability or quality.

**Non-trigger / cheaper path:** Name and check the actual required interaction property without imposing either complete style.

**Authority:** Interface and architecture designers distinguishing their selected mechanisms. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Translate the specific style, platform or domain constraint into obligations understood by implementers and affected consumers; labels alone communicate too little. Specific subject: Service and REST constraints distinguished from labels.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Name and check the actual required interaction property without imposing either complete style.", "reopening_condition_not_equated_with_retirement": "Use the successor records when the design or terminology changes; do not count this row as an additional retained mechanism.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S034`, `ESA:ESA-S035`, `ESA:ESA-S026`.

**Clusters:** `SSS-K027`. **Tensions:** None. **Directional references:** 26 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/56`.

## ESA:ESA-058

**Emergence as a reason to omit architectural reasoning**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Architectural reasoning across time, distinct from a mandatory upfront document phase.

**Criterion / operative mechanism:** Emergence is not a general exemption from examining architecture-relevant consequences; reason just enough, and revise as the system and knowledge change.

**Trigger:** An evolutionary or agile label is used to avoid considering a consequential interface, quality or migration decision.

**Non-trigger / cheaper path:** Use timely local reasoning, concrete experiments and brief rationale rather than a speculative full upfront design.

**Authority:** Development teams and stakeholders exposed to evolving structural choices. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Translate the specific style, platform or domain constraint into obligations understood by implementers and affected consumers; labels alone communicate too little. Specific subject: Emergence as a reason to omit architectural reasoning.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use timely local reasoning, concrete experiments and brief rationale rather than a speculative full upfront design.", "reopening_condition_not_equated_with_retirement": "Reopen reasoning whenever a local choice becomes consequential; do not schedule all architecture only at project start.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S008`, `ESA:ESA-S010`, `ESA:ESA-S041`, `ESA:ESA-S026`, `ESA:ESA-S056`.

**Clusters:** `SSS-K016`, `SSS-K027`. **Tensions:** None. **Directional references:** 66 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/57`.

## ESA:ESA-059

**Description-standard conformance as quality certification**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Boundary between architecture-description requirements and realised architecture quality.

**Criterion / operative mechanism:** Conformance of an architecture description is not admitted as a certificate that the actual architecture satisfies stakeholder concerns.

**Trigger:** A standards claim about documentation is offered as proof of performance, security, maintainability or other operating quality.

**Non-trigger / cheaper path:** Use the standard for the description purpose and separately establish the selected system-quality claim.

**Authority:** Standards users, reviewers and recipients of assurance claims. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Translate the specific style, platform or domain constraint into obligations understood by implementers and affected consumers; labels alone communicate too little. Specific subject: Description-standard conformance as quality certification.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use the standard for the description purpose and separately establish the selected system-quality claim.", "reopening_condition_not_equated_with_retirement": "Reassess separately when the description edition or the implemented architecture changes.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S011`, `ESA:ESA-S012`, `ESA:ESA-S065`, `ESA:ESA-S020`, `ESA:ESA-S054`.

**Clusters:** `SSS-K007`, `SSS-K027`. **Tensions:** None. **Directional references:** 45 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/58`.

## ESA:ESA-060

**Autonomous architecting under open-ended requirements**

**Disposition:** `UNRESOLVED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Autonomous architecture decision and change process under open-ended requirements.

**Criterion / operative mechanism:** No general method for reliable autonomous architecting under evolving open-ended requirements is established by the examined evidence; preserve it as a research question rather than a prohibition or accepted capability.

**Trigger:** A proposed system is expected to choose, authorise, implement and validate consequential architecture with little or no external judgement.

**Non-trigger / cheaper path:** Use bounded assistance or a constrained controller with explicit admissible actions and independent evaluation.

**Authority:** Researchers and anyone proposing delegated architectural authority; the evidence does not supply that delegation. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Translate the specific style, platform or domain constraint into obligations understood by implementers and affected consumers; labels alone communicate too little. Specific subject: Autonomous architecting under open-ended requirements.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use bounded assistance or a constrained controller with explicit admissible actions and independent evaluation.", "reopening_condition_not_equated_with_retirement": "Reopen when representative end-to-end evidence or a rigorously bounded new capability materially changes the claim.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S059`, `ESA:ESA-S062`, `ESA:ESA-S063`.

**Clusters:** `SSS-K024`, `SSS-K033`. **Tensions:** None. **Directional references:** 78 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/59`.

## ESA:ESA-061

**Bounded semantic models and explicit translation**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Domain model validity and semantic relationships, distinct from physical topology.

**Criterion / operative mechanism:** State where a model’s terms and rules are valid, map actual relations to other models, and make required translation or shared meaning explicit.

**Trigger:** Different domains or teams use similar terms with incompatible meanings or need different model evolution.

**Non-trigger / cheaper path:** A single shared model and conversation can suffice where meanings genuinely coincide; do not invent contexts solely to match teams.

**Authority:** Domain experts and software teams on both sides of the boundary. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Producer and consumer exchange the obligations and hidden assumptions that affect composition; communicate changed semantics, not merely changed signatures. Specific subject: Bounded semantic models and explicit translation.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "A single shared model and conversation can suffice where meanings genuinely coincide; do not invent contexts solely to match teams.", "reopening_condition_not_equated_with_retirement": "Reopen when domain meaning, upstream/downstream obligations or the cost of translation changes.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S033`, `ESA:ESA-S035`, `ESA:ESA-S026`, `ESA:ESA-S060`.

**Clusters:** `SSS-K003`, `SSS-K029`. **Tensions:** None. **Directional references:** 35 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/60`.

## ESA:ESA-062

**Usability concerns allowed to reshape architecture**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Coupling between user interaction and architectural state/control mechanisms.

**Criterion / operative mechanism:** Allow a concrete user-interaction concern to change architecture when satisfying it requires system state, control, responsiveness or recoverability beyond visual layout.

**Trigger:** A user scenario cannot be met by presentation changes alone.

**Non-trigger / cheaper path:** Keep the change in local interface design when it has no substantive architectural implication; the source method itself discards such scenarios.

**Authority:** Users or their representatives, interaction designers and system engineers. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Supply stimuli, environment, responses and limits to designers and evaluators; tell affected stakeholders which scenarios were omitted or traded off. Specific subject: Usability concerns allowed to reshape architecture.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Keep the change in local interface design when it has no substantive architectural implication; the source method itself discards such scenarios.", "reopening_condition_not_equated_with_retirement": "Reopen when tasks, user populations or implementation constraints change the relevant scenario.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S018`, `ESA:ESA-S017`.

**Clusters:** `SSS-K006`, `SSS-K022`. **Tensions:** None. **Directional references:** 52 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/61`.

## ESA:ESA-063

**Safe change of adaptation policies and assurance assumptions**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Adaptation controller, monitoring model, policy and their revision boundaries.

**Criterion / operative mechanism:** Treat changes to sensors, architectural models, adaptation policies and assurance assumptions as consequential changes requiring bounded validation and continuity checks, not as automatically safe self-repair.

**Trigger:** A running adaptation mechanism or its evidence/decision rules are being revised.

**Non-trigger / cheaper path:** Use a reviewed offline policy change or retain the existing validated configuration where live self-revision adds avoidable risk.

**Authority:** Engineers/operators authorised to revise control rules; self-revision is only within an independently justified delegation. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Observations reach the people or bounded controller selecting a change; commands and post-change effects must not be confused with model updates. Specific subject: Safe change of adaptation policies and assurance assumptions.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use a reviewed offline policy change or retain the existing validated configuration where live self-revision adds avoidable risk.", "reopening_condition_not_equated_with_retirement": "Reopen or stop relying on the revised mechanism when continuity or its assumptions cannot be established.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S052`, `ESA:ESA-S053`, `ESA:ESA-S054`, `ESA:ESA-S055`, `ESA:ESA-S061`.

**Clusters:** `SSS-K009`, `SSS-K014`, `SSS-K015`, `SSS-K020`, `SSS-K025`. **Tensions:** None. **Directional references:** 117 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/62`.

## ESA:ESA-064

**Rationalised design explanation distinguished from actual history**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Design rationale and its historical/propositional status.

**Criterion / operative mechanism:** Provide a coherent explanation of why the current design is defensible while separately labelling historical records and reconstructed reasoning; do not make a tidy story into fabricated provenance.

**Trigger:** A later consumer needs an understandable design account and the original process was incomplete, iterative or poorly recorded.

**Non-trigger / cheaper path:** A concise explanation marked as reconstructed is better than reconstructing a fictitious complete decision chronology.

**Authority:** Documentation authors, maintainers and researchers relying on provenance. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** People making and inheriting decisions need the relevant context, consequences and exceptions; use existing communication channels when adequate. Specific subject: Rationalised design explanation distinguished from actual history.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "A concise explanation marked as reconstructed is better than reconstructing a fictitious complete decision chronology.", "reopening_condition_not_equated_with_retirement": "Reopen when evidence contradicts the rationale or reveals that the historical account was inferred.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S009`, `ESA:ESA-S027`, `ESA:ESA-S029`.

**Clusters:** `SSS-K008`, `SSS-K029`. **Tensions:** None. **Directional references:** 41 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/63`.

## ESA:ESA-065

**REST interaction constraints**

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Network interaction style at distributed-hypermedia scope.

**Criterion / operative mechanism:** Where its context fits, apply REST’s client/server, stateless interaction, cache, uniform-interface and layered constraints together, with optional code-on-demand and their associated trade-offs.

**Trigger:** An Internet-scale distributed-hypermedia interaction problem benefits from visibility, intermediaries and independent evolution.

**Non-trigger / cheaper path:** Use a simpler local interface or another protocol/style where its constraints impose costs without those benefits; do not call every HTTP API REST.

**Authority:** Client/server and intermediary designers and their independent consumers. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Translate the specific style, platform or domain constraint into obligations understood by implementers and affected consumers; labels alone communicate too little. Specific subject: REST interaction constraints.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use a simpler local interface or another protocol/style where its constraints impose costs without those benefits; do not call every HTTP API REST.", "reopening_condition_not_equated_with_retirement": "Reopen when application semantics or efficiency needs no longer justify the style’s constraints.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S034`, `ESA:ESA-S026`.

**Clusters:** `SSS-K003`. **Tensions:** None. **Directional references:** 18 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/64`.

## ESA:ESA-066

**Service visibility, interaction and real-world-effect contracts**

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Service relationship and externally meaningful effects, not merely interface syntax.

**Criterion / operative mechanism:** For a service relationship, distinguish awareness/reachability/willingness, the exchanged information/actions and the consequence that the consumer seeks, including policy or contract conditions.

**Trigger:** A consumer relies on another participant’s capability across a service boundary.

**Non-trigger / cheaper path:** A direct internal function contract may suffice when there is no separate service/participant relation to manage.

**Authority:** Providers and consumers within their real policies/contracts; each retains its actual authority boundary. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Translate the specific style, platform or domain constraint into obligations understood by implementers and affected consumers; labels alone communicate too little. Specific subject: Service visibility, interaction and real-world-effect contracts.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "A direct internal function contract may suffice when there is no separate service/participant relation to manage.", "reopening_condition_not_equated_with_retirement": "Reopen when capability, access conditions, semantics or the promised effect changes.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S035`, `ESA:ESA-S026`.

**Clusters:** `SSS-K003`, `SSS-K022`. **Tensions:** None. **Directional references:** 46 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/65`.

## ESA:ESA-067

**Driver-based recursive architectural design**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Design of a system or architectural element through requirement allocation and interfaces.

**Criterion / operative mechanism:** Use prioritised requirements and constraints to select a consequential element, choose design concepts, allocate responsibilities, define interfaces and refine the resulting obligations; revisit earlier choices when evaluation reveals a problem.

**Trigger:** A system or element needs deliberate architectural decomposition and the significant drivers are understood sufficiently to guide a choice.

**Non-trigger / cheaper path:** Use a focused local design decision when recursive decomposition would only reproduce the obvious.

**Authority:** Designers and affected stakeholders; algorithmic decomposition does not replace trade-off judgement. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** Designers and evaluators exchange alternatives, assumptions and decisive observations; risk identification is not an approval mandate. Specific subject: Driver-based recursive architectural design.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use a focused local design decision when recursive decomposition would only reproduce the obvious.", "reopening_condition_not_equated_with_retirement": "Reopen when child-level analysis, prototyping or changed drivers invalidate the parent choice.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S024`, `ESA:ESA-S025`, `ESA:ESA-S016`, `ESA:ESA-S010`, `ESA:ESA-S041`.

**Clusters:** `SSS-K034`. **Tensions:** `SSS-T007`. **Directional references:** 22 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/66`.

## ESA:ESA-068

**Connector compatibility under well-formedness constraints**

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Formal component ports, connector roles and glue in the Wright/CSP model.

**Criterion / operative mechanism:** When using the Wright/CSP formalism, establish both connector conservatism and deadlock freedom along with port/role compatibility before transferring the theorem’s deadlock-freedom result to an instantiated connector.

**Trigger:** A connector composition relies specifically on this formal deadlock-freedom guarantee.

**Non-trigger / cheaper path:** Use an ordinary protocol review or targeted model for a smaller obligation; do not impose Wright on unrelated architectures.

**Authority:** Formal modellers and implementers responsible for matching real interactions to the model. This criterion does not grant authority, resources or execution capability; those must already exist or be legitimately supplied.

**Communication/interaction:** The model author or extractor supplies relation definitions and mappings; the consumer receives both checked correspondences and known omissions. Specific subject: Connector compatibility under well-formedness constraints.

**Omission/retirement and retained reopening distinctions:** {"separate_omission_retirement_field_present": false, "non_trigger_cheap_path": "Use an ordinary protocol review or targeted model for a smaller obligation; do not impose Wright on unrelated architectures.", "reopening_condition_not_equated_with_retirement": "Reopen when glue, roles, port behaviour, topology or implementation mapping changes.", "policy": "Reopening, omission and retirement are not identical. Consult the exact original scope and controls; no unrecorded retirement condition is supplied."}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESA:ESA-S015`.

**Clusters:** `SSS-K003`, `SSS-K017`, `SSS-K020`. **Tensions:** `SSS-T008`, `SSS-T014`. **Directional references:** 74 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESA.zip!/EVOLVED_SOFTWARE_ARCHITECTURE_PROPERTY_LEDGER.json#/properties/67`.

## ESME:ESME-C001

**Authorised change intent and obligation revision**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Change request, affected behaviour and requirements history. Requests, contracts, code, data, configuration, manuals and maintenance readiness can all be affected.

**Criterion / operative mechanism:** An authorised change objective and explicit preserved or revised obligations can be compared with the actual result.

**Mechanism:** State the intended difference, affected obligations, legitimate decision maker and acceptance question before endorsing an intervention.

**Trigger:** A request, discovered defect or environmental pressure proposes changing an existing commitment.

**Non-trigger / cheaper path:** A short accepted issue with concrete examples is enough for a bounded low-risk change; reject or defer an unjustified request.

**Authority:** {"actors": "Those entitled to request or rely on the behaviour, not merely the test author.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Change request, affected behaviour and requirements history.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-001", "CONDITIONS": "A short accepted issue with concrete examples is enough for a bounded low-risk change; reject or defer an unjustified request. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-001", "CONDITIONS": "Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS001`, `ESME:ESME-CS004`, `ESME:ESME-CS041`, `ESME:ESME-CS025`, `ESME:ESME-CS064`, `ESME:ESME-CS065`, `ESME:ESME-CS069`, `ESME:ESME-CS006`, `ESME:ESME-CS083`.

**Clusters:** `SSS-K001`, `SSS-K009`, `SSS-K012`, `SSS-K034`. **Tensions:** `SSS-T001`, `SSS-T005`, `SSS-T009`. **Directional references:** 67 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/0`.

## ESME:ESME-C002

**Decision-relevant, edition-aware maintenance classification**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Request intent and actual changed artefacts. Requests, contracts, code, data, configuration, manuals and maintenance readiness can all be affected.

**Criterion / operative mechanism:** A mixed change can be described without hiding one purpose or treating a statistic from another taxonomy as comparable.

**Mechanism:** Use purpose labels alongside observable activity and artefact scope, permitting multiple purposes; include additive and emergency distinctions when using the 2022 terminology.

**Trigger:** Classification affects estimates, authorisation, reporting or selection of maintenance evidence.

**Non-trigger / cheaper path:** Do not label every commit when the label changes no decision; one explanatory sentence may suffice.

**Authority:** {"actors": "Request owner for intention; analyst for observed activities.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Request intent and actual changed artefacts.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-002", "CONDITIONS": "Do not label every commit when the label changes no decision; one explanatory sentence may suffice. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-002", "CONDITIONS": "Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS001`, `ESME:ESME-CS004`, `ESME:ESME-CS005`, `ESME:ESME-CS041`, `ESME:ESME-CS007`, `ESME:ESME-CS003`, `ESME:ESME-CS006`, `ESME:ESME-CS069`, `ESME:ESME-CS071`.

**Clusters:** `SSS-K001`, `SSS-K027`. **Tensions:** None. **Directional references:** 37 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/1`.

## ESME:ESME-C003

**Consequential non-code artefact scope**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Consequential code and non-code artefacts within a stated maintenance obligation.

**Criterion / operative mechanism:** The consequential non-code objects and their consumers are in the scope, with irrelevant objects omitted explicitly when disputed.

**Mechanism:** Include build, configuration, data, documentation and other non-code objects only where a current or planned maintenance obligation depends on them.

**Trigger:** A maintenance task depends on consequential state outside conventional source code.

**Non-trigger / cheaper path:** Keep the scope local; no organisation-wide inventory is required when the relevant inputs and consumers are already known.

**Authority:** {"actors": "Maintainer, operator and downstream consumer of the actual artefact.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Code, build inputs, schemas, configurations, operational instructions and handover material.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-003", "CONDITIONS": "Exclude irrelevant artefacts explicitly rather than constructing an organisation-wide inventory for a local task. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS001`, `ESME:ESME-CS006`, `ESME:ESME-CS041`, `ESME:ESME-CS024`, `ESME:ESME-CS062`.

**Clusters:** `SSS-K001`, `SSS-K025`. **Tensions:** None. **Directional references:** 44 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/2`.

## ESME:ESME-C004

**Demonstrated maintenance readiness and knowledge succession**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** The actual recipient or continuing maintenance group and its supported work.

**Criterion / operative mechanism:** The recipient can perform the relevant supported work, or the remaining capability/support limitation is explicit and acted upon.

**Mechanism:** At a transfer or continuity risk, establish that an actual willing recipient has the knowledge, access, time and practical ability to perform representative supported work; use explanation, supervised work or equivalent evidence.

**Trigger:** Initial handover, onboarding, departure, concentration or a new support obligation threatens practical maintenance capability.

**Non-trigger / cheaper path:** One representative diagnosis or change can suffice; stable small projects may instead make support limits or retirement explicit, without inventing extra maintainers.

**Authority:** Delivering and receiving maintainers exchange knowledge; managers provide time and authority rather than infer competence from attendance.

**Communication/interaction:** {"recipient_and_boundary": "Delivering and receiving maintainers exchange knowledge; managers provide time and authority rather than infer competence from attendance.", "content": "Use representative tasks, access checks and dialogue to test the receiving maintainer’s ability; preserve rationale and unresolved questions that the task exposes.", "adequacy_test": "The receiver can complete a representative task or the handoff plan changes to address demonstrated gaps.", "non_requirement": "No separate person, meeting, registry or tool is required merely because the analytical roles are distinct."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-003", "CONDITIONS": "Exclude irrelevant artefacts explicitly rather than constructing an organisation-wide inventory for a local task. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "A:ESME-064", "CONDITIONS": "A small stable project may need a clear support/retirement policy rather than recruiting multiple maintainers. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-004", "CONDITIONS": "Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}, {"INPUT_PROPERTY_KEY": "B:ESME-056", "CONDITIONS": "Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS001`, `ESME:ESME-CS006`, `ESME:ESME-CS041`, `ESME:ESME-CS024`, `ESME:ESME-CS062`, `ESME:ESME-CS013`, `ESME:ESME-CS016`, `ESME:ESME-CS032`, `ESME:ESME-CS060`, `ESME:ESME-CS069`, `ESME:ESME-CS070`, `ESME:ESME-CS089`, `ESME:ESME-CS073`, `ESME:ESME-CS017`, `ESME:ESME-CS085`.

**Clusters:** `SSS-K010`, `SSS-K021`, `SSS-K022`. **Tensions:** None. **Directional references:** 57 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/3`.

## ESME:ESME-C005

**Identifiable and recoverable maintenance baseline**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Source revision, build inputs, package versions, configuration and relevant data-state reference. Requests, contracts, code, data, configuration, manuals and maintenance readiness can all be affected.

**Criterion / operative mechanism:** Another authorised maintainer can locate the baseline and reproduce the relevant comparison; restoration is separately tested.

**Mechanism:** Identify and retain the exact baseline and configuration needed to interpret, build, compare or restore the changed system.

**Trigger:** An intervention or investigation requires attributing differences or returning to a known state.

**Non-trigger / cheaper path:** A versioned file and recorded command can suffice for a local deterministic artefact; retain richer dependencies only where needed.

**Authority:** {"actors": "Reviewer and operator comparing the same system, not merely matching a branch name.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Source revision, build inputs, package versions, configuration and relevant data-state reference.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-004", "CONDITIONS": "A versioned file and recorded command can suffice for a local deterministic artefact; retain richer dependencies only where needed. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-003", "CONDITIONS": "Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS019`, `ESME:ESME-CS041`, `ESME:ESME-CS051`, `ESME:ESME-CS053`, `ESME:ESME-CS063`, `ESME:ESME-CS069`, `ESME:ESME-CS080`, `ESME:ESME-CS088`.

**Clusters:** `SSS-K002`, `SSS-K015`. **Tensions:** None. **Directional references:** 46 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/4`.

## ESME:ESME-C006

**Bounded emergency containment and deliberate degradation**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Live service, temporary configuration or patch and follow-up obligation. Requests, contracts, code, data, configuration, manuals and maintenance readiness can all be affected.

**Criterion / operative mechanism:** The accepted containment objective is achieved within its loss and authority boundary, with recovery or permanent resolution still owned.

**Mechanism:** Authorise a bounded temporary change of objective, including disabling or degrading capability when that contains a more consequential failure; state residual obligations, accepted loss, observation and follow-up.

**Trigger:** An incident or serious exposure makes ordinary repair timing unsafe and a feasible containment action can reduce harm.

**Non-trigger / cheaper path:** Use normal repair or deliberate non-change when urgency is absent; a simple reversible feature disablement can need only proportionate evidence.

**Authority:** {"actors": "Affected users and the person authorised to accept temporary degradation.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Live service, temporary configuration or patch and follow-up obligation.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-005", "CONDITIONS": "Use normal repair when delay is tolerable; do not invent an emergency fast lane for ordinary convenience. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "A:ESME-089", "CONDITIONS": "Use a true local correction when feasible; do not invoke containment merely to obtain a passing suite. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS001`, `ESME:ESME-CS041`, `ESME:ESME-CS034`, `ESME:ESME-CS063`.

**Clusters:** `SSS-K020`. **Tensions:** None. **Directional references:** 26 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/5`.

## ESME:ESME-C007

**Four categories as a universally exhaustive taxonomy**

**Disposition:** `SUPERSEDED_BY_STRONGER_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Classified requests and activity statistics. Requests, contracts, code, data, configuration, manuals and maintenance readiness can all be affected.

**Criterion / operative mechanism:** Rejection is observable when mixed purposes or additive/emergency dimensions remain representable rather than forced away.

**Mechanism:** Candidate proposes requiring every maintenance activity to fit exactly one of four boxes.

**Trigger:** An audit or metric system attempts to treat four labels as exhaustive and exclusive.

**Non-trigger / cheaper path:** Use ESME-C002 and declare the edition and classification purpose.

**Authority:** {"actors": "The analyst using the categories to make comparisons.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Classified requests and activity statistics.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-006", "CONDITIONS": "Use ESME-C002 and declare the edition and classification purpose. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS003`, `ESME:ESME-CS006`, `ESME:ESME-CS041`, `ESME:ESME-CS001`, `ESME:ESME-CS004`, `ESME:ESME-CS005`.

**Clusters:** `SSS-K001`, `SSS-K027`. **Tensions:** None. **Directional references:** 32 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/6`.

## ESME:ESME-C008

**Environment-sensitive usefulness feedback**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** System-environment relationship and observed user outcomes. Fix the sampled release stream, artefact boundary, organisation and time unit before interpreting a trajectory.

**Criterion / operative mechanism:** An identified change in environmental fit has a reasoned response, which may be no change.

**Mechanism:** Observe changes in use, expectations and constraints; decide whether adaptation, servicing, unchanged operation or retirement best preserves justified usefulness.

**Trigger:** Evidence of changed environment, user dissatisfaction or new constraints, not age alone.

**Non-trigger / cheaper path:** For a stable environment, use occasional review or existing user feedback rather than continuous change.

**Authority:** {"actors": "Users and stakeholders whose activity the software serves.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "System-environment relationship and observed user outcomes.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-007", "CONDITIONS": "For a stable environment, use occasional review or existing user feedback rather than continuous change. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-006", "CONDITIONS": "Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS008`, `ESME:ESME-CS009`, `ESME:ESME-CS010`, `ESME:ESME-CS011`, `ESME:ESME-CS012`, `ESME:ESME-CS079`, `ESME:ESME-CS100`, `ESME:ESME-CS101`.

**Clusters:** `SSS-K014`, `SSS-K028`. **Tensions:** None. **Directional references:** 41 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/7`.

## ESME:ESME-C009

**Universal growth and inevitable deterioration as prescriptions**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Release histories and environmental conditions. Fix the sampled release stream, artefact boundary, organisation and time unit before interpreting a trajectory.

**Criterion / operative mechanism:** A decision does not mandate growth or replacement solely from age.

**Mechanism:** Candidate treats chronological age or lack of feature growth as sufficient grounds for intervention.

**Trigger:** Someone invokes an evolution law without identifying system class, measure or environment.

**Non-trigger / cheaper path:** Assess actual usefulness and obligations through ESME-C008 instead.

**Authority:** {"actors": "Actual users, not an age or LOC threshold.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Release histories and environmental conditions.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-008", "CONDITIONS": "Assess actual usefulness and obligations through ESME-C008 instead. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-010", "CONDITIONS": "Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS008`, `ESME:ESME-CS009`, `ESME:ESME-CS010`, `ESME:ESME-CS011`, `ESME:ESME-CS012`, `ESME:ESME-CS013`, `ESME:ESME-CS079`, `ESME:ESME-CS100`, `ESME:ESME-CS101`.

**Clusters:** `SSS-K027`, `SSS-K028`. **Tensions:** None. **Directional references:** 38 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/8`.

## ESME:ESME-C010

**Population-, metric- and timescale-bounded evolution claims**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Release sample, size/function/effort measures and data-extraction rules. Fix the sampled release stream, artefact boundary, organisation and time unit before interpreting a trajectory.

**Criterion / operative mechanism:** The claim and its planning use have a declared domain and contrary evidence rather than an unqualified law.

**Mechanism:** Before using an evolution regularity, state its population, measure, time horizon, model and empirical exceptions; narrow or withhold the forecast when these change.

**Trigger:** Growth, complexity, effort or decline measurements guide investment or generalisation.

**Non-trigger / cheaper path:** Use a simple trend with explicit units when it directly answers the decision; no statistical model is mandatory.

**Authority:** {"actors": "Analyst and decision maker interpreting the metric.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Release sample, size/function/effort measures and data-extraction rules.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-009", "CONDITIONS": "Use a simple trend with explicit units when it directly answers the decision; no statistical model is mandatory. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-007", "CONDITIONS": "Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS008`, `ESME:ESME-CS010`, `ESME:ESME-CS011`, `ESME:ESME-CS012`, `ESME:ESME-CS007`, `ESME:ESME-CS009`, `ESME:ESME-CS079`, `ESME:ESME-CS100`, `ESME:ESME-CS101`.

**Clusters:** `SSS-K018`, `SSS-K033`. **Tensions:** None. **Directional references:** 46 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/9`.

## ESME:ESME-C011

**Familiarity and demonstrated maintenance capacity**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Maintainer knowledge, workload, change volume and review outcomes. Fix the sampled release stream, artefact boundary, organisation and time unit before interpreting a trajectory.

**Criterion / operative mechanism:** The selected workload can be understood and supported by available people, with bottlenecks made explicit.

**Mechanism:** Use observed comprehension, review and recovery demand to constrain change intake and invest in knowledge when understanding becomes a bottleneck.

**Trigger:** Change volume or personnel turnover outpaces demonstrated ability to understand and maintain obligations.

**Non-trigger / cheaper path:** A small expert-maintained component may need only a direct conversation and modest change cadence.

**Authority:** {"actors": "Maintainers and those allocating time, not a fixed universal staffing formula.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Maintainer knowledge, workload, change volume and review outcomes.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-010", "CONDITIONS": "A small expert-maintained component may need only a direct conversation and modest change cadence. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-009", "CONDITIONS": "Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS010`, `ESME:ESME-CS013`, `ESME:ESME-CS016`, `ESME:ESME-CS018`, `ESME:ESME-CS036`, `ESME:ESME-CS037`, `ESME:ESME-CS008`, `ESME:ESME-CS073`, `ESME:ESME-CS089`, `ESME:ESME-CS085`.

**Clusters:** `SSS-K010`, `SSS-K026`. **Tensions:** `SSS-T016`. **Directional references:** 46 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/10`.

## ESME:ESME-C012

**Invariant organisational work rate as a planning law**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Historical effort and release-rate observations. Fix the sampled release stream, artefact boundary, organisation and time unit before interpreting a trajectory.

**Criterion / operative mechanism:** Forecasts retain uncertainty and do not treat changed conditions as impossible by definition.

**Mechanism:** Candidate fixes staffing, effort or delivery-rate predictions as invariant across organisations and tool/environment changes.

**Trigger:** A plan invokes a universal rate to dismiss changed capability or demand.

**Non-trigger / cheaper path:** Measure local capacity and uncertainty using ESME-C011.

**Authority:** {"actors": "Those planning support and change commitments.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Historical effort and release-rate observations.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-011", "CONDITIONS": "Measure local capacity and uncertainty using ESME-C011. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS008`, `ESME:ESME-CS010`, `ESME:ESME-CS011`, `ESME:ESME-CS012`, `ESME:ESME-CS036`, `ESME:ESME-CS037`.

**Clusters:** `SSS-K010`, `SSS-K027`. **Tensions:** None. **Directional references:** 34 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/11`.

## ESME:ESME-C013

**Bounded, change-specific comprehension**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** The affected feature and evidence needed for the current decision. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.

**Criterion / operative mechanism:** The maintainer can answer the consequential change questions and state remaining uncertainty.

**Mechanism:** Establish enough understanding to discriminate the pending change decision; expand inquiry when observed contradictions or impact escape invalidate that boundary.

**Trigger:** A maintainer cannot explain the relevant effect or uncertainty of a proposed intervention.

**Non-trigger / cheaper path:** Inspect the relevant code, test and domain example directly for a small familiar change; avoid mandatory reconstruction of everything.

**Authority:** {"actors": "Maintainer and reviewer who must act, with domain experts where intent is lost.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "The affected feature and evidence needed for the current decision.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-012", "CONDITIONS": "Inspect the relevant code, test and domain example directly for a small familiar change; avoid mandatory reconstruction of everything. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-011", "CONDITIONS": "Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS014`, `ESME:ESME-CS016`, `ESME:ESME-CS017`, `ESME:ESME-CS018`, `ESME:ESME-CS015`, `ESME:ESME-CS044`, `ESME:ESME-CS073`, `ESME:ESME-CS025`.

**Clusters:** `SSS-K004`, `SSS-K032`. **Tensions:** `SSS-T003`. **Directional references:** 44 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/12`.

## ESME:ESME-C014

**Criterion-relative static slicing**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Program statements, variable criterion and control/data dependencies. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.

**Criterion / operative mechanism:** The result states the criterion and model and is not represented as an exact minimal slice or a complete account of all real effects.

**Mechanism:** Use a declared slicing criterion and static dependence model to find potentially relevant statements, with explicit language, alias and environment assumptions.

**Trigger:** A consequential comprehension or impact question benefits from model-based relevance beyond a single observed run.

**Non-trigger / cheaper path:** Direct inspection suffices for a small obvious dependence; no slicing tool is required.

**Authority:** {"actors": "The observation specified by the slicing criterion, not every external effect.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Program statements, variable criterion and control/data dependencies.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-013", "CONDITIONS": "Manual inspection or a small dependency query may dominate building a slicer. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-013", "CONDITIONS": "Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS015`, `ESME:ESME-CS044`, `ESME:ESME-CS072`, `ESME:ESME-CS025`.

**Clusters:** `SSS-K004`, `SSS-K032`. **Tensions:** `SSS-T003`. **Directional references:** 44 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/13`.

## ESME:ESME-C015

**Execution-conditioned dynamic slicing and tracing**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Trace, instrumentation, inputs and runtime configuration. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.

**Criterion / operative mechanism:** The explanation is supported for the observed execution and does not become a universal absence-of-effect claim.

**Mechanism:** Trace a relevant execution and its data/control effects to answer a bounded question, retaining the input, environment and observation criterion.

**Trigger:** Observed behaviour or a concrete failure requires an execution-specific explanation.

**Non-trigger / cheaper path:** Use direct reproduction or existing logs when adequate; omit instrumentation when no relevant run can be obtained.

**Authority:** {"actors": "The observed run and selected values/events.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Trace, instrumentation, inputs and runtime configuration.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-014", "CONDITIONS": "A debugger or targeted log can suffice; do not collect exhaustive production traces without need. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-013", "CONDITIONS": "Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS044`, `ESME:ESME-CS045`, `ESME:ESME-CS015`, `ESME:ESME-CS025`, `ESME:ESME-CS072`.

**Clusters:** `SSS-K004`, `SSS-K032`. **Tensions:** None. **Directional references:** 40 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/14`.

## ESME:ESME-C016

**Corroborated design and intent recovery**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Implementation, domain rules, historical decisions and tacit operational knowledge. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.

**Criterion / operative mechanism:** The recovered explanation supports a concrete maintenance decision and identifies uncertain or contested intent.

**Mechanism:** Recover the rationale and abstractions needed for the change by checking code/behaviour against knowledgeable people and domain evidence.

**Trigger:** Undocumented behaviour or lost intent makes structural reconstruction insufficient.

**Non-trigger / cheaper path:** Ask a knowledgeable maintainer a focused question rather than commissioning a comprehensive recovery model.

**Authority:** {"actors": "Domain expert and successor maintainer, not solely the analysis tool.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Implementation, domain rules, historical decisions and tacit operational knowledge.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-015", "CONDITIONS": "Ask a knowledgeable maintainer a focused question rather than commissioning a comprehensive recovery model. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-015", "CONDITIONS": "Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS014`, `ESME:ESME-CS016`, `ESME:ESME-CS045`, `ESME:ESME-CS017`, `ESME:ESME-CS073`, `ESME:ESME-CS089`, `ESME:ESME-CS085`.

**Clusters:** `SSS-K007`, `SSS-K008`, `SSS-K029`. **Tensions:** None. **Directional references:** 62 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/15`.

## ESME:ESME-C017

**Faithful redocumentation with an actual consumer**

**Disposition:** `USEFUL_BUT_EASILY_BUREAUCRATISED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Documentation and its source artefact/version. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.

**Criterion / operative mechanism:** A consumer can use the description to perform the intended task; its version and limits are visible.

**Mechanism:** Produce or refresh a description only when a maintainer or downstream consumer needs it, and check it against the current subject.

**Trigger:** A useful explanation is missing, stale or inaccessible to an actual consumer.

**Non-trigger / cheaper path:** A checked example, code comment or targeted note can replace a large document.

**Authority:** {"actors": "The intended reader performing a named maintenance or operational task.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Documentation and its source artefact/version.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-016", "CONDITIONS": "A checked example, code comment or targeted note can replace a large document. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS014`, `ESME:ESME-CS041`, `ESME:ESME-CS016`, `ESME:ESME-CS059`.

**Clusters:** `SSS-K007`, `SSS-K008`, `SSS-K032`. **Tensions:** `SSS-T007`. **Directional references:** 64 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/16`.

## ESME:ESME-C018

**Recovery and redocumentation are not operative transformation**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Use source, generated artefacts, build/configuration state, execution traces, relevant history and rationale where each is needed to answer Q.

**Criterion / operative mechanism:** A recovered model is not counted as an implemented or validated change, and any real transformation has its own evidence and authority boundary.

**Mechanism:** Distinguish analysis that changes a representation or understanding from an intervention that alters the subject system; describe the actual abstraction level and effects.

**Trigger:** A recovery or modernisation activity is proposed, evaluated or handed off.

**Non-trigger / cheaper path:** Ordinary descriptions suffice for unambiguous local work; a taxonomy table is unnecessary.

**Authority:** Analysts recover evidence; authorised maintainers perform transformations; consumers must not infer one from the other.

**Communication/interaction:** {"recipient_and_boundary": "Analysts recover evidence; authorised maintainers perform transformations; consumers must not infer one from the other.", "content": "Label whether an activity recovers information, changes representation at the same abstraction, or reconstructs/changes the system; assign evidence and authority accordingly.", "adequacy_test": "The activity’s deliverable and actual effect are distinguishable and testable.", "non_requirement": "No separate person, meeting, registry or tool is required merely because the analytical roles are distinct."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-017", "CONDITIONS": "Keep recovery findings separate from an authorised intervention and its measured effect. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-014", "CONDITIONS": "Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS014`, `ESME:ESME-CS077`.

**Clusters:** `SSS-K007`, `SSS-K027`, `SSS-K029`. **Tensions:** None. **Directional references:** 71 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/17`.

## ESME:ESME-C019

**Exhaustive comprehension before every change**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Whole-system knowledge claims. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.

**Criterion / operative mechanism:** A local change may proceed on justified local evidence while unknown remote areas remain declared.

**Mechanism:** Candidate blocks every local change until the entire system and all tacit intent are recovered.

**Trigger:** A process imposes global understanding without a decision-relevant trigger.

**Non-trigger / cheaper path:** Use ESME-C013, widening only on consequential uncertainty.

**Authority:** {"actors": "The person deciding a particular bounded intervention.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Whole-system knowledge claims.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-018", "CONDITIONS": "Use ESME-C013, widening only on consequential uncertainty. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-016", "CONDITIONS": "Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS014`, `ESME:ESME-CS016`, `ESME:ESME-CS015`, `ESME:ESME-CS017`, `ESME:ESME-CS018`, `ESME:ESME-CS073`, `ESME:ESME-CS072`.

**Clusters:** `SSS-K008`, `SSS-K032`. **Tensions:** None. **Directional references:** 26 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/18`.

## ESME:ESME-C020

**Feature-location hypotheses and interactive refinement**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Feature description, code locations, calls, traces and change history. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.

**Criterion / operative mechanism:** Candidate locations are confirmed against the feature and false leads are recorded or discarded.

**Mechanism:** Treat names, search results, traces and history as candidate locations; verify relevance and revise the search from observed behaviour.

**Trigger:** A change request describes a feature whose implementation is not already known.

**Non-trigger / cheaper path:** A direct known location or maintainer pointer avoids a specialised search workflow.

**Authority:** {"actors": "Maintainer locating the implementation of the requested effect.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Feature description, code locations, calls, traces and change history.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-019", "CONDITIONS": "A direct known location or maintainer pointer avoids a specialised search workflow. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS017`, `ESME:ESME-CS020`, `ESME:ESME-CS045`, `ESME:ESME-CS018`.

**Clusters:** `SSS-K004`. **Tensions:** None. **Directional references:** 18 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/19`.

## ESME:ESME-C021

**Question-selected views and reconciliation of discrepancies**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Extracted components/relations, execution observations and build mapping. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.

**Criterion / operative mechanism:** The relevant conclusion states supporting views, discrepancies and remaining uncertainty.

**Mechanism:** Choose static, dynamic, historical and human views for the question; reconcile consequential disagreement instead of treating agreement or diagram completeness as proof.

**Trigger:** A single view leaves a consequential question unresolved or independent views disagree.

**Non-trigger / cheaper path:** One adequate direct view can settle a local question without a fusion framework.

**Authority:** {"actors": "Analyst and maintainer using the recovered view.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Extracted components/relations, execution observations and build mapping.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-020", "CONDITIONS": "Use a single sufficient view when cross-checks reveal no consequential gap. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-012", "CONDITIONS": "Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS014`, `ESME:ESME-CS045`, `ESME:ESME-CS016`, `ESME:ESME-CS072`, `ESME:ESME-CS073`, `ESME:ESME-CS017`, `ESME:ESME-CS086`, `ESME:ESME-CS025`.

**Clusters:** `SSS-K007`, `SSS-K008`, `SSS-K029`, `SSS-K032`. **Tensions:** None. **Directional references:** 69 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/20`.

## ESME:ESME-C022

**Revisable impact boundary with proportionate counterexample challenge**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Code, data, interfaces, configuration, builds, documentation and consumers. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.

**Criterion / operative mechanism:** The proposed boundary has a stated basis and uncertainty, and known consequential escapes change the scope or decision rather than being ignored.

**Mechanism:** State the consequential artefacts, consumers, dependencies and assumptions potentially affected; challenge the boundary in proportion to missed-effect consequence and reopen it when counterevidence appears.

**Trigger:** An edit can propagate outside its immediate location or alter a relied-on contract.

**Non-trigger / cheaper path:** Local review is sufficient when a defensible dependency boundary makes wider effects immaterial.

**Authority:** {"actors": "Affected technical and human consumers of the change.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Code, data, interfaces, configuration, builds, documentation and consumers.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-021", "CONDITIONS": "Local review is sufficient when a defensible dependency boundary makes wider effects immaterial. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-017", "CONDITIONS": "Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}, {"INPUT_PROPERTY_KEY": "B:ESME-021", "CONDITIONS": "Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS019`, `ESME:ESME-CS020`, `ESME:ESME-CS021`, `ESME:ESME-CS041`, `ESME:ESME-CS024`, `ESME:ESME-CS062`, `ESME:ESME-CS074`, `ESME:ESME-CS072`, `ESME:ESME-CS075`, `ESME:ESME-CS086`, `ESME:ESME-CS025`.

**Clusters:** `SSS-K004`, `SSS-K014`, `SSS-K019`, `SSS-K025`, `SSS-K030`, `SSS-K034`. **Tensions:** `SSS-T016`. **Directional references:** 114 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/21`.

## ESME:ESME-C023

**Interpreted historical co-change evidence**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Version-history transactions and recommended entities. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.

**Criterion / operative mechanism:** Suggested entities are either justified as relevant or dismissed; absent suggestions do not certify independence.

**Mechanism:** Use co-change suggestions to direct inspection; verify semantic or organisational relevance before adding an obligation.

**Trigger:** History contains sufficiently comparable changes and a maintainer needs likely impact leads.

**Non-trigger / cheaper path:** Skip mining for new code, sparse history or an obvious direct dependency.

**Authority:** {"actors": "Maintainer deciding what to inspect, not automatically what to edit.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Version-history transactions and recommended entities.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-022", "CONDITIONS": "Skip mining for new code, sparse history or an obvious direct dependency. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-019", "CONDITIONS": "Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS020`, `ESME:ESME-CS075`, `ESME:ESME-CS086`.

**Clusters:** `SSS-K004`, `SSS-K033`. **Tensions:** None. **Directional references:** 46 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/22`.

## ESME:ESME-C024

**Co-change correlation proves necessary dependency**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Mined transactions and candidate dependency edge. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.

**Criterion / operative mechanism:** A mined edge remains provisional until its meaning is established.

**Mechanism:** Candidate automatically edits every co-changed entity or treats absent co-change as proof of independence.

**Trigger:** An impact tool’s history score is used as operative authority.

**Non-trigger / cheaper path:** Inspect the proposed relation under ESME-C023 and seek direct dependency evidence.

**Authority:** {"actors": "Maintainer distinguishing prediction from requirement.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Mined transactions and candidate dependency edge.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-023", "CONDITIONS": "Inspect the proposed relation under ESME-C023 and seek direct dependency evidence. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS020`.

**Clusters:** `SSS-K004`, `SSS-K033`. **Tensions:** None. **Directional references:** 37 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/23`.

## ESME:ESME-C025

**Typed, multi-artefact dependency propagation**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Build scripts, resources, schemas, generated code, package inputs and tool versions. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.

**Criterion / operative mechanism:** Impact reasoning identifies relevant edge kinds and their limits, including consequential non-code propagation.

**Mechanism:** Represent the dependency types that can propagate the actual change, including build, generated, runtime, data and organisational/interface edges where consequential; distinguish observed or inferred edges from necessary ones.

**Trigger:** Non-source inputs or generators influence the target behaviour or regression selection.

**Non-trigger / cheaper path:** A recorded explicit command and input list suffice where there is no indirect generation or configuration.

**Authority:** {"actors": "Build consumer, tester and deployed runtime.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Build scripts, resources, schemas, generated code, package inputs and tool versions.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-024", "CONDITIONS": "A recorded explicit command and input list suffice where there is no indirect generation or configuration. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-018", "CONDITIONS": "Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS019`, `ESME:ESME-CS024`, `ESME:ESME-CS045`, `ESME:ESME-CS053`, `ESME:ESME-CS062`, `ESME:ESME-CS074`, `ESME:ESME-CS093`, `ESME:ESME-CS033`, `ESME:ESME-CS086`.

**Clusters:** `SSS-K004`, `SSS-K015`, `SSS-K019`, `SSS-K025`. **Tensions:** None. **Directional references:** 91 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/24`.

## ESME:ESME-C026

**Supported-observer compatibility obligations**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Public API, binary interface, protocol, persistent representation and supported versions. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.

**Criterion / operative mechanism:** Supported interactions remain valid or consumers have an authorised transition path with explicit limitations.

**Mechanism:** Declare supported clients and observers, test their relevant interactions and coordinate intentional breaking transitions.

**Trigger:** An interface, schema or protocol is relied on outside the edited component.

**Non-trigger / cheaper path:** Internal changes with no consequential external observer need no compatibility programme.

**Authority:** {"actors": "Actual client source/binary/runtime/data consumers.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Public API, binary interface, protocol, persistent representation and supported versions.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-025", "CONDITIONS": "Internal changes with no consequential external observer need no compatibility programme. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-038", "CONDITIONS": "Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS021`, `ESME:ESME-CS050`, `ESME:ESME-CS068`, `ESME:ESME-CS055`, `ESME:ESME-CS087`, `ESME:ESME-CS025`, `ESME:ESME-CS085`.

**Clusters:** `SSS-K003`, `SSS-K012`, `SSS-K030`. **Tensions:** `SSS-T005`. **Directional references:** 54 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/25`.

## ESME:ESME-C027

**Version labels prove compatibility**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Version labels and actual package/API behaviour. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.

**Criterion / operative mechanism:** A label is distinguished from evidence of the relevant compatibility property.

**Mechanism:** Candidate accepts or rejects a dependency solely from its version number as proof of actual compatibility.

**Trigger:** An update policy infers behaviour from a label without checking the applicable contract.

**Non-trigger / cheaper path:** Use the label as a triage signal and verify consequential interactions.

**Authority:** {"actors": "Downstream consumer of the labelled release.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Version labels and actual package/API behaviour.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-026", "CONDITIONS": "Use the label as a triage signal and verify consequential interactions. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS068`, `ESME:ESME-CS021`, `ESME:ESME-CS050`.

**Clusters:** `SSS-K012`. **Tensions:** None. **Directional references:** 12 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/26`.

## ESME:ESME-C028

**Semantic validation of concurrent and merged changes**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Base/left/right/merge versions, build definitions and behavioural interactions. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.

**Criterion / operative mechanism:** The merged state satisfies the jointly accepted objectives or an explicit conflict is resolved.

**Mechanism:** Check the actual merged or concurrently effective candidate against joint intent and supported effects; do not reuse isolated green results as evidence for the new combined state.

**Trigger:** Changes overlap semantically or one branch alters assumptions used by another.

**Non-trigger / cheaper path:** Ordinary compilation and targeted tests suffice for clearly independent low-risk changes.

**Authority:** {"actors": "Contributors and consumers of the merged result.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Base/left/right/merge versions, build definitions and behavioural interactions.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-027", "CONDITIONS": "Ordinary compilation and targeted tests suffice for clearly independent low-risk changes. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-022", "CONDITIONS": "Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS019`, `ESME:ESME-CS040`, `ESME:ESME-CS067`, `ESME:ESME-CS086`, `ESME:ESME-CS025`.

**Clusters:** `SSS-K019`. **Tensions:** None. **Directional references:** 20 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/27`.

## ESME:ESME-C029

**Scoped support of concurrent versions and variants**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Supported releases, feature/configuration choices, platform/tool versions and consumers. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.

**Criterion / operative mechanism:** Evidence and limitations can be mapped to the supported combinations and obsolete obligations are retired.

**Mechanism:** Identify supported releases/configurations and the obligations shared or different across them; select evidence by actual support promises and interaction risk.

**Trigger:** Several versions, build options, platforms or deployment variants remain supported.

**Non-trigger / cheaper path:** One explicitly supported configuration needs no elaborate matrix; retire unsupported variants transparently.

**Authority:** {"actors": "Maintainers supporting variants and downstream users relying on declared combinations.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Supported releases, feature/configuration choices, platform/tool versions and consumers.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-092", "CONDITIONS": "One explicitly supported configuration needs no elaborate matrix; retire unsupported variants transparently. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS019`, `ESME:ESME-CS005`, `ESME:ESME-CS041`, `ESME:ESME-CS050`, `ESME:ESME-CS024`.

**Clusters:** `SSS-K005`, `SSS-K030`. **Tensions:** `SSS-T013`. **Directional references:** 43 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/28`.

## ESME:ESME-C030

**Observer-relative preservation claims**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Pre/post implementation and relevant external context. Use exact pre/post code, language/tool versions and relevant runtime, persistence and external-interface context.

**Criterion / operative mechanism:** The claimed equivalence is stated relative to the observer and supported by appropriate evidence.

**Mechanism:** Name the observer, relevant environment and deliberately excluded observations before claiming behaviour preservation.

**Trigger:** A transformation is justified as non-functional or structure-only.

**Non-trigger / cheaper path:** For an isolated pure function, input/output and exceptional behaviour may be an adequate observer; no universal observer inventory is mandatory.

**Authority:** {"actors": "Specified outputs, exceptions, timing, resources, reflection, layout or persistence as warranted.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Pre/post implementation and relevant external context.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-028", "CONDITIONS": "For an isolated pure function, input/output and exceptional behaviour may be an adequate observer; no universal observer inventory is mandatory. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-023", "CONDITIONS": "Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS014`, `ESME:ESME-CS022`, `ESME:ESME-CS021`, `ESME:ESME-CS023`, `ESME:ESME-CS046`, `ESME:ESME-CS025`, `ESME:ESME-CS087`, `ESME:ESME-CS076`, `ESME:ESME-CS078`.

**Clusters:** `SSS-K003`, `SSS-K006`, `SSS-K012`, `SSS-K017`, `SSS-K029`, `SSS-K030`. **Tensions:** `SSS-T009`. **Directional references:** 97 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/29`.

## ESME:ESME-C031

**Applicable transformation rules and preconditions**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Transformation rule, input program, language semantics and engine version. Use exact pre/post code, language/tool versions and relevant runtime, persistence and external-interface context.

**Criterion / operative mechanism:** Applicability is demonstrated or transformation is refused/narrowed; exceptions remain explicit.

**Mechanism:** Check the transformation’s applicability conditions and supported constructs, then validate that the implemented tool follows them.

**Trigger:** A transformation’s correctness depends on names, bindings, inheritance, types or other structural conditions.

**Non-trigger / cheaper path:** Direct review of a small transformation can replace a general engine when its conditions are simple.

**Authority:** {"actors": "The observer specified by the preservation contract.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Transformation rule, input program, language semantics and engine version.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-029", "CONDITIONS": "Direct review of a small transformation can replace a general engine when its conditions are simple. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-024", "CONDITIONS": "Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS022`, `ESME:ESME-CS046`, `ESME:ESME-CS076`, `ESME:ESME-CS025`.

**Clusters:** `SSS-K017`. **Tensions:** None. **Directional references:** 16 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/30`.

## ESME:ESME-C032

**Validation of transformation-engine implementation**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** The selected transformation engine, implementation and version.

**Criterion / operative mechanism:** The relevant engine behaviour has bounded validation evidence and known exclusions.

**Mechanism:** Exercise relevant tool/version transformations with targeted counterexamples, compilation, differential or other justified checks; investigate disagreements.

**Trigger:** A transformation engine is new, changed, historically faulty or used outside its validated envelope.

**Non-trigger / cheaper path:** For a small trusted operation, review its concrete output rather than building a universal tool-validation campaign.

**Authority:** {"actors": "Tool user and reviewer who rely on the engine’s preservation claim.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Engine version, transformation, generated or real test inputs and resulting artefacts.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-030", "CONDITIONS": "For a small trusted operation, review its concrete output rather than building a universal tool-validation campaign. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS046`, `ESME:ESME-CS024`.

**Clusters:** `SSS-K007`, `SSS-K015`, `SSS-K017`. **Tensions:** None. **Directional references:** 58 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/31`.

## ESME:ESME-C033

**Validation of the actual transformed candidate**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** The actual transformed candidate and the observations required of it.

**Criterion / operative mechanism:** The exact candidate has evidence for its intended and preserved obligations, with unresolved failures visible.

**Mechanism:** Check the actual transformed baseline using relevant semantic reasoning, tests or comparison; invalidate earlier evidence when consequential inputs change.

**Trigger:** Any consequential restructuring, generated patch or composed change is proposed for acceptance.

**Non-trigger / cheaper path:** A small reviewed diff and a targeted check may be enough; no universal demand for multiple expensive validators.

**Authority:** Maintainers and reviewers consume validation evidence; the generator cannot self-certify correctness solely through its own success flag.

**Communication/interaction:** {"recipient_and_boundary": "Maintainers and reviewers consume validation evidence; the generator cannot self-certify correctness solely through its own success flag.", "content": "Check the actual transformed baseline using relevant semantic reasoning, tests or comparison; invalidate earlier evidence when consequential inputs change.", "adequacy_test": "The exact candidate has evidence for its intended and preserved obligations, with unresolved failures visible.", "non_requirement": "No separate person, meeting, registry or tool is required merely because the analytical roles are distinct."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "B:ESME-025", "CONDITIONS": "Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS022`, `ESME:ESME-CS025`, `ESME:ESME-CS076`, `ESME:ESME-CS034`, `ESME:ESME-CS092`.

**Clusters:** `SSS-K007`, `SSS-K015`, `SSS-K017`. **Tensions:** None. **Directional references:** 58 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/32`.

## ESME:ESME-C034

**Task-costed structural improvement with bounded payoff review**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Structure, expected change scenarios and intervention effort. Use exact pre/post code, language/tool versions and relevant runtime, persistence and external-interface context.

**Criterion / operative mechanism:** A structural investment has a task-specific benefit hypothesis, cost/uncertainty account and a continuation, revision or stop decision based on applicable observations.

**Mechanism:** Name the recurring maintenance task and expected improvement, compare transition and opportunity costs, intervene within a justified bound and review observed task outcomes before continuing or expanding.

**Trigger:** Repeated or credible upcoming work is materially hindered by the current structure and a feasible change may improve it.

**Non-trigger / cheaper path:** Leave adequate stable structure alone; a small relevant transformation and one representative task can suffice without an economic dashboard.

**Authority:** {"actors": "Future maintainers and those bearing current conversion cost.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Structure, expected change scenarios and intervention effort.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-031", "CONDITIONS": "Perform a bounded repair or defer cleanup when no plausible future demand repays its cost. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-008", "CONDITIONS": "Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}, {"INPUT_PROPERTY_KEY": "B:ESME-027", "CONDITIONS": "Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}, {"INPUT_PROPERTY_KEY": "B:ESME-052", "CONDITIONS": "Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS022`, `ESME:ESME-CS027`, `ESME:ESME-CS059`, `ESME:ESME-CS023`, `ESME:ESME-CS058`, `ESME:ESME-CS008`, `ESME:ESME-CS091`, `ESME:ESME-CS076`, `ESME:ESME-CS078`, `ESME:ESME-CS100`, `ESME:ESME-CS077`, `ESME:ESME-CS090`.

**Clusters:** `SSS-K006`, `SSS-K011`, `SSS-K016`, `SSS-K026`, `SSS-K031`. **Tensions:** None. **Directional references:** 80 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/33`.

## ESME:ESME-C035

**Task-validated maintainability measurements**

**Disposition:** `USEFUL_BUT_EASILY_GAMED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Metric definition, affected structure and real maintenance tasks. Use exact pre/post code, language/tool versions and relevant runtime, persistence and external-interface context.

**Criterion / operative mechanism:** Metric movement is not reported as benefit unless the relevant outcome is also supported.

**Mechanism:** Use metrics to identify questions and compare a declared local objective; cross-check against actual task cost and requirements.

**Trigger:** A metric might reveal a bottleneck not already understood.

**Non-trigger / cheaper path:** Direct evidence of difficult changes or a small review may dominate metric dashboards.

**Authority:** {"actors": "Maintainer or planner interpreting the signal.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Metric definition, affected structure and real maintenance tasks.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-032", "CONDITIONS": "Direct evidence of difficult changes or a small review may dominate metric dashboards. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-053", "CONDITIONS": "Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS023`, `ESME:ESME-CS058`, `ESME:ESME-CS059`, `ESME:ESME-CS078`, `ESME:ESME-CS090`, `ESME:ESME-CS100`.

**Clusters:** `SSS-K006`, `SSS-K016`, `SSS-K031`, `SSS-K033`. **Tensions:** None. **Directional references:** 88 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/34`.

## ESME:ESME-C036

**Catalogue compliance as a maintenance property**

**Disposition:** `CEREMONY_NOT_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Transformation label and resulting code. Use exact pre/post code, language/tool versions and relevant runtime, persistence and external-interface context.

**Criterion / operative mechanism:** The acceptance decision refers to preservation and benefit evidence rather than a label.

**Mechanism:** Candidate treats a named pattern, tool command or catalogue count as evidence of successful improvement.

**Trigger:** A process rewards transformations performed rather than obligations preserved or cost reduced.

**Non-trigger / cheaper path:** Use ESME-C030–031 without requiring a named catalogue entry.

**Authority:** {"actors": "Actual reviewer and future maintainer, not a compliance counter.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Transformation label and resulting code.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-033", "CONDITIONS": "Use ESME-C030–031 without requiring a named catalogue entry. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS022`, `ESME:ESME-CS041`, `ESME:ESME-CS023`, `ESME:ESME-CS046`.

**Clusters:** `SSS-K016`, `SSS-K027`. **Tensions:** None. **Directional references:** 40 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/35`.

## ESME:ESME-C037

**Characterisation as descriptive evidence, not automatic specification**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Legacy outputs, tests, data examples and requirement interpretation. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Criterion / operative mechanism:** Observed behaviour is distinguished from authorised expectations; a golden output is not automatically an immutable obligation.

**Mechanism:** Record relevant existing observations to expose relied-on behaviour and candidate regressions, then determine which expectations are legitimately retained or deliberately changed.

**Trigger:** Important undocumented behaviour makes a change risky.

**Non-trigger / cheaper path:** A focused example or domain review may suffice instead of broad snapshot generation.

**Authority:** {"actors": "Domain consumer whose reliance may or may not legitimise the behaviour.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Legacy outputs, tests, data examples and requirement interpretation.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-034", "CONDITIONS": "A focused example or domain review may suffice instead of broad snapshot generation. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-030", "CONDITIONS": "Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}, {"INPUT_PROPERTY_KEY": "B:ESME-070", "CONDITIONS": "Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS025`, `ESME:ESME-CS041`, `ESME:ESME-CS034`, `ESME:ESME-CS064`, `ESME:ESME-CS065`, `ESME:ESME-CS099`.

**Clusters:** `SSS-K012`. **Tensions:** `SSS-T009`. **Directional references:** 22 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/36`.

## ESME:ESME-C038

**Intentional differences and independently retained obligations**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** New objective, preservation set, tests and other evidence. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Criterion / operative mechanism:** Acceptance can explain both the justified difference and the justified continuity.

**Mechanism:** Separately establish evidence for the intended new effect and the consequential behaviours that must survive, with uncertainty stated for both.

**Trigger:** Any intervention changes or risks a relied-on behaviour.

**Non-trigger / cheaper path:** One test may address both obligations if its distinct assertions and coverage are clear; no separate team is inherently required.

**Authority:** {"actors": "Requesting stakeholder and existing consumers.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "New objective, preservation set, tests and other evidence.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-035", "CONDITIONS": "One test may address both obligations if its distinct assertions and coverage are clear; no separate team is inherently required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-026", "CONDITIONS": "Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS025`, `ESME:ESME-CS026`, `ESME:ESME-CS041`, `ESME:ESME-CS034`, `ESME:ESME-CS064`, `ESME:ESME-CS065`, `ESME:ESME-CS069`, `ESME:ESME-CS022`, `ESME:ESME-CS047`, `ESME:ESME-CS099`.

**Clusters:** `SSS-K006`, `SSS-K009`, `SSS-K012`, `SSS-K030`, `SSS-K034`. **Tensions:** `SSS-T001`, `SSS-T009`. **Directional references:** 97 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/37`.

## ESME:ESME-C039

**Oracle provenance and justified expected outcomes**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** The provenance and scope of the observation or acceptance criterion.

**Criterion / operative mechanism:** The acceptance claim distinguishes observed passage from the supported intended and preserved obligations.

**Mechanism:** Trace acceptance expectations to independent requirements, adjudicated behaviour, domain properties or credible reference evidence; state gaps and conflicts.

**Trigger:** Test results support a change decision or a test expectation itself changes.

**Non-trigger / cheaper path:** A trusted narrow assertion may suffice for a simple obligation; do not build a specification language merely for appearance.

**Authority:** Domain experts and obligation owners adjudicate expectations; tests and agents produce evidence, not authority.

**Communication/interaction:** {"recipient_and_boundary": "Domain experts and obligation owners adjudicate expectations; tests and agents produce evidence, not authority.", "content": "Trace acceptance expectations to independent requirements, adjudicated behaviour, domain properties or credible reference evidence; state gaps and conflicts.", "adequacy_test": "The acceptance claim distinguishes observed passage from the supported intended and preserved obligations.", "non_requirement": "No separate person, meeting, registry or tool is required merely because the analytical roles are distinct."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "B:ESME-029", "CONDITIONS": "Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS025`, `ESME:ESME-CS034`, `ESME:ESME-CS064`, `ESME:ESME-CS092`.

**Clusters:** `SSS-K006`, `SSS-K007`, `SSS-K015`, `SSS-K017`, `SSS-K018`. **Tensions:** `SSS-T012`. **Directional references:** 78 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/38`.

## ESME:ESME-C040

**Assumption-bounded regression-test selection**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Original/changed program, existing test suite and selection dependencies. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Criterion / operative mechanism:** Selected-suite rationale and exclusions are visible; unsupported change kinds trigger fallback.

**Mechanism:** Choose a selection method only within its dependency/language envelope; escalate to broader execution when relevant changes fall outside it.

**Trigger:** Running the whole available suite has material cost and sound selection can be justified.

**Non-trigger / cheaper path:** Run the full affordable suite; do not add selection complexity when it saves little.

**Authority:** {"actors": "Tests in the declared suite, not all possible user observations.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Original/changed program, existing test suite and selection dependencies.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-036", "CONDITIONS": "Run the full affordable suite; do not add selection complexity when it saves little. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-034", "CONDITIONS": "Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS026`, `ESME:ESME-CS047`, `ESME:ESME-CS024`, `ESME:ESME-CS025`.

**Clusters:** `SSS-K015`, `SSS-K017`, `SSS-K018`. **Tensions:** `SSS-T008`. **Directional references:** 56 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/39`.

## ESME:ESME-C041

**Action-relevant regression-test prioritisation**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Test set, order, duration estimates and failure relevance. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Criterion / operative mechanism:** The ordering objective is stated and omitted tests, if any, remain known.

**Mechanism:** Order tests by justified expected information or risk within available time, while separately deciding whether stopping early is acceptable.

**Trigger:** A time-constrained test run benefits from earlier actionable failures.

**Non-trigger / cheaper path:** Keep the existing order when the suite is cheap or priority estimates are unreliable.

**Authority:** {"actors": "Developer or release decision maker waiting for information.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Test set, order, duration estimates and failure relevance.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-037", "CONDITIONS": "Keep the existing order when the suite is cheap or priority estimates are unreliable. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-035", "CONDITIONS": "Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS048`, `ESME:ESME-CS047`, `ESME:ESME-CS025`, `ESME:ESME-CS105`, `ESME:ESME-CS098`.

**Clusters:** `SSS-K018`. **Tensions:** `SSS-T008`. **Directional references:** 28 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/40`.

## ESME:ESME-C042

**Mutation-based challenge of test sensitivity**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Mutants, tests, fault model and targeted behaviour. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Criterion / operative mechanism:** A surviving relevant mutant yields a useful test/observation or an explained non-obligation.

**Mechanism:** Use relevant mutation operators to challenge specific test weaknesses; investigate surviving mutants and equivalent or irrelevant mutants separately.

**Trigger:** A consequential preservation obligation may be weakly exercised by the current tests.

**Non-trigger / cheaper path:** Add a targeted real-fault regression case or review a missing assertion rather than run broad mutation campaigns.

**Authority:** {"actors": "Maintainer assessing tests, not treating a score as requirements completeness.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Mutants, tests, fault model and targeted behaviour.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-038", "CONDITIONS": "Add a targeted real-fault regression case or review a missing assertion rather than run broad mutation campaigns. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-033", "CONDITIONS": "Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS049`, `ESME:ESME-CS025`, `ESME:ESME-CS047`.

**Clusters:** `SSS-K018`. **Tensions:** None. **Directional references:** 18 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/41`.

## ESME:ESME-C043

**Differential comparison under a justified reference relation**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** The implementations, input domain and comparison interpretation used by differential evidence.

**Criterion / operative mechanism:** Observed differences are classified as intended, erroneous or unresolved rather than automatically counted as bugs.

**Mechanism:** Run comparable inputs against the old/new or independent implementations, locate differences and adjudicate them against intended obligations.

**Trigger:** A credible reference exists and executions can be made comparable.

**Non-trigger / cheaper path:** Use direct expected results for simple cases; no duplicate implementation is required where it adds less evidence than it costs.

**Authority:** Maintainers investigate discrepancies; a reference implementation is evidence, not an unquestionable specification.

**Communication/interaction:** {"recipient_and_boundary": "Maintainers investigate discrepancies; a reference implementation is evidence, not an unquestionable specification.", "content": "Run comparable inputs against the old/new or independent implementations, locate differences and adjudicate them against intended obligations.", "adequacy_test": "Observed differences are classified as intended, erroneous or unresolved rather than automatically counted as bugs.", "non_requirement": "No separate person, meeting, registry or tool is required merely because the analytical roles are distinct."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-039", "CONDITIONS": "Manual expected-value examples suffice for simple known behaviour; do not introduce an untrusted reference unnecessarily. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-031", "CONDITIONS": "Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS025`, `ESME:ESME-CS046`, `ESME:ESME-CS064`, `ESME:ESME-CS065`, `ESME:ESME-CS103`.

**Clusters:** `SSS-K018`. **Tensions:** None. **Directional references:** 18 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/42`.

## ESME:ESME-C044

**Justified metamorphic relations as partial oracles**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** The justified relation between transformed inputs and expected output relations.

**Criterion / operative mechanism:** The relation is checked for stated cases, with no claim that satisfaction proves arbitrary output correctness.

**Mechanism:** Choose justified input/output relations, execute related cases and investigate violations while preserving the relation’s domain assumptions.

**Trigger:** Exact expected results are difficult but a relevant mathematical or domain relation is credible.

**Non-trigger / cheaper path:** Use ordinary assertions when expected results are cheap; do not invent weak relations to inflate a test count.

**Authority:** Domain specialists justify relations; maintainers implement and interpret tests.

**Communication/interaction:** {"recipient_and_boundary": "Domain specialists justify relations; maintainers implement and interpret tests.", "content": "Choose justified input/output relations, execute related cases and investigate violations while preserving the relation’s domain assumptions.", "adequacy_test": "The relation is checked for stated cases, with no claim that satisfaction proves arbitrary output correctness.", "non_requirement": "No separate person, meeting, registry or tool is required merely because the analytical roles are distinct."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-039", "CONDITIONS": "Manual expected-value examples suffice for simple known behaviour; do not introduce an untrusted reference unnecessarily. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-032", "CONDITIONS": "Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS025`, `ESME:ESME-CS046`, `ESME:ESME-CS064`, `ESME:ESME-CS065`, `ESME:ESME-CS102`.

**Clusters:** `SSS-K017`, `SSS-K018`. **Tensions:** None. **Directional references:** 30 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/43`.

## ESME:ESME-C045

**Passing all selected tests proves correctness**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Patch, test suite, harness, environment and accepted requirements. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Criterion / operative mechanism:** The reported conclusion does not exceed the actual tested obligation and environment.

**Mechanism:** Candidate promotes test passage to complete correctness without proving coverage and oracle adequacy.

**Trigger:** A release or generated patch is accepted solely because a finite suite is green.

**Non-trigger / cheaper path:** Make a scoped test claim and add only the missing consequential evidence, rather than demand impossible universal testing.

**Authority:** {"actors": "Relevant users beyond the exercised test inputs.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Patch, test suite, harness, environment and accepted requirements.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-040", "CONDITIONS": "Make a scoped test claim and add only the missing consequential evidence, rather than demand impossible universal testing. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS025`, `ESME:ESME-CS026`, `ESME:ESME-CS024`, `ESME:ESME-CS034`, `ESME:ESME-CS064`, `ESME:ESME-CS065`.

**Clusters:** `SSS-K007`, `SSS-K018`, `SSS-K033`. **Tensions:** None. **Directional references:** 57 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/44`.

## ESME:ESME-C046

**Build provenance and relevant reproducibility**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Source, compiler, packaging tools, dependencies, environment and released artefact. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Criterion / operative mechanism:** A relevant rebuild or exact identity comparison succeeds, or its nondeterminism and limitations are explicit.

**Mechanism:** Record the relevant build inputs and verify a repeatable path to the released artefact; distinguish bitwise reproducibility from functional repeatability.

**Trigger:** Attribution, support, archival reuse or supply-chain checks depend on connecting source and delivered artefacts.

**Non-trigger / cheaper path:** For a directly interpreted single file, version identity and execution environment may be enough; do not mandate byte-identical builds without a consumer.

**Authority:** {"actors": "Maintainer or downstream party comparing built outputs.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Source, compiler, packaging tools, dependencies, environment and released artefact.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-041", "CONDITIONS": "For a directly interpreted single file, version identity and execution environment may be enough; do not mandate byte-identical builds without a consumer. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-036", "CONDITIONS": "Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS019`, `ESME:ESME-CS051`, `ESME:ESME-CS053`, `ESME:ESME-CS063`, `ESME:ESME-CS088`, `ESME:ESME-CS069`, `ESME:ESME-CS080`.

**Clusters:** `SSS-K002`, `SSS-K015`. **Tensions:** None. **Directional references:** 46 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/45`.

## ESME:ESME-C047

**Actionable integration feedback**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Integrated revisions, build/test results and responsible maintainers. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Criterion / operative mechanism:** Integration failures are attributed and resolved or consciously deferred before relying on the combined state.

**Mechanism:** Integrate at a cadence suited to actual dependencies and run evidence that can detect meaningful interaction failures; communicate failures to someone able to act.

**Trigger:** Concurrent changes or delayed integration conceal incompatibilities.

**Non-trigger / cheaper path:** A small serially maintained artefact can use direct build/test checks without a dedicated service or fixed cadence.

**Authority:** {"actors": "Contributors and release consumers affected by integration.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Integrated revisions, build/test results and responsible maintainers.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-042", "CONDITIONS": "A small serially maintained artefact can use direct build/test checks without a dedicated service or fixed cadence. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-037", "CONDITIONS": "Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS019`, `ESME:ESME-CS041`, `ESME:ESME-CS051`, `ESME:ESME-CS024`, `ESME:ESME-CS067`, `ESME:ESME-CS069`, `ESME:ESME-CS098`, `ESME:ESME-CS084`.

**Clusters:** `SSS-K014`, `SSS-K019`. **Tensions:** None. **Directional references:** 42 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/46`.

## ESME:ESME-C048

**Observable, actionable staged exposure**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Release candidate, control, traffic population, data/configuration and monitoring. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Criterion / operative mechanism:** Expansion is justified by relevant observations; missing signal is not treated as a pass.

**Mechanism:** Choose an isolatable population, meaningful observation window and attributable metrics; stop or revise on adverse or insufficient evidence.

**Trigger:** Production-only uncertainties can be investigated with genuinely limited and reversible exposure.

**Non-trigger / cheaper path:** Use direct release with proportionate checks for low-impact changes, or offline rehearsal where live exposure is unsafe.

**Authority:** {"actors": "Real users and operators observing relevant service consequences.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Release candidate, control, traffic population, data/configuration and monitoring.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-043", "CONDITIONS": "Use direct release with proportionate checks for low-impact changes, or offline rehearsal where live exposure is unsafe. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-040", "CONDITIONS": "Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS052`, `ESME:ESME-CS063`, `ESME:ESME-CS030`, `ESME:ESME-CS031`, `ESME:ESME-CS082`.

**Clusters:** `SSS-K014`. **Tensions:** None. **Directional references:** 26 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/47`.

## ESME:ESME-C049

**Effect-aware recovery, forward repair and changing returnability**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** The remaining recovery and forward-repair options for the actual effect history.

**Criterion / operative mechanism:** At the consequential action boundary, the promised remaining recovery/containment route is feasible for the relevant state, or the residual loss is explicitly accepted by the appropriate decision maker.

**Mechanism:** Identify persistent and external effects, demonstrate the restoration, containment or forward-repair route actually promised, and reconsider remaining options before a transition invalidates them; obtain legitimate acceptance for residual irreversibility.

**Trigger:** A change or exposure can leave consequential state or lose an existing recovery option.

**Non-trigger / cheaper path:** A pure reversible local edit may need only one verified return path; acceptable reconstruction or forward repair can replace elaborate rollback machinery.

**Authority:** {"actors": "Operator and affected data/service consumers.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Code, data, schema, external actions, backup/restore tooling and effect history.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-044", "CONDITIONS": "For an isolated reversible file edit, a verified prior file may suffice; richer recovery is unnecessary when no external effect exists. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "A:ESME-095", "CONDITIONS": "A single reversible edit needs only one verified return path; no global state machine is required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-041", "CONDITIONS": "Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS041`, `ESME:ESME-CS050`, `ESME:ESME-CS052`, `ESME:ESME-CS063`, `ESME:ESME-CS019`, `ESME:ESME-CS029`, `ESME:ESME-CS093`.

**Clusters:** `SSS-K013`, `SSS-K020`. **Tensions:** `SSS-T010`. **Directional references:** 51 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/48`.

## ESME:ESME-C050

**Bounded local repair as an alternative to restructuring**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Fault location, affected behaviour and support horizon. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.

**Criterion / operative mechanism:** The fault is corrected and preserved obligations are evidenced within the stated boundary.

**Mechanism:** Choose a small repair when it satisfies the obligation at lower expected total cost and risk than structural transformation.

**Trigger:** A local fault has a justified impact boundary and no demonstrated need for broad redesign.

**Non-trigger / cheaper path:** No change is cheaper where the reported behaviour is acceptable; a focused correction is cheaper than modernisation when adequate.

**Authority:** {"actors": "User needing restoration and maintainer bearing repair risk.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Fault location, affected behaviour and support horizon.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-045", "CONDITIONS": "No change is cheaper where the reported behaviour is acceptable; a focused correction is cheaper than modernisation when adequate. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS001`, `ESME:ESME-CS013`, `ESME:ESME-CS041`, `ESME:ESME-CS023`, `ESME:ESME-CS059`.

**Clusters:** `SSS-K028`. **Tensions:** None. **Directional references:** 19 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/49`.

## ESME:ESME-C051

**Legacy value distinguished from technical age**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Existing service, domain behaviour, technology dependencies and support capacity. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.

**Criterion / operative mechanism:** A continue/change/retire decision is supported by actual value and risk rather than age alone.

**Mechanism:** Assess obligations, supportability and change cost directly; treat age as a possible clue, not proof that replacement is needed.

**Trigger:** A system is labelled legacy or obsolete as grounds for investment.

**Non-trigger / cheaper path:** Continue operation with existing support when useful and adequately maintainable.

**Authority:** {"actors": "Current users and maintainers, not a technology-fashion ranking.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Existing service, domain behaviour, technology dependencies and support capacity.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-046", "CONDITIONS": "Continue operation with existing support when useful and adequately maintainable. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS013`, `ESME:ESME-CS029`, `ESME:ESME-CS041`, `ESME:ESME-CS059`.

**Clusters:** `SSS-K011`, `SSS-K028`. **Tensions:** None. **Directional references:** 32 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/50`.

## ESME:ESME-C052

**Obligation- and lifecycle-based intervention selection**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Existing capability, candidate host/platform/implementation and transition obligations. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.

**Criterion / operative mechanism:** The chosen branch has a defensible advantage over feasible no-change, repair or migration alternatives.

**Mechanism:** Compare feasible interventions by preserved obligations, domain recovery, data conversion, support horizon and transition cost; do not collapse all modernisation into rewriting.

**Trigger:** Current maintenance no longer meets justified needs or costs warrant reconsideration.

**Non-trigger / cheaper path:** Compare only credible alternatives; a short repair-versus-replace decision can suffice.

**Authority:** {"actors": "Owner of the capability, maintainers, operators and affected consumers.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Existing capability, candidate host/platform/implementation and transition obligations.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-047", "CONDITIONS": "Compare only credible alternatives; a short repair-versus-replace decision can suffice. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-042", "CONDITIONS": "Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS013`, `ESME:ESME-CS029`, `ESME:ESME-CS031`, `ESME:ESME-CS056`, `ESME:ESME-CS059`, `ESME:ESME-CS030`, `ESME:ESME-CS083`, `ESME:ESME-CS084`.

**Clusters:** `SSS-K005`, `SSS-K011`, `SSS-K013`, `SSS-K023`, `SSS-K028`. **Tensions:** None. **Directional references:** 60 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/51`.

## ESME:ESME-C053

**Incremental responsibility transfer at viable seams**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Legacy/successor components, seam, routing, shared data and temporary adapters. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.

**Criterion / operative mechanism:** A slice of responsibility is actually transferred and temporary coexistence remains controlled.

**Mechanism:** Identify a separable responsibility and route or transfer it under a tested coexistence protocol, with a funded exit for temporary integration.

**Trigger:** Useful seams permit partial replacement and intermediate states preserve required service/data semantics.

**Non-trigger / cheaper path:** A small system may be cheaper to replace atomically; no migration when existing service remains adequate.

**Authority:** {"actors": "Consumers crossing the seam and operators controlling cutover.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Legacy/successor components, seam, routing, shared data and temporary adapters.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-048", "CONDITIONS": "A small system may be cheaper to replace atomically; no migration when existing service remains adequate. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-043", "CONDITIONS": "Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS029`, `ESME:ESME-CS030`, `ESME:ESME-CS031`, `ESME:ESME-CS052`, `ESME:ESME-CS082`, `ESME:ESME-CS093`.

**Clusters:** `SSS-K013`. **Tensions:** None. **Directional references:** 22 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/52`.

## ESME:ESME-C054

**Rehearsed quiescent or atomic cutover**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Complete successor, cutover state, consumers and recovery resources. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.

**Criterion / operative mechanism:** The cutover is authorised against endpoint and conversion evidence, not just successor tests.

**Mechanism:** Choose a single transition only when rehearsal, downtime/loss acceptance and state conversion evidence make it preferable to unsupported coexistence.

**Trigger:** The system is small or separability is poor, downtime is acceptable, or dual operation creates intolerable inconsistency.

**Non-trigger / cheaper path:** Prefer bounded repair or incremental transfer where they meet obligations with less risk.

**Authority:** {"actors": "Users accepting the transition and operators performing it.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Complete successor, cutover state, consumers and recovery resources.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-049", "CONDITIONS": "Prefer bounded repair or incremental transfer where they meet obligations with less risk. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-044", "CONDITIONS": "Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS029`, `ESME:ESME-CS041`, `ESME:ESME-CS056`, `ESME:ESME-CS031`, `ESME:ESME-CS063`, `ESME:ESME-CS093`.

**Clusters:** `SSS-K013`. **Tensions:** None. **Directional references:** 22 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/53`.

## ESME:ESME-C055

**Data-conversion meaning, authority and reconciliation**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Old/new data, mapping rules, transaction history and reconciliation evidence. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.

**Criterion / operative mechanism:** The converted state has justified meaning and authority within a declared scope, with divergence and unresolved losses surfaced.

**Mechanism:** Declare old/new data meanings, authoritative writers and reconciliation rules; check the transfer against actual data and concurrent effects instead of equating record counts or script success with preserved meaning.

**Trigger:** Schema, encoding, representation or ownership changes can alter persisted meaning.

**Non-trigger / cheaper path:** For stateless replacement this is not triggered; a simple verified bijective conversion may need only direct checks.

**Authority:** {"actors": "Consumers relying on meanings such as identity, balances, ordering or provenance.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Old/new data, mapping rules, transaction history and reconciliation evidence.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-050", "CONDITIONS": "For stateless replacement this is not triggered; a simple verified bijective conversion may need only direct checks. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-045", "CONDITIONS": "Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS029`, `ESME:ESME-CS050`, `ESME:ESME-CS063`, `ESME:ESME-CS093`.

**Clusters:** `SSS-K003`, `SSS-K013`, `SSS-K020`, `SSS-K029`. **Tensions:** None. **Directional references:** 71 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/54`.

## ESME:ESME-C056

**Schema mappings, information loss and inverse limits**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Identify both implementations, mappings, data versions, routing, write ownership, temporary adapters and relevant consumer versions.

**Criterion / operative mechanism:** Queries and converted states meet the declared mapping, or losses and unsupported rewrites block the preservation claim.

**Mechanism:** State the mapping and its information-loss/invertibility conditions; preserve enough source information or choose forward repair where an inverse does not exist.

**Trigger:** Schema/data representation changes affect persistent meaning or old-version access.

**Non-trigger / cheaper path:** Use a direct checked migration for a simple bijective mapping; a full workbench is unnecessary.

**Authority:** Database maintainers establish mappings; data owners authorise losses and changed interpretation.

**Communication/interaction:** {"recipient_and_boundary": "Database maintainers establish mappings; data owners authorise losses and changed interpretation.", "content": "State the mapping and its information-loss/invertibility conditions; preserve enough source information or choose forward repair where an inverse does not exist.", "adequacy_test": "Queries and converted states meet the declared mapping, or losses and unsupported rewrites block the preservation claim.", "non_requirement": "No separate person, meeting, registry or tool is required merely because the analytical roles are distinct."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-050", "CONDITIONS": "For stateless replacement this is not triggered; a simple verified bijective conversion may need only direct checks. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-046", "CONDITIONS": "Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS029`, `ESME:ESME-CS050`, `ESME:ESME-CS063`, `ESME:ESME-CS093`.

**Clusters:** `SSS-K003`, `SSS-K013`, `SSS-K029`. **Tensions:** None. **Directional references:** 53 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/55`.

## ESME:ESME-C057

**Reachable mixed-version and schema compatibility**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Versions of readers/writers, schema, protocol, configuration and shared state. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.

**Criterion / operative mechanism:** Only validated version/state combinations are active; unsupported skew triggers containment or a different route.

**Mechanism:** Enumerate the supported intermediate combinations and constrain activation order or feature use until each combination’s obligations hold.

**Trigger:** Rolling upgrades, data conversion or partial migration create old/new participants at the same time.

**Non-trigger / cheaper path:** Use an atomic stop-and-switch when mixed versions offer no justified advantage and downtime is acceptable.

**Authority:** {"actors": "Old and new consumers interacting concurrently.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Versions of readers/writers, schema, protocol, configuration and shared state.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-051", "CONDITIONS": "Use an atomic stop-and-switch when mixed versions offer no justified advantage and downtime is acceptable. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-039", "CONDITIONS": "Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS050`, `ESME:ESME-CS052`, `ESME:ESME-CS068`, `ESME:ESME-CS063`, `ESME:ESME-CS029`, `ESME:ESME-CS087`, `ESME:ESME-CS093`, `ESME:ESME-CS085`.

**Clusters:** `SSS-K013`, `SSS-K019`, `SSS-K020`, `SSS-K030`. **Tensions:** None. **Directional references:** 67 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/56`.

## ESME:ESME-C058

**Coexistence cost, completion witness and scaffold retirement**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Temporary migration/coexistence machinery and its remaining obligations.

**Criterion / operative mechanism:** Removal or declared completion has evidence that the relevant old-path obligations are discharged or explicitly reassigned; remaining supported coexistence and cost are not hidden.

**Mechanism:** Keep temporary gateways and duplicate operation only while they protect a live obligation; before declaring completion or removing them, check residual consumers, data authority, supported versions and recovery needs, then close the old path or explicitly reclassify enduring coexistence.

**Trigger:** Migration creates temporary coexistence, or completion/removal of an old path is proposed.

**Non-trigger / cheaper path:** No scaffold is needed for a genuine one-step transfer; justified permanent coexistence can be reclassified rather than falsely called completed migration.

**Authority:** {"actors": "Operators, legacy/successor maintainers and consumers yet to migrate.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Temporary routes, duplicate systems, data synchronisation and support obligations.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-052", "CONDITIONS": "Avoid coexistence entirely where a local repair or simple cutover is adequate. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "A:ESME-096", "CONDITIONS": "A simple statement and check that no supported consumer remains may suffice; permanent deliberate coexistence is a new supported configuration, not an unfinished migration by definition. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-047", "CONDITIONS": "Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS013`, `ESME:ESME-CS029`, `ESME:ESME-CS031`, `ESME:ESME-CS056`, `ESME:ESME-CS041`, `ESME:ESME-CS055`, `ESME:ESME-CS030`, `ESME:ESME-CS082`.

**Clusters:** `SSS-K013`, `SSS-K023`. **Tensions:** `SSS-T015`. **Directional references:** 43 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/57`.

## ESME:ESME-C059

**Rewrites are always wrong**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Replacement decision and realistic alternatives. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.

**Criterion / operative mechanism:** Replacement remains admissible when it meets obligations better than available alternatives.

**Mechanism:** Candidate forbids replacement regardless of support constraints, separability or transition evidence.

**Trigger:** A viable replacement is rejected solely by a slogan.

**Non-trigger / cheaper path:** Compare repair, incremental and atomic alternatives under ESME-C052.

**Authority:** {"actors": "Those responsible for service continuity and future maintenance.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Replacement decision and realistic alternatives.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-053", "CONDITIONS": "Compare repair, incremental and atomic alternatives under ESME-C052. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS013`, `ESME:ESME-CS029`, `ESME:ESME-CS031`, `ESME:ESME-CS056`.

**Clusters:** `SSS-K013`, `SSS-K016`, `SSS-K028`. **Tensions:** None. **Directional references:** 32 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/58`.

## ESME:ESME-C060

**Age or novelty alone as the intervention rule**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Current and candidate platforms, relevant tooling and maintainer skills. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.

**Criterion / operative mechanism:** The selected platform is justified by concrete requirements, not release date.

**Mechanism:** Candidate ranks maturity by platform age rather than fit, supportability and demonstrated maintenance value.

**Trigger:** A migration is justified principally by novelty or fashion.

**Non-trigger / cheaper path:** Retain the existing platform when obligations and support are satisfied.

**Authority:** {"actors": "Actual users and future maintainers.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Current and candidate platforms, relevant tooling and maintainer skills.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-054", "CONDITIONS": "Retain the existing platform when obligations and support are satisfied. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-048", "CONDITIONS": "Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS029`, `ESME:ESME-CS031`, `ESME:ESME-CS056`, `ESME:ESME-CS059`, `ESME:ESME-CS091`, `ESME:ESME-CS083`, `ESME:ESME-CS084`.

**Clusters:** `SSS-K016`, `SSS-K027`, `SSS-K028`. **Tensions:** None. **Directional references:** 49 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/59`.

## ESME:ESME-C061

**Reverting code reverses the system**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Code revision, persistent and external effect history. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.

**Criterion / operative mechanism:** Recovery claims distinguish source rollback from restored data and accepted irreversible consequences.

**Mechanism:** Candidate treats a code revert as proof that all deployed consequences are undone.

**Trigger:** A rollout or migration changes data, schemas, messages, payments or other external state.

**Non-trigger / cheaper path:** For a genuinely isolated file-only effect, code reversion can be adequate; otherwise use ESME-C049.

**Authority:** {"actors": "Data owners, users and operators observing more than source text.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Code revision, persistent and external effect history.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-055", "CONDITIONS": "For a genuinely isolated file-only effect, code reversion can be adequate; otherwise use ESME-C049. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS019`, `ESME:ESME-CS041`, `ESME:ESME-CS050`, `ESME:ESME-CS052`, `ESME:ESME-CS063`.

**Clusters:** `SSS-K013`, `SSS-K020`. **Tensions:** None. **Directional references:** 28 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/60`.

## ESME:ESME-C062

**Causally specified future-maintenance debt**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Debt condition, cause, affected future change and support horizon. A debt item links a concrete design/implementation condition to affected future work and its economic context.

**Criterion / operative mechanism:** An item states how and when it imposes additional cost; disappearance of that scenario can retire the item.

**Mechanism:** Identify a concrete design/implementation condition and the future work that makes its liability actual; distinguish defects, missing features and ordinary maintenance.

**Trigger:** A structural choice plausibly increases future change cost or blocks justified evolution.

**Non-trigger / cheaper path:** Do not create debt items for disliked code with no relevant future-cost mechanism.

**Authority:** {"actors": "Future maintainers and value/cost decision makers.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Debt condition, cause, affected future change and support horizon.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-056", "CONDITIONS": "Do not create debt items for disliked code with no relevant future-cost mechanism. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-049", "CONDITIONS": "Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS027`, `ESME:ESME-CS028`, `ESME:ESME-CS059`, `ESME:ESME-CS023`, `ESME:ESME-CS090`, `ESME:ESME-CS058`, `ESME:ESME-CS062`.

**Clusters:** `SSS-K011`, `SSS-K016`, `SSS-K031`. **Tensions:** None. **Directional references:** 54 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/61`.

## ESME:ESME-C063

**Actionable debt records with a consumer**

**Disposition:** `USEFUL_BUT_EASILY_BUREAUCRATISED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Debt item, supporting observations, cost estimates and decision history. A debt item links a concrete design/implementation condition to affected future work and its economic context.

**Criterion / operative mechanism:** The record changes or supports a prioritisation decision and is refreshed or retired as context changes.

**Mechanism:** Record only enough evidence about an important liability, affected work, uncertainty and intended decision for the people prioritising it.

**Trigger:** A significant liability risks being forgotten, misunderstood or shifted across teams.

**Non-trigger / cheaper path:** A tracked issue or brief decision note can replace a dedicated register; delete records whose liability has vanished.

**Authority:** {"actors": "Maintainer, budget holder and affected downstream cost bearer.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Debt item, supporting observations, cost estimates and decision history.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-057", "CONDITIONS": "A tracked issue or brief decision note can replace a dedicated register; delete records whose liability has vanished. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS028`, `ESME:ESME-CS059`, `ESME:ESME-CS058`.

**Clusters:** `SSS-K031`. **Tensions:** None. **Directional references:** 19 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/62`.

## ESME:ESME-C064

**Contingent maintenance economics and opportunity cost**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Maintenance options, benefits, cost horizon and uncertainty. A debt item links a concrete design/implementation condition to affected future work and its economic context.

**Criterion / operative mechanism:** A priority decision explains trade-offs, uncertainty and the evidence that could reverse it.

**Mechanism:** Compare intervention, validation, disruption, future support and opportunity costs under plausible scenarios; retain uncertainty and identify cost bearers.

**Trigger:** Competing repairs, features, structural improvements or retirement choices draw on limited resources.

**Non-trigger / cheaper path:** A qualitative ordered comparison is sufficient when numerical estimates would be fictitious.

**Authority:** {"actors": "Stakeholders allocating effort and those who bear downstream costs.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Maintenance options, benefits, cost horizon and uncertainty.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-058", "CONDITIONS": "A qualitative ordered comparison is sufficient when numerical estimates would be fictitious. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-050", "CONDITIONS": "Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS027`, `ESME:ESME-CS028`, `ESME:ESME-CS058`, `ESME:ESME-CS059`, `ESME:ESME-CS023`, `ESME:ESME-CS090`.

**Clusters:** `SSS-K005`, `SSS-K011`, `SSS-K026`, `SSS-K031`. **Tensions:** None. **Directional references:** 60 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/63`.

## ESME:ESME-C065

**Option-preserving deferral and deliberate non-repayment**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Deferred liability, prospective demand and revisit condition. A debt item links a concrete design/implementation condition to affected future work and its economic context.

**Criterion / operative mechanism:** Deferral is an explicit justified choice with a relevant trigger rather than forgotten work.

**Mechanism:** Defer a structural intervention when its expected value is below its cost, while retaining a trigger to revisit if demand, risk or support changes.

**Trigger:** Future change demand is uncertain, interest is small, or the system may retire before repayment benefits arise.

**Non-trigger / cheaper path:** Do nothing beyond existing observation when there is no live liability; immediate repair dominates when an obligation is already breached.

**Authority:** {"actors": "Those bearing future effort and present opportunity cost.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Deferred liability, prospective demand and revisit condition.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-059", "CONDITIONS": "Do nothing beyond existing observation when there is no live liability; immediate repair dominates when an obligation is already breached. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS013`, `ESME:ESME-CS056`, `ESME:ESME-CS059`.

**Clusters:** `SSS-K005`, `SSS-K011`, `SSS-K023`, `SSS-K028`, `SSS-K031`. **Tensions:** `SSS-T004`. **Directional references:** 60 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/64`.

## ESME:ESME-C066

**Visible cost bearers and legitimate maintenance prioritisation**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Cost allocation, support promises and affected stakeholders. A debt item links a concrete design/implementation condition to affected future work and its economic context.

**Criterion / operative mechanism:** The decision states material shifted costs and how affected parties can act on the information.

**Mechanism:** Identify who gains now and who must later maintain, migrate or absorb risk; involve affected decision makers to the extent needed for legitimate trade-offs.

**Trigger:** A local benefit shifts material work or obligations to other teams, future maintainers or external consumers.

**Non-trigger / cheaper path:** A direct agreement can suffice; no universal committee or separate owner per item is required.

**Authority:** {"actors": "Present and future maintainers, sponsors and downstream users.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Cost allocation, support promises and affected stakeholders.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-060", "CONDITIONS": "A direct agreement can suffice; no universal committee or separate owner per item is required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-051", "CONDITIONS": "Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS028`, `ESME:ESME-CS059`, `ESME:ESME-CS060`, `ESME:ESME-CS061`, `ESME:ESME-CS090`, `ESME:ESME-CS058`, `ESME:ESME-CS085`.

**Clusters:** `SSS-K010`, `SSS-K011`, `SSS-K021`, `SSS-K031`. **Tensions:** `SSS-T006`. **Directional references:** 71 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/65`.

## ESME:ESME-C067

**Zero technical debt as the objective**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Debt inventory and maintenance budget. A debt item links a concrete design/implementation condition to affected future work and its economic context.

**Criterion / operative mechanism:** Debt reduction is not accepted as benefit without an affected-value account.

**Mechanism:** Candidate requires all debt items to be eliminated irrespective of future use, opportunity cost or retirement.

**Trigger:** A programme treats the debt count as a target to drive to zero.

**Non-trigger / cheaper path:** Prioritise justified liabilities and retire irrelevant ones under ESME-C062–059.

**Authority:** {"actors": "Those needing useful current and future software.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Debt inventory and maintenance budget.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-061", "CONDITIONS": "Prioritise justified liabilities and retire irrelevant ones under ESME-C062–059. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-054", "CONDITIONS": "Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS027`, `ESME:ESME-CS028`, `ESME:ESME-CS059`, `ESME:ESME-CS090`, `ESME:ESME-CS058`, `ESME:ESME-CS084`.

**Clusters:** `SSS-K011`, `SSS-K031`. **Tensions:** None. **Directional references:** 21 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/66`.

## ESME:ESME-C068

**A universal maintainability index proves future savings**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Index, scoring model and future tasks. A debt item links a concrete design/implementation condition to affected future work and its economic context.

**Criterion / operative mechanism:** A score is identified as a proxy and does not independently certify savings.

**Mechanism:** Candidate treats a universal index or tool-generated principal as proof of maintenance return.

**Trigger:** A decision claims certain savings from score improvement without task evidence.

**Non-trigger / cheaper path:** Use actual change history, qualitative estimates or bounded experiments and disclose uncertainty.

**Authority:** {"actors": "Maintainer or sponsor relying on a cost prediction.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Index, scoring model and future tasks.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-062", "CONDITIONS": "Use actual change history, qualitative estimates or bounded experiments and disclose uncertainty. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS023`, `ESME:ESME-CS059`, `ESME:ESME-CS058`.

**Clusters:** `SSS-K011`, `SSS-K016`, `SSS-K031`. **Tensions:** None. **Directional references:** 28 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/67`.

## ESME:ESME-C069

**Clean structure as a guarantee of maintenance benefit**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Bind before/after source, language/tool version, configuration and persistent representations to the actual applied transformation.

**Criterion / operative mechanism:** No unconditional payoff is inferred from a cleaner representation alone.

**Mechanism:** Reject the guarantee; require a task-specific causal account and proportionate outcome evidence.

**Trigger:** Adjudicate when a structural metric or catalogue label is offered as sufficient benefit evidence.

**Non-trigger / cheaper path:** Keep a harmless structure or make a bounded repair.

**Authority:** Metric producers do not determine product value; affected maintainers and users supply task evidence.

**Communication/interaction:** {"recipient_and_boundary": "Metric producers do not determine product value; affected maintainers and users supply task evidence.", "content": "Reject the guarantee; require a task-specific causal account and proportionate outcome evidence.", "adequacy_test": "No unconditional payoff is inferred from a cleaner representation alone.", "non_requirement": "No separate person, meeting, registry or tool is required merely because the analytical roles are distinct."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "B:ESME-028", "CONDITIONS": "Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS077`, `ESME:ESME-CS078`, `ESME:ESME-CS076`.

**Clusters:** `SSS-K011`, `SSS-K016`, `SSS-K031`. **Tensions:** None. **Directional references:** 28 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/68`.

## ESME:ESME-C070

**Retained rationale through actual future use**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Change rationale, baseline references and accepted trade-offs. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Criterion / operative mechanism:** A successor can connect a relevant constraint to its reason and identify when that reason no longer holds.

**Mechanism:** Retain the decision-relevant reasons, alternatives and accepted limitations in a form successors can locate and test against current conditions.

**Trigger:** Loss of intent would materially obstruct future change, support or retirement.

**Non-trigger / cheaper path:** An adjacent comment, issue or concise handover may suffice; do not duplicate rationale in unconsumed documents.

**Authority:** {"actors": "Future maintainer, operator or downstream decision maker.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Change rationale, baseline references and accepted trade-offs.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-063", "CONDITIONS": "An adjacent comment, issue or concise handover may suffice; do not duplicate rationale in unconsumed documents. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-015", "CONDITIONS": "Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS014`, `ESME:ESME-CS016`, `ESME:ESME-CS019`, `ESME:ESME-CS041`, `ESME:ESME-CS059`, `ESME:ESME-CS073`, `ESME:ESME-CS017`, `ESME:ESME-CS089`, `ESME:ESME-CS085`.

**Clusters:** `SSS-K008`. **Tensions:** None. **Directional references:** 22 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/69`.

## ESME:ESME-C071

**Scoped ownership and change coordination**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Change requests, affected components and decision responsibilities. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Criterion / operative mechanism:** A relevant request or conflict can reach someone able and authorised to decide or explicitly decline.

**Mechanism:** Make responsibility and decision rights clear enough to resolve overlapping changes and support requests without assuming exclusive code ownership.

**Trigger:** Multiple contributors or support paths create ambiguity about acceptance, review or incident response.

**Non-trigger / cheaper path:** One maintainer can hold several roles; collaborative ownership is adequate when responsibility remains actionable.

**Authority:** {"actors": "Contributors, maintainers and downstream users seeking a decision.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Change requests, affected components and decision responsibilities.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-065", "CONDITIONS": "One maintainer can hold several roles; collaborative ownership is adequate when responsibility remains actionable. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS019`, `ESME:ESME-CS041`, `ESME:ESME-CS060`, `ESME:ESME-CS032`, `ESME:ESME-CS061`.

**Clusters:** `SSS-K009`, `SSS-K010`, `SSS-K021`, `SSS-K022`. **Tensions:** `SSS-T002`. **Directional references:** 63 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/70`.

## ESME:ESME-C072

**Sustainable and willing maintenance support**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Support promises, workload, available people and tooling. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Criterion / operative mechanism:** Support expectations match an actionable capacity plan or clearly announced limitation.

**Mechanism:** Align promised support, intake and update obligations with available willing capacity; negotiate reduced scope, sponsorship, transfer or retirement when infeasible.

**Trigger:** Demand, dependency obligations or turnover exceed sustainable support capability.

**Non-trigger / cheaper path:** Reduce nonessential scope or state a limited support policy rather than add complex automation by default.

**Authority:** {"actors": "Maintainers, users relying on support and potential sponsors/successors.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Support promises, workload, available people and tooling.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-066", "CONDITIONS": "Reduce nonessential scope or state a limited support policy rather than add complex automation by default. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-055", "CONDITIONS": "Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS013`, `ESME:ESME-CS060`, `ESME:ESME-CS061`, `ESME:ESME-CS036`, `ESME:ESME-CS037`, `ESME:ESME-CS084`, `ESME:ESME-CS085`, `ESME:ESME-CS089`.

**Clusters:** `SSS-K010`, `SSS-K021`, `SSS-K023`, `SSS-K026`. **Tensions:** None. **Directional references:** 76 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/71`.

## ESME:ESME-C073

**Knowledge-concentration metrics as fallible prompts**

**Disposition:** `USEFUL_BUT_EASILY_GAMED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Commit history, authorship assumptions and demonstrated expertise. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Criterion / operative mechanism:** The estimate is accompanied by checks of actual capability and omitted knowledge.

**Mechanism:** Use the estimate to ask who can actually support critical work; verify with maintainers rather than treating a computed number as a failure probability.

**Trigger:** A project needs to assess continuity and history can offer a useful first approximation.

**Non-trigger / cheaper path:** Ask maintainers directly or exercise a handover when feasible; no metric is required.

**Authority:** {"actors": "Maintainers and support planners.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Commit history, authorship assumptions and demonstrated expertise.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-067", "CONDITIONS": "Ask maintainers directly or exercise a handover when feasible; no metric is required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS032`, `ESME:ESME-CS016`.

**Clusters:** `SSS-K010`, `SSS-K033`. **Tensions:** None. **Directional references:** 45 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/72`.

## ESME:ESME-C074

**Obligation-based dependency viability and response**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Dependency manifests, resolved versions, support status and affected uses. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Criterion / operative mechanism:** A consequential dependency change has a justified action or deferral and an explicit support/compatibility account.

**Mechanism:** Identify supported dependency versions and consequential transitive reliance; assess update, pinning, substitution or retirement against actual compatibility and support needs.

**Trigger:** A dependency changes, loses support or creates a relevant defect/security obligation.

**Non-trigger / cheaper path:** Use a small explicit dependency list and targeted check for a bounded artefact; no ecosystem-wide graph is inherently necessary.

**Authority:** {"actors": "Upstream/downstream maintainers and operators.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Dependency manifests, resolved versions, support status and affected uses.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-068", "CONDITIONS": "Use a small explicit dependency list and targeted check for a bounded artefact; no ecosystem-wide graph is inherently necessary. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-058", "CONDITIONS": "Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS019`, `ESME:ESME-CS033`, `ESME:ESME-CS061`, `ESME:ESME-CS024`, `ESME:ESME-CS085`, `ESME:ESME-CS084`.

**Clusters:** `SSS-K021`, `SSS-K022`. **Tensions:** None. **Directional references:** 44 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/73`.

## ESME:ESME-C075

**Discovery of affected downstream consumers**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Include code, API, schema, protocol, configuration, build, policy and relevant ownership/deployment state rather than a universal source-file-only graph.

**Criterion / operative mechanism:** Known affected consumers receive actionable information or an inability to reach them constrains release.

**Mechanism:** Identify plausible consumers through interfaces, usage, dependency data and consultation; disclose uncertainty and notify those needing action.

**Trigger:** A public or shared behaviour, data format, dependency or support promise changes.

**Non-trigger / cheaper path:** For a private bounded use with no external consumer, direct coordination with the local caller may suffice.

**Authority:** Producers communicate change and uncertainty; independent consumers decide their own migration and acceptance.

**Communication/interaction:** {"recipient_and_boundary": "Producers communicate change and uncertainty; independent consumers decide their own migration and acceptance.", "content": "Identify plausible consumers through interfaces, usage, dependency data and consultation; disclose uncertainty and notify those needing action.", "adequacy_test": "Known affected consumers receive actionable information or an inability to reach them constrains release.", "non_requirement": "No separate person, meeting, registry or tool is required merely because the analytical roles are distinct."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "B:ESME-020", "CONDITIONS": "Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS074`, `ESME:ESME-CS062`, `ESME:ESME-CS087`, `ESME:ESME-CS033`, `ESME:ESME-CS085`.

**Clusters:** `SSS-K021`, `SSS-K022`. **Tensions:** None. **Directional references:** 54 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/74`.

## ESME:ESME-C076

**Consumer-directed, actionable change communication**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Release notes, support policy, client dependencies and transition instructions. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Criterion / operative mechanism:** The relevant consumer can determine required action and remaining support/transition limits; merely publishing a notice is not counted as successful transfer.

**Mechanism:** Provide affected supported consumers with the behaviour/support change, affected versions, timing and feasible response information needed for their decision; examine whether the channel and recipient can make it operative.

**Trigger:** A change affects consumer obligations, compatibility, support or availability.

**Non-trigger / cheaper path:** A direct agreement with the sole consumer may suffice; no broad notice is needed for a truly private effect.

**Authority:** {"actors": "Downstream maintainers and users able to adapt or contest the change.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Release notes, support policy, client dependencies and transition instructions.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-069", "CONDITIONS": "A direct agreement with the sole consumer may suffice; no broad notice is needed for a truly private effect. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-057", "CONDITIONS": "Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS021`, `ESME:ESME-CS041`, `ESME:ESME-CS054`, `ESME:ESME-CS055`, `ESME:ESME-CS061`, `ESME:ESME-CS087`, `ESME:ESME-CS085`.

**Clusters:** `SSS-K021`, `SSS-K022`. **Tensions:** `SSS-T013`. **Directional references:** 49 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/75`.

## ESME:ESME-C077

**Deprecation signalling separated from shutdown**

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Resource, API version, support policy, deprecation date and possible sunset date. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Criterion / operative mechanism:** The announced state and implications are unambiguous to the intended consumer.

**Mechanism:** Declare the local meaning and support effect of deprecation, distinguishing discouraged use, changed guarantees, end of support and service termination.

**Trigger:** An interface or service is being superseded, losing guarantees or approaching shutdown.

**Non-trigger / cheaper path:** A documented support statement may suffice outside HTTP; no header is required where it has no consumer.

**Authority:** {"actors": "Client developers and supported users.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Resource, API version, support policy, deprecation date and possible sunset date.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-070", "CONDITIONS": "A documented support statement may suffice outside HTTP; no header is required where it has no consumer. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS054`, `ESME:ESME-CS055`, `ESME:ESME-CS056`.

**Clusters:** `SSS-K022`, `SSS-K023`. **Tensions:** None. **Directional references:** 55 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/76`.

## ESME:ESME-C078

**Responsible servicing phaseout and retirement**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Service endpoints, users, data, credentials/access, support promises and retained records. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Criterion / operative mechanism:** Operational termination and surviving preservation/support arrangements are evidenced separately.

**Mechanism:** Identify remaining users, data, support and archival obligations; authorise termination and verify the intended services/routes actually close while agreed retained assets remain usable.

**Trigger:** The software is no longer useful, supportable or justified relative to alternatives.

**Non-trigger / cheaper path:** Continue a stable low-cost service when retirement would strand justified obligations; close simple unused artefacts with proportionate checks.

**Authority:** {"actors": "Remaining consumers, maintainers and authorised custodians.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Service endpoints, users, data, credentials/access, support promises and retained records.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-071", "CONDITIONS": "Continue a stable low-cost service when retirement would strand justified obligations; close simple unused artefacts with proportionate checks. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-060", "CONDITIONS": "Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS013`, `ESME:ESME-CS041`, `ESME:ESME-CS054`, `ESME:ESME-CS056`, `ESME:ESME-CS057`, `ESME:ESME-CS063`, `ESME:ESME-CS001`, `ESME:ESME-CS069`, `ESME:ESME-CS087`, `ESME:ESME-CS094`, `ESME:ESME-CS084`, `ESME:ESME-CS085`.

**Clusters:** `SSS-K022`, `SSS-K023`, `SSS-K028`. **Tensions:** `SSS-T015`. **Directional references:** 61 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/77`.

## ESME:ESME-C079

**Purpose-specific historical preservation**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Source, dependencies, documentation, data rights and optional executable environment. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Criterion / operative mechanism:** The specified historical object can be retrieved or relevant execution reproduced within stated limitations.

**Mechanism:** Choose what must remain retrievable or executable for a declared purpose and horizon, and verify the relevant retrieval/reproduction capability.

**Trigger:** Historical analysis, compliance, research reproduction or future revival justifies retained artefacts after active use.

**Non-trigger / cheaper path:** Retain a source snapshot and rationale when execution is unnecessary; avoid indefinitely operating a service solely to preserve history.

**Authority:** {"actors": "Future researcher, maintainer or custodian with a concrete use.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Source, dependencies, documentation, data rights and optional executable environment.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-072", "CONDITIONS": "Retain a source snapshot and rationale when execution is unnecessary; avoid indefinitely operating a service solely to preserve history. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-059", "CONDITIONS": "Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS056`, `ESME:ESME-CS057`, `ESME:ESME-CS053`, `ESME:ESME-CS094`, `ESME:ESME-CS080`, `ESME:ESME-CS088`.

**Clusters:** `SSS-K023`. **Tensions:** `SSS-T015`. **Directional references:** 31 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/78`.

## ESME:ESME-C080

**Popularity guarantees dependency continuity**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Package popularity, dependency reach and maintainer capacity. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Criterion / operative mechanism:** Continuity claims use actual support evidence rather than download counts alone.

**Mechanism:** Candidate assumes a widely used package cannot lose maintainers or support.

**Trigger:** A dependency is accepted without continuity consideration because many projects use it.

**Non-trigger / cheaper path:** Check actual support/capacity and feasible alternatives under ESME-C072 and 068.

**Authority:** {"actors": "Downstream users and upstream maintainers.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Package popularity, dependency reach and maintainer capacity.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-073", "CONDITIONS": "Check actual support/capacity and feasible alternatives under ESME-C072 and 068. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS032`, `ESME:ESME-CS033`, `ESME:ESME-CS060`, `ESME:ESME-CS061`.

**Clusters:** `SSS-K033`. **Tensions:** None. **Directional references:** 28 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/79`.

## ESME:ESME-C081

**Deliberate continued usefulness without change**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Current capability, support horizon and environmental assumptions. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Criterion / operative mechanism:** A no-change decision states why obligations remain met and what evidence would prompt reconsideration.

**Mechanism:** Choose continued unchanged operation where current obligations, support conditions and expected value do not justify intervention; keep only relevant observation triggers.

**Trigger:** No demonstrated defect, adaptation need or investment opportunity outweighs change risk and cost.

**Non-trigger / cheaper path:** This is the cheap path itself; review existing signals rather than create permanent change machinery.

**Authority:** {"actors": "Current users and maintainers.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Current capability, support horizon and environmental assumptions.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-074", "CONDITIONS": "This is the cheap path itself; review existing signals rather than create permanent change machinery. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-005", "CONDITIONS": "Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS009`, `ESME:ESME-CS013`, `ESME:ESME-CS056`, `ESME:ESME-CS059`, `ESME:ESME-CS008`, `ESME:ESME-CS029`, `ESME:ESME-CS084`, `ESME:ESME-CS010`, `ESME:ESME-CS091`, `ESME:ESME-CS101`.

**Clusters:** `SSS-K011`, `SSS-K023`, `SSS-K028`. **Tensions:** None. **Directional references:** 44 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/80`.

## ESME:ESME-C082

**Transition to servicing is effectively irreversible**

**Disposition:** `CONTESTED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Remaining expertise, recoverable design knowledge and feasible change classes. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Criterion / operative mechanism:** The practical feasibility of renewed evolution is investigated, not decided solely by a lifecycle diagram.

**Mechanism:** Use servicing-stage diagnosis to examine remaining comprehension and evolution capacity, but do not infer impossibility from the label.

**Trigger:** A long-lived system can receive patches but no longer support broad justified evolution economically.

**Non-trigger / cheaper path:** Assess actual knowledge recovery and replacement choices rather than require a stage label.

**Authority:** {"actors": "Maintainers and those choosing investment or retirement.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Remaining expertise, recoverable design knowledge and feasible change classes.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-075", "CONDITIONS": "Assess actual knowledge recovery and replacement choices rather than require a stage label. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS013`, `ESME:ESME-CS014`, `ESME:ESME-CS016`, `ESME:ESME-CS045`.

**Clusters:** `SSS-K023`. **Tensions:** None. **Directional references:** 30 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/81`.

## ESME:ESME-C083

**Generated repairs remain candidates until justified acceptance**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Generated diff, issue interpretation, tests, harness and environment. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Criterion / operative mechanism:** Accepted claims identify repaired obligations and residual uncertainty; unsupported additions are removed or authorised.

**Mechanism:** Treat the patch as a candidate; check intended repair, preservation, unsupported changes and uncertainty before acceptance.

**Trigger:** A repair or evolution suggestion is generated by a search system, model or agent.

**Non-trigger / cheaper path:** A direct human correction may dominate; use the same substantive obligations regardless of who authored the patch.

**Authority:** {"actors": "Maintainer accepting the repair and affected consumers.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Generated diff, issue interpretation, tests, harness and environment.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-076", "CONDITIONS": "A direct human correction may dominate; use the same substantive obligations regardless of who authored the patch. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-061", "CONDITIONS": "Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS034`, `ESME:ESME-CS035`, `ESME:ESME-CS064`, `ESME:ESME-CS065`, `ESME:ESME-CS104`, `ESME:ESME-CS095`, `ESME:ESME-CS066`, `ESME:ESME-CS092`, `ESME:ESME-CS106`.

**Clusters:** `SSS-K024`. **Tensions:** `SSS-T011`. **Directional references:** 23 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/82`.

## ESME:ESME-C084

**Validation of the evaluation harness itself**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Execution harness, environment, selected tests, exit conditions and recorded results. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Criterion / operative mechanism:** The harness distinguishes relevant known pass/fail controls and binds results to the intended artefact.

**Mechanism:** Check that tests actually execute against the intended version, inputs and result criteria; challenge known failure/success controls and broken dependency assumptions.

**Trigger:** A harness is new, changed, migrated or relied on for a consequential acceptance claim.

**Non-trigger / cheaper path:** A simple transparent command with known checks may need only a small sanity test rather than a framework audit.

**Authority:** {"actors": "Reviewer interpreting evidence rather than trusting its producer.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Execution harness, environment, selected tests, exit conditions and recorded results.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-077", "CONDITIONS": "A simple transparent command with known checks may need only a small sanity test rather than a framework audit. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS024`, `ESME:ESME-CS034`, `ESME:ESME-CS035`, `ESME:ESME-CS053`, `ESME:ESME-CS064`.

**Clusters:** `SSS-K015`, `SSS-K018`, `SSS-K024`. **Tensions:** None. **Directional references:** 49 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/83`.

## ESME:ESME-C085

**Benchmark identity, leakage and transfer boundaries**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Benchmark tasks, public history, model versions and evaluation settings. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Criterion / operative mechanism:** Evaluation conclusions distinguish the observed benchmark result from uncertain transfer and contamination.

**Mechanism:** Record task provenance, temporal/version scope, possible training exposure and test-oracle limits; avoid treating repeated benchmark scores as independent evidence of unseen maintenance ability.

**Trigger:** Benchmark results justify deployment claims or compare automation approaches.

**Non-trigger / cheaper path:** Use a bounded private or newly authored representative task evaluation where feasible; disclose limits rather than invent clean provenance.

**Authority:** {"actors": "Researchers and maintainers deciding transfer from benchmark to practice.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Benchmark tasks, public history, model versions and evaluation settings.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-078", "CONDITIONS": "Use a bounded private or newly authored representative task evaluation where feasible; disclose limits rather than invent clean provenance. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-062", "CONDITIONS": "Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS035`, `ESME:ESME-CS064`, `ESME:ESME-CS065`, `ESME:ESME-CS066`, `ESME:ESME-CS034`, `ESME:ESME-CS097`, `ESME:ESME-CS106`.

**Clusters:** `SSS-K015`, `SSS-K024`, `SSS-K033`. **Tensions:** None. **Directional references:** 73 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/84`.

## ESME:ESME-C086

**Issue, reference patch and test objective alignment**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Issue statement, reference PR, changed tests and alternative patches. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Criterion / operative mechanism:** Differences are classified as required, permitted, irrelevant, erroneous or unresolved with reasons.

**Mechanism:** Compare the stated requirement, reference change and acceptance tests; adjudicate mismatches before using them to judge another implementation.

**Trigger:** Generated repair, benchmark construction or legacy acceptance relies on a reference patch as expected truth.

**Non-trigger / cheaper path:** A precise issue and focused test can suffice; no LLM checker is inherently required.

**Authority:** {"actors": "Legitimate requester/maintainer, not an automatically privileged reference implementation.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Issue statement, reference PR, changed tests and alternative patches.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-079", "CONDITIONS": "A precise issue and focused test can suffice; no LLM checker is inherently required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS035`, `ESME:ESME-CS064`, `ESME:ESME-CS065`.

**Clusters:** `SSS-K024`. **Tensions:** None. **Directional references:** 19 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/85`.

## ESME:ESME-C087

**End-to-end automation outcome and cost evaluation**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Human tasks, model calls, review effort, compute and accepted outcomes. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Criterion / operative mechanism:** The benefit claim includes relevant total work and uncertainty rather than generation speed alone.

**Mechanism:** Measure the end-to-end effort, latency, quality and resource costs relevant to the actual workflow against credible human/tool-assisted alternatives.

**Trigger:** Automation adoption is justified as saving maintenance effort or increasing useful output.

**Non-trigger / cheaper path:** A small representative paired trial or observed task sample may suffice; no grand benchmark is required.

**Authority:** {"actors": "Maintainers and sponsors bearing both visible and shifted costs.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Human tasks, model calls, review effort, compute and accepted outcomes.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-080", "CONDITIONS": "A small representative paired trial or observed task sample may suffice; no grand benchmark is required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-063", "CONDITIONS": "Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS036`, `ESME:ESME-CS037`, `ESME:ESME-CS039`, `ESME:ESME-CS064`, `ESME:ESME-CS065`, `ESME:ESME-CS081`, `ESME:ESME-CS092`, `ESME:ESME-CS097`.

**Clusters:** `SSS-K024`, `SSS-K026`. **Tensions:** `SSS-T011`. **Directional references:** 52 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/86`.

## ESME:ESME-C088

**Version-bound automation evidence and revalidation**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Automation configuration and supporting evaluation evidence. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Criterion / operative mechanism:** Reused evidence states why its assumptions still hold; affected claims are revalidated or narrowed.

**Mechanism:** Bind automation evidence to the model/tool, configuration, prompts, hardware and task envelope; recheck changed assumptions before reusing the claim.

**Trigger:** A model, engine, prompt strategy, hardware or evaluation context changes in a way relevant to prior evidence.

**Non-trigger / cheaper path:** Do not rerun everything for an irrelevant metadata change; use targeted revalidation of affected claims.

**Authority:** {"actors": "Maintainer relying on the tool’s prior effectiveness or preservation claims.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Automation configuration and supporting evaluation evidence.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-081", "CONDITIONS": "Do not rerun everything for an irrelevant metadata change; use targeted revalidation of affected claims. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS038`, `ESME:ESME-CS039`, `ESME:ESME-CS046`, `ESME:ESME-CS037`.

**Clusters:** `SSS-K015`, `SSS-K024`. **Tensions:** None. **Directional references:** 45 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/87`.

## ESME:ESME-C089

**Repair automation resource trade-offs**

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Model, quantisation, hardware, repair instances and resource measurements. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Criterion / operative mechanism:** The chosen configuration meets the stated resource and validated outcome constraints.

**Mechanism:** Choose model/quantisation settings by relevant repair quality and measured total resource constraints, not parameter count or aggregate success alone.

**Trigger:** Resource-limited repair automation makes memory, energy or time consequential.

**Non-trigger / cheaper path:** A simpler deterministic tool or human repair can dominate model tuning for a small task.

**Authority:** {"actors": "Maintainer/operator constrained by compute and accepted repair quality.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Model, quantisation, hardware, repair instances and resource measurements.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-082", "CONDITIONS": "A simpler deterministic tool or human repair can dominate model tuning for a small task. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS039`.

**Clusters:** `SSS-K024`, `SSS-K026`. **Tensions:** None. **Directional references:** 48 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/88`.

## ESME:ESME-C090

**Bounded automated semantic-conflict detection**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Base/parent/merged program, generated tests or build-conflict patterns. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Criterion / operative mechanism:** A detected interaction has scoped supporting evidence and a disposition rather than automatic rejection or a universal conflict-free guarantee.

**Mechanism:** Use applicable static or generated-test analysis to propose potentially interfering changes, then adjudicate actual joint intent and behaviour; retain detector assumptions, false positives and missed conflicts.

**Trigger:** Concurrent changes have plausible semantic interference that targeted automation can help expose.

**Non-trigger / cheaper path:** Manual joint review and focused integration tests may be enough; clean noninteracting changes need no special tool.

**Authority:** {"actors": "Contributors and maintainers reconciling jointly intended changes.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Base/parent/merged program, generated tests or build-conflict patterns.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-083", "CONDITIONS": "Manual joint review and focused integration tests may be enough; clean noninteracting changes need no special tool. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-022", "CONDITIONS": "Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS040`, `ESME:ESME-CS067`, `ESME:ESME-CS086`, `ESME:ESME-CS025`.

**Clusters:** `SSS-K019`. **Tensions:** None. **Directional references:** 20 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/89`.

## ESME:ESME-C091

**Learned-system data, model and configuration dependencies**

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Training/serving data, features, model, code, pipeline and configuration. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Criterion / operative mechanism:** The impact claim covers relevant non-code/model dependencies or explicitly marks unknowns.

**Mechanism:** Include data provenance, feature transformations, model versions and consequential configuration in maintenance impact and baseline reasoning.

**Trigger:** A learned component or data pipeline influences supported behaviour.

**Non-trigger / cheaper path:** Ordinary code/configuration analysis is enough when no learned or changing data dependency is present.

**Authority:** {"actors": "Users and downstream models/components receiving predictions or decisions.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Training/serving data, features, model, code, pipeline and configuration.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-084", "CONDITIONS": "Ordinary code/configuration analysis is enough when no learned or changing data dependency is present. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-065", "CONDITIONS": "Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS062`, `ESME:ESME-CS005`, `ESME:ESME-CS041`, `ESME:ESME-CS025`, `ESME:ESME-CS097`.

**Clusters:** `SSS-K015`, `SSS-K025`. **Tensions:** None. **Directional references:** 59 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/90`.

## ESME:ESME-C092

**Drift-sensitive evidence and preserved-obligation review**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Data distribution, model, feedback channels and accepted outcome criteria. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Criterion / operative mechanism:** A material shift triggers justified re-evaluation or a narrowed claim, not automatic retraining.

**Mechanism:** Monitor the relevant data/environment and outcome assumptions; reconsider preservation and regression evidence when those assumptions shift.

**Trigger:** A learned or environment-sensitive service has a live obligation whose validity depends on changing distributions or feedback.

**Non-trigger / cheaper path:** For a stable deterministic computation, ordinary version-bound regression may suffice.

**Authority:** {"actors": "Those affected by the model’s actual outcomes.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Data distribution, model, feedback channels and accepted outcome criteria.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-085", "CONDITIONS": "For a stable deterministic computation, ordinary version-bound regression may suffice. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-065", "CONDITIONS": "Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS009`, `ESME:ESME-CS010`, `ESME:ESME-CS062`, `ESME:ESME-CS025`, `ESME:ESME-CS097`.

**Clusters:** `SSS-K014`, `SSS-K015`, `SSS-K025`. **Tensions:** None. **Directional references:** 69 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/91`.

## ESME:ESME-C093

**Operative validation of non-code artefacts**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Documents, configuration, datasets, schemas, build recipes and generated outputs. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Criterion / operative mechanism:** Validation addresses the artefact’s actual obligation and the effects it can propagate.

**Mechanism:** Choose validation that checks the meaning and consumer of the changed artefact, including its generated or runtime effects.

**Trigger:** A non-code edit can alter buildability, operation, user guidance, data semantics or model behaviour.

**Non-trigger / cheaper path:** A factual documentation correction may need reader/source verification, not an entire executable test suite.

**Authority:** {"actors": "The actual reader, builder, runtime or downstream data consumer.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Documents, configuration, datasets, schemas, build recipes and generated outputs.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-086", "CONDITIONS": "A factual documentation correction may need reader/source verification, not an entire executable test suite. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-066", "CONDITIONS": "Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS001`, `ESME:ESME-CS024`, `ESME:ESME-CS041`, `ESME:ESME-CS053`, `ESME:ESME-CS062`, `ESME:ESME-CS063`, `ESME:ESME-CS069`, `ESME:ESME-CS080`, `ESME:ESME-CS096`.

**Clusters:** `SSS-K015`, `SSS-K025`, `SSS-K029`. **Tensions:** None. **Directional references:** 80 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/92`.

## ESME:ESME-C094

**Bounded acceptance and execution authority**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** The acceptance decision and execution powers for a concrete intervention.

**Criterion / operative mechanism:** The real acceptance and action stay within the delegated object, scope and capability; generated insight or test success does not enlarge them.

**Mechanism:** Distinguish proposing a change, accepting its evidence and executing consequential actions; bind each to actual legitimate capability and any limited delegation. Authorisation of a goal does not automatically transfer deployment or external-state powers.

**Trigger:** An actor or automated tool proposes, accepts or executes a change, especially when these functions cross authority boundaries.

**Non-trigger / cheaper path:** One competent authorised actor may perform all functions for a bounded change; no separate human, meeting or AI-specific approval is implied.

**Authority:** The legitimate request/obligation owner, acceptance decision maker and action executor may differ. A goal approval or generated insight does not delegate deployment or external-state powers. One capable actor may hold all roles within the agreed scope.

**Communication/interaction:** {"recipient_and_boundary": "Authorised maintainers or policy holders accept changes; generators cannot enlarge their own mandate from a successful test.", "content": "Identify who may accept and deploy which changes, what evidence they need and when an automatic path must defer or stop.", "adequacy_test": "Acceptance and deployment can be traced to an authorised decision within its stated scope.", "non_requirement": "No separate person, meeting, registry or tool is required merely because the analytical roles are distinct."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-087", "CONDITIONS": "Apply ESME-C001 through the existing authorisation route; do not create a separate AI approval bureaucracy solely for this duplicate. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-064", "CONDITIONS": "Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS034`, `ESME:ESME-CS035`, `ESME:ESME-CS041`, `ESME:ESME-CS064`, `ESME:ESME-CS065`, `ESME:ESME-CS095`, `ESME:ESME-CS092`, `ESME:ESME-CS069`, `ESME:ESME-CS106`.

**Clusters:** `SSS-K009`, `SSS-K020`, `SSS-K024`. **Tensions:** `SSS-T011`. **Directional references:** 68 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/93`.

## ESME:ESME-C095

**Long-term net maintainability benefit of AI-assisted evolution**

**Disposition:** `UNRESOLVED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Accepted generated changes, later maintenance tasks, regressions and total lifecycle costs. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Criterion / operative mechanism:** No universal benefit asserted; later tasks and regressions would be needed to resolve the claim.

**Mechanism:** Investigated claim: AI assistance yields durable net improvement in maintainability after accounting for later comprehension, regressions and support.

**Trigger:** A decision generalises short-run scores or time savings to multi-release lifecycle benefit.

**Non-trigger / cheaper path:** Run bounded adoption with follow-up evidence; do not assert a long-term benefit absent an adequate horizon and comparator.

**Authority:** {"actors": "Future maintainers and sponsors, not only benchmark operators.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Accepted generated changes, later maintenance tasks, regressions and total lifecycle costs.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-088", "CONDITIONS": "Run bounded adoption with follow-up evidence; do not assert a long-term benefit absent an adequate horizon and comparator. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS035`, `ESME:ESME-CS036`, `ESME:ESME-CS037`, `ESME:ESME-CS038`, `ESME:ESME-CS039`, `ESME:ESME-CS064`, `ESME:ESME-CS065`.

**Clusters:** `SSS-K024`, `SSS-K033`. **Tensions:** None. **Directional references:** 50 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/94`.

## ESME:ESME-C096

**Universal autonomous maintenance without residual review or authority**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Automated workflow, generated changes and live obligations. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Criterion / operative mechanism:** Delegation remains scoped and its consequences observed; success in a task does not expand its own authority.

**Mechanism:** Candidate claims that successful generated patches eliminate the need to establish intent, residual evidence or accountable action.

**Trigger:** A benchmark or demonstration is used to justify unrestricted self-directed production maintenance.

**Non-trigger / cheaper path:** Delegate a bounded class with explicit conditions and monitor actual outcomes; human review need not be ceremonial or applied identically to every case.

**Authority:** {"actors": "Maintainers and affected users, including those bearing external effects.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Automated workflow, generated changes and live obligations.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-090", "CONDITIONS": "Delegate a bounded class with explicit conditions and monitor actual outcomes; human review need not be ceremonial or applied identically to every case. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS035`, `ESME:ESME-CS038`, `ESME:ESME-CS040`, `ESME:ESME-CS034`, `ESME:ESME-CS036`, `ESME:ESME-CS037`, `ESME:ESME-CS064`, `ESME:ESME-CS065`, `ESME:ESME-CS067`.

**Clusters:** `SSS-K009`, `SSS-K024`. **Tensions:** None. **Directional references:** 28 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/95`.

## ESME:ESME-C097

**Every historical behaviour must be preserved**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Legacy behaviour, actual reliance and current requirements. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Criterion / operative mechanism:** Each preserved or changed behaviour has a justified status and affected consumers are considered.

**Mechanism:** Candidate elevates all observed legacy behaviour to a perpetual requirement.

**Trigger:** A characterisation test or compatibility argument blocks correction of an obsolete, accidental or harmful behaviour.

**Non-trigger / cheaper path:** Retain relevant promises and authorise justified revisions under ESME-C001 and 034.

**Authority:** {"actors": "Affected legitimate users, not only historical code output.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Legacy behaviour, actual reliance and current requirements.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-091", "CONDITIONS": "Retain relevant promises and authorise justified revisions under ESME-C001 and 034. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS001`, `ESME:ESME-CS022`, `ESME:ESME-CS025`, `ESME:ESME-CS034`, `ESME:ESME-CS064`, `ESME:ESME-CS065`.

**Clusters:** `SSS-K009`, `SSS-K012`, `SSS-K030`. **Tensions:** None. **Directional references:** 32 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/96`.

## ESME:ESME-C098

**Non-circular, authorised revision of maintenance methods and oracles**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** A proposed revision of a maintenance method or oracle relative to the preceding obligation.

**Criterion / operative mechanism:** The revision and any change of obligation have a bounded non-circular warrant; unchanged obligations remain in force and the successor does not grant itself wider authority.

**Mechanism:** Revise a method, threshold or oracle only for an authorised failure/benefit hypothesis or separately authorised objective change, using evidence not constituted merely by the candidate satisfying its newly chosen rule; preserve unrelated predecessor obligations.

**Trigger:** The method is failing or disproportionately costly, technology changes, or a candidate proposes to revise the expectation by which it will be judged.

**Non-trigger / cheaper path:** Keep an adequate method or remove an unused control; independent warrant need not mean a different person or an infallible external oracle.

**Authority:** Method owners and affected consumers approve changes; the method or agent cannot authorise its own broader powers.

**Communication/interaction:** {"recipient_and_boundary": "Method owners and affected consumers approve changes; the method or agent cannot authorise its own broader powers.", "content": "Revise tools, thresholds or inquiry methods through an authorised change with a stated failure/benefit hypothesis, preserving prior obligations unless separately changed.", "adequacy_test": "The revision has a bounded rationale and evidence, and previous obligations are not silently rewritten to make it pass.", "non_requirement": "No separate person, meeting, registry or tool is required merely because the analytical roles are distinct."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-098", "CONDITIONS": "An obvious erroneous expected value can be corrected with a checked domain example; a separate team or elaborate meta-process is not mandatory. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-067", "CONDITIONS": "Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS001`, `ESME:ESME-CS022`, `ESME:ESME-CS025`, `ESME:ESME-CS041`, `ESME:ESME-CS034`, `ESME:ESME-CS064`, `ESME:ESME-CS065`, `ESME:ESME-CS004`, `ESME:ESME-CS079`, `ESME:ESME-CS059`, `ESME:ESME-CS102`, `ESME:ESME-CS036`, `ESME:ESME-CS037`, `ESME:ESME-CS098`.

**Clusters:** `SSS-K009`, `SSS-K014`, `SSS-K020`. **Tensions:** None. **Directional references:** 61 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/97`.

## ESME:ESME-C099

**Human-only maintenance is universally superior**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Identify repository/task baseline, tool/model version, prompts/configuration relevant to evaluation, tests and data/model/policy artefacts. Record benchmark version and excluded cases.

**Criterion / operative mechanism:** The conclusion preserves both observed harms and supported benefits within their populations.

**Mechanism:** Reject the universal comparison; evaluate bounded automation by correct outcomes and complete costs.

**Trigger:** Adjudicate when a negative experiment is used to forbid all maintenance automation.

**Non-trigger / cheaper path:** Use whichever simple human/tool combination is supported for the actual task, including no automation.

**Authority:** Maintainers and decision makers select tools; neither vendor optimism nor a single negative study dictates every setting.

**Communication/interaction:** {"recipient_and_boundary": "Maintainers and decision makers select tools; neither vendor optimism nor a single negative study dictates every setting.", "content": "Reject the universal comparison; evaluate bounded automation by correct outcomes and complete costs.", "adequacy_test": "The conclusion preserves both observed harms and supported benefits within their populations.", "non_requirement": "No separate person, meeting, registry or tool is required merely because the analytical roles are distinct."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "B:ESME-068", "CONDITIONS": "Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS036`, `ESME:ESME-CS092`, `ESME:ESME-CS095`, `ESME:ESME-CS037`, `ESME:ESME-CS081`, `ESME:ESME-CS106`.

**Clusters:** `SSS-K024`. **Tensions:** None. **Directional references:** 13 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/98`.

## ESME:ESME-C100

**Reliable unattended repository-scale maintenance as a general capability**

**Disposition:** `UNRESOLVED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Identify repository/task baseline, tool/model version, prompts/configuration relevant to evaluation, tests and data/model/policy artefacts. Record benchmark version and excluded cases.

**Criterion / operative mechanism:** The packet exports an unresolved claim, not an unconditional audit obligation or a declaration of impossibility.

**Mechanism:** Withhold the general capability claim; distinguish bounded demonstrated tasks from open obligations in intent, long-term regression, review, authority and deployment.

**Trigger:** A general unattended-maintenance claim is used to remove oversight or transfer responsibility.

**Non-trigger / cheaper path:** Use bounded automation with explicit constraints, or an ordinary authorised maintainer when evidence is insufficient.

**Authority:** Tool evaluators establish evidence; service/repository owners decide permissible delegation; the claimed capability does not create authority.

**Communication/interaction:** {"recipient_and_boundary": "Tool evaluators establish evidence; service/repository owners decide permissible delegation; the claimed capability does not create authority.", "content": "Withhold the general capability claim; distinguish bounded demonstrated tasks from open obligations in intent, long-term regression, review, authority and deployment.", "adequacy_test": "The packet exports an unresolved claim, not an unconditional audit obligation or a declaration of impossibility.", "non_requirement": "No separate person, meeting, registry or tool is required merely because the analytical roles are distinct."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "B:ESME-069", "CONDITIONS": "Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS034`, `ESME:ESME-CS036`, `ESME:ESME-CS064`, `ESME:ESME-CS066`, `ESME:ESME-CS037`, `ESME:ESME-CS092`, `ESME:ESME-CS095`, `ESME:ESME-CS097`, `ESME:ESME-CS104`, `ESME:ESME-CS106`.

**Clusters:** `SSS-K024`, `SSS-K033`. **Tensions:** None. **Directional references:** 50 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/99`.

## ESME:ESME-C101

**A formal change board for every change**

**Disposition:** `CEREMONY_NOT_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Identify the system/configuration being changed and any non-code artefact needed to interpret the request. A source commit alone may omit deployed data and obligations.

**Criterion / operative mechanism:** The decision is adequately authorised and informed whether or not a meeting occurs.

**Mechanism:** Strip the mandatory ritual while preserving appropriate authorisation, consultation and evidence; use a fuller forum only when conflicts or obligations require it.

**Trigger:** Adjudicate when the presence of a board is treated as the maintenance property itself.

**Non-trigger / cheaper path:** A direct authorised maintainer decision can suffice for a bounded change.

**Authority:** Existing legitimate decision authority remains; removal of ceremony does not permit unauthorised changes.

**Communication/interaction:** {"recipient_and_boundary": "Existing legitimate decision authority remains; removal of ceremony does not permit unauthorised changes.", "content": "Strip the mandatory ritual while preserving appropriate authorisation, consultation and evidence; use a fuller forum only when conflicts or obligations require it.", "adequacy_test": "The decision is adequately authorised and informed whether or not a meeting occurs.", "non_requirement": "No separate person, meeting, registry or tool is required merely because the analytical roles are distinct."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "B:ESME-071", "CONDITIONS": "Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS069`, `ESME:ESME-CS006`, `ESME:ESME-CS071`, `ESME:ESME-CS083`.

**Clusters:** `SSS-K009`, `SSS-K032`. **Tensions:** None. **Directional references:** 34 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/100`.

## ESME:ESME-C102

**Cross-stage change–evidence–action coherence**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** The cross-stage binding between intent, subject, candidate, evidence and authorised action.

**Criterion / operative mechanism:** The evidence actually consumed and the action actually taken concern the same scoped candidate, obligations and authority; a detected mismatch blocks only the unsupported use.

**Mechanism:** Bind the relevant intent, baseline, candidate, impact boundary, observation/oracle and acceptance/action authority across mechanism handoffs so that evidence is consumed for the same authorised intervention.

**Trigger:** Evidence or decisions pass among stages, tools or actors, or concurrent work can change the subject before action.

**Non-trigger / cheaper path:** One visible issue, exact diff and direct check can establish the binding in a local change; no separate contract document or registry is required.

**Authority:** {"actors": "Those authorising, implementing and accepting the same intervention.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Baseline, change objective, preservation set, affected consumers and evidence bindings.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-093", "CONDITIONS": "For a local task, one concise issue with linked baseline and tests can carry the contract; no new schema or formal document is mandatory. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-072", "CONDITIONS": "Include coordination and validation costs created by composition. Consolidate or retire controls when a cheaper adequate configuration exists, without silently waiving protected obligations.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS001`, `ESME:ESME-CS019`, `ESME:ESME-CS022`, `ESME:ESME-CS025`, `ESME:ESME-CS041`, `ESME:ESME-CS064`, `ESME:ESME-CS065`, `ESME:ESME-CS069`, `ESME:ESME-CS074`, `ESME:ESME-CS095`, `ESME:ESME-CS034`, `ESME:ESME-CS063`, `ESME:ESME-CS092`.

**Clusters:** `SSS-K002`, `SSS-K015`. **Tensions:** None. **Directional references:** 46 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/101`.

## ESME:ESME-C103

**Assumption-indexed evidence invalidation across mechanisms**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** The applicability of downstream claims to their consequential supporting assumptions.

**Criterion / operative mechanism:** No affected claim retains unqualified operative force outside its evidence envelope; unaffected evidence remains usable.

**Mechanism:** Track the consequential assumptions under which evidence supports a downstream claim; when an assumption changes, narrow or invalidate only dependent claims and obtain adequate replacement evidence before consequential reuse.

**Trigger:** A relevant environment, observer, tool/model, data distribution, dependency or obligation changes while earlier evidence is still being consumed.

**Non-trigger / cheaper path:** Reuse evidence when its relevant envelope remains valid; explicit local reasoning may replace a dependency registry or global rerun.

**Authority:** {"actors": "Maintainer or acceptor reusing prior results.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Evidence claims and their baseline, environment, observer and tool assumptions.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-094", "CONDITIONS": "A direct note that the dependency is unchanged may suffice; no universal dependency database is required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-072", "CONDITIONS": "Include coordination and validation costs created by composition. Consolidate or retire controls when a cheaper adequate configuration exists, without silently waiving protected obligations.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS019`, `ESME:ESME-CS024`, `ESME:ESME-CS038`, `ESME:ESME-CS050`, `ESME:ESME-CS052`, `ESME:ESME-CS064`, `ESME:ESME-CS069`, `ESME:ESME-CS074`, `ESME:ESME-CS022`, `ESME:ESME-CS025`, `ESME:ESME-CS095`, `ESME:ESME-CS034`, `ESME:ESME-CS063`, `ESME:ESME-CS092`.

**Clusters:** `SSS-K014`, `SSS-K015`, `SSS-K025`. **Tensions:** None. **Directional references:** 61 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/102`.

## ESME:ESME-C104

**Obligation continuity across reachable joint states**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Reachable joint states of independently considered edits, versions, mappings and responsibilities.

**Criterion / operative mechanism:** Newly reachable consequential combinations have adequate obligation evidence or are prevented; endpoint correctness is not silently extrapolated to the join.

**Mechanism:** At the join of concurrent edits, mixed versions, data mappings and responsibility transfers, identify reachable combinations that matter to supported obligations and validate, isolate or prohibit those combinations.

**Trigger:** The selected composition creates materially new joint states or interactions not covered by its constituent endpoint evidence.

**Non-trigger / cheaper path:** Proven disjointness, a genuine quiescent boundary or a simpler strategy can remove a combination; no exhaustive universal state model is required.

**Authority:** Integrators and operators control only their own transitions; consumer/data owners adjudicate cross-boundary obligations.

**Communication/interaction:** {"recipient_and_boundary": "Integrators and operators control only their own transitions; consumer/data owners adjudicate cross-boundary obligations.", "content": "Identify reachable joint states, authoritative data and permitted version/change combinations; constrain operation or add evidence for the newly created interactions.", "adequacy_test": "No supported transition relies solely on endpoint tests when consequential intermediate interactions remain unexamined.", "non_requirement": "No separate person, meeting, registry or tool is required merely because the analytical roles are distinct."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "B:ESME-073", "CONDITIONS": "Include coordination and validation costs created by composition. Consolidate or retire controls when a cheaper adequate configuration exists, without silently waiving protected obligations.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS029`, `ESME:ESME-CS087`, `ESME:ESME-CS093`, `ESME:ESME-CS063`, `ESME:ESME-CS086`.

**Clusters:** `SSS-K013`, `SSS-K019`, `SSS-K020`. **Tensions:** `SSS-T010`, `SSS-T014`. **Directional references:** 62 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/103`.

## ESME:ESME-C105

**Feedback-driven proportionality and retirement of combined controls**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** The combined maintenance-control arrangement and its continuing consumers, protection and total burden.

**Criterion / operative mechanism:** The selected combination has justified protection, consumers and continuation conditions; unnecessary controls can end while residual obligations remain protected.

**Mechanism:** Evaluate the combined inquiry, validation, coordination and support arrangement against live obligations and observed outcomes; consolidate, substitute or retire controls whose consumer or protection has ended or whose cost is dominated, without silently waiving the outcome.

**Trigger:** Several controls interact, compete for finite maintenance capacity or persist after their original obligations change.

**Non-trigger / cheaper path:** Use the existing adequate local method unchanged; a simple cost/consumer judgment can suffice without a meta-process or optimisation engine.

**Authority:** {"actors": "Maintainers and affected stakeholders deciding acceptable evidence and coordination.", "boundary": "Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record."}

**Communication/interaction:** {"exchange": "Selected controls, protected obligations, costs and consumers.", "purpose": "Enable the stated consumer to judge the mechanism, assumptions and postcondition. Use the cheapest adequate channel in NON_TRIGGER_OR_CHEAP_PATH; mere publication is not successful communication."}

**Omission/retirement and retained reopening distinctions:** {"CANONICAL": "Omit a mechanism when its trigger is absent or a cheaper adequate substitute establishes the actual obligation; retire it when its protected obligation or consumer ends. Do not use omission to waive an unchanged supported outcome.", "INPUT_SPECIFIC": [{"INPUT_PROPERTY_KEY": "A:ESME-097", "CONDITIONS": "Use a local explanation, direct test and reversible edit when adequate; choose no intervention when no justified change exists. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it."}, {"INPUT_PROPERTY_KEY": "B:ESME-074", "CONDITIONS": "Include coordination and validation costs created by composition. Consolidate or retire controls when a cheaper adequate configuration exists, without silently waiving protected obligations.", "SOURCE": "Frozen B synthesis intake Retirement field; no alteration to original property JSON."}]}

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESME:ESME-CS013`, `ESME:ESME-CS025`, `ESME:ESME-CS052`, `ESME:ESME-CS056`, `ESME:ESME-CS059`, `ESME:ESME-CS023`, `ESME:ESME-CS036`, `ESME:ESME-CS037`, `ESME:ESME-CS008`, `ESME:ESME-CS029`, `ESME:ESME-CS084`, `ESME:ESME-CS090`, `ESME:ESME-CS078`, `ESME:ESME-CS058`, `ESME:ESME-CS098`.

**Clusters:** `SSS-K011`, `SSS-K023`, `SSS-K026`, `SSS-K032`. **Tensions:** `SSS-T008`, `SSS-T012`, `SSS-T016`. **Directional references:** 95 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESME.zip!/EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CANONICAL_PROPERTY_LEDGER.json#/properties/104`.

## ESPLE:ESPLE-001

**Warranted family boundary**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** The family consists of products whose shared domain assumptions warrant coordinated production; code resemblance alone is insufficient.

**Criterion / operative mechanism:** State which products and foreseeable needs belong together; test shared domain assumptions against counterexamples before committing to shared production.

**Trigger:** A decision to coordinate assets or future variants across more than one product need.

**Non-trigger / cheaper path:** For incidental shared utilities, use ordinary component reuse or independent products without introducing a family programme.

**Authority:** Portfolio and domain decision-makers with product representatives; similarity analysis does not authorise merging teams or obligations. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Product needs, differences, expected future use and who can sustain shared assets.; the result must expose Included and excluded products have reasons; at least one plausible contrary case has been adjudicated; the chosen boundary supports feasible derivation. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Reopen the boundary when required assumptions diverge; dissolve or split the family when coordinated reuse no longer earns its cost.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S002`, `ESPLE:ESPLE-S003`, `ESPLE:ESPLE-S007`, `ESPLE:ESPLE-S009`, `ESPLE:ESPLE-S013`, `ESPLE:ESPLE-S026`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K001`, `SSS-K005`, `SSS-K034`. **Tensions:** None. **Directional references:** 44 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/0`.

## ESPLE:ESPLE-002

**Evidence of commonality and variability**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** The family consists of products whose shared domain assumptions warrant coordinated production; code resemblance alone is insufficient.

**Criterion / operative mechanism:** Compare requirements, products and expert explanations; separate invariant needs, intended variation and historical accidents; record disagreement rather than infer a common core from names.

**Trigger:** Establishing or revising the domain knowledge on which reusable assets depend.

**Non-trigger / cheaper path:** A short reviewed comparison of a few stable products can replace an elaborate modelling exercise.

**Authority:** Domain engineers and product experts exchange examples and exceptions; neither an extractor nor one expert unilaterally determines all valid products. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Representative products, stakeholder needs, operational differences and access to domain expertise.; the result must expose Claimed commonalities have examples and scope; observed differences have an explicit disposition rather than automatically becoming features. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Stop analysing details with no current or expected product consumer, while retaining knowledge needed for supported products.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S005`, `ESPLE:ESPLE-S006`, `ESPLE:ESPLE-S007`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K001`, `SSS-K005`, `SSS-K008`, `SSS-K030`. **Tensions:** None. **Directional references:** 64 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/1`.

## ESPLE:ESPLE-003

**Value-bound admission of variability**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** The family consists of products whose shared domain assumptions warrant coordinated production; code resemblance alone is insufficient.

**Criterion / operative mechanism:** Admit a new variation only with a product or credible future need, an implementation boundary, an assurance consequence and an identified support cost.

**Trigger:** A request to broaden the set of products or selectable behaviours.

**Non-trigger / cheaper path:** Keep a one-off requirement product-local, or postpone its generalisation until repeated demand supplies evidence.

**Authority:** Product sponsors and shared-asset maintainers negotiate the scope; this criterion does not require a new board for each feature. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Demand rationale, expected reuse, interaction impact and costs of both local and shared realisation.; the result must expose An admitted option has a consumer and support path; rejected or deferred options retain their rationale. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Reassess the option when its demand disappears; support-aware removal is a separate obligation in ESPLE-061.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S007`, `ESPLE:ESPLE-S009`, `ESPLE:ESPLE-S012`, `ESPLE:ESPLE-S013`, `ESPLE:ESPLE-S041`, `ESPLE:ESPLE-S045`.

**Clusters:** `SSS-K005`, `SSS-K011`, `SSS-K023`, `SSS-K026`, `SSS-K028`, `SSS-K030`, `SSS-K031`. **Tensions:** `SSS-T004`. **Directional references:** 106 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/2`.

## ESPLE:ESPLE-004

**Coupled domain and application responsibilities**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Domain and application work are justified by a family whose reusable capabilities serve actual or credible products.

**Criterion / operative mechanism:** Maintain a functional distinction between creating family capabilities and instantiating products, with explicit exchange of requirements, constraints and feasibility evidence.

**Trigger:** At least one asset or production decision is intended to serve several products.

**Non-trigger / cheaper path:** The same people may perform both activities; a small family needs no separate departments or serial phases.

**Authority:** Asset developers and product developers need reciprocal access to decisions; management supplies resources rather than treating a model as authority. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Defined family scope, asset responsibilities and actual product requests.; the result must expose Product work can identify the reusable baseline it consumes, and asset work can identify the products it supports. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** If no cross-product asset remains, use a single-product process rather than preserve two ceremonial tracks.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S006`, `ESPLE:ESPLE-S008`, `ESPLE:ESPLE-S009`, `ESPLE:ESPLE-S013`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K009`, `SSS-K010`, `SSS-K021`, `SSS-K022`, `SSS-K034`. **Tensions:** None. **Directional references:** 69 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/3`.

## ESPLE:ESPLE-005

**Product-to-core feedback**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Domain and application work are justified by a family whose reusable capabilities serve actual or credible products.

**Criterion / operative mechanism:** Return a product observation with its configuration, asset baseline and consequence; decide whether to repair the core, adjust a constraint, retain an exception or revise scope.

**Trigger:** Derivation failure, recurring local workaround, unexpected interaction or a justified new common need.

**Non-trigger / cheaper path:** A direct conversation and linked change record can suffice when the team and affected products are small.

**Authority:** Product engineers communicate evidence to domain maintainers; affected product owners participate when obligations change. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Reproducible observation, affected product context and a maintainer able to change the relevant shared asset.; the result must expose Feedback has a reasoned disposition and the producing product receives the result; absence of a core change can be legitimate. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Stop recurring review when the triggering problem is resolved or outside the family; retain the decision's trace for supported versions.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S006`, `ESPLE:ESPLE-S009`, `ESPLE:ESPLE-S011`, `ESPLE:ESPLE-S013`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K008`, `SSS-K014`, `SSS-K021`, `SSS-K022`. **Tensions:** None. **Directional references:** 80 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/4`.

## ESPLE:ESPLE-006

**Product exceptions with retained lineage**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Domain and application work are justified by a family whose reusable capabilities serve actual or credible products.

**Criterion / operative mechanism:** Permit a bounded product divergence with its baseline, purpose, support responsibility and conditions for reintegration or continued separation.

**Trigger:** A product obligation cannot be met adequately through the current shared assets without disproportionate disruption.

**Non-trigger / cheaper path:** A small isolated patch with a recorded origin may be better than a new family-wide variation point.

**Authority:** Product and core maintainers agree who carries future changes; permission to diverge is not permission to misrepresent family assurance. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Product obligation, impact on other products and an owner willing to maintain the exception.; the result must expose The exceptional product is identifiable, its unsupported shared claims are withdrawn, and applicable fixes can be located. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Reintegrate when a genuine common mechanism emerges, or remove family membership when divergence is enduring and independent.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S010`, `ESPLE:ESPLE-S011`, `ESPLE:ESPLE-S041`, `ESPLE:ESPLE-S013`, `ESPLE:ESPLE-S026`, `ESPLE:ESPLE-S028`.

**Clusters:** `SSS-K009`, `SSS-K012`, `SSS-K013`, `SSS-K021`, `SSS-K022`, `SSS-K023`, `SSS-K030`. **Tensions:** `SSS-T001`, `SSS-T002`, `SSS-T006`. **Directional references:** 124 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/5`.

## ESPLE:ESPLE-007

**Selection among proactive, reactive and extractive adoption**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Domain and application work are justified by a family whose reusable capabilities serve actual or credible products.

**Criterion / operative mechanism:** Choose anticipatory domain investment, incremental extension or recovery from existing variants according to uncertainty, existing assets and available migration capacity.

**Trigger:** Starting a product line or changing how an existing portfolio is produced.

**Non-trigger / cheaper path:** Reuse a few stable assets or retain clone-and-own while collecting evidence; no immediate platform conversion is required.

**Authority:** Portfolio sponsors and engineering leads select a transition strategy; a tool supplier's capability does not determine organisational readiness. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Demand horizon, asset state, change rate, budget and the cost of delaying products.; the result must expose The chosen route states what is invested now, what remains product-local and what evidence triggers further consolidation. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Change route when uncertainty resolves, stable commonality emerges or expected reuse fails to materialise.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S007`, `ESPLE:ESPLE-S010`, `ESPLE:ESPLE-S013`, `ESPLE:ESPLE-S026`, `ESPLE:ESPLE-S027`.

**Clusters:** `SSS-K005`, `SSS-K011`, `SSS-K013`, `SSS-K016`, `SSS-K028`, `SSS-K031`. **Tensions:** None. **Directional references:** 87 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/6`.

## ESPLE:ESPLE-008

**Explicit feature semantics**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** The model represents a declared product family, not every conceivable configuration in the technology domain.

**Criterion / operative mechanism:** Define what each feature denotes, who interprets it and how selections relate to requirements, implementation and runtime capability.

**Trigger:** Features are used to negotiate products, derive artefacts or justify assurance.

**Non-trigger / cheaper path:** A compact glossary plus explicit configuration rules can be sufficient; a tree is optional.

**Authority:** Domain experts, configurators and developers must resolve semantic disagreement; the modeller cannot decide stakeholder intent by naming a node. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Stakeholder vocabulary, variation decisions and the relevant implementation mapping.; the result must expose A selected feature has a checkable meaning at the product boundary, including attributes or multiplicity where required. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Remove semantic entries only with the associated supported feature or replace them with an explicit migration mapping.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S005`, `ESPLE:ESPLE-S009`, `ESPLE:ESPLE-S014`, `ESPLE:ESPLE-S015`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K001`, `SSS-K003`, `SSS-K022`, `SSS-K029`, `SSS-K034`. **Tensions:** None. **Directional references:** 78 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/7`.

## ESPLE:ESPLE-009

**Constraint-consistency diagnostics**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** The model represents a declared product family, not every conceivable configuration in the technology domain.

**Criterion / operative mechanism:** Check the model's declared semantics for consistency and investigate diagnoses relative to intended configurations; report the exact model and solver interpretation.

**Trigger:** Constraints are nontrivial, edited, combined or used to reject user selections.

**Non-trigger / cheaper path:** Exhaustive enumeration or a manually checked decision table may suffice for a tiny model.

**Authority:** Modellers and configurators consume witnesses or explanations; a satisfiability result is not a release authorisation. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: A defined constraint language, faithful encoding and intended interpretations for anomalies.; the result must expose The checked model has a satisfiable witness or an understood inconsistency; apparent anomalies have domain dispositions. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Omit a solver when a simpler complete check is reliable; retain the consistency obligation while constraints matter.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S014`, `ESPLE:ESPLE-S015`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K007`. **Tensions:** None. **Directional references:** 29 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/8`.

## ESPLE:ESPLE-010

**Validation of domain-constraint adequacy**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** The model represents a declared product family, not every conceivable configuration in the technology domain.

**Criterion / operative mechanism:** Validate constraints against representative positive and negative product scenarios, expert knowledge and implementation evidence; explicitly record unmodelled conditions.

**Trigger:** A variability model is relied upon to accept or exclude product choices.

**Non-trigger / cheaper path:** Review a small set of known supported and forbidden combinations instead of building a comprehensive formal ontology.

**Authority:** Domain experts and product stakeholders validate meaning; technical extraction contributes evidence but cannot supply every missing obligation. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Domain obligations, known product examples, counterexamples and the boundary of extraction or modelling.; the result must expose Important rejected and accepted combinations have reasons traceable outside the model itself; limitations accompany configuration advice. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Remove obsolete constraints only after checking supported products and external obligations; do not equate unused with invalid.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S005`, `ESPLE:ESPLE-S009`, `ESPLE:ESPLE-S041`, `ESPLE:ESPLE-S015`.

**Clusters:** `SSS-K006`, `SSS-K007`. **Tensions:** None. **Directional references:** 54 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/9`.

## ESPLE:ESPLE-011

**Explanation-assisted configuration**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** The model represents a declared product family, not every conceivable configuration in the technology domain.

**Criterion / operative mechanism:** Relate a conflict or forced choice to the smallest useful set of decisions and constraints; permit human correction and show relevant provenance.

**Trigger:** Configuration choices are numerous, cross-constrained or made by users without implementation expertise.

**Non-trigger / cheaper path:** A domain expert can explain a small stable set of rules directly; automated minimal explanations are not always needed.

**Authority:** Configurators and domain experts; an explanation assists choice but must not conceal alternative repairs or silently change requirements. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Meaningful feature semantics, decision history and a link from the diagnosis to a possible user action.; the result must expose The consumer can identify an acceptable repair or understand why no permitted product meets the request. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Omit explanation machinery when nobody needs it or when stable direct guidance is cheaper and equally effective.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S015`, `ESPLE:ESPLE-S032`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K022`, `SSS-K032`. **Tensions:** None. **Directional references:** 52 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/10`.

## ESPLE:ESPLE-012

**Richer variability types when the domain requires them**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** The model represents a declared product family, not every conceivable configuration in the technology domain.

**Criterion / operative mechanism:** Use the least expressive representation that preserves required distinctions; verify translations and tool support for the actual language level.

**Trigger:** The domain requires multiplicity, arithmetic, typed values or constraints not expressible adequately by simple selection.

**Non-trigger / cheaper path:** Keep a Boolean model or a small typed table when that already captures consequential decisions.

**Authority:** Modellers and tool integrators agree the supported semantics; unsupported constructs must not be silently ignored. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Value domains, intended constraints and known limitations of the chosen analysis tools.; the result must expose Required domain distinctions survive parsing, transformation and analysis, with unsupported cases explicitly rejected or handled separately. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Simplify representation when removed requirements no longer need its expressive power.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S009`, `ESPLE:ESPLE-S032`, `ESPLE:ESPLE-S041`, `ESPLE:ESPLE-S015`.

**Clusters:** `SSS-K003`, `SSS-K029`, `SSS-K032`. **Tensions:** `SSS-T003`. **Directional references:** 58 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/11`.

## ESPLE:ESPLE-013

**Deliberate binding-time selection**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Realisation choices serve the selected family scope rather than requiring all products to share one implementation technique.

**Criterion / operative mechanism:** Choose a binding time for each variation by weighing when information becomes available against footprint, assurance, deployment and runtime transition costs.

**Trigger:** A variation point is introduced or its resolution time changes.

**Non-trigger / cheaper path:** Bind early when the required choice is already known and later change has no justified value.

**Authority:** Product architects, build/deployment engineers and operators where relevant; runtime rebinding needs actual operational permission. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Timing of product knowledge, resource limits, supported changes and operational safety constraints.; the result must expose The implementation resolves the choice at the declared point, and the corresponding invariants and failure handling have been checked. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Remove late-binding infrastructure when the need to change at runtime disappears; do not remove support for existing variants silently.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S017`, `ESPLE:ESPLE-S030`, `ESPLE:ESPLE-S042`, `ESPLE:ESPLE-S043`, `ESPLE:ESPLE-S031`, `ESPLE:ESPLE-S045`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K020`, `SSS-K025`, `SSS-K026`, `SSS-K034`. **Tensions:** `SSS-T010`. **Directional references:** 90 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/12`.

## ESPLE:ESPLE-014

**Feature-to-realisation traceability**

**Disposition:** `USEFUL_BUT_EASILY_BUREAUCRATISED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Realisation choices serve the selected family scope rather than requiring all products to share one implementation technique.

**Criterion / operative mechanism:** Preserve the feature-to-artefact relations needed for derivation, change impact and diagnosis, including build selection, generator input and shared implementation.

**Trigger:** Consequential changes or product construction depend on understanding how a feature is realised.

**Non-trigger / cheaper path:** Local naming, module structure and a small checked mapping can replace a comprehensive trace database.

**Authority:** Developers, product builders and assurance engineers; a trace owner maintains evidence but does not infer semantic equivalence from a link alone. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Feature semantics, actual artefacts and the consumers of impact or derivation information.; the result must expose A relevant selection or change can be followed to affected realisation and products, with known unmapped areas exposed. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Drop a trace whose decision consumer disappears, provided structural or direct evidence supplies the same needed relation.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S005`, `ESPLE:ESPLE-S009`, `ESPLE:ESPLE-S017`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K004`, `SSS-K008`, `SSS-K029`, `SSS-K032`. **Tensions:** None. **Directional references:** 70 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/13`.

## ESPLE:ESPLE-015

**A portfolio of variability realisation techniques**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Realisation choices serve the selected family scope rather than requiring all products to share one implementation technique.

**Criterion / operative mechanism:** Select among conditional code, parameters, component/plugin substitution, inheritance, aspects, feature modules and transformations according to local constraints; explicitly manage cross-mechanism interactions.

**Trigger:** Designing or restructuring the realisation of family variation.

**Non-trigger / cheaper path:** Retain an ordinary parameter or small conditional when it is understandable and adequately checked.

**Authority:** Implementers and architects choose mechanisms within the family invariants; tool fashion is not an independent requirement. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Required binding time, feature granularity, language/tool constraints and change patterns.; the result must expose The chosen mechanisms realise intended variants and expose the dependencies needed for maintenance and assurance. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Consolidate mechanisms only when doing so reduces consequential complexity without destroying useful product autonomy.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S017`, `ESPLE:ESPLE-S018`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K016`. **Tensions:** None. **Directional references:** 22 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/14`.

## ESPLE:ESPLE-016

**Ordered and conditional delta composition**

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Realisation choices serve the selected family scope rather than requiring all products to share one implementation technique.

**Criterion / operative mechanism:** Define applicable deltas, their dependencies or order and the validity conditions of each modification; verify the resulting product rather than assuming arbitrary edits commute.

**Trigger:** Product differences naturally require structured additions, removals or changes over a shared base.

**Non-trigger / cheaper path:** Use direct modules or parameters where no meaningful transformation sequence is needed.

**Authority:** Product-line implementers and type/consistency analysers; a delta is a proposed construction step, not unrestricted authority to modify any supported product. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: A base program, delta applicability conditions, ordering constraints and language-specific well-formedness checks.; the result must expose Each selected delta is applicable in its context and the ordered derivation yields a well-formed product meeting selected requirements. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Replace deltas with a simpler representation when the transformation structure no longer provides useful reuse or separation.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S018`, `ESPLE:ESPLE-S017`.

**Clusters:** `SSS-K013`, `SSS-K019`. **Tensions:** None. **Directional references:** 42 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/15`.

## ESPLE:ESPLE-017

**Validation of generator realisation**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Realisation choices serve the selected family scope rather than requiring all products to share one implementation technique.

**Criterion / operative mechanism:** Validate the mapping from selections and asset versions to generated structure and behaviour, using applicable checks on transformations and produced products.

**Trigger:** Product derivation relies on generation or nontrivial transformation of shared assets.

**Non-trigger / cheaper path:** Review a simple deterministic template and test representative outputs; do not require a universal proof of the generator.

**Authority:** Generator maintainers and product acceptance engineers exchange failing configurations and output evidence. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Intended realisation relation, generator/version identity and an oracle independent of merely successful generation.; the result must expose Selected and excluded capabilities have the intended realised effects; failures are attributable to the configuration and derivation baseline. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Remove generator-specific controls if derivation no longer uses generation; retain ordinary product validation.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S006`, `ESPLE:ESPLE-S016`, `ESPLE:ESPLE-S021`, `ESPLE:ESPLE-S019`.

**Clusters:** `SSS-K007`, `SSS-K015`, `SSS-K017`, `SSS-K024`, `SSS-K025`. **Tensions:** None. **Directional references:** 99 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/16`.

## ESPLE:ESPLE-018

**Reusable non-code assets with consumers**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Core assets and production plans are bounded by the supported family and its product obligations.

**Criterion / operative mechanism:** Treat non-code work products as reusable assets where products actually consume them, with compatible versioning and variation information.

**Trigger:** Repeated product work depends on shared engineering knowledge beyond implementation code.

**Non-trigger / cheaper path:** Share only the few requirements, tests or instructions that have a real consumer; a full document suite is not obligatory.

**Authority:** Requirements, development, assurance and product-production participants according to the artefact; public templates do not establish use. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Identified product consumers, scope of reuse and responsibility for keeping the asset valid.; the result must expose A product can identify which shared non-code asset supports its construction or acceptance and which parts are product-specific. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Retire a non-code asset when it has no supported consumer or a cheaper embedded mechanism performs its function.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S008`, `ESPLE:ESPLE-S009`, `ESPLE:ESPLE-S011`, `ESPLE:ESPLE-S033`, `ESPLE:ESPLE-S013`, `ESPLE:ESPLE-S006`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K008`, `SSS-K021`, `SSS-K032`. **Tensions:** None. **Directional references:** 59 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/17`.

## ESPLE:ESPLE-019

**Family architectural invariants and variation boundaries**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Core assets and production plans are bounded by the supported family and its product obligations.

**Criterion / operative mechanism:** State the architectural invariants required for reuse and the permitted substitutions; enforce or check them in the derivation path where the claim requires enforcement.

**Trigger:** Shared components, interfaces or assurance depend on product architecture remaining within a known class.

**Non-trigger / cheaper path:** A few stable interfaces and reviewed component choices can suffice; an elaborate reference architecture is unnecessary for a small family.

**Authority:** Family architects and product implementers; a reference diagram alone cannot prohibit an actual implementation choice. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Common obligations, variation points and evidence about what the real production process constrains.; the result must expose A derived product either satisfies the relevant invariants or carries an explicit exception that limits inherited guarantees. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Remove an invariant when no shared asset or claim depends on it; reassess architecture rather than accumulate exceptions indefinitely.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S003`, `ESPLE:ESPLE-S005`, `ESPLE:ESPLE-S009`, `ESPLE:ESPLE-S017`, `ESPLE:ESPLE-S013`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K003`, `SSS-K021`, `SSS-K030`, `SSS-K034`. **Tensions:** `SSS-T001`, `SSS-T002`, `SSS-T006`. **Directional references:** 94 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/18`.

## ESPLE:ESPLE-020

**A versioned product-derivation plan**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Core assets and production plans are bounded by the supported family and its product obligations.

**Criterion / operative mechanism:** Maintain an actionable, version-related derivation procedure that tells builders which decisions, assets, tools and checks produce a supported product.

**Trigger:** Products must be reproduced, handed to another team or built repeatedly from shared assets.

**Non-trigger / cheaper path:** A short script plus explicit human decisions can be a complete plan for a small stable family.

**Authority:** Product builders execute the plan and return obstacles to maintainers; the plan does not itself accept a release. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Asset catalogue, configuration decisions, compatible tool versions and product acceptance criteria.; the result must expose A competent builder can derive the intended product from declared inputs and identify unsupported deviations. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Delete unused steps and retire plans for unsupported baselines; retain what is needed to reproduce obligations still in force.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S011`, `ESPLE:ESPLE-S013`, `ESPLE:ESPLE-S021`, `ESPLE:ESPLE-S006`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K002`, `SSS-K024`, `SSS-K034`. **Tensions:** `SSS-T007`. **Directional references:** 56 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/19`.

## ESPLE:ESPLE-021

**Configuration, asset and tool baseline identity**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Core assets and production plans are bounded by the supported family and its product obligations.

**Criterion / operative mechanism:** Identify the configuration and the relevant asset, generator, dependency and tool versions together; distinguish requested configuration from realised product identity.

**Trigger:** Reproduction, support, change impact or transfer of an assurance result depends on knowing what was built.

**Non-trigger / cheaper path:** A versioned configuration file and pinned build inputs may suffice; a new provenance service is not inherently required.

**Authority:** Builders, maintainers and acceptance reviewers exchange product identities; an identifier is evidence of naming, not proof of semantic correctness. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Actual build inputs and the equivalence level required for support or assurance.; the result must expose A reported product can be traced to its actual derivation inputs and distinguished from a similarly named but different baseline. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Reduce retention when support and reproducibility obligations end, not merely because the current mainline has moved on.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S011`, `ESPLE:ESPLE-S021`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K002`, `SSS-K015`, `SSS-K024`, `SSS-K025`. **Tensions:** None. **Directional references:** 77 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/20`.

## ESPLE:ESPLE-022

**Repeatable derivation at a declared equivalence level**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Core assets and production plans are bounded by the supported family and its product obligations.

**Criterion / operative mechanism:** Declare whether repeatability means equal feature realisation, equivalent tested behaviour, identical generated source or identical bytes, then control the inputs necessary for that claim.

**Trigger:** Support, certification, comparison or distribution requires reliable reconstruction of a product.

**Non-trigger / cheaper path:** Behavioural or structural equivalence may be adequate; do not impose bit-for-bit output where timestamps or tool differences are immaterial.

**Authority:** Builders and assurance consumers agree the needed repeatability; the strongest possible level is not automatically economically justified. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: A declared equivalence criterion, relevant environment inputs and known nondeterministic steps.; the result must expose A repeat derivation meets the declared equivalence criterion, or differences are explained and adjudicated. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Relax controls whose stronger identity is no longer consumed, while retaining enough information for supported products.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S011`, `ESPLE:ESPLE-S016`, `ESPLE:ESPLE-S021`, `ESPLE:ESPLE-S006`.

**Clusters:** `SSS-K002`. **Tensions:** None. **Directional references:** 12 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/21`.

## ESPLE:ESPLE-023

**Layer-specific assurance claims**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Assurance quantifies over a declared configuration set, not an undefined claim about every possible product.

**Criterion / operative mechanism:** State each assurance claim's object, quantified configurations, inputs, environment and baseline; identify the realisation obligations needed to carry it to a product.

**Trigger:** A model, test, proof or analysis result is used to justify a product or family decision.

**Non-trigger / cheaper path:** A concise claim-and-boundary statement attached to the result can be sufficient.

**Authority:** Assurance reviewers and release decision-makers consume bounded claims; analysts do not acquire release authority by producing evidence. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Actual analysis semantics, configuration coverage, tool limitations and product identity.; the result must expose It is possible to tell what the result establishes, what it leaves open and which derived products may inherit it. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Retire an assurance claim when its baseline or assumptions cease to hold; do not carry it forward by name alone.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S014`, `ESPLE:ESPLE-S019`, `ESPLE:ESPLE-S021`, `ESPLE:ESPLE-S031`, `ESPLE:ESPLE-S040`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K006`, `SSS-K007`, `SSS-K015`, `SSS-K017`, `SSS-K018`, `SSS-K024`, `SSS-K025`, `SSS-K033`. **Tensions:** None. **Directional references:** 160 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/22`.

## ESPLE:ESPLE-024

**Interaction-aware coverage**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Assurance quantifies over a declared configuration set, not an undefined claim about every possible product.

**Criterion / operative mechanism:** Identify plausible interaction mechanisms and select checks whose coverage matches their order and risk; include shared-asset and environmental interactions, not only adjacent feature-tree nodes.

**Trigger:** Features share state, resources, protocols, build choices or behavioural assumptions.

**Non-trigger / cheaper path:** Isolated independent substitutions may need only interface checks; do not impose high-order combinatorial testing without an interaction rationale.

**Authority:** Feature developers and assurance engineers exchange interaction hypotheses and failures; product owners decide acceptable residual risk. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Dependency evidence, known faults, changed features and the operational conditions under which they combine.; the result must expose Important interaction hypotheses have tests, analysis or an explicit unresolved disposition; coverage statements identify what was not exercised. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Remove checks only when the interaction is structurally impossible, no longer supported or covered by a demonstrably adequate alternative.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S017`, `ESPLE:ESPLE-S019`, `ESPLE:ESPLE-S020`, `ESPLE:ESPLE-S021`, `ESPLE:ESPLE-S040`.

**Clusters:** `SSS-K004`, `SSS-K006`, `SSS-K018`, `SSS-K019`, `SSS-K025`. **Tensions:** `SSS-T016`. **Directional references:** 102 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/23`.

## ESPLE:ESPLE-025

**Constrained and risk-informed sampling**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Assurance quantifies over a declared configuration set, not an undefined claim about every possible product.

**Criterion / operative mechanism:** Sample valid configurations using a declared objective and budget, include critical known combinations, and report residual higher-order or environmental coverage limits.

**Trigger:** Full enumeration is infeasible and a bounded sample can provide useful assurance.

**Non-trigger / cheaper path:** Test every supported configuration when the family is small, or analyse a relevant shared property once when a sound family analysis is cheaper.

**Authority:** Test planners and assurance consumers choose the coverage trade-off; a sampler cannot declare all unsampled products correct. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Configuration constraints, test cost, fault-risk assumptions and a meaningful comparison baseline.; the result must expose The selected configurations are valid, the stated coverage is computed correctly and important omissions are visible. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Replace sampling when full analysis becomes cheaper or new evidence invalidates its interaction assumptions.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S019`, `ESPLE:ESPLE-S020`, `ESPLE:ESPLE-S021`, `ESPLE:ESPLE-S037`, `ESPLE:ESPLE-S040`.

**Clusters:** `SSS-K006`, `SSS-K015`, `SSS-K018`, `SSS-K026`, `SSS-K033`. **Tensions:** `SSS-T008`, `SSS-T016`. **Directional references:** 147 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/24`.

## ESPLE:ESPLE-026

**Family-based sharing of analysis**

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Assurance quantifies over a declared configuration set, not an undefined claim about every possible product.

**Criterion / operative mechanism:** Preserve variation symbolically or structurally during analysis so common computations are reused, while retaining conditions under which each result applies.

**Trigger:** Many products share analyzable structure and the analysis implementation supports their variability semantics.

**Non-trigger / cheaper path:** Ordinary product analysis is preferable for a few configurations or unsupported languages and artefacts.

**Authority:** Analysis engineers produce conditional results for developers and reviewers; coverage of configurations is not coverage of every kind of bug. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Correct variability-aware representation, configuration constraints and a sound underlying analysis for the claim in question.; the result must expose Results correspond to the intended per-product analysis across the represented configurations, with conditional warnings and unsupported cases exposed. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Use a simpler product or compositional approach when sharing no longer offsets infrastructure and analysis costs.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S019`, `ESPLE:ESPLE-S022`, `ESPLE:ESPLE-S040`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K015`, `SSS-K017`, `SSS-K018`, `SSS-K032`. **Tensions:** `SSS-T008`. **Directional references:** 94 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/25`.

## ESPLE:ESPLE-027

**Compositional feature contracts**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Assurance quantifies over a declared configuration set, not an undefined claim about every possible product.

**Criterion / operative mechanism:** State the assumptions and guarantees of a feature or component and discharge compatibility and interaction obligations when composing selected parts.

**Trigger:** Stable interfaces and separable properties make local reasoning reusable across products.

**Non-trigger / cheaper path:** Check the whole derived product when contracts would be harder to specify or maintain than the verification itself.

**Authority:** Feature developers and integration/assurance engineers jointly discharge assumptions; no module can certify unexamined partners. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Explicit environmental assumptions, composition semantics and evidence that the actual interfaces meet the contracts.; the result must expose A product-level claim follows from the local results and checked composition premises, not merely from all modules passing tests individually. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Abandon a compositional claim when its interface or independence assumptions fail; use product-level checking instead.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S016`, `ESPLE:ESPLE-S017`, `ESPLE:ESPLE-S019`, `ESPLE:ESPLE-S018`.

**Clusters:** `SSS-K003`, `SSS-K012`, `SSS-K015`, `SSS-K017`, `SSS-K019`, `SSS-K020`, `SSS-K030`. **Tensions:** `SSS-T008`. **Directional references:** 127 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/26`.

## ESPLE:ESPLE-028

**Acceptance of the actual derived product**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Assurance quantifies over a declared configuration set, not an undefined claim about every possible product.

**Criterion / operative mechanism:** Check the actual derived artefacts against the selected product obligations and operating context, reusing family evidence only where its premises apply.

**Trigger:** A product is delivered, deployed or materially changed.

**Non-trigger / cheaper path:** Reuse valid existing evidence and perform only the additional product checks needed for unestablished obligations; repeated full testing is not automatically required.

**Authority:** Product acceptance and operational stakeholders decide readiness; core-asset maintainers supply evidence but do not replace local obligations. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Product identity, selected requirements, environment and applicable family-level results.; the result must expose The accepted product is the one tested or otherwise justified, and unresolved obligations are explicit to the decision-maker. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Reuse an unchanged valid result instead of rerunning ceremony; retire acceptance claims when material assumptions change.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S006`, `ESPLE:ESPLE-S009`, `ESPLE:ESPLE-S021`, `ESPLE:ESPLE-S019`.

**Clusters:** `SSS-K002`, `SSS-K006`, `SSS-K007`, `SSS-K012`, `SSS-K015`, `SSS-K017`, `SSS-K024`. **Tensions:** `SSS-T011`. **Directional references:** 125 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/27`.

## ESPLE:ESPLE-029

**Analysis of build, macro and configuration layers**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Assurance quantifies over a declared configuration set, not an undefined claim about every possible product.

**Criterion / operative mechanism:** Include the configuration layers relevant to the claimed result and track approximation or unsupported constructs in the extraction chain.

**Trigger:** Build, dependency or generator configuration affects product realisation or static-analysis reach.

**Non-trigger / cheaper path:** A single checked configuration layer is enough when the derivation genuinely has no hidden variation elsewhere.

**Authority:** Build and analysis engineers reconcile the representation; a parser warning or missing extractor needs an explicit assurance disposition. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Build rules, macro definitions, selected versions and non-code artefacts that influence inclusion or generated interfaces.; the result must expose Conditional results refer to the actual relevant product space, or clearly state which layers were excluded. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Remove an extractor only when its layer no longer affects the product or another validated mechanism captures it.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S020`, `ESPLE:ESPLE-S022`, `ESPLE:ESPLE-S040`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K004`, `SSS-K015`, `SSS-K025`. **Tensions:** None. **Directional references:** 73 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/28`.

## ESPLE:ESPLE-030

**Semantic classification of feature-model edits**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Evolution preserves or explicitly revises obligations of supported products, not just the newest family model.

**Criterion / operative mechanism:** Compare old and new model semantics using an explicit feature correspondence; classify preserved, added and removed configurations before selecting migration or regression work.

**Trigger:** A feature model, cross-tree constraint or feature vocabulary changes.

**Non-trigger / cheaper path:** Enumerate and compare all configurations for a small family rather than introduce a specialised solver.

**Authority:** Modellers, product maintainers and test planners consume the classification; set preservation does not certify unchanged implementation behaviour. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Both model versions, feature identity mapping and the intended semantic relation.; the result must expose The semantic effect is supported by witnesses, counterexamples or a justified equivalence result under the stated mapping. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Skip a new comparison when no relevant model semantics changed and this is established by an adequate simpler check.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S023`, `ESPLE:ESPLE-S024`, `ESPLE:ESPLE-S039`, `ESPLE:ESPLE-S037`.

**Clusters:** `SSS-K012`, `SSS-K014`, `SSS-K029`. **Tensions:** None. **Directional references:** 63 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/29`.

## ESPLE:ESPLE-031

**Intent-preserving configuration migration**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Evolution preserves or explicitly revises obligations of supported products, not just the newest family model.

**Criterion / operative mechanism:** Map old selections and product intent to a permitted new configuration, accounting for intermediate constraints, change costs and the actual resulting product.

**Trigger:** A supported product must move to a changed model, core baseline or production environment.

**Non-trigger / cheaper path:** Retain a supported older baseline or use a reviewed manual migration when the portfolio is small.

**Authority:** Product maintainers and stakeholders approve changed selections; a migration optimiser proposes solutions within authorised objectives. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Old identity, new constraints, stakeholder intent, supported transition paths and acceptance evidence.; the result must expose The migrated product satisfies the relevant new constraints and preserved obligations, or explicit accepted changes are recorded. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** End migration machinery for retired baselines only after outstanding support obligations are resolved.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S011`, `ESPLE:ESPLE-S024`, `ESPLE:ESPLE-S041`, `ESPLE:ESPLE-S037`.

**Clusters:** `SSS-K012`, `SSS-K013`, `SSS-K023`, `SSS-K029`, `SSS-K030`. **Tensions:** `SSS-T005`, `SSS-T009`. **Directional references:** 106 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/30`.

## ESPLE:ESPLE-032

**Impact and regression analysis of shared changes**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Evolution preserves or explicitly revises obligations of supported products, not just the newest family model.

**Criterion / operative mechanism:** Identify affected products and assumptions, select appropriate regression evidence and coordinate propagation, exceptions or supported parallel versions.

**Trigger:** A shared requirement, component, test, model or production tool changes materially.

**Non-trigger / cheaper path:** Use local regression when the changed asset is demonstrably product-local; reuse established evidence for unaffected products.

**Authority:** Shared-asset and product maintainers communicate impact; a core maintainer cannot erase a product obligation merely by merging a change. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Traceable product baselines, change semantics, dependencies and supported obligations.; the result must expose Affected supported variants have an impact disposition, and propagated fixes are bound to the tested or justified product versions. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Narrow checks when independence is established; do not retire a variant from the impact set solely because it is inconvenient.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S009`, `ESPLE:ESPLE-S011`, `ESPLE:ESPLE-S021`, `ESPLE:ESPLE-S041`, `ESPLE:ESPLE-S028`.

**Clusters:** `SSS-K004`, `SSS-K014`, `SSS-K019`, `SSS-K021`, `SSS-K030`. **Tensions:** `SSS-T013`. **Directional references:** 105 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/31`.

## ESPLE:ESPLE-033

**Supported baseline and release relationships**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Evolution preserves or explicitly revises obligations of supported products, not just the newest family model.

**Criterion / operative mechanism:** State compatible baseline combinations and supported release relationships; allow coordinated or independent product schedules while making upgrade and support obligations explicit.

**Trigger:** Products, core assets or tools evolve on different schedules.

**Non-trigger / cheaper path:** A single synchronised release may be adequate when all products and stakeholders can genuinely move together.

**Authority:** Release and product maintainers agree the supported combinations; the newest core version is not automatically authoritative for all products. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Compatibility evidence, support commitments and product delivery schedules.; the result must expose Each supported product has an identifiable maintenance path and compatible production baseline. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Retire a baseline through an explicit support decision and migration or end-of-life path, not by deleting its name from the current model.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S011`, `ESPLE:ESPLE-S024`, `ESPLE:ESPLE-S041`, `ESPLE:ESPLE-S013`.

**Clusters:** `SSS-K013`, `SSS-K019`, `SSS-K021`, `SSS-K023`, `SSS-K030`. **Tensions:** `SSS-T005`, `SSS-T013`, `SSS-T015`. **Directional references:** 115 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/32`.

## ESPLE:ESPLE-034

**Recovery of variability with domain reconciliation**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Evolution preserves or explicitly revises obligations of supported products, not just the newest family model.

**Criterion / operative mechanism:** Recover candidate features and constraints from multiple artefact types, preserve existing valid domain knowledge and review recovered relations against product intent.

**Trigger:** Consolidating variants, repairing stale models or reducing dependence on tacit configuration knowledge.

**Non-trigger / cheaper path:** Compare a few existing products manually; do not introduce a general extraction framework for a tiny stable portfolio.

**Authority:** Reverse engineers and domain experts jointly assess extracted candidates; extraction alone cannot decide that historical differences are valuable. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Relevant versions, configurations, artefact semantics and expert knowledge of what the code does not express.; the result must expose Recovered constraints have provenance and approximation limits, and domain review distinguishes implementation dependencies from valid-product requirements. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Stop extraction after the needed model is established and maintained directly, unless drift evidence reactivates it.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S010`, `ESPLE:ESPLE-S025`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K004`, `SSS-K008`, `SSS-K029`. **Tensions:** `SSS-T003`. **Directional references:** 65 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/33`.

## ESPLE:ESPLE-035

**Co-evolution of configuration-oriented tests**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Evolution preserves or explicitly revises obligations of supported products, not just the newest family model.

**Criterion / operative mechanism:** Reassess test-configuration validity and purpose after model change; choose repair, fresh generation or targeted new-product tests according to regression and novelty objectives.

**Trigger:** A feature-model change alters permitted products or test-selection assumptions.

**Non-trigger / cheaper path:** Retain still-valid tests and manually add a few relevant configurations when changes are small.

**Authority:** Test engineers and product assurance consumers choose the objective; similarity of configurations is not automatically low behavioural test-maintenance effort. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Old tests, old/new model semantics, test costs and the risk of old versus newly admitted configurations.; the result must expose The suite's selected configurations remain valid and its coverage purpose addresses the relevant change; behavioural oracles are separately checked. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Remove tests for unsupported configurations only after support decisions; retain a cheap fresh-generation path when repairing costs more.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S009`, `ESPLE:ESPLE-S037`, `ESPLE:ESPLE-S021`.

**Clusters:** `SSS-K014`, `SSS-K015`, `SSS-K018`. **Tensions:** None. **Directional references:** 77 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/34`.

## ESPLE:ESPLE-036

**Lifecycle economics with uncertainty**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Family scope and expected product demand are assumptions in the economic case, not benefits created by writing a model.

**Criterion / operative mechanism:** Compare lifecycle costs and required outcomes over an explicit horizon; vary demand, reuse rate and maintenance assumptions rather than rely on a universal break-even count.

**Trigger:** An investment or continuation decision depends on product-line benefits.

**Non-trigger / cheaper path:** Use a coarse scenario comparison when precise estimates are not credible; keep assumptions visible rather than manufacture precision.

**Authority:** Portfolio sponsors and engineering managers review estimates with those bearing the costs; an economic model is not a realised-return measurement. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Alternative costs, expected products, asset investment, ongoing coordination and support commitments.; the result must expose The decision states the horizon, counterfactual, omitted costs and sensitivity that could reverse the preferred option. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Replace estimates with actual evidence as available; stop modelling details too small to change the decision.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S012`, `ESPLE:ESPLE-S010`, `ESPLE:ESPLE-S013`, `ESPLE:ESPLE-S026`, `ESPLE:ESPLE-S027`.

**Clusters:** `SSS-K005`, `SSS-K006`, `SSS-K011`, `SSS-K026`, `SSS-K031`, `SSS-K033`. **Tensions:** `SSS-T004`. **Directional references:** 128 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/35`.

## ESPLE:ESPLE-037

**An explicit adequate non-product-line alternative**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Family scope and expected product demand are assumptions in the economic case, not benefits created by writing a model.

**Criterion / operative mechanism:** Compare SPLE with clone-and-own, selective component reuse, a modular single product or independent development under the same quality and support obligations.

**Trigger:** Choosing or defending shared family production.

**Non-trigger / cheaper path:** Keep the adequate non-product-line method when its total burden is lower or the product-line benefit is not established.

**Authority:** Product sponsors and engineers assess alternatives without treating adoption of a tradition as a success metric. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Actual portfolio size and variation, ownership autonomy, defect risk and comparable outcome requirements.; the result must expose The chosen approach beats or reasonably dominates the relevant alternative for stated reasons; a non-SPLE result is permitted. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Revisit the alternative when repeated shared changes, portfolio growth or new obligations change its adequacy.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S010`, `ESPLE:ESPLE-S012`, `ESPLE:ESPLE-S026`, `ESPLE:ESPLE-S013`, `ESPLE:ESPLE-S027`, `ESPLE:ESPLE-S028`.

**Clusters:** `SSS-K005`, `SSS-K011`, `SSS-K016`, `SSS-K023`, `SSS-K028`, `SSS-K032`. **Tensions:** `SSS-T004`. **Directional references:** 98 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/36`.

## ESPLE:ESPLE-038

**Economic reassessment without a sunk-cost veto**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Family scope and expected product demand are assumptions in the economic case, not benefits created by writing a model.

**Criterion / operative mechanism:** Reassess future costs and obligations at material changes; narrow, split, retire or continue the family based on prospective adequacy, preserving outstanding support.

**Trigger:** Demand changes, reuse disappoints, coordination dominates or the product portfolio contracts.

**Non-trigger / cheaper path:** A brief decision review using actual product experience may replace a recurrent formal business-case ceremony.

**Authority:** Portfolio sponsors with product and asset maintainers decide future investment; sunk costs explain history but cannot by themselves justify continuation. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Current support obligations, observed costs and credible future alternatives.; the result must expose Continued shared production has a current rationale, or a bounded transition away from it preserves necessary commitments. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Stop reviewing an already retired family except for residual support and evidence obligations.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S007`, `ESPLE:ESPLE-S012`, `ESPLE:ESPLE-S013`, `ESPLE:ESPLE-S026`, `ESPLE:ESPLE-S028`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K011`, `SSS-K014`, `SSS-K016`, `SSS-K023`, `SSS-K028`, `SSS-K031`. **Tensions:** None. **Directional references:** 96 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/37`.

## ESPLE:ESPLE-039

**Authority and arbitration for shared assets**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Organisational reach and participant autonomy bound the family; an ecosystem may not be one controlled product line.

**Criterion / operative mechanism:** Make contribution, variation and release decision rights explicit; provide a proportionate way to adjudicate competing product obligations and fund accepted shared work.

**Trigger:** Shared changes affect products with different priorities or authorities.

**Non-trigger / cheaper path:** A named maintainer and direct product-owner agreement can suffice; a new committee is not a property.

**Authority:** Product and core decision-makers exchange impact and priority information; evidence of a technical opportunity is separate from authority to act. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Ownership, affected obligations, cost bearers and an escalation path for unresolved conflict.; the result must expose A disputed shared change can receive an accountable decision, and affected products learn its consequences. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Simplify authority arrangements when the portfolio or conflict surface shrinks; preserve accountability for supported products.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S008`, `ESPLE:ESPLE-S011`, `ESPLE:ESPLE-S013`, `ESPLE:ESPLE-S041`, `ESPLE:ESPLE-S026`, `ESPLE:ESPLE-S044`.

**Clusters:** `SSS-K009`, `SSS-K010`, `SSS-K021`, `SSS-K022`. **Tensions:** `SSS-T002`, `SSS-T012`. **Directional references:** 72 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/38`.

## ESPLE:ESPLE-040

**Capability, incentives and resource alignment**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Organisational reach and participant autonomy bound the family; an ecosystem may not be one controlled product line.

**Criterion / operative mechanism:** Align skills, capacity, incentives and cost allocation with the intended shared-production responsibilities; scale commitments to actual capability.

**Trigger:** A product-line plan requires work or coordination beyond the existing organisation's supported practice.

**Non-trigger / cheaper path:** Start with a limited shared capability and existing staff rather than create a full platform organisation before demand is known.

**Authority:** Engineering managers, product teams and sponsors negotiate resourcing; training completion alone does not establish operational capability. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Skill gaps, delivery commitments, maintenance capacity and how shared costs and benefits are distributed.; the result must expose Accepted shared work has capacity and ownership, and product teams can obtain needed support without hidden unpaid obligations. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Remove specialised arrangements whose shared workload disappears, while retaining needed domain knowledge.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S008`, `ESPLE:ESPLE-S012`, `ESPLE:ESPLE-S013`, `ESPLE:ESPLE-S026`, `ESPLE:ESPLE-S028`, `ESPLE:ESPLE-S027`.

**Clusters:** `SSS-K010`, `SSS-K021`, `SSS-K026`. **Tensions:** `SSS-T016`. **Directional references:** 60 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/39`.

## ESPLE:ESPLE-041

**An explicit ecosystem participation boundary**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Organisational reach and participant autonomy bound the family; an ecosystem may not be one controlled product line.

**Criterion / operative mechanism:** Identify who controls assets, proposals, interfaces and releases; distinguish contractual or negotiated compatibility from internal derivation authority; export bounded interfaces rather than fictitious central control.

**Trigger:** Suppliers, open-source participants or independent platform users determine material variation.

**Non-trigger / cheaper path:** Manage a bounded component dependency when no broader ecosystem coordination is required.

**Authority:** Platform maintainers and external participants negotiate evidence and compatibility; one organisation cannot unilaterally authorise changes to autonomous derivatives. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Participant autonomy, shared interface/specification obligations and actual contribution or compatibility mechanisms.; the result must expose Shared claims identify their organisational reach; independent products are not silently counted as conforming family instances. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Omit ecosystem machinery when the relevant relationship is only ordinary dependency consumption.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S029`, `ESPLE:ESPLE-S044`.

**Clusters:** `SSS-K009`, `SSS-K010`, `SSS-K021`, `SSS-K022`. **Tensions:** `SSS-T002`. **Directional references:** 63 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/40`.

## ESPLE:ESPLE-042

**Traceability of externally specified obligations**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Organisational reach and participant autonomy bound the family; an ecosystem may not be one controlled product line.

**Criterion / operative mechanism:** Associate externally supplied obligations with affected assets and products, then require appropriate evidence or specialist adjudication before deriving or changing those products.

**Trigger:** Supplier conditions, security requirements, licences, regulation or support commitments constrain valid product use.

**Non-trigger / cheaper path:** Preserve the relevant external requirement and its affected products; do not invent a new compliance framework or a legal conclusion.

**Authority:** Product owners, relevant specialists and asset maintainers exchange obligations and impact evidence; SPLE analysis does not grant legal permission or certify security. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Authoritative external requirements, applicable versions and an identified competent decision-maker.; the result must expose A shared change cannot silently erase product-specific obligations; unresolved applicability is visible to the authorised consumer. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Remove a constraint only when its external basis or affected supported products genuinely cease to apply.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S009`, `ESPLE:ESPLE-S011`, `ESPLE:ESPLE-S033`, `ESPLE:ESPLE-S041`, `ESPLE:ESPLE-S005`.

**Clusters:** `SSS-K001`, `SSS-K009`, `SSS-K021`, `SSS-K022`. **Tensions:** `SSS-T006`. **Directional references:** 63 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/41`.

## ESPLE:ESPLE-043

**Context-to-configuration mapping for dynamic families**

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Dynamic and AI-assisted variants remain bounded by a declared family; broader ecosystem derivatives may require a different organisational model.

**Criterion / operative mechanism:** Model permitted runtime configurations, relevant context and the mapping from observations to proposed reconfiguration; connect the decision to actual actuators and feedback.

**Trigger:** A product must change its selected capabilities during execution as conditions change.

**Non-trigger / cheaper path:** Select a static or deployment-time variant when runtime rebinding is not required.

**Authority:** Operators and adaptation designers define the allowed policy; a runtime controller acts only within the authority and capabilities supplied to it. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Observable context, supported configurations, adaptation goals and a feasible reconfiguration mechanism.; the result must expose A context change leads to a permitted, realised configuration or a diagnosed inability to reconfigure; actual state is observed afterwards. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Eliminate dynamic control when operating conditions no longer require runtime product variation.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S030`, `ESPLE:ESPLE-S031`, `ESPLE:ESPLE-S043`.

**Clusters:** `SSS-K014`, `SSS-K020`, `SSS-K025`, `SSS-K027`. **Tensions:** `SSS-T010`. **Directional references:** 88 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/42`.

## ESPLE:ESPLE-044

**Transition safety and state continuity**

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Dynamic and AI-assisted variants remain bounded by a declared family; broader ecosystem derivatives may require a different organisational model.

**Criterion / operative mechanism:** Check the transition path, quiescence or state transfer and actual controllability; preserve safety requirements throughout the operating phase or enter a separately justified safe reconfiguration phase.

**Trigger:** Features or components are rebound while the system is operating.

**Non-trigger / cheaper path:** Stop and restart in a known safe condition, or prohibit runtime switching, when live transition assurance is disproportionate.

**Authority:** Adaptation and safety/operations decision-makers approve the transition envelope; endpoint SAT checks are insufficient. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Current state, intermediate-state constraints, controllable actions, timing assumptions and recovery behaviour.; the result must expose The realised transition respects the declared operational invariants and state-continuity obligations, not only its final feature selection. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Remove live-transition machinery if the product is constrained to safe offline reconfiguration.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S030`, `ESPLE:ESPLE-S031`.

**Clusters:** `SSS-K013`, `SSS-K019`, `SSS-K020`. **Tensions:** `SSS-T010`. **Directional references:** 64 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/43`.

## ESPLE:ESPLE-045

**Supervisory control under plant assumptions**

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Dynamic and AI-assisted variants remain bounded by a declared family; broader ecosystem derivatives may require a different organisational model.

**Criterion / operative mechanism:** Synthesize a supervisor for the modelled plant and requirements, then establish that observations, event controllability and actuation match the implementation.

**Trigger:** A finite-state or otherwise supported discrete-event model adequately captures a consequential dynamic product-line problem.

**Non-trigger / cheaper path:** A reviewed transition table or offline configuration can suffice where synthesis adds no justified assurance.

**Authority:** Control and product engineers assess model adequacy and deploy within operational authority; a theorem does not grant new actuator powers. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Plant model, marked states, requirements, event partition and a faithful implementation mapping.; the result must expose Within the model, the supervisor is safe, controllable and nonblocking as specified; implementation checks support transfer of the relevant result. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Withdraw the guarantee when plant or controllability assumptions fail; retain a safe operational fallback if available.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S031`.

**Clusters:** `SSS-K020`. **Tensions:** `SSS-T008`, `SSS-T010`, `SSS-T014`. **Directional references:** 42 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/44`.

## ESPLE:ESPLE-046

**Semantic fidelity in variability interchange**

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Dynamic and AI-assisted variants remain bounded by a declared family; broader ecosystem derivatives may require a different organisational model.

**Criterion / operative mechanism:** Specify the supported language level and check semantic preservation for translations and toolchains; make unsupported constructs explicit.

**Trigger:** Variability models move across tools, organisations or analysis backends.

**Non-trigger / cheaper path:** Keep one stable representation and tool when interchange has no real consumer.

**Authority:** Tool integrators and model consumers agree the interchange contract; a shared extension does not automatically become a normative standard. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Source and destination semantics, supported versions and a meaningful equivalence or conformance test.; the result must expose Relevant configurations and constraints survive interchange, or the loss is detected before relying on the result. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Remove conversions whose consumer disappears; preserve native evidence rather than flatten richer semantics silently.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S032`, `ESPLE:ESPLE-S033`.

**Clusters:** `SSS-K003`, `SSS-K007`, `SSS-K029`. **Tensions:** None. **Directional references:** 53 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/45`.

## ESPLE:ESPLE-047

**AI-assisted migration as a validated proposal**

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Dynamic and AI-assisted variants remain bounded by a declared family; broader ecosystem derivatives may require a different organisational model.

**Criterion / operative mechanism:** Treat generated changes as proposals; validate syntax, constraints, semantic intent, realisation and product obligations using appropriate independent checks before acceptance.

**Trigger:** Learned tools assist feature modelling, configuration advice, migration or variant generation.

**Non-trigger / cheaper path:** Use deterministic constraint solving, a conventional transformation or manual review when these are cheaper and adequate.

**Authority:** Modellers, maintainers and product acceptance decision-makers review the candidate; model fluency confers no mutation or release permission. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Versioned input/output, preserved intent, an acceptance oracle and authority independent of the proposal generator.; the result must expose Accepted outputs pass the checks needed for the actual claim, and rejected or uncertain suggestions are not silently enacted. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Stop using the learned assistant when validated throughput or cost is worse than the deterministic/manual alternative.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S034`, `ESPLE:ESPLE-S038`, `ESPLE:ESPLE-S036`.

**Clusters:** `SSS-K009`, `SSS-K015`, `SSS-K024`. **Tensions:** `SSS-T011`. **Directional references:** 91 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/46`.

## ESPLE:ESPLE-048

**LLM regeneration as a superior replacement for maintained variability**

**Disposition:** `UNRESOLVED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Dynamic and AI-assisted variants remain bounded by a declared family; broader ecosystem derivatives may require a different organisational model.

**Criterion / operative mechanism:** The candidate is a replacement strategy: retain specifications and regenerate variants. Its stronger claim of superior lifecycle adequacy is not established by the inspected evidence.

**Trigger:** Considering regeneration as a substitute for a maintained family realisation, not merely as assistance.

**Non-trigger / cheaper path:** Keep maintained assets and use an assistant only for bounded changes; conventional generation remains an alternative.

**Authority:** Product and assurance owners would have to accept the replacement; the study does not authorise such adoption. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Stable specifications, independently checked outputs, versioned models/tooling and longitudinal cost/defect evidence.; the result must expose A discriminating evaluation would preserve obligations across repeated variants and changes while comparing full costs and defects against a competent maintained-family baseline. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Reject a trial replacement when output continuity or lifecycle cost cannot be established; retain useful bounded assistance separately.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S034`, `ESPLE:ESPLE-S038`.

**Clusters:** `SSS-K024`, `SSS-K033`. **Tensions:** None. **Directional references:** 66 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/47`.

## ESPLE:ESPLE-049

**A universal break-even product count**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Family scope and expected product demand are assumptions in the economic case, not benefits created by writing a model.

**Criterion / operative mechanism:** No general mechanism supports the universal threshold. Replace the claim with a horizon-specific comparison of investment, derivation, coordination and support costs.

**Trigger:** A proposed adoption is justified by reaching a supposedly universal number of products.

**Non-trigger / cheaper path:** A small scenario calculation showing the relevant cost drivers is adequate to reject the fixed threshold.

**Authority:** Investment decision-makers should demand a local comparison, not treat a published example as a rule. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Actual cost structure, demand uncertainty and a credible non-product-line baseline.; the result must expose The threshold claim is withdrawn or bounded to the assumptions from which it was derived. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Do not retain the universal rule; retain any locally useful conditional estimate under ESPLE-036.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S012`, `ESPLE:ESPLE-S010`, `ESPLE:ESPLE-S026`, `ESPLE:ESPLE-S027`.

**Clusters:** `SSS-K011`, `SSS-K027`, `SSS-K033`. **Tensions:** None. **Directional references:** 82 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/48`.

## ESPLE:ESPLE-050

**A complete upfront platform as a prerequisite**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Domain and application work are justified by a family whose reusable capabilities serve actual or credible products.

**Criterion / operative mechanism:** Reject the universal prerequisite; use the proactive, reactive, extractive or hybrid route justified by the actual starting conditions.

**Trigger:** A process requires complete domain assets before permitting useful product work.

**Non-trigger / cheaper path:** Start with a bounded common asset and one product, then expand only when evidence warrants it.

**Authority:** Portfolio and engineering leads choose a transition route; no method diagram establishes that all assets must precede all products. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Current assets, product urgency and uncertainty about future variation.; the result must expose Upfront work is limited to what the chosen route and product obligations actually require. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Remove the compulsory rule; retain bounded proactive investment where it earns its cost.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S010`, `ESPLE:ESPLE-S007`, `ESPLE:ESPLE-S013`, `ESPLE:ESPLE-S026`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K005`, `SSS-K016`, `SSS-K028`. **Tensions:** None. **Directional references:** 36 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/49`.

## ESPLE:ESPLE-051

**A feature-tree artefact as sufficient variability management**

**Disposition:** `CEREMONY_NOT_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** The model represents a declared product family, not every conceivable configuration in the technology domain.

**Criterion / operative mechanism:** Reject artefact sufficiency; require meaningful features, usable constraints, a relation to realisation and an actual configuration or change consumer.

**Trigger:** A diagram, modelling tool or documentation checklist is offered as the evidence of control.

**Non-trigger / cheaper path:** A checked decision table or direct configuration rules may supply the required function without a tree.

**Authority:** Modellers and configurators should demonstrate use; reviewers must not infer fulfilment from a file's existence. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: The decision the artefact supports and evidence that it remains aligned with products.; the result must expose The artefact changes or supports a valid decision, or is identified as nonessential documentation. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Retire an unused tree if its information is adequately preserved elsewhere; retain consumed models.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S005`, `ESPLE:ESPLE-S015`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K007`, `SSS-K008`, `SSS-K027`, `SSS-K032`. **Tensions:** `SSS-T007`. **Directional references:** 68 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/50`.

## ESPLE:ESPLE-052

**Feature-model satisfiability as delivered-product correctness**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Assurance quantifies over a declared configuration set, not an undefined claim about every possible product.

**Criterion / operative mechanism:** Reject the implication. Keep model consistency, realisation correctness and product behaviour as separate claims with explicit connecting premises.

**Trigger:** A SAT result is used to assert product correctness or release readiness.

**Non-trigger / cheaper path:** Show a concrete missing domain constraint or faulty realisation to expose the gap; retain the SAT check for its genuine purpose.

**Authority:** Assurance and release consumers require the missing evidence; the solver supplies only the stated logical result. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: The actual encoded formula, generator/implementation relation and product obligations.; the result must expose The final claim no longer exceeds the model and encoding that were checked. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Remove the universal implication permanently; retain ESPLE-009, ESPLE-010, ESPLE-017 and ESPLE-028 as distinct concerns.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S014`, `ESPLE:ESPLE-S015`, `ESPLE:ESPLE-S021`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K007`. **Tensions:** None. **Directional references:** 19 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/51`.

## ESPLE:ESPLE-053

**Pairwise coverage as family correctness**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Assurance quantifies over a declared configuration set, not an undefined claim about every possible product.

**Criterion / operative mechanism:** Reject the guarantee; use pairwise testing only as a bounded selection strategy within an explicit assurance argument.

**Trigger:** A pairwise coverage percentage is presented as complete family assurance.

**Non-trigger / cheaper path:** A four-row three-feature counterexample demonstrates the logical gap without a large experiment.

**Authority:** Test and acceptance decision-makers distinguish coverage from correctness; the sampling tool cannot make that stronger claim. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: The actual tested configurations, coverage definition and the fault hypotheses relevant to the product.; the result must expose Higher-order and non-configuration omissions are acknowledged, and critical known interactions receive suitable checks. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Retire the universal claim; change the sampling strategy only when risk or cost evidence justifies it.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S020`, `ESPLE:ESPLE-S021`, `ESPLE:ESPLE-S040`.

**Clusters:** `SSS-K018`, `SSS-K033`. **Tensions:** None. **Directional references:** 49 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/52`.

## ESPLE:ESPLE-054

**Later binding as universally better**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Realisation choices serve the selected family scope rather than requiring all products to share one implementation technique.

**Criterion / operative mechanism:** Reject a universal ranking and select binding time by the timing of needed knowledge and the costs of retained flexibility.

**Trigger:** A compile/deployment-time choice is moved later without a concrete operational need.

**Non-trigger / cheaper path:** Fix the choice earlier and rebuild or redeploy when rare changes occur.

**Authority:** Architects and operators assess the actual need for late choice; flexibility is not an end in itself. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Change frequency, latency requirements, footprint and transition obligations.; the result must expose Each late-bound choice has a justified consumer and an assurance path for its extra reachable states. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Remove the universal preference, not the late-binding branch itself.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S030`, `ESPLE:ESPLE-S042`, `ESPLE:ESPLE-S043`, `ESPLE:ESPLE-S017`, `ESPLE:ESPLE-S031`, `ESPLE:ESPLE-S045`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K020`, `SSS-K023`, `SSS-K026`, `SSS-K028`. **Tensions:** None. **Directional references:** 54 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/53`.

## ESPLE:ESPLE-055

**A universal one-feature/one-module correspondence**

**Disposition:** `NO_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Realisation choices serve the selected family scope rather than requiring all products to share one implementation technique.

**Criterion / operative mechanism:** Reject the universal correspondence; model the relations needed for derivation and impact, allowing many-to-many mappings and interaction artefacts.

**Trigger:** Traceability or architecture forces a one-to-one feature/module decomposition.

**Non-trigger / cheaper path:** Keep a simple mapping where it genuinely exists; do not introduce complexity solely to avoid one-to-one cases.

**Authority:** Feature modellers and implementers reconcile their abstractions; neither representation automatically dictates the other. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Feature semantics and actual realisation structure rather than a desired visual symmetry.; the result must expose Shared and crosscutting realisations remain visible and their consequences can be checked. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Remove false correspondence constraints; preserve useful local modularity under ESPLE-014 and ESPLE-015.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S017`, `ESPLE:ESPLE-S018`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K027`. **Tensions:** None. **Directional references:** 26 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/54`.

## ESPLE:ESPLE-056

**Total automation as the definition of SPLE**

**Disposition:** `NO_GENERAL_PROPERTY`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Core assets and production plans are bounded by the supported family and its product obligations.

**Criterion / operative mechanism:** Reject total automation as a universal definition; require a defined, adequate derivation method and evidence for the resulting products.

**Trigger:** Automation percentage is used as the criterion for product-line existence or maturity.

**Non-trigger / cheaper path:** A reliable reviewed manual derivation can be sufficient for a small stable family.

**Authority:** Product builders and managers judge production adequacy; narrower standard or method definitions must be named rather than universalised. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Product volume, error consequences, required repeatability and a real production plan.; the result must expose The family can reliably derive supported products, with consequential manual decisions explicit and checked. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Retire the blanket definition and automate only where volume, risk or coordination makes it preferable.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S008`, `ESPLE:ESPLE-S011`, `ESPLE:ESPLE-S033`, `ESPLE:ESPLE-S013`, `ESPLE:ESPLE-S041`, `ESPLE:ESPLE-S006`.

**Clusters:** `SSS-K024`, `SSS-K027`, `SSS-K032`. **Tensions:** None. **Directional references:** 63 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/55`.

## ESPLE:ESPLE-057

**Clone-and-own as universally inadmissible**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Family scope and expected product demand are assumptions in the economic case, not benefits created by writing a model.

**Criterion / operative mechanism:** Reject universal inadmissibility; compare cloning's immediate adequacy and future synchronisation costs with the actual product-line alternative.

**Trigger:** Cloning is rejected without examining portfolio conditions or maintenance obligations.

**Non-trigger / cheaper path:** Retain clones with sufficient provenance and targeted shared-fix tracking when they are the lower-cost adequate solution.

**Authority:** Product and portfolio owners choose a strategy; no favourable case study establishes a universal winner. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Product divergence, expected common changes, ownership constraints and a realistic lifecycle horizon.; the result must expose Cloning is accepted, bounded or replaced for explicit reasons, with its support risks visible. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Reconsider cloning when common changes accumulate or needed assurance can no longer be sustained cheaply.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S026`, `ESPLE:ESPLE-S027`, `ESPLE:ESPLE-S028`.

**Clusters:** `SSS-K005`, `SSS-K011`, `SSS-K016`, `SSS-K028`, `SSS-K031`. **Tensions:** `SSS-T004`. **Directional references:** 47 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/56`.

## ESPLE:ESPLE-058

**Stable names or configuration sets as behavioural compatibility**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Evolution preserves or explicitly revises obligations of supported products, not just the newest family model.

**Criterion / operative mechanism:** Reject the equivalence; preserve or explicitly change feature intent and verify the actual migrated product's obligations.

**Trigger:** Compatibility is asserted solely because names or model-level product sets did not change.

**Non-trigger / cheaper path:** A targeted behavioural regression can be sufficient where a full migration analysis adds nothing.

**Authority:** Model and product maintainers communicate semantic change; model equivalence does not authorise silent behavioural changes. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Old/new feature meanings, realisation versions and relevant behavioural expectations.; the result must expose Compatibility claims name what is preserved and are supported at that level. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Remove the unsupported equivalence; retain model-change classification under ESPLE-030.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S023`, `ESPLE:ESPLE-S024`, `ESPLE:ESPLE-S037`, `ESPLE:ESPLE-S041`.

**Clusters:** `SSS-K012`, `SSS-K029`. **Tensions:** `SSS-T009`. **Directional references:** 30 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/57`.

## ESPLE:ESPLE-059

**Raw configuration count as a benefit measure**

**Disposition:** `USEFUL_BUT_EASILY_GAMED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Family scope and expected product demand are assumptions in the economic case, not benefits created by writing a model.

**Criterion / operative mechanism:** Use counts to estimate analysis, support or selection complexity; assess value through useful products and avoided costs rather than raw combinatorics.

**Trigger:** Configuration-space size is used in an investment or maturity claim.

**Non-trigger / cheaper path:** Count supported or demanded products and their costs when theoretical possibilities do not affect the decision.

**Authority:** Portfolio and assurance planners interpret the count; a metric collector cannot infer market value from arithmetic. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Validity constraints, demand evidence and the purpose of the metric.; the result must expose A reported count is tied to a concrete planning use and is not equated with realised benefit. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Stop reporting the count when it has no decision consumer; retain it when needed to plan coverage or support.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S012`, `ESPLE:ESPLE-S015`, `ESPLE:ESPLE-S045`, `ESPLE:ESPLE-S021`.

**Clusters:** `SSS-K011`, `SSS-K016`, `SSS-K026`, `SSS-K031`, `SSS-K033`. **Tensions:** None. **Directional references:** 99 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/58`.

## ESPLE:ESPLE-060

**Formal modelling as operational authority**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **Composition-induced:** No.

**Bearer:** Dynamic and AI-assisted variants remain bounded by a declared family; broader ecosystem derivatives may require a different organisational model.

**Criterion / operative mechanism:** Reject self-authorising control; separately establish observation, actual actuation capability, external permission and the expected consequence.

**Trigger:** A formal or generated controller is proposed for real runtime configuration.

**Non-trigger / cheaper path:** Keep the result advisory or use an existing authorised operational process when actuation is not established.

**Authority:** Operators and accountable product authorities decide deployment; the proof author cannot create authority through notation. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Model/plant mapping, permissions, controllability and operational feedback.; the result must expose Each real action is feasible and authorised, and the observed consequence is checked separately from the command being issued. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Remove the unsupported inference; retain valid model analysis as evidence or advice.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S031`, `ESPLE:ESPLE-S044`.

**Clusters:** `SSS-K009`, `SSS-K020`. **Tensions:** None. **Directional references:** 31 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/59`.

## ESPLE:ESPLE-061

**Support-aware retirement of variability**

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Evolution preserves or explicitly revises obligations of supported products, not just the newest family model.

**Criterion / operative mechanism:** Distinguish admission to new products from continued support of existing ones; retire or bind variability when its consumer disappears, preserving required historical baselines and migration paths.

**Trigger:** A feature is unused for new demand, fixed to one value or becomes disproportionately costly to support.

**Non-trigger / cheaper path:** Mark the feature unavailable to new configurations while retaining the older baseline, rather than immediately rewriting all code.

**Authority:** Product support and core maintainers agree retirement; apparent non-use in a sample is not permission to abandon a supported customer. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: Actual usage, supported products, external commitments and the effect of removal on derivation and tests.; the result must expose New products no longer inherit unnecessary variation, and supported older products retain an adequate maintenance or migration path. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** End the retirement control itself when no supported product or retained obligation depends on the old variation.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S007`, `ESPLE:ESPLE-S011`, `ESPLE:ESPLE-S041`, `ESPLE:ESPLE-S045`.

**Clusters:** `SSS-K011`, `SSS-K013`, `SSS-K023`, `SSS-K028`. **Tensions:** `SSS-T012`, `SSS-T015`. **Directional references:** 86 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/60`.

## ESPLE:ESPLE-062

**Null configurability as context-independent behaviour**

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **Composition-induced:** No.

**Bearer:** Dynamic and AI-assisted variants remain bounded by a declared family; broader ecosystem derivatives may require a different organisational model.

**Criterion / operative mechanism:** Reject that stronger implication. Retain the narrower distinction that selected features are fixed after a declared binding time; analyse inputs, state, timing and environment separately.

**Trigger:** Fixed feature selection is used to infer environment-independent behaviour or a general correctness guarantee.

**Non-trigger / cheaper path:** A fixed-function program that reads a changing external value supplies a logical counterexample to the stronger inference.

**Authority:** Modellers and assurance readers interpret the claim at its proper level; terminology cannot supply an unproved behavioural theorem. A diagnosis, model result or recommendation is not by itself authorisation, capacity to execute, or evidence that the consequence occurred.

**Communication/interaction:** The consequential exchange is the following input and result, between the consumer roles already identified: A clear separation of configuration, ordinary input, internal state and operating environment.; the result must expose The claim is bounded to lack of configurability, without denying ordinary input/output dependence or external failure modes. No separate meeting, team or owner is required merely by this record.

**Omission/retirement and retained reopening distinctions:** Do not retain the broad guarantee; use ESPLE-013 and ESPLE-061 for justified early binding and reduction.

**Evidence, assumptions, costs, failures and criticism:** retained without modification in this row of `EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json`; expand `evidence_ceiling`, `assumptions`, `costs_failure_modes`, `failure_modes`, `criticisms` and `later_questions`. This index is not a replacement for those fields.

**Sources:** `ESPLE:ESPLE-S045`.

**Clusters:** `SSS-K020`, `SSS-K025`, `SSS-K027`. **Tensions:** None. **Directional references:** 51 exact IDs in the JSON row.

**Frozen original:** `frozen_inputs/ESPLE.zip!/EVOLVED_SOFTWARE_PRODUCT_LINE_ENGINEERING_PROPERTY_LEDGER.json#/properties/61`.

