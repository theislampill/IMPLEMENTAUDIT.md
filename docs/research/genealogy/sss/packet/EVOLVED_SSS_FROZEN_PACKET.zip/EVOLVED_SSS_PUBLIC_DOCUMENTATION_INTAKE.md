# Evolved-SSS — Public-documentation intake

**Revision:** SSS-2026-09-06-r1. **Inherited research cut-off:** 6 September 2026.

## What the name describes

Software architecture, software maintenance and evolution, and software product line engineering are established research fields. The supplied ESA, canonical ESME and ESPLE packets are independent, criticism-tested analytical studies of those fields. Evolved-SSS is an analytical composition of those three frozen studies. It is not a claim that “Evolved-SSS” is an established historical school or a previously validated universal methodology.

The composition preserves 235 individually identifiable properties: 68 architectural, 105 maintenance/evolution, and 62 product-line properties. “Property” here is part of a scholarly register: a row can be conditional, domain-specific, rejected, ceremonial, superseded, contested or unresolved. The count does not mean that every project should implement 235 controls.

## What composition adds

The synthesis identifies the relationships that separate studies can leave implicit. A property about a model is not automatically a property of the delivered product. An architectural quality result may apply only to one workload, configuration and baseline. A permitted feature selection does not prove the generator produced an acceptable product. Successful endpoint migrations do not guarantee that old and new versions can safely coexist. Technical ability and evidence do not create authority to change another product’s obligations.

These relationships are explicit, directional where necessary and conditional on actual objects and concerns. Shared-source records are also reconciled so the same underlying work is not counted repeatedly as independent corroboration. Many-to-one convergences preserve their separate members; one-to-many realisations explain why a claim may need several distinct inputs without requiring separate bureaucracy for each.

The composition contains 34 convergence/composition clusters, 16 cross-lineage tensions and 11 alternative configurations. The complete 17,866-pair matrix distinguishes 3,539 material-bucket pairs, 14,320 pairs for which no additional direct material relation is established under the declared comparison, and seven specific unresolved stronger questions. There are 6,825 material directed records plus seven unresolved directed records; these are not the same unit as unordered pairs.

## What the emergence investigation found

The synthesis actively tested all ten requested composition questions and four additional candidates. No distinct new SSS property survived. That is not a finding that composition is useless or that higher-order failures cannot occur.

Several anticipated “new” requirements were already present in the mature canonical maintenance/evolution study: evidence/action identity, assumption-indexed invalidation, obligations across reachable joint states, and proportionality/retirement of combined controls. Architecture and product-line engineering give those requirements important additional mappings, state dimensions and affected populations. Adding a relevant argument to an existing rule is not automatically another property.

An executed three-way example shows why pairwise checks can miss a joint inconsistency. Nevertheless, the inherited composition-premise and actual-product acceptance requirements already forbid accepting such a joint claim on pairwise evidence alone. A higher-order failure witness is not, by itself, a new normative requirement. Stronger claims of global runtime progress or reliable autonomous lifecycle stewardship lacked the necessary common assumptions or representative evidence and were not promoted into validated capabilities.

All fourteen rejected emergence candidates remain documented, including their parents, proposed criterion, counterexample, distinctness judgment and useful surviving relation. The later property-by-property intake therefore contains 235 + 0 = 235 rows.

## Not a prescribed pipeline

The composition is a network of decisions, artefacts, views, baselines, configurations, products, obligations, evidence, authority, observations, transitions, repair and retirement. Work can proceed concurrently, feedback can reopen assumptions, and a detected mismatch can interrupt only the unsupported claim or action rather than all useful work.

No universal sequence “architecture, then maintenance, then product line, then done” is prescribed. A genuinely necessary local ordering is stated for that relation, not expanded into a mandatory lifecycle. No universal roles, boards, architecture documents, feature models, migration machinery or autonomous agents are introduced.

## Simpler arrangements are legitimate

A small stable single product can remain small and unchanged. A modular product can be maintained without a product-line programme. Selective reuse or traceable clones can be preferable to a shared platform. A managed family may justify stronger configuration/asset coordination; a runtime-variable family may additionally need transition assurance. A high-assurance subset can require stronger evidence without imposing the same formality on every product.

Migration, decentralisation, restricted servicing, support-aware retirement and historical preservation are legitimate alternatives or outcomes. A control can be omitted when its trigger is absent or a cheaper adequate method meets the actual obligation. Ending new feature admission is not necessarily ending support for older products. Forward repair can sometimes be the right recovery mechanism even when code reversal is impossible.

## Evidence and limitations

The 217 source rows are lineage-local bibliographic and claim/access records, not 217 independent empirical studies. Six cross-lineage shared-work groups are preserved with distinct access/version uses. Historical accounts, standards, industrial cases, formal results and analytical deductions keep their original ceilings. Stronger evidence in one lineage does not silently upgrade a superficially similar claim in another.

Twelve executable finite examples check particular logical failure possibilities. They do not measure real-world SSS effectiveness. A separate read-only checker verifies conservation, complete pair accounting, references, direction, counts and package integrity; the semantic synthesis and adversarial readback were performed by the same executor, not an independent scholarly assessor. The semantic matrix remains a finite, explicit interpretation that can be challenged by a specific counterexample.

Open questions include the net benefit and cost of the combined arrangement, economical scope/observer adequacy, hidden consumers and irreversible effects, legitimate conflicts among stakeholders, cross-tool evidence maintenance, real dynamic-plant correspondence and long-term automation effectiveness. No universal optimum or guaranteed autonomous lifecycle has been established.

## Relationship to later work

This packet does not compare SSS with outside trifectas, assign existing implementation owners, derive Rockstars/RXXs, or recommend adoption by IMPLEMENTAUDIT or another target. Those are later, separately authorised property-by-property comparisons. A later process must preserve the 235-row denominator even when one implementation mechanism can address multiple concerns.

Suitable public wording is: “Evolved-SSS is a traceable analytical composition of three frozen software-engineering studies, preserving their separate properties and evidence limits while making cross-lineage relations, tensions and alternatives explicit.” Avoid “best of all three”, “universally superior methodology”, “autonomous lifecycle guaranteed”, or language implying that every project must enter an SSS mode.

Primary packet references: `EVOLVED_SSS_FROZEN_REPORT.md`; constituent register; relation, tension, candidate and configuration ledgers; shared-source identity ledger; and the completeness/reverse-consistency review.
