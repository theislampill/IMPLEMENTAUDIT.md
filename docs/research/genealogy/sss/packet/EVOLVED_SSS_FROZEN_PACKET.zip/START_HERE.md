# Start here — Evolved-SSS frozen packet

Revision: **SSS-2026-09-06-r1**. Research cut-off inherited from inputs: **2026-09-06**.

Begin with `EVOLVED_SSS_FROZEN_REPORT.md`. The central result is 235 preserved inherited properties, a complete 17,866-pair crosswalk and **zero new SSS-induced properties after fourteen explicit candidate tests**. This is a relational synthesis, not an implementation mandate, a historical school or a concatenation.

`EVOLVED_SSS_INTER_CROSSWALK_INTAKE.json` exports every inherited row, including negative and open findings. Its Markdown companion is a complete reading index. The original ZIPs under `frozen_inputs/` are the unmodified research authorities; ESME predecessors remain ancestry only.

The matrix and directional ledger are large because all pairs and exact endpoint comparisons are explicit. IDs and namespaces remain distinct. The 3,539 material-bucket pairs are not the 6,825 material directional records; seven further directed records concern open questions. Five of the seven open pair cells also retain known boundary relations.

Verification after extraction uses only Python's standard library:

```bash
python analysis/verify_sss.py . --stage full
python analysis/finite_counterexamples.py
```

Do not write verifier results inside this directory before testing its exact manifest inventory; direct `--out` to a path outside the extracted packet. No network calls or repository writes are made.

The internal receipt covers verified pre-archive analysis and the procedural review boundary. The separately delivered `EVOLVED_SSS_ARCHIVE_VERIFICATION.json` contains the final ZIP SHA-256, byte count, close/reopen/member checks and fresh extraction verification. An archive cannot contain its own final cryptographic hash without a circularity problem; the manifest also excludes its own hash.

No other-trifecta corpus, IMPLEMENTAUDIT crosswalk, target adoption or Rockstar/RXX derivation was performed. The packet is a research intake for later individual-property inter-crosswalking, not a declaration that all its mechanisms should be adopted.
