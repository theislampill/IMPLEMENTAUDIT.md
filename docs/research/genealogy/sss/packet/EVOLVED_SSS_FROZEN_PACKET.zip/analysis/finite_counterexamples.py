#!/usr/bin/env python3
"""Finite analytical witnesses, not empirical tests of any real software system."""
from __future__ import annotations
import itertools, json, pathlib, argparse

def run_tests():
    results=[]
    def check(i,name,claim,parents,observations,condition,limit):
        assert condition, (i, observations)
        results.append(dict(test_id=f'SSS-AT{i:03d}',name=name,claim_tested=claim,
            parent_property_ids=parents,observations=observations,result='PASS',
            evidence_class='EXECUTED_FINITE_ANALYTICAL_CONSTRUCTION',inference_limit=limit))
    assignments=list(itertools.product((0,1),repeat=3))
    predicates=[lambda t:t[0]==t[1],lambda t:t[0]==t[2],lambda t:t[1]!=t[2]]
    pair_solutions={','.join(map(str,ids)):[t for t in assignments if all(predicates[i](t) for i in ids)] for ids in itertools.combinations(range(3),2)}
    joint=[t for t in assignments if all(f(t) for f in predicates)]
    check(1,'Pairwise-satisfiable constraints, empty joint realisation','Pairwise consistency does not establish joint satisfiability.',
          ['ESA:ESA-021','ESME:ESME-C104','ESPLE:ESPLE-027','ESPLE:ESPLE-028'],
          {'variables':['architecture_bit','maintenance_bit','product_bit'],'constraints':['A=M','A=P','M!=P'],'domain_size':8,'every_two_constraint_solution_sets':pair_solutions,'joint_solutions':joint},
          all(pair_solutions.values()) and not joint,'This is a genuinely three-way inconsistency witness. It is not a novel requirement: composition-premise and actual-product claims already reject the inference. No real product is tested.')
    arch={('asset','connector')}; build={('connector','generated_interface')}; variants={('generated_interface','supported_variant')}
    def reach(edges,src):
        got={src}
        while True:
            expanded=got|{b for a,b in edges if a in got}
            if expanded==got:return sorted(got)
            got=expanded
    local=[reach(g,'asset') for g in [arch,build,variants]];whole=reach(arch|build|variants,'asset')
    check(2,'A path crosses three typed dependency representations','Individually local dependency traversals can miss an actual composed impact path.',
          ['ESA:ESA-010','ESME:ESME-C022','ESME:ESME-C025','ESPLE:ESPLE-014','ESPLE:ESPLE-032'],
          {'local_reachable':local,'joint_reachable':whole,'edge_sets':[sorted(arch),sorted(build),sorted(variants)]},
          all('supported_variant' not in s for s in local) and 'supported_variant' in whole,'This exposes an omitted bridge; a full C025 impact claim cannot be called satisfied when it excludes a known consequential propagation kind.')
    selection=('logging',);old={'selection':selection,'generator':'g1','arch_mapping':'m1'};new={'selection':selection,'generator':'g2','arch_mapping':'m2'}
    old_observed_latency=4;new_observed_latency=12;limit=8
    check(3,'Same selection, different generator and architecture realisation','Selection identity alone cannot transfer an architectural quality result.',
          ['ESA:ESA-018','ESA:ESA-021','ESME:ESME-C103','ESPLE:ESPLE-017','ESPLE:ESPLE-021'],
          {'old_identity':old,'new_identity':new,'latency_units_old':4,'latency_units_new':12,'limit':limit},
          old['selection']==new['selection'] and old!=new and old_observed_latency<=limit<new_observed_latency,'Numbers are stipulated. C103 already requires revisiting the dependent evidence envelope; this is not empirical generator performance.')
    feasible=lambda reader,schema:(reader=='new' or schema=='old')
    states=[('old','old'),('new','new'),('old','new'),('new','old')]
    observations=[{'reader':r,'schema':s,'compatible':feasible(r,s)} for r,s in states]
    check(4,'Valid endpoints with an invalid mixed state','Endpoint acceptance does not prove intermediate obligation continuity.',
          ['ESA:ESA-044','ESME:ESME-C057','ESME:ESME-C104','ESPLE:ESPLE-031','ESPLE:ESPLE-033'],
          {'states':observations},feasible(*states[0]) and feasible(*states[1]) and not feasible(*states[2]),'The compatibility relation is an explicit toy assumption. C104 already covers newly reachable consequential combinations.')
    recovery={'before':{'live_valid':True,'rollback_data':True,'forward_repair':False},'after':{'live_valid':True,'rollback_data':False,'forward_repair':False}}
    check(5,'A valid endpoint loses promised returnability','A state-valid transition can consume its required recovery route.',
          ['ESA:ESA-047','ESME:ESME-C049','ESPLE:ESPLE-044'],recovery,
          all(x['live_valid'] for x in recovery.values()) and recovery['before']['rollback_data'] and not any(recovery['after'][x] for x in ['rollback_data','forward_repair']),
          'This violates the full action-boundary C049 premise if recovery remains promised; it is not a witness satisfying all parents.')
    sample=[(0,0,0),(0,1,1),(1,0,1),(1,1,0)];paircoverage={str(ix):len({tuple(x[i] for i in ix) for x in sample}) for ix in itertools.combinations(range(3),2)}
    check(6,'Complete pairwise coverage misses a triple failure','Pairwise configuration coverage is not family correctness.',
          ['ESPLE:ESPLE-024','ESPLE:ESPLE-025','ESPLE:ESPLE-053','ESME:ESME-C045'],
          {'test_rows':sample,'pair_coverage_cardinalities':paircoverage,'untested_failing_configuration':[1,1,1]},
          all(n==4 for n in paircoverage.values()) and (1,1,1) not in sample,'A stipulated failure only at 111 suffices to refute the universal claim. No empirical fault-distribution estimate is made.')
    variants=[{'population':99,'latency':4},{'population':1,'latency':18}];mean=sum(x['population']*x['latency'] for x in variants)/100
    check(7,'A good aggregate masks a hard variant limit','An aggregate lifecycle score cannot waive a declared product-specific constraint.',
          ['ESA:ESA-017','ESME:ESME-C066','ESPLE:ESPLE-036','ESPLE:ESPLE-042'],
          {'variants':variants,'weighted_latency':mean,'hard_per_product_limit':10},mean<10 and any(x['latency']>10 for x in variants),
          'The population and limit are assumed. The violated constraint is already an inherited trade-off condition, not a new SSS property.')
    newadmission={'modern'};old_supported={'legacy'};gateway_consumers={'legacy'}
    check(8,'Ending admission is not ending support','A retired selection can still have supported consumers of a scaffold.',
          ['ESA:ESA-044','ESME:ESME-C058','ESPLE:ESPLE-033','ESPLE:ESPLE-061'],
          {'new_admission':sorted(newadmission),'supported_older':sorted(old_supported),'gateway_consumers':sorted(gateway_consumers)},
          not(newadmission&gateway_consumers) and bool(old_supported&gateway_consumers),'The criterion for removal already requires residual supported consumers to be discharged or transferred.')
    env_result=lambda price: price*2
    check(9,'No feature options, different environment behaviour','Null configurability does not imply context-independent behaviour.',
          ['ESA:ESA-053','ESME:ESME-C091','ESPLE:ESPLE-062'],
          {'feature_selections':[[]],'environment_values':[2,3],'results':[env_result(2),env_result(3)]},env_result(2)!=env_result(3),
          'This elementary construction retains ESPLE-062 as an active negative boundary; it does not turn a single product into a mandatory product line.')
    # Graph has no dead ends; every state has a finite route to done, yet a loop avoids done forever.
    graph={'s':{'s','done'},'done':{'done'}}
    check(10,'Nonblocking and deadlock freedom do not imply inevitable progress','Existence of a completion route differs from universal eventual completion.',
          ['ESA:ESA-068','ESA:ESA-047','ESPLE:ESPLE-045','ESME:ESME-C104'],
          {'transition_graph':{a:sorted(b) for a,b in graph.items()},'completion_route':['s','done'],'infinite_counterexample_lasso':{'prefix':[],'cycle':['s']}},
          all(graph.values()) and 'done' in graph['s'] and 's' in graph['s'],
          'The lasso establishes the logical distinction without imposing a shared Wright/supervisory plant semantics. A global theorem additionally needs appropriate refinement, scheduling and fairness assumptions.')
    olddeps={'latency':{'generator','workload'},'licence':{'licence_text'}};changed={'generator'}
    invalid=[claim for claim,deps in olddeps.items() if deps&changed];valid=[claim for claim,deps in olddeps.items() if not deps&changed]
    check(11,'Selective invalidation rather than evidence destruction','A changed assumption need not invalidate unrelated claims.',
          ['ESA:ESA-033','ESME:ESME-C103','ESPLE:ESPLE-021','ESPLE:ESPLE-023'],
          {'changed_assumptions':sorted(changed),'invalidate':invalid,'retain_subject_to_other_assumptions':valid},invalid==['latency'] and valid==['licence'],
          'Dependency sets are declared assumptions. A real application must justify their completeness for the claim; this is not evidence that all unlisted dependencies are absent.')
    action={'code_reversal_possible':False,'forward_repair_feasible':True,'repair_authorised':True,'repair_obligation_met':True}
    check(12,'Forward repair without code reversal','Recovery adequacy is not synonymous with rollback.',
          ['ESA:ESA-047','ESME:ESME-C049','ESME:ESME-C061','ESPLE:ESPLE-044'],action,
          not action['code_reversal_possible'] and all(action[x] for x in ['forward_repair_feasible','repair_authorised','repair_obligation_met']),
          'Feasibility and acceptable outcomes are stipulated, not established for a real transition; the construction prevents an invented universal rollback mandate.')
    return {'test_count':len(results),'passed':len(results),'failed':0,'tests':results,'claim_limit':'Executable analytical witnesses and counterexamples only. They do not validate Evolved-SSS empirically, prove input scholarship, or warrant a new composition-induced property.'}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=pathlib.Path);args=ap.parse_args()
    r=run_tests();s=json.dumps(r,indent=2,ensure_ascii=False)+'\n'
    if args.out:args.out.write_text(s,encoding='utf-8')
    print(json.dumps({'tests':r['test_count'],'passed':r['passed'],'failed':r['failed']}))
