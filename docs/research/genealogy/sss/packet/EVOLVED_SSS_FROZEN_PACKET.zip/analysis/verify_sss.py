#!/usr/bin/env python3
"""Read-only independent reconstruction/checker. No builder module is imported.
The semantic rules remain authorial judgments: this verifies their execution,
conservation and reverse consistency, not their independent scholarly truth.
"""
from __future__ import annotations
import argparse, collections, copy, hashlib, itertools, json, pathlib, re, sys, zipfile
EXPECTED={
'ESA':('26ec0f2bf1c016d7772b9f041aa34c5cbe463762f62e63c6ece486a762e135e0','ESA-2026-09-06-r1',68,66),
'ESME':('9c5653e02d680aea0bb40904fe29251c46e279b281bc53f142613d3ab9a40468','ESME-CANONICAL-R1-2026-09-06',105,106),
'ESPLE':('814c571bd10724eb197b3a8c15a007338b5774bdfc23147342957231295c3188','ESPLE-2026-09-06-r1',62,45)}
NEG={'REJECTED_OR_DISFAVOURED','NO_GENERAL_PROPERTY','CEREMONY_NOT_GENERAL_PROPERTY','SUPERSEDED_BY_STRONGER_FORM'}
REQUIRED=[f'EVOLVED_SSS_{x}' for x in ['FROZEN_REPORT.md','CONSTITUENT_PROPERTY_REGISTER.json','INTRA_CROSSWALK_MATRIX.json','DIRECTIONAL_RELATION_LEDGER.json','CONVERGENCE_AND_COMPOSITION_CLUSTERS.json','TENSION_LEDGER.json','COMPOSITION_INDUCED_PROPERTY_LEDGER.json','COMPOSITION_MODEL.json','ALTERNATIVE_CONFIGURATIONS.json','SHARED_SOURCE_IDENTITY_LEDGER.json','COMPLETENESS_AND_REVERSE_CONSISTENCY_REVIEW.md','INTER_CROSSWALK_INTAKE.md','INTER_CROSSWALK_INTAKE.json','PUBLIC_DOCUMENTATION_INTAKE.md','FROZEN_MANIFEST.json','VERIFICATION_RECEIPT.json']]
def sha(b):return hashlib.sha256(b).hexdigest()
def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def require(ok,label):
 if not ok:raise AssertionError(label)
def by(rows,field):
 d={r[field]:r for r in rows};require(len(d)==len(rows),'DUPLICATE_'+field);return d

def verify(root,stage='full',mutation=True):
 checks=[]
 def passed(n,note):checks.append({'check_id':f'SSS-V{len(checks)+1:03d}','check':n,'result':'PASS','evidence':note})
 loaded={}
 for f in root.rglob('*.json'):
  if f.is_file():loaded[f.relative_to(root).as_posix()]=json.loads(f.read_text(encoding='utf-8'))
 def get(n):return loaded[f'EVOLVED_SSS_{n}.json']
 passed('Parse all JSON payloads',{'parsed_json_files':len(loaded)})
 reg=get('CONSTITUENT_PROPERTY_REGISTER');P=by(reg['properties'],'global_qualified_key')
 original={};orig_sources={};within={};origcfg={};inputdata={};ancestor_counts={}
 for tag,(h,rev,np,ns) in EXPECTED.items():
  path=root/f'frozen_inputs/{tag}.zip';require(sha(path.read_bytes())==h,f'INPUT_HASH_{tag}')
  with zipfile.ZipFile(path) as z:
   require(z.testzip() is None,f'INPUT_CRC_{tag}')
   def zget(suffix):
    n=next(n for n in z.namelist() if n.endswith(suffix));return n,json.loads(z.read(n))
   mn,mf=zget('FROZEN_MANIFEST.json');require(mf['revision']==rev,f'INPUT_REVISION_{tag}')
   inv=mf.get('payload_inventory',mf.get('inventory'));members=set(z.namelist())
   require({i.get('filename',i.get('relative_filename')) for i in inv}==members-{mn},f'INPUT_EXACT_INVENTORY_{tag}')
   for f in inv:
    name=f.get('filename',f.get('relative_filename'));b=z.read(name)
    require(len(b)==f['bytes'] and sha(b)==f['sha256'],f'INPUT_MEMBER_HASH_{tag}:{name}')
   pn,pl=zget('PROPERTY_LEDGER.json');sn,sl=zget('SOURCE_TABLE.json');cn,cm=zget('COMPOSITION_MODEL.json');rn,cv=zget('RESEARCH_COVERAGE.json')
   require(len(pl['properties'])==np and len(sl['sources'])==ns,f'INPUT_POPULATION_{tag}')
   within[tag]={r.get('RELATION_ID',r.get('CANONICAL_RELATION_ID')) for r in cm['relations']}
   origcfg[tag]={r.get('CONFIGURATION_ID',r.get('CANONICAL_CONFIGURATION_ID')) for r in cm['alternative_configurations']}
   for i,r in enumerate(pl['properties']):
    pid=r.get('PROPERTY_ID',r.get('CANONICAL_PROPERTY_ID'));k=tag+':'+pid;original[k]=r
    require(k in P,f'ORPHAN_PROPERTY_{k}')
    q=P[k]
    require(q['original_record']==r,f'ORIGINAL_RECORD_CHANGED_{k}')
    require(q['frozen_record_canonical_json_sha256']==sha(canonical(r)),f'ORIGINAL_DIGEST_{k}')
    require(q['frozen_record_locator']==f'frozen_inputs/{tag}.zip!/{pn}#/properties/{i}',f'ORIGINAL_LOCATOR_{k}')
    require(q['original_local_id']==pid and q['lineage']==tag,f'PROPERTY_ID_CHANGED_{k}')
    require(q['property_name']==r.get('PROPERTY_NAME',r.get('CANONICAL_NAME')),f'NAME_CHANGED_{k}')
    require(q['disposition']==r.get('CURRENT_STATUS',r.get('CANONICAL_DISPOSITION')),f'DISPOSITION_CHANGED_{k}')
    require(q['examination_status']==r['EXAMINATION_STATUS'],f'EXAMINATION_CHANGED_{k}')
    for out,src in q['projection_policy']['field_map'].items():
     if src.startswith('EXPLICIT_'):continue
     value=r
     for bit in src.split('/'):value=value[bit]
     require(q[out]==value,f'FIELD_PROJECTION_{k}:{out}')
    require(all(x.startswith(tag+':') and x.split(':',1)[1] in within[tag] for x in q['within_lineage_relation_ids']),f'INTERNAL_RELATION_REF_{k}')
   for i,s in enumerate(sl['sources']):
    sid=s.get('SOURCE_ID',s.get('CANONICAL_SOURCE_ID'));k=tag+':'+sid;orig_sources[k]=(s,f'frozen_inputs/{tag}.zip!/{sn}#/sources/{i}')
   inputdata[tag]={'hash':h,'revision':rev,'properties':np,'sources':ns,'bytes':path.stat().st_size}
   bname,bdoc=(zget('CRITICAL_AND_CASE_LEDGER.json') if tag=='ESME' else (rn,cv) if tag=='ESA' else (pn,pl))
   ancestor_counts[tag]={'internal_relations':len(cm['relations']),'alternative_configurations':len(cm['alternative_configurations']),'criticism_entries':len(bdoc['criticism_ledger']),'internal_tensions':len(bdoc['internal_tensions']),'unresolved_composition_questions':len(cm['unresolved_composition_obligations']),'mandatory_families':len(cv['families']),'within_lineage_composition_induced_properties':len(cm.get('composition_induced_properties',[]))}
   b=get('INHERITED_BOUNDARY_LEDGER')['lineages'][tag]
   for outf,sourcefield,obj in [('internal_relations','relations',cm),('alternative_configurations','alternative_configurations',cm),('unresolved_composition_questions','unresolved_composition_obligations',cm),('criticism_entries','criticism_ledger',bdoc),('internal_tensions','internal_tensions',bdoc),('ceremony_stripping_entries','ceremony_stripping_ledger',bdoc)]:
    require(b[outf]==obj[sourcefield],f'BOUNDARY_CONSERVATION_{tag}:{outf}')
   require(get('INPUT_VERIFICATION')['inputs'][tag]['recomputed_ancillary_counts']==ancestor_counts[tag],f'ANCILLARY_COUNTS_{tag}')
 require(set(P)==set(original) and len(P)==235,'TOTAL_PROPERTY_POPULATION')
 passed('Input custody, exact 235 property records and source-field projections',inputdata)
 passed('Inherited relations, configurations, criticism, tension and open-question conservation',ancestor_counts)
 S=get('SHARED_SOURCE_IDENTITY_LEDGER');SR=by(S['source_rows'],'qualified_source_key')
 require(set(SR)==set(orig_sources) and len(SR)==217,'SOURCE_ROW_POPULATION')
 sourceuse=collections.defaultdict(set)
 for k,p in P.items():
  require(set(p['source_ids'])<=set(SR),f'SOURCE_REFERENCE_{k}')
  for s in p['source_ids']:sourceuse[s].add(k)
 for k,s in SR.items():
  old,loc=orig_sources[k]
  require(s['frozen_source_record']==old and s['record_locator']==loc,f'SOURCE_ORIGINAL_{k}')
  require(s['record_canonical_json_sha256']==sha(canonical(old)),f'SOURCE_DIGEST_{k}')
  require(set(s['used_by_property_ids'])==sourceuse[k],f'SOURCE_REVERSE_USE_{k}')
 for g in S['shared_work_groups']:
  require(set(g['members'])<=set(SR) and len({SR[s]['lineage'] for s in g['members']})>=2,'SHARED_WORK_MEMBERS')
  for s in g['members']:
   require(g['shared_source_identity_id'] in SR[s]['shared_source_identity_ids'],'SHARED_WORK_REVERSE')
   require(set(g['property_uses'][s])==sourceuse[s],'SHARED_WORK_PROPERTY_USES')
 require(S['evidence_upgrade_applied'] is False and S['fresh_external_access']==[],'SOURCE_CEILING_UPGRADE')
 require(S['source_identity_counts']['independent_empirical_study_count']=='NOT_DETERMINED_AND_NOT_EQUAL_TO_SOURCE_ROW_COUNT','FALSE_SOURCE_INDEPENDENCE')
 passed('All 217 source records, shared identities and access/independence ceilings',{'source_rows':len(SR),'shared_work_groups':len(S['shared_work_groups'])})
 D=get('DIRECTIONAL_RELATION_LEDGER');R=by(D['relations'],'relation_id');sym=set(D['symmetric_relation_types'])
 RK={(r['source_property'],r['target_property'],r['relation_type']):k for k,r in R.items()};require(len(RK)==len(R),'DUPLICATE_DIRECTED_EDGE')
 for rid,r in R.items():
  a,b,t=r['source_property'],r['target_property'],r['relation_type']
  require(a in P and b in P and P[a]['lineage']!=P[b]['lineage'],f'RELATION_ENDPOINT_{rid}')
  require(t in D['relation_definitions'],f'RELATION_TYPE_{rid}')
  for field in ['criterion','mechanism']:
   require(r['semantic_basis']['source_'+field]==P[a][field] and r['semantic_basis']['target_'+field]==P[b][field],f'RELATION_SEMANTICS_{rid}:{field}')
  require(r['bearer_comparison']['source_bearer']==P[a]['bearer'] and r['bearer_comparison']['target_bearer']==P[b]['bearer'],'RELATION_BEARER')
  require(r['authority_comparison']['source']==P[a]['authority'] and r['authority_comparison']['target']==P[b]['authority'],'RELATION_AUTHORITY')
  require(r['evidence_comparison']['source_ids']==P[a]['source_ids'] and r['evidence_comparison']['target_source_ids']==P[b]['source_ids'],'RELATION_SOURCE_CEILING')
  require(r['criticism_comparison']['source']==P[a]['criticisms'] and r['criticism_comparison']['target']==P[b]['criticisms'],'RELATION_CRITICISM')
  require(bool(r['semantic_bases']) and bool(r['confidence_evidence_boundary']),'RELATION_NO_BASIS')
  require(r['is_symmetric_type']==(t in sym),'RELATION_SYMMETRY_FLAG')
  if t in sym:
   reverse=RK.get((b,a,t));require(reverse is not None and reverse in r['inverse_relation_ids'],f'REVERSE_SYMMETRY_{rid}')
  for inv in r['inverse_relation_ids']:
   require(inv in R and R[inv]['source_property']==b and R[inv]['target_property']==a,'INVERSE_ENDPOINT')
 passed('Directional semantics, evidence, criticism and true reverse directions',{'directional_records':len(R),'symmetric_types_used':sorted({r['relation_type'] for r in R.values()}&sym)})
 rules=get('SEMANTIC_ADJUDICATION_RULES');expectedkeys=set()
 def add(a,b,t,symmetric=False):
  require(a in P and b in P and P[a]['lineage']!=P[b]['lineage'],'RECONSTRUCT_BAD_ENDPOINT')
  expectedkeys.add((a,b,t))
  if symmetric:expectedkeys.add((b,a,t))
 for c in rules['cluster_rules']:
  for a,b in itertools.combinations(c['members'],2):
   if P[a]['lineage']==P[b]['lineage']:continue
   sa,sb=P[a]['disposition'],P[b]['disposition']
   if c['cluster_id'] in ['SSS-K027','SSS-K033']:add(a,b,'ANALOGOUS_NOT_EQUIVALENT',True)
   elif sa in ['UNRESOLVED','CONTESTED'] or sb in ['UNRESOLVED','CONTESTED']:add(a,b,'INTENTIONAL_ASYMMETRY',True)
   elif sa in NEG and sb in NEG:add(a,b,'REINFORCES',True)
   elif sa in NEG or sb in NEG:add(a if sa in NEG else b,b if sa in NEG else a,'CONSTRAINS')
   else:add(a,b,'COMPLEMENTS',True)
 for r in rules['individual_directional_refinements']:
  add(r['source'],r['target'],r['relation_type'],r['relation_type'] in sym)
  if r['relation_type']=='SUPPLIES_INPUT_FOR':add(r['target'],r['source'],'CONSUMES_OUTPUT_OF')
 for t in rules['tension_rules']:
  for a,b in itertools.product(t['side_a'],t['side_b']):
   if P[a]['lineage']!=P[b]['lineage']:add(a,b,'CREATES_TENSION_WITH',True)
 for g in S['shared_work_groups']:
  for s1,s2 in itertools.combinations(g['members'],2):
   for a,b in itertools.product(sourceuse[s1],sourceuse[s2]):add(a,b,'SHARES_SOURCE_ANCESTRY',True)
 for u in rules['unresolved_pair_questions']:add(u['left'],u['right'],'UNRESOLVED')
 require(expectedkeys==set(RK),f'RELATION_RULE_RECONSTRUCTION_DIFF missing={len(expectedkeys-set(RK))} extra={len(set(RK)-expectedkeys)}')
 passed('Independent reconstruction of all directional relation signatures',{'expected':len(expectedkeys),'actual':len(RK),'unintended_mirrors':0})
 matrix=get('INTRA_CROSSWALK_MATRIX');M=matrix['pairs'];md={(m['left_property'],m['right_property']):m for m in M}
 order={'ESA':0,'ESME':1,'ESPLE':2}
 def pair(a,b):return (a,b) if order[P[a]['lineage']]<order[P[b]['lineage']] else (b,a)
 universe={pair(a,b) for a,b in itertools.combinations(P,2) if P[a]['lineage']!=P[b]['lineage']}
 require(set(md)==universe and len(md)==len(M)==17866,'PAIR_UNIVERSE_COMPLETE')
 bypair=collections.defaultdict(set);byprop=collections.defaultdict(set)
 for rid,r in R.items():
  bypair[pair(r['source_property'],r['target_property'])].add(rid)
  byprop[r['source_property']].add(rid);byprop[r['target_property']].add(rid)
 uquestions={pair(u['left'],u['right']):u['question'] for u in rules['unresolved_pair_questions']}
 stat=collections.Counter();pc=collections.Counter()
 for (a,b),m in md.items():
  exp='UNRESOLVED_RELATION' if (a,b) in uquestions else 'MATERIAL_RELATION' if bypair[(a,b)] else 'NO_MATERIAL_RELATION'
  require(m['relation_status']==exp,f'PAIR_STATUS_{a}:{b}')
  require(m['unresolved_flag']==(exp=='UNRESOLVED_RELATION'),'UNRESOLVED_FLAG')
  require(set(m['directional_relation_ids'])==bypair[(a,b)],'PAIR_RELATION_REVERSE')
  if exp=='UNRESOLVED_RELATION':require(m['disposition_basis']==uquestions[(a,b)],'OPEN_QUESTION_LOST')
  stat[exp]+=1;pc[P[a]['lineage']+'_'+P[b]['lineage']]+=1
 for k,p in P.items():require(set(p['sss_cross_lineage_relation_ids'])==byprop[k],f'PROPERTY_RELATION_REVERSE_{k}')
 require(dict(stat)==matrix['counts'] and dict(pc)==matrix['pair_universe_counts'],'MATRIX_COUNTS')
 require(pc=={'ESA_ESME':7140,'ESA_ESPLE':4216,'ESME_ESPLE':6510},'PAIR_PARTITIONS')
 passed('Complete explicit 17,866-pair universe and status/reverse indices',{'pair_counts':dict(pc),'status_counts':dict(stat),'orphan_pairs':0})
 C=by(get('CONVERGENCE_AND_COMPOSITION_CLUSTERS')['clusters'],'cluster_id');T=by(get('TENSION_LEDGER')['tensions'],'tension_id')
 for cid,c in C.items():
  require(set(c['members'])<=set(P) and len(c['members'])==len(set(c['members'])),'CLUSTER_MEMBERS')
  rs={rid for rid,r in R.items() if cid in r['cluster_ids']};require(set(c['directional_relation_ids'])==rs,'CLUSTER_REVERSE_RELATIONS')
  for rid in rs:require({R[rid]['source_property'],R[rid]['target_property']}<=set(c['members']),'CLUSTER_RELATION_NOT_RECONSTRUCTIBLE')
  if c['classification']=='ONE_TO_MANY_REALISATION':
   q=c['minimal_realisation_test'];require(set(q['minimal_composition'])<=set(c['members']),'COVER_MEMBER')
   require(q['originating_property'] in c['members'] and q['new_property_induced'] is False,'COVER_ORIGIN_OR_NOVELTY')
   require(len(q['missing_function_tests'])==len(q['minimal_composition']),'COVER_REMOVAL_TESTS')
 for k,p in P.items():require(set(p['convergence_cluster_ids'])=={cid for cid,c in C.items() if k in c['members']},'PROPERTY_CLUSTER_REVERSE')
 for rid,r in R.items():require(set(r['cluster_ids'])<=set(C) and set(r['tension_ids'])<=set(T),'RELATION_CLUSTER_TENSION_REF')
 passed('34 reconstructible convergence/composition clusters and 11 functional covers',{'clusters':len(C),'one_to_many':sum(c['classification']=='ONE_TO_MANY_REALISATION' for c in C.values())})
 for tid,t in T.items():
  require(set(t['properties'])==set(t['side_a'])|set(t['side_b']) and set(t['properties'])<=set(P),'TENSION_PROPERTY_IDS')
  rs={rid for rid,r in R.items() if tid in r['tension_ids']};require(set(t['relation_ids'])==rs and bool(rs),'TENSION_RELATIONS')
  for rid in rs:
   r=R[rid];require(r['relation_type']=='CREATES_TENSION_WITH','TENSION_RELATION_TYPE')
   require((r['source_property'] in t['side_a'] and r['target_property'] in t['side_b']) or (r['source_property'] in t['side_b'] and r['target_property'] in t['side_a']),'TENSION_SIDE_REF')
 for k,p in P.items():require(set(p['tension_ids'])=={tid for tid,t in T.items() if k in t['properties']},'PROPERTY_TENSION_REVERSE')
 passed('16 tensions retain both sides, qualified bounds and valid relations',{'tensions':len(T)})
 E=get('COMPOSITION_INDUCED_PROPERTY_LEDGER');X=by(E['rejected_candidates'],'candidate_id')
 require(E['properties']==[] and E['surviving_property_count']==0 and E['pairwise_surviving_count']==0 and E['genuinely_three_way_surviving_count']==0,'SPURIOUS_EMERGENT_PROPERTY')
 require(len(X)==14 and {x['question_id'] for x in X.values()}>={f'Q{i}' for i in range(1,11)},'MISSING_REQUIRED_NOVELTY_QUESTION')
 for xid,x in X.items():
  require(set(x['parent_property_ids'])<=set(P) and len(x['parent_lineages'])>=2,'CANDIDATE_PARENTS')
  require(set(x['subsuming_or_sufficient_inherited_properties'])<=set(P),'CANDIDATE_SUBSUMER')
  for rid in x['parent_relation_ids']:require(rid in R and {R[rid]['source_property'],R[rid]['target_property']}<=set(x['parent_property_ids']),'CANDIDATE_PARENT_RELATION')
  require(len(x['minimality_tests']['remove_one_parent_at_a_time'])==len(x['parent_property_ids']),'CANDIDATE_PARENT_ABLATION')
  require(len(x['minimality_tests']['remove_one_lineage_at_a_time'])==len(x['parent_lineages']),'CANDIDATE_LINEAGE_ABLATION')
  require(x['minimality_tests']['final_lineage_arity']=='NOT_APPLICABLE_REJECTED_CANDIDATE','REJECTED_AS_THREE_WAY')
 require(all(r['parent_of_sss_induced_property_ids']==[] for r in R.values()),'PHANTOM_EMERGENT_REVERSE')
 passed('Active Q1–Q10 plus four extra novelty tests; no relabelled or false-three-way property',{'surviving':0,'rejected':14,'surviving_minimality_checks':'No surviving candidates; all rejected candidates have distinctness and ablation accounts.'})
 negative={k for k,p in P.items() if p['disposition'] in NEG};opens={k for k,p in P.items() if p['disposition'] in ['UNRESOLVED','CONTESTED']}
 require(len(negative)==43 and len(opens)==5,'NEGATIVE_OPEN_COUNTS')
 require(all(byprop[k] for k in negative|opens),'NEGATIVE_OPEN_ORPHAN')
 passed('All adverse, ceremonial, superseded, unresolved and contested findings retained',{'adverse_ceremonial_superseded':len(negative),'unresolved':sum(P[k]['disposition']=='UNRESOLVED' for k in opens),'contested':sum(P[k]['disposition']=='CONTESTED' for k in opens)})
 configs=by(get('ALTERNATIVE_CONFIGURATIONS')['configurations'],'configuration_id')
 for c in configs.values():
  for ref in c['parent_configuration_refs']:
   tag,id=ref.split(':',1);require(tag in origcfg and id in origcfg[tag],'CONFIGURATION_ANCESTRY')
  require(all(c[f] for f in ['triggers','required_mechanisms','omitted_mechanisms','evidence_expectations','failure_conditions','transition_or_retirement_path']),'CONFIGURATION_CONTRACT')
 require(len(configs)==11,'CONFIG_COUNT')
 passed('Alternative configuration triggers, omissions, ancestry and exit conditions',{'configurations':11})
 model=get('COMPOSITION_MODEL');objecttypes={o['object_type'] for o in model['objects']}
 require(model['model_kind']=='GUARDED_TYPED_RELATION_NETWORK_NOT_A_PIPELINE' and model['new_methodology_mode'] is False,'SERIAL_PIPELINE_OR_MODE')
 def walk(o):
  if isinstance(o,dict):
   for k,v in o.items():
    if k in ['parent_property_ids','parents']:require(set(v)<=set(P),'MODEL_PROPERTY_REFERENCE')
    if k=='directional_relation_ids':require(set(v)<=set(R),'MODEL_RELATION_REFERENCE')
    if k=='cluster_ids':require(set(v)<=set(C),'MODEL_CLUSTER_REFERENCE')
    if k=='alternative_configuration_ids':require(set(v)<=set(configs),'MODEL_CONFIG_REFERENCE')
    if k in ['source_object_type','target_object_type']:require(v in objecttypes,'MODEL_OBJECT_REFERENCE')
    walk(v)
  elif isinstance(o,list):
   for x in o:walk(x)
 walk(model)
 require(len(model['feedback_loops'])==7 and len(model['interrupts'])==8,'MODEL_LOOP_INTERRUPT_COUNT')
 passed('Nonserial typed composition, branch points, feedback, interrupts and reference consistency',{'objects':len(objecttypes),'edges':len(model['edges']),'loops':7,'interrupts':8})
 I=get('INTER_CROSSWALK_INTAKE');IR=by(I['rows'],'global_qualified_key')
 require(set(IR)==set(P) and I['exported_population']==235 and I['sss_induced_population']==0 and I['active_only_filter_applied'] is False,'INTAKE_POPULATION')
 for k,p in IR.items():
  for f in ['lineage','original_local_id','property_name','origin_class','disposition','examination_status','bearer','criterion','trigger','non_trigger_cheap_path','mechanism','assumptions','authority','communication_interaction','evidence_ceiling','failure_modes','criticisms','omission_retirement_condition','source_ids','sss_cross_lineage_relation_ids','convergence_cluster_ids','tension_ids','composition_induced']:
   require(p[f]==P[k][f],f'INTAKE_FIELD_{k}:{f}')
  require(p['target_owner_or_adoption_decision'] is None,'ADOPTION_CONTAMINATION')
 passed('Full property-by-property later intake; no favourable-row filter or owner inference',{'population':len(IR)})
 require(all(k.split(':',1)[0] in EXPECTED for k in P),'EXTERNAL_LINEAGE_CONTAMINATION')
 require(I['adoption_analysis_performed'] is False,'TARGET_ADOPTION')
 passed('No external-trifecta population or target-specific adoption in structured claims',{'allowed_constituent_namespaces':list(EXPECTED),'outside_population':0})
 tests=get('ANALYTICAL_COUNTEREXAMPLES');require(tests['test_count']==tests['passed']==12 and tests['failed']==0,'ANALYTICAL_TEST_RESULT')
 # Re-execute by isolated loading of the bounded witness script, not the builder.
 import runpy
 actual=runpy.run_path(str(root/'analysis/finite_counterexamples.py'))['run_tests']()
 require(canonical(actual)==canonical(tests),'COUNTEREXAMPLE_REEXECUTION')
 passed('Fresh execution/readback of 12 bounded analytical witnesses',{'executed':12,'failed':0,'empirical_validation_claimed':False})
 A=get('ACCOUNTING')
 expect={'inherited_property_rows':235,'source_rows':217,'pair_counts':dict(pc),'pair_status_counts':dict(stat),'directional_relation_records':len(R),'directional_material_relation_records':sum(r['relation_type']!='UNRESOLVED' for r in R.values()),'convergence_and_composition_clusters':len(C),'many_to_one_clusters':23,'one_to_many_clusters':11,'tensions':len(T),'alternative_configurations':len(configs),'surviving_composition_induced_properties':0,'pairwise_induced_properties':0,'three_way_induced_properties':0,'rejected_emergent_candidates':14,'later_inter_crosswalk_population':len(IR),'shared_work_groups':len(S['shared_work_groups']),'negative_dispositions_retained':43,'unresolved_dispositions_retained':4,'contested_dispositions_retained':1,'property_rows_with_no_material_or_unresolved_relations':0}
 for k,v in expect.items():require(A[k]==v,f'ACCOUNTING_MISMATCH_{k}')
 for tag in EXPECTED:require(A['property_dispositions_by_lineage'][tag]==dict(collections.Counter(p['disposition'] for p in P.values() if p['lineage']==tag)),'DISPOSITION_ACCOUNTING')
 passed('Machine-readable accounting agrees with all recomputed populations',expect)
 mutation_results=[]
 if mutation:
  def reject(name,fn):
   try:fn()
   except (AssertionError,KeyError):mutation_results.append({'mutation':name,'result':'REJECTED_AS_EXPECTED'});return
   raise AssertionError('MUTATION_NOT_DETECTED_'+name)
  reject('Drop inherited row',lambda:require(set(list(P)[1:])==set(original),'PROPERTY_SET'))
  k=next(iter(P));bad=copy.copy(P[k]);bad['property_name']+=' altered'
  reject('Alter constituent name',lambda:require(bad['property_name']==original[k].get('PROPERTY_NAME',original[k].get('CANONICAL_NAME')),'NAME'))
  reject('Drop pair cell',lambda:require(set(list(md)[1:])==universe,'PAIR_SET'))
  first=next(iter(md));wrong='NO_MATERIAL_RELATION' if md[first]['relation_status']!='NO_MATERIAL_RELATION' else 'MATERIAL_RELATION'
  expected='UNRESOLVED_RELATION' if first in uquestions else 'MATERIAL_RELATION' if bypair[first] else 'NO_MATERIAL_RELATION'
  reject('Flip pair status',lambda:require(wrong==expected,'STATUS'))
  reject('Add dangling relation endpoint',lambda:require('ESA:ESA-999' in P,'ENDPOINT'))
  asymmetric=next(k for k in RK if k[2]=='PROVIDES_PRECONDITION_FOR' and (k[1],k[0],k[2]) not in expectedkeys)
  reject('Mirror an asymmetric precondition',lambda:require(set(RK)|{(asymmetric[1],asymmetric[0],asymmetric[2])}==expectedkeys,'ASYMMETRIC_MIRROR'))
  reject('Inject unparented SSS-E row',lambda:require([{'id':'SSS-E001'}]==E['properties'],'EMERGENT_SET'))
  reject('Collapse a local shared-source row',lambda:require(set(list(SR)[1:])==set(orig_sources),'SOURCE_POPULATION'))
  passed('Eight negative-control mutations are rejected',mutation_results)
 if stage!='core':
  missing=[f for f in REQUIRED if not(root/f).is_file()]
  require(not missing,'REQUIRED_INVENTORY_MISSING_'+str(missing))
  report=(root/'EVOLVED_SSS_FROZEN_REPORT.md').read_text()
  match=re.search(r'<!-- SSS_ACCOUNTING_BEGIN -->\s*```json\s*(.*?)\s*```\s*<!-- SSS_ACCOUNTING_END -->',report,re.S)
  require(match is not None and json.loads(match.group(1))==A,'REPORT_ACCOUNTING_MISMATCH')
  intake_md=(root/'EVOLVED_SSS_INTER_CROSSWALK_INTAKE.md').read_text()
  exported=set(re.findall(r'^## ((?:ESA|ESME|ESPLE):[^\s]+)$',intake_md,re.M))
  require(exported==set(P),'MARKDOWN_INTAKE_POPULATION')
  passed('Exact mandatory inventory and report/intake counts',{'mandatory_files':len(REQUIRED),'markdown_intake_rows':len(exported)})
  mf=get('FROZEN_MANIFEST');inv=mf['payload_inventory']
  actualmembers={f.relative_to(root).as_posix() for f in root.rglob('*') if f.is_file()}
  expectedmembers={i['filename'] for i in inv}|{'EVOLVED_SSS_FROZEN_MANIFEST.json'}
  require(actualmembers==expectedmembers,'OUTPUT_EXACT_INVENTORY')
  require(len(inv)==len({i['filename'] for i in inv}),'DUPLICATE_MANIFEST_PATH')
  for i in inv:
   b=(root/i['filename']).read_bytes();require(len(b)==i['bytes'] and sha(b)==i['sha256'],'OUTPUT_PAYLOAD_HASH_'+i['filename'])
  passed('Exact output payload inventory and SHA-256 correspondence',{'files':len(actualmembers),'hashed_payloads':len(inv),'manifest_self_hash':'excluded to avoid circularity'})
 return {'revision':'SSS-2026-09-06-r1','result':'PASS','stage':stage,'checks_passed':len(checks),'checks_failed':0,'checks':checks,'negative_control_mutations':mutation_results,
    'independence_boundary':'Separately implemented read-only checking process; no authoring-module imports. Semantic judgments and adversarial readback are by the same executor, not a second scholar/agent. Custody and machine consistency do not certify scholarly truth.',
    'semantic_review_required':'The authored crosswalk remains a finite guarded semantic interpretation, not a theorem that all possible relations were discovered.'}

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('root',type=pathlib.Path);ap.add_argument('--stage',choices=['core','full'],default='full');ap.add_argument('--out',type=pathlib.Path);args=ap.parse_args()
 try:r=verify(args.root,args.stage)
 except Exception as e:
  print(json.dumps({'result':'FAIL','error_type':type(e).__name__,'error':str(e)},indent=2));raise
 if args.out:args.out.write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({'result':r['result'],'checks_passed':r['checks_passed'],'stage':r['stage'],'mutations_rejected':len(r['negative_control_mutations'])}))
