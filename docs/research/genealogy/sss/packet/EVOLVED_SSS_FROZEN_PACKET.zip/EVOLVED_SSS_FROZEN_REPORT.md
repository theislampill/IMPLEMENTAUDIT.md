# Evolved-SSS — Frozen three-lineage synthesis
**Revision:** `SSS-2026-09-06-r1`  
**Inherited research cut-off:** 6 September 2026  
**Object:** intra-trifecta crosswalk and guarded composition of three frozen studies.
## 1. Substantive result

Evolved-SSS is a structured analytical composition of the frozen Evolved Software Architecture (ESA), canonical Evolved Software Maintenance and Evolution (ESME), and Evolved Software Product Line Engineering (ESPLE) studies. The underlying software-engineering fields have established research traditions; the “Evolved” studies and this SSS composition are analytical reconstructions, not a claim that a historical school called Evolved-SSS already exists.

The result is **235 unchanged inherited property rows, explicit cross-lineage relations, preserved tensions and alternative arrangements, and zero additional SSS-induced property rows**. Zero is the adjudicated novelty result, not an omission of the mandatory emergence search. Fourteen candidates were examined, including all ten required questions and four adversarial extensions. They resolve into already inherited criteria, guarded conjunctions and scope refinements, provenance metadata, or unsupported stronger capability/entailment claims. No candidate met the requirement of being distinct from every sufficient inherited property while retaining a valid local-satisfaction failure witness.

The main substantive gain is a cross-boundary account of *which actual objects, populations, assumptions, evidence, obligations and authorities must meet*. An architectural model is not a delivered product. A valid configuration is not its generator’s correctness. A successful maintenance transformation is not proof that a supported older product can survive the mixed deployment. A local review is not permission to alter another product’s obligations. These distinctions become explicit relations and failure tests rather than being left to a reader to infer from three separate packets.

The strongest recurring structure is: identify the real architectural and configuration dimensions; carry them into the existing change/evidence/obligation criteria; preserve scoped decision rights; observe relevant consequences; revise, constrain, repair, decline, continue without change or retire as justified. That structure is not a compulsory lifecycle sequence. It does not make all 235 rows active controls, appoint a universal owner, require a product line, or establish an empirically superior universal methodology.

**Source locator convention.** A qualified property key in this report points to `EVOLVED_SSS_CONSTITUENT_PROPERTY_REGISTER.json` and its exact `original_record`, frozen ZIP/JSON pointer, source IDs and claim/access account. A relation, cluster, tension or candidate ID points to the corresponding SSS ledger. The original ZIPs are preserved byte-for-byte under `frozen_inputs/`. These are the research authorities; no fresh literature search or source access was performed.
## 2. Verified inputs and conserved populations

| Lineage | Frozen revision | ZIP bytes | Properties | Source rows |
|---|---|---:|---:|---:|
| ESA | `ESA-2026-09-06-r1` | 306,979 | 68/68 | 66/66 |
| ESME | `ESME-CANONICAL-R1-2026-09-06` | 3,727,653 | 105/105 | 106/106 |
| ESPLE | `ESPLE-2026-09-06-r1` | 352,196 | 62/62 | 45/45 |

**ESA SHA-256:** `26ec0f2bf1c016d7772b9f041aa34c5cbe463762f62e63c6ece486a762e135e0`. Its ZIP integrity, exact member inventory and all manifest-listed payload hashes were checked against the actual bytes.

**ESME SHA-256:** `9c5653e02d680aea0bb40904fe29251c46e279b281bc53f142613d3ab9a40468`. Its ZIP integrity, exact member inventory and all manifest-listed payload hashes were checked against the actual bytes.

**ESPLE SHA-256:** `814c571bd10724eb197b3a8c15a007338b5774bdfc23147342957231295c3188`. Its ZIP integrity, exact member inventory and all manifest-listed payload hashes were checked against the actual bytes.

The inherited denominator is **68 + 105 + 62 = 235**, with no missing, deleted or renumbered row. ESME’s 98-row and 74-row predecessor executions remain reconciliation ancestry inside its original canonical packet; they are not additional SSS lineages or populations. Its inherited source denominator is 106, not the sum of predecessor and canonical bibliographies.

The exact local ESME IDs are `ESME-C001` through `ESME-C105`; the qualified keys therefore take the form `ESME:ESME-C001`. Prompt shorthand is not used to invent replacement canonical IDs. Original property wording, dispositions, examination states, access ceilings and criticism are preserved. Normalised fields are labelled projections: ESA and ESPLE lack a separate general `CRITERION` field, so their exact mechanism is projected, not silently rewritten. ESA’s reopening condition is explicitly **not** treated as synonymous with retirement. Full source records remain available whenever a short normalised field is insufficient.

Beyond the two primary denominators, the packet explicitly conserves **201 within-lineage relation rows, 22 inherited alternative configurations, 73 inherited criticisms, 31 inherited internal tensions, 14 inherited open composition questions and 29 mandatory-family records**. These are ancestry, not new SSS relation/property counts. ESME’s four surviving within-lineage induced properties, C102–C105, remain inside its 105 inherited rows, not in the SSS-E namespace. Their unchanged provenance and analytical evidence status are retained.

Three canonical ESME cheap-path prose references have potentially ambiguous shorthand (C067, C080 and C097). Their text is preserved and flagged in the inherited-boundary ledger. No intended destination is silently substituted; the explicit criterion and validated structured references, not an invented correction, govern this synthesis. This is a source-locator limitation, not permission to reopen the predecessor reconciliation or change the denominator.
## 3. Pair universe, relation method and evidential meaning

| Cross-lineage universe | Material bucket | No material relation established | Unresolved stronger relation | Total |
|---|---:|---:|---:|---:|
| ESA × ESME | 1,164 | 5,973 | 3 | 7,140 |
| ESA × ESPLE | 960 | 3,255 | 1 | 4,216 |
| ESME × ESPLE | 1,415 | 5,092 | 3 | 6,510 |
| **Total** | **3,539** | **14,320** | **7** | **17,866** |

Every unordered pair has an explicit JSON row; no implicit missing cell stands in for a judgment. The seven unresolved pair summaries take precedence over the material bucket. Five of them also retain established boundary/analogy relations. Thus 3,539 is the exclusive material-bucket count, not the number of every pair carrying any known boundary. There are **6,832 directional records: 6,825 material records and seven unresolved records**. A pair may carry multiple directions or kinds, and symmetric relations have explicit reverse records. Pair counts and directed-record counts must not be added or substituted for one another.

The comparison is semantic and finite. The property records were organised into analyst-authored junctions by criterion, object/bearer, mechanism, failure, trigger and cheaper path, assumptions, outputs/consumers, authority, evidence and criticism. Thirty-six individually specified directional refinements and sixteen tension adjudications supplement the junction rules; resolved shared-source uses add ancestry relations. Deterministic expansion produces the full matrix and exact reverse indices. A separately implemented checker reconstructs the same relation signatures and pair statuses from those declared rules without importing the authoring module.

This is **not** title similarity, embedding similarity or a claim of 17,866 independent empirical investigations. A material relation is a specified guarded conceptual relation, not necessarily equivalence, causation, implementation sharing or logical sufficiency. A many-to-one junction permits paired membership comparisons without asserting that each member’s mechanism performs every other member’s job. The exact endpoint semantics remain in each relation record. The semantic/adversarial review also records ten representative no-material cells with pair-specific reasons.

`NO_MATERIAL_RELATION` means that no additional direct relation is established under this declared frozen comparison. It is not a theorem that the pair can never interact in any possible system. A later specific semantic counterexample can warrant revisiting the relation. Exhaustive matrix accounting and independent execution checking do not turn a finite scholarly interpretation into an oracle for every conceivable relation.

Negative rows require particular care. The retained lesson of a rejected universal claim can constrain a positive mechanism; that does not endorse the rejected claim. For example, rejecting “feature-model satisfiability implies product correctness” reinforces architecture’s rejection of description conformance as quality certification, while preserving legitimate satisfiability and description checks. Open automation rows supply no general capability premise merely because they are paired with established bounded mechanisms. These are active boundaries, not discarded rows.

### Selected explicitly directional findings
**SSS-R00267:** `ESA:ESA-010` **SUPPLIES_INPUT_FOR** `ESME:ESME-C025`. Typed architectural relations identify dependency kinds that change-impact propagation must distinguish; the existence and relevance of each edge still need evidence.

**SSS-R05020:** `ESPLE:ESPLE-014` **SUPPLIES_INPUT_FOR** `ESME:ESME-C025`. Feature-to-realisation mappings expose generator, build and shared implementation paths missing from a code-only change boundary.

**SSS-R02659:** `ESME:ESME-C025` **SUPPLIES_INPUT_FOR** `ESPLE:ESPLE-032`. Typed actual-change propagation supplies candidate affected products; family support scope decides which need action.

**SSS-R05210:** `ESPLE:ESPLE-021` **SUPPLIES_SCOPE_FOR** `ESA:ESA-038`. Configuration/asset/tool identity supplies the realised-product scope of an architectural conformance observation.

**SSS-R00653:** `ESA:ESA-021` **PROVIDES_PRECONDITION_FOR** `ESPLE:ESPLE-023`. A model-level architectural claim cannot transfer to a product before the consequential correspondence has been checked.

**SSS-R05257:** `ESPLE:ESPLE-023` **CONSTRAINS** `ESA:ESA-022`. Family use may not extend a formal architectural result beyond its quantified configurations, assumptions and realisation mapping.

**SSS-R04460:** `ESME:ESME-C103` **CONSTRAINS** `ESA:ESA-033`. Decision reopening must narrow the dependent operative claim when its evidence assumptions fail; merely marking the decision old is insufficient.

**SSS-R04481:** `ESME:ESME-C103` **CONSTRAINS** `ESPLE:ESPLE-035`. Repaired configuration validity does not retain behavioural-oracle evidence whose relevant assumptions changed.

**SSS-R05879:** `ESPLE:ESPLE-035` **SUPPLIES_INPUT_FOR** `ESME:ESME-C040`. Changed permissible test configurations provide selection-envelope information; test-selection soundness still uses its own dependency assumptions.

**SSS-R04490:** `ESME:ESME-C104` **CONSTRAINS** `ESA:ESA-044`. New mixed architecture/data/runtime states need obligation evidence or prevention; endpoint success does not discharge the path.

**SSS-R04506:** `ESME:ESME-C104` **CONSTRAINS** `ESPLE:ESPLE-031`. A permitted new configuration cannot license unsupported intermediate combinations created by migration.

**SSS-R03223:** `ESME:ESME-C049` **CONSTRAINS** `ESPLE:ESPLE-044`. A safe transition must not consume a promised recovery route without feasible replacement or legitimate residual-loss acceptance.

**SSS-R00227:** `ESA:ESA-008` **SUPPLIES_INPUT_FOR** `ESPLE:ESPLE-044`. Interface state, ordering and side-effect assumptions identify obligations the dynamic transition must preserve.

**SSS-R06214:** `ESPLE:ESPLE-044` **SUPPLIES_INPUT_FOR** `ESA:ESA-047`. Actually feasible state-transfer and activation paths supply transition evidence for architecture-level post-change assurance.

**SSS-R00113:** `ESA:ESA-005` **SUPPLIES_AUTHORITY_CONSTRAINT_FOR** `ESPLE:ESPLE-039`. A shared-asset decision that changes a consequential architecture trade-off must retain the affected parties' real decision rights, not create an overriding family owner.

**SSS-R06066:** `ESPLE:ESPLE-039` **SUPPLIES_AUTHORITY_CONSTRAINT_FOR** `ESME:ESME-C071`. Shared-asset contribution and release rights constrain which maintainer can resolve a cross-product request.

**SSS-R04242:** `ESME:ESME-C094` **CONSTRAINS** `ESA:ESA-054`. Checked architectural suggestions do not grant permission to alter code, deployment or external state.

**SSS-R04263:** `ESME:ESME-C094` **CONSTRAINS** `ESPLE:ESPLE-047`. Accepted generated migration advice remains within actual delegated object and action authority.

**SSS-R03392:** `ESME:ESME-C058` **CONSTRAINS** `ESA:ESA-044`. Architecture migration completion must account for residual consumers, data authority and recovery use of temporary paths.

**SSS-R06783:** `ESPLE:ESPLE-061` **SUPPLIES_SCOPE_FOR** `ESME:ESME-C058`. Older supported products can remain consumers of a scaffold even after variability is closed to new products.

**SSS-R04534:** `ESME:ESME-C105` **CONSTRAINS** `ESA:ESA-056`. Local proportionality must be assessed as part of the actual combined inquiry/validation/coordination burden, without losing live protection.

**SSS-R04554:** `ESME:ESME-C105` **CONSTRAINS** `ESPLE:ESPLE-039`. A separately defensible family governance action does not justify redundant or conflicting combined controls.

**SSS-R00491:** `ESA:ESA-017` **SUPPLIES_INPUT_FOR** `ESPLE:ESPLE-036`. Architecture supplies hard quality limits and sacrifices that a lifecycle economic comparison must not average away.

**SSS-R03548:** `ESME:ESME-C064` **SUPPLIES_INPUT_FOR** `ESPLE:ESPLE-036`. Intervention, validation, disruption and future-support costs supply lifecycle scenario inputs, not a universal return estimate.

**SSS-R05914:** `ESPLE:ESPLE-036` **SUPPLIES_INPUT_FOR** `ESA:ESA-029`. Product population, reuse horizon and support scenarios can change the ranking of feasible architectural alternatives.

**SSS-R00162:** `ESA:ESA-007` **REINFORCES** `ESPLE:ESPLE-019`. Information hiding can support a stable architectural substitution boundary when the predicted variation and interface assumptions actually hold.

**SSS-R04730:** `ESPLE:ESPLE-006` **INTENTIONAL_ASYMMETRY** `ESA:ESA-004`. A supported product exception may use a different implementation without defeating required conceptual integrity; uniformity is not the common criterion.

**SSS-R02052:** `ESA:ESA-068` **ANALOGOUS_NOT_EQUIVALENT** `ESPLE:ESPLE-045`. Wright connector deadlock freedom under conservatism/compatibility is not supervisory nonblocking under plant controllability/observability, and neither establishes inevitable global progress.

**SSS-R01930:** `ESA:ESA-063` **REINFORCES** `ESME:ESME-C098`. Revising the observer, policy or acceptance method must not allow the successor mechanism to authorise or certify itself circularly.

**SSS-R06483:** `ESPLE:ESPLE-052` **REINFORCES** `ESA:ESA-059`. Both retain a negative inference boundary between representation-level success and delivered-system quality; neither rejects the valid lower-layer result.

**SSS-R06515:** `ESPLE:ESPLE-053` **REINFORCES** `ESME:ESME-C045`. Coverage of a selected set is not arbitrary behaviour correctness; oracle and unexamined interactions remain distinct limitations.

**SSS-R01252:** `ESA:ESA-041` **REINFORCES** `ESME:ESME-C016`. Recovered structure needs independent domain/person/history corroboration before being presented as intended design.

**SSS-R06676:** `ESPLE:ESPLE-058` **REINFORCES** `ESME:ESME-C027`. Stable labels or sets do not establish semantic compatibility of supported observers.

**SSS-R01604:** `ESA:ESA-053` **SUPPLIES_INPUT_FOR** `ESME:ESME-C091`. Architectural data, training/serving and hidden-consumer dependencies identify consequential maintenance artefacts beyond source code.

**SSS-R06803:** `ESPLE:ESPLE-062` **CONSTRAINS** `ESA:ESA-047`. Static feature binding alone cannot be used as proof of environment-independent operation or safe adaptation.

**SSS-R03848:** `ESME:ESME-C076` **PROVIDES_PRECONDITION_FOR** `ESPLE:ESPLE-033`. Where independent product schedules require consumer action, support relationships are not operable until recipients can determine and take that action.

## 4. Convergence and one-to-many composition

There are **34 clusters: 23 many-to-one conceptual convergences and 11 one-to-many realisations**. The former preserve the distinct rows even when one later mechanism might discharge several concerns. The latter specify a conditional functional cover, its scope, missing-function failures and a cheaper path. They do not prove a unique cardinality-minimal implementation or make every listed property irreplaceable. No shared implementation owner is inferred.

The complete membership, original endpoint distinctions, relation references and functional-cover records are machine-readable. The following is the interpretation of each cluster; it is not a list of mandatory controls.
### SSS-K001 — Consequential scope and legitimate product intent

**Many To One Convergence.** Determine the object and obligations to which a proposed decision actually applies. Use concrete affected concerns, intended effects, artefacts and consumers rather than a discipline or category label.

**Guard:** A consequential architectural, maintenance or family-boundary decision is actually being made; a taxonomy alone activates nothing. **Preserved distinction:** Architectural significance is not maintenance-purpose classification, and neither supplies a warranted family boundary.

**Members:** `ESA:ESA-001`, `ESA:ESA-002`, `ESA:ESA-006`, `ESME:ESME-C001`, `ESME:ESME-C002`, `ESME:ESME-C003`, `ESME:ESME-C007`, `ESPLE:ESPLE-001`, `ESPLE:ESPLE-002`, `ESPLE:ESPLE-008`, `ESPLE:ESPLE-042`.

### SSS-K002 — Identity across descriptions, interventions and derivations

**One To Many Realisation.** Prevent a claim about one baseline or representation from being consumed for a different realised subject. Relate the relevant architectural mapping, exact maintenance candidate and configuration/asset/tool inputs.

**Guard:** Evidence or artefacts cross a representation, build or action boundary; irrelevant input changes need not trigger revalidation. **Preserved distinction:** A description identity, a source baseline, a derivation recipe and a delivered product remain different objects.

**Members:** `ESA:ESA-003`, `ESA:ESA-021`, `ESA:ESA-038`, `ESME:ESME-C005`, `ESME:ESME-C046`, `ESME:ESME-C102`, `ESPLE:ESPLE-020`, `ESPLE:ESPLE-021`, `ESPLE:ESPLE-022`, `ESPLE:ESPLE-028`.

**Conditional functional cover:** `ESA:ESA-021`: Identify the consequential architecture-description/realisation correspondence.; `ESME:ESME-C102`: Bind the evidence actually consumed and action taken to the scoped candidate and obligations.; `ESPLE:ESPLE-021`: Identify selected configuration, shared assets and tools for the realised product.

**Cheaper/non-trigger path:** One directly inspected artefact can discharge several functions. When no relevant derivation or action occurs, omit that function rather than inventing a family lifecycle.

### SSS-K003 — Semantic obligations across interfaces

**Many To One Convergence.** The meaning and interaction assumptions on both sides of a consequential boundary must fit. Expose state, ordering, data meaning and permitted substitutions; establish only the selected contract or formal claim.

**Guard:** The particular interface, translation or formalism is used by the product; REST and Wright are never mandatory. **Preserved distinction:** Architecture interaction, supported-observer compatibility, schema meaning and feature contracts have different bearers and theorem assumptions.

**Members:** `ESA:ESA-008`, `ESA:ESA-009`, `ESA:ESA-061`, `ESA:ESA-065`, `ESA:ESA-066`, `ESA:ESA-068`, `ESME:ESME-C026`, `ESME:ESME-C030`, `ESME:ESME-C055`, `ESME:ESME-C056`, `ESPLE:ESPLE-008`, `ESPLE:ESPLE-012`, `ESPLE:ESPLE-019`, `ESPLE:ESPLE-027`, `ESPLE:ESPLE-046`.

### SSS-K004 — Typed cross-boundary impact

**One To Many Realisation.** A change can escape a local analysis through dependency kinds or configuration mappings that local evidence omits. Combine justified dependency kinds, relevant comprehension and feature/build-to-realisation links; challenge consequential missing edges.

**Guard:** An actual change or design-change scenario can affect another obligation; proven local independence admits local review. **Preserved distinction:** Static slices, executed traces, co-change, architectural uses and feature mappings are not interchangeable edge types.

**Members:** `ESA:ESA-007`, `ESA:ESA-010`, `ESA:ESA-011`, `ESA:ESA-027`, `ESME:ESME-C013`, `ESME:ESME-C014`, `ESME:ESME-C015`, `ESME:ESME-C020`, `ESME:ESME-C022`, `ESME:ESME-C023`, `ESME:ESME-C024`, `ESME:ESME-C025`, `ESPLE:ESPLE-014`, `ESPLE:ESPLE-024`, `ESPLE:ESPLE-029`, `ESPLE:ESPLE-032`, `ESPLE:ESPLE-034`.

**Conditional functional cover:** `ESA:ESA-010`: Distinguish the architectural uses/interface dependency that crosses the selected boundary.; `ESME:ESME-C022`: Reopen the actual impact scope when a consequential escape is exposed.; `ESME:ESME-C025`: Represent the justified change-propagating dependency kinds.; `ESPLE:ESPLE-014`: Resolve the selected feature-to-realisation mapping.

**Cheaper/non-trigger path:** For a proven local change, direct code/consumer inspection may supply the necessary path evidence; there is no universal whole-family graph.

### SSS-K005 — Warranted commonality and anticipatory flexibility

**Many To One Convergence.** Shared production and hidden variation need credible consumers rather than speculative universality. Examine commonality, plausible variation and its support burden against independent products or selective reuse.

**Guard:** Shared assets or future flexibility are being considered, not merely a single implementation with parameters. **Preserved distinction:** Architectural family constructibility is not a product-line economic case or a maintenance support promise.

**Members:** `ESA:ESA-007`, `ESA:ESA-013`, `ESA:ESA-049`, `ESME:ESME-C029`, `ESME:ESME-C052`, `ESME:ESME-C064`, `ESME:ESME-C065`, `ESPLE:ESPLE-001`, `ESPLE:ESPLE-002`, `ESPLE:ESPLE-003`, `ESPLE:ESPLE-007`, `ESPLE:ESPLE-036`, `ESPLE:ESPLE-037`, `ESPLE:ESPLE-050`, `ESPLE:ESPLE-057`.

### SSS-K006 — Quality criteria and selected populations

**Many To One Convergence.** An acceptable result is relative to real concerns, observers, configurations and hard constraints. Use explicit response conditions and representative product/maintenance scenarios; keep sacrifices and excluded populations visible.

**Guard:** A quality or benefit claim supports a consequential choice; small concrete examples may discharge the concern. **Preserved distinction:** Architectural response measures, maintenance-task outcomes and family coverage cannot be added into a universal quality score.

**Members:** `ESA:ESA-014`, `ESA:ESA-015`, `ESA:ESA-016`, `ESA:ESA-017`, `ESA:ESA-018`, `ESA:ESA-019`, `ESA:ESA-028`, `ESA:ESA-030`, `ESA:ESA-062`, `ESME:ESME-C030`, `ESME:ESME-C034`, `ESME:ESME-C035`, `ESME:ESME-C038`, `ESME:ESME-C039`, `ESPLE:ESPLE-010`, `ESPLE:ESPLE-023`, `ESPLE:ESPLE-024`, `ESPLE:ESPLE-025`, `ESPLE:ESPLE-028`, `ESPLE:ESPLE-036`.

### SSS-K007 — Model, tool and actual-product assurance layers

**One To Many Realisation.** A valid representation or successful analysis is not automatically a valid realised system. Keep model adequacy, encoding/engine validity, correspondence and actual-subject evidence separate.

**Guard:** A view, solver, generator or transformation is being used as evidence beyond its own object. **Preserved distinction:** Description conformance, SAT, engine tests and product acceptance establish different claims.

**Members:** `ESA:ESA-003`, `ESA:ESA-020`, `ESA:ESA-021`, `ESA:ESA-022`, `ESA:ESA-024`, `ESA:ESA-031`, `ESA:ESA-038`, `ESA:ESA-059`, `ESME:ESME-C016`, `ESME:ESME-C017`, `ESME:ESME-C018`, `ESME:ESME-C021`, `ESME:ESME-C032`, `ESME:ESME-C033`, `ESME:ESME-C039`, `ESME:ESME-C045`, `ESPLE:ESPLE-009`, `ESPLE:ESPLE-010`, `ESPLE:ESPLE-017`, `ESPLE:ESPLE-023`, `ESPLE:ESPLE-028`, `ESPLE:ESPLE-046`, `ESPLE:ESPLE-051`, `ESPLE:ESPLE-052`.

**Conditional functional cover:** `ESA:ESA-021`: Check the architecture assertion against the realised structure.; `ESME:ESME-C033`: Validate the actual transformed candidate rather than only its rule or tool.; `ESPLE:ESPLE-028`: Accept the delivered derived product under its selected obligations.

**Cheaper/non-trigger path:** A simple single product may have one artefact and one direct check. Extra layers are omitted when they are not distinct consequential claims.

### SSS-K008 — Useful rationale and reconstructible knowledge

**Many To One Convergence.** Later consumers need useful reasons and checked relationships, not document volume or fabricated historical intent. Retain a small accessible explanation with its baseline, uncertainty and reopening condition.

**Guard:** Loss or disagreement of knowledge can change an actual future decision; unconsumed documentation may be omitted. **Preserved distinction:** Present justification, historical evidence, recovered structure, feature meaning and a maintenance handover are distinct.

**Members:** `ESA:ESA-020`, `ESA:ESA-023`, `ESA:ESA-032`, `ESA:ESA-033`, `ESA:ESA-037`, `ESA:ESA-041`, `ESA:ESA-064`, `ESME:ESME-C016`, `ESME:ESME-C017`, `ESME:ESME-C019`, `ESME:ESME-C021`, `ESME:ESME-C070`, `ESPLE:ESPLE-002`, `ESPLE:ESPLE-005`, `ESPLE:ESPLE-014`, `ESPLE:ESPLE-018`, `ESPLE:ESPLE-034`, `ESPLE:ESPLE-051`.

### SSS-K009 — Authority is not evidence or tooling

**Many To One Convergence.** Knowing, proposing, accepting evidence and executing an effect do not automatically convey one another's decision rights. Retain existing scoped decision rights and negotiated obligations at the consequential handoff.

**Guard:** A decision affects another actor, product, baseline or external state; one authorised actor can discharge several functions. **Preserved distinction:** Architecture trade-off authority, maintenance action authority and shared-asset arbitration remain context-supplied, not merged into a new owner.

**Members:** `ESA:ESA-005`, `ESA:ESA-035`, `ESA:ESA-039`, `ESA:ESA-042`, `ESA:ESA-048`, `ESA:ESA-063`, `ESME:ESME-C001`, `ESME:ESME-C038`, `ESME:ESME-C071`, `ESME:ESME-C094`, `ESME:ESME-C096`, `ESME:ESME-C097`, `ESME:ESME-C098`, `ESME:ESME-C101`, `ESPLE:ESPLE-004`, `ESPLE:ESPLE-006`, `ESPLE:ESPLE-039`, `ESPLE:ESPLE-041`, `ESPLE:ESPLE-042`, `ESPLE:ESPLE-047`, `ESPLE:ESPLE-060`.

### SSS-K010 — Practical capacity and coordination

**Many To One Convergence.** Responsibility must remain actionable with willing capacity and adequate cross-boundary communication. Match accepted shared work and dependent decisions to actual capability; resolve conflicts without prescribing team topology.

**Guard:** Cross-team dependencies, turnover or shared-product demand threaten delivery or support. **Preserved distinction:** Conceptual integrity is not centralised staffing; a knowledge metric and an organisation chart do not prove capacity.

**Members:** `ESA:ESA-004`, `ESA:ESA-012`, `ESA:ESA-034`, `ESA:ESA-035`, `ESA:ESA-036`, `ESME:ESME-C004`, `ESME:ESME-C011`, `ESME:ESME-C012`, `ESME:ESME-C066`, `ESME:ESME-C071`, `ESME:ESME-C072`, `ESME:ESME-C073`, `ESPLE:ESPLE-004`, `ESPLE:ESPLE-039`, `ESPLE:ESPLE-040`, `ESPLE:ESPLE-041`.

### SSS-K011 — Lifecycle alternatives, cost bearers and uncertainty

**Many To One Convergence.** A locally attractive decision can shift unacceptable cost or violate a population-specific obligation. Compare feasible alternatives over the relevant horizon, respect hard constraints, and expose uncertainty and who bears costs.

**Guard:** Investment, continuation or retirement depends on expected value; qualitative comparison is legitimate. **Preserved distinction:** Architecture quality, maintenance effort, variability economics and sustainability boundaries are separate inputs, not additive independent benefits.

**Members:** `ESA:ESA-017`, `ESA:ESA-026`, `ESA:ESA-029`, `ESA:ESA-043`, `ESA:ESA-049`, `ESA:ESA-055`, `ESA:ESA-056`, `ESME:ESME-C034`, `ESME:ESME-C051`, `ESME:ESME-C052`, `ESME:ESME-C062`, `ESME:ESME-C064`, `ESME:ESME-C065`, `ESME:ESME-C066`, `ESME:ESME-C067`, `ESME:ESME-C068`, `ESME:ESME-C069`, `ESME:ESME-C081`, `ESME:ESME-C105`, `ESPLE:ESPLE-003`, `ESPLE:ESPLE-007`, `ESPLE:ESPLE-036`, `ESPLE:ESPLE-037`, `ESPLE:ESPLE-038`, `ESPLE:ESPLE-049`, `ESPLE:ESPLE-057`, `ESPLE:ESPLE-059`, `ESPLE:ESPLE-061`.

### SSS-K012 — Preservation and deliberate revision

**Many To One Convergence.** Preserve legitimate observer obligations while permitting authorised changes; historical equality is not the objective. Separate observed behaviour, intended differences and surviving promises; test the relevant actual interactions.

**Guard:** A changed model, interface, constraint or implementation is accepted or rejected on compatibility grounds. **Preserved distinction:** A stable name, unchanged feature-set language or historic architecture does not establish behavioural compatibility.

**Members:** `ESA:ESA-008`, `ESA:ESA-038`, `ESA:ESA-039`, `ESA:ESA-042`, `ESME:ESME-C001`, `ESME:ESME-C026`, `ESME:ESME-C027`, `ESME:ESME-C030`, `ESME:ESME-C037`, `ESME:ESME-C038`, `ESME:ESME-C097`, `ESPLE:ESPLE-006`, `ESPLE:ESPLE-027`, `ESPLE:ESPLE-028`, `ESPLE:ESPLE-030`, `ESPLE:ESPLE-031`, `ESPLE:ESPLE-058`.

### SSS-K013 — Migration, coexistence and reachable states

**One To Many Realisation.** Valid endpoints do not discharge the obligations of reachable mixed states or temporary paths. Inspect transfer seams, conversion semantics, supported version/configuration combinations and remaining repair routes.

**Guard:** Migration or reconfiguration creates consequential intermediate states; a justified atomic switch can remove them. **Preserved distinction:** Architecture consolidation, maintenance data transfer and configuration migration have different costs and authorities.

**Members:** `ESA:ESA-009`, `ESA:ESA-044`, `ESA:ESA-051`, `ESME:ESME-C049`, `ESME:ESME-C052`, `ESME:ESME-C053`, `ESME:ESME-C054`, `ESME:ESME-C055`, `ESME:ESME-C056`, `ESME:ESME-C057`, `ESME:ESME-C058`, `ESME:ESME-C059`, `ESME:ESME-C061`, `ESME:ESME-C104`, `ESPLE:ESPLE-006`, `ESPLE:ESPLE-007`, `ESPLE:ESPLE-016`, `ESPLE:ESPLE-031`, `ESPLE:ESPLE-033`, `ESPLE:ESPLE-044`, `ESPLE:ESPLE-061`.

**Conditional functional cover:** `ESA:ESA-044`: Expose the actual architectural coexistence seam and compatibility assumptions.; `ESME:ESME-C104`: Adjudicate or prevent newly reachable consequential joint states.; `ESPLE:ESPLE-033`: Identify the supported release/configuration population that may coexist.

**Cheaper/non-trigger path:** A justified quiescent cutover or unsupported-product exclusion can remove joint states; validate that exclusion instead of implementing universal coexistence machinery.

### SSS-K014 — Observation, feedback and revision

**Many To One Convergence.** Changed observations can reopen assumptions rather than merely report a score. Return a scoped observation to an actor able to change the relevant decision, evidence claim, constraint or support choice.

**Guard:** A material observation or assumption change can alter justified action; no fixed feedback cadence follows. **Preserved distinction:** Product-to-core feedback, architectural fitness checks, regression feedback and distribution drift have different signals and consumers.

**Members:** `ESA:ESA-018`, `ESA:ESA-033`, `ESA:ESA-039`, `ESA:ESA-045`, `ESA:ESA-046`, `ESA:ESA-063`, `ESME:ESME-C008`, `ESME:ESME-C022`, `ESME:ESME-C047`, `ESME:ESME-C048`, `ESME:ESME-C092`, `ESME:ESME-C098`, `ESME:ESME-C103`, `ESPLE:ESPLE-005`, `ESPLE:ESPLE-030`, `ESPLE:ESPLE-032`, `ESPLE:ESPLE-035`, `ESPLE:ESPLE-038`, `ESPLE:ESPLE-043`.

### SSS-K015 — Selective evidence applicability and invalidation

**One To Many Realisation.** Evidence is reusable only for the subject, assumptions and claim it actually supports. Relate architectural mapping and observer assumptions to candidate/build/configuration identity; invalidate dependent claims without discarding unaffected results.

**Guard:** An applicable baseline, selection, generator, observer, environment, tool or obligation changes while evidence is reused. **Preserved distinction:** The validity index supplies arguments to inherited invalidation; stronger support in another lineage does not upgrade a local evidence ceiling.

**Members:** `ESA:ESA-015`, `ESA:ESA-018`, `ESA:ESA-021`, `ESA:ESA-022`, `ESA:ESA-030`, `ESA:ESA-033`, `ESA:ESA-045`, `ESA:ESA-054`, `ESA:ESA-063`, `ESME:ESME-C005`, `ESME:ESME-C025`, `ESME:ESME-C032`, `ESME:ESME-C033`, `ESME:ESME-C039`, `ESME:ESME-C040`, `ESME:ESME-C046`, `ESME:ESME-C084`, `ESME:ESME-C085`, `ESME:ESME-C088`, `ESME:ESME-C091`, `ESME:ESME-C092`, `ESME:ESME-C093`, `ESME:ESME-C102`, `ESME:ESME-C103`, `ESPLE:ESPLE-017`, `ESPLE:ESPLE-021`, `ESPLE:ESPLE-023`, `ESPLE:ESPLE-025`, `ESPLE:ESPLE-026`, `ESPLE:ESPLE-027`, `ESPLE:ESPLE-028`, `ESPLE:ESPLE-029`, `ESPLE:ESPLE-035`, `ESPLE:ESPLE-047`.

**Conditional functional cover:** `ESA:ESA-033`: Expose the architectural claim whose rationale or assumptions have aged.; `ESME:ESME-C103`: Narrow/revalidate dependent evidence when a relevant premise changes, retaining unaffected claims.; `ESPLE:ESPLE-021`: Distinguish configuration, asset and tool baselines that index the claim.

**Cheaper/non-trigger path:** When the changed input is demonstrably irrelevant to a claim, retain that evidence. A small explicit assumption note may replace a registry.

### SSS-K016 — Structural intervention versus actual benefit

**Many To One Convergence.** A structural label, metric improvement or more reuse does not by itself justify intervention. Connect the selected structural mechanism to an actual task, quality or product-production consequence and a cheaper alternative.

**Guard:** Refactoring, decomposition, consolidation or variability restructuring is justified by its claimed payoff. **Preserved distinction:** Service count, catalogue compliance and configuration count are distinct proxies; their common limitation does not make the mechanisms equivalent.

**Members:** `ESA:ESA-025`, `ESA:ESA-040`, `ESA:ESA-043`, `ESA:ESA-050`, `ESA:ESA-051`, `ESA:ESA-058`, `ESME:ESME-C034`, `ESME:ESME-C035`, `ESME:ESME-C036`, `ESME:ESME-C059`, `ESME:ESME-C060`, `ESME:ESME-C062`, `ESME:ESME-C068`, `ESME:ESME-C069`, `ESPLE:ESPLE-007`, `ESPLE:ESPLE-015`, `ESPLE:ESPLE-037`, `ESPLE:ESPLE-038`, `ESPLE:ESPLE-050`, `ESPLE:ESPLE-057`, `ESPLE:ESPLE-059`.

### SSS-K017 — Reusable local proofs and composition premises

**One To Many Realisation.** Local results transfer only through discharged semantic and realisation premises. Check applicability, environment, interface assumptions and actual correspondence before reusing a proof or test result.

**Guard:** An acceptance argument composes local results; whole-product checks can be cheaper than reusable contracts. **Preserved distinction:** Wright connector deadlock freedom, transformation preservation, metamorphic relations and feature contracts use different semantics.

**Members:** `ESA:ESA-021`, `ESA:ESA-022`, `ESA:ESA-068`, `ESME:ESME-C030`, `ESME:ESME-C031`, `ESME:ESME-C032`, `ESME:ESME-C033`, `ESME:ESME-C039`, `ESME:ESME-C040`, `ESME:ESME-C044`, `ESPLE:ESPLE-017`, `ESPLE:ESPLE-023`, `ESPLE:ESPLE-026`, `ESPLE:ESPLE-027`, `ESPLE:ESPLE-028`.

**Conditional functional cover:** `ESA:ESA-068`: State the selected connector compatibility/well-formedness theorem and its assumptions.; `ESME:ESME-C031`: Check applicability of a relied-on transformation under its preconditions.; `ESPLE:ESPLE-027`: Check the premises needed to compose feature contracts for the realised product.

**Cheaper/non-trigger path:** This is one specific conditional cover, not a claim that Wright or formal feature contracts are mandatory. Direct product testing or another adequate proof can replace a local mechanism; different theorems cannot be fused without a mapping.

### SSS-K018 — Sampling, regression selection and oracle limits

**Many To One Convergence.** A selected scenario or test population must match the stated question and cannot certify every unexamined case. Select evidence by consequential interactions and budget, validate the oracle/harness, and expose exclusions.

**Guard:** Full applicable checking is costly or a sample is being used to support a wider claim. **Preserved distinction:** Test ordering is not test selection; configuration coverage is not an oracle; mutation and differential evidence remain scoped.

**Members:** `ESA:ESA-015`, `ESA:ESA-018`, `ESA:ESA-030`, `ESA:ESA-031`, `ESME:ESME-C010`, `ESME:ESME-C039`, `ESME:ESME-C040`, `ESME:ESME-C041`, `ESME:ESME-C042`, `ESME:ESME-C043`, `ESME:ESME-C044`, `ESME:ESME-C045`, `ESME:ESME-C084`, `ESPLE:ESPLE-023`, `ESPLE:ESPLE-024`, `ESPLE:ESPLE-025`, `ESPLE:ESPLE-026`, `ESPLE:ESPLE-035`, `ESPLE:ESPLE-053`.

### SSS-K019 — Concurrent change and joint interaction

**One To Many Realisation.** Changes that are acceptable in isolation can alter each other's assumptions when jointly effective. Check actual merged, ordered or interacting combinations; allow demonstrably disjoint work concurrently.

**Guard:** Independent edits, deltas, releases or runtime actions can interfere semantically. **Preserved distinction:** Textual merge, delta applicability, version skew and feature interaction are different sources of joint-state risk.

**Members:** `ESA:ESA-008`, `ESA:ESA-009`, `ESA:ESA-035`, `ESA:ESA-047`, `ESME:ESME-C022`, `ESME:ESME-C025`, `ESME:ESME-C028`, `ESME:ESME-C047`, `ESME:ESME-C057`, `ESME:ESME-C090`, `ESME:ESME-C104`, `ESPLE:ESPLE-016`, `ESPLE:ESPLE-024`, `ESPLE:ESPLE-027`, `ESPLE:ESPLE-032`, `ESPLE:ESPLE-033`, `ESPLE:ESPLE-044`.

**Conditional functional cover:** `ESA:ESA-008`: Expose the interaction/state assumptions at a consequential interface.; `ESME:ESME-C104`: Evaluate the reachable consequential combination of concurrent or staged changes.; `ESPLE:ESPLE-024`: Identify relevant feature interactions and the coverage boundary.

**Cheaper/non-trigger path:** Proven noninteraction, constrained release ordering or a direct combined check can discharge the need without exhaustive configuration enumeration.

### SSS-K020 — Runtime change, recovery and action envelopes

**One To Many Realisation.** Valid selected states and local improvements do not guarantee safe, authorised or recoverable transitions. Couple observations, permitted action, state/interface assumptions, actual actuation and the promised residual repair path.

**Guard:** Runtime variation or live adaptation is materially required and its operational envelope can be justified. **Preserved distinction:** Static feature validity, controller nonblocking, architectural compatibility and effect-aware recovery are not the same guarantee.

**Members:** `ESA:ESA-008`, `ESA:ESA-018`, `ESA:ESA-046`, `ESA:ESA-047`, `ESA:ESA-048`, `ESA:ESA-063`, `ESA:ESA-068`, `ESME:ESME-C006`, `ESME:ESME-C049`, `ESME:ESME-C055`, `ESME:ESME-C057`, `ESME:ESME-C061`, `ESME:ESME-C094`, `ESME:ESME-C098`, `ESME:ESME-C104`, `ESPLE:ESPLE-013`, `ESPLE:ESPLE-027`, `ESPLE:ESPLE-043`, `ESPLE:ESPLE-044`, `ESPLE:ESPLE-045`, `ESPLE:ESPLE-054`, `ESPLE:ESPLE-060`, `ESPLE:ESPLE-062`.

**Conditional functional cover:** `ESA:ESA-047`: Constrain actual adaptation and observe relevant post-change architectural effects.; `ESME:ESME-C049`: Establish feasible remaining recovery, forward repair or legitimate residual-loss acceptance.; `ESPLE:ESPLE-044`: Establish transition safety and state continuity for the dynamic configuration.

**Cheaper/non-trigger path:** A static product needs no dynamic-transition controller. Feasible authorised forward repair can substitute for reversal; imposing rollback universally is not warranted.

### SSS-K021 — Shared-asset responsibility and product autonomy

**One To Many Realisation.** Shared decisions affect product-specific obligations without automatically creating common decision authority. Identify affected products, responsible asset participants, practical support and a proportionate arbitration/exception path.

**Guard:** A shared asset or architecture decision crosses a product or organisational boundary. **Preserved distinction:** The same mechanism may inform several participants, but internal ownership, supplier control and autonomous product acceptance remain distinct.

**Members:** `ESA:ESA-005`, `ESA:ESA-012`, `ESA:ESA-013`, `ESA:ESA-034`, `ESA:ESA-035`, `ESME:ESME-C004`, `ESME:ESME-C066`, `ESME:ESME-C071`, `ESME:ESME-C072`, `ESME:ESME-C074`, `ESME:ESME-C075`, `ESME:ESME-C076`, `ESPLE:ESPLE-004`, `ESPLE:ESPLE-005`, `ESPLE:ESPLE-006`, `ESPLE:ESPLE-018`, `ESPLE:ESPLE-019`, `ESPLE:ESPLE-032`, `ESPLE:ESPLE-033`, `ESPLE:ESPLE-039`, `ESPLE:ESPLE-040`, `ESPLE:ESPLE-041`, `ESPLE:ESPLE-042`.

**Conditional functional cover:** `ESA:ESA-035`: Expose the external/shared consequences that bound a local design decision.; `ESME:ESME-C071`: Route the actual change to scoped owners and affected consumers.; `ESPLE:ESPLE-039`: Identify contribution, variation and release authority and a legitimate shared-asset dispute route.

**Cheaper/non-trigger path:** For a single legitimate owner with no external obligation change, a direct decision suffices. Where no joint authority exists, narrow the shared boundary or negotiate; the synthesis cannot appoint one.

### SSS-K022 — Consumer-directed communication

**Many To One Convergence.** The affected actor must be able to interpret and act on the relevant consequence. Communicate changed meanings, support and permitted responses through a channel the real consumer can use.

**Guard:** A decision, conflict, retirement or interaction changes another participant's obligations or required action. **Preserved distinction:** Publishing a notice, issuing a command and achieving the consumer's real-world effect are different postconditions.

**Members:** `ESA:ESA-002`, `ESA:ESA-005`, `ESA:ESA-008`, `ESA:ESA-034`, `ESA:ESA-035`, `ESA:ESA-062`, `ESA:ESA-066`, `ESME:ESME-C004`, `ESME:ESME-C071`, `ESME:ESME-C074`, `ESME:ESME-C075`, `ESME:ESME-C076`, `ESME:ESME-C077`, `ESME:ESME-C078`, `ESPLE:ESPLE-004`, `ESPLE:ESPLE-005`, `ESPLE:ESPLE-006`, `ESPLE:ESPLE-008`, `ESPLE:ESPLE-011`, `ESPLE:ESPLE-039`, `ESPLE:ESPLE-041`, `ESPLE:ESPLE-042`.

### SSS-K023 — Completion, support-aware retirement and historical retention

**One To Many Realisation.** Removing new demand does not discharge older supported products, data or recovery obligations. Check residual consumers and state obligations; retire, reclassify enduring coexistence or retain a supported historical baseline.

**Guard:** A scaffold, feature, service, record or support programme is being stopped or declared complete. **Preserved distinction:** No new products, no new changes, no running service and no retained history are four different boundaries.

**Members:** `ESA:ESA-026`, `ESA:ESA-033`, `ESA:ESA-044`, `ESA:ESA-049`, `ESA:ESA-051`, `ESA:ESA-056`, `ESME:ESME-C052`, `ESME:ESME-C058`, `ESME:ESME-C065`, `ESME:ESME-C072`, `ESME:ESME-C077`, `ESME:ESME-C078`, `ESME:ESME-C079`, `ESME:ESME-C081`, `ESME:ESME-C082`, `ESME:ESME-C105`, `ESPLE:ESPLE-003`, `ESPLE:ESPLE-006`, `ESPLE:ESPLE-031`, `ESPLE:ESPLE-033`, `ESPLE:ESPLE-037`, `ESPLE:ESPLE-038`, `ESPLE:ESPLE-054`, `ESPLE:ESPLE-061`.

**Conditional functional cover:** `ESA:ESA-044`: Identify the temporary architectural coexistence structure.; `ESME:ESME-C058`: Require a completion/removal witness for residual consumers, data, support and repair.; `ESPLE:ESPLE-061`: Distinguish ending new selections from discharging support for older variants.

**Cheaper/non-trigger path:** A structure with continuing justified obligations can be reclassified as maintained architecture; never force removal to satisfy a migration label.

### SSS-K024 — Bounded automation versus lifecycle replacement

**Many To One Convergence.** Task assistance does not establish autonomous architecture, maintenance or superior product-line regeneration. Keep suggestions as candidates; check exact outputs, intent, tool versions, authority and total work; retain unresolved broader claims.

**Guard:** Automation is proposed for a bounded task or extrapolated into a lifecycle capability. **Preserved distinction:** Architectural advice, patch repair, deterministic generation and regenerative replacement are distinct interventions with different evidence.

**Members:** `ESA:ESA-054`, `ESA:ESA-060`, `ESME:ESME-C083`, `ESME:ESME-C084`, `ESME:ESME-C085`, `ESME:ESME-C086`, `ESME:ESME-C087`, `ESME:ESME-C088`, `ESME:ESME-C089`, `ESME:ESME-C094`, `ESME:ESME-C095`, `ESME:ESME-C096`, `ESME:ESME-C099`, `ESME:ESME-C100`, `ESPLE:ESPLE-017`, `ESPLE:ESPLE-020`, `ESPLE:ESPLE-021`, `ESPLE:ESPLE-023`, `ESPLE:ESPLE-028`, `ESPLE:ESPLE-047`, `ESPLE:ESPLE-048`, `ESPLE:ESPLE-056`.

### SSS-K025 — Learned, generated and environmental dependencies

**Many To One Convergence.** Consequential behaviour can change through data, generated inputs and environment even with unchanged conventional source. Include relevant non-code dependency and observation envelopes in impact and evidence applicability.

**Guard:** Learned components, generation or context-dependent features materially influence supported behaviour. **Preserved distinction:** A fixed feature selection does not imply fixed data or context; neither a model version nor a configuration hash alone determines behaviour.

**Members:** `ESA:ESA-018`, `ESA:ESA-053`, `ESA:ESA-063`, `ESME:ESME-C003`, `ESME:ESME-C022`, `ESME:ESME-C025`, `ESME:ESME-C091`, `ESME:ESME-C092`, `ESME:ESME-C093`, `ESME:ESME-C103`, `ESPLE:ESPLE-013`, `ESPLE:ESPLE-017`, `ESPLE:ESPLE-021`, `ESPLE:ESPLE-023`, `ESPLE:ESPLE-024`, `ESPLE:ESPLE-029`, `ESPLE:ESPLE-043`, `ESPLE:ESPLE-062`.

### SSS-K026 — Resource constraints and costly flexibility

**Many To One Convergence.** Assurance, variation and distribution consume resources that may outweigh the protected benefit. Compare footprint, operation, support, evaluation and opportunity costs under explicit hard constraints.

**Guard:** The selected mechanism imposes material resource or coordination burden; unneeded machinery can be omitted. **Preserved distinction:** Energy is not lifecycle sustainability, model memory is not total repair cost, and theoretical variants are not realised value.

**Members:** `ESA:ESA-012`, `ESA:ESA-017`, `ESA:ESA-029`, `ESA:ESA-050`, `ESA:ESA-051`, `ESA:ESA-052`, `ESA:ESA-055`, `ESA:ESA-056`, `ESME:ESME-C011`, `ESME:ESME-C034`, `ESME:ESME-C064`, `ESME:ESME-C072`, `ESME:ESME-C087`, `ESME:ESME-C089`, `ESME:ESME-C105`, `ESPLE:ESPLE-003`, `ESPLE:ESPLE-013`, `ESPLE:ESPLE-025`, `ESPLE:ESPLE-036`, `ESPLE:ESPLE-040`, `ESPLE:ESPLE-054`, `ESPLE:ESPLE-059`.

### SSS-K027 — Classification and labels without universal mandates

**Many To One Convergence.** A name, category or descriptive regularity does not by itself prescribe an operative method or guarantee. Retain the specific semantic criterion; do not promote an architectural, maintenance or product-line label into authority.

**Guard:** An actual decision is justified by label/category membership rather than the named property's conditions. **Preserved distinction:** These are analogous inferential limits, not one taxonomy or a shared implementation mechanism.

**Members:** `ESA:ESA-006`, `ESA:ESA-025`, `ESA:ESA-036`, `ESA:ESA-057`, `ESA:ESA-058`, `ESA:ESA-059`, `ESME:ESME-C002`, `ESME:ESME-C007`, `ESME:ESME-C009`, `ESME:ESME-C012`, `ESME:ESME-C018`, `ESME:ESME-C036`, `ESME:ESME-C060`, `ESPLE:ESPLE-043`, `ESPLE:ESPLE-049`, `ESPLE:ESPLE-051`, `ESPLE:ESPLE-055`, `ESPLE:ESPLE-056`, `ESPLE:ESPLE-062`.

### SSS-K028 — Legitimate local, unchanged and non-family alternatives

**Many To One Convergence.** Deliberate non-change or a smaller production arrangement can be the adequate choice. Compare feasible intervention and non-intervention branches against the same live obligations.

**Guard:** A proposed programme is not justified by current or credible future need. **Preserved distinction:** A useful unchanged product need not become a family, and rejecting universal rewrites does not ban a justified replacement.

**Members:** `ESA:ESA-026`, `ESA:ESA-049`, `ESA:ESA-056`, `ESME:ESME-C008`, `ESME:ESME-C009`, `ESME:ESME-C050`, `ESME:ESME-C051`, `ESME:ESME-C052`, `ESME:ESME-C059`, `ESME:ESME-C060`, `ESME:ESME-C065`, `ESME:ESME-C078`, `ESME:ESME-C081`, `ESPLE:ESPLE-003`, `ESPLE:ESPLE-007`, `ESPLE:ESPLE-037`, `ESPLE:ESPLE-038`, `ESPLE:ESPLE-050`, `ESPLE:ESPLE-054`, `ESPLE:ESPLE-057`, `ESPLE:ESPLE-061`.

### SSS-K029 — Semantic translation and model evolution

**Many To One Convergence.** Names and structural mappings can preserve syntax while changing meaning. Establish the relevant correspondence, loss conditions and external meaning before transporting a claim between models.

**Guard:** A model, schema, feature vocabulary, recovered account or tool representation changes or crosses a boundary. **Preserved distinction:** A rationalised explanation is not historical proof; feature-set equivalence is not data or product-observer equivalence.

**Members:** `ESA:ESA-003`, `ESA:ESA-008`, `ESA:ESA-021`, `ESA:ESA-061`, `ESA:ESA-064`, `ESME:ESME-C016`, `ESME:ESME-C018`, `ESME:ESME-C021`, `ESME:ESME-C030`, `ESME:ESME-C055`, `ESME:ESME-C056`, `ESME:ESME-C093`, `ESPLE:ESPLE-008`, `ESPLE:ESPLE-012`, `ESPLE:ESPLE-014`, `ESPLE:ESPLE-030`, `ESPLE:ESPLE-031`, `ESPLE:ESPLE-034`, `ESPLE:ESPLE-046`, `ESPLE:ESPLE-058`.

### SSS-K030 — Stability under justified evolution

**Many To One Convergence.** Stable shared obligations and adaptable local implementations can coexist only under explicit boundaries. Preserve required invariants and support while admitting authorised exceptions, revised models and product-local changes.

**Guard:** A shared invariant or historical baseline is used to constrain a proposed evolution. **Preserved distinction:** Architectural stability, maintenance preservation and family commonality have different legitimate scopes.

**Members:** `ESA:ESA-004`, `ESA:ESA-007`, `ESA:ESA-013`, `ESA:ESA-038`, `ESA:ESA-039`, `ESA:ESA-042`, `ESME:ESME-C022`, `ESME:ESME-C026`, `ESME:ESME-C029`, `ESME:ESME-C030`, `ESME:ESME-C038`, `ESME:ESME-C057`, `ESME:ESME-C097`, `ESPLE:ESPLE-002`, `ESPLE:ESPLE-003`, `ESPLE:ESPLE-006`, `ESPLE:ESPLE-019`, `ESPLE:ESPLE-027`, `ESPLE:ESPLE-031`, `ESPLE:ESPLE-032`, `ESPLE:ESPLE-033`.

### SSS-K031 — Causal liabilities and prospective payoff

**Many To One Convergence.** A predicted future burden needs a specific change/use scenario and an affected cost bearer. Retain an actionable liability and compare repay/defer/retire branches; observe actual task consequences.

**Guard:** Debt or shared-asset investment is proposed as the reason to restructure. **Preserved distinction:** Architectural debt, maintenance debt and variation synchronisation cost can overlap without being independent monetary quantities.

**Members:** `ESA:ESA-027`, `ESA:ESA-029`, `ESA:ESA-043`, `ESA:ESA-049`, `ESME:ESME-C034`, `ESME:ESME-C035`, `ESME:ESME-C062`, `ESME:ESME-C063`, `ESME:ESME-C064`, `ESME:ESME-C065`, `ESME:ESME-C066`, `ESME:ESME-C067`, `ESME:ESME-C068`, `ESME:ESME-C069`, `ESPLE:ESPLE-003`, `ESPLE:ESPLE-007`, `ESPLE:ESPLE-036`, `ESPLE:ESPLE-038`, `ESPLE:ESPLE-057`, `ESPLE:ESPLE-059`.

### SSS-K032 — Proportionate knowledge and control forms

**Many To One Convergence.** Required distinctions and protected outcomes, not document/tool/meeting counts, determine adequate form. Choose the smallest coherent view, explanation, review or analysis; retain escalation on consequential uncertainty.

**Guard:** A proposed form costs more than needed or a cheaper form might omit a consequential distinction. **Preserved distinction:** A local walkthrough, slice, variability model and joint control arrangement are distinct forms and may legitimately be absent.

**Members:** `ESA:ESA-020`, `ESA:ESA-021`, `ESA:ESA-023`, `ESA:ESA-024`, `ESA:ESA-037`, `ESA:ESA-056`, `ESME:ESME-C013`, `ESME:ESME-C014`, `ESME:ESME-C015`, `ESME:ESME-C017`, `ESME:ESME-C019`, `ESME:ESME-C021`, `ESME:ESME-C101`, `ESME:ESME-C105`, `ESPLE:ESPLE-011`, `ESPLE:ESPLE-012`, `ESPLE:ESPLE-014`, `ESPLE:ESPLE-018`, `ESPLE:ESPLE-026`, `ESPLE:ESPLE-037`, `ESPLE:ESPLE-051`, `ESPLE:ESPLE-056`.

### SSS-K033 — Evidence populations and limits of generalisation

**Many To One Convergence.** A setting-bound observation or proxy must not become a universal capability, safety or economic claim. Preserve population, horizon, measurement boundary and independence limitations alongside every cross-lineage use.

**Guard:** Evidence is being transported to a different population or a stronger claim. **Preserved distinction:** These epistemic similarities provide no multiplication of confidence and no new empirical study.

**Members:** `ESA:ESA-015`, `ESA:ESA-018`, `ESA:ESA-028`, `ESA:ESA-029`, `ESA:ESA-031`, `ESA:ESA-054`, `ESA:ESA-060`, `ESME:ESME-C010`, `ESME:ESME-C023`, `ESME:ESME-C024`, `ESME:ESME-C035`, `ESME:ESME-C045`, `ESME:ESME-C073`, `ESME:ESME-C080`, `ESME:ESME-C085`, `ESME:ESME-C095`, `ESME:ESME-C100`, `ESPLE:ESPLE-023`, `ESPLE:ESPLE-025`, `ESPLE:ESPLE-036`, `ESPLE:ESPLE-048`, `ESPLE:ESPLE-049`, `ESPLE:ESPLE-053`, `ESPLE:ESPLE-059`.

### SSS-K034 — Driver refinement across design and product construction

**One To Many Realisation.** Consequential requirements must remain connected to the responsibilities and derivation choices that realise them. Refine selected design elements, allocate obligations and inspect product/maintenance consequences with feedback to earlier assumptions.

**Guard:** A significant driver genuinely requires decomposition or construction work; a local direct decision remains legitimate. **Preserved distinction:** Recursive design is not a mandatory sequence between lineages, and product derivation does not confer change authority.

**Members:** `ESA:ESA-002`, `ESA:ESA-014`, `ESA:ESA-017`, `ESA:ESA-067`, `ESME:ESME-C001`, `ESME:ESME-C022`, `ESME:ESME-C038`, `ESPLE:ESPLE-001`, `ESPLE:ESPLE-004`, `ESPLE:ESPLE-008`, `ESPLE:ESPLE-013`, `ESPLE:ESPLE-019`, `ESPLE:ESPLE-020`.

**Conditional functional cover:** `ESA:ESA-067`: Refine architectural drivers recursively into feasible decisions and structures.; `ESME:ESME-C038`: Distinguish intended changed outcomes from independently retained obligations.; `ESPLE:ESPLE-019`: Identify family invariants and justified variation boundaries in the realised design.

**Cheaper/non-trigger path:** The functions may be discharged in a small design/change example. Driver refinement does not require a universal sequential architecture programme or a platform commitment.

## 5. Tensions, asymmetries and bounded resolutions

The **16 SSS tensions** supplement, rather than replace, the **31 internal inherited tensions**. The two sides are not averaged into a universal compromise. Where the actual supported obligations or legitimate authorities conflict, a justified response may be a narrowed claim, different configuration, deferred change or non-adoption of the proposed mechanism. The corpus supplies no universal social authority or scalar optimisation rule.
### SSS-T001 — Architectural stability versus authorised adaptation

A shared architectural constraint can protect a live promise or entrench an obsolete implementation; drift alone cannot distinguish them.

**Side A:** `ESA:ESA-038`, `ESME:ESME-C038`, `ESPLE:ESPLE-019`. **Side B:** `ESA:ESA-039`, `ESME:ESME-C001`, `ESPLE:ESPLE-006`.

**Failure from universalising A:** Historical conformance blocks a legitimate improvement or defect correction.

**Failure from universalising B:** Unqualified evolution excuses harmful erosion and silently withdraws product guarantees.

**Bounded synthesis:** Adjudicate the changed obligation, revise the correct object, and bound product exceptions without erasing ancestry.

**Unresolved remainder:** The corpora do not supply a universal threshold between erosion and beneficial drift; the disputed consumer and effect remain contextual.

**Side a justified when:** Supported observers and reused assurance still rely on the invariant.

**Side b justified when:** Current consequences or authorised intent invalidate the historic rule, and replacement evidence exists.

### SSS-T002 — Family consistency versus product autonomy

Shared asset invariants can protect products while family-wide approval can prevent legitimate local or independent-owner action.

**Side A:** `ESA:ESA-004`, `ESPLE:ESPLE-019`, `ESPLE:ESPLE-039`. **Side B:** `ESA:ESA-035`, `ESME:ESME-C071`, `ESPLE:ESPLE-006`, `ESPLE:ESPLE-041`.

**Failure from universalising A:** Central authority is invented, queues grow and valid product needs are suppressed.

**Failure from universalising B:** Incompatible local optima and unsupported exceptions contaminate shared assurances.

**Bounded synthesis:** Negotiate bounded shared interfaces and arbitration; allow explicit exceptions, separate baselines or exit where common authority is absent.

**Unresolved remainder:** Legitimate disagreements may remain irreconcilable; technical composition cannot manufacture decision rights.

**Side a justified when:** A variation changes a shared interface or relied-on guarantee.

**Side b justified when:** Local decisions remain within shared consequences, or an independent owner has not delegated authority.

### SSS-T003 — Broad reconstruction versus change-specific understanding

Broader reconstruction can expose hidden coupling but imposes cost and model-maintenance obligations.

**Side A:** `ESA:ESA-024`, `ESME:ESME-C014`, `ESPLE:ESPLE-034`. **Side B:** `ESA:ESA-020`, `ESME:ESME-C013`, `ESPLE:ESPLE-012`.

**Failure from universalising A:** Every small repair waits for an unattainable complete system model.

**Failure from universalising B:** Unexamined nonlocal effects are passed off as known independence.

**Bounded synthesis:** Start from the actual decision, use appropriate views, and widen on consequential discrepancies or counterexamples.

**Unresolved remainder:** Unknown consumers and incomplete execution traces prevent a universal completeness threshold.

**Side a justified when:** Contradictory evidence or consequential uncertainty defeats the local boundary.

**Side b justified when:** A defensible local question and bounded dependency envelope are sufficient.

### SSS-T004 — Reuse investment versus selective reuse or cloning

Shared production can amortise change but may create speculative infrastructure and coordination cost.

**Side A:** `ESA:ESA-013`, `ESPLE:ESPLE-003`, `ESPLE:ESPLE-036`. **Side B:** `ESA:ESA-026`, `ESME:ESME-C065`, `ESPLE:ESPLE-037`, `ESPLE:ESPLE-057`.

**Failure from universalising A:** A mandatory common platform absorbs unsupported variation and sunk cost.

**Failure from universalising B:** Untracked divergence duplicates fixes and loses support provenance.

**Bounded synthesis:** Compare the same obligations over a declared horizon; retain selective commonality and justified exceptions without a universal product-count rule.

**Unresolved remainder:** No representative universal break-even point or lifetime superiority estimate is supplied.

**Side a justified when:** Repeated demanded variants and sustainable support make common assets worthwhile.

**Side b justified when:** Demand is uncertain, needs conflict or the adequate independent route costs less.

### SSS-T005 — Backwards compatibility versus deliberate breaking change

Existing supported interactions can conflict with needed corrections, new constraints or an unsustainable support horizon.

**Side A:** `ESA:ESA-008`, `ESME:ESME-C026`, `ESPLE:ESPLE-033`. **Side B:** `ESA:ESA-039`, `ESME:ESME-C001`, `ESPLE:ESPLE-031`.

**Failure from universalising A:** Obsolete contracts become perpetual and harmful behaviour cannot be corrected.

**Failure from universalising B:** Unilateral breakage strands consumers despite locally correct new code.

**Bounded synthesis:** Name supported observers, communicate actionable change and preserve or explicitly revise the promise for each supported baseline.

**Unresolved remainder:** Unknown consumers and disputed support promises can constrain release without admitting a universal solution.

**Side a justified when:** Consumers retain legitimate support promises and feasible continued service.

**Side b justified when:** Affected parties authorise the changed obligation and a feasible migration, parallel baseline or accepted loss exists.

### SSS-T006 — Commonality versus product-specific quality limits

One common architecture may violate a particular product's quality or externally supplied obligation even when portfolio averages improve.

**Side A:** `ESA:ESA-013`, `ESPLE:ESPLE-019`. **Side B:** `ESA:ESA-017`, `ESME:ESME-C066`, `ESPLE:ESPLE-006`, `ESPLE:ESPLE-042`.

**Failure from universalising A:** Portfolio benefit averages away unacceptable losses for a product population.

**Failure from universalising B:** Every preference becomes a permanent fork and destroys useful commonality.

**Bounded synthesis:** Compare variant-indexed constraints; use bounded substitutions, exceptions or a split when necessary, without inventing numeric utility weights.

**Unresolved remainder:** Which trade-offs are legitimately acceptable is not settled by economic or technical modelling alone.

**Side a justified when:** The common design satisfies every relevant non-negotiable product limit and its reuse benefit is warranted.

**Side b justified when:** A product has a genuine incompatible limit or cost burden that the common design cannot adequately accommodate.

### SSS-T007 — Shared documentation conventions versus concern-driven omission

Common views or production instructions can enable collaboration, while mandatory complete templates can create unused and stale artefacts.

**Side A:** `ESA:ESA-021`, `ESA:ESA-067`, `ESPLE:ESPLE-020`. **Side B:** `ESA:ESA-020`, `ESME:ESME-C017`, `ESPLE:ESPLE-051`.

**Failure from universalising A:** The full view set or plan becomes a proxy for actual knowledge and quality.

**Failure from universalising B:** Missing explanation obstructs builders, successors or cross-boundary review.

**Bounded synthesis:** Retain the smallest shared conventions and correspondences that have a consumer; expressly reject mandatory complete 4+1 and feature-tree sufficiency.

**Unresolved remainder:** The maintenance cost and adequacy of a particular documentation set require actual use evidence.

**Side a justified when:** Real consumers need multiple distinctions or repeatable cross-team construction.

**Side b justified when:** A simpler checked representation answers the consequential question.

### SSS-T008 — Formal coverage versus proportionate assurance

Stronger modelled coverage can justify important claims but modelling cost, semantic omissions and state growth can dominate.

**Side A:** `ESA:ESA-022`, `ESA:ESA-068`, `ESPLE:ESPLE-026`, `ESPLE:ESPLE-027`, `ESPLE:ESPLE-045`. **Side B:** `ESME:ESME-C040`, `ESME:ESME-C041`, `ESME:ESME-C105`, `ESPLE:ESPLE-025`.

**Failure from universalising A:** A model is expanded indefinitely while unmodelled reality and implementation mapping remain unchecked.

**Failure from universalising B:** Cheap testing is mistaken for complete correctness or critical interactions are knowingly omitted.

**Bounded synthesis:** Choose or combine methods by claim, model applicability and missed-effect consequence; restrict configurations when adequate evidence is infeasible.

**Unresolved remainder:** The corpora do not provide a universal acceptable risk budget or economically complete abstraction.

**Side a justified when:** A tractable consequential formal property and demonstrable model-to-implementation mapping exist.

**Side b justified when:** A scoped risk-informed sample, direct check or constrained state space answers the actual decision more economically.

### SSS-T009 — Characterised behaviour versus intended change

Observed behaviour is useful regression evidence but can encode defects or outdated intent.

**Side A:** `ESA:ESA-038`, `ESME:ESME-C030`, `ESME:ESME-C037`. **Side B:** `ESME:ESME-C001`, `ESME:ESME-C038`, `ESPLE:ESPLE-031`, `ESPLE:ESPLE-058`.

**Failure from universalising A:** Every golden output becomes an immutable specification.

**Failure from universalising B:** Tests are rewritten merely to make the candidate pass, hiding regressions.

**Bounded synthesis:** Separate intended differences from retained promises and source the oracle independently of the candidate's own output.

**Unresolved remainder:** Disputed historical intent cannot be recovered from observation alone.

**Side a justified when:** The observer corresponds to a legitimately retained commitment.

**Side b justified when:** An authorised change explicitly revises the relevant outcome while retaining independent obligations.

### SSS-T010 — Runtime flexibility versus transition and recovery assurance

Late-bound choices respond to context but introduce intermediate states and can remove repair options.

**Side A:** `ESA:ESA-046`, `ESPLE:ESPLE-013`, `ESPLE:ESPLE-043`. **Side B:** `ESA:ESA-047`, `ESME:ESME-C049`, `ESME:ESME-C104`, `ESPLE:ESPLE-044`, `ESPLE:ESPLE-045`.

**Failure from universalising A:** Valid endpoint selection is used to justify unsafe or irreversible transitions.

**Failure from universalising B:** All useful runtime adaptation is prohibited even where a bounded safe protocol exists.

**Bounded synthesis:** Permit only justified transitions with observed realisation and state/effect-aware recovery; use safe reconfiguration phases or earlier binding where appropriate.

**Unresolved remainder:** Adequate plant/observer models and open-world effects remain context-specific.

**Side a justified when:** A real operational need cannot be met adequately by earlier binding and the action envelope is established.

**Side b justified when:** Live transfer or recovery cannot be adequately assured, or static/restart operation is cheaper and adequate.

### SSS-T011 — Automation speed versus acceptance and total cost

Faster suggestions can increase validation, comprehension or later support costs and cannot authorise their own application.

**Side A:** `ESA:ESA-054`, `ESPLE:ESPLE-047`. **Side B:** `ESME:ESME-C083`, `ESME:ESME-C087`, `ESME:ESME-C094`, `ESPLE:ESPLE-028`.

**Failure from universalising A:** Fluent output and benchmark passage are promoted into autonomous lifecycle stewardship.

**Failure from universalising B:** An adverse result from one task becomes a universal prohibition of useful assistance.

**Bounded synthesis:** Compare complete bounded workflows and delegate only the supported object/action envelope; retain unresolved long-horizon and replacement claims.

**Unresolved remainder:** No general unattended capability or superior lifecycle regeneration result is established by these inputs.

**Side a justified when:** Bounded assistance reduces full task burden with adequate output evidence.

**Side b justified when:** Verification, uncertainty or external-action risk exceeds the apparent generation benefit.

### SSS-T012 — Individually justified controls versus combined burden

Several local controls can duplicate evidence, conflict or consume the capacity needed to protect the system.

**Side A:** `ESA:ESA-028`, `ESME:ESME-C039`, `ESPLE:ESPLE-039`. **Side B:** `ESA:ESA-056`, `ESME:ESME-C105`, `ESPLE:ESPLE-061`.

**Failure from universalising A:** Assurance accumulates without consumers, suppressing useful work and hiding conflicting rules.

**Failure from universalising B:** Cost cutting removes rare but necessary protection and calls that proportionality.

**Bounded synthesis:** Assess the combined arrangement, preserve the protected outcome, and consolidate, substitute or retire only with a residual-obligation account.

**Unresolved remainder:** No empirical optimum for the complete SSS control arrangement is available.

**Side a justified when:** Each control protects a live consequential obligation not adequately discharged elsewhere.

**Side b justified when:** A combined arrangement is redundant, dominated, obsolete or unsustainably costly.

### SSS-T013 — Synchronous shared propagation versus independent releases

A shared fix can benefit all products but simultaneous rollout may be infeasible or amplify a common fault.

**Side A:** `ESA:ESA-035`, `ESPLE:ESPLE-032`. **Side B:** `ESME:ESME-C029`, `ESME:ESME-C076`, `ESPLE:ESPLE-033`.

**Failure from universalising A:** One slow or exceptional product blocks urgent justified repairs everywhere.

**Failure from universalising B:** Untracked skew leaves products without an applicable fix or valid support path.

**Bounded synthesis:** Bind each propagation decision to actual product/baseline evidence and communicate the compatible independent or coordinated path.

**Unresolved remainder:** Actual support horizon, release capacity and consumer reach are not determined by this synthesis.

**Side a justified when:** A tightly coupled supported obligation requires coordinated activation.

**Side b justified when:** Products have independent acceptable schedules and compatible older baselines remain supportable.

### SSS-T014 — Local formal guarantees versus global progress

Wright deadlock freedom and supervisory nonblocking have different semantics; neither automatically establishes progress of their coupled execution.

**Side A:** `ESA:ESA-068`, `ESPLE:ESPLE-045`. **Side B:** `ESA:ESA-047`, `ESME:ESME-C104`.

**Failure from universalising A:** Local theorems are conjoined into an unsupported global liveness guarantee.

**Failure from universalising B:** Useful bounded formal results are discarded merely because they do not prove the whole system.

**Bounded synthesis:** Keep local results with their assumptions; separately model or constrain relevant coupled states and the actual progress obligation.

**Unresolved remainder:** No frozen common plant, scheduler/fairness assumption or refinement proof decides the general theorem-composition question.

**Side a justified when:** The local theorem's formal conditions and implementation correspondence are actually met.

**Side b justified when:** A composite progress or safety obligation concerns interactions outside either local model.

### SSS-T015 — Termination versus enduring support and preservation

Removing a route or feature can reduce cost while older products, records or recovery procedures still depend on it.

**Side A:** `ESA:ESA-051`, `ESME:ESME-C078`, `ESPLE:ESPLE-061`. **Side B:** `ESME:ESME-C058`, `ESME:ESME-C079`, `ESPLE:ESPLE-033`.

**Failure from universalising A:** Deletion strands historical or supported consumers and falsely declares completion.

**Failure from universalising B:** Everything is preserved as a live service indefinitely with no continuing purpose.

**Bounded synthesis:** Distinguish new-product admission, support, running operation and historical retrieval; retire each on its own observed witness.

**Unresolved remainder:** Hidden consumers and the horizon of a legitimate retention obligation may remain uncertain.

**Side a justified when:** Its live obligations have ended or are explicitly transferred.

**Side b justified when:** An actual supported product or declared preservation purpose still requires the object.

### SSS-T016 — Counterexample challenge versus finite inquiry capacity

Searching for consequential omissions improves scope but can expand without bound in an open environment.

**Side A:** `ESA:ESA-015`, `ESME:ESME-C022`, `ESPLE:ESPLE-024`. **Side B:** `ESME:ESME-C011`, `ESME:ESME-C105`, `ESPLE:ESPLE-025`, `ESPLE:ESPLE-040`.

**Failure from universalising A:** The system cannot take any bounded action because unknown unknowns are treated as an obligation to enumerate everything.

**Failure from universalising B:** A budget cutoff is misrepresented as proof that no consequential omissions exist.

**Bounded synthesis:** State the finite examined envelope, unresolved remainder and action restriction; choose a cheaper or no-change branch where assurance is inadequate.

**Unresolved remainder:** No universal stopping rule eliminates open-world uncertainty.

**Side a justified when:** A plausible missed effect could change the decision or violate a supported obligation.

**Side b justified when:** Further inquiry is dominated or unsupported, and the remaining claim can be safely narrowed or the action constrained.

## 6. Composition-induced-property investigation

**Surviving SSS-E properties: 0. Pairwise: 0. Genuinely three-way: 0. Rejected emergence candidates: 14.** All candidate records retain parents, relational derivation context, the proposed bearer and criterion, a failure witness, distinctness adjudication, parent/lineage removal accounts and the useful remaining result.

The decisive test is not whether an example mentions all three lineages. It is whether the proposed predicate is distinct, warranted and not already covered at the actual trigger. Removing a lineage can remove an example’s vocabulary or evidence input without establishing that a new three-way predicate existed. Likewise, a real interaction failure can be new to the analyst while already violating a retained constituent obligation. Missing premises for a stronger theorem or capability are not evidence of emergence.

Canonical C102–C105 make this distinction especially important. They already govern candidate/evidence/action coherence, selective assumption-indexed invalidation, obligations of consequential reachable joint states, and feedback-driven retirement of combined controls. A configuration, generator, architectural mapping or shared asset can add a consequential argument to one of those rules. It does not automatically create another rule. The original four remain analytical within-lineage deductions with their inherited ceilings; this synthesis does not retroactively validate them empirically.
### Q1 / SSS-X001 — Configuration-indexed architectural evidence

**Proposed bearer:** An operative architectural claim reused for a selected and realised product baseline.

**Proposed criterion:** Use the claim only for the configuration, architecture mapping, observer and baseline for which its premises hold.

**Parents:** `ESA:ESA-018`, `ESA:ESA-038`, `ESME:ESME-C102`, `ESME:ESME-C103`, `ESPLE:ESPLE-021`, `ESPLE:ESPLE-023`.

**Putative failure witness:** A latency result for variant A is attached to variant B using the same product name. Architecture measured A correctly, the maintainer retained the old result and the configurator produces a permitted B.

**Adjudication — REJECTED_AS_DISTINCT_SUBSUMED:** The putative witness does not satisfy C103: it gives a dependent claim unqualified operative force after the relevant evidence envelope changed. C102 also disallows the mismatched action. ESA and ESPLE identify additional envelope arguments; they do not establish a new invalidation predicate. This use of C103 is limited to consequential reuse under its actual trigger, not all static architecture description.

**Retained result:** Bind architecture observations to product identity and carry their assumptions into the existing invalidation relation.

### Q2 / SSS-X002 — Cross-boundary dependency-path closure

**Proposed bearer:** The impact account of an actual shared change across architecture, build and product mappings.

**Proposed criterion:** Include justified consequential paths that traverse different dependency representations; expose unknown edges and unsupported scope.

**Parents:** `ESA:ESA-010`, `ESME:ESME-C022`, `ESME:ESME-C025`, `ESPLE:ESPLE-014`, `ESPLE:ESPLE-032`.

**Putative failure witness:** An architectural dependency leads to a generated interface used only by one feature configuration. Separate code and feature analyses miss the composed path.

**Adjudication — REJECTED_AS_DISTINCT_SUBSUMED:** C025 already includes consequential generated, runtime, data and interface propagation and distinguishes edge kinds; C022 requires consequential escapes to reopen scope. Calling an artificially truncated analysis locally satisfied changes the inherited criterion. A stronger guarantee of complete open-world transitive closure is not supported by any parent and is not warranted emergence.

**Retained result:** The useful addition is an explicit typed bridge and a cross-boundary counterexample challenge, not a new universal completeness guarantee.

### Q3 / SSS-X003 — Variant-indexed lifecycle trade-off adequacy

**Proposed bearer:** A portfolio decision evaluated across product populations and their lifecycle obligations.

**Proposed criterion:** Do not trade away a product-specific hard limit through an aggregate economic score; compare feasible lifecycle alternatives with affected cost bearers visible.

**Parents:** `ESA:ESA-017`, `ESA:ESA-029`, `ESME:ESME-C064`, `ESME:ESME-C066`, `ESPLE:ESPLE-036`, `ESPLE:ESPLE-042`.

**Putative failure witness:** A common design lowers average maintenance cost while an infrequently used product exceeds a hard response-time or external obligation.

**Adjudication — REJECTED_AS_DISTINCT_CONJUNCTION:** The failure already violates ESA-017 when the product limit is a declared hard constraint, or exposes an omitted outcome/population in ESPLE-036. Maintenance economics supplies costs; family scope supplies populations. The proposed predicate is constrained trade-off reasoning instantiated with those inputs, not an additional joint invariant. No common empirical utility function or universally optimal arrangement follows.

**Retained result:** Keep a one-to-many economic argument with variant-specific constraints, costs and authority rather than renaming it as an SSS law.

### Q4 / SSS-X004 — Architecture-family migration joint-state continuity

**Proposed bearer:** Reachable mixed architecture, version, schema and configuration states during a selected migration.

**Proposed criterion:** Every consequential newly reachable combination has adequate obligation evidence or is prevented.

**Parents:** `ESA:ESA-044`, `ESME:ESME-C057`, `ESME:ESME-C104`, `ESPLE:ESPLE-031`, `ESPLE:ESPLE-033`, `ESPLE:ESPLE-044`.

**Putative failure witness:** Old and new product endpoints each pass, but a shared old reader encounters a newly migrated schema while a third product still uses the old gateway.

**Adjudication — REJECTED_AS_DISTINCT_SUBSUMED:** This is the exact criterion and trigger of C104. The canonical bearer already includes concurrent edits, mixed versions, data mappings and responsibility transfers. Products and architecture supply concrete dimensions of that joint state; changing the state tuple is not a distinct predicate.

**Retained result:** Derive the relevant state dimensions and constrain the real migration path; do not issue a duplicate SSS-E property.

### Q5 / SSS-X005 — Generation-aware multi-index evidence invalidation

**Proposed bearer:** A reused evidence claim indexed by generator, mapping, selection, baseline and observer.

**Proposed criterion:** Invalidate or narrow exactly those claims whose relevant index assumptions changed; preserve unaffected results.

**Parents:** `ESA:ESA-021`, `ESA:ESA-033`, `ESME:ESME-C088`, `ESME:ESME-C103`, `ESPLE:ESPLE-017`, `ESPLE:ESPLE-021`, `ESPLE:ESPLE-023`.

**Putative failure witness:** The requested feature set remains identical but a generator revision changes an architecture mapping, and a previously accepted quality result is reused.

**Adjudication — REJECTED_AS_DISTINCT_SUBSUMED:** C103 explicitly covers relevant tool/model, dependency, observer, environment and obligation changes. ESPLE identity and ESA correspondence tell which assumptions matter. A new column in an applicability record is not a new property of evidence validity.

**Retained result:** Retain the joint validity-index example and the selection/generation/correspondence dependency relations.

### Q6 / SSS-X006 — Recovery-preserving dynamic family reconfiguration

**Proposed bearer:** A live transition and the remaining feasible repair or accepted-loss envelope of the realised system.

**Proposed criterion:** Do not consume a promised restoration, containment or forward-repair route without feasible replacement or legitimate residual-loss acceptance.

**Parents:** `ESA:ESA-008`, `ESA:ESA-047`, `ESME:ESME-C049`, `ESME:ESME-C104`, `ESPLE:ESPLE-043`, `ESPLE:ESPLE-044`.

**Putative failure witness:** A valid feature switch and a separately safe architectural optimisation jointly discard the data needed by the promised recovery path.

**Adjudication — REJECTED_AS_DISTINCT_SUBSUMED:** C049 checks remaining returnability at the consequential action boundary, including persistent and external effects. The witness cannot leave C049 satisfied once the promised route is gone and loss unaccepted. ESPLE and ESA add actual state and transition assumptions, not a stronger general returnability invariant.

**Retained result:** Connect actual dynamic transition semantics to effect-aware repair and, where appropriate, constrain transitions under C104.

### Q7 / SSS-X007 — Cross-lineage shared-asset authority coherence

**Proposed bearer:** A disputed consequential shared-asset decision crossing product and organisational boundaries.

**Proposed criterion:** The request reaches a capable legitimate decision route or an explicit negotiated limitation; evidence cannot create missing authority.

**Parents:** `ESA:ESA-005`, `ESA:ESA-035`, `ESME:ESME-C071`, `ESME:ESME-C094`, `ESPLE:ESPLE-039`, `ESPLE:ESPLE-041`.

**Putative failure witness:** An architect approves an interface, a maintainer can edit the repository, and a product team owns its release, yet no one can legitimately accept the other products' changed obligations.

**Adjudication — REJECTED_AS_DISTINCT_SUBSUMED:** ESPLE-039 already requires explicit contribution/variation/release rights and accountable arbitration of competing product obligations; ESA-005 distinguishes acceptance, consultation and execution. Local permissions are not satisfaction of those cross-boundary criteria. Where external owners cannot agree, ESPLE-041 permits a bounded interface or separation rather than inventing an SSS authority.

**Retained result:** Export the authority-comparison and exception relations; no shared implementation owner is derived.

### Q8 / SSS-X008 — Cross-lineage scaffold termination witness

**Proposed bearer:** A declaration of completion/removal for a temporary structure still used by supported product variants.

**Proposed criterion:** Remove or reclassify the structure only after residual consumers, data authority, support and recovery uses are discharged or transferred.

**Parents:** `ESA:ESA-020`, `ESA:ESA-044`, `ESME:ESME-C058`, `ESPLE:ESPLE-014`, `ESPLE:ESPLE-033`, `ESPLE:ESPLE-061`.

**Putative failure witness:** The architecture view omits an old gateway after new products stop selecting a feature, although supported older variants still require it.

**Adjudication — REJECTED_AS_DISTINCT_SUBSUMED:** C058 explicitly checks supported versions, residual consumers, data authority and recovery before removal or completion. ESPLE-061 separates new admission from old support, and architecture/feature mappings reveal the hidden consumer. The proposed termination witness is an application of the inherited criterion, not a new one.

**Retained result:** Keep the support-aware scope bridge and the option to reclassify permanent coexistence instead of falsely reporting completion.

### Q9 / SSS-X009 — Autonomous cross-stage lifecycle stewardship

**Proposed bearer:** A chain of assisted architecture, change and product-generation operations.

**Proposed criterion:** Proposed stronger claim: the assembled chain reliably performs open-ended lifecycle stewardship without additional residual authority or evidence obligations.

**Parents:** `ESA:ESA-054`, `ESA:ESA-060`, `ESME:ESME-C083`, `ESME:ESME-C094`, `ESME:ESME-C100`, `ESME:ESME-C102`, `ESPLE:ESPLE-047`, `ESPLE:ESPLE-048`.

**Putative failure witness:** Each tool succeeds on its local benchmark, yet the chain deploys a different variant, changes the acceptance oracle or incurs later support costs.

**Adjudication — REJECTED_AS_DISTINCT_UNSUPPORTED_CAPABILITY:** Binding, authority, actual-output acceptance and observation already reject the witnessed unsupported action. The further reliable autonomous capability is not entailed by assembling bounded assistants; ESA-060 and ESME-C100 remain unresolved and ESPLE-048 does not establish replacement superiority. Missing end-to-end evidence is not a new validated property.

**Retained result:** Retain bounded automation relations and unresolved capability comparisons, with no blanket human-only rule.

### Q10 / SSS-X010 — Whole-SSS control economy

**Proposed bearer:** The selected combined inquiry, validation, coordination and support arrangement.

**Proposed criterion:** The combination retains justified protection and consumers at a defensible cost; redundant or obsolete controls may end without waiving live obligations.

**Parents:** `ESA:ESA-028`, `ESA:ESA-056`, `ESME:ESME-C105`, `ESPLE:ESPLE-036`, `ESPLE:ESPLE-039`, `ESPLE:ESPLE-061`.

**Putative failure witness:** Each lineage adds a locally reasonable review, but their overlapping approval and retest demands consume all change capacity or impose contradictory acceptance rules.

**Adjudication — REJECTED_AS_DISTINCT_SUBSUMED:** The exact bearer and combined-control criterion are already present in C105. Architecture reviews and family governance add components of the arrangement. A stronger guarantee of an optimal or contradiction-free organisation is not supplied by the frozen evidence.

**Retained result:** Treat cost, conflict and retirement as cross-lineage inputs to C105; preserve protected obligations and context-specific unresolved optimisation.

### Q11 / SSS-X011 — Global compatibility beyond pairwise agreement

**Proposed bearer:** The joint consistency/acceptance claim for selected descriptions, configurations and realisations.

**Proposed criterion:** Do not infer a realizable or acceptable joint system merely from pairwise satisfiable projections.

**Parents:** `ESA:ESA-021`, `ESME:ESME-C104`, `ESPLE:ESPLE-023`, `ESPLE:ESPLE-027`, `ESPLE:ESPLE-028`.

**Putative failure witness:** Three binary constraints A=M, A=P and M!=P are each satisfiable, while their joint conjunction is empty. Pairwise review alone therefore cannot establish a common implementation.

**Adjudication — REJECTED_AS_DISTINCT_SUBSUMED:** The finite witness establishes a genuine higher-order failure possibility, not a novel inherited-obligation gap. ESPLE-027 requires checked composition premises for the product claim and ESPLE-028 concerns the actual accepted product; C104 already guards consequential new joint states. A global claim based solely on pairwise checks does not satisfy those criteria. For purely static pre-design analysis, retain the ESPLE claim boundary rather than falsely extending a maintenance trigger.

**Retained result:** Retain an executed three-way counterexample and require joint claim evidence where consequential; do not label every higher-order failure a new property.

### Q12 / SSS-X012 — Composition of local liveness guarantees

**Proposed bearer:** A putative global progress theorem for a coupled architecture connector and dynamic-family supervisor.

**Proposed criterion:** Proposed stronger claim: local deadlock freedom and local nonblocking imply safe inevitable progress of the composed runtime.

**Parents:** `ESA:ESA-068`, `ESA:ESA-047`, `ESME:ESME-C104`, `ESPLE:ESPLE-045`.

**Putative failure witness:** Each controller has an available local completion route, while their enabled actions alternately disable one another or the scheduler indefinitely avoids completion.

**Adjudication — REJECTED_AS_DISTINCT_UNSUPPORTED_ENTAILMENT:** Wright deadlock freedom and supervisory nonblocking are not equivalent to universal eventual progress, and their frozen assumptions do not provide a common plant/refinement/fairness model. The positive entailment fails; the requirement to establish relevant joint obligations is already C104. This is missing premises for a stronger theorem, not a deduced new capability.

**Retained result:** Keep the intentional asymmetry and the unresolved common-model question; do not discard the legitimate local formal results.

### Q13 / SSS-X013 — Independent corroboration of the composed system

**Proposed bearer:** The synthesis's evidence account and claimed corroboration, not the target software.

**Proposed criterion:** Do not multiply support when local properties reuse the same work, programme, dataset or access-limited claim.

**Parents:** `ESA:ESA-013`, `ESA:ESA-054`, `ESME:ESME-C085`, `ESPLE:ESPLE-023`, `ESPLE:ESPLE-047`.

**Putative failure witness:** A shared Parnas work is cited in two lineages and a common benchmark programme is described as separate confirmation of SSS effectiveness.

**Adjudication — REJECTED_AS_DISTINCT_EVIDENCE_METADATA:** The evidence partitions and source-independence limitations already forbid this inference. Cross-lineage identity resolution adds provenance metadata, not an engineering capability or new software-bearer property. No source-count transformation establishes an independent-study denominator.

**Retained result:** Preserve six shared-work groups, all local records and programme-dependence cautions without assigning a new SSS-E number.

### Q14 / SSS-X014 — Non-circular revision of the composed method

**Proposed bearer:** A change to a policy, oracle, variability constraint or assessment method used by the composed arrangement.

**Proposed criterion:** Do not let the revised mechanism solely warrant itself or silently broaden delegated authority; preserve unrelated predecessor obligations.

**Parents:** `ESA:ESA-063`, `ESME:ESME-C098`, `ESME:ESME-C103`, `ESME:ESME-C105`, `ESPLE:ESPLE-010`, `ESPLE:ESPLE-060`.

**Putative failure witness:** An assistant changes the feature constraints or quality threshold until its chosen product passes, then treats the new passage as justification for the rule change.

**Adjudication — REJECTED_AS_DISTINCT_SUBSUMED:** C098 directly covers authorised non-circular revision of methods and oracles; ESA-063 adds sensor/policy assumptions and ESPLE-010 requires external domain adequacy. Under a real method-change trigger the candidate is a scope specialisation, while an unchanged static model only needs its inherited adequacy checks.

**Retained result:** Keep the method-revision interrupt, independent warrant and selective evidence invalidation; no self-authorising SSS meta-method is created.

### What the executed examples establish

Twelve executable analytical constructions are included with their scripts and fresh readback results. They cover: three-way inconsistency despite pairwise satisfiability; an impact path crossing three representations; same feature selection with changed generation; valid migration endpoints with an invalid mixed state; lost promised recovery; pairwise coverage missing a triple fault; aggregate benefit hiding a hard variant limit; new-admission retirement leaving older consumers; environment variation without feature options; nonblocking versus inevitable progress; selective invalidation; and forward repair without code reversal.

These tests establish the logic of the specified examples, not their frequency in practice or the effectiveness of SSS as a whole. Some proposed witnesses deliberately fail the full inherited criterion; that is the reason the corresponding new-property claim is rejected. The higher-order inconsistency witness is a genuine higher-order *failure possibility*, but not a new property merely by virtue of arity. The complete `SSS-AT001`–`SSS-AT012` records state assumptions and inference limits.
## 7. Composition model: relations, not phases

The composition model has **16 object types, 12 typed relation edges, seven feedback loops and eight interrupt conditions**. The object types cover decisions, artefacts, actual architectural structures and their views, baselines, obligations, configurations, shared assets, products, evidence, actors, actual authorities, observations, transitions, recovery/forward repair and retirement.

Architecture inquiry, comprehension, feature validation, affected-consumer discovery, economic analysis and local testing can proceed concurrently under bounded authority. A combined consequential action or claim must then use a consistent actual candidate, appropriate evidence and the supported obligations. Clean textual merging does not establish semantic compatibility. Local sequencing exists only where the relation requires it: identify the candidate before relying on its evidence, preserve or legitimately revise a promised recovery route before consuming it, and establish a support/retirement witness before removing a live path.

The following loops are optional whenever their trigger is absent. Their arrows express possible feedback, not a universal schedule.
**SSS-L001 — Product-to-core correction:** product → observation → decision → shared_asset → product. A product-specific exception may improve the core, remain a justified exception, or justify reducing shared scope. Parent criteria: `ESA:ESA-039`, `ESME:ESME-C008`, `ESPLE:ESPLE-005`.

**SSS-L002 — Evidence applicability feedback:** baseline → evidence → decision → migration_transition → baseline. Invalidate only affected claims; unchanged premises can retain evidence. Parent criteria: `ESA:ESA-033`, `ESME:ESME-C103`, `ESPLE:ESPLE-021`.

**SSS-L003 — Architectural conformance and justified improvement:** architecture_structure → observation → architecture_view → decision → architecture_structure. Drift can be a defect, an obsolete description, or an authorised improvement; historical conformance is not universally right. Parent criteria: `ESA:ESA-021`, `ESA:ESA-039`, `ESME:ESME-C021`, `ESPLE:ESPLE-019`.

**SSS-L004 — Impact-boundary revision:** artefact → architecture_structure → variant_configuration → product → decision → artefact. An exposed consequential dependency reopens scope locally; it does not demand exhaustive understanding before every change. Parent criteria: `ESA:ESA-010`, `ESME:ESME-C022`, `ESME:ESME-C025`, `ESPLE:ESPLE-032`.

**SSS-L005 — Runtime adaptation and repair:** observation → variant_configuration → migration_transition → product → observation. Accept, constrain, roll back, repair forward or narrow the claim according to actual state/effect evidence. Parent criteria: `ESA:ESA-046`, `ESA:ESA-047`, `ESME:ESME-C049`, `ESPLE:ESPLE-043`, `ESPLE:ESPLE-044`.

**SSS-L006 — Control proportionality and retirement:** decision → evidence → observation → retirement → decision. Retire redundant/obsolete controls while retaining live obligations; no-change is a legitimate outcome. Parent criteria: `ESA:ESA-056`, `ESME:ESME-C105`, `ESPLE:ESPLE-036`, `ESPLE:ESPLE-061`.

**SSS-L007 — Non-circular method revision:** decision → authority → evidence → observation → decision. A successor rule cannot be its own sole warrant or silently expand authority. Parent criteria: `ESA:ESA-063`, `ESME:ESME-C098`, `ESME:ESME-C103`, `ESPLE:ESPLE-010`, `ESPLE:ESPLE-060`.

### Interrupt behaviour

**SSS-I001 — Candidate/evidence mismatch:** Suspend the unsupported evidence use/action, reconcile identity or narrow scope; unaffected local work can continue. The interrupt creates no new authority.

**SSS-I002 — Changed relevant assumption:** Invalidate or qualify the affected claim; do not destroy unrelated evidence. The interrupt creates no new authority.

**SSS-I003 — Unanticipated consequential interaction:** Challenge and extend the impact/joint-state account or constrain the action. The interrupt creates no new authority.

**SSS-I004 — Authority gap or dispute:** Negotiate an authorised route, preserve a bounded product exception, split scope, defer or decline. The interrupt creates no new authority.

**SSS-I005 — Emergency harm:** Use bounded containment/deliberate degradation within real emergency authority, preserve surviving obligations and repair prospects. The interrupt creates no new authority.

**SSS-I006 — Lost returnability:** Constrain the transition, establish feasible forward repair or obtain legitimate residual-loss acceptance. The interrupt creates no new authority.

**SSS-I007 — Obsolete method/oracle or gaming:** Reopen the method under independent prior warrant; do not let passing the revised rule authorise itself. The interrupt creates no new authority.

**SSS-I008 — Retirement without a support witness:** Do not remove the remaining path; discharge, transfer or reclassify the ongoing obligation. The interrupt creates no new authority.

Termination is scoped, not a global “done” stage. A completed change can coexist with supported older baselines. A gateway can be legitimately reclassified as maintained infrastructure instead of falsely declared removed. Useful operation without change can continue. Control retirement can reduce burden while support obligations remain. The explicit cross-boundary assumptions concern actual representation/realisation correspondence, evidence population/oracle applicability, legitimate authority and an adequate supported-consumer/dependency account; none is guaranteed merely by assembling the fields.

## 8. Alternative configurations

There are **eight base arrangements and three guarded overlays**, not a maturity ladder or methodology modes. They are analytical combinations of frozen alternatives, not empirically validated packages. The parent configuration IDs and full triggers, omissions, evidence expectations, failures and exit paths remain in the configuration ledger.
### SSS-CFG001 — Small stable single product

**Kind:** BASE_CONFIGURATION. **Trigger:** One product, few consequential boundaries, adequate current support and no justified family investment.

**Required functions:** Direct understanding of actual obligations and interfaces; One relevant outcome/alternative check when a real decision arises; Explicit non-change and revisit conditions.

**Omitted mechanisms:** Product-line programme; Full architecture view set; Standing change board; Generator, solver or runtime supervisor.

**Evidence:** A small checked example, exact relevant baseline and direct authorised conversation can suffice.

**Failure boundary:** Hidden supported consumers or a newly consequential change defeats the local scope.

**Transition/retirement:** Remain unchanged while useful; move to bounded maintenance or a family only when actual need and cost justify it.

**Frozen ancestry:** `ESA:ESA-CFG01`, `ESME:ESME-CFG001`, `ESPLE:ESPLE-ALT-06`.

### SSS-CFG002 — Continuing modular single-product maintenance

**Kind:** BASE_CONFIGURATION. **Trigger:** A long-lived product has recurring changes and useful modular/shared-interface boundaries without a product family.

**Required functions:** Bounded impact and legitimate intent; Task-justified transformation or local repair; Relevant rationale, actual-candidate evidence and recovery; Feedback on change burden.

**Omitted mechanisms:** A family feature model; Mandatory service decomposition; Exhaustive reconstruction before every change.

**Evidence:** Change-specific understanding, supported-observer checks and applicable post-change observations.

**Failure boundary:** Scope escapes, stale mapping, unknown intent or infeasible promised repair require a bounded interruption.

**Transition/retirement:** Retain local work; broaden coordination only at shared consequences; phase into servicing or retirement if justified.

**Frozen ancestry:** `ESA:ESA-CFG02`, `ESME:ESME-CFG002`, `ESME:ESME-CFG003`, `ESPLE:ESPLE-ALT-06`.

### SSS-CFG003 — Selective reuse or traceable clone-and-own

**Kind:** BASE_CONFIGURATION. **Trigger:** Some genuine common assets exist but a full managed-family investment is not justified.

**Required functions:** Justified commonality boundary; Retained clone/exception provenance; Shared-fix impact and support knowledge; Independent product acceptance.

**Omitted mechanisms:** Universal feature modelling; Mandatory reintegration; Simultaneous release of all products.

**Evidence:** Concrete comparison of support/coordination costs, affected products and relevant shared changes.

**Failure boundary:** Untracked divergence or assumed shared assurance that does not apply to an exceptional product.

**Transition/retirement:** Consolidate selectively when observed recurring cost warrants it, or separate further while preserving actual obligations.

**Frozen ancestry:** `ESA:ESA-CFG05`, `ESME:ESME-CFG005`, `ESPLE:ESPLE-ALT-03`, `ESPLE:ESPLE-ALT-06`.

### SSS-CFG004 — Managed static or generated family

**Kind:** BASE_CONFIGURATION. **Trigger:** Repeated related products and support economics justify coordinated assets and derivation.

**Required functions:** Meaningful feature/configuration choices; Version-related production inputs and actual-product acceptance; Architectural invariants and explicit exceptions; Shared-change propagation and product feedback.

**Omitted mechanisms:** Runtime variability unless needed; Automatic use of every solver, sampling or family-analysis strategy; Mandatory platform departments.

**Evidence:** Separate constraint adequacy, generator/realisation evidence and applicable product/family assurance.

**Failure boundary:** Requested selection mistaken for realised identity, unmodelled build variation or inherited guarantee applied beyond its scope.

**Transition/retirement:** Use prospective economic review to simplify, split, restrict variants or move to servicing.

**Frozen ancestry:** `ESA:ESA-CFG05`, `ESME:ESME-CFG005`, `ESPLE:ESPLE-ALT-01`, `ESPLE:ESPLE-ALT-02`.

### SSS-CFG005 — Incremental portfolio consolidation or architectural migration

**Kind:** BASE_CONFIGURATION. **Trigger:** Existing independent products or architectures have useful consolidation opportunities and viable transfer seams.

**Required functions:** Recovered commonality with domain reconciliation; Explicit supported mixed states and data authority; Product-local exceptions and parallel baselines; Scaffold completion or permanent-coexistence reclassification.

**Omitted mechanisms:** Complete upfront platform; Immediate elimination of all clones; A universal ban on atomic cutover.

**Evidence:** Actual transfer, configuration migration and residual-consumer evidence at consequential steps.

**Failure boundary:** Endpoint-only validation, absent data reconciliation, unfunded coexistence or missing repair route.

**Transition/retirement:** Complete only on a residual-obligation witness; use quiescent cutover, stop consolidation or retain justified separation when necessary.

**Frozen ancestry:** `ESA:ESA-CFG05`, `ESME:ESME-CFG006`, `ESPLE:ESPLE-ALT-03`.

### SSS-CFG006 — Decentralised family or independently owned ecosystem

**Kind:** BASE_CONFIGURATION. **Trigger:** Independent owners share interfaces or assets but have not delegated universal product or release control.

**Required functions:** Negotiated semantic/interface boundaries; Real scoped contribution and acceptance rights; Consumer-directed communication; Explicit unsupported or separate products.

**Omitted mechanisms:** Fictitious central family owner; Mandatory unified release; One-feature/one-team or one-service mapping.

**Evidence:** Each claimed compatibility or shared assurance result identifies the participating products and organisational reach.

**Failure boundary:** Internal derivation authority is extrapolated to autonomous participants or conflicting obligations are hidden.

**Transition/retirement:** Split over-centralised arrangements, narrow shared contracts or end coordination when its actual consumers disappear.

**Frozen ancestry:** `ESA:ESA-CFG02`, `ESA:ESA-CFG05`, `ESME:ESME-CFG005`, `ESPLE:ESPLE-ALT-05`.

### SSS-CFG007 — Restricted servicing with supported older baselines

**Kind:** BASE_CONFIGURATION. **Trigger:** A useful product or family remains supportable for limited repair while broader evolution is not currently justified.

**Required functions:** Honest supported versions and willing capacity; Bounded repairs and relevant compatibility checks; Known limitation and retirement/revival triggers; Purpose-relevant baseline retention.

**Omitted mechanisms:** Mandatory feature growth; Assumed irreversible loss of future evolution; Full new-product variability admission.

**Evidence:** Practical support and actual repair capability, not lifecycle labels or age alone.

**Failure boundary:** A promised support path is infeasible, or servicing is used to conceal unowned obligations.

**Transition/retirement:** Reassess actual revival feasibility, transfer support, or retire responsibly; do not infer impossibility from the stage label.

**Frozen ancestry:** `ESA:ESA-CFG01`, `ESME:ESME-CFG011`, `ESPLE:ESPLE-ALT-01`, `ESPLE:ESPLE-ALT-06`.

### SSS-CFG008 — Retirement, consolidation and purpose-specific preservation

**Kind:** BASE_CONFIGURATION. **Trigger:** Prospective value/support no longer justifies continued service or variability, subject to residual obligations.

**Required functions:** Actionable consumer/support disposition; Verified closure or transfer of operative paths; Explicit historical retrieval/execution purpose where retained; Separate old-product support and new-product admission decisions.

**Omitted mechanisms:** Permanent live operation solely to preserve history; Retention of every obsolete control; Universal immediate deletion.

**Evidence:** Observed closure and separate successful retrieval or reproduction of what is deliberately retained.

**Failure boundary:** A declaration of completion hides older consumers, data authority, recovery use or unavailable archives.

**Transition/retirement:** Terminate each mechanism at its own justified boundary; reclassify warranted continuing coexistence honestly.

**Frozen ancestry:** `ESA:ESA-CFG01`, `ESME:ESME-CFG008`, `ESPLE:ESPLE-ALT-06`.

### SSS-CFG009 — Bounded runtime-variable family

**Kind:** OVERLAY. **Trigger:** A real runtime need outweighs earlier binding or restart alternatives and adequate observation/control is feasible.

**Required functions:** Permitted configuration/context mapping; Actual actuation and post-change observation; Transition/state continuity and residual recovery; Policy/oracle revision boundaries.

**Omitted mechanisms:** Open-ended self-authorisation; Assumption that endpoint validity proves transition safety; Supervisory synthesis where its plant assumptions do not hold.

**Evidence:** A valid observation/plant/action envelope and evidence of consequential reachable-state obligations.

**Failure boundary:** Lost observer validity, uncontrolled events, incompatible controller interaction or an unavailable promised repair route.

**Transition/retirement:** Interrupt unsupported actions, enter a separately justified safe phase, bind earlier or return to authorised operator control.

**Frozen ancestry:** `ESA:ESA-CFG04`, `ESME:ESME-CFG004`, `ESPLE:ESPLE-ALT-04`.

### SSS-CFG010 — High-assurance architectural or family subset

**Kind:** OVERLAY. **Trigger:** A material property has tractable formal semantics and the implementation/environment mapping can be checked.

**Required functions:** Explicit quantified model and assumptions; Separate model, engine and implementation evidence; Checked composition premises; Restriction of unsupported configurations or transitions.

**Omitted mechanisms:** Whole-system correctness by local theorem; Mandatory universal formal language; Assumption that a solver gives operational permission.

**Evidence:** Precisely scoped proofs/analyses plus needed correspondence and environmental observations; preserve formal exclusions.

**Failure boundary:** Model drift, unsupported feature language, missing controllability or an unjustified lift to global progress.

**Transition/retirement:** Narrow the modelled subset, choose a different transition strategy or use cheaper adequate evidence when the protected concern ends.

**Frozen ancestry:** `ESA:ESA-CFG03`, `ESME:ESME-CFG003`, `ESPLE:ESPLE-ALT-02`, `ESPLE:ESPLE-ALT-04`.

### SSS-CFG011 — Bounded emergency or staged live intervention

**Kind:** OVERLAY. **Trigger:** Urgent containment or production-only uncertainty warrants a genuinely bounded live action.

**Required functions:** Accepted loss/authority envelope; Identifiable actual exposed products and baselines; Actionable observation and effect-aware recovery; Owned follow-up and unsupported-expansion stop.

**Omitted mechanisms:** Automatic promotion on missing signals; Universal canary percentage or duration; Requirement to migrate every product together.

**Evidence:** Representative isolatable exposure or an explicit containment rationale; observation must discriminate and reach someone able to act.

**Failure boundary:** Shared state defeats isolation, telemetry is absent, or temporary degradation silently becomes indefinite unowned support.

**Transition/retirement:** Expand only on applicable evidence, stop or repair adverse effects, and close/reclassify the temporary arrangement on its own obligations.

**Frozen ancestry:** `ESA:ESA-CFG02`, `ESME:ESME-CFG004`, `ESME:ESME-CFG002`, `ESPLE:ESPLE-ALT-01`.

## 9. Sources, independence and evidence ceilings

All **217 lineage-local source records** are retained with their original claim/access partitions and exact source-record locators. They are not 217 independent empirical studies, and agreement among three lineages does not triple confidence. Historical material, formal theorems, standards/guidance, industrial case evidence, empirical evaluations and analytical deductions retain their different inferential roles. Metadata-only access is not promoted to full-text inspection, and a narrow theorem is not extended to an unmatched plant or population.

Six material shared-work identity groups were resolved from the frozen bibliographic/version/URL/access records. Five link the same work and edition/revision at the level justified by those records. One links an original work and reprint while preserving distinct edition/access accounts. No additional literature access was necessary. A shared source establishes ancestry dependence, not property equivalence or an independent effect estimate.
**SSS-SRC001 — Mass Produced Software Components.** Records: `ESA:ESA-S007`, `ESPLE:ESPLE-S001`. Same author-hosted 1998 transcription of the 1968 contribution/1969 report. The two access scopes differ; neither is a new industrial outcome study.

**SSS-SRC002 — Designing Software for Ease of Extension and Contraction.** Records: `ESA:ESA-S006`, `ESPLE:ESPLE-S003`. Same author, 1979 journal work and hosted PDF; architectural constructibility is not independent family-economic corroboration.

**SSS-SRC003 — On the Design and Development of Program Families.** Records: `ESA:ESA-S064`, `ESPLE:ESPLE-S002`. The frozen ESA record identifies a later collected reprint by metadata; ESPLE identifies the 1976 journal work through limited metadata/abstract access. Work ancestry is shared; exact inspected edition equality is not asserted and neither access is upgraded.

**SSS-SRC004 — The WyCash Portfolio Management System.** Records: `ESA:ESA-S049`, `ESME:ESME-CS027`. Same 1992 author account and URL, not two independent debt studies.

**SSS-SRC005 — Strangler Fig Application, revised 2024.** Records: `ESA:ESA-S040`, `ESME:ESME-CS031`. Both identify the 2024 revised article. ESME-CS030 is the distinct 2004 antecedent and is not merged.

**SSS-SRC006 — Hidden Technical Debt in Machine Learning Systems.** Records: `ESA:ESA-S056`, `ESME:ESME-CS062`. Same 2015 paper, authors and URL. Experienced engineering analysis is not a controlled causal comparison or independent replication across lineages.

The source ledger also retains the complete inherited source-table dependence metadata and highlights programme-level cautions: architecture/product-line programme publications, common family/architecture genealogy, shared variability analysis infrastructure and datasets, and changing automation benchmarks. Distinct titles or publication dates alone do not establish independent evidence. Conversely, different works within one programme are not casually collapsed into one citation. An independent empirical-study denominator remains undetermined.

## 10. Negative findings and unresolved limits

All **43 adverse, ceremony-only, no-general-property or superseded rows**, **four unresolved rows**, and **one contested row** remain in the register and the later intake. Context-dependent, assumption-sensitive, domain-specific, gameable and bureaucratisation-prone rows likewise remain unchanged; they are not silently upgraded to universal controls.

The five primary open/contested property records are:
**ESA:ESA-060 — Autonomous architecting under open-ended requirements:** `UNRESOLVED`. ["Reopen when representative end-to-end evidence or a rigorously bounded new capability materially changes the claim."]

**ESME:ESME-C082 — Transition to servicing is effectively irreversible:** `CONTESTED`. [{"INPUT_PROPERTY_KEY": "A:ESME-075", "QUESTIONS": ["Can a bounded recovery effort restore the needed change capability at acceptable cost?"]}]

**ESME:ESME-C095 — Long-term net maintainability benefit of AI-assisted evolution:** `UNRESOLVED`. [{"INPUT_PROPERTY_KEY": "A:ESME-088", "QUESTIONS": ["What multi-release evidence would distinguish genuine maintainability gains from deferred review and regression costs?"]}]

**ESME:ESME-C100 — Reliable unattended repository-scale maintenance as a general capability:** `UNRESOLVED`. [{"INPUT_PROPERTY_KEY": "B:ESME-069", "QUESTIONS": ["Can independently evaluated unattended systems sustain correct, authorised and economical maintenance across representative repositories over time?"]}]

**ESPLE:ESPLE-048 — LLM regeneration as a superior replacement for maintained variability:** `UNRESOLVED`. ["Does regeneration preserve family obligations and reduce total lifecycle burden under a credible repeated-change comparison?"]

The seven exclusive open-pair cells ask whether architectural autonomy, long-term assisted maintainability, unattended maintenance and regeneration can establish durable authorised lifecycle capability, and whether disputed servicing irreversibility can be reversed by such capabilities. These are unresolved stronger questions, not unexamined pairs. The formal-progress asymmetry is a known limitation of the proposed entailment; its missing common model is separately retained as a tension remainder rather than converted into a fictitious positive theorem.

The fourteen inherited composition questions continue to matter. Their principal unresolved themes are the cost and net benefit of the complete arrangement; economical adequacy of scenario, dependency and joint-state abstractions; hidden consumers and irreversible external effects; legitimate conflicts among stakeholders; affordable evidence binding/invalidation across tools; real plant/observer correspondence for dynamic families; and reconciliation among independently owned models and products. No universal break-even threshold, globally complete tractable model, universally correct control budget or automatic source of authority is established.

The final synthesis does not claim to resolve every uncertainty by adding a ledger. Ledgers can be stale, expensive, unused or misleading. A bounded direct check, an already adequate artefact, a local repair, an independently maintained product or deliberate non-change may be the appropriate outcome under the inherited criteria.

## 11. Separate review, repairs and reproducibility

A separate read-only checker reopens the original archives, verifies their hashes and exact manifests, compares all original property/source objects, checks normalised field projections, reconstructs the relation signatures from the declared rules, enumerates the full pair universe and validates forward/reverse references. It also checks clusters and tensions, the fourteen rejected-candidate accounts, the complete intake, alternatives, nonserial model references and report counts. Twelve analytical examples are re-executed. Eight in-memory invariant-level negative controls confirm rejection of a missing property, changed name, missing/flipped pair, dangling relation, accidental asymmetric mirror, phantom induced row and collapsed source record. These are not represented as eight full mutated-archive campaigns.

The semantic readback separately challenged bearer overreach, higher-order novelty, formal-liveness upgrades, compulsory family adoption, support retirement, false independence, open automation premises and control accumulation. Three execution/projection issues were repaired before freezing: cluster-context references now require actual endpoint membership; an ESA reopening field is no longer semantically equated with retirement; and witness readback compares canonical JSON rather than unequal in-memory tuple/list representations. None changed a frozen constituent definition or disposition.

**Independence boundary:** the checking implementation and execution are separate from the authoring module, but the semantic synthesis and adversarial readback were conducted by the same executor. No second scholar or model assessor participated. Mechanical completeness, successful finite examples and custody checks do not independently certify the truth or empirical adequacy of the synthesis. The review is procedural/reconstruction independence, not independent academic validation.

To reproduce the read-only checks after extracting the final archive, run:

```bash
python analysis/verify_sss.py . --stage full
python analysis/finite_counterexamples.py
```

The manifest inventories every payload except itself, avoiding a circular self-hash. The internal verification receipt records verified pre-archive logic and the review boundary. The enclosing ZIP’s final bytes/hash, close/reopen CRC, exact members, member hashes and fresh extraction/readback results are recorded in the separately delivered archive-verification receipt. That detached receipt is not a hidden missing research payload; it is the necessary outer custody evidence for the final ZIP.

## 12. Later inter-crosswalk intake and public use

The later intake exports **235 + 0 = 235 properties**, individually and without a retained-only filter. Each row carries its original identity, disposition, bearer/criterion, actual trigger and cheaper path, mechanism, authority, communication, evidence ceiling, costs/failure context, criticism, omission/retirement conditions, source IDs, and SSS relation/cluster/tension references. A later comparison must adjudicate those rows individually; a shared outside implementation mechanism would not erase their separate scholarly identities.

No outside-trifecta comparison, IMPLEMENTAUDIT crosswalk, Rockstar/RXX derivation, repository mutation, target-owner assignment or target adoption was performed. The packet is a frozen research intake for that later, separately authorised work, not an implementation instruction or a command to adopt SSS wholesale. It remains legitimate to conclude that a property’s trigger is absent, its cheaper path is adequate, its evidence is insufficient, or its negative finding rules out the proposed use.

The public-documentation intake explains the same boundary: established underlying fields; analytical evolved studies and synthesis; source-limited deductions rather than a historical school; no universal empirical superiority; and legitimate simpler arrangements and non-adoption paths.

## 13. Machine-readable report accounting

This block is compared byte-semantically after JSON parsing with the accounting payload by the final read-only verifier.

<!-- SSS_ACCOUNTING_BEGIN -->
```json
{
  "revision": "SSS-2026-09-06-r1",
  "inherited_property_rows": 235,
  "source_rows": 217,
  "pair_counts": {
    "ESA_ESME": 7140,
    "ESA_ESPLE": 4216,
    "ESME_ESPLE": 6510
  },
  "pair_status_counts": {
    "MATERIAL_RELATION": 3539,
    "NO_MATERIAL_RELATION": 14320,
    "UNRESOLVED_RELATION": 7
  },
  "directional_relation_records": 6832,
  "directional_material_relation_records": 6825,
  "convergence_and_composition_clusters": 34,
  "many_to_one_clusters": 23,
  "one_to_many_clusters": 11,
  "tensions": 16,
  "alternative_configurations": 11,
  "surviving_composition_induced_properties": 0,
  "pairwise_induced_properties": 0,
  "three_way_induced_properties": 0,
  "rejected_emergent_candidates": 14,
  "later_inter_crosswalk_population": 235,
  "shared_work_groups": 6,
  "exact_work_edition_groups": 5,
  "work_reprint_groups_not_collapsed": 1,
  "source_rows_in_shared_work_groups": 12,
  "negative_dispositions_retained": 43,
  "unresolved_dispositions_retained": 4,
  "contested_dispositions_retained": 1,
  "property_rows_with_no_material_or_unresolved_relations": 0,
  "property_dispositions_by_lineage": {
    "ESA": {
      "RETAINED_IN_EVOLVED_FORM": 15,
      "STRONGLY_RETAINED": 9,
      "CONTEXT_DEPENDENT": 13,
      "NO_GENERAL_PROPERTY": 1,
      "ASSUMPTION_SENSITIVE": 8,
      "DOMAIN_SPECIFIC": 8,
      "REJECTED_OR_DISFAVOURED": 8,
      "CEREMONY_NOT_GENERAL_PROPERTY": 2,
      "USEFUL_BUT_EASILY_GAMED": 2,
      "SUPERSEDED_BY_STRONGER_FORM": 1,
      "UNRESOLVED": 1
    },
    "ESME": {
      "STRONGLY_RETAINED": 16,
      "RETAINED_IN_EVOLVED_FORM": 25,
      "CONTEXT_DEPENDENT": 20,
      "SUPERSEDED_BY_STRONGER_FORM": 1,
      "REJECTED_OR_DISFAVOURED": 16,
      "ASSUMPTION_SENSITIVE": 15,
      "USEFUL_BUT_EASILY_BUREAUCRATISED": 2,
      "USEFUL_BUT_EASILY_GAMED": 2,
      "CEREMONY_NOT_GENERAL_PROPERTY": 2,
      "DOMAIN_SPECIFIC": 3,
      "CONTESTED": 1,
      "UNRESOLVED": 2
    },
    "ESPLE": {
      "STRONGLY_RETAINED": 9,
      "RETAINED_IN_EVOLVED_FORM": 18,
      "CONTEXT_DEPENDENT": 12,
      "USEFUL_BUT_EASILY_BUREAUCRATISED": 1,
      "DOMAIN_SPECIFIC": 4,
      "ASSUMPTION_SENSITIVE": 4,
      "UNRESOLVED": 1,
      "REJECTED_OR_DISFAVOURED": 9,
      "CEREMONY_NOT_GENERAL_PROPERTY": 1,
      "NO_GENERAL_PROPERTY": 2,
      "USEFUL_BUT_EASILY_GAMED": 1
    }
  }
}
```
<!-- SSS_ACCOUNTING_END -->
