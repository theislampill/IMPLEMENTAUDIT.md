# Evolved Software Maintenance and Evolution — public-documentation intake

**Research revision:** ESME-R2-2026-09-06  
**Research cut-off:** 6 September 2026  
**Status:** complete explanatory intake for a frozen external study; no host-system adoption is asserted.

## Introduction suitable for a public page

Software maintenance and evolution is the established study and practice of keeping existing software useful under changing requirements, environments and support conditions. It includes far more than repairing defects: understanding and recovering knowledge, analysing change effects, restructuring software, preserving relevant behaviour, migrating data and responsibilities, sustaining maintainers and eventually ending support or operation. Its history is plural: purpose classifications, Lehman and Belady’s evolution programme, program slicing and comprehension, configuration management, reverse engineering, refactoring and legacy migration each address different objects and failure mechanisms. Later taxonomies, empirical work and current standards refine these branches rather than replace them with one universally superior method. [ESME-S001, preview §§3–5; ESME-S004, §§1–3; ESME-S008–010; ESME-S014–019; ESME-S022; ESME-S029.]

**Evolved Software Maintenance and Evolution** is the name of this study’s criticism-tested analytical synthesis, not a claim that an academic school with that compound name already exists. Its central principle is **justified continuity under change**: decide what should change, what should survive and what may legitimately end; obtain enough understanding and evidence for that decision; and act through actual maintenance capability and authority. Continued stable use, local repair, restructuring, migration and retirement remain alternatives. The full candidate population is preserved separately, including rejected, superseded, duplicate, contested and unresolved findings.

## Evolution under criticism

The field’s useful mechanisms survive by acquiring clearer boundaries. Historical evolution laws cannot be applied as physical laws to every software population. Static and dynamic views answer different questions and do not automatically recover intent. A refactoring rule, a correct engine and an economically useful transformation are separate claims. Regression selection is relative to a suite and assumptions; passing tests cannot establish untested requirements. Migration needs valid intermediate states and consumers, not merely a successful endpoint demonstration. Debt describes contingent future-change liabilities rather than every unwanted task. Maintainer popularity and authorship measures do not establish practical support capacity. [ESME-S009–012, ESME-S015–018, ESME-S021–026, ESME-S029, ESME-S032, ESME-S045–049, ESME-S057–060.]

Adverse evidence changes the synthesis. The 2022 maintenance standard includes additive maintenance, defeating four-category exhaustiveness. Refactoring-engine and regression-selection studies expose actual implementation and dependency limitations. Repair studies distinguish patch plausibility, correctness and the validity of the evaluation harness. Recent issue-solving work shows that a reference patch or test can disagree with a candidate without establishing which behaviour is justified. Consequently, the evolved account preserves legitimate objective clarification and independently warranted oracle revision rather than treating every green result or old behaviour as authoritative. [ESME-S001; ESME-S024; ESME-S034; ESME-S045; ESME-S063–064.]

## How the parts form a system

An objective constrains the comprehension question, impact boundary and required evidence. New observations can reopen any of these. Actual release and data effects constrain available recovery, while maintainership and lifecycle cost can change the choice between further repair, migration and retirement. This is an interacting decision system, not a forced serial pipeline or an obligation to use every technique simultaneously.

The composition adds six explicitly analytical coupling properties: keep intent/baseline/observers/evidence aligned; reconsider evidence when its assumptions change; recognise when effect recovery options change; establish when a transition is genuinely finished; choose proportionate combined controls; and justify oracle revision independently of a candidate passing the revised test. These are reasoned synthesis claims, not empirically proven superiority of the combined system. One existing mechanism may realise several of them.

## Strongest surviving distinctions

The strongest core is an explicit justified change intention, an identifiable baseline, bounded comprehension and impact, observer-relative preservation, distinct change and regression obligations, effect-relative recovery, practical human/consumer continuity and an economically defensible lifecycle choice. A diagnosis does not itself authorise an operation. Performing an operation does not by itself establish the intended consequence. A supported claim must name what its evidence can discriminate and what remains outside its scope.

A minimal form can be small: an accepted issue, a relevant baseline/diff, a capable actor, adequate local evidence and an appropriate continuation or recovery decision. Richer documentation, models or coordination earn their place when the risk and consumer require them. A stable useful system can warrant no change. Retiring a control or service can be responsible rather than evidence of immaturity.

## Caricatures and ceremonies to avoid

Do not describe maintenance as only bug fixing, evolution as compulsory growth, reverse engineering as necessarily changing its subject, refactoring as automatically improving maintainability, a successful test suite as proof of complete correctness, a code revert as undoing all effects, technical debt as every defect, or automation as removing the need for intent and review. Equally, do not dismiss useful documents or formal models merely because they are artefacts: their function is judged through a consumer, an adequate postcondition and a proportionate cost.

## Citation-ready factual claims

The entries below separate source-supported statements from the study’s analytical conclusions. Use the exact work and access limit; do not cite an abstract as though its full methods were inspected.

### PC01 — SOURCE_SUPPORTED_DEFINITION

ISO/IEC/IEEE 14764:2022 includes additive maintenance alongside adaptive, corrective, perfective and preventive maintenance; its terminology is not exhausted by the familiar four labels.

**Sources:** ESME-S001. **Locators:** Preview §3.1.2 and Figure 1 within §3.1.8 notes (printed pp.2 and 4).

**Limit:** Only official metadata and the lawful preview were inspected, not the entire standard.

### PC02 — SOURCE_SUPPORTED_TAXONOMY

Purpose classifications and activity-based or multidimensional classifications answer different questions about software change.

**Sources:** ESME-S004, ESME-S005. **Locators:** Chapin §§1–3; Buckley taxonomy dimensions and figure.

**Limit:** No single taxonomy is demonstrated optimal for every maintenance decision.

### PC03 — SOURCE_SUPPORTED_SCOPE

Lehman’s later laws explicitly concern E-type systems and feedback with a changing application environment.

**Sources:** ESME-S009, ESME-S010. **Locators:** Inspected S/P/E discussion and E-type/eight-laws text.

**Limit:** This is not a universal physical law or a prescription for continual growth.

### PC04 — SOURCE_SUPPORTED_DEFINITION

Chikofsky and Cross distinguish reverse engineering, redocumentation, design recovery, restructuring and re-engineering; reverse engineering does not itself alter the subject.

**Sources:** ESME-S014. **Locators:** Printed pp.13–17, definitions and diagram.

**Limit:** This taxonomy does not supply a mandatory serial lifecycle.

### PC05 — SOURCE_SUPPORTED_FORMAL_SCOPE

Static and dynamic slicing have different analysis scopes; a dynamic slice is tied to an execution.

**Sources:** ESME-S015, ESME-S043. **Locators:** Weiser pp.352–357; Agrawal and Horgan pp.246–247.

**Limit:** The full dynamic-slicing work was only partially accessible; no complete proof is reconstructed.

### PC06 — SOURCE_SUPPORTED_MODEL_LIMIT

Opdyke’s preservation account has explicit modelling and representation-sensitive limits.

**Sources:** ESME-S022. **Locators:** §4.1, printed p.42.

**Limit:** Do not extend it to excluded layout, reflection, foreign-interface or other observers without further evidence.

### PC07 — SOURCE_SUPPORTED_NEGATIVE_EVIDENCE

Refactoring engines and regression-selection tools can have implementation defects or unsupported dependency cases despite the intended method.

**Sources:** ESME-S024, ESME-S045. **Locators:** RTSCheck results/manual classification; ASTGen evaluation.

**Limit:** Generated test populations and tool versions do not establish a universal deployed defect rate.

### PC08 — SOURCE_SUPPORTED_HISTORICAL_PROVENANCE

Cunningham’s 1992 debt metaphor arose in a particular software-product experience and related expedient implementation to later consolidation.

**Sources:** ESME-S027. **Locators:** Author-hosted WyCash text.

**Limit:** It is not a financial accounting model or evidence that all debt is deliberate.

### PC09 — SOURCE_SUPPORTED_SEMANTICS

HTTP deprecation and anticipated endpoint unresponsiveness are distinct signals in RFC 9745 and RFC 8594.

**Sources:** ESME-S053, ESME-S054. **Locators:** RFC 8594 §§1–2; RFC 9745 semantics and §7.

**Limit:** Signals do not establish that consumers received or acted on them.

### PC10 — SOURCE_SUPPORTED_INCIDENT

GitLab’s January 2017 incident account identifies failed recovery assumptions, including a database-version mismatch in backup tooling.

**Sources:** ESME-S062. **Locators:** Postmortem backup/recovery and contributing factors.

**Limit:** One incident is not a frequency estimate, and a remediation plan is not evidence of later completion.

### PC11 — SOURCE_SUPPORTED_BOUNDED_EMPIRICAL

The 2025 METR study reported longer completion time with the tested AI workflow in its experienced-developer task population; its 2026 follow-up explicitly warns that its newer estimate is unreliable.

**Sources:** ESME-S036, ESME-S037. **Locators:** 2025 results/method; 2026 follow-up selection and timing limitations.

**Limit:** Neither establishes that all AI assistance is always slower or faster.

### PC12 — SOURCE_SUPPORTED_EVALUATION_LIMIT

Recent repository-patch evaluations distinguish additional-test failures, candidate/reference disagreement and issue/PR misalignment.

**Sources:** ESME-S063, ESME-S064. **Locators:** Patch-correctness method/manual review; PAIChecker method/misalignment findings.

**Limit:** Different denominators cannot be merged; suspicious differences are not automatically incorrect patches.

### PC13 — RESEARCHER_INTERPRETATION

A coherent maintenance system should couple legitimate intent, scoped evidence, actual effects and lifecycle alternatives without making every technique mandatory.

**Sources:** ESME-S001, ESME-S019, ESME-S022, ESME-S025, ESME-S029, ESME-S041, ESME-S049, ESME-S051, ESME-S058, ESME-S063, ESME-S064. **Locators:** This report’s composed-system section and ESME-093–098; antecedent locators in source table.

**Limit:** This combined system has not been empirically validated as a whole.

## Suggested page outline

A public page can proceed from “What maintenance and evolution studies”, through “Plural historical roots”, “What criticism changed”, “A conditional system of continuity and change”, “Strong core and optional mechanisms”, “Evidence and current research limits”, and finally “Sources and the complete research corpus”. The explanatory introduction is not a substitute for the property denominator or evidence tables.

## Claims not to make

Do not invent a historical founder or consensus for the “Evolved” label. Do not describe historical laws as universal causal guarantees, a model-bound preservation result as a guarantee for all environments, or standards as empirical proof of benefit. Do not generalise isolated deployments, selected benchmarks, self-reports or incident accounts into universal success rates. Do not count shared datasets or revised editions as independent replications.

Do not equate popularity, newer languages, more automation, zero debt or more process with maturity. Do not imply all 98 candidates are retained or that the 78 crosswalk-worthy records require 78 controls. Do not turn contested servicing irreversibility or unresolved long-term AI benefit into accepted facts. Do not claim a host system implements, conforms to or benefits from these properties without a separate evidence-based assessment. No downstream adoption is established by this intake.

## Complete corpus accounting

98 candidates are examined: 66 EXAMINED and 32 EXAMINED_WITH_EVIDENCE_LIMIT. There are 15 strongly retained, 31 retained in evolved form, 16 context-dependent, seven assumption-sensitive, five domain-specific, two easily gamed and two easily bureaucratised candidates. The other 20 comprise 15 rejected/disfavoured, one ceremonial proxy, one superseded claim, one duplicate, one contested claim and one unresolved claim. Six of the retained/assumption-sensitive records are expressly analytical composition-induced properties. All ten mandatory families are examined. Source access limits and combined-system validity limits remain part of the frozen judgement.
