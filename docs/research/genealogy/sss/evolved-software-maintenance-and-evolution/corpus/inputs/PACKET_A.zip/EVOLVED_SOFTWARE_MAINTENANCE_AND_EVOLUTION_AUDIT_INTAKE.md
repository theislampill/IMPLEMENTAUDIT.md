# Evolved Software Maintenance and Evolution — complete audit intake

**Lineage:** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION`  
**Revision:** `ESME-R2-2026-09-06`  
**Research cut-off:** 2026-09-06  
**Intended use:** a later, separate audit of an unspecified real software system.  
**Authority:** this research and these questions authorise no target mutation or adoption.

## Scope and counting

Independent study of software maintenance and evolution across existing software’s useful life: classification, evolution feedback, comprehension, impact, preservation, regression/release evidence, migration, economics, human/ecosystem continuity and contemporary automation. Hardware maintainability, general operations, whole security engineering and sibling syntheses are outside the lane except for documented intersections necessary to explain change.

The frozen population is **98 / 98 examined**, with **66 EXAMINED** and **32 EXAMINED_WITH_EVIDENCE_LIMIT**. All **10 / 10** mandatory domain families are examined. The source register contains **67 exact works/editions**, not 67 independent experiments. There are **78 conditionally crosswalk-worthy candidates**, **20 non-active candidates**, **six analytical composition-induced candidates**, **52 typed composition relations**, **22 criticism entries**, **16 ceremony-stripping entries** and **eight internal tensions**. Counts preserve unfavourable outcomes rather than equating research completeness with retention.

## How to use the intake without presuming a gap

Begin with the target’s actual change classes, supported consumers, obligations and available evidence. For each applicable candidate, first determine whether its function is already addressed. Acceptable outcomes include **already adequately addressed**, **inapplicable**, **simpler mechanism sufficient**, **credible improvement opportunity**, **evidence insufficient**, and **legitimately unresolved**. A named tool, document, owner or source property does not by itself demonstrate either a gap or its closure. A source-grounded criterion may be realised by an existing mechanism that serves several concerns.

The questions below distinguish the criterion, the operating mechanism and the evidence needed to judge their coupling. Do not impose a new control for each row. Preserve the original ID and disposition when creating a later crosswalk; a target judgement is a separate record. No content in this intake answers a question about a particular repository or software product.

## Evidence partitions and transfer burdens

Provenance, theory, comparative evidence, field experience, replication, contrary findings and transferability remain separate. Model-bound slicing, transformation and regression-selection claims need the target’s semantics and tool assumptions. Version-skew schema claims have only abstract-level source access in this corpus. Practitioner release/migration mechanisms and incident observations do not supply universal success rates. Debt and comprehension measurements retain their self-report/observational or selected-population limits. Human capability cannot be inferred solely from authorship. Recent automation results need matching model/tool/task/hardware context and total human-work accounting.

The six composition-induced candidates are analytical, with no direct comparative validation of the complete combined mechanism. Their audit value is a reasoned possible failure to examine, not evidence that an additional process will necessarily pay for itself. ESME-075 is contested; ESME-088 unresolved. The appropriate target response can be a bounded local experiment, acceptance of residual uncertainty, non-use or continuation without a new mechanism.

## Primary dispositions

| Disposition | Count |
| --- | --- |
| ASSUMPTION_SENSITIVE | 7 |
| CEREMONY_NOT_GENERAL_PROPERTY | 1 |
| CONTESTED | 1 |
| CONTEXT_DEPENDENT | 16 |
| DOMAIN_SPECIFIC | 5 |
| DUPLICATE_CANDIDATE | 1 |
| REJECTED_OR_DISFAVOURED | 15 |
| RETAINED_IN_EVOLVED_FORM | 31 |
| STRONGLY_RETAINED | 15 |
| SUPERSEDED_BY_STRONGER_FORM | 1 |
| UNRESOLVED | 1 |
| USEFUL_BUT_EASILY_BUREAUCRATISED | 2 |
| USEFUL_BUT_EASILY_GAMED | 2 |

## Complete ID inventory

| ID | Candidate | Disposition |
| --- | --- | --- |
| ESME-001 | Explicit change objective and authorised obligation revision | STRONGLY_RETAINED |
| ESME-002 | Purpose-and-activity classification without false exclusivity | RETAINED_IN_EVOLVED_FORM |
| ESME-003 | Maintenance includes non-code artefacts and readiness | RETAINED_IN_EVOLVED_FORM |
| ESME-004 | Recoverable and identifiable configuration baseline | STRONGLY_RETAINED |
| ESME-005 | Emergency stabilisation separated from permanent repair | CONTEXT_DEPENDENT |
| ESME-006 | Four categories as a universally exhaustive taxonomy | SUPERSEDED_BY_STRONGER_FORM |
| ESME-007 | Environment-relative usefulness feedback | RETAINED_IN_EVOLVED_FORM |
| ESME-008 | Universal growth and inevitable deterioration | REJECTED_OR_DISFAVOURED |
| ESME-009 | Population- and metric-conditioned evolution claims | STRONGLY_RETAINED |
| ESME-010 | Familiarity and capacity as feedback constraints | ASSUMPTION_SENSITIVE |
| ESME-011 | Invariant organisational work rate as a planning law | REJECTED_OR_DISFAVOURED |
| ESME-012 | Bounded change-specific comprehension | STRONGLY_RETAINED |
| ESME-013 | Criterion-relative conservative static slicing | ASSUMPTION_SENSITIVE |
| ESME-014 | Execution-relative dynamic observation and slicing | CONTEXT_DEPENDENT |
| ESME-015 | Design recovery includes domain and human knowledge | RETAINED_IN_EVOLVED_FORM |
| ESME-016 | Faithful redocumentation with an actual consumer | USEFUL_BUT_EASILY_BUREAUCRATISED |
| ESME-017 | Reverse engineering itself modifies the subject | REJECTED_OR_DISFAVOURED |
| ESME-018 | Exhaustive comprehension before every change | REJECTED_OR_DISFAVOURED |
| ESME-019 | Feature-location hypotheses and interactive refinement | CONTEXT_DEPENDENT |
| ESME-020 | Evidence-fused architecture and behaviour recovery | CONTEXT_DEPENDENT |
| ESME-021 | Explicit multi-artefact impact boundary | STRONGLY_RETAINED |
| ESME-022 | Historical co-change as fallible guidance | CONTEXT_DEPENDENT |
| ESME-023 | Co-change correlation proves necessary dependency | REJECTED_OR_DISFAVOURED |
| ESME-024 | Build, configuration and generated-artefact dependency closure | RETAINED_IN_EVOLVED_FORM |
| ESME-025 | Observer-specific API and protocol compatibility | RETAINED_IN_EVOLVED_FORM |
| ESME-026 | Version labels prove compatibility | REJECTED_OR_DISFAVOURED |
| ESME-027 | Concurrent-change semantic validation | RETAINED_IN_EVOLVED_FORM |
| ESME-028 | Observer-relative preservation in refactoring | STRONGLY_RETAINED |
| ESME-029 | Transformation precondition enforcement | ASSUMPTION_SENSITIVE |
| ESME-030 | Validation of transformation engines | RETAINED_IN_EVOLVED_FORM |
| ESME-031 | Refactoring payoff tied to a future change class | RETAINED_IN_EVOLVED_FORM |
| ESME-032 | Maintainability metrics as fallible diagnostics | USEFUL_BUT_EASILY_GAMED |
| ESME-033 | Catalogue compliance as a maintenance property | CEREMONY_NOT_GENERAL_PROPERTY |
| ESME-034 | Characterisation tests with normative review | RETAINED_IN_EVOLVED_FORM |
| ESME-035 | Independent change and regression obligations | STRONGLY_RETAINED |
| ESME-036 | Regression selection with suite-relative safety | ASSUMPTION_SENSITIVE |
| ESME-037 | Test prioritisation for early information | CONTEXT_DEPENDENT |
| ESME-038 | Mutation analysis as an adequacy diagnostic | CONTEXT_DEPENDENT |
| ESME-039 | Differential and metamorphic evidence without an infallible oracle | RETAINED_IN_EVOLVED_FORM |
| ESME-040 | Passing all selected tests proves correctness | REJECTED_OR_DISFAVOURED |
| ESME-041 | Reproducible build and artefact identity | RETAINED_IN_EVOLVED_FORM |
| ESME-042 | Continuous integration as integration feedback | CONTEXT_DEPENDENT |
| ESME-043 | Observation-aware staged exposure | CONTEXT_DEPENDENT |
| ESME-044 | Effect-aware recovery and forward repair | STRONGLY_RETAINED |
| ESME-045 | Bounded local repair as an alternative to restructuring | CONTEXT_DEPENDENT |
| ESME-046 | Legacy value distinguished from technical age | STRONGLY_RETAINED |
| ESME-047 | Explicit comparison of modernisation alternatives | RETAINED_IN_EVOLVED_FORM |
| ESME-048 | Incremental substitution through valid migration seams | CONTEXT_DEPENDENT |
| ESME-049 | Atomic replacement where coexistence is the greater risk | CONTEXT_DEPENDENT |
| ESME-050 | Data-conversion invariants and reconciliation | STRONGLY_RETAINED |
| ESME-051 | Compatibility of intermediate and mixed-version states | ASSUMPTION_SENSITIVE |
| ESME-052 | Coexistence budget and explicit exit | RETAINED_IN_EVOLVED_FORM |
| ESME-053 | Rewrites are always wrong | REJECTED_OR_DISFAVOURED |
| ESME-054 | Newest language or platform is the mature form | REJECTED_OR_DISFAVOURED |
| ESME-055 | Reverting code reverses the system | REJECTED_OR_DISFAVOURED |
| ESME-056 | Technical debt as a contingent future-change liability | RETAINED_IN_EVOLVED_FORM |
| ESME-057 | Actionable debt records with a consumer | USEFUL_BUT_EASILY_BUREAUCRATISED |
| ESME-058 | Lifecycle-cost and value-based prioritisation | RETAINED_IN_EVOLVED_FORM |
| ESME-059 | Option-preserving deferral and deliberate non-repayment | CONTEXT_DEPENDENT |
| ESME-060 | Visibility of future cost bearers and participation | RETAINED_IN_EVOLVED_FORM |
| ESME-061 | Zero technical debt as the objective | REJECTED_OR_DISFAVOURED |
| ESME-062 | A universal maintainability index proves future savings | REJECTED_OR_DISFAVOURED |
| ESME-063 | Retained rationale through actual use | STRONGLY_RETAINED |
| ESME-064 | Knowledge succession and demonstrated onboarding | RETAINED_IN_EVOLVED_FORM |
| ESME-065 | Scoped ownership and change coordination | CONTEXT_DEPENDENT |
| ESME-066 | Finite maintainer capacity and realistic support commitments | RETAINED_IN_EVOLVED_FORM |
| ESME-067 | Knowledge-concentration metrics as fallible prompts | USEFUL_BUT_EASILY_GAMED |
| ESME-068 | Dependency inventory and update trade-offs | RETAINED_IN_EVOLVED_FORM |
| ESME-069 | Downstream communication that enables action | STRONGLY_RETAINED |
| ESME-070 | Deprecation signalling separated from shutdown | DOMAIN_SPECIFIC |
| ESME-071 | Responsible retirement with discharged obligations | RETAINED_IN_EVOLVED_FORM |
| ESME-072 | Purpose-bounded archival preservation and reproducibility | CONTEXT_DEPENDENT |
| ESME-073 | Popularity guarantees dependency continuity | REJECTED_OR_DISFAVOURED |
| ESME-074 | Stable useful software may justify no change | STRONGLY_RETAINED |
| ESME-075 | Transition to servicing is effectively irreversible | CONTESTED |
| ESME-076 | Generated patches remain candidates for justified repair | RETAINED_IN_EVOLVED_FORM |
| ESME-077 | Validation of the evaluation harness itself | STRONGLY_RETAINED |
| ESME-078 | Benchmark provenance and contamination limits | RETAINED_IN_EVOLVED_FORM |
| ESME-079 | Issue, reference patch and test objective alignment | STRONGLY_RETAINED |
| ESME-080 | Total human–automation workflow cost | RETAINED_IN_EVOLVED_FORM |
| ESME-081 | Version-bound automation evidence and revalidation | RETAINED_IN_EVOLVED_FORM |
| ESME-082 | Repair automation resource trade-offs | DOMAIN_SPECIFIC |
| ESME-083 | Automated semantic-conflict detection as supplementary evidence | DOMAIN_SPECIFIC |
| ESME-084 | Learned-system data and configuration dependencies | DOMAIN_SPECIFIC |
| ESME-085 | Feedback and drift as preservation-boundary changes | ASSUMPTION_SENSITIVE |
| ESME-086 | Artefact-appropriate validation for non-code evolution | RETAINED_IN_EVOLVED_FORM |
| ESME-087 | A generated insight does not authorise mutation | DUPLICATE_CANDIDATE |
| ESME-088 | Long-term net maintainability benefit of AI-assisted evolution | UNRESOLVED |
| ESME-089 | Deletion or degradation requires an explicit containment objective | DOMAIN_SPECIFIC |
| ESME-090 | Universal autonomous maintenance without residual review or authority | REJECTED_OR_DISFAVOURED |
| ESME-091 | Every historical behaviour must be preserved | REJECTED_OR_DISFAVOURED |
| ESME-092 | Supported-version and variant obligation matrix | CONTEXT_DEPENDENT |
| ESME-093 | Composition-induced change–obligation contract | RETAINED_IN_EVOLVED_FORM |
| ESME-094 | Composition-induced assumption-indexed evidence invalidation | RETAINED_IN_EVOLVED_FORM |
| ESME-095 | Composition-induced effect-relative returnability frontier | ASSUMPTION_SENSITIVE |
| ESME-096 | Composition-induced coexistence termination witness | RETAINED_IN_EVOLVED_FORM |
| ESME-097 | Composition-induced proportional control and retirement | RETAINED_IN_EVOLVED_FORM |
| ESME-098 | Composition-induced independent warrant for oracle revision | RETAINED_IN_EVOLVED_FORM |

## Crosswalk-worthy records

Each record carries its own trigger, non-trigger, prerequisites, domain profile, consumer, criticism and neutral questions. “Retained” always remains subject to these conditions. The complete claim-level evidence partitions are reproduced compactly and resolve to the source-table JSON by source ID.

### ESME-001 — Explicit change objective and authorised obligation revision

**Disposition and kind.** STRONGLY_RETAINED; CRITERION_COUPLED_TO_DECISION

**Mature form.** Retain explicit intent while allowing brief local decisions and escalation only for actual conflicts.

**Controlled failure.** Source-supported: issue/PR/test disagreement can leave correctness indeterminate. Analytical: a formal approval can still exclude affected people.

**Operating mechanism.** State the intended difference, affected obligations, legitimate decision maker and acceptance question before endorsing an intervention.

**Trigger.** A request, discovered defect or environmental pressure proposes changing an existing commitment.

**Non-trigger and cheap path.** A short accepted issue with concrete examples is enough for a bounded low-risk change; reject or defer an unjustified request.

**Prerequisites.** Conditions: Decision authority and domain meaning must be established; disputed intent cannot be resolved by test count.; Related property ids: ESME-035; ESME-063; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Those entitled to request or rely on the behaviour, not merely the test author.; Decision: An authorised change objective and explicit preserved or revised obligations can be compared with the actual result.

**Authority and practical action.** Actors: Those entitled to request or rely on the behaviour, not merely the test author.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** An authorised change objective and explicit preserved or revised obligations can be compared with the actual result. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S025; ESME-S063; ESME-S064; Adjudication: Source-supported: issue/PR/test disagreement can leave correctness indeterminate. Analytical: a formal approval can still exclude affected people.; Effect on disposition: Retain explicit intent while allowing brief local decisions and escalation only for actual conflicts.

**Anti-ceremony boundary.** Essential: An authorised change objective and explicit preserved or revised obligations can be compared with the actual result.; Minimal alternative: A short accepted issue with concrete examples is enough for a bounded low-risk change; reject or defer an unjustified request.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A short accepted issue with concrete examples is enough for a bounded low-risk change; reject or defer an unjustified request. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T01; Discriminator: Identify the actual obligation, consumer and authorisation for revision; unresolved authority blocks that revision, not unrelated work.; Hybrid failure: Two ambiguous meanings, unmaintained compatibility mode, or an oracle changed solely to pass.

**Composition coupling.** ESME-R001; ESME-R003; ESME-R022; ESME-R026; ESME-R029; ESME-R030; ESME-R035; ESME-R037

#### Domain profile

**Change intent and change class.** A request, discovered defect or environmental pressure proposes changing an existing commitment. Identify whose intended result is changing and distinguish corrective, adaptive, perfective, preventive, additive and emergency dimensions without forcing exclusivity.

**Baseline and affected artefacts.** Change request, affected behaviour and requirements history. Requests, contracts, code, data, configuration, manuals and maintenance readiness can all be affected.

**Preservation obligation and observer.** Those entitled to request or rely on the behaviour, not merely the test author. A request owner or affected stakeholder supplies legitimate intent; observation of existing behaviour alone cannot authorise its preservation or revision.

**Impact boundary and dependency evidence.** Classification and request history help orient impact inquiry but do not replace dependency evidence.

**Comprehension assumptions.** Decision authority and domain meaning must be established; disputed intent cannot be resolved by test count. The requester and maintainer must share enough domain meaning to distinguish a fault from a newly desired behaviour.

**Oracle and regression limits.** Acceptance examples can misunderstand the request; separately inspect preserved obligations.

**Compatibility and migration preconditions.** A purpose label says nothing by itself about API or schema compatibility; determine these where an intervention reaches them.

**Release rollback or forward repair condition.** Classification is informational; any subsequent intervention must separately justify code, state and external-effect recovery.

**Maintainer and downstream consumers.** Requesting/accepting stakeholders, maintainers and affected consumers need a shared account of what is and is not promised.

**Lifecycle cost and retirement condition.** A short accepted issue with concrete examples is enough for a bounded low-risk change; reject or defer an unjustified request. Reject, defer or retire work without a justified benefit or surviving obligation; abandon redundant classification paperwork.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S001.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S063; ESME-S064; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S025; ESME-S063; ESME-S064; Reason: Source-supported: issue/PR/test disagreement can leave correctness indeterminate. Analytical: a formal approval can still exclude affected people.

**Transferability.** Assessment: CONDITIONAL; Reason: Decision authority and domain meaning must be established; disputed intent cannot be resolved by test count. Which affected stakeholder is missing from the stated acceptance question?

**Source IDs:** ESME-S001, ESME-S004, ESME-S041, ESME-S025, ESME-S063, ESME-S064. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which affected stakeholder is missing from the stated acceptance question?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-002 — Purpose-and-activity classification without false exclusivity

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; MODELLING_CRITERION

**Mature form.** Multiple orthogonal descriptors replace an exhaustive four-box ontology.

**Controlled failure.** Source-supported: survey and measured activity distributions differ; categories are not interchangeable.

**Operating mechanism.** Use purpose labels alongside observable activity and artefact scope, permitting multiple purposes; include additive and emergency distinctions when using the 2022 terminology.

**Trigger.** Classification affects estimates, authorisation, reporting or selection of maintenance evidence.

**Non-trigger and cheap path.** Do not label every commit when the label changes no decision; one explanatory sentence may suffice.

**Prerequisites.** Conditions: The taxonomy edition, unit and use must be declared.; Related property ids: ESME-001; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Request owner for intention; analyst for observed activities.; Decision: A mixed change can be described without hiding one purpose or treating a statistic from another taxonomy as comparable.

**Authority and practical action.** Actors: Request owner for intention; analyst for observed activities.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** A mixed change can be described without hiding one purpose or treating a statistic from another taxonomy as comparable. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S004; ESME-S007; Adjudication: Source-supported: survey and measured activity distributions differ; categories are not interchangeable.; Effect on disposition: Multiple orthogonal descriptors replace an exhaustive four-box ontology.

**Anti-ceremony boundary.** Essential: A mixed change can be described without hiding one purpose or treating a statistic from another taxonomy as comparable.; Minimal alternative: Do not label every commit when the label changes no decision; one explanatory sentence may suffice.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Do not label every commit when the label changes no decision; one explanatory sentence may suffice. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R001; ESME-R036

#### Domain profile

**Change intent and change class.** Classification affects estimates, authorisation, reporting or selection of maintenance evidence. Identify whose intended result is changing and distinguish corrective, adaptive, perfective, preventive, additive and emergency dimensions without forcing exclusivity.

**Baseline and affected artefacts.** Request intent and actual changed artefacts. Requests, contracts, code, data, configuration, manuals and maintenance readiness can all be affected.

**Preservation obligation and observer.** Request owner for intention; analyst for observed activities. A request owner or affected stakeholder supplies legitimate intent; observation of existing behaviour alone cannot authorise its preservation or revision.

**Impact boundary and dependency evidence.** Classification and request history help orient impact inquiry but do not replace dependency evidence.

**Comprehension assumptions.** The taxonomy edition, unit and use must be declared. The requester and maintainer must share enough domain meaning to distinguish a fault from a newly desired behaviour.

**Oracle and regression limits.** Acceptance examples can misunderstand the request; separately inspect preserved obligations.

**Compatibility and migration preconditions.** A purpose label says nothing by itself about API or schema compatibility; determine these where an intervention reaches them.

**Release rollback or forward repair condition.** Classification is informational; any subsequent intervention must separately justify code, state and external-effect recovery.

**Maintainer and downstream consumers.** Requesting/accepting stakeholders, maintainers and affected consumers need a shared account of what is and is not promised.

**Lifecycle cost and retirement condition.** Do not label every commit when the label changes no decision; one explanatory sentence may suffice. Reject, defer or retire work without a justified benefit or surviving obligation; abandon redundant classification paperwork.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S001, ESME-S007.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S007; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S004; ESME-S007; Reason: Source-supported: survey and measured activity distributions differ; categories are not interchangeable.

**Transferability.** Assessment: CONDITIONAL; Reason: The taxonomy edition, unit and use must be declared. Does this classification change a decision, and are compared measurements commensurable?

**Source IDs:** ESME-S001, ESME-S004, ESME-S005, ESME-S041, ESME-S007. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Does this classification change a decision, and are compared measurements commensurable?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-003 — Maintenance includes non-code artefacts and readiness

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; SCOPE_CRITERION

**Mature form.** Scope follows consequential artefacts, not a delivery-date boundary.

**Controlled failure.** Source-supported: omitted non-code dependencies can break test selection; ML configuration can carry substantial system logic.

**Operating mechanism.** Include the artefacts and pre-delivery arrangements required to maintain an existing capability: build, configuration, data, documentation and transition knowledge.

**Trigger.** A future or current maintenance task depends on non-code state or transfer readiness.

**Non-trigger and cheap path.** Exclude irrelevant artefacts explicitly rather than constructing an organisation-wide inventory for a local task.

**Prerequisites.** Conditions: Artefact relevance must be tied to a concrete maintenance obligation.; Related property ids: ESME-004; ESME-021; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Maintainer, operator and downstream consumer of the actual artefact.; Decision: Necessary non-code changes and readiness dependencies are included in scope and assigned a consumer.

**Authority and practical action.** Actors: Maintainer, operator and downstream consumer of the actual artefact.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Necessary non-code changes and readiness dependencies are included in scope and assigned a consumer. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S024; ESME-S061; Adjudication: Source-supported: omitted non-code dependencies can break test selection; ML configuration can carry substantial system logic.; Effect on disposition: Scope follows consequential artefacts, not a delivery-date boundary.

**Anti-ceremony boundary.** Essential: Necessary non-code changes and readiness dependencies are included in scope and assigned a consumer.; Minimal alternative: Exclude irrelevant artefacts explicitly rather than constructing an organisation-wide inventory for a local task.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Exclude irrelevant artefacts explicitly rather than constructing an organisation-wide inventory for a local task. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R001

#### Domain profile

**Change intent and change class.** A future or current maintenance task depends on non-code state or transfer readiness. Identify whose intended result is changing and distinguish corrective, adaptive, perfective, preventive, additive and emergency dimensions without forcing exclusivity.

**Baseline and affected artefacts.** Code, build inputs, schemas, configurations, operational instructions and handover material. Requests, contracts, code, data, configuration, manuals and maintenance readiness can all be affected.

**Preservation obligation and observer.** Maintainer, operator and downstream consumer of the actual artefact. A request owner or affected stakeholder supplies legitimate intent; observation of existing behaviour alone cannot authorise its preservation or revision.

**Impact boundary and dependency evidence.** Classification and request history help orient impact inquiry but do not replace dependency evidence.

**Comprehension assumptions.** Artefact relevance must be tied to a concrete maintenance obligation. The requester and maintainer must share enough domain meaning to distinguish a fault from a newly desired behaviour.

**Oracle and regression limits.** Acceptance examples can misunderstand the request; separately inspect preserved obligations.

**Compatibility and migration preconditions.** A purpose label says nothing by itself about API or schema compatibility; determine these where an intervention reaches them.

**Release rollback or forward repair condition.** Classification is informational; any subsequent intervention must separately justify code, state and external-effect recovery.

**Maintainer and downstream consumers.** Requesting/accepting stakeholders, maintainers and affected consumers need a shared account of what is and is not promised.

**Lifecycle cost and retirement condition.** Exclude irrelevant artefacts explicitly rather than constructing an organisation-wide inventory for a local task. Reject, defer or retire work without a justified benefit or surviving obligation; abandon redundant classification paperwork.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S001.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S024; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S061; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S024; ESME-S061; Reason: Source-supported: omitted non-code dependencies can break test selection; ML configuration can carry substantial system logic.

**Transferability.** Assessment: CONDITIONAL; Reason: Artefact relevance must be tied to a concrete maintenance obligation. What relevant non-code state is currently outside the impact account?

**Source IDs:** ESME-S001, ESME-S006, ESME-S041, ESME-S024, ESME-S061. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What relevant non-code state is currently outside the impact account?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-004 — Recoverable and identifiable configuration baseline

**Disposition and kind.** STRONGLY_RETAINED; OPERATING_MECHANISM

**Mature form.** Treat baseline as a resolvable configuration rather than a repository tag alone.

**Controlled failure.** Source-supported: source identity alone does not guarantee reproducible packaging or usable backups.

**Operating mechanism.** Identify and retain the exact baseline and configuration needed to interpret, build, compare or restore the changed system.

**Trigger.** An intervention or investigation requires attributing differences or returning to a known state.

**Non-trigger and cheap path.** A versioned file and recorded command can suffice for a local deterministic artefact; retain richer dependencies only where needed.

**Prerequisites.** Conditions: Referenced artefacts remain accessible and configuration identifiers resolve.; Related property ids: ESME-041; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Reviewer and operator comparing the same system, not merely matching a branch name.; Decision: Another authorised maintainer can locate the baseline and reproduce the relevant comparison; restoration is separately tested.

**Authority and practical action.** Actors: Reviewer and operator comparing the same system, not merely matching a branch name.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Another authorised maintainer can locate the baseline and reproduce the relevant comparison; restoration is separately tested. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S052; ESME-S062; Adjudication: Source-supported: source identity alone does not guarantee reproducible packaging or usable backups.; Effect on disposition: Treat baseline as a resolvable configuration rather than a repository tag alone.

**Anti-ceremony boundary.** Essential: Another authorised maintainer can locate the baseline and reproduce the relevant comparison; restoration is separately tested.; Minimal alternative: A versioned file and recorded command can suffice for a local deterministic artefact; retain richer dependencies only where needed.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A versioned file and recorded command can suffice for a local deterministic artefact; retain richer dependencies only where needed. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T08; Discriminator: Ask what future consumer must actually be able to do: retrieve, interpret, execute or receive service.; Hybrid failure: An archive is advertised as runnable despite missing dependencies, or an obsolete service is kept live without a support purpose.

**Composition coupling.** ESME-R002; ESME-R021; ESME-R030; ESME-R031

#### Domain profile

**Change intent and change class.** An intervention or investigation requires attributing differences or returning to a known state. Identify whose intended result is changing and distinguish corrective, adaptive, perfective, preventive, additive and emergency dimensions without forcing exclusivity.

**Baseline and affected artefacts.** Source revision, build inputs, package versions, configuration and relevant data-state reference. Requests, contracts, code, data, configuration, manuals and maintenance readiness can all be affected.

**Preservation obligation and observer.** Reviewer and operator comparing the same system, not merely matching a branch name. A request owner or affected stakeholder supplies legitimate intent; observation of existing behaviour alone cannot authorise its preservation or revision.

**Impact boundary and dependency evidence.** Classification and request history help orient impact inquiry but do not replace dependency evidence.

**Comprehension assumptions.** Referenced artefacts remain accessible and configuration identifiers resolve. The requester and maintainer must share enough domain meaning to distinguish a fault from a newly desired behaviour.

**Oracle and regression limits.** Acceptance examples can misunderstand the request; separately inspect preserved obligations.

**Compatibility and migration preconditions.** A purpose label says nothing by itself about API or schema compatibility; determine these where an intervention reaches them.

**Release rollback or forward repair condition.** Classification is informational; any subsequent intervention must separately justify code, state and external-effect recovery.

**Maintainer and downstream consumers.** Requesting/accepting stakeholders, maintainers and affected consumers need a shared account of what is and is not promised.

**Lifecycle cost and retirement condition.** A versioned file and recorded command can suffice for a local deterministic artefact; retain richer dependencies only where needed. Reject, defer or retire work without a justified benefit or surviving obligation; abandon redundant classification paperwork.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S052; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S050; ESME-S062; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S052; ESME-S062; Reason: Source-supported: source identity alone does not guarantee reproducible packaging or usable backups.

**Transferability.** Assessment: CONDITIONAL; Reason: Referenced artefacts remain accessible and configuration identifiers resolve. Which mutable or external input prevents the baseline from denoting one relevant state?

**Source IDs:** ESME-S019, ESME-S041, ESME-S050, ESME-S052, ESME-S062. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which mutable or external input prevents the baseline from denoting one relevant state?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-005 — Emergency stabilisation separated from permanent repair

**Disposition and kind.** CONTEXT_DEPENDENT; OPERATING_BRANCH

**Mature form.** Temporary success is judged against containment intent and cannot certify permanent restoration.

**Controlled failure.** Source-supported: deletion patches can pass weak tests. Analytical: an emergency label can launder permanent feature removal.

**Operating mechanism.** Authorise a bounded containment objective, record intentionally lost behaviour and establish review or expiry conditions for the temporary state.

**Trigger.** Continuing the current fault causes greater immediate harm than a controlled degraded state.

**Non-trigger and cheap path.** Use normal repair when delay is tolerable; do not invent an emergency fast lane for ordinary convenience.

**Prerequisites.** Conditions: Containment scope, operational capability and recovery or follow-up must be credible.; Related property ids: ESME-001; ESME-044; ESME-089; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Affected users and the person authorised to accept temporary degradation.; Decision: Temporary degradation and its accepted scope are visible, with a named follow-up decision rather than presumed final correctness.

**Authority and practical action.** Actors: Affected users and the person authorised to accept temporary degradation.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Temporary degradation and its accepted scope are visible, with a named follow-up decision rather than presumed final correctness. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S034; ESME-S062; Adjudication: Source-supported: deletion patches can pass weak tests. Analytical: an emergency label can launder permanent feature removal.; Effect on disposition: Temporary success is judged against containment intent and cannot certify permanent restoration.

**Anti-ceremony boundary.** Essential: Temporary degradation and its accepted scope are visible, with a named follow-up decision rather than presumed final correctness.; Minimal alternative: Use normal repair when delay is tolerable; do not invent an emergency fast lane for ordinary convenience.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Use normal repair when delay is tolerable; do not invent an emergency fast lane for ordinary convenience. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R029

#### Domain profile

**Change intent and change class.** Continuing the current fault causes greater immediate harm than a controlled degraded state. Identify whose intended result is changing and distinguish corrective, adaptive, perfective, preventive, additive and emergency dimensions without forcing exclusivity.

**Baseline and affected artefacts.** Live service, temporary configuration or patch and follow-up obligation. Requests, contracts, code, data, configuration, manuals and maintenance readiness can all be affected.

**Preservation obligation and observer.** Affected users and the person authorised to accept temporary degradation. A request owner or affected stakeholder supplies legitimate intent; observation of existing behaviour alone cannot authorise its preservation or revision.

**Impact boundary and dependency evidence.** Classification and request history help orient impact inquiry but do not replace dependency evidence.

**Comprehension assumptions.** Containment scope, operational capability and recovery or follow-up must be credible. The requester and maintainer must share enough domain meaning to distinguish a fault from a newly desired behaviour.

**Oracle and regression limits.** Acceptance examples can misunderstand the request; separately inspect preserved obligations.

**Compatibility and migration preconditions.** A purpose label says nothing by itself about API or schema compatibility; determine these where an intervention reaches them.

**Release rollback or forward repair condition.** Classification is informational; any subsequent intervention must separately justify code, state and external-effect recovery.

**Maintainer and downstream consumers.** Requesting/accepting stakeholders, maintainers and affected consumers need a shared account of what is and is not promised.

**Lifecycle cost and retirement condition.** Use normal repair when delay is tolerable; do not invent an emergency fast lane for ordinary convenience. Reject, defer or retire work without a justified benefit or surviving obligation; abandon redundant classification paperwork.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S001.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S034; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S062; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S034; ESME-S062; Reason: Source-supported: deletion patches can pass weak tests. Analytical: an emergency label can launder permanent feature removal.

**Transferability.** Assessment: CONDITIONAL; Reason: Containment scope, operational capability and recovery or follow-up must be credible. What event ends the emergency exception, and who accepts residual loss?

**Source IDs:** ESME-S001, ESME-S041, ESME-S034, ESME-S062. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What event ends the emergency exception, and who accepts residual loss?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-007 — Environment-relative usefulness feedback

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; FEEDBACK_MECHANISM

**Mature form.** Retain feedback and reject a universal prescription for continuing growth.

**Controlled failure.** Source-supported: empirical growth trajectories vary. Analytical: demand for more features is not automatically legitimate value.

**Operating mechanism.** Observe changes in use, expectations and constraints; decide whether adaptation, servicing, unchanged operation or retirement best preserves justified usefulness.

**Trigger.** Evidence of changed environment, user dissatisfaction or new constraints, not age alone.

**Non-trigger and cheap path.** For a stable environment, use occasional review or existing user feedback rather than continuous change.

**Prerequisites.** Conditions: Environmental observations must be relevant and not just proxy growth metrics.; Related property ids: ESME-001; ESME-074; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Users and stakeholders whose activity the software serves.; Decision: An identified change in environmental fit has a reasoned response, which may be no change.

**Authority and practical action.** Actors: Users and stakeholders whose activity the software serves.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** An identified change in environmental fit has a reasoned response, which may be no change. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S011; ESME-S012; Adjudication: Source-supported: empirical growth trajectories vary. Analytical: demand for more features is not automatically legitimate value.; Effect on disposition: Retain feedback and reject a universal prescription for continuing growth.

**Anti-ceremony boundary.** Essential: An identified change in environmental fit has a reasoned response, which may be no change.; Minimal alternative: For a stable environment, use occasional review or existing user feedback rather than continuous change.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** For a stable environment, use occasional review or existing user feedback rather than continuous change. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R003; ESME-R038

#### Domain profile

**Change intent and change class.** Evidence of changed environment, user dissatisfaction or new constraints, not age alone. Study environmental fit, complexity, familiarity and change rate; do not infer a mandate to grow from an observed growth curve.

**Baseline and affected artefacts.** System-environment relationship and observed user outcomes. Fix the sampled release stream, artefact boundary, organisation and time unit before interpreting a trajectory.

**Preservation obligation and observer.** Users and stakeholders whose activity the software serves. Usefulness belongs to actual users and environments; LOC, release size and observed effort are different observables.

**Impact boundary and dependency evidence.** Feedback crosses users, organisation and technical structure; correlation alone does not identify a causal channel.

**Comprehension assumptions.** Environmental observations must be relevant and not just proxy growth metrics. Maintainers must understand what a metric counts and which environmental assumptions remained stable.

**Oracle and regression limits.** Historical fit does not validate future predictions; a counterexample may concern sampling rather than the whole theory.

**Compatibility and migration preconditions.** A historical trend does not establish a compatibility constraint; such obligations require separate consumer evidence.

**Release rollback or forward repair condition.** The explanatory model does not deploy code: operational rollback is not applicable until a concrete intervention is chosen.

**Maintainer and downstream consumers.** Analysts explain conditional trends to those deciding staffing, investment, evolution, servicing or closure.

**Lifecycle cost and retirement condition.** For a stable environment, use occasional review or existing user feedback rather than continuous change. Retain a useful unchanged system where obligations permit; retire a metric or model when its measurement assumptions no longer hold.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S011; ESME-S012; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S008; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S011; ESME-S012; Reason: Source-supported: empirical growth trajectories vary. Analytical: demand for more features is not automatically legitimate value.

**Transferability.** Assessment: CONDITIONAL; Reason: Environmental observations must be relevant and not just proxy growth metrics. What observation would show that unchanged operation remains adequate?

**Source IDs:** ESME-S008, ESME-S009, ESME-S010, ESME-S011, ESME-S012. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What observation would show that unchanged operation remains adequate?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-009 — Population- and metric-conditioned evolution claims

**Disposition and kind.** STRONGLY_RETAINED; EVIDENCE_CRITERION

**Mature form.** Scope and provenance become part of the claim rather than a footnote.

**Controlled failure.** Source-supported: Linux growth interpretation changes with release/artefact selection; survey versus measured categories differ.

**Operating mechanism.** Bind an evolution claim to system population, stable/development stream, measured unit and environmental context; compare unlike studies only after reconciling these.

**Trigger.** Growth, complexity, effort or decline measurements guide investment or generalisation.

**Non-trigger and cheap path.** Use a simple trend with explicit units when it directly answers the decision; no statistical model is mandatory.

**Prerequisites.** Conditions: Consistent measurement and a declared transfer population.; Related property ids: ESME-007; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Analyst and decision maker interpreting the metric.; Decision: The claim states its population and measure, and contrary samples remain visible.

**Authority and practical action.** Actors: Analyst and decision maker interpreting the metric.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The claim states its population and measure, and contrary samples remain visible. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S007; Adjudication: Source-supported: Linux growth interpretation changes with release/artefact selection; survey versus measured categories differ.; Effect on disposition: Scope and provenance become part of the claim rather than a footnote.

**Anti-ceremony boundary.** Essential: The claim states its population and measure, and contrary samples remain visible.; Minimal alternative: Use a simple trend with explicit units when it directly answers the decision; no statistical model is mandatory.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Use a simple trend with explicit units when it directly answers the decision; no statistical model is mandatory. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R003; ESME-R038

#### Domain profile

**Change intent and change class.** Growth, complexity, effort or decline measurements guide investment or generalisation. Study environmental fit, complexity, familiarity and change rate; do not infer a mandate to grow from an observed growth curve.

**Baseline and affected artefacts.** Release sample, size/function/effort measures and data-extraction rules. Fix the sampled release stream, artefact boundary, organisation and time unit before interpreting a trajectory.

**Preservation obligation and observer.** Analyst and decision maker interpreting the metric. Usefulness belongs to actual users and environments; LOC, release size and observed effort are different observables.

**Impact boundary and dependency evidence.** Feedback crosses users, organisation and technical structure; correlation alone does not identify a causal channel.

**Comprehension assumptions.** Consistent measurement and a declared transfer population. Maintainers must understand what a metric counts and which environmental assumptions remained stable.

**Oracle and regression limits.** Historical fit does not validate future predictions; a counterexample may concern sampling rather than the whole theory.

**Compatibility and migration preconditions.** A historical trend does not establish a compatibility constraint; such obligations require separate consumer evidence.

**Release rollback or forward repair condition.** The explanatory model does not deploy code: operational rollback is not applicable until a concrete intervention is chosen.

**Maintainer and downstream consumers.** Analysts explain conditional trends to those deciding staffing, investment, evolution, servicing or closure.

**Lifecycle cost and retirement condition.** Use a simple trend with explicit units when it directly answers the decision; no statistical model is mandatory. Retain a useful unchanged system where obligations permit; retire a metric or model when its measurement assumptions no longer hold.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S007.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S011; ESME-S012; ESME-S007; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S008; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S007; Reason: Source-supported: Linux growth interpretation changes with release/artefact selection; survey versus measured categories differ.

**Transferability.** Assessment: CONDITIONAL; Reason: Consistent measurement and a declared transfer population. Would a different legitimate sampling rule reverse the conclusion?

**Source IDs:** ESME-S008, ESME-S010, ESME-S011, ESME-S012, ESME-S007. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Would a different legitimate sampling rule reverse the conclusion?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-010 — Familiarity and capacity as feedback constraints

**Disposition and kind.** ASSUMPTION_SENSITIVE; ORGANISATIONAL_FEEDBACK_HYPOTHESIS

**Mature form.** Retain capacity-sensitive feedback, not invariant work-rate or mandatory change-size ceilings.

**Controlled failure.** Source-supported: comprehension consumes substantial observed time but is not one universal proportion; AI time effects vary by setting.

**Operating mechanism.** Use observed comprehension, review and recovery demand to constrain change intake and invest in knowledge when understanding becomes a bottleneck.

**Trigger.** Change volume or personnel turnover outpaces demonstrated ability to understand and maintain obligations.

**Non-trigger and cheap path.** A small expert-maintained component may need only a direct conversation and modest change cadence.

**Prerequisites.** Conditions: Workload signals must distinguish familiarity from tooling, task complexity and organisational restrictions.; Related property ids: ESME-012; ESME-064; ESME-066; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Maintainers and those allocating time, not a fixed universal staffing formula.; Decision: The selected workload can be understood and supported by available people, with bottlenecks made explicit.

**Authority and practical action.** Actors: Maintainers and those allocating time, not a fixed universal staffing formula.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The selected workload can be understood and supported by available people, with bottlenecks made explicit. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S018; ESME-S036; ESME-S037; Adjudication: Source-supported: comprehension consumes substantial observed time but is not one universal proportion; AI time effects vary by setting.; Effect on disposition: Retain capacity-sensitive feedback, not invariant work-rate or mandatory change-size ceilings.

**Anti-ceremony boundary.** Essential: The selected workload can be understood and supported by available people, with bottlenecks made explicit.; Minimal alternative: A small expert-maintained component may need only a direct conversation and modest change cadence.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A small expert-maintained component may need only a direct conversation and modest change cadence. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T02; Discriminator: Compare demonstrated next-change capability and total transition cost, not complexity score alone.; Hybrid failure: Long-lived mixed styles and half-transferred knowledge make both old and new harder to understand.

**Composition coupling.** ESME-R003; ESME-R038

#### Domain profile

**Change intent and change class.** Change volume or personnel turnover outpaces demonstrated ability to understand and maintain obligations. Study environmental fit, complexity, familiarity and change rate; do not infer a mandate to grow from an observed growth curve.

**Baseline and affected artefacts.** Maintainer knowledge, workload, change volume and review outcomes. Fix the sampled release stream, artefact boundary, organisation and time unit before interpreting a trajectory.

**Preservation obligation and observer.** Maintainers and those allocating time, not a fixed universal staffing formula. Usefulness belongs to actual users and environments; LOC, release size and observed effort are different observables.

**Impact boundary and dependency evidence.** Feedback crosses users, organisation and technical structure; correlation alone does not identify a causal channel.

**Comprehension assumptions.** Workload signals must distinguish familiarity from tooling, task complexity and organisational restrictions. Maintainers must understand what a metric counts and which environmental assumptions remained stable.

**Oracle and regression limits.** Historical fit does not validate future predictions; a counterexample may concern sampling rather than the whole theory.

**Compatibility and migration preconditions.** A historical trend does not establish a compatibility constraint; such obligations require separate consumer evidence.

**Release rollback or forward repair condition.** The explanatory model does not deploy code: operational rollback is not applicable until a concrete intervention is chosen.

**Maintainer and downstream consumers.** Analysts explain conditional trends to those deciding staffing, investment, evolution, servicing or closure.

**Lifecycle cost and retirement condition.** A small expert-maintained component may need only a direct conversation and modest change cadence. Retain a useful unchanged system where obligations permit; retire a metric or model when its measurement assumptions no longer hold.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S036; ESME-S037; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S013; ESME-S016; ESME-S018; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S018; ESME-S036; ESME-S037; Reason: Source-supported: comprehension consumes substantial observed time but is not one universal proportion; AI time effects vary by setting.

**Transferability.** Assessment: CONDITIONAL; Reason: Workload signals must distinguish familiarity from tooling, task complexity and organisational restrictions. Is apparent capacity loss caused by missing knowledge or by another constraint?

**Source IDs:** ESME-S010, ESME-S013, ESME-S016, ESME-S018, ESME-S036, ESME-S037. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Is apparent capacity loss caused by missing knowledge or by another constraint?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-012 — Bounded change-specific comprehension

**Disposition and kind.** STRONGLY_RETAINED; INQUIRY_MECHANISM

**Mature form.** Question-led, revisable comprehension replaces an exhaustive prerequisite.

**Controlled failure.** Source-supported: slices and traces omit different things; documentation alone cannot replace all tacit knowledge.

**Operating mechanism.** Establish enough understanding to discriminate the pending change decision; expand inquiry when observed contradictions or impact escape invalidate that boundary.

**Trigger.** A maintainer cannot explain the relevant effect or uncertainty of a proposed intervention.

**Non-trigger and cheap path.** Inspect the relevant code, test and domain example directly for a small familiar change; avoid mandatory reconstruction of everything.

**Prerequisites.** Conditions: The pending decision and consequential unknowns must be stated.; Related property ids: ESME-001; ESME-021; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Maintainer and reviewer who must act, with domain experts where intent is lost.; Decision: The maintainer can answer the consequential change questions and state remaining uncertainty.

**Authority and practical action.** Actors: Maintainer and reviewer who must act, with domain experts where intent is lost.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The maintainer can answer the consequential change questions and state remaining uncertainty. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S015; ESME-S043; Adjudication: Source-supported: slices and traces omit different things; documentation alone cannot replace all tacit knowledge.; Effect on disposition: Question-led, revisable comprehension replaces an exhaustive prerequisite.

**Anti-ceremony boundary.** Essential: The maintainer can answer the consequential change questions and state remaining uncertainty.; Minimal alternative: Inspect the relevant code, test and domain example directly for a small familiar change; avoid mandatory reconstruction of everything.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Inspect the relevant code, test and domain example directly for a small familiar change; avoid mandatory reconstruction of everything. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T02; Discriminator: Compare demonstrated next-change capability and total transition cost, not complexity score alone.; Hybrid failure: Long-lived mixed styles and half-transferred knowledge make both old and new harder to understand.

**Composition coupling.** ESME-R001; ESME-R002; ESME-R004; ESME-R006; ESME-R022; ESME-R023; ESME-R034; ESME-R039

#### Domain profile

**Change intent and change class.** A maintainer cannot explain the relevant effect or uncertainty of a proposed intervention. Select the question needed for a proposed change, diagnosis or handover rather than presupposing whole-system understanding.

**Baseline and affected artefacts.** The affected feature and evidence needed for the current decision. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.

**Preservation obligation and observer.** Maintainer and reviewer who must act, with domain experts where intent is lost. Distinguish a recovered description from an authorised requirement and from what an actual user can observe.

**Impact boundary and dependency evidence.** Static relations overapproximate modelled paths; dynamic traces underapproximate possible executions; fuse only with declared boundaries.

**Comprehension assumptions.** The pending decision and consequential unknowns must be stated. Incomplete intent, unsupported languages, generated code and tacit operational knowledge limit recovery.

**Oracle and regression limits.** Recovered models require cross-checking; observed behaviour can be a defect and absent evidence is not evidence of absence.

**Compatibility and migration preconditions.** Recovery may reveal interface or migration assumptions but cannot itself establish their validity.

**Release rollback or forward repair condition.** Read-only inquiry normally needs no production rollback; intrusive instrumentation must control perturbation and cleanup.

**Maintainer and downstream consumers.** Maintainers and domain/operational experts exchange concrete questions and evidence; documentation is useful through an actual consumer.

**Lifecycle cost and retirement condition.** Inspect the relevant code, test and domain example directly for a small familiar change; avoid mandatory reconstruction of everything. Stop inquiry when it discriminates the pending decision sufficiently; deepen it when contradictions or impact escape appear; retire stale views.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S017; ESME-S015; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S016; ESME-S017; ESME-S018; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S015; ESME-S043; Reason: Source-supported: slices and traces omit different things; documentation alone cannot replace all tacit knowledge.

**Transferability.** Assessment: CONDITIONAL; Reason: The pending decision and consequential unknowns must be stated. Which unanswered question could actually alter the next decision?

**Source IDs:** ESME-S014, ESME-S016, ESME-S017, ESME-S018, ESME-S015, ESME-S043. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which unanswered question could actually alter the next decision?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-013 — Criterion-relative conservative static slicing

**Disposition and kind.** ASSUMPTION_SENSITIVE; FORMAL_ANALYSIS_MECHANISM

**Mature form.** Retain conservative relevance under assumptions, not minimality or whole-system understanding.

**Controlled failure.** Source-supported: minimality limits and large slices; student-scale evidence does not establish industrial productivity.

**Operating mechanism.** Choose a slicing criterion and use sound dependency analysis to conservatively identify relevant statements, documenting unsupported constructs.

**Trigger.** A data/control relevance question can be expressed in the supported program model.

**Non-trigger and cheap path.** Manual inspection or a small dependency query may dominate building a slicer.

**Prerequisites.** Conditions: Sound dependencies and supported semantics; minimal arbitrary slices are not computable in general.; Related property ids: ESME-012; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: The observation specified by the slicing criterion, not every external effect.; Decision: The slice is traceable to its criterion and conservative assumptions; unknown constructs remain visible.

**Authority and practical action.** Actors: The observation specified by the slicing criterion, not every external effect.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The slice is traceable to its criterion and conservative assumptions; unknown constructs remain visible. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S043; Adjudication: Source-supported: minimality limits and large slices; student-scale evidence does not establish industrial productivity.; Effect on disposition: Retain conservative relevance under assumptions, not minimality or whole-system understanding.

**Anti-ceremony boundary.** Essential: The slice is traceable to its criterion and conservative assumptions; unknown constructs remain visible.; Minimal alternative: Manual inspection or a small dependency query may dominate building a slicer.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Manual inspection or a small dependency query may dominate building a slicer. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R004; ESME-R005; ESME-R051

#### Domain profile

**Change intent and change class.** A data/control relevance question can be expressed in the supported program model. Select the question needed for a proposed change, diagnosis or handover rather than presupposing whole-system understanding.

**Baseline and affected artefacts.** Program statements, variable criterion and control/data dependencies. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.

**Preservation obligation and observer.** The observation specified by the slicing criterion, not every external effect. Distinguish a recovered description from an authorised requirement and from what an actual user can observe.

**Impact boundary and dependency evidence.** Static relations overapproximate modelled paths; dynamic traces underapproximate possible executions; fuse only with declared boundaries.

**Comprehension assumptions.** Sound dependencies and supported semantics; minimal arbitrary slices are not computable in general. Incomplete intent, unsupported languages, generated code and tacit operational knowledge limit recovery.

**Oracle and regression limits.** Recovered models require cross-checking; observed behaviour can be a defect and absent evidence is not evidence of absence.

**Compatibility and migration preconditions.** Recovery may reveal interface or migration assumptions but cannot itself establish their validity.

**Release rollback or forward repair condition.** Read-only inquiry normally needs no production rollback; intrusive instrumentation must control perturbation and cleanup.

**Maintainer and downstream consumers.** Maintainers and domain/operational experts exchange concrete questions and evidence; documentation is useful through an actual consumer.

**Lifecycle cost and retirement condition.** Manual inspection or a small dependency query may dominate building a slicer. Stop inquiry when it discriminates the pending decision sufficiently; deepen it when contradictions or impact escape appear; retire stale views.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: MODEL_BOUND; Reason: FORMAL_SCOPE_BOUND: source-supported model/guarantee and assumptions recorded in source table; no independent re-proof or unbounded deployment guarantee.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S015; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S043; Reason: Source-supported: minimality limits and large slices; student-scale evidence does not establish industrial productivity.

**Transferability.** Assessment: CONDITIONAL; Reason: Sound dependencies and supported semantics; minimal arbitrary slices are not computable in general. Which unsupported dependency could invalidate the slice’s claimed preservation?

**Source IDs:** ESME-S015, ESME-S043. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which unsupported dependency could invalidate the slice’s claimed preservation?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-014 — Execution-relative dynamic observation and slicing

**Disposition and kind.** CONTEXT_DEPENDENT; OBSERVATION_MECHANISM

**Mature form.** Complement static evidence and human knowledge instead of replacing them.

**Controlled failure.** Source-supported: dynamic graphs can be costly; particular runs cannot establish all-input behaviour.

**Operating mechanism.** Record the input, environment and trace boundary, then use execution evidence to investigate the specific effect without treating unexecuted behaviour as absent.

**Trigger.** Static uncertainty, dynamic dispatch or a reproducible failure makes execution evidence discriminating.

**Non-trigger and cheap path.** A debugger or targeted log can suffice; do not collect exhaustive production traces without need.

**Prerequisites.** Conditions: Reproducible or adequately characterised execution; instrumentation does not conceal or change the critical effect.; Related property ids: ESME-012; ESME-013; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: The observed run and selected values/events.; Decision: A claim identifies the executions observed and the neighbouring cases still unobserved.

**Authority and practical action.** Actors: The observed run and selected values/events.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** A claim identifies the executions observed and the neighbouring cases still unobserved. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S015; ESME-S025; Adjudication: Source-supported: dynamic graphs can be costly; particular runs cannot establish all-input behaviour.; Effect on disposition: Complement static evidence and human knowledge instead of replacing them.

**Anti-ceremony boundary.** Essential: A claim identifies the executions observed and the neighbouring cases still unobserved.; Minimal alternative: A debugger or targeted log can suffice; do not collect exhaustive production traces without need.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A debugger or targeted log can suffice; do not collect exhaustive production traces without need. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R004; ESME-R005; ESME-R051

#### Domain profile

**Change intent and change class.** Static uncertainty, dynamic dispatch or a reproducible failure makes execution evidence discriminating. Select the question needed for a proposed change, diagnosis or handover rather than presupposing whole-system understanding.

**Baseline and affected artefacts.** Trace, instrumentation, inputs and runtime configuration. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.

**Preservation obligation and observer.** The observed run and selected values/events. Distinguish a recovered description from an authorised requirement and from what an actual user can observe.

**Impact boundary and dependency evidence.** Static relations overapproximate modelled paths; dynamic traces underapproximate possible executions; fuse only with declared boundaries.

**Comprehension assumptions.** Reproducible or adequately characterised execution; instrumentation does not conceal or change the critical effect. Incomplete intent, unsupported languages, generated code and tacit operational knowledge limit recovery.

**Oracle and regression limits.** Recovered models require cross-checking; observed behaviour can be a defect and absent evidence is not evidence of absence.

**Compatibility and migration preconditions.** Recovery may reveal interface or migration assumptions but cannot itself establish their validity.

**Release rollback or forward repair condition.** Read-only inquiry normally needs no production rollback; intrusive instrumentation must control perturbation and cleanup.

**Maintainer and downstream consumers.** Maintainers and domain/operational experts exchange concrete questions and evidence; documentation is useful through an actual consumer.

**Lifecycle cost and retirement condition.** A debugger or targeted log can suffice; do not collect exhaustive production traces without need. Stop inquiry when it discriminates the pending decision sufficiently; deepen it when contradictions or impact escape appear; retire stale views.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: MODEL_BOUND; Reason: FORMAL_SCOPE_BOUND: source-supported model/guarantee and assumptions recorded in source table; no independent re-proof or unbounded deployment guarantee.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S015; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S044; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S015; ESME-S025; Reason: Source-supported: dynamic graphs can be costly; particular runs cannot establish all-input behaviour.

**Transferability.** Assessment: CONDITIONAL; Reason: Reproducible or adequately characterised execution; instrumentation does not conceal or change the critical effect. What unobserved execution would falsify the present explanation?

**Source IDs:** ESME-S043, ESME-S044, ESME-S015, ESME-S025. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What unobserved execution would falsify the present explanation?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-015 — Design recovery includes domain and human knowledge

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; RECOVERY_MECHANISM

**Mature form.** Use fallible triangulation; never treat reconstructed intent as self-authorising.

**Controlled failure.** Source-supported: transfer experiences show knowledge is not exhausted by documents. Analytical: expert memory can also be wrong.

**Operating mechanism.** Recover the rationale and abstractions needed for the change by checking code/behaviour against knowledgeable people and domain evidence.

**Trigger.** Undocumented behaviour or lost intent makes structural reconstruction insufficient.

**Non-trigger and cheap path.** Ask a knowledgeable maintainer a focused question rather than commissioning a comprehensive recovery model.

**Prerequisites.** Conditions: Knowledge claims must be checked against current obligations and observable behaviour.; Related property ids: ESME-001; ESME-012; ESME-063; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Domain expert and successor maintainer, not solely the analysis tool.; Decision: The recovered explanation supports a concrete maintenance decision and identifies uncertain or contested intent.

**Authority and practical action.** Actors: Domain expert and successor maintainer, not solely the analysis tool.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The recovered explanation supports a concrete maintenance decision and identifies uncertain or contested intent. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S017; Adjudication: Source-supported: transfer experiences show knowledge is not exhausted by documents. Analytical: expert memory can also be wrong.; Effect on disposition: Use fallible triangulation; never treat reconstructed intent as self-authorising.

**Anti-ceremony boundary.** Essential: The recovered explanation supports a concrete maintenance decision and identifies uncertain or contested intent.; Minimal alternative: Ask a knowledgeable maintainer a focused question rather than commissioning a comprehensive recovery model.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Ask a knowledgeable maintainer a focused question rather than commissioning a comprehensive recovery model. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T02; Discriminator: Compare demonstrated next-change capability and total transition cost, not complexity score alone.; Hybrid failure: Long-lived mixed styles and half-transferred knowledge make both old and new harder to understand.

**Composition coupling.** ESME-R004; ESME-R005; ESME-R023; ESME-R039; ESME-R047; ESME-R050

#### Domain profile

**Change intent and change class.** Undocumented behaviour or lost intent makes structural reconstruction insufficient. Select the question needed for a proposed change, diagnosis or handover rather than presupposing whole-system understanding.

**Baseline and affected artefacts.** Implementation, domain rules, historical decisions and tacit operational knowledge. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.

**Preservation obligation and observer.** Domain expert and successor maintainer, not solely the analysis tool. Distinguish a recovered description from an authorised requirement and from what an actual user can observe.

**Impact boundary and dependency evidence.** Static relations overapproximate modelled paths; dynamic traces underapproximate possible executions; fuse only with declared boundaries.

**Comprehension assumptions.** Knowledge claims must be checked against current obligations and observable behaviour. Incomplete intent, unsupported languages, generated code and tacit operational knowledge limit recovery.

**Oracle and regression limits.** Recovered models require cross-checking; observed behaviour can be a defect and absent evidence is not evidence of absence.

**Compatibility and migration preconditions.** Recovery may reveal interface or migration assumptions but cannot itself establish their validity.

**Release rollback or forward repair condition.** Read-only inquiry normally needs no production rollback; intrusive instrumentation must control perturbation and cleanup.

**Maintainer and downstream consumers.** Maintainers and domain/operational experts exchange concrete questions and evidence; documentation is useful through an actual consumer.

**Lifecycle cost and retirement condition.** Ask a knowledgeable maintainer a focused question rather than commissioning a comprehensive recovery model. Stop inquiry when it discriminates the pending decision sufficiently; deepen it when contradictions or impact escape appear; retire stale views.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S017; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S016; ESME-S044; ESME-S017; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S017; Reason: Source-supported: transfer experiences show knowledge is not exhausted by documents. Analytical: expert memory can also be wrong.

**Transferability.** Assessment: CONDITIONAL; Reason: Knowledge claims must be checked against current obligations and observable behaviour. What independent observation could contradict the recovered rationale?

**Source IDs:** ESME-S014, ESME-S016, ESME-S044, ESME-S017. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What independent observation could contradict the recovered rationale?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-016 — Faithful redocumentation with an actual consumer

**Disposition and kind.** USEFUL_BUT_EASILY_BUREAUCRATISED; COMMUNICATION_MECHANISM

**Mature form.** Retain consumed, version-bound explanation and retire orphan descriptions.

**Controlled failure.** Source-supported: documentation does not encompass all expertise; comprehensive registers can become bureaucracy.

**Operating mechanism.** Produce or refresh a description only when a maintainer or downstream consumer needs it, and check it against the current subject.

**Trigger.** A useful explanation is missing, stale or inaccessible to an actual consumer.

**Non-trigger and cheap path.** A checked example, code comment or targeted note can replace a large document.

**Prerequisites.** Conditions: A resolvable source baseline and a way to detect stale statements.; Related property ids: ESME-004; ESME-012; ESME-063; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: The intended reader performing a named maintenance or operational task.; Decision: A consumer can use the description to perform the intended task; its version and limits are visible.

**Authority and practical action.** Actors: The intended reader performing a named maintenance or operational task.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** A consumer can use the description to perform the intended task; its version and limits are visible. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S016; ESME-S058; Adjudication: Source-supported: documentation does not encompass all expertise; comprehensive registers can become bureaucracy.; Effect on disposition: Retain consumed, version-bound explanation and retire orphan descriptions.

**Anti-ceremony boundary.** Essential: A consumer can use the description to perform the intended task; its version and limits are visible.; Minimal alternative: A checked example, code comment or targeted note can replace a large document.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A checked example, code comment or targeted note can replace a large document. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R049

#### Domain profile

**Change intent and change class.** A useful explanation is missing, stale or inaccessible to an actual consumer. Select the question needed for a proposed change, diagnosis or handover rather than presupposing whole-system understanding.

**Baseline and affected artefacts.** Documentation and its source artefact/version. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.

**Preservation obligation and observer.** The intended reader performing a named maintenance or operational task. Distinguish a recovered description from an authorised requirement and from what an actual user can observe.

**Impact boundary and dependency evidence.** Static relations overapproximate modelled paths; dynamic traces underapproximate possible executions; fuse only with declared boundaries.

**Comprehension assumptions.** A resolvable source baseline and a way to detect stale statements. Incomplete intent, unsupported languages, generated code and tacit operational knowledge limit recovery.

**Oracle and regression limits.** Recovered models require cross-checking; observed behaviour can be a defect and absent evidence is not evidence of absence.

**Compatibility and migration preconditions.** Recovery may reveal interface or migration assumptions but cannot itself establish their validity.

**Release rollback or forward repair condition.** Read-only inquiry normally needs no production rollback; intrusive instrumentation must control perturbation and cleanup.

**Maintainer and downstream consumers.** Maintainers and domain/operational experts exchange concrete questions and evidence; documentation is useful through an actual consumer.

**Lifecycle cost and retirement condition.** A checked example, code comment or targeted note can replace a large document. Stop inquiry when it discriminates the pending decision sufficiently; deepen it when contradictions or impact escape appear; retire stale views.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S016; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S016; ESME-S058; Reason: Source-supported: documentation does not encompass all expertise; comprehensive registers can become bureaucracy.

**Transferability.** Assessment: CONDITIONAL; Reason: A resolvable source baseline and a way to detect stale statements. Who uses this description, and what would fail if it were omitted?

**Source IDs:** ESME-S014, ESME-S041, ESME-S016, ESME-S058. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Who uses this description, and what would fail if it were omitted?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-019 — Feature-location hypotheses and interactive refinement

**Disposition and kind.** CONTEXT_DEPENDENT; SEARCH_AND_INQUIRY_MECHANISM

**Mature form.** Interactive hypothesis refinement, not search-ranking authority.

**Controlled failure.** Source-supported: question sequences require multiple relations; history suggestions have false positives and misses.

**Operating mechanism.** Treat names, search results, traces and history as candidate locations; verify relevance and revise the search from observed behaviour.

**Trigger.** A change request describes a feature whose implementation is not already known.

**Non-trigger and cheap path.** A direct known location or maintainer pointer avoids a specialised search workflow.

**Prerequisites.** Conditions: A discriminating feature example and access to relevant artefacts.; Related property ids: ESME-012; ESME-014; ESME-022; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Maintainer locating the implementation of the requested effect.; Decision: Candidate locations are confirmed against the feature and false leads are recorded or discarded.

**Authority and practical action.** Actors: Maintainer locating the implementation of the requested effect.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Candidate locations are confirmed against the feature and false leads are recorded or discarded. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S018; Adjudication: Source-supported: question sequences require multiple relations; history suggestions have false positives and misses.; Effect on disposition: Interactive hypothesis refinement, not search-ranking authority.

**Anti-ceremony boundary.** Essential: Candidate locations are confirmed against the feature and false leads are recorded or discarded.; Minimal alternative: A direct known location or maintainer pointer avoids a specialised search workflow.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A direct known location or maintainer pointer avoids a specialised search workflow. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R004; ESME-R005; ESME-R006

#### Domain profile

**Change intent and change class.** A change request describes a feature whose implementation is not already known. Select the question needed for a proposed change, diagnosis or handover rather than presupposing whole-system understanding.

**Baseline and affected artefacts.** Feature description, code locations, calls, traces and change history. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.

**Preservation obligation and observer.** Maintainer locating the implementation of the requested effect. Distinguish a recovered description from an authorised requirement and from what an actual user can observe.

**Impact boundary and dependency evidence.** Static relations overapproximate modelled paths; dynamic traces underapproximate possible executions; fuse only with declared boundaries.

**Comprehension assumptions.** A discriminating feature example and access to relevant artefacts. Incomplete intent, unsupported languages, generated code and tacit operational knowledge limit recovery.

**Oracle and regression limits.** Recovered models require cross-checking; observed behaviour can be a defect and absent evidence is not evidence of absence.

**Compatibility and migration preconditions.** Recovery may reveal interface or migration assumptions but cannot itself establish their validity.

**Release rollback or forward repair condition.** Read-only inquiry normally needs no production rollback; intrusive instrumentation must control perturbation and cleanup.

**Maintainer and downstream consumers.** Maintainers and domain/operational experts exchange concrete questions and evidence; documentation is useful through an actual consumer.

**Lifecycle cost and retirement condition.** A direct known location or maintainer pointer avoids a specialised search workflow. Stop inquiry when it discriminates the pending decision sufficiently; deepen it when contradictions or impact escape appear; retire stale views.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S017; ESME-S020; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S017; ESME-S044; ESME-S018; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S018; Reason: Source-supported: question sequences require multiple relations; history suggestions have false positives and misses.

**Transferability.** Assessment: CONDITIONAL; Reason: A discriminating feature example and access to relevant artefacts. What observation distinguishes a coincidental name match from the relevant implementation?

**Source IDs:** ESME-S017, ESME-S020, ESME-S044, ESME-S018. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What observation distinguishes a coincidental name match from the relevant implementation?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-020 — Evidence-fused architecture and behaviour recovery

**Disposition and kind.** CONTEXT_DEPENDENT; MODELLING_AND_RECOVERY_MECHANISM

**Mature form.** Conditional view fusion with an exit criterion, not a canonical whole-system diagram.

**Controlled failure.** Source-supported: tool-supported examples demonstrate feasibility, not general economic superiority; interpretation remains necessary.

**Operating mechanism.** Cross-check static, runtime and build views; retain conflicts as investigation targets and recover only abstractions that serve the current decision.

**Trigger.** Late binding, generated code or divergent documentation makes any one view misleading.

**Non-trigger and cheap path.** Use a single sufficient view when cross-checks reveal no consequential gap.

**Prerequisites.** Conditions: Compatible identifiers and explicit interpretation rules between views.; Related property ids: ESME-012; ESME-014; ESME-024; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Analyst and maintainer using the recovered view.; Decision: The view states what each relation is based on and which conflicts remain.

**Authority and practical action.** Actors: Analyst and maintainer using the recovered view.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The view states what each relation is based on and which conflicts remain. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S016; Adjudication: Source-supported: tool-supported examples demonstrate feasibility, not general economic superiority; interpretation remains necessary.; Effect on disposition: Conditional view fusion with an exit criterion, not a canonical whole-system diagram.

**Anti-ceremony boundary.** Essential: The view states what each relation is based on and which conflicts remain.; Minimal alternative: Use a single sufficient view when cross-checks reveal no consequential gap.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Use a single sufficient view when cross-checks reveal no consequential gap. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R004; ESME-R005; ESME-R006

#### Domain profile

**Change intent and change class.** Late binding, generated code or divergent documentation makes any one view misleading. Select the question needed for a proposed change, diagnosis or handover rather than presupposing whole-system understanding.

**Baseline and affected artefacts.** Extracted components/relations, execution observations and build mapping. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.

**Preservation obligation and observer.** Analyst and maintainer using the recovered view. Distinguish a recovered description from an authorised requirement and from what an actual user can observe.

**Impact boundary and dependency evidence.** Static relations overapproximate modelled paths; dynamic traces underapproximate possible executions; fuse only with declared boundaries.

**Comprehension assumptions.** Compatible identifiers and explicit interpretation rules between views. Incomplete intent, unsupported languages, generated code and tacit operational knowledge limit recovery.

**Oracle and regression limits.** Recovered models require cross-checking; observed behaviour can be a defect and absent evidence is not evidence of absence.

**Compatibility and migration preconditions.** Recovery may reveal interface or migration assumptions but cannot itself establish their validity.

**Release rollback or forward repair condition.** Read-only inquiry normally needs no production rollback; intrusive instrumentation must control perturbation and cleanup.

**Maintainer and downstream consumers.** Maintainers and domain/operational experts exchange concrete questions and evidence; documentation is useful through an actual consumer.

**Lifecycle cost and retirement condition.** Use a single sufficient view when cross-checks reveal no consequential gap. Stop inquiry when it discriminates the pending decision sufficiently; deepen it when contradictions or impact escape appear; retire stale views.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S044; ESME-S016; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S016; Reason: Source-supported: tool-supported examples demonstrate feasibility, not general economic superiority; interpretation remains necessary.

**Transferability.** Assessment: CONDITIONAL; Reason: Compatible identifiers and explicit interpretation rules between views. Which decision is improved by adding another view, and which contradiction does it resolve?

**Source IDs:** ESME-S014, ESME-S044, ESME-S016. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which decision is improved by adding another view, and which contradiction does it resolve?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-021 — Explicit multi-artefact impact boundary

**Disposition and kind.** STRONGLY_RETAINED; BOUNDARY_AND_INQUIRY_MECHANISM

**Mature form.** Impact is a revisable claim, not merely a generated list.

**Controlled failure.** Source-supported: non-code omissions and ecosystem transitivity defeat source-only boundaries.

**Operating mechanism.** State the expected affected set, dependency kinds examined and plausible escape paths; widen or revise when counterevidence appears.

**Trigger.** An edit can propagate outside its immediate location or alter a relied-on contract.

**Non-trigger and cheap path.** Local review is sufficient when a defensible dependency boundary makes wider effects immaterial.

**Prerequisites.** Conditions: Identifiable baseline and an account of relevant dependency kinds.; Related property ids: ESME-004; ESME-012; ESME-024; ESME-025; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Affected technical and human consumers of the change.; Decision: The impact set is justified by evidence and unresolved edges are visible to the acceptance decision.

**Authority and practical action.** Actors: Affected technical and human consumers of the change.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The impact set is justified by evidence and unresolved edges are visible to the acceptance decision. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S024; ESME-S061; Adjudication: Source-supported: non-code omissions and ecosystem transitivity defeat source-only boundaries.; Effect on disposition: Impact is a revisable claim, not merely a generated list.

**Anti-ceremony boundary.** Essential: The impact set is justified by evidence and unresolved edges are visible to the acceptance decision.; Minimal alternative: Local review is sufficient when a defensible dependency boundary makes wider effects immaterial.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Local review is sufficient when a defensible dependency boundary makes wider effects immaterial. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T03; Discriminator: Compare feasible obligations, seam/data constraints and prospective costs including the exit, not sunk effort.; Hybrid failure: Permanent adapters and dual data authorities add migration cost without eliminating legacy cost.

**Composition coupling.** ESME-R001; ESME-R002; ESME-R005; ESME-R006; ESME-R022; ESME-R024; ESME-R026; ESME-R028; ESME-R030; ESME-R031

#### Domain profile

**Change intent and change class.** An edit can propagate outside its immediate location or alter a relied-on contract. Bound a proposed edit by the effects it may propagate, not solely by its textual size.

**Baseline and affected artefacts.** Code, data, interfaces, configuration, builds, documentation and consumers. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.

**Preservation obligation and observer.** Affected technical and human consumers of the change. A consumer can observe source, binary, semantic, persistence or protocol changes through different interfaces.

**Impact boundary and dependency evidence.** Record which dependency relations are analysed, inferred from history, dynamically observed or still unknown.

**Comprehension assumptions.** Identifiable baseline and an account of relevant dependency kinds. A maintainer must understand the changed relation and relevant external consumers, not necessarily every internal module.

**Oracle and regression limits.** A passing local test cannot rule out omitted dependency kinds; challenge the boundary with targeted downstream checks.

**Compatibility and migration preconditions.** Compatibility depends on declared supported versions and actual interactions, not version labels alone.

**Release rollback or forward repair condition.** Concurrent or downstream changes may invalidate a planned rollback; reevaluate actual deployment and state combinations.

**Maintainer and downstream consumers.** Upstream and downstream maintainers exchange changes, assumptions, supported versions and unresolved impact questions.

**Lifecycle cost and retirement condition.** Local review is sufficient when a defensible dependency boundary makes wider effects immaterial. Prefer local analysis only with a justified boundary; retire temporary compatibility bridges and stale impact links after consumers have moved.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S020; ESME-S021; ESME-S024; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S061; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S024; ESME-S061; Reason: Source-supported: non-code omissions and ecosystem transitivity defeat source-only boundaries.

**Transferability.** Assessment: CONDITIONAL; Reason: Identifiable baseline and an account of relevant dependency kinds. What dependency kind was not observed by the method that declared this change local?

**Source IDs:** ESME-S019, ESME-S020, ESME-S021, ESME-S041, ESME-S024, ESME-S061. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What dependency kind was not observed by the method that declared this change local?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-022 — Historical co-change as fallible guidance

**Disposition and kind.** CONTEXT_DEPENDENT; PREDICTIVE_INQUIRY_MECHANISM

**Mature form.** Recommendation becomes evidence to investigate, never a causal dependency proof.

**Controlled failure.** Source-supported: useful predictions coexist with missed and unnecessary edits; actual developer savings were not established.

**Operating mechanism.** Use co-change suggestions to direct inspection; verify semantic or organisational relevance before adding an obligation.

**Trigger.** History contains sufficiently comparable changes and a maintainer needs likely impact leads.

**Non-trigger and cheap path.** Skip mining for new code, sparse history or an obvious direct dependency.

**Prerequisites.** Conditions: Transaction extraction, temporal ordering and history quality must be adequate.; Related property ids: ESME-021; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Maintainer deciding what to inspect, not automatically what to edit.; Decision: Suggested entities are either justified as relevant or dismissed; absent suggestions do not certify independence.

**Authority and practical action.** Actors: Maintainer deciding what to inspect, not automatically what to edit.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Suggested entities are either justified as relevant or dismissed; absent suggestions do not certify independence. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S020; Adjudication: Source-supported: useful predictions coexist with missed and unnecessary edits; actual developer savings were not established.; Effect on disposition: Recommendation becomes evidence to investigate, never a causal dependency proof.

**Anti-ceremony boundary.** Essential: Suggested entities are either justified as relevant or dismissed; absent suggestions do not certify independence.; Minimal alternative: Skip mining for new code, sparse history or an obvious direct dependency.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Skip mining for new code, sparse history or an obvious direct dependency. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R005; ESME-R040

#### Domain profile

**Change intent and change class.** History contains sufficiently comparable changes and a maintainer needs likely impact leads. Bound a proposed edit by the effects it may propagate, not solely by its textual size.

**Baseline and affected artefacts.** Version-history transactions and recommended entities. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.

**Preservation obligation and observer.** Maintainer deciding what to inspect, not automatically what to edit. A consumer can observe source, binary, semantic, persistence or protocol changes through different interfaces.

**Impact boundary and dependency evidence.** Record which dependency relations are analysed, inferred from history, dynamically observed or still unknown.

**Comprehension assumptions.** Transaction extraction, temporal ordering and history quality must be adequate. A maintainer must understand the changed relation and relevant external consumers, not necessarily every internal module.

**Oracle and regression limits.** A passing local test cannot rule out omitted dependency kinds; challenge the boundary with targeted downstream checks.

**Compatibility and migration preconditions.** Compatibility depends on declared supported versions and actual interactions, not version labels alone.

**Release rollback or forward repair condition.** Concurrent or downstream changes may invalidate a planned rollback; reevaluate actual deployment and state combinations.

**Maintainer and downstream consumers.** Upstream and downstream maintainers exchange changes, assumptions, supported versions and unresolved impact questions.

**Lifecycle cost and retirement condition.** Skip mining for new code, sparse history or an obvious direct dependency. Prefer local analysis only with a justified boundary; retire temporary compatibility bridges and stale impact links after consumers have moved.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S020; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S020; Reason: Source-supported: useful predictions coexist with missed and unnecessary edits; actual developer savings were not established.

**Transferability.** Assessment: CONDITIONAL; Reason: Transaction extraction, temporal ordering and history quality must be adequate. Is this recurring co-edit necessary, accidental or an artefact of commit aggregation?

**Source IDs:** ESME-S020. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Is this recurring co-edit necessary, accidental or an artefact of commit aggregation?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-024 — Build, configuration and generated-artefact dependency closure

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; DEPENDENCY_ANALYSIS_MECHANISM

**Mature form.** Close only the consequential dependency kinds rather than all possible supply-chain history.

**Controlled failure.** Source-supported: RTSCheck found non-code limitations; packaging depends on environment and tool assumptions.

**Operating mechanism.** Follow the build/configuration/generation path that produces or selects the changed runtime artefact; challenge unsupported file types explicitly.

**Trigger.** Non-source inputs or generators influence the target behaviour or regression selection.

**Non-trigger and cheap path.** A recorded explicit command and input list suffice where there is no indirect generation or configuration.

**Prerequisites.** Conditions: The producing process and external inputs can be identified or bounded.; Related property ids: ESME-004; ESME-021; ESME-041; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Build consumer, tester and deployed runtime.; Decision: The relevant producer/input/output chain is accounted for and changes reach validated consumers.

**Authority and practical action.** Actors: Build consumer, tester and deployed runtime.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The relevant producer/input/output chain is accounted for and changes reach validated consumers. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S024; ESME-S061; Adjudication: Source-supported: RTSCheck found non-code limitations; packaging depends on environment and tool assumptions.; Effect on disposition: Close only the consequential dependency kinds rather than all possible supply-chain history.

**Anti-ceremony boundary.** Essential: The relevant producer/input/output chain is accounted for and changes reach validated consumers.; Minimal alternative: A recorded explicit command and input list suffice where there is no indirect generation or configuration.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A recorded explicit command and input list suffice where there is no indirect generation or configuration. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R005; ESME-R020; ESME-R028

#### Domain profile

**Change intent and change class.** Non-source inputs or generators influence the target behaviour or regression selection. Bound a proposed edit by the effects it may propagate, not solely by its textual size.

**Baseline and affected artefacts.** Build scripts, resources, schemas, generated code, package inputs and tool versions. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.

**Preservation obligation and observer.** Build consumer, tester and deployed runtime. A consumer can observe source, binary, semantic, persistence or protocol changes through different interfaces.

**Impact boundary and dependency evidence.** Record which dependency relations are analysed, inferred from history, dynamically observed or still unknown.

**Comprehension assumptions.** The producing process and external inputs can be identified or bounded. A maintainer must understand the changed relation and relevant external consumers, not necessarily every internal module.

**Oracle and regression limits.** A passing local test cannot rule out omitted dependency kinds; challenge the boundary with targeted downstream checks.

**Compatibility and migration preconditions.** Compatibility depends on declared supported versions and actual interactions, not version labels alone.

**Release rollback or forward repair condition.** Concurrent or downstream changes may invalidate a planned rollback; reevaluate actual deployment and state combinations.

**Maintainer and downstream consumers.** Upstream and downstream maintainers exchange changes, assumptions, supported versions and unresolved impact questions.

**Lifecycle cost and retirement condition.** A recorded explicit command and input list suffice where there is no indirect generation or configuration. Prefer local analysis only with a justified boundary; retire temporary compatibility bridges and stale impact links after consumers have moved.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S024; ESME-S052; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S044; ESME-S061; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S024; ESME-S061; Reason: Source-supported: RTSCheck found non-code limitations; packaging depends on environment and tool assumptions.

**Transferability.** Assessment: CONDITIONAL; Reason: The producing process and external inputs can be identified or bounded. Which file or environment value can change the output without changing the tracked source?

**Source IDs:** ESME-S019, ESME-S024, ESME-S044, ESME-S052, ESME-S061. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which file or environment value can change the output without changing the tracked source?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-025 — Observer-specific API and protocol compatibility

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; CONSTRAINT_AND_COORDINATION_MECHANISM

**Mature form.** Compatibility is dimensional and time-bounded, not perpetual preservation of all history.

**Controlled failure.** Source-supported: nominal refactoring can force client adaptation; versioning declares rather than verifies compatibility.

**Operating mechanism.** Declare supported clients and observers, test their relevant interactions and coordinate intentional breaking transitions.

**Trigger.** An interface, schema or protocol is relied on outside the edited component.

**Non-trigger and cheap path.** Internal changes with no consequential external observer need no compatibility programme.

**Prerequisites.** Conditions: Known support scope and evidence for the particular compatibility dimension.; Related property ids: ESME-001; ESME-021; ESME-051; ESME-069; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Actual client source/binary/runtime/data consumers.; Decision: Supported interactions remain valid or consumers have an authorised transition path with explicit limitations.

**Authority and practical action.** Actors: Actual client source/binary/runtime/data consumers.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Supported interactions remain valid or consumers have an authorised transition path with explicit limitations. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S021; ESME-S054; Adjudication: Source-supported: nominal refactoring can force client adaptation; versioning declares rather than verifies compatibility.; Effect on disposition: Compatibility is dimensional and time-bounded, not perpetual preservation of all history.

**Anti-ceremony boundary.** Essential: Supported interactions remain valid or consumers have an authorised transition path with explicit limitations.; Minimal alternative: Internal changes with no consequential external observer need no compatibility programme.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Internal changes with no consequential external observer need no compatibility programme. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T07; Discriminator: Determine real promises, capacity and transition feasibility; usage popularity is neither permission nor an infinite support contract.; Hybrid failure: Dates are announced without a viable path, or compatibility branches multiply beyond capacity.

**Composition coupling.** ESME-R024; ESME-R040

#### Domain profile

**Change intent and change class.** An interface, schema or protocol is relied on outside the edited component. Bound a proposed edit by the effects it may propagate, not solely by its textual size.

**Baseline and affected artefacts.** Public API, binary interface, protocol, persistent representation and supported versions. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.

**Preservation obligation and observer.** Actual client source/binary/runtime/data consumers. A consumer can observe source, binary, semantic, persistence or protocol changes through different interfaces.

**Impact boundary and dependency evidence.** Record which dependency relations are analysed, inferred from history, dynamically observed or still unknown.

**Comprehension assumptions.** Known support scope and evidence for the particular compatibility dimension. A maintainer must understand the changed relation and relevant external consumers, not necessarily every internal module.

**Oracle and regression limits.** A passing local test cannot rule out omitted dependency kinds; challenge the boundary with targeted downstream checks.

**Compatibility and migration preconditions.** Compatibility depends on declared supported versions and actual interactions, not version labels alone.

**Release rollback or forward repair condition.** Concurrent or downstream changes may invalidate a planned rollback; reevaluate actual deployment and state combinations.

**Maintainer and downstream consumers.** Upstream and downstream maintainers exchange changes, assumptions, supported versions and unresolved impact questions.

**Lifecycle cost and retirement condition.** Internal changes with no consequential external observer need no compatibility programme. Prefer local analysis only with a justified boundary; retire temporary compatibility bridges and stale impact links after consumers have moved.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S049.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S021; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S021; ESME-S054; Reason: Source-supported: nominal refactoring can force client adaptation; versioning declares rather than verifies compatibility.

**Transferability.** Assessment: CONDITIONAL; Reason: Known support scope and evidence for the particular compatibility dimension. Which observer can detect a change despite unchanged method signatures?

**Source IDs:** ESME-S021, ESME-S049, ESME-S067, ESME-S054. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which observer can detect a change despite unchanged method signatures?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-027 — Concurrent-change semantic validation

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; INTEGRATION_EVIDENCE_MECHANISM

**Mature form.** Retain joint-intent validation with selective automation, not a universal merge oracle.

**Controlled failure.** Source-supported: SAM detects only a subset of local interference; BuCoR build repair is not semantic correctness.

**Operating mechanism.** Compare base, both parents and merged behaviour for consequential interactions; validate build and domain effects separately.

**Trigger.** Changes overlap semantically or one branch alters assumptions used by another.

**Non-trigger and cheap path.** Ordinary compilation and targeted tests suffice for clearly independent low-risk changes.

**Prerequisites.** Conditions: Parent intents and relevant interactions must be available; test-generated interference is only partial evidence.; Related property ids: ESME-001; ESME-021; ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Contributors and consumers of the merged result.; Decision: The merged state satisfies the jointly accepted objectives or an explicit conflict is resolved.

**Authority and practical action.** Actors: Contributors and consumers of the merged result.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The merged state satisfies the jointly accepted objectives or an explicit conflict is resolved. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S066; Adjudication: Source-supported: SAM detects only a subset of local interference; BuCoR build repair is not semantic correctness.; Effect on disposition: Retain joint-intent validation with selective automation, not a universal merge oracle.

**Anti-ceremony boundary.** Essential: The merged state satisfies the jointly accepted objectives or an explicit conflict is resolved.; Minimal alternative: Ordinary compilation and targeted tests suffice for clearly independent low-risk changes.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Ordinary compilation and targeted tests suffice for clearly independent low-risk changes. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R021; ESME-R023

#### Domain profile

**Change intent and change class.** Changes overlap semantically or one branch alters assumptions used by another. Bound a proposed edit by the effects it may propagate, not solely by its textual size.

**Baseline and affected artefacts.** Base/left/right/merge versions, build definitions and behavioural interactions. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.

**Preservation obligation and observer.** Contributors and consumers of the merged result. A consumer can observe source, binary, semantic, persistence or protocol changes through different interfaces.

**Impact boundary and dependency evidence.** Record which dependency relations are analysed, inferred from history, dynamically observed or still unknown.

**Comprehension assumptions.** Parent intents and relevant interactions must be available; test-generated interference is only partial evidence. A maintainer must understand the changed relation and relevant external consumers, not necessarily every internal module.

**Oracle and regression limits.** A passing local test cannot rule out omitted dependency kinds; challenge the boundary with targeted downstream checks.

**Compatibility and migration preconditions.** Compatibility depends on declared supported versions and actual interactions, not version labels alone.

**Release rollback or forward repair condition.** Concurrent or downstream changes may invalidate a planned rollback; reevaluate actual deployment and state combinations.

**Maintainer and downstream consumers.** Upstream and downstream maintainers exchange changes, assumptions, supported versions and unresolved impact questions.

**Lifecycle cost and retirement condition.** Ordinary compilation and targeted tests suffice for clearly independent low-risk changes. Prefer local analysis only with a justified boundary; retire temporary compatibility bridges and stale impact links after consumers have moved.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S040; ESME-S066; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S066; Reason: Source-supported: SAM detects only a subset of local interference; BuCoR build repair is not semantic correctness.

**Transferability.** Assessment: CONDITIONAL; Reason: Parent intents and relevant interactions must be available; test-generated interference is only partial evidence. Which assumption from one branch is invalidated by the other?

**Source IDs:** ESME-S019, ESME-S040, ESME-S066. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which assumption from one branch is invalidated by the other?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-028 — Observer-relative preservation in refactoring

**Disposition and kind.** STRONGLY_RETAINED; PRESERVATION_CRITERION

**Mature form.** Preservation is explicit and scoped, not an unqualified slogan.

**Controlled failure.** Source-supported: Opdyke excludes representation-sensitive observations; real API refactoring can affect clients and engines can err.

**Operating mechanism.** Name the observer, relevant environment and deliberately excluded observations before claiming behaviour preservation.

**Trigger.** A transformation is justified as non-functional or structure-only.

**Non-trigger and cheap path.** For an isolated pure function, input/output and exceptional behaviour may be an adequate observer; no universal observer inventory is mandatory.

**Prerequisites.** Conditions: Preservation claims must match the actual language/runtime and consumer scope.; Related property ids: ESME-001; ESME-021; ESME-029; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Specified outputs, exceptions, timing, resources, reflection, layout or persistence as warranted.; Decision: The claimed equivalence is stated relative to the observer and supported by appropriate evidence.

**Authority and practical action.** Actors: Specified outputs, exceptions, timing, resources, reflection, layout or persistence as warranted.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The claimed equivalence is stated relative to the observer and supported by appropriate evidence. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S021; ESME-S023; ESME-S045; Adjudication: Source-supported: Opdyke excludes representation-sensitive observations; real API refactoring can affect clients and engines can err.; Effect on disposition: Preservation is explicit and scoped, not an unqualified slogan.

**Anti-ceremony boundary.** Essential: The claimed equivalence is stated relative to the observer and supported by appropriate evidence.; Minimal alternative: For an isolated pure function, input/output and exceptional behaviour may be an adequate observer; no universal observer inventory is mandatory.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** For an isolated pure function, input/output and exceptional behaviour may be an adequate observer; no universal observer inventory is mandatory. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T01; Discriminator: Identify the actual obligation, consumer and authorisation for revision; unresolved authority blocks that revision, not unrelated work.; Hybrid failure: Two ambiguous meanings, unmaintained compatibility mode, or an oracle changed solely to pass.

**Composition coupling.** ESME-R007; ESME-R008; ESME-R030; ESME-R041

#### Domain profile

**Change intent and change class.** A transformation is justified as non-functional or structure-only. Distinguish structure-preserving transformation from corrective or feature change; mixed changes need distinct obligations.

**Baseline and affected artefacts.** Pre/post implementation and relevant external context. Use exact pre/post code, language/tool versions and relevant runtime, persistence and external-interface context.

**Preservation obligation and observer.** Specified outputs, exceptions, timing, resources, reflection, layout or persistence as warranted. Preservation is relative to an observer: outputs, exceptions, timing, resources, reflection and layout may differ.

**Impact boundary and dependency evidence.** A refactoring boundary includes clients and hidden reflection/serialization use where consequential.

**Comprehension assumptions.** Preservation claims must match the actual language/runtime and consumer scope. The transformation engine and maintainer must know or conservatively handle the preconditions relied on.

**Oracle and regression limits.** Catalogue names, structural metrics and selected test passage are not proofs of observer-relative equivalence.

**Compatibility and migration preconditions.** A source-level refactoring may break binary/API consumers; include migration only when those observers matter.

**Release rollback or forward repair condition.** Reverting text may restore structure but cannot undo already emitted data or external effects; use the release model when deployed.

**Maintainer and downstream consumers.** Tool operator, reviewer and affected clients need the preservation scope and any deliberately changed behaviour.

**Lifecycle cost and retirement condition.** For an isolated pure function, input/output and exceptional behaviour may be an adequate observer; no universal observer inventory is mandatory. Name the future change class or other benefit; avoid cleanup without expected value and retire a transformation control when its trigger disappears.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: MODEL_BOUND; Reason: FORMAL_SCOPE_BOUND: source-supported model/guarantee and assumptions recorded in source table; no independent re-proof or unbounded deployment guarantee.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S021; ESME-S023; ESME-S045; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S021; ESME-S023; ESME-S045; Reason: Source-supported: Opdyke excludes representation-sensitive observations; real API refactoring can affect clients and engines can err.

**Transferability.** Assessment: CONDITIONAL; Reason: Preservation claims must match the actual language/runtime and consumer scope. Which excluded observation is nevertheless used by a real consumer?

**Source IDs:** ESME-S014, ESME-S022, ESME-S021, ESME-S023, ESME-S045. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which excluded observation is nevertheless used by a real consumer?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-029 — Transformation precondition enforcement

**Disposition and kind.** ASSUMPTION_SENSITIVE; FORMAL_TRANSFORMATION_MECHANISM

**Mature form.** Separate rule correctness, precondition truth and implementation conformity.

**Controlled failure.** Source-supported: valid formal intention does not prevent implementation bugs or unsupported contexts.

**Operating mechanism.** Check the transformation’s applicability conditions and supported constructs, then validate that the implemented tool follows them.

**Trigger.** A transformation’s correctness depends on names, bindings, inheritance, types or other structural conditions.

**Non-trigger and cheap path.** Direct review of a small transformation can replace a general engine when its conditions are simple.

**Prerequisites.** Conditions: Preconditions are adequate and actually checked; unknown reflection or external uses are not silently assumed absent.; Related property ids: ESME-028; ESME-030; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: The observer specified by the preservation contract.; Decision: Applicability is demonstrated or transformation is refused/narrowed; exceptions remain explicit.

**Authority and practical action.** Actors: The observer specified by the preservation contract.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Applicability is demonstrated or transformation is refused/narrowed; exceptions remain explicit. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S045; Adjudication: Source-supported: valid formal intention does not prevent implementation bugs or unsupported contexts.; Effect on disposition: Separate rule correctness, precondition truth and implementation conformity.

**Anti-ceremony boundary.** Essential: Applicability is demonstrated or transformation is refused/narrowed; exceptions remain explicit.; Minimal alternative: Direct review of a small transformation can replace a general engine when its conditions are simple.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Direct review of a small transformation can replace a general engine when its conditions are simple. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R007; ESME-R008; ESME-R041

#### Domain profile

**Change intent and change class.** A transformation’s correctness depends on names, bindings, inheritance, types or other structural conditions. Distinguish structure-preserving transformation from corrective or feature change; mixed changes need distinct obligations.

**Baseline and affected artefacts.** Transformation rule, input program, language semantics and engine version. Use exact pre/post code, language/tool versions and relevant runtime, persistence and external-interface context.

**Preservation obligation and observer.** The observer specified by the preservation contract. Preservation is relative to an observer: outputs, exceptions, timing, resources, reflection and layout may differ.

**Impact boundary and dependency evidence.** A refactoring boundary includes clients and hidden reflection/serialization use where consequential.

**Comprehension assumptions.** Preconditions are adequate and actually checked; unknown reflection or external uses are not silently assumed absent. The transformation engine and maintainer must know or conservatively handle the preconditions relied on.

**Oracle and regression limits.** Catalogue names, structural metrics and selected test passage are not proofs of observer-relative equivalence.

**Compatibility and migration preconditions.** A source-level refactoring may break binary/API consumers; include migration only when those observers matter.

**Release rollback or forward repair condition.** Reverting text may restore structure but cannot undo already emitted data or external effects; use the release model when deployed.

**Maintainer and downstream consumers.** Tool operator, reviewer and affected clients need the preservation scope and any deliberately changed behaviour.

**Lifecycle cost and retirement condition.** Direct review of a small transformation can replace a general engine when its conditions are simple. Name the future change class or other benefit; avoid cleanup without expected value and retire a transformation control when its trigger disappears.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: MODEL_BOUND; Reason: FORMAL_SCOPE_BOUND: source-supported model/guarantee and assumptions recorded in source table; no independent re-proof or unbounded deployment guarantee.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S045; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S045; Reason: Source-supported: valid formal intention does not prevent implementation bugs or unsupported contexts.

**Transferability.** Assessment: CONDITIONAL; Reason: Preconditions are adequate and actually checked; unknown reflection or external uses are not silently assumed absent. Which precondition is assumed rather than checked, and how could it fail?

**Source IDs:** ESME-S022, ESME-S045. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which precondition is assumed rather than checked, and how could it fail?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-030 — Validation of transformation engines

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; TOOL_ASSURANCE_MECHANISM

**Mature form.** Validate the implementation proportionately and recheck after relevant version changes.

**Controlled failure.** Source-supported: ASTGen exposed bugs, but bounded tests and differential checks do not prove all-engine correctness.

**Operating mechanism.** Exercise relevant tool/version transformations with targeted counterexamples, compilation, differential or other justified checks; investigate disagreements.

**Trigger.** A transformation engine is new, changed, historically faulty or used outside its validated envelope.

**Non-trigger and cheap path.** For a small trusted operation, review its concrete output rather than building a universal tool-validation campaign.

**Prerequisites.** Conditions: Useful oracles and representative dangerous constructs must be available.; Related property ids: ESME-028; ESME-029; ESME-081; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Tool user and reviewer who rely on the engine’s preservation claim.; Decision: The relevant engine behaviour has bounded validation evidence and known exclusions.

**Authority and practical action.** Actors: Tool user and reviewer who rely on the engine’s preservation claim.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The relevant engine behaviour has bounded validation evidence and known exclusions. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S045; Adjudication: Source-supported: ASTGen exposed bugs, but bounded tests and differential checks do not prove all-engine correctness.; Effect on disposition: Validate the implementation proportionately and recheck after relevant version changes.

**Anti-ceremony boundary.** Essential: The relevant engine behaviour has bounded validation evidence and known exclusions.; Minimal alternative: For a small trusted operation, review its concrete output rather than building a universal tool-validation campaign.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** For a small trusted operation, review its concrete output rather than building a universal tool-validation campaign. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T04; Discriminator: Compare accepted outcomes and total work, including later repair, on representative tasks under versioned settings.; Hybrid failure: Several tools share one invalid oracle, or the human rubber-stamps unreviewable volume.

**Composition coupling.** ESME-R007; ESME-R008; ESME-R041

#### Domain profile

**Change intent and change class.** A transformation engine is new, changed, historically faulty or used outside its validated envelope. Distinguish structure-preserving transformation from corrective or feature change; mixed changes need distinct obligations.

**Baseline and affected artefacts.** Engine version, transformation, generated or real test inputs and resulting artefacts. Use exact pre/post code, language/tool versions and relevant runtime, persistence and external-interface context.

**Preservation obligation and observer.** Tool user and reviewer who rely on the engine’s preservation claim. Preservation is relative to an observer: outputs, exceptions, timing, resources, reflection and layout may differ.

**Impact boundary and dependency evidence.** A refactoring boundary includes clients and hidden reflection/serialization use where consequential.

**Comprehension assumptions.** Useful oracles and representative dangerous constructs must be available. The transformation engine and maintainer must know or conservatively handle the preconditions relied on.

**Oracle and regression limits.** Catalogue names, structural metrics and selected test passage are not proofs of observer-relative equivalence.

**Compatibility and migration preconditions.** A source-level refactoring may break binary/API consumers; include migration only when those observers matter.

**Release rollback or forward repair condition.** Reverting text may restore structure but cannot undo already emitted data or external effects; use the release model when deployed.

**Maintainer and downstream consumers.** Tool operator, reviewer and affected clients need the preservation scope and any deliberately changed behaviour.

**Lifecycle cost and retirement condition.** For a small trusted operation, review its concrete output rather than building a universal tool-validation campaign. Name the future change class or other benefit; avoid cleanup without expected value and retire a transformation control when its trigger disappears.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S045; ESME-S024; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S045; Reason: Source-supported: ASTGen exposed bugs, but bounded tests and differential checks do not prove all-engine correctness.

**Transferability.** Assessment: CONDITIONAL; Reason: Useful oracles and representative dangerous constructs must be available. What concrete failure class is not exercised by the engine’s current validation?

**Source IDs:** ESME-S045, ESME-S024. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What concrete failure class is not exercised by the engine’s current validation?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-031 — Refactoring payoff tied to a future change class

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; ECONOMIC_SELECTION_CRITERION

**Mature form.** Retain conditional investment rather than refactoring as an unconditional virtue.

**Controlled failure.** Source-supported: structural metrics can worsen or fail to establish future savings; debt time is not automatically recoverable.

**Operating mechanism.** Name the future work or other justified benefit enabled by restructuring and compare expected avoided cost with transformation and regression risk.

**Trigger.** Repeated costly edits or a credible forthcoming change makes structural improvement valuable.

**Non-trigger and cheap path.** Perform a bounded repair or defer cleanup when no plausible future demand repays its cost.

**Prerequisites.** Conditions: Future demand and cost assumptions must be explicit and revisable.; Related property ids: ESME-028; ESME-058; ESME-059; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Future maintainers and those bearing current conversion cost.; Decision: A refactoring decision has a falsifiable benefit hypothesis and an after-use review point where proportionate.

**Authority and practical action.** Actors: Future maintainers and those bearing current conversion cost.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** A refactoring decision has a falsifiable benefit hypothesis and an after-use review point where proportionate. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S023; ESME-S057; Adjudication: Source-supported: structural metrics can worsen or fail to establish future savings; debt time is not automatically recoverable.; Effect on disposition: Retain conditional investment rather than refactoring as an unconditional virtue.

**Anti-ceremony boundary.** Essential: A refactoring decision has a falsifiable benefit hypothesis and an after-use review point where proportionate.; Minimal alternative: Perform a bounded repair or defer cleanup when no plausible future demand repays its cost.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Perform a bounded repair or defer cleanup when no plausible future demand repays its cost. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T02; Discriminator: Compare demonstrated next-change capability and total transition cost, not complexity score alone.; Hybrid failure: Long-lived mixed styles and half-transferred knowledge make both old and new harder to understand.; Tension id: ESME-T03; Discriminator: Compare feasible obligations, seam/data constraints and prospective costs including the exit, not sunk effort.; Hybrid failure: Permanent adapters and dual data authorities add migration cost without eliminating legacy cost.; Tension id: ESME-T06; Discriminator: State the change-contingent cost mechanism, horizon and uncertainty that could reverse priority.; Hybrid failure: Endless incidental cleanup hides scope expansion; feature urgency becomes a permanent excuse to ignore a known liability.

**Composition coupling.** ESME-R009; ESME-R041

#### Domain profile

**Change intent and change class.** Repeated costly edits or a credible forthcoming change makes structural improvement valuable. Distinguish structure-preserving transformation from corrective or feature change; mixed changes need distinct obligations.

**Baseline and affected artefacts.** Structure, expected change scenarios and intervention effort. Use exact pre/post code, language/tool versions and relevant runtime, persistence and external-interface context.

**Preservation obligation and observer.** Future maintainers and those bearing current conversion cost. Preservation is relative to an observer: outputs, exceptions, timing, resources, reflection and layout may differ.

**Impact boundary and dependency evidence.** A refactoring boundary includes clients and hidden reflection/serialization use where consequential.

**Comprehension assumptions.** Future demand and cost assumptions must be explicit and revisable. The transformation engine and maintainer must know or conservatively handle the preconditions relied on.

**Oracle and regression limits.** Catalogue names, structural metrics and selected test passage are not proofs of observer-relative equivalence.

**Compatibility and migration preconditions.** A source-level refactoring may break binary/API consumers; include migration only when those observers matter.

**Release rollback or forward repair condition.** Reverting text may restore structure but cannot undo already emitted data or external effects; use the release model when deployed.

**Maintainer and downstream consumers.** Tool operator, reviewer and affected clients need the preservation scope and any deliberately changed behaviour.

**Lifecycle cost and retirement condition.** Perform a bounded repair or defer cleanup when no plausible future demand repays its cost. Name the future change class or other benefit; avoid cleanup without expected value and retire a transformation control when its trigger disappears.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S023; ESME-S057; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S027; ESME-S057; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S023; ESME-S057; Reason: Source-supported: structural metrics can worsen or fail to establish future savings; debt time is not automatically recoverable.

**Transferability.** Assessment: CONDITIONAL; Reason: Future demand and cost assumptions must be explicit and revisable. Which expected future change would actually become cheaper, and at whose expense?

**Source IDs:** ESME-S022, ESME-S027, ESME-S058, ESME-S023, ESME-S057. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which expected future change would actually become cheaper, and at whose expense?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-032 — Maintainability metrics as fallible diagnostics

**Disposition and kind.** USEFUL_BUT_EASILY_GAMED; MEASUREMENT_PROXY

**Mature form.** Retain diagnosis with anti-gaming checks and discard unused scores.

**Controlled failure.** Source-supported: refactoring can increase structural metrics; current debt guidance rejects a single universal measure.

**Operating mechanism.** Use metrics to identify questions and compare a declared local objective; cross-check against actual task cost and requirements.

**Trigger.** A metric might reveal a bottleneck not already understood.

**Non-trigger and cheap path.** Direct evidence of difficult changes or a small review may dominate metric dashboards.

**Prerequisites.** Conditions: Measurement unit, tool and relation to desired outcome must be justified.; Related property ids: ESME-031; ESME-058; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Maintainer or planner interpreting the signal.; Decision: Metric movement is not reported as benefit unless the relevant outcome is also supported.

**Authority and practical action.** Actors: Maintainer or planner interpreting the signal.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Metric movement is not reported as benefit unless the relevant outcome is also supported. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S023; ESME-S058; Adjudication: Source-supported: refactoring can increase structural metrics; current debt guidance rejects a single universal measure.; Effect on disposition: Retain diagnosis with anti-gaming checks and discard unused scores.

**Anti-ceremony boundary.** Essential: Metric movement is not reported as benefit unless the relevant outcome is also supported.; Minimal alternative: Direct evidence of difficult changes or a small review may dominate metric dashboards.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Direct evidence of difficult changes or a small review may dominate metric dashboards. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R009; ESME-R041

#### Domain profile

**Change intent and change class.** A metric might reveal a bottleneck not already understood. Distinguish structure-preserving transformation from corrective or feature change; mixed changes need distinct obligations.

**Baseline and affected artefacts.** Metric definition, affected structure and real maintenance tasks. Use exact pre/post code, language/tool versions and relevant runtime, persistence and external-interface context.

**Preservation obligation and observer.** Maintainer or planner interpreting the signal. Preservation is relative to an observer: outputs, exceptions, timing, resources, reflection and layout may differ.

**Impact boundary and dependency evidence.** A refactoring boundary includes clients and hidden reflection/serialization use where consequential.

**Comprehension assumptions.** Measurement unit, tool and relation to desired outcome must be justified. The transformation engine and maintainer must know or conservatively handle the preconditions relied on.

**Oracle and regression limits.** Catalogue names, structural metrics and selected test passage are not proofs of observer-relative equivalence.

**Compatibility and migration preconditions.** A source-level refactoring may break binary/API consumers; include migration only when those observers matter.

**Release rollback or forward repair condition.** Reverting text may restore structure but cannot undo already emitted data or external effects; use the release model when deployed.

**Maintainer and downstream consumers.** Tool operator, reviewer and affected clients need the preservation scope and any deliberately changed behaviour.

**Lifecycle cost and retirement condition.** Direct evidence of difficult changes or a small review may dominate metric dashboards. Name the future change class or other benefit; avoid cleanup without expected value and retire a transformation control when its trigger disappears.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S023; ESME-S057; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S057; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: PARTIAL_WITH_SHARED_PROGRAMME; Reason: ESME-S057 includes a separate company setting with changed measurement and overlapping researchers.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S023; ESME-S058; Reason: Source-supported: refactoring can increase structural metrics; current debt guidance rejects a single universal measure.

**Transferability.** Assessment: CONDITIONAL; Reason: Measurement unit, tool and relation to desired outcome must be justified. Can the score improve while the real maintenance task becomes harder?

**Source IDs:** ESME-S023, ESME-S057, ESME-S058. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Can the score improve while the real maintenance task becomes harder?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-034 — Characterisation tests with normative review

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; ORACLE_RECOVERY_MECHANISM

**Mature form.** Characterisation is descriptive evidence coupled to an independent intent decision.

**Controlled failure.** Source-supported: existing tests and reference patches can encode mistakes or irrelevant behaviour.

**Operating mechanism.** Record observed behaviour and label whether it is an accepted obligation, disputed legacy behaviour or a defect; use characterisation to expose change rather than automatically bless the baseline.

**Trigger.** Important undocumented behaviour makes a change risky.

**Non-trigger and cheap path.** A focused example or domain review may suffice instead of broad snapshot generation.

**Prerequisites.** Conditions: Baseline observations are reproducible and their normative status can be examined.; Related property ids: ESME-001; ESME-012; ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Domain consumer whose reliance may or may not legitimise the behaviour.; Decision: Captured behaviour is classified as preserve, deliberately revise or unresolved before it becomes an acceptance rule.

**Authority and practical action.** Actors: Domain consumer whose reliance may or may not legitimise the behaviour.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Captured behaviour is classified as preserve, deliberately revise or unresolved before it becomes an acceptance rule. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S034; ESME-S063; ESME-S064; Adjudication: Source-supported: existing tests and reference patches can encode mistakes or irrelevant behaviour.; Effect on disposition: Characterisation is descriptive evidence coupled to an independent intent decision.

**Anti-ceremony boundary.** Essential: Captured behaviour is classified as preserve, deliberately revise or unresolved before it becomes an acceptance rule.; Minimal alternative: A focused example or domain review may suffice instead of broad snapshot generation.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A focused example or domain review may suffice instead of broad snapshot generation. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T01; Discriminator: Identify the actual obligation, consumer and authorisation for revision; unresolved authority blocks that revision, not unrelated work.; Hybrid failure: Two ambiguous meanings, unmaintained compatibility mode, or an oracle changed solely to pass.

**Composition coupling.** ESME-R018; ESME-R035; ESME-R042; ESME-R052

#### Domain profile

**Change intent and change class.** Important undocumented behaviour makes a change risky. Separate the newly intended effect from independent obligations intended to survive a release.

**Baseline and affected artefacts.** Legacy outputs, tests, data examples and requirement interpretation. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Preservation obligation and observer.** Domain consumer whose reliance may or may not legitimise the behaviour. An oracle is a source of expected behaviour with assumptions, not the fact that a test happened to pass.

**Impact boundary and dependency evidence.** Test selection and release sampling cover declared dependency/traffic boundaries; shared state can defeat assumed isolation.

**Comprehension assumptions.** Baseline observations are reproducible and their normative status can be examined. Maintainers must know test and environment omissions, while operators must understand release and recovery conditions.

**Oracle and regression limits.** Tests can encode old faults, miss rare behaviour or use broken harnesses; independent evidence must address consequential omissions.

**Compatibility and migration preconditions.** Mixed versions and schema transitions require accepted intermediate states, not just endpoint compatibility.

**Release rollback or forward repair condition.** Specify whether recovery means code reversion, data restoration, compensation, containment or forward repair, with evidence of feasibility.

**Maintainer and downstream consumers.** Developers, release operators and downstream users exchange version identity, acceptance evidence, exposure decisions and incident observations.

**Lifecycle cost and retirement condition.** A focused example or domain review may suffice instead of broad snapshot generation. Testing and rollout costs must be proportional to loss exposure; remove redundant checks, not the last evidence for a live obligation.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S034; ESME-S063; ESME-S064; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S034; ESME-S063; ESME-S064; Reason: Source-supported: existing tests and reference patches can encode mistakes or irrelevant behaviour.

**Transferability.** Assessment: CONDITIONAL; Reason: Baseline observations are reproducible and their normative status can be examined. Does this test capture a promise, an accident, or a disputed behaviour?

**Source IDs:** ESME-S025, ESME-S041, ESME-S034, ESME-S063, ESME-S064. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Does this test capture a promise, an accident, or a disputed behaviour?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-035 — Independent change and regression obligations

**Disposition and kind.** STRONGLY_RETAINED; ACCEPTANCE_CRITERION

**Mature form.** Independence concerns the obligations and warrants, not mandatory organisational separation.

**Controlled failure.** Source-supported: plausible repair can satisfy selected tests yet regress or remain under-specified.

**Operating mechanism.** Separately establish evidence for the intended new effect and the consequential behaviours that must survive, with uncertainty stated for both.

**Trigger.** Any intervention changes or risks a relied-on behaviour.

**Non-trigger and cheap path.** One test may address both obligations if its distinct assertions and coverage are clear; no separate team is inherently required.

**Prerequisites.** Conditions: Intent is legitimate; evidence addresses rather than merely restates the claimed result.; Related property ids: ESME-001; ESME-021; ESME-034; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Requesting stakeholder and existing consumers.; Decision: Acceptance can explain both the justified difference and the justified continuity.

**Authority and practical action.** Actors: Requesting stakeholder and existing consumers.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Acceptance can explain both the justified difference and the justified continuity. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S034; ESME-S063; ESME-S064; Adjudication: Source-supported: plausible repair can satisfy selected tests yet regress or remain under-specified.; Effect on disposition: Independence concerns the obligations and warrants, not mandatory organisational separation.

**Anti-ceremony boundary.** Essential: Acceptance can explain both the justified difference and the justified continuity.; Minimal alternative: One test may address both obligations if its distinct assertions and coverage are clear; no separate team is inherently required.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** One test may address both obligations if its distinct assertions and coverage are clear; no separate team is inherently required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T01; Discriminator: Identify the actual obligation, consumer and authorisation for revision; unresolved authority blocks that revision, not unrelated work.; Hybrid failure: Two ambiguous meanings, unmaintained compatibility mode, or an oracle changed solely to pass.; Tension id: ESME-T05; Discriminator: Identify the loss-bearing observation and whether the chosen method can actually detect it before unacceptable exposure.; Hybrid failure: Early green results become unspoken permission to omit the only test for a live obligation.

**Composition coupling.** ESME-R001; ESME-R002; ESME-R007; ESME-R018; ESME-R019; ESME-R021; ESME-R026; ESME-R028; ESME-R029; ESME-R030; ESME-R031; ESME-R034; ESME-R035; ESME-R042

#### Domain profile

**Change intent and change class.** Any intervention changes or risks a relied-on behaviour. Separate the newly intended effect from independent obligations intended to survive a release.

**Baseline and affected artefacts.** New objective, preservation set, tests and other evidence. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Preservation obligation and observer.** Requesting stakeholder and existing consumers. An oracle is a source of expected behaviour with assumptions, not the fact that a test happened to pass.

**Impact boundary and dependency evidence.** Test selection and release sampling cover declared dependency/traffic boundaries; shared state can defeat assumed isolation.

**Comprehension assumptions.** Intent is legitimate; evidence addresses rather than merely restates the claimed result. Maintainers must know test and environment omissions, while operators must understand release and recovery conditions.

**Oracle and regression limits.** Tests can encode old faults, miss rare behaviour or use broken harnesses; independent evidence must address consequential omissions.

**Compatibility and migration preconditions.** Mixed versions and schema transitions require accepted intermediate states, not just endpoint compatibility.

**Release rollback or forward repair condition.** Specify whether recovery means code reversion, data restoration, compensation, containment or forward repair, with evidence of feasibility.

**Maintainer and downstream consumers.** Developers, release operators and downstream users exchange version identity, acceptance evidence, exposure decisions and incident observations.

**Lifecycle cost and retirement condition.** One test may address both obligations if its distinct assertions and coverage are clear; no separate team is inherently required. Testing and rollout costs must be proportional to loss exposure; remove redundant checks, not the last evidence for a live obligation.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S026.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S034; ESME-S063; ESME-S064; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S034; ESME-S063; ESME-S064; Reason: Source-supported: plausible repair can satisfy selected tests yet regress or remain under-specified.

**Transferability.** Assessment: CONDITIONAL; Reason: Intent is legitimate; evidence addresses rather than merely restates the claimed result. What evidence checks the preserved obligation independently of the new patch’s preferred interpretation?

**Source IDs:** ESME-S025, ESME-S026, ESME-S041, ESME-S034, ESME-S063, ESME-S064. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What evidence checks the preserved obligation independently of the new patch’s preferred interpretation?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-036 — Regression selection with suite-relative safety

**Disposition and kind.** ASSUMPTION_SENSITIVE; FORMAL_AND_ANALYTICAL_MECHANISM

**Mature form.** Safety remains relative to the suite and implementation envelope, never total correctness.

**Controlled failure.** Source-supported: RTSCheck exposes both implementation failures and technique limitations; empirical cost models can be coarse.

**Operating mechanism.** Choose a selection method only within its dependency/language envelope; escalate to broader execution when relevant changes fall outside it.

**Trigger.** Running the whole available suite has material cost and sound selection can be justified.

**Non-trigger and cheap path.** Run the full affordable suite; do not add selection complexity when it saves little.

**Prerequisites.** Conditions: Method conditions, dependency modelling and tool implementation must hold.; Related property ids: ESME-021; ESME-024; ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Tests in the declared suite, not all possible user observations.; Decision: Selected-suite rationale and exclusions are visible; unsupported change kinds trigger fallback.

**Authority and practical action.** Actors: Tests in the declared suite, not all possible user observations.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Selected-suite rationale and exclusions are visible; unsupported change kinds trigger fallback. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S024; Adjudication: Source-supported: RTSCheck exposes both implementation failures and technique limitations; empirical cost models can be coarse.; Effect on disposition: Safety remains relative to the suite and implementation envelope, never total correctness.

**Anti-ceremony boundary.** Essential: Selected-suite rationale and exclusions are visible; unsupported change kinds trigger fallback.; Minimal alternative: Run the full affordable suite; do not add selection complexity when it saves little.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Run the full affordable suite; do not add selection complexity when it saves little. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T05; Discriminator: Identify the loss-bearing observation and whether the chosen method can actually detect it before unacceptable exposure.; Hybrid failure: Early green results become unspoken permission to omit the only test for a live obligation.

**Composition coupling.** ESME-R019; ESME-R020

#### Domain profile

**Change intent and change class.** Running the whole available suite has material cost and sound selection can be justified. Separate the newly intended effect from independent obligations intended to survive a release.

**Baseline and affected artefacts.** Original/changed program, existing test suite and selection dependencies. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Preservation obligation and observer.** Tests in the declared suite, not all possible user observations. An oracle is a source of expected behaviour with assumptions, not the fact that a test happened to pass.

**Impact boundary and dependency evidence.** Test selection and release sampling cover declared dependency/traffic boundaries; shared state can defeat assumed isolation.

**Comprehension assumptions.** Method conditions, dependency modelling and tool implementation must hold. Maintainers must know test and environment omissions, while operators must understand release and recovery conditions.

**Oracle and regression limits.** Tests can encode old faults, miss rare behaviour or use broken harnesses; independent evidence must address consequential omissions.

**Compatibility and migration preconditions.** Mixed versions and schema transitions require accepted intermediate states, not just endpoint compatibility.

**Release rollback or forward repair condition.** Specify whether recovery means code reversion, data restoration, compensation, containment or forward repair, with evidence of feasibility.

**Maintainer and downstream consumers.** Developers, release operators and downstream users exchange version identity, acceptance evidence, exposure decisions and incident observations.

**Lifecycle cost and retirement condition.** Run the full affordable suite; do not add selection complexity when it saves little. Testing and rollout costs must be proportional to loss exposure; remove redundant checks, not the last evidence for a live obligation.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S026.

**Theory.** Assessment: MODEL_BOUND; Reason: FORMAL_SCOPE_BOUND: source-supported model/guarantee and assumptions recorded in source table; no independent re-proof or unbounded deployment guarantee.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S046; ESME-S024; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S024; Reason: Source-supported: RTSCheck exposes both implementation failures and technique limitations; empirical cost models can be coarse.

**Transferability.** Assessment: CONDITIONAL; Reason: Method conditions, dependency modelling and tool implementation must hold. Which existing failing test could be omitted by this selector’s unsupported dependency kind?

**Source IDs:** ESME-S026, ESME-S046, ESME-S024. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which existing failing test could be omitted by this selector’s unsupported dependency kind?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-037 — Test prioritisation for early information

**Disposition and kind.** CONTEXT_DEPENDENT; SCHEDULING_MECHANISM

**Mature form.** Separate prioritisation from selection and from evidence adequacy.

**Controlled failure.** Source-supported: inspected original abstract supports the objective, not detailed general benefit; order does not cure weak oracles.

**Operating mechanism.** Order tests by justified expected information or risk within available time, while separately deciding whether stopping early is acceptable.

**Trigger.** A time-constrained test run benefits from earlier actionable failures.

**Non-trigger and cheap path.** Keep the existing order when the suite is cheap or priority estimates are unreliable.

**Prerequisites.** Conditions: Priority assumptions and any truncation policy must be explicit.; Related property ids: ESME-035; ESME-036; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Developer or release decision maker waiting for information.; Decision: The ordering objective is stated and omitted tests, if any, remain known.

**Authority and practical action.** Actors: Developer or release decision maker waiting for information.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The ordering objective is stated and omitted tests, if any, remain known. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S025; Adjudication: Source-supported: inspected original abstract supports the objective, not detailed general benefit; order does not cure weak oracles.; Effect on disposition: Separate prioritisation from selection and from evidence adequacy.

**Anti-ceremony boundary.** Essential: The ordering objective is stated and omitted tests, if any, remain known.; Minimal alternative: Keep the existing order when the suite is cheap or priority estimates are unreliable.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Keep the existing order when the suite is cheap or priority estimates are unreliable. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T05; Discriminator: Identify the loss-bearing observation and whether the chosen method can actually detect it before unacceptable exposure.; Hybrid failure: Early green results become unspoken permission to omit the only test for a live obligation.

**Composition coupling.** ESME-R019

#### Domain profile

**Change intent and change class.** A time-constrained test run benefits from earlier actionable failures. Separate the newly intended effect from independent obligations intended to survive a release.

**Baseline and affected artefacts.** Test set, order, duration estimates and failure relevance. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Preservation obligation and observer.** Developer or release decision maker waiting for information. An oracle is a source of expected behaviour with assumptions, not the fact that a test happened to pass.

**Impact boundary and dependency evidence.** Test selection and release sampling cover declared dependency/traffic boundaries; shared state can defeat assumed isolation.

**Comprehension assumptions.** Priority assumptions and any truncation policy must be explicit. Maintainers must know test and environment omissions, while operators must understand release and recovery conditions.

**Oracle and regression limits.** Tests can encode old faults, miss rare behaviour or use broken harnesses; independent evidence must address consequential omissions.

**Compatibility and migration preconditions.** Mixed versions and schema transitions require accepted intermediate states, not just endpoint compatibility.

**Release rollback or forward repair condition.** Specify whether recovery means code reversion, data restoration, compensation, containment or forward repair, with evidence of feasibility.

**Maintainer and downstream consumers.** Developers, release operators and downstream users exchange version identity, acceptance evidence, exposure decisions and incident observations.

**Lifecycle cost and retirement condition.** Keep the existing order when the suite is cheap or priority estimates are unreliable. Testing and rollout costs must be proportional to loss exposure; remove redundant checks, not the last evidence for a live obligation.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S047.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S047; ESME-S046; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S025; Reason: Source-supported: inspected original abstract supports the objective, not detailed general benefit; order does not cure weak oracles.

**Transferability.** Assessment: CONDITIONAL; Reason: Priority assumptions and any truncation policy must be explicit. Does faster early feedback justify leaving later tests unexecuted in this decision?

**Source IDs:** ESME-S047, ESME-S046, ESME-S025. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Does faster early feedback justify leaving later tests unexecuted in this decision?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-038 — Mutation analysis as an adequacy diagnostic

**Disposition and kind.** CONTEXT_DEPENDENT; TEST_ASSESSMENT_MECHANISM

**Mature form.** Retain conditional diagnostics and avoid maximising mutation score for its own sake.

**Controlled failure.** Source-supported: real-fault studies require filtered, language-specific samples; mutation is not all-defect equivalence.

**Operating mechanism.** Use relevant mutation operators to challenge specific test weaknesses; investigate surviving mutants and equivalent or irrelevant mutants separately.

**Trigger.** A consequential preservation obligation may be weakly exercised by the current tests.

**Non-trigger and cheap path.** Add a targeted real-fault regression case or review a missing assertion rather than run broad mutation campaigns.

**Prerequisites.** Conditions: Operators and mutants represent relevant fault mechanisms; equivalent mutants and cost are handled.; Related property ids: ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Maintainer assessing tests, not treating a score as requirements completeness.; Decision: A surviving relevant mutant yields a useful test/observation or an explained non-obligation.

**Authority and practical action.** Actors: Maintainer assessing tests, not treating a score as requirements completeness.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** A surviving relevant mutant yields a useful test/observation or an explained non-obligation. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S025; ESME-S046; Adjudication: Source-supported: real-fault studies require filtered, language-specific samples; mutation is not all-defect equivalence.; Effect on disposition: Retain conditional diagnostics and avoid maximising mutation score for its own sake.

**Anti-ceremony boundary.** Essential: A surviving relevant mutant yields a useful test/observation or an explained non-obligation.; Minimal alternative: Add a targeted real-fault regression case or review a missing assertion rather than run broad mutation campaigns.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Add a targeted real-fault regression case or review a missing assertion rather than run broad mutation campaigns. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T05; Discriminator: Identify the loss-bearing observation and whether the chosen method can actually detect it before unacceptable exposure.; Hybrid failure: Early green results become unspoken permission to omit the only test for a live obligation.

**Composition coupling.** ESME-R019

#### Domain profile

**Change intent and change class.** A consequential preservation obligation may be weakly exercised by the current tests. Separate the newly intended effect from independent obligations intended to survive a release.

**Baseline and affected artefacts.** Mutants, tests, fault model and targeted behaviour. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Preservation obligation and observer.** Maintainer assessing tests, not treating a score as requirements completeness. An oracle is a source of expected behaviour with assumptions, not the fact that a test happened to pass.

**Impact boundary and dependency evidence.** Test selection and release sampling cover declared dependency/traffic boundaries; shared state can defeat assumed isolation.

**Comprehension assumptions.** Operators and mutants represent relevant fault mechanisms; equivalent mutants and cost are handled. Maintainers must know test and environment omissions, while operators must understand release and recovery conditions.

**Oracle and regression limits.** Tests can encode old faults, miss rare behaviour or use broken harnesses; independent evidence must address consequential omissions.

**Compatibility and migration preconditions.** Mixed versions and schema transitions require accepted intermediate states, not just endpoint compatibility.

**Release rollback or forward repair condition.** Specify whether recovery means code reversion, data restoration, compensation, containment or forward repair, with evidence of feasibility.

**Maintainer and downstream consumers.** Developers, release operators and downstream users exchange version identity, acceptance evidence, exposure decisions and incident observations.

**Lifecycle cost and retirement condition.** Add a targeted real-fault regression case or review a missing assertion rather than run broad mutation campaigns. Testing and rollout costs must be proportional to loss exposure; remove redundant checks, not the last evidence for a live obligation.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S048; ESME-S046; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S025; ESME-S046; Reason: Source-supported: real-fault studies require filtered, language-specific samples; mutation is not all-defect equivalence.

**Transferability.** Assessment: CONDITIONAL; Reason: Operators and mutants represent relevant fault mechanisms; equivalent mutants and cost are handled. Could the suite kill these mutants while still missing the relevant real requirement?

**Source IDs:** ESME-S048, ESME-S025, ESME-S046. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Could the suite kill these mutants while still missing the relevant real requirement?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-039 — Differential and metamorphic evidence without an infallible oracle

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; ORACLE_COMPARISON_MECHANISM

**Mature form.** Diversity creates questions for adjudication, not an automatic correctness oracle.

**Controlled failure.** Source-supported: suspicious SWE-bench patches include correct alternatives and invalid differentiating inputs.

**Operating mechanism.** Specify why the compared outputs or metamorphic relation should agree, then adjudicate differences against legitimate input and requirement assumptions.

**Trigger.** A missing direct oracle can be supplemented by another implementation or justified relation.

**Non-trigger and cheap path.** Manual expected-value examples suffice for simple known behaviour; do not introduce an untrusted reference unnecessarily.

**Prerequisites.** Conditions: The reference or relation has a justified domain and cannot supply its own normative authority.; Related property ids: ESME-001; ESME-034; ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Domain-relevant observer, not identity to a reference patch.; Decision: A discrepancy is classified as defect, valid alternative, invalid test or unresolved requirement.

**Authority and practical action.** Actors: Domain-relevant observer, not identity to a reference patch.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** A discrepancy is classified as defect, valid alternative, invalid test or unresolved requirement. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S063; ESME-S064; Adjudication: Source-supported: suspicious SWE-bench patches include correct alternatives and invalid differentiating inputs.; Effect on disposition: Diversity creates questions for adjudication, not an automatic correctness oracle.

**Anti-ceremony boundary.** Essential: A discrepancy is classified as defect, valid alternative, invalid test or unresolved requirement.; Minimal alternative: Manual expected-value examples suffice for simple known behaviour; do not introduce an untrusted reference unnecessarily.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Manual expected-value examples suffice for simple known behaviour; do not introduce an untrusted reference unnecessarily. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R018; ESME-R019; ESME-R042; ESME-R052

#### Domain profile

**Change intent and change class.** A missing direct oracle can be supplemented by another implementation or justified relation. Separate the newly intended effect from independent obligations intended to survive a release.

**Baseline and affected artefacts.** Implementations, transformed inputs, expected relations and differentiating tests. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Preservation obligation and observer.** Domain-relevant observer, not identity to a reference patch. An oracle is a source of expected behaviour with assumptions, not the fact that a test happened to pass.

**Impact boundary and dependency evidence.** Test selection and release sampling cover declared dependency/traffic boundaries; shared state can defeat assumed isolation.

**Comprehension assumptions.** The reference or relation has a justified domain and cannot supply its own normative authority. Maintainers must know test and environment omissions, while operators must understand release and recovery conditions.

**Oracle and regression limits.** Tests can encode old faults, miss rare behaviour or use broken harnesses; independent evidence must address consequential omissions.

**Compatibility and migration preconditions.** Mixed versions and schema transitions require accepted intermediate states, not just endpoint compatibility.

**Release rollback or forward repair condition.** Specify whether recovery means code reversion, data restoration, compensation, containment or forward repair, with evidence of feasibility.

**Maintainer and downstream consumers.** Developers, release operators and downstream users exchange version identity, acceptance evidence, exposure decisions and incident observations.

**Lifecycle cost and retirement condition.** Manual expected-value examples suffice for simple known behaviour; do not introduce an untrusted reference unnecessarily. Testing and rollout costs must be proportional to loss exposure; remove redundant checks, not the last evidence for a live obligation.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S045; ESME-S063; ESME-S064; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S063; ESME-S064; Reason: Source-supported: suspicious SWE-bench patches include correct alternatives and invalid differentiating inputs.

**Transferability.** Assessment: CONDITIONAL; Reason: The reference or relation has a justified domain and cannot supply its own normative authority. Why is agreement required on this input, and which implementation might be wrong?

**Source IDs:** ESME-S025, ESME-S045, ESME-S063, ESME-S064. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Why is agreement required on this input, and which implementation might be wrong?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-041 — Reproducible build and artefact identity

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; CONFIGURATION_AND_REPRODUCTION_MECHANISM

**Mature form.** Repeatability is scoped evidence, not a proof of safety or correctness.

**Controlled failure.** Source-supported: package-manager and environment differences matter; a repeatably malicious or incorrect source remains wrong.

**Operating mechanism.** Record the relevant build inputs and verify a repeatable path to the released artefact; distinguish bitwise reproducibility from functional repeatability.

**Trigger.** Attribution, support, archival reuse or supply-chain checks depend on connecting source and delivered artefacts.

**Non-trigger and cheap path.** For a directly interpreted single file, version identity and execution environment may be enough; do not mandate byte-identical builds without a consumer.

**Prerequisites.** Conditions: The chosen reproducibility notion and external inputs are declared.; Related property ids: ESME-004; ESME-024; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Maintainer or downstream party comparing built outputs.; Decision: A relevant rebuild or exact identity comparison succeeds, or its nondeterminism and limitations are explicit.

**Authority and practical action.** Actors: Maintainer or downstream party comparing built outputs.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** A relevant rebuild or exact identity comparison succeeds, or its nondeterminism and limitations are explicit. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S052; ESME-S062; Adjudication: Source-supported: package-manager and environment differences matter; a repeatably malicious or incorrect source remains wrong.; Effect on disposition: Repeatability is scoped evidence, not a proof of safety or correctness.

**Anti-ceremony boundary.** Essential: A relevant rebuild or exact identity comparison succeeds, or its nondeterminism and limitations are explicit.; Minimal alternative: For a directly interpreted single file, version identity and execution environment may be enough; do not mandate byte-identical builds without a consumer.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** For a directly interpreted single file, version identity and execution environment may be enough; do not mandate byte-identical builds without a consumer. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T08; Discriminator: Ask what future consumer must actually be able to do: retrieve, interpret, execute or receive service.; Hybrid failure: An archive is advertised as runnable despite missing dependencies, or an obsolete service is kept live without a support purpose.

**Composition coupling.** ESME-R002

#### Domain profile

**Change intent and change class.** Attribution, support, archival reuse or supply-chain checks depend on connecting source and delivered artefacts. Separate the newly intended effect from independent obligations intended to survive a release.

**Baseline and affected artefacts.** Source, compiler, packaging tools, dependencies, environment and released artefact. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Preservation obligation and observer.** Maintainer or downstream party comparing built outputs. An oracle is a source of expected behaviour with assumptions, not the fact that a test happened to pass.

**Impact boundary and dependency evidence.** Test selection and release sampling cover declared dependency/traffic boundaries; shared state can defeat assumed isolation.

**Comprehension assumptions.** The chosen reproducibility notion and external inputs are declared. Maintainers must know test and environment omissions, while operators must understand release and recovery conditions.

**Oracle and regression limits.** Tests can encode old faults, miss rare behaviour or use broken harnesses; independent evidence must address consequential omissions.

**Compatibility and migration preconditions.** Mixed versions and schema transitions require accepted intermediate states, not just endpoint compatibility.

**Release rollback or forward repair condition.** Specify whether recovery means code reversion, data restoration, compensation, containment or forward repair, with evidence of feasibility.

**Maintainer and downstream consumers.** Developers, release operators and downstream users exchange version identity, acceptance evidence, exposure decisions and incident observations.

**Lifecycle cost and retirement condition.** For a directly interpreted single file, version identity and execution environment may be enough; do not mandate byte-identical builds without a consumer. Testing and rollout costs must be proportional to loss exposure; remove redundant checks, not the last evidence for a live obligation.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S052; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S050; ESME-S062; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S052; ESME-S062; Reason: Source-supported: package-manager and environment differences matter; a repeatably malicious or incorrect source remains wrong.

**Transferability.** Assessment: CONDITIONAL; Reason: The chosen reproducibility notion and external inputs are declared. Which uncontrolled input changes the output despite the same source revision?

**Source IDs:** ESME-S019, ESME-S050, ESME-S052, ESME-S062. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which uncontrolled input changes the output despite the same source revision?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-042 — Continuous integration as integration feedback

**Disposition and kind.** CONTEXT_DEPENDENT; FEEDBACK_AND_COORDINATION_MECHANISM

**Mature form.** Retain actionable integration feedback, not a universal daily ritual or tool brand.

**Controlled failure.** Source-supported: clean merges and selected tests can miss semantics/non-code dependencies. Analytical: frequent green runs with no useful consumer are ceremony.

**Operating mechanism.** Integrate at a cadence suited to actual dependencies and run evidence that can detect meaningful interaction failures; communicate failures to someone able to act.

**Trigger.** Concurrent changes or delayed integration conceal incompatibilities.

**Non-trigger and cheap path.** A small serially maintained artefact can use direct build/test checks without a dedicated service or fixed cadence.

**Prerequisites.** Conditions: Feedback is timely, interpretable and linked to a corrective decision.; Related property ids: ESME-004; ESME-027; ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Contributors and release consumers affected by integration.; Decision: Integration failures are attributed and resolved or consciously deferred before relying on the combined state.

**Authority and practical action.** Actors: Contributors and release consumers affected by integration.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Integration failures are attributed and resolved or consciously deferred before relying on the combined state. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S024; ESME-S066; Adjudication: Source-supported: clean merges and selected tests can miss semantics/non-code dependencies. Analytical: frequent green runs with no useful consumer are ceremony.; Effect on disposition: Retain actionable integration feedback, not a universal daily ritual or tool brand.

**Anti-ceremony boundary.** Essential: Integration failures are attributed and resolved or consciously deferred before relying on the combined state.; Minimal alternative: A small serially maintained artefact can use direct build/test checks without a dedicated service or fixed cadence.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A small serially maintained artefact can use direct build/test checks without a dedicated service or fixed cadence. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T05; Discriminator: Identify the loss-bearing observation and whether the chosen method can actually detect it before unacceptable exposure.; Hybrid failure: Early green results become unspoken permission to omit the only test for a live obligation.

**Composition coupling.** ESME-R021; ESME-R022

#### Domain profile

**Change intent and change class.** Concurrent changes or delayed integration conceal incompatibilities. Separate the newly intended effect from independent obligations intended to survive a release.

**Baseline and affected artefacts.** Integrated revisions, build/test results and responsible maintainers. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Preservation obligation and observer.** Contributors and release consumers affected by integration. An oracle is a source of expected behaviour with assumptions, not the fact that a test happened to pass.

**Impact boundary and dependency evidence.** Test selection and release sampling cover declared dependency/traffic boundaries; shared state can defeat assumed isolation.

**Comprehension assumptions.** Feedback is timely, interpretable and linked to a corrective decision. Maintainers must know test and environment omissions, while operators must understand release and recovery conditions.

**Oracle and regression limits.** Tests can encode old faults, miss rare behaviour or use broken harnesses; independent evidence must address consequential omissions.

**Compatibility and migration preconditions.** Mixed versions and schema transitions require accepted intermediate states, not just endpoint compatibility.

**Release rollback or forward repair condition.** Specify whether recovery means code reversion, data restoration, compensation, containment or forward repair, with evidence of feasibility.

**Maintainer and downstream consumers.** Developers, release operators and downstream users exchange version identity, acceptance evidence, exposure decisions and incident observations.

**Lifecycle cost and retirement condition.** A small serially maintained artefact can use direct build/test checks without a dedicated service or fixed cadence. Testing and rollout costs must be proportional to loss exposure; remove redundant checks, not the last evidence for a live obligation.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S024; ESME-S066; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S050; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S024; ESME-S066; Reason: Source-supported: clean merges and selected tests can miss semantics/non-code dependencies. Analytical: frequent green runs with no useful consumer are ceremony.

**Transferability.** Assessment: CONDITIONAL; Reason: Feedback is timely, interpretable and linked to a corrective decision. Which integration failure can this feedback detect and who changes the resulting decision?

**Source IDs:** ESME-S019, ESME-S041, ESME-S050, ESME-S024, ESME-S066. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which integration failure can this feedback detect and who changes the resulting decision?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-043 — Observation-aware staged exposure

**Disposition and kind.** CONTEXT_DEPENDENT; DEPLOYMENT_EXPERIMENT_MECHANISM

**Mature form.** Conditional staged observation, not mandatory percentages or automatic promotion on green dashboards.

**Controlled failure.** Source-supported: shared failure domains, rare events and nonrepresentative traffic can invalidate canary conclusions.

**Operating mechanism.** Choose an isolatable population, meaningful observation window and attributable metrics; stop or revise on adverse or insufficient evidence.

**Trigger.** Production-only uncertainties can be investigated with genuinely limited and reversible exposure.

**Non-trigger and cheap path.** Use direct release with proportionate checks for low-impact changes, or offline rehearsal where live exposure is unsafe.

**Prerequisites.** Conditions: Isolation, representativeness, measurement sensitivity and authority to halt must exist.; Related property ids: ESME-035; ESME-044; ESME-051; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Real users and operators observing relevant service consequences.; Decision: Expansion is justified by relevant observations; missing signal is not treated as a pass.

**Authority and practical action.** Actors: Real users and operators observing relevant service consequences.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Expansion is justified by relevant observations; missing signal is not treated as a pass. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S051; ESME-S062; Adjudication: Source-supported: shared failure domains, rare events and nonrepresentative traffic can invalidate canary conclusions.; Effect on disposition: Conditional staged observation, not mandatory percentages or automatic promotion on green dashboards.

**Anti-ceremony boundary.** Essential: Expansion is justified by relevant observations; missing signal is not treated as a pass.; Minimal alternative: Use direct release with proportionate checks for low-impact changes, or offline rehearsal where live exposure is unsafe.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Use direct release with proportionate checks for low-impact changes, or offline rehearsal where live exposure is unsafe. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T05; Discriminator: Identify the loss-bearing observation and whether the chosen method can actually detect it before unacceptable exposure.; Hybrid failure: Early green results become unspoken permission to omit the only test for a live obligation.

**Composition coupling.** ESME-R014; ESME-R019; ESME-R022; ESME-R034

#### Domain profile

**Change intent and change class.** Production-only uncertainties can be investigated with genuinely limited and reversible exposure. Separate the newly intended effect from independent obligations intended to survive a release.

**Baseline and affected artefacts.** Release candidate, control, traffic population, data/configuration and monitoring. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Preservation obligation and observer.** Real users and operators observing relevant service consequences. An oracle is a source of expected behaviour with assumptions, not the fact that a test happened to pass.

**Impact boundary and dependency evidence.** Test selection and release sampling cover declared dependency/traffic boundaries; shared state can defeat assumed isolation.

**Comprehension assumptions.** Isolation, representativeness, measurement sensitivity and authority to halt must exist. Maintainers must know test and environment omissions, while operators must understand release and recovery conditions.

**Oracle and regression limits.** Tests can encode old faults, miss rare behaviour or use broken harnesses; independent evidence must address consequential omissions.

**Compatibility and migration preconditions.** Mixed versions and schema transitions require accepted intermediate states, not just endpoint compatibility.

**Release rollback or forward repair condition.** Specify whether recovery means code reversion, data restoration, compensation, containment or forward repair, with evidence of feasibility.

**Maintainer and downstream consumers.** Developers, release operators and downstream users exchange version identity, acceptance evidence, exposure decisions and incident observations.

**Lifecycle cost and retirement condition.** Use direct release with proportionate checks for low-impact changes, or offline rehearsal where live exposure is unsafe. Testing and rollout costs must be proportional to loss exposure; remove redundant checks, not the last evidence for a live obligation.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S051; ESME-S062; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S051; ESME-S062; Reason: Source-supported: shared failure domains, rare events and nonrepresentative traffic can invalidate canary conclusions.

**Transferability.** Assessment: CONDITIONAL; Reason: Isolation, representativeness, measurement sensitivity and authority to halt must exist. What consequential failure would remain invisible or affect the control as well?

**Source IDs:** ESME-S051, ESME-S062. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What consequential failure would remain invisible or affect the control as well?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-044 — Effect-aware recovery and forward repair

**Disposition and kind.** STRONGLY_RETAINED; OPERATIVE_RECOVERY_MECHANISM

**Mature form.** Recovery is relative to effects and conditions, with forward repair a legitimate branch.

**Controlled failure.** Source-supported: GitLab backups failed through tooling/observation defects; F1 compatibility has restrictive transition assumptions.

**Operating mechanism.** Before consequential change, identify recoverable effects and demonstrate the relevant restore, compensation, containment or forward-repair path; revisit after new irreversible effects.

**Trigger.** A failed intervention could damage persistent data, external state or continuity beyond code text.

**Non-trigger and cheap path.** For an isolated reversible file edit, a verified prior file may suffice; richer recovery is unnecessary when no external effect exists.

**Prerequisites.** Conditions: Recovery artefacts are usable, required tools match, and accepted loss/time bounds are explicit.; Related property ids: ESME-004; ESME-050; ESME-051; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Operator and affected data/service consumers.; Decision: The stated recovery outcome is achievable for the relevant state, or irreversibility is explicitly accepted with a viable alternative.

**Authority and practical action.** Actors: Operator and affected data/service consumers.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The stated recovery outcome is achievable for the relevant state, or irreversibility is explicitly accepted with a viable alternative. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S049; ESME-S062; Adjudication: Source-supported: GitLab backups failed through tooling/observation defects; F1 compatibility has restrictive transition assumptions.; Effect on disposition: Recovery is relative to effects and conditions, with forward repair a legitimate branch.

**Anti-ceremony boundary.** Essential: The stated recovery outcome is achievable for the relevant state, or irreversibility is explicitly accepted with a viable alternative.; Minimal alternative: For an isolated reversible file edit, a verified prior file may suffice; richer recovery is unnecessary when no external effect exists.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** For an isolated reversible file edit, a verified prior file may suffice; richer recovery is unnecessary when no external effect exists. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T05; Discriminator: Identify the loss-bearing observation and whether the chosen method can actually detect it before unacceptable exposure.; Hybrid failure: Early green results become unspoken permission to omit the only test for a live obligation.

**Composition coupling.** ESME-R013; ESME-R015; ESME-R022; ESME-R029; ESME-R032; ESME-R043

#### Domain profile

**Change intent and change class.** A failed intervention could damage persistent data, external state or continuity beyond code text. Separate the newly intended effect from independent obligations intended to survive a release.

**Baseline and affected artefacts.** Code, data, schema, external actions, backup/restore tooling and effect history. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.

**Preservation obligation and observer.** Operator and affected data/service consumers. An oracle is a source of expected behaviour with assumptions, not the fact that a test happened to pass.

**Impact boundary and dependency evidence.** Test selection and release sampling cover declared dependency/traffic boundaries; shared state can defeat assumed isolation.

**Comprehension assumptions.** Recovery artefacts are usable, required tools match, and accepted loss/time bounds are explicit. Maintainers must know test and environment omissions, while operators must understand release and recovery conditions.

**Oracle and regression limits.** Tests can encode old faults, miss rare behaviour or use broken harnesses; independent evidence must address consequential omissions.

**Compatibility and migration preconditions.** Mixed versions and schema transitions require accepted intermediate states, not just endpoint compatibility.

**Release rollback or forward repair condition.** Specify whether recovery means code reversion, data restoration, compensation, containment or forward repair, with evidence of feasibility.

**Maintainer and downstream consumers.** Developers, release operators and downstream users exchange version identity, acceptance evidence, exposure decisions and incident observations.

**Lifecycle cost and retirement condition.** For an isolated reversible file edit, a verified prior file may suffice; richer recovery is unnecessary when no external effect exists. Testing and rollout costs must be proportional to loss exposure; remove redundant checks, not the last evidence for a live obligation.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S049.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S051; ESME-S062; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S049; ESME-S062; Reason: Source-supported: GitLab backups failed through tooling/observation defects; F1 compatibility has restrictive transition assumptions.

**Transferability.** Assessment: CONDITIONAL; Reason: Recovery artefacts are usable, required tools match, and accepted loss/time bounds are explicit. After this step, what state or external effect cannot be returned merely by reverting code?

**Source IDs:** ESME-S041, ESME-S049, ESME-S051, ESME-S062. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. After this step, what state or external effect cannot be returned merely by reverting code?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-045 — Bounded local repair as an alternative to restructuring

**Disposition and kind.** CONTEXT_DEPENDENT; INTERVENTION_BRANCH

**Mature form.** Local repair remains an explicit competitor, with an escalation trigger for recurring or widening costs.

**Controlled failure.** Analytical, grounded in alternative maintenance forms: repeated patches can accumulate coupling and conceal a larger architectural issue.

**Operating mechanism.** Choose a small repair when it satisfies the obligation at lower expected total cost and risk than structural transformation.

**Trigger.** A local fault has a justified impact boundary and no demonstrated need for broad redesign.

**Non-trigger and cheap path.** No change is cheaper where the reported behaviour is acceptable; a focused correction is cheaper than modernisation when adequate.

**Prerequisites.** Conditions: Locality is justified and the patch does not merely defer a spreading failure.; Related property ids: ESME-001; ESME-021; ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: User needing restoration and maintainer bearing repair risk.; Decision: The fault is corrected and preserved obligations are evidenced within the stated boundary.

**Authority and practical action.** Actors: User needing restoration and maintainer bearing repair risk.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The fault is corrected and preserved obligations are evidenced within the stated boundary. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S023; ESME-S058; Adjudication: Analytical, grounded in alternative maintenance forms: repeated patches can accumulate coupling and conceal a larger architectural issue.; Effect on disposition: Local repair remains an explicit competitor, with an escalation trigger for recurring or widening costs.

**Anti-ceremony boundary.** Essential: The fault is corrected and preserved obligations are evidenced within the stated boundary.; Minimal alternative: No change is cheaper where the reported behaviour is acceptable; a focused correction is cheaper than modernisation when adequate.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** No change is cheaper where the reported behaviour is acceptable; a focused correction is cheaper than modernisation when adequate. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T03; Discriminator: Compare feasible obligations, seam/data constraints and prospective costs including the exit, not sunk effort.; Hybrid failure: Permanent adapters and dual data authorities add migration cost without eliminating legacy cost.

**Composition coupling.** ESME-R010; ESME-R011

#### Domain profile

**Change intent and change class.** A local fault has a justified impact boundary and no demonstrated need for broad redesign. Choose among continued maintenance, local repair, wrapping, rehosting, replatforming, restructuring, incremental/atomic replacement and retirement.

**Baseline and affected artefacts.** Fault location, affected behaviour and support horizon. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.

**Preservation obligation and observer.** User needing restoration and maintainer bearing repair risk. Migration invariants specify what users, data consumers and operators must continue to observe and what may deliberately change.

**Impact boundary and dependency evidence.** Identify cutover seams, dual writes, external consumers and transitions where old/new states cannot be kept equivalent.

**Comprehension assumptions.** Locality is justified and the patch does not merely defer a spreading failure. Undocumented domain knowledge and imperfect data semantics can dominate migration difficulty.

**Oracle and regression limits.** Endpoint tests do not establish intermediate-state integrity; reconciliation and failed-observation paths are necessary.

**Compatibility and migration preconditions.** Coexistence requires a supported version/state protocol and an account of which representation is authoritative.

**Release rollback or forward repair condition.** Locate irreversible conversion or external-effect steps; distinguish true reversal from loss-tolerant restore and forward reconciliation.

**Maintainer and downstream consumers.** Legacy experts, successor maintainers, operators and affected customers must coordinate cutover and accepted losses.

**Lifecycle cost and retirement condition.** No change is cheaper where the reported behaviour is acceptable; a focused correction is cheaper than modernisation when adequate. Include temporary duplication, conversion and exit costs; keep old service only while justified and actually close retired paths.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S001.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S023; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S013; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S023; ESME-S058; Reason: Analytical, grounded in alternative maintenance forms: repeated patches can accumulate coupling and conceal a larger architectural issue.

**Transferability.** Assessment: CONDITIONAL; Reason: Locality is justified and the patch does not merely defer a spreading failure. What evidence makes the problem local rather than the visible symptom of a broader defect?

**Source IDs:** ESME-S001, ESME-S013, ESME-S041, ESME-S023, ESME-S058. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What evidence makes the problem local rather than the visible symptom of a broader defect?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-046 — Legacy value distinguished from technical age

**Disposition and kind.** STRONGLY_RETAINED; SELECTION_CRITERION

**Mature form.** Retain value-based stewardship while recognising real environment/support constraints.

**Controlled failure.** Source-supported: migration literature emphasises lost domain knowledge and transition difficulty; technical support may nevertheless genuinely expire.

**Operating mechanism.** Assess obligations, supportability and change cost directly; treat age as a possible clue, not proof that replacement is needed.

**Trigger.** A system is labelled legacy or obsolete as grounds for investment.

**Non-trigger and cheap path.** Continue operation with existing support when useful and adequately maintainable.

**Prerequisites.** Conditions: Relevant benefits and risks are identified independently of age.; Related property ids: ESME-007; ESME-058; ESME-074; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Current users and maintainers, not a technology-fashion ranking.; Decision: A continue/change/retire decision is supported by actual value and risk rather than age alone.

**Authority and practical action.** Actors: Current users and maintainers, not a technology-fashion ranking.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** A continue/change/retire decision is supported by actual value and risk rather than age alone. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S029; ESME-S058; Adjudication: Source-supported: migration literature emphasises lost domain knowledge and transition difficulty; technical support may nevertheless genuinely expire.; Effect on disposition: Retain value-based stewardship while recognising real environment/support constraints.

**Anti-ceremony boundary.** Essential: A continue/change/retire decision is supported by actual value and risk rather than age alone.; Minimal alternative: Continue operation with existing support when useful and adequately maintainable.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Continue operation with existing support when useful and adequately maintainable. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T03; Discriminator: Compare feasible obligations, seam/data constraints and prospective costs including the exit, not sunk effort.; Hybrid failure: Permanent adapters and dual data authorities add migration cost without eliminating legacy cost.

**Composition coupling.** ESME-R043

#### Domain profile

**Change intent and change class.** A system is labelled legacy or obsolete as grounds for investment. Choose among continued maintenance, local repair, wrapping, rehosting, replatforming, restructuring, incremental/atomic replacement and retirement.

**Baseline and affected artefacts.** Existing service, domain behaviour, technology dependencies and support capacity. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.

**Preservation obligation and observer.** Current users and maintainers, not a technology-fashion ranking. Migration invariants specify what users, data consumers and operators must continue to observe and what may deliberately change.

**Impact boundary and dependency evidence.** Identify cutover seams, dual writes, external consumers and transitions where old/new states cannot be kept equivalent.

**Comprehension assumptions.** Relevant benefits and risks are identified independently of age. Undocumented domain knowledge and imperfect data semantics can dominate migration difficulty.

**Oracle and regression limits.** Endpoint tests do not establish intermediate-state integrity; reconciliation and failed-observation paths are necessary.

**Compatibility and migration preconditions.** Coexistence requires a supported version/state protocol and an account of which representation is authoritative.

**Release rollback or forward repair condition.** Locate irreversible conversion or external-effect steps; distinguish true reversal from loss-tolerant restore and forward reconciliation.

**Maintainer and downstream consumers.** Legacy experts, successor maintainers, operators and affected customers must coordinate cutover and accepted losses.

**Lifecycle cost and retirement condition.** Continue operation with existing support when useful and adequately maintainable. Include temporary duplication, conversion and exit costs; keep old service only while justified and actually close retired paths.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S013; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S029; ESME-S058; Reason: Source-supported: migration literature emphasises lost domain knowledge and transition difficulty; technical support may nevertheless genuinely expire.

**Transferability.** Assessment: CONDITIONAL; Reason: Relevant benefits and risks are identified independently of age. What risk or blocked capability is being attributed to age, and is that causal link demonstrated?

**Source IDs:** ESME-S013, ESME-S029, ESME-S041, ESME-S058. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What risk or blocked capability is being attributed to age, and is that causal link demonstrated?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-047 — Explicit comparison of modernisation alternatives

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; DECISION_PROCEDURE

**Mature form.** Conditional alternative selection, not a ladder from old language to mature new platform.

**Controlled failure.** Source-supported: successful migration descriptions are selected and rarely establish comparative dominance.

**Operating mechanism.** Compare feasible interventions by preserved obligations, domain recovery, data conversion, support horizon and transition cost; do not collapse all modernisation into rewriting.

**Trigger.** Current maintenance no longer meets justified needs or costs warrant reconsideration.

**Non-trigger and cheap path.** Compare only credible alternatives; a short repair-versus-replace decision can suffice.

**Prerequisites.** Conditions: Alternatives have sufficiently understood constraints; labels alone do not specify technical feasibility.; Related property ids: ESME-045; ESME-046; ESME-048; ESME-049; ESME-058; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Owner of the capability, maintainers, operators and affected consumers.; Decision: The chosen branch has a defensible advantage over feasible no-change, repair or migration alternatives.

**Authority and practical action.** Actors: Owner of the capability, maintainers, operators and affected consumers.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The chosen branch has a defensible advantage over feasible no-change, repair or migration alternatives. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S029; ESME-S058; Adjudication: Source-supported: successful migration descriptions are selected and rarely establish comparative dominance.; Effect on disposition: Conditional alternative selection, not a ladder from old language to mature new platform.

**Anti-ceremony boundary.** Essential: The chosen branch has a defensible advantage over feasible no-change, repair or migration alternatives.; Minimal alternative: Compare only credible alternatives; a short repair-versus-replace decision can suffice.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Compare only credible alternatives; a short repair-versus-replace decision can suffice. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T03; Discriminator: Compare feasible obligations, seam/data constraints and prospective costs including the exit, not sunk effort.; Hybrid failure: Permanent adapters and dual data authorities add migration cost without eliminating legacy cost.

**Composition coupling.** ESME-R010; ESME-R043; ESME-R047

#### Domain profile

**Change intent and change class.** Current maintenance no longer meets justified needs or costs warrant reconsideration. Choose among continued maintenance, local repair, wrapping, rehosting, replatforming, restructuring, incremental/atomic replacement and retirement.

**Baseline and affected artefacts.** Existing capability, candidate host/platform/implementation and transition obligations. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.

**Preservation obligation and observer.** Owner of the capability, maintainers, operators and affected consumers. Migration invariants specify what users, data consumers and operators must continue to observe and what may deliberately change.

**Impact boundary and dependency evidence.** Identify cutover seams, dual writes, external consumers and transitions where old/new states cannot be kept equivalent.

**Comprehension assumptions.** Alternatives have sufficiently understood constraints; labels alone do not specify technical feasibility. Undocumented domain knowledge and imperfect data semantics can dominate migration difficulty.

**Oracle and regression limits.** Endpoint tests do not establish intermediate-state integrity; reconciliation and failed-observation paths are necessary.

**Compatibility and migration preconditions.** Coexistence requires a supported version/state protocol and an account of which representation is authoritative.

**Release rollback or forward repair condition.** Locate irreversible conversion or external-effect steps; distinguish true reversal from loss-tolerant restore and forward reconciliation.

**Maintainer and downstream consumers.** Legacy experts, successor maintainers, operators and affected customers must coordinate cutover and accepted losses.

**Lifecycle cost and retirement condition.** Compare only credible alternatives; a short repair-versus-replace decision can suffice. Include temporary duplication, conversion and exit costs; keep old service only while justified and actually close retired paths.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S013; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S029; ESME-S058; Reason: Source-supported: successful migration descriptions are selected and rarely establish comparative dominance.

**Transferability.** Assessment: CONDITIONAL; Reason: Alternatives have sufficiently understood constraints; labels alone do not specify technical feasibility. Which simpler alternative was excluded, and on what evidence?

**Source IDs:** ESME-S013, ESME-S029, ESME-S031, ESME-S055, ESME-S058. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which simpler alternative was excluded, and on what evidence?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-048 — Incremental substitution through valid migration seams

**Disposition and kind.** CONTEXT_DEPENDENT; MIGRATION_BRANCH

**Mature form.** Incremental migration is conditional on valid seams and closure, not universally preferable.

**Controlled failure.** Source-supported: gateways and dual operation can cause consistency problems; early strangler account is not a comparative completed-success trial.

**Operating mechanism.** Identify a separable responsibility and route or transfer it under a tested coexistence protocol, with a funded exit for temporary integration.

**Trigger.** Useful seams permit partial replacement and intermediate states preserve required service/data semantics.

**Non-trigger and cheap path.** A small system may be cheaper to replace atomically; no migration when existing service remains adequate.

**Prerequisites.** Conditions: Separation, reconciled data ownership and transitional compatibility must be feasible.; Related property ids: ESME-025; ESME-050; ESME-051; ESME-052; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Consumers crossing the seam and operators controlling cutover.; Decision: A slice of responsibility is actually transferred and temporary coexistence remains controlled.

**Authority and practical action.** Actors: Consumers crossing the seam and operators controlling cutover.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** A slice of responsibility is actually transferred and temporary coexistence remains controlled. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S029; ESME-S051; Adjudication: Source-supported: gateways and dual operation can cause consistency problems; early strangler account is not a comparative completed-success trial.; Effect on disposition: Incremental migration is conditional on valid seams and closure, not universally preferable.

**Anti-ceremony boundary.** Essential: A slice of responsibility is actually transferred and temporary coexistence remains controlled.; Minimal alternative: A small system may be cheaper to replace atomically; no migration when existing service remains adequate.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A small system may be cheaper to replace atomically; no migration when existing service remains adequate. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T03; Discriminator: Compare feasible obligations, seam/data constraints and prospective costs including the exit, not sunk effort.; Hybrid failure: Permanent adapters and dual data authorities add migration cost without eliminating legacy cost.

**Composition coupling.** ESME-R011; ESME-R012; ESME-R013; ESME-R014; ESME-R016; ESME-R043

#### Domain profile

**Change intent and change class.** Useful seams permit partial replacement and intermediate states preserve required service/data semantics. Choose among continued maintenance, local repair, wrapping, rehosting, replatforming, restructuring, incremental/atomic replacement and retirement.

**Baseline and affected artefacts.** Legacy/successor components, seam, routing, shared data and temporary adapters. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.

**Preservation obligation and observer.** Consumers crossing the seam and operators controlling cutover. Migration invariants specify what users, data consumers and operators must continue to observe and what may deliberately change.

**Impact boundary and dependency evidence.** Identify cutover seams, dual writes, external consumers and transitions where old/new states cannot be kept equivalent.

**Comprehension assumptions.** Separation, reconciled data ownership and transitional compatibility must be feasible. Undocumented domain knowledge and imperfect data semantics can dominate migration difficulty.

**Oracle and regression limits.** Endpoint tests do not establish intermediate-state integrity; reconciliation and failed-observation paths are necessary.

**Compatibility and migration preconditions.** Coexistence requires a supported version/state protocol and an account of which representation is authoritative.

**Release rollback or forward repair condition.** Locate irreversible conversion or external-effect steps; distinguish true reversal from loss-tolerant restore and forward reconciliation.

**Maintainer and downstream consumers.** Legacy experts, successor maintainers, operators and affected customers must coordinate cutover and accepted losses.

**Lifecycle cost and retirement condition.** A small system may be cheaper to replace atomically; no migration when existing service remains adequate. Include temporary duplication, conversion and exit costs; keep old service only while justified and actually close retired paths.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S030; ESME-S051; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S029; ESME-S051; Reason: Source-supported: gateways and dual operation can cause consistency problems; early strangler account is not a comparative completed-success trial.

**Transferability.** Assessment: CONDITIONAL; Reason: Separation, reconciled data ownership and transitional compatibility must be feasible. Does the proposed seam separate responsibility or merely create two inconsistent authorities?

**Source IDs:** ESME-S029, ESME-S030, ESME-S031, ESME-S051. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Does the proposed seam separate responsibility or merely create two inconsistent authorities?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-049 — Atomic replacement where coexistence is the greater risk

**Disposition and kind.** CONTEXT_DEPENDENT; MIGRATION_ALTERNATIVE

**Mature form.** Retain as an alternative, not disfavoured merely because incremental patterns are popular.

**Controlled failure.** Analytical comparison grounded in migration criticism: concentrated loss and forgotten requirements may dominate any simplicity benefit.

**Operating mechanism.** Choose a single transition only when rehearsal, downtime/loss acceptance and state conversion evidence make it preferable to unsupported coexistence.

**Trigger.** The system is small or separability is poor, downtime is acceptable, or dual operation creates intolerable inconsistency.

**Non-trigger and cheap path.** Prefer bounded repair or incremental transfer where they meet obligations with less risk.

**Prerequisites.** Conditions: Validated conversion, feasible operating window and explicit recovery/forward limits.; Related property ids: ESME-047; ESME-050; ESME-044; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Users accepting the transition and operators performing it.; Decision: The cutover is authorised against endpoint and conversion evidence, not just successor tests.

**Authority and practical action.** Actors: Users accepting the transition and operators performing it.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The cutover is authorised against endpoint and conversion evidence, not just successor tests. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S029; ESME-S031; Adjudication: Analytical comparison grounded in migration criticism: concentrated loss and forgotten requirements may dominate any simplicity benefit.; Effect on disposition: Retain as an alternative, not disfavoured merely because incremental patterns are popular.

**Anti-ceremony boundary.** Essential: The cutover is authorised against endpoint and conversion evidence, not just successor tests.; Minimal alternative: Prefer bounded repair or incremental transfer where they meet obligations with less risk.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Prefer bounded repair or incremental transfer where they meet obligations with less risk. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T03; Discriminator: Compare feasible obligations, seam/data constraints and prospective costs including the exit, not sunk effort.; Hybrid failure: Permanent adapters and dual data authorities add migration cost without eliminating legacy cost.

**Composition coupling.** ESME-R011; ESME-R012; ESME-R013; ESME-R043

#### Domain profile

**Change intent and change class.** The system is small or separability is poor, downtime is acceptable, or dual operation creates intolerable inconsistency. Choose among continued maintenance, local repair, wrapping, rehosting, replatforming, restructuring, incremental/atomic replacement and retirement.

**Baseline and affected artefacts.** Complete successor, cutover state, consumers and recovery resources. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.

**Preservation obligation and observer.** Users accepting the transition and operators performing it. Migration invariants specify what users, data consumers and operators must continue to observe and what may deliberately change.

**Impact boundary and dependency evidence.** Identify cutover seams, dual writes, external consumers and transitions where old/new states cannot be kept equivalent.

**Comprehension assumptions.** Validated conversion, feasible operating window and explicit recovery/forward limits. Undocumented domain knowledge and imperfect data semantics can dominate migration difficulty.

**Oracle and regression limits.** Endpoint tests do not establish intermediate-state integrity; reconciliation and failed-observation paths are necessary.

**Compatibility and migration preconditions.** Coexistence requires a supported version/state protocol and an account of which representation is authoritative.

**Release rollback or forward repair condition.** Locate irreversible conversion or external-effect steps; distinguish true reversal from loss-tolerant restore and forward reconciliation.

**Maintainer and downstream consumers.** Legacy experts, successor maintainers, operators and affected customers must coordinate cutover and accepted losses.

**Lifecycle cost and retirement condition.** Prefer bounded repair or incremental transfer where they meet obligations with less risk. Include temporary duplication, conversion and exit costs; keep old service only while justified and actually close retired paths.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S029; ESME-S031; Reason: Analytical comparison grounded in migration criticism: concentrated loss and forgotten requirements may dominate any simplicity benefit.

**Transferability.** Assessment: CONDITIONAL; Reason: Validated conversion, feasible operating window and explicit recovery/forward limits. What makes a dual-running intermediate state less safe than a rehearsed single transition?

**Source IDs:** ESME-S029, ESME-S041, ESME-S055, ESME-S031. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What makes a dual-running intermediate state less safe than a rehearsed single transition?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-050 — Data-conversion invariants and reconciliation

**Disposition and kind.** STRONGLY_RETAINED; MIGRATION_VALIDATION_MECHANISM

**Mature form.** Validation covers meanings and intermediate states, not only row counts or successful scripts.

**Controlled failure.** Source-supported: heterogeneous dual updates remain difficult; a backup’s existence does not establish usable restoration.

**Operating mechanism.** Specify the semantic invariants of conversion, identify the authoritative state during transition, and reconcile records/effects with explicit loss and uncertainty handling.

**Trigger.** Schema, encoding, representation or ownership changes can alter persisted meaning.

**Non-trigger and cheap path.** For stateless replacement this is not triggered; a simple verified bijective conversion may need only direct checks.

**Prerequisites.** Conditions: Mappings and concurrency rules must preserve or deliberately revise the required semantics.; Related property ids: ESME-001; ESME-025; ESME-044; ESME-051; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Consumers relying on meanings such as identity, balances, ordering or provenance.; Decision: Reconciled state satisfies declared invariants; unmatched or irreversible changes are explicitly resolved or accepted.

**Authority and practical action.** Actors: Consumers relying on meanings such as identity, balances, ordering or provenance.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Reconciled state satisfies declared invariants; unmatched or irreversible changes are explicitly resolved or accepted. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S029; ESME-S062; Adjudication: Source-supported: heterogeneous dual updates remain difficult; a backup’s existence does not establish usable restoration.; Effect on disposition: Validation covers meanings and intermediate states, not only row counts or successful scripts.

**Anti-ceremony boundary.** Essential: Reconciled state satisfies declared invariants; unmatched or irreversible changes are explicitly resolved or accepted.; Minimal alternative: For stateless replacement this is not triggered; a simple verified bijective conversion may need only direct checks.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** For stateless replacement this is not triggered; a simple verified bijective conversion may need only direct checks. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R013; ESME-R015; ESME-R016; ESME-R032

#### Domain profile

**Change intent and change class.** Schema, encoding, representation or ownership changes can alter persisted meaning. Choose among continued maintenance, local repair, wrapping, rehosting, replatforming, restructuring, incremental/atomic replacement and retirement.

**Baseline and affected artefacts.** Old/new data, mapping rules, transaction history and reconciliation evidence. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.

**Preservation obligation and observer.** Consumers relying on meanings such as identity, balances, ordering or provenance. Migration invariants specify what users, data consumers and operators must continue to observe and what may deliberately change.

**Impact boundary and dependency evidence.** Identify cutover seams, dual writes, external consumers and transitions where old/new states cannot be kept equivalent.

**Comprehension assumptions.** Mappings and concurrency rules must preserve or deliberately revise the required semantics. Undocumented domain knowledge and imperfect data semantics can dominate migration difficulty.

**Oracle and regression limits.** Endpoint tests do not establish intermediate-state integrity; reconciliation and failed-observation paths are necessary.

**Compatibility and migration preconditions.** Coexistence requires a supported version/state protocol and an account of which representation is authoritative.

**Release rollback or forward repair condition.** Locate irreversible conversion or external-effect steps; distinguish true reversal from loss-tolerant restore and forward reconciliation.

**Maintainer and downstream consumers.** Legacy experts, successor maintainers, operators and affected customers must coordinate cutover and accepted losses.

**Lifecycle cost and retirement condition.** For stateless replacement this is not triggered; a simple verified bijective conversion may need only direct checks. Include temporary duplication, conversion and exit costs; keep old service only while justified and actually close retired paths.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S049.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S062; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S029; ESME-S062; Reason: Source-supported: heterogeneous dual updates remain difficult; a backup’s existence does not establish usable restoration.

**Transferability.** Assessment: CONDITIONAL; Reason: Mappings and concurrency rules must preserve or deliberately revise the required semantics. Which semantic distinction is lost by conversion even when every row is transferred?

**Source IDs:** ESME-S029, ESME-S049, ESME-S062. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which semantic distinction is lost by conversion even when every row is transferred?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-051 — Compatibility of intermediate and mixed-version states

**Disposition and kind.** ASSUMPTION_SENSITIVE; TRANSITION_CONSTRAINT

**Mature form.** Treat coexistence compatibility as its own obligation rather than endpoint regression.

**Controlled failure.** Source-supported: F1 abstract guarantee is restricted; full protocol proof was inaccessible, so no general transfer guarantee is made.

**Operating mechanism.** Enumerate the supported intermediate combinations and constrain activation order or feature use until each combination’s obligations hold.

**Trigger.** Rolling upgrades, data conversion or partial migration create old/new participants at the same time.

**Non-trigger and cheap path.** Use an atomic stop-and-switch when mixed versions offer no justified advantage and downtime is acceptable.

**Prerequisites.** Conditions: Version-skew bounds, ordering and data semantics are actually enforced.; Related property ids: ESME-025; ESME-043; ESME-044; ESME-050; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Old and new consumers interacting concurrently.; Decision: Only validated version/state combinations are active; unsupported skew triggers containment or a different route.

**Authority and practical action.** Actors: Old and new consumers interacting concurrently.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Only validated version/state combinations are active; unsupported skew triggers containment or a different route. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S049; ESME-S062; Adjudication: Source-supported: F1 abstract guarantee is restricted; full protocol proof was inaccessible, so no general transfer guarantee is made.; Effect on disposition: Treat coexistence compatibility as its own obligation rather than endpoint regression.

**Anti-ceremony boundary.** Essential: Only validated version/state combinations are active; unsupported skew triggers containment or a different route.; Minimal alternative: Use an atomic stop-and-switch when mixed versions offer no justified advantage and downtime is acceptable.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Use an atomic stop-and-switch when mixed versions offer no justified advantage and downtime is acceptable. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T07; Discriminator: Determine real promises, capacity and transition feasibility; usage popularity is neither permission nor an infinite support contract.; Hybrid failure: Dates are announced without a viable path, or compatibility branches multiply beyond capacity.

**Composition coupling.** ESME-R014; ESME-R015; ESME-R016; ESME-R031; ESME-R032

#### Domain profile

**Change intent and change class.** Rolling upgrades, data conversion or partial migration create old/new participants at the same time. Choose among continued maintenance, local repair, wrapping, rehosting, replatforming, restructuring, incremental/atomic replacement and retirement.

**Baseline and affected artefacts.** Versions of readers/writers, schema, protocol, configuration and shared state. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.

**Preservation obligation and observer.** Old and new consumers interacting concurrently. Migration invariants specify what users, data consumers and operators must continue to observe and what may deliberately change.

**Impact boundary and dependency evidence.** Identify cutover seams, dual writes, external consumers and transitions where old/new states cannot be kept equivalent.

**Comprehension assumptions.** Version-skew bounds, ordering and data semantics are actually enforced. Undocumented domain knowledge and imperfect data semantics can dominate migration difficulty.

**Oracle and regression limits.** Endpoint tests do not establish intermediate-state integrity; reconciliation and failed-observation paths are necessary.

**Compatibility and migration preconditions.** Coexistence requires a supported version/state protocol and an account of which representation is authoritative.

**Release rollback or forward repair condition.** Locate irreversible conversion or external-effect steps; distinguish true reversal from loss-tolerant restore and forward reconciliation.

**Maintainer and downstream consumers.** Legacy experts, successor maintainers, operators and affected customers must coordinate cutover and accepted losses.

**Lifecycle cost and retirement condition.** Use an atomic stop-and-switch when mixed versions offer no justified advantage and downtime is acceptable. Include temporary duplication, conversion and exit costs; keep old service only while justified and actually close retired paths.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S049.

**Theory.** Assessment: MODEL_BOUND; Reason: FORMAL_SCOPE_BOUND: source-supported model/guarantee and assumptions recorded in source table; no independent re-proof or unbounded deployment guarantee.

**Comparative evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S051; ESME-S062; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S049; ESME-S062; Reason: Source-supported: F1 abstract guarantee is restricted; full protocol proof was inaccessible, so no general transfer guarantee is made.

**Transferability.** Assessment: CONDITIONAL; Reason: Version-skew bounds, ordering and data semantics are actually enforced. Which intermediate reader/writer combination is neither covered by old nor new endpoint tests?

**Source IDs:** ESME-S049, ESME-S051, ESME-S067, ESME-S062. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which intermediate reader/writer combination is neither covered by old nor new endpoint tests?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-052 — Coexistence budget and explicit exit

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; TRANSITION_TERMINATION_MECHANISM

**Mature form.** Require an exit decision and its evidence, not a mandatory deadline detached from obligations.

**Controlled failure.** Analytical, grounded in migration costs: premature removal can strand consumers; indefinitely retained bridges can erase expected benefit.

**Operating mechanism.** Fund and track the temporary support burden, define responsibility-transfer criteria and remove obsolete paths once agreed obligations are discharged.

**Trigger.** Old and new implementations or data representations operate simultaneously during migration.

**Non-trigger and cheap path.** Avoid coexistence entirely where a local repair or simple cutover is adequate.

**Prerequisites.** Conditions: Authority to retire old paths and evidence that residual consumers/data obligations are resolved.; Related property ids: ESME-048; ESME-050; ESME-051; ESME-071; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Operators, legacy/successor maintainers and consumers yet to migrate.; Decision: A completed migration has observable old-path closure or a newly authorised reason to retain it.

**Authority and practical action.** Actors: Operators, legacy/successor maintainers and consumers yet to migrate.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** A completed migration has observable old-path closure or a newly authorised reason to retain it. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S029; Adjudication: Analytical, grounded in migration costs: premature removal can strand consumers; indefinitely retained bridges can erase expected benefit.; Effect on disposition: Require an exit decision and its evidence, not a mandatory deadline detached from obligations.

**Anti-ceremony boundary.** Essential: A completed migration has observable old-path closure or a newly authorised reason to retain it.; Minimal alternative: Avoid coexistence entirely where a local repair or simple cutover is adequate.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Avoid coexistence entirely where a local repair or simple cutover is adequate. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T03; Discriminator: Compare feasible obligations, seam/data constraints and prospective costs including the exit, not sunk effort.; Hybrid failure: Permanent adapters and dual data authorities add migration cost without eliminating legacy cost.

**Composition coupling.** ESME-R016; ESME-R017; ESME-R033

#### Domain profile

**Change intent and change class.** Old and new implementations or data representations operate simultaneously during migration. Choose among continued maintenance, local repair, wrapping, rehosting, replatforming, restructuring, incremental/atomic replacement and retirement.

**Baseline and affected artefacts.** Temporary routes, duplicate systems, data synchronisation and support obligations. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.

**Preservation obligation and observer.** Operators, legacy/successor maintainers and consumers yet to migrate. Migration invariants specify what users, data consumers and operators must continue to observe and what may deliberately change.

**Impact boundary and dependency evidence.** Identify cutover seams, dual writes, external consumers and transitions where old/new states cannot be kept equivalent.

**Comprehension assumptions.** Authority to retire old paths and evidence that residual consumers/data obligations are resolved. Undocumented domain knowledge and imperfect data semantics can dominate migration difficulty.

**Oracle and regression limits.** Endpoint tests do not establish intermediate-state integrity; reconciliation and failed-observation paths are necessary.

**Compatibility and migration preconditions.** Coexistence requires a supported version/state protocol and an account of which representation is authoritative.

**Release rollback or forward repair condition.** Locate irreversible conversion or external-effect steps; distinguish true reversal from loss-tolerant restore and forward reconciliation.

**Maintainer and downstream consumers.** Legacy experts, successor maintainers, operators and affected customers must coordinate cutover and accepted losses.

**Lifecycle cost and retirement condition.** Avoid coexistence entirely where a local repair or simple cutover is adequate. Include temporary duplication, conversion and exit costs; keep old service only while justified and actually close retired paths.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S013; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S029; Reason: Analytical, grounded in migration costs: premature removal can strand consumers; indefinitely retained bridges can erase expected benefit.

**Transferability.** Assessment: CONDITIONAL; Reason: Authority to retire old paths and evidence that residual consumers/data obligations are resolved. What precisely would permit removal of the last legacy path, and who can establish it?

**Source IDs:** ESME-S013, ESME-S029, ESME-S031, ESME-S055. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What precisely would permit removal of the last legacy path, and who can establish it?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-056 — Technical debt as a contingent future-change liability

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; ECONOMIC_CONCEPT

**Mature form.** A contingent liability, not a universal financial balance-sheet quantity.

**Controlled failure.** Source-supported: current debt manifesto rejects calling all issues debt and recognises context-dependent interest.

**Operating mechanism.** Identify a concrete design/implementation condition and the future work that makes its liability actual; distinguish defects, missing features and ordinary maintenance.

**Trigger.** A structural choice plausibly increases future change cost or blocks justified evolution.

**Non-trigger and cheap path.** Do not create debt items for disliked code with no relevant future-cost mechanism.

**Prerequisites.** Conditions: The future-change scenario and comparison to an alternative are intelligible.; Related property ids: ESME-031; ESME-058; ESME-059; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Future maintainers and value/cost decision makers.; Decision: An item states how and when it imposes additional cost; disappearance of that scenario can retire the item.

**Authority and practical action.** Actors: Future maintainers and value/cost decision makers.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** An item states how and when it imposes additional cost; disappearance of that scenario can retire the item. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S023; ESME-S058; Adjudication: Source-supported: current debt manifesto rejects calling all issues debt and recognises context-dependent interest.; Effect on disposition: A contingent liability, not a universal financial balance-sheet quantity.

**Anti-ceremony boundary.** Essential: An item states how and when it imposes additional cost; disappearance of that scenario can retire the item.; Minimal alternative: Do not create debt items for disliked code with no relevant future-cost mechanism.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Do not create debt items for disliked code with no relevant future-cost mechanism. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T06; Discriminator: State the change-contingent cost mechanism, horizon and uncertainty that could reverse priority.; Hybrid failure: Endless incidental cleanup hides scope expansion; feature urgency becomes a permanent excuse to ignore a known liability.

**Composition coupling.** ESME-R009; ESME-R044

#### Domain profile

**Change intent and change class.** A structural choice plausibly increases future change cost or blocks justified evolution. Define a future-change liability, not every defect, missing feature or disliked structure as technical debt.

**Baseline and affected artefacts.** Debt condition, cause, affected future change and support horizon. A debt item links a concrete design/implementation condition to affected future work and its economic context.

**Preservation obligation and observer.** Future maintainers and value/cost decision makers. The payoff is reduced justified lifecycle cost or enabled value; a changed static metric is merely a proxy.

**Impact boundary and dependency evidence.** Liabilities can be local or architectural; dependencies and changing objectives alter who incurs interest.

**Comprehension assumptions.** The future-change scenario and comparison to an alternative are intelligible. Estimates require domain and maintenance experience; uncertainty about future change demand is irreducible.

**Oracle and regression limits.** Debt scanners and self-reported effort do not establish recoverable causal savings; compare plausible alternatives.

**Compatibility and migration preconditions.** Debt repayment may itself impose incompatible changes; make those migration assumptions explicit.

**Release rollback or forward repair condition.** Economic analysis is non-operative until an intervention is authorised; repayment then needs its own release/recovery evidence.

**Maintainer and downstream consumers.** Technical and business decision makers, maintainers and downstream cost bearers communicate trade-offs without blame.

**Lifecycle cost and retirement condition.** Do not create debt items for disliked code with no relevant future-cost mechanism. Compare repayment, servicing, deferral and retirement; extinguish items when their future-cost mechanism or relevant system disappears.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S023; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S027; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S023; ESME-S058; Reason: Source-supported: current debt manifesto rejects calling all issues debt and recognises context-dependent interest.

**Transferability.** Assessment: CONDITIONAL; Reason: The future-change scenario and comparison to an alternative are intelligible. What future change would incur this debt’s interest, and compared with what alternative?

**Source IDs:** ESME-S027, ESME-S028, ESME-S058, ESME-S023. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What future change would incur this debt’s interest, and compared with what alternative?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-057 — Actionable debt records with a consumer

**Disposition and kind.** USEFUL_BUT_EASILY_BUREAUCRATISED; COMMUNICATION_AND_PRIORITISATION_MECHANISM

**Mature form.** Keep actionable causes and trade-offs, not a compulsory debt-tool workflow.

**Controlled failure.** Source-supported: the 2025 manifesto warns against heavy debt bureaucracy; reported debt effort does not prove register value.

**Operating mechanism.** Record only enough evidence about an important liability, affected work, uncertainty and intended decision for the people prioritising it.

**Trigger.** A significant liability risks being forgotten, misunderstood or shifted across teams.

**Non-trigger and cheap path.** A tracked issue or brief decision note can replace a dedicated register; delete records whose liability has vanished.

**Prerequisites.** Conditions: There is a real decision consumer and estimates are labelled as estimates.; Related property ids: ESME-056; ESME-058; ESME-063; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Maintainer, budget holder and affected downstream cost bearer.; Decision: The record changes or supports a prioritisation decision and is refreshed or retired as context changes.

**Authority and practical action.** Actors: Maintainer, budget holder and affected downstream cost bearer.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The record changes or supports a prioritisation decision and is refreshed or retired as context changes. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S057; ESME-S058; Adjudication: Source-supported: the 2025 manifesto warns against heavy debt bureaucracy; reported debt effort does not prove register value.; Effect on disposition: Keep actionable causes and trade-offs, not a compulsory debt-tool workflow.

**Anti-ceremony boundary.** Essential: The record changes or supports a prioritisation decision and is refreshed or retired as context changes.; Minimal alternative: A tracked issue or brief decision note can replace a dedicated register; delete records whose liability has vanished.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A tracked issue or brief decision note can replace a dedicated register; delete records whose liability has vanished. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T06; Discriminator: State the change-contingent cost mechanism, horizon and uncertainty that could reverse priority.; Hybrid failure: Endless incidental cleanup hides scope expansion; feature urgency becomes a permanent excuse to ignore a known liability.

**Composition coupling.** ESME-R009; ESME-R049

#### Domain profile

**Change intent and change class.** A significant liability risks being forgotten, misunderstood or shifted across teams. Define a future-change liability, not every defect, missing feature or disliked structure as technical debt.

**Baseline and affected artefacts.** Debt item, supporting observations, cost estimates and decision history. A debt item links a concrete design/implementation condition to affected future work and its economic context.

**Preservation obligation and observer.** Maintainer, budget holder and affected downstream cost bearer. The payoff is reduced justified lifecycle cost or enabled value; a changed static metric is merely a proxy.

**Impact boundary and dependency evidence.** Liabilities can be local or architectural; dependencies and changing objectives alter who incurs interest.

**Comprehension assumptions.** There is a real decision consumer and estimates are labelled as estimates. Estimates require domain and maintenance experience; uncertainty about future change demand is irreducible.

**Oracle and regression limits.** Debt scanners and self-reported effort do not establish recoverable causal savings; compare plausible alternatives.

**Compatibility and migration preconditions.** Debt repayment may itself impose incompatible changes; make those migration assumptions explicit.

**Release rollback or forward repair condition.** Economic analysis is non-operative until an intervention is authorised; repayment then needs its own release/recovery evidence.

**Maintainer and downstream consumers.** Technical and business decision makers, maintainers and downstream cost bearers communicate trade-offs without blame.

**Lifecycle cost and retirement condition.** A tracked issue or brief decision note can replace a dedicated register; delete records whose liability has vanished. Compare repayment, servicing, deferral and retirement; extinguish items when their future-cost mechanism or relevant system disappears.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S057; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S057; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S057; ESME-S058; Reason: Source-supported: the 2025 manifesto warns against heavy debt bureaucracy; reported debt effort does not prove register value.

**Transferability.** Assessment: CONDITIONAL; Reason: There is a real decision consumer and estimates are labelled as estimates. Who acts on this record, and what decision would be worse without it?

**Source IDs:** ESME-S028, ESME-S058, ESME-S057. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Who acts on this record, and what decision would be worse without it?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-058 — Lifecycle-cost and value-based prioritisation

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; DECISION_PROCEDURE

**Mature form.** Use scenario-based comparison, not a falsely exact return-on-investment number.

**Controlled failure.** Source-supported: self-reported debt burdens do not identify causal recoverable savings; precise universal debt metrics are unsupported.

**Operating mechanism.** Compare intervention, validation, disruption, future support and opportunity costs under plausible scenarios; retain uncertainty and identify cost bearers.

**Trigger.** Competing repairs, features, structural improvements or retirement choices draw on limited resources.

**Non-trigger and cheap path.** A qualitative ordered comparison is sufficient when numerical estimates would be fictitious.

**Prerequisites.** Conditions: Alternatives and relevant time horizon are explicit; sunk cost is not treated as prospective benefit.; Related property ids: ESME-001; ESME-031; ESME-047; ESME-056; ESME-060; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Stakeholders allocating effort and those who bear downstream costs.; Decision: A priority decision explains trade-offs, uncertainty and the evidence that could reverse it.

**Authority and practical action.** Actors: Stakeholders allocating effort and those who bear downstream costs.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** A priority decision explains trade-offs, uncertainty and the evidence that could reverse it. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S023; ESME-S057; ESME-S058; Adjudication: Source-supported: self-reported debt burdens do not identify causal recoverable savings; precise universal debt metrics are unsupported.; Effect on disposition: Use scenario-based comparison, not a falsely exact return-on-investment number.

**Anti-ceremony boundary.** Essential: A priority decision explains trade-offs, uncertainty and the evidence that could reverse it.; Minimal alternative: A qualitative ordered comparison is sufficient when numerical estimates would be fictitious.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A qualitative ordered comparison is sufficient when numerical estimates would be fictitious. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T06; Discriminator: State the change-contingent cost mechanism, horizon and uncertainty that could reverse priority.; Hybrid failure: Endless incidental cleanup hides scope expansion; feature urgency becomes a permanent excuse to ignore a known liability.

**Composition coupling.** ESME-R003; ESME-R009; ESME-R010; ESME-R022; ESME-R034; ESME-R044; ESME-R048

#### Domain profile

**Change intent and change class.** Competing repairs, features, structural improvements or retirement choices draw on limited resources. Define a future-change liability, not every defect, missing feature or disliked structure as technical debt.

**Baseline and affected artefacts.** Maintenance options, benefits, cost horizon and uncertainty. A debt item links a concrete design/implementation condition to affected future work and its economic context.

**Preservation obligation and observer.** Stakeholders allocating effort and those who bear downstream costs. The payoff is reduced justified lifecycle cost or enabled value; a changed static metric is merely a proxy.

**Impact boundary and dependency evidence.** Liabilities can be local or architectural; dependencies and changing objectives alter who incurs interest.

**Comprehension assumptions.** Alternatives and relevant time horizon are explicit; sunk cost is not treated as prospective benefit. Estimates require domain and maintenance experience; uncertainty about future change demand is irreducible.

**Oracle and regression limits.** Debt scanners and self-reported effort do not establish recoverable causal savings; compare plausible alternatives.

**Compatibility and migration preconditions.** Debt repayment may itself impose incompatible changes; make those migration assumptions explicit.

**Release rollback or forward repair condition.** Economic analysis is non-operative until an intervention is authorised; repayment then needs its own release/recovery evidence.

**Maintainer and downstream consumers.** Technical and business decision makers, maintainers and downstream cost bearers communicate trade-offs without blame.

**Lifecycle cost and retirement condition.** A qualitative ordered comparison is sufficient when numerical estimates would be fictitious. Compare repayment, servicing, deferral and retirement; extinguish items when their future-cost mechanism or relevant system disappears.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S057; ESME-S023; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S027; ESME-S057; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: PARTIAL_WITH_SHARED_PROGRAMME; Reason: ESME-S057 includes a separate company setting with changed measurement and overlapping researchers.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S023; ESME-S057; ESME-S058; Reason: Source-supported: self-reported debt burdens do not identify causal recoverable savings; precise universal debt metrics are unsupported.

**Transferability.** Assessment: CONDITIONAL; Reason: Alternatives and relevant time horizon are explicit; sunk cost is not treated as prospective benefit. Which uncertainty could reverse the preferred option, and is more information worth its cost?

**Source IDs:** ESME-S027, ESME-S028, ESME-S057, ESME-S058, ESME-S023. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which uncertainty could reverse the preferred option, and is more information worth its cost?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-059 — Option-preserving deferral and deliberate non-repayment

**Disposition and kind.** CONTEXT_DEPENDENT; ECONOMIC_SELECTION_BRANCH

**Mature form.** Retain qualitative option reasoning without claiming a validated universal valuation formula.

**Controlled failure.** Source-supported: 2025 debt discussion recognises value in paying limited interest; numerical real-options calibration is not established here.

**Operating mechanism.** Defer a structural intervention when its expected value is below its cost, while retaining a trigger to revisit if demand, risk or support changes.

**Trigger.** Future change demand is uncertain, interest is small, or the system may retire before repayment benefits arise.

**Non-trigger and cheap path.** Do nothing beyond existing observation when there is no live liability; immediate repair dominates when an obligation is already breached.

**Prerequisites.** Conditions: Delay must not violate present obligations or create unacceptable irreversible lock-in.; Related property ids: ESME-056; ESME-058; ESME-074; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Those bearing future effort and present opportunity cost.; Decision: Deferral is an explicit justified choice with a relevant trigger rather than forgotten work.

**Authority and practical action.** Actors: Those bearing future effort and present opportunity cost.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Deferral is an explicit justified choice with a relevant trigger rather than forgotten work. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S058; Adjudication: Source-supported: 2025 debt discussion recognises value in paying limited interest; numerical real-options calibration is not established here.; Effect on disposition: Retain qualitative option reasoning without claiming a validated universal valuation formula.

**Anti-ceremony boundary.** Essential: Deferral is an explicit justified choice with a relevant trigger rather than forgotten work.; Minimal alternative: Do nothing beyond existing observation when there is no live liability; immediate repair dominates when an obligation is already breached.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Do nothing beyond existing observation when there is no live liability; immediate repair dominates when an obligation is already breached. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T06; Discriminator: State the change-contingent cost mechanism, horizon and uncertainty that could reverse priority.; Hybrid failure: Endless incidental cleanup hides scope expansion; feature urgency becomes a permanent excuse to ignore a known liability.

**Composition coupling.** ESME-R010; ESME-R044

#### Domain profile

**Change intent and change class.** Future change demand is uncertain, interest is small, or the system may retire before repayment benefits arise. Define a future-change liability, not every defect, missing feature or disliked structure as technical debt.

**Baseline and affected artefacts.** Deferred liability, prospective demand and revisit condition. A debt item links a concrete design/implementation condition to affected future work and its economic context.

**Preservation obligation and observer.** Those bearing future effort and present opportunity cost. The payoff is reduced justified lifecycle cost or enabled value; a changed static metric is merely a proxy.

**Impact boundary and dependency evidence.** Liabilities can be local or architectural; dependencies and changing objectives alter who incurs interest.

**Comprehension assumptions.** Delay must not violate present obligations or create unacceptable irreversible lock-in. Estimates require domain and maintenance experience; uncertainty about future change demand is irreducible.

**Oracle and regression limits.** Debt scanners and self-reported effort do not establish recoverable causal savings; compare plausible alternatives.

**Compatibility and migration preconditions.** Debt repayment may itself impose incompatible changes; make those migration assumptions explicit.

**Release rollback or forward repair condition.** Economic analysis is non-operative until an intervention is authorised; repayment then needs its own release/recovery evidence.

**Maintainer and downstream consumers.** Technical and business decision makers, maintainers and downstream cost bearers communicate trade-offs without blame.

**Lifecycle cost and retirement condition.** Do nothing beyond existing observation when there is no live liability; immediate repair dominates when an obligation is already breached. Compare repayment, servicing, deferral and retirement; extinguish items when their future-cost mechanism or relevant system disappears.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S013; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S058; Reason: Source-supported: 2025 debt discussion recognises value in paying limited interest; numerical real-options calibration is not established here.

**Transferability.** Assessment: CONDITIONAL; Reason: Delay must not violate present obligations or create unacceptable irreversible lock-in. What change in demand or exposure would make continued deferral indefensible?

**Source IDs:** ESME-S013, ESME-S055, ESME-S058. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What change in demand or exposure would make continued deferral indefensible?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-060 — Visibility of future cost bearers and participation

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; COORDINATION_AND_ACCOUNTABILITY_CRITERION

**Mature form.** Retain accountable cost communication with proportional participation.

**Controlled failure.** Source-supported: shared responsibility is recommended, but evidence does not establish a single governance structure; workload and unpaid expectations are real constraints.

**Operating mechanism.** Identify who gains now and who must later maintain, migrate or absorb risk; involve affected decision makers to the extent needed for legitimate trade-offs.

**Trigger.** A local benefit shifts material work or obligations to other teams, future maintainers or external consumers.

**Non-trigger and cheap path.** A direct agreement can suffice; no universal committee or separate owner per item is required.

**Prerequisites.** Conditions: Relevant representatives and actual authority are available; participation does not imply unanimity.; Related property ids: ESME-001; ESME-058; ESME-066; ESME-069; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Present and future maintainers, sponsors and downstream users.; Decision: The decision states material shifted costs and how affected parties can act on the information.

**Authority and practical action.** Actors: Present and future maintainers, sponsors and downstream users.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The decision states material shifted costs and how affected parties can act on the information. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S060; Adjudication: Source-supported: shared responsibility is recommended, but evidence does not establish a single governance structure; workload and unpaid expectations are real constraints.; Effect on disposition: Retain accountable cost communication with proportional participation.

**Anti-ceremony boundary.** Essential: The decision states material shifted costs and how affected parties can act on the information.; Minimal alternative: A direct agreement can suffice; no universal committee or separate owner per item is required.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A direct agreement can suffice; no universal committee or separate owner per item is required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T06; Discriminator: State the change-contingent cost mechanism, horizon and uncertainty that could reverse priority.; Hybrid failure: Endless incidental cleanup hides scope expansion; feature urgency becomes a permanent excuse to ignore a known liability.

**Composition coupling.** ESME-R010

#### Domain profile

**Change intent and change class.** A local benefit shifts material work or obligations to other teams, future maintainers or external consumers. Define a future-change liability, not every defect, missing feature or disliked structure as technical debt.

**Baseline and affected artefacts.** Cost allocation, support promises and affected stakeholders. A debt item links a concrete design/implementation condition to affected future work and its economic context.

**Preservation obligation and observer.** Present and future maintainers, sponsors and downstream users. The payoff is reduced justified lifecycle cost or enabled value; a changed static metric is merely a proxy.

**Impact boundary and dependency evidence.** Liabilities can be local or architectural; dependencies and changing objectives alter who incurs interest.

**Comprehension assumptions.** Relevant representatives and actual authority are available; participation does not imply unanimity. Estimates require domain and maintenance experience; uncertainty about future change demand is irreducible.

**Oracle and regression limits.** Debt scanners and self-reported effort do not establish recoverable causal savings; compare plausible alternatives.

**Compatibility and migration preconditions.** Debt repayment may itself impose incompatible changes; make those migration assumptions explicit.

**Release rollback or forward repair condition.** Economic analysis is non-operative until an intervention is authorised; repayment then needs its own release/recovery evidence.

**Maintainer and downstream consumers.** Technical and business decision makers, maintainers and downstream cost bearers communicate trade-offs without blame.

**Lifecycle cost and retirement condition.** A direct agreement can suffice; no universal committee or separate owner per item is required. Compare repayment, servicing, deferral and retirement; extinguish items when their future-cost mechanism or relevant system disappears.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S059.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S059; ESME-S060; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S060; Reason: Source-supported: shared responsibility is recommended, but evidence does not establish a single governance structure; workload and unpaid expectations are real constraints.

**Transferability.** Assessment: CONDITIONAL; Reason: Relevant representatives and actual authority are available; participation does not imply unanimity. Who pays the future cost but is absent from the current decision?

**Source IDs:** ESME-S028, ESME-S058, ESME-S059, ESME-S060. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Who pays the future cost but is absent from the current decision?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-063 — Retained rationale through actual use

**Disposition and kind.** STRONGLY_RETAINED; KNOWLEDGE_CONTINUITY_MECHANISM

**Mature form.** Consumer-tested rationale with retirement of obsolete constraints.

**Controlled failure.** Source-supported: human expertise exceeds documentation, so retained text is necessary only where useful and never sufficient by itself.

**Operating mechanism.** Retain the decision-relevant reasons, alternatives and accepted limitations in a form successors can locate and test against current conditions.

**Trigger.** Loss of intent would materially obstruct future change, support or retirement.

**Non-trigger and cheap path.** An adjacent comment, issue or concise handover may suffice; do not duplicate rationale in unconsumed documents.

**Prerequisites.** Conditions: The account is findable, interpretable and can be revised when evidence contradicts it.; Related property ids: ESME-004; ESME-012; ESME-015; ESME-016; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Future maintainer, operator or downstream decision maker.; Decision: A successor can connect a relevant constraint to its reason and identify when that reason no longer holds.

**Authority and practical action.** Actors: Future maintainer, operator or downstream decision maker.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** A successor can connect a relevant constraint to its reason and identify when that reason no longer holds. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S016; ESME-S058; Adjudication: Source-supported: human expertise exceeds documentation, so retained text is necessary only where useful and never sufficient by itself.; Effect on disposition: Consumer-tested rationale with retirement of obsolete constraints.

**Anti-ceremony boundary.** Essential: A successor can connect a relevant constraint to its reason and identify when that reason no longer holds.; Minimal alternative: An adjacent comment, issue or concise handover may suffice; do not duplicate rationale in unconsumed documents.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** An adjacent comment, issue or concise handover may suffice; do not duplicate rationale in unconsumed documents. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T02; Discriminator: Compare demonstrated next-change capability and total transition cost, not complexity score alone.; Hybrid failure: Long-lived mixed styles and half-transferred knowledge make both old and new harder to understand.; Tension id: ESME-T08; Discriminator: Ask what future consumer must actually be able to do: retrieve, interpret, execute or receive service.; Hybrid failure: An archive is advertised as runnable despite missing dependencies, or an obsolete service is kept live without a support purpose.

**Composition coupling.** ESME-R023; ESME-R049; ESME-R050

#### Domain profile

**Change intent and change class.** Loss of intent would materially obstruct future change, support or retirement. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Baseline and affected artefacts.** Change rationale, baseline references and accepted trade-offs. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Preservation obligation and observer.** Future maintainer, operator or downstream decision maker. A downstream promise must distinguish operational service, support, compatibility and historical retrievability.

**Impact boundary and dependency evidence.** Dependency metadata exposes possible reliance, not actual runtime reach or maintainers’ willingness to continue.

**Comprehension assumptions.** The account is findable, interpretable and can be revised when evidence contradicts it. Authorship is not full expertise; documentation cannot guarantee that a successor can diagnose and modify the system.

**Oracle and regression limits.** A sent notice or created archive does not prove a consumer has migrated or can reproduce execution.

**Compatibility and migration preconditions.** Transitions require a stated supported-version policy and consumer options; perpetual compatibility is not automatically required.

**Release rollback or forward repair condition.** Retirement and deletion can be irreversible; preserve agreed records and recovery capability only for the declared purpose/horizon.

**Maintainer and downstream consumers.** Maintainers, successors, upstream/downstream users and support sponsors exchange realistic responsibilities and closure information.

**Lifecycle cost and retirement condition.** An adjacent comment, issue or concise handover may suffice; do not duplicate rationale in unconsumed documents. Respect finite maintainer capacity; retire unsupported commitments explicitly, and preserve only what has a justified future consumer.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S016; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S016; ESME-S058; Reason: Source-supported: human expertise exceeds documentation, so retained text is necessary only where useful and never sufficient by itself.

**Transferability.** Assessment: CONDITIONAL; Reason: The account is findable, interpretable and can be revised when evidence contradicts it. Can the next maintainer tell whether this old constraint is still justified?

**Source IDs:** ESME-S014, ESME-S016, ESME-S019, ESME-S041, ESME-S058. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Can the next maintainer tell whether this old constraint is still justified?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-064 — Knowledge succession and demonstrated onboarding

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; HUMAN_CONTINUITY_MECHANISM

**Mature form.** Capability demonstration, not a minimum headcount or document inventory.

**Controlled failure.** Source-supported: truck-factor estimates have partial validation; successful-maintainer interviews are selected and do not prove one onboarding procedure.

**Operating mechanism.** Transfer practical ability through explanation, paired or supervised tasks and accessible artefacts; check that a successor can perform the relevant maintenance work.

**Trigger.** Departure, concentration, growth or a new support obligation makes continuity vulnerable.

**Non-trigger and cheap path.** A small stable project may need a clear support/retirement policy rather than recruiting multiple maintainers.

**Prerequisites.** Conditions: Successors have time, access, willingness and opportunities to practise; names on a roster are insufficient.; Related property ids: ESME-012; ESME-063; ESME-066; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Outgoing/incoming maintainers and supported users.; Decision: A successor can carry out representative supported work or the remaining limitation is explicit.

**Authority and practical action.** Actors: Outgoing/incoming maintainers and supported users.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** A successor can carry out representative supported work or the remaining limitation is explicit. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S032; ESME-S059; Adjudication: Source-supported: truck-factor estimates have partial validation; successful-maintainer interviews are selected and do not prove one onboarding procedure.; Effect on disposition: Capability demonstration, not a minimum headcount or document inventory.

**Anti-ceremony boundary.** Essential: A successor can carry out representative supported work or the remaining limitation is explicit.; Minimal alternative: A small stable project may need a clear support/retirement policy rather than recruiting multiple maintainers.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A small stable project may need a clear support/retirement policy rather than recruiting multiple maintainers. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T02; Discriminator: Compare demonstrated next-change capability and total transition cost, not complexity score alone.; Hybrid failure: Long-lived mixed styles and half-transferred knowledge make both old and new harder to understand.

**Composition coupling.** ESME-R023; ESME-R045; ESME-R047; ESME-R050

#### Domain profile

**Change intent and change class.** Departure, concentration, growth or a new support obligation makes continuity vulnerable. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Baseline and affected artefacts.** People, task knowledge, access, artefacts and support responsibilities. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Preservation obligation and observer.** Outgoing/incoming maintainers and supported users. A downstream promise must distinguish operational service, support, compatibility and historical retrievability.

**Impact boundary and dependency evidence.** Dependency metadata exposes possible reliance, not actual runtime reach or maintainers’ willingness to continue.

**Comprehension assumptions.** Successors have time, access, willingness and opportunities to practise; names on a roster are insufficient. Authorship is not full expertise; documentation cannot guarantee that a successor can diagnose and modify the system.

**Oracle and regression limits.** A sent notice or created archive does not prove a consumer has migrated or can reproduce execution.

**Compatibility and migration preconditions.** Transitions require a stated supported-version policy and consumer options; perpetual compatibility is not automatically required.

**Release rollback or forward repair condition.** Retirement and deletion can be irreversible; preserve agreed records and recovery capability only for the declared purpose/horizon.

**Maintainer and downstream consumers.** Maintainers, successors, upstream/downstream users and support sponsors exchange realistic responsibilities and closure information.

**Lifecycle cost and retirement condition.** A small stable project may need a clear support/retirement policy rather than recruiting multiple maintainers. Respect finite maintainer capacity; retire unsupported commitments explicitly, and preserve only what has a justified future consumer.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S059.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S032; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S013; ESME-S016; ESME-S059; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S032; ESME-S059; Reason: Source-supported: truck-factor estimates have partial validation; successful-maintainer interviews are selected and do not prove one onboarding procedure.

**Transferability.** Assessment: CONDITIONAL; Reason: Successors have time, access, willingness and opportunities to practise; names on a roster are insufficient. What representative task demonstrates that knowledge has actually transferred?

**Source IDs:** ESME-S013, ESME-S016, ESME-S032, ESME-S059. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What representative task demonstrates that knowledge has actually transferred?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-065 — Scoped ownership and change coordination

**Disposition and kind.** CONTEXT_DEPENDENT; AUTHORITY_AND_COORDINATION_MECHANISM

**Mature form.** Responsibility follows real decisions, not one owner per file or source property.

**Controlled failure.** Source-supported: authorship is not complete competence; maintainer success involves communication beyond technical gatekeeping.

**Operating mechanism.** Make responsibility and decision rights clear enough to resolve overlapping changes and support requests without assuming exclusive code ownership.

**Trigger.** Multiple contributors or support paths create ambiguity about acceptance, review or incident response.

**Non-trigger and cheap path.** One maintainer can hold several roles; collaborative ownership is adequate when responsibility remains actionable.

**Prerequisites.** Conditions: Stated responsibility matches actual access, capability and agreed support commitments.; Related property ids: ESME-001; ESME-027; ESME-064; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Contributors, maintainers and downstream users seeking a decision.; Decision: A relevant request or conflict can reach someone able and authorised to decide or explicitly decline.

**Authority and practical action.** Actors: Contributors, maintainers and downstream users seeking a decision.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** A relevant request or conflict can reach someone able and authorised to decide or explicitly decline. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S032; ESME-S060; Adjudication: Source-supported: authorship is not complete competence; maintainer success involves communication beyond technical gatekeeping.; Effect on disposition: Responsibility follows real decisions, not one owner per file or source property.

**Anti-ceremony boundary.** Essential: A relevant request or conflict can reach someone able and authorised to decide or explicitly decline.; Minimal alternative: One maintainer can hold several roles; collaborative ownership is adequate when responsibility remains actionable.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** One maintainer can hold several roles; collaborative ownership is adequate when responsibility remains actionable. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R023

#### Domain profile

**Change intent and change class.** Multiple contributors or support paths create ambiguity about acceptance, review or incident response. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Baseline and affected artefacts.** Change requests, affected components and decision responsibilities. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Preservation obligation and observer.** Contributors, maintainers and downstream users seeking a decision. A downstream promise must distinguish operational service, support, compatibility and historical retrievability.

**Impact boundary and dependency evidence.** Dependency metadata exposes possible reliance, not actual runtime reach or maintainers’ willingness to continue.

**Comprehension assumptions.** Stated responsibility matches actual access, capability and agreed support commitments. Authorship is not full expertise; documentation cannot guarantee that a successor can diagnose and modify the system.

**Oracle and regression limits.** A sent notice or created archive does not prove a consumer has migrated or can reproduce execution.

**Compatibility and migration preconditions.** Transitions require a stated supported-version policy and consumer options; perpetual compatibility is not automatically required.

**Release rollback or forward repair condition.** Retirement and deletion can be irreversible; preserve agreed records and recovery capability only for the declared purpose/horizon.

**Maintainer and downstream consumers.** Maintainers, successors, upstream/downstream users and support sponsors exchange realistic responsibilities and closure information.

**Lifecycle cost and retirement condition.** One maintainer can hold several roles; collaborative ownership is adequate when responsibility remains actionable. Respect finite maintainer capacity; retire unsupported commitments explicitly, and preserve only what has a justified future consumer.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S059.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S032; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S059; ESME-S060; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S032; ESME-S060; Reason: Source-supported: authorship is not complete competence; maintainer success involves communication beyond technical gatekeeping.

**Transferability.** Assessment: CONDITIONAL; Reason: Stated responsibility matches actual access, capability and agreed support commitments. Who can decide this change, and who can actually carry it out or decline support?

**Source IDs:** ESME-S019, ESME-S041, ESME-S059, ESME-S032, ESME-S060. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Who can decide this change, and who can actually carry it out or decline support?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-066 — Finite maintainer capacity and realistic support commitments

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; RESOURCE_AND_CONTINUITY_CRITERION

**Mature form.** Retain capacity-aware stewardship without prescribing unpaid labour or universal staffing ratios.

**Controlled failure.** Source-supported: mixed-methods studies report support barriers; automation’s net time effect depends on task and tools.

**Operating mechanism.** Align promised support, intake and update obligations with available willing capacity; negotiate reduced scope, sponsorship, transfer or retirement when infeasible.

**Trigger.** Demand, dependency obligations or turnover exceed sustainable support capability.

**Non-trigger and cheap path.** Reduce nonessential scope or state a limited support policy rather than add complex automation by default.

**Prerequisites.** Conditions: Capacity claims include review and coordination, not only code production; willingness is not implied by public code.; Related property ids: ESME-010; ESME-060; ESME-064; ESME-069; ESME-071; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Maintainers, users relying on support and potential sponsors/successors.; Decision: Support expectations match an actionable capacity plan or clearly announced limitation.

**Authority and practical action.** Actors: Maintainers, users relying on support and potential sponsors/successors.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Support expectations match an actionable capacity plan or clearly announced limitation. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S036; ESME-S037; ESME-S060; Adjudication: Source-supported: mixed-methods studies report support barriers; automation’s net time effect depends on task and tools.; Effect on disposition: Retain capacity-aware stewardship without prescribing unpaid labour or universal staffing ratios.

**Anti-ceremony boundary.** Essential: Support expectations match an actionable capacity plan or clearly announced limitation.; Minimal alternative: Reduce nonessential scope or state a limited support policy rather than add complex automation by default.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Reduce nonessential scope or state a limited support policy rather than add complex automation by default. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T07; Discriminator: Determine real promises, capacity and transition feasibility; usage popularity is neither permission nor an infinite support contract.; Hybrid failure: Dates are announced without a viable path, or compatibility branches multiply beyond capacity.

**Composition coupling.** ESME-R010; ESME-R023; ESME-R025; ESME-R034; ESME-R045

#### Domain profile

**Change intent and change class.** Demand, dependency obligations or turnover exceed sustainable support capability. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Baseline and affected artefacts.** Support promises, workload, available people and tooling. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Preservation obligation and observer.** Maintainers, users relying on support and potential sponsors/successors. A downstream promise must distinguish operational service, support, compatibility and historical retrievability.

**Impact boundary and dependency evidence.** Dependency metadata exposes possible reliance, not actual runtime reach or maintainers’ willingness to continue.

**Comprehension assumptions.** Capacity claims include review and coordination, not only code production; willingness is not implied by public code. Authorship is not full expertise; documentation cannot guarantee that a successor can diagnose and modify the system.

**Oracle and regression limits.** A sent notice or created archive does not prove a consumer has migrated or can reproduce execution.

**Compatibility and migration preconditions.** Transitions require a stated supported-version policy and consumer options; perpetual compatibility is not automatically required.

**Release rollback or forward repair condition.** Retirement and deletion can be irreversible; preserve agreed records and recovery capability only for the declared purpose/horizon.

**Maintainer and downstream consumers.** Maintainers, successors, upstream/downstream users and support sponsors exchange realistic responsibilities and closure information.

**Lifecycle cost and retirement condition.** Reduce nonessential scope or state a limited support policy rather than add complex automation by default. Respect finite maintainer capacity; retire unsupported commitments explicitly, and preserve only what has a justified future consumer.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S059.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S036; ESME-S037; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S013; ESME-S059; ESME-S060; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S036; ESME-S037; ESME-S060; Reason: Source-supported: mixed-methods studies report support barriers; automation’s net time effect depends on task and tools.

**Transferability.** Assessment: CONDITIONAL; Reason: Capacity claims include review and coordination, not only code production; willingness is not implied by public code. Which current promise cannot be met with the available people, authority and time?

**Source IDs:** ESME-S013, ESME-S059, ESME-S060, ESME-S036, ESME-S037. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which current promise cannot be met with the available people, authority and time?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-067 — Knowledge-concentration metrics as fallible prompts

**Disposition and kind.** USEFUL_BUT_EASILY_GAMED; MEASUREMENT_PROXY

**Mature form.** Retain as a diagnostic, not a staffing target or an actuarial collapse estimate.

**Controlled failure.** Source-supported: participant validation differs substantially for authorship and inferred truck factor.

**Operating mechanism.** Use the estimate to ask who can actually support critical work; verify with maintainers rather than treating a computed number as a failure probability.

**Trigger.** A project needs to assess continuity and history can offer a useful first approximation.

**Non-trigger and cheap path.** Ask maintainers directly or exercise a handover when feasible; no metric is required.

**Prerequisites.** Conditions: Authorship mapping represents some relevant knowledge; uncommitted, operational and domain expertise remain unmeasured.; Related property ids: ESME-064; ESME-066; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Maintainers and support planners.; Decision: The estimate is accompanied by checks of actual capability and omitted knowledge.

**Authority and practical action.** Actors: Maintainers and support planners.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The estimate is accompanied by checks of actual capability and omitted knowledge. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S016; ESME-S032; Adjudication: Source-supported: participant validation differs substantially for authorship and inferred truck factor.; Effect on disposition: Retain as a diagnostic, not a staffing target or an actuarial collapse estimate.

**Anti-ceremony boundary.** Essential: The estimate is accompanied by checks of actual capability and omitted knowledge.; Minimal alternative: Ask maintainers directly or exercise a handover when feasible; no metric is required.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Ask maintainers directly or exercise a handover when feasible; no metric is required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R045

#### Domain profile

**Change intent and change class.** A project needs to assess continuity and history can offer a useful first approximation. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Baseline and affected artefacts.** Commit history, authorship assumptions and demonstrated expertise. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Preservation obligation and observer.** Maintainers and support planners. A downstream promise must distinguish operational service, support, compatibility and historical retrievability.

**Impact boundary and dependency evidence.** Dependency metadata exposes possible reliance, not actual runtime reach or maintainers’ willingness to continue.

**Comprehension assumptions.** Authorship mapping represents some relevant knowledge; uncommitted, operational and domain expertise remain unmeasured. Authorship is not full expertise; documentation cannot guarantee that a successor can diagnose and modify the system.

**Oracle and regression limits.** A sent notice or created archive does not prove a consumer has migrated or can reproduce execution.

**Compatibility and migration preconditions.** Transitions require a stated supported-version policy and consumer options; perpetual compatibility is not automatically required.

**Release rollback or forward repair condition.** Retirement and deletion can be irreversible; preserve agreed records and recovery capability only for the declared purpose/horizon.

**Maintainer and downstream consumers.** Maintainers, successors, upstream/downstream users and support sponsors exchange realistic responsibilities and closure information.

**Lifecycle cost and retirement condition.** Ask maintainers directly or exercise a handover when feasible; no metric is required. Respect finite maintainer capacity; retire unsupported commitments explicitly, and preserve only what has a justified future consumer.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S032; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S016; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S016; ESME-S032; Reason: Source-supported: participant validation differs substantially for authorship and inferred truck factor.

**Transferability.** Assessment: CONDITIONAL; Reason: Authorship mapping represents some relevant knowledge; uncommitted, operational and domain expertise remain unmeasured. Who knows the system despite low commit authorship, or commits without transferable understanding?

**Source IDs:** ESME-S032, ESME-S016. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Who knows the system despite low commit authorship, or commits without transferable understanding?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-068 — Dependency inventory and update trade-offs

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; ECOSYSTEM_MAINTENANCE_MECHANISM

**Mature form.** Update policy is conditional on use, risk and support, not always latest or always pinned.

**Controlled failure.** Source-supported: network exposure is not failure frequency; notifications and automatic updates can increase burden.

**Operating mechanism.** Identify supported dependency versions and consequential transitive reliance; assess update, pinning, substitution or retirement against actual compatibility and support needs.

**Trigger.** A dependency changes, loses support or creates a relevant defect/security obligation.

**Non-trigger and cheap path.** Use a small explicit dependency list and targeted check for a bounded artefact; no ecosystem-wide graph is inherently necessary.

**Prerequisites.** Conditions: Inventory reflects actual resolution and relevant use; a graph edge is not itself a live failure.; Related property ids: ESME-021; ESME-025; ESME-066; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Upstream/downstream maintainers and operators.; Decision: A consequential dependency change has a justified action or deferral and an explicit support/compatibility account.

**Authority and practical action.** Actors: Upstream/downstream maintainers and operators.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** A consequential dependency change has a justified action or deferral and an explicit support/compatibility account. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S024; ESME-S033; ESME-S060; Adjudication: Source-supported: network exposure is not failure frequency; notifications and automatic updates can increase burden.; Effect on disposition: Update policy is conditional on use, risk and support, not always latest or always pinned.

**Anti-ceremony boundary.** Essential: A consequential dependency change has a justified action or deferral and an explicit support/compatibility account.; Minimal alternative: Use a small explicit dependency list and targeted check for a bounded artefact; no ecosystem-wide graph is inherently necessary.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Use a small explicit dependency list and targeted check for a bounded artefact; no ecosystem-wide graph is inherently necessary. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T07; Discriminator: Determine real promises, capacity and transition feasibility; usage popularity is neither permission nor an infinite support contract.; Hybrid failure: Dates are announced without a viable path, or compatibility branches multiply beyond capacity.

**Composition coupling.** ESME-R024; ESME-R025; ESME-R045

#### Domain profile

**Change intent and change class.** A dependency changes, loses support or creates a relevant defect/security obligation. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Baseline and affected artefacts.** Dependency manifests, resolved versions, support status and affected uses. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Preservation obligation and observer.** Upstream/downstream maintainers and operators. A downstream promise must distinguish operational service, support, compatibility and historical retrievability.

**Impact boundary and dependency evidence.** Dependency metadata exposes possible reliance, not actual runtime reach or maintainers’ willingness to continue.

**Comprehension assumptions.** Inventory reflects actual resolution and relevant use; a graph edge is not itself a live failure. Authorship is not full expertise; documentation cannot guarantee that a successor can diagnose and modify the system.

**Oracle and regression limits.** A sent notice or created archive does not prove a consumer has migrated or can reproduce execution.

**Compatibility and migration preconditions.** Transitions require a stated supported-version policy and consumer options; perpetual compatibility is not automatically required.

**Release rollback or forward repair condition.** Retirement and deletion can be irreversible; preserve agreed records and recovery capability only for the declared purpose/horizon.

**Maintainer and downstream consumers.** Maintainers, successors, upstream/downstream users and support sponsors exchange realistic responsibilities and closure information.

**Lifecycle cost and retirement condition.** Use a small explicit dependency list and targeted check for a bounded artefact; no ecosystem-wide graph is inherently necessary. Respect finite maintainer capacity; retire unsupported commitments explicitly, and preserve only what has a justified future consumer.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S033; ESME-S024; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S060; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S024; ESME-S033; ESME-S060; Reason: Source-supported: network exposure is not failure frequency; notifications and automatic updates can increase burden.

**Transferability.** Assessment: CONDITIONAL; Reason: Inventory reflects actual resolution and relevant use; a graph edge is not itself a live failure. Which used dependency lacks a credible support or transition path, and what actual exposure follows?

**Source IDs:** ESME-S019, ESME-S033, ESME-S060, ESME-S024. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which used dependency lacks a credible support or transition path, and what actual exposure follows?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-069 — Downstream communication that enables action

**Disposition and kind.** STRONGLY_RETAINED; COMMUNICATION_AND_COORDINATION_MECHANISM

**Mature form.** Actionable communication with proportional evidence of reach, not a mandatory newsletter ritual.

**Controlled failure.** Source-supported: HTTP hints do not guarantee receipt, authenticity or migration; notification overload can defeat communication.

**Operating mechanism.** Send the scope, timing, supported alternatives and required action to relevant consumers through an effective channel; check critical dependencies rather than assuming broadcast receipt.

**Trigger.** A change affects consumer obligations, compatibility, support or availability.

**Non-trigger and cheap path.** A direct agreement with the sole consumer may suffice; no broad notice is needed for a truly private effect.

**Prerequisites.** Conditions: The recipient can understand and act; publication alone may be insufficient for critical commitments.; Related property ids: ESME-001; ESME-025; ESME-060; ESME-066; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Downstream maintainers and users able to adapt or contest the change.; Decision: Consequential consumers have usable transition information and unresolved reliance is visible.

**Authority and practical action.** Actors: Downstream maintainers and users able to adapt or contest the change.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Consequential consumers have usable transition information and unresolved reliance is visible. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S054; ESME-S060; Adjudication: Source-supported: HTTP hints do not guarantee receipt, authenticity or migration; notification overload can defeat communication.; Effect on disposition: Actionable communication with proportional evidence of reach, not a mandatory newsletter ritual.

**Anti-ceremony boundary.** Essential: Consequential consumers have usable transition information and unresolved reliance is visible.; Minimal alternative: A direct agreement with the sole consumer may suffice; no broad notice is needed for a truly private effect.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A direct agreement with the sole consumer may suffice; no broad notice is needed for a truly private effect. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T01; Discriminator: Identify the actual obligation, consumer and authorisation for revision; unresolved authority blocks that revision, not unrelated work.; Hybrid failure: Two ambiguous meanings, unmaintained compatibility mode, or an oracle changed solely to pass.; Tension id: ESME-T07; Discriminator: Determine real promises, capacity and transition feasibility; usage popularity is neither permission nor an infinite support contract.; Hybrid failure: Dates are announced without a viable path, or compatibility branches multiply beyond capacity.

**Composition coupling.** ESME-R017; ESME-R023; ESME-R024; ESME-R025; ESME-R033

#### Domain profile

**Change intent and change class.** A change affects consumer obligations, compatibility, support or availability. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Baseline and affected artefacts.** Release notes, support policy, client dependencies and transition instructions. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Preservation obligation and observer.** Downstream maintainers and users able to adapt or contest the change. A downstream promise must distinguish operational service, support, compatibility and historical retrievability.

**Impact boundary and dependency evidence.** Dependency metadata exposes possible reliance, not actual runtime reach or maintainers’ willingness to continue.

**Comprehension assumptions.** The recipient can understand and act; publication alone may be insufficient for critical commitments. Authorship is not full expertise; documentation cannot guarantee that a successor can diagnose and modify the system.

**Oracle and regression limits.** A sent notice or created archive does not prove a consumer has migrated or can reproduce execution.

**Compatibility and migration preconditions.** Transitions require a stated supported-version policy and consumer options; perpetual compatibility is not automatically required.

**Release rollback or forward repair condition.** Retirement and deletion can be irreversible; preserve agreed records and recovery capability only for the declared purpose/horizon.

**Maintainer and downstream consumers.** Maintainers, successors, upstream/downstream users and support sponsors exchange realistic responsibilities and closure information.

**Lifecycle cost and retirement condition.** A direct agreement with the sole consumer may suffice; no broad notice is needed for a truly private effect. Respect finite maintainer capacity; retire unsupported commitments explicitly, and preserve only what has a justified future consumer.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S021; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S060; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S054; ESME-S060; Reason: Source-supported: HTTP hints do not guarantee receipt, authenticity or migration; notification overload can defeat communication.

**Transferability.** Assessment: CONDITIONAL; Reason: The recipient can understand and act; publication alone may be insufficient for critical commitments. What can the affected consumer actually do with this notice before the change occurs?

**Source IDs:** ESME-S021, ESME-S041, ESME-S053, ESME-S054, ESME-S060. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What can the affected consumer actually do with this notice before the change occurs?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-070 — Deprecation signalling separated from shutdown

**Disposition and kind.** DOMAIN_SPECIFIC; PROTOCOL_AND_POLICY_MECHANISM

**Mature form.** Use appropriate domain signalling, not a universal ritual or semantic conflation.

**Controlled failure.** Source-supported: the two RFCs deliberately signal different transitions; the same word in archival guidance has another meaning.

**Operating mechanism.** Declare the local meaning and support effect of deprecation, distinguishing discouraged use, changed guarantees, end of support and service termination.

**Trigger.** An interface or service is being superseded, losing guarantees or approaching shutdown.

**Non-trigger and cheap path.** A documented support statement may suffice outside HTTP; no header is required where it has no consumer.

**Prerequisites.** Conditions: Dates, scope and authoritative documentation agree; a signal is not itself a migration plan.; Related property ids: ESME-025; ESME-069; ESME-071; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Client developers and supported users.; Decision: The announced state and implications are unambiguous to the intended consumer.

**Authority and practical action.** Actors: Client developers and supported users.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The announced state and implications are unambiguous to the intended consumer. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S053; ESME-S054; Adjudication: Source-supported: the two RFCs deliberately signal different transitions; the same word in archival guidance has another meaning.; Effect on disposition: Use appropriate domain signalling, not a universal ritual or semantic conflation.

**Anti-ceremony boundary.** Essential: The announced state and implications are unambiguous to the intended consumer.; Minimal alternative: A documented support statement may suffice outside HTTP; no header is required where it has no consumer.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A documented support statement may suffice outside HTTP; no header is required where it has no consumer. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T07; Discriminator: Determine real promises, capacity and transition feasibility; usage popularity is neither permission nor an infinite support contract.; Hybrid failure: Dates are announced without a viable path, or compatibility branches multiply beyond capacity.

**Composition coupling.** ESME-R017; ESME-R024

#### Domain profile

**Change intent and change class.** An interface or service is being superseded, losing guarantees or approaching shutdown. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Baseline and affected artefacts.** Resource, API version, support policy, deprecation date and possible sunset date. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Preservation obligation and observer.** Client developers and supported users. A downstream promise must distinguish operational service, support, compatibility and historical retrievability.

**Impact boundary and dependency evidence.** Dependency metadata exposes possible reliance, not actual runtime reach or maintainers’ willingness to continue.

**Comprehension assumptions.** Dates, scope and authoritative documentation agree; a signal is not itself a migration plan. Authorship is not full expertise; documentation cannot guarantee that a successor can diagnose and modify the system.

**Oracle and regression limits.** A sent notice or created archive does not prove a consumer has migrated or can reproduce execution.

**Compatibility and migration preconditions.** Transitions require a stated supported-version policy and consumer options; perpetual compatibility is not automatically required.

**Release rollback or forward repair condition.** Retirement and deletion can be irreversible; preserve agreed records and recovery capability only for the declared purpose/horizon.

**Maintainer and downstream consumers.** Maintainers, successors, upstream/downstream users and support sponsors exchange realistic responsibilities and closure information.

**Lifecycle cost and retirement condition.** A documented support statement may suffice outside HTTP; no header is required where it has no consumer. Respect finite maintainer capacity; retire unsupported commitments explicitly, and preserve only what has a justified future consumer.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S053; ESME-S054; Reason: Source-supported: the two RFCs deliberately signal different transitions; the same word in archival guidance has another meaning.

**Transferability.** Assessment: CONDITIONAL; Reason: Dates, scope and authoritative documentation agree; a signal is not itself a migration plan. Does this announcement change recommendation, support, behaviour, availability, or several of them?

**Source IDs:** ESME-S053, ESME-S054, ESME-S055. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Does this announcement change recommendation, support, behaviour, availability, or several of them?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-071 — Responsible retirement with discharged obligations

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; LIFECYCLE_TERMINATION_MECHANISM

**Mature form.** Retirement is an active accountable branch, not failure to modernise or abandonment by silence.

**Controlled failure.** Analytical limits grounded in guidance: archival success does not prove all consumer needs discharged; over-retention creates ongoing cost.

**Operating mechanism.** Identify remaining users, data, support and archival obligations; authorise termination and verify the intended services/routes actually close while agreed retained assets remain usable.

**Trigger.** The software is no longer useful, supportable or justified relative to alternatives.

**Non-trigger and cheap path.** Continue a stable low-cost service when retirement would strand justified obligations; close simple unused artefacts with proportionate checks.

**Prerequisites.** Conditions: Authority to terminate and resolve surviving obligations must be established; jurisdiction-specific legal duties require separate expertise.; Related property ids: ESME-052; ESME-066; ESME-069; ESME-072; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Remaining consumers, maintainers and authorised custodians.; Decision: Operational termination and surviving preservation/support arrangements are evidenced separately.

**Authority and practical action.** Actors: Remaining consumers, maintainers and authorised custodians.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Operational termination and surviving preservation/support arrangements are evidenced separately. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S055; ESME-S062; Adjudication: Analytical limits grounded in guidance: archival success does not prove all consumer needs discharged; over-retention creates ongoing cost.; Effect on disposition: Retirement is an active accountable branch, not failure to modernise or abandonment by silence.

**Anti-ceremony boundary.** Essential: Operational termination and surviving preservation/support arrangements are evidenced separately.; Minimal alternative: Continue a stable low-cost service when retirement would strand justified obligations; close simple unused artefacts with proportionate checks.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Continue a stable low-cost service when retirement would strand justified obligations; close simple unused artefacts with proportionate checks. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T07; Discriminator: Determine real promises, capacity and transition feasibility; usage popularity is neither permission nor an infinite support contract.; Hybrid failure: Dates are announced without a viable path, or compatibility branches multiply beyond capacity.; Tension id: ESME-T08; Discriminator: Ask what future consumer must actually be able to do: retrieve, interpret, execute or receive service.; Hybrid failure: An archive is advertised as runnable despite missing dependencies, or an obsolete service is kept live without a support purpose.

**Composition coupling.** ESME-R010; ESME-R017; ESME-R025; ESME-R033

#### Domain profile

**Change intent and change class.** The software is no longer useful, supportable or justified relative to alternatives. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Baseline and affected artefacts.** Service endpoints, users, data, credentials/access, support promises and retained records. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Preservation obligation and observer.** Remaining consumers, maintainers and authorised custodians. A downstream promise must distinguish operational service, support, compatibility and historical retrievability.

**Impact boundary and dependency evidence.** Dependency metadata exposes possible reliance, not actual runtime reach or maintainers’ willingness to continue.

**Comprehension assumptions.** Authority to terminate and resolve surviving obligations must be established; jurisdiction-specific legal duties require separate expertise. Authorship is not full expertise; documentation cannot guarantee that a successor can diagnose and modify the system.

**Oracle and regression limits.** A sent notice or created archive does not prove a consumer has migrated or can reproduce execution.

**Compatibility and migration preconditions.** Transitions require a stated supported-version policy and consumer options; perpetual compatibility is not automatically required.

**Release rollback or forward repair condition.** Retirement and deletion can be irreversible; preserve agreed records and recovery capability only for the declared purpose/horizon.

**Maintainer and downstream consumers.** Maintainers, successors, upstream/downstream users and support sponsors exchange realistic responsibilities and closure information.

**Lifecycle cost and retirement condition.** Continue a stable low-cost service when retirement would strand justified obligations; close simple unused artefacts with proportionate checks. Respect finite maintainer capacity; retire unsupported commitments explicitly, and preserve only what has a justified future consumer.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S013; ESME-S062; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S055; ESME-S062; Reason: Analytical limits grounded in guidance: archival success does not prove all consumer needs discharged; over-retention creates ongoing cost.

**Transferability.** Assessment: CONDITIONAL; Reason: Authority to terminate and resolve surviving obligations must be established; jurisdiction-specific legal duties require separate expertise. Which obligation survives shutdown, and what evidence shows it has a viable custodian or is legitimately ended?

**Source IDs:** ESME-S013, ESME-S041, ESME-S053, ESME-S055, ESME-S056, ESME-S062. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which obligation survives shutdown, and what evidence shows it has a viable custodian or is legitimately ended?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-072 — Purpose-bounded archival preservation and reproducibility

**Disposition and kind.** CONTEXT_DEPENDENT; PRESERVATION_MECHANISM

**Mature form.** Purpose and capability determine preservation depth, with review and eventual disposal conditions.

**Controlled failure.** Source-supported: source archival guide is version-specific; reproducible packaging has environment limits. Analytical: data rights may constrain retention.

**Operating mechanism.** Choose what must remain retrievable or executable for a declared purpose and horizon, and verify the relevant retrieval/reproduction capability.

**Trigger.** Historical analysis, compliance, research reproduction or future revival justifies retained artefacts after active use.

**Non-trigger and cheap path.** Retain a source snapshot and rationale when execution is unnecessary; avoid indefinitely operating a service solely to preserve history.

**Prerequisites.** Conditions: Retained rights, identifiers, storage and environment assumptions support the intended use.; Related property ids: ESME-004; ESME-041; ESME-063; ESME-071; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Future researcher, maintainer or custodian with a concrete use.; Decision: The specified historical object can be retrieved or relevant execution reproduced within stated limitations.

**Authority and practical action.** Actors: Future researcher, maintainer or custodian with a concrete use.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The specified historical object can be retrieved or relevant execution reproduced within stated limitations. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S052; ESME-S055; Adjudication: Source-supported: source archival guide is version-specific; reproducible packaging has environment limits. Analytical: data rights may constrain retention.; Effect on disposition: Purpose and capability determine preservation depth, with review and eventual disposal conditions.

**Anti-ceremony boundary.** Essential: The specified historical object can be retrieved or relevant execution reproduced within stated limitations.; Minimal alternative: Retain a source snapshot and rationale when execution is unnecessary; avoid indefinitely operating a service solely to preserve history.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Retain a source snapshot and rationale when execution is unnecessary; avoid indefinitely operating a service solely to preserve history. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T08; Discriminator: Ask what future consumer must actually be able to do: retrieve, interpret, execute or receive service.; Hybrid failure: An archive is advertised as runnable despite missing dependencies, or an obsolete service is kept live without a support purpose.

**Composition coupling.** ESME-R017

#### Domain profile

**Change intent and change class.** Historical analysis, compliance, research reproduction or future revival justifies retained artefacts after active use. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Baseline and affected artefacts.** Source, dependencies, documentation, data rights and optional executable environment. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Preservation obligation and observer.** Future researcher, maintainer or custodian with a concrete use. A downstream promise must distinguish operational service, support, compatibility and historical retrievability.

**Impact boundary and dependency evidence.** Dependency metadata exposes possible reliance, not actual runtime reach or maintainers’ willingness to continue.

**Comprehension assumptions.** Retained rights, identifiers, storage and environment assumptions support the intended use. Authorship is not full expertise; documentation cannot guarantee that a successor can diagnose and modify the system.

**Oracle and regression limits.** A sent notice or created archive does not prove a consumer has migrated or can reproduce execution.

**Compatibility and migration preconditions.** Transitions require a stated supported-version policy and consumer options; perpetual compatibility is not automatically required.

**Release rollback or forward repair condition.** Retirement and deletion can be irreversible; preserve agreed records and recovery capability only for the declared purpose/horizon.

**Maintainer and downstream consumers.** Maintainers, successors, upstream/downstream users and support sponsors exchange realistic responsibilities and closure information.

**Lifecycle cost and retirement condition.** Retain a source snapshot and rationale when execution is unnecessary; avoid indefinitely operating a service solely to preserve history. Respect finite maintainer capacity; retire unsupported commitments explicitly, and preserve only what has a justified future consumer.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S052; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S052; ESME-S055; Reason: Source-supported: source archival guide is version-specific; reproducible packaging has environment limits. Analytical: data rights may constrain retention.

**Transferability.** Assessment: CONDITIONAL; Reason: Retained rights, identifiers, storage and environment assumptions support the intended use. Does the future consumer need source identity, semantic context, a runnable environment, or an operating service?

**Source IDs:** ESME-S055, ESME-S056, ESME-S052. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Does the future consumer need source identity, semantic context, a runnable environment, or an operating service?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-074 — Stable useful software may justify no change

**Disposition and kind.** STRONGLY_RETAINED; NON_INTERVENTION_BRANCH

**Mature form.** No-change is positive stewardship under conditions, not denial of emerging obligations.

**Controlled failure.** Analytical deduction from scoped evolution and lifecycle economics: unchanged code can still become unfit if environment or support changes.

**Operating mechanism.** Choose continued unchanged operation where current obligations, support conditions and expected value do not justify intervention; keep only relevant observation triggers.

**Trigger.** No demonstrated defect, adaptation need or investment opportunity outweighs change risk and cost.

**Non-trigger and cheap path.** This is the cheap path itself; review existing signals rather than create permanent change machinery.

**Prerequisites.** Conditions: The environment and obligations remain sufficiently stable; no ignored known breach exists.; Related property ids: ESME-007; ESME-046; ESME-059; ESME-066; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Current users and maintainers.; Decision: A no-change decision states why obligations remain met and what evidence would prompt reconsideration.

**Authority and practical action.** Actors: Current users and maintainers.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** A no-change decision states why obligations remain met and what evidence would prompt reconsideration. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S008; ESME-S029; Adjudication: Analytical deduction from scoped evolution and lifecycle economics: unchanged code can still become unfit if environment or support changes.; Effect on disposition: No-change is positive stewardship under conditions, not denial of emerging obligations.

**Anti-ceremony boundary.** Essential: A no-change decision states why obligations remain met and what evidence would prompt reconsideration.; Minimal alternative: This is the cheap path itself; review existing signals rather than create permanent change machinery.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** This is the cheap path itself; review existing signals rather than create permanent change machinery. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R003; ESME-R010; ESME-R025; ESME-R034; ESME-R038

#### Domain profile

**Change intent and change class.** No demonstrated defect, adaptation need or investment opportunity outweighs change risk and cost. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Baseline and affected artefacts.** Current capability, support horizon and environmental assumptions. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.

**Preservation obligation and observer.** Current users and maintainers. A downstream promise must distinguish operational service, support, compatibility and historical retrievability.

**Impact boundary and dependency evidence.** Dependency metadata exposes possible reliance, not actual runtime reach or maintainers’ willingness to continue.

**Comprehension assumptions.** The environment and obligations remain sufficiently stable; no ignored known breach exists. Authorship is not full expertise; documentation cannot guarantee that a successor can diagnose and modify the system.

**Oracle and regression limits.** A sent notice or created archive does not prove a consumer has migrated or can reproduce execution.

**Compatibility and migration preconditions.** Transitions require a stated supported-version policy and consumer options; perpetual compatibility is not automatically required.

**Release rollback or forward repair condition.** Retirement and deletion can be irreversible; preserve agreed records and recovery capability only for the declared purpose/horizon.

**Maintainer and downstream consumers.** Maintainers, successors, upstream/downstream users and support sponsors exchange realistic responsibilities and closure information.

**Lifecycle cost and retirement condition.** This is the cheap path itself; review existing signals rather than create permanent change machinery. Respect finite maintainer capacity; retire unsupported commitments explicitly, and preserve only what has a justified future consumer.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S013; ESME-S008; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S008; ESME-S029; Reason: Analytical deduction from scoped evolution and lifecycle economics: unchanged code can still become unfit if environment or support changes.

**Transferability.** Assessment: CONDITIONAL; Reason: The environment and obligations remain sufficiently stable; no ignored known breach exists. What concrete obligation or expected benefit warrants disturbing the current useful state?

**Source IDs:** ESME-S009, ESME-S013, ESME-S055, ESME-S058, ESME-S008, ESME-S029. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What concrete obligation or expected benefit warrants disturbing the current useful state?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-076 — Generated patches remain candidates for justified repair

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; AUTOMATION_ACCEPTANCE_CRITERION

**Mature form.** Automation supplies proposals, not a new epistemic or operative authority.

**Controlled failure.** Source-supported: both classical and LLM repair show oracle/harness and requirement weaknesses.

**Operating mechanism.** Treat the patch as a candidate; check intended repair, preservation, unsupported changes and uncertainty before acceptance.

**Trigger.** A repair or evolution suggestion is generated by a search system, model or agent.

**Non-trigger and cheap path.** A direct human correction may dominate; use the same substantive obligations regardless of who authored the patch.

**Prerequisites.** Conditions: The objective is legitimate and validation is not solely the generator’s own assertion.; Related property ids: ESME-001; ESME-035; ESME-077; ESME-079; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Maintainer accepting the repair and affected consumers.; Decision: Accepted claims identify repaired obligations and residual uncertainty; unsupported additions are removed or authorised.

**Authority and practical action.** Actors: Maintainer accepting the repair and affected consumers.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Accepted claims identify repaired obligations and residual uncertainty; unsupported additions are removed or authorised. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S034; ESME-S063; ESME-S064; Adjudication: Source-supported: both classical and LLM repair show oracle/harness and requirement weaknesses.; Effect on disposition: Automation supplies proposals, not a new epistemic or operative authority.

**Anti-ceremony boundary.** Essential: Accepted claims identify repaired obligations and residual uncertainty; unsupported additions are removed or authorised.; Minimal alternative: A direct human correction may dominate; use the same substantive obligations regardless of who authored the patch.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A direct human correction may dominate; use the same substantive obligations regardless of who authored the patch. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T04; Discriminator: Compare accepted outcomes and total work, including later repair, on representative tasks under versioned settings.; Hybrid failure: Several tools share one invalid oracle, or the human rubber-stamps unreviewable volume.

**Composition coupling.** ESME-R026; ESME-R027; ESME-R046; ESME-R048

#### Domain profile

**Change intent and change class.** A repair or evolution suggestion is generated by a search system, model or agent. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Baseline and affected artefacts.** Generated diff, issue interpretation, tests, harness and environment. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Preservation obligation and observer.** Maintainer accepting the repair and affected consumers. Correctness follows justified requirements and relevant observations, not necessarily identity to one reference patch.

**Impact boundary and dependency evidence.** Repository, model/data/configuration and concurrent-change dependencies exceed isolated-function benchmarks.

**Comprehension assumptions.** The objective is legitimate and validation is not solely the generator’s own assertion. Automation may redistribute comprehension and review work; record what humans and tools actually inspected.

**Oracle and regression limits.** Weak tests, contaminated history, issue/PR mismatch and manual uncertainty constrain benchmark and patch claims.

**Compatibility and migration preconditions.** Generated or learned-component changes still owe the applicable interface, schema and version-combination obligations.

**Release rollback or forward repair condition.** Tools have no intrinsic deployment authority; actual effects must retain justified containment, restoration or forward-repair choices.

**Maintainer and downstream consumers.** Maintainers and reviewers receive proposed changes, assumptions and counterevidence; affected stakeholders resolve unclear objectives.

**Lifecycle cost and retirement condition.** A direct human correction may dominate; use the same substantive obligations regardless of who authored the patch. Measure total work and compute over an appropriate horizon; discontinue assistance when its net payoff or evidence boundary deteriorates.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S034; ESME-S035; ESME-S063; ESME-S064; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S034; ESME-S063; ESME-S064; Reason: Source-supported: both classical and LLM repair show oracle/harness and requirement weaknesses.

**Transferability.** Assessment: CONDITIONAL; Reason: The objective is legitimate and validation is not solely the generator’s own assertion. Which part of this patch is unsupported by the requested change or preservation evidence?

**Source IDs:** ESME-S034, ESME-S035, ESME-S063, ESME-S064. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which part of this patch is unsupported by the requested change or preservation evidence?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-077 — Validation of the evaluation harness itself

**Disposition and kind.** STRONGLY_RETAINED; EVIDENCE_PRODUCTION_ASSURANCE

**Mature form.** Evidence production is validated separately from the candidate implementation.

**Controlled failure.** Source-supported: APR reanalysis and RTSCheck found faulty evaluation/selection behaviour; even reproducibility tooling needed corrections.

**Operating mechanism.** Check that tests actually execute against the intended version, inputs and result criteria; challenge known failure/success controls and broken dependency assumptions.

**Trigger.** A harness is new, changed, migrated or relied on for a consequential acceptance claim.

**Non-trigger and cheap path.** A simple transparent command with known checks may need only a small sanity test rather than a framework audit.

**Prerequisites.** Conditions: Observability includes test execution and failures, not merely process completion.; Related property ids: ESME-004; ESME-024; ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Reviewer interpreting evidence rather than trusting its producer.; Decision: The harness distinguishes relevant known pass/fail controls and binds results to the intended artefact.

**Authority and practical action.** Actors: Reviewer interpreting evidence rather than trusting its producer.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The harness distinguishes relevant known pass/fail controls and binds results to the intended artefact. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S024; ESME-S034; ESME-S063; Adjudication: Source-supported: APR reanalysis and RTSCheck found faulty evaluation/selection behaviour; even reproducibility tooling needed corrections.; Effect on disposition: Evidence production is validated separately from the candidate implementation.

**Anti-ceremony boundary.** Essential: The harness distinguishes relevant known pass/fail controls and binds results to the intended artefact.; Minimal alternative: A simple transparent command with known checks may need only a small sanity test rather than a framework audit.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A simple transparent command with known checks may need only a small sanity test rather than a framework audit. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T04; Discriminator: Compare accepted outcomes and total work, including later repair, on representative tasks under versioned settings.; Hybrid failure: Several tools share one invalid oracle, or the human rubber-stamps unreviewable volume.

**Composition coupling.** ESME-R020; ESME-R026; ESME-R046

#### Domain profile

**Change intent and change class.** A harness is new, changed, migrated or relied on for a consequential acceptance claim. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Baseline and affected artefacts.** Execution harness, environment, selected tests, exit conditions and recorded results. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Preservation obligation and observer.** Reviewer interpreting evidence rather than trusting its producer. Correctness follows justified requirements and relevant observations, not necessarily identity to one reference patch.

**Impact boundary and dependency evidence.** Repository, model/data/configuration and concurrent-change dependencies exceed isolated-function benchmarks.

**Comprehension assumptions.** Observability includes test execution and failures, not merely process completion. Automation may redistribute comprehension and review work; record what humans and tools actually inspected.

**Oracle and regression limits.** Weak tests, contaminated history, issue/PR mismatch and manual uncertainty constrain benchmark and patch claims.

**Compatibility and migration preconditions.** Generated or learned-component changes still owe the applicable interface, schema and version-combination obligations.

**Release rollback or forward repair condition.** Tools have no intrinsic deployment authority; actual effects must retain justified containment, restoration or forward-repair choices.

**Maintainer and downstream consumers.** Maintainers and reviewers receive proposed changes, assumptions and counterevidence; affected stakeholders resolve unclear objectives.

**Lifecycle cost and retirement condition.** A simple transparent command with known checks may need only a small sanity test rather than a framework audit. Measure total work and compute over an appropriate horizon; discontinue assistance when its net payoff or evidence boundary deteriorates.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S024; ESME-S034; ESME-S035; ESME-S052; ESME-S063; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S024; ESME-S034; ESME-S063; Reason: Source-supported: APR reanalysis and RTSCheck found faulty evaluation/selection behaviour; even reproducibility tooling needed corrections.

**Transferability.** Assessment: CONDITIONAL; Reason: Observability includes test execution and failures, not merely process completion. Could a skipped test, stale binary or harness exception still produce this reported pass?

**Source IDs:** ESME-S024, ESME-S034, ESME-S035, ESME-S052, ESME-S063. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Could a skipped test, stale binary or harness exception still produce this reported pass?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-078 — Benchmark provenance and contamination limits

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; EVALUATION_VALIDITY_CRITERION

**Mature form.** Provenance-aware claims with independent target evidence, not a demand that all public benchmarks be discarded.

**Controlled failure.** Source-supported: selected-task contamination probes and issue/PR audits reveal validity problems; selected samples do not estimate universal prevalence.

**Operating mechanism.** Record task provenance, temporal/version scope, possible training exposure and test-oracle limits; avoid treating repeated benchmark scores as independent evidence of unseen maintenance ability.

**Trigger.** Benchmark results justify deployment claims or compare automation approaches.

**Non-trigger and cheap path.** Use a bounded private or newly authored representative task evaluation where feasible; disclose limits rather than invent clean provenance.

**Prerequisites.** Conditions: Exposure cannot generally be exhaustively audited; independence and held-out status require evidence.; Related property ids: ESME-076; ESME-077; ESME-080; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Researchers and maintainers deciding transfer from benchmark to practice.; Decision: Evaluation conclusions distinguish the observed benchmark result from uncertain transfer and contamination.

**Authority and practical action.** Actors: Researchers and maintainers deciding transfer from benchmark to practice.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Evaluation conclusions distinguish the observed benchmark result from uncertain transfer and contamination. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S065; Adjudication: Source-supported: selected-task contamination probes and issue/PR audits reveal validity problems; selected samples do not estimate universal prevalence.; Effect on disposition: Provenance-aware claims with independent target evidence, not a demand that all public benchmarks be discarded.

**Anti-ceremony boundary.** Essential: Evaluation conclusions distinguish the observed benchmark result from uncertain transfer and contamination.; Minimal alternative: Use a bounded private or newly authored representative task evaluation where feasible; disclose limits rather than invent clean provenance.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Use a bounded private or newly authored representative task evaluation where feasible; disclose limits rather than invent clean provenance. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R027; ESME-R046

#### Domain profile

**Change intent and change class.** Benchmark results justify deployment claims or compare automation approaches. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Baseline and affected artefacts.** Benchmark tasks, public history, model versions and evaluation settings. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Preservation obligation and observer.** Researchers and maintainers deciding transfer from benchmark to practice. Correctness follows justified requirements and relevant observations, not necessarily identity to one reference patch.

**Impact boundary and dependency evidence.** Repository, model/data/configuration and concurrent-change dependencies exceed isolated-function benchmarks.

**Comprehension assumptions.** Exposure cannot generally be exhaustively audited; independence and held-out status require evidence. Automation may redistribute comprehension and review work; record what humans and tools actually inspected.

**Oracle and regression limits.** Weak tests, contaminated history, issue/PR mismatch and manual uncertainty constrain benchmark and patch claims.

**Compatibility and migration preconditions.** Generated or learned-component changes still owe the applicable interface, schema and version-combination obligations.

**Release rollback or forward repair condition.** Tools have no intrinsic deployment authority; actual effects must retain justified containment, restoration or forward-repair choices.

**Maintainer and downstream consumers.** Maintainers and reviewers receive proposed changes, assumptions and counterevidence; affected stakeholders resolve unclear objectives.

**Lifecycle cost and retirement condition.** Use a bounded private or newly authored representative task evaluation where feasible; disclose limits rather than invent clean provenance. Measure total work and compute over an appropriate horizon; discontinue assistance when its net payoff or evidence boundary deteriorates.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S035; ESME-S063; ESME-S064; ESME-S065; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S065; Reason: Source-supported: selected-task contamination probes and issue/PR audits reveal validity problems; selected samples do not estimate universal prevalence.

**Transferability.** Assessment: CONDITIONAL; Reason: Exposure cannot generally be exhaustively audited; independence and held-out status require evidence. What establishes that this score reflects the kind of unseen task and workflow at issue?

**Source IDs:** ESME-S035, ESME-S063, ESME-S064, ESME-S065. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What establishes that this score reflects the kind of unseen task and workflow at issue?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-079 — Issue, reference patch and test objective alignment

**Disposition and kind.** STRONGLY_RETAINED; ORACLE_AND_INTENT_VALIDATION

**Mature form.** Reference patches are fallible evidence whose authority must be established.

**Controlled failure.** Source-supported: 2026 misalignment and correctness studies find genuine ambiguity; author consensus is not universal ground truth.

**Operating mechanism.** Compare the stated requirement, reference change and acceptance tests; adjudicate mismatches before using them to judge another implementation.

**Trigger.** Generated repair, benchmark construction or legacy acceptance relies on a reference patch as expected truth.

**Non-trigger and cheap path.** A precise issue and focused test can suffice; no LLM checker is inherently required.

**Prerequisites.** Conditions: Access to enough intent and relevant baseline is needed; otherwise preserve uncertainty.; Related property ids: ESME-001; ESME-034; ESME-035; ESME-039; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Legitimate requester/maintainer, not an automatically privileged reference implementation.; Decision: Differences are classified as required, permitted, irrelevant, erroneous or unresolved with reasons.

**Authority and practical action.** Actors: Legitimate requester/maintainer, not an automatically privileged reference implementation.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Differences are classified as required, permitted, irrelevant, erroneous or unresolved with reasons. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S063; ESME-S064; Adjudication: Source-supported: 2026 misalignment and correctness studies find genuine ambiguity; author consensus is not universal ground truth.; Effect on disposition: Reference patches are fallible evidence whose authority must be established.

**Anti-ceremony boundary.** Essential: Differences are classified as required, permitted, irrelevant, erroneous or unresolved with reasons.; Minimal alternative: A precise issue and focused test can suffice; no LLM checker is inherently required.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A precise issue and focused test can suffice; no LLM checker is inherently required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T04; Discriminator: Compare accepted outcomes and total work, including later repair, on representative tasks under versioned settings.; Hybrid failure: Several tools share one invalid oracle, or the human rubber-stamps unreviewable volume.

**Composition coupling.** ESME-R018; ESME-R027; ESME-R035; ESME-R042; ESME-R046

#### Domain profile

**Change intent and change class.** Generated repair, benchmark construction or legacy acceptance relies on a reference patch as expected truth. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Baseline and affected artefacts.** Issue statement, reference PR, changed tests and alternative patches. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Preservation obligation and observer.** Legitimate requester/maintainer, not an automatically privileged reference implementation. Correctness follows justified requirements and relevant observations, not necessarily identity to one reference patch.

**Impact boundary and dependency evidence.** Repository, model/data/configuration and concurrent-change dependencies exceed isolated-function benchmarks.

**Comprehension assumptions.** Access to enough intent and relevant baseline is needed; otherwise preserve uncertainty. Automation may redistribute comprehension and review work; record what humans and tools actually inspected.

**Oracle and regression limits.** Weak tests, contaminated history, issue/PR mismatch and manual uncertainty constrain benchmark and patch claims.

**Compatibility and migration preconditions.** Generated or learned-component changes still owe the applicable interface, schema and version-combination obligations.

**Release rollback or forward repair condition.** Tools have no intrinsic deployment authority; actual effects must retain justified containment, restoration or forward-repair choices.

**Maintainer and downstream consumers.** Maintainers and reviewers receive proposed changes, assumptions and counterevidence; affected stakeholders resolve unclear objectives.

**Lifecycle cost and retirement condition.** A precise issue and focused test can suffice; no LLM checker is inherently required. Measure total work and compute over an appropriate horizon; discontinue assistance when its net payoff or evidence boundary deteriorates.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S035; ESME-S063; ESME-S064; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S063; ESME-S064; Reason: Source-supported: 2026 misalignment and correctness studies find genuine ambiguity; author consensus is not universal ground truth.

**Transferability.** Assessment: CONDITIONAL; Reason: Access to enough intent and relevant baseline is needed; otherwise preserve uncertainty. Which test expectation is justified by the requirement rather than merely copied from the reference patch?

**Source IDs:** ESME-S035, ESME-S063, ESME-S064. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which test expectation is justified by the requirement rather than merely copied from the reference patch?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-080 — Total human–automation workflow cost

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; EMPIRICAL_SELECTION_CRITERION

**Mature form.** Conditional workflow evaluation instead of universal AI productivity claims.

**Controlled failure.** Source-supported: 2025 randomised expert study found slower work; 2026 follow-up was judged unreliable due to selection/measurement, not a settled reversal.

**Operating mechanism.** Measure the end-to-end effort, latency, quality and resource costs relevant to the actual workflow against credible human/tool-assisted alternatives.

**Trigger.** Automation adoption is justified as saving maintenance effort or increasing useful output.

**Non-trigger and cheap path.** A small representative paired trial or observed task sample may suffice; no grand benchmark is required.

**Prerequisites.** Conditions: Task selection, experience, tooling, concurrency and quality standards are comparable.; Related property ids: ESME-058; ESME-066; ESME-076; ESME-078; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Maintainers and sponsors bearing both visible and shifted costs.; Decision: The benefit claim includes relevant total work and uncertainty rather than generation speed alone.

**Authority and practical action.** Actors: Maintainers and sponsors bearing both visible and shifted costs.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The benefit claim includes relevant total work and uncertainty rather than generation speed alone. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S036; ESME-S037; ESME-S063; ESME-S064; Adjudication: Source-supported: 2025 randomised expert study found slower work; 2026 follow-up was judged unreliable due to selection/measurement, not a settled reversal.; Effect on disposition: Conditional workflow evaluation instead of universal AI productivity claims.

**Anti-ceremony boundary.** Essential: The benefit claim includes relevant total work and uncertainty rather than generation speed alone.; Minimal alternative: A small representative paired trial or observed task sample may suffice; no grand benchmark is required.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A small representative paired trial or observed task sample may suffice; no grand benchmark is required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T04; Discriminator: Compare accepted outcomes and total work, including later repair, on representative tasks under versioned settings.; Hybrid failure: Several tools share one invalid oracle, or the human rubber-stamps unreviewable volume.

**Composition coupling.** ESME-R027; ESME-R046; ESME-R048

#### Domain profile

**Change intent and change class.** Automation adoption is justified as saving maintenance effort or increasing useful output. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Baseline and affected artefacts.** Human tasks, model calls, review effort, compute and accepted outcomes. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Preservation obligation and observer.** Maintainers and sponsors bearing both visible and shifted costs. Correctness follows justified requirements and relevant observations, not necessarily identity to one reference patch.

**Impact boundary and dependency evidence.** Repository, model/data/configuration and concurrent-change dependencies exceed isolated-function benchmarks.

**Comprehension assumptions.** Task selection, experience, tooling, concurrency and quality standards are comparable. Automation may redistribute comprehension and review work; record what humans and tools actually inspected.

**Oracle and regression limits.** Weak tests, contaminated history, issue/PR mismatch and manual uncertainty constrain benchmark and patch claims.

**Compatibility and migration preconditions.** Generated or learned-component changes still owe the applicable interface, schema and version-combination obligations.

**Release rollback or forward repair condition.** Tools have no intrinsic deployment authority; actual effects must retain justified containment, restoration or forward-repair choices.

**Maintainer and downstream consumers.** Maintainers and reviewers receive proposed changes, assumptions and counterevidence; affected stakeholders resolve unclear objectives.

**Lifecycle cost and retirement condition.** A small representative paired trial or observed task sample may suffice; no grand benchmark is required. Measure total work and compute over an appropriate horizon; discontinue assistance when its net payoff or evidence boundary deteriorates.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S036; ESME-S037; ESME-S039; ESME-S063; ESME-S064; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S036; ESME-S037; ESME-S063; ESME-S064; Reason: Source-supported: 2025 randomised expert study found slower work; 2026 follow-up was judged unreliable due to selection/measurement, not a settled reversal.

**Transferability.** Assessment: CONDITIONAL; Reason: Task selection, experience, tooling, concurrency and quality standards are comparable. Which effort disappears from the metric but still has to be performed by someone?

**Source IDs:** ESME-S036, ESME-S037, ESME-S039, ESME-S063, ESME-S064. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which effort disappears from the metric but still has to be performed by someone?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-081 — Version-bound automation evidence and revalidation

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; EVIDENCE_MAINTENANCE_MECHANISM

**Mature form.** Evidence has an applicability envelope, not a permanent tool certification.

**Controlled failure.** Source-supported: prompt effects age and quantisation has nontrivial trade-offs; accepted 2026 preprints are not long-term replications.

**Operating mechanism.** Bind automation evidence to the model/tool, configuration, prompts, hardware and task envelope; recheck changed assumptions before reusing the claim.

**Trigger.** A model, engine, prompt strategy, hardware or evaluation context changes in a way relevant to prior evidence.

**Non-trigger and cheap path.** Do not rerun everything for an irrelevant metadata change; use targeted revalidation of affected claims.

**Prerequisites.** Conditions: Version identity and affected assumptions are observable.; Related property ids: ESME-004; ESME-030; ESME-077; ESME-080; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Maintainer relying on the tool’s prior effectiveness or preservation claims.; Decision: Reused evidence states why its assumptions still hold; affected claims are revalidated or narrowed.

**Authority and practical action.** Actors: Maintainer relying on the tool’s prior effectiveness or preservation claims.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Reused evidence states why its assumptions still hold; affected claims are revalidated or narrowed. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S037; ESME-S038; Adjudication: Source-supported: prompt effects age and quantisation has nontrivial trade-offs; accepted 2026 preprints are not long-term replications.; Effect on disposition: Evidence has an applicability envelope, not a permanent tool certification.

**Anti-ceremony boundary.** Essential: Reused evidence states why its assumptions still hold; affected claims are revalidated or narrowed.; Minimal alternative: Do not rerun everything for an irrelevant metadata change; use targeted revalidation of affected claims.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Do not rerun everything for an irrelevant metadata change; use targeted revalidation of affected claims. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T04; Discriminator: Compare accepted outcomes and total work, including later repair, on representative tasks under versioned settings.; Hybrid failure: Several tools share one invalid oracle, or the human rubber-stamps unreviewable volume.

**Composition coupling.** ESME-R027; ESME-R028; ESME-R031; ESME-R046

#### Domain profile

**Change intent and change class.** A model, engine, prompt strategy, hardware or evaluation context changes in a way relevant to prior evidence. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Baseline and affected artefacts.** Automation configuration and supporting evaluation evidence. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Preservation obligation and observer.** Maintainer relying on the tool’s prior effectiveness or preservation claims. Correctness follows justified requirements and relevant observations, not necessarily identity to one reference patch.

**Impact boundary and dependency evidence.** Repository, model/data/configuration and concurrent-change dependencies exceed isolated-function benchmarks.

**Comprehension assumptions.** Version identity and affected assumptions are observable. Automation may redistribute comprehension and review work; record what humans and tools actually inspected.

**Oracle and regression limits.** Weak tests, contaminated history, issue/PR mismatch and manual uncertainty constrain benchmark and patch claims.

**Compatibility and migration preconditions.** Generated or learned-component changes still owe the applicable interface, schema and version-combination obligations.

**Release rollback or forward repair condition.** Tools have no intrinsic deployment authority; actual effects must retain justified containment, restoration or forward-repair choices.

**Maintainer and downstream consumers.** Maintainers and reviewers receive proposed changes, assumptions and counterevidence; affected stakeholders resolve unclear objectives.

**Lifecycle cost and retirement condition.** Do not rerun everything for an irrelevant metadata change; use targeted revalidation of affected claims. Measure total work and compute over an appropriate horizon; discontinue assistance when its net payoff or evidence boundary deteriorates.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S038; ESME-S039; ESME-S045; ESME-S037; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S037; ESME-S038; Reason: Source-supported: prompt effects age and quantisation has nontrivial trade-offs; accepted 2026 preprints are not long-term replications.

**Transferability.** Assessment: CONDITIONAL; Reason: Version identity and affected assumptions are observable. Which previously valid claim depends on an assumption changed by this upgrade?

**Source IDs:** ESME-S038, ESME-S039, ESME-S045, ESME-S037. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which previously valid claim depends on an assumption changed by this upgrade?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-082 — Repair automation resource trade-offs

**Disposition and kind.** DOMAIN_SPECIFIC; RESOURCE_SELECTION_CRITERION

**Mature form.** Domain-specific, measured trade-offs; no universal small-model superiority.

**Controlled failure.** Source-supported: 2026 preprint finds non-monotonic trade-offs and differing repaired-case sets; two datasets limit transfer.

**Operating mechanism.** Choose model/quantisation settings by relevant repair quality and measured total resource constraints, not parameter count or aggregate success alone.

**Trigger.** Resource-limited repair automation makes memory, energy or time consequential.

**Non-trigger and cheap path.** A simpler deterministic tool or human repair can dominate model tuning for a small task.

**Prerequisites.** Conditions: Measurements use the intended hardware/workload; plausible patch counts are not correctness evidence.; Related property ids: ESME-076; ESME-080; ESME-081; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Maintainer/operator constrained by compute and accepted repair quality.; Decision: The chosen configuration meets the stated resource and validated outcome constraints.

**Authority and practical action.** Actors: Maintainer/operator constrained by compute and accepted repair quality.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The chosen configuration meets the stated resource and validated outcome constraints. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S039; Adjudication: Source-supported: 2026 preprint finds non-monotonic trade-offs and differing repaired-case sets; two datasets limit transfer.; Effect on disposition: Domain-specific, measured trade-offs; no universal small-model superiority.

**Anti-ceremony boundary.** Essential: The chosen configuration meets the stated resource and validated outcome constraints.; Minimal alternative: A simpler deterministic tool or human repair can dominate model tuning for a small task.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A simpler deterministic tool or human repair can dominate model tuning for a small task. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R027

#### Domain profile

**Change intent and change class.** Resource-limited repair automation makes memory, energy or time consequential. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Baseline and affected artefacts.** Model, quantisation, hardware, repair instances and resource measurements. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Preservation obligation and observer.** Maintainer/operator constrained by compute and accepted repair quality. Correctness follows justified requirements and relevant observations, not necessarily identity to one reference patch.

**Impact boundary and dependency evidence.** Repository, model/data/configuration and concurrent-change dependencies exceed isolated-function benchmarks.

**Comprehension assumptions.** Measurements use the intended hardware/workload; plausible patch counts are not correctness evidence. Automation may redistribute comprehension and review work; record what humans and tools actually inspected.

**Oracle and regression limits.** Weak tests, contaminated history, issue/PR mismatch and manual uncertainty constrain benchmark and patch claims.

**Compatibility and migration preconditions.** Generated or learned-component changes still owe the applicable interface, schema and version-combination obligations.

**Release rollback or forward repair condition.** Tools have no intrinsic deployment authority; actual effects must retain justified containment, restoration or forward-repair choices.

**Maintainer and downstream consumers.** Maintainers and reviewers receive proposed changes, assumptions and counterevidence; affected stakeholders resolve unclear objectives.

**Lifecycle cost and retirement condition.** A simpler deterministic tool or human repair can dominate model tuning for a small task. Measure total work and compute over an appropriate horizon; discontinue assistance when its net payoff or evidence boundary deteriorates.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S039; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S039; Reason: Source-supported: 2026 preprint finds non-monotonic trade-offs and differing repaired-case sets; two datasets limit transfer.

**Transferability.** Assessment: CONDITIONAL; Reason: Measurements use the intended hardware/workload; plausible patch counts are not correctness evidence. Does equal aggregate repair count conceal failure on the cases this deployment actually needs?

**Source IDs:** ESME-S039. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Does equal aggregate repair count conceal failure on the cases this deployment actually needs?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-083 — Automated semantic-conflict detection as supplementary evidence

**Disposition and kind.** DOMAIN_SPECIFIC; CONFLICT_DETECTION_MECHANISM

**Mature form.** Complement the ESME-027 integration obligation with optional narrow automation.

**Controlled failure.** Source-supported: SAM’s local-interference detection is incomplete; build success and semantic correctness differ.

**Operating mechanism.** Use a tool for its supported conflict class; inspect positive findings and retain unobserved semantic interactions as uncertainty.

**Trigger.** Concurrent changes have plausible semantic interference that targeted automation can help expose.

**Non-trigger and cheap path.** Manual joint review and focused integration tests may be enough; clean noninteracting changes need no special tool.

**Prerequisites.** Conditions: The tool’s language, conflict and observation model fits the case.; Related property ids: ESME-027; ESME-035; ESME-077; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Contributors and maintainers reconciling jointly intended changes.; Decision: Detected interference is adjudicated against intent; absence of a warning is not a safety guarantee.

**Authority and practical action.** Actors: Contributors and maintainers reconciling jointly intended changes.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Detected interference is adjudicated against intent; absence of a warning is not a safety guarantee. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S066; Adjudication: Source-supported: SAM’s local-interference detection is incomplete; build success and semantic correctness differ.; Effect on disposition: Complement the ESME-027 integration obligation with optional narrow automation.

**Anti-ceremony boundary.** Essential: Detected interference is adjudicated against intent; absence of a warning is not a safety guarantee.; Minimal alternative: Manual joint review and focused integration tests may be enough; clean noninteracting changes need no special tool.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Manual joint review and focused integration tests may be enough; clean noninteracting changes need no special tool. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R026; ESME-R027

#### Domain profile

**Change intent and change class.** Concurrent changes have plausible semantic interference that targeted automation can help expose. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Baseline and affected artefacts.** Base/parent/merged program, generated tests or build-conflict patterns. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Preservation obligation and observer.** Contributors and maintainers reconciling jointly intended changes. Correctness follows justified requirements and relevant observations, not necessarily identity to one reference patch.

**Impact boundary and dependency evidence.** Repository, model/data/configuration and concurrent-change dependencies exceed isolated-function benchmarks.

**Comprehension assumptions.** The tool’s language, conflict and observation model fits the case. Automation may redistribute comprehension and review work; record what humans and tools actually inspected.

**Oracle and regression limits.** Weak tests, contaminated history, issue/PR mismatch and manual uncertainty constrain benchmark and patch claims.

**Compatibility and migration preconditions.** Generated or learned-component changes still owe the applicable interface, schema and version-combination obligations.

**Release rollback or forward repair condition.** Tools have no intrinsic deployment authority; actual effects must retain justified containment, restoration or forward-repair choices.

**Maintainer and downstream consumers.** Maintainers and reviewers receive proposed changes, assumptions and counterevidence; affected stakeholders resolve unclear objectives.

**Lifecycle cost and retirement condition.** Manual joint review and focused integration tests may be enough; clean noninteracting changes need no special tool. Measure total work and compute over an appropriate horizon; discontinue assistance when its net payoff or evidence boundary deteriorates.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S040; ESME-S066; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S066; Reason: Source-supported: SAM’s local-interference detection is incomplete; build success and semantic correctness differ.

**Transferability.** Assessment: CONDITIONAL; Reason: The tool’s language, conflict and observation model fits the case. What semantic interaction lies outside this tool’s definition of conflict?

**Source IDs:** ESME-S040, ESME-S066. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What semantic interaction lies outside this tool’s definition of conflict?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-084 — Learned-system data and configuration dependencies

**Disposition and kind.** DOMAIN_SPECIFIC; DOMAIN_TRANSLATED_IMPACT_MECHANISM

**Mature form.** Domain translation of baseline/impact principles, not a full ML governance method.

**Controlled failure.** Source-supported: industrial ML patterns identify debt mechanisms but not universal effect sizes; CACE is not a theorem.

**Operating mechanism.** Include data provenance, feature transformations, model versions and consequential configuration in maintenance impact and baseline reasoning.

**Trigger.** A learned component or data pipeline influences supported behaviour.

**Non-trigger and cheap path.** Ordinary code/configuration analysis is enough when no learned or changing data dependency is present.

**Prerequisites.** Conditions: Relevant data rights, lineage and model/version access are available; incompleteness is declared.; Related property ids: ESME-004; ESME-021; ESME-024; ESME-085; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Users and downstream models/components receiving predictions or decisions.; Decision: The impact claim covers relevant non-code/model dependencies or explicitly marks unknowns.

**Authority and practical action.** Actors: Users and downstream models/components receiving predictions or decisions.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The impact claim covers relevant non-code/model dependencies or explicitly marks unknowns. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S061; Adjudication: Source-supported: industrial ML patterns identify debt mechanisms but not universal effect sizes; CACE is not a theorem.; Effect on disposition: Domain translation of baseline/impact principles, not a full ML governance method.

**Anti-ceremony boundary.** Essential: The impact claim covers relevant non-code/model dependencies or explicitly marks unknowns.; Minimal alternative: Ordinary code/configuration analysis is enough when no learned or changing data dependency is present.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Ordinary code/configuration analysis is enough when no learned or changing data dependency is present. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R028

#### Domain profile

**Change intent and change class.** A learned component or data pipeline influences supported behaviour. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Baseline and affected artefacts.** Training/serving data, features, model, code, pipeline and configuration. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Preservation obligation and observer.** Users and downstream models/components receiving predictions or decisions. Correctness follows justified requirements and relevant observations, not necessarily identity to one reference patch.

**Impact boundary and dependency evidence.** Repository, model/data/configuration and concurrent-change dependencies exceed isolated-function benchmarks.

**Comprehension assumptions.** Relevant data rights, lineage and model/version access are available; incompleteness is declared. Automation may redistribute comprehension and review work; record what humans and tools actually inspected.

**Oracle and regression limits.** Weak tests, contaminated history, issue/PR mismatch and manual uncertainty constrain benchmark and patch claims.

**Compatibility and migration preconditions.** Generated or learned-component changes still owe the applicable interface, schema and version-combination obligations.

**Release rollback or forward repair condition.** Tools have no intrinsic deployment authority; actual effects must retain justified containment, restoration or forward-repair choices.

**Maintainer and downstream consumers.** Maintainers and reviewers receive proposed changes, assumptions and counterevidence; affected stakeholders resolve unclear objectives.

**Lifecycle cost and retirement condition.** Ordinary code/configuration analysis is enough when no learned or changing data dependency is present. Measure total work and compute over an appropriate horizon; discontinue assistance when its net payoff or evidence boundary deteriorates.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S061; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S061; Reason: Source-supported: industrial ML patterns identify debt mechanisms but not universal effect sizes; CACE is not a theorem.

**Transferability.** Assessment: CONDITIONAL; Reason: Relevant data rights, lineage and model/version access are available; incompleteness is declared. Which learned or data-dependent behaviour can change without a source-code edit?

**Source IDs:** ESME-S061, ESME-S005, ESME-S041. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which learned or data-dependent behaviour can change without a source-code edit?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-085 — Feedback and drift as preservation-boundary changes

**Disposition and kind.** ASSUMPTION_SENSITIVE; DOMAIN_TRANSLATED_FEEDBACK_CRITERION

**Mature form.** Assumption-sensitive feedback, with human authority retained for revised objectives.

**Controlled failure.** Source-supported conceptual warning; robust general drift thresholds and causality are not established by the inspected source.

**Operating mechanism.** Monitor the relevant data/environment and outcome assumptions; reconsider preservation and regression evidence when those assumptions shift.

**Trigger.** A learned or environment-sensitive service has a live obligation whose validity depends on changing distributions or feedback.

**Non-trigger and cheap path.** For a stable deterministic computation, ordinary version-bound regression may suffice.

**Prerequisites.** Conditions: Observation windows and criteria reflect the obligation; distributional observations do not themselves decide normative acceptability.; Related property ids: ESME-007; ESME-035; ESME-081; ESME-084; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Those affected by the model’s actual outcomes.; Decision: A material shift triggers justified re-evaluation or a narrowed claim, not automatic retraining.

**Authority and practical action.** Actors: Those affected by the model’s actual outcomes.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** A material shift triggers justified re-evaluation or a narrowed claim, not automatic retraining. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S061; ESME-S025; Adjudication: Source-supported conceptual warning; robust general drift thresholds and causality are not established by the inspected source.; Effect on disposition: Assumption-sensitive feedback, with human authority retained for revised objectives.

**Anti-ceremony boundary.** Essential: A material shift triggers justified re-evaluation or a narrowed claim, not automatic retraining.; Minimal alternative: For a stable deterministic computation, ordinary version-bound regression may suffice.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** For a stable deterministic computation, ordinary version-bound regression may suffice. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R028; ESME-R031

#### Domain profile

**Change intent and change class.** A learned or environment-sensitive service has a live obligation whose validity depends on changing distributions or feedback. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Baseline and affected artefacts.** Data distribution, model, feedback channels and accepted outcome criteria. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Preservation obligation and observer.** Those affected by the model’s actual outcomes. Correctness follows justified requirements and relevant observations, not necessarily identity to one reference patch.

**Impact boundary and dependency evidence.** Repository, model/data/configuration and concurrent-change dependencies exceed isolated-function benchmarks.

**Comprehension assumptions.** Observation windows and criteria reflect the obligation; distributional observations do not themselves decide normative acceptability. Automation may redistribute comprehension and review work; record what humans and tools actually inspected.

**Oracle and regression limits.** Weak tests, contaminated history, issue/PR mismatch and manual uncertainty constrain benchmark and patch claims.

**Compatibility and migration preconditions.** Generated or learned-component changes still owe the applicable interface, schema and version-combination obligations.

**Release rollback or forward repair condition.** Tools have no intrinsic deployment authority; actual effects must retain justified containment, restoration or forward-repair choices.

**Maintainer and downstream consumers.** Maintainers and reviewers receive proposed changes, assumptions and counterevidence; affected stakeholders resolve unclear objectives.

**Lifecycle cost and retirement condition.** For a stable deterministic computation, ordinary version-bound regression may suffice. Measure total work and compute over an appropriate horizon; discontinue assistance when its net payoff or evidence boundary deteriorates.

#### Evidence partitions

**Provenance.** Assessment: DIRECT_WITH_DECLARED_SCOPE; Reason: Attribution to inspected primary material is strong where directly accessible; exact antecedents and edition/access limits are listed below.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S061; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S061; ESME-S025; Reason: Source-supported conceptual warning; robust general drift thresholds and causality are not established by the inspected source.

**Transferability.** Assessment: CONDITIONAL; Reason: Observation windows and criteria reflect the obligation; distributional observations do not themselves decide normative acceptability. What observed environmental shift would invalidate the present acceptance evidence?

**Source IDs:** ESME-S009, ESME-S010, ESME-S061, ESME-S025. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What observed environmental shift would invalidate the present acceptance evidence?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-086 — Artefact-appropriate validation for non-code evolution

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; VALIDATION_SCOPE_CRITERION

**Mature form.** Match evidence to artefact semantics rather than apply one testing ritual everywhere.

**Controlled failure.** Source-supported: code-oriented tools omit important resources; backup and ML configurations have operative effects.

**Operating mechanism.** Choose validation that checks the meaning and consumer of the changed artefact, including its generated or runtime effects.

**Trigger.** A non-code edit can alter buildability, operation, user guidance, data semantics or model behaviour.

**Non-trigger and cheap path.** A factual documentation correction may need reader/source verification, not an entire executable test suite.

**Prerequisites.** Conditions: The artefact’s purpose and relevant effect path are understood.; Related property ids: ESME-003; ESME-021; ESME-024; ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: The actual reader, builder, runtime or downstream data consumer.; Decision: Validation addresses the artefact’s actual obligation and the effects it can propagate.

**Authority and practical action.** Actors: The actual reader, builder, runtime or downstream data consumer.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Validation addresses the artefact’s actual obligation and the effects it can propagate. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S024; ESME-S062; Adjudication: Source-supported: code-oriented tools omit important resources; backup and ML configurations have operative effects.; Effect on disposition: Match evidence to artefact semantics rather than apply one testing ritual everywhere.

**Anti-ceremony boundary.** Essential: Validation addresses the artefact’s actual obligation and the effects it can propagate.; Minimal alternative: A factual documentation correction may need reader/source verification, not an entire executable test suite.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A factual documentation correction may need reader/source verification, not an entire executable test suite. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R026

#### Domain profile

**Change intent and change class.** A non-code edit can alter buildability, operation, user guidance, data semantics or model behaviour. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Baseline and affected artefacts.** Documents, configuration, datasets, schemas, build recipes and generated outputs. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Preservation obligation and observer.** The actual reader, builder, runtime or downstream data consumer. Correctness follows justified requirements and relevant observations, not necessarily identity to one reference patch.

**Impact boundary and dependency evidence.** Repository, model/data/configuration and concurrent-change dependencies exceed isolated-function benchmarks.

**Comprehension assumptions.** The artefact’s purpose and relevant effect path are understood. Automation may redistribute comprehension and review work; record what humans and tools actually inspected.

**Oracle and regression limits.** Weak tests, contaminated history, issue/PR mismatch and manual uncertainty constrain benchmark and patch claims.

**Compatibility and migration preconditions.** Generated or learned-component changes still owe the applicable interface, schema and version-combination obligations.

**Release rollback or forward repair condition.** Tools have no intrinsic deployment authority; actual effects must retain justified containment, restoration or forward-repair choices.

**Maintainer and downstream consumers.** Maintainers and reviewers receive proposed changes, assumptions and counterevidence; affected stakeholders resolve unclear objectives.

**Lifecycle cost and retirement condition.** A factual documentation correction may need reader/source verification, not an entire executable test suite. Measure total work and compute over an appropriate horizon; discontinue assistance when its net payoff or evidence boundary deteriorates.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S001.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S024; ESME-S052; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S061; ESME-S062; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S024; ESME-S062; Reason: Source-supported: code-oriented tools omit important resources; backup and ML configurations have operative effects.

**Transferability.** Assessment: CONDITIONAL; Reason: The artefact’s purpose and relevant effect path are understood. Who or what consumes this artefact, and what evidence checks the consequence of the edit?

**Source IDs:** ESME-S001, ESME-S024, ESME-S041, ESME-S052, ESME-S061, ESME-S062. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Who or what consumes this artefact, and what evidence checks the consequence of the edit?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-089 — Deletion or degradation requires an explicit containment objective

**Disposition and kind.** DOMAIN_SPECIFIC; EMERGENCY_INTERVENTION_CRITERION

**Mature form.** Domain-specific objective separation, coupled to ESME-005 rather than a blanket prohibition on deletion.

**Controlled failure.** Source-supported: deletion can pass inadequate tests; legitimate emergency semantics differ from permanent corrective semantics.

**Operating mechanism.** Distinguish removing a required behaviour to fool an oracle from authorised containment that deliberately suspends it, with restoration or closure conditions.

**Trigger.** A proposed fix bypasses code, suppresses errors or disables functionality, especially during an incident.

**Non-trigger and cheap path.** Use a true local correction when feasible; do not invoke containment merely to obtain a passing suite.

**Prerequisites.** Conditions: The containment objective and accepted loss are explicit; tests are not allowed to redefine required service silently.; Related property ids: ESME-001; ESME-005; ESME-035; ESME-076; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Users experiencing lost capability and operator authorised to accept it.; Decision: The lost capability is either intentionally accepted under bounded conditions or the patch is rejected.

**Authority and practical action.** Actors: Users experiencing lost capability and operator authorised to accept it.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The lost capability is either intentionally accepted under bounded conditions or the patch is rejected. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S034; Adjudication: Source-supported: deletion can pass inadequate tests; legitimate emergency semantics differ from permanent corrective semantics.; Effect on disposition: Domain-specific objective separation, coupled to ESME-005 rather than a blanket prohibition on deletion.

**Anti-ceremony boundary.** Essential: The lost capability is either intentionally accepted under bounded conditions or the patch is rejected.; Minimal alternative: Use a true local correction when feasible; do not invoke containment merely to obtain a passing suite.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Use a true local correction when feasible; do not invoke containment merely to obtain a passing suite. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R029

#### Domain profile

**Change intent and change class.** A proposed fix bypasses code, suppresses errors or disables functionality, especially during an incident. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Baseline and affected artefacts.** Disabled behaviour, degraded service and temporary acceptance conditions. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.

**Preservation obligation and observer.** Users experiencing lost capability and operator authorised to accept it. Correctness follows justified requirements and relevant observations, not necessarily identity to one reference patch.

**Impact boundary and dependency evidence.** Repository, model/data/configuration and concurrent-change dependencies exceed isolated-function benchmarks.

**Comprehension assumptions.** The containment objective and accepted loss are explicit; tests are not allowed to redefine required service silently. Automation may redistribute comprehension and review work; record what humans and tools actually inspected.

**Oracle and regression limits.** Weak tests, contaminated history, issue/PR mismatch and manual uncertainty constrain benchmark and patch claims.

**Compatibility and migration preconditions.** Generated or learned-component changes still owe the applicable interface, schema and version-combination obligations.

**Release rollback or forward repair condition.** Tools have no intrinsic deployment authority; actual effects must retain justified containment, restoration or forward-repair choices.

**Maintainer and downstream consumers.** Maintainers and reviewers receive proposed changes, assumptions and counterevidence; affected stakeholders resolve unclear objectives.

**Lifecycle cost and retirement condition.** Use a true local correction when feasible; do not invoke containment merely to obtain a passing suite. Measure total work and compute over an appropriate horizon; discontinue assistance when its net payoff or evidence boundary deteriorates.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S001.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S034; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: BOUNDED; Source ids: ESME-S062; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S034; Reason: Source-supported: deletion can pass inadequate tests; legitimate emergency semantics differ from permanent corrective semantics.

**Transferability.** Assessment: CONDITIONAL; Reason: The containment objective and accepted loss are explicit; tests are not allowed to redefine required service silently. Is disabled behaviour an authorised containment trade-off or an unreported failure to implement the obligation?

**Source IDs:** ESME-S001, ESME-S034, ESME-S062. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Is disabled behaviour an authorised containment trade-off or an unreported failure to implement the obligation?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-092 — Supported-version and variant obligation matrix

**Disposition and kind.** CONTEXT_DEPENDENT; CONFIGURATION_AND_SUPPORT_MECHANISM

**Mature form.** Native configuration/support reasoning exported for later product-line reconciliation, not a borrowed sibling synthesis.

**Controlled failure.** Source-supported: configuration dimensions and bounded schema skew matter; full cross-product checking may be infeasible.

**Operating mechanism.** Identify supported releases/configurations and the obligations shared or different across them; select evidence by actual support promises and interaction risk.

**Trigger.** Several versions, build options, platforms or deployment variants remain supported.

**Non-trigger and cheap path.** One explicitly supported configuration needs no elaborate matrix; retire unsupported variants transparently.

**Prerequisites.** Conditions: The support population is explicit; interaction sampling and omissions are not confused with exhaustive coverage.; Related property ids: ESME-004; ESME-021; ESME-025; ESME-051; ESME-069; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Maintainers supporting variants and downstream users relying on declared combinations.; Decision: Evidence and limitations can be mapped to the supported combinations and obsolete obligations are retired.

**Authority and practical action.** Actors: Maintainers supporting variants and downstream users relying on declared combinations.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Evidence and limitations can be mapped to the supported combinations and obsolete obligations are retired. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S024; ESME-S049; Adjudication: Source-supported: configuration dimensions and bounded schema skew matter; full cross-product checking may be infeasible.; Effect on disposition: Native configuration/support reasoning exported for later product-line reconciliation, not a borrowed sibling synthesis.

**Anti-ceremony boundary.** Essential: Evidence and limitations can be mapped to the supported combinations and obsolete obligations are retired.; Minimal alternative: One explicitly supported configuration needs no elaborate matrix; retire unsupported variants transparently.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** One explicitly supported configuration needs no elaborate matrix; retire unsupported variants transparently. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T07; Discriminator: Determine real promises, capacity and transition feasibility; usage popularity is neither permission nor an infinite support contract.; Hybrid failure: Dates are announced without a viable path, or compatibility branches multiply beyond capacity.

**Composition coupling.** ESME-R014; ESME-R024; ESME-R033

#### Domain profile

**Change intent and change class.** Several versions, build options, platforms or deployment variants remain supported. Bound a proposed edit by the effects it may propagate, not solely by its textual size.

**Baseline and affected artefacts.** Supported releases, feature/configuration choices, platform/tool versions and consumers. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.

**Preservation obligation and observer.** Maintainers supporting variants and downstream users relying on declared combinations. A consumer can observe source, binary, semantic, persistence or protocol changes through different interfaces.

**Impact boundary and dependency evidence.** Record which dependency relations are analysed, inferred from history, dynamically observed or still unknown.

**Comprehension assumptions.** The support population is explicit; interaction sampling and omissions are not confused with exhaustive coverage. A maintainer must understand the changed relation and relevant external consumers, not necessarily every internal module.

**Oracle and regression limits.** A passing local test cannot rule out omitted dependency kinds; challenge the boundary with targeted downstream checks.

**Compatibility and migration preconditions.** Compatibility depends on declared supported versions and actual interactions, not version labels alone.

**Release rollback or forward repair condition.** Concurrent or downstream changes may invalidate a planned rollback; reevaluate actual deployment and state combinations.

**Maintainer and downstream consumers.** Upstream and downstream maintainers exchange changes, assumptions, supported versions and unresolved impact questions.

**Lifecycle cost and retirement condition.** One explicitly supported configuration needs no elaborate matrix; retire unsupported variants transparently. Prefer local analysis only with a justified boundary; retire temporary compatibility bridges and stale impact links after consumers have moved.

#### Evidence partitions

**Provenance.** Assessment: MIXED_DIRECT_AND_LIMITED; Reason: Mixed direct and mediated/partial access; historical identity is distinguished from unread original detail. See access-limited source IDs: ESME-S049.

**Theory.** Assessment: CONCEPTUAL; Reason: CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff.

**Comparative evidence.** Assessment: LIMITED_OR_MIXED; Source ids: ESME-S024; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: ABSENT; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S024; ESME-S049; Reason: Source-supported: configuration dimensions and bounded schema skew matter; full cross-product checking may be infeasible.

**Transferability.** Assessment: CONDITIONAL; Reason: The support population is explicit; interaction sampling and omissions are not confused with exhaustive coverage. Which supported combination has no relevant evidence, and can the support promise be narrowed instead?

**Source IDs:** ESME-S019, ESME-S005, ESME-S041, ESME-S049, ESME-S024. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which supported combination has no relevant evidence, and can the support promise be narrowed instead?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-093 — Composition-induced change–obligation contract

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; ANALYTICAL_COMPOSITION_INVARIANT

**Mature form.** Retained in evolved form as a minimal coupling constraint, not a new academic doctrine or mandatory artefact.

**Controlled failure.** Analytical: the combined contract can become costly bureaucracy and is not empirically validated as a whole.

**Operating mechanism.** Bind a decision to a specific baseline, authorised desired difference, preserved observations, impact scope and acceptance evidence; change any element only with an explicit compatibility check.

**Trigger.** Several otherwise sound maintenance mechanisms could be acting on different versions or meanings of success.

**Non-trigger and cheap path.** For a local task, one concise issue with linked baseline and tests can carry the contract; no new schema or formal document is mandatory.

**Prerequisites.** Conditions: Constituent claims are meaningful and compatible; a document cannot create missing authority or oracle evidence.; Related property ids: ESME-001; ESME-004; ESME-021; ESME-028; ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Those authorising, implementing and accepting the same intervention.; Decision: Every consequential acceptance claim can be traced to the same declared change and baseline or an explicit revision.

**Authority and practical action.** Actors: Those authorising, implementing and accepting the same intervention.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Every consequential acceptance claim can be traced to the same declared change and baseline or an explicit revision. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S063; ESME-S064; Adjudication: Analytical: the combined contract can become costly bureaucracy and is not empirically validated as a whole.; Effect on disposition: Retained in evolved form as a minimal coupling constraint, not a new academic doctrine or mandatory artefact.

**Anti-ceremony boundary.** Essential: Every consequential acceptance claim can be traced to the same declared change and baseline or an explicit revision.; Minimal alternative: For a local task, one concise issue with linked baseline and tests can carry the contract; no new schema or formal document is mandatory.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** For a local task, one concise issue with linked baseline and tests can carry the contract; no new schema or formal document is mandatory. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R030; ESME-R035

#### Domain profile

**Change intent and change class.** Several otherwise sound maintenance mechanisms could be acting on different versions or meanings of success. Reconcile change intent, preservation, evidence and lifecycle choices rather than requiring every source technique simultaneously.

**Baseline and affected artefacts.** Baseline, change objective, preservation set, affected consumers and evidence bindings. Treat artefacts, environments, consumers, obligations, evidence assumptions and effect history as coupled state.

**Preservation obligation and observer.** Those authorising, implementing and accepting the same intervention. Each invariant names its observer and authorised exceptions; the synthesis supplies no new stakeholder authority.

**Impact boundary and dependency evidence.** An impact or environmental change can invalidate evidence previously adequate for another state.

**Comprehension assumptions.** Constituent claims are meaningful and compatible; a document cannot create missing authority or oracle evidence. A coherent account requires only the understanding needed to justify its current decisions; fuller models have explicit triggers.

**Oracle and regression limits.** Composed evidence is not stronger than its missing oracle or invalid assumptions; declare conflicts and failed observations.

**Compatibility and migration preconditions.** Acceptance must cover intermediate coexistence states and supported variants wherever those are actual obligations.

**Release rollback or forward repair condition.** Actions cross different recoverability boundaries; accepted irreversibility needs explicit authority and compensating/forward conditions.

**Maintainer and downstream consumers.** Actors exchange actionable obligations, evidence, changes and limitations; distinctions, authority, action and achieved consequences remain separate.

**Lifecycle cost and retirement condition.** For a local task, one concise issue with linked baseline and tests can carry the contract; no new schema or formal document is mandatory. Each control needs a consumer and stopping condition; no-change and retirement are first-class branches; the combined system has no comparative validation yet.

#### Evidence partitions

**Provenance.** Assessment: ANALYTICAL; Reason: Analytical synthesis on 2026-09-06; supporting antecedents are independently listed, not claimed to name this compound property.

**Theory.** Assessment: ANALYTICAL; Reason: RESEARCHER_INTERPRETATION: relational necessity and boundary argument, not an established theorem or empirical validation of the compound system.

**Comparative evidence.** Assessment: ABSENT_FOR_COMPOSED_MECHANISM; Source ids: ESME-S063; ESME-S064; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: PARTIAL_ANTECEDENT_EVIDENCE_ONLY; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S063; ESME-S064; Reason: Analytical: the combined contract can become costly bureaucracy and is not empirically validated as a whole.

**Transferability.** Assessment: UNVALIDATED_AS_A_COMBINED_SYSTEM; Reason: Constituent claims are meaningful and compatible; a document cannot create missing authority or oracle evidence. Are all participants actually judging the same change, baseline and preservation obligations?

**Source IDs:** ESME-S001, ESME-S019, ESME-S022, ESME-S025, ESME-S041, ESME-S063, ESME-S064. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Are all participants actually judging the same change, baseline and preservation obligations?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-094 — Composition-induced assumption-indexed evidence invalidation

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; ANALYTICAL_FEEDBACK_INVARIANT

**Mature form.** Retained as targeted evidence maintenance with an explicit relevance threshold.

**Controlled failure.** Analytical: tracing all assumptions can be unbounded; overly broad invalidation can stall maintenance.

**Operating mechanism.** Associate consequential evidence with the assumptions it needs, and revisit only affected claims when intent, baseline, tool, consumer or environment changes.

**Trigger.** A composed system reuses earlier evidence after a potentially relevant change elsewhere.

**Non-trigger and cheap path.** A direct note that the dependency is unchanged may suffice; no universal dependency database is required.

**Prerequisites.** Conditions: Dependencies between assumptions and claims are sufficiently known; unknowns remain explicit.; Related property ids: ESME-004; ESME-021; ESME-035; ESME-051; ESME-081; ESME-085; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Maintainer or acceptor reusing prior results.; Decision: Reused evidence has an applicability reason, and invalidated claims are rechecked, narrowed or withdrawn.

**Authority and practical action.** Actors: Maintainer or acceptor reusing prior results.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Reused evidence has an applicability reason, and invalidated claims are rechecked, narrowed or withdrawn. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S024; ESME-S038; ESME-S063; Adjudication: Analytical: tracing all assumptions can be unbounded; overly broad invalidation can stall maintenance.; Effect on disposition: Retained as targeted evidence maintenance with an explicit relevance threshold.

**Anti-ceremony boundary.** Essential: Reused evidence has an applicability reason, and invalidated claims are rechecked, narrowed or withdrawn.; Minimal alternative: A direct note that the dependency is unchanged may suffice; no universal dependency database is required.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A direct note that the dependency is unchanged may suffice; no universal dependency database is required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R031

#### Domain profile

**Change intent and change class.** A composed system reuses earlier evidence after a potentially relevant change elsewhere. Reconcile change intent, preservation, evidence and lifecycle choices rather than requiring every source technique simultaneously.

**Baseline and affected artefacts.** Evidence claims and their baseline, environment, observer and tool assumptions. Treat artefacts, environments, consumers, obligations, evidence assumptions and effect history as coupled state.

**Preservation obligation and observer.** Maintainer or acceptor reusing prior results. Each invariant names its observer and authorised exceptions; the synthesis supplies no new stakeholder authority.

**Impact boundary and dependency evidence.** An impact or environmental change can invalidate evidence previously adequate for another state.

**Comprehension assumptions.** Dependencies between assumptions and claims are sufficiently known; unknowns remain explicit. A coherent account requires only the understanding needed to justify its current decisions; fuller models have explicit triggers.

**Oracle and regression limits.** Composed evidence is not stronger than its missing oracle or invalid assumptions; declare conflicts and failed observations.

**Compatibility and migration preconditions.** Acceptance must cover intermediate coexistence states and supported variants wherever those are actual obligations.

**Release rollback or forward repair condition.** Actions cross different recoverability boundaries; accepted irreversibility needs explicit authority and compensating/forward conditions.

**Maintainer and downstream consumers.** Actors exchange actionable obligations, evidence, changes and limitations; distinctions, authority, action and achieved consequences remain separate.

**Lifecycle cost and retirement condition.** A direct note that the dependency is unchanged may suffice; no universal dependency database is required. Each control needs a consumer and stopping condition; no-change and retirement are first-class branches; the combined system has no comparative validation yet.

#### Evidence partitions

**Provenance.** Assessment: ANALYTICAL; Reason: Analytical synthesis on 2026-09-06; supporting antecedents are independently listed, not claimed to name this compound property.

**Theory.** Assessment: ANALYTICAL; Reason: RESEARCHER_INTERPRETATION: relational necessity and boundary argument, not an established theorem or empirical validation of the compound system.

**Comparative evidence.** Assessment: ABSENT_FOR_COMPOSED_MECHANISM; Source ids: ESME-S024; ESME-S038; ESME-S063; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: PARTIAL_ANTECEDENT_EVIDENCE_ONLY; Source ids: ESME-S051; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S024; ESME-S038; ESME-S063; Reason: Analytical: tracing all assumptions can be unbounded; overly broad invalidation can stall maintenance.

**Transferability.** Assessment: UNVALIDATED_AS_A_COMBINED_SYSTEM; Reason: Dependencies between assumptions and claims are sufficiently known; unknowns remain explicit. Which prior conclusion ceases to be warranted because this assumption changed?

**Source IDs:** ESME-S019, ESME-S024, ESME-S038, ESME-S049, ESME-S051, ESME-S063. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. Which prior conclusion ceases to be warranted because this assumption changed?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-095 — Composition-induced effect-relative returnability frontier

**Disposition and kind.** ASSUMPTION_SENSITIVE; ANALYTICAL_TRANSITION_INVARIANT

**Mature form.** Assumption-sensitive relational property, not a new proof of distributed recovery.

**Controlled failure.** Analytical: unobserved external effects can make the frontier incomplete; a complete formal model is not claimed.

**Operating mechanism.** Track which recovery options remain valid after each consequential transition; before crossing an irreversible boundary, require accepted loss and feasible containment or forward action.

**Trigger.** A migration or release changes the state so a previously valid recovery route no longer applies.

**Non-trigger and cheap path.** A single reversible edit needs only one verified return path; no global state machine is required.

**Prerequisites.** Conditions: The relevant effects and feasibility of recovery options are known well enough to support the decision.; Related property ids: ESME-004; ESME-044; ESME-050; ESME-051; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Operator and consumers whose state may be irreversibly changed.; Decision: Before a boundary is crossed, the remaining options and accepted irreversibility are explicit and evidenced.

**Authority and practical action.** Actors: Operator and consumers whose state may be irreversibly changed.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Before a boundary is crossed, the remaining options and accepted irreversibility are explicit and evidenced. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S049; ESME-S062; Adjudication: Analytical: unobserved external effects can make the frontier incomplete; a complete formal model is not claimed.; Effect on disposition: Assumption-sensitive relational property, not a new proof of distributed recovery.

**Anti-ceremony boundary.** Essential: Before a boundary is crossed, the remaining options and accepted irreversibility are explicit and evidenced.; Minimal alternative: A single reversible edit needs only one verified return path; no global state machine is required.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A single reversible edit needs only one verified return path; no global state machine is required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R015; ESME-R032

#### Domain profile

**Change intent and change class.** A migration or release changes the state so a previously valid recovery route no longer applies. Reconcile change intent, preservation, evidence and lifecycle choices rather than requiring every source technique simultaneously.

**Baseline and affected artefacts.** Transition sequence, persistent/external effects and available recovery actions. Treat artefacts, environments, consumers, obligations, evidence assumptions and effect history as coupled state.

**Preservation obligation and observer.** Operator and consumers whose state may be irreversibly changed. Each invariant names its observer and authorised exceptions; the synthesis supplies no new stakeholder authority.

**Impact boundary and dependency evidence.** An impact or environmental change can invalidate evidence previously adequate for another state.

**Comprehension assumptions.** The relevant effects and feasibility of recovery options are known well enough to support the decision. A coherent account requires only the understanding needed to justify its current decisions; fuller models have explicit triggers.

**Oracle and regression limits.** Composed evidence is not stronger than its missing oracle or invalid assumptions; declare conflicts and failed observations.

**Compatibility and migration preconditions.** Acceptance must cover intermediate coexistence states and supported variants wherever those are actual obligations.

**Release rollback or forward repair condition.** Actions cross different recoverability boundaries; accepted irreversibility needs explicit authority and compensating/forward conditions.

**Maintainer and downstream consumers.** Actors exchange actionable obligations, evidence, changes and limitations; distinctions, authority, action and achieved consequences remain separate.

**Lifecycle cost and retirement condition.** A single reversible edit needs only one verified return path; no global state machine is required. Each control needs a consumer and stopping condition; no-change and retirement are first-class branches; the combined system has no comparative validation yet.

#### Evidence partitions

**Provenance.** Assessment: ANALYTICAL; Reason: Analytical synthesis on 2026-09-06; supporting antecedents are independently listed, not claimed to name this compound property.

**Theory.** Assessment: ANALYTICAL; Reason: RESEARCHER_INTERPRETATION: relational necessity and boundary argument, not an established theorem or empirical validation of the compound system.

**Comparative evidence.** Assessment: ABSENT_FOR_COMPOSED_MECHANISM; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: PARTIAL_ANTECEDENT_EVIDENCE_ONLY; Source ids: ESME-S051; ESME-S062; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S049; ESME-S062; Reason: Analytical: unobserved external effects can make the frontier incomplete; a complete formal model is not claimed.

**Transferability.** Assessment: UNVALIDATED_AS_A_COMBINED_SYSTEM; Reason: The relevant effects and feasibility of recovery options are known well enough to support the decision. At this exact transition, which recovery option is lost and what replaces it?

**Source IDs:** ESME-S019, ESME-S029, ESME-S049, ESME-S051, ESME-S062. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. At this exact transition, which recovery option is lost and what replaces it?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-096 — Composition-induced coexistence termination witness

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; ANALYTICAL_COMPLETION_CRITERION

**Mature form.** Retain bounded termination evidence, not impossible proof of universal non-use.

**Controlled failure.** Analytical: proving absence of unknown consumers may be impossible; bounded scope and accepted residual risk are necessary.

**Operating mechanism.** Require evidence that responsibilities, consumers and required state have transferred before declaring migration complete and removing temporary old paths.

**Trigger.** A migration claims completion while old/new systems, bridges or unresolved users remain.

**Non-trigger and cheap path.** A simple statement and check that no supported consumer remains may suffice; permanent deliberate coexistence is a new supported configuration, not an unfinished migration by definition.

**Prerequisites.** Conditions: The retained support scope and authority to terminate are explicit.; Related property ids: ESME-048; ESME-050; ESME-052; ESME-069; ESME-071; ESME-092; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Legacy/successor maintainers, operators and remaining consumers.; Decision: Completion points to transferred obligations and actual closure, or explicitly reclassifies justified continued coexistence.

**Authority and practical action.** Actors: Legacy/successor maintainers, operators and remaining consumers.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Completion points to transferred obligations and actual closure, or explicitly reclassifies justified continued coexistence. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S029; ESME-S054; Adjudication: Analytical: proving absence of unknown consumers may be impossible; bounded scope and accepted residual risk are necessary.; Effect on disposition: Retain bounded termination evidence, not impossible proof of universal non-use.

**Anti-ceremony boundary.** Essential: Completion points to transferred obligations and actual closure, or explicitly reclassifies justified continued coexistence.; Minimal alternative: A simple statement and check that no supported consumer remains may suffice; permanent deliberate coexistence is a new supported configuration, not an unfinished migration by definition.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** A simple statement and check that no supported consumer remains may suffice; permanent deliberate coexistence is a new supported configuration, not an unfinished migration by definition. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R016; ESME-R033

#### Domain profile

**Change intent and change class.** A migration claims completion while old/new systems, bridges or unresolved users remain. Reconcile change intent, preservation, evidence and lifecycle choices rather than requiring every source technique simultaneously.

**Baseline and affected artefacts.** Responsibility allocation, consumer transitions, reconciled data and retired routes. Treat artefacts, environments, consumers, obligations, evidence assumptions and effect history as coupled state.

**Preservation obligation and observer.** Legacy/successor maintainers, operators and remaining consumers. Each invariant names its observer and authorised exceptions; the synthesis supplies no new stakeholder authority.

**Impact boundary and dependency evidence.** An impact or environmental change can invalidate evidence previously adequate for another state.

**Comprehension assumptions.** The retained support scope and authority to terminate are explicit. A coherent account requires only the understanding needed to justify its current decisions; fuller models have explicit triggers.

**Oracle and regression limits.** Composed evidence is not stronger than its missing oracle or invalid assumptions; declare conflicts and failed observations.

**Compatibility and migration preconditions.** Acceptance must cover intermediate coexistence states and supported variants wherever those are actual obligations.

**Release rollback or forward repair condition.** Actions cross different recoverability boundaries; accepted irreversibility needs explicit authority and compensating/forward conditions.

**Maintainer and downstream consumers.** Actors exchange actionable obligations, evidence, changes and limitations; distinctions, authority, action and achieved consequences remain separate.

**Lifecycle cost and retirement condition.** A simple statement and check that no supported consumer remains may suffice; permanent deliberate coexistence is a new supported configuration, not an unfinished migration by definition. Each control needs a consumer and stopping condition; no-change and retirement are first-class branches; the combined system has no comparative validation yet.

#### Evidence partitions

**Provenance.** Assessment: ANALYTICAL; Reason: Analytical synthesis on 2026-09-06; supporting antecedents are independently listed, not claimed to name this compound property.

**Theory.** Assessment: ANALYTICAL; Reason: RESEARCHER_INTERPRETATION: relational necessity and boundary argument, not an established theorem or empirical validation of the compound system.

**Comparative evidence.** Assessment: ABSENT_FOR_COMPOSED_MECHANISM; Source ids: None asserted in this record.; Reason: No directly comparative intervention estimate is asserted for this candidate.

**Field evidence.** Assessment: PARTIAL_ANTECEDENT_EVIDENCE_ONLY; Source ids: ESME-S013; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S029; ESME-S054; Reason: Analytical: proving absence of unknown consumers may be impossible; bounded scope and accepted residual risk are necessary.

**Transferability.** Assessment: UNVALIDATED_AS_A_COMBINED_SYSTEM; Reason: The retained support scope and authority to terminate are explicit. What evidence establishes the old responsibility is discharged rather than merely hidden behind the new interface?

**Source IDs:** ESME-S013, ESME-S029, ESME-S031, ESME-S041, ESME-S055, ESME-S054. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What evidence establishes the old responsibility is discharged rather than merely hidden behind the new interface?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-097 — Composition-induced proportional control and retirement

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; ANALYTICAL_SELECTION_INVARIANT

**Mature form.** Minimal coherent system with triggers for richer forms and explicit control retirement.

**Controlled failure.** Analytical: cheapest can be dangerously underpowered; proportionality needs an explicit loss/uncertainty discriminator, not a slogan.

**Operating mechanism.** Select the smallest set of mechanisms that jointly meets the actual obligations; expand on concrete uncertainty or exposure and remove controls whose consumer or failure mechanism disappears.

**Trigger.** Combining individually useful techniques risks imposing all of them simultaneously or retaining obsolete machinery.

**Non-trigger and cheap path.** Use a local explanation, direct test and reversible edit when adequate; choose no intervention when no justified change exists.

**Prerequisites.** Conditions: Omission must be justified by covered obligations, not by convenience alone.; Related property ids: ESME-012; ESME-035; ESME-043; ESME-058; ESME-066; ESME-074; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Maintainers and affected stakeholders deciding acceptable evidence and coordination.; Decision: Each applied control has a protected failure, consumer and continuation condition; omitted alternatives have a rationale.

**Authority and practical action.** Actors: Maintainers and affected stakeholders deciding acceptable evidence and coordination.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** Each applied control has a protected failure, consumer and continuation condition; omitted alternatives have a rationale. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S023; ESME-S036; ESME-S037; ESME-S058; Adjudication: Analytical: cheapest can be dangerously underpowered; proportionality needs an explicit loss/uncertainty discriminator, not a slogan.; Effect on disposition: Minimal coherent system with triggers for richer forms and explicit control retirement.

**Anti-ceremony boundary.** Essential: Each applied control has a protected failure, consumer and continuation condition; omitted alternatives have a rationale.; Minimal alternative: Use a local explanation, direct test and reversible edit when adequate; choose no intervention when no justified change exists.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** Use a local explanation, direct test and reversible edit when adequate; choose no intervention when no justified change exists. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Absence reason: No separately named tension entry includes this candidate; the record’s critical assumption, known failure and cheap path still constrain selection.

**Composition coupling.** ESME-R034

#### Domain profile

**Change intent and change class.** Combining individually useful techniques risks imposing all of them simultaneously or retaining obsolete machinery. Reconcile change intent, preservation, evidence and lifecycle choices rather than requiring every source technique simultaneously.

**Baseline and affected artefacts.** Selected controls, protected obligations, costs and consumers. Treat artefacts, environments, consumers, obligations, evidence assumptions and effect history as coupled state.

**Preservation obligation and observer.** Maintainers and affected stakeholders deciding acceptable evidence and coordination. Each invariant names its observer and authorised exceptions; the synthesis supplies no new stakeholder authority.

**Impact boundary and dependency evidence.** An impact or environmental change can invalidate evidence previously adequate for another state.

**Comprehension assumptions.** Omission must be justified by covered obligations, not by convenience alone. A coherent account requires only the understanding needed to justify its current decisions; fuller models have explicit triggers.

**Oracle and regression limits.** Composed evidence is not stronger than its missing oracle or invalid assumptions; declare conflicts and failed observations.

**Compatibility and migration preconditions.** Acceptance must cover intermediate coexistence states and supported variants wherever those are actual obligations.

**Release rollback or forward repair condition.** Actions cross different recoverability boundaries; accepted irreversibility needs explicit authority and compensating/forward conditions.

**Maintainer and downstream consumers.** Actors exchange actionable obligations, evidence, changes and limitations; distinctions, authority, action and achieved consequences remain separate.

**Lifecycle cost and retirement condition.** Use a local explanation, direct test and reversible edit when adequate; choose no intervention when no justified change exists. Each control needs a consumer and stopping condition; no-change and retirement are first-class branches; the combined system has no comparative validation yet.

#### Evidence partitions

**Provenance.** Assessment: ANALYTICAL; Reason: Analytical synthesis on 2026-09-06; supporting antecedents are independently listed, not claimed to name this compound property.

**Theory.** Assessment: ANALYTICAL; Reason: RESEARCHER_INTERPRETATION: relational necessity and boundary argument, not an established theorem or empirical validation of the compound system.

**Comparative evidence.** Assessment: ABSENT_FOR_COMPOSED_MECHANISM; Source ids: ESME-S023; ESME-S036; ESME-S037; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: PARTIAL_ANTECEDENT_EVIDENCE_ONLY; Source ids: ESME-S013; ESME-S051; Reason: The setting, self-report/incident status and limited transfer are preserved in each source record; a case is not a frequency estimate.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S023; ESME-S036; ESME-S037; ESME-S058; Reason: Analytical: cheapest can be dangerously underpowered; proportionality needs an explicit loss/uncertainty discriminator, not a slogan.

**Transferability.** Assessment: UNVALIDATED_AS_A_COMBINED_SYSTEM; Reason: Omission must be justified by covered obligations, not by convenience alone. What failure remains covered if this control is removed, and what cost disappears?

**Source IDs:** ESME-S013, ESME-S025, ESME-S051, ESME-S055, ESME-S058, ESME-S023, ESME-S036, ESME-S037. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What failure remains covered if this control is removed, and what cost disappears?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

### ESME-098 — Composition-induced independent warrant for oracle revision

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; ANALYTICAL_META_CHANGE_CONSTRAINT

**Mature form.** Retain bounded non-circular warrant for method/oracle revision; it does not grant self-authorising evolution.

**Controlled failure.** Analytical: perfect independent truth may be unavailable; the rule requires a defensible external warrant, not impossible absolute certainty.

**Operating mechanism.** When the change also revises expected behaviour or acceptance rules, justify that revision through the authorised requirement and affected consumers, not merely the candidate’s ability to pass the new tests.

**Trigger.** A patch removes, weakens or changes an oracle, specification or preservation obligation relevant to its own acceptance.

**Non-trigger and cheap path.** An obvious erroneous expected value can be corrected with a checked domain example; a separate team or elaborate meta-process is not mandatory.

**Prerequisites.** Conditions: A warrant independent of the candidate’s success under the new rule is available; unresolved intent remains unresolved.; Related property ids: ESME-001; ESME-034; ESME-035; ESME-079; ESME-091; ESME-093; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.

**Consumer and decision.** Consumer: Request owner, reviewer and consumers affected by the redefinition.; Decision: The acceptance-rule change has a reason not reducible to making the patch pass, and remaining preservation obligations are checked.

**Authority and practical action.** Actors: Request owner, reviewer and consumers affected by the redefinition.; Boundary: Understanding or recommending a change does not itself authorise altering another actor’s obligations. Use actual agreed decision rights and capability; no new role or veto is created by this record.

**Evidence needed.** The acceptance-rule change has a reason not reducible to making the patch pass, and remaining preservation obligations are checked. Evidence must concern the actual target baseline, affected consumers and declared assumptions. Test results, analysis output, support records or conversations are relevant only insofar as they establish this postcondition.

**Critical evidence and residual uncertainty.** Source ids: ESME-S034; ESME-S063; ESME-S064; Adjudication: Analytical: perfect independent truth may be unavailable; the rule requires a defensible external warrant, not impossible absolute certainty.; Effect on disposition: Retain bounded non-circular warrant for method/oracle revision; it does not grant self-authorising evolution.

**Anti-ceremony boundary.** Essential: The acceptance-rule change has a reason not reducible to making the patch pass, and remaining preservation obligations are checked.; Minimal alternative: An obvious erroneous expected value can be corrected with a checked domain example; a separate team or elaborate meta-process is not mandatory.; Anti ceremony: Presence of an artefact, tool name, meeting or metric does not establish the postcondition; remove it when its protected failure and consumer disappear.

**Omission or retirement.** An obvious erroneous expected value can be corrected with a checked domain example; a separate team or elaborate meta-process is not mandatory. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts and selection.** Tension id: ESME-T01; Discriminator: Identify the actual obligation, consumer and authorisation for revision; unresolved authority blocks that revision, not unrelated work.; Hybrid failure: Two ambiguous meanings, unmaintained compatibility mode, or an oracle changed solely to pass.

**Composition coupling.** ESME-R035

#### Domain profile

**Change intent and change class.** A patch removes, weakens or changes an oracle, specification or preservation obligation relevant to its own acceptance. Reconcile change intent, preservation, evidence and lifecycle choices rather than requiring every source technique simultaneously.

**Baseline and affected artefacts.** Changed tests/specification, prior obligation, authorised new objective and supporting evidence. Treat artefacts, environments, consumers, obligations, evidence assumptions and effect history as coupled state.

**Preservation obligation and observer.** Request owner, reviewer and consumers affected by the redefinition. Each invariant names its observer and authorised exceptions; the synthesis supplies no new stakeholder authority.

**Impact boundary and dependency evidence.** An impact or environmental change can invalidate evidence previously adequate for another state.

**Comprehension assumptions.** A warrant independent of the candidate’s success under the new rule is available; unresolved intent remains unresolved. A coherent account requires only the understanding needed to justify its current decisions; fuller models have explicit triggers.

**Oracle and regression limits.** Composed evidence is not stronger than its missing oracle or invalid assumptions; declare conflicts and failed observations.

**Compatibility and migration preconditions.** Acceptance must cover intermediate coexistence states and supported variants wherever those are actual obligations.

**Release rollback or forward repair condition.** Actions cross different recoverability boundaries; accepted irreversibility needs explicit authority and compensating/forward conditions.

**Maintainer and downstream consumers.** Actors exchange actionable obligations, evidence, changes and limitations; distinctions, authority, action and achieved consequences remain separate.

**Lifecycle cost and retirement condition.** An obvious erroneous expected value can be corrected with a checked domain example; a separate team or elaborate meta-process is not mandatory. Each control needs a consumer and stopping condition; no-change and retirement are first-class branches; the combined system has no comparative validation yet.

#### Evidence partitions

**Provenance.** Assessment: ANALYTICAL; Reason: Analytical synthesis on 2026-09-06; supporting antecedents are independently listed, not claimed to name this compound property.

**Theory.** Assessment: ANALYTICAL; Reason: RESEARCHER_INTERPRETATION: relational necessity and boundary argument, not an established theorem or empirical validation of the compound system.

**Comparative evidence.** Assessment: ABSENT_FOR_COMPOSED_MECHANISM; Source ids: ESME-S034; ESME-S063; ESME-S064; Reason: These comparisons bear on premises, limits or submechanisms; they do not establish universal net benefit of the full operative rule.

**Field evidence.** Assessment: PARTIAL_ANTECEDENT_EVIDENCE_ONLY; Source ids: None asserted in this record.; Reason: No field-effect estimate claimed.

**Replication.** Assessment: NO_INDEPENDENT_MECHANISM_REPLICATION_ESTABLISHED; Reason: Shared Linux, Defects4J, SWE-bench, Google or other datasets/programmes are not counted as independent replications. Absence here is not a claim that no replication exists anywhere.

**Contrary findings.** Assessment: EXAMINED; Source ids: ESME-S034; ESME-S063; ESME-S064; Reason: Analytical: perfect independent truth may be unavailable; the rule requires a defensible external warrant, not impossible absolute certainty.

**Transferability.** Assessment: UNVALIDATED_AS_A_COMBINED_SYSTEM; Reason: A warrant independent of the candidate’s success under the new rule is available; unresolved intent remains unresolved. What justifies this changed expectation other than the fact that it makes the proposed change pass?

**Source IDs:** ESME-S001, ESME-S022, ESME-S025, ESME-S041, ESME-S034, ESME-S063, ESME-S064. Full locators and actual access levels are in the source table and each property’s `SOURCE_CLAIM_LINKS`.

#### Neutral audit questions

1. What justifies this changed expectation other than the fact that it makes the proposed change pass?
2. Is the mechanism already adequately addressed, inapplicable, dominated by a simpler alternative, or presently unsupported by sufficient evidence?
3. What observation would demonstrate the stated postcondition, and what evidence would falsify the payoff in this setting?

## Non-retained, superseded, duplicate, contested and unresolved records

These are not unconditional obligations. Their absence in a target is not a gap. Retain these IDs in any later denominator and record why a narrower mechanism, uncertainty or rejection applies.

### ESME-006 — Four categories as a universally exhaustive taxonomy

**Status:** SUPERSEDED_BY_STRONGER_FORM.

SUPERSEDED_BY_STRONGER_FORM: Superseded by multidimensional, edition-aware classification; historical four-term usage remains legitimate within a declared scope. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Source-supported: ISO 2022 additive maintenance and alternative activity taxonomies defeat the universal claim.

**Narrower or alternative form:** Superseded by multidimensional, edition-aware classification; historical four-term usage remains legitimate within a declared scope.

**Links:** Relation: SUPERSEDED_BY; Property id: ESME-002

**Neutral question:** Is a reported distribution really based on the same taxonomy and unit?

**Sources:** ESME-S003, ESME-S006, ESME-S041, ESME-S001, ESME-S004, ESME-S005.

### ESME-008 — Universal growth and inevitable deterioration

**Status:** REJECTED_OR_DISFAVOURED.

REJECTED_OR_DISFAVOURED: Reject universality, preserve scope-conditioned empirical questions. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Source-supported: population and release-stream results vary. Analytical: stable specified computations need not gain features to remain useful.

**Narrower or alternative form:** Reject universality, preserve scope-conditioned empirical questions.

**Links:** No duplicate/supersession link is asserted; this is its own adverse or unsettled candidate.

**Neutral question:** Which premise connects the cited law to this system’s current obligation?

**Sources:** ESME-S008, ESME-S009, ESME-S010, ESME-S011, ESME-S012, ESME-S013.

### ESME-011 — Invariant organisational work rate as a planning law

**Status:** REJECTED_OR_DISFAVOURED.

REJECTED_OR_DISFAVOURED: Reject universal prescription while preserving local longitudinal investigation. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Source-supported: heterogeneous evolution studies and version-specific work experiments undermine unqualified transfer, not the original conditional observation.

**Narrower or alternative form:** Reject universal prescription while preserving local longitudinal investigation.

**Links:** No duplicate/supersession link is asserted; this is its own adverse or unsettled candidate.

**Neutral question:** Which changed organisational or technical condition invalidates the extrapolation?

**Sources:** ESME-S008, ESME-S010, ESME-S011, ESME-S012, ESME-S036, ESME-S037.

### ESME-017 — Reverse engineering itself modifies the subject

**Status:** REJECTED_OR_DISFAVOURED.

REJECTED_OR_DISFAVOURED: Reject category conflation; preserve analysis as an enabling activity. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Source-supported: Chikofsky and Cross define reverse engineering without changing the subject; re-engineering includes subsequent alteration.

**Narrower or alternative form:** Reject category conflation; preserve analysis as an enabling activity.

**Links:** No duplicate/supersession link is asserted; this is its own adverse or unsettled candidate.

**Neutral question:** Which real object changed, rather than merely its description?

**Sources:** ESME-S014.

### ESME-018 — Exhaustive comprehension before every change

**Status:** REJECTED_OR_DISFAVOURED.

REJECTED_OR_DISFAVOURED: Reject exhaustive prerequisite, not the need to understand consequential effects. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Source-supported: developers ask bounded evolving questions; formal analyses are purpose-relative. Analytical: mandatory exhaustiveness imposes unbounded cost.

**Narrower or alternative form:** Reject exhaustive prerequisite, not the need to understand consequential effects.

**Links:** No duplicate/supersession link is asserted; this is its own adverse or unsettled candidate.

**Neutral question:** Would the missing global knowledge change the local acceptance decision?

**Sources:** ESME-S014, ESME-S016, ESME-S015, ESME-S017, ESME-S018.

### ESME-023 — Co-change correlation proves necessary dependency

**Status:** REJECTED_OR_DISFAVOURED.

REJECTED_OR_DISFAVOURED: Reject necessity inference, retain bounded search guidance. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Source-supported: historical transactions contain unnecessary or flawed edits and incomplete recall.

**Narrower or alternative form:** Reject necessity inference, retain bounded search guidance.

**Links:** No duplicate/supersession link is asserted; this is its own adverse or unsettled candidate.

**Neutral question:** What intervention or semantic relation would establish that this edit must propagate?

**Sources:** ESME-S020.

### ESME-026 — Version labels prove compatibility

**Status:** REJECTED_OR_DISFAVOURED.

REJECTED_OR_DISFAVOURED: Reject proof-by-label, retain semantic versioning as communication. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Source-supported: versioning rules are promises; API and schema behaviour require additional conditions.

**Narrower or alternative form:** Reject proof-by-label, retain semantic versioning as communication.

**Links:** No duplicate/supersession link is asserted; this is its own adverse or unsettled candidate.

**Neutral question:** What evidence checks the publisher’s compatibility promise for this consumer?

**Sources:** ESME-S067, ESME-S021, ESME-S049.

### ESME-033 — Catalogue compliance as a maintenance property

**Status:** CEREMONY_NOT_GENERAL_PROPERTY.

CEREMONY_NOT_GENERAL_PROPERTY: Strip the ritual while retaining useful vocabulary and validated rules. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Source-supported: refactoring-labelled changes and automated transformations can have adverse results.

**Narrower or alternative form:** Strip the ritual while retaining useful vocabulary and validated rules.

**Links:** No duplicate/supersession link is asserted; this is its own adverse or unsettled candidate.

**Neutral question:** What protected outcome would remain if the catalogue name were removed?

**Sources:** ESME-S022, ESME-S041, ESME-S023, ESME-S045.

### ESME-040 — Passing all selected tests proves correctness

**Status:** REJECTED_OR_DISFAVOURED.

REJECTED_OR_DISFAVOURED: Reject the universal inference, not the utility of tests. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Source-supported: wrong patches, omitted regressions, broken harnesses and issue/PR misalignment provide counterexamples.

**Narrower or alternative form:** Reject the universal inference, not the utility of tests.

**Links:** No duplicate/supersession link is asserted; this is its own adverse or unsettled candidate.

**Neutral question:** Which untested behaviour or incorrect oracle would leave these tests green?

**Sources:** ESME-S025, ESME-S026, ESME-S024, ESME-S034, ESME-S063, ESME-S064.

### ESME-053 — Rewrites are always wrong

**Status:** REJECTED_OR_DISFAVOURED.

REJECTED_OR_DISFAVOURED: Reject the universal rule while retaining scrutiny of lost domain knowledge and cutover risk. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Analytical: documented migration alternatives and retirement conditions contradict universal exclusion; this is not a claimed empirical rewrite success rate.

**Narrower or alternative form:** Reject the universal rule while retaining scrutiny of lost domain knowledge and cutover risk.

**Links:** No duplicate/supersession link is asserted; this is its own adverse or unsettled candidate.

**Neutral question:** Is continued servicing actually feasible over the required support horizon?

**Sources:** ESME-S013, ESME-S029, ESME-S031, ESME-S055.

### ESME-054 — Newest language or platform is the mature form

**Status:** REJECTED_OR_DISFAVOURED.

REJECTED_OR_DISFAVOURED: Reject newest-equals-best; preserve targeted adaptation to genuine environmental change. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Analytical objection grounded in migration and debt trade-offs: no universal technology-age ordering is established.

**Narrower or alternative form:** Reject newest-equals-best; preserve targeted adaptation to genuine environmental change.

**Links:** No duplicate/supersession link is asserted; this is its own adverse or unsettled candidate.

**Neutral question:** What necessary capability or avoided risk is unavailable on the current platform?

**Sources:** ESME-S029, ESME-S031, ESME-S055, ESME-S058.

### ESME-055 — Reverting code reverses the system

**Status:** REJECTED_OR_DISFAVOURED.

REJECTED_OR_DISFAVOURED: Reject equivalence and retain effect-relative recovery. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Source-supported: actual database recovery and constrained schema evolution demonstrate distinct obligations.

**Narrower or alternative form:** Reject equivalence and retain effect-relative recovery.

**Links:** No duplicate/supersession link is asserted; this is its own adverse or unsettled candidate.

**Neutral question:** What happened while this code was running that a textual revert cannot undo?

**Sources:** ESME-S019, ESME-S041, ESME-S049, ESME-S051, ESME-S062.

### ESME-061 — Zero technical debt as the objective

**Status:** REJECTED_OR_DISFAVOURED.

REJECTED_OR_DISFAVOURED: Reject zero-debt optimisation, preserve explicit investment decisions. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Source-supported: deliberate debt and low-interest deferral can create value; scanner issues are not all debt.

**Narrower or alternative form:** Reject zero-debt optimisation, preserve explicit investment decisions.

**Links:** No duplicate/supersession link is asserted; this is its own adverse or unsettled candidate.

**Neutral question:** Which current obligation would be neglected to remove this low-value item?

**Sources:** ESME-S027, ESME-S028, ESME-S058.

### ESME-062 — A universal maintainability index proves future savings

**Status:** REJECTED_OR_DISFAVOURED.

REJECTED_OR_DISFAVOURED: Reject universal calibration, retain context-tested diagnostics. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Source-supported: refactoring metrics can be adverse; debt manifesto rejects one-size-fits-all measurement.

**Narrower or alternative form:** Reject universal calibration, retain context-tested diagnostics.

**Links:** No duplicate/supersession link is asserted; this is its own adverse or unsettled candidate.

**Neutral question:** Was this score validated against the kind of maintenance work being forecast?

**Sources:** ESME-S023, ESME-S058, ESME-S057.

### ESME-073 — Popularity guarantees dependency continuity

**Status:** REJECTED_OR_DISFAVOURED.

REJECTED_OR_DISFAVOURED: Reject popularity-as-assurance, retain it as exposure information. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Source-supported: concentration and maintainer support barriers coexist with public OSS success; graph centrality does not measure human resilience.

**Narrower or alternative form:** Reject popularity-as-assurance, retain it as exposure information.

**Links:** No duplicate/supersession link is asserted; this is its own adverse or unsettled candidate.

**Neutral question:** Who will do the work if the present maintainer leaves, regardless of download count?

**Sources:** ESME-S032, ESME-S033, ESME-S059, ESME-S060.

### ESME-075 — Transition to servicing is effectively irreversible

**Status:** CONTESTED.

CONTESTED: Still contested as a general claim; retain a local hypothesis to test with recovery cost and demonstrated tasks. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Source-supported conceptual claim is stronger than available universal evidence; recovery methods make irreversibility contingent, not automatically refuted.

**Narrower or alternative form:** Still contested as a general claim; retain a local hypothesis to test with recovery cost and demonstrated tasks.

**Links:** No duplicate/supersession link is asserted; this is its own adverse or unsettled candidate.

**Neutral question:** Can a bounded recovery effort restore the needed change capability at acceptable cost?

**Sources:** ESME-S013, ESME-S014, ESME-S016, ESME-S044.

### ESME-087 — A generated insight does not authorise mutation

**Status:** DUPLICATE_CANDIDATE.

DUPLICATE_CANDIDATE: Duplicate retained for genealogy and denominator integrity; substitute ESME-001 rather than add a new control. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Analytical duplication judgement: source provenance differs, but the authority invariant and failure are equivalent.

**Narrower or alternative form:** Duplicate retained for genealogy and denominator integrity; substitute ESME-001 rather than add a new control.

**Links:** Relation: DUPLICATE_OF; Property id: ESME-001

**Neutral question:** Is the perceived new requirement actually an existing authority boundary in a new proposal channel?

**Sources:** ESME-S034, ESME-S035, ESME-S041, ESME-S063, ESME-S064.

### ESME-088 — Long-term net maintainability benefit of AI-assisted evolution

**Status:** UNRESOLVED.

UNRESOLVED: UNRESOLVED after examination, not NOT_EXAMINED; permit conditional local use without claiming settled long-term superiority. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Source-supported: task/benchmark scope and unreliable follow-up limit long-horizon inference; contrary evidence does not prove permanent harm.

**Narrower or alternative form:** UNRESOLVED after examination, not NOT_EXAMINED; permit conditional local use without claiming settled long-term superiority.

**Links:** No duplicate/supersession link is asserted; this is its own adverse or unsettled candidate.

**Neutral question:** What multi-release evidence would distinguish genuine maintainability gains from deferred review and regression costs?

**Sources:** ESME-S035, ESME-S036, ESME-S037, ESME-S038, ESME-S039, ESME-S063, ESME-S064.

### ESME-090 — Universal autonomous maintenance without residual review or authority

**Status:** REJECTED_OR_DISFAVOURED.

REJECTED_OR_DISFAVOURED: Reject universality without asserting that every action needs manual intervention. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Source-supported: oracle ambiguity, incomplete semantic detection, harness errors and variable productivity leave significant residual obligations.

**Narrower or alternative form:** Reject universality without asserting that every action needs manual intervention.

**Links:** No duplicate/supersession link is asserted; this is its own adverse or unsettled candidate.

**Neutral question:** Which unmodelled objective or external effect is this autonomous workflow unable or unauthorised to resolve?

**Sources:** ESME-S035, ESME-S038, ESME-S040, ESME-S034, ESME-S036, ESME-S037, ESME-S063, ESME-S064, ESME-S066.

### ESME-091 — Every historical behaviour must be preserved

**Status:** REJECTED_OR_DISFAVOURED.

REJECTED_OR_DISFAVOURED: Reject total preservation; retain observer-relative, obligation-sensitive continuity. The negative candidate remains in the population but is not an unconditional audit obligation.

**Evidence and objection:** Source-supported: benchmark/reference behaviours can be irrelevant or erroneous; taxonomy includes intentional behavioural change.

**Narrower or alternative form:** Reject total preservation; retain observer-relative, obligation-sensitive continuity.

**Links:** No duplicate/supersession link is asserted; this is its own adverse or unsettled candidate.

**Neutral question:** Why is this old behaviour an obligation today rather than evidence to investigate?

**Sources:** ESME-S001, ESME-S022, ESME-S025, ESME-S034, ESME-S063, ESME-S064.

## Target evidence that cannot be supplied by this external study

A later audit must establish the actual legitimate purpose, supported versions/configurations, affected consumers, operational/data consequences, authorised actors, practical capability, acceptable loss/recovery conditions, relevant evidence and remaining support horizon. Where these are unknown, “evidence insufficient” is truthful. No source property automatically grants an auditor the right to infer or change them. Source-level synthesis remains useful even when a particular target has no justified intervention.

## Companion records

The frozen report explains the historical and critical argument; the property ledger resolves every mandatory field; the composition model resolves relation, criticism, ceremony and tension IDs; the source table resolves evidence; the coverage register records examination and limits. The synthesis intake is for later independent reconciliation, not a target implementation plan.
