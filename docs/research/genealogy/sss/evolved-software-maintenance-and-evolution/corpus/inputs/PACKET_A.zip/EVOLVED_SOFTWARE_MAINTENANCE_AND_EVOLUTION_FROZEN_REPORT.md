# Evolved Software Maintenance and Evolution — frozen independent study

**Revision:** ESME-R2-2026-09-06  
**Research cut-off and access date:** 6 September 2026  
**Analytical label:** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION`  
**Status:** `FROZEN` — bounded examined corpus, not a claim of universal certainty.

## Executive judgement

Software maintenance and evolution is the engineering of **justified continuity under change**. Its object is not just a source tree and its purpose is not perpetual modification. Existing behaviour, requirements, configuration, data, human knowledge, supported consumers and the ability to make later changes all enter the problem. The relevant question is which obligations should survive, which should legitimately change, and which may end. Standards and taxonomies establish a field broader than corrective repair; historical and contemporary research shows why change, understanding and evidence cannot be treated independently. [ESME-S001, §§3–5 preview; ESME-S004, §§1–3; ESME-S014, pp.13–17; ESME-S041, chapter 7]

The strongest synthesis is a **conditional stewardship system with alternatives**. It establishes a specific objective and baseline; obtains enough understanding to bound consequential effects; chooses among non-change, repair, transformation, migration and retirement; obtains evidence appropriate to the change and its observers; acts through legitimately authorised, capable people and tools; and revises its conclusions when real effects or assumptions change. These activities interact. An unexpected test result can reopen intent, a discovered consumer can widen impact, a data conversion can remove a rollback option, and a support-capacity loss can make retirement preferable to another patch. The combined formulation is this study’s analytical synthesis, not a historically recognised school or an empirically validated package. [Analytical composition of ESME-S001, ESME-S019, ESME-S022, ESME-S025, ESME-S029, ESME-S041, ESME-S049, ESME-S051, ESME-S058; see ESME-R001–052.]

Three distinctions are indispensable. **A description is not an obligation:** observed legacy behaviour and recovered rationale still require interpretation. **Evidence is not authority:** a correct diagnosis or generated patch does not grant permission to change another party’s commitments. **A successful operation is not necessarily its intended consequence:** a green harness, sent deprecation notice, completed conversion script or successful code revert can fail to establish correctness, consumer readiness, preserved meaning or restored state. These distinctions explain why the mature system needs interaction and actual operations, not merely more information about itself. [ESME-S014; ESME-S025; ESME-S053–054; ESME-S062–064; analytical coupling ESME-093–098.]

The final population contains **98 examined candidates**: **78 conditionally crosswalk-worthy records**, plus 15 rejected/disfavoured claims, one ceremonial proxy, one superseded taxonomy claim, one duplicate, one contested hypothesis and one unresolved effectiveness claim. Crosswalk-worthy does **not** mean mandatory adoption. Fifteen candidates are strongly retained and 31 retained in evolved form; the others in the 78 are conditional, assumption-sensitive, domain-specific or easily gamed/bureaucratised. Six composition-induced records are explicitly analytical. The earlier reported 71-candidate state was not inherited. Complete IDs, primary dispositions, source links and the exact counting rule appear below and in the ledger JSON.

## How this study establishes and limits its claims

This is a critical, source-grounded tradition study, not an exhaustive enumeration of every paper or a pooled effect-size meta-analysis. The ten mandatory domain families were examined through named historical works, subsequent mechanisms, negative evidence and current research through the cut-off. The source table has **67 exact-work/edition records**. That number includes standards, historical documents, conceptual work, empirical studies, primary practice/incident accounts and explicitly limited-access records. It is neither a count of independent experiments nor a claim that every work was read cover to cover. Each record says what was inspected and at what locator. The coverage JSON provides topic-level search/acquisition records and decision-changing findings; it does not pretend to preserve verbatim every original search query.

Primary records were preferred for concepts, methods and outcomes. Scholarly reviews organise migration and oracle alternatives but do not turn the cases they describe into independent replications. Issuing-body material specifies categories, protocols and guidance, not their universal adoption or economic superiority. Practitioner accounts establish actual mechanisms or reported experience, not representative comparative effects. Empirical designs retain their units, comparison, sample, setting, outcome and threats in the source table. The mature decision rules in the property ledger are researcher interpretation built from those premises; they are not attributed verbatim to each cited author.

Several access limits are material. Swanson’s original 1976 paper could not be directly retrieved after bounded attempts; its bibliographic identity and three-purpose attribution are mediated through inspected historical/scholarly successors. The 2022 maintenance standard was inspected through official metadata and a lawful 13-page preview, not all 36 pages. The 2006 predecessor has only official abstract access. The early safe-selection paper has only opening primary pages; the original prioritisation paper and the F1 schema paper have abstract-level access in the retrieved copies. The corresponding formal or empirical details are **not** reconstructed from imagination. These limits narrow specific claims and are reflected in 32 candidate records marked `EXAMINED_WITH_EVIDENCE_LIMIT`; they do not leave the domain families unresearched. [ESME-S001–003, ESME-S026, ESME-S047, ESME-S049.]

Edition and event dates were kept distinct. Lehman’s 1996 revisitation is an author copy revised in January 1997. Naur’s 1985 paper was inspected in an anthology reprint whose edition was not established. The SWEBOK PDF’s **visible cover** says v4.0a, released September 2025, while extracted text anomalously gave August 2026; the visible date controls and the mismatch is disclosed. ICSE 2026 publication and a 2025 author preprint can identify the same work. The ICSME event scheduled for 14–18 September 2026 had not occurred at this cut-off; accepted August preprints are already research evidence, but not evidence of a completed future presentation. [ESME-S010, ESME-S016, ESME-S038–042, ESME-S063.]

Source dependence was actively preserved. The IBM evolution programme underlies several formulations. Linux recurs across empirical studies. Defects4J appears across mutation, regression and repair work. SWE-bench and its Verified subset recur across the original benchmark, patch-correctness, PR-issue and contamination investigations. Google release/schema accounts are not independent replications of a general practice benefit. Original papers, blog summaries and later editions are not counted as new experiments merely because they have different URLs. The source table records these relationships without collapsing genuinely distinct work or editions.

## Reconstructing the field’s problems and mechanisms

### Maintenance purposes are not an exhaustive ontology of edits

Swanson’s historical corrective/adaptive/perfective distinction concerns the **purpose** of maintenance. It was important because maintaining an existing system includes changing it to fit new conditions and improve usefulness, not only repairing mistakes. Later preventive terminology, activity-based classification and multidimensional schemes do not form one simple replacement ladder. Chapin and colleagues ask what maintainers actually do, proposing twelve activity types in four clusters; Buckley and colleagues organise change along dimensions such as when, what, how and where. A single intervention can occupy several meaningful descriptions. Survey proportions over intentions therefore cannot be silently equated with measured proportions over activities or changed lines. [ESME-S003, mediated via ESME-S004/ESME-S006; ESME-S004, §§1–3 and appendix; ESME-S005, §§2–3; ESME-S007, abstract.]

Current terminology also prevents freezing a familiar teaching summary into timeless completeness. The inspected 2022 standard distinguishes **additive maintenance** as well as corrective, adaptive, perfective and preventive maintenance; emergency maintenance describes a temporary urgent intervention. This study therefore does not force all work into four exclusive boxes. Nor does it require every team to use the most elaborate taxonomy. A descriptor earns its place when it changes estimation, authority, evidence or communication. Where a short request already expresses the relevant purpose and artefacts, extra classification has no demonstrated general value. [ESME-S001, definition preview; ESME-S041, chapter 7; analytical ESME-002/006.]

A corrective request asks to restore an accepted intention; an adaptive request changes the system for an altered environment; perfective, additive and preventive descriptions distinguish other motivations under the chosen edition. But a label cannot settle whether the intention is justified. An erroneous request implemented perfectly is still the wrong intervention for its affected users. Consequently, the evolved form couples classification to explicit intent and acceptance authority rather than treating a work-type form as permission to change. This coupling is reinforced by contemporary issue/PR/test mismatch evidence, but is not claimed as a new historical definition of maintenance. [ESME-S001, ESME-S041, ESME-S063–064; analytical ESME-001/093.]

### Evolution laws are an explanatory programme with a scope

Belady and Lehman studied the development of a large evolving software system, with IBM OS/360 as a central empirical setting. The important move was to treat successive releases, organisational effort, complexity and changing use as related phenomena. Software does not wear out through material abrasion, but its relationship to a changing world can become inadequate. Lehman’s S/P/E distinctions make that relationship explicit: specification-defined computation differs from solving a problem through an imperfect model, and both differ from software embedded in and changing the human activity it serves. In the latter setting, use itself can change expectations and therefore the next requirements. [ESME-S008, opening and process discussion; ESME-S009, S/P/E and correctness sections.]

The eight-law formulation is best read as a programme of conditional empirical claims and feedback hypotheses. It is not a set of physical laws proving that every maintained system must expand, decay, maintain an invariant work rate or undergo the same lifecycle. The following adjudication preserves the programme rather than caricaturing it:

| Historical formulation | Question retained here | Limit imposed by examination |
|---|---|---|
| Continuing change | Does environmental change make the present system inadequate? | No change is required merely because time has passed. |
| Increasing complexity | Is accumulated structure making justified modification harder? | Size or a higher structural score is not itself harmful complexity. |
| Self-regulation | What organisational/technical feedback constrains observed evolution? | A fitted distribution does not establish universal causal regulation. |
| Conservation of organisational stability | How stable is a locally measured effort/capacity relationship? | No invariant rate across different organisations, tools or objectives is prescribed. |
| Conservation of familiarity | Can available people understand and support the rate and scope of change? | No universal change-size ceiling or fixed comprehension percentage follows. |
| Continuing growth | Does sustaining useful functionality require additions in this setting? | Growth is not a universal objective; reduced scope or retirement can be appropriate. |
| Declining quality | Have changing conditions made previously adequate behaviour or assumptions inadequate? | Age alone is not a measurement of quality loss. |
| Feedback system | Which interacting feedback processes explain change, and where should observations inform decisions? | Merely drawing loops supplies neither stable control nor causal validation. |

[Historical names/scope: ESME-S010, §§1–3 and law table. The right-hand columns are this study’s narrowed interpretation, mapped to ESME-007–011 and ESME-074.]

The Linux and FreeBSD studies make measurement discipline substantive. Mixing stable and development releases, changing the counted artefact population, or treating source size as functional value can change the apparent trajectory. Godfrey and Tu’s studied Linux series reported superlinear growth; Izurieta and Bieman’s stable-release study found approximately linear growth. These are not interchangeable replications proving an intrinsic property of all open-source development. The surviving mechanism is to bind the claim to its population and measure, then observe whether the actual system-environment relationship warrants intervention. [ESME-S011–012, selected methods/results.]

Familiarity is equally important but not a licence to prohibit change. Structural simplification can improve later work while imposing immediate relearning; preserving familiar complexity can be cheaper for a stable short horizon. The discriminator is demonstrated capability and prospective maintenance need, not “always preserve familiarity” or “always simplify”. A stage model that distinguishes evolution from restricted servicing provides a useful warning about lost knowledge, but its strong irreversibility reading remains contested in this corpus. Recovery may restore some capability; whether it does so economically requires actual evidence. [ESME-S013; ESME-S016; ESME-S018; ESME-T02 and ESME-075.]

### Comprehension is question-led and plural

Weiser’s static slicing makes a precise distinction: given a program point and variables of interest, construct a conservative portion of the program relevant to that observation within the stated semantics. It is not a promise to find the universally smallest relevant program or recover every requirement. Dynamic slicing changes the scope to one execution and its actual dependencies. That can exclude irrelevant potential paths, but it cannot establish what happens on every unexecuted path. The methods trade different kinds of precision, cost and incompleteness; neither becomes a complete oracle simply by being combined with the other. [ESME-S015, pp.352–357; ESME-S043, pp.246–247.]

Human comprehension asks other questions. Naur’s theory-building account concerns why knowing source and possessing documents can differ from being able to explain and modify a system. Later observational studies of programmer questions and professional activity make the cost and sequence of inquiry visible, without supplying a mandatory protocol or universal time budget. A maintainer may first locate a feature, then follow relationships, then ask what a change would affect. The relevant stopping condition is enough justified understanding for that consequential decision—not a comprehensive model of all software and not confidence based on a convenient fragment. [ESME-S016, inspected reprint pages; ESME-S017, study/questions; ESME-S018, activity study.]

Chikofsky and Cross separate operations often conflated in maintenance language. **Reverse engineering** examines a subject to identify components/relationships and create another representation; it does not itself alter that subject. **Redocumentation** changes the representation at a similar abstraction level. **Design recovery** adds domain knowledge and reasoning not contained in implementation syntax alone. **Restructuring** changes representation/structure while preserving relevant external behaviour. **Re-engineering** includes examination and alteration, often followed by a new implementation. Their conceptual diagram permits iterative/recursive activity; it is not a compulsory serial lifecycle. [ESME-S014, pp.13–17, visually inspected.]

Multi-view recovery provides an operative bridge. DALI-style view extraction/fusion combines static, runtime and build evidence because one view may miss late binding or the relationship between built objects and source. The analyst still interprets the results. A merged diagram is not proof that the right architecture or all intent has been recovered. The mature mechanism is a question-driven choice of views whose discrepancies have a consumer: someone deciding where and how to change, what to preserve, or which uncertainty remains. [ESME-S044, View Fusion/How Dali Works/conclusion; ESME-012–020.]

### Change impact is not a list of nearby files

Configuration management supplies more than a history of text. Product/configuration spaces, workspaces and change sets represent different combinations and concurrent work. A change can propagate through types and calls, but also through build inputs, generated artefacts, persistent data, protocols, documentation and human support commitments. The impact boundary is therefore an evidence-backed claim about consequential dependencies, not the directory containing the edited file. [ESME-S019; ESME-S021; ESME-S024; ESME-S041.]

History can make that inquiry cheaper. Zimmermann and colleagues use earlier change transactions to recommend likely related entities. This is a predictive aid, not proof of necessary co-change: commits may group unrelated work, repeat mistakes or omit changes that should have been made. Conversely, a new dependency need not have any recorded co-change history. A mature tool points a maintainer towards a question, while direct semantic, configuration or consumer evidence determines whether the relation creates an obligation. [ESME-S020, evaluation and threats; ESME-022/023.]

API compatibility also has several observers. Source compatibility, binary linkage, runtime behaviour, data interpretation, protocol sequencing and resource usage are not equivalent. Dig and Johnson’s API study links framework evolution and refactoring to client adaptation, showing why an internal structural change can still matter externally. Semantic-version labels communicate a declared public-API promise; they do not perform the validation that makes the promise true. Supported configurations and versions therefore need a bounded obligation account, not a claim to test every theoretical combination or an assumption that the latest branch represents them all. [ESME-S021; ESME-S067; ESME-025/026/092.]

Concurrent changes add a further relation. Two individually acceptable branches can compose badly even when a textual merge is clean. Build-conflict tools and generated-test semantic-merge tools address different failure classes. The recent SAM study explicitly measures **local interference**, not complete correctness against developer intentions; BuCoR’s build-conflict repair does not prove all runtime semantics. Their useful role is selective evidence for a joint-intent decision, not a universal conflict detector. [ESME-S040; ESME-S066, method and §7 threats.]

### Refactoring requires both preservation and a reason to pay for it

Opdyke’s formalisation is valuable precisely because it has preconditions and a model. It does not establish every observation in every runtime environment. The inspected discussion excludes representation-sensitive observations such as particular layout/size assumptions. A real client using reflection, serialised layout, binary interfaces, timing or resources may therefore fall outside an apparently harmless transformation’s preservation envelope. The mature claim must identify the observer and environment; it need not enumerate irrelevant observers for every small pure function. [ESME-S022, §4.1 and printed p.42; ESME-S021.]

Three claims must remain separate: the transformation rule preserves the stated semantics if its preconditions hold; the preconditions hold for this program; and this concrete tool correctly implements the rule and checks. ASTGen’s refactoring-engine failures concern the latter claims, not a mathematical refutation of a theorem by an implementation that violates its assumptions. Conversely, invoking the theorem cannot excuse actual engine defects. Targeted validation and direct inspection can be adequate for small transformations; a full engine-validation campaign is not always the cheapest justified route. [ESME-S045; ESME-028–030.]

Preservation is not benefit. A behaviour-preserving transformation may make future work easier, harder or unchanged. Refactoring-associated metric studies do not give a uniform improvement story and cannot by themselves establish future causal savings. The defensible investment names the plausible change class, its expected frequency/cost, the present transformation and regression burden, and the support horizon. A complexity increase can accompany useful modularity or needed variation. A lower score can coexist with a harder real task. Thus catalogue compliance and universal maintainability-index claims are not general properties. [ESME-S023; ESME-S057–058; ESME-031–033/062.]

### Regression evidence and release continuity protect different things

An acceptance decision must establish a justified difference and justified continuity. A new test can show a repaired example while old functionality regresses; an unchanged baseline can pass old tests without implementing the requested change. Characterisation tests are useful where the specification is missing, but they initially describe what happened. Whether that behaviour should survive depends on legitimate requirements and affected consumers. Differential and metamorphic methods can expose distinctions, but their reference implementation or relation also has a validity domain. [ESME-S025; ESME-S034; ESME-S063–064.]

Selection, prioritisation and mutation must not be conflated. Safe regression selection is relative to a declared original suite and analysis conditions; it is not complete correctness. Prioritisation changes when useful information is obtained, not what every omitted test would reveal. Mutation analysis probes sensitivity to a chosen fault model; it does not supply missing requirements. The original empirical and later tool-checking literature exposes threats from seeded/filtered faults, coarse cost measures, unsupported dependencies and actual implementation errors. A full affordable suite may dominate sophisticated selection; a targeted assertion may dominate a broad mutation exercise. [ESME-S024–026; ESME-S046–048.]

The release then introduces another object: the actual delivered artefact and its environment. Source identity does not automatically give reproducible packaging, and reproducibility does not make incorrect source correct. Continuous integration only earns its cost when it exposes consequential interactions and its results reach someone able to act. Canarying needs an isolatable population, representative traffic, an appropriate observation window and attributable signals. Missing alarms on an unexercised canary are not favourable evidence; shared state can contaminate both candidate and control. [ESME-S019; ESME-S050–052.]

Finally, rollback is effect-relative. Returning source text does not necessarily restore data, schema meaning, sent messages or external actions. The GitLab database-outage postmortem is a concrete primary example of expected recovery arrangements failing through tooling/version and observation problems. It does not show that all backups fail, nor does a plan to improve them establish subsequent completion. It does show why evidence of a recovery procedure’s relevant capability is different from the presence of its name or script. [ESME-S062; analytical ESME-044/055/095.]

### Migration is an alternatives problem with intermediate states

A legacy system can be old and useful, difficult and valuable, or genuinely unsupported. Age alone identifies none of these. Migration work compares continued maintenance, wrapping, host/platform changes, restructuring, replacement and retirement. Each option inherits some obligations and creates others. Existing behaviour may contain undocumented requirements; data can carry meanings that a cleaner successor model silently discards. A successful endpoint demonstration cannot settle whether users and state can get from the old system to the new one. [ESME-S013; ESME-S029; ESME-S041; ESME-S055.]

Incremental strategies use seams and coexistence to distribute transition and discovery. Gateway-based approaches predate the later strangler-fig terminology. The inspected original strangler account is an early practitioner report, not proof of completed replacement or comparative superiority; the revised account is not another independent experiment. Incrementality requires a responsibility boundary, routing or transfer mechanism, and coherent old/new state. When these are absent, the hybrid can retain old-system cost while adding a new system, synchronisation and a still-dangerous final cutover. [ESME-S029–031.]

Atomic replacement is not therefore prohibited. A small system, acceptable interruption or intractable coexistence may make a rehearsed single transition preferable. Its evidence burden is concentrated: conversion correctness, accepted downtime/loss, viable restoration or forward repair and consumer readiness. Neither branch has universal dominance. The source limitations prevent this study from inventing a representative success rate or treating selected modernisation accounts as a causal ranking. [ESME-S029; ESME-S041; ESME-S055; analytical ESME-047–049.]

Data conversion and intermediate compatibility are independently consequential. F1’s abstract describes a corruption-avoiding asynchronous schema approach under restricted version skew; the full proof was not accessible, so no complete protocol guarantee is transferred here. The general analytical lesson is narrower: endpoints can each be valid while a mixed reader/writer state is not. Conversion also can remove distinctions or create irreversible effects. Migration completion therefore requires evidence of transferred responsibilities and resolved supported consumers, not just successor feature parity. [ESME-S049, abstract only; ESME-S029; ESME-S052–054; ESME-050–052/095–096.]

### Debt is not all unwanted work and repayment is not the objective

Cunningham’s 1992 metaphor connected expedient implementation, learning and later consolidation in a particular product experience. It was not a universal accounting standard or a claim that every debt is consciously reckless. Later working definitions focus on a design/implementation context that makes future change more costly or impossible. A defect, missing feature or ordinary maintenance task is not automatically technical debt; the candidate liability needs a concrete mechanism and a relevant future change scenario. [ESME-S027–028; ESME-S058, §1.]

Empirical debt work gives evidence of perceived and reported burden without making every estimate a recoverable saving. Besker and colleagues collected repeated developer reports and interviews across companies and conducted a replication in another setting. The reported original average of around 23% debt-attributed wasted effort is not a universal developer percentage, a scanner calibration or a randomised estimate of the benefit from repayment. Measurement and activity rankings differed in the replication. Those distinctions matter when deciding what one can actually promise from a cleanup programme. [ESME-S057, selected design/replication/findings.]

The 2025 reframing explicitly distinguishes values, beliefs and principles. It warns against one-size-fits-all metrics, records without a decision consumer and treating every tool issue as debt. It also recognises value in tolerating limited interest or deferring expenditure where future work is uncertain. These are source-supported conceptual and practice recommendations, not demonstrated universal causal necessities. This study retains the liability, cost-bearer and decision mechanisms while rejecting a mandatory zero-debt objective, an exact universal principal estimate or a required special committee/tool. [ESME-S058, §§1–3; ESME-056–062.]

### Human continuity, ecosystems and retirement are operative concerns

A maintainer is not merely a repository of facts. Time, willingness, access, practical understanding, communication and acceptance authority all affect whether a system can actually be supported. Authorship-based truck-factor estimates can prompt investigation, but commit history cannot establish all operational/domain knowledge or a numerical probability of collapse. Interviews about effective maintainers identify salient technical and communication characteristics, yet selected successful participants do not demonstrate a universal staffing template. A real handover needs evidence that the successor can do the relevant work, or an honest limitation on support. [ESME-S016; ESME-S032; ESME-S059.]

Dependency reach is likewise not maintainership capacity. Ecosystem studies measure structural exposure; maintainer vulnerability-management research shows additional work, trust and support problems within its particular advisory-sampled population. Neither popularity nor an automated queue guarantees a willing competent person will perform the next necessary change. The evolved mechanism is to connect actual dependency use, support scope, compatibility and consumer options. Updates, pinning, substitution, reduced support and retirement remain alternatives rather than ideological defaults. [ESME-S033; ESME-S060; ESME-066–069/073.]

Communication succeeds through action, not only transmission. RFC 9745’s deprecation signal and RFC 8594’s expected future unresponsiveness concern different transitions. The latter is Informational; the former is Standards Track. Neither proves that a consumer received, understood or can act on the notice. Preservation guidance uses the same word “deprecation” for another lifecycle choice, so the vocabulary must be grounded in the promised consequence. [ESME-S053–055.]

Retirement does not mean erasing all knowledge, and preservation does not mean operating a service forever. A future consumer may need source identity, historical rationale, reproducible execution or continuing live service; these require different assets and capabilities. The archival guide inspected here is a 2019 walkthrough, not a current guarantee about every supported service feature. Source retrieval alone does not reproduce an environment. A responsible closure discharges actual support/data/consumer obligations and verifies the intended operational state while preserving only the justified historical capabilities. [ESME-S013; ESME-S055–056; ESME-S052; analytical ESME-071–072.]

### Contemporary automation inherits rather than abolishes these problems

Classical generate-and-validate repair made the distinction between **plausible** and **correct** patches unavoidable. The adverse reanalysis of GenProg-related evaluations separated weak tests from harness errors and showed why a deletion baseline could exploit insufficient obligations. Repository-level issue solving enlarges the task compared with isolated function generation, but does not make extracted issue descriptions and reference patches infallible. The original SWE-bench population and its derivatives remain selected task sets, not the whole maintenance profession. [ESME-S034–035.]

Current criticism has materially changed this study’s selection. Wang, Pradel and Liu’s ICSE 2026 study uses additional developer tests, generated differentiating tests and manual requirement analysis. Disagreement with a reference patch is not automatically an error: in the sampled suspicious patches, some were correct and many remained uncertain. PAIChecker’s August 2026 preprint examines PR-issue misalignment over all 500 Verified instances and reports 68 misalignments. These are different denominators and questions; neither licenses declaring every suspicious patch incorrect. They support the separate objective-alignment and oracle-revision candidates, ESME-079 and ESME-098. [ESME-S063–064.]

Contamination and total-work evidence impose further limits. OpenAI’s February 2026 audit selected 138 particularly problematic Verified tasks; its reported proportion applies to that selected sample, not all 500. Its model-provider role and gold-informed probes remain validity qualifications. METR’s 2025 randomised study involved 16 experienced developers and 246 tasks with early-2025 tools and reported 19% longer completion time, with a 95% interval of 2%–39%. The February 2026 follow-up explicitly judges its new estimate unreliable because participation, task selection and time accounting changed. Thus neither “AI always slows maintainers” nor “the follow-up proves a current universal speedup” is warranted. [ESME-S065; ESME-S036–037.]

Recent prompt-ageing, quantisation and conflict studies also have task/version/hardware envelopes. August 2026 prompt work does not validate every repository-level workflow; memory savings from quantisation need not reduce total time or energy; build-conflict repair and local semantic-interference detection remain different tasks. Learned systems add data/configuration and feedback dependencies, not authority to revise their objectives automatically. The full long-term maintainability benefit of AI-assisted evolution remains **UNRESOLVED** here after examination. Conditional local use is compatible with that conclusion; unsupported universal claims are not. [ESME-S038–040; ESME-S061; ESME-S066; ESME-081–090.]


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_TIMELINE

Dates identify original publication or the explicitly stated edition/event. Digitised copies and later revisions are not independent replications. The 2026 conference dates below remain future relative to the cut-off.

| Date | Development and scope | Sources |
| --- | --- | --- |
| 1968 programme, documented retrospectively in later papers | IBM-era empirical study of large-system evolution; not asserted as the single origin of all maintenance research. | ESME-S008, ESME-S010 |
| 1976 | Belady–Lehman process modelling and Swanson purpose classification address different objects: longitudinal system change versus kinds of maintenance work. | ESME-S003, ESME-S008 |
| 1980 | S/P/E distinctions make specification-bound computation, problem-solving models and environment-embedded software different explanatory cases. | ESME-S009 |
| 1983 | NBS guidance records maintenance as an engineering concern extending beyond ad hoc repair; publication is December 1983, not digitisation date. | ESME-S006 |
| 1984–1985 | Conservative program slicing and theory-building accounts offer distinct analytical and human explanations of comprehension. | ESME-S015, ESME-S016 |
| 1990 | Dynamic slicing changes the execution scope of relevance; reverse-engineering taxonomy distinguishes analysis from operative alteration. | ESME-S014, ESME-S043 |
| 1992 | Opdyke formalises object-oriented refactorings and preconditions; Cunningham describes a debt metaphor from incremental product experience. | ESME-S022, ESME-S027 |
| 1996 / author revision 1997 | Eight evolution laws and feedback programme are restated with E-type scope; not universal physical laws. | ESME-S010 |
| 1997–2001 | Regression selection and prioritisation develop different evidence/cost objectives; migration, SCM and staged-evolution roadmaps organise lifecycle alternatives. | ESME-S013, ESME-S019, ESME-S026, ESME-S029, ESME-S046, ESME-S047 |
| 2000–2006 | Open-source evolution studies challenge generalisation; activity/multidimensional taxonomies broaden classification; mined co-change and API studies expose propagation. | ESME-S004, ESME-S005, ESME-S007, ESME-S011, ESME-S012, ESME-S020, ESME-S021 |
| 2004 / revised 2024 | Strangler-fig terminology communicates incremental substitution; updated explanation is not an independent replication of the original experience. | ESME-S030, ESME-S031 |
| 2007 | Refactoring metrics show nonuniform outcomes and generated engine tests expose implementation defects. | ESME-S023, ESME-S045 |
| 2013–2015 | Asynchronous schema evolution, real-fault mutation study, oracle taxonomy, adverse APR reanalysis and ML system-debt account widen evidence boundaries. | ESME-S025, ESME-S034, ESME-S048, ESME-S049, ESME-S061 |
| 2016–2019 | Debt definitions, human knowledge-concentration measures, professional comprehension, ecosystem studies and incident/release accounts deepen socioeconomic and operational scope. | ESME-S018, ESME-S028, ESME-S032, ESME-S033, ESME-S050, ESME-S051, ESME-S057, ESME-S062 |
| 2019–2022 | Archival/sunset mechanisms, maintainer interviews and the third maintenance-standard edition refine continuity and taxonomy; 2022 includes additive maintenance. | ESME-S001, ESME-S053, ESME-S056, ESME-S059 |
| 2024–2025 | Repository-level repair benchmarks, semantic-merge tests, reproductive packaging, debt reframing, deprecation signalling and a real-task AI experiment bring new measurement problems. | ESME-S035, ESME-S036, ESME-S052, ESME-S054, ESME-S058, ESME-S060, ESME-S066 |
| 2026 through 6 September | ICSE/MSR papers and current preprints scrutinise patch correctness, PR-issue mismatch, prompt ageing, quantisation and unreliable productivity follow-up. ICSME 14–18 September is still future. | ESME-S037, ESME-S038, ESME-S039, ESME-S040, ESME-S042, ESME-S063, ESME-S064, ESME-S065 |


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_GENEALOGY

This is a plural genealogy. Nodes aggregate a problem programme, not a claim that the first inspected publication invented every mechanism. Self-edges represent criticism or extension within a branch. External context nodes are explicitly declared in the composition JSON. Similarity, documentary influence and present analytical composition are kept distinct.

### ESME-G01 — Purpose classifications

**Date.** 1976 and earlier study programme

**Problem.** Understand what maintenance work is for.

**Mechanism.** Classify intention; successors distinguish activity and multiple dimensions.

**Contribution.** Maintenance is broader than corrective repair.

**Limits.** Original Swanson inaccessible; origin is mediated, not invented direct reading.

**Reception.** Refined rather than simply replaced by later taxonomies and standards.

**Source ids.** ESME-S003; ESME-S004; ESME-S005; ESME-S006; ESME-S007; ESME-S001; ESME-S041

**Property ids.** ESME-001; ESME-002; ESME-003; ESME-005; ESME-006

### ESME-G02 — Empirical evolution and feedback

**Date.** 1976–1997

**Problem.** Explain long-lived large-system change in an environment.

**Mechanism.** Longitudinal observations, S/P/E scope and feedback hypotheses.

**Contribution.** Connect usefulness, growth, complexity, effort and familiarity.

**Limits.** Particular populations and measurement choices; causal claims not universally validated.

**Reception.** OSS studies motivate narrower generalisation, not abandonment of all feedback inquiry.

**Source ids.** ESME-S008; ESME-S009; ESME-S010; ESME-S011; ESME-S012

**Property ids.** ESME-007; ESME-008; ESME-009; ESME-010; ESME-011

### ESME-G03 — Slicing and dependency-based comprehension

**Date.** 1984–1990 and successors

**Problem.** Find code relevant to a concrete observation.

**Mechanism.** Static criterion-relative conservative analysis and execution-specific dynamic dependence.

**Contribution.** Reduce irrelevant material while stating what observation is preserved.

**Limits.** Minimality/semantics and trace coverage; no automatic normative intent.

**Reception.** Used as an ingredient in analysis, recovery and testing rather than a whole maintenance process.

**Source ids.** ESME-S015; ESME-S043; ESME-S044

**Property ids.** ESME-012; ESME-013; ESME-014; ESME-020; ESME-021

### ESME-G04 — Human understanding and theory building

**Date.** 1985; empirical extensions 2006–2018

**Problem.** Explain why source/document transfer may not transfer modification ability.

**Mechanism.** Domain explanations, programmer questions and observations of real work.

**Contribution.** Knowledge is practical and socially sustained, not simply stored text.

**Limits.** Selected cases and work classifications; no universal comprehension percentage.

**Reception.** Continues in comprehension, onboarding and maintainership research.

**Source ids.** ESME-S016; ESME-S017; ESME-S018; ESME-S059

**Property ids.** ESME-012; ESME-015; ESME-016; ESME-018; ESME-019; ESME-063; ESME-064

### ESME-G05 — Reverse engineering, recovery and re-engineering

**Date.** 1990–1998

**Problem.** Recover usable abstractions and distinguish knowledge production from alteration.

**Mechanism.** Redocumentation, design recovery, restructuring and multi-view fusion.

**Contribution.** Explicit separation of observations, models and changes to the subject.

**Limits.** Interpretation and lost intent; recovered view not necessarily complete.

**Reception.** Architectural recovery provides a documented intersection with architecture research.

**Source ids.** ESME-S014; ESME-S044

**Property ids.** ESME-015; ESME-016; ESME-017; ESME-020

### ESME-G06 — Refactoring and transformation validation

**Date.** 1992–2007 and successors

**Problem.** Change structure without unintended observable change and make later work easier.

**Mechanism.** Rule/precondition reasoning, tools and independent engine checks.

**Contribution.** Separates structural transformation from functionality changes.

**Limits.** Observer exclusions, clients and implementation errors; structural metrics not guaranteed payoff.

**Reception.** API studies and negative metric/tool results force conditional rather than categorical claims.

**Source ids.** ESME-S021; ESME-S022; ESME-S023; ESME-S045

**Property ids.** ESME-028; ESME-029; ESME-030; ESME-031; ESME-032; ESME-033

### ESME-G07 — Configuration, change history and propagation

**Date.** Established earlier; 2000 roadmap and 2004 mining study inspected

**Problem.** Control multiple configurations and coordinated edits; identify related change sites.

**Mechanism.** Version/configuration spaces, workspaces, change sets and empirical co-change.

**Contribution.** A maintenance baseline can be more than one source tree.

**Limits.** Text merge and correlation do not imply semantic compatibility.

**Reception.** Build/semantic conflict research and ecosystem studies extend the object population.

**Source ids.** ESME-S019; ESME-S020; ESME-S024; ESME-S033; ESME-S040; ESME-S066

**Property ids.** ESME-004; ESME-021; ESME-022; ESME-023; ESME-024; ESME-025; ESME-026; ESME-027; ESME-092

### ESME-G08 — Regression evidence and oracle research

**Date.** 1997–2019

**Problem.** Check unwanted change under finite test/inspection budgets.

**Mechanism.** Suite-relative selection, prioritisation, mutation, differential and other oracle information.

**Contribution.** Different techniques protect different aspects of evidence production.

**Limits.** Incomplete oracles, seeded/selected datasets and actual harness/tool defects.

**Reception.** Adverse APR and LLM patch studies make evidence limits more visible.

**Source ids.** ESME-S024; ESME-S025; ESME-S026; ESME-S046; ESME-S047; ESME-S048; ESME-S063

**Property ids.** ESME-034; ESME-035; ESME-036; ESME-037; ESME-038; ESME-039; ESME-040; ESME-077; ESME-079; ESME-091

### ESME-G09 — Legacy migration and staged lifecycle alternatives

**Date.** 1999–2024 inspected accounts

**Problem.** Continue value while changing platform, structure, data or support stage.

**Mechanism.** Wrapping/gateways, incremental or atomic replacement, servicing, phaseout and closedown.

**Contribution.** Old/new coexistence and domain/data recovery are first-class problems.

**Limits.** Success selection, dual maintenance and uncertain comparative economics.

**Reception.** Strangler terminology popularises a conditional incremental branch, not a universal successor methodology.

**Source ids.** ESME-S013; ESME-S029; ESME-S030; ESME-S031; ESME-S049; ESME-S055

**Property ids.** ESME-045; ESME-046; ESME-047; ESME-048; ESME-049; ESME-050; ESME-051; ESME-052; ESME-053; ESME-054; ESME-055; ESME-071; ESME-075

### ESME-G10 — Technical-debt economics and social responsibility

**Date.** 1992–2025

**Problem.** Communicate present trade-offs that affect future change effort.

**Mechanism.** Debt metaphor, item/cause/consequence definitions, value-based prioritisation and field inquiry.

**Contribution.** Future costs can be contingent, shifted and worth accepting.

**Limits.** Metaphor inflation, self-report, uncertain causality and metric gaming.

**Reception.** 2025 manifesto explicitly challenges single metrics and heavyweight bookkeeping.

**Source ids.** ESME-S027; ESME-S028; ESME-S057; ESME-S058

**Property ids.** ESME-056; ESME-057; ESME-058; ESME-059; ESME-060; ESME-061; ESME-062

### ESME-G11 — Operational release and data continuity

**Date.** 2013–2025 inspected accounts

**Problem.** Make change safe enough under live traffic, configuration and persistent effects.

**Mechanism.** Reproducible artefacts, schema transitions, canaries and tested recovery.

**Contribution.** Safe endpoints and source reversion do not establish safe transitions.

**Limits.** Industrial assumptions, nonrepresentative traffic and irreversible effects.

**Reception.** Failure postmortems and packaging research expose missing readiness/observation.

**Source ids.** ESME-S049; ESME-S050; ESME-S051; ESME-S052; ESME-S062

**Property ids.** ESME-041; ESME-042; ESME-043; ESME-044; ESME-050; ESME-051; ESME-055

### ESME-G12 — Ecosystem, maintainership and preservation

**Date.** 2016–2025 inspected accounts

**Problem.** Sustain actual capability and end obligations responsibly.

**Mechanism.** Human succession, support boundaries, dependency communication and purpose-bounded archival/retirement.

**Contribution.** Popularity, names and stored files are distinct from living support.

**Limits.** Proxy/perception evidence, unknown consumers and institution-specific retention duties.

**Reception.** Protocol standards improve signalling without proving successful consumer transitions.

**Source ids.** ESME-S032; ESME-S033; ESME-S053; ESME-S054; ESME-S055; ESME-S056; ESME-S059; ESME-S060

**Property ids.** ESME-063; ESME-064; ESME-065; ESME-066; ESME-067; ESME-068; ESME-069; ESME-070; ESME-071; ESME-072; ESME-073; ESME-074

### ESME-G13 — Automated repair and repository-scale assistance

**Date.** 2015–2026 inspected classical and current work

**Problem.** Produce useful change candidates without confusing selection proxies with correctness or productivity.

**Mechanism.** Generate-and-validate repair, repository issue solving and specialised conflict transformation.

**Contribution.** Automation enlarges candidate search and reveals new evaluation burdens.

**Limits.** Oracle weakness, contamination, intent mismatch, model ageing and hidden human work.

**Reception.** Current adverse studies refine evaluation rather than warrant universal automation or universal rejection.

**Source ids.** ESME-S034; ESME-S035; ESME-S036; ESME-S037; ESME-S038; ESME-S039; ESME-S040; ESME-S063; ESME-S064; ESME-S065; ESME-S066

**Property ids.** ESME-076; ESME-077; ESME-078; ESME-079; ESME-080; ESME-081; ESME-082; ESME-083; ESME-087; ESME-088; ESME-089; ESME-090

### ESME-G14 — Evolution of learned and non-code systems

**Date.** 2015 and current translations

**Problem.** Understand changed behaviour when data, feedback, pipelines or configuration change.

**Mechanism.** Documented debt import and artefact/dependency expansion.

**Contribution.** The maintenance object is not confined to program statements.

**Limits.** Patterns are not universal quantified laws or a complete ML governance method.

**Reception.** Requires rechecking traditional evidence/observer assumptions rather than simply renaming them.

**Source ids.** ESME-S005; ESME-S024; ESME-S041; ESME-S061

**Property ids.** ESME-003; ESME-084; ESME-085; ESME-086

### ESME-G15 — This packet’s within-tradition analytical composition

**Date.** 2026-09-06

**Problem.** Make surviving criteria and operating mechanisms cooperate without mandatory union.

**Mechanism.** Guarded alternatives, feedback and six explicit composition-induced constraints.

**Contribution.** A synthesis-ready decision/continuity system rather than a property catalogue.

**Limits.** Not an established school or empirically validated compound intervention.

**Reception.** No adoption or downstream validation claimed.

**Source ids.** ESME-S001; ESME-S019; ESME-S022; ESME-S025; ESME-S029; ESME-S041; ESME-S049; ESME-S051; ESME-S058; ESME-S063; ESME-S064

**Property ids.** ESME-093; ESME-094; ESME-095; ESME-096; ESME-097; ESME-098

### Classified relationships

### ESME-GE001

**Relation type.** CRITICISM_AND_RESPONSE

**Source ids.** ESME-S004; ESME-S005; ESME-S007; ESME-S001; ESME-S041

**Warrant.** Later authors explicitly discuss inadequacies of prior purpose/activity classifications; the standard adds/refines categories.

**Limit.** Not a simple replacement chain or a universal winner; original Swanson access is mediated.

**From node ids.** ESME-G01

**To node ids.** ESME-G01

### ESME-GE002

**Relation type.** EXPLICIT_EXTENSION

**Source ids.** ESME-S008; ESME-S009; ESME-S010

**Warrant.** Lehman revisits the same empirical/explanatory programme and explicitly broadens feedback framing.

**Limit.** Reformulations share ancestry and data; not independent replications.

**From node ids.** ESME-G02

**To node ids.** ESME-G02

### ESME-GE003

**Relation type.** CRITICISM_AND_RESPONSE

**Source ids.** ESME-S011; ESME-S012

**Warrant.** OSS studies explicitly engage earlier evolution expectations with different samples and measures.

**Limit.** A different growth curve does not refute every law or identify a new universal one.

**From node ids.** ESME-G02

**To node ids.** ESME-G02

### ESME-GE004

**Relation type.** EXPLICIT_EXTENSION

**Source ids.** ESME-S015; ESME-S043

**Warrant.** Dynamic slicing explicitly cites Weiser and changes the quantification from possible executions to a particular execution.

**Limit.** Neither method subsumes all useful guarantees of the other.

**From node ids.** ESME-G03

**To node ids.** ESME-G03

### ESME-GE005

**Relation type.** DOCUMENTED_IMPORT

**Source ids.** ESME-S014

**Warrant.** Chikofsky and Cross explicitly relate software reverse engineering to hardware practice while distinguishing purposes.

**Limit.** The precursor is contextual, not a separately studied engineering corpus.

**From node ids.** HARDWARE_REVERSE_ENGINEERING_PRECURSOR

**To node ids.** ESME-G05

### ESME-GE006

**Relation type.** EXPLICIT_EXTENSION

**Source ids.** ESME-S014; ESME-S044

**Warrant.** DALI continues recovery through static/dynamic/build views and explicit fusion.

**Limit.** A documented task continuity, not proof that every detail is derived from one taxonomy paper.

**From node ids.** ESME-G05

**To node ids.** ESME-G05

### ESME-GE007

**Relation type.** CONVERGENT_DEVELOPMENT

**Source ids.** ESME-S014; ESME-S016; ESME-S044

**Warrant.** Theory-building and design recovery both require interpretation beyond source text.

**Limit.** No direct Naur-to-DALI influence is established here; similarity alone is not transmission.

**From node ids.** ESME-G04

**To node ids.** ESME-G05

### ESME-GE008

**Relation type.** CRITICISM_AND_RESPONSE

**Source ids.** ESME-S021; ESME-S022; ESME-S023; ESME-S045

**Warrant.** API, metric and engine work qualify preservation, applicability and benefit claims.

**Limit.** These are different objections; a buggy engine does not refute a theorem whose premises it violates.

**From node ids.** ESME-G06

**To node ids.** ESME-G06

### ESME-GE009

**Relation type.** EXPLICIT_EXTENSION

**Source ids.** ESME-S019; ESME-S020; ESME-S040; ESME-S066

**Warrant.** History-based recommendation and conflict techniques explicitly work on version histories/merges.

**Limit.** The 2000 roadmap is not claimed as the historical inventor of configuration management.

**From node ids.** ESME-G07

**To node ids.** ESME-G07

### ESME-GE010

**Relation type.** DOCUMENTED_IMPORT

**Source ids.** ESME-S040; ESME-S043

**Warrant.** BuCoR explicitly uses control/data-dependence analysis in extracting transformations.

**Limit.** This supports an analysis-method import, not a claim that all impact methods descend from dynamic slicing.

**From node ids.** ESME-G03

**To node ids.** ESME-G07

### ESME-GE011

**Relation type.** CRITICISM_AND_RESPONSE

**Source ids.** ESME-S025; ESME-S034; ESME-S063; ESME-S064

**Warrant.** APR and issue-solving criticisms explicitly concern test-oracle and harness inadequacy; ESME-S063 cites earlier weak-suite research.

**Limit.** Later task populations and models differ; criticisms do not imply identical error rates.

**From node ids.** ESME-G08

**To node ids.** ESME-G13

### ESME-GE012

**Relation type.** UNRESOLVED_RELATIONSHIP

**Source ids.** ESME-S029; ESME-S030; ESME-S031

**Warrant.** The inspected gateway and strangler accounts address similar incremental replacement/coexistence problems. This establishes a comparison, not common documentary ancestry or independent invention.

**Limit.** Direct transmission from Chicken Little to the 2004 naming is not established; no exclusive origin claimed.

**From node ids.** ESME-G09

**To node ids.** ESME-G09

### ESME-GE013

**Relation type.** DOCUMENTED_IMPORT

**Source ids.** ESME-S027

**Warrant.** Cunningham explicitly uses debt to explain expedient implementation and later consolidation.

**Limit.** Metaphor does not import a mathematically calibrated balance-sheet liability or imply deliberate recklessness.

**From node ids.** FINANCIAL_DEBT_METAPHOR

**To node ids.** ESME-G10

### ESME-GE014

**Relation type.** EXPLICIT_EXTENSION

**Source ids.** ESME-S028; ESME-S057; ESME-S058

**Warrant.** 2016 definitions and 2025 reframing explicitly share definitions; field studies operationalise developer burden.

**Limit.** Reported costs are not universal principal/interest measures.

**From node ids.** ESME-G10

**To node ids.** ESME-G10

### ESME-GE015

**Relation type.** DOMAIN_TRANSLATION

**Source ids.** ESME-S061

**Warrant.** The ML systems paper explicitly invokes software technical debt and extends its objects to learned-system dependencies.

**Limit.** No universal CACE law or full ML governance method is implied.

**From node ids.** ESME-G10

**To node ids.** ESME-G14

### ESME-GE016

**Relation type.** SHARED_ANCESTRY

**Source ids.** ESME-S019; ESME-S050; ESME-S052

**Warrant.** Release engineering relies on configuration/version/build relations already central to SCM.

**Limit.** No exclusive founding influence from the inspected roadmap is asserted.

**From node ids.** ESME-G07

**To node ids.** ESME-G11

### ESME-GE017

**Relation type.** HYBRIDISATION

**Source ids.** ESME-S029; ESME-S049; ESME-S051

**Warrant.** Migration problems interact with database transition and operational exposure mechanisms.

**Limit.** Their combination in this packet is partly analytical; not every migration uses canaries or F1.

**From node ids.** ESME-G09

**To node ids.** ESME-G11

### ESME-GE018

**Relation type.** UNRESOLVED_RELATIONSHIP

**Source ids.** ESME-S016; ESME-S032; ESME-S059

**Warrant.** Human knowledge and maintainership studies address related capability/transfer problems.

**Limit.** Direct documentary influence from Naur to the specific truck-factor study is not established.

**From node ids.** ESME-G04

**To node ids.** ESME-G12

### ESME-GE019

**Relation type.** ONLY_ANALOGOUS

**Source ids.** ESME-S053; ESME-S054; ESME-S055; ESME-S056

**Warrant.** This study compares support-transition and preservation obligations. The inspected sources do not establish that one school historically derived from the other.

**Limit.** Same vocabulary, especially deprecation, is not semantic identity.

**From node ids.** ESME-G11

**To node ids.** ESME-G12

### ESME-GE020

**Relation type.** ANALYTICAL_COMPOSITION

**Source ids.** ESME-S001; ESME-S019; ESME-S022; ESME-S025; ESME-S029; ESME-S041; ESME-S049; ESME-S051; ESME-S058; ESME-S063; ESME-S064

**Warrant.** This study selects and couples surviving mechanisms, retaining conflicts and domain limits.

**Limit.** Added edge type explicitly means present researcher synthesis, not a documented historical school or influence claim.

**From node ids.** ESME-G01; ESME-G02; ESME-G03; ESME-G04; ESME-G05; ESME-G06; ESME-G07; ESME-G08; ESME-G09; ESME-G10; ESME-G11; ESME-G12; ESME-G13; ESME-G14

**To node ids.** ESME-G15


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_SCOPE_AND_CARICATURES

Independent study of software maintenance and evolution across existing software’s useful life: classification, evolution feedback, comprehension, impact, preservation, regression/release evidence, migration, economics, human/ecosystem continuity and contemporary automation. Hardware maintainability, general operations, whole security engineering and sibling syntheses are outside the lane except for documented intersections necessary to explain change.

| Caricature | Examined correction | Candidate IDs |
| --- | --- | --- |
| Maintenance is bug fixing after release | Purposes, artefacts and preparatory work extend beyond that boundary. | ESME-001–006 |
| Evolution requires indefinite growth | Feedback and environmental scope do not prescribe expansion. | ESME-007–011/074 |
| Documentation equals understanding | Representations support a capable consumer; they cannot automatically replace practical theory. | ESME-012–020/063–064 |
| A local diff has local effects | Dependencies include configurations, data, interfaces and actual supported consumers. | ESME-021–027/092 |
| Refactoring proves benefit | Preservation, correct tool implementation and worthwhile investment are separate. | ESME-028–033 |
| All tests pass, therefore correct | An oracle, input population and environment limit the claim. | ESME-034–044/076–079 |
| A newer platform is more mature | Continued maintenance, different replacement branches and retirement remain alternatives. | ESME-045–055/074–075 |
| All bad code is debt; zero is ideal | Liability needs a future-work mechanism and a value comparison. | ESME-056–062 |
| Popularity or an assigned owner guarantees support | Willingness, access, time, knowledge and commitments remain necessary. | ESME-063–073 |
| Agents remove the need for maintenance judgement | Generated changes retain objective, evidence, cost and authority boundaries. | ESME-076–090/098 |

Boundaries are deliberate: no full hardware-maintainability study, general operations doctrine, systems-security programme, financial theory, legal-retention regime or sibling tradition is imported. Documented intersections are retained only to understand actual maintenance obligations. No requester-specific adoption is asserted.


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER

The complete denominator is **98**, all examined. **78** are crosswalk-worthy only under their guards; none of these counts prescribes a number of controls, roles or tools. Complete mandatory fields, domain profiles and source claim links are in [EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json). References in this report resolve by `PROPERTY_ID`, not an unsupported JSON fragment-navigation convention.

| Primary disposition | Count |
| --- | --- |
| ASSUMPTION_SENSITIVE | 7 |
| CEREMONY_NOT_GENERAL_PROPERTY | 1 |
| CONTESTED | 1 |
| CONTEXT_DEPENDENT | 16 |
| DOMAIN_SPECIFIC | 5 |
| DUPLICATE_CANDIDATE | 1 |
| REJECTED_OR_DISFAVOURED | 15 |
| RETAINED_IN_EVOLVED_FORM | 31 |
| STRONGLY_RETAINED | 15 |
| SUPERSEDED_BY_STRONGER_FORM | 1 |
| UNRESOLVED | 1 |
| USEFUL_BUT_EASILY_BUREAUCRATISED | 2 |
| USEFUL_BUT_EASILY_GAMED | 2 |

| Property ID | Candidate | Primary disposition | Examination |
| --- | --- | --- | --- |
| ESME-001 | Explicit change objective and authorised obligation revision | STRONGLY_RETAINED | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-002 | Purpose-and-activity classification without false exclusivity | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-003 | Maintenance includes non-code artefacts and readiness | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-004 | Recoverable and identifiable configuration baseline | STRONGLY_RETAINED | EXAMINED |
| ESME-005 | Emergency stabilisation separated from permanent repair | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-006 | Four categories as a universally exhaustive taxonomy | SUPERSEDED_BY_STRONGER_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-007 | Environment-relative usefulness feedback | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-008 | Universal growth and inevitable deterioration | REJECTED_OR_DISFAVOURED | EXAMINED |
| ESME-009 | Population- and metric-conditioned evolution claims | STRONGLY_RETAINED | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-010 | Familiarity and capacity as feedback constraints | ASSUMPTION_SENSITIVE | EXAMINED |
| ESME-011 | Invariant organisational work rate as a planning law | REJECTED_OR_DISFAVOURED | EXAMINED |
| ESME-012 | Bounded change-specific comprehension | STRONGLY_RETAINED | EXAMINED |
| ESME-013 | Criterion-relative conservative static slicing | ASSUMPTION_SENSITIVE | EXAMINED |
| ESME-014 | Execution-relative dynamic observation and slicing | CONTEXT_DEPENDENT | EXAMINED |
| ESME-015 | Design recovery includes domain and human knowledge | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-016 | Faithful redocumentation with an actual consumer | USEFUL_BUT_EASILY_BUREAUCRATISED | EXAMINED |
| ESME-017 | Reverse engineering itself modifies the subject | REJECTED_OR_DISFAVOURED | EXAMINED |
| ESME-018 | Exhaustive comprehension before every change | REJECTED_OR_DISFAVOURED | EXAMINED |
| ESME-019 | Feature-location hypotheses and interactive refinement | CONTEXT_DEPENDENT | EXAMINED |
| ESME-020 | Evidence-fused architecture and behaviour recovery | CONTEXT_DEPENDENT | EXAMINED |
| ESME-021 | Explicit multi-artefact impact boundary | STRONGLY_RETAINED | EXAMINED |
| ESME-022 | Historical co-change as fallible guidance | CONTEXT_DEPENDENT | EXAMINED |
| ESME-023 | Co-change correlation proves necessary dependency | REJECTED_OR_DISFAVOURED | EXAMINED |
| ESME-024 | Build, configuration and generated-artefact dependency closure | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-025 | Observer-specific API and protocol compatibility | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-026 | Version labels prove compatibility | REJECTED_OR_DISFAVOURED | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-027 | Concurrent-change semantic validation | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-028 | Observer-relative preservation in refactoring | STRONGLY_RETAINED | EXAMINED |
| ESME-029 | Transformation precondition enforcement | ASSUMPTION_SENSITIVE | EXAMINED |
| ESME-030 | Validation of transformation engines | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-031 | Refactoring payoff tied to a future change class | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-032 | Maintainability metrics as fallible diagnostics | USEFUL_BUT_EASILY_GAMED | EXAMINED |
| ESME-033 | Catalogue compliance as a maintenance property | CEREMONY_NOT_GENERAL_PROPERTY | EXAMINED |
| ESME-034 | Characterisation tests with normative review | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-035 | Independent change and regression obligations | STRONGLY_RETAINED | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-036 | Regression selection with suite-relative safety | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-037 | Test prioritisation for early information | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-038 | Mutation analysis as an adequacy diagnostic | CONTEXT_DEPENDENT | EXAMINED |
| ESME-039 | Differential and metamorphic evidence without an infallible oracle | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-040 | Passing all selected tests proves correctness | REJECTED_OR_DISFAVOURED | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-041 | Reproducible build and artefact identity | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-042 | Continuous integration as integration feedback | CONTEXT_DEPENDENT | EXAMINED |
| ESME-043 | Observation-aware staged exposure | CONTEXT_DEPENDENT | EXAMINED |
| ESME-044 | Effect-aware recovery and forward repair | STRONGLY_RETAINED | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-045 | Bounded local repair as an alternative to restructuring | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-046 | Legacy value distinguished from technical age | STRONGLY_RETAINED | EXAMINED |
| ESME-047 | Explicit comparison of modernisation alternatives | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-048 | Incremental substitution through valid migration seams | CONTEXT_DEPENDENT | EXAMINED |
| ESME-049 | Atomic replacement where coexistence is the greater risk | CONTEXT_DEPENDENT | EXAMINED |
| ESME-050 | Data-conversion invariants and reconciliation | STRONGLY_RETAINED | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-051 | Compatibility of intermediate and mixed-version states | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-052 | Coexistence budget and explicit exit | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-053 | Rewrites are always wrong | REJECTED_OR_DISFAVOURED | EXAMINED |
| ESME-054 | Newest language or platform is the mature form | REJECTED_OR_DISFAVOURED | EXAMINED |
| ESME-055 | Reverting code reverses the system | REJECTED_OR_DISFAVOURED | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-056 | Technical debt as a contingent future-change liability | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-057 | Actionable debt records with a consumer | USEFUL_BUT_EASILY_BUREAUCRATISED | EXAMINED |
| ESME-058 | Lifecycle-cost and value-based prioritisation | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-059 | Option-preserving deferral and deliberate non-repayment | CONTEXT_DEPENDENT | EXAMINED |
| ESME-060 | Visibility of future cost bearers and participation | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-061 | Zero technical debt as the objective | REJECTED_OR_DISFAVOURED | EXAMINED |
| ESME-062 | A universal maintainability index proves future savings | REJECTED_OR_DISFAVOURED | EXAMINED |
| ESME-063 | Retained rationale through actual use | STRONGLY_RETAINED | EXAMINED |
| ESME-064 | Knowledge succession and demonstrated onboarding | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-065 | Scoped ownership and change coordination | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-066 | Finite maintainer capacity and realistic support commitments | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-067 | Knowledge-concentration metrics as fallible prompts | USEFUL_BUT_EASILY_GAMED | EXAMINED |
| ESME-068 | Dependency inventory and update trade-offs | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-069 | Downstream communication that enables action | STRONGLY_RETAINED | EXAMINED |
| ESME-070 | Deprecation signalling separated from shutdown | DOMAIN_SPECIFIC | EXAMINED |
| ESME-071 | Responsible retirement with discharged obligations | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-072 | Purpose-bounded archival preservation and reproducibility | CONTEXT_DEPENDENT | EXAMINED |
| ESME-073 | Popularity guarantees dependency continuity | REJECTED_OR_DISFAVOURED | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-074 | Stable useful software may justify no change | STRONGLY_RETAINED | EXAMINED |
| ESME-075 | Transition to servicing is effectively irreversible | CONTESTED | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-076 | Generated patches remain candidates for justified repair | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-077 | Validation of the evaluation harness itself | STRONGLY_RETAINED | EXAMINED |
| ESME-078 | Benchmark provenance and contamination limits | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-079 | Issue, reference patch and test objective alignment | STRONGLY_RETAINED | EXAMINED |
| ESME-080 | Total human–automation workflow cost | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-081 | Version-bound automation evidence and revalidation | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-082 | Repair automation resource trade-offs | DOMAIN_SPECIFIC | EXAMINED |
| ESME-083 | Automated semantic-conflict detection as supplementary evidence | DOMAIN_SPECIFIC | EXAMINED |
| ESME-084 | Learned-system data and configuration dependencies | DOMAIN_SPECIFIC | EXAMINED |
| ESME-085 | Feedback and drift as preservation-boundary changes | ASSUMPTION_SENSITIVE | EXAMINED |
| ESME-086 | Artefact-appropriate validation for non-code evolution | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-087 | A generated insight does not authorise mutation | DUPLICATE_CANDIDATE | EXAMINED |
| ESME-088 | Long-term net maintainability benefit of AI-assisted evolution | UNRESOLVED | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-089 | Deletion or degradation requires an explicit containment objective | DOMAIN_SPECIFIC | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-090 | Universal autonomous maintenance without residual review or authority | REJECTED_OR_DISFAVOURED | EXAMINED |
| ESME-091 | Every historical behaviour must be preserved | REJECTED_OR_DISFAVOURED | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-092 | Supported-version and variant obligation matrix | CONTEXT_DEPENDENT | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-093 | Composition-induced change–obligation contract | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-094 | Composition-induced assumption-indexed evidence invalidation | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-095 | Composition-induced effect-relative returnability frontier | ASSUMPTION_SENSITIVE | EXAMINED_WITH_EVIDENCE_LIMIT |
| ESME-096 | Composition-induced coexistence termination witness | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-097 | Composition-induced proportional control and retirement | RETAINED_IN_EVOLVED_FORM | EXAMINED |
| ESME-098 | Composition-induced independent warrant for oracle revision | RETAINED_IN_EVOLVED_FORM | EXAMINED_WITH_EVIDENCE_LIMIT |

**Duplicate and supersession accounting:** ESME-087 remains a registered duplicate of ESME-001 and is not a second operative authority mechanism. ESME-006 is superseded by ESME-002. ESME-075 is contested and ESME-088 unresolved; neither is an unconditional audit obligation. ESME-093–098 are six explicitly analytical composition-induced candidates. No ID was deleted or renumbered to improve the apparent retention rate.


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_DOMAIN_MODELS

### 1. Change classification and legitimate intention

Represent a proposed change by its **purpose**, **activity**, **affected artefacts**, **timing/urgency**, **authorised change in obligations**, and **obligations to preserve**. These dimensions answer different questions. A corrective purpose can require restructuring activity; an environment adaptation can add a feature; a preventive change can alter build or documentation artefacts without changing delivered functional behaviour. The 2022 standard’s additive category prevents treating the familiar four purposes as exhaustive current terminology. The taxonomy supports a decision only when the selected dimension changes the inquiry, comparison or reporting. [ESME-S001, preview §§3–5; ESME-S004–005; ESME-001–006.]

The analytical state can be written `C = (intent, baseline, changed_obligations, preserved_obligations, affected_consumers, permitted_actions)`. This is a compact accounting device, not a source-attributed formal standard. A category does not authorise the action. Unresolved intent is recorded rather than silently replaced by the implementer’s preferred feature. Non-change is an available disposition of a request, not a missing maintenance step.

### 2. Evolution feedback and scope

Observe a system and environment over a declared window: delivered capability, actual usage, stakeholder demands, complexity measures, familiarity/capacity, change effort and defects. A feedback hypothesis relates these observations; it does not convert every historical correlation into a universal causal equation. An E-type setting involves continuing interaction with a changing problem environment. That scope is different from a fixed formal specification and does not establish mandatory expansion of every product. [ESME-S008–012; ESME-007–011.]

Before comparing trajectories, fix the measured unit: releases, lines, modules, stable versus development branches, elapsed time and population. An apparent law can change when the sample or metric changes. The operative consumer is a maintainer or decision maker evaluating continued fit and capacity. A signal can prompt clarification, investment, simplification, reduced scope or retirement; it does not automatically command growth. Stable useful operation with unchanged obligations is a legitimate feedback outcome.

### 3. Comprehension and recovery

Start with a consequential question and competing explanations. Record which source, runtime, configuration, history, domain or human observations bear on it. Static slicing gives a conservative dependency view within supported semantics; dynamic slicing conditions on a particular execution; feature location suggests where to inspect; design recovery adds interpretation; view fusion reveals relations not evident in any one representation. Conflicting views are evidence to investigate, not votes to average. [ESME-S014–018, ESME-S043–044; ESME-012–020.]

The stopping rule is **enough understanding to justify the specific impact and intervention decision**, including known gaps. It is not exhaustive mastery or mere personal confidence. Retain the rationale needed by the next relevant consumer. A comprehensive document with no reader or maintenance decision does not substitute for capability, while a short issue discussion can sometimes preserve the necessary distinction. Recovery itself consumes time and can remain unable to recover lost intention.

### 4. Impact propagation and supported boundaries

Use a typed relation model over code, interfaces, build inputs, generated artefacts, data/schema, configurations, deployment states, documentation and supported consumers. Label each relation by kind and warrant: static/dynamic observation, explicit contract, historical correlation, human assertion or unresolved hypothesis. Historical co-change is not upgraded to semantic necessity. Absence of observed use is not automatically proof of no consumer. [ESME-S019–021, ESME-S024, ESME-S044, ESME-S066; ESME-021–027/092.]

For a proposed change, follow consequential relations until the preservation/change decision has a defensible boundary. “Closure” here means a justified assessment under a support scope, not a mathematical claim that every open-world downstream dependency is known. Broaden the analysis when a cross-boundary consumer, unsupported dependency or concurrent change appears. For a local change whose consumers and semantics are genuinely confined, direct inspection and existing tests can be sufficient; a global graph is not mandatory.

### 5. Preservation and transformation

A useful analytical preservation statement is: for declared inputs `I`, environments `E` and observer `O`, the relevant observations of baseline `B` and transformed version `B′` agree, **except for the explicitly authorised difference**. Refactoring normally intends no such behavioural difference under its declared observer. Corrective or feature change normally does. Observers may include outputs, exceptions, supported interfaces, persisted meaning, timing or resource bounds when these are real obligations. [ESME-S021–023, ESME-S045; ESME-028–033/091.]

A proof for a language model, a satisfied precondition and a correct implementation are separate warrants. Excluded reflection/layout/foreign-interface observations must not be smuggled into the guarantee. Where formal checking is unavailable, targeted tests and review supply bounded evidence, not the missing theorem. Even successful preservation does not prove the transformation is worth doing: identify the future change class or other justified benefit, and compare its expected value with transition cost and no change.

### 6. Regression evidence and release identity

Treat an evidence item as `(claim, baseline/candidate identity, inputs, oracle, environment, method, assumptions, observed result)`. A test cannot establish a claim it does not discriminate. Regression evidence asks what should remain; change evidence asks what should differ; characterisation describes behaviour; an oracle determines what counts as acceptable. Independent justification for that oracle remains necessary when baseline or reference behaviour is disputed. [ESME-S024–026, ESME-S034, ESME-S046–048, ESME-S063–064; ESME-034–044/076–079/098.]

Selection is suite-relative, prioritisation is order-related and mutation is fault-model-related. Record which one is being claimed. Reproducible artefact identity helps establish that evidence concerns the object actually delivered, but does not establish source correctness. Canary observation needs exposure, representative traffic and an adequate failure signal; a quiet dashboard is not automatically favourable evidence. A failed observation can reopen the impact model, oracle or release decision rather than produce another nominal pass.

### 7. Migration and coexistence

Model old/new implementations, routed responsibilities, supported readers/writers, persistent state, conversion mappings and permitted intermediate states. Each transition needs meaningful invariants: which distinctions in old data survive, how old and new views agree, how concurrent writes are handled and which consumers are supported at each stage. Equal-looking endpoints do not prove every intermediate combination valid. F1 is an example of bounded version-skew reasoning; only its inspected abstract is transferred here, not its inaccessible full proof. [ESME-S029–031, ESME-S049; ESME-047–052.]

Incremental replacement needs seams and reconciled coexistence. Atomic replacement needs a justified outage/cutover and recovery or forward-repair case. A **returnability frontier** marks where available recovery options change because of lost information, external effects or removed compatibility. Crossing it can be authorised, but cannot be made safe merely by naming a rollback command. Completion requires evidence of transferred responsibilities and closure of temporary duplication, not just successor feature parity. [ESME-S062; analytical ESME-095–096.]

### 8. Technical-debt and lifecycle economics

A debt claim identifies a particular design/implementation condition, the future work whose cost it increases, who bears that cost, and the conditions under which the liability materialises. An ordinary missing feature or current defect is not automatically debt. Compare intervention cost, expected future burden, present user value, uncertainty, opportunity cost and remaining support horizon. A qualitative ranked comparison is preferable to invented precise return-on-investment figures. [ESME-S027–028, ESME-S057–058; ESME-056–062.]

The options include local repair, restructuring, compensating constraints, deferral, reduced support and retirement. Information acquired while waiting can change the decision; delay can also accumulate serious cost. Therefore “always repay” and “always defer” both fail. A debt record has value through a decision consumer; a scanner score is a diagnostic proxy, not calibrated money. Changes to the objective or support horizon can retire a previously sensible cleanup programme.

### 9. Human and ecosystem continuity

Model required maintenance activities against practical knowledge, access, authority, time, willingness and substitute capacity. Keep these dimensions distinct: commit authorship is evidence about contribution, not all competence; naming an owner does not give them time; documenting a process does not prove a successor can execute it. A handover can use a relevant task, review or rehearsal to expose the remaining knowledge gap without demanding an exhaustive duplicate of expertise. [ESME-S016–018, ESME-S032, ESME-S059–060; ESME-063–069/073.]

For dependencies, distinguish exposure from support capacity. A widely used package can create extensive obligations without providing anyone able or willing to satisfy them. Consumers need actionable compatibility/support information and feasible choices, not merely a notification count. Updating, pinning, substituting, supporting a bounded subset or ending use can each be appropriate. Community and volunteer constraints are real costs, not defects removable by another queue or nominal owner.

### 10. Deprecation, retirement and preservation

Separate the promises to discourage use, withdraw support, cease responding, retain historical source, reproduce an execution, and continue a live service. RFC 9745 and RFC 8594 define different HTTP signals; preservation frameworks may use related words differently. Establish the actual promised consequence and recipient. A delivered notice alone does not prove that dependent users can migrate. [ESME-S053–056; ESME-070–074.]

Retirement transitions obligations, not just files. Determine surviving data, consumer, support and archival duties; end live operation only within the actual authority and accepted consequences; verify the resulting state. Archival identity requires different resources from runnable preservation. Stable useful operation can continue without active expansion, and historical knowledge can be preserved without indefinite service operation. The termination witness is proportionate evidence that the relevant transition has actually ended, not a compulsory new document.

### Domain-profile use and limits

All 98 records supply the ten requested domain-profile fields. Family models above define the common objects and distinctions; each record adds its concrete trigger, affected artefacts, observer, assumptions and cheap path. Rejected claims retain profiles to show where they fail, not to create obligations. Learned components add training data, model/configuration versions and feedback effects within this same accounting; no universal equivalence between deterministic and learned behaviour is assumed. The notation in this section is the study’s explanatory modelling, not an imported theorem or an implementation specification.

## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CEREMONY_STRIPPING_LEDGER

Each entry preserves a real function before suggesting simplification. Omission is not justified merely by disliking documents or coordination. Every retained property also carries its own cheap path and retirement condition in the full ledger.

### ESME-Z001 — Mandatory maintenance-class form

**Property ids.** ESME-001; ESME-002; ESME-006

**Protected property and failure.** Shared objective and meaningful category comparisons, not one checked box.

**Consumer.** Requester, planner, maintainer

**Prerequisites.** Classification actually changes evidence or reporting.

**Minimal adequate alternative.** Concrete accepted issue and optional mixed-purpose labels.

**Trigger for fuller form.** Several purposes or reporting populations would otherwise be confused.

**Costs of simplification.** Less uniform statistics; still must preserve relevant distinctions.

**Omission or retirement conditions.** No consumer or decision relies on the labels.

### ESME-Z002 — Large baseline dossier

**Property ids.** ESME-004; ESME-041

**Protected property and failure.** Resolvable artefact/configuration identity; prevent wrong-subject comparisons.

**Consumer.** Builder, reviewer, future maintainer

**Prerequisites.** Relevant mutable inputs are identifiable.

**Minimal adequate alternative.** Version plus necessary dependency/configuration references and a tested command.

**Trigger for fuller form.** Generated builds, multiple variants or irreproducible external inputs.

**Costs of simplification.** A terse baseline may omit environment or data state.

**Omission or retirement conditions.** Retire superseded snapshots according to actual support/preservation duties, not merely age.

### ESME-Z003 — Complete architecture reconstruction before editing

**Property ids.** ESME-012; ESME-015; ESME-020

**Protected property and failure.** Enough recovery to justify a consequential change.

**Consumer.** Maintainer making the next decision

**Prerequisites.** A specific unresolved question warrants a model.

**Minimal adequate alternative.** Direct inspection, domain example or targeted view.

**Trigger for fuller form.** Conflicting static/dynamic/build observations or wide impact.

**Costs of simplification.** A local view can conceal a consequential nonlocal relation.

**Omission or retirement conditions.** Stop expansion when remaining unknowns cannot alter the bounded decision; retire stale unconsumed views.

### ESME-Z004 — Documentation volume or handover meeting attendance

**Property ids.** ESME-016; ESME-063; ESME-064

**Protected property and failure.** Transfer practical understanding and retained rationale.

**Consumer.** Successor who must maintain the system

**Prerequisites.** Access, time and a representative task.

**Minimal adequate alternative.** Focused explanation and checked example or supervised task.

**Trigger for fuller form.** Complex domain, high turnover or lost intent.

**Costs of simplification.** Tacit expertise can be lost despite a brief written account.

**Omission or retirement conditions.** No future consumer or obligation needs the material; preserve history only for a stated purpose.

### ESME-Z005 — Complete impact graph or co-change dashboard

**Property ids.** ESME-021; ESME-022; ESME-024

**Protected property and failure.** Defensible boundary across relevant dependency kinds.

**Consumer.** Reviewer and affected consumers

**Prerequisites.** Graphs have defined edge semantics and versions.

**Minimal adequate alternative.** Small explicit dependency argument with targeted checks.

**Trigger for fuller form.** Many consumers, generated/configuration effects or uncertain propagation.

**Costs of simplification.** Manual analysis may miss unexpected relationships.

**Omission or retirement conditions.** Discard stale edges and dashboards that no longer guide an actual impact decision.

### ESME-Z006 — Named refactoring/catalogue completion

**Property ids.** ESME-028; ESME-029; ESME-030; ESME-033

**Protected property and failure.** Preservation under valid preconditions and useful structural change.

**Consumer.** Tool operator, reviewer, future maintainer

**Prerequisites.** Declared observer and applicable language/tool conditions.

**Minimal adequate alternative.** Inspect a small transformation and test the relevant observations.

**Trigger for fuller form.** Bulk transformations or novel/unsafe tool versions.

**Costs of simplification.** Manual checks may omit systematic precondition failures.

**Omission or retirement conditions.** A catalogue label or campaign is omitted when it protects no additional obligation.

### ESME-Z007 — Green test dashboard and percentage targets

**Property ids.** ESME-034; ESME-035; ESME-036; ESME-037; ESME-038; ESME-039; ESME-040

**Protected property and failure.** New and surviving obligations supported by scoped evidence.

**Consumer.** Acceptance decision maker

**Prerequisites.** Valid oracle, harness and relevant population.

**Minimal adequate alternative.** Focused tests, domain reasoning or another adequate observation.

**Trigger for fuller form.** Large suites, hidden oracles, important state combinations or costly missed regressions.

**Costs of simplification.** Cheaper checks can lose rare-case or interaction coverage.

**Omission or retirement conditions.** Remove redundant tests only when their surviving obligation is still evidenced or legitimately retired.

### ESME-Z008 — Fixed daily integration or fixed-percentage canary

**Property ids.** ESME-042; ESME-043

**Protected property and failure.** Timely integration and attributable staged exposure.

**Consumer.** Contributors and release operators

**Prerequisites.** Joint work or isolatable live uncertainty actually exists.

**Minimal adequate alternative.** Direct build/test and straightforward release for a small safe change.

**Trigger for fuller form.** Concurrent interaction, production-only uncertainty, high exposure.

**Costs of simplification.** Less early live evidence; immediate release can concentrate loss.

**Omission or retirement conditions.** No relevant coupling/live uncertainty or inability to isolate safely makes this form inapplicable.

### ESME-Z009 — A rollback button or recovery document

**Property ids.** ESME-044; ESME-055; ESME-095

**Protected property and failure.** Actually achievable effect-relative restoration or forward repair.

**Consumer.** Operator and data consumer

**Prerequisites.** Restorable data/tooling and accepted loss bounds.

**Minimal adequate alternative.** Verified prior file for an isolated file edit.

**Trigger for fuller form.** Persistent state, schema changes or external effects.

**Costs of simplification.** Text-only recovery fails after irreversible effects.

**Omission or retirement conditions.** Retire recovery machinery only when the risk/obligation ends or a justified alternative replaces it.

### ESME-Z010 — Strangler branding or migration percentage complete

**Property ids.** ESME-047; ESME-048; ESME-049; ESME-052; ESME-096

**Protected property and failure.** Controlled transfer and a real exit from temporary dual support.

**Consumer.** Legacy/successor maintainers and consumers

**Prerequisites.** Feasible seams, data ownership and supported intermediate states.

**Minimal adequate alternative.** Local repair or rehearsed single cutover where superior.

**Trigger for fuller form.** Large separable replacement with valuable incremental feedback.

**Costs of simplification.** Atomic change concentrates risk; simplistic seams can hide data coupling.

**Omission or retirement conditions.** Close bridges after obligations transfer; deliberate permanent coexistence needs its own support justification.

### ESME-Z011 — Debt inventory, debt score or cleanup quota

**Property ids.** ESME-056; ESME-057; ESME-058; ESME-061; ESME-062

**Protected property and failure.** Visible material future-change liabilities and justified priority.

**Consumer.** Maintainers and value/cost decision makers

**Prerequisites.** A named future-cost mechanism and real decision consumer.

**Minimal adequate alternative.** Brief issue describing cause, impact and trade-off.

**Trigger for fuller form.** Cross-team architectural liabilities or repeated costly rediscovery.

**Costs of simplification.** Terse records can lose rationale and shifted costs.

**Omission or retirement conditions.** Liability disappears with changed use, replacement or retirement; remove metric-only items.

### ESME-Z012 — Minimum owner count or truck-factor target

**Property ids.** ESME-064; ESME-065; ESME-066; ESME-067

**Protected property and failure.** Real capacity, authority and succession.

**Consumer.** Supported users and working maintainers

**Prerequisites.** Willing capable participants, access and support horizon.

**Minimal adequate alternative.** Clear limited support policy plus demonstrable task capability.

**Trigger for fuller form.** Critical knowledge concentration or widening support commitments.

**Costs of simplification.** Single-person arrangements retain continuity risk even when honest.

**Omission or retirement conditions.** Narrow or end commitments that cannot be supported; do not infer mandatory unpaid staffing.

### ESME-Z013 — Dependency bot queue and broadcast deprecation notice

**Property ids.** ESME-068; ESME-069; ESME-070

**Protected property and failure.** Relevant update decisions and actionable consumer transition.

**Consumer.** Upstream/downstream maintainers

**Prerequisites.** Known actual use and viable recipient action.

**Minimal adequate alternative.** Targeted advisory and direct consumer agreement.

**Trigger for fuller form.** Many actual consumers, risky support loss or mixed-version transition.

**Costs of simplification.** Narrow communication can miss unknown reliance.

**Omission or retirement conditions.** Retire unsupported alerts and old notices only when their action/transition need ends.

### ESME-Z014 — Archive badge or indefinitely running obsolete service

**Property ids.** ESME-071; ESME-072

**Protected property and failure.** Required historical retrieval or ongoing service, distinctly specified.

**Consumer.** Future custodian or remaining service users

**Prerequisites.** Stated purpose, rights, horizon and actual capability.

**Minimal adequate alternative.** Source snapshot and rationale when execution is unnecessary.

**Trigger for fuller form.** Reproduction/revival or ongoing contractual service needs.

**Costs of simplification.** Source-only preservation may not recover the executable environment.

**Omission or retirement conditions.** Dispose or stop operating when obligations end; do not conflate archival preservation with endless uptime.

### ESME-Z015 — Agent count, benchmark leaderboard or mandatory AI reviewer

**Property ids.** ESME-076; ESME-077; ESME-078; ESME-079; ESME-080; ESME-081; ESME-082; ESME-087; ESME-090

**Protected property and failure.** Candidate correctness, valid evaluation and beneficial bounded delegation.

**Consumer.** Maintainer accepting real changes

**Prerequisites.** Aligned objective, valid evidence and actual authority.

**Minimal adequate alternative.** Human correction or a small targeted independent check.

**Trigger for fuller form.** Repeated suitable tasks and demonstrated total-work benefit.

**Costs of simplification.** Manual routes may forgo throughput; extra agents can share the same mistake.

**Omission or retirement conditions.** Stop or restrict assistance when changed versions or hidden review costs invalidate its benefit.

### ESME-Z016 — A new control, form or owner for each extracted property

**Property ids.** ESME-093; ESME-094; ESME-095; ESME-096; ESME-097; ESME-098

**Protected property and failure.** Coherent obligation/evidence/effect coupling across the selected system.

**Consumer.** Existing decision makers and maintainers

**Prerequisites.** Each added mechanism covers a real unresolved failure or coordination need.

**Minimal adequate alternative.** One concise change account plus existing baseline/tests/communication.

**Trigger for fuller form.** Conflicting intent, uncertain impact, multi-state migration or evidence invalidation.

**Costs of simplification.** Over-simplification can erase who accepts irreversibility or which oracle is legitimate.

**Omission or retirement conditions.** Remove duplicate/obsolete controls with a coverage argument; frozen provenance remains even when implementation is shared.


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CRITICISM_LEDGER

The following objections alter selection, assumptions or claim strength. “Later findings” are distinguished from a demonstrated historical causal response. Broader adversarial counterexamples are analytical unless the entry identifies an observed study or incident. Source locators identify what was actually inspected.

### ESME-C001

**Affected property ids.** ESME-002; ESME-006

**Source and locator.** Source id: ESME-S001; Locators: Official scope; preview §§3.1.1–3.1.14; Figure 1 within §3.1.8 notes (printed p.4); §4 Conformance (printed p.5); opening §§5.1–5.2; Source id: ESME-S004; Locators: §§1–3: purpose versus observable activity; twelve types in four clusters; conclusion; Appendix A definitions; Source id: ESME-S005; Locators: §§2–3, especially dimensions of when, what, how and where; Figure 1 on printed p.312; Source id: ESME-S007; Locators: Abstract: three products, two granularities, comparison with Lientz–Swanson–Tompkins survey; Source id: ESME-S041; Locators: Visual cover; chapter 7 §§1.1–1.6 and §§3.1–3.2.2; Figure 7.2; selected chapter 6 interface

**Strongest objection.** A familiar four-category classification can erase additive work, mixed purposes and observable activity differences.

**Evidence.** New standard terminology plus rival taxonomies; measured/survey distributions differ in an abstract-access study.

**Response.** Use purpose, activity, artefact and timing dimensions only where useful.

**Later findings.** 2022 ISO terminology and visible SWEBOK v4.0a preserve additive maintenance.

**Present judgement.** ESME-006 superseded; ESME-002 retained in evolved form.

**Residual uncertainty.** No single taxonomy is proved optimal for every decision; original Swanson text was not directly accessible.

### ESME-C002

**Affected property ids.** ESME-007; ESME-008; ESME-009; ESME-010; ESME-011

**Source and locator.** Source id: ESME-S008; Locators: Opening problem and OS/360 setting; process-model discussion; Source id: ESME-S009; Locators: Introduction; discussion distinguishing software change from physical wear; S/P/E programme classification; Source id: ESME-S010; Locators: §§1–3; eight-law table; E-type scope; FEAST feedback discussion; Source id: ESME-S011; Locators: §5 Linux measurement; source-file scope and growth discussion; figures inspected; Source id: ESME-S012; Locators: §§5–6, stable-release trends; conclusion; plots inspected

**Strongest objection.** Historical evolution regularities become unfalsifiable or wrong when all software, metrics and organisations are conflated.

**Evidence.** IBM, Linux and FreeBSD settings differ; stable and development-release sampling alter trajectories.

**Response.** Keep E-type/environment scope and explicit measurement units; investigate rather than prescribe growth.

**Later findings.** Subsequent studies broaden populations but do not make them statistically independent.

**Present judgement.** Universal growth and invariant-rate prescriptions rejected; feedback retained conditionally.

**Residual uncertainty.** No universal causal law or accurate staffing model established.

### ESME-C003

**Affected property ids.** ESME-012; ESME-015; ESME-016; ESME-018; ESME-063; ESME-064

**Source and locator.** Source id: ESME-S014; Locators: pp.13–17; p.14 abstraction diagram and iteration qualification; p.15 definitions; p.16 recovery limits; Source id: ESME-S016; Locators: Reprint pp.229 and 232: transfer experiences, theory building and modification costs; original paper identity on first page; Source id: ESME-S017; Locators: §3 study design; question categorisation and iterative inquiry findings; Source id: ESME-S018; Locators: Introduction; activity-classification design; discussion and validity cautions

**Strongest objection.** Documentation or a model can exist while people still cannot perform the required maintenance.

**Evidence.** Primary theory-building cases and observed programmer-question/work studies; no universal comprehension percentage inferred.

**Response.** Use question-led inquiry and practical successor capability, not exhaustive model completion.

**Later findings.** View fusion helps reconstruct relations but does not automatically recover intent (ESME-S044).

**Present judgement.** Exhaustive prerequisite rejected; redocumentation becomes consumer-bound.

**Residual uncertainty.** Tacit knowledge may be unavailable; documentation can still be valuable without replacing expertise.

### ESME-C004

**Affected property ids.** ESME-013; ESME-014; ESME-020

**Source and locator.** Source id: ESME-S015; Locators: pp.352–357: slicing criterion, conservative construction, minimality limits and experiment; Source id: ESME-S043; Locators: pp.246–247: execution-specific criterion; dependence graphs; relationship to static slicing; Source id: ESME-S044; Locators: Opening; View Fusion; How Dali Works; conclusion

**Strongest objection.** Static and dynamic analyses omit different things and cannot simply be added into complete knowledge.

**Evidence.** Conservative slicing versus execution-specific dependencies; view extraction requires analyst interpretation.

**Response.** Declare the criterion, supported semantics and observed executions; investigate contradictory views.

**Later findings.** Later recovery work fuses build and runtime information rather than relying on one representation.

**Present judgement.** Static slicing assumption-sensitive; dynamic and fused views conditional.

**Residual uncertainty.** Minimal arbitrary slicing is not generally computable; missing intent remains outside these analyses.

### ESME-C005

**Affected property ids.** ESME-021; ESME-022; ESME-023; ESME-024

**Source and locator.** Source id: ESME-S020; Locators: §6 evaluation and §6.8 threats; time-ordered history, changed-entity recommendations; Source id: ESME-S024; Locators: §§III–IV; §VI; result table visually inspected; Source id: ESME-S044; Locators: Opening; View Fusion; How Dali Works; conclusion

**Strongest objection.** Historical co-editing and source-only dependencies can misidentify or miss propagation.

**Evidence.** History-based recommendations have misses; RTSCheck exposes non-code technique limits and implementation defects.

**Response.** Use co-change as a lead, and state dependency kinds actually covered.

**Later findings.** Modern learned/configuration systems add further non-code dependencies (ESME-S061).

**Present judgement.** Necessary-dependency inference rejected; impact closure explicitly multi-artefact.

**Residual uncertainty.** An open ecosystem cannot generally supply a complete known consumer set.

### ESME-C006

**Affected property ids.** ESME-025; ESME-026; ESME-028; ESME-029

**Source and locator.** Source id: ESME-S021; Locators: Abstract and introduction: framework/library API changes and client adaptation; Source id: ESME-S022; Locators: Abstract; §4.1 preconditions; printed p.42 excluded language-observation features; Source id: ESME-S067; Locators: Introduction; declared public API; major/minor/patch rules

**Strongest objection.** A source-level refactoring or compatible version label can still break an external observer.

**Evidence.** Opdyke excludes representation-dependent observations; API evolution requires client adaptation; SemVer is a convention.

**Response.** Name observer and support contract, then check actual client behaviour and transformation preconditions.

**Later findings.** Mixed-version schema work adds constraints on intermediate readers/writers (ESME-S049, abstract only).

**Present judgement.** Observer-relative preservation retained; proof by version label rejected.

**Residual uncertainty.** Full observations may be costly or impossible to enumerate; bounded support promises are necessary.

### ESME-C007

**Affected property ids.** ESME-029; ESME-030; ESME-033

**Source and locator.** Source id: ESME-S045; Locators: Introduction; ASTGen generation/oracles; §5.1 engine evaluation; Source id: ESME-S024; Locators: §§III–IV; §VI; result table visually inspected

**Strongest objection.** A theoretically valid transformation does not validate a buggy engine or test selector.

**Evidence.** ASTGen and RTSCheck identify concrete tool failures, with generated-population and oracle limitations.

**Response.** Validate the relevant implementation/version and distinguish a violated premise from a refuted theorem.

**Later findings.** Different validation studies share a method family but are not a general deployed failure-rate estimate.

**Present judgement.** Tool validation retained; catalogue compliance is not a property.

**Residual uncertainty.** Bounded engine tests still cannot establish all-input correctness.

### ESME-C008

**Affected property ids.** ESME-031; ESME-032; ESME-058; ESME-062

**Source and locator.** Source id: ESME-S023; Locators: Study design, results, Apache example and conclusions; Source id: ESME-S057; Locators: §4.1 study design/training; §4.1.7 replication; reported work-activity comparisons; Source id: ESME-S058; Locators: §1 inherited 2016 definition; §§2.1–2.3 values/beliefs/principles; §3.1 value creation and uncertainty

**Strongest objection.** Cleaner-looking code or a lower score may not reduce future maintenance effort.

**Evidence.** Refactoring-labelled histories show nonuniform metric effects; debt effort is self-reported rather than counterfactual savings.

**Response.** Identify future change class, relevant outcome and uncertainty; compare local repair and deferral.

**Later findings.** The 2025 debt manifesto criticises one-size-fits-all metrics and over-detailed tool inventories.

**Present judgement.** Metrics retained only as easily gamed diagnostics; universal savings index rejected.

**Residual uncertainty.** Longitudinal causal return on specific restructuring remains difficult to identify.

### ESME-C009

**Affected property ids.** ESME-034; ESME-035; ESME-039; ESME-040; ESME-076; ESME-079; ESME-091; ESME-098

**Source and locator.** Source id: ESME-S025; Locators: Introduction and oracle definitions; taxonomy of oracle information sources; Source id: ESME-S034; Locators: Introduction; evaluation-harness and plausibility/correctness distinction; deletion baseline; Source id: ESME-S063; Locators: §3 method; §§4.1–4.4 tests, discrepancies and manual correctness; §5.3 threats; Source id: ESME-S064; Locators: §2.1 benchmark annotation; misalignment taxonomy; §7 threats

**Strongest objection.** A test or reference patch can be wrong, irrelevant or unable to disambiguate the intended behaviour.

**Evidence.** Classical APR reanalysis and 2026 issue/patch studies expose plausibility, correctness and objective mismatch.

**Response.** Separate new/preserved obligations and adjudicate references against authorised intent.

**Later findings.** ESME-S063 manually found four valid suspicious alternatives and 51 uncertain cases; ESME-S064 studies explicit PR-issue mismatch.

**Present judgement.** Test-passage proof and preserve-everything claims rejected; independent oracle-revision warrant added.

**Residual uncertainty.** Some requirements remain genuinely underspecified even after additional tests.

### ESME-C010

**Affected property ids.** ESME-036; ESME-037; ESME-038; ESME-077

**Source and locator.** Source id: ESME-S024; Locators: §§III–IV; §VI; result table visually inspected; Source id: ESME-S026; Locators: Opening pp.173–175: P/P′, specification/test-set setting and safe selection objective; Source id: ESME-S046; Locators: §3.3.4–§3.3.6 validity: seeded/real faults, programme size and cost measures; Source id: ESME-S047; Locators: Institutional abstract and bibliographic record; Source id: ESME-S048; Locators: Introduction; §2 real-fault isolation and dataset construction; printed p.656 figures/table

**Strongest objection.** Selection, prioritisation and mutation address different objectives and can give false confidence about coverage.

**Evidence.** Suite-relative safety, partial access to early priority results, seeded-fault limitations and selected real-fault populations.

**Response.** Choose by the evidence objective; fall back where selection assumptions fail; do not treat an order/score as an oracle.

**Later findings.** RTSCheck shows unsupported non-code dependencies in real tool versions.

**Present judgement.** All three techniques remain conditional; harness validation is a separate obligation.

**Residual uncertainty.** No generally best cost/adequacy trade-off or automatic all-obligation coverage established.

### ESME-C011

**Affected property ids.** ESME-041; ESME-042; ESME-043; ESME-044; ESME-055

**Source and locator.** Source id: ESME-S049; Locators: Official abstract: formal model, transition sequence and bounded schema-version skew; Source id: ESME-S050; Locators: Role of release engineers; philosophy; building reproducible binaries/configurations and coordinating releases; Source id: ESME-S051; Locators: Requirements of a Canary Process; Choosing a Canary Population and Duration; Selecting and Evaluating Metrics; artificial load and traffic teeing limitations; Source id: ESME-S052; Locators: Introduction; §II.C reproducible-build requirements; §III.E limitations and threats to validity; Source id: ESME-S062; Locators: Broken recovery procedures; actual restore sequence; database-tool mismatch; corrective-action discussion

**Strongest objection.** A green pipeline, reproducible build or successful canary can coexist with nonrecoverable state damage.

**Evidence.** Package-manager assumptions, nonrepresentative/shared canary state and a primary failed-recovery incident.

**Response.** Distinguish artefact identity, regression, exposure and effect-relative recovery.

**Later findings.** Recent packaging evidence broadens environments but does not prove correct source or arbitrary restoration.

**Present judgement.** Code-revert equivalence rejected; staged exposure conditional; returnability frontier added.

**Residual uncertainty.** Unobserved external actions can make rollback impossible even with intact source history.

### ESME-C012

**Affected property ids.** ESME-045; ESME-046; ESME-047; ESME-048; ESME-049; ESME-052; ESME-053; ESME-054

**Source and locator.** Source id: ESME-S013; Locators: §§1–2; staged model Figure 1; evolution/servicing knowledge distinction; phaseout and closedown; Source id: ESME-S029; Locators: Legacy migration alternatives; §2.3.2 Chicken Little and gateways; Butterfly discussion; Source id: ESME-S030; Locators: Original account and Chris Stevenson project context; Source id: ESME-S031; Locators: Updated replacement-pattern explanation and conditions; Source id: ESME-S055; Locators: Purpose, horizon, cost, capability and capacity questions; seven preservation/sustainability options

**Strongest objection.** Modernisation accounts select visible successes and underestimate domain knowledge and temporary dual-system cost.

**Evidence.** Review-level migration difficulties; early strangler account is interim, not a completed comparative trial.

**Response.** Compare continued servicing, repair, incremental/atomic replacement and retirement; require seams and exit evidence.

**Later findings.** Updated practitioner explanations are not independent replications.

**Present judgement.** No newest-platform or never-rewrite rule survives; alternatives remain conditional.

**Residual uncertainty.** Evidence does not rank migration strategies across all system sizes and organisational contexts.

### ESME-C013

**Affected property ids.** ESME-050; ESME-051; ESME-095; ESME-096

**Source and locator.** Source id: ESME-S029; Locators: Legacy migration alternatives; §2.3.2 Chicken Little and gateways; Butterfly discussion; Source id: ESME-S049; Locators: Official abstract: formal model, transition sequence and bounded schema-version skew; Source id: ESME-S062; Locators: Broken recovery procedures; actual restore sequence; database-tool mismatch; corrective-action discussion

**Strongest objection.** Correct endpoints do not establish a safe intermediate conversion or a meaningful rollback.

**Evidence.** Migration review identifies heterogeneous-update difficulty; F1 abstract imposes bounded version skew; actual backup recovery failed in GitLab.

**Response.** Check conversion semantics, intermediate combinations and the point beyond which recovery changes.

**Later findings.** Returnability and termination-witness properties are this study’s analytical coupling, not source-named mechanisms.

**Present judgement.** Intermediate compatibility is assumption-sensitive and exit/recovery claims require explicit evidence.

**Residual uncertainty.** The full F1 proof was inaccessible; no theorem-level transfer beyond its complete protocol is claimed.

### ESME-C014

**Affected property ids.** ESME-056; ESME-057; ESME-058; ESME-059; ESME-060; ESME-061

**Source and locator.** Source id: ESME-S027; Locators: Author text: incremental development, consolidation and debt metaphor; Source id: ESME-S028; Locators: Technical-debt definition and debt-item/cause/consequence discussion; Source id: ESME-S057; Locators: §4.1 study design/training; §4.1.7 replication; reported work-activity comparisons; Source id: ESME-S058; Locators: §1 inherited 2016 definition; §§2.1–2.3 values/beliefs/principles; §3.1 value creation and uncertainty

**Strongest objection.** Debt can become a label for everything, a falsely precise financial quantity or an excuse for endless cleanup.

**Evidence.** Historical metaphor, later working definition, self-report burden and explicit 2025 criticism of metric-only practice.

**Response.** Specify the liability-producing future work, affected cost bearer and value of alternatives.

**Later findings.** Current manifesto distinguishes beliefs and principles from demonstrated causal outcomes.

**Present judgement.** Zero-debt target rejected; records consumer-bound; deferral retained conditionally.

**Residual uncertainty.** Principal, interest and option values often lack calibrated estimates.

### ESME-C015

**Affected property ids.** ESME-064; ESME-065; ESME-066; ESME-067; ESME-068; ESME-069; ESME-073

**Source and locator.** Source id: ESME-S016; Locators: Reprint pp.229 and 232: transfer experiences, theory building and modification costs; original paper identity on first page; Source id: ESME-S032; Locators: Abstract, authorship-based estimation and validation discussion; Source id: ESME-S033; Locators: Dataset and network-growth/dependency measures; interpretation and limits; Source id: ESME-S059; Locators: Abstract: interviews and contributor assessment; communication and technical excellence; Source id: ESME-S060; Locators: §3 recruitment/analysis/limitations; §5.5 support opportunities; participant setting

**Strongest objection.** Public code, commit counts, popularity and sent notifications do not ensure available maintenance capability.

**Evidence.** Partial truck-factor validation, selected maintainer accounts, advisory-sampled burden and dependency-network exposure.

**Response.** Check willingness/capability/support scope; use metrics as questions and communicate actionable transitions.

**Later findings.** Recent maintainer work adds security-related workload without establishing universal volunteer obligations.

**Present judgement.** Popularity guarantee rejected; realistic capacity and succession retained.

**Residual uncertainty.** Opaque upstreams and disappearing expertise can remain genuine unsupported risks.

### ESME-C016

**Affected property ids.** ESME-070; ESME-071; ESME-072

**Source and locator.** Source id: ESME-S053; Locators: §1.4 deprecation versus decommissioning; §§3–5 field semantics and scope; Source id: ESME-S054; Locators: Opening and field purpose; §7 Security Considerations; relation to Sunset; Source id: ESME-S055; Locators: Purpose, horizon, cost, capability and capacity questions; seven preservation/sustainability options; Source id: ESME-S056; Locators: Introduction; §§1–2 preparing and saving source; archival referencing explanation

**Strongest objection.** Deprecation, shutdown, archival retrieval and runnable preservation are different promises.

**Evidence.** RFCs specify different signals; preservation guidance uses different vocabulary and options.

**Response.** State the actual support transition and future preservation consumer.

**Later findings.** 2025 RFC 9745 gives a standard signal but not evidence of adoption or successful migration.

**Present judgement.** Domain-specific signalling retained; responsible retirement and purpose-bounded preservation remain alternatives.

**Residual uncertainty.** Legal retention/deletion obligations must be established separately for any real target.

### ESME-C017

**Affected property ids.** ESME-075

**Source and locator.** Source id: ESME-S013; Locators: §§1–2; staged model Figure 1; evolution/servicing knowledge distinction; phaseout and closedown; Source id: ESME-S014; Locators: pp.13–17; p.14 abstraction diagram and iteration qualification; p.15 definitions; p.16 recovery limits; Source id: ESME-S016; Locators: Reprint pp.229 and 232: transfer experiences, theory building and modification costs; original paper identity on first page; Source id: ESME-S044; Locators: Opening; View Fusion; How Dali Works; conclusion

**Strongest objection.** A stage label can overstate irreversible loss of evolution capability.

**Evidence.** Roadmap proposes a strong servicing transition; recovery mechanisms show possible routes to regain some understanding.

**Response.** Test bounded knowledge-recovery and real change capability rather than infer impossibility.

**Later findings.** No general comparative cost threshold for recovery versus replacement established.

**Present judgement.** ESME-075 CONTESTED; not an unconditional audit requirement.

**Residual uncertainty.** Recovered knowledge may still be too expensive or incomplete for useful renewed evolution.

### ESME-C018

**Affected property ids.** ESME-078; ESME-079; ESME-080; ESME-088

**Source and locator.** Source id: ESME-S035; Locators: Dataset construction; issue/PR/test extraction; evaluation and limitations; Source id: ESME-S036; Locators: §2.2 experimental design; main result; Appendix D estimator; figure and issue examples inspected; Source id: ESME-S037; Locators: Opening result qualification; participation and task-selection mechanisms; redesigned-study discussion; Source id: ESME-S063; Locators: §3 method; §§4.1–4.4 tests, discrepancies and manual correctness; §5.3 threats; Source id: ESME-S064; Locators: §2.1 benchmark annotation; misalignment taxonomy; §7 threats; Source id: ESME-S065; Locators: Background; selected-task audit; contamination probes and limitations

**Strongest objection.** Benchmark success can fail to transfer through contaminated history, objective mismatch or omitted human work.

**Evidence.** Task-level randomisation, adverse benchmark reanalyses and supplier contamination probes have different units and biases.

**Response.** Require provenance and target-workflow comparisons; keep selected-sample denominators explicit.

**Later findings.** 2026 METR follow-up explicitly lacks a reliable speed estimate; its point estimates do not settle the question.

**Present judgement.** Unrestricted autonomy rejected; long-term maintainability benefit UNRESOLVED.

**Residual uncertainty.** Representative multi-release data and stable comparison conditions are lacking in the inspected corpus.

### ESME-C019

**Affected property ids.** ESME-081; ESME-082; ESME-083

**Source and locator.** Source id: ESME-S038; Locators: Study design and prompt/model-version comparison; threats to validity; Source id: ESME-S039; Locators: Experimental design; memory, runtime, energy and repair outcomes; validity section; Source id: ESME-S040; Locators: BuCoR design and build-conflict evaluation; Source id: ESME-S066; Locators: §4.1 dataset; SAM method outline; §7 threats to validity

**Strongest objection.** Automation performance and failure classes change with model/tool/version/resource context.

**Evidence.** 2026 prompt-ageing and quantisation studies; build-conflict and semantic-interference methods cover only particular tasks.

**Response.** Revalidate changed assumptions and choose by total relevant cost and outcome, not headline scores.

**Later findings.** Accepted 2026 preprints are evidence of experiments, not completed future conference presentations or independent replications.

**Present judgement.** Version-bound evidence retained; resource/conflict techniques domain-specific.

**Residual uncertainty.** General transfer across languages, task sizes, hardware and maintained products is not established.

### ESME-C020

**Affected property ids.** ESME-084; ESME-085; ESME-086

**Source and locator.** Source id: ESME-S005; Locators: §§2–3, especially dimensions of when, what, how and where; Figure 1 on printed p.312; Source id: ESME-S024; Locators: §§III–IV; §VI; result table visually inspected; Source id: ESME-S041; Locators: Visual cover; chapter 7 §§1.1–1.6 and §§3.1–3.2.2; Figure 7.2; selected chapter 6 interface; Source id: ESME-S061; Locators: §§1–2 debt import and entanglement; §5 system patterns; §6 configuration

**Strongest objection.** Code-only evolution misses learned, data, configuration and documentation effects; naive drift detection can also redefine values without authority.

**Evidence.** Industrial ML debt patterns and non-code RTS failures establish concrete reasons to widen scope.

**Response.** Apply artefact-appropriate evidence and distinguish distributional change from authorised objective revision.

**Later findings.** This is domain translation, not a complete safety/security/ML governance synthesis.

**Present judgement.** Non-code validation retained; learned-system feedback assumption-sensitive.

**Residual uncertainty.** Normative outcome criteria and causal feedback models need target-specific evidence.

### ESME-C021

**Affected property ids.** ESME-093; ESME-094; ESME-095; ESME-096; ESME-097; ESME-098

**Source and locator.** Source id: ESME-S019; Locators: Product space, workspaces, change sets and merging; explicit limitations of textual three-way merge; Source id: ESME-S025; Locators: Introduction and oracle definitions; taxonomy of oracle information sources; Source id: ESME-S029; Locators: Legacy migration alternatives; §2.3.2 Chicken Little and gateways; Butterfly discussion; Source id: ESME-S041; Locators: Visual cover; chapter 7 §§1.1–1.6 and §§3.1–3.2.2; Figure 7.2; selected chapter 6 interface; Source id: ESME-S051; Locators: Requirements of a Canary Process; Choosing a Canary Population and Duration; Selecting and Evaluating Metrics; artificial load and traffic teeing limitations; Source id: ESME-S058; Locators: §1 inherited 2016 definition; §§2.1–2.3 values/beliefs/principles; §3.1 value creation and uncertainty

**Strongest objection.** The proposed composition could become a heavy parallel bureaucracy that costs more than it protects.

**Evidence.** Analytical objection using documented comprehension, test, migration and debt-control costs; no experiment of this compound model exists.

**Response.** Require an actual consumer, protected failure and cheap-path discriminator; permit shared controls and explicit omission.

**Later findings.** Composition-induced properties are hypotheses about coupling, not claims of new proven universal machinery.

**Present judgement.** The smallest coherent form is retained; blanket application of all 78 crosswalk-worthy rows is rejected.

**Residual uncertainty.** Target trials would be needed to estimate net coordination/evidence cost and reveal unforeseen interactions.

### ESME-C022

**Affected property ids.** ESME-001; ESME-005; ESME-035; ESME-044; ESME-069; ESME-074; ESME-089; ESME-098

**Source and locator.** Source id: ESME-S001; Locators: Official scope; preview §§3.1.1–3.1.14; Figure 1 within §3.1.8 notes (printed p.4); §4 Conformance (printed p.5); opening §§5.1–5.2; Source id: ESME-S025; Locators: Introduction and oracle definitions; taxonomy of oracle information sources; Source id: ESME-S041; Locators: Visual cover; chapter 7 §§1.1–1.6 and §§3.1–3.2.2; Figure 7.2; selected chapter 6 interface; Source id: ESME-S054; Locators: Opening and field purpose; §7 Security Considerations; relation to Sunset; Source id: ESME-S063; Locators: §3 method; §§4.1–4.4 tests, discrepancies and manual correctness; §5.3 threats; Source id: ESME-S064; Locators: §2.1 benchmark annotation; misalignment taxonomy; §7 threats

**Strongest objection.** Continuity, emergency action and necessary revision may conflict; preserving every constraint simultaneously can be impossible.

**Evidence.** Taxonomies distinguish change purposes; real patch studies show uncertain intent; protocol transitions can revise support expectations.

**Response.** Identify the conflict, authorised trade-off and affected consumer; narrow or stop the intervention where neither evidence nor authority is adequate.

**Later findings.** The synthesis separates distinction, authority, action and consequence rather than treating correct analysis as permission.

**Present judgement.** Conditional unification with explicit alternatives, not universal simultaneous satisfaction.

**Residual uncertainty.** The corpus cannot supply a missing real-system decision maker or settle a disputed external obligation.


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_EVOLUTION_UNDER_CRITICISM

A transition describes the justified change in mechanism or claim, not a monotonic ranking of schools. Domain-specific alternatives and unsettled questions remain visible. The last row is the present analytical composition, not evidence that an academic field has already adopted it.

| Branch | Transition | Changed mechanism or assumption | Properties | Sources |
| --- | --- | --- | --- | --- |
| Purpose taxonomy | REFINED | Purpose/activity distinctions and 2022 additive terminology replace false four-category exhaustiveness. | ESME-001, ESME-002, ESME-006 | ESME-S001, ESME-S004, ESME-S005, ESME-S007, ESME-S041 |
| Evolution laws | NARROWED | Preserve environment/feedback questions; reject universal growth and invariant-rate prescriptions. | ESME-007, ESME-008, ESME-009, ESME-010, ESME-011 | ESME-S008, ESME-S009, ESME-S010, ESME-S011, ESME-S012 |
| Comprehension and recovery | REFINED | Question-led sufficient understanding and view interpretation replace exhaustive-document proxies. | ESME-012, ESME-015, ESME-016, ESME-018, ESME-019, ESME-020 | ESME-S014, ESME-S016, ESME-S017, ESME-S018, ESME-S044 |
| Static/dynamic slicing | DOMAIN_SPECIFIC | Distinct model and execution scopes remain alternatives, not a universal stronger combined oracle. | ESME-013, ESME-014 | ESME-S015, ESME-S043 |
| History-based impact | NARROWED | Historical recommendations guide inquiry; semantic and non-code dependencies determine actual obligations. | ESME-021, ESME-022, ESME-023, ESME-024 | ESME-S020, ESME-S024 |
| Refactoring validity | PRESERVED | Keep observer-relative rules and preconditions; separately validate actual engines rather than abandoning the model. | ESME-028, ESME-029, ESME-030 | ESME-S021, ESME-S022, ESME-S045 |
| Refactoring payoff | NARROWED | Future-work benefit needs a scenario/outcome; catalogue or metric improvement alone is not benefit. | ESME-031, ESME-032, ESME-033, ESME-062 | ESME-S023, ESME-S057, ESME-S058 |
| Regression techniques | REFINED | Keep suite/ordering/fault-model scopes distinct and require justified oracles. | ESME-034, ESME-035, ESME-036, ESME-037, ESME-038, ESME-039, ESME-040 | ESME-S024, ESME-S025, ESME-S026, ESME-S046, ESME-S047, ESME-S048 |
| Release continuity | HYBRIDISED | Combine artefact identity, representative exposure and effect-level recovery without equating their guarantees. | ESME-041, ESME-042, ESME-043, ESME-044, ESME-055 | ESME-S049, ESME-S050, ESME-S051, ESME-S052, ESME-S062 |
| Migration strategies | DOMAIN_SPECIFIC | Incremental and atomic alternatives persist; coexistence invariants and exit conditions discriminate. | ESME-045, ESME-046, ESME-047, ESME-048, ESME-049, ESME-050, ESME-051, ESME-052, ESME-053, ESME-054 | ESME-S013, ESME-S029, ESME-S030, ESME-S031, ESME-S049 |
| Debt metaphor and practice | REFINED | Liability, cost bearers and decision value replace an undifferentiated inventory of undesirable work. | ESME-056, ESME-057, ESME-058, ESME-059, ESME-060 | ESME-S027, ESME-S028, ESME-S057, ESME-S058 |
| Zero-debt optimisation | REJECTED | Repayment and metric targets are not ends independent of current value and support horizon. | ESME-061, ESME-062 | ESME-S057, ESME-S058 |
| Human continuity proxies | REFINED | Practical capability and consumer action qualify authorship, popularity and notification proxies. | ESME-063, ESME-064, ESME-065, ESME-066, ESME-067, ESME-068, ESME-069, ESME-073 | ESME-S016, ESME-S032, ESME-S033, ESME-S059, ESME-S060 |
| Servicing irreversibility | STILL_CONTESTED | A stage-model diagnosis is retained as a warning, not a theorem forbidding economic knowledge recovery. | ESME-075 | ESME-S013, ESME-S014, ESME-S016, ESME-S044 |
| Generated program repair | REFINED | Patches remain candidates; harness, benchmark, objective alignment and total human work constrain evaluation. | ESME-076, ESME-077, ESME-078, ESME-079, ESME-080, ESME-081, ESME-087, ESME-090 | ESME-S034, ESME-S035, ESME-S036, ESME-S037, ESME-S063, ESME-S064, ESME-S065 |
| Learned-software maintenance | DOMAIN_SPECIFIC | Data/configuration/feedback dependencies extend relevant artefacts but do not transfer deterministic guarantees automatically. | ESME-084, ESME-085, ESME-086 | ESME-S061 |
| Long-term AI maintainability | STILL_CONTESTED | Examined evidence does not establish a general multi-release net improvement or universal harm. | ESME-088 | ESME-S036, ESME-S037, ESME-S038, ESME-S063, ESME-S064 |
| Present within-tradition composition | REFINED | Analytical coupling adds mismatch, staleness, exit and circularity controls; not claimed historical maturation or validated superiority. | ESME-093, ESME-094, ESME-095, ESME-096, ESME-097, ESME-098 | ESME-S019, ESME-S025, ESME-S029, ESME-S049, ESME-S051, ESME-S058, ESME-S062, ESME-S063, ESME-S064 |


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_INTERNAL_TENSIONS

The discriminator, rather than the word “balance”, does the decision work. A supported hybrid is conditional and can be worse than either alternative when its coordination or semantic assumptions fail.

### ESME-T01

**Property ids.** ESME-001; ESME-028; ESME-034; ESME-035; ESME-069; ESME-091; ESME-098

**Values.** Continuity of relied-on behaviour versus necessary correction/adaptation.

**Costs.** Preserving faults harms users; breaking relied-on behaviour creates transition cost.

**Favours first.** A legitimate supported consumer relies on the behaviour and no authorised revision exists.

**Favours second.** The behaviour violates the accepted objective or an authorised new obligation, with consequences addressed.

**Supported hybrid.** Compatibility window or explicit old/new mode with tested semantics and support horizon.

**Hybrid failure.** Two ambiguous meanings, unmaintained compatibility mode, or an oracle changed solely to pass.

**Discriminator.** Identify the actual obligation, consumer and authorisation for revision; unresolved authority blocks that revision, not unrelated work.

**Uncertainty.** Existing usage does not itself establish legitimacy; disagreement can persist.

**Source ids.** ESME-S001; ESME-S022; ESME-S025; ESME-S041; ESME-S063; ESME-S064

### ESME-T02

**Property ids.** ESME-010; ESME-012; ESME-015; ESME-031; ESME-063; ESME-064

**Values.** Familiarity and domain knowledge versus simplification of costly structure.

**Costs.** Change can destroy valuable tacit knowledge; non-change can retain avoidable complexity.

**Favours first.** Few expected changes, scarce expertise and useful stable behaviour.

**Favours second.** Repeated task-specific cost and credible ability to transfer knowledge.

**Supported hybrid.** Small verified transformations with retained rationale and representative maintenance tasks.

**Hybrid failure.** Long-lived mixed styles and half-transferred knowledge make both old and new harder to understand.

**Discriminator.** Compare demonstrated next-change capability and total transition cost, not complexity score alone.

**Uncertainty.** Future demand and learning cost remain uncertain.

**Source ids.** ESME-S013; ESME-S016; ESME-S018; ESME-S023; ESME-S058

### ESME-T03

**Property ids.** ESME-021; ESME-031; ESME-045; ESME-046; ESME-047; ESME-048; ESME-049; ESME-052

**Values.** Local repair versus structural replacement.

**Costs.** A cheap patch may compound systemic cost; replacement can lose hidden requirements and create dual support.

**Favours first.** Bounded impact, adequate support and a short or stable horizon.

**Favours second.** Required capability cannot be supported economically by available local changes.

**Supported hybrid.** Incremental transfer over validated seams with explicit exit.

**Hybrid failure.** Permanent adapters and dual data authorities add migration cost without eliminating legacy cost.

**Discriminator.** Compare feasible obligations, seam/data constraints and prospective costs including the exit, not sunk effort.

**Uncertainty.** Published migration accounts rarely establish representative comparative rates.

**Source ids.** ESME-S013; ESME-S029; ESME-S030; ESME-S031; ESME-S055; ESME-S058

### ESME-T04

**Property ids.** ESME-030; ESME-076; ESME-077; ESME-079; ESME-080; ESME-081; ESME-088

**Values.** Automation throughput versus validation, comprehension and review burden.

**Costs.** Human work may move rather than disappear; refusing suitable automation also has opportunity cost.

**Favours first.** A bounded task class with aligned oracles and observed end-to-end benefit.

**Favours second.** Ambiguous requirements, unstable tools, poor harness or expensive review.

**Supported hybrid.** Scoped generation with selective independent checks and outcome feedback.

**Hybrid failure.** Several tools share one invalid oracle, or the human rubber-stamps unreviewable volume.

**Discriminator.** Compare accepted outcomes and total work, including later repair, on representative tasks under versioned settings.

**Uncertainty.** ESME-088 remains unresolved; contemporary follow-up does not establish a universal speedup.

**Source ids.** ESME-S034; ESME-S036; ESME-S037; ESME-S038; ESME-S063; ESME-S064

### ESME-T05

**Property ids.** ESME-035; ESME-036; ESME-037; ESME-038; ESME-042; ESME-043; ESME-044

**Values.** Fast feedback/release versus breadth and representativeness of evidence.

**Costs.** Broad tests delay useful repairs; narrow selection and short canaries miss consequential cases.

**Favours first.** Cheap reversible effects and reliable scoped dependency/sampling assumptions.

**Favours second.** High loss, unknown dependencies, rare effects or shared state.

**Supported hybrid.** Early prioritised feedback plus explicit completion criteria and targeted broader validation.

**Hybrid failure.** Early green results become unspoken permission to omit the only test for a live obligation.

**Discriminator.** Identify the loss-bearing observation and whether the chosen method can actually detect it before unacceptable exposure.

**Uncertainty.** No universal acceptable test coverage or canary duration follows.

**Source ids.** ESME-S024; ESME-S025; ESME-S026; ESME-S046; ESME-S047; ESME-S051

### ESME-T06

**Property ids.** ESME-031; ESME-056; ESME-057; ESME-058; ESME-059; ESME-060; ESME-061

**Values.** Debt reduction versus current useful delivery.

**Costs.** Repayment consumes present resources and can regress; deferral can block or multiply later work.

**Favours first.** Credible repeated interest or a near-term required change whose cost is reduced.

**Favours second.** Low future use, inexpensive interest, impending retirement or more urgent obligations.

**Supported hybrid.** Bounded structural improvement during relevant work with an explicit opportunity-cost account.

**Hybrid failure.** Endless incidental cleanup hides scope expansion; feature urgency becomes a permanent excuse to ignore a known liability.

**Discriminator.** State the change-contingent cost mechanism, horizon and uncertainty that could reverse priority.

**Uncertainty.** Precise economic calibration is not generally established.

**Source ids.** ESME-S027; ESME-S028; ESME-S057; ESME-S058

### ESME-T07

**Property ids.** ESME-025; ESME-051; ESME-066; ESME-068; ESME-069; ESME-070; ESME-071; ESME-092

**Values.** Downstream continuity versus finite support capacity and upstream freedom to evolve.

**Costs.** Unlimited compatibility can exhaust maintainers; abrupt discontinuity can strand dependent users.

**Favours first.** Live accepted support commitments and high consumer migration costs.

**Favours second.** Unfunded/expired commitments, unsafe unsupported dependencies or viable consumer alternatives.

**Supported hybrid.** Explicit support windows, actionable deprecation and scoped version variants.

**Hybrid failure.** Dates are announced without a viable path, or compatibility branches multiply beyond capacity.

**Discriminator.** Determine real promises, capacity and transition feasibility; usage popularity is neither permission nor an infinite support contract.

**Uncertainty.** Unknown consumers and disputed responsibilities remain possible.

**Source ids.** ESME-S021; ESME-S032; ESME-S033; ESME-S053; ESME-S054; ESME-S059; ESME-S060

### ESME-T08

**Property ids.** ESME-004; ESME-041; ESME-063; ESME-071; ESME-072

**Values.** Historical preservation versus ending obsolete operational/data burdens.

**Costs.** Insufficient preservation loses meaning; indiscriminate retention creates storage, rights and support costs.

**Favours first.** A justified future retrieval, reproduction or ongoing service obligation.

**Favours second.** No surviving purpose, or a legitimate requirement to remove the retained object.

**Supported hybrid.** Stop service while retaining purpose-specific source/data/context under an explicit horizon.

**Hybrid failure.** An archive is advertised as runnable despite missing dependencies, or an obsolete service is kept live without a support purpose.

**Discriminator.** Ask what future consumer must actually be able to do: retrieve, interpret, execute or receive service.

**Uncertainty.** Specific legal retention/deletion duties lie outside this neutral corpus.

**Source ids.** ESME-S052; ESME-S053; ESME-S055; ESME-S056


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_COMPOSED_SYSTEM

### Purpose, objects and practical powers

The system stewards justified usefulness and intelligibility over the life of existing software. Its state includes not only versions of source, but configuration/build artefacts, persistent and external effects, supported consumers, obligations, available maintenance capability, outstanding uncertainty and evidence with a validity envelope. Its environment can change even when no source is edited. Conversely, source can change without improving usefulness. The purpose therefore cannot be “maximise change”, “minimise complexity” or “maximise auditing”. [ESME-001–004/007/021/056/064/071/074.]

Requesters and affected stakeholders supply purposes and reliance claims; maintainers investigate and change artefacts; reviewers challenge proposed evidence; operators and data custodians control actual delivery and state operations; upstream/downstream maintainers negotiate compatible transitions; successors and archival custodians sustain or conclude particular capabilities. These are **functions and real authority/capability relations**, not a required new organisational role per candidate. One person can perform several functions where appropriate; a test runner or agent supplies no authority merely by producing an answer. [ESME-S001, ESME-S019, ESME-S041, ESME-S050, ESME-S059–060.]

A change affects the world through actual edits, deployments, data conversions, consumer transfers, support decisions and restoration or forward repair. Those actions require capability and permission in the relevant system. The resulting observations must still establish the intended consequence. For example, publishing a deprecation date communicates a claim, but a consumer must receive enough usable information to act; deleting a duplicate service ends one process, but does not establish discharge of every supported consumer or retention obligation. The composition keeps **distinction, authority, action and consequence** separate while connecting their consumers. [ESME-S053–056, ESME-S062; ESME-069/071/093/096.]

### A relational system, not a prescribed sequence

Intent, comprehension, impact analysis and evidence formation form a revisable inquiry loop. A request supplies a tentative changed/preserved-obligation boundary. Inspection may reveal an undocumented consumer; that finding can revise both the scope and the intention. A proposed regression test may conflict with a legitimate correction; the oracle then needs adjudication rather than automatic preservation. A release observation can expose an environmental assumption that invalidates earlier test transfer. The typed relations record these dependencies and feedback paths; their existence does not impose a fixed order of meetings or tools. [ESME-R001–013/020–031/044–052.]

Several activities can proceed concurrently when their dependency and authority boundaries allow it. Comprehension of one component need not stop an unrelated bounded repair. Two accepted changes can nevertheless create a semantic conflict when composed, so their joint effect requires attention at the relevant boundary. An emergency can trigger containment before comprehensive reconstruction, but that narrower permission and evidence do not silently become approval for a permanent redesign. New evidence that contradicts a safety, data or objective premise can interrupt the affected transition without forcing every independent inquiry to restart. [ESME-005/021/027/044/083; ESME-S001, ESME-S040, ESME-S066.]

Lifecycle choice is a branch, not a mandatory migration progression. Continued stable use, bounded repair, refactoring, broader re-engineering, incremental replacement, atomic replacement, restricted servicing and retirement are alternative configurations. Each protects different values and has different preconditions. A repair can dominate a rewrite over a short useful horizon; a rewrite can dominate indefinite coexistence when there is no defensible seam; retirement can dominate either when continued obligations can legitimately end. No branch is selected merely because it appears later in a maturity diagram. [ESME-045–062/071/074–075; ESME-A01–09.]

### Six composition-induced properties

**ESME-093 — coupled change contract.** Individually sound intent clarification, baseline identification, impact analysis and tests can still concern *different changes*. Coupling them requires the decision to refer to the same objective, objects, observers and accepted differences. A shared issue and a small test can realise the contract; a new schema or approval body is not mandatory. The new risk is administrative coupling that costs more than the mismatch it prevents.

**ESME-094 — evidence validity under changing assumptions.** Evidence remains useful only within the version, environment, observer and method assumptions that made it relevant. When another maintenance mechanism changes one of these, dependent conclusions must be reconsidered. This does not demand rerunning everything after every edit: determine which evidence depends on the changed premise. The added cost is dependency tracking; excessive invalidation can make maintenance unaffordable.

**ESME-095 — effect-relative returnability frontier.** Migration, release, data conversion and recovery can each appear locally justified while their composition removes a previously available exit. The combined decision must identify when the recovery option changes and what authorises proceeding past that point. Some effects are knowingly irreversible; their irreversibility is not a proof that no legitimate intervention exists. The evidence requirement is a credible restoration, compensation, forward-repair or accepted-loss arrangement for the relevant effect—not universal reversibility.

**ESME-096 — transition termination witness.** Successful component actions do not establish that a migration, compatibility window, support transfer or retirement is complete. There must be proportionate evidence that the responsibilities and surviving consumers have reached the intended state and that temporary duplication can end. For a small local change, ordinary acceptance evidence can be enough. For a distributed migration, routing/data/consumer observations may be necessary. A nominal closure form without those observations is not the witness.

**ESME-097 — proportional control composition.** Every locally useful control consumes attention, time or authority and can interact with the others. The combined system must therefore compare overlapping controls, cheaper adequate substitutes and non-intervention, rather than add one mechanism per source property. Removing a control is justified only when its protected failure is absent or adequately addressed elsewhere; minimising artefacts regardless of their function is the opposite error. No scalar cost function or universal minimal configuration is established.

**ESME-098 — independently warranted oracle revision.** Preserving existing tests can perpetuate wrong behaviour, yet changing the tests until a patch passes is circular. Composition needs an independent warrant for changing acceptance criteria: legitimate intent, a specification, a relevant consumer decision or other evidence not merely the candidate’s success under the revised test. Independence here means independence from the circular acceptance claim, not necessarily a different person or a statistically independent dataset. Disputed requirements can remain unresolved, with their decision consequence made explicit.

These six are **this study’s analytical deductions from interactions among source-supported mechanisms**. They are not source-named laws, six empirically validated additions, or evidence that the full system outperforms alternatives. The composition model gives each typed relation a guard, shared and incompatible assumptions, mechanism, new cost, evidence status and remaining obligation. [ESME-S019, ESME-S022, ESME-S025, ESME-S029, ESME-S049, ESME-S051, ESME-S058, ESME-S062–064.]

### Smallest coherent form and escalation

The smallest form has an understood objective and baseline, a defensible effect/preservation boundary, relevant evidence, a capable authorised actor and an appropriate continuation or recovery decision. An existing issue, a short conversation, a local diff and a relevant test may jointly satisfy those functions. It need not contain a graph database, a debt committee, a formal proof, a migration plan, a canary or an autonomous agent. For a stable useful system with no justified new obligation, its principal action may be to decline a proposed intervention and retain only the necessary monitoring/support capability. [ESME-012/016/035/045/057/074/097.]

Richer forms are triggered by actual difficulty: unresolved coupling, several supported versions, consequential data conversion, unfamiliar semantics, scarce knowledge, irreversible effects, conflicting stakeholders or high-cost failure. Formal models can then be economical rather than ceremonial; wider review can protect an otherwise hidden consumer; additional recovery rehearsal can establish a capability a script alone does not prove. The fuller mechanism must still identify its consumer and retirement condition. No general principle requires single ownership, one implementation, direct observation of everything or monotonically increasing machinery. [ESME-Z001–016; ESME-T01–08.]

### Revision, accountability and open boundaries

The maintenance process itself can be revised after contrary observations, changed objectives, stale tools or disproportionate costs. Those revisions need actual decision rights, evidence of their effect and continuity of important commitments. A model diagnosing its own weakness does not acquire permission to modify a live target or to enlarge its authority. An agent’s proposed rule change remains a proposal. Changing acceptance rules must address the predecessor’s relevant obligations or obtain legitimate authority to revise them; it cannot be justified solely by the successor passing its own test. [Analytical ESME-001/080/081/094/097/098.]

The combined system cannot guarantee complete open-world consumer discovery, perfect recovery of tacit knowledge, universal behavioural equivalence, resolution of every stakeholder dispute or favourable lifetime economics. It exposes those uncertainties to the appropriate decision rather than hiding them behind a generic pass. Representative longitudinal evaluation of this *combined* system remains an examined research obligation, not an unfinished source-reading task. The present verdict is a coherent conditional core with alternatives, not a universal prescription.
### Complete relational inventory

The complete machine model contains 98 candidate nodes and 52 guarded relations. Rejected, duplicate and unresolved nodes remain visible but are not thereby executable. `REQUIRES` means the FROM claim/mechanism relies on the TO obligation; it is not a universal scheduling edge. Every relation’s assumptions and residual obligation are in the JSON.

| Relation | From → to | Type | Guard and mechanism | New cost/failure |
| --- | --- | --- | --- | --- |
| ESME-R001 | ESME-001, ESME-002, ESME-003 → ESME-012, ESME-021, ESME-035 | CONSTRAINS | An intervention has a legitimate objective. Intent and artefact scope determine the questions to answer and the obligations evidence must establish. | Misstated intent contaminates otherwise sound analysis. |
| ESME-R002 | ESME-012, ESME-021, ESME-035, ESME-041 → ESME-004 | REQUIRES | Claims compare or modify a particular existing configuration. A resolvable baseline makes comprehension, impact and regression claims about the same subject. | Capturing mutable external inputs can be expensive or incomplete. |
| ESME-R003 | ESME-007, ESME-009, ESME-010 → ESME-001, ESME-058, ESME-074 | FEEDBACK_TO | Changed usefulness, capacity or environmental evidence appears. Feedback can revise the proposed objective, investment priority or decision to leave the system alone. | Metric drift can masquerade as changed value. |
| ESME-R004 | ESME-012 → ESME-013, ESME-014, ESME-015, ESME-019, ESME-020 | ACTS_THROUGH | A concrete comprehension question needs more evidence. Select static, dynamic, historical and human methods by the unknown that could change the decision. | Combining every view can consume more effort than the intervention merits. |
| ESME-R005 | ESME-013, ESME-014, ESME-015, ESME-019, ESME-020, ESME-022, ESME-024 → ESME-021 | PROVIDES_EVIDENCE_FOR | The selected method covers a relevant dependency or rationale. Recovered evidence supports a revisable impact boundary and can expose missing edges. | Over-approximation expands work; under-observation hides affected consumers. |
| ESME-R006 | ESME-021 → ESME-012, ESME-019, ESME-020 | FEEDBACK_TO | Impact escapes or conflicting views appear. Unexpected propagation reopens bounded comprehension rather than invalidating all prior work automatically. | Repeated reopening can stall a decision without a stopping discriminator. |
| ESME-R007 | ESME-028, ESME-029 → ESME-030, ESME-035 | CONSTRAINS | A transformation claims preservation. Observer and preconditions determine what tool validation and regression evidence must address. | A narrow formal observer may omit a real client effect. |
| ESME-R008 | ESME-030 → ESME-029, ESME-028 | PROVIDES_EVIDENCE_FOR | Validation exercises relevant engine operations and assumptions. Tool tests challenge implementation conformity without upgrading bounded testing to proof. | Generated cases and differential oracles have false positives and omissions. |
| ESME-R009 | ESME-031, ESME-032, ESME-056, ESME-057 → ESME-058 | PROVIDES_EVIDENCE_FOR | A structural investment competes with other work. Task-linked cost and liability evidence inform priority; scores and debt counts do not decide it alone. | Proxy gaming and speculative future demand can reverse the choice. |
| ESME-R010 | ESME-058, ESME-060, ESME-066 → ESME-045, ESME-047, ESME-059, ESME-071, ESME-074 | CONSTRAINS | Limited time and support capacity require a lifecycle choice. Account for real cost bearers and feasible support before choosing repair, migration, deferral, unchanged operation or retirement. | Participation and estimation can become costly bureaucracy. |
| ESME-R011 | ESME-045 → ESME-048, ESME-049 | ALTERNATIVE_TO | A local repair can meet the actual obligation. Repair can dominate migration when scope and support remain adequate. | Repeated local patches may conceal a growing systemic cost. |
| ESME-R012 | ESME-048 → ESME-049 | ALTERNATIVE_TO | Compare valid seams/coexistence with a feasible atomic transition. Choose staged substitution or single cutover according to intermediate-state feasibility and concentrated loss. | A hybrid without clear authority can combine prolonged duplication with final cutover risk. |
| ESME-R013 | ESME-048, ESME-049 → ESME-050, ESME-044 | REQUIRES | Migration changes persistent meanings or exposes loss. Conversion invariants and recoverability must be addressed in either migration branch. | Overbuilt recovery can cost more than acceptable reconstruction; underbuilt recovery can destroy data. |
| ESME-R014 | ESME-048, ESME-043, ESME-092 → ESME-051 | REQUIRES | Old/new participants coexist or versions roll out gradually. Intermediate combinations have their own compatibility obligations. | Combinatorial growth or shared state may defeat testing and isolation. |
| ESME-R015 | ESME-050, ESME-051 → ESME-044, ESME-095 | CONSTRAINS | Data or version state advances during release/migration. A conversion or activation step may invalidate earlier recovery routes. | Stale rollback promises persist unless effect changes are observed. |
| ESME-R016 | ESME-048, ESME-050, ESME-051 → ESME-052, ESME-096 | ENABLES | Responsibility and data have actually transferred. Validated transfer makes old-path retirement possible; endpoint features alone do not. | Premature exit strands consumers; delayed exit creates double maintenance. |
| ESME-R017 | ESME-052, ESME-069, ESME-070, ESME-072 → ESME-071 | PROVIDES_EVIDENCE_FOR | Operational closure is being considered. Transfer, communication and retained assets inform whether surviving obligations are discharged. | A notice or archive can be mistaken for consumer readiness or runnable preservation. |
| ESME-R018 | ESME-034, ESME-039, ESME-079 → ESME-035 | PROVIDES_EVIDENCE_FOR | Expected behaviour is incomplete or disputed. Characterisation and comparison expose observations requiring normative adjudication. | A faulty reference or generated relation can reward an incorrect implementation. |
| ESME-R019 | ESME-035 → ESME-036, ESME-037, ESME-038, ESME-039, ESME-043 | CONSTRAINS | Evidence-production techniques are selected for a release. Acceptance obligations determine appropriate test selection, priority, mutation, differential checks or staged exposure. | The cheapest technique may omit a consequential observation. |
| ESME-R020 | ESME-036 → ESME-024, ESME-077 | REQUIRES | Selective testing relies on dependency and execution correctness. Selection must account for consequential non-code dependencies and a working harness. | Valid algorithmic assumptions can still be violated by a concrete tool. |
| ESME-R021 | ESME-004, ESME-027, ESME-035 → ESME-042 | ENABLES | Concurrent work needs timely integration evidence. Identified revisions and joint-intent tests make integration feedback actionable. | A fast green pipeline can still be semantically empty. |
| ESME-R022 | ESME-042, ESME-043, ESME-044 → ESME-001, ESME-012, ESME-021, ESME-058 | FEEDBACK_TO | Integration, rollout or recovery produces unexpected observations. New failures can reopen intent, diagnosis, impact or the intervention choice; they are not simply retries of a pipeline. | Feedback without an accountable consumer becomes alert noise. |
| ESME-R023 | ESME-063, ESME-064, ESME-065, ESME-066 → ESME-012, ESME-015, ESME-027, ESME-069 | ENABLES | People must understand, coordinate or explain a change. Retained rationale and real capacity support inquiry, joint work and consumer communication. | Named owners or stored documents may not carry practical capability. |
| ESME-R024 | ESME-021, ESME-025, ESME-068, ESME-092 → ESME-069, ESME-070 | COMMUNICATES_TO | Actual consumers face changed support or compatibility. Impact evidence identifies what consumers need to know and which versions are affected. | Broadcasting everything overwhelms recipients; silence hides necessary action. |
| ESME-R025 | ESME-066, ESME-069 → ESME-068, ESME-071, ESME-074 | FEEDBACK_TO | Support availability or downstream reliance changes. Capacity and consumer feedback can revise update, retire or no-change choices. | Dependence can create pressure for indefinite unpaid support without consent. |
| ESME-R026 | ESME-076, ESME-083, ESME-086 → ESME-001, ESME-021, ESME-035, ESME-077 | REQUIRES | Automation or non-code intervention affects real obligations. Authorship and artefact type do not remove intent, impact or trustworthy-evidence requirements. | Applying the same test ritual to every artefact can waste effort and miss its semantics. |
| ESME-R027 | ESME-078, ESME-079, ESME-080, ESME-081, ESME-082 → ESME-076, ESME-083 | CONSTRAINS | Automation effectiveness or acceptance is inferred from prior evaluation. Task provenance, objective alignment, total cost and version/resource conditions bound the claim. | Over-analysis can erase local savings; weak evaluation can hide deferred costs. |
| ESME-R028 | ESME-084, ESME-085 → ESME-021, ESME-024, ESME-035, ESME-081 | REFINES | Learned/data-dependent components change behaviour without ordinary source edits. Extend ordinary maintenance evidence to data, feedback and model/configuration assumptions. | Distribution and normative drift are not interchangeable; retraining can worsen outcomes. |
| ESME-R029 | ESME-005, ESME-089 → ESME-001, ESME-035, ESME-044 | REQUIRES | An emergency intervention deliberately suspends behaviour. Containment needs a different objective and evidence from permanent corrective repair. | An emergency label can conceal spec deletion and no follow-up. |
| ESME-R030 | ESME-093 → ESME-001, ESME-004, ESME-021, ESME-028, ESME-035 | ACTS_THROUGH | Constituent mechanisms risk judging different subjects or promises. A shared change-obligation binding makes the distinctions mutually operative rather than a union of checklists. | Binding can become documentation overhead without an actual mismatch risk. |
| ESME-R031 | ESME-094 → ESME-004, ESME-021, ESME-035, ESME-051, ESME-081, ESME-085 | FEEDBACK_TO | A changed assumption affects previously accepted evidence. Invalidate or narrow only the claims that depend on the changed condition. | Missing links preserve stale assurance; excessive links cause global rework. |
| ESME-R032 | ESME-095 → ESME-044, ESME-050, ESME-051 | CONSTRAINS | A planned transition crosses a recovery boundary. The remaining recovery options must still support the accepted loss envelope before acting. | An incomplete external-effect model can conceal the boundary. |
| ESME-R033 | ESME-096 → ESME-052, ESME-069, ESME-071, ESME-092 | CONSTRAINS | Completion or old-path retirement is asserted. Require a witness of discharged responsibilities and supported-consumer transition within declared scope. | Absence-of-use evidence is imperfect; premature universal claims are unsafe. |
| ESME-R034 | ESME-097 → ESME-012, ESME-035, ESME-043, ESME-058, ESME-066, ESME-074 | CONSTRAINS | Selecting and retaining the combined method’s controls. Demand a protected obligation, consumer and continuation condition while allowing adequate substitutes. | A vague appeal to proportionality can become an excuse for missing evidence. |
| ESME-R035 | ESME-098 → ESME-001, ESME-034, ESME-035, ESME-079, ESME-093 | CONSTRAINS | A candidate change revises the rule or oracle judging it. Require a warrant for the revised expectation not supplied merely by the candidate passing that expectation. | Demands for absolute independence can make legitimate correction impossible. |
| ESME-R036 | ESME-002 → ESME-006 | SUPERSEDES | A four-box taxonomy is asserted as universally exhaustive. Edition-aware multidimensional classification preserves distinctions that a forced four-way assignment loses. | More labels can burden reporting when unused. |
| ESME-R037 | ESME-001 → ESME-087 | SUPERSEDES | An AI-specific authority criterion duplicates the existing boundary. One mechanism can govern human and generated proposals without losing their distinct provenance. | A new process solely for the duplicate can add redundant approval cost. |
| ESME-R038 | ESME-007, ESME-009, ESME-010, ESME-074 → ESME-008, ESME-011 | SUPERSEDES | Unqualified growth or work-rate laws are proposed. Conditional environmental feedback and measured capacity replace universal prescriptions. | Losing the historical context can also discard useful local regularities. |
| ESME-R039 | ESME-012, ESME-015 → ESME-017, ESME-018 | SUPERSEDES | Knowledge acquisition is confused with mutation or exhaustive understanding. Bounded recovery distinguishes actionable knowledge from actual effects and rejects unbounded prerequisites. | Too narrow a boundary can hide a consequential dependency. |
| ESME-R040 | ESME-022, ESME-025 → ESME-023, ESME-026 | SUPERSEDES | Historical association or a version label is treated as proof. Investigated dependency and observer-specific compatibility replace unsupported proxy guarantees. | Additional checking costs must be proportional to relevant reliance. |
| ESME-R041 | ESME-028, ESME-029, ESME-030, ESME-031, ESME-032 → ESME-033, ESME-062 | SUPERSEDES | Catalogue or metric conformity is treated as benefit or preservation. Concrete preconditions, observers and task-linked payoff replace ceremonial acceptance. | Economic forecasts remain uncertain despite improved structure. |
| ESME-R042 | ESME-034, ESME-035, ESME-039, ESME-079 → ESME-040, ESME-091 | SUPERSEDES | Test success or historical behaviour is treated as complete normative truth. Obligation-sensitive evidence preserves what should survive and permits authorised correction. | Normative ambiguity cannot always be solved by more tests. |
| ESME-R043 | ESME-044, ESME-046, ESME-047, ESME-048, ESME-049 → ESME-053, ESME-054, ESME-055 | SUPERSEDES | Migration/recovery slogans replace alternative analysis. Actual value, transition feasibility and effect-aware recovery replace categorical rewrite/novelty/revert claims. | A detailed alternatives exercise can itself be unnecessary for a simple change. |
| ESME-R044 | ESME-056, ESME-058, ESME-059 → ESME-061 | SUPERSEDES | Debt count is treated as a zero target. Future-cost mechanisms and value-based choice replace indiscriminate repayment. | Uncertainty can also be misused to postpone a live harmful liability. |
| ESME-R045 | ESME-064, ESME-066, ESME-067, ESME-068 → ESME-073 | SUPERSEDES | Popularity is treated as support assurance. Demonstrated human capacity and viable dependency plans replace usage-count guarantees. | Gathering support information may be difficult for opaque upstreams. |
| ESME-R046 | ESME-076, ESME-077, ESME-078, ESME-079, ESME-080, ESME-081 → ESME-090 | SUPERSEDES | A task demonstration is used to justify universal autonomous maintenance. Bounded delegation and scoped evidence replace unrestricted self-authorising intervention. | Excessive manual ceremony can unnecessarily discard valid automation benefit. |
| ESME-R047 | ESME-075 → ESME-015, ESME-047, ESME-064 | CONFLICTS_WITH | Servicing-stage irreversibility is asserted as a universal capability loss. Recovery and succession may restore capability, but actual cost may still make renewed evolution infeasible. | Either categorical optimism or categorical impossibility can waste investment. |
| ESME-R048 | ESME-088 → ESME-058, ESME-076, ESME-080 | CONSTRAINS | Short-term evidence is used to promise long-term maintainability. Keep longitudinal benefit unresolved and choose bounded use with follow-up rather than assert proven lifecycle superiority. | Waiting for perfect long-term evidence can forgo useful immediate tools. |
| ESME-R049 | ESME-016, ESME-057 → ESME-063 | COMMUNICATES_TO | Documentation and debt records have a future decision consumer. Versioned explanations preserve reasons and uncertainty for later maintainers. | Orphaned records and duplicated explanations impose upkeep without use. |
| ESME-R050 | ESME-063, ESME-064 → ESME-015 | FEEDBACK_TO | Handover or recovery discovers a missing or false rationale. Update the recovered explanation while preserving why earlier decisions were made. | Replacing history with the newest interpretation can erase important uncertainty. |
| ESME-R051 | ESME-013 → ESME-014 | SHARES_ANCESTRY_WITH | Static and dynamic slicing address criterion-relative relevance. The dynamic paper explicitly refers to Weiser and changes the execution quantifier, rather than independently rediscovering an unrelated mechanism. | Conflating their guarantees hides static over-approximation and dynamic under-observation. |
| ESME-R052 | ESME-034 → ESME-039 | ALTERNATIVE_TO | A missing direct oracle can be addressed by baseline capture or another justified comparison. Select characterisation, differential evidence or both according to available information and normative uncertainty. | Both can inherit the same flawed assumption and offer no independent check. |

### Alternative configurations

### ESME-A01 — Stable useful non-change

**Property ids.** ESME-007; ESME-058; ESME-066; ESME-074; ESME-097

**Selection guard.** Current obligations and support remain met; no proposed intervention earns its cost.

**Cheaper or omitted mechanisms.** No forced refactoring, migration, CI service or extra documentation.

**Exit or revision condition.** Changed obligation, environment, capacity or worthwhile opportunity triggers reconsideration.

**Status.** ANALYTICAL_CONFIGURATION; not a mandatory operating procedure

### ESME-A02 — Small local repair

**Property ids.** ESME-001; ESME-004; ESME-012; ESME-021; ESME-035; ESME-045; ESME-093; ESME-097

**Selection guard.** A bounded fault with adequate local evidence and acceptable effect risk.

**Cheaper or omitted mechanisms.** Single issue, direct inspection and focused tests can cover several properties.

**Exit or revision condition.** Impact escape or intent uncertainty reopens only relevant questions.

**Status.** ANALYTICAL_CONFIGURATION; not a mandatory operating procedure

### ESME-A03 — Structure-preserving transformation

**Property ids.** ESME-004; ESME-021; ESME-028; ESME-029; ESME-030; ESME-031; ESME-035; ESME-058

**Selection guard.** A useful future change class justifies restructuring under valid preservation assumptions.

**Cheaper or omitted mechanisms.** No debt register or named catalogue required; inspect small tool outputs directly.

**Exit or revision condition.** Observer/precondition failure or no plausible payoff makes repair/deferral preferable.

**Status.** ANALYTICAL_CONFIGURATION; not a mandatory operating procedure

### ESME-A04 — Staged live release

**Property ids.** ESME-004; ESME-035; ESME-041; ESME-043; ESME-044; ESME-051; ESME-069; ESME-094; ESME-095

**Selection guard.** Representative isolatable exposure and actionable observations exist.

**Cheaper or omitted mechanisms.** No fixed rollout percentage or automatic promotion requirement.

**Exit or revision condition.** Failed or absent observation stops expansion; shared-state risk can force another strategy.

**Status.** ANALYTICAL_CONFIGURATION; not a mandatory operating procedure

### ESME-A05 — Incremental migration

**Property ids.** ESME-001; ESME-004; ESME-025; ESME-047; ESME-048; ESME-050; ESME-051; ESME-052; ESME-069; ESME-096

**Selection guard.** Valid seams and manageable old/new coexistence can preserve obligations.

**Cheaper or omitted mechanisms.** A local repair or atomic cutover remains an alternative.

**Exit or revision condition.** Transfer witness permits closure; escalating duplication can require replan or abandonment.

**Status.** ANALYTICAL_CONFIGURATION; not a mandatory operating procedure

### ESME-A06 — Rehearsed atomic transition

**Property ids.** ESME-001; ESME-004; ESME-047; ESME-049; ESME-050; ESME-044; ESME-069; ESME-095

**Selection guard.** Concentrated transition is feasible and preferable to unsafe/prolonged coexistence.

**Cheaper or omitted mechanisms.** No dual operation imposed for its own sake.

**Exit or revision condition.** Failed conversion/recovery rehearsal or unacceptable loss invalidates the branch.

**Status.** ANALYTICAL_CONFIGURATION; not a mandatory operating procedure

### ESME-A07 — Support phaseout and retirement

**Property ids.** ESME-063; ESME-066; ESME-069; ESME-070; ESME-071; ESME-072; ESME-096

**Selection guard.** Continuing operation or support is no longer justified and surviving duties can be resolved.

**Cheaper or omitted mechanisms.** Source-only archive can suffice where execution/service is unnecessary.

**Exit or revision condition.** Undischarged legitimate consumers or preservation needs defer closure or require a revised arrangement.

**Status.** ANALYTICAL_CONFIGURATION; not a mandatory operating procedure

### ESME-A08 — Bounded automation overlay

**Property ids.** ESME-001; ESME-035; ESME-076; ESME-077; ESME-078; ESME-079; ESME-080; ESME-081; ESME-087

**Selection guard.** A suitable task class, trustworthy evidence and actual bounded authority exist.

**Cheaper or omitted mechanisms.** No obligation to use agents; human/tool alternatives can dominate; ESME-087 adds no separate control.

**Exit or revision condition.** Changed assumptions, poor total cost or ambiguous intent narrows/revokes use.

**Status.** ANALYTICAL_CONFIGURATION; not a mandatory operating procedure

### ESME-A09 — Learned/non-code dependency extension

**Property ids.** ESME-003; ESME-021; ESME-024; ESME-035; ESME-084; ESME-085; ESME-086; ESME-094

**Selection guard.** Learned/data/configuration effects are consequential to supported outcomes.

**Cheaper or omitted mechanisms.** No ML-specific controls when no such dependency exists.

**Exit or revision condition.** Changed distribution or purpose requires new evidence, not automatic self-authorised objective revision.

**Status.** ANALYTICAL_CONFIGURATION; not a mandatory operating procedure

### Discriminating case tests

These are analytical tests of the composed account, not newly observed industrial cases or empirical validation. Published anchors establish the constituent failure mechanisms, not the invented scenario’s frequency. All six mandatory discriminators are included, plus conflict and failed-observation tests.

### ESME-K01 — Important undocumented behaviour

**Kind.** ANALYTICAL_DISCRIMINATING_CASE

**Setup.** A seemingly redundant output ordering supports a downstream batch process, but is absent from the tests.

**Activated.** ESME-001; ESME-012; ESME-014; ESME-015; ESME-021; ESME-034; ESME-035; ESME-063; ESME-069; ESME-098

**Expected decision.** Investigate actual reliance and legitimate intent; preserve or deliberately revise with a consumer transition. Do not make observed behaviour automatically normative.

**Non trigger.** No consumer or obligation relies on the ordering, and an authorised clarification permits revision.

**Failed observation.** If tests do not observe ordering, their passage does not settle the case.

**Falsifier or failure.** A recovered story accepted without consumer/domain corroboration can preserve the wrong behaviour.

**Published anchors.** ESME-S014; ESME-S016; ESME-S017; ESME-S063; ESME-S064

**Evidence limit.** Invented scenario, not empirical validation of the composed system.

### ESME-K02 — Refactor passes tests but changes an external observer

**Kind.** ANALYTICAL_DISCRIMINATING_CASE

**Setup.** A structural transformation preserves usual return values but changes reflection, serialization, binary layout or an API client’s required behaviour.

**Activated.** ESME-021; ESME-025; ESME-028; ESME-029; ESME-030; ESME-035; ESME-039

**Expected decision.** Reject the unqualified preservation claim; widen the observer or authorise an actual behaviour/compatibility change.

**Non trigger.** The excluded observation is outside supported use and no legitimate consumer relies on it.

**Failed observation.** Ordinary unit-test passage is insufficient when the changed observer is not exercised.

**Falsifier or failure.** Testing only the original input/output model can give false assurance even if the transformation rule is sound within that model.

**Published anchors.** ESME-S021; ESME-S022; ESME-S045

**Evidence limit.** Analytical scenario uses published observer/tool limitations; not a measured rate of refactoring failure.

### ESME-K03 — Schema rollback after irreversible conversion

**Kind.** ANALYTICAL_DISCRIMINATING_CASE

**Setup.** The new representation merges categories or emits external transactions that the old code cannot interpret or undo.

**Activated.** ESME-004; ESME-044; ESME-050; ESME-051; ESME-055; ESME-095

**Expected decision.** Locate the information/effect-loss boundary and require preserved source data, accepted loss or a valid forward/compensating route before crossing it.

**Non trigger.** A verified bijective conversion with no external effects can have a simple inverse.

**Failed observation.** A rollback script that exits successfully does not establish restored meaning or usable data.

**Falsifier or failure.** A restore procedure can be unusable through version/tool mismatch, even when backup files appear to exist.

**Published anchors.** ESME-S029; ESME-S049; ESME-S062

**Evidence limit.** Scenario is invented; GitLab is a distinct published failed-recovery incident, not this schema-migration experiment.

### ESME-K04 — Popular dependency loses maintainers

**Kind.** ANALYTICAL_DISCRIMINATING_CASE

**Setup.** A widely relied-on package’s current maintainers stop supporting it while downstream use continues.

**Activated.** ESME-060; ESME-064; ESME-066; ESME-067; ESME-068; ESME-069; ESME-071; ESME-073

**Expected decision.** Assess actual required support, willing successors, pin/update/substitute options and consumer obligations; popularity is not capacity.

**Non trigger.** No relevant ongoing change/support obligation remains and stable use has acceptable exposure.

**Failed observation.** Commit counts or downloads cannot establish willingness and practical capability.

**Falsifier or failure.** Assigning a nominal new owner without access or time does not transfer maintenance ability.

**Published anchors.** ESME-S032; ESME-S033; ESME-S059; ESME-S060

**Evidence limit.** Invented discriminating case, not an asserted incident frequency or a specific package history.

### ESME-K05 — Increased structural complexity supports needed variation

**Kind.** ANALYTICAL_DISCRIMINATING_CASE

**Setup.** A justified new supported configuration adds branching or modules and increases a complexity score.

**Activated.** ESME-001; ESME-009; ESME-028; ESME-031; ESME-032; ESME-058; ESME-092

**Expected decision.** Judge fulfilled variation obligations, future task cost and preservation evidence rather than reject the change solely for a higher score.

**Non trigger.** The variation is unused or unjustified and adds no value; a simpler implementation may dominate.

**Failed observation.** Neither the complexity increase nor a changed score establishes maintainability benefit or harm by itself.

**Falsifier or failure.** An attractive abstraction can increase actual future edit and comprehension costs.

**Published anchors.** ESME-S005; ESME-S019; ESME-S023; ESME-S058

**Evidence limit.** Analytical variation case; ESME-S023 supplies a published metric/structure counterexample, not validation of this exact scenario.

### ESME-K06 — Stable useful system with no justified change

**Kind.** ANALYTICAL_NON_TRIGGER_CASE

**Setup.** A small deterministic service remains correct for its supported purpose, has a viable environment and has no worthwhile proposed enhancement.

**Activated.** ESME-007; ESME-046; ESME-058; ESME-059; ESME-066; ESME-074; ESME-097

**Expected decision.** Retain unchanged operation and existing appropriate observation; impose neither migration nor continuous refactoring.

**Non trigger.** The change mechanisms themselves do not trigger until an obligation, support condition or prospective value changes.

**Failed observation.** Silence from users is not enough if an important environmental change has not been observed.

**Falsifier or failure.** An expired dependency/support obligation or actual environmental incompatibility defeats the no-change assumptions.

**Published anchors.** ESME-S009; ESME-S013; ESME-S055; ESME-S058

**Evidence limit.** Analytical test of conditional scope, not a longitudinal study proving all stable systems remain useful.

### ESME-K07 — Bounded local repair with a valid regression oracle

**Kind.** ANALYTICAL_FAVOURABLE_COMPOSITION_CASE

**Setup.** An isolated deterministic parser mishandles a documented valid input; supported behaviour and dependencies are known.

**Activated.** ESME-001; ESME-004; ESME-012; ESME-021; ESME-035; ESME-045; ESME-063; ESME-093; ESME-097

**Expected decision.** Use one concise issue, known baseline, targeted correction and relevant regression check; preserve rationale where it prevents rediscovery.

**Non trigger.** No schema migration, canary population, new owner, debt register or AI agent is needed.

**Failed observation.** A test that checks only process exit, not the parser output, fails to establish the correction.

**Falsifier or failure.** A previously unknown consumer or ambiguous input obligation reopens the relevant boundary, not all research.

**Published anchors.** ESME-S001; ESME-S017; ESME-S025; ESME-S041

**Evidence limit.** A constructed demonstration of coherent selection, not representative empirical effectiveness.

### ESME-K08 — Changed model/tool or failing canary observation

**Kind.** ANALYTICAL_CHANGED_ASSUMPTION_CASE

**Setup.** A validated repair tool is upgraded while the deployed canary has no representative requests and shares persistent state with its control.

**Activated.** ESME-035; ESME-043; ESME-044; ESME-077; ESME-080; ESME-081; ESME-094; ESME-095

**Expected decision.** Do not reuse tool or canary evidence beyond its envelope; perform targeted revalidation and choose an alternative observation/exposure route.

**Non trigger.** Unchanged relevant semantics and representative existing evidence can justify reuse without a universal rerun.

**Failed observation.** Missing signal is neither success nor proof of harm; contaminated control does not identify the cause.

**Falsifier or failure.** Automatic promotion on no alarms can expose all consumers while preserving the same invalid assumptions.

**Published anchors.** ESME-S024; ESME-S038; ESME-S039; ESME-S051

**Evidence limit.** Analytical stress test combining independently documented limitations, not a reported deployment.


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_HYBRIDISATION_AND_EXTERNAL_RELATIONS

Software maintenance overlaps architecture recovery, configuration/variation, testing, release engineering, community coordination and learned-system development. The overlap is not a reason to omit a native concern, nor evidence that independently named traditions are equivalent. The present study retains the following bounded interfaces without reading any sibling synthesis.

### Software Architecture

**Status.** SIBLING_CORPORA_NOT_CONSULTED

**Inputs.** Existing architecture decisions, constraints and recovered views, where supplied by later independent work.

**Outputs.** Impact/observer/support constraints, change scenarios, recovery uncertainty and migration feedback.

**Questions.** Are recovered architecture views evidence of the same constraints as design-time views? Which evolution feedback should revise those decisions?

**Source ids.** ESME-S014; ESME-S019; ESME-S021; ESME-S044; ESME-S058

### Software Product Line Engineering

**Status.** SIBLING_CORPORA_NOT_CONSULTED

**Inputs.** Later independently studied variation/configuration concepts and supported-family obligations.

**Outputs.** Native SCM configuration-space and supported-version obligations, compatibility and migration conditions.

**Questions.** Which supported configurations share preservation obligations? When are variant-specific evidence or retirement decisions irreducible?

**Source ids.** ESME-S005; ESME-S019; ESME-S041; ESME-S049

### Actual operational and stakeholder authority

**Status.** MUST_BE_SUPPLIED_BY_LATER_TARGET; no mutation authorised by export

**Inputs.** Legitimate commitments, support horizon, permitted actions and real artefacts.

**Outputs.** Conditional audit questions and evidence obligations, not implementation commands.

**Questions.** Who can act, who can decide, who is affected and which consequences can actually be observed?

**Source ids.** ESME-S001; ESME-S041; ESME-S053; ESME-S054; ESME-S059

DALI supplies a documented architecture-recovery intersection; SCM and multidimensional evolution taxonomies supply native configuration-space questions; F1 supplies a bounded mixed-version schema example. None licenses claims about the yet-unread Software Architecture or Software Product Line Engineering corpora. Cunningham explicitly imports a metaphor, while learned-system debt is a documented domain translation. Similarity between gateway and strangler approaches remains an unresolved historical relationship here.


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_STRONGEST_SURVIVING_PROPERTIES

The strongest core protects the validity of the maintenance decision, not maximum process. Strong retention denotes a well-supported necessary distinction or bounded mechanism, not a quantified universal economic effect.

### ESME-001 — Explicit change objective and authorised obligation revision

Retain explicit intent while allowing brief local decisions and escalation only for actual conflicts.

**Why it matters:** Avoid implementing the wrong change correctly. **Boundary/cheap path:** A short accepted issue with concrete examples is enough for a bounded low-risk change; reject or defer an unjustified request. **Sources:** ESME-S001, ESME-S004, ESME-S041, ESME-S025, ESME-S063, ESME-S064.

### ESME-004 — Recoverable and identifiable configuration baseline

Treat baseline as a resolvable configuration rather than a repository tag alone.

**Why it matters:** Reduce wrong-baseline diagnosis and unverifiable change attribution. **Boundary/cheap path:** A versioned file and recorded command can suffice for a local deterministic artefact; retain richer dependencies only where needed. **Sources:** ESME-S019, ESME-S041, ESME-S050, ESME-S052, ESME-S062.

### ESME-009 — Population- and metric-conditioned evolution claims

Scope and provenance become part of the claim rather than a footnote.

**Why it matters:** Prevent a measurement artefact from becoming a universal maintenance rule. **Boundary/cheap path:** Use a simple trend with explicit units when it directly answers the decision; no statistical model is mandatory. **Sources:** ESME-S008, ESME-S010, ESME-S011, ESME-S012, ESME-S007.

### ESME-012 — Bounded change-specific comprehension

Question-led, revisable comprehension replaces an exhaustive prerequisite.

**Why it matters:** Avoid both blind editing and unbounded analysis that consumes the maintenance budget. **Boundary/cheap path:** Inspect the relevant code, test and domain example directly for a small familiar change; avoid mandatory reconstruction of everything. **Sources:** ESME-S014, ESME-S016, ESME-S017, ESME-S018, ESME-S015, ESME-S043.

### ESME-021 — Explicit multi-artefact impact boundary

Impact is a revisable claim, not merely a generated list.

**Why it matters:** Prevent falsely local changes and unnecessary whole-system reviews. **Boundary/cheap path:** Local review is sufficient when a defensible dependency boundary makes wider effects immaterial. **Sources:** ESME-S019, ESME-S020, ESME-S021, ESME-S041, ESME-S024, ESME-S061.

### ESME-028 — Observer-relative preservation in refactoring

Preservation is explicit and scoped, not an unqualified slogan.

**Why it matters:** Avoid calling a client-visible behavioural change a harmless refactor. **Boundary/cheap path:** For an isolated pure function, input/output and exceptional behaviour may be an adequate observer; no universal observer inventory is mandatory. **Sources:** ESME-S014, ESME-S022, ESME-S021, ESME-S023, ESME-S045.

### ESME-035 — Independent change and regression obligations

Independence concerns the obligations and warrants, not mandatory organisational separation.

**Why it matters:** Prevent a successful fix from concealing a regression or an unchanged system from masquerading as a fix. **Boundary/cheap path:** One test may address both obligations if its distinct assertions and coverage are clear; no separate team is inherently required. **Sources:** ESME-S025, ESME-S026, ESME-S041, ESME-S034, ESME-S063, ESME-S064.

### ESME-044 — Effect-aware recovery and forward repair

Recovery is relative to effects and conditions, with forward repair a legitimate branch.

**Why it matters:** Avoid a rollback command that restores code while leaving incompatible or lost state. **Boundary/cheap path:** For an isolated reversible file edit, a verified prior file may suffice; richer recovery is unnecessary when no external effect exists. **Sources:** ESME-S041, ESME-S049, ESME-S051, ESME-S062, ESME-S049, ESME-S062.

### ESME-046 — Legacy value distinguished from technical age

Retain value-based stewardship while recognising real environment/support constraints.

**Why it matters:** Avoid destroying valuable behaviour or funding migration without a problem. **Boundary/cheap path:** Continue operation with existing support when useful and adequately maintainable. **Sources:** ESME-S013, ESME-S029, ESME-S041, ESME-S029, ESME-S058.

### ESME-050 — Data-conversion invariants and reconciliation

Validation covers meanings and intermediate states, not only row counts or successful scripts.

**Why it matters:** Prevent data that is structurally valid but semantically lost or duplicated. **Boundary/cheap path:** For stateless replacement this is not triggered; a simple verified bijective conversion may need only direct checks. **Sources:** ESME-S029, ESME-S049, ESME-S062, ESME-S029, ESME-S062.

### ESME-063 — Retained rationale through actual use

Consumer-tested rationale with retirement of obsolete constraints.

**Why it matters:** Reduce costly rediscovery and accidental removal of justified behaviour. **Boundary/cheap path:** An adjacent comment, issue or concise handover may suffice; do not duplicate rationale in unconsumed documents. **Sources:** ESME-S014, ESME-S016, ESME-S019, ESME-S041, ESME-S016, ESME-S058.

### ESME-069 — Downstream communication that enables action

Actionable communication with proportional evidence of reach, not a mandatory newsletter ritual.

**Why it matters:** Reduce surprise breakage and allow coordinated transition or explicit accepted discontinuity. **Boundary/cheap path:** A direct agreement with the sole consumer may suffice; no broad notice is needed for a truly private effect. **Sources:** ESME-S021, ESME-S041, ESME-S053, ESME-S054, ESME-S054, ESME-S060.

### ESME-074 — Stable useful software may justify no change

No-change is positive stewardship under conditions, not denial of emerging obligations.

**Why it matters:** Avoid needless regression, migration and maintenance debt created by improvement programmes. **Boundary/cheap path:** This is the cheap path itself; review existing signals rather than create permanent change machinery. **Sources:** ESME-S009, ESME-S013, ESME-S055, ESME-S058, ESME-S008, ESME-S029.

### ESME-077 — Validation of the evaluation harness itself

Evidence production is validated separately from the candidate implementation.

**Why it matters:** Prevent false evidence from silently validating invalid patches. **Boundary/cheap path:** A simple transparent command with known checks may need only a small sanity test rather than a framework audit. **Sources:** ESME-S024, ESME-S034, ESME-S035, ESME-S052, ESME-S024, ESME-S034, ESME-S063.

### ESME-079 — Issue, reference patch and test objective alignment

Reference patches are fallible evidence whose authority must be established.

**Why it matters:** Avoid penalising valid alternatives or accepting irrelevant behavioural changes. **Boundary/cheap path:** A precise issue and focused test can suffice; no LLM checker is inherently required. **Sources:** ESME-S035, ESME-S063, ESME-S064, ESME-S063, ESME-S064.


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CONTEXT_SPECIFIC_PROPERTIES

Every retained candidate has a trigger. The following specifically require selection by context, assumptions, domain or resistance to metric/administrative distortion. An inapplicable result is an acceptable audit outcome, not a failure to adopt the tradition.

| ID and candidate | Disposition | Selection/assumption boundary | Cheap alternative |
| --- | --- | --- | --- |
| ESME-005 Emergency stabilisation separated from permanent repair | CONTEXT_DEPENDENT | Continuing the current fault causes greater immediate harm than a controlled degraded state. Containment scope, operational capability and recovery or follow-up must be credible. | Use normal repair when delay is tolerable; do not invent an emergency fast lane for ordinary convenience. |
| ESME-010 Familiarity and capacity as feedback constraints | ASSUMPTION_SENSITIVE | Change volume or personnel turnover outpaces demonstrated ability to understand and maintain obligations. Workload signals must distinguish familiarity from tooling, task complexity and organisational restrictions. | A small expert-maintained component may need only a direct conversation and modest change cadence. |
| ESME-013 Criterion-relative conservative static slicing | ASSUMPTION_SENSITIVE | A data/control relevance question can be expressed in the supported program model. Sound dependencies and supported semantics; minimal arbitrary slices are not computable in general. | Manual inspection or a small dependency query may dominate building a slicer. |
| ESME-014 Execution-relative dynamic observation and slicing | CONTEXT_DEPENDENT | Static uncertainty, dynamic dispatch or a reproducible failure makes execution evidence discriminating. Reproducible or adequately characterised execution; instrumentation does not conceal or change the critical effect. | A debugger or targeted log can suffice; do not collect exhaustive production traces without need. |
| ESME-016 Faithful redocumentation with an actual consumer | USEFUL_BUT_EASILY_BUREAUCRATISED | A useful explanation is missing, stale or inaccessible to an actual consumer. A resolvable source baseline and a way to detect stale statements. | A checked example, code comment or targeted note can replace a large document. |
| ESME-019 Feature-location hypotheses and interactive refinement | CONTEXT_DEPENDENT | A change request describes a feature whose implementation is not already known. A discriminating feature example and access to relevant artefacts. | A direct known location or maintainer pointer avoids a specialised search workflow. |
| ESME-020 Evidence-fused architecture and behaviour recovery | CONTEXT_DEPENDENT | Late binding, generated code or divergent documentation makes any one view misleading. Compatible identifiers and explicit interpretation rules between views. | Use a single sufficient view when cross-checks reveal no consequential gap. |
| ESME-022 Historical co-change as fallible guidance | CONTEXT_DEPENDENT | History contains sufficiently comparable changes and a maintainer needs likely impact leads. Transaction extraction, temporal ordering and history quality must be adequate. | Skip mining for new code, sparse history or an obvious direct dependency. |
| ESME-029 Transformation precondition enforcement | ASSUMPTION_SENSITIVE | A transformation’s correctness depends on names, bindings, inheritance, types or other structural conditions. Preconditions are adequate and actually checked; unknown reflection or external uses are not silently assumed absent. | Direct review of a small transformation can replace a general engine when its conditions are simple. |
| ESME-032 Maintainability metrics as fallible diagnostics | USEFUL_BUT_EASILY_GAMED | A metric might reveal a bottleneck not already understood. Measurement unit, tool and relation to desired outcome must be justified. | Direct evidence of difficult changes or a small review may dominate metric dashboards. |
| ESME-036 Regression selection with suite-relative safety | ASSUMPTION_SENSITIVE | Running the whole available suite has material cost and sound selection can be justified. Method conditions, dependency modelling and tool implementation must hold. | Run the full affordable suite; do not add selection complexity when it saves little. |
| ESME-037 Test prioritisation for early information | CONTEXT_DEPENDENT | A time-constrained test run benefits from earlier actionable failures. Priority assumptions and any truncation policy must be explicit. | Keep the existing order when the suite is cheap or priority estimates are unreliable. |
| ESME-038 Mutation analysis as an adequacy diagnostic | CONTEXT_DEPENDENT | A consequential preservation obligation may be weakly exercised by the current tests. Operators and mutants represent relevant fault mechanisms; equivalent mutants and cost are handled. | Add a targeted real-fault regression case or review a missing assertion rather than run broad mutation campaigns. |
| ESME-042 Continuous integration as integration feedback | CONTEXT_DEPENDENT | Concurrent changes or delayed integration conceal incompatibilities. Feedback is timely, interpretable and linked to a corrective decision. | A small serially maintained artefact can use direct build/test checks without a dedicated service or fixed cadence. |
| ESME-043 Observation-aware staged exposure | CONTEXT_DEPENDENT | Production-only uncertainties can be investigated with genuinely limited and reversible exposure. Isolation, representativeness, measurement sensitivity and authority to halt must exist. | Use direct release with proportionate checks for low-impact changes, or offline rehearsal where live exposure is unsafe. |
| ESME-045 Bounded local repair as an alternative to restructuring | CONTEXT_DEPENDENT | A local fault has a justified impact boundary and no demonstrated need for broad redesign. Locality is justified and the patch does not merely defer a spreading failure. | No change is cheaper where the reported behaviour is acceptable; a focused correction is cheaper than modernisation when adequate. |
| ESME-048 Incremental substitution through valid migration seams | CONTEXT_DEPENDENT | Useful seams permit partial replacement and intermediate states preserve required service/data semantics. Separation, reconciled data ownership and transitional compatibility must be feasible. | A small system may be cheaper to replace atomically; no migration when existing service remains adequate. |
| ESME-049 Atomic replacement where coexistence is the greater risk | CONTEXT_DEPENDENT | The system is small or separability is poor, downtime is acceptable, or dual operation creates intolerable inconsistency. Validated conversion, feasible operating window and explicit recovery/forward limits. | Prefer bounded repair or incremental transfer where they meet obligations with less risk. |
| ESME-051 Compatibility of intermediate and mixed-version states | ASSUMPTION_SENSITIVE | Rolling upgrades, data conversion or partial migration create old/new participants at the same time. Version-skew bounds, ordering and data semantics are actually enforced. | Use an atomic stop-and-switch when mixed versions offer no justified advantage and downtime is acceptable. |
| ESME-057 Actionable debt records with a consumer | USEFUL_BUT_EASILY_BUREAUCRATISED | A significant liability risks being forgotten, misunderstood or shifted across teams. There is a real decision consumer and estimates are labelled as estimates. | A tracked issue or brief decision note can replace a dedicated register; delete records whose liability has vanished. |
| ESME-059 Option-preserving deferral and deliberate non-repayment | CONTEXT_DEPENDENT | Future change demand is uncertain, interest is small, or the system may retire before repayment benefits arise. Delay must not violate present obligations or create unacceptable irreversible lock-in. | Do nothing beyond existing observation when there is no live liability; immediate repair dominates when an obligation is already breached. |
| ESME-065 Scoped ownership and change coordination | CONTEXT_DEPENDENT | Multiple contributors or support paths create ambiguity about acceptance, review or incident response. Stated responsibility matches actual access, capability and agreed support commitments. | One maintainer can hold several roles; collaborative ownership is adequate when responsibility remains actionable. |
| ESME-067 Knowledge-concentration metrics as fallible prompts | USEFUL_BUT_EASILY_GAMED | A project needs to assess continuity and history can offer a useful first approximation. Authorship mapping represents some relevant knowledge; uncommitted, operational and domain expertise remain unmeasured. | Ask maintainers directly or exercise a handover when feasible; no metric is required. |
| ESME-070 Deprecation signalling separated from shutdown | DOMAIN_SPECIFIC | An interface or service is being superseded, losing guarantees or approaching shutdown. Dates, scope and authoritative documentation agree; a signal is not itself a migration plan. | A documented support statement may suffice outside HTTP; no header is required where it has no consumer. |
| ESME-072 Purpose-bounded archival preservation and reproducibility | CONTEXT_DEPENDENT | Historical analysis, compliance, research reproduction or future revival justifies retained artefacts after active use. Retained rights, identifiers, storage and environment assumptions support the intended use. | Retain a source snapshot and rationale when execution is unnecessary; avoid indefinitely operating a service solely to preserve history. |
| ESME-082 Repair automation resource trade-offs | DOMAIN_SPECIFIC | Resource-limited repair automation makes memory, energy or time consequential. Measurements use the intended hardware/workload; plausible patch counts are not correctness evidence. | A simpler deterministic tool or human repair can dominate model tuning for a small task. |
| ESME-083 Automated semantic-conflict detection as supplementary evidence | DOMAIN_SPECIFIC | Concurrent changes have plausible semantic interference that targeted automation can help expose. The tool’s language, conflict and observation model fits the case. | Manual joint review and focused integration tests may be enough; clean noninteracting changes need no special tool. |
| ESME-084 Learned-system data and configuration dependencies | DOMAIN_SPECIFIC | A learned component or data pipeline influences supported behaviour. Relevant data rights, lineage and model/version access are available; incompleteness is declared. | Ordinary code/configuration analysis is enough when no learned or changing data dependency is present. |
| ESME-085 Feedback and drift as preservation-boundary changes | ASSUMPTION_SENSITIVE | A learned or environment-sensitive service has a live obligation whose validity depends on changing distributions or feedback. Observation windows and criteria reflect the obligation; distributional observations do not themselves decide normative acceptability. | For a stable deterministic computation, ordinary version-bound regression may suffice. |
| ESME-089 Deletion or degradation requires an explicit containment objective | DOMAIN_SPECIFIC | A proposed fix bypasses code, suppresses errors or disables functionality, especially during an incident. The containment objective and accepted loss are explicit; tests are not allowed to redefine required service silently. | Use a true local correction when feasible; do not invoke containment merely to obtain a passing suite. |
| ESME-092 Supported-version and variant obligation matrix | CONTEXT_DEPENDENT | Several versions, build options, platforms or deployment variants remain supported. The support population is explicit; interaction sampling and omissions are not confused with exhaustive coverage. | One explicitly supported configuration needs no elaborate matrix; retire unsupported variants transparently. |
| ESME-095 Composition-induced effect-relative returnability frontier | ASSUMPTION_SENSITIVE | A migration or release changes the state so a previously valid recovery route no longer applies. The relevant effects and feasibility of recovery options are known well enough to support the decision. | A single reversible edit needs only one verified return path; no global state machine is required. |


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_REJECTED_OR_SUPERSEDED_PRACTICES

These records remain in the denominator. Rejection concerns the stated generalisation or proxy, not every narrower technique with related vocabulary. Contested and unresolved rows are included here for visibility but are not mislabelled as disproved.

### ESME-006 — Four categories as a universally exhaustive taxonomy

**Disposition:** SUPERSEDED_BY_STRONGER_FORM. SUPERSEDED_BY_STRONGER_FORM: Superseded by multidimensional, edition-aware classification; historical four-term usage remains legitimate within a declared scope. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Source-supported: ISO 2022 additive maintenance and alternative activity taxonomies defeat the universal claim.

**Uncertainty / discriminator:** Is a reported distribution really based on the same taxonomy and unit?

**Sources:** ESME-S003, ESME-S006, ESME-S041, ESME-S001, ESME-S004, ESME-S005.

### ESME-008 — Universal growth and inevitable deterioration

**Disposition:** REJECTED_OR_DISFAVOURED. REJECTED_OR_DISFAVOURED: Reject universality, preserve scope-conditioned empirical questions. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Source-supported: population and release-stream results vary. Analytical: stable specified computations need not gain features to remain useful.

**Uncertainty / discriminator:** Which premise connects the cited law to this system’s current obligation?

**Sources:** ESME-S008, ESME-S009, ESME-S010, ESME-S011, ESME-S012, ESME-S013.

### ESME-011 — Invariant organisational work rate as a planning law

**Disposition:** REJECTED_OR_DISFAVOURED. REJECTED_OR_DISFAVOURED: Reject universal prescription while preserving local longitudinal investigation. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Source-supported: heterogeneous evolution studies and version-specific work experiments undermine unqualified transfer, not the original conditional observation.

**Uncertainty / discriminator:** Which changed organisational or technical condition invalidates the extrapolation?

**Sources:** ESME-S008, ESME-S010, ESME-S011, ESME-S012, ESME-S036, ESME-S037.

### ESME-017 — Reverse engineering itself modifies the subject

**Disposition:** REJECTED_OR_DISFAVOURED. REJECTED_OR_DISFAVOURED: Reject category conflation; preserve analysis as an enabling activity. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Source-supported: Chikofsky and Cross define reverse engineering without changing the subject; re-engineering includes subsequent alteration.

**Uncertainty / discriminator:** Which real object changed, rather than merely its description?

**Sources:** ESME-S014, ESME-S014.

### ESME-018 — Exhaustive comprehension before every change

**Disposition:** REJECTED_OR_DISFAVOURED. REJECTED_OR_DISFAVOURED: Reject exhaustive prerequisite, not the need to understand consequential effects. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Source-supported: developers ask bounded evolving questions; formal analyses are purpose-relative. Analytical: mandatory exhaustiveness imposes unbounded cost.

**Uncertainty / discriminator:** Would the missing global knowledge change the local acceptance decision?

**Sources:** ESME-S014, ESME-S016, ESME-S015, ESME-S017, ESME-S018.

### ESME-023 — Co-change correlation proves necessary dependency

**Disposition:** REJECTED_OR_DISFAVOURED. REJECTED_OR_DISFAVOURED: Reject necessity inference, retain bounded search guidance. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Source-supported: historical transactions contain unnecessary or flawed edits and incomplete recall.

**Uncertainty / discriminator:** What intervention or semantic relation would establish that this edit must propagate?

**Sources:** ESME-S020, ESME-S020.

### ESME-026 — Version labels prove compatibility

**Disposition:** REJECTED_OR_DISFAVOURED. REJECTED_OR_DISFAVOURED: Reject proof-by-label, retain semantic versioning as communication. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Source-supported: versioning rules are promises; API and schema behaviour require additional conditions.

**Uncertainty / discriminator:** What evidence checks the publisher’s compatibility promise for this consumer?

**Sources:** ESME-S067, ESME-S021, ESME-S049.

### ESME-033 — Catalogue compliance as a maintenance property

**Disposition:** CEREMONY_NOT_GENERAL_PROPERTY. CEREMONY_NOT_GENERAL_PROPERTY: Strip the ritual while retaining useful vocabulary and validated rules. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Source-supported: refactoring-labelled changes and automated transformations can have adverse results.

**Uncertainty / discriminator:** What protected outcome would remain if the catalogue name were removed?

**Sources:** ESME-S022, ESME-S041, ESME-S023, ESME-S045.

### ESME-040 — Passing all selected tests proves correctness

**Disposition:** REJECTED_OR_DISFAVOURED. REJECTED_OR_DISFAVOURED: Reject the universal inference, not the utility of tests. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Source-supported: wrong patches, omitted regressions, broken harnesses and issue/PR misalignment provide counterexamples.

**Uncertainty / discriminator:** Which untested behaviour or incorrect oracle would leave these tests green?

**Sources:** ESME-S025, ESME-S026, ESME-S024, ESME-S034, ESME-S063, ESME-S064.

### ESME-053 — Rewrites are always wrong

**Disposition:** REJECTED_OR_DISFAVOURED. REJECTED_OR_DISFAVOURED: Reject the universal rule while retaining scrutiny of lost domain knowledge and cutover risk. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Analytical: documented migration alternatives and retirement conditions contradict universal exclusion; this is not a claimed empirical rewrite success rate.

**Uncertainty / discriminator:** Is continued servicing actually feasible over the required support horizon?

**Sources:** ESME-S013, ESME-S029, ESME-S031, ESME-S029, ESME-S055.

### ESME-054 — Newest language or platform is the mature form

**Disposition:** REJECTED_OR_DISFAVOURED. REJECTED_OR_DISFAVOURED: Reject newest-equals-best; preserve targeted adaptation to genuine environmental change. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Analytical objection grounded in migration and debt trade-offs: no universal technology-age ordering is established.

**Uncertainty / discriminator:** What necessary capability or avoided risk is unavailable on the current platform?

**Sources:** ESME-S029, ESME-S031, ESME-S055, ESME-S029, ESME-S058.

### ESME-055 — Reverting code reverses the system

**Disposition:** REJECTED_OR_DISFAVOURED. REJECTED_OR_DISFAVOURED: Reject equivalence and retain effect-relative recovery. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Source-supported: actual database recovery and constrained schema evolution demonstrate distinct obligations.

**Uncertainty / discriminator:** What happened while this code was running that a textual revert cannot undo?

**Sources:** ESME-S019, ESME-S041, ESME-S049, ESME-S051, ESME-S062.

### ESME-061 — Zero technical debt as the objective

**Disposition:** REJECTED_OR_DISFAVOURED. REJECTED_OR_DISFAVOURED: Reject zero-debt optimisation, preserve explicit investment decisions. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Source-supported: deliberate debt and low-interest deferral can create value; scanner issues are not all debt.

**Uncertainty / discriminator:** Which current obligation would be neglected to remove this low-value item?

**Sources:** ESME-S027, ESME-S028, ESME-S058, ESME-S058.

### ESME-062 — A universal maintainability index proves future savings

**Disposition:** REJECTED_OR_DISFAVOURED. REJECTED_OR_DISFAVOURED: Reject universal calibration, retain context-tested diagnostics. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Source-supported: refactoring metrics can be adverse; debt manifesto rejects one-size-fits-all measurement.

**Uncertainty / discriminator:** Was this score validated against the kind of maintenance work being forecast?

**Sources:** ESME-S023, ESME-S058, ESME-S023, ESME-S057, ESME-S058.

### ESME-073 — Popularity guarantees dependency continuity

**Disposition:** REJECTED_OR_DISFAVOURED. REJECTED_OR_DISFAVOURED: Reject popularity-as-assurance, retain it as exposure information. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Source-supported: concentration and maintainer support barriers coexist with public OSS success; graph centrality does not measure human resilience.

**Uncertainty / discriminator:** Who will do the work if the present maintainer leaves, regardless of download count?

**Sources:** ESME-S032, ESME-S033, ESME-S059, ESME-S060.

### ESME-075 — Transition to servicing is effectively irreversible

**Disposition:** CONTESTED. CONTESTED: Still contested as a general claim; retain a local hypothesis to test with recovery cost and demonstrated tasks. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Source-supported conceptual claim is stronger than available universal evidence; recovery methods make irreversibility contingent, not automatically refuted.

**Uncertainty / discriminator:** Can a bounded recovery effort restore the needed change capability at acceptable cost?

**Sources:** ESME-S013, ESME-S014, ESME-S016, ESME-S044.

### ESME-087 — A generated insight does not authorise mutation

**Disposition:** DUPLICATE_CANDIDATE. DUPLICATE_CANDIDATE: Duplicate retained for genealogy and denominator integrity; substitute ESME-001 rather than add a new control. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Analytical duplication judgement: source provenance differs, but the authority invariant and failure are equivalent.

**Uncertainty / discriminator:** Is the perceived new requirement actually an existing authority boundary in a new proposal channel?

**Sources:** ESME-S034, ESME-S035, ESME-S041, ESME-S063, ESME-S064.

### ESME-088 — Long-term net maintainability benefit of AI-assisted evolution

**Disposition:** UNRESOLVED. UNRESOLVED: UNRESOLVED after examination, not NOT_EXAMINED; permit conditional local use without claiming settled long-term superiority. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Source-supported: task/benchmark scope and unreliable follow-up limit long-horizon inference; contrary evidence does not prove permanent harm.

**Uncertainty / discriminator:** What multi-release evidence would distinguish genuine maintainability gains from deferred review and regression costs?

**Sources:** ESME-S035, ESME-S036, ESME-S037, ESME-S038, ESME-S039, ESME-S063, ESME-S064, ESME-S036, ESME-S037, ESME-S063.

### ESME-090 — Universal autonomous maintenance without residual review or authority

**Disposition:** REJECTED_OR_DISFAVOURED. REJECTED_OR_DISFAVOURED: Reject universality without asserting that every action needs manual intervention. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Source-supported: oracle ambiguity, incomplete semantic detection, harness errors and variable productivity leave significant residual obligations.

**Uncertainty / discriminator:** Which unmodelled objective or external effect is this autonomous workflow unable or unauthorised to resolve?

**Sources:** ESME-S035, ESME-S038, ESME-S040, ESME-S034, ESME-S036, ESME-S037, ESME-S063, ESME-S064, ESME-S066.

### ESME-091 — Every historical behaviour must be preserved

**Disposition:** REJECTED_OR_DISFAVOURED. REJECTED_OR_DISFAVOURED: Reject total preservation; retain observer-relative, obligation-sensitive continuity. The negative candidate remains in the population but is not an unconditional audit obligation.

**Strongest limit:** Source-supported: benchmark/reference behaviours can be irrelevant or erroneous; taxonomy includes intentional behavioural change.

**Uncertainty / discriminator:** Why is this old behaviour an obligation today rather than evidence to investigate?

**Sources:** ESME-S001, ESME-S022, ESME-S025, ESME-S034, ESME-S063, ESME-S064.


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CURRENT_STATE_AND_RESEARCH_FRONTIER

The current search extends through **6 September 2026**, including work posted in August 2026. This temporal boundary does not turn forthcoming presentation into completed community replication. The inspected ICSME series page places its 2026 meeting on 14–18 September, after this cut-off. Conference scope establishes the field, not effectiveness of every included technique. [ESME-S042.]

The strongest contemporary shift is not “agents solve maintenance”; it is a broader evaluation object. Repository tasks require requirements, multi-file dependencies and build context. Patch correctness requires more than matching a reference or passing extracted tests. Issue/PR alignment is itself fallible. Tool/model versions, quantisation, prompt age and evaluation hardware can affect outcomes; a particular benchmark result does not transfer automatically to a maintained repository or long-lived system. [ESME-S035, ESME-S038–040, ESME-S063–066.]

The evidence ledger keeps the recent studies separate. METR’s 2025 trial is a particular experienced-developer population and early-2025 workflow; its 2026 follow-up reports important unreliability rather than a clean causal update. PAIChecker’s 68/500 misalignment findings concern its studied Verified population. OpenAI’s selected 138-task audit is not the denominator of the entire 500-task set. Generated tests can detect suspicious differences yet leave requirements unresolved. Quantisation results depend on model, hardware and cost metric. These are reasons to revise candidate claims, not to discard all local automation. [ESME-S036–039, ESME-S063–065.]

Human acceptance, hidden review effort, multi-release regressions and long-term structure remain critical outcomes. The present corpus does not establish a universal lifetime productivity or maintainability effect from AI use. ESME-088 remains UNRESOLVED. Learned-system evolution additionally requires reasoning about data and feedback dependencies, but the CACE warning is not a universal theorem that every change affects every component. A favourable benchmark, popular tool or version label is therefore a lead for bounded evaluation, not a sufficient acceptance argument. [ESME-S061; ESME-078–085/088/090.]


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_ADVERSARIAL_SYNTHESIS_VERDICT

**Verdict: a coherent conditional core survives, with alternatives and explicitly unvalidated composition.** The strongest core links legitimate intent, an identifiable baseline, bounded comprehension and impact, observer-relative preservation, appropriate change/regression evidence, real maintainer/consumer capability and lifecycle decisions. These are coupled by shared objects and decision consumers; the system is more than the union of technique names.

The strongest objection to unification is cost: making every dependency, observer, authority and assumption explicit can exceed the maintenance task’s value. This objection changes the system. ESME-097 and every retained record permit an adequate cheap path; the smallest form can be an existing issue, a relevant test and a capable actor. A mandatory full formal model, comprehensive debt inventory or universal migration governance structure does not survive. The next objection is epistemic: a neat contract can stabilise the wrong requirements. This changes ESME-098 and the contested/uncertain branch: independent intent evidence and unresolved questions cannot be replaced by more self-confirming tests.

A third objection is that some failures cannot be closed internally. Unknown consumers, lost expertise, insufficient operational access and irreversible external effects remain outside the investigator’s unilateral control. The model therefore distinguishes recognising a need, having authority/capability, acting, and establishing the effect. It does not self-authorise interventions or imply that every responsible transition is reversible. A fourth objection is evidence transfer: conceptual coherence and examples do not establish representative net benefit. The six composition-induced properties retain analytical evidence status, and ESME-CO01 keeps empirical evaluation of the combined system explicit.

The discriminating cases change decisions rather than merely demonstrate success. Important undocumented behaviour triggers inquiry rather than automatic preservation; an observer-changing refactor invalidates an unqualified preservation claim; irreversible conversion removes simple rollback; popularity does not replace maintainer capacity; complexity that enables needed variation is not automatically debt; and stable useful operation may justify no change. Conflict and failed-observation cases reopen the relevant acceptance assumptions. Those outcomes are the reason the synthesis rejects universal growth, “tests equal correctness”, automatic rewrites, zero-debt goals, presumed reversible releases and blanket agent autonomy.

The corpus is ready for independent later comparison, not validated target adoption. Freezing records the scope and present judgements, including adverse and unresolved results. It does not freeze the future field or turn its current evidence limits into permanent truths.


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_OPEN_QUESTIONS_AND_EVIDENCE_LIMITS

### Examined unsettled questions

| Record | Status | Question and consequence |
| --- | --- | --- |
| ESME-075 | CONTESTED | Whether loss of evolution capability is economically irreversible in a particular servicing stage. The strong universal reading is not an obligation; target-specific recovery evidence can discriminate. |
| ESME-088 | UNRESOLVED | Whether AI-assisted maintenance produces general net multi-release maintainability improvement rather than displaced effort or later liabilities. Local conditional use remains possible. |
| ESME-CO01 | EXAMINED_UNRESOLVED_EMPIRICAL_VALIDITY | Representative comparative net benefit and coordination cost of this composed system have not been established. |
| ESME-CO02 | EXAMINED_TARGET_DEPENDENT_BOUNDARY | Unknown consumers, irreversible effects and disputed intent require target evidence; this external corpus does not invent it. |
| ESME-CO03 | EXAMINED_UNRESOLVED_LONGITUDINAL_CLAIM | Longitudinal automation effects remain open despite recent task-level evidence. |

### Access and evidence limitations

Original Swanson access remains mediated by inspected later primary taxonomies and historical guidance. ISO 14764:2022 was inspected through official metadata and a lawful partial preview, not the entire standard. F1 and selected other works have abstract/partial-text limits. The Naur reprint’s original-work date is distinct from its unestablished reprint edition; visible SWEBOK metadata has a date anomaly recorded in its source entry. These limits narrow claims rather than permit invented methods or locators. All such sources remain identified in the coverage JSON. ISO/IEC/IEEE 14764:2022 §4 explicitly directs conformance claims to the ISO/IEC/IEEE 12207 maintenance process and tailoring, not to 14764 itself; mandatory requirements in 14764 are duplicated from 12207. This study therefore does not turn every guidance statement into a conformity obligation. [ESME-S001, printed p.5.]

The evidence partitions are intentionally not averaged. Formal validity can be strong within a stated model while deployment transfer remains weak; a standard defines an obligation but does not show benefit; practitioner and incident accounts support possible mechanisms but not frequency; selected empirical populations do not yield universal effects. Shared Linux releases, Google programmes, Defects4J-derived tasks, SWE-bench populations or overlapping study teams are not counted as independent confirmations. Every source records its inspected scope and design or an explicit reason no empirical/formal design is asserted.

### Source register and claim locators

This human-readable register resolves all report citations. The source-table JSON additionally preserves roles, methods, measures, uncertainty, shared datasets/programmes and supported/adjudicated property links. No copyrighted full-text sources are bundled.

#### ESME-S001 — Software engineering — Software life cycle processes — Maintenance

**Author / body:** ISO/IEC/IEEE. **Date:** 2022-01. **Edition:** Third edition, 2022; distinct from 2006.

**Access:** OFFICIAL_METADATA_AND_LAWFUL_PARTIAL_PREVIEW; 2026-09-06. **Inspected locators:** Official scope; preview §§3.1.1–3.1.14; Figure 1 within §3.1.8 notes (printed p.4); §4 Conformance (printed p.5); opening §§5.1–5.2.

**Exact work:** https://www.iso.org/standard/80710.html; https://cdn.standards.iteh.ai/samples/80710/9a26fc3a1a464fa286fb85d6c1eeed31/ISO-IEC-IEEE-14764-2022.pdf

**Roles:** DEFINITION_OR_TAXONOMY, STANDARD_OR_GUIDANCE_REQUIREMENT. **Limits:** Thirteen-page preview, not the complete 36-page standard. No claim to have inspected later requirements. Section 4 says conformance cannot be claimed to this guidance document itself, but can be claimed to the ISO/IEC/IEEE 12207 maintenance process and tailoring; only duplicated 12207 clauses supply mandatory requirements. Definitions and guidance do not establish comparative benefit.

#### ESME-S002 — Software Engineering — Software Life Cycle Processes — Maintenance

**Author / body:** ISO/IEC; IEEE. **Date:** 2006. **Edition:** Second edition, 2006.

**Access:** OFFICIAL_ABSTRACT_ONLY; 2026-09-06. **Inspected locators:** IEEE record, title and scope.

**Exact work:** https://standards.ieee.org/ieee/14764/3498/

**Roles:** HISTORICAL_PROVENANCE, STANDARD_OR_GUIDANCE_REQUIREMENT. **Limits:** Predecessor identity verified; full text not inspected. Definitions are not silently substituted for the 2022 edition.; Contextual source only: establishes edition/community provenance, not a distinct property; genuine non-allocation, not unfinished extraction.

#### ESME-S003 — The dimensions of maintenance

**Author / body:** E. Burton Swanson. **Date:** 1976. **Edition:** ICSE 1976, pp.492–497; original not directly inspected.

**Access:** ORIGINAL_ACCESS_LIMIT_MEDIATED_PROVENANCE; 2026-09-06. **Inspected locators:** Original bibliographic identity; discussion of the original three-purpose taxonomy in ESME-S004 §2 and ESME-S006 historical discussion.

**Exact work:** https://dl.acm.org/doi/10.5555/800253.807723

**Roles:** HISTORICAL_PROVENANCE. **Limits:** Publisher landing/PDF could not be retrieved after bounded attempts. No original page-level substantive reading claimed. Original attribution is mediated through inspected scholarly and historical successors.

#### ESME-S004 — Types of software evolution and software maintenance

**Author / body:** Ned Chapin; Joanne E. Hale; Khaled Md. Khan; Juan F. Ramil; Wui-Gee Tan. **Date:** 2001. **Edition:** Original work / author copy as specified.

**Access:** FULL_TEXT_SELECTED_SECTIONS; 2026-09-06. **Inspected locators:** §§1–3: purpose versus observable activity; twelve types in four clusters; conclusion; Appendix A definitions.

**Exact work:** https://www.academia.edu/21971143/Types_of_software_evolution_and_software_maintenance

**Roles:** DEFINITION_OR_TAXONOMY, HISTORICAL_PROVENANCE, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Proposed taxonomy, not a universal ontology or empirical demonstration of superior decisions. Prose inspected; figures not used.

#### ESME-S005 — Towards a taxonomy of software change

**Author / body:** Jim Buckley; Tom Mens; Matthias Zenger; Awais Rashid; Günter Kniesel. **Date:** 2005. **Edition:** Original work / author copy as specified.

**Access:** FULL_TEXT_SELECTED_SECTIONS_AND_FIGURE; 2026-09-06. **Inspected locators:** §§2–3, especially dimensions of when, what, how and where; Figure 1 on printed p.312.

**Exact work:** https://www.cs.kent.edu/~jmaletic/cs63902/Papers/Buckley05.pdf

**Roles:** DEFINITION_OR_TAXONOMY, HISTORICAL_PROVENANCE. **Limits:** Authors explicitly decline exhaustiveness; taxonomy does not establish causal effectiveness of a particular mechanism.

#### ESME-S006 — Guidance on software maintenance

**Author / body:** Roger J. Martin; Wilma M. Osborne; National Bureau of Standards. **Date:** 1983-12. **Edition:** NBS Special Publication 500-106.

**Access:** FULL_TEXT_SELECTED_SECTIONS; 2026-09-06. **Inspected locators:** Cover (December 1983); abstract; introductory maintenance scope and historical taxonomy discussion.

**Exact work:** https://nvlpubs.nist.gov/nistpubs/Legacy/SP/nbsspecialpublication500-106.pdf

**Roles:** HISTORICAL_PROVENANCE, STANDARD_OR_GUIDANCE_REQUIREMENT. **Limits:** Not a controlled evaluation; selected sections only. Publication date is not digitisation date.

#### ESME-S007 — Determining the distribution of maintenance categories: Survey versus measurement

**Author / body:** Stephen R. Schach; Bo Jin; Liguo Yu; Gillian Z. Heller; Jeff Offutt. **Date:** 2003. **Edition:** Original work / author copy as specified.

**Access:** PUBLISHER_ABSTRACT_ONLY; 2026-09-06. **Inspected locators:** Abstract: three products, two granularities, comparison with Lientz–Swanson–Tompkins survey.

**Exact work:** https://link.springer.com/article/10.1023/A:1025368318006

**Roles:** EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Subscription methods not inspected; no new general proportion or causal attribution inferred from abstract.

#### ESME-S008 — A model of large program development

**Author / body:** László A. Belady; Meir M. Lehman. **Date:** 1976. **Edition:** Original work / author copy as specified.

**Access:** FULL_TEXT_SELECTED_SECTIONS; 2026-09-06. **Inspected locators:** Opening problem and OS/360 setting; process-model discussion.

**Exact work:** https://cseweb.ucsd.edu/~wgg/CSE218/BeladyModel-10.1.1.86.9200.pdf

**Roles:** HISTORICAL_PROVENANCE, FORMAL_OR_THEORETICAL_RESULT, FIELD_OR_DEPLOYMENT_EVIDENCE. **Limits:** Historical study of a specific industrial programme, not a physical law for all software. Metrics and organisation are part of the model.

#### ESME-S009 — Programs, life cycles, and laws of software evolution

**Author / body:** Meir M. Lehman. **Date:** 1980. **Edition:** Original work / author copy as specified.

**Access:** FULL_TEXT_SELECTED_SECTIONS; 2026-09-06. **Inspected locators:** Introduction; discussion distinguishing software change from physical wear; S/P/E programme classification.

**Exact work:** https://users.ece.utexas.edu/~perry/education/SE-Intro/lehman.pdf

**Roles:** HISTORICAL_PROVENANCE, DEFINITION_OR_TAXONOMY, FORMAL_OR_THEORETICAL_RESULT. **Limits:** Classification and empirical laws are explanatory proposals, not universal mathematical guarantees.

#### ESME-S010 — Laws of software evolution revisited

**Author / body:** Meir M. Lehman. **Date:** 1996. **Edition:** 1996 workshop paper; author revision dated 1997-01-21.

**Access:** FULL_TEXT_SELECTED_SECTIONS_AND_TABLE; 2026-09-06. **Inspected locators:** §§1–3; eight-law table; E-type scope; FEAST feedback discussion.

**Exact work:** https://www.cs.kent.edu/~jmaletic/cs63902/Papers/Lehman96.pdf

**Roles:** HISTORICAL_PROVENANCE, FORMAL_OR_THEORETICAL_RESULT. **Limits:** Author copy revised 21 January 1997; event/publication 1996. E-type and organisational assumptions must not be dropped. Not independent evidence from original IBM study.

#### ESME-S011 — Evolution in open source software: A case study

**Author / body:** Michael W. Godfrey; Qiang Tu. **Date:** 2000. **Edition:** Original work / author copy as specified.

**Access:** FULL_TEXT_SELECTED_METHODS_AND_RESULTS; 2026-09-06. **Inspected locators:** §5 Linux measurement; source-file scope and growth discussion; figures inspected.

**Exact work:** https://plg2.cs.uwaterloo.ca/~migod/papers/2000/icsm00.pdf

**Roles:** EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Release streams and counted artefacts affect growth estimates; no general OSS superiority follows.

#### ESME-S012 — The evolution of FreeBSD and Linux

**Author / body:** Clemente Izurieta; James M. Bieman. **Date:** 2006. **Edition:** Original work / author copy as specified.

**Access:** FULL_TEXT_SELECTED_METHODS_AND_RESULTS; 2026-09-06. **Inspected locators:** §§5–6, stable-release trends; conclusion; plots inspected.

**Exact work:** https://www.cs.montana.edu/izurieta/pubs/isese2006.pdf

**Roles:** EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Stable-release sampling differs from studies mixing development releases; failure to support a general prediction is not proof of its negation everywhere.

#### ESME-S013 — Software maintenance and evolution: A roadmap

**Author / body:** Keith H. Bennett; Václav T. Rajlich. **Date:** 2000. **Edition:** Original work / author copy as specified.

**Access:** FULL_TEXT_SELECTED_SECTIONS_AND_FIGURE; 2026-09-06. **Inspected locators:** §§1–2; staged model Figure 1; evolution/servicing knowledge distinction; phaseout and closedown.

**Exact work:** https://www.staff.science.uu.nl/~telea001/uploads/SME/BR_SW_maint_evol.pdf; https://doi.org/10.1145/336512.336534

**Roles:** DEFINITION_OR_TAXONOMY, FIELD_OR_DEPLOYMENT_EVIDENCE, RESEARCHER_INTERPRETATION. **Limits:** Authors state near-irreversibility of transition to servicing; this packet narrows it to a contingent knowledge/cost hypothesis, not a theorem. Stage model is not a compulsory linear lifecycle.

#### ESME-S014 — Reverse engineering and design recovery: A taxonomy

**Author / body:** Elliot J. Chikofsky; James H. Cross II. **Date:** 1990. **Edition:** Original work / author copy as specified.

**Access:** ALL_FIVE_PAGES_VISUALLY_INSPECTED; 2026-09-06. **Inspected locators:** pp.13–17; p.14 abstraction diagram and iteration qualification; p.15 definitions; p.16 recovery limits.

**Exact work:** https://www.ifi.uzh.ch/dam/jcr:00000000-2f41-7b40-ffff-ffffdc0b3b5e/chikofsky90.pdf

**Roles:** DEFINITION_OR_TAXONOMY, HISTORICAL_PROVENANCE. **Limits:** Terminological reconstruction; claimed economic benefits are not comparative evidence. Software import from hardware reverse engineering is qualified by different purposes.

#### ESME-S015 — Program slicing

**Author / body:** Mark Weiser. **Date:** 1984. **Edition:** Original work / author copy as specified.

**Access:** ALL_SIX_PAGES_VISUALLY_INSPECTED; 2026-09-06. **Inspected locators:** pp.352–357: slicing criterion, conservative construction, minimality limits and experiment.

**Exact work:** https://faculty.cc.gatech.edu/~harrold/6340/cs6340_fall2009/Readings/Weiser.Slicing.TSE.pdf

**Roles:** FORMAL_OR_THEORETICAL_RESULT, EMPIRICAL_COMPARISON, HISTORICAL_PROVENANCE. **Limits:** Terminating-execution and language/analysis assumptions delimit result. Small student-program study does not establish industrial comprehension savings.

#### ESME-S016 — Programming as theory building

**Author / body:** Peter Naur. **Date:** 1985. **Edition:** 1985 original; inspected anthology reprint, edition not established.

**Access:** SELECTED_REPRINT_PAGES_VISUALLY_INSPECTED; 2026-09-06. **Inspected locators:** Reprint pp.229 and 232: transfer experiences, theory building and modification costs; original paper identity on first page.

**Exact work:** https://pages.cs.wisc.edu/~remzi/Naur.pdf

**Roles:** HISTORICAL_PROVENANCE, FIELD_OR_DEPLOYMENT_EVIDENCE, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Anthology edition of accessible reprint is not identified; do not attribute editor introduction to Naur. Two reported experiences are not controlled causal evidence.

#### ESME-S017 — Questions programmers ask during software evolution tasks

**Author / body:** Jonathan Sillito; Gail C. Murphy; Kris De Volder. **Date:** 2006. **Edition:** Original work / author copy as specified.

**Access:** FULL_TEXT_SELECTED_METHODS_AND_FINDINGS; 2026-09-06. **Inspected locators:** §3 study design; question categorisation and iterative inquiry findings.

**Exact work:** https://www.researchgate.net/publication/221560447_ABSTRACT_Questions_Programmers_Ask_During_Software_Evolution_Tasks; https://doi.org/10.1145/1181775.1181779

**Roles:** EMPIRICAL_COMPARISON, FIELD_OR_DEPLOYMENT_EVIDENCE. **Limits:** Nine newcomers and sixteen experienced developers in distinct settings; 44 question types are an observational result, not a universal mandatory protocol.

#### ESME-S018 — Measuring program comprehension: A large-scale field study with professionals

**Author / body:** Xin Xia; Lingfeng Bao; David Lo; Zhenchang Xing; Ahmed E. Hassan; Shanping Li. **Date:** 2018. **Edition:** Original work / author copy as specified.

**Access:** FULL_TEXT_SELECTED_METHODS_DISCUSSION; 2026-09-06. **Inspected locators:** Introduction; activity-classification design; discussion and validity cautions.

**Exact work:** https://soarsmu.github.io/papers/2018/Xia2018ProgramComprehension.pdf; https://doi.org/10.1109/TSE.2017.2734091

**Roles:** FIELD_OR_DEPLOYMENT_EVIDENCE. **Limits:** Online publication 2017, journal issue 2018. Classified activity time is not a universal budget or randomised treatment effect.

#### ESME-S019 — Software configuration management: A roadmap

**Author / body:** Jacky Estublier. **Date:** 2000. **Edition:** Original work / author copy as specified.

**Access:** FULL_TEXT_SELECTED_SECTIONS; 2026-09-06. **Inspected locators:** Product space, workspaces, change sets and merging; explicit limitations of textual three-way merge.

**Exact work:** https://www.academia.edu/78976947/Software_configuration_management; https://doi.org/10.1145/336512.336576

**Roles:** DEFINITION_OR_TAXONOMY, HISTORICAL_PROVENANCE, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Roadmap and practitioner synthesis, not comparative proof of one SCM tool. Full PDF unavailable; primary article prose accessible.

#### ESME-S020 — Mining version histories to guide software changes

**Author / body:** Thomas Zimmermann; Peter Weißgerber; Stephan Diehl; Andreas Zeller. **Date:** 2004. **Edition:** Original work / author copy as specified.

**Access:** FULL_TEXT_SELECTED_METHODS_RESULTS_LIMITS; 2026-09-06. **Inspected locators:** §6 evaluation and §6.8 threats; time-ordered history, changed-entity recommendations.

**Exact work:** https://thomas-zimmermann.com/publications/files/zimmermann-icse-2004.pdf

**Roles:** EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Co-edit prediction is not semantic dependency detection; historical changes may be unnecessary or flawed. Developer benefit not directly demonstrated.

#### ESME-S021 — How do APIs evolve? A story of refactoring

**Author / body:** Danny Dig; Ralph Johnson. **Date:** 2006. **Edition:** Original work / author copy as specified.

**Access:** FULL_TEXT_SELECTED_SECTIONS; 2026-09-06. **Inspected locators:** Abstract and introduction: framework/library API changes and client adaptation.

**Exact work:** https://www.cs.kent.edu/~jmaletic/cs63902/Papers/Dig06.pdf

**Roles:** EMPIRICAL_COMPARISON, HISTORICAL_PROVENANCE. **Limits:** Four frameworks and one library; not an ecosystem-wide breaking-change rate. Author manuscript pagination differs from final pp.83–107. Earlier conference paper is not another replication.

#### ESME-S022 — Refactoring object-oriented frameworks

**Author / body:** William F. Opdyke. **Date:** 1992. **Edition:** Original work / author copy as specified.

**Access:** FULL_TEXT_SELECTED_FORMAL_SECTIONS; 2026-09-06. **Inspected locators:** Abstract; §4.1 preconditions; printed p.42 excluded language-observation features.

**Exact work:** https://www.laputan.org/pub/papers/opdyke-thesis.pdf

**Roles:** FORMAL_OR_THEORETICAL_RESULT, HISTORICAL_PROVENANCE. **Limits:** Formalisation deliberately excludes some representation-observing operations. Preconditions may be conservative or undecidable in general. Catalogue breadth is not language-universal completeness.

#### ESME-S023 — Refactoring — Does it improve software quality?

**Author / body:** Konstantinos Stroggylos; Diomidis Spinellis. **Date:** 2007. **Edition:** Original work / author copy as specified.

**Access:** FULL_PRIMARY_HTML_TEXT; 2026-09-06. **Inspected locators:** Study design, results, Apache example and conclusions.

**Exact work:** https://www2.dmst.aueb.gr/dds/pubs/conf/2007-WoSQ-Refactor/html/SS07.html; https://doi.org/10.1109/WOSQ.2007.11

**Roles:** EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Commit-message identification and metric proxies do not establish clean causal refactoring effects or future maintenance cost. Changed requirements may be mixed into commits.

#### ESME-S024 — A framework for checking regression test selection tools

**Author / body:** Chenguang Zhu; Owolabi Legunsen; August Shi; Milos Gligoric. **Date:** 2019. **Edition:** Original work / author copy as specified.

**Access:** FULL_TEXT_METHODS_RESULTS_THREATS_AND_TABLE; 2026-09-06. **Inspected locators:** §§III–IV; §VI; result table visually inspected.

**Exact work:** https://www.cs.cornell.edu/~legunsen/pubs/ZhuETAL19RTSCheck.pdf

**Roles:** EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE, IMPLEMENTATION_SEMANTICS. **Limits:** 24,000+ observed violations are not 24,000 unique bugs; 207 inspected violations yielded 27 issues, including technique limits. Not all issues independently confirmed.

#### ESME-S025 — The oracle problem in software testing: A survey

**Author / body:** Earl T. Barr; Mark Harman; Phil McMinn; Muzammil Shahbaz; Shin Yoo. **Date:** 2015. **Edition:** Original work / author copy as specified.

**Access:** FULL_TEXT_SELECTED_TAXONOMY_SECTIONS; 2026-09-06. **Inspected locators:** Introduction and oracle definitions; taxonomy of oracle information sources.

**Exact work:** https://eecs481.org/readings/testoracles.pdf; https://doi.org/10.1109/TSE.2014.2372785

**Roles:** DEFINITION_OR_TAXONOMY, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Used to organise oracle alternatives, not as independent effectiveness evidence for every technique. Online DOI date 2014; journal publication 2015.

#### ESME-S026 — A safe, efficient regression test selection technique

**Author / body:** Gregg Rothermel; Mary Jean Harrold. **Date:** 1997. **Edition:** Original work / author copy as specified.

**Access:** PARTIAL_PRIMARY_TEXT_PREVIEW; 2026-09-06. **Inspected locators:** Opening pp.173–175: P/P′, specification/test-set setting and safe selection objective.

**Exact work:** https://paperity.org/p/376973901/a-safe-efficient-regression-test-selection-technique; https://doi.org/10.1145/248233.248262

**Roles:** FORMAL_OR_THEORETICAL_RESULT. **Limits:** Full proof and complete experimental details not inspected in this copy; no independent re-proof claimed. Ignore unrelated metadata author inserted by host.

#### ESME-S027 — The WyCash portfolio management system

**Author / body:** Ward Cunningham. **Date:** 1992-03-26. **Edition:** Original work / author copy as specified.

**Access:** COMPLETE_AUTHOR_HTML_TEXT; 2026-09-06. **Inspected locators:** Author text: incremental development, consolidation and debt metaphor.

**Exact work:** https://c2.com/doc/oopsla92.html

**Roles:** HISTORICAL_PROVENANCE, FIELD_OR_DEPLOYMENT_EVIDENCE. **Limits:** First-person Smalltalk experience, not a measurement model or proof that all undesirable code is debt. Date is author-page version; OOPSLA experience-report context 1992.

#### ESME-S028 — The future of managing technical debt

**Author / body:** Software Engineering Institute, reporting the 2016 Dagstuhl technical-debt seminar. **Date:** 2016-08-29. **Edition:** Original work / author copy as specified.

**Access:** PRIMARY_TEXT_SELECTED_SECTIONS; 2026-09-06. **Inspected locators:** Technical-debt definition and debt-item/cause/consequence discussion.

**Exact work:** https://www.sei.cmu.edu/blog/the-future-of-managing-technical-debt/

**Roles:** DEFINITION_OR_TAXONOMY, HISTORICAL_PROVENANCE. **Limits:** Collective working definition and agenda, not economic-effect validation; stakeholder agreement does not imply universal measurement validity.

#### ESME-S029 — Legacy information system migration: A brief review of problems, solutions and research issues

**Author / body:** Jesús Bisbal; Deirdre Lawless; Bing Wu; Jane Grimson. **Date:** 1999. **Edition:** TCD-CS-1999-38.

**Access:** FULL_TEXT_SELECTED_MIGRATION_SECTIONS; 2026-09-06. **Inspected locators:** Legacy migration alternatives; §2.3.2 Chicken Little and gateways; Butterfly discussion.

**Exact work:** https://publications.scss.tcd.ie/tech-reports/reports.99/TCD-CS-1999-38.pdf

**Roles:** DEFINITION_OR_TAXONOMY, HISTORICAL_PROVENANCE, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Review used for mechanisms and documented relationships, not counted as empirical replication of described migrations. General heterogeneous update reconciliation remains an explicit difficulty.

#### ESME-S030 — Original Strangler Fig Application

**Author / body:** Martin Fowler. **Date:** 2004-06-29. **Edition:** Original work / author copy as specified.

**Access:** PRIMARY_HTML_TEXT; 2026-09-06. **Inspected locators:** Original account and Chris Stevenson project context.

**Exact work:** https://martinfowler.com/bliki/OriginalStranglerFigApplication.html

**Roles:** HISTORICAL_PROVENANCE, FIELD_OR_DEPLOYMENT_EVIDENCE. **Limits:** Early project account was not completed retirement evidence or a comparative trial. Incremental risk argument has architectural prerequisites.

#### ESME-S031 — Strangler Fig Application

**Author / body:** Martin Fowler. **Date:** 2024. **Edition:** 2024 revised explanation, distinct from original 2004 text.

**Access:** PRIMARY_HTML_TEXT; 2026-09-06. **Inspected locators:** Updated replacement-pattern explanation and conditions.

**Exact work:** https://martinfowler.com/bliki/StranglerFigApplication.html

**Roles:** DEFINITION_OR_TAXONOMY, HISTORICAL_PROVENANCE. **Limits:** Distinct revised account, not an independent replication of 2004 experience. No universal claim that incremental replacement dominates.

#### ESME-S032 — A novel approach for estimating truck factors

**Author / body:** Guilherme Avelino; Leonardo Passos; Andre Hora; Marco Tulio Valente. **Date:** 2016. **Edition:** Original work / author copy as specified.

**Access:** FULL_TEXT_SELECTED_METHODS_RESULTS; 2026-09-06. **Inspected locators:** Abstract, authorship-based estimation and validation discussion.

**Exact work:** https://arxiv.org/pdf/1604.06766; https://doi.org/10.1109/ICPC.2016.7503718

**Roles:** EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Commit-based ownership is a proxy for recoverable knowledge, not a collapse probability. Validation agreement differs for authorship and final truck-factor estimate.

#### ESME-S033 — An empirical comparison of dependency network evolution in seven software packaging ecosystems

**Author / body:** Alexandre Decan; Tom Mens; Philippe Grosjean. **Date:** 2019. **Edition:** 2017 arXiv preprint; 2019 journal publication (online DOI earlier).

**Access:** FULL_TEXT_SELECTED_METHODS_RESULTS; 2026-09-06. **Inspected locators:** Dataset and network-growth/dependency measures; interpretation and limits.

**Exact work:** https://arxiv.org/pdf/1710.04936; https://doi.org/10.1007/s10664-017-9589-y

**Roles:** EMPIRICAL_COMPARISON. **Limits:** 2017 preprint and later journal publication are the same research programme. Structural exposure is not observed failure frequency.

#### ESME-S034 — An analysis of patch plausibility and correctness for generate-and-validate patch generation systems

**Author / body:** Zichao Qi; Fan Long; Sara Achour; Martin Rinard. **Date:** 2015. **Edition:** Original work / author copy as specified.

**Access:** FULL_TEXT_SELECTED_METHODS_FINDINGS; 2026-09-06. **Inspected locators:** Introduction; evaluation-harness and plausibility/correctness distinction; deletion baseline.

**Exact work:** https://people.csail.mit.edu/rinard/paper/issta15.pdf

**Roles:** EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Separate test-harness defects from genuinely test-passing but wrong patches. Study of particular GenProg, RSRepair and AE configurations is not a refutation of every APR method.

#### ESME-S035 — SWE-bench: Can language models resolve real-world GitHub issues?

**Author / body:** Carlos E. Jimenez; John Yang; Alexander Wettig; Shunyu Yao; Kexin Pei; Ofir Press; Karthik Narasimhan. **Date:** 2024. **Edition:** ICLR 2024; arXiv v3 of 2023 submission.

**Access:** FULL_TEXT_SELECTED_DATASET_EVALUATION_LIMITS; 2026-09-06. **Inspected locators:** Dataset construction; issue/PR/test extraction; evaluation and limitations.

**Exact work:** https://arxiv.org/html/2310.06770v3

**Roles:** EMPIRICAL_COMPARISON, DEFINITION_OR_TAXONOMY. **Limits:** 2,294 issues from twelve Python repositories do not represent all maintenance. Historical scores are not current leaderboard claims; repository history can contaminate evaluation.

#### ESME-S036 — Measuring the impact of early-2025 AI on experienced open-source developer productivity

**Author / body:** Joel Becker; Nate Rush; Beth Barnes; David Rein. **Date:** 2025. **Edition:** Original work / author copy as specified.

**Access:** FULL_TEXT_SELECTED_METHODS_RESULTS_AND_FIGURE; 2026-09-06. **Inspected locators:** §2.2 experimental design; main result; Appendix D estimator; figure and issue examples inspected.

**Exact work:** https://metr.org/Early_2025_AI_Experienced_OS_Devs_Study-paper.pdf; https://metr.org/blog/2025-07-10-early-2025-ai-experienced-os-dev-study/

**Roles:** EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** 16 developers/246 tasks; experienced maintainers and early-2025 tool versions. Not a universal claim about current AI. Follow-up ESME-S037 materially limits temporal extrapolation.

#### ESME-S037 — We are changing our developer productivity experiment design

**Author / body:** Joel Becker; Nate Rush; Tom Cunningham; David Rein; Khalid Mahamud; METR. **Date:** 2026-02-24. **Edition:** Original work / author copy as specified.

**Access:** PRIMARY_TEXT_METHODS_AND_RESULTS; 2026-09-06. **Inspected locators:** Opening result qualification; participation and task-selection mechanisms; redesigned-study discussion.

**Exact work:** https://metr.org/blog/2026-02-24-uplift-update/

**Roles:** EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Follow-up authors explicitly call the estimate unreliable due to selection and measurement effects. Neither proves no benefit nor establishes a precise current speedup.

#### ESME-S038 — Aging of prompt engineering techniques across LLM versions

**Author / body:** Anastasiia Rudyk; Julian Oertel; Regina Hebig. **Date:** 2026-08-25. **Edition:** arXiv v1, 2026-08-25; accepted for future ICSME 2026.

**Access:** FULL_TEXT_SELECTED_METHODS_RESULTS_LIMITS; 2026-09-06. **Inspected locators:** Study design and prompt/model-version comparison; threats to validity.

**Exact work:** https://arxiv.org/html/2608.24641v1

**Roles:** EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Accepted-author/preprint evidence before ICSME 2026 event; not a completed conference presentation. Function-level benchmark and particular version pairs, not repository-wide long-term maintainability.

#### ESME-S039 — Smaller models, unexpected costs: Trade-offs in LLM quantization for automated program repair

**Author / body:** Fernando Vallecillos-Ruiz; Giordano d’Aloisio; Max Hort; Luca Traini; Antinisca Di Marco; Leon Moonen. **Date:** 2026-06-25. **Edition:** arXiv v1, 2026-06-25.

**Access:** FULL_TEXT_SELECTED_METHODS_RESULTS_LIMITS; 2026-09-06. **Inspected locators:** Experimental design; memory, runtime, energy and repair outcomes; validity section.

**Exact work:** https://arxiv.org/html/2606.27205v1

**Roles:** EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Results depend on hardware, model and quantisation; plausible patches are not fully verified repairs. Preprint/accepted paper, not long-term field validation.

#### ESME-S040 — Combining example-based and rule-based program transformations to resolve build conflicts

**Author / body:** Sheikh Shadab Towqir; Fei He; Todd Mytkowicz; Na Meng. **Date:** 2026. **Edition:** MSR 2026; arXiv v2 of 2025 submission.

**Access:** FULL_TEXT_SELECTED_METHODS_RESULTS; 2026-09-06. **Inspected locators:** BuCoR design and build-conflict evaluation.

**Exact work:** https://arxiv.org/html/2507.19432v2; https://doi.org/10.1145/3793302.3793347

**Roles:** EMPIRICAL_COMPARISON, IMPLEMENTATION_SEMANTICS. **Limits:** Build conflict resolution is not full semantic merge correctness. Dataset small and typed; counts are suggestions versus correct resolutions, not interchangeable.

#### ESME-S041 — Guide to the Software Engineering Body of Knowledge, version 4.0a

**Author / body:** IEEE Computer Society; Hironori Washizaki (editor). **Date:** 2025-09. **Edition:** v4.0a; visible cover Released Sept 2025, inspected 2026-09-06.

**Access:** SELECTED_CHAPTER_TEXT_AND_VISUAL_PAGES; 2026-09-06. **Inspected locators:** Visual cover; chapter 7 §§1.1–1.6 and §§3.1–3.2.2; Figure 7.2; selected chapter 6 interface.

**Exact work:** https://ieeecs-media.computer.org/media/education/swebok/swebok-v4.pdf; https://www.computer.org/education/bodies-of-knowledge/software-engineering

**Roles:** STANDARD_OR_GUIDANCE_REQUIREMENT, DEFINITION_OR_TAXONOMY. **Limits:** Visual cover says September 2025; web parsed text anomalously says August 2026. Use visible edition date and disclose mismatch. Guide compresses evolution-law scope; primary E-type formulations control interpretation. Not all chapters read.

#### ESME-S042 — ICSME series and ICSME 2026 research-track programme

**Author / body:** ICSME community and 2026 organisers. **Date:** 2026. **Edition:** Original work / author copy as specified.

**Access:** OFFICIAL_SCOPE_AND_PROGRAMME; 2026-09-06. **Inspected locators:** Series scope; 2026 research track, accepted-paper listings and 14–18 September dates.

**Exact work:** https://icsme.github.io/; https://conf.researchr.org/track/icsme-2026/icsme-2026-papers

**Roles:** HISTORICAL_PROVENANCE. **Limits:** Programme establishes topic/activity, not effectiveness. Conference is after research cut-off; accepted preprints can already report experiments.; Contextual source only: establishes edition/community provenance, not a distinct property; genuine non-allocation, not unfinished extraction.

#### ESME-S043 — Dynamic program slicing

**Author / body:** Hiralal Agrawal; Joseph R. Horgan. **Date:** 1990. **Edition:** PLDI 1990, pp.246–256.

**Access:** FIRST_TWO_PAGES_VISUALLY_INSPECTED; 2026-09-06. **Inspected locators:** pp.246–247: execution-specific criterion; dependence graphs; relationship to static slicing.

**Exact work:** https://www.cs.columbia.edu/~junfeng/08fa-e6998/sched/readings/slicing.pdf

**Roles:** FORMAL_OR_THEORETICAL_RESULT, HISTORICAL_PROVENANCE. **Limits:** Full algorithm/proof and industrial effectiveness not inspected. A dynamic slice covers a particular execution, not all possible executions or absent requirements.

#### ESME-S044 — View extraction and view fusion in architectural understanding

**Author / body:** Rick Kazman; S. Jeromy Carrière. **Date:** 1998. **Edition:** Original work / author copy as specified.

**Access:** SELECTED_FULL_TEXT_AND_OPENING_FIGURE; 2026-09-06. **Inspected locators:** Opening; View Fusion; How Dali Works; conclusion.

**Exact work:** https://www.sei.cmu.edu/documents/193/1998_019_001_29682.pdf

**Roles:** HISTORICAL_PROVENANCE, IMPLEMENTATION_SEMANTICS, FIELD_OR_DEPLOYMENT_EVIDENCE. **Limits:** Two extended examples and a workbench, not controlled comparative productivity evidence. A fused view is an interpretation, not exhaustive recovered intent.

#### ESME-S045 — Automated testing of refactoring engines

**Author / body:** Brett Daniel; Danny Dig; Kely Garcia; Darko Marinov. **Date:** 2007. **Edition:** Original work / author copy as specified.

**Access:** SELECTED_METHODS_RESULTS_AND_LIMITS; 2026-09-06. **Inspected locators:** Introduction; ASTGen generation/oracles; §5.1 engine evaluation.

**Exact work:** https://dig.cs.illinois.edu/papers/AutomatedTestingOfRefactoringEngines.pdf

**Roles:** EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE, IMPLEMENTATION_SEMANTICS. **Limits:** Bounded generated Java programs and particular tool versions; differential disagreement needs adjudication. No universal rate of unsafe refactorings.

#### ESME-S046 — An empirical study of regression test selection techniques

**Author / body:** Todd L. Graves; Mary Jean Harrold; Jung-Min Kim; Adam Porter; Gregg Rothermel. **Date:** 2001. **Edition:** Original work / author copy as specified.

**Access:** SELECTED_DESIGN_AND_VALIDITY_SECTIONS; 2026-09-06. **Inspected locators:** §3.3.4–§3.3.6 validity: seeded/real faults, programme size and cost measures.

**Exact work:** https://www.cs.umd.edu/users/aporter/Docs/p184-graves.pdf

**Roles:** EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Used primarily for empirical-design limits, not a universal best-technique ranking. Coarse costs and usually single faults limit transfer.

#### ESME-S047 — Prioritizing test cases for regression testing

**Author / body:** Gregg Rothermel; Roland H. Untch; Chengyun Chu; Mary Jean Harrold. **Date:** 2001-10. **Edition:** Original work / author copy as specified.

**Access:** INSTITUTIONAL_ABSTRACT_ONLY; 2026-09-06. **Inspected locators:** Institutional abstract and bibliographic record.

**Exact work:** https://digitalcommons.unl.edu/csearticles/9/

**Roles:** DEFINITION_OR_TAXONOMY, EMPIRICAL_COMPARISON. **Limits:** Full PDF retrieval failed; no detailed sample or statistical result asserted. Reordering can affect early detection without establishing suite adequacy.

#### ESME-S048 — Are mutants a valid substitute for real faults in software testing?

**Author / body:** René Just; Darioush Jalali; Laura Inozemtseva; Michael D. Ernst; Reid Holmes; Gordon Fraser. **Date:** 2014. **Edition:** Original work / author copy as specified.

**Access:** SELECTED_DATASET_METHODS_AND_FIGURES; 2026-09-06. **Inspected locators:** Introduction; §2 real-fault isolation and dataset construction; printed p.656 figures/table.

**Exact work:** https://homes.cs.washington.edu/~mernst/pubs/mutation-effectiveness-fse2014.pdf

**Roles:** EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Mutation is an indirect diagnostic; study population is Java real faults, not every defect or requirement. No perfect adequacy guarantee inferred.

#### ESME-S049 — Online asynchronous schema change in F1

**Author / body:** Ian Rae; Eric Rollins; Jeff Shute; Sukhdeep Sodhi; Radek Vingralek. **Date:** 2013. **Edition:** Original work / author copy as specified.

**Access:** OFFICIAL_AUTHOR_ABSTRACT_ONLY; 2026-09-06. **Inspected locators:** Official abstract: formal model, transition sequence and bounded schema-version skew.

**Exact work:** https://research.google/pubs/online-asynchronous-schema-change-in-f1/

**Roles:** FORMAL_OR_THEORETICAL_RESULT, IMPLEMENTATION_SEMANTICS. **Limits:** Lawful full-copy retrieval failed. Full proof, algorithms and operational evaluation not inspected. Abstract guarantee requires clients at most one schema version behind; not arbitrary mixed-version compatibility.

#### ESME-S050 — Release engineering

**Author / body:** Google SRE authors. **Date:** 2016. **Edition:** Original work / author copy as specified.

**Access:** SELECTED_PRIMARY_CHAPTER_SECTIONS; 2026-09-06. **Inspected locators:** Role of release engineers; philosophy; building reproducible binaries/configurations and coordinating releases.

**Exact work:** https://sre.google/sre-book/release-engineering/

**Roles:** FIELD_OR_DEPLOYMENT_EVIDENCE, IMPLEMENTATION_SEMANTICS. **Limits:** Google-specific operating context, not independent comparative evidence. Release engineering is a documented import/intersection, not the whole maintenance tradition.

#### ESME-S051 — Canarying releases

**Author / body:** Google SRE Workbook authors. **Date:** 2018. **Edition:** Original work / author copy as specified.

**Access:** SELECTED_PRIMARY_CHAPTER_SECTIONS; 2026-09-06. **Inspected locators:** Requirements of a Canary Process; Choosing a Canary Population and Duration; Selecting and Evaluating Metrics; artificial load and traffic teeing limitations.

**Exact work:** https://sre.google/workbook/canarying-releases/

**Roles:** FIELD_OR_DEPLOYMENT_EVIDENCE, CRITICISM_OR_NEGATIVE_EVIDENCE, IMPLEMENTATION_SEMANTICS. **Limits:** Worked application is deliberately contrived; representativeness, attribution and shared failure domains constrain transfer. Canarying does not demonstrate data reversibility.

#### ESME-S052 — An empirical study on reproducible packaging in open-source ecosystems

**Author / body:** Giacomo Benedetti; Oreofe Solarin; Courtney Miller; Greg Tystahl; William Enck; Christian Kästner; Alexandros Kapravelos; Alessio Merlo; Luca Verderame. **Date:** 2025. **Edition:** Original work / author copy as specified.

**Access:** SELECTED_INTRODUCTION_AND_METHOD_LIMITS; 2026-09-06. **Inspected locators:** Introduction; §II.C reproducible-build requirements; §III.E limitations and threats to validity.

**Exact work:** https://www.cs.cmu.edu/~ckaestne/pdf/icse25_rb.pdf; https://doi.org/10.1109/ICSE55347.2025.00136

**Roles:** EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Study isolates package-manager effects under compiler/environment assumptions. Reproducibility does not prove source correctness or absence of malicious source/toolchains.

#### ESME-S053 — The Sunset HTTP Header Field

**Author / body:** Erik Wilde; IETF. **Date:** 2019-05. **Edition:** RFC 8594, Informational.

**Access:** PRIMARY_TEXT_SELECTED_SECTIONS; 2026-09-06. **Inspected locators:** §1.4 deprecation versus decommissioning; §§3–5 field semantics and scope.

**Exact work:** https://www.rfc-editor.org/rfc/rfc8594.html; https://doi.org/10.17487/RFC8594

**Roles:** STANDARD_OR_GUIDANCE_REQUIREMENT, IMPLEMENTATION_SEMANTICS. **Limits:** Informational RFC, not Standards Track. Advertised future unavailability is not evidence that every consumer received notice or can migrate.

#### ESME-S054 — The Deprecation HTTP Response Header Field

**Author / body:** Sanjay Dalal; Erik Wilde; IETF. **Date:** 2025-03. **Edition:** RFC 9745, Standards Track.

**Access:** PRIMARY_TEXT_SELECTED_SECTIONS; 2026-09-06. **Inspected locators:** Opening and field purpose; §7 Security Considerations; relation to Sunset.

**Exact work:** https://www.rfc-editor.org/rfc/rfc9745.html; https://doi.org/10.17487/RFC9745

**Roles:** STANDARD_OR_GUIDANCE_REQUIREMENT, IMPLEMENTATION_SEMANTICS. **Limits:** Standards Track specification, not adoption or benefit evidence. Deprecation signals changed support expectations, not necessarily service shutdown.

#### ESME-S055 — Sustainability and preservation framework

**Author / body:** Software Sustainability Institute / Institute for Research Software. **Date:** UNDATED. **Edition:** Undated web guide as inspected on research cut-off.

**Access:** PRIMARY_GUIDE_TEXT; 2026-09-06. **Inspected locators:** Purpose, horizon, cost, capability and capacity questions; seven preservation/sustainability options.

**Exact work:** https://www.software.ac.uk/guide/sustainability-and-preservation-framework

**Roles:** STANDARD_OR_GUIDANCE_REQUIREMENT, DEFINITION_OR_TAXONOMY. **Limits:** Not an effectiveness trial. The guide uses deprecation for retirement without resuscitation, unlike RFC 9745 signalling semantics; do not equate the two. Publication date not established.

#### ESME-S056 — How to use Software Heritage for archiving and referencing your source code: guidelines and walkthrough

**Author / body:** Roberto Di Cosmo. **Date:** 2019-09-24. **Edition:** arXiv v1.

**Access:** SELECTED_PRIMARY_SECTIONS; 2026-09-06. **Inspected locators:** Introduction; §§1–2 preparing and saving source; archival referencing explanation.

**Exact work:** https://arxiv.org/pdf/1909.10760

**Roles:** IMPLEMENTATION_SEMANTICS, STANDARD_OR_GUIDANCE_REQUIREMENT. **Limits:** 2019 walkthrough is not evidence of current service/version behaviour. Source archival does not itself preserve a runnable environment or operating service.

#### ESME-S057 — Software developer productivity loss due to technical debt—A replication and extension study examining developers’ development work

**Author / body:** Terese Besker; Antonio Martini; Jan Bosch. **Date:** 2019. **Edition:** Original work / author copy as specified.

**Access:** SELECTED_METHODS_REPLICATION_AND_FINDINGS; 2026-09-06. **Inspected locators:** §4.1 study design/training; §4.1.7 replication; reported work-activity comparisons.

**Exact work:** https://research.chalmers.se/publication/511450/file/511450_Fulltext.pdf

**Roles:** FIELD_OR_DEPLOYMENT_EVIDENCE, EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Self-reported debt-attributed time is not a randomised estimate of recoverable savings. Original and replication measures differ; replication authors overlap.

#### ESME-S058 — Reframing technical debt

**Author / body:** Neil Ernst; Paris Avgeriou; Ipek Ozkaya; Heiko Koziolek; Zadia Codabux and Dagstuhl workshop contributors. **Date:** 2025-05-19. **Edition:** arXiv v1; Dagstuhl Perspectives Workshop 24452, held November 2024.

**Access:** PRIMARY_TEXT_SELECTED_SECTIONS; 2026-09-06. **Inspected locators:** §1 inherited 2016 definition; §§2.1–2.3 values/beliefs/principles; §3.1 value creation and uncertainty.

**Exact work:** https://arxiv.org/html/2505.13009v1

**Roles:** HISTORICAL_PROVENANCE, DEFINITION_OR_TAXONOMY, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Manifesto from November 2024 workshop, not a controlled study. Explicitly labelled beliefs and recommended roles are not established causal necessities; placeholder DOI in manuscript not treated as valid identifier.

#### ESME-S059 — What makes a great maintainer of open source projects?

**Author / body:** Edson Dias; Paulo Meirelles; Fernando Castor; Igor Steinmacher; Igor Wiese; Gustavo Pinto. **Date:** 2021. **Edition:** Original work / author copy as specified.

**Access:** INSTITUTIONAL_ABSTRACT_AND_METADATA; 2026-09-06. **Inspected locators:** Abstract: interviews and contributor assessment; communication and technical excellence.

**Exact work:** https://research-portal.uu.nl/en/publications/what-makes-a-great-maintainer-of-open-source-projects/; https://doi.org/10.1109/ICSE43902.2021.00093

**Roles:** FIELD_OR_DEPLOYMENT_EVIDENCE. **Limits:** Full author-copy retrieval failed. Selected successful maintainers and contributor perceptions; not causal proof of universal staffing/role requirements.

#### ESME-S060 — A mixed-methods study of open-source software maintainers on vulnerability management and platform security features

**Author / body:** Jessy Ayala; Yu-Jye Tung; Joshua Garcia. **Date:** 2025-02-03. **Edition:** arXiv v2, 2025-02-03; original submission 2024.

**Access:** SELECTED_METHODS_RESULTS_AND_LIMITS; 2026-09-06. **Inspected locators:** §3 recruitment/analysis/limitations; §5.5 support opportunities; participant setting.

**Exact work:** https://arxiv.org/html/2409.07669v2

**Roles:** FIELD_OR_DEPLOYMENT_EVIDENCE, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** GitHub Advisory Database recruitment selects previously vulnerable projects; demographic/geographic skew. Security is included only where it creates maintenance workload and update obligations.

#### ESME-S061 — Hidden technical debt in machine learning systems

**Author / body:** D. Sculley; Gary Holt; Daniel Golovin; Eugene Davydov; Todd Phillips; Dietmar Ebner; Vinay Chaudhary; Michael Young; Jean-François Crespo; Dan Dennison. **Date:** 2015. **Edition:** Original work / author copy as specified.

**Access:** SELECTED_PRIMARY_SECTIONS; 2026-09-06. **Inspected locators:** §§1–2 debt import and entanglement; §5 system patterns; §6 configuration.

**Exact work:** https://papers.neurips.cc/paper/5656-hidden-technical-debt-in-machine-learning-systems.pdf

**Roles:** HISTORICAL_PROVENANCE, FIELD_OR_DEPLOYMENT_EVIDENCE, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Industrial experience and diagnostic patterns, not universal causal effect sizes. CACE is a warning about coupling, not a theorem that every edit changes every output.

#### ESME-S062 — Postmortem of database outage of January 31

**Author / body:** GitLab. **Date:** 2017-02-10. **Edition:** Original work / author copy as specified.

**Access:** PRIMARY_POSTMORTEM_SELECTED_SECTIONS; 2026-09-06. **Inspected locators:** Broken recovery procedures; actual restore sequence; database-tool mismatch; corrective-action discussion.

**Exact work:** https://about.gitlab.com/blog/postmortem-of-database-outage-of-january-31/

**Roles:** INCIDENT_OR_FAILURE_EVIDENCE, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** One incident, not a failure-rate estimate. Reported planned remediation is not evidence of subsequent completion. GitLab is an external published case, not an inspected user repository.

#### ESME-S063 — Are “solved issues” in SWE-bench really solved correctly? An empirical study

**Author / body:** You Wang; Michael Pradel; Zhongxin Liu. **Date:** 2026. **Edition:** ICSE April 2026; inspected arXiv v2 dated 2025-09-09.

**Access:** SELECTED_METHODS_CORRECTNESS_ADJUDICATION_AND_LIMITS; 2026-09-06. **Inspected locators:** §3 method; §§4.1–4.4 tests, discrepancies and manual correctness; §5.3 threats.

**Exact work:** https://arxiv.org/html/2503.15223v2; https://doi.org/10.1145/3744916.3764576

**Roles:** EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Differential discrepancy is not necessarily incorrectness: most manually sampled suspicious patches remained uncertain. Ground-truth patches and generated tests can themselves be inappropriate.

#### ESME-S064 — PAIChecker: Uncovering and checking PR-issue misalignment in SWE-bench-like benchmarks

**Author / body:** Manyi Wang; Junjielong Xu; Pinjia He. **Date:** 2026-08-04. **Edition:** arXiv v2; original July 2026 submission.

**Access:** SELECTED_DATASET_METHODS_AND_THREATS; 2026-09-06. **Inspected locators:** §2.1 benchmark annotation; misalignment taxonomy; §7 threats.

**Exact work:** https://arxiv.org/html/2607.28587v2

**Roles:** EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE. **Limits:** Preprint; author annotation/LLM checking can err. A proposed checker is not a universal obligation or established independent authority.

#### ESME-S065 — Why SWE-bench Verified no longer measures frontier coding capabilities

**Author / body:** OpenAI. **Date:** 2026-02-23. **Edition:** Original work / author copy as specified.

**Access:** PRIMARY_METHOD_AND_SELECTION_DESCRIPTION; 2026-09-06. **Inspected locators:** Background; selected-task audit; contamination probes and limitations.

**Exact work:** https://openai.com/index/why-we-no-longer-evaluate-swe-bench-verified/

**Roles:** CRITICISM_OR_NEGATIVE_EVIDENCE, EMPIRICAL_COMPARISON. **Limits:** 64-run task selection favours difficult/inconsistent tasks; 59.4% finding concerns 138 selected tasks, not all 500. Model provider interest and gold-informed probes limit generalisation; no complete training-data audit.

#### ESME-S066 — Detecting semantic conflicts with unit tests

**Author / body:** Léuson Da Silva; Paulo Borba; Toni Maciel; Wardah Mahmood; Thorsten Berger; João Moisakis; Aldiberg Gomes; Vinícius Leite. **Date:** 2024. **Edition:** 2024 journal publication; inspected preprint 2023-10-03.

**Access:** SELECTED_METHODS_AND_VALIDITY; COVER_VISUALLY_INSPECTED; 2026-09-06. **Inspected locators:** §4.1 dataset; SAM method outline; §7 threats to validity.

**Exact work:** https://se.rub.de/wp-content/uploads/2023/10/2310.02395.pdf; https://research.chalmers.se/publication/541567

**Roles:** EMPIRICAL_COMPARISON, CRITICISM_OR_NEGATIVE_EVIDENCE, IMPLEMENTATION_SEMANTICS. **Limits:** Authors measure local interference, not full semantic correctness against developer intent. Testability transformations and selected Java projects limit transfer.

#### ESME-S067 — Semantic Versioning 2.0.0

**Author / body:** Semantic Versioning contributors. **Date:** UNDATED. **Edition:** 2.0.0 specification as inspected on research cut-off.

**Access:** PRIMARY_SPECIFICATION_TEXT; 2026-09-06. **Inspected locators:** Introduction; declared public API; major/minor/patch rules.

**Exact work:** https://semver.org/

**Roles:** DEFINITION_OR_TAXONOMY, IMPLEMENTATION_SEMANTICS. **Limits:** Version labels express promises under a declared API; they do not test actual source, binary, behavioural, data or resource compatibility. Web publication date not established.

### Frozen coverage conclusion

All ten mandatory families and all 98 candidates are examined; 32 candidates explicitly carry evidence-access or unresolved-evidence limits. No mandatory family or candidate is `NOT_EXAMINED`. This is bounded critical saturation, not a claim to have retrieved every publication. The eight payloads preserve scope, candidate denominator, criticism, composition and intake interfaces. Packaging verification is recorded separately in the manifest and external receipt and does not purport to validate scholarly conclusions by hashing them.
