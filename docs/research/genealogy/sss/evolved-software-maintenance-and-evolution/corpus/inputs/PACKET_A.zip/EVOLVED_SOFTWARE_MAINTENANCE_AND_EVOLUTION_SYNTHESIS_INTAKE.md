# Evolved Software Maintenance and Evolution — later-synthesis intake

**Lineage:** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION`  
**Revision:** `ESME-R2-2026-09-06`  
**Research cut-off:** 2026-09-06  
**Candidate grouping:** SSS — Software Architecture / Software Maintenance and Evolution / Software Product Line Engineering  
**Lane:** 5.2  
**SIBLING_CORPORA_NOT_CONSULTED**  
**CROSS_TRIFECTA_SYNTHESIS_NOT_PERFORMED**

## Status and authority

This is a complete interface from one independent tradition study. “Evolved” names this study’s analytical composition, not an established historical school. The SSS grouping is provisional and has not been reconciled here. No sibling output or requester repository supplies evidence for this lane. Exported analysis authorises no target mutation, adoption or new organisational authority.

The population is **98 examined candidates** across ten examined mandatory families. **78** are eligible for a conditional crosswalk and **20** remain adverse, superseded, duplicate, contested or unresolved. Six candidates are composition-induced analytical deductions. The source register has **67 exact works/editions**, with access, methodological and dependency limits. The composition model preserves **52 guarded relations**, **nine alternative configurations**, **eight analytical tests**, **22 criticisms**, **16 ceremony-stripping entries** and **eight tensions**.

## Within-tradition synthesis

The purpose is justified continuity under change: establish what should change, what should survive and what may end; acquire enough understanding to bound relevant effects; choose among non-change, repair, transformation, migration and retirement; obtain scoped evidence; and act through actual capability and legitimate authority. Intent, impact, comprehension, tests, runtime effects and lifecycle value can reopen one another. This is a conditional relational system, not a serial development methodology or mandatory union of tools.

Its native objects include change purpose/activity, E-type feedback, comprehension questions, recovered representations, slices, configuration/version spaces, impact dependencies, preservation observers, regression oracles, coexistence states, debt-producing future-work liabilities, maintainer capability, support obligations and archival/retirement consequences. These objects sit at different abstraction levels. A behaviour criterion is not the same kind of thing as a test selector, a compatibility signal, an economic decision or an actor’s permission to act.

Six analytical coupling properties address failure between mechanisms: ESME-093 shared change contract; ESME-094 assumption-sensitive evidence validity; ESME-095 effect-relative returnability frontier; ESME-096 transition termination witness; ESME-097 proportional combined controls; ESME-098 independently warranted oracle revision. Their premises have source support, but the full composed system has no established representative comparative net-benefit result.

## Dependencies and alternatives

Every relation in the composition model identifies FROM/TO property IDs, relation type, guard, shared/incompatible assumptions, coupling mechanism, new cost/failure, sources, evidence status and unresolved obligation. `REQUIRES` points from a claim or mechanism to its necessary obligation under the guard; it is not a mandatory execution ordering. The model preserves `ENABLES`, `CONSTRAINS`, `PROVIDES_EVIDENCE_FOR`, `COMMUNICATES_TO`, `ACTS_THROUGH`, `FEEDBACK_TO`, `ALTERNATIVE_TO`, `CONFLICTS_WITH`, `REFINES`, `SUPERSEDES` and `SHARES_ANCESTRY_WITH` where justified.

Local repair, conservative servicing, formal/automated transformation, incremental migration, atomic migration, supported mixed versions, emergency containment, retirement/preservation and stable useful non-change are not simultaneous requirements. Choose the relevant configuration and its omissions using the recorded guards. Do not create one new owner, document or control per property. Shared realisation is compatible with preserved distinct criteria and genealogy.

## Questions for Software Architecture — not answers for an unread lane

How do architecture decisions, constraints and views from that independently researched corpus relate to maintenance’s recovered views and actual effect dependencies? Are two apparently equivalent views based on the same observer, support scope and environment, or does one describe design intention while the other describes current implementation? Which change scenarios and empirical feedback legitimately reopen an architecture decision? Can an existing architecture mechanism supply the evidence required by ESME-021/025/028/050 without redundant control, and what remains unknown if it cannot?

The documented intersections here are reverse/design recovery, DALI view fusion, API evolution, configuration management and lifecycle debt. These sources justify reconciliation questions, not claims about the sibling’s conclusions. [ESME-S014, ESME-S019, ESME-S021, ESME-S044, ESME-S058.]

## Questions for Software Product Line Engineering — not answers for an unread lane

How do the sibling’s variation and configuration concepts relate to this lane’s native supported-version/configuration obligations? Which preservation and regression requirements are shared across variants, and which are irreducibly variant-specific? When does family-level evidence justify reuse, and when do configuration, data or deployment differences invalidate it? How should variant retirement and mixed-version migration transfer support obligations without pretending every theoretical configuration is supported?

Buckley’s evolution dimensions, SCM product/configuration spaces and bounded mixed-version schema reasoning supply this lane’s documented intersection. They do not establish the product-line tradition’s history or preferred mechanisms. Preserve variation-related complexity when it serves legitimate supported differences; do not label all such complexity debt. [ESME-S005, ESME-S019, ESME-S041, ESME-S049; ESME-092.]

## Later reconciliation tests

Test **semantic equivalence** by protected failure, observer, trigger and postcondition, not common wording. Test **complementarity** by whether one mechanism produces evidence or capability another actually consumes. Test **redundancy/substitution** by whether a cheaper shared mechanism establishes both criteria without losing scope. Test **abstraction level** before treating a value, criterion, operating method and governance permission as interchangeable. Test **incompatible assumptions** explicitly, including closed/open consumer populations, supported version skew, deterministic/learned components and different time horizons.

Preserve shared sources, datasets and industrial programmes so repeated citation does not become replication. Test whether the combined traditions create **new obligations** at their interfaces, such as stale evidence, conflicting acceptance criteria, unowned consumer transitions or unjustified duplicated controls. New claims need their own IDs/evidence status in a later synthesis; do not silently attribute them to a source tradition. Selection, substitution, omission and retirement require reasons, not monotonically adding controls.

## Global-key exports and frozen accounting

The complete machine-readable export is `synthesis_exports` in `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_COMPOSITION_MODEL.json`. The entries below are its human-readable interface. Each global key is unique and retains the original disposition, source IDs, assumptions and limits. Non-active entries remain included for denominator preservation and criticism, not adoption. Later crosswalks must retain `GLOBAL_KEY` and create separate target/synthesis decisions rather than rewriting the frozen record.

| Disposition | Count |
| --- | --- |
| ASSUMPTION_SENSITIVE | 7 |
| CEREMONY_NOT_GENERAL_PROPERTY | 1 |
| CONTESTED | 1 |
| CONTEXT_DEPENDENT | 16 |
| DOMAIN_SPECIFIC | 5 |
| DUPLICATE_CANDIDATE | 1 |
| REJECTED_OR_DISFAVOURED | 15 |
| RETAINED_IN_EVOLVED_FORM | 31 |
| STRONGLY_RETAINED | 15 |
| SUPERSEDED_BY_STRONGER_FORM | 1 |
| UNRESOLVED | 1 |
| USEFUL_BUT_EASILY_BUREAUCRATISED | 2 |
| USEFUL_BUT_EASILY_GAMED | 2 |

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-001 — Explicit change objective and authorised obligation revision

**Disposition.** STRONGLY_RETAINED

**Kind.** CRITERION_COUPLED_TO_DECISION

**Criterion.** An authorised change objective and explicit preserved or revised obligations can be compared with the actual result.

**Operating mechanism.** State the intended difference, affected obligations, legitimate decision maker and acceptance question before endorsing an intervention.

**Trigger.** A request, discovered defect or environmental pressure proposes changing an existing commitment.

**Inputs.** Baseline artefacts: Change request, affected behaviour and requirements history. Requests, contracts, code, data, configuration, manuals and maintenance readiness can all be affected.; Preconditions: Conditions: Decision authority and domain meaning must be established; disputed intent cannot be resolved by test count.; Related property ids: ESME-035; ESME-063; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A request, discovered defect or environmental pressure proposes changing an existing commitment. Identify whose intended result is changing and distinguish corrective, adaptive, perfective, preventive, additive and emergency dimensions without forcing exclusivity.

**Produced constraints or evidence.** An authorised change objective and explicit preserved or revised obligations can be compared with the actual result.

**Consumer.** Consumer: Those entitled to request or rely on the behaviour, not merely the test author.; Decision: An authorised change objective and explicit preserved or revised obligations can be compared with the actual result.

**Costs and possible harm.** Source-supported: issue/PR/test disagreement can leave correctness indeterminate. Analytical: a formal approval can still exclude affected people.

**Assumptions.** Critical assumption: Decision authority and domain meaning must be established; disputed intent cannot be resolved by test count.; Discriminating question: Which affected stakeholder is missing from the stated acceptance question?

**Cheap path / omission.** A short accepted issue with concrete examples is enough for a bounded low-risk change; reject or defer an unjustified request.

**Retirement.** A short accepted issue with concrete examples is enough for a bounded low-risk change; reject or defer an unjustified request. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T01; Discriminator: Identify the actual obligation, consumer and authorisation for revision; unresolved authority blocks that revision, not unrelated work.; Hybrid failure: Two ambiguous meanings, unmaintained compatibility mode, or an oracle changed solely to pass.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R001, ESME-R003, ESME-R022, ESME-R026, ESME-R029, ESME-R030, ESME-R035, ESME-R037

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Decision authority and domain meaning must be established; disputed intent cannot be resolved by test count. Which affected stakeholder is missing from the stated acceptance question? **Source IDs:** ESME-S001, ESME-S004, ESME-S041, ESME-S025, ESME-S063, ESME-S064.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-002 — Purpose-and-activity classification without false exclusivity

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** MODELLING_CRITERION

**Criterion.** A mixed change can be described without hiding one purpose or treating a statistic from another taxonomy as comparable.

**Operating mechanism.** Use purpose labels alongside observable activity and artefact scope, permitting multiple purposes; include additive and emergency distinctions when using the 2022 terminology.

**Trigger.** Classification affects estimates, authorisation, reporting or selection of maintenance evidence.

**Inputs.** Baseline artefacts: Request intent and actual changed artefacts. Requests, contracts, code, data, configuration, manuals and maintenance readiness can all be affected.; Preconditions: Conditions: The taxonomy edition, unit and use must be declared.; Related property ids: ESME-001; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Classification affects estimates, authorisation, reporting or selection of maintenance evidence. Identify whose intended result is changing and distinguish corrective, adaptive, perfective, preventive, additive and emergency dimensions without forcing exclusivity.

**Produced constraints or evidence.** A mixed change can be described without hiding one purpose or treating a statistic from another taxonomy as comparable.

**Consumer.** Consumer: Request owner for intention; analyst for observed activities.; Decision: A mixed change can be described without hiding one purpose or treating a statistic from another taxonomy as comparable.

**Costs and possible harm.** Source-supported: survey and measured activity distributions differ; categories are not interchangeable.

**Assumptions.** Critical assumption: The taxonomy edition, unit and use must be declared.; Discriminating question: Does this classification change a decision, and are compared measurements commensurable?

**Cheap path / omission.** Do not label every commit when the label changes no decision; one explanatory sentence may suffice.

**Retirement.** Do not label every commit when the label changes no decision; one explanatory sentence may suffice. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R001, ESME-R036

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. The taxonomy edition, unit and use must be declared. Does this classification change a decision, and are compared measurements commensurable? **Source IDs:** ESME-S001, ESME-S004, ESME-S005, ESME-S041, ESME-S007.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-003 — Maintenance includes non-code artefacts and readiness

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** SCOPE_CRITERION

**Criterion.** Necessary non-code changes and readiness dependencies are included in scope and assigned a consumer.

**Operating mechanism.** Include the artefacts and pre-delivery arrangements required to maintain an existing capability: build, configuration, data, documentation and transition knowledge.

**Trigger.** A future or current maintenance task depends on non-code state or transfer readiness.

**Inputs.** Baseline artefacts: Code, build inputs, schemas, configurations, operational instructions and handover material. Requests, contracts, code, data, configuration, manuals and maintenance readiness can all be affected.; Preconditions: Conditions: Artefact relevance must be tied to a concrete maintenance obligation.; Related property ids: ESME-004; ESME-021; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A future or current maintenance task depends on non-code state or transfer readiness. Identify whose intended result is changing and distinguish corrective, adaptive, perfective, preventive, additive and emergency dimensions without forcing exclusivity.

**Produced constraints or evidence.** Necessary non-code changes and readiness dependencies are included in scope and assigned a consumer.

**Consumer.** Consumer: Maintainer, operator and downstream consumer of the actual artefact.; Decision: Necessary non-code changes and readiness dependencies are included in scope and assigned a consumer.

**Costs and possible harm.** Source-supported: omitted non-code dependencies can break test selection; ML configuration can carry substantial system logic.

**Assumptions.** Critical assumption: Artefact relevance must be tied to a concrete maintenance obligation.; Discriminating question: What relevant non-code state is currently outside the impact account?

**Cheap path / omission.** Exclude irrelevant artefacts explicitly rather than constructing an organisation-wide inventory for a local task.

**Retirement.** Exclude irrelevant artefacts explicitly rather than constructing an organisation-wide inventory for a local task. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R001

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Artefact relevance must be tied to a concrete maintenance obligation. What relevant non-code state is currently outside the impact account? **Source IDs:** ESME-S001, ESME-S006, ESME-S041, ESME-S024, ESME-S061.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-004 — Recoverable and identifiable configuration baseline

**Disposition.** STRONGLY_RETAINED

**Kind.** OPERATING_MECHANISM

**Criterion.** Another authorised maintainer can locate the baseline and reproduce the relevant comparison; restoration is separately tested.

**Operating mechanism.** Identify and retain the exact baseline and configuration needed to interpret, build, compare or restore the changed system.

**Trigger.** An intervention or investigation requires attributing differences or returning to a known state.

**Inputs.** Baseline artefacts: Source revision, build inputs, package versions, configuration and relevant data-state reference. Requests, contracts, code, data, configuration, manuals and maintenance readiness can all be affected.; Preconditions: Conditions: Referenced artefacts remain accessible and configuration identifiers resolve.; Related property ids: ESME-041; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: An intervention or investigation requires attributing differences or returning to a known state. Identify whose intended result is changing and distinguish corrective, adaptive, perfective, preventive, additive and emergency dimensions without forcing exclusivity.

**Produced constraints or evidence.** Another authorised maintainer can locate the baseline and reproduce the relevant comparison; restoration is separately tested.

**Consumer.** Consumer: Reviewer and operator comparing the same system, not merely matching a branch name.; Decision: Another authorised maintainer can locate the baseline and reproduce the relevant comparison; restoration is separately tested.

**Costs and possible harm.** Source-supported: source identity alone does not guarantee reproducible packaging or usable backups.

**Assumptions.** Critical assumption: Referenced artefacts remain accessible and configuration identifiers resolve.; Discriminating question: Which mutable or external input prevents the baseline from denoting one relevant state?

**Cheap path / omission.** A versioned file and recorded command can suffice for a local deterministic artefact; retain richer dependencies only where needed.

**Retirement.** A versioned file and recorded command can suffice for a local deterministic artefact; retain richer dependencies only where needed. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T08; Discriminator: Ask what future consumer must actually be able to do: retrieve, interpret, execute or receive service.; Hybrid failure: An archive is advertised as runnable despite missing dependencies, or an obsolete service is kept live without a support purpose.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R002, ESME-R021, ESME-R030, ESME-R031

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Referenced artefacts remain accessible and configuration identifiers resolve. Which mutable or external input prevents the baseline from denoting one relevant state? **Source IDs:** ESME-S019, ESME-S041, ESME-S050, ESME-S052, ESME-S062.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-005 — Emergency stabilisation separated from permanent repair

**Disposition.** CONTEXT_DEPENDENT

**Kind.** OPERATING_BRANCH

**Criterion.** Temporary degradation and its accepted scope are visible, with a named follow-up decision rather than presumed final correctness.

**Operating mechanism.** Authorise a bounded containment objective, record intentionally lost behaviour and establish review or expiry conditions for the temporary state.

**Trigger.** Continuing the current fault causes greater immediate harm than a controlled degraded state.

**Inputs.** Baseline artefacts: Live service, temporary configuration or patch and follow-up obligation. Requests, contracts, code, data, configuration, manuals and maintenance readiness can all be affected.; Preconditions: Conditions: Containment scope, operational capability and recovery or follow-up must be credible.; Related property ids: ESME-001; ESME-044; ESME-089; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Continuing the current fault causes greater immediate harm than a controlled degraded state. Identify whose intended result is changing and distinguish corrective, adaptive, perfective, preventive, additive and emergency dimensions without forcing exclusivity.

**Produced constraints or evidence.** Temporary degradation and its accepted scope are visible, with a named follow-up decision rather than presumed final correctness.

**Consumer.** Consumer: Affected users and the person authorised to accept temporary degradation.; Decision: Temporary degradation and its accepted scope are visible, with a named follow-up decision rather than presumed final correctness.

**Costs and possible harm.** Source-supported: deletion patches can pass weak tests. Analytical: an emergency label can launder permanent feature removal.

**Assumptions.** Critical assumption: Containment scope, operational capability and recovery or follow-up must be credible.; Discriminating question: What event ends the emergency exception, and who accepts residual loss?

**Cheap path / omission.** Use normal repair when delay is tolerable; do not invent an emergency fast lane for ordinary convenience.

**Retirement.** Use normal repair when delay is tolerable; do not invent an emergency fast lane for ordinary convenience. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R029

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Containment scope, operational capability and recovery or follow-up must be credible. What event ends the emergency exception, and who accepts residual loss? **Source IDs:** ESME-S001, ESME-S041, ESME-S034, ESME-S062.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-006 — Four categories as a universally exhaustive taxonomy

**Disposition.** SUPERSEDED_BY_STRONGER_FORM

**Kind.** REJECTED_EXHAUSTIVENESS_CLAIM

**Criterion.** Rejection is observable when mixed purposes or additive/emergency dimensions remain representable rather than forced away.

**Operating mechanism.** Candidate proposes requiring every maintenance activity to fit exactly one of four boxes.

**Trigger.** An audit or metric system attempts to treat four labels as exhaustive and exclusive.

**Inputs.** Baseline artefacts: Classified requests and activity statistics. Requests, contracts, code, data, configuration, manuals and maintenance readiness can all be affected.; Preconditions: Conditions: Exhaustiveness would require showing no meaningful omitted or mixed classes; evidence does not support this.; Related property ids: ESME-002; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: An audit or metric system attempts to treat four labels as exhaustive and exclusive. Identify whose intended result is changing and distinguish corrective, adaptive, perfective, preventive, additive and emergency dimensions without forcing exclusivity.

**Produced constraints or evidence.** Rejection is observable when mixed purposes or additive/emergency dimensions remain representable rather than forced away.

**Consumer.** Consumer: The analyst using the categories to make comparisons.; Decision: Rejection is observable when mixed purposes or additive/emergency dimensions remain representable rather than forced away.

**Costs and possible harm.** Source-supported: ISO 2022 additive maintenance and alternative activity taxonomies defeat the universal claim.

**Assumptions.** Critical assumption: Exhaustiveness would require showing no meaningful omitted or mixed classes; evidence does not support this.; Discriminating question: Is a reported distribution really based on the same taxonomy and unit?

**Cheap path / omission.** Use ESME-002 and declare the edition and classification purpose.

**Retirement.** Use ESME-002 and declare the edition and classification purpose. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R036

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Exhaustiveness would require showing no meaningful omitted or mixed classes; evidence does not support this. Is a reported distribution really based on the same taxonomy and unit? **Source IDs:** ESME-S003, ESME-S006, ESME-S041, ESME-S001, ESME-S004, ESME-S005.

**Selection restriction.** SUPERSEDED_BY_STRONGER_FORM: Superseded by multidimensional, edition-aware classification; historical four-term usage remains legitimate within a declared scope. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-007 — Environment-relative usefulness feedback

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** FEEDBACK_MECHANISM

**Criterion.** An identified change in environmental fit has a reasoned response, which may be no change.

**Operating mechanism.** Observe changes in use, expectations and constraints; decide whether adaptation, servicing, unchanged operation or retirement best preserves justified usefulness.

**Trigger.** Evidence of changed environment, user dissatisfaction or new constraints, not age alone.

**Inputs.** Baseline artefacts: System-environment relationship and observed user outcomes. Fix the sampled release stream, artefact boundary, organisation and time unit before interpreting a trajectory.; Preconditions: Conditions: Environmental observations must be relevant and not just proxy growth metrics.; Related property ids: ESME-001; ESME-074; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Evidence of changed environment, user dissatisfaction or new constraints, not age alone. Study environmental fit, complexity, familiarity and change rate; do not infer a mandate to grow from an observed growth curve.

**Produced constraints or evidence.** An identified change in environmental fit has a reasoned response, which may be no change.

**Consumer.** Consumer: Users and stakeholders whose activity the software serves.; Decision: An identified change in environmental fit has a reasoned response, which may be no change.

**Costs and possible harm.** Source-supported: empirical growth trajectories vary. Analytical: demand for more features is not automatically legitimate value.

**Assumptions.** Critical assumption: Environmental observations must be relevant and not just proxy growth metrics.; Discriminating question: What observation would show that unchanged operation remains adequate?

**Cheap path / omission.** For a stable environment, use occasional review or existing user feedback rather than continuous change.

**Retirement.** For a stable environment, use occasional review or existing user feedback rather than continuous change. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R003, ESME-R038

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Environmental observations must be relevant and not just proxy growth metrics. What observation would show that unchanged operation remains adequate? **Source IDs:** ESME-S008, ESME-S009, ESME-S010, ESME-S011, ESME-S012.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-008 — Universal growth and inevitable deterioration

**Disposition.** REJECTED_OR_DISFAVOURED

**Kind.** UNIVERSAL_HISTORICAL_OVERGENERALISATION

**Criterion.** A decision does not mandate growth or replacement solely from age.

**Operating mechanism.** Candidate treats chronological age or lack of feature growth as sufficient grounds for intervention.

**Trigger.** Someone invokes an evolution law without identifying system class, measure or environment.

**Inputs.** Baseline artefacts: Release histories and environmental conditions. Fix the sampled release stream, artefact boundary, organisation and time unit before interpreting a trajectory.; Preconditions: Conditions: Universal inevitability is not established by the studied populations.; Related property ids: ESME-007; ESME-009; ESME-074; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Someone invokes an evolution law without identifying system class, measure or environment. Study environmental fit, complexity, familiarity and change rate; do not infer a mandate to grow from an observed growth curve.

**Produced constraints or evidence.** A decision does not mandate growth or replacement solely from age.

**Consumer.** Consumer: Actual users, not an age or LOC threshold.; Decision: A decision does not mandate growth or replacement solely from age.

**Costs and possible harm.** Source-supported: population and release-stream results vary. Analytical: stable specified computations need not gain features to remain useful.

**Assumptions.** Critical assumption: Universal inevitability is not established by the studied populations.; Discriminating question: Which premise connects the cited law to this system’s current obligation?

**Cheap path / omission.** Assess actual usefulness and obligations through ESME-007 instead.

**Retirement.** Assess actual usefulness and obligations through ESME-007 instead. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R038

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Universal inevitability is not established by the studied populations. Which premise connects the cited law to this system’s current obligation? **Source IDs:** ESME-S008, ESME-S009, ESME-S010, ESME-S011, ESME-S012, ESME-S013.

**Selection restriction.** REJECTED_OR_DISFAVOURED: Reject universality, preserve scope-conditioned empirical questions. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-009 — Population- and metric-conditioned evolution claims

**Disposition.** STRONGLY_RETAINED

**Kind.** EVIDENCE_CRITERION

**Criterion.** The claim states its population and measure, and contrary samples remain visible.

**Operating mechanism.** Bind an evolution claim to system population, stable/development stream, measured unit and environmental context; compare unlike studies only after reconciling these.

**Trigger.** Growth, complexity, effort or decline measurements guide investment or generalisation.

**Inputs.** Baseline artefacts: Release sample, size/function/effort measures and data-extraction rules. Fix the sampled release stream, artefact boundary, organisation and time unit before interpreting a trajectory.; Preconditions: Conditions: Consistent measurement and a declared transfer population.; Related property ids: ESME-007; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Growth, complexity, effort or decline measurements guide investment or generalisation. Study environmental fit, complexity, familiarity and change rate; do not infer a mandate to grow from an observed growth curve.

**Produced constraints or evidence.** The claim states its population and measure, and contrary samples remain visible.

**Consumer.** Consumer: Analyst and decision maker interpreting the metric.; Decision: The claim states its population and measure, and contrary samples remain visible.

**Costs and possible harm.** Source-supported: Linux growth interpretation changes with release/artefact selection; survey versus measured categories differ.

**Assumptions.** Critical assumption: Consistent measurement and a declared transfer population.; Discriminating question: Would a different legitimate sampling rule reverse the conclusion?

**Cheap path / omission.** Use a simple trend with explicit units when it directly answers the decision; no statistical model is mandatory.

**Retirement.** Use a simple trend with explicit units when it directly answers the decision; no statistical model is mandatory. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R003, ESME-R038

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Consistent measurement and a declared transfer population. Would a different legitimate sampling rule reverse the conclusion? **Source IDs:** ESME-S008, ESME-S010, ESME-S011, ESME-S012, ESME-S007.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-010 — Familiarity and capacity as feedback constraints

**Disposition.** ASSUMPTION_SENSITIVE

**Kind.** ORGANISATIONAL_FEEDBACK_HYPOTHESIS

**Criterion.** The selected workload can be understood and supported by available people, with bottlenecks made explicit.

**Operating mechanism.** Use observed comprehension, review and recovery demand to constrain change intake and invest in knowledge when understanding becomes a bottleneck.

**Trigger.** Change volume or personnel turnover outpaces demonstrated ability to understand and maintain obligations.

**Inputs.** Baseline artefacts: Maintainer knowledge, workload, change volume and review outcomes. Fix the sampled release stream, artefact boundary, organisation and time unit before interpreting a trajectory.; Preconditions: Conditions: Workload signals must distinguish familiarity from tooling, task complexity and organisational restrictions.; Related property ids: ESME-012; ESME-064; ESME-066; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Change volume or personnel turnover outpaces demonstrated ability to understand and maintain obligations. Study environmental fit, complexity, familiarity and change rate; do not infer a mandate to grow from an observed growth curve.

**Produced constraints or evidence.** The selected workload can be understood and supported by available people, with bottlenecks made explicit.

**Consumer.** Consumer: Maintainers and those allocating time, not a fixed universal staffing formula.; Decision: The selected workload can be understood and supported by available people, with bottlenecks made explicit.

**Costs and possible harm.** Source-supported: comprehension consumes substantial observed time but is not one universal proportion; AI time effects vary by setting.

**Assumptions.** Critical assumption: Workload signals must distinguish familiarity from tooling, task complexity and organisational restrictions.; Discriminating question: Is apparent capacity loss caused by missing knowledge or by another constraint?

**Cheap path / omission.** A small expert-maintained component may need only a direct conversation and modest change cadence.

**Retirement.** A small expert-maintained component may need only a direct conversation and modest change cadence. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T02; Discriminator: Compare demonstrated next-change capability and total transition cost, not complexity score alone.; Hybrid failure: Long-lived mixed styles and half-transferred knowledge make both old and new harder to understand.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R003, ESME-R038

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Workload signals must distinguish familiarity from tooling, task complexity and organisational restrictions. Is apparent capacity loss caused by missing knowledge or by another constraint? **Source IDs:** ESME-S010, ESME-S013, ESME-S016, ESME-S018, ESME-S036, ESME-S037.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-011 — Invariant organisational work rate as a planning law

**Disposition.** REJECTED_OR_DISFAVOURED

**Kind.** UNIVERSAL_RATE_CLAIM

**Criterion.** Forecasts retain uncertainty and do not treat changed conditions as impossible by definition.

**Operating mechanism.** Candidate fixes staffing, effort or delivery-rate predictions as invariant across organisations and tool/environment changes.

**Trigger.** A plan invokes a universal rate to dismiss changed capability or demand.

**Inputs.** Baseline artefacts: Historical effort and release-rate observations. Fix the sampled release stream, artefact boundary, organisation and time unit before interpreting a trajectory.; Preconditions: Conditions: The extrapolation would require stable organisation, measurement and environment not demonstrated here.; Related property ids: ESME-009; ESME-010; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A plan invokes a universal rate to dismiss changed capability or demand. Study environmental fit, complexity, familiarity and change rate; do not infer a mandate to grow from an observed growth curve.

**Produced constraints or evidence.** Forecasts retain uncertainty and do not treat changed conditions as impossible by definition.

**Consumer.** Consumer: Those planning support and change commitments.; Decision: Forecasts retain uncertainty and do not treat changed conditions as impossible by definition.

**Costs and possible harm.** Source-supported: heterogeneous evolution studies and version-specific work experiments undermine unqualified transfer, not the original conditional observation.

**Assumptions.** Critical assumption: The extrapolation would require stable organisation, measurement and environment not demonstrated here.; Discriminating question: Which changed organisational or technical condition invalidates the extrapolation?

**Cheap path / omission.** Measure local capacity and uncertainty using ESME-010.

**Retirement.** Measure local capacity and uncertainty using ESME-010. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R038

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. The extrapolation would require stable organisation, measurement and environment not demonstrated here. Which changed organisational or technical condition invalidates the extrapolation? **Source IDs:** ESME-S008, ESME-S010, ESME-S011, ESME-S012, ESME-S036, ESME-S037.

**Selection restriction.** REJECTED_OR_DISFAVOURED: Reject universal prescription while preserving local longitudinal investigation. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-012 — Bounded change-specific comprehension

**Disposition.** STRONGLY_RETAINED

**Kind.** INQUIRY_MECHANISM

**Criterion.** The maintainer can answer the consequential change questions and state remaining uncertainty.

**Operating mechanism.** Establish enough understanding to discriminate the pending change decision; expand inquiry when observed contradictions or impact escape invalidate that boundary.

**Trigger.** A maintainer cannot explain the relevant effect or uncertainty of a proposed intervention.

**Inputs.** Baseline artefacts: The affected feature and evidence needed for the current decision. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.; Preconditions: Conditions: The pending decision and consequential unknowns must be stated.; Related property ids: ESME-001; ESME-021; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A maintainer cannot explain the relevant effect or uncertainty of a proposed intervention. Select the question needed for a proposed change, diagnosis or handover rather than presupposing whole-system understanding.

**Produced constraints or evidence.** The maintainer can answer the consequential change questions and state remaining uncertainty.

**Consumer.** Consumer: Maintainer and reviewer who must act, with domain experts where intent is lost.; Decision: The maintainer can answer the consequential change questions and state remaining uncertainty.

**Costs and possible harm.** Source-supported: slices and traces omit different things; documentation alone cannot replace all tacit knowledge.

**Assumptions.** Critical assumption: The pending decision and consequential unknowns must be stated.; Discriminating question: Which unanswered question could actually alter the next decision?

**Cheap path / omission.** Inspect the relevant code, test and domain example directly for a small familiar change; avoid mandatory reconstruction of everything.

**Retirement.** Inspect the relevant code, test and domain example directly for a small familiar change; avoid mandatory reconstruction of everything. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T02; Discriminator: Compare demonstrated next-change capability and total transition cost, not complexity score alone.; Hybrid failure: Long-lived mixed styles and half-transferred knowledge make both old and new harder to understand.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R001, ESME-R002, ESME-R004, ESME-R006, ESME-R022, ESME-R023, ESME-R034, ESME-R039

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. The pending decision and consequential unknowns must be stated. Which unanswered question could actually alter the next decision? **Source IDs:** ESME-S014, ESME-S016, ESME-S017, ESME-S018, ESME-S015, ESME-S043.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-013 — Criterion-relative conservative static slicing

**Disposition.** ASSUMPTION_SENSITIVE

**Kind.** FORMAL_ANALYSIS_MECHANISM

**Criterion.** The slice is traceable to its criterion and conservative assumptions; unknown constructs remain visible.

**Operating mechanism.** Choose a slicing criterion and use sound dependency analysis to conservatively identify relevant statements, documenting unsupported constructs.

**Trigger.** A data/control relevance question can be expressed in the supported program model.

**Inputs.** Baseline artefacts: Program statements, variable criterion and control/data dependencies. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.; Preconditions: Conditions: Sound dependencies and supported semantics; minimal arbitrary slices are not computable in general.; Related property ids: ESME-012; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A data/control relevance question can be expressed in the supported program model. Select the question needed for a proposed change, diagnosis or handover rather than presupposing whole-system understanding.

**Produced constraints or evidence.** The slice is traceable to its criterion and conservative assumptions; unknown constructs remain visible.

**Consumer.** Consumer: The observation specified by the slicing criterion, not every external effect.; Decision: The slice is traceable to its criterion and conservative assumptions; unknown constructs remain visible.

**Costs and possible harm.** Source-supported: minimality limits and large slices; student-scale evidence does not establish industrial productivity.

**Assumptions.** Critical assumption: Sound dependencies and supported semantics; minimal arbitrary slices are not computable in general.; Discriminating question: Which unsupported dependency could invalidate the slice’s claimed preservation?

**Cheap path / omission.** Manual inspection or a small dependency query may dominate building a slicer.

**Retirement.** Manual inspection or a small dependency query may dominate building a slicer. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R004, ESME-R005, ESME-R051

**Evidence boundary.** FORMAL_SCOPE_BOUND: source-supported model/guarantee and assumptions recorded in source table; no independent re-proof or unbounded deployment guarantee. Sound dependencies and supported semantics; minimal arbitrary slices are not computable in general. Which unsupported dependency could invalidate the slice’s claimed preservation? **Source IDs:** ESME-S015, ESME-S043.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-014 — Execution-relative dynamic observation and slicing

**Disposition.** CONTEXT_DEPENDENT

**Kind.** OBSERVATION_MECHANISM

**Criterion.** A claim identifies the executions observed and the neighbouring cases still unobserved.

**Operating mechanism.** Record the input, environment and trace boundary, then use execution evidence to investigate the specific effect without treating unexecuted behaviour as absent.

**Trigger.** Static uncertainty, dynamic dispatch or a reproducible failure makes execution evidence discriminating.

**Inputs.** Baseline artefacts: Trace, instrumentation, inputs and runtime configuration. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.; Preconditions: Conditions: Reproducible or adequately characterised execution; instrumentation does not conceal or change the critical effect.; Related property ids: ESME-012; ESME-013; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Static uncertainty, dynamic dispatch or a reproducible failure makes execution evidence discriminating. Select the question needed for a proposed change, diagnosis or handover rather than presupposing whole-system understanding.

**Produced constraints or evidence.** A claim identifies the executions observed and the neighbouring cases still unobserved.

**Consumer.** Consumer: The observed run and selected values/events.; Decision: A claim identifies the executions observed and the neighbouring cases still unobserved.

**Costs and possible harm.** Source-supported: dynamic graphs can be costly; particular runs cannot establish all-input behaviour.

**Assumptions.** Critical assumption: Reproducible or adequately characterised execution; instrumentation does not conceal or change the critical effect.; Discriminating question: What unobserved execution would falsify the present explanation?

**Cheap path / omission.** A debugger or targeted log can suffice; do not collect exhaustive production traces without need.

**Retirement.** A debugger or targeted log can suffice; do not collect exhaustive production traces without need. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R004, ESME-R005, ESME-R051

**Evidence boundary.** FORMAL_SCOPE_BOUND: source-supported model/guarantee and assumptions recorded in source table; no independent re-proof or unbounded deployment guarantee. Reproducible or adequately characterised execution; instrumentation does not conceal or change the critical effect. What unobserved execution would falsify the present explanation? **Source IDs:** ESME-S043, ESME-S044, ESME-S015, ESME-S025.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-015 — Design recovery includes domain and human knowledge

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** RECOVERY_MECHANISM

**Criterion.** The recovered explanation supports a concrete maintenance decision and identifies uncertain or contested intent.

**Operating mechanism.** Recover the rationale and abstractions needed for the change by checking code/behaviour against knowledgeable people and domain evidence.

**Trigger.** Undocumented behaviour or lost intent makes structural reconstruction insufficient.

**Inputs.** Baseline artefacts: Implementation, domain rules, historical decisions and tacit operational knowledge. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.; Preconditions: Conditions: Knowledge claims must be checked against current obligations and observable behaviour.; Related property ids: ESME-001; ESME-012; ESME-063; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Undocumented behaviour or lost intent makes structural reconstruction insufficient. Select the question needed for a proposed change, diagnosis or handover rather than presupposing whole-system understanding.

**Produced constraints or evidence.** The recovered explanation supports a concrete maintenance decision and identifies uncertain or contested intent.

**Consumer.** Consumer: Domain expert and successor maintainer, not solely the analysis tool.; Decision: The recovered explanation supports a concrete maintenance decision and identifies uncertain or contested intent.

**Costs and possible harm.** Source-supported: transfer experiences show knowledge is not exhausted by documents. Analytical: expert memory can also be wrong.

**Assumptions.** Critical assumption: Knowledge claims must be checked against current obligations and observable behaviour.; Discriminating question: What independent observation could contradict the recovered rationale?

**Cheap path / omission.** Ask a knowledgeable maintainer a focused question rather than commissioning a comprehensive recovery model.

**Retirement.** Ask a knowledgeable maintainer a focused question rather than commissioning a comprehensive recovery model. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T02; Discriminator: Compare demonstrated next-change capability and total transition cost, not complexity score alone.; Hybrid failure: Long-lived mixed styles and half-transferred knowledge make both old and new harder to understand.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R004, ESME-R005, ESME-R023, ESME-R039, ESME-R047, ESME-R050

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Knowledge claims must be checked against current obligations and observable behaviour. What independent observation could contradict the recovered rationale? **Source IDs:** ESME-S014, ESME-S016, ESME-S044, ESME-S017.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-016 — Faithful redocumentation with an actual consumer

**Disposition.** USEFUL_BUT_EASILY_BUREAUCRATISED

**Kind.** COMMUNICATION_MECHANISM

**Criterion.** A consumer can use the description to perform the intended task; its version and limits are visible.

**Operating mechanism.** Produce or refresh a description only when a maintainer or downstream consumer needs it, and check it against the current subject.

**Trigger.** A useful explanation is missing, stale or inaccessible to an actual consumer.

**Inputs.** Baseline artefacts: Documentation and its source artefact/version. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.; Preconditions: Conditions: A resolvable source baseline and a way to detect stale statements.; Related property ids: ESME-004; ESME-012; ESME-063; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A useful explanation is missing, stale or inaccessible to an actual consumer. Select the question needed for a proposed change, diagnosis or handover rather than presupposing whole-system understanding.

**Produced constraints or evidence.** A consumer can use the description to perform the intended task; its version and limits are visible.

**Consumer.** Consumer: The intended reader performing a named maintenance or operational task.; Decision: A consumer can use the description to perform the intended task; its version and limits are visible.

**Costs and possible harm.** Source-supported: documentation does not encompass all expertise; comprehensive registers can become bureaucracy.

**Assumptions.** Critical assumption: A resolvable source baseline and a way to detect stale statements.; Discriminating question: Who uses this description, and what would fail if it were omitted?

**Cheap path / omission.** A checked example, code comment or targeted note can replace a large document.

**Retirement.** A checked example, code comment or targeted note can replace a large document. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R049

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. A resolvable source baseline and a way to detect stale statements. Who uses this description, and what would fail if it were omitted? **Source IDs:** ESME-S014, ESME-S041, ESME-S016, ESME-S058.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-017 — Reverse engineering itself modifies the subject

**Disposition.** REJECTED_OR_DISFAVOURED

**Kind.** CATEGORY_ERROR

**Criterion.** Recovery can be complete while implementation remains explicitly unchanged.

**Operating mechanism.** Candidate infers that reconstructing a view has already re-engineered or improved the running system.

**Trigger.** A report equates recovered knowledge with an operative system change.

**Inputs.** Baseline artefacts: Subject software versus recovered model. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.; Preconditions: Conditions: No legitimate inference from an analysis artefact to an executed modification.; Related property ids: ESME-015; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A report equates recovered knowledge with an operative system change. Select the question needed for a proposed change, diagnosis or handover rather than presupposing whole-system understanding.

**Produced constraints or evidence.** Recovery can be complete while implementation remains explicitly unchanged.

**Consumer.** Consumer: Maintainer distinguishing knowledge of a system from changes to it.; Decision: Recovery can be complete while implementation remains explicitly unchanged.

**Costs and possible harm.** Source-supported: Chikofsky and Cross define reverse engineering without changing the subject; re-engineering includes subsequent alteration.

**Assumptions.** Critical assumption: No legitimate inference from an analysis artefact to an executed modification.; Discriminating question: Which real object changed, rather than merely its description?

**Cheap path / omission.** Keep recovery findings separate from an authorised intervention and its measured effect.

**Retirement.** Keep recovery findings separate from an authorised intervention and its measured effect. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R039

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. No legitimate inference from an analysis artefact to an executed modification. Which real object changed, rather than merely its description? **Source IDs:** ESME-S014.

**Selection restriction.** REJECTED_OR_DISFAVOURED: Reject category conflation; preserve analysis as an enabling activity. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-018 — Exhaustive comprehension before every change

**Disposition.** REJECTED_OR_DISFAVOURED

**Kind.** UNBOUNDED_PREREQUISITE

**Criterion.** A local change may proceed on justified local evidence while unknown remote areas remain declared.

**Operating mechanism.** Candidate blocks every local change until the entire system and all tacit intent are recovered.

**Trigger.** A process imposes global understanding without a decision-relevant trigger.

**Inputs.** Baseline artefacts: Whole-system knowledge claims. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.; Preconditions: Conditions: Complete recovery is generally unattainable and not demonstrated as necessary for every task.; Related property ids: ESME-012; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A process imposes global understanding without a decision-relevant trigger. Select the question needed for a proposed change, diagnosis or handover rather than presupposing whole-system understanding.

**Produced constraints or evidence.** A local change may proceed on justified local evidence while unknown remote areas remain declared.

**Consumer.** Consumer: The person deciding a particular bounded intervention.; Decision: A local change may proceed on justified local evidence while unknown remote areas remain declared.

**Costs and possible harm.** Source-supported: developers ask bounded evolving questions; formal analyses are purpose-relative. Analytical: mandatory exhaustiveness imposes unbounded cost.

**Assumptions.** Critical assumption: Complete recovery is generally unattainable and not demonstrated as necessary for every task.; Discriminating question: Would the missing global knowledge change the local acceptance decision?

**Cheap path / omission.** Use ESME-012, widening only on consequential uncertainty.

**Retirement.** Use ESME-012, widening only on consequential uncertainty. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R039

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Complete recovery is generally unattainable and not demonstrated as necessary for every task. Would the missing global knowledge change the local acceptance decision? **Source IDs:** ESME-S014, ESME-S016, ESME-S015, ESME-S017, ESME-S018.

**Selection restriction.** REJECTED_OR_DISFAVOURED: Reject exhaustive prerequisite, not the need to understand consequential effects. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-019 — Feature-location hypotheses and interactive refinement

**Disposition.** CONTEXT_DEPENDENT

**Kind.** SEARCH_AND_INQUIRY_MECHANISM

**Criterion.** Candidate locations are confirmed against the feature and false leads are recorded or discarded.

**Operating mechanism.** Treat names, search results, traces and history as candidate locations; verify relevance and revise the search from observed behaviour.

**Trigger.** A change request describes a feature whose implementation is not already known.

**Inputs.** Baseline artefacts: Feature description, code locations, calls, traces and change history. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.; Preconditions: Conditions: A discriminating feature example and access to relevant artefacts.; Related property ids: ESME-012; ESME-014; ESME-022; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A change request describes a feature whose implementation is not already known. Select the question needed for a proposed change, diagnosis or handover rather than presupposing whole-system understanding.

**Produced constraints or evidence.** Candidate locations are confirmed against the feature and false leads are recorded or discarded.

**Consumer.** Consumer: Maintainer locating the implementation of the requested effect.; Decision: Candidate locations are confirmed against the feature and false leads are recorded or discarded.

**Costs and possible harm.** Source-supported: question sequences require multiple relations; history suggestions have false positives and misses.

**Assumptions.** Critical assumption: A discriminating feature example and access to relevant artefacts.; Discriminating question: What observation distinguishes a coincidental name match from the relevant implementation?

**Cheap path / omission.** A direct known location or maintainer pointer avoids a specialised search workflow.

**Retirement.** A direct known location or maintainer pointer avoids a specialised search workflow. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R004, ESME-R005, ESME-R006

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. A discriminating feature example and access to relevant artefacts. What observation distinguishes a coincidental name match from the relevant implementation? **Source IDs:** ESME-S017, ESME-S020, ESME-S044, ESME-S018.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-020 — Evidence-fused architecture and behaviour recovery

**Disposition.** CONTEXT_DEPENDENT

**Kind.** MODELLING_AND_RECOVERY_MECHANISM

**Criterion.** The view states what each relation is based on and which conflicts remain.

**Operating mechanism.** Cross-check static, runtime and build views; retain conflicts as investigation targets and recover only abstractions that serve the current decision.

**Trigger.** Late binding, generated code or divergent documentation makes any one view misleading.

**Inputs.** Baseline artefacts: Extracted components/relations, execution observations and build mapping. Relevant source, executable traces, build descriptions, documents and human knowledge form different evidence views.; Preconditions: Conditions: Compatible identifiers and explicit interpretation rules between views.; Related property ids: ESME-012; ESME-014; ESME-024; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Late binding, generated code or divergent documentation makes any one view misleading. Select the question needed for a proposed change, diagnosis or handover rather than presupposing whole-system understanding.

**Produced constraints or evidence.** The view states what each relation is based on and which conflicts remain.

**Consumer.** Consumer: Analyst and maintainer using the recovered view.; Decision: The view states what each relation is based on and which conflicts remain.

**Costs and possible harm.** Source-supported: tool-supported examples demonstrate feasibility, not general economic superiority; interpretation remains necessary.

**Assumptions.** Critical assumption: Compatible identifiers and explicit interpretation rules between views.; Discriminating question: Which decision is improved by adding another view, and which contradiction does it resolve?

**Cheap path / omission.** Use a single sufficient view when cross-checks reveal no consequential gap.

**Retirement.** Use a single sufficient view when cross-checks reveal no consequential gap. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R004, ESME-R005, ESME-R006

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Compatible identifiers and explicit interpretation rules between views. Which decision is improved by adding another view, and which contradiction does it resolve? **Source IDs:** ESME-S014, ESME-S044, ESME-S016.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-021 — Explicit multi-artefact impact boundary

**Disposition.** STRONGLY_RETAINED

**Kind.** BOUNDARY_AND_INQUIRY_MECHANISM

**Criterion.** The impact set is justified by evidence and unresolved edges are visible to the acceptance decision.

**Operating mechanism.** State the expected affected set, dependency kinds examined and plausible escape paths; widen or revise when counterevidence appears.

**Trigger.** An edit can propagate outside its immediate location or alter a relied-on contract.

**Inputs.** Baseline artefacts: Code, data, interfaces, configuration, builds, documentation and consumers. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.; Preconditions: Conditions: Identifiable baseline and an account of relevant dependency kinds.; Related property ids: ESME-004; ESME-012; ESME-024; ESME-025; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: An edit can propagate outside its immediate location or alter a relied-on contract. Bound a proposed edit by the effects it may propagate, not solely by its textual size.

**Produced constraints or evidence.** The impact set is justified by evidence and unresolved edges are visible to the acceptance decision.

**Consumer.** Consumer: Affected technical and human consumers of the change.; Decision: The impact set is justified by evidence and unresolved edges are visible to the acceptance decision.

**Costs and possible harm.** Source-supported: non-code omissions and ecosystem transitivity defeat source-only boundaries.

**Assumptions.** Critical assumption: Identifiable baseline and an account of relevant dependency kinds.; Discriminating question: What dependency kind was not observed by the method that declared this change local?

**Cheap path / omission.** Local review is sufficient when a defensible dependency boundary makes wider effects immaterial.

**Retirement.** Local review is sufficient when a defensible dependency boundary makes wider effects immaterial. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T03; Discriminator: Compare feasible obligations, seam/data constraints and prospective costs including the exit, not sunk effort.; Hybrid failure: Permanent adapters and dual data authorities add migration cost without eliminating legacy cost.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R001, ESME-R002, ESME-R005, ESME-R006, ESME-R022, ESME-R024, ESME-R026, ESME-R028, ESME-R030, ESME-R031

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Identifiable baseline and an account of relevant dependency kinds. What dependency kind was not observed by the method that declared this change local? **Source IDs:** ESME-S019, ESME-S020, ESME-S021, ESME-S041, ESME-S024, ESME-S061.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-022 — Historical co-change as fallible guidance

**Disposition.** CONTEXT_DEPENDENT

**Kind.** PREDICTIVE_INQUIRY_MECHANISM

**Criterion.** Suggested entities are either justified as relevant or dismissed; absent suggestions do not certify independence.

**Operating mechanism.** Use co-change suggestions to direct inspection; verify semantic or organisational relevance before adding an obligation.

**Trigger.** History contains sufficiently comparable changes and a maintainer needs likely impact leads.

**Inputs.** Baseline artefacts: Version-history transactions and recommended entities. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.; Preconditions: Conditions: Transaction extraction, temporal ordering and history quality must be adequate.; Related property ids: ESME-021; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: History contains sufficiently comparable changes and a maintainer needs likely impact leads. Bound a proposed edit by the effects it may propagate, not solely by its textual size.

**Produced constraints or evidence.** Suggested entities are either justified as relevant or dismissed; absent suggestions do not certify independence.

**Consumer.** Consumer: Maintainer deciding what to inspect, not automatically what to edit.; Decision: Suggested entities are either justified as relevant or dismissed; absent suggestions do not certify independence.

**Costs and possible harm.** Source-supported: useful predictions coexist with missed and unnecessary edits; actual developer savings were not established.

**Assumptions.** Critical assumption: Transaction extraction, temporal ordering and history quality must be adequate.; Discriminating question: Is this recurring co-edit necessary, accidental or an artefact of commit aggregation?

**Cheap path / omission.** Skip mining for new code, sparse history or an obvious direct dependency.

**Retirement.** Skip mining for new code, sparse history or an obvious direct dependency. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R005, ESME-R040

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Transaction extraction, temporal ordering and history quality must be adequate. Is this recurring co-edit necessary, accidental or an artefact of commit aggregation? **Source IDs:** ESME-S020.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-023 — Co-change correlation proves necessary dependency

**Disposition.** REJECTED_OR_DISFAVOURED

**Kind.** INVALID_CAUSAL_INFERENCE

**Criterion.** A mined edge remains provisional until its meaning is established.

**Operating mechanism.** Candidate automatically edits every co-changed entity or treats absent co-change as proof of independence.

**Trigger.** An impact tool’s history score is used as operative authority.

**Inputs.** Baseline artefacts: Mined transactions and candidate dependency edge. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.; Preconditions: Conditions: Causal necessity cannot be inferred from co-occurrence alone.; Related property ids: ESME-022; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: An impact tool’s history score is used as operative authority. Bound a proposed edit by the effects it may propagate, not solely by its textual size.

**Produced constraints or evidence.** A mined edge remains provisional until its meaning is established.

**Consumer.** Consumer: Maintainer distinguishing prediction from requirement.; Decision: A mined edge remains provisional until its meaning is established.

**Costs and possible harm.** Source-supported: historical transactions contain unnecessary or flawed edits and incomplete recall.

**Assumptions.** Critical assumption: Causal necessity cannot be inferred from co-occurrence alone.; Discriminating question: What intervention or semantic relation would establish that this edit must propagate?

**Cheap path / omission.** Inspect the proposed relation under ESME-022 and seek direct dependency evidence.

**Retirement.** Inspect the proposed relation under ESME-022 and seek direct dependency evidence. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R040

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Causal necessity cannot be inferred from co-occurrence alone. What intervention or semantic relation would establish that this edit must propagate? **Source IDs:** ESME-S020.

**Selection restriction.** REJECTED_OR_DISFAVOURED: Reject necessity inference, retain bounded search guidance. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-024 — Build, configuration and generated-artefact dependency closure

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** DEPENDENCY_ANALYSIS_MECHANISM

**Criterion.** The relevant producer/input/output chain is accounted for and changes reach validated consumers.

**Operating mechanism.** Follow the build/configuration/generation path that produces or selects the changed runtime artefact; challenge unsupported file types explicitly.

**Trigger.** Non-source inputs or generators influence the target behaviour or regression selection.

**Inputs.** Baseline artefacts: Build scripts, resources, schemas, generated code, package inputs and tool versions. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.; Preconditions: Conditions: The producing process and external inputs can be identified or bounded.; Related property ids: ESME-004; ESME-021; ESME-041; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Non-source inputs or generators influence the target behaviour or regression selection. Bound a proposed edit by the effects it may propagate, not solely by its textual size.

**Produced constraints or evidence.** The relevant producer/input/output chain is accounted for and changes reach validated consumers.

**Consumer.** Consumer: Build consumer, tester and deployed runtime.; Decision: The relevant producer/input/output chain is accounted for and changes reach validated consumers.

**Costs and possible harm.** Source-supported: RTSCheck found non-code limitations; packaging depends on environment and tool assumptions.

**Assumptions.** Critical assumption: The producing process and external inputs can be identified or bounded.; Discriminating question: Which file or environment value can change the output without changing the tracked source?

**Cheap path / omission.** A recorded explicit command and input list suffice where there is no indirect generation or configuration.

**Retirement.** A recorded explicit command and input list suffice where there is no indirect generation or configuration. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R005, ESME-R020, ESME-R028

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. The producing process and external inputs can be identified or bounded. Which file or environment value can change the output without changing the tracked source? **Source IDs:** ESME-S019, ESME-S024, ESME-S044, ESME-S052, ESME-S061.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-025 — Observer-specific API and protocol compatibility

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** CONSTRAINT_AND_COORDINATION_MECHANISM

**Criterion.** Supported interactions remain valid or consumers have an authorised transition path with explicit limitations.

**Operating mechanism.** Declare supported clients and observers, test their relevant interactions and coordinate intentional breaking transitions.

**Trigger.** An interface, schema or protocol is relied on outside the edited component.

**Inputs.** Baseline artefacts: Public API, binary interface, protocol, persistent representation and supported versions. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.; Preconditions: Conditions: Known support scope and evidence for the particular compatibility dimension.; Related property ids: ESME-001; ESME-021; ESME-051; ESME-069; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: An interface, schema or protocol is relied on outside the edited component. Bound a proposed edit by the effects it may propagate, not solely by its textual size.

**Produced constraints or evidence.** Supported interactions remain valid or consumers have an authorised transition path with explicit limitations.

**Consumer.** Consumer: Actual client source/binary/runtime/data consumers.; Decision: Supported interactions remain valid or consumers have an authorised transition path with explicit limitations.

**Costs and possible harm.** Source-supported: nominal refactoring can force client adaptation; versioning declares rather than verifies compatibility.

**Assumptions.** Critical assumption: Known support scope and evidence for the particular compatibility dimension.; Discriminating question: Which observer can detect a change despite unchanged method signatures?

**Cheap path / omission.** Internal changes with no consequential external observer need no compatibility programme.

**Retirement.** Internal changes with no consequential external observer need no compatibility programme. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T07; Discriminator: Determine real promises, capacity and transition feasibility; usage popularity is neither permission nor an infinite support contract.; Hybrid failure: Dates are announced without a viable path, or compatibility branches multiply beyond capacity.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R024, ESME-R040

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Known support scope and evidence for the particular compatibility dimension. Which observer can detect a change despite unchanged method signatures? **Source IDs:** ESME-S021, ESME-S049, ESME-S067, ESME-S054.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-026 — Version labels prove compatibility

**Disposition.** REJECTED_OR_DISFAVOURED

**Kind.** UNSUPPORTED_PROXY_GUARANTEE

**Criterion.** A label is distinguished from evidence of the relevant compatibility property.

**Operating mechanism.** Candidate accepts or rejects a dependency solely from its version number as proof of actual compatibility.

**Trigger.** An update policy infers behaviour from a label without checking the applicable contract.

**Inputs.** Baseline artefacts: Version labels and actual package/API behaviour. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.; Preconditions: Conditions: A publisher must apply the convention correctly; declared API may omit important observations.; Related property ids: ESME-025; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: An update policy infers behaviour from a label without checking the applicable contract. Bound a proposed edit by the effects it may propagate, not solely by its textual size.

**Produced constraints or evidence.** A label is distinguished from evidence of the relevant compatibility property.

**Consumer.** Consumer: Downstream consumer of the labelled release.; Decision: A label is distinguished from evidence of the relevant compatibility property.

**Costs and possible harm.** Source-supported: versioning rules are promises; API and schema behaviour require additional conditions.

**Assumptions.** Critical assumption: A publisher must apply the convention correctly; declared API may omit important observations.; Discriminating question: What evidence checks the publisher’s compatibility promise for this consumer?

**Cheap path / omission.** Use the label as a triage signal and verify consequential interactions.

**Retirement.** Use the label as a triage signal and verify consequential interactions. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R040

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. A publisher must apply the convention correctly; declared API may omit important observations. What evidence checks the publisher’s compatibility promise for this consumer? **Source IDs:** ESME-S067, ESME-S021, ESME-S049.

**Selection restriction.** REJECTED_OR_DISFAVOURED: Reject proof-by-label, retain semantic versioning as communication. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-027 — Concurrent-change semantic validation

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** INTEGRATION_EVIDENCE_MECHANISM

**Criterion.** The merged state satisfies the jointly accepted objectives or an explicit conflict is resolved.

**Operating mechanism.** Compare base, both parents and merged behaviour for consequential interactions; validate build and domain effects separately.

**Trigger.** Changes overlap semantically or one branch alters assumptions used by another.

**Inputs.** Baseline artefacts: Base/left/right/merge versions, build definitions and behavioural interactions. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.; Preconditions: Conditions: Parent intents and relevant interactions must be available; test-generated interference is only partial evidence.; Related property ids: ESME-001; ESME-021; ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Changes overlap semantically or one branch alters assumptions used by another. Bound a proposed edit by the effects it may propagate, not solely by its textual size.

**Produced constraints or evidence.** The merged state satisfies the jointly accepted objectives or an explicit conflict is resolved.

**Consumer.** Consumer: Contributors and consumers of the merged result.; Decision: The merged state satisfies the jointly accepted objectives or an explicit conflict is resolved.

**Costs and possible harm.** Source-supported: SAM detects only a subset of local interference; BuCoR build repair is not semantic correctness.

**Assumptions.** Critical assumption: Parent intents and relevant interactions must be available; test-generated interference is only partial evidence.; Discriminating question: Which assumption from one branch is invalidated by the other?

**Cheap path / omission.** Ordinary compilation and targeted tests suffice for clearly independent low-risk changes.

**Retirement.** Ordinary compilation and targeted tests suffice for clearly independent low-risk changes. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R021, ESME-R023

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Parent intents and relevant interactions must be available; test-generated interference is only partial evidence. Which assumption from one branch is invalidated by the other? **Source IDs:** ESME-S019, ESME-S040, ESME-S066.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-028 — Observer-relative preservation in refactoring

**Disposition.** STRONGLY_RETAINED

**Kind.** PRESERVATION_CRITERION

**Criterion.** The claimed equivalence is stated relative to the observer and supported by appropriate evidence.

**Operating mechanism.** Name the observer, relevant environment and deliberately excluded observations before claiming behaviour preservation.

**Trigger.** A transformation is justified as non-functional or structure-only.

**Inputs.** Baseline artefacts: Pre/post implementation and relevant external context. Use exact pre/post code, language/tool versions and relevant runtime, persistence and external-interface context.; Preconditions: Conditions: Preservation claims must match the actual language/runtime and consumer scope.; Related property ids: ESME-001; ESME-021; ESME-029; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A transformation is justified as non-functional or structure-only. Distinguish structure-preserving transformation from corrective or feature change; mixed changes need distinct obligations.

**Produced constraints or evidence.** The claimed equivalence is stated relative to the observer and supported by appropriate evidence.

**Consumer.** Consumer: Specified outputs, exceptions, timing, resources, reflection, layout or persistence as warranted.; Decision: The claimed equivalence is stated relative to the observer and supported by appropriate evidence.

**Costs and possible harm.** Source-supported: Opdyke excludes representation-sensitive observations; real API refactoring can affect clients and engines can err.

**Assumptions.** Critical assumption: Preservation claims must match the actual language/runtime and consumer scope.; Discriminating question: Which excluded observation is nevertheless used by a real consumer?

**Cheap path / omission.** For an isolated pure function, input/output and exceptional behaviour may be an adequate observer; no universal observer inventory is mandatory.

**Retirement.** For an isolated pure function, input/output and exceptional behaviour may be an adequate observer; no universal observer inventory is mandatory. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T01; Discriminator: Identify the actual obligation, consumer and authorisation for revision; unresolved authority blocks that revision, not unrelated work.; Hybrid failure: Two ambiguous meanings, unmaintained compatibility mode, or an oracle changed solely to pass.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R007, ESME-R008, ESME-R030, ESME-R041

**Evidence boundary.** FORMAL_SCOPE_BOUND: source-supported model/guarantee and assumptions recorded in source table; no independent re-proof or unbounded deployment guarantee. Preservation claims must match the actual language/runtime and consumer scope. Which excluded observation is nevertheless used by a real consumer? **Source IDs:** ESME-S014, ESME-S022, ESME-S021, ESME-S023, ESME-S045.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-029 — Transformation precondition enforcement

**Disposition.** ASSUMPTION_SENSITIVE

**Kind.** FORMAL_TRANSFORMATION_MECHANISM

**Criterion.** Applicability is demonstrated or transformation is refused/narrowed; exceptions remain explicit.

**Operating mechanism.** Check the transformation’s applicability conditions and supported constructs, then validate that the implemented tool follows them.

**Trigger.** A transformation’s correctness depends on names, bindings, inheritance, types or other structural conditions.

**Inputs.** Baseline artefacts: Transformation rule, input program, language semantics and engine version. Use exact pre/post code, language/tool versions and relevant runtime, persistence and external-interface context.; Preconditions: Conditions: Preconditions are adequate and actually checked; unknown reflection or external uses are not silently assumed absent.; Related property ids: ESME-028; ESME-030; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A transformation’s correctness depends on names, bindings, inheritance, types or other structural conditions. Distinguish structure-preserving transformation from corrective or feature change; mixed changes need distinct obligations.

**Produced constraints or evidence.** Applicability is demonstrated or transformation is refused/narrowed; exceptions remain explicit.

**Consumer.** Consumer: The observer specified by the preservation contract.; Decision: Applicability is demonstrated or transformation is refused/narrowed; exceptions remain explicit.

**Costs and possible harm.** Source-supported: valid formal intention does not prevent implementation bugs or unsupported contexts.

**Assumptions.** Critical assumption: Preconditions are adequate and actually checked; unknown reflection or external uses are not silently assumed absent.; Discriminating question: Which precondition is assumed rather than checked, and how could it fail?

**Cheap path / omission.** Direct review of a small transformation can replace a general engine when its conditions are simple.

**Retirement.** Direct review of a small transformation can replace a general engine when its conditions are simple. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R007, ESME-R008, ESME-R041

**Evidence boundary.** FORMAL_SCOPE_BOUND: source-supported model/guarantee and assumptions recorded in source table; no independent re-proof or unbounded deployment guarantee. Preconditions are adequate and actually checked; unknown reflection or external uses are not silently assumed absent. Which precondition is assumed rather than checked, and how could it fail? **Source IDs:** ESME-S022, ESME-S045.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-030 — Validation of transformation engines

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** TOOL_ASSURANCE_MECHANISM

**Criterion.** The relevant engine behaviour has bounded validation evidence and known exclusions.

**Operating mechanism.** Exercise relevant tool/version transformations with targeted counterexamples, compilation, differential or other justified checks; investigate disagreements.

**Trigger.** A transformation engine is new, changed, historically faulty or used outside its validated envelope.

**Inputs.** Baseline artefacts: Engine version, transformation, generated or real test inputs and resulting artefacts. Use exact pre/post code, language/tool versions and relevant runtime, persistence and external-interface context.; Preconditions: Conditions: Useful oracles and representative dangerous constructs must be available.; Related property ids: ESME-028; ESME-029; ESME-081; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A transformation engine is new, changed, historically faulty or used outside its validated envelope. Distinguish structure-preserving transformation from corrective or feature change; mixed changes need distinct obligations.

**Produced constraints or evidence.** The relevant engine behaviour has bounded validation evidence and known exclusions.

**Consumer.** Consumer: Tool user and reviewer who rely on the engine’s preservation claim.; Decision: The relevant engine behaviour has bounded validation evidence and known exclusions.

**Costs and possible harm.** Source-supported: ASTGen exposed bugs, but bounded tests and differential checks do not prove all-engine correctness.

**Assumptions.** Critical assumption: Useful oracles and representative dangerous constructs must be available.; Discriminating question: What concrete failure class is not exercised by the engine’s current validation?

**Cheap path / omission.** For a small trusted operation, review its concrete output rather than building a universal tool-validation campaign.

**Retirement.** For a small trusted operation, review its concrete output rather than building a universal tool-validation campaign. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T04; Discriminator: Compare accepted outcomes and total work, including later repair, on representative tasks under versioned settings.; Hybrid failure: Several tools share one invalid oracle, or the human rubber-stamps unreviewable volume.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R007, ESME-R008, ESME-R041

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Useful oracles and representative dangerous constructs must be available. What concrete failure class is not exercised by the engine’s current validation? **Source IDs:** ESME-S045, ESME-S024.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-031 — Refactoring payoff tied to a future change class

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** ECONOMIC_SELECTION_CRITERION

**Criterion.** A refactoring decision has a falsifiable benefit hypothesis and an after-use review point where proportionate.

**Operating mechanism.** Name the future work or other justified benefit enabled by restructuring and compare expected avoided cost with transformation and regression risk.

**Trigger.** Repeated costly edits or a credible forthcoming change makes structural improvement valuable.

**Inputs.** Baseline artefacts: Structure, expected change scenarios and intervention effort. Use exact pre/post code, language/tool versions and relevant runtime, persistence and external-interface context.; Preconditions: Conditions: Future demand and cost assumptions must be explicit and revisable.; Related property ids: ESME-028; ESME-058; ESME-059; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Repeated costly edits or a credible forthcoming change makes structural improvement valuable. Distinguish structure-preserving transformation from corrective or feature change; mixed changes need distinct obligations.

**Produced constraints or evidence.** A refactoring decision has a falsifiable benefit hypothesis and an after-use review point where proportionate.

**Consumer.** Consumer: Future maintainers and those bearing current conversion cost.; Decision: A refactoring decision has a falsifiable benefit hypothesis and an after-use review point where proportionate.

**Costs and possible harm.** Source-supported: structural metrics can worsen or fail to establish future savings; debt time is not automatically recoverable.

**Assumptions.** Critical assumption: Future demand and cost assumptions must be explicit and revisable.; Discriminating question: Which expected future change would actually become cheaper, and at whose expense?

**Cheap path / omission.** Perform a bounded repair or defer cleanup when no plausible future demand repays its cost.

**Retirement.** Perform a bounded repair or defer cleanup when no plausible future demand repays its cost. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T02; Discriminator: Compare demonstrated next-change capability and total transition cost, not complexity score alone.; Hybrid failure: Long-lived mixed styles and half-transferred knowledge make both old and new harder to understand.; Tension id: ESME-T03; Discriminator: Compare feasible obligations, seam/data constraints and prospective costs including the exit, not sunk effort.; Hybrid failure: Permanent adapters and dual data authorities add migration cost without eliminating legacy cost.; Tension id: ESME-T06; Discriminator: State the change-contingent cost mechanism, horizon and uncertainty that could reverse priority.; Hybrid failure: Endless incidental cleanup hides scope expansion; feature urgency becomes a permanent excuse to ignore a known liability.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R009, ESME-R041

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Future demand and cost assumptions must be explicit and revisable. Which expected future change would actually become cheaper, and at whose expense? **Source IDs:** ESME-S022, ESME-S027, ESME-S058, ESME-S023, ESME-S057.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-032 — Maintainability metrics as fallible diagnostics

**Disposition.** USEFUL_BUT_EASILY_GAMED

**Kind.** MEASUREMENT_PROXY

**Criterion.** Metric movement is not reported as benefit unless the relevant outcome is also supported.

**Operating mechanism.** Use metrics to identify questions and compare a declared local objective; cross-check against actual task cost and requirements.

**Trigger.** A metric might reveal a bottleneck not already understood.

**Inputs.** Baseline artefacts: Metric definition, affected structure and real maintenance tasks. Use exact pre/post code, language/tool versions and relevant runtime, persistence and external-interface context.; Preconditions: Conditions: Measurement unit, tool and relation to desired outcome must be justified.; Related property ids: ESME-031; ESME-058; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A metric might reveal a bottleneck not already understood. Distinguish structure-preserving transformation from corrective or feature change; mixed changes need distinct obligations.

**Produced constraints or evidence.** Metric movement is not reported as benefit unless the relevant outcome is also supported.

**Consumer.** Consumer: Maintainer or planner interpreting the signal.; Decision: Metric movement is not reported as benefit unless the relevant outcome is also supported.

**Costs and possible harm.** Source-supported: refactoring can increase structural metrics; current debt guidance rejects a single universal measure.

**Assumptions.** Critical assumption: Measurement unit, tool and relation to desired outcome must be justified.; Discriminating question: Can the score improve while the real maintenance task becomes harder?

**Cheap path / omission.** Direct evidence of difficult changes or a small review may dominate metric dashboards.

**Retirement.** Direct evidence of difficult changes or a small review may dominate metric dashboards. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R009, ESME-R041

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Measurement unit, tool and relation to desired outcome must be justified. Can the score improve while the real maintenance task becomes harder? **Source IDs:** ESME-S023, ESME-S057, ESME-S058.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-033 — Catalogue compliance as a maintenance property

**Disposition.** CEREMONY_NOT_GENERAL_PROPERTY

**Kind.** CEREMONIAL_PROXY

**Criterion.** The acceptance decision refers to preservation and benefit evidence rather than a label.

**Operating mechanism.** Candidate treats a named pattern, tool command or catalogue count as evidence of successful improvement.

**Trigger.** A process rewards transformations performed rather than obligations preserved or cost reduced.

**Inputs.** Baseline artefacts: Transformation label and resulting code. Use exact pre/post code, language/tool versions and relevant runtime, persistence and external-interface context.; Preconditions: Conditions: No catalogue is a complete theory or universal priority order.; Related property ids: ESME-028; ESME-031; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A process rewards transformations performed rather than obligations preserved or cost reduced. Distinguish structure-preserving transformation from corrective or feature change; mixed changes need distinct obligations.

**Produced constraints or evidence.** The acceptance decision refers to preservation and benefit evidence rather than a label.

**Consumer.** Consumer: Actual reviewer and future maintainer, not a compliance counter.; Decision: The acceptance decision refers to preservation and benefit evidence rather than a label.

**Costs and possible harm.** Source-supported: refactoring-labelled changes and automated transformations can have adverse results.

**Assumptions.** Critical assumption: No catalogue is a complete theory or universal priority order.; Discriminating question: What protected outcome would remain if the catalogue name were removed?

**Cheap path / omission.** Use ESME-028–031 without requiring a named catalogue entry.

**Retirement.** Use ESME-028–031 without requiring a named catalogue entry. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R041

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. No catalogue is a complete theory or universal priority order. What protected outcome would remain if the catalogue name were removed? **Source IDs:** ESME-S022, ESME-S041, ESME-S023, ESME-S045.

**Selection restriction.** CEREMONY_NOT_GENERAL_PROPERTY: Strip the ritual while retaining useful vocabulary and validated rules. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-034 — Characterisation tests with normative review

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** ORACLE_RECOVERY_MECHANISM

**Criterion.** Captured behaviour is classified as preserve, deliberately revise or unresolved before it becomes an acceptance rule.

**Operating mechanism.** Record observed behaviour and label whether it is an accepted obligation, disputed legacy behaviour or a defect; use characterisation to expose change rather than automatically bless the baseline.

**Trigger.** Important undocumented behaviour makes a change risky.

**Inputs.** Baseline artefacts: Legacy outputs, tests, data examples and requirement interpretation. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.; Preconditions: Conditions: Baseline observations are reproducible and their normative status can be examined.; Related property ids: ESME-001; ESME-012; ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Important undocumented behaviour makes a change risky. Separate the newly intended effect from independent obligations intended to survive a release.

**Produced constraints or evidence.** Captured behaviour is classified as preserve, deliberately revise or unresolved before it becomes an acceptance rule.

**Consumer.** Consumer: Domain consumer whose reliance may or may not legitimise the behaviour.; Decision: Captured behaviour is classified as preserve, deliberately revise or unresolved before it becomes an acceptance rule.

**Costs and possible harm.** Source-supported: existing tests and reference patches can encode mistakes or irrelevant behaviour.

**Assumptions.** Critical assumption: Baseline observations are reproducible and their normative status can be examined.; Discriminating question: Does this test capture a promise, an accident, or a disputed behaviour?

**Cheap path / omission.** A focused example or domain review may suffice instead of broad snapshot generation.

**Retirement.** A focused example or domain review may suffice instead of broad snapshot generation. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T01; Discriminator: Identify the actual obligation, consumer and authorisation for revision; unresolved authority blocks that revision, not unrelated work.; Hybrid failure: Two ambiguous meanings, unmaintained compatibility mode, or an oracle changed solely to pass.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R018, ESME-R035, ESME-R042, ESME-R052

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Baseline observations are reproducible and their normative status can be examined. Does this test capture a promise, an accident, or a disputed behaviour? **Source IDs:** ESME-S025, ESME-S041, ESME-S034, ESME-S063, ESME-S064.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-035 — Independent change and regression obligations

**Disposition.** STRONGLY_RETAINED

**Kind.** ACCEPTANCE_CRITERION

**Criterion.** Acceptance can explain both the justified difference and the justified continuity.

**Operating mechanism.** Separately establish evidence for the intended new effect and the consequential behaviours that must survive, with uncertainty stated for both.

**Trigger.** Any intervention changes or risks a relied-on behaviour.

**Inputs.** Baseline artefacts: New objective, preservation set, tests and other evidence. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.; Preconditions: Conditions: Intent is legitimate; evidence addresses rather than merely restates the claimed result.; Related property ids: ESME-001; ESME-021; ESME-034; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Any intervention changes or risks a relied-on behaviour. Separate the newly intended effect from independent obligations intended to survive a release.

**Produced constraints or evidence.** Acceptance can explain both the justified difference and the justified continuity.

**Consumer.** Consumer: Requesting stakeholder and existing consumers.; Decision: Acceptance can explain both the justified difference and the justified continuity.

**Costs and possible harm.** Source-supported: plausible repair can satisfy selected tests yet regress or remain under-specified.

**Assumptions.** Critical assumption: Intent is legitimate; evidence addresses rather than merely restates the claimed result.; Discriminating question: What evidence checks the preserved obligation independently of the new patch’s preferred interpretation?

**Cheap path / omission.** One test may address both obligations if its distinct assertions and coverage are clear; no separate team is inherently required.

**Retirement.** One test may address both obligations if its distinct assertions and coverage are clear; no separate team is inherently required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T01; Discriminator: Identify the actual obligation, consumer and authorisation for revision; unresolved authority blocks that revision, not unrelated work.; Hybrid failure: Two ambiguous meanings, unmaintained compatibility mode, or an oracle changed solely to pass.; Tension id: ESME-T05; Discriminator: Identify the loss-bearing observation and whether the chosen method can actually detect it before unacceptable exposure.; Hybrid failure: Early green results become unspoken permission to omit the only test for a live obligation.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R001, ESME-R002, ESME-R007, ESME-R018, ESME-R019, ESME-R021, ESME-R026, ESME-R028, ESME-R029, ESME-R030, ESME-R031, ESME-R034, ESME-R035, ESME-R042

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Intent is legitimate; evidence addresses rather than merely restates the claimed result. What evidence checks the preserved obligation independently of the new patch’s preferred interpretation? **Source IDs:** ESME-S025, ESME-S026, ESME-S041, ESME-S034, ESME-S063, ESME-S064.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-036 — Regression selection with suite-relative safety

**Disposition.** ASSUMPTION_SENSITIVE

**Kind.** FORMAL_AND_ANALYTICAL_MECHANISM

**Criterion.** Selected-suite rationale and exclusions are visible; unsupported change kinds trigger fallback.

**Operating mechanism.** Choose a selection method only within its dependency/language envelope; escalate to broader execution when relevant changes fall outside it.

**Trigger.** Running the whole available suite has material cost and sound selection can be justified.

**Inputs.** Baseline artefacts: Original/changed program, existing test suite and selection dependencies. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.; Preconditions: Conditions: Method conditions, dependency modelling and tool implementation must hold.; Related property ids: ESME-021; ESME-024; ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Running the whole available suite has material cost and sound selection can be justified. Separate the newly intended effect from independent obligations intended to survive a release.

**Produced constraints or evidence.** Selected-suite rationale and exclusions are visible; unsupported change kinds trigger fallback.

**Consumer.** Consumer: Tests in the declared suite, not all possible user observations.; Decision: Selected-suite rationale and exclusions are visible; unsupported change kinds trigger fallback.

**Costs and possible harm.** Source-supported: RTSCheck exposes both implementation failures and technique limitations; empirical cost models can be coarse.

**Assumptions.** Critical assumption: Method conditions, dependency modelling and tool implementation must hold.; Discriminating question: Which existing failing test could be omitted by this selector’s unsupported dependency kind?

**Cheap path / omission.** Run the full affordable suite; do not add selection complexity when it saves little.

**Retirement.** Run the full affordable suite; do not add selection complexity when it saves little. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T05; Discriminator: Identify the loss-bearing observation and whether the chosen method can actually detect it before unacceptable exposure.; Hybrid failure: Early green results become unspoken permission to omit the only test for a live obligation.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R019, ESME-R020

**Evidence boundary.** FORMAL_SCOPE_BOUND: source-supported model/guarantee and assumptions recorded in source table; no independent re-proof or unbounded deployment guarantee. Method conditions, dependency modelling and tool implementation must hold. Which existing failing test could be omitted by this selector’s unsupported dependency kind? **Source IDs:** ESME-S026, ESME-S046, ESME-S024.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-037 — Test prioritisation for early information

**Disposition.** CONTEXT_DEPENDENT

**Kind.** SCHEDULING_MECHANISM

**Criterion.** The ordering objective is stated and omitted tests, if any, remain known.

**Operating mechanism.** Order tests by justified expected information or risk within available time, while separately deciding whether stopping early is acceptable.

**Trigger.** A time-constrained test run benefits from earlier actionable failures.

**Inputs.** Baseline artefacts: Test set, order, duration estimates and failure relevance. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.; Preconditions: Conditions: Priority assumptions and any truncation policy must be explicit.; Related property ids: ESME-035; ESME-036; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A time-constrained test run benefits from earlier actionable failures. Separate the newly intended effect from independent obligations intended to survive a release.

**Produced constraints or evidence.** The ordering objective is stated and omitted tests, if any, remain known.

**Consumer.** Consumer: Developer or release decision maker waiting for information.; Decision: The ordering objective is stated and omitted tests, if any, remain known.

**Costs and possible harm.** Source-supported: inspected original abstract supports the objective, not detailed general benefit; order does not cure weak oracles.

**Assumptions.** Critical assumption: Priority assumptions and any truncation policy must be explicit.; Discriminating question: Does faster early feedback justify leaving later tests unexecuted in this decision?

**Cheap path / omission.** Keep the existing order when the suite is cheap or priority estimates are unreliable.

**Retirement.** Keep the existing order when the suite is cheap or priority estimates are unreliable. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T05; Discriminator: Identify the loss-bearing observation and whether the chosen method can actually detect it before unacceptable exposure.; Hybrid failure: Early green results become unspoken permission to omit the only test for a live obligation.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R019

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Priority assumptions and any truncation policy must be explicit. Does faster early feedback justify leaving later tests unexecuted in this decision? **Source IDs:** ESME-S047, ESME-S046, ESME-S025.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-038 — Mutation analysis as an adequacy diagnostic

**Disposition.** CONTEXT_DEPENDENT

**Kind.** TEST_ASSESSMENT_MECHANISM

**Criterion.** A surviving relevant mutant yields a useful test/observation or an explained non-obligation.

**Operating mechanism.** Use relevant mutation operators to challenge specific test weaknesses; investigate surviving mutants and equivalent or irrelevant mutants separately.

**Trigger.** A consequential preservation obligation may be weakly exercised by the current tests.

**Inputs.** Baseline artefacts: Mutants, tests, fault model and targeted behaviour. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.; Preconditions: Conditions: Operators and mutants represent relevant fault mechanisms; equivalent mutants and cost are handled.; Related property ids: ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A consequential preservation obligation may be weakly exercised by the current tests. Separate the newly intended effect from independent obligations intended to survive a release.

**Produced constraints or evidence.** A surviving relevant mutant yields a useful test/observation or an explained non-obligation.

**Consumer.** Consumer: Maintainer assessing tests, not treating a score as requirements completeness.; Decision: A surviving relevant mutant yields a useful test/observation or an explained non-obligation.

**Costs and possible harm.** Source-supported: real-fault studies require filtered, language-specific samples; mutation is not all-defect equivalence.

**Assumptions.** Critical assumption: Operators and mutants represent relevant fault mechanisms; equivalent mutants and cost are handled.; Discriminating question: Could the suite kill these mutants while still missing the relevant real requirement?

**Cheap path / omission.** Add a targeted real-fault regression case or review a missing assertion rather than run broad mutation campaigns.

**Retirement.** Add a targeted real-fault regression case or review a missing assertion rather than run broad mutation campaigns. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T05; Discriminator: Identify the loss-bearing observation and whether the chosen method can actually detect it before unacceptable exposure.; Hybrid failure: Early green results become unspoken permission to omit the only test for a live obligation.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R019

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Operators and mutants represent relevant fault mechanisms; equivalent mutants and cost are handled. Could the suite kill these mutants while still missing the relevant real requirement? **Source IDs:** ESME-S048, ESME-S025, ESME-S046.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-039 — Differential and metamorphic evidence without an infallible oracle

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** ORACLE_COMPARISON_MECHANISM

**Criterion.** A discrepancy is classified as defect, valid alternative, invalid test or unresolved requirement.

**Operating mechanism.** Specify why the compared outputs or metamorphic relation should agree, then adjudicate differences against legitimate input and requirement assumptions.

**Trigger.** A missing direct oracle can be supplemented by another implementation or justified relation.

**Inputs.** Baseline artefacts: Implementations, transformed inputs, expected relations and differentiating tests. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.; Preconditions: Conditions: The reference or relation has a justified domain and cannot supply its own normative authority.; Related property ids: ESME-001; ESME-034; ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A missing direct oracle can be supplemented by another implementation or justified relation. Separate the newly intended effect from independent obligations intended to survive a release.

**Produced constraints or evidence.** A discrepancy is classified as defect, valid alternative, invalid test or unresolved requirement.

**Consumer.** Consumer: Domain-relevant observer, not identity to a reference patch.; Decision: A discrepancy is classified as defect, valid alternative, invalid test or unresolved requirement.

**Costs and possible harm.** Source-supported: suspicious SWE-bench patches include correct alternatives and invalid differentiating inputs.

**Assumptions.** Critical assumption: The reference or relation has a justified domain and cannot supply its own normative authority.; Discriminating question: Why is agreement required on this input, and which implementation might be wrong?

**Cheap path / omission.** Manual expected-value examples suffice for simple known behaviour; do not introduce an untrusted reference unnecessarily.

**Retirement.** Manual expected-value examples suffice for simple known behaviour; do not introduce an untrusted reference unnecessarily. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R018, ESME-R019, ESME-R042, ESME-R052

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. The reference or relation has a justified domain and cannot supply its own normative authority. Why is agreement required on this input, and which implementation might be wrong? **Source IDs:** ESME-S025, ESME-S045, ESME-S063, ESME-S064.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-040 — Passing all selected tests proves correctness

**Disposition.** REJECTED_OR_DISFAVOURED

**Kind.** UNSUPPORTED_EVIDENCE_ESCALATION

**Criterion.** The reported conclusion does not exceed the actual tested obligation and environment.

**Operating mechanism.** Candidate promotes test passage to complete correctness without proving coverage and oracle adequacy.

**Trigger.** A release or generated patch is accepted solely because a finite suite is green.

**Inputs.** Baseline artefacts: Patch, test suite, harness, environment and accepted requirements. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.; Preconditions: Conditions: A universal inference would require completeness and correct oracles not generally established.; Related property ids: ESME-035; ESME-039; ESME-077; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A release or generated patch is accepted solely because a finite suite is green. Separate the newly intended effect from independent obligations intended to survive a release.

**Produced constraints or evidence.** The reported conclusion does not exceed the actual tested obligation and environment.

**Consumer.** Consumer: Relevant users beyond the exercised test inputs.; Decision: The reported conclusion does not exceed the actual tested obligation and environment.

**Costs and possible harm.** Source-supported: wrong patches, omitted regressions, broken harnesses and issue/PR misalignment provide counterexamples.

**Assumptions.** Critical assumption: A universal inference would require completeness and correct oracles not generally established.; Discriminating question: Which untested behaviour or incorrect oracle would leave these tests green?

**Cheap path / omission.** Make a scoped test claim and add only the missing consequential evidence, rather than demand impossible universal testing.

**Retirement.** Make a scoped test claim and add only the missing consequential evidence, rather than demand impossible universal testing. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R042

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. A universal inference would require completeness and correct oracles not generally established. Which untested behaviour or incorrect oracle would leave these tests green? **Source IDs:** ESME-S025, ESME-S026, ESME-S024, ESME-S034, ESME-S063, ESME-S064.

**Selection restriction.** REJECTED_OR_DISFAVOURED: Reject the universal inference, not the utility of tests. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-041 — Reproducible build and artefact identity

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** CONFIGURATION_AND_REPRODUCTION_MECHANISM

**Criterion.** A relevant rebuild or exact identity comparison succeeds, or its nondeterminism and limitations are explicit.

**Operating mechanism.** Record the relevant build inputs and verify a repeatable path to the released artefact; distinguish bitwise reproducibility from functional repeatability.

**Trigger.** Attribution, support, archival reuse or supply-chain checks depend on connecting source and delivered artefacts.

**Inputs.** Baseline artefacts: Source, compiler, packaging tools, dependencies, environment and released artefact. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.; Preconditions: Conditions: The chosen reproducibility notion and external inputs are declared.; Related property ids: ESME-004; ESME-024; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Attribution, support, archival reuse or supply-chain checks depend on connecting source and delivered artefacts. Separate the newly intended effect from independent obligations intended to survive a release.

**Produced constraints or evidence.** A relevant rebuild or exact identity comparison succeeds, or its nondeterminism and limitations are explicit.

**Consumer.** Consumer: Maintainer or downstream party comparing built outputs.; Decision: A relevant rebuild or exact identity comparison succeeds, or its nondeterminism and limitations are explicit.

**Costs and possible harm.** Source-supported: package-manager and environment differences matter; a repeatably malicious or incorrect source remains wrong.

**Assumptions.** Critical assumption: The chosen reproducibility notion and external inputs are declared.; Discriminating question: Which uncontrolled input changes the output despite the same source revision?

**Cheap path / omission.** For a directly interpreted single file, version identity and execution environment may be enough; do not mandate byte-identical builds without a consumer.

**Retirement.** For a directly interpreted single file, version identity and execution environment may be enough; do not mandate byte-identical builds without a consumer. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T08; Discriminator: Ask what future consumer must actually be able to do: retrieve, interpret, execute or receive service.; Hybrid failure: An archive is advertised as runnable despite missing dependencies, or an obsolete service is kept live without a support purpose.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R002

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. The chosen reproducibility notion and external inputs are declared. Which uncontrolled input changes the output despite the same source revision? **Source IDs:** ESME-S019, ESME-S050, ESME-S052, ESME-S062.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-042 — Continuous integration as integration feedback

**Disposition.** CONTEXT_DEPENDENT

**Kind.** FEEDBACK_AND_COORDINATION_MECHANISM

**Criterion.** Integration failures are attributed and resolved or consciously deferred before relying on the combined state.

**Operating mechanism.** Integrate at a cadence suited to actual dependencies and run evidence that can detect meaningful interaction failures; communicate failures to someone able to act.

**Trigger.** Concurrent changes or delayed integration conceal incompatibilities.

**Inputs.** Baseline artefacts: Integrated revisions, build/test results and responsible maintainers. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.; Preconditions: Conditions: Feedback is timely, interpretable and linked to a corrective decision.; Related property ids: ESME-004; ESME-027; ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Concurrent changes or delayed integration conceal incompatibilities. Separate the newly intended effect from independent obligations intended to survive a release.

**Produced constraints or evidence.** Integration failures are attributed and resolved or consciously deferred before relying on the combined state.

**Consumer.** Consumer: Contributors and release consumers affected by integration.; Decision: Integration failures are attributed and resolved or consciously deferred before relying on the combined state.

**Costs and possible harm.** Source-supported: clean merges and selected tests can miss semantics/non-code dependencies. Analytical: frequent green runs with no useful consumer are ceremony.

**Assumptions.** Critical assumption: Feedback is timely, interpretable and linked to a corrective decision.; Discriminating question: Which integration failure can this feedback detect and who changes the resulting decision?

**Cheap path / omission.** A small serially maintained artefact can use direct build/test checks without a dedicated service or fixed cadence.

**Retirement.** A small serially maintained artefact can use direct build/test checks without a dedicated service or fixed cadence. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T05; Discriminator: Identify the loss-bearing observation and whether the chosen method can actually detect it before unacceptable exposure.; Hybrid failure: Early green results become unspoken permission to omit the only test for a live obligation.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R021, ESME-R022

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Feedback is timely, interpretable and linked to a corrective decision. Which integration failure can this feedback detect and who changes the resulting decision? **Source IDs:** ESME-S019, ESME-S041, ESME-S050, ESME-S024, ESME-S066.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-043 — Observation-aware staged exposure

**Disposition.** CONTEXT_DEPENDENT

**Kind.** DEPLOYMENT_EXPERIMENT_MECHANISM

**Criterion.** Expansion is justified by relevant observations; missing signal is not treated as a pass.

**Operating mechanism.** Choose an isolatable population, meaningful observation window and attributable metrics; stop or revise on adverse or insufficient evidence.

**Trigger.** Production-only uncertainties can be investigated with genuinely limited and reversible exposure.

**Inputs.** Baseline artefacts: Release candidate, control, traffic population, data/configuration and monitoring. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.; Preconditions: Conditions: Isolation, representativeness, measurement sensitivity and authority to halt must exist.; Related property ids: ESME-035; ESME-044; ESME-051; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Production-only uncertainties can be investigated with genuinely limited and reversible exposure. Separate the newly intended effect from independent obligations intended to survive a release.

**Produced constraints or evidence.** Expansion is justified by relevant observations; missing signal is not treated as a pass.

**Consumer.** Consumer: Real users and operators observing relevant service consequences.; Decision: Expansion is justified by relevant observations; missing signal is not treated as a pass.

**Costs and possible harm.** Source-supported: shared failure domains, rare events and nonrepresentative traffic can invalidate canary conclusions.

**Assumptions.** Critical assumption: Isolation, representativeness, measurement sensitivity and authority to halt must exist.; Discriminating question: What consequential failure would remain invisible or affect the control as well?

**Cheap path / omission.** Use direct release with proportionate checks for low-impact changes, or offline rehearsal where live exposure is unsafe.

**Retirement.** Use direct release with proportionate checks for low-impact changes, or offline rehearsal where live exposure is unsafe. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T05; Discriminator: Identify the loss-bearing observation and whether the chosen method can actually detect it before unacceptable exposure.; Hybrid failure: Early green results become unspoken permission to omit the only test for a live obligation.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R014, ESME-R019, ESME-R022, ESME-R034

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Isolation, representativeness, measurement sensitivity and authority to halt must exist. What consequential failure would remain invisible or affect the control as well? **Source IDs:** ESME-S051, ESME-S062.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-044 — Effect-aware recovery and forward repair

**Disposition.** STRONGLY_RETAINED

**Kind.** OPERATIVE_RECOVERY_MECHANISM

**Criterion.** The stated recovery outcome is achievable for the relevant state, or irreversibility is explicitly accepted with a viable alternative.

**Operating mechanism.** Before consequential change, identify recoverable effects and demonstrate the relevant restore, compensation, containment or forward-repair path; revisit after new irreversible effects.

**Trigger.** A failed intervention could damage persistent data, external state or continuity beyond code text.

**Inputs.** Baseline artefacts: Code, data, schema, external actions, backup/restore tooling and effect history. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.; Preconditions: Conditions: Recovery artefacts are usable, required tools match, and accepted loss/time bounds are explicit.; Related property ids: ESME-004; ESME-050; ESME-051; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A failed intervention could damage persistent data, external state or continuity beyond code text. Separate the newly intended effect from independent obligations intended to survive a release.

**Produced constraints or evidence.** The stated recovery outcome is achievable for the relevant state, or irreversibility is explicitly accepted with a viable alternative.

**Consumer.** Consumer: Operator and affected data/service consumers.; Decision: The stated recovery outcome is achievable for the relevant state, or irreversibility is explicitly accepted with a viable alternative.

**Costs and possible harm.** Source-supported: GitLab backups failed through tooling/observation defects; F1 compatibility has restrictive transition assumptions.

**Assumptions.** Critical assumption: Recovery artefacts are usable, required tools match, and accepted loss/time bounds are explicit.; Discriminating question: After this step, what state or external effect cannot be returned merely by reverting code?

**Cheap path / omission.** For an isolated reversible file edit, a verified prior file may suffice; richer recovery is unnecessary when no external effect exists.

**Retirement.** For an isolated reversible file edit, a verified prior file may suffice; richer recovery is unnecessary when no external effect exists. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T05; Discriminator: Identify the loss-bearing observation and whether the chosen method can actually detect it before unacceptable exposure.; Hybrid failure: Early green results become unspoken permission to omit the only test for a live obligation.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R013, ESME-R015, ESME-R022, ESME-R029, ESME-R032, ESME-R043

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Recovery artefacts are usable, required tools match, and accepted loss/time bounds are explicit. After this step, what state or external effect cannot be returned merely by reverting code? **Source IDs:** ESME-S041, ESME-S049, ESME-S051, ESME-S062.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-045 — Bounded local repair as an alternative to restructuring

**Disposition.** CONTEXT_DEPENDENT

**Kind.** INTERVENTION_BRANCH

**Criterion.** The fault is corrected and preserved obligations are evidenced within the stated boundary.

**Operating mechanism.** Choose a small repair when it satisfies the obligation at lower expected total cost and risk than structural transformation.

**Trigger.** A local fault has a justified impact boundary and no demonstrated need for broad redesign.

**Inputs.** Baseline artefacts: Fault location, affected behaviour and support horizon. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.; Preconditions: Conditions: Locality is justified and the patch does not merely defer a spreading failure.; Related property ids: ESME-001; ESME-021; ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A local fault has a justified impact boundary and no demonstrated need for broad redesign. Choose among continued maintenance, local repair, wrapping, rehosting, replatforming, restructuring, incremental/atomic replacement and retirement.

**Produced constraints or evidence.** The fault is corrected and preserved obligations are evidenced within the stated boundary.

**Consumer.** Consumer: User needing restoration and maintainer bearing repair risk.; Decision: The fault is corrected and preserved obligations are evidenced within the stated boundary.

**Costs and possible harm.** Analytical, grounded in alternative maintenance forms: repeated patches can accumulate coupling and conceal a larger architectural issue.

**Assumptions.** Critical assumption: Locality is justified and the patch does not merely defer a spreading failure.; Discriminating question: What evidence makes the problem local rather than the visible symptom of a broader defect?

**Cheap path / omission.** No change is cheaper where the reported behaviour is acceptable; a focused correction is cheaper than modernisation when adequate.

**Retirement.** No change is cheaper where the reported behaviour is acceptable; a focused correction is cheaper than modernisation when adequate. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T03; Discriminator: Compare feasible obligations, seam/data constraints and prospective costs including the exit, not sunk effort.; Hybrid failure: Permanent adapters and dual data authorities add migration cost without eliminating legacy cost.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R010, ESME-R011

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Locality is justified and the patch does not merely defer a spreading failure. What evidence makes the problem local rather than the visible symptom of a broader defect? **Source IDs:** ESME-S001, ESME-S013, ESME-S041, ESME-S023, ESME-S058.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-046 — Legacy value distinguished from technical age

**Disposition.** STRONGLY_RETAINED

**Kind.** SELECTION_CRITERION

**Criterion.** A continue/change/retire decision is supported by actual value and risk rather than age alone.

**Operating mechanism.** Assess obligations, supportability and change cost directly; treat age as a possible clue, not proof that replacement is needed.

**Trigger.** A system is labelled legacy or obsolete as grounds for investment.

**Inputs.** Baseline artefacts: Existing service, domain behaviour, technology dependencies and support capacity. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.; Preconditions: Conditions: Relevant benefits and risks are identified independently of age.; Related property ids: ESME-007; ESME-058; ESME-074; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A system is labelled legacy or obsolete as grounds for investment. Choose among continued maintenance, local repair, wrapping, rehosting, replatforming, restructuring, incremental/atomic replacement and retirement.

**Produced constraints or evidence.** A continue/change/retire decision is supported by actual value and risk rather than age alone.

**Consumer.** Consumer: Current users and maintainers, not a technology-fashion ranking.; Decision: A continue/change/retire decision is supported by actual value and risk rather than age alone.

**Costs and possible harm.** Source-supported: migration literature emphasises lost domain knowledge and transition difficulty; technical support may nevertheless genuinely expire.

**Assumptions.** Critical assumption: Relevant benefits and risks are identified independently of age.; Discriminating question: What risk or blocked capability is being attributed to age, and is that causal link demonstrated?

**Cheap path / omission.** Continue operation with existing support when useful and adequately maintainable.

**Retirement.** Continue operation with existing support when useful and adequately maintainable. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T03; Discriminator: Compare feasible obligations, seam/data constraints and prospective costs including the exit, not sunk effort.; Hybrid failure: Permanent adapters and dual data authorities add migration cost without eliminating legacy cost.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R043

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Relevant benefits and risks are identified independently of age. What risk or blocked capability is being attributed to age, and is that causal link demonstrated? **Source IDs:** ESME-S013, ESME-S029, ESME-S041, ESME-S058.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-047 — Explicit comparison of modernisation alternatives

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** DECISION_PROCEDURE

**Criterion.** The chosen branch has a defensible advantage over feasible no-change, repair or migration alternatives.

**Operating mechanism.** Compare feasible interventions by preserved obligations, domain recovery, data conversion, support horizon and transition cost; do not collapse all modernisation into rewriting.

**Trigger.** Current maintenance no longer meets justified needs or costs warrant reconsideration.

**Inputs.** Baseline artefacts: Existing capability, candidate host/platform/implementation and transition obligations. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.; Preconditions: Conditions: Alternatives have sufficiently understood constraints; labels alone do not specify technical feasibility.; Related property ids: ESME-045; ESME-046; ESME-048; ESME-049; ESME-058; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Current maintenance no longer meets justified needs or costs warrant reconsideration. Choose among continued maintenance, local repair, wrapping, rehosting, replatforming, restructuring, incremental/atomic replacement and retirement.

**Produced constraints or evidence.** The chosen branch has a defensible advantage over feasible no-change, repair or migration alternatives.

**Consumer.** Consumer: Owner of the capability, maintainers, operators and affected consumers.; Decision: The chosen branch has a defensible advantage over feasible no-change, repair or migration alternatives.

**Costs and possible harm.** Source-supported: successful migration descriptions are selected and rarely establish comparative dominance.

**Assumptions.** Critical assumption: Alternatives have sufficiently understood constraints; labels alone do not specify technical feasibility.; Discriminating question: Which simpler alternative was excluded, and on what evidence?

**Cheap path / omission.** Compare only credible alternatives; a short repair-versus-replace decision can suffice.

**Retirement.** Compare only credible alternatives; a short repair-versus-replace decision can suffice. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T03; Discriminator: Compare feasible obligations, seam/data constraints and prospective costs including the exit, not sunk effort.; Hybrid failure: Permanent adapters and dual data authorities add migration cost without eliminating legacy cost.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R010, ESME-R043, ESME-R047

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Alternatives have sufficiently understood constraints; labels alone do not specify technical feasibility. Which simpler alternative was excluded, and on what evidence? **Source IDs:** ESME-S013, ESME-S029, ESME-S031, ESME-S055, ESME-S058.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-048 — Incremental substitution through valid migration seams

**Disposition.** CONTEXT_DEPENDENT

**Kind.** MIGRATION_BRANCH

**Criterion.** A slice of responsibility is actually transferred and temporary coexistence remains controlled.

**Operating mechanism.** Identify a separable responsibility and route or transfer it under a tested coexistence protocol, with a funded exit for temporary integration.

**Trigger.** Useful seams permit partial replacement and intermediate states preserve required service/data semantics.

**Inputs.** Baseline artefacts: Legacy/successor components, seam, routing, shared data and temporary adapters. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.; Preconditions: Conditions: Separation, reconciled data ownership and transitional compatibility must be feasible.; Related property ids: ESME-025; ESME-050; ESME-051; ESME-052; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Useful seams permit partial replacement and intermediate states preserve required service/data semantics. Choose among continued maintenance, local repair, wrapping, rehosting, replatforming, restructuring, incremental/atomic replacement and retirement.

**Produced constraints or evidence.** A slice of responsibility is actually transferred and temporary coexistence remains controlled.

**Consumer.** Consumer: Consumers crossing the seam and operators controlling cutover.; Decision: A slice of responsibility is actually transferred and temporary coexistence remains controlled.

**Costs and possible harm.** Source-supported: gateways and dual operation can cause consistency problems; early strangler account is not a comparative completed-success trial.

**Assumptions.** Critical assumption: Separation, reconciled data ownership and transitional compatibility must be feasible.; Discriminating question: Does the proposed seam separate responsibility or merely create two inconsistent authorities?

**Cheap path / omission.** A small system may be cheaper to replace atomically; no migration when existing service remains adequate.

**Retirement.** A small system may be cheaper to replace atomically; no migration when existing service remains adequate. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T03; Discriminator: Compare feasible obligations, seam/data constraints and prospective costs including the exit, not sunk effort.; Hybrid failure: Permanent adapters and dual data authorities add migration cost without eliminating legacy cost.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R011, ESME-R012, ESME-R013, ESME-R014, ESME-R016, ESME-R043

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Separation, reconciled data ownership and transitional compatibility must be feasible. Does the proposed seam separate responsibility or merely create two inconsistent authorities? **Source IDs:** ESME-S029, ESME-S030, ESME-S031, ESME-S051.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-049 — Atomic replacement where coexistence is the greater risk

**Disposition.** CONTEXT_DEPENDENT

**Kind.** MIGRATION_ALTERNATIVE

**Criterion.** The cutover is authorised against endpoint and conversion evidence, not just successor tests.

**Operating mechanism.** Choose a single transition only when rehearsal, downtime/loss acceptance and state conversion evidence make it preferable to unsupported coexistence.

**Trigger.** The system is small or separability is poor, downtime is acceptable, or dual operation creates intolerable inconsistency.

**Inputs.** Baseline artefacts: Complete successor, cutover state, consumers and recovery resources. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.; Preconditions: Conditions: Validated conversion, feasible operating window and explicit recovery/forward limits.; Related property ids: ESME-047; ESME-050; ESME-044; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: The system is small or separability is poor, downtime is acceptable, or dual operation creates intolerable inconsistency. Choose among continued maintenance, local repair, wrapping, rehosting, replatforming, restructuring, incremental/atomic replacement and retirement.

**Produced constraints or evidence.** The cutover is authorised against endpoint and conversion evidence, not just successor tests.

**Consumer.** Consumer: Users accepting the transition and operators performing it.; Decision: The cutover is authorised against endpoint and conversion evidence, not just successor tests.

**Costs and possible harm.** Analytical comparison grounded in migration criticism: concentrated loss and forgotten requirements may dominate any simplicity benefit.

**Assumptions.** Critical assumption: Validated conversion, feasible operating window and explicit recovery/forward limits.; Discriminating question: What makes a dual-running intermediate state less safe than a rehearsed single transition?

**Cheap path / omission.** Prefer bounded repair or incremental transfer where they meet obligations with less risk.

**Retirement.** Prefer bounded repair or incremental transfer where they meet obligations with less risk. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T03; Discriminator: Compare feasible obligations, seam/data constraints and prospective costs including the exit, not sunk effort.; Hybrid failure: Permanent adapters and dual data authorities add migration cost without eliminating legacy cost.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R011, ESME-R012, ESME-R013, ESME-R043

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Validated conversion, feasible operating window and explicit recovery/forward limits. What makes a dual-running intermediate state less safe than a rehearsed single transition? **Source IDs:** ESME-S029, ESME-S041, ESME-S055, ESME-S031.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-050 — Data-conversion invariants and reconciliation

**Disposition.** STRONGLY_RETAINED

**Kind.** MIGRATION_VALIDATION_MECHANISM

**Criterion.** Reconciled state satisfies declared invariants; unmatched or irreversible changes are explicitly resolved or accepted.

**Operating mechanism.** Specify the semantic invariants of conversion, identify the authoritative state during transition, and reconcile records/effects with explicit loss and uncertainty handling.

**Trigger.** Schema, encoding, representation or ownership changes can alter persisted meaning.

**Inputs.** Baseline artefacts: Old/new data, mapping rules, transaction history and reconciliation evidence. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.; Preconditions: Conditions: Mappings and concurrency rules must preserve or deliberately revise the required semantics.; Related property ids: ESME-001; ESME-025; ESME-044; ESME-051; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Schema, encoding, representation or ownership changes can alter persisted meaning. Choose among continued maintenance, local repair, wrapping, rehosting, replatforming, restructuring, incremental/atomic replacement and retirement.

**Produced constraints or evidence.** Reconciled state satisfies declared invariants; unmatched or irreversible changes are explicitly resolved or accepted.

**Consumer.** Consumer: Consumers relying on meanings such as identity, balances, ordering or provenance.; Decision: Reconciled state satisfies declared invariants; unmatched or irreversible changes are explicitly resolved or accepted.

**Costs and possible harm.** Source-supported: heterogeneous dual updates remain difficult; a backup’s existence does not establish usable restoration.

**Assumptions.** Critical assumption: Mappings and concurrency rules must preserve or deliberately revise the required semantics.; Discriminating question: Which semantic distinction is lost by conversion even when every row is transferred?

**Cheap path / omission.** For stateless replacement this is not triggered; a simple verified bijective conversion may need only direct checks.

**Retirement.** For stateless replacement this is not triggered; a simple verified bijective conversion may need only direct checks. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R013, ESME-R015, ESME-R016, ESME-R032

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Mappings and concurrency rules must preserve or deliberately revise the required semantics. Which semantic distinction is lost by conversion even when every row is transferred? **Source IDs:** ESME-S029, ESME-S049, ESME-S062.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-051 — Compatibility of intermediate and mixed-version states

**Disposition.** ASSUMPTION_SENSITIVE

**Kind.** TRANSITION_CONSTRAINT

**Criterion.** Only validated version/state combinations are active; unsupported skew triggers containment or a different route.

**Operating mechanism.** Enumerate the supported intermediate combinations and constrain activation order or feature use until each combination’s obligations hold.

**Trigger.** Rolling upgrades, data conversion or partial migration create old/new participants at the same time.

**Inputs.** Baseline artefacts: Versions of readers/writers, schema, protocol, configuration and shared state. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.; Preconditions: Conditions: Version-skew bounds, ordering and data semantics are actually enforced.; Related property ids: ESME-025; ESME-043; ESME-044; ESME-050; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Rolling upgrades, data conversion or partial migration create old/new participants at the same time. Choose among continued maintenance, local repair, wrapping, rehosting, replatforming, restructuring, incremental/atomic replacement and retirement.

**Produced constraints or evidence.** Only validated version/state combinations are active; unsupported skew triggers containment or a different route.

**Consumer.** Consumer: Old and new consumers interacting concurrently.; Decision: Only validated version/state combinations are active; unsupported skew triggers containment or a different route.

**Costs and possible harm.** Source-supported: F1 abstract guarantee is restricted; full protocol proof was inaccessible, so no general transfer guarantee is made.

**Assumptions.** Critical assumption: Version-skew bounds, ordering and data semantics are actually enforced.; Discriminating question: Which intermediate reader/writer combination is neither covered by old nor new endpoint tests?

**Cheap path / omission.** Use an atomic stop-and-switch when mixed versions offer no justified advantage and downtime is acceptable.

**Retirement.** Use an atomic stop-and-switch when mixed versions offer no justified advantage and downtime is acceptable. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T07; Discriminator: Determine real promises, capacity and transition feasibility; usage popularity is neither permission nor an infinite support contract.; Hybrid failure: Dates are announced without a viable path, or compatibility branches multiply beyond capacity.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R014, ESME-R015, ESME-R016, ESME-R031, ESME-R032

**Evidence boundary.** FORMAL_SCOPE_BOUND: source-supported model/guarantee and assumptions recorded in source table; no independent re-proof or unbounded deployment guarantee. Version-skew bounds, ordering and data semantics are actually enforced. Which intermediate reader/writer combination is neither covered by old nor new endpoint tests? **Source IDs:** ESME-S049, ESME-S051, ESME-S067, ESME-S062.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-052 — Coexistence budget and explicit exit

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** TRANSITION_TERMINATION_MECHANISM

**Criterion.** A completed migration has observable old-path closure or a newly authorised reason to retain it.

**Operating mechanism.** Fund and track the temporary support burden, define responsibility-transfer criteria and remove obsolete paths once agreed obligations are discharged.

**Trigger.** Old and new implementations or data representations operate simultaneously during migration.

**Inputs.** Baseline artefacts: Temporary routes, duplicate systems, data synchronisation and support obligations. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.; Preconditions: Conditions: Authority to retire old paths and evidence that residual consumers/data obligations are resolved.; Related property ids: ESME-048; ESME-050; ESME-051; ESME-071; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Old and new implementations or data representations operate simultaneously during migration. Choose among continued maintenance, local repair, wrapping, rehosting, replatforming, restructuring, incremental/atomic replacement and retirement.

**Produced constraints or evidence.** A completed migration has observable old-path closure or a newly authorised reason to retain it.

**Consumer.** Consumer: Operators, legacy/successor maintainers and consumers yet to migrate.; Decision: A completed migration has observable old-path closure or a newly authorised reason to retain it.

**Costs and possible harm.** Analytical, grounded in migration costs: premature removal can strand consumers; indefinitely retained bridges can erase expected benefit.

**Assumptions.** Critical assumption: Authority to retire old paths and evidence that residual consumers/data obligations are resolved.; Discriminating question: What precisely would permit removal of the last legacy path, and who can establish it?

**Cheap path / omission.** Avoid coexistence entirely where a local repair or simple cutover is adequate.

**Retirement.** Avoid coexistence entirely where a local repair or simple cutover is adequate. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T03; Discriminator: Compare feasible obligations, seam/data constraints and prospective costs including the exit, not sunk effort.; Hybrid failure: Permanent adapters and dual data authorities add migration cost without eliminating legacy cost.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R016, ESME-R017, ESME-R033

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Authority to retire old paths and evidence that residual consumers/data obligations are resolved. What precisely would permit removal of the last legacy path, and who can establish it? **Source IDs:** ESME-S013, ESME-S029, ESME-S031, ESME-S055.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-053 — Rewrites are always wrong

**Disposition.** REJECTED_OR_DISFAVOURED

**Kind.** UNIVERSAL_STRATEGY_PROHIBITION

**Criterion.** Replacement remains admissible when it meets obligations better than available alternatives.

**Operating mechanism.** Candidate forbids replacement regardless of support constraints, separability or transition evidence.

**Trigger.** A viable replacement is rejected solely by a slogan.

**Inputs.** Baseline artefacts: Replacement decision and realistic alternatives. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.; Preconditions: Conditions: A universal prohibition would require showing every replacement dominated, which this evidence does not support.; Related property ids: ESME-047; ESME-049; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A viable replacement is rejected solely by a slogan. Choose among continued maintenance, local repair, wrapping, rehosting, replatforming, restructuring, incremental/atomic replacement and retirement.

**Produced constraints or evidence.** Replacement remains admissible when it meets obligations better than available alternatives.

**Consumer.** Consumer: Those responsible for service continuity and future maintenance.; Decision: Replacement remains admissible when it meets obligations better than available alternatives.

**Costs and possible harm.** Analytical: documented migration alternatives and retirement conditions contradict universal exclusion; this is not a claimed empirical rewrite success rate.

**Assumptions.** Critical assumption: A universal prohibition would require showing every replacement dominated, which this evidence does not support.; Discriminating question: Is continued servicing actually feasible over the required support horizon?

**Cheap path / omission.** Compare repair, incremental and atomic alternatives under ESME-047.

**Retirement.** Compare repair, incremental and atomic alternatives under ESME-047. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R043

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. A universal prohibition would require showing every replacement dominated, which this evidence does not support. Is continued servicing actually feasible over the required support horizon? **Source IDs:** ESME-S013, ESME-S029, ESME-S031, ESME-S055.

**Selection restriction.** REJECTED_OR_DISFAVOURED: Reject the universal rule while retaining scrutiny of lost domain knowledge and cutover risk. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-054 — Newest language or platform is the mature form

**Disposition.** REJECTED_OR_DISFAVOURED

**Kind.** TECHNOLOGY_AGE_PROXY

**Criterion.** The selected platform is justified by concrete requirements, not release date.

**Operating mechanism.** Candidate ranks maturity by platform age rather than fit, supportability and demonstrated maintenance value.

**Trigger.** A migration is justified principally by novelty or fashion.

**Inputs.** Baseline artefacts: Current and candidate platforms, relevant tooling and maintainer skills. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.; Preconditions: Conditions: Transfer costs, ecosystem viability and needed capabilities must be shown, not presumed.; Related property ids: ESME-046; ESME-047; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A migration is justified principally by novelty or fashion. Choose among continued maintenance, local repair, wrapping, rehosting, replatforming, restructuring, incremental/atomic replacement and retirement.

**Produced constraints or evidence.** The selected platform is justified by concrete requirements, not release date.

**Consumer.** Consumer: Actual users and future maintainers.; Decision: The selected platform is justified by concrete requirements, not release date.

**Costs and possible harm.** Analytical objection grounded in migration and debt trade-offs: no universal technology-age ordering is established.

**Assumptions.** Critical assumption: Transfer costs, ecosystem viability and needed capabilities must be shown, not presumed.; Discriminating question: What necessary capability or avoided risk is unavailable on the current platform?

**Cheap path / omission.** Retain the existing platform when obligations and support are satisfied.

**Retirement.** Retain the existing platform when obligations and support are satisfied. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R043

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Transfer costs, ecosystem viability and needed capabilities must be shown, not presumed. What necessary capability or avoided risk is unavailable on the current platform? **Source IDs:** ESME-S029, ESME-S031, ESME-S055, ESME-S058.

**Selection restriction.** REJECTED_OR_DISFAVOURED: Reject newest-equals-best; preserve targeted adaptation to genuine environmental change. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-055 — Reverting code reverses the system

**Disposition.** REJECTED_OR_DISFAVOURED

**Kind.** FALSE_RECOVERY_EQUIVALENCE

**Criterion.** Recovery claims distinguish source rollback from restored data and accepted irreversible consequences.

**Operating mechanism.** Candidate treats a code revert as proof that all deployed consequences are undone.

**Trigger.** A rollout or migration changes data, schemas, messages, payments or other external state.

**Inputs.** Baseline artefacts: Code revision, persistent and external effect history. Baseline includes domain behaviour, live data, old/new implementations, routing and temporary synchronisation mechanisms.; Preconditions: Conditions: Effect inversion is required; code identity alone cannot establish it.; Related property ids: ESME-044; ESME-050; ESME-051; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A rollout or migration changes data, schemas, messages, payments or other external state. Choose among continued maintenance, local repair, wrapping, rehosting, replatforming, restructuring, incremental/atomic replacement and retirement.

**Produced constraints or evidence.** Recovery claims distinguish source rollback from restored data and accepted irreversible consequences.

**Consumer.** Consumer: Data owners, users and operators observing more than source text.; Decision: Recovery claims distinguish source rollback from restored data and accepted irreversible consequences.

**Costs and possible harm.** Source-supported: actual database recovery and constrained schema evolution demonstrate distinct obligations.

**Assumptions.** Critical assumption: Effect inversion is required; code identity alone cannot establish it.; Discriminating question: What happened while this code was running that a textual revert cannot undo?

**Cheap path / omission.** For a genuinely isolated file-only effect, code reversion can be adequate; otherwise use ESME-044.

**Retirement.** For a genuinely isolated file-only effect, code reversion can be adequate; otherwise use ESME-044. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R043

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Effect inversion is required; code identity alone cannot establish it. What happened while this code was running that a textual revert cannot undo? **Source IDs:** ESME-S019, ESME-S041, ESME-S049, ESME-S051, ESME-S062.

**Selection restriction.** REJECTED_OR_DISFAVOURED: Reject equivalence and retain effect-relative recovery. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-056 — Technical debt as a contingent future-change liability

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** ECONOMIC_CONCEPT

**Criterion.** An item states how and when it imposes additional cost; disappearance of that scenario can retire the item.

**Operating mechanism.** Identify a concrete design/implementation condition and the future work that makes its liability actual; distinguish defects, missing features and ordinary maintenance.

**Trigger.** A structural choice plausibly increases future change cost or blocks justified evolution.

**Inputs.** Baseline artefacts: Debt condition, cause, affected future change and support horizon. A debt item links a concrete design/implementation condition to affected future work and its economic context.; Preconditions: Conditions: The future-change scenario and comparison to an alternative are intelligible.; Related property ids: ESME-031; ESME-058; ESME-059; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A structural choice plausibly increases future change cost or blocks justified evolution. Define a future-change liability, not every defect, missing feature or disliked structure as technical debt.

**Produced constraints or evidence.** An item states how and when it imposes additional cost; disappearance of that scenario can retire the item.

**Consumer.** Consumer: Future maintainers and value/cost decision makers.; Decision: An item states how and when it imposes additional cost; disappearance of that scenario can retire the item.

**Costs and possible harm.** Source-supported: current debt manifesto rejects calling all issues debt and recognises context-dependent interest.

**Assumptions.** Critical assumption: The future-change scenario and comparison to an alternative are intelligible.; Discriminating question: What future change would incur this debt’s interest, and compared with what alternative?

**Cheap path / omission.** Do not create debt items for disliked code with no relevant future-cost mechanism.

**Retirement.** Do not create debt items for disliked code with no relevant future-cost mechanism. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T06; Discriminator: State the change-contingent cost mechanism, horizon and uncertainty that could reverse priority.; Hybrid failure: Endless incidental cleanup hides scope expansion; feature urgency becomes a permanent excuse to ignore a known liability.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R009, ESME-R044

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. The future-change scenario and comparison to an alternative are intelligible. What future change would incur this debt’s interest, and compared with what alternative? **Source IDs:** ESME-S027, ESME-S028, ESME-S058, ESME-S023.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-057 — Actionable debt records with a consumer

**Disposition.** USEFUL_BUT_EASILY_BUREAUCRATISED

**Kind.** COMMUNICATION_AND_PRIORITISATION_MECHANISM

**Criterion.** The record changes or supports a prioritisation decision and is refreshed or retired as context changes.

**Operating mechanism.** Record only enough evidence about an important liability, affected work, uncertainty and intended decision for the people prioritising it.

**Trigger.** A significant liability risks being forgotten, misunderstood or shifted across teams.

**Inputs.** Baseline artefacts: Debt item, supporting observations, cost estimates and decision history. A debt item links a concrete design/implementation condition to affected future work and its economic context.; Preconditions: Conditions: There is a real decision consumer and estimates are labelled as estimates.; Related property ids: ESME-056; ESME-058; ESME-063; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A significant liability risks being forgotten, misunderstood or shifted across teams. Define a future-change liability, not every defect, missing feature or disliked structure as technical debt.

**Produced constraints or evidence.** The record changes or supports a prioritisation decision and is refreshed or retired as context changes.

**Consumer.** Consumer: Maintainer, budget holder and affected downstream cost bearer.; Decision: The record changes or supports a prioritisation decision and is refreshed or retired as context changes.

**Costs and possible harm.** Source-supported: the 2025 manifesto warns against heavy debt bureaucracy; reported debt effort does not prove register value.

**Assumptions.** Critical assumption: There is a real decision consumer and estimates are labelled as estimates.; Discriminating question: Who acts on this record, and what decision would be worse without it?

**Cheap path / omission.** A tracked issue or brief decision note can replace a dedicated register; delete records whose liability has vanished.

**Retirement.** A tracked issue or brief decision note can replace a dedicated register; delete records whose liability has vanished. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T06; Discriminator: State the change-contingent cost mechanism, horizon and uncertainty that could reverse priority.; Hybrid failure: Endless incidental cleanup hides scope expansion; feature urgency becomes a permanent excuse to ignore a known liability.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R009, ESME-R049

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. There is a real decision consumer and estimates are labelled as estimates. Who acts on this record, and what decision would be worse without it? **Source IDs:** ESME-S028, ESME-S058, ESME-S057.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-058 — Lifecycle-cost and value-based prioritisation

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** DECISION_PROCEDURE

**Criterion.** A priority decision explains trade-offs, uncertainty and the evidence that could reverse it.

**Operating mechanism.** Compare intervention, validation, disruption, future support and opportunity costs under plausible scenarios; retain uncertainty and identify cost bearers.

**Trigger.** Competing repairs, features, structural improvements or retirement choices draw on limited resources.

**Inputs.** Baseline artefacts: Maintenance options, benefits, cost horizon and uncertainty. A debt item links a concrete design/implementation condition to affected future work and its economic context.; Preconditions: Conditions: Alternatives and relevant time horizon are explicit; sunk cost is not treated as prospective benefit.; Related property ids: ESME-001; ESME-031; ESME-047; ESME-056; ESME-060; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Competing repairs, features, structural improvements or retirement choices draw on limited resources. Define a future-change liability, not every defect, missing feature or disliked structure as technical debt.

**Produced constraints or evidence.** A priority decision explains trade-offs, uncertainty and the evidence that could reverse it.

**Consumer.** Consumer: Stakeholders allocating effort and those who bear downstream costs.; Decision: A priority decision explains trade-offs, uncertainty and the evidence that could reverse it.

**Costs and possible harm.** Source-supported: self-reported debt burdens do not identify causal recoverable savings; precise universal debt metrics are unsupported.

**Assumptions.** Critical assumption: Alternatives and relevant time horizon are explicit; sunk cost is not treated as prospective benefit.; Discriminating question: Which uncertainty could reverse the preferred option, and is more information worth its cost?

**Cheap path / omission.** A qualitative ordered comparison is sufficient when numerical estimates would be fictitious.

**Retirement.** A qualitative ordered comparison is sufficient when numerical estimates would be fictitious. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T06; Discriminator: State the change-contingent cost mechanism, horizon and uncertainty that could reverse priority.; Hybrid failure: Endless incidental cleanup hides scope expansion; feature urgency becomes a permanent excuse to ignore a known liability.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R003, ESME-R009, ESME-R010, ESME-R022, ESME-R034, ESME-R044, ESME-R048

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Alternatives and relevant time horizon are explicit; sunk cost is not treated as prospective benefit. Which uncertainty could reverse the preferred option, and is more information worth its cost? **Source IDs:** ESME-S027, ESME-S028, ESME-S057, ESME-S058, ESME-S023.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-059 — Option-preserving deferral and deliberate non-repayment

**Disposition.** CONTEXT_DEPENDENT

**Kind.** ECONOMIC_SELECTION_BRANCH

**Criterion.** Deferral is an explicit justified choice with a relevant trigger rather than forgotten work.

**Operating mechanism.** Defer a structural intervention when its expected value is below its cost, while retaining a trigger to revisit if demand, risk or support changes.

**Trigger.** Future change demand is uncertain, interest is small, or the system may retire before repayment benefits arise.

**Inputs.** Baseline artefacts: Deferred liability, prospective demand and revisit condition. A debt item links a concrete design/implementation condition to affected future work and its economic context.; Preconditions: Conditions: Delay must not violate present obligations or create unacceptable irreversible lock-in.; Related property ids: ESME-056; ESME-058; ESME-074; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Future change demand is uncertain, interest is small, or the system may retire before repayment benefits arise. Define a future-change liability, not every defect, missing feature or disliked structure as technical debt.

**Produced constraints or evidence.** Deferral is an explicit justified choice with a relevant trigger rather than forgotten work.

**Consumer.** Consumer: Those bearing future effort and present opportunity cost.; Decision: Deferral is an explicit justified choice with a relevant trigger rather than forgotten work.

**Costs and possible harm.** Source-supported: 2025 debt discussion recognises value in paying limited interest; numerical real-options calibration is not established here.

**Assumptions.** Critical assumption: Delay must not violate present obligations or create unacceptable irreversible lock-in.; Discriminating question: What change in demand or exposure would make continued deferral indefensible?

**Cheap path / omission.** Do nothing beyond existing observation when there is no live liability; immediate repair dominates when an obligation is already breached.

**Retirement.** Do nothing beyond existing observation when there is no live liability; immediate repair dominates when an obligation is already breached. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T06; Discriminator: State the change-contingent cost mechanism, horizon and uncertainty that could reverse priority.; Hybrid failure: Endless incidental cleanup hides scope expansion; feature urgency becomes a permanent excuse to ignore a known liability.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R010, ESME-R044

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Delay must not violate present obligations or create unacceptable irreversible lock-in. What change in demand or exposure would make continued deferral indefensible? **Source IDs:** ESME-S013, ESME-S055, ESME-S058.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-060 — Visibility of future cost bearers and participation

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** COORDINATION_AND_ACCOUNTABILITY_CRITERION

**Criterion.** The decision states material shifted costs and how affected parties can act on the information.

**Operating mechanism.** Identify who gains now and who must later maintain, migrate or absorb risk; involve affected decision makers to the extent needed for legitimate trade-offs.

**Trigger.** A local benefit shifts material work or obligations to other teams, future maintainers or external consumers.

**Inputs.** Baseline artefacts: Cost allocation, support promises and affected stakeholders. A debt item links a concrete design/implementation condition to affected future work and its economic context.; Preconditions: Conditions: Relevant representatives and actual authority are available; participation does not imply unanimity.; Related property ids: ESME-001; ESME-058; ESME-066; ESME-069; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A local benefit shifts material work or obligations to other teams, future maintainers or external consumers. Define a future-change liability, not every defect, missing feature or disliked structure as technical debt.

**Produced constraints or evidence.** The decision states material shifted costs and how affected parties can act on the information.

**Consumer.** Consumer: Present and future maintainers, sponsors and downstream users.; Decision: The decision states material shifted costs and how affected parties can act on the information.

**Costs and possible harm.** Source-supported: shared responsibility is recommended, but evidence does not establish a single governance structure; workload and unpaid expectations are real constraints.

**Assumptions.** Critical assumption: Relevant representatives and actual authority are available; participation does not imply unanimity.; Discriminating question: Who pays the future cost but is absent from the current decision?

**Cheap path / omission.** A direct agreement can suffice; no universal committee or separate owner per item is required.

**Retirement.** A direct agreement can suffice; no universal committee or separate owner per item is required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T06; Discriminator: State the change-contingent cost mechanism, horizon and uncertainty that could reverse priority.; Hybrid failure: Endless incidental cleanup hides scope expansion; feature urgency becomes a permanent excuse to ignore a known liability.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R010

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Relevant representatives and actual authority are available; participation does not imply unanimity. Who pays the future cost but is absent from the current decision? **Source IDs:** ESME-S028, ESME-S058, ESME-S059, ESME-S060.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-061 — Zero technical debt as the objective

**Disposition.** REJECTED_OR_DISFAVOURED

**Kind.** UNIVERSAL_OPTIMISATION_TARGET

**Criterion.** Debt reduction is not accepted as benefit without an affected-value account.

**Operating mechanism.** Candidate requires all debt items to be eliminated irrespective of future use, opportunity cost or retirement.

**Trigger.** A programme treats the debt count as a target to drive to zero.

**Inputs.** Baseline artefacts: Debt inventory and maintenance budget. A debt item links a concrete design/implementation condition to affected future work and its economic context.; Preconditions: Conditions: Zero debt is neither clearly measurable nor demonstrated optimal.; Related property ids: ESME-056; ESME-058; ESME-059; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A programme treats the debt count as a target to drive to zero. Define a future-change liability, not every defect, missing feature or disliked structure as technical debt.

**Produced constraints or evidence.** Debt reduction is not accepted as benefit without an affected-value account.

**Consumer.** Consumer: Those needing useful current and future software.; Decision: Debt reduction is not accepted as benefit without an affected-value account.

**Costs and possible harm.** Source-supported: deliberate debt and low-interest deferral can create value; scanner issues are not all debt.

**Assumptions.** Critical assumption: Zero debt is neither clearly measurable nor demonstrated optimal.; Discriminating question: Which current obligation would be neglected to remove this low-value item?

**Cheap path / omission.** Prioritise justified liabilities and retire irrelevant ones under ESME-056–059.

**Retirement.** Prioritise justified liabilities and retire irrelevant ones under ESME-056–059. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T06; Discriminator: State the change-contingent cost mechanism, horizon and uncertainty that could reverse priority.; Hybrid failure: Endless incidental cleanup hides scope expansion; feature urgency becomes a permanent excuse to ignore a known liability.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R044

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Zero debt is neither clearly measurable nor demonstrated optimal. Which current obligation would be neglected to remove this low-value item? **Source IDs:** ESME-S027, ESME-S028, ESME-S058.

**Selection restriction.** REJECTED_OR_DISFAVOURED: Reject zero-debt optimisation, preserve explicit investment decisions. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-062 — A universal maintainability index proves future savings

**Disposition.** REJECTED_OR_DISFAVOURED

**Kind.** UNSUPPORTED_MEASUREMENT_GUARANTEE

**Criterion.** A score is identified as a proxy and does not independently certify savings.

**Operating mechanism.** Candidate treats a universal index or tool-generated principal as proof of maintenance return.

**Trigger.** A decision claims certain savings from score improvement without task evidence.

**Inputs.** Baseline artefacts: Index, scoring model and future tasks. A debt item links a concrete design/implementation condition to affected future work and its economic context.; Preconditions: Conditions: Transfer validity from metric to task cost is unproven outside demonstrated settings.; Related property ids: ESME-032; ESME-058; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A decision claims certain savings from score improvement without task evidence. Define a future-change liability, not every defect, missing feature or disliked structure as technical debt.

**Produced constraints or evidence.** A score is identified as a proxy and does not independently certify savings.

**Consumer.** Consumer: Maintainer or sponsor relying on a cost prediction.; Decision: A score is identified as a proxy and does not independently certify savings.

**Costs and possible harm.** Source-supported: refactoring metrics can be adverse; debt manifesto rejects one-size-fits-all measurement.

**Assumptions.** Critical assumption: Transfer validity from metric to task cost is unproven outside demonstrated settings.; Discriminating question: Was this score validated against the kind of maintenance work being forecast?

**Cheap path / omission.** Use actual change history, qualitative estimates or bounded experiments and disclose uncertainty.

**Retirement.** Use actual change history, qualitative estimates or bounded experiments and disclose uncertainty. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R041

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Transfer validity from metric to task cost is unproven outside demonstrated settings. Was this score validated against the kind of maintenance work being forecast? **Source IDs:** ESME-S023, ESME-S058, ESME-S057.

**Selection restriction.** REJECTED_OR_DISFAVOURED: Reject universal calibration, retain context-tested diagnostics. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-063 — Retained rationale through actual use

**Disposition.** STRONGLY_RETAINED

**Kind.** KNOWLEDGE_CONTINUITY_MECHANISM

**Criterion.** A successor can connect a relevant constraint to its reason and identify when that reason no longer holds.

**Operating mechanism.** Retain the decision-relevant reasons, alternatives and accepted limitations in a form successors can locate and test against current conditions.

**Trigger.** Loss of intent would materially obstruct future change, support or retirement.

**Inputs.** Baseline artefacts: Change rationale, baseline references and accepted trade-offs. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.; Preconditions: Conditions: The account is findable, interpretable and can be revised when evidence contradicts it.; Related property ids: ESME-004; ESME-012; ESME-015; ESME-016; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Loss of intent would materially obstruct future change, support or retirement. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Produced constraints or evidence.** A successor can connect a relevant constraint to its reason and identify when that reason no longer holds.

**Consumer.** Consumer: Future maintainer, operator or downstream decision maker.; Decision: A successor can connect a relevant constraint to its reason and identify when that reason no longer holds.

**Costs and possible harm.** Source-supported: human expertise exceeds documentation, so retained text is necessary only where useful and never sufficient by itself.

**Assumptions.** Critical assumption: The account is findable, interpretable and can be revised when evidence contradicts it.; Discriminating question: Can the next maintainer tell whether this old constraint is still justified?

**Cheap path / omission.** An adjacent comment, issue or concise handover may suffice; do not duplicate rationale in unconsumed documents.

**Retirement.** An adjacent comment, issue or concise handover may suffice; do not duplicate rationale in unconsumed documents. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T02; Discriminator: Compare demonstrated next-change capability and total transition cost, not complexity score alone.; Hybrid failure: Long-lived mixed styles and half-transferred knowledge make both old and new harder to understand.; Tension id: ESME-T08; Discriminator: Ask what future consumer must actually be able to do: retrieve, interpret, execute or receive service.; Hybrid failure: An archive is advertised as runnable despite missing dependencies, or an obsolete service is kept live without a support purpose.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R023, ESME-R049, ESME-R050

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. The account is findable, interpretable and can be revised when evidence contradicts it. Can the next maintainer tell whether this old constraint is still justified? **Source IDs:** ESME-S014, ESME-S016, ESME-S019, ESME-S041, ESME-S058.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-064 — Knowledge succession and demonstrated onboarding

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** HUMAN_CONTINUITY_MECHANISM

**Criterion.** A successor can carry out representative supported work or the remaining limitation is explicit.

**Operating mechanism.** Transfer practical ability through explanation, paired or supervised tasks and accessible artefacts; check that a successor can perform the relevant maintenance work.

**Trigger.** Departure, concentration, growth or a new support obligation makes continuity vulnerable.

**Inputs.** Baseline artefacts: People, task knowledge, access, artefacts and support responsibilities. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.; Preconditions: Conditions: Successors have time, access, willingness and opportunities to practise; names on a roster are insufficient.; Related property ids: ESME-012; ESME-063; ESME-066; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Departure, concentration, growth or a new support obligation makes continuity vulnerable. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Produced constraints or evidence.** A successor can carry out representative supported work or the remaining limitation is explicit.

**Consumer.** Consumer: Outgoing/incoming maintainers and supported users.; Decision: A successor can carry out representative supported work or the remaining limitation is explicit.

**Costs and possible harm.** Source-supported: truck-factor estimates have partial validation; successful-maintainer interviews are selected and do not prove one onboarding procedure.

**Assumptions.** Critical assumption: Successors have time, access, willingness and opportunities to practise; names on a roster are insufficient.; Discriminating question: What representative task demonstrates that knowledge has actually transferred?

**Cheap path / omission.** A small stable project may need a clear support/retirement policy rather than recruiting multiple maintainers.

**Retirement.** A small stable project may need a clear support/retirement policy rather than recruiting multiple maintainers. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T02; Discriminator: Compare demonstrated next-change capability and total transition cost, not complexity score alone.; Hybrid failure: Long-lived mixed styles and half-transferred knowledge make both old and new harder to understand.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R023, ESME-R045, ESME-R047, ESME-R050

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Successors have time, access, willingness and opportunities to practise; names on a roster are insufficient. What representative task demonstrates that knowledge has actually transferred? **Source IDs:** ESME-S013, ESME-S016, ESME-S032, ESME-S059.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-065 — Scoped ownership and change coordination

**Disposition.** CONTEXT_DEPENDENT

**Kind.** AUTHORITY_AND_COORDINATION_MECHANISM

**Criterion.** A relevant request or conflict can reach someone able and authorised to decide or explicitly decline.

**Operating mechanism.** Make responsibility and decision rights clear enough to resolve overlapping changes and support requests without assuming exclusive code ownership.

**Trigger.** Multiple contributors or support paths create ambiguity about acceptance, review or incident response.

**Inputs.** Baseline artefacts: Change requests, affected components and decision responsibilities. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.; Preconditions: Conditions: Stated responsibility matches actual access, capability and agreed support commitments.; Related property ids: ESME-001; ESME-027; ESME-064; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Multiple contributors or support paths create ambiguity about acceptance, review or incident response. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Produced constraints or evidence.** A relevant request or conflict can reach someone able and authorised to decide or explicitly decline.

**Consumer.** Consumer: Contributors, maintainers and downstream users seeking a decision.; Decision: A relevant request or conflict can reach someone able and authorised to decide or explicitly decline.

**Costs and possible harm.** Source-supported: authorship is not complete competence; maintainer success involves communication beyond technical gatekeeping.

**Assumptions.** Critical assumption: Stated responsibility matches actual access, capability and agreed support commitments.; Discriminating question: Who can decide this change, and who can actually carry it out or decline support?

**Cheap path / omission.** One maintainer can hold several roles; collaborative ownership is adequate when responsibility remains actionable.

**Retirement.** One maintainer can hold several roles; collaborative ownership is adequate when responsibility remains actionable. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R023

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Stated responsibility matches actual access, capability and agreed support commitments. Who can decide this change, and who can actually carry it out or decline support? **Source IDs:** ESME-S019, ESME-S041, ESME-S059, ESME-S032, ESME-S060.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-066 — Finite maintainer capacity and realistic support commitments

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** RESOURCE_AND_CONTINUITY_CRITERION

**Criterion.** Support expectations match an actionable capacity plan or clearly announced limitation.

**Operating mechanism.** Align promised support, intake and update obligations with available willing capacity; negotiate reduced scope, sponsorship, transfer or retirement when infeasible.

**Trigger.** Demand, dependency obligations or turnover exceed sustainable support capability.

**Inputs.** Baseline artefacts: Support promises, workload, available people and tooling. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.; Preconditions: Conditions: Capacity claims include review and coordination, not only code production; willingness is not implied by public code.; Related property ids: ESME-010; ESME-060; ESME-064; ESME-069; ESME-071; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Demand, dependency obligations or turnover exceed sustainable support capability. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Produced constraints or evidence.** Support expectations match an actionable capacity plan or clearly announced limitation.

**Consumer.** Consumer: Maintainers, users relying on support and potential sponsors/successors.; Decision: Support expectations match an actionable capacity plan or clearly announced limitation.

**Costs and possible harm.** Source-supported: mixed-methods studies report support barriers; automation’s net time effect depends on task and tools.

**Assumptions.** Critical assumption: Capacity claims include review and coordination, not only code production; willingness is not implied by public code.; Discriminating question: Which current promise cannot be met with the available people, authority and time?

**Cheap path / omission.** Reduce nonessential scope or state a limited support policy rather than add complex automation by default.

**Retirement.** Reduce nonessential scope or state a limited support policy rather than add complex automation by default. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T07; Discriminator: Determine real promises, capacity and transition feasibility; usage popularity is neither permission nor an infinite support contract.; Hybrid failure: Dates are announced without a viable path, or compatibility branches multiply beyond capacity.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R010, ESME-R023, ESME-R025, ESME-R034, ESME-R045

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Capacity claims include review and coordination, not only code production; willingness is not implied by public code. Which current promise cannot be met with the available people, authority and time? **Source IDs:** ESME-S013, ESME-S059, ESME-S060, ESME-S036, ESME-S037.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-067 — Knowledge-concentration metrics as fallible prompts

**Disposition.** USEFUL_BUT_EASILY_GAMED

**Kind.** MEASUREMENT_PROXY

**Criterion.** The estimate is accompanied by checks of actual capability and omitted knowledge.

**Operating mechanism.** Use the estimate to ask who can actually support critical work; verify with maintainers rather than treating a computed number as a failure probability.

**Trigger.** A project needs to assess continuity and history can offer a useful first approximation.

**Inputs.** Baseline artefacts: Commit history, authorship assumptions and demonstrated expertise. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.; Preconditions: Conditions: Authorship mapping represents some relevant knowledge; uncommitted, operational and domain expertise remain unmeasured.; Related property ids: ESME-064; ESME-066; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A project needs to assess continuity and history can offer a useful first approximation. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Produced constraints or evidence.** The estimate is accompanied by checks of actual capability and omitted knowledge.

**Consumer.** Consumer: Maintainers and support planners.; Decision: The estimate is accompanied by checks of actual capability and omitted knowledge.

**Costs and possible harm.** Source-supported: participant validation differs substantially for authorship and inferred truck factor.

**Assumptions.** Critical assumption: Authorship mapping represents some relevant knowledge; uncommitted, operational and domain expertise remain unmeasured.; Discriminating question: Who knows the system despite low commit authorship, or commits without transferable understanding?

**Cheap path / omission.** Ask maintainers directly or exercise a handover when feasible; no metric is required.

**Retirement.** Ask maintainers directly or exercise a handover when feasible; no metric is required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R045

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Authorship mapping represents some relevant knowledge; uncommitted, operational and domain expertise remain unmeasured. Who knows the system despite low commit authorship, or commits without transferable understanding? **Source IDs:** ESME-S032, ESME-S016.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-068 — Dependency inventory and update trade-offs

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** ECOSYSTEM_MAINTENANCE_MECHANISM

**Criterion.** A consequential dependency change has a justified action or deferral and an explicit support/compatibility account.

**Operating mechanism.** Identify supported dependency versions and consequential transitive reliance; assess update, pinning, substitution or retirement against actual compatibility and support needs.

**Trigger.** A dependency changes, loses support or creates a relevant defect/security obligation.

**Inputs.** Baseline artefacts: Dependency manifests, resolved versions, support status and affected uses. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.; Preconditions: Conditions: Inventory reflects actual resolution and relevant use; a graph edge is not itself a live failure.; Related property ids: ESME-021; ESME-025; ESME-066; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A dependency changes, loses support or creates a relevant defect/security obligation. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Produced constraints or evidence.** A consequential dependency change has a justified action or deferral and an explicit support/compatibility account.

**Consumer.** Consumer: Upstream/downstream maintainers and operators.; Decision: A consequential dependency change has a justified action or deferral and an explicit support/compatibility account.

**Costs and possible harm.** Source-supported: network exposure is not failure frequency; notifications and automatic updates can increase burden.

**Assumptions.** Critical assumption: Inventory reflects actual resolution and relevant use; a graph edge is not itself a live failure.; Discriminating question: Which used dependency lacks a credible support or transition path, and what actual exposure follows?

**Cheap path / omission.** Use a small explicit dependency list and targeted check for a bounded artefact; no ecosystem-wide graph is inherently necessary.

**Retirement.** Use a small explicit dependency list and targeted check for a bounded artefact; no ecosystem-wide graph is inherently necessary. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T07; Discriminator: Determine real promises, capacity and transition feasibility; usage popularity is neither permission nor an infinite support contract.; Hybrid failure: Dates are announced without a viable path, or compatibility branches multiply beyond capacity.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R024, ESME-R025, ESME-R045

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Inventory reflects actual resolution and relevant use; a graph edge is not itself a live failure. Which used dependency lacks a credible support or transition path, and what actual exposure follows? **Source IDs:** ESME-S019, ESME-S033, ESME-S060, ESME-S024.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-069 — Downstream communication that enables action

**Disposition.** STRONGLY_RETAINED

**Kind.** COMMUNICATION_AND_COORDINATION_MECHANISM

**Criterion.** Consequential consumers have usable transition information and unresolved reliance is visible.

**Operating mechanism.** Send the scope, timing, supported alternatives and required action to relevant consumers through an effective channel; check critical dependencies rather than assuming broadcast receipt.

**Trigger.** A change affects consumer obligations, compatibility, support or availability.

**Inputs.** Baseline artefacts: Release notes, support policy, client dependencies and transition instructions. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.; Preconditions: Conditions: The recipient can understand and act; publication alone may be insufficient for critical commitments.; Related property ids: ESME-001; ESME-025; ESME-060; ESME-066; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A change affects consumer obligations, compatibility, support or availability. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Produced constraints or evidence.** Consequential consumers have usable transition information and unresolved reliance is visible.

**Consumer.** Consumer: Downstream maintainers and users able to adapt or contest the change.; Decision: Consequential consumers have usable transition information and unresolved reliance is visible.

**Costs and possible harm.** Source-supported: HTTP hints do not guarantee receipt, authenticity or migration; notification overload can defeat communication.

**Assumptions.** Critical assumption: The recipient can understand and act; publication alone may be insufficient for critical commitments.; Discriminating question: What can the affected consumer actually do with this notice before the change occurs?

**Cheap path / omission.** A direct agreement with the sole consumer may suffice; no broad notice is needed for a truly private effect.

**Retirement.** A direct agreement with the sole consumer may suffice; no broad notice is needed for a truly private effect. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T01; Discriminator: Identify the actual obligation, consumer and authorisation for revision; unresolved authority blocks that revision, not unrelated work.; Hybrid failure: Two ambiguous meanings, unmaintained compatibility mode, or an oracle changed solely to pass.; Tension id: ESME-T07; Discriminator: Determine real promises, capacity and transition feasibility; usage popularity is neither permission nor an infinite support contract.; Hybrid failure: Dates are announced without a viable path, or compatibility branches multiply beyond capacity.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R017, ESME-R023, ESME-R024, ESME-R025, ESME-R033

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. The recipient can understand and act; publication alone may be insufficient for critical commitments. What can the affected consumer actually do with this notice before the change occurs? **Source IDs:** ESME-S021, ESME-S041, ESME-S053, ESME-S054, ESME-S060.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-070 — Deprecation signalling separated from shutdown

**Disposition.** DOMAIN_SPECIFIC

**Kind.** PROTOCOL_AND_POLICY_MECHANISM

**Criterion.** The announced state and implications are unambiguous to the intended consumer.

**Operating mechanism.** Declare the local meaning and support effect of deprecation, distinguishing discouraged use, changed guarantees, end of support and service termination.

**Trigger.** An interface or service is being superseded, losing guarantees or approaching shutdown.

**Inputs.** Baseline artefacts: Resource, API version, support policy, deprecation date and possible sunset date. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.; Preconditions: Conditions: Dates, scope and authoritative documentation agree; a signal is not itself a migration plan.; Related property ids: ESME-025; ESME-069; ESME-071; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: An interface or service is being superseded, losing guarantees or approaching shutdown. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Produced constraints or evidence.** The announced state and implications are unambiguous to the intended consumer.

**Consumer.** Consumer: Client developers and supported users.; Decision: The announced state and implications are unambiguous to the intended consumer.

**Costs and possible harm.** Source-supported: the two RFCs deliberately signal different transitions; the same word in archival guidance has another meaning.

**Assumptions.** Critical assumption: Dates, scope and authoritative documentation agree; a signal is not itself a migration plan.; Discriminating question: Does this announcement change recommendation, support, behaviour, availability, or several of them?

**Cheap path / omission.** A documented support statement may suffice outside HTTP; no header is required where it has no consumer.

**Retirement.** A documented support statement may suffice outside HTTP; no header is required where it has no consumer. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T07; Discriminator: Determine real promises, capacity and transition feasibility; usage popularity is neither permission nor an infinite support contract.; Hybrid failure: Dates are announced without a viable path, or compatibility branches multiply beyond capacity.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R017, ESME-R024

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Dates, scope and authoritative documentation agree; a signal is not itself a migration plan. Does this announcement change recommendation, support, behaviour, availability, or several of them? **Source IDs:** ESME-S053, ESME-S054, ESME-S055.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-071 — Responsible retirement with discharged obligations

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** LIFECYCLE_TERMINATION_MECHANISM

**Criterion.** Operational termination and surviving preservation/support arrangements are evidenced separately.

**Operating mechanism.** Identify remaining users, data, support and archival obligations; authorise termination and verify the intended services/routes actually close while agreed retained assets remain usable.

**Trigger.** The software is no longer useful, supportable or justified relative to alternatives.

**Inputs.** Baseline artefacts: Service endpoints, users, data, credentials/access, support promises and retained records. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.; Preconditions: Conditions: Authority to terminate and resolve surviving obligations must be established; jurisdiction-specific legal duties require separate expertise.; Related property ids: ESME-052; ESME-066; ESME-069; ESME-072; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: The software is no longer useful, supportable or justified relative to alternatives. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Produced constraints or evidence.** Operational termination and surviving preservation/support arrangements are evidenced separately.

**Consumer.** Consumer: Remaining consumers, maintainers and authorised custodians.; Decision: Operational termination and surviving preservation/support arrangements are evidenced separately.

**Costs and possible harm.** Analytical limits grounded in guidance: archival success does not prove all consumer needs discharged; over-retention creates ongoing cost.

**Assumptions.** Critical assumption: Authority to terminate and resolve surviving obligations must be established; jurisdiction-specific legal duties require separate expertise.; Discriminating question: Which obligation survives shutdown, and what evidence shows it has a viable custodian or is legitimately ended?

**Cheap path / omission.** Continue a stable low-cost service when retirement would strand justified obligations; close simple unused artefacts with proportionate checks.

**Retirement.** Continue a stable low-cost service when retirement would strand justified obligations; close simple unused artefacts with proportionate checks. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T07; Discriminator: Determine real promises, capacity and transition feasibility; usage popularity is neither permission nor an infinite support contract.; Hybrid failure: Dates are announced without a viable path, or compatibility branches multiply beyond capacity.; Tension id: ESME-T08; Discriminator: Ask what future consumer must actually be able to do: retrieve, interpret, execute or receive service.; Hybrid failure: An archive is advertised as runnable despite missing dependencies, or an obsolete service is kept live without a support purpose.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R010, ESME-R017, ESME-R025, ESME-R033

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Authority to terminate and resolve surviving obligations must be established; jurisdiction-specific legal duties require separate expertise. Which obligation survives shutdown, and what evidence shows it has a viable custodian or is legitimately ended? **Source IDs:** ESME-S013, ESME-S041, ESME-S053, ESME-S055, ESME-S056, ESME-S062.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-072 — Purpose-bounded archival preservation and reproducibility

**Disposition.** CONTEXT_DEPENDENT

**Kind.** PRESERVATION_MECHANISM

**Criterion.** The specified historical object can be retrieved or relevant execution reproduced within stated limitations.

**Operating mechanism.** Choose what must remain retrievable or executable for a declared purpose and horizon, and verify the relevant retrieval/reproduction capability.

**Trigger.** Historical analysis, compliance, research reproduction or future revival justifies retained artefacts after active use.

**Inputs.** Baseline artefacts: Source, dependencies, documentation, data rights and optional executable environment. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.; Preconditions: Conditions: Retained rights, identifiers, storage and environment assumptions support the intended use.; Related property ids: ESME-004; ESME-041; ESME-063; ESME-071; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Historical analysis, compliance, research reproduction or future revival justifies retained artefacts after active use. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Produced constraints or evidence.** The specified historical object can be retrieved or relevant execution reproduced within stated limitations.

**Consumer.** Consumer: Future researcher, maintainer or custodian with a concrete use.; Decision: The specified historical object can be retrieved or relevant execution reproduced within stated limitations.

**Costs and possible harm.** Source-supported: source archival guide is version-specific; reproducible packaging has environment limits. Analytical: data rights may constrain retention.

**Assumptions.** Critical assumption: Retained rights, identifiers, storage and environment assumptions support the intended use.; Discriminating question: Does the future consumer need source identity, semantic context, a runnable environment, or an operating service?

**Cheap path / omission.** Retain a source snapshot and rationale when execution is unnecessary; avoid indefinitely operating a service solely to preserve history.

**Retirement.** Retain a source snapshot and rationale when execution is unnecessary; avoid indefinitely operating a service solely to preserve history. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T08; Discriminator: Ask what future consumer must actually be able to do: retrieve, interpret, execute or receive service.; Hybrid failure: An archive is advertised as runnable despite missing dependencies, or an obsolete service is kept live without a support purpose.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R017

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Retained rights, identifiers, storage and environment assumptions support the intended use. Does the future consumer need source identity, semantic context, a runnable environment, or an operating service? **Source IDs:** ESME-S055, ESME-S056, ESME-S052.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-073 — Popularity guarantees dependency continuity

**Disposition.** REJECTED_OR_DISFAVOURED

**Kind.** UNSUPPORTED_ECOSYSTEM_PROXY

**Criterion.** Continuity claims use actual support evidence rather than download counts alone.

**Operating mechanism.** Candidate assumes a widely used package cannot lose maintainers or support.

**Trigger.** A dependency is accepted without continuity consideration because many projects use it.

**Inputs.** Baseline artefacts: Package popularity, dependency reach and maintainer capacity. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.; Preconditions: Conditions: No implication from usage count to willingness, funding, competence or succession is established.; Related property ids: ESME-064; ESME-066; ESME-068; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A dependency is accepted without continuity consideration because many projects use it. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Produced constraints or evidence.** Continuity claims use actual support evidence rather than download counts alone.

**Consumer.** Consumer: Downstream users and upstream maintainers.; Decision: Continuity claims use actual support evidence rather than download counts alone.

**Costs and possible harm.** Source-supported: concentration and maintainer support barriers coexist with public OSS success; graph centrality does not measure human resilience.

**Assumptions.** Critical assumption: No implication from usage count to willingness, funding, competence or succession is established.; Discriminating question: Who will do the work if the present maintainer leaves, regardless of download count?

**Cheap path / omission.** Check actual support/capacity and feasible alternatives under ESME-066 and 068.

**Retirement.** Check actual support/capacity and feasible alternatives under ESME-066 and 068. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R045

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. No implication from usage count to willingness, funding, competence or succession is established. Who will do the work if the present maintainer leaves, regardless of download count? **Source IDs:** ESME-S032, ESME-S033, ESME-S059, ESME-S060.

**Selection restriction.** REJECTED_OR_DISFAVOURED: Reject popularity-as-assurance, retain it as exposure information. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-074 — Stable useful software may justify no change

**Disposition.** STRONGLY_RETAINED

**Kind.** NON_INTERVENTION_BRANCH

**Criterion.** A no-change decision states why obligations remain met and what evidence would prompt reconsideration.

**Operating mechanism.** Choose continued unchanged operation where current obligations, support conditions and expected value do not justify intervention; keep only relevant observation triggers.

**Trigger.** No demonstrated defect, adaptation need or investment opportunity outweighs change risk and cost.

**Inputs.** Baseline artefacts: Current capability, support horizon and environmental assumptions. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.; Preconditions: Conditions: The environment and obligations remain sufficiently stable; no ignored known breach exists.; Related property ids: ESME-007; ESME-046; ESME-059; ESME-066; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: No demonstrated defect, adaptation need or investment opportunity outweighs change risk and cost. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Produced constraints or evidence.** A no-change decision states why obligations remain met and what evidence would prompt reconsideration.

**Consumer.** Consumer: Current users and maintainers.; Decision: A no-change decision states why obligations remain met and what evidence would prompt reconsideration.

**Costs and possible harm.** Analytical deduction from scoped evolution and lifecycle economics: unchanged code can still become unfit if environment or support changes.

**Assumptions.** Critical assumption: The environment and obligations remain sufficiently stable; no ignored known breach exists.; Discriminating question: What concrete obligation or expected benefit warrants disturbing the current useful state?

**Cheap path / omission.** This is the cheap path itself; review existing signals rather than create permanent change machinery.

**Retirement.** This is the cheap path itself; review existing signals rather than create permanent change machinery. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R003, ESME-R010, ESME-R025, ESME-R034, ESME-R038

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. The environment and obligations remain sufficiently stable; no ignored known breach exists. What concrete obligation or expected benefit warrants disturbing the current useful state? **Source IDs:** ESME-S009, ESME-S013, ESME-S055, ESME-S058, ESME-S008, ESME-S029.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-075 — Transition to servicing is effectively irreversible

**Disposition.** CONTESTED

**Kind.** STAGE_MODEL_HYPOTHESIS

**Criterion.** The practical feasibility of renewed evolution is investigated, not decided solely by a lifecycle diagram.

**Operating mechanism.** Use servicing-stage diagnosis to examine remaining comprehension and evolution capacity, but do not infer impossibility from the label.

**Trigger.** A long-lived system can receive patches but no longer support broad justified evolution economically.

**Inputs.** Baseline artefacts: Remaining expertise, recoverable design knowledge and feasible change classes. People, ownership, documentation, dependency graphs, support policies, releases and archives all matter.; Preconditions: Conditions: The relevant knowledge/cost loss must be demonstrated; capability recovery is not ruled out a priori.; Related property ids: ESME-012; ESME-015; ESME-047; ESME-064; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A long-lived system can receive patches but no longer support broad justified evolution economically. Maintain viable knowledge and support for justified obligations; permit explicit reduction or termination of support.

**Produced constraints or evidence.** The practical feasibility of renewed evolution is investigated, not decided solely by a lifecycle diagram.

**Consumer.** Consumer: Maintainers and those choosing investment or retirement.; Decision: The practical feasibility of renewed evolution is investigated, not decided solely by a lifecycle diagram.

**Costs and possible harm.** Source-supported conceptual claim is stronger than available universal evidence; recovery methods make irreversibility contingent, not automatically refuted.

**Assumptions.** Critical assumption: The relevant knowledge/cost loss must be demonstrated; capability recovery is not ruled out a priori.; Discriminating question: Can a bounded recovery effort restore the needed change capability at acceptable cost?

**Cheap path / omission.** Assess actual knowledge recovery and replacement choices rather than require a stage label.

**Retirement.** Assess actual knowledge recovery and replacement choices rather than require a stage label. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R047

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. The relevant knowledge/cost loss must be demonstrated; capability recovery is not ruled out a priori. Can a bounded recovery effort restore the needed change capability at acceptable cost? **Source IDs:** ESME-S013, ESME-S014, ESME-S016, ESME-S044.

**Selection restriction.** CONTESTED: Still contested as a general claim; retain a local hypothesis to test with recovery cost and demonstrated tasks. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-076 — Generated patches remain candidates for justified repair

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** AUTOMATION_ACCEPTANCE_CRITERION

**Criterion.** Accepted claims identify repaired obligations and residual uncertainty; unsupported additions are removed or authorised.

**Operating mechanism.** Treat the patch as a candidate; check intended repair, preservation, unsupported changes and uncertainty before acceptance.

**Trigger.** A repair or evolution suggestion is generated by a search system, model or agent.

**Inputs.** Baseline artefacts: Generated diff, issue interpretation, tests, harness and environment. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.; Preconditions: Conditions: The objective is legitimate and validation is not solely the generator’s own assertion.; Related property ids: ESME-001; ESME-035; ESME-077; ESME-079; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A repair or evolution suggestion is generated by a search system, model or agent. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Produced constraints or evidence.** Accepted claims identify repaired obligations and residual uncertainty; unsupported additions are removed or authorised.

**Consumer.** Consumer: Maintainer accepting the repair and affected consumers.; Decision: Accepted claims identify repaired obligations and residual uncertainty; unsupported additions are removed or authorised.

**Costs and possible harm.** Source-supported: both classical and LLM repair show oracle/harness and requirement weaknesses.

**Assumptions.** Critical assumption: The objective is legitimate and validation is not solely the generator’s own assertion.; Discriminating question: Which part of this patch is unsupported by the requested change or preservation evidence?

**Cheap path / omission.** A direct human correction may dominate; use the same substantive obligations regardless of who authored the patch.

**Retirement.** A direct human correction may dominate; use the same substantive obligations regardless of who authored the patch. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T04; Discriminator: Compare accepted outcomes and total work, including later repair, on representative tasks under versioned settings.; Hybrid failure: Several tools share one invalid oracle, or the human rubber-stamps unreviewable volume.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R026, ESME-R027, ESME-R046, ESME-R048

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. The objective is legitimate and validation is not solely the generator’s own assertion. Which part of this patch is unsupported by the requested change or preservation evidence? **Source IDs:** ESME-S034, ESME-S035, ESME-S063, ESME-S064.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-077 — Validation of the evaluation harness itself

**Disposition.** STRONGLY_RETAINED

**Kind.** EVIDENCE_PRODUCTION_ASSURANCE

**Criterion.** The harness distinguishes relevant known pass/fail controls and binds results to the intended artefact.

**Operating mechanism.** Check that tests actually execute against the intended version, inputs and result criteria; challenge known failure/success controls and broken dependency assumptions.

**Trigger.** A harness is new, changed, migrated or relied on for a consequential acceptance claim.

**Inputs.** Baseline artefacts: Execution harness, environment, selected tests, exit conditions and recorded results. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.; Preconditions: Conditions: Observability includes test execution and failures, not merely process completion.; Related property ids: ESME-004; ESME-024; ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A harness is new, changed, migrated or relied on for a consequential acceptance claim. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Produced constraints or evidence.** The harness distinguishes relevant known pass/fail controls and binds results to the intended artefact.

**Consumer.** Consumer: Reviewer interpreting evidence rather than trusting its producer.; Decision: The harness distinguishes relevant known pass/fail controls and binds results to the intended artefact.

**Costs and possible harm.** Source-supported: APR reanalysis and RTSCheck found faulty evaluation/selection behaviour; even reproducibility tooling needed corrections.

**Assumptions.** Critical assumption: Observability includes test execution and failures, not merely process completion.; Discriminating question: Could a skipped test, stale binary or harness exception still produce this reported pass?

**Cheap path / omission.** A simple transparent command with known checks may need only a small sanity test rather than a framework audit.

**Retirement.** A simple transparent command with known checks may need only a small sanity test rather than a framework audit. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T04; Discriminator: Compare accepted outcomes and total work, including later repair, on representative tasks under versioned settings.; Hybrid failure: Several tools share one invalid oracle, or the human rubber-stamps unreviewable volume.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R020, ESME-R026, ESME-R046

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Observability includes test execution and failures, not merely process completion. Could a skipped test, stale binary or harness exception still produce this reported pass? **Source IDs:** ESME-S024, ESME-S034, ESME-S035, ESME-S052, ESME-S063.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-078 — Benchmark provenance and contamination limits

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** EVALUATION_VALIDITY_CRITERION

**Criterion.** Evaluation conclusions distinguish the observed benchmark result from uncertain transfer and contamination.

**Operating mechanism.** Record task provenance, temporal/version scope, possible training exposure and test-oracle limits; avoid treating repeated benchmark scores as independent evidence of unseen maintenance ability.

**Trigger.** Benchmark results justify deployment claims or compare automation approaches.

**Inputs.** Baseline artefacts: Benchmark tasks, public history, model versions and evaluation settings. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.; Preconditions: Conditions: Exposure cannot generally be exhaustively audited; independence and held-out status require evidence.; Related property ids: ESME-076; ESME-077; ESME-080; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Benchmark results justify deployment claims or compare automation approaches. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Produced constraints or evidence.** Evaluation conclusions distinguish the observed benchmark result from uncertain transfer and contamination.

**Consumer.** Consumer: Researchers and maintainers deciding transfer from benchmark to practice.; Decision: Evaluation conclusions distinguish the observed benchmark result from uncertain transfer and contamination.

**Costs and possible harm.** Source-supported: selected-task contamination probes and issue/PR audits reveal validity problems; selected samples do not estimate universal prevalence.

**Assumptions.** Critical assumption: Exposure cannot generally be exhaustively audited; independence and held-out status require evidence.; Discriminating question: What establishes that this score reflects the kind of unseen task and workflow at issue?

**Cheap path / omission.** Use a bounded private or newly authored representative task evaluation where feasible; disclose limits rather than invent clean provenance.

**Retirement.** Use a bounded private or newly authored representative task evaluation where feasible; disclose limits rather than invent clean provenance. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R027, ESME-R046

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Exposure cannot generally be exhaustively audited; independence and held-out status require evidence. What establishes that this score reflects the kind of unseen task and workflow at issue? **Source IDs:** ESME-S035, ESME-S063, ESME-S064, ESME-S065.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-079 — Issue, reference patch and test objective alignment

**Disposition.** STRONGLY_RETAINED

**Kind.** ORACLE_AND_INTENT_VALIDATION

**Criterion.** Differences are classified as required, permitted, irrelevant, erroneous or unresolved with reasons.

**Operating mechanism.** Compare the stated requirement, reference change and acceptance tests; adjudicate mismatches before using them to judge another implementation.

**Trigger.** Generated repair, benchmark construction or legacy acceptance relies on a reference patch as expected truth.

**Inputs.** Baseline artefacts: Issue statement, reference PR, changed tests and alternative patches. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.; Preconditions: Conditions: Access to enough intent and relevant baseline is needed; otherwise preserve uncertainty.; Related property ids: ESME-001; ESME-034; ESME-035; ESME-039; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Generated repair, benchmark construction or legacy acceptance relies on a reference patch as expected truth. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Produced constraints or evidence.** Differences are classified as required, permitted, irrelevant, erroneous or unresolved with reasons.

**Consumer.** Consumer: Legitimate requester/maintainer, not an automatically privileged reference implementation.; Decision: Differences are classified as required, permitted, irrelevant, erroneous or unresolved with reasons.

**Costs and possible harm.** Source-supported: 2026 misalignment and correctness studies find genuine ambiguity; author consensus is not universal ground truth.

**Assumptions.** Critical assumption: Access to enough intent and relevant baseline is needed; otherwise preserve uncertainty.; Discriminating question: Which test expectation is justified by the requirement rather than merely copied from the reference patch?

**Cheap path / omission.** A precise issue and focused test can suffice; no LLM checker is inherently required.

**Retirement.** A precise issue and focused test can suffice; no LLM checker is inherently required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T04; Discriminator: Compare accepted outcomes and total work, including later repair, on representative tasks under versioned settings.; Hybrid failure: Several tools share one invalid oracle, or the human rubber-stamps unreviewable volume.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R018, ESME-R027, ESME-R035, ESME-R042, ESME-R046

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Access to enough intent and relevant baseline is needed; otherwise preserve uncertainty. Which test expectation is justified by the requirement rather than merely copied from the reference patch? **Source IDs:** ESME-S035, ESME-S063, ESME-S064.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-080 — Total human–automation workflow cost

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** EMPIRICAL_SELECTION_CRITERION

**Criterion.** The benefit claim includes relevant total work and uncertainty rather than generation speed alone.

**Operating mechanism.** Measure the end-to-end effort, latency, quality and resource costs relevant to the actual workflow against credible human/tool-assisted alternatives.

**Trigger.** Automation adoption is justified as saving maintenance effort or increasing useful output.

**Inputs.** Baseline artefacts: Human tasks, model calls, review effort, compute and accepted outcomes. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.; Preconditions: Conditions: Task selection, experience, tooling, concurrency and quality standards are comparable.; Related property ids: ESME-058; ESME-066; ESME-076; ESME-078; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Automation adoption is justified as saving maintenance effort or increasing useful output. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Produced constraints or evidence.** The benefit claim includes relevant total work and uncertainty rather than generation speed alone.

**Consumer.** Consumer: Maintainers and sponsors bearing both visible and shifted costs.; Decision: The benefit claim includes relevant total work and uncertainty rather than generation speed alone.

**Costs and possible harm.** Source-supported: 2025 randomised expert study found slower work; 2026 follow-up was judged unreliable due to selection/measurement, not a settled reversal.

**Assumptions.** Critical assumption: Task selection, experience, tooling, concurrency and quality standards are comparable.; Discriminating question: Which effort disappears from the metric but still has to be performed by someone?

**Cheap path / omission.** A small representative paired trial or observed task sample may suffice; no grand benchmark is required.

**Retirement.** A small representative paired trial or observed task sample may suffice; no grand benchmark is required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T04; Discriminator: Compare accepted outcomes and total work, including later repair, on representative tasks under versioned settings.; Hybrid failure: Several tools share one invalid oracle, or the human rubber-stamps unreviewable volume.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R027, ESME-R046, ESME-R048

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Task selection, experience, tooling, concurrency and quality standards are comparable. Which effort disappears from the metric but still has to be performed by someone? **Source IDs:** ESME-S036, ESME-S037, ESME-S039, ESME-S063, ESME-S064.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-081 — Version-bound automation evidence and revalidation

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** EVIDENCE_MAINTENANCE_MECHANISM

**Criterion.** Reused evidence states why its assumptions still hold; affected claims are revalidated or narrowed.

**Operating mechanism.** Bind automation evidence to the model/tool, configuration, prompts, hardware and task envelope; recheck changed assumptions before reusing the claim.

**Trigger.** A model, engine, prompt strategy, hardware or evaluation context changes in a way relevant to prior evidence.

**Inputs.** Baseline artefacts: Automation configuration and supporting evaluation evidence. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.; Preconditions: Conditions: Version identity and affected assumptions are observable.; Related property ids: ESME-004; ESME-030; ESME-077; ESME-080; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A model, engine, prompt strategy, hardware or evaluation context changes in a way relevant to prior evidence. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Produced constraints or evidence.** Reused evidence states why its assumptions still hold; affected claims are revalidated or narrowed.

**Consumer.** Consumer: Maintainer relying on the tool’s prior effectiveness or preservation claims.; Decision: Reused evidence states why its assumptions still hold; affected claims are revalidated or narrowed.

**Costs and possible harm.** Source-supported: prompt effects age and quantisation has nontrivial trade-offs; accepted 2026 preprints are not long-term replications.

**Assumptions.** Critical assumption: Version identity and affected assumptions are observable.; Discriminating question: Which previously valid claim depends on an assumption changed by this upgrade?

**Cheap path / omission.** Do not rerun everything for an irrelevant metadata change; use targeted revalidation of affected claims.

**Retirement.** Do not rerun everything for an irrelevant metadata change; use targeted revalidation of affected claims. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T04; Discriminator: Compare accepted outcomes and total work, including later repair, on representative tasks under versioned settings.; Hybrid failure: Several tools share one invalid oracle, or the human rubber-stamps unreviewable volume.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R027, ESME-R028, ESME-R031, ESME-R046

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Version identity and affected assumptions are observable. Which previously valid claim depends on an assumption changed by this upgrade? **Source IDs:** ESME-S038, ESME-S039, ESME-S045, ESME-S037.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-082 — Repair automation resource trade-offs

**Disposition.** DOMAIN_SPECIFIC

**Kind.** RESOURCE_SELECTION_CRITERION

**Criterion.** The chosen configuration meets the stated resource and validated outcome constraints.

**Operating mechanism.** Choose model/quantisation settings by relevant repair quality and measured total resource constraints, not parameter count or aggregate success alone.

**Trigger.** Resource-limited repair automation makes memory, energy or time consequential.

**Inputs.** Baseline artefacts: Model, quantisation, hardware, repair instances and resource measurements. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.; Preconditions: Conditions: Measurements use the intended hardware/workload; plausible patch counts are not correctness evidence.; Related property ids: ESME-076; ESME-080; ESME-081; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Resource-limited repair automation makes memory, energy or time consequential. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Produced constraints or evidence.** The chosen configuration meets the stated resource and validated outcome constraints.

**Consumer.** Consumer: Maintainer/operator constrained by compute and accepted repair quality.; Decision: The chosen configuration meets the stated resource and validated outcome constraints.

**Costs and possible harm.** Source-supported: 2026 preprint finds non-monotonic trade-offs and differing repaired-case sets; two datasets limit transfer.

**Assumptions.** Critical assumption: Measurements use the intended hardware/workload; plausible patch counts are not correctness evidence.; Discriminating question: Does equal aggregate repair count conceal failure on the cases this deployment actually needs?

**Cheap path / omission.** A simpler deterministic tool or human repair can dominate model tuning for a small task.

**Retirement.** A simpler deterministic tool or human repair can dominate model tuning for a small task. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R027

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Measurements use the intended hardware/workload; plausible patch counts are not correctness evidence. Does equal aggregate repair count conceal failure on the cases this deployment actually needs? **Source IDs:** ESME-S039.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-083 — Automated semantic-conflict detection as supplementary evidence

**Disposition.** DOMAIN_SPECIFIC

**Kind.** CONFLICT_DETECTION_MECHANISM

**Criterion.** Detected interference is adjudicated against intent; absence of a warning is not a safety guarantee.

**Operating mechanism.** Use a tool for its supported conflict class; inspect positive findings and retain unobserved semantic interactions as uncertainty.

**Trigger.** Concurrent changes have plausible semantic interference that targeted automation can help expose.

**Inputs.** Baseline artefacts: Base/parent/merged program, generated tests or build-conflict patterns. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.; Preconditions: Conditions: The tool’s language, conflict and observation model fits the case.; Related property ids: ESME-027; ESME-035; ESME-077; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Concurrent changes have plausible semantic interference that targeted automation can help expose. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Produced constraints or evidence.** Detected interference is adjudicated against intent; absence of a warning is not a safety guarantee.

**Consumer.** Consumer: Contributors and maintainers reconciling jointly intended changes.; Decision: Detected interference is adjudicated against intent; absence of a warning is not a safety guarantee.

**Costs and possible harm.** Source-supported: SAM’s local-interference detection is incomplete; build success and semantic correctness differ.

**Assumptions.** Critical assumption: The tool’s language, conflict and observation model fits the case.; Discriminating question: What semantic interaction lies outside this tool’s definition of conflict?

**Cheap path / omission.** Manual joint review and focused integration tests may be enough; clean noninteracting changes need no special tool.

**Retirement.** Manual joint review and focused integration tests may be enough; clean noninteracting changes need no special tool. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R026, ESME-R027

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. The tool’s language, conflict and observation model fits the case. What semantic interaction lies outside this tool’s definition of conflict? **Source IDs:** ESME-S040, ESME-S066.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-084 — Learned-system data and configuration dependencies

**Disposition.** DOMAIN_SPECIFIC

**Kind.** DOMAIN_TRANSLATED_IMPACT_MECHANISM

**Criterion.** The impact claim covers relevant non-code/model dependencies or explicitly marks unknowns.

**Operating mechanism.** Include data provenance, feature transformations, model versions and consequential configuration in maintenance impact and baseline reasoning.

**Trigger.** A learned component or data pipeline influences supported behaviour.

**Inputs.** Baseline artefacts: Training/serving data, features, model, code, pipeline and configuration. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.; Preconditions: Conditions: Relevant data rights, lineage and model/version access are available; incompleteness is declared.; Related property ids: ESME-004; ESME-021; ESME-024; ESME-085; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A learned component or data pipeline influences supported behaviour. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Produced constraints or evidence.** The impact claim covers relevant non-code/model dependencies or explicitly marks unknowns.

**Consumer.** Consumer: Users and downstream models/components receiving predictions or decisions.; Decision: The impact claim covers relevant non-code/model dependencies or explicitly marks unknowns.

**Costs and possible harm.** Source-supported: industrial ML patterns identify debt mechanisms but not universal effect sizes; CACE is not a theorem.

**Assumptions.** Critical assumption: Relevant data rights, lineage and model/version access are available; incompleteness is declared.; Discriminating question: Which learned or data-dependent behaviour can change without a source-code edit?

**Cheap path / omission.** Ordinary code/configuration analysis is enough when no learned or changing data dependency is present.

**Retirement.** Ordinary code/configuration analysis is enough when no learned or changing data dependency is present. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R028

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Relevant data rights, lineage and model/version access are available; incompleteness is declared. Which learned or data-dependent behaviour can change without a source-code edit? **Source IDs:** ESME-S061, ESME-S005, ESME-S041.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-085 — Feedback and drift as preservation-boundary changes

**Disposition.** ASSUMPTION_SENSITIVE

**Kind.** DOMAIN_TRANSLATED_FEEDBACK_CRITERION

**Criterion.** A material shift triggers justified re-evaluation or a narrowed claim, not automatic retraining.

**Operating mechanism.** Monitor the relevant data/environment and outcome assumptions; reconsider preservation and regression evidence when those assumptions shift.

**Trigger.** A learned or environment-sensitive service has a live obligation whose validity depends on changing distributions or feedback.

**Inputs.** Baseline artefacts: Data distribution, model, feedback channels and accepted outcome criteria. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.; Preconditions: Conditions: Observation windows and criteria reflect the obligation; distributional observations do not themselves decide normative acceptability.; Related property ids: ESME-007; ESME-035; ESME-081; ESME-084; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A learned or environment-sensitive service has a live obligation whose validity depends on changing distributions or feedback. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Produced constraints or evidence.** A material shift triggers justified re-evaluation or a narrowed claim, not automatic retraining.

**Consumer.** Consumer: Those affected by the model’s actual outcomes.; Decision: A material shift triggers justified re-evaluation or a narrowed claim, not automatic retraining.

**Costs and possible harm.** Source-supported conceptual warning; robust general drift thresholds and causality are not established by the inspected source.

**Assumptions.** Critical assumption: Observation windows and criteria reflect the obligation; distributional observations do not themselves decide normative acceptability.; Discriminating question: What observed environmental shift would invalidate the present acceptance evidence?

**Cheap path / omission.** For a stable deterministic computation, ordinary version-bound regression may suffice.

**Retirement.** For a stable deterministic computation, ordinary version-bound regression may suffice. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R028, ESME-R031

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Observation windows and criteria reflect the obligation; distributional observations do not themselves decide normative acceptability. What observed environmental shift would invalidate the present acceptance evidence? **Source IDs:** ESME-S009, ESME-S010, ESME-S061, ESME-S025.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-086 — Artefact-appropriate validation for non-code evolution

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** VALIDATION_SCOPE_CRITERION

**Criterion.** Validation addresses the artefact’s actual obligation and the effects it can propagate.

**Operating mechanism.** Choose validation that checks the meaning and consumer of the changed artefact, including its generated or runtime effects.

**Trigger.** A non-code edit can alter buildability, operation, user guidance, data semantics or model behaviour.

**Inputs.** Baseline artefacts: Documents, configuration, datasets, schemas, build recipes and generated outputs. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.; Preconditions: Conditions: The artefact’s purpose and relevant effect path are understood.; Related property ids: ESME-003; ESME-021; ESME-024; ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A non-code edit can alter buildability, operation, user guidance, data semantics or model behaviour. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Produced constraints or evidence.** Validation addresses the artefact’s actual obligation and the effects it can propagate.

**Consumer.** Consumer: The actual reader, builder, runtime or downstream data consumer.; Decision: Validation addresses the artefact’s actual obligation and the effects it can propagate.

**Costs and possible harm.** Source-supported: code-oriented tools omit important resources; backup and ML configurations have operative effects.

**Assumptions.** Critical assumption: The artefact’s purpose and relevant effect path are understood.; Discriminating question: Who or what consumes this artefact, and what evidence checks the consequence of the edit?

**Cheap path / omission.** A factual documentation correction may need reader/source verification, not an entire executable test suite.

**Retirement.** A factual documentation correction may need reader/source verification, not an entire executable test suite. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R026

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. The artefact’s purpose and relevant effect path are understood. Who or what consumes this artefact, and what evidence checks the consequence of the edit? **Source IDs:** ESME-S001, ESME-S024, ESME-S041, ESME-S052, ESME-S061, ESME-S062.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-087 — A generated insight does not authorise mutation

**Disposition.** DUPLICATE_CANDIDATE

**Kind.** DUPLICATE_AUTHORITY_CRITERION

**Criterion.** The duplicate maps to ESME-001 and is not counted again as a retained mechanism.

**Operating mechanism.** The authority criterion is the same mechanism as ESME-001, encountered again in AI-assisted maintenance; generation changes the source of a proposal, not its legitimacy.

**Trigger.** A tool-generated diagnosis or patch is treated as permission to edit or deploy.

**Inputs.** Baseline artefacts: Generated recommendation and proposed real-world change. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.; Preconditions: Conditions: Tool capability does not confer authority; explicit delegation can authorise bounded actions.; Related property ids: ESME-001; ESME-076; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A tool-generated diagnosis or patch is treated as permission to edit or deploy. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Produced constraints or evidence.** The duplicate maps to ESME-001 and is not counted again as a retained mechanism.

**Consumer.** Consumer: Legitimate requester, maintainer and affected consumer.; Decision: The duplicate maps to ESME-001 and is not counted again as a retained mechanism.

**Costs and possible harm.** Analytical duplication judgement: source provenance differs, but the authority invariant and failure are equivalent.

**Assumptions.** Critical assumption: Tool capability does not confer authority; explicit delegation can authorise bounded actions.; Discriminating question: Is the perceived new requirement actually an existing authority boundary in a new proposal channel?

**Cheap path / omission.** Apply ESME-001 through the existing authorisation route; do not create a separate AI approval bureaucracy solely for this duplicate.

**Retirement.** Apply ESME-001 through the existing authorisation route; do not create a separate AI approval bureaucracy solely for this duplicate. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R037

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Tool capability does not confer authority; explicit delegation can authorise bounded actions. Is the perceived new requirement actually an existing authority boundary in a new proposal channel? **Source IDs:** ESME-S034, ESME-S035, ESME-S041, ESME-S063, ESME-S064.

**Selection restriction.** DUPLICATE_CANDIDATE: Duplicate retained for genealogy and denominator integrity; substitute ESME-001 rather than add a new control. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-088 — Long-term net maintainability benefit of AI-assisted evolution

**Disposition.** UNRESOLVED

**Kind.** LONGITUDINAL_EFFECTIVENESS_CLAIM

**Criterion.** No universal benefit asserted; later tasks and regressions would be needed to resolve the claim.

**Operating mechanism.** Investigated claim: AI assistance yields durable net improvement in maintainability after accounting for later comprehension, regressions and support.

**Trigger.** A decision generalises short-run scores or time savings to multi-release lifecycle benefit.

**Inputs.** Baseline artefacts: Accepted generated changes, later maintenance tasks, regressions and total lifecycle costs. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.; Preconditions: Conditions: Representative longitudinal follow-up, comparable baselines and changing tools must be accounted for.; Related property ids: ESME-058; ESME-076; ESME-078; ESME-080; ESME-081; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A decision generalises short-run scores or time savings to multi-release lifecycle benefit. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Produced constraints or evidence.** No universal benefit asserted; later tasks and regressions would be needed to resolve the claim.

**Consumer.** Consumer: Future maintainers and sponsors, not only benchmark operators.; Decision: No universal benefit asserted; later tasks and regressions would be needed to resolve the claim.

**Costs and possible harm.** Source-supported: task/benchmark scope and unreliable follow-up limit long-horizon inference; contrary evidence does not prove permanent harm.

**Assumptions.** Critical assumption: Representative longitudinal follow-up, comparable baselines and changing tools must be accounted for.; Discriminating question: What multi-release evidence would distinguish genuine maintainability gains from deferred review and regression costs?

**Cheap path / omission.** Run bounded adoption with follow-up evidence; do not assert a long-term benefit absent an adequate horizon and comparator.

**Retirement.** Run bounded adoption with follow-up evidence; do not assert a long-term benefit absent an adequate horizon and comparator. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T04; Discriminator: Compare accepted outcomes and total work, including later repair, on representative tasks under versioned settings.; Hybrid failure: Several tools share one invalid oracle, or the human rubber-stamps unreviewable volume.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R048

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Representative longitudinal follow-up, comparable baselines and changing tools must be accounted for. What multi-release evidence would distinguish genuine maintainability gains from deferred review and regression costs? **Source IDs:** ESME-S035, ESME-S036, ESME-S037, ESME-S038, ESME-S039, ESME-S063, ESME-S064.

**Selection restriction.** UNRESOLVED: UNRESOLVED after examination, not NOT_EXAMINED; permit conditional local use without claiming settled long-term superiority. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-089 — Deletion or degradation requires an explicit containment objective

**Disposition.** DOMAIN_SPECIFIC

**Kind.** EMERGENCY_INTERVENTION_CRITERION

**Criterion.** The lost capability is either intentionally accepted under bounded conditions or the patch is rejected.

**Operating mechanism.** Distinguish removing a required behaviour to fool an oracle from authorised containment that deliberately suspends it, with restoration or closure conditions.

**Trigger.** A proposed fix bypasses code, suppresses errors or disables functionality, especially during an incident.

**Inputs.** Baseline artefacts: Disabled behaviour, degraded service and temporary acceptance conditions. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.; Preconditions: Conditions: The containment objective and accepted loss are explicit; tests are not allowed to redefine required service silently.; Related property ids: ESME-001; ESME-005; ESME-035; ESME-076; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A proposed fix bypasses code, suppresses errors or disables functionality, especially during an incident. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Produced constraints or evidence.** The lost capability is either intentionally accepted under bounded conditions or the patch is rejected.

**Consumer.** Consumer: Users experiencing lost capability and operator authorised to accept it.; Decision: The lost capability is either intentionally accepted under bounded conditions or the patch is rejected.

**Costs and possible harm.** Source-supported: deletion can pass inadequate tests; legitimate emergency semantics differ from permanent corrective semantics.

**Assumptions.** Critical assumption: The containment objective and accepted loss are explicit; tests are not allowed to redefine required service silently.; Discriminating question: Is disabled behaviour an authorised containment trade-off or an unreported failure to implement the obligation?

**Cheap path / omission.** Use a true local correction when feasible; do not invoke containment merely to obtain a passing suite.

**Retirement.** Use a true local correction when feasible; do not invoke containment merely to obtain a passing suite. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R029

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. The containment objective and accepted loss are explicit; tests are not allowed to redefine required service silently. Is disabled behaviour an authorised containment trade-off or an unreported failure to implement the obligation? **Source IDs:** ESME-S001, ESME-S034, ESME-S062.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-090 — Universal autonomous maintenance without residual review or authority

**Disposition.** REJECTED_OR_DISFAVOURED

**Kind.** UNIVERSAL_AUTOMATION_CLAIM

**Criterion.** Delegation remains scoped and its consequences observed; success in a task does not expand its own authority.

**Operating mechanism.** Candidate claims that successful generated patches eliminate the need to establish intent, residual evidence or accountable action.

**Trigger.** A benchmark or demonstration is used to justify unrestricted self-directed production maintenance.

**Inputs.** Baseline artefacts: Automated workflow, generated changes and live obligations. Identify issue text, reference patch, model/tool version, prompt, dataset, harness, repository state and non-code dependencies.; Preconditions: Conditions: Universal reliable intent inference, correctness and authority are not established.; Related property ids: ESME-001; ESME-035; ESME-076; ESME-080; ESME-081; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A benchmark or demonstration is used to justify unrestricted self-directed production maintenance. Generated patches, suggested merges and changed learned components are candidate interventions, not self-validating outcomes.

**Produced constraints or evidence.** Delegation remains scoped and its consequences observed; success in a task does not expand its own authority.

**Consumer.** Consumer: Maintainers and affected users, including those bearing external effects.; Decision: Delegation remains scoped and its consequences observed; success in a task does not expand its own authority.

**Costs and possible harm.** Source-supported: oracle ambiguity, incomplete semantic detection, harness errors and variable productivity leave significant residual obligations.

**Assumptions.** Critical assumption: Universal reliable intent inference, correctness and authority are not established.; Discriminating question: Which unmodelled objective or external effect is this autonomous workflow unable or unauthorised to resolve?

**Cheap path / omission.** Delegate a bounded class with explicit conditions and monitor actual outcomes; human review need not be ceremonial or applied identically to every case.

**Retirement.** Delegate a bounded class with explicit conditions and monitor actual outcomes; human review need not be ceremonial or applied identically to every case. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R046

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Universal reliable intent inference, correctness and authority are not established. Which unmodelled objective or external effect is this autonomous workflow unable or unauthorised to resolve? **Source IDs:** ESME-S035, ESME-S038, ESME-S040, ESME-S034, ESME-S036, ESME-S037, ESME-S063, ESME-S064, ESME-S066.

**Selection restriction.** REJECTED_OR_DISFAVOURED: Reject universality without asserting that every action needs manual intervention. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-091 — Every historical behaviour must be preserved

**Disposition.** REJECTED_OR_DISFAVOURED

**Kind.** UNQUALIFIED_PRESERVATION_CLAIM

**Criterion.** Each preserved or changed behaviour has a justified status and affected consumers are considered.

**Operating mechanism.** Candidate elevates all observed legacy behaviour to a perpetual requirement.

**Trigger.** A characterisation test or compatibility argument blocks correction of an obsolete, accidental or harmful behaviour.

**Inputs.** Baseline artefacts: Legacy behaviour, actual reliance and current requirements. Bind tests, results, build inputs, artefact identity, environment, deployed versions and relevant data state.; Preconditions: Conditions: Past existence does not establish current normative obligation.; Related property ids: ESME-001; ESME-028; ESME-034; ESME-069; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A characterisation test or compatibility argument blocks correction of an obsolete, accidental or harmful behaviour. Separate the newly intended effect from independent obligations intended to survive a release.

**Produced constraints or evidence.** Each preserved or changed behaviour has a justified status and affected consumers are considered.

**Consumer.** Consumer: Affected legitimate users, not only historical code output.; Decision: Each preserved or changed behaviour has a justified status and affected consumers are considered.

**Costs and possible harm.** Source-supported: benchmark/reference behaviours can be irrelevant or erroneous; taxonomy includes intentional behavioural change.

**Assumptions.** Critical assumption: Past existence does not establish current normative obligation.; Discriminating question: Why is this old behaviour an obligation today rather than evidence to investigate?

**Cheap path / omission.** Retain relevant promises and authorise justified revisions under ESME-001 and 034.

**Retirement.** Retain relevant promises and authorise justified revisions under ESME-001 and 034. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T01; Discriminator: Identify the actual obligation, consumer and authorisation for revision; unresolved authority blocks that revision, not unrelated work.; Hybrid failure: Two ambiguous meanings, unmaintained compatibility mode, or an oracle changed solely to pass.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R042

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. Past existence does not establish current normative obligation. Why is this old behaviour an obligation today rather than evidence to investigate? **Source IDs:** ESME-S001, ESME-S022, ESME-S025, ESME-S034, ESME-S063, ESME-S064.

**Selection restriction.** REJECTED_OR_DISFAVOURED: Reject total preservation; retain observer-relative, obligation-sensitive continuity. The negative candidate remains in the population but is not an unconditional audit obligation.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-092 — Supported-version and variant obligation matrix

**Disposition.** CONTEXT_DEPENDENT

**Kind.** CONFIGURATION_AND_SUPPORT_MECHANISM

**Criterion.** Evidence and limitations can be mapped to the supported combinations and obsolete obligations are retired.

**Operating mechanism.** Identify supported releases/configurations and the obligations shared or different across them; select evidence by actual support promises and interaction risk.

**Trigger.** Several versions, build options, platforms or deployment variants remain supported.

**Inputs.** Baseline artefacts: Supported releases, feature/configuration choices, platform/tool versions and consumers. Include code, APIs, data, configuration, generated artefacts, builds, release combinations and downstream consumers.; Preconditions: Conditions: The support population is explicit; interaction sampling and omissions are not confused with exhaustive coverage.; Related property ids: ESME-004; ESME-021; ESME-025; ESME-051; ESME-069; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Several versions, build options, platforms or deployment variants remain supported. Bound a proposed edit by the effects it may propagate, not solely by its textual size.

**Produced constraints or evidence.** Evidence and limitations can be mapped to the supported combinations and obsolete obligations are retired.

**Consumer.** Consumer: Maintainers supporting variants and downstream users relying on declared combinations.; Decision: Evidence and limitations can be mapped to the supported combinations and obsolete obligations are retired.

**Costs and possible harm.** Source-supported: configuration dimensions and bounded schema skew matter; full cross-product checking may be infeasible.

**Assumptions.** Critical assumption: The support population is explicit; interaction sampling and omissions are not confused with exhaustive coverage.; Discriminating question: Which supported combination has no relevant evidence, and can the support promise be narrowed instead?

**Cheap path / omission.** One explicitly supported configuration needs no elaborate matrix; retire unsupported variants transparently.

**Retirement.** One explicitly supported configuration needs no elaborate matrix; retire unsupported variants transparently. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T07; Discriminator: Determine real promises, capacity and transition feasibility; usage popularity is neither permission nor an infinite support contract.; Hybrid failure: Dates are announced without a viable path, or compatibility branches multiply beyond capacity.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R014, ESME-R024, ESME-R033

**Evidence boundary.** CONCEPTUAL_OR_DECISION_ARGUMENT: mechanism and counterexample reasoning; not a mathematical guarantee of practical payoff. The support population is explicit; interaction sampling and omissions are not confused with exhaustive coverage. Which supported combination has no relevant evidence, and can the support promise be narrowed instead? **Source IDs:** ESME-S019, ESME-S005, ESME-S041, ESME-S049, ESME-S024.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-093 — Composition-induced change–obligation contract

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** ANALYTICAL_COMPOSITION_INVARIANT

**Criterion.** Every consequential acceptance claim can be traced to the same declared change and baseline or an explicit revision.

**Operating mechanism.** Bind a decision to a specific baseline, authorised desired difference, preserved observations, impact scope and acceptance evidence; change any element only with an explicit compatibility check.

**Trigger.** Several otherwise sound maintenance mechanisms could be acting on different versions or meanings of success.

**Inputs.** Baseline artefacts: Baseline, change objective, preservation set, affected consumers and evidence bindings. Treat artefacts, environments, consumers, obligations, evidence assumptions and effect history as coupled state.; Preconditions: Conditions: Constituent claims are meaningful and compatible; a document cannot create missing authority or oracle evidence.; Related property ids: ESME-001; ESME-004; ESME-021; ESME-028; ESME-035; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Several otherwise sound maintenance mechanisms could be acting on different versions or meanings of success. Reconcile change intent, preservation, evidence and lifecycle choices rather than requiring every source technique simultaneously.

**Produced constraints or evidence.** Every consequential acceptance claim can be traced to the same declared change and baseline or an explicit revision.

**Consumer.** Consumer: Those authorising, implementing and accepting the same intervention.; Decision: Every consequential acceptance claim can be traced to the same declared change and baseline or an explicit revision.

**Costs and possible harm.** Analytical: the combined contract can become costly bureaucracy and is not empirically validated as a whole.

**Assumptions.** Critical assumption: Constituent claims are meaningful and compatible; a document cannot create missing authority or oracle evidence.; Discriminating question: Are all participants actually judging the same change, baseline and preservation obligations?

**Cheap path / omission.** For a local task, one concise issue with linked baseline and tests can carry the contract; no new schema or formal document is mandatory.

**Retirement.** For a local task, one concise issue with linked baseline and tests can carry the contract; no new schema or formal document is mandatory. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R030, ESME-R035

**Evidence boundary.** RESEARCHER_INTERPRETATION: relational necessity and boundary argument, not an established theorem or empirical validation of the compound system. Constituent claims are meaningful and compatible; a document cannot create missing authority or oracle evidence. Are all participants actually judging the same change, baseline and preservation obligations? **Source IDs:** ESME-S001, ESME-S019, ESME-S022, ESME-S025, ESME-S041, ESME-S063, ESME-S064.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-094 — Composition-induced assumption-indexed evidence invalidation

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** ANALYTICAL_FEEDBACK_INVARIANT

**Criterion.** Reused evidence has an applicability reason, and invalidated claims are rechecked, narrowed or withdrawn.

**Operating mechanism.** Associate consequential evidence with the assumptions it needs, and revisit only affected claims when intent, baseline, tool, consumer or environment changes.

**Trigger.** A composed system reuses earlier evidence after a potentially relevant change elsewhere.

**Inputs.** Baseline artefacts: Evidence claims and their baseline, environment, observer and tool assumptions. Treat artefacts, environments, consumers, obligations, evidence assumptions and effect history as coupled state.; Preconditions: Conditions: Dependencies between assumptions and claims are sufficiently known; unknowns remain explicit.; Related property ids: ESME-004; ESME-021; ESME-035; ESME-051; ESME-081; ESME-085; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A composed system reuses earlier evidence after a potentially relevant change elsewhere. Reconcile change intent, preservation, evidence and lifecycle choices rather than requiring every source technique simultaneously.

**Produced constraints or evidence.** Reused evidence has an applicability reason, and invalidated claims are rechecked, narrowed or withdrawn.

**Consumer.** Consumer: Maintainer or acceptor reusing prior results.; Decision: Reused evidence has an applicability reason, and invalidated claims are rechecked, narrowed or withdrawn.

**Costs and possible harm.** Analytical: tracing all assumptions can be unbounded; overly broad invalidation can stall maintenance.

**Assumptions.** Critical assumption: Dependencies between assumptions and claims are sufficiently known; unknowns remain explicit.; Discriminating question: Which prior conclusion ceases to be warranted because this assumption changed?

**Cheap path / omission.** A direct note that the dependency is unchanged may suffice; no universal dependency database is required.

**Retirement.** A direct note that the dependency is unchanged may suffice; no universal dependency database is required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R031

**Evidence boundary.** RESEARCHER_INTERPRETATION: relational necessity and boundary argument, not an established theorem or empirical validation of the compound system. Dependencies between assumptions and claims are sufficiently known; unknowns remain explicit. Which prior conclusion ceases to be warranted because this assumption changed? **Source IDs:** ESME-S019, ESME-S024, ESME-S038, ESME-S049, ESME-S051, ESME-S063.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-095 — Composition-induced effect-relative returnability frontier

**Disposition.** ASSUMPTION_SENSITIVE

**Kind.** ANALYTICAL_TRANSITION_INVARIANT

**Criterion.** Before a boundary is crossed, the remaining options and accepted irreversibility are explicit and evidenced.

**Operating mechanism.** Track which recovery options remain valid after each consequential transition; before crossing an irreversible boundary, require accepted loss and feasible containment or forward action.

**Trigger.** A migration or release changes the state so a previously valid recovery route no longer applies.

**Inputs.** Baseline artefacts: Transition sequence, persistent/external effects and available recovery actions. Treat artefacts, environments, consumers, obligations, evidence assumptions and effect history as coupled state.; Preconditions: Conditions: The relevant effects and feasibility of recovery options are known well enough to support the decision.; Related property ids: ESME-004; ESME-044; ESME-050; ESME-051; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A migration or release changes the state so a previously valid recovery route no longer applies. Reconcile change intent, preservation, evidence and lifecycle choices rather than requiring every source technique simultaneously.

**Produced constraints or evidence.** Before a boundary is crossed, the remaining options and accepted irreversibility are explicit and evidenced.

**Consumer.** Consumer: Operator and consumers whose state may be irreversibly changed.; Decision: Before a boundary is crossed, the remaining options and accepted irreversibility are explicit and evidenced.

**Costs and possible harm.** Analytical: unobserved external effects can make the frontier incomplete; a complete formal model is not claimed.

**Assumptions.** Critical assumption: The relevant effects and feasibility of recovery options are known well enough to support the decision.; Discriminating question: At this exact transition, which recovery option is lost and what replaces it?

**Cheap path / omission.** A single reversible edit needs only one verified return path; no global state machine is required.

**Retirement.** A single reversible edit needs only one verified return path; no global state machine is required. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R015, ESME-R032

**Evidence boundary.** RESEARCHER_INTERPRETATION: relational necessity and boundary argument, not an established theorem or empirical validation of the compound system. The relevant effects and feasibility of recovery options are known well enough to support the decision. At this exact transition, which recovery option is lost and what replaces it? **Source IDs:** ESME-S019, ESME-S029, ESME-S049, ESME-S051, ESME-S062.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-096 — Composition-induced coexistence termination witness

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** ANALYTICAL_COMPLETION_CRITERION

**Criterion.** Completion points to transferred obligations and actual closure, or explicitly reclassifies justified continued coexistence.

**Operating mechanism.** Require evidence that responsibilities, consumers and required state have transferred before declaring migration complete and removing temporary old paths.

**Trigger.** A migration claims completion while old/new systems, bridges or unresolved users remain.

**Inputs.** Baseline artefacts: Responsibility allocation, consumer transitions, reconciled data and retired routes. Treat artefacts, environments, consumers, obligations, evidence assumptions and effect history as coupled state.; Preconditions: Conditions: The retained support scope and authority to terminate are explicit.; Related property ids: ESME-048; ESME-050; ESME-052; ESME-069; ESME-071; ESME-092; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A migration claims completion while old/new systems, bridges or unresolved users remain. Reconcile change intent, preservation, evidence and lifecycle choices rather than requiring every source technique simultaneously.

**Produced constraints or evidence.** Completion points to transferred obligations and actual closure, or explicitly reclassifies justified continued coexistence.

**Consumer.** Consumer: Legacy/successor maintainers, operators and remaining consumers.; Decision: Completion points to transferred obligations and actual closure, or explicitly reclassifies justified continued coexistence.

**Costs and possible harm.** Analytical: proving absence of unknown consumers may be impossible; bounded scope and accepted residual risk are necessary.

**Assumptions.** Critical assumption: The retained support scope and authority to terminate are explicit.; Discriminating question: What evidence establishes the old responsibility is discharged rather than merely hidden behind the new interface?

**Cheap path / omission.** A simple statement and check that no supported consumer remains may suffice; permanent deliberate coexistence is a new supported configuration, not an unfinished migration by definition.

**Retirement.** A simple statement and check that no supported consumer remains may suffice; permanent deliberate coexistence is a new supported configuration, not an unfinished migration by definition. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R016, ESME-R033

**Evidence boundary.** RESEARCHER_INTERPRETATION: relational necessity and boundary argument, not an established theorem or empirical validation of the compound system. The retained support scope and authority to terminate are explicit. What evidence establishes the old responsibility is discharged rather than merely hidden behind the new interface? **Source IDs:** ESME-S013, ESME-S029, ESME-S031, ESME-S041, ESME-S055, ESME-S054.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-097 — Composition-induced proportional control and retirement

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** ANALYTICAL_SELECTION_INVARIANT

**Criterion.** Each applied control has a protected failure, consumer and continuation condition; omitted alternatives have a rationale.

**Operating mechanism.** Select the smallest set of mechanisms that jointly meets the actual obligations; expand on concrete uncertainty or exposure and remove controls whose consumer or failure mechanism disappears.

**Trigger.** Combining individually useful techniques risks imposing all of them simultaneously or retaining obsolete machinery.

**Inputs.** Baseline artefacts: Selected controls, protected obligations, costs and consumers. Treat artefacts, environments, consumers, obligations, evidence assumptions and effect history as coupled state.; Preconditions: Conditions: Omission must be justified by covered obligations, not by convenience alone.; Related property ids: ESME-012; ESME-035; ESME-043; ESME-058; ESME-066; ESME-074; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: Combining individually useful techniques risks imposing all of them simultaneously or retaining obsolete machinery. Reconcile change intent, preservation, evidence and lifecycle choices rather than requiring every source technique simultaneously.

**Produced constraints or evidence.** Each applied control has a protected failure, consumer and continuation condition; omitted alternatives have a rationale.

**Consumer.** Consumer: Maintainers and affected stakeholders deciding acceptable evidence and coordination.; Decision: Each applied control has a protected failure, consumer and continuation condition; omitted alternatives have a rationale.

**Costs and possible harm.** Analytical: cheapest can be dangerously underpowered; proportionality needs an explicit loss/uncertainty discriminator, not a slogan.

**Assumptions.** Critical assumption: Omission must be justified by covered obligations, not by convenience alone.; Discriminating question: What failure remains covered if this control is removed, and what cost disappears?

**Cheap path / omission.** Use a local explanation, direct test and reversible edit when adequate; choose no intervention when no justified change exists.

**Retirement.** Use a local explanation, direct test and reversible edit when adequate; choose no intervention when no justified change exists. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** No separate named tension is asserted; record-specific assumptions, known failures and alternatives still govern.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R034

**Evidence boundary.** RESEARCHER_INTERPRETATION: relational necessity and boundary argument, not an established theorem or empirical validation of the compound system. Omission must be justified by covered obligations, not by convenience alone. What failure remains covered if this control is removed, and what cost disappears? **Source IDs:** ESME-S013, ESME-S025, ESME-S051, ESME-S055, ESME-S058, ESME-S023, ESME-S036, ESME-S037.

### EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-098 — Composition-induced independent warrant for oracle revision

**Disposition.** RETAINED_IN_EVOLVED_FORM

**Kind.** ANALYTICAL_META_CHANGE_CONSTRAINT

**Criterion.** The acceptance-rule change has a reason not reducible to making the patch pass, and remaining preservation obligations are checked.

**Operating mechanism.** When the change also revises expected behaviour or acceptance rules, justify that revision through the authorised requirement and affected consumers, not merely the candidate’s ability to pass the new tests.

**Trigger.** A patch removes, weakens or changes an oracle, specification or preservation obligation relevant to its own acceptance.

**Inputs.** Baseline artefacts: Changed tests/specification, prior obligation, authorised new objective and supporting evidence. Treat artefacts, environments, consumers, obligations, evidence assumptions and effect history as coupled state.; Preconditions: Conditions: A warrant independent of the candidate’s success under the new rule is available; unresolved intent remains unresolved.; Related property ids: ESME-001; ESME-034; ESME-035; ESME-079; ESME-091; ESME-093; Interpretation: Related obligations and prerequisites, not a serial scheduling graph. Typed relations in the composition model control the relationship meaning.; Authorised objective and scope: A patch removes, weakens or changes an oracle, specification or preservation obligation relevant to its own acceptance. Reconcile change intent, preservation, evidence and lifecycle choices rather than requiring every source technique simultaneously.

**Produced constraints or evidence.** The acceptance-rule change has a reason not reducible to making the patch pass, and remaining preservation obligations are checked.

**Consumer.** Consumer: Request owner, reviewer and consumers affected by the redefinition.; Decision: The acceptance-rule change has a reason not reducible to making the patch pass, and remaining preservation obligations are checked.

**Costs and possible harm.** Analytical: perfect independent truth may be unavailable; the rule requires a defensible external warrant, not impossible absolute certainty.

**Assumptions.** Critical assumption: A warrant independent of the candidate’s success under the new rule is available; unresolved intent remains unresolved.; Discriminating question: What justifies this changed expectation other than the fact that it makes the proposed change pass?

**Cheap path / omission.** An obvious erroneous expected value can be corrected with a checked domain example; a separate team or elaborate meta-process is not mandatory.

**Retirement.** An obvious erroneous expected value can be corrected with a checked domain example; a separate team or elaborate meta-process is not mandatory. Omit or retire a control when its protected obligation, relevant failure mechanism or decision consumer no longer exists; record unresolved support consequences before removing it.

**Conflicts.** Tension id: ESME-T01; Discriminator: Identify the actual obligation, consumer and authorisation for revision; unresolved authority blocks that revision, not unrelated work.; Hybrid failure: Two ambiguous meanings, unmaintained compatibility mode, or an oracle changed solely to pass.

**Coupling and relation IDs.** The mechanism is relevant only when it can establish the stated postcondition for the actual consumer; its presence alone is not the criterion. ESME-R035

**Evidence boundary.** RESEARCHER_INTERPRETATION: relational necessity and boundary argument, not an established theorem or empirical validation of the compound system. A warrant independent of the candidate’s success under the new rule is available; unresolved intent remains unresolved. What justifies this changed expectation other than the fact that it makes the proposed change pass? **Source IDs:** ESME-S001, ESME-S022, ESME-S025, ESME-S041, ESME-S034, ESME-S063, ESME-S064.

## Closure of this interface

The frozen lineage and 98-candidate denominator must remain recoverable through later integration, even where one selected mechanism addresses several concerns. A future combined system may reject, substitute or leave conditional these exports. That does not retrospectively change this tradition’s sources or history. No sibling findings, cross-trifecta reconciliation or target-native adoption decision is claimed here.
