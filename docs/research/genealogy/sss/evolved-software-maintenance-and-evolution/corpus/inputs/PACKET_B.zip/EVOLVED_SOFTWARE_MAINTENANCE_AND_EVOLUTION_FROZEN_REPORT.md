# Evolved Software Maintenance and Evolution

## Independent tradition study and criticism-tested composition

**Analytical lineage:** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION`  
**Revision:** `ESME-2026-09-06-r1`  
**Research run and cut-off:** 6 September 2026  
**State:** FROZEN, subject to the accompanying manifest and exact-byte archive verification.  
**Status of the name:** a researcher-authored analytical synthesis, not a claim that an established academic school bears this compound name.

This report reconstructs the established software-maintenance and software-evolution tradition, adjudicates a complete declared candidate population, and composes the surviving mechanisms into a conditional engineering system. The later SSS grouping is provisional. Software Architecture and Software Product Line Engineering supply boundary questions, not borrowed findings. No sibling corpus or requester repository was consulted; no host-system adoption or mutation is established.

The complete denominator is **74 candidates**. All were examined: **55 `EXAMINED` and 19 `EXAMINED_WITH_EVIDENCE_LIMIT`**. There are **67 source records**, **24 criticism entries**, **11 internal tensions**, **14 genealogy nodes and 20 classified edges**, **11 domain models**, and a composition containing **62 relations, seven alternative configurations and 12 case tests**. Three candidates arise from composition rather than simple extraction from an individual technique. These counts describe this bounded study; they are not a census of all publications or all possible properties.

The main conclusion is not that existing software should always grow, be refactored, be replaced, or be maintained indefinitely. It is that consequential change needs a defensible relationship between **purpose, baseline, understanding, impact, intended differences, preservation evidence, legitimate action and observed consequences**. Each relationship may be established cheaply in a simple setting. Complicated dependencies, uncertain oracles, persistent state and independent consumers can make a richer arrangement necessary. Whether the combined arrangement earns its cost remains an empirical question, not a result established merely by composing well-supported parts.

## How to read and use this packet

The explanatory argument below precedes the required structured sections. Source citations use durable identifiers such as `[ESME-S018]`; the source register at the end supplies exact titles, editions, inspected locators and access limitations. The companion source JSON is authoritative for provenance. The property JSON contains all common fields and all ten domain-profile fields for every candidate, including unfavourable and unresolved candidates. JSON array pointers are zero-based.

The **audit intake** turns eligible candidates into neutral questions for an unspecified later system. The **public-documentation intake** separates citation-ready facts from this synthesis. The **synthesis intake** exports all global keys without performing the later reconciliation. The **coverage JSON** identifies the examined families, grouped searches, source access limits and stopping judgement. The **composition JSON** carries the full relational account, alternatives, interfaces, revision boundaries and case tests.

“Strongly retained” is a disposition within this synthesis, not a quantitative confidence score or a universal causal-effect claim. A useful criterion can have strong conceptual support and little evidence about the cost of a particular implementation. Conversely, an industrial deployment can establish feasibility without establishing comparative superiority. The packet deliberately keeps historical provenance, theory, comparison, deployment, replication, contrary evidence and transferability separate.

## 1. The object of maintenance is an existing system with continuing obligations

Software maintenance is broader than correction after delivery. The inspected SWEBOK V3 account organises corrective, adaptive, perfective and preventive purposes and also discusses the processes that make maintenance possible. The V4 overview includes preparation and transition as well as post-delivery work. The official 2022 maintenance-standard catalogue distinguishes its scope from routine operational administration and includes disposal. The paid normative body was not inspected; this report does not assert clause-level conformance requirements. [ESME-S001, official scope; ESME-S002, Chapter 5; ESME-S003, maintenance overview.]

A useful distinction is between restoring an accepted intention and changing that intention. Corrective work can restore intended behaviour; adaptive work responds to a changed environment; perfective and preventive purposes concern useful improvement and prospective problems. The purposes can overlap. One patch might remove a defect, support a new platform and reduce a recurring obstacle. A commit is therefore not necessarily a natural unit for an exclusive purpose label. The 1976 Swanson work is an important historical anchor, but its original body was inaccessible in this run. Attribution is triangulated through inspected later guidance, not through invented original passages. Chapin and colleagues' later taxonomy was inspected only at abstract and reference level. [ESME-S004–ESME-S007.]

Classification matters through its consumer. A label can support allocation, reporting or discussion, but it does not authorise a new objective or establish benefit. A small field experiment found low agreement between developers applying the compared classifications. The synthesis therefore retains a revisable, potentially multi-purpose distinction and rejects compulsory single-label coding when no decision benefits from it. This is a substantive narrowing, not an invitation to declare every ambiguous change unclassifiable. [ESME-S007, study design and reliability results; ESME-002.]

The system boundary includes relevant source, build and configuration inputs, persistent data, interfaces, documentation, executable policies and human knowledge. It need not include every surrounding object. A baseline is adequate when it identifies the objects whose variation could change the judgement being made. Version control contributes recoverable history and selection, but a source revision does not identify all deployed state. This distinction becomes critical when a change can affect a database, a generated artefact or a remote consumer. [ESME-S002, Chapter 6; ESME-S030, revision/configuration selection; ESME-S038, recovery account.]

The first acceptance question is consequently not “does the patch pass?” but “what change is this patch supposed to make, and who can legitimately resolve competing obligations?” A requester may be mistaken; a maintainer may correctly diagnose an implementation but lack authority to withdraw a downstream commitment. Tests and approvals each have narrower roles than that entire decision. ESME-001 retains explicit intent and legitimate acceptance while ESME-071 rejects a formal board for every edit. This is the study's analytical adjudication of the scope and failure evidence, not a claim that one universal approval protocol has been experimentally established. [ESME-S005; ESME-S039; ESME-S051.]

## 2. Evolution is a plural explanatory programme, not a mandate for expansion

Belady and Lehman's early model examined large-program development through observations of an industrial operating-system programme. Its models and observations should not be recast as timeless physical laws. The work allows consolidation as part of development; it does not entail that every useful system must increase its functionality continuously. Lehman's later S/P/E distinctions and reformulations make the system's relationship with its environment central to interpretation. The E-type qualification matters: evidence concerning evolving embedded real-world requirements cannot simply be transferred to every program object. [ESME-S008, scope and growth discussion; ESME-S009, S/P/E distinctions; ESME-S010, formulations.]

Later investigations are not one homogeneous replication series. Godfrey and Tu examined Linux growth; Israeli and Feitelson later studied a longer Linux history. These share a project population, even where dates and measurements differ. The latter study illustrates why aggregation matters: total complexity and mean complexity per function can move in different directions. A glibc study identifies phases, including a period of relatively stable size, and discusses measurement and population qualifications. Its suggested future consequences of a plateau are not observations that those consequences actually occurred. [ESME-S011; ESME-S060, complexity results and discussion; ESME-S061, growth phases and threats.]

The review literature organises these disagreements but does not add an independent deployment trial merely by describing them. The defensible survivor is to state the population, measure, time scale and conditions before applying a claimed regularity, then expose the decision to contrary observation. Effort, complexity, user demand, familiarity and change rate remain useful things to investigate. Their association alone does not identify a causal control law. [ESME-S029, discussion and conclusions; ESME-006–ESME-010.]

Parnas's software-aging discussion adds a complementary distinction: changing needs and damaging modifications can make software less useful. It is not a claim that source text wears out like a physical component, nor is it the separate operational notion of resource accumulation during long execution. This supports attention to adaptation and change quality, not a calendar-based replacement rule. [ESME-S050, printed pp. 279–280 and scope discussion.]

Accordingly, deliberate non-change is a legitimate branch. It requires a supported account of current obligations and feasible support, not merely an absence of reported problems. A changing dependency, loss of expertise or new requirement can reopen the decision. An inactive repository does not by itself establish either success or failure: some respondents in the inspected cessation study described their projects as finished. The synthesis rejects both automatic growth targets and the equally unsupported inference that inactivity always means adequate maintenance. [ESME-S040, finished-project responses; ESME-005, ESME-010.]

## 3. Comprehension is an inquiry with a purpose and a stopping condition

Program comprehension addresses what a maintainer needs to know in order to make a particular change. The cognitive and observational traditions do not support one compulsory route through every representation. The inspected work describes interacting modes of comprehension and interdependent questions asked during evolution tasks. A maintainer may move between a feature, a caller, an execution observation and a hypothesis about intent. Forty-four question types in a study are not forty-four required documents or independent experiments. [ESME-S014, cognitive and integrated models; ESME-S015, designs and question catalogue.]

Chikofsky and Cross distinguish recovering information from changing a system. Reverse engineering analyses an existing system to identify components and relationships or create representations at another level. Redocumentation and design recovery serve different recovery purposes; restructuring and re-engineering concern transformations in different ways. These distinctions matter because an explanatory representation and an authorised intervention have different postconditions. A reconstructed architecture can be informative while still being incomplete or incorrect. [ESME-S012, printed pp. 14–16.]

Slicing offers a more formal example of boundedness. A slice is relative to a criterion and an analysis model. It can help explain which parts affect selected observations; it is not automatically the full impact set for arbitrary external effects. General minimality and computability limitations must not be confused with the possibility of constructing useful conservative slices. The relevant question is whether the guarantee's assumptions and observations cover the intended use, including any termination qualification. [ESME-S013, definitions, correctness discussion and construction; ESME-013.]

Static structure and executed behaviour answer different questions. A conservative static analysis can include infeasible effects, whereas a dynamic trace omits paths that were not exercised. Agreement is not independent confirmation when both analyses share the same incomplete configuration or assumption. Triangulation is valuable where the second mode discriminates a consequential alternative. It is not a requirement to run several tools on a demonstrably closed local edit. [ESME-S013–ESME-S017; ESME-012, ESME-021.]

Rationale, historical changes and knowledgeable people can supply missing intent. None is infallible. A historical reason may have expired, a document may be stale, and an expert may not know a recently introduced consumer. The appropriate stopping rule is question-bounded adequacy: consequential uncertainties are resolved, constrained or explicitly carried into the decision. The rule does not require exhaustive understanding of every future environment. It also does not permit ignorance to be renamed a justified local boundary. [ESME-S012; ESME-S015; ESME-S047; ESME-011, ESME-015, ESME-016.]

## 4. Impact analysis connects an edit to consequences and people

Impact analysis investigates how a proposed change can propagate. Dependencies can be textual, syntactic, semantic, architectural, data-related, protocol-related, configurational or organisational. A useful boundary therefore depends on the change and its possible effects, not solely on a source-import graph. The inspected impact-analysis introduction supplies the conceptual framing; repository-mining work adds historical evidence rather than replacing semantic judgement. [ESME-S016, Chapter 1; ESME-S017.]

ROSE uses version histories to suggest associated changes. Its own discussion distinguishes historical practice from intended dependency. Correlated edits may reflect a real constraint, a broad commit, generated files or habit. An absence of co-change can reflect missing history or a newly introduced relationship. The mature mechanism treats a recommendation as a hypothesis to confirm, not an automatic requirement to modify another component. [ESME-S017, mechanism and §11; ESME-019.]

Package-ecosystem analysis expands the scale but changes the meaning of the evidence. Declared package edges are not direct observations of all runtime effects, and they do not encode an upstream maintainer's willingness to supply labour. Undeclared consumers, alternative configurations and operational relationships can remain outside the graph. Discovery therefore combines available technical evidence with consultation and honest uncertainty where independent parties are involved. Notification supplies information; it does not establish receipt, agreement or ability to migrate. [ESME-S041, data and network limits; ESME-S043, dependency-abandonment strategies; ESME-S045, compatibility scope.]

Concurrent changes introduce another distinction. A textual merge can succeed while combined behaviour changes. A semantic-interference detector may identify a possible interaction without establishing that it is unwanted. The inspected static-analysis study therefore warrants an assumption-sensitive candidate, not a universal merge-acceptance oracle. Acceptance must still refer to intended combined behaviour. [ESME-S044, design, scenario selection and threats; ESME-022.]

The synthesis requires a justified boundary and a proportionate challenge to false negatives. High-consequence uncertainty can warrant broader regression, another evidence mode or a restriction on allowed operation. A small edit with an established local dependency chain can remain local. Exhaustiveness and economy are alternatives to adjudicate, not competing slogans resolved by saying “balance”.

## 5. Preservation is observer-relative; improvement is a different claim

Opdyke's refactoring work formalises transformations and their preservation conditions for an object-oriented setting. That is a much more precise contribution than “cleaner code is better”. A preservation argument depends on the language and model, preconditions and observations included. An implementation may violate those assumptions through reflection, persistence, external integrations or other effects that a simplified model does not cover. Such a violation limits the application; it does not refute a valid theorem about its stated model. [ESME-S018, preservation and precondition chapters; ESME-023–ESME-025.]

The relevant observer may care about return values, exceptions, ordering, timing, resources or persisted representations. Not all of these must be preserved in every change. The point is to identify the obligations that do survive and separately authorise those that change. A corrective repair can deliberately alter behaviour; calling it a refactoring cannot make that difference disappear. Conversely, one patch may reasonably contain both a preserving transformation and a feature change when their acceptance obligations remain intelligible. [ESME-S045, public API scope; ESME-S051, specified and derived oracles; ESME-026.]

Preservation does not establish economic benefit. Industrial respondents use refactoring more broadly than a strict catalogue definition, and their perceptions do not alone identify a causal improvement. Metric studies do not directly measure a human maintainer's success on a future task. The differentiated replication of refactoring–bug relationships examines confounding while retaining the possibility of genuine harmful changes. This evidence narrows, rather than destroys, the candidate: identify the likely class of future changes and compare the expected benefit with relearning, validation and regression costs. [ESME-S020–ESME-S022.]

A simpler metric value can accompany a less useful design, and a larger total structure can support necessary variation. ESME-027 is therefore context-dependent, ESME-053 is easily gamed, and ESME-028 rejects structural cleanliness as sufficient proof of benefit. The strongest preservation core does not require that all software be made smaller, more abstract or more uniform.

## 6. Regression evidence must answer the right question

The oracle problem is not eliminated by automation. Existing tests can encode an obsolete expectation or fail to observe the relevant behaviour. A new test can be written from the same mistaken interpretation as a patch. Characterisation records what the system presently does; it is useful evidence for investigating obligations, not an automatic decision that every observed behaviour should remain. The inspected Feathers interview supports this account and the possibility of temporary tests; the entire original book was not inspected. [ESME-S051, §§2 and 4–7; ESME-S059, characterisation discussion.]

Differential testing obtains discrepancies from another implementation. Metamorphic testing uses valid relations between observations where a complete result oracle is difficult. Mutation analysis probes the ability of tests to reveal representative perturbations. Each has its own assumptions. Reference implementations can be wrong; a metamorphic relation can be invalid for the actual domain; a mutation family can fail to represent the important fault class. These techniques are alternatives or complements, not votes that can be counted without considering common assumptions. [ESME-S063, original 1998 report; ESME-S064, KConfigReader experience; ESME-S062, design and validity threats.]

Regression selection and prioritisation likewise solve distinct problems. Selection can reduce execution when its analysis cost and coverage assumptions justify it. Prioritisation can make a consequential failure visible earlier without increasing the suite's eventual ability to reveal faults. The original prioritisation study used small programs and seeded faults; its many ordering observations are not thousands of independent projects. When the suite is cheap, retest-all with a simple order can dominate sophisticated optimisation. [ESME-S023, cost model and design; ESME-S066, §2, study and threats.]

Continuous integration makes evidence timely and available to collaborators, but a dashboard or policy file is inert without a consumer and an action. Build skipping changes which failures are observed when; a skipped build is not a passed build. Reproducible builds establish a relationship between specified inputs, environment and outputs, not correctness or security of those outputs. These distinctions preserve useful mechanisms while rejecting their ceremonial substitutes. [ESME-S058, skipped-versus-passed discussion; ESME-S046, definition; ESME-S056, enforcement limitations.]

Release evidence must also address the deployed state. A canary can reduce exposure only when its observations are relevant and timely enough to change the rollout. A compatibility label cannot prove that mixed versions preserve consumer expectations. Reverting source cannot reverse information loss or already-issued external effects. GitLab's database-outage account supplies a concrete warning about assuming that intended backup and recovery arrangements are operationally available; it is one incident, not a frequency estimate. [ESME-S038, backup failure and recovery/reconciliation; ESME-S045; ESME-038–ESME-041.]

## 7. Migration creates temporary systems that must also be maintained

The legacy-migration literature describes several alternatives, including continued maintenance, wrapping, re-engineering and replacement. Incremental and quiescent approaches answer different constraints. Wrappers and gateways can enable coexistence, but they introduce integration work and may perpetuate old constraints. The review's account of Chicken Little and Butterfly is used as a reviewed comparison; it is not falsely presented as direct inspection of every original method. [ESME-S031, §§2.1–2.3.]

Fowler's 2004 strangler-fig account and revised 2024 presentation concern progressive displacement. They did not originate all incremental migration. The later mobile case illustrates one arrangement of native and replacement responsibilities, with a bridge and substantial contextual choices. It is a selected field account with concurrent changes, not a controlled estimate of the pattern's productivity benefit. [ESME-S035–ESME-S037.]

An incremental transition requires a workable partition, authority over routing and data, and a way to reconcile state. A quiescent cutover can eliminate many mixed-state obligations when interruption and a stable write boundary are genuinely achievable. Neither branch dominates by name. A hybrid can be worse than either: two writable representations may diverge while a gateway keeps both systems permanently necessary.

Schema evolution makes irreversibility explicit. If a conversion discards distinctions, no inverse can reconstruct them from the converted value alone without retained information or additional assumptions. The PRISM demonstration relates mappings and information-preserving transformations within a specific formal and prototype setting. That supports careful reasoning about applicability, not a general claim that arbitrary production migrations are reversible. Rehearsal, reconciliation and authority over real writes remain separate obligations. [ESME-S053, §III and demonstration; ESME-045, ESME-046.]

Undocumented behaviour can be part of what users actually depend on. Recovering it does not automatically sanctify it, but replacing it unknowingly can destroy useful functionality. The FBI Virtual Case File oversight account additionally warns against reducing a failed programme to technical novelty or a single causal story: requirements and management capabilities were among multiple interacting concerns. [ESME-S039, summary and lessons.]

The mature migration account therefore includes retirement of the transition machinery. If the old path, dual operation or gateway can never be removed, the supposed temporary mechanism has become another maintained system. That may still be justified, but its ongoing obligations and costs must be accepted as such rather than hidden in a permanently unfinished migration.

## 8. Debt and maintainability need an economic consumer

Cunningham's WyCash account uses debt to explain consequences of development choices and the need to consolidate understanding. Later technical-debt work develops more explicit concepts and prioritisation questions. The 2016 Dagstuhl discussions and the 2025 reframing do not justify labelling all defects, missing features or disliked code as one quantity. Nor does metaphorical principal or interest automatically acquire the measurement properties of a financial instrument. [ESME-S019, debt and consolidation; ESME-S048–ESME-S049.]

A useful debt candidate identifies the decision that incurred or retained a burden, a plausible future cost, who bears it and the horizon over which remediation could matter. The cost can be uncertain. A system near retirement may never repay an extensive restructuring; an urgent bounded correction may be preferable even when broader remediation is attractive later. Differences in whose costs are counted can change the priority without changing the code.

The inspected debt-productivity study contains a replication and extension with distinct reporting measures. Time fractions, fractions of tasks affected and time within affected tasks must not be pooled into a single universal waste percentage. Developer reports are meaningful field evidence but do not by themselves estimate the causal benefit of paying a specific debt item. [ESME-S032, design, results and validity threats.]

The synthesis retains bounded definitions, uncertainty-aware comparisons, affected-party prioritisation and bounded remediation. It rejects a universal zero-debt target. Maintainability metrics remain useful when their relation to a real task is justified and when they do not reward displacement of cost onto unmeasured consumers. ESME-049–ESME-054 make these distinctions explicit rather than converting “debt reduction” into an unconditional virtue.

## 9. Continuity is partly a human and ecosystem capability

A named owner is not the same thing as an available and capable maintainer. Repository-derived ownership and turnover measures can expose risks, but they cannot fully measure tacit knowledge, willingness or actual ability to diagnose a failure. Handoffs and onboarding need a consumer and, where consequential, a demonstration that the recipient can perform the required work. One person can fulfil several roles; the analysis does not require a new actor for each property. [ESME-S047, model and limitations; ESME-004, ESME-055, ESME-056.]

Dependency abandonment makes the boundary between information and power especially visible. The inspected interviews describe choices such as waiting, contributing, forking, vendoring or replacing. Each can impose substantial work. Popularity does not compel an upstream maintainer to continue, and a downstream assessment does not create the capacity to maintain a fork. Choosing a response therefore requires actual need, resources and legitimate responsibility, not merely an automated warning. [ESME-S043, methods and response strategies; ESME-S041.]

Deprecation is a communication and transition mechanism, not proof that users have migrated. Version-specific policies define their own scope and exceptions. PEP 387 is an example of a real policy, not a universal notice period for all projects. Soft deprecation can preserve a supported interface rather than guarantee its eventual removal. [ESME-S045, basic policy, incompatible changes and soft deprecation.]

Archival preservation and continued operation are different outcomes. The Software Heritage account supports identifiable source custody and distinguishes broader archival coverage from curation. It does not imply that every archived object is buildable, safe or supportable. Responsible retirement can end a live service while retaining justified historical artefacts; conversely, an archive may not satisfy a current user's need for a functioning service. [ESME-S054, §2.1 and §2.1.2; ESME-059, ESME-060.]

## 10. Automation changes the allocation of inquiry and review

Automated repair has several lineages and mechanisms. The inspected primary GenProg account uses evolutionary computation to search transformations against test-based fitness and then reduce patches. Its original authors' later retrospective clarifies the publication lineage, partial specifications and possible use cases. The 2009 original paper was not fully accessible; the 2010 account and 2025 retrospective are registered as distinct works, not interchangeable editions or independent replications. “Evolution” in this search procedure is not documentary evidence of descent from Lehman's empirical laws. [ESME-S065, §§2 and 6; ESME-S067, §§I–III.]

The important distinction is between plausible and correct repair. Historical adverse evidence includes weak tests, separate validation-infrastructure defects and limitations of a search space. These should not be collapsed into “all repair is overfitting”. Nor is equality with one developer patch the only possible definition of correctness. The mature mechanism treats generated patches as candidate interventions, gives independent obligations a chance to reject them, and preserves the difference between an oracle limitation and an implementation error. [ESME-S024, patch analysis; ESME-S026, adjudication; ESME-S067, repair quality.]

Positive evidence is also retained. SapFix documents bounded industrial use with human review before landing. A controlled study of repair assistance found that the quality of suggestions matters: correct patches can help while deceptive plausible patches can harm debugging. Neither result establishes that every generated patch needs the same review ceremony, or that a human signature repairs a weak oracle. [ESME-S055, generation, validation and landing; ESME-S052, design and results.]

Productivity claims are particularly sensitive to setting and date. METR's early-2025 randomised study involved experienced developers working in familiar repositories and measured a slowdown in that setting. Its 2026 follow-up discusses selection and design problems that prevent treating new estimates as a clean general effect of current tools. A separate 2026 survey measures self-reported experience, not the same causal quantity. The synthesis rejects both universal automation superiority and universal human-only superiority. [ESME-S025, primary outcome and limits; ESME-S033, interpretation; ESME-S034, survey limits.]

Contemporary benchmark investigation adds concerns about narrow tests, selected difficult subsets and possible contamination. A percentage from an intentionally selected subset is not a benchmark-wide defect rate. Model and hardware costs are also multidimensional: the inspected 2026 quantisation study compares particular models, tasks and hardware, so memory savings do not entail time or energy savings everywhere. Unchanged aggregate success can hide changes in which tasks succeed. [ESME-S027, audit sampling; ESME-S057, setup, results and limitations.]

AI-enabled systems also evolve through data and feedback rather than only source changes. The hidden-debt account explicitly imports the debt concept into machine-learning-system concerns such as entanglement and undeclared consumers. The recent policy-as-code study extends observation of non-code maintenance, but low commit share is not a labour-cost estimate and file presence is not proof of enforcement. These are genuine extensions of the maintenance boundary, not evidence that one repository-wide agent can safely govern them all. [ESME-S042, data and feedback sections; ESME-S056, RQ3 and threats.]

The current frontier is therefore bounded, testable assistance with explicit authority and complete cost accounting. General reliable unattended repository-scale maintenance remains an **examined unresolved claim**, not an impossibility theorem and not an established capability. ICSME 2026's September event lies after this cut-off; available 2026 research is identified by its actual publication or preprint status rather than represented as already replicated conference evidence. [ESME-S028; ESME-061–ESME-069.]

## 11. What composition contributes beyond a union of techniques

The Evolved system is a network of decisions and feedback, not a forced sequence of forms. Intent informs the acceptance question; recovered knowledge and impact analysis can expose a reason to revise that intent. A proposed transformation provides a new object for validation. A concurrent edit can invalidate evidence about an earlier baseline. Release observations can interrupt rollout and require forward repair rather than a code revert. Support loss or changed demand can reopen the choice between continued operation, maintenance, migration and retirement.

Three candidates arise from joining mechanisms. **ESME-072** binds evidence and acceptance to the actual candidate, objective and assumptions, and requires consequential changes to invalidate or reopen affected evidence. **ESME-073** addresses the reachable joint states created by concurrent changes, mixed versions and migration coexistence. **ESME-074** evaluates the combined cost and protective function of controls, including their substitution, consolidation and retirement. Their parts are source-grounded; the composed obligations and proposed architecture are explicitly analytical, not an already validated named method.

These additions are not cost-free. Binding can cause rechecking cascades; joint-state analysis can explode; a meta-process for controlling maintenance can cost more than the work it protects. The smallest adequate arrangement may be one capable authorised maintainer, a clear local objective, an identifiable candidate, sufficient understanding, a meaningful check and a feasible consequence/recovery decision. The model's role distinctions do not require separate people or independent documents.

A richer arrangement is justified by actual guards: conflicting obligation owners, distributed consumers, expensive regression, irreversible state, weak oracles, concurrent edits or lost support capacity. It can also be made simpler by constraining the problem—for example, establishing quiescence instead of validating every mixed version. The seven configurations preserve these alternatives. The analytical case tests below challenge the network with non-trigger, favourable, conflicting, changed-assumption and failed-observation cases. They test coherence and expose missing obligations; they do not constitute empirical validation of the whole system.

## 12. Research and bounded-completeness judgement

The study used historical backward tracing, forward criticism and derivative searches, and current searches across the ten mandatory families. The source table records exact inspected access, distinguishing full-text sections, abstract-only material, official catalogue scope and bibliography-only records. The coverage log is a grouped reconstruction of performed searches, not a fabricated exhaustive engine transcript. No fixed source or property total was treated as a research objective.

Saturation was judged at the level of decisions: whether more evidence altered a mechanism, prerequisite, criticism, genealogy edge, disposition or composition relation. Law critiques changed the no-change and growth claims; refactoring studies changed benefit and preservation claims; migration evidence preserved rival branches; ecosystem evidence changed continuity assumptions; recent repair and productivity evidence changed automation claims. Final tracing of repair and prioritisation strengthened existing origins without adding a distinct mechanism. All registered candidates and mandatory families have a reasoned disposition. Access limits and unresolved transfer questions remain visible rather than being called negative results.

The resulting freeze is a stable, independently usable research revision. It is **not** universal certainty, an exhaustive bibliography, a certification of standard compliance, proof of net benefit from the whole composition, or authorisation for downstream adoption. New evidence can require a new revision; later integration must preserve this revision's denominator and lineage while testing equivalence, redundancy, conflicts and target applicability.

## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_TIMELINE

These dates identify inspected anchors, not unique births of whole fields. Original publication, later interpretation and digitisation are kept separate. The RCS archive has an uncertain exact archival edition; its earlier-publication footnote is not treated as the date of every word in the copy.

**1976.** Swanson’s classification anchor and Belady–Lehman’s large-program model represent different problems: purpose distinctions and longitudinal development dynamics. [ESME-S004; ESME-S005; ESME-S008]

**1980–1983.** Lehman’s S/P/E framing, criterion-relative slicing, and maintenance guidance strengthen scope, analysis and management as distinct branches. [ESME-S009; ESME-S013; ESME-S005]

**1980s onward.** Revision-control work supplies selectable history and configurations; the exact retrieved RCS archival version remains qualified. [ESME-S030]

**1990.** Reverse-engineering taxonomy distinguishes analytical recovery from forms of transformation. [ESME-S012]

**1992.** Opdyke’s thesis formalises object-oriented refactoring; Cunningham’s WyCash account gives the debt metaphor an experience-based articulation. Similar concerns do not prove one descended from the other. [ESME-S018; ESME-S019]

**1994–1996.** Software aging, cognitive comprehension and impact analysis expose different sources of change difficulty. Evolution-law reformulation continues rather than replacing all these branches. [ESME-S050; ESME-S014; ESME-S016; ESME-S010]

**1998–2001.** Metamorphic testing, regression optimisation, legacy-migration comparisons and empirical open-source growth studies diversify methods. The 1998 metamorphic report was digitised on arXiv in 2020; it did not originate then. [ESME-S063; ESME-S066; ESME-S031; ESME-S023; ESME-S011; ESME-S006]

**2004–2006.** The strangler-fig account, mined co-change and observational maintenance questions contribute migration, history-based inference and inquiry mechanisms. [ESME-S035; ESME-S017; ESME-S015]

**2008–2012.** Classification reliability, schema mappings, GenProg, longer Linux histories and industrial refactoring studies test different assumptions. The original 2009 repair paper was traced through the inspected 2010 primary account and 2025 retrospective. [ESME-S007; ESME-S053; ESME-S065; ESME-S060; ESME-S021; ESME-S067]

**2013–2017.** Evolution reviews, long-lived FLOSS observations, oracle and mutation studies, repair criticism, knowledge-loss work, debt clarification, ML debt, ecosystem and variational-analysis experience extend scope and expose limits. [ESME-S029; ESME-S061; ESME-S051; ESME-S062; ESME-S024; ESME-S047; ESME-S048; ESME-S042; ESME-S040; ESME-S041; ESME-S064]

**2018–2022.** Bounded deployed repair, debt replication, refactoring replication, build-cost work and comprehension-proxy research qualify effectiveness. The 2022 maintenance standard’s official scope is inspected, not its paid clauses. [ESME-S055; ESME-S032; ESME-S020; ESME-S058; ESME-S022; ESME-S001]

**2023–2024.** Abandoned-dependency interviews, archival infrastructure, semantic conflicts, repair assistance and revised migration accounts examine human continuity and real operational boundaries. [ESME-S043; ESME-S054; ESME-S044; ESME-S052; ESME-S036; ESME-S037]

**2025.** Debt reframing, the original repair authors’ retrospective, patch-correctness analysis and a time-specific AI-productivity experiment continue criticism rather than establish universal automation. [ESME-S049; ESME-S067; ESME-S026; ESME-S025]

**2026 through 6 September.** Benchmark criticism, a confounded productivity follow-up, a self-report survey, non-code maintenance and quantisation research supply current evidence. ICSME’s September event is still future at this cut-off. [ESME-S027; ESME-S033; ESME-S034; ESME-S056; ESME-S057; ESME-S028]


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_GENEALOGY

The nodes below are plural branch reconstructions. A self-edge records a documented development inside an aggregated branch, not a claim that one work caused itself. Similar vocabulary alone is insufficient for an influence edge. The graph explicitly separates import, extension, criticism, shared ancestry, convergence, translation and analogy.

### ESME-G001 — Maintenance scope and classification

**Dates.** 1976; guidance 1983; later editions 2014–2024

**Problem.** Different reasons for changing already-existing software were conflated.

**Mechanism and contribution.** Purpose classifications and maintenance-management guidance.

**Contribution.** Separates motives and preparation/support/disposal responsibilities.

**Limits.** 1976 is an inspected historical anchor, not a claim that maintenance began then; Swanson’s original body unavailable.

**Reception and later development.** Refined taxonomies and standards persist; classification reliability remains contested.

**Properties.** `ESME-001`, `ESME-002`, `ESME-003`, `ESME-004`, `ESME-071`

[ESME-S001; ESME-S002; ESME-S003; ESME-S004; ESME-S005; ESME-S006; ESME-S007]

### ESME-G002 — Empirical evolution and feedback programme

**Dates.** 1976–1996/1997

**Problem.** Large long-lived software exhibited recurring growth, effort and complexity patterns.

**Mechanism and contribution.** Longitudinal measurement, S/P/E distinctions and conditional laws.

**Contribution.** Treats development and maintenance as evolving systems embedded in environments.

**Limits.** OS/360-based origins and later conceptual extensions do not establish universal laws.

**Reception and later development.** Linux, glibc and reviews test scope, metrics and interpretations.

**Properties.** `ESME-005`, `ESME-006`, `ESME-007`, `ESME-008`, `ESME-009`, `ESME-010`

[ESME-S008; ESME-S009; ESME-S010; ESME-S011; ESME-S029; ESME-S060; ESME-S061]

### ESME-G003 — Slicing and program comprehension

**Dates.** 1981; cognitive synthesis 1995; field questions 2006

**Problem.** Maintainers need relevant understanding of unfamiliar behaviour.

**Mechanism and contribution.** Criterion-relative analysis plus interacting cognitive and question-driven inquiry.

**Contribution.** Different evidence modes and task-bounded recovery of meaning.

**Limits.** No exhaustive general understanding or universally minimal slice.

**Reception and later development.** Later tools and question studies refine practical inquiry without one canonical workflow.

**Properties.** `ESME-011`, `ESME-012`, `ESME-013`, `ESME-015`, `ESME-016`

[ESME-S013; ESME-S014; ESME-S015]

### ESME-G004 — Configuration management

**Dates.** 1985 antecedent; later archived RCS revision of uncertain date

**Problem.** Multiple versions and shared development require controlled identity and history.

**Mechanism and contribution.** Revision storage, identification and configuration control.

**Contribution.** Recoverable baseline and ancestry for maintenance.

**Limits.** The inspected RCS text is a later archived revision; not all modern build/data state is captured by text versions.

**Reception and later development.** Guide treatment and reproducible-build definitions broaden relevant identity.

**Properties.** `ESME-003`, `ESME-036`

[ESME-S002; ESME-S030; ESME-S046]

### ESME-G005 — Reverse engineering and re-engineering taxonomy

**Dates.** 1990

**Problem.** Recovery, redocumentation and transformation were terminologically conflated.

**Mechanism and contribution.** Explicit definitions by abstraction and whether artefacts are altered.

**Contribution.** Separates analysis output from operative change.

**Limits.** Taxonomy clarifies activities; terminology remains plural in practice.

**Reception and later development.** Migration and recovery work reuse these distinctions without becoming one technique.

**Properties.** `ESME-012`, `ESME-014`, `ESME-015`

[ESME-S012; ESME-S031]

### ESME-G006 — Refactoring

**Dates.** 1992; industrial and empirical studies 2012–2022

**Problem.** Change-friendly structure without unintended behavioural difference.

**Mechanism and contribution.** Preconditioned transformations and later catalogue/tool practice.

**Contribution.** Makes preservation assumptions and future-change benefits examinable.

**Limits.** No general guarantee from tool branding; empirical metric results are not task benefit.

**Reception and later development.** Broad industrial uses coexist with strict definitions; differentiated replication narrows bug claims.

**Properties.** `ESME-023`, `ESME-024`, `ESME-025`, `ESME-026`, `ESME-027`, `ESME-028`

[ESME-S018; ESME-S020; ESME-S021; ESME-S022]

### ESME-G007 — Technical debt

**Dates.** 1992; 2016; 2024 seminar/2025 publication

**Problem.** Expedient delivery and incomplete understanding can impose later work.

**Mechanism and contribution.** Debt metaphor, later definitions and contingent investment models.

**Contribution.** Makes delayed costs and changing options explicit.

**Limits.** Not all bad code is debt; no universally validated interest measure.

**Reception and later development.** Productivity replication and reframing agenda retain uncertainty and decision context.

**Properties.** `ESME-049`, `ESME-050`, `ESME-051`, `ESME-052`, `ESME-053`, `ESME-054`

[ESME-S019; ESME-S032; ESME-S048; ESME-S049]

### ESME-G008 — Change impact and historical coupling

**Dates.** 1996 synthesis; 2004/2005 repository mining

**Problem.** Changes propagate through relationships not obvious from the edited text.

**Mechanism and contribution.** Dependency analysis, traceability and mined co-change recommendations.

**Contribution.** Supplies candidate impact boundaries and overlooked companion work.

**Limits.** Historical correlation is not a necessary semantic dependency.

**Reception and later development.** Semantic-conflict and ecosystem research add evidence types and expose limits.

**Properties.** `ESME-017`, `ESME-018`, `ESME-019`, `ESME-020`, `ESME-021`, `ESME-022`

[ESME-S016; ESME-S017; ESME-S041; ESME-S044]

### ESME-G009 — Regression evidence and partial oracles

**Dates.** 1998; 1999; 2001; 2014–2017

**Problem.** Testing is costly and expected outcomes are often incomplete.

**Mechanism and contribution.** Selection, prioritisation, metamorphic relations, mutation and differential comparison.

**Contribution.** Separates which observations, when they occur and what they warrant.

**Limits.** Each method has a model, cost and oracle boundary; none proves general correctness.

**Reception and later development.** Repair studies and CI optimisation make these limits newly consequential.

**Properties.** `ESME-029`, `ESME-030`, `ESME-031`, `ESME-032`, `ESME-033`, `ESME-034`, `ESME-035`

[ESME-S023; ESME-S051; ESME-S062; ESME-S063; ESME-S064; ESME-S066]

### ESME-G010 — Legacy migration and modernisation

**Dates.** 1999 review; 2004 original account; 2009 schema prototype; 2024 refinements

**Problem.** Useful systems need adaptation without discarding embedded obligations.

**Mechanism and contribution.** Wrapping, incremental displacement, quiescent cutover and schema mappings.

**Contribution.** Preserves rival migration strategies and transition-state obligations.

**Limits.** Selected cases and prototypes do not establish universal strategy superiority.

**Reception and later development.** Strangler accounts refine incremental displacement; incidents expose recovery gaps.

**Properties.** `ESME-039`, `ESME-040`, `ESME-041`, `ESME-042`, `ESME-043`, `ESME-044`, `ESME-045`, `ESME-046`, `ESME-047`, `ESME-048`

[ESME-S031; ESME-S035; ESME-S036; ESME-S037; ESME-S038; ESME-S039; ESME-S053]

### ESME-G011 — Automated program repair

**Dates.** 2009 origins documented through 2010 primary account; 2015 criticism; 2018 deployment; 2025 retrospective

**Problem.** Fault localisation and patch search are labour-intensive.

**Mechanism and contribution.** Test-guided program variation and validation; later candidate/review workflows.

**Contribution.** Demonstrates useful bounded automation and forces scrutiny of patch quality.

**Limits.** Tests are partial; selected examples and particular search spaces do not establish general repair.

**Reception and later development.** LLM generation broadens candidates while oracle, cost and authority questions survive.

**Properties.** `ESME-061`, `ESME-062`, `ESME-063`, `ESME-064`, `ESME-068`, `ESME-069`

[ESME-S024; ESME-S052; ESME-S055; ESME-S065; ESME-S067]

### ESME-G012 — Human and ecosystem continuity

**Dates.** 2016–2023

**Problem.** Long-lived dependencies and knowledge can become unsupported.

**Mechanism and contribution.** Knowledge-loss models, maintainer interviews and dependency-network studies.

**Contribution.** Distinguishes project activity, support capacity and actual downstream obligations.

**Limits.** Proxies, selection and resource constraints limit prediction and remedy.

**Reception and later development.** Responses include no-change, funding, forks, replacement and retirement rather than one universal practice.

**Properties.** `ESME-005`, `ESME-055`, `ESME-056`, `ESME-057`, `ESME-058`, `ESME-059`, `ESME-060`

[ESME-S040; ESME-S041; ESME-S043; ESME-S047; ESME-S054]

### ESME-G013 — Learned and non-code artefact evolution

**Dates.** 2015; 2026

**Problem.** Code-only maintenance misses data feedback and executable policy.

**Mechanism and contribution.** ML-debt analysis and empirical policy-as-code maintenance study.

**Contribution.** Includes consequential data, configuration, model and policy consumers.

**Limits.** Industrial concepts and observational commit data do not establish universal benefit or enforcement.

**Reception and later development.** Current frontier requires task-specific oracles and real consumer/effect evidence.

**Properties.** `ESME-018`, `ESME-065`, `ESME-066`

[ESME-S042; ESME-S056]

### ESME-G014 — LLM-assisted maintenance and evaluation revision

**Dates.** 2024–2026

**Problem.** Rapidly improving generation outpaces trustworthy evaluation and cost accounting.

**Mechanism and contribution.** Human-task experiments, benchmark audits and platform-specific efficiency studies.

**Contribution.** Separates generation speed, plausible repair, correctness and total work.

**Limits.** Current estimates face selection, leakage, changing tools and limited long-term observation.

**Reception and later development.** No general pro- or anti-automation conclusion survives; narrow effective configurations remain viable.

**Properties.** `ESME-061`, `ESME-062`, `ESME-063`, `ESME-064`, `ESME-068`, `ESME-069`

[ESME-S025; ESME-S026; ESME-S027; ESME-S033; ESME-S034; ESME-S052; ESME-S057; ESME-S067]

**ESME-GE001: ESME-G001 → ESME-G001, `EXPLICIT_EXTENSION`.** Later guidance and Chapin’s abstract explicitly organise/refine maintenance classifications. Limit: No unread class-level reconstruction of the inaccessible originals. [ESME-S002; ESME-S005; ESME-S006]

**ESME-GE002: ESME-G002 → ESME-G002, `CRITICISM_AND_RESPONSE`.** Linux/glibc studies and the review explicitly test or reinterpret Lehman’s laws. Limit: Same Linux population and review reuse are not independent replications. [ESME-S011; ESME-S029; ESME-S060; ESME-S061]

**ESME-GE003: ESME-G003 → ESME-G008, `DOCUMENTED_IMPORT`.** Impact analysis uses program-dependence/slicing concepts discussed in the inspected introduction and methods. Limit: Does not imply all impact tools derive from a single slicing algorithm. [ESME-S013; ESME-S016]

**ESME-GE004: ESME-G003 → ESME-G005, `CONVERGENT_DEVELOPMENT`.** Both address recovering information from existing programs at different levels. Limit: This relationship is conceptual convergence, not a claimed personal transmission. [ESME-S012; ESME-S013; ESME-S014]

**ESME-GE005: ESME-G004 → ESME-G008, `DOCUMENTED_IMPORT`.** ROSE uses revision histories as the empirical input for mined co-change. Limit: Use of version histories does not imply RCS specifically caused ROSE. [ESME-S017]

**ESME-GE006: ESME-G005 → ESME-G010, `DOCUMENTED_IMPORT`.** The legacy-migration review uses reverse/re-engineering categories in classifying options. Limit: The review is not the original source of all migration methods it describes. [ESME-S012; ESME-S031]

**ESME-GE007: ESME-G006 → ESME-G007, `SHARED_ANCESTRY`.** Both arise in change-intensive object-oriented development and address future change burden. Limit: No claim that one 1992 work directly caused the other. [ESME-S018; ESME-S019]

**ESME-GE008: ESME-G006 → ESME-G006, `CRITICISM_AND_RESPONSE`.** Industrial/metric studies and the differentiated replication directly examine refactoring meanings and outcomes. Limit: Mixed evidence does not yield a universal causal benefit or harm. [ESME-S020; ESME-S021; ESME-S022]

**ESME-GE009: ESME-G007 → ESME-G007, `EXPLICIT_EXTENSION`.** 2016 definitions and the 2025 reframing explicitly revisit technical debt. Limit: Seminar agreement and agenda are not comparative validation. [ESME-S048; ESME-S049]

**ESME-GE010: ESME-G007 → ESME-G013, `DOCUMENTED_IMPORT`.** Hidden Technical Debt in Machine Learning Systems explicitly applies the debt concept to ML-system mechanisms. Limit: Deterministic equivalence does not transfer automatically to learned outcomes. [ESME-S042]

**ESME-GE011: ESME-G009 → ESME-G011, `DOCUMENTED_IMPORT`.** The GenProg primary account uses test cases as fitness and acceptance evidence. Limit: Test use is not complete specification satisfaction. [ESME-S065]

**ESME-GE012: ESME-G011 → ESME-G011, `CRITICISM_AND_RESPONSE`.** Repair-quality analysis and the original-author retrospective explicitly address partial oracles and overfitting. Limit: The retrospective is an author response, not independent confirmation of deployment quality. [ESME-S024; ESME-S067]

**ESME-GE013: ESME-G011 → ESME-G014, `EXPLICIT_EXTENSION`.** The original-author retrospective discusses later machine-learning/synthesis approaches in the repair research programme. Limit: This is not documentary proof that every code-assistant product descends causally from GenProg. [ESME-S067]

**ESME-GE014: ESME-G009 → ESME-G009, `DOCUMENTED_INFLUENCE`.** Kästner explicitly identifies exposure to differential-testing work and earlier suggestions in his development account. Limit: Underlying cited papers not separately read; the edge establishes this author’s reported influence only. [ESME-S064]

**ESME-GE015: ESME-G010 → ESME-G010, `EXPLICIT_EXTENSION`.** Fowler’s revised account and mobile migration article explicitly develop strangler-fig application practice. Limit: Separate editions/cases are not independent replications of comparative superiority. [ESME-S035; ESME-S036; ESME-S037]

**ESME-GE016: ESME-G008 → ESME-G012, `DOMAIN_TRANSLATION`.** Dependency evidence is studied at package-ecosystem scale rather than only within one system. Limit: Translation is analytical; graph edges do not directly measure runtime failure. [ESME-S041]

**ESME-GE017: ESME-G012 → ESME-G013, `CONVERGENT_DEVELOPMENT`.** Both require identifying consumers beyond direct code edits. Limit: No unsupported influence edge from identical vocabulary. [ESME-S042; ESME-S043; ESME-S056]

**ESME-GE018: ESME-G002 → ESME-G011, `ONLY_ANALOGOUS`.** Both use the word evolution, but Lehman’s longitudinal software evolution and genetic-programming search concern different mechanisms. Limit: Biological/search analogy is not evidence of a shared law or direct intellectual derivation. [ESME-S008; ESME-S009; ESME-S065; ESME-S067]

**ESME-GE019: ESME-G008 → ESME-G008, `EXPLICIT_EXTENSION`.** Semantic conflict analysis addresses interactions of concurrently changed versions using dependence/flow evidence. Limit: References establish a research relationship, not a complete automatic intent oracle. [ESME-S044]

**ESME-GE020: ESME-G009 → ESME-G014, `CRITICISM_AND_RESPONSE`.** LLM patch and benchmark studies continue to confront partial oracles and tests-versus-correctness. Limit: Shared benchmark data and interested authorship are retained as validity limits. [ESME-S026; ESME-S027; ESME-S057; ESME-S067]


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_SCOPE_AND_CARICATURES

The research boundary is existing software and its continuing or deliberately ended obligations. Maintenance is not only post-delivery defect repair; evolution is not compulsory functionality growth; refactoring is not any helpful code edit; reverse engineering is not itself re-engineering; a clean merge is not semantic agreement; regression success is not a complete oracle; migration is not automatically an upgrade; debt is not every undesirable item; a maintainer name is not capacity; a source archive is not a running service; and a generated patch is not an authorised or correct change. These rejected caricatures must not be attributed to every author in the field.

Not a census of every publication or all maintenance tools. Candidate population is decision-relevant mechanisms and tested generalisations within the ten mandatory families.

Hardware repair-time/reliability modelling, operations in isolation and general security engineering are outside scope. Security-response examples are included only for their maintenance consequences.

No requester repository, earlier Evolved corpus, sibling output or target-specific runtime was consulted. No adoption, issue, code, release or target crosswalk was proposed.

Official standard scope/edition is distinguished from inaccessible paid clauses. This is not a standard-conformance certification.

No causal performance guarantee or empirical validation is claimed for the composed Evolved system.

Current evidence is through 2026-09-06. ICSME 2026’s September event is still future; accessible accepted/preprint research is not future proceedings evidence.

The ten mandatory families are all examined. General hardware maintainability, operations detached from change, all-purpose development ideology and full security engineering are outside scope. Relevant security response, architectural reconstruction and product-configuration effects remain legitimate maintenance intersections. Sources and mechanisms overlap with other fields; no sibling synthesis was read to remove or pre-resolve those overlaps.


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER

The entire denominator is enumerated below, including six rejected generalisations, one duplicate, one ritual-only candidate and one unresolved capability claim. **65 candidates are crosswalk-worthy questions; they are not 65 unconditional controls.** Every row resolves to a complete JSON record with all common and domain-profile fields.

| Primary disposition | Candidates |
|---|---:|
| `ASSUMPTION_SENSITIVE` | 12 |
| `CEREMONY_NOT_GENERAL_PROPERTY` | 1 |
| `CONTEXT_DEPENDENT` | 14 |
| `DOMAIN_SPECIFIC` | 2 |
| `DUPLICATE_CANDIDATE` | 1 |
| `REJECTED_OR_DISFAVOURED` | 6 |
| `RETAINED_IN_EVOLVED_FORM` | 25 |
| `STRONGLY_RETAINED` | 11 |
| `UNRESOLVED` | 1 |
| `USEFUL_BUT_EASILY_GAMED` | 1 |
| **Total** | **74** |

| Property ID | Candidate | Primary disposition | Examination | Complete record |
|---|---|---|---|---|
| `ESME-001` | Explicit and authorised change intent | `STRONGLY_RETAINED` | `EXAMINED` | [ESME-001: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/0) |
| `ESME-002` | Multi-purpose change classification | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED_WITH_EVIDENCE_LIMIT` | [ESME-002: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/1) |
| `ESME-003` | Recoverable configuration baseline | `STRONGLY_RETAINED` | `EXAMINED` | [ESME-003: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/2) |
| `ESME-004` | Maintenance readiness across the delivery boundary | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED_WITH_EVIDENCE_LIMIT` | [ESME-004: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/3) |
| `ESME-005` | Deliberate non-change | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-005: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/4) |
| `ESME-006` | Evolution feedback with measurable consequences | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-006: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/5) |
| `ESME-007` | Population-scoped evolution-law interpretation | `ASSUMPTION_SENSITIVE` | `EXAMINED` | [ESME-007: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/6) |
| `ESME-008` | Costed complexity and anti-regressive work | `CONTEXT_DEPENDENT` | `EXAMINED` | [ESME-008: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/7) |
| `ESME-009` | Familiarity and knowledge-capacity constraints | `CONTEXT_DEPENDENT` | `EXAMINED` | [ESME-009: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/8) |
| `ESME-010` | Universal mandatory growth or inevitable deterioration | `REJECTED_OR_DISFAVOURED` | `EXAMINED` | [ESME-010: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/9) |
| `ESME-011` | Question-bounded program comprehension | `STRONGLY_RETAINED` | `EXAMINED` | [ESME-011: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/10) |
| `ESME-012` | Static and dynamic evidence triangulation | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-012: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/11) |
| `ESME-013` | Criterion-relative program slicing | `ASSUMPTION_SENSITIVE` | `EXAMINED_WITH_EVIDENCE_LIMIT` | [ESME-013: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/12) |
| `ESME-014` | Distinguish recovery from transformation | `STRONGLY_RETAINED` | `EXAMINED` | [ESME-014: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/13) |
| `ESME-015` | Recover intent with rationale and human knowledge | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-015: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/14) |
| `ESME-016` | Exhaustive system comprehension before every change | `REJECTED_OR_DISFAVOURED` | `EXAMINED_WITH_EVIDENCE_LIMIT` | [ESME-016: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/15) |
| `ESME-017` | Justified impact boundary | `STRONGLY_RETAINED` | `EXAMINED` | [ESME-017: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/16) |
| `ESME-018` | Heterogeneous dependency propagation | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-018: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/17) |
| `ESME-019` | Historical co-change as defeasible evidence | `ASSUMPTION_SENSITIVE` | `EXAMINED` | [ESME-019: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/18) |
| `ESME-020` | Affected-consumer discovery | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-020: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/19) |
| `ESME-021` | Impact false-negative challenge | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-021: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/20) |
| `ESME-022` | Semantic interference analysis for merged changes | `ASSUMPTION_SENSITIVE` | `EXAMINED_WITH_EVIDENCE_LIMIT` | [ESME-022: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/21) |
| `ESME-023` | Observer-relative preservation obligations | `STRONGLY_RETAINED` | `EXAMINED` | [ESME-023: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/22) |
| `ESME-024` | Transformation preconditions and model scope | `ASSUMPTION_SENSITIVE` | `EXAMINED_WITH_EVIDENCE_LIMIT` | [ESME-024: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/23) |
| `ESME-025` | Validation of the actual transformed artefact | `STRONGLY_RETAINED` | `EXAMINED` | [ESME-025: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/24) |
| `ESME-026` | Separate preservation from intentional behaviour change | `STRONGLY_RETAINED` | `EXAMINED` | [ESME-026: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/25) |
| `ESME-027` | Refactoring benefit tied to a future change class | `CONTEXT_DEPENDENT` | `EXAMINED` | [ESME-027: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/26) |
| `ESME-028` | Cleaner structure guarantees engineering benefit | `REJECTED_OR_DISFAVOURED` | `EXAMINED` | [ESME-028: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/27) |
| `ESME-029` | Oracle provenance and independent obligations | `STRONGLY_RETAINED` | `EXAMINED` | [ESME-029: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/28) |
| `ESME-030` | Characterisation as provisional behavioural evidence | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-030: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/29) |
| `ESME-031` | Differential testing with adjudicated differences | `CONTEXT_DEPENDENT` | `EXAMINED` | [ESME-031: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/30) |
| `ESME-032` | Metamorphic relations as partial oracles | `ASSUMPTION_SENSITIVE` | `EXAMINED_WITH_EVIDENCE_LIMIT` | [ESME-032: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/31) |
| `ESME-033` | Mutation analysis as an adequacy probe | `CONTEXT_DEPENDENT` | `EXAMINED` | [ESME-033: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/32) |
| `ESME-034` | Regression selection under explicit safety and cost assumptions | `ASSUMPTION_SENSITIVE` | `EXAMINED` | [ESME-034: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/33) |
| `ESME-035` | Test prioritisation under interruption and feedback costs | `CONTEXT_DEPENDENT` | `EXAMINED` | [ESME-035: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/34) |
| `ESME-036` | Reproducible and identifiable build evidence | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-036: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/35) |
| `ESME-037` | Continuous integration with consumed feedback | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-037: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/36) |
| `ESME-038` | Declared compatibility surface and version policy | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-038: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/37) |
| `ESME-039` | Mixed-version compatibility conditions | `ASSUMPTION_SENSITIVE` | `EXAMINED_WITH_EVIDENCE_LIMIT` | [ESME-039: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/38) |
| `ESME-040` | Staged exposure with actionable observations | `CONTEXT_DEPENDENT` | `EXAMINED` | [ESME-040: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/39) |
| `ESME-041` | State-and-effect recovery rather than code reversion alone | `STRONGLY_RETAINED` | `EXAMINED` | [ESME-041: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/40) |
| `ESME-042` | Compare maintenance, migration, replacement and non-change | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-042: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/41) |
| `ESME-043` | Incremental displacement with bounded coexistence | `CONTEXT_DEPENDENT` | `EXAMINED` | [ESME-043: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/42) |
| `ESME-044` | Quiescent or big-bang cutover as a conditional alternative | `DOMAIN_SPECIFIC` | `EXAMINED_WITH_EVIDENCE_LIMIT` | [ESME-044: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/43) |
| `ESME-045` | Migration state reconciliation and data authority | `ASSUMPTION_SENSITIVE` | `EXAMINED` | [ESME-045: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/44) |
| `ESME-046` | Schema mappings and information-loss analysis | `ASSUMPTION_SENSITIVE` | `EXAMINED_WITH_EVIDENCE_LIMIT` | [ESME-046: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/45) |
| `ESME-047` | Retire migration scaffolding and duplicate operation | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-047: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/46) |
| `ESME-048` | Technical novelty or age decides replacement | `REJECTED_OR_DISFAVOURED` | `EXAMINED` | [ESME-048: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/47) |
| `ESME-049` | Bounded technical-debt identification | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-049: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/48) |
| `ESME-050` | Contingent lifecycle economics | `ASSUMPTION_SENSITIVE` | `EXAMINED_WITH_EVIDENCE_LIMIT` | [ESME-050: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/49) |
| `ESME-051` | Debt prioritisation across affected stakeholders | `CONTEXT_DEPENDENT` | `EXAMINED` | [ESME-051: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/50) |
| `ESME-052` | Bounded remediation with payoff reassessment | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-052: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/51) |
| `ESME-053` | Maintainability measures as validated proxies | `USEFUL_BUT_EASILY_GAMED` | `EXAMINED` | [ESME-053: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/52) |
| `ESME-054` | Mandatory comprehensive cleanup or zero debt | `REJECTED_OR_DISFAVOURED` | `EXAMINED` | [ESME-054: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/53) |
| `ESME-055` | Maintainership capacity and continuity | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-055: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/54) |
| `ESME-056` | Handoff and onboarding through demonstrated capability | `CONTEXT_DEPENDENT` | `EXAMINED` | [ESME-056: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/55) |
| `ESME-057` | Deprecation communication with actionable transition | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-057: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/56) |
| `ESME-058` | Dependency viability and response alternatives | `CONTEXT_DEPENDENT` | `EXAMINED` | [ESME-058: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/57) |
| `ESME-059` | Archival identity without a false execution guarantee | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED_WITH_EVIDENCE_LIMIT` | [ESME-059: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/58) |
| `ESME-060` | Responsible service retirement and residual obligations | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED_WITH_EVIDENCE_LIMIT` | [ESME-060: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/59) |
| `ESME-061` | Generated repairs remain candidate interventions | `STRONGLY_RETAINED` | `EXAMINED` | [ESME-061: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/60) |
| `ESME-062` | Benchmark and evaluation provenance | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-062: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/61) |
| `ESME-063` | End-to-end automation cost and outcome assessment | `CONTEXT_DEPENDENT` | `EXAMINED` | [ESME-063: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/62) |
| `ESME-064` | Acceptance authority distinct from generation capability | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-064: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/63) |
| `ESME-065` | Learned-system data and feedback evolution | `DOMAIN_SPECIFIC` | `EXAMINED_WITH_EVIDENCE_LIMIT` | [ESME-065: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/64) |
| `ESME-066` | Executable-policy and non-code artefact evolution | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED` | [ESME-066: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/65) |
| `ESME-067` | Bounded revision of maintenance methods | `CONTEXT_DEPENDENT` | `EXAMINED_WITH_EVIDENCE_LIMIT` | [ESME-067: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/66) |
| `ESME-068` | Human-only maintenance is universally superior | `REJECTED_OR_DISFAVOURED` | `EXAMINED` | [ESME-068: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/67) |
| `ESME-069` | Reliable unattended repository-scale maintenance as a general capability | `UNRESOLVED` | `EXAMINED_WITH_EVIDENCE_LIMIT` | [ESME-069: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/68) |
| `ESME-070` | Golden-master preservation as a separate mechanism | `DUPLICATE_CANDIDATE` | `EXAMINED` | [ESME-070: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/69) |
| `ESME-071` | A formal change board for every change | `CEREMONY_NOT_GENERAL_PROPERTY` | `EXAMINED` | [ESME-071: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/70) |
| `ESME-072` | Evidence-to-action binding and invalidation | `RETAINED_IN_EVOLVED_FORM` | `EXAMINED_WITH_EVIDENCE_LIMIT` | [ESME-072: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/71) |
| `ESME-073` | Continuity of obligations across temporary joint states | `ASSUMPTION_SENSITIVE` | `EXAMINED_WITH_EVIDENCE_LIMIT` | [ESME-073: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/72) |
| `ESME-074` | Feedback-driven proportionality and retirement of maintenance controls | `CONTEXT_DEPENDENT` | `EXAMINED_WITH_EVIDENCE_LIMIT` | [ESME-074: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/73) |

**Examination totals:** 55 examined; 19 examined with evidence limits; 0 not examined. An evidence limit can concern original-body access, model applicability or unvalidated synthesis; it is not silently treated as a negative experiment.


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_DOMAIN_MODELS

These are reconstructed analytical models, not claimed canonical diagrams. M1–M10 implement the ten required models; the final model describes their composition. The profile names are stable machine keys. Each property also carries a complete, property-qualified profile in the ledger.

### ESME-DM-M1 — Change classification and legitimate objective

**Model.** A change is represented as a baseline B, a proposed difference Δ, a set of purposes C, intended changed obligations I and surviving obligations P. C is a set, not necessarily one mutually exclusive label. Acceptance needs an authorised interpretation of I and P; classification alone supplies neither.

**Operation.** The requester and maintainer clarify intended effects, affected parties challenge conflicts, and an authorised actor chooses change, deferral, non-change or retirement. New evidence can reopen intent without silently rewriting already-used acceptance evidence.

**Limit and evidence status.** This is an analytical decision model, not a proof that stakeholder agreement produces a beneficial objective. Swanson and Chapin body-access limits preclude detailed original-taxonomy claims. ANALYTICAL_RECONSTRUCTION_OF_INSPECTED_SOURCES; no empirical validation of the integrated model

**CHANGE_INTENT_AND_CHANGE_CLASS.** Corrective restores accepted intent; adaptive responds to environment; perfective changes capability or useful qualities; preventive reduces prospective problems. A single intervention can serve several purposes.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify the system/configuration being changed and any non-code artefact needed to interpret the request. A source commit alone may omit deployed data and obligations.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Separate the observations that must differ from those that must survive. Current obligation holders, including downstream users where relevant, determine what is accepted rather than copying old tests unquestioningly.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Begin with affected purposes and consumers; expand when interfaces, data or ownership cross the proposed local boundary. A request label is not dependency evidence.

**COMPREHENSION_ASSUMPTIONS.** The maintainer needs enough understanding to interpret the change and recognise disputed assumptions; complete historical reconstruction is not a universal prerequisite.

**ORACLE_AND_REGRESSION_LIMITS.** Tests need expectations justified by intent or independently adjudicated behaviour. Passing the old suite may preserve the wrong objective.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Compatibility and migration are applicable when other consumers or persistent representations are affected; for a purely local inquiry with no intervention they are not yet operative obligations.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** An approval does not establish deployability or reversibility. Consequential release requires separately justified state/effect recovery or forward repair.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Request/obligation owners, maintainers, reviewers, operators and affected consumers have distinct information and powers; one person may fulfil several roles.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

[ESME-S001; ESME-S002; ESME-S004; ESME-S005; ESME-S006; ESME-S007; ESME-S039; ESME-S040]

### ESME-DM-M2 — Evolution feedback and scope

**Model.** Observe a trajectory X(t) = (usefulness, demand, artefact size/structure, effort, familiarity, environment) under declared measures. A law is a scoped claim about some components of X, not an instruction to maximise size. Total complexity and mean complexity per function are different observables.

**Operation.** Compare anticipated effects with observed use and maintenance burden; investigate deviations, competing explanations and changed objectives. Feedback changes prioritisation or supports deliberate non-change; it is not necessarily a serial release cycle.

**Limit and evidence status.** Longitudinal associations do not identify causal feedback. E-type classification, stage, aggregation, organisational factors and conditional clauses affect interpretation. ANALYTICAL_RECONSTRUCTION_OF_INSPECTED_SOURCES; no empirical validation of the integrated model

**CHANGE_INTENT_AND_CHANGE_CLASS.** Changes may respond to external expectations, defects, opportunities or internal difficulty. Growth itself is not an authorised objective or necessary change class.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Use comparable system/version boundaries over time; separate source size, feature count, local complexity and organisational work rather than calling them one growth variable.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The observer includes users’ usefulness and maintainers’ ability to change, not just line counts. Preserve required service while allowing deliberate simplification or changed requirements.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Explanations may involve organisation, ecosystem and usage as well as code. Time-series correlation does not establish an impact edge.

**COMPREHENSION_ASSUMPTIONS.** People’s familiarity and limits must be observed through actual tasks or credible evidence; a repository ownership proxy is incomplete.

**ORACLE_AND_REGRESSION_LIMITS.** Trends are not test oracles. A local regression suite cannot establish the causal validity of an evolution law or long-term continued usefulness.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Migration is one possible response to feedback, not an inevitable mature phase. Compare coexistence and replacement burdens before selecting it.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Feedback can stop or defer rollout, but state restoration needs independent feasibility evidence; a favourable trend is not a release guarantee.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Users, maintainers and managers exchange demand, effort and outcome observations; responsibility for priorities remains with legitimate decision makers.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.

[ESME-S008; ESME-S009; ESME-S010; ESME-S011; ESME-S029; ESME-S050; ESME-S060; ESME-S061]

### ESME-DM-M3 — Question-bounded comprehension and recovery

**Model.** Let Q be the questions needed for the proposed change and H the maintainer’s provisional explanation. Static structure, traces, history and human testimony provide different evidence E. Inquiry updates H and may expand Q when a counterexample reveals an omitted consequence.

**Operation.** Locate a feature or value, inspect relevant dependencies, exercise behaviour and ask knowledgeable consumers where intent is missing. Distinguish redocumentation or reverse engineering from actual restructuring or re-engineering.

**Limit and evidence status.** Agreement among incomplete views is not complete understanding. A slice preserves a criterion under its model, not arbitrary external behaviour. ANALYTICAL_RECONSTRUCTION_OF_INSPECTED_SOURCES; no empirical validation of the integrated model

**CHANGE_INTENT_AND_CHANGE_CLASS.** Comprehension is directed by the intended repair, adaptation, restructuring or migration question; inquiry alone need not change behaviour.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Use source, generated artefacts, build/configuration state, execution traces, relevant history and rationale where each is needed to answer Q.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Name the value, behaviour, feature or consumer being explained. Recovering what happens does not determine whether it should continue.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Slices and feature-location results are starting boundaries; reflection, environment and tacit operational dependencies can require expansion.

**COMPREHENSION_ASSUMPTIONS.** Understanding is provisional and task-bounded. Static and dynamic evidence have complementary omissions; access to tacit expertise may be essential.

**ORACLE_AND_REGRESSION_LIMITS.** A plausible explanation is not an oracle. Characterisation can support prediction but may capture a defect; unknown behaviour remains explicitly unknown.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** For analysis-only work, compatibility checks are not an executed migration obligation. A later transformation must use the recovered model without assuming it is complete.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Recovery of a model does not establish a recoverable deployment. An operative change requires separate release/effect evidence.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainers, domain experts and operators answer different questions. Current obligation owners adjudicate whether historical intent still applies.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

[ESME-S012; ESME-S013; ESME-S014; ESME-S015; ESME-S047; ESME-S051]

### ESME-DM-M4 — Impact propagation and boundary challenge

**Model.** Represent artefacts/consumers as nodes and typed dependencies as guarded edges. The candidate impact set is reachability from a change through relevant edges, plus explicitly uncertain effects. Static, dynamic and historical edges carry different evidential meanings.

**Operation.** Construct a bounded impact hypothesis, identify affected consumers, challenge likely false negatives and reassess merged changes. A necessary semantic dependency differs from a historically common companion edit.

**Limit and evidence status.** Graphs can omit undeclared consumers or over-approximate possible behaviour. Absence of a detected edge is not proof of independence. ANALYTICAL_RECONSTRUCTION_OF_INSPECTED_SOURCES; no empirical validation of the integrated model

**CHANGE_INTENT_AND_CHANGE_CLASS.** The intended difference determines which dependency paths matter; a documentation-only update and a schema rewrite need different propagation inquiries.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Include code, API, schema, protocol, configuration, build, policy and relevant ownership/deployment state rather than a universal source-file-only graph.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Impacted observers include direct callers, data readers, operators and combined changes. Preserve their accepted obligations, not every correlation in history.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Label each edge as declared, structurally inferred, dynamically observed or historically correlated and state its guard. Challenge missed paths proportional to consequence.

**COMPREHENSION_ASSUMPTIONS.** The maintainer must understand enough semantics to interpret a candidate edge; a high-confidence predictor cannot replace that interpretation.

**ORACLE_AND_REGRESSION_LIMITS.** Test selected impact hypotheses and plausible omissions. Tool recall on reused benchmark cases does not guarantee target recall.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Identify supported version/schema combinations when dependencies cross deployment or ecosystem boundaries; consumers may upgrade independently.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** A broader impact boundary can require staged release, forward repair or coordinated recovery. A local source revert may not reverse propagated effects.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Producer maintainers communicate affected obligations to reviewers and consumers; independent consumers retain authority over their systems.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

[ESME-S013; ESME-S016; ESME-S017; ESME-S041; ESME-S042; ESME-S044]

### ESME-DM-M5 — Observer-relative preservation and transformation

**Model.** For a declared environment set E and observer O, a preserving transformation seeks O(B,e)=O(B′,e) for the required observations and e in E. Intended changes are separately specified. This equation defines the obligation; it is not a generally decidable equivalence procedure.

**Operation.** Choose a transformation and check model preconditions, then validate the actual resulting artefact. Where preservation and feature change are combined, keep their acceptance obligations distinct even when one patch is necessary.

**Limit and evidence status.** A proof or catalogue rule only covers its semantics. Timing, resource use, reflection, persistence and external integrations can introduce observers outside a tool’s model. ANALYTICAL_RECONSTRUCTION_OF_INSPECTED_SOURCES; no empirical validation of the integrated model

**CHANGE_INTENT_AND_CHANGE_CLASS.** Refactoring preserves the declared external behaviour; repair and feature change intentionally alter some obligations. Mixed changes require an explicit distinction, not always separate commits.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Bind before/after source, language/tool version, configuration and persistent representations to the actual applied transformation.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Declare relevant O and E, including exceptions, side effects and performance when part of the supported contract; do not assume all internal differences are observable obligations.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use semantic dependency evidence to determine which consumers could observe the transformation, including reflective and external uses.

**COMPREHENSION_ASSUMPTIONS.** Applicability requires understanding of the transformation’s preconditions and exclusions. A formal rule does not prove that the implementation satisfies them.

**ORACLE_AND_REGRESSION_LIMITS.** Test passage provides partial evidence. Independent preservation obligations and tests of the actual transformed candidate can expose tool or integration defects.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Renaming or restructuring exposed entities may require adapters or a migration; purely internal supported transformations may not require any compatibility machinery.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Reverting a structure change is simple only when no incompatible data/effects escaped. Assess actual release state separately from source-level invertibility.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Tool authors define model guarantees; maintainers verify applicability; affected consumers/obligation owners determine which behaviour must survive.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

[ESME-S012; ESME-S018; ESME-S020; ESME-S021; ESME-S022; ESME-S045; ESME-S051]

### ESME-DM-M6 — Regression evidence and release continuity

**Model.** An obligation set P combines independently justified intended differences and preserved behaviour. Tests/analyses provide partial evidence about P for a versioned candidate. Selection changes what is observed; prioritisation changes when; neither manufactures an oracle.

**Operation.** Obtain credible expectations, select cost-effective checks, inspect differences and route failures to an actor able to respond. Release creates new observations; a rollout may halt, roll back where feasible, or move to forward repair.

**Limit and evidence status.** Passing tests need not imply correct intent or adequate coverage. Reproducibility establishes identity, and staged exposure limits some consequences, but neither guarantees correctness. ANALYTICAL_RECONSTRUCTION_OF_INSPECTED_SOURCES; no empirical validation of the integrated model

**CHANGE_INTENT_AND_CHANGE_CLASS.** Test obligations distinguish intended change, characterisation, preserved contracts and invalid/obsolete expectations. A changed oracle requires its own rationale.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify candidate, baseline, test version, build inputs, configuration and relevant persistent state. Skipped or stale checks are not passed checks.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use change-impact evidence for selection but challenge omitted areas when its assumptions are weak. Existing tests bound any safe-selection guarantee.

**COMPREHENSION_ASSUMPTIONS.** Understand which expectations are independently justified, inherited, reference-derived or relational. A test producer may share the patch’s misconception.

**ORACLE_AND_REGRESSION_LIMITS.** Characterisation can preserve defects; differential agreement can share bugs; metamorphic relations can be wrong; mutation probes have operator limits. None is a complete general oracle.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Check the actual supported version/schema combinations during staged change. A version number or green isolated build does not establish coexistence safety.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Distinguish code reversion, restoration of compatible data, compensation and forward repair. Irreversible effects require explicit decisions and cannot be promised away.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Test/build tools observe; maintainers diagnose; release operators act; obligation owners authorise exceptions. A feedback result needs a consumer with time and capability to respond.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

[ESME-S023; ESME-S024; ESME-S038; ESME-S045; ESME-S046; ESME-S051; ESME-S058; ESME-S059; ESME-S062; ESME-S063; ESME-S064]

### ESME-DM-M7 — Migration, coexistence and replacement

**Model.** Migration changes both implementation and the relation between old state So and new state Sn. A mapping μ and phase-dependent authority A determine which writes and queries are valid. Correct endpoints do not imply correct reachable joint states (So,Sn,A,version combinations).

**Operation.** Choose continued maintenance, incremental displacement, wrapping, quiescent cutover or retirement. Establish mappings and recovery bounds, migrate a justified unit, reconcile, transfer authority and retire unnecessary duplicate operation.

**Limit and evidence status.** Incremental migration reduces some concentration risks but creates gateway and dual-state costs. A non-injective data transformation has no full inverse without retained information; this analytical fact does not establish a target’s exact recovery design. ANALYTICAL_RECONSTRUCTION_OF_INSPECTED_SOURCES; no empirical validation of the integrated model

**CHANGE_INTENT_AND_CHANGE_CLASS.** State the required modernisation outcome, not merely a newer technology. Compare adaptation, restructuring, replacement and deliberate non-change.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify both implementations, mappings, data versions, routing, write ownership, temporary adapters and relevant consumer versions.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Preserve accepted domain meaning and service obligations while deliberately changing implementation or supported behaviour; legacy bugs can be relied-on observations that require adjudication.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Assess shared-data, API, consumer and operational dependencies that cross the migration partition. Artificial partitions can make incremental migration worse.

**COMPREHENSION_ASSUMPTIONS.** Recover enough undocumented behaviour and data meaning to choose mappings and boundaries; replacement cannot assume the old system’s code is its complete specification.

**ORACLE_AND_REGRESSION_LIMITS.** Endpoint tests and row counts do not establish semantic reconciliation. Compare meaningful invariants, actual query interpretation and reachable intermediate states.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Incremental operation needs controlled coexistence and authority; quiescent cutover needs a credible no-write boundary and accepted interruption. Neither is universally preferable.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Identify irreversible conversion, external effects and validated backups/logs. Choose feasible rollback, compensation or forward repair; never infer data recovery from source reversion.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Data and service owners adjudicate loss, downtime and meaning; operators route and reconcile; consumers need feasible transitions rather than mere notices.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

[ESME-S031; ESME-S035; ESME-S036; ESME-S037; ESME-S038; ESME-S039; ESME-S053]

### ESME-DM-M8 — Contingent debt and lifecycle economics

**Model.** A debt candidate identifies a choice d, a future change class k, possible added cost I(d,k,t), remediation cost R and remaining horizon H. Compare scenarios of future work and opportunity cost; the metaphor supplies no universal interest rate or reliable numeric optimum.

**Operation.** Identify actual burdens, distinguish defects/features from debt, compare bounded repair and broader re-engineering, negotiate who bears costs and evaluate realised outcomes. Revise or stop investment when horizon or demand changes.

**Limit and evidence status.** Self-reported wasted time and structural metrics are evidence with validity limits, not guaranteed recoverable savings. A future change that never occurs may never incur the hypothesised interest. ANALYTICAL_RECONSTRUCTION_OF_INSPECTED_SOURCES; no empirical validation of the integrated model

**CHANGE_INTENT_AND_CHANGE_CLASS.** Debt repayment is preventive/perfective only insofar as a specific future burden is addressed; urgent defects and missing capabilities may need separate priority logic.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify the choice, artefacts, affected task class and baseline cost observations. A smell count alone does not identify an economic liability.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Preserve current useful behaviour while improving future work unless an intentional change is separately accepted; include costs borne by downstream maintainers.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Trace the proposed causal mechanism from structure or decision to recurring work rather than relying on a generic metric association.

**COMPREHENSION_ASSUMPTIONS.** Maintainers must understand why the burden occurs and whether a local repair, wrapper, learning intervention or replacement could address it.

**ORACLE_AND_REGRESSION_LIMITS.** Regression checks protect current obligations; they do not establish future productivity benefit. Benefit evaluation needs task outcomes and confounding awareness.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Remediation crossing interfaces or schemas inherits migration/compatibility requirements; internal cleanup does not justify a public break automatically.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Preventive work still needs release/recovery evidence. Economic attractiveness is not permission to impose irreversible risk on other consumers.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Technical and nontechnical decision makers negotiate present and future costs; no score substitutes for legitimate priority authority.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

[ESME-S019; ESME-S022; ESME-S032; ESME-S048; ESME-S049]

### ESME-DM-M9 — Human/ecosystem continuity, deprecation and retirement

**Model.** Continuity is the relation among obligations, consumers, willing competent maintainers, resources and accessible artefacts. Activity is an imperfect indicator: a project can be finished, abandoned while still needed, or technically active but unsustainably supported.

**Operation.** Assess actual support needs, transfer capability through representative work, choose an upstream/downstream response, communicate deprecation and end service responsibly. Retain source/history for named consumers without necessarily operating an obsolete service.

**Limit and evidence status.** Knowledge cannot be reduced to a repository database, and an owner label does not create willingness or capacity. Hidden consumers and indefinite obligations can prevent simple retirement. ANALYTICAL_RECONSTRUCTION_OF_INSPECTED_SOURCES; no empirical validation of the integrated model

**CHANGE_INTENT_AND_CHANGE_CLASS.** Change may concern code, ownership, support, dependency substitution or ending operation. No-change is legitimate when obligations remain met.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Include artefacts, access, build/dependency identity, human knowledge, support promises and consumer relationships relevant to continuity.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Preserve accepted service/data/support obligations during handoff or retirement, not indefinite operation or every historical implementation detail.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Declared dependency networks identify possible exposure; actual use, transitive obligations and human responsibility require additional evidence.

**COMPREHENSION_ASSUMPTIONS.** Demonstrate bounded maintenance ability through tasks and dialogue. Commit history, popularity and documents remain incomplete expertise proxies.

**ORACLE_AND_REGRESSION_LIMITS.** A successful onboarding task or archived build is partial evidence, not proof of readiness for every failure. Inactivity needs interpretation rather than automatic failure classification.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Deprecation needs a feasible transition or explicit exception; forks and replacements transfer maintenance obligations rather than eliminating them.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Shutdown, dependency replacement and ownership transfer need contingency conditions appropriate to actual data/service effects; archival retention alone cannot restore a service.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainers, sponsors, upstream/downstream users and custodians exchange obligations and knowledge. Participation does not imply an entitlement to unpaid labour.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

[ESME-S040; ESME-S041; ESME-S043; ESME-S045; ESME-S047; ESME-S054]

### ESME-DM-M10 — Contemporary automation and evolving artefacts

**Model.** Automation is a candidate-producing or evidence-producing participant in maintenance, not a source of authority. Evaluate task provenance, tool/version, generated patch, oracle, human review, deployment and delayed consequences as distinct stages of evidence and action, not a mandatory serial implementation.

**Operation.** Select bounded tasks and baselines, validate generated changes, include non-code/data artefacts and review costs, and revise delegation when adverse evidence appears. Reliable narrow automation and unresolved general autonomy can coexist.

**Limit and evidence status.** Benchmarks may leak, mix feature requests with bugs, use weak tests or exclude difficult projects. Current evidence through September 2026 does not justify a timeless universal pro- or anti-automation verdict. ANALYTICAL_RECONSTRUCTION_OF_INSPECTED_SOURCES; no empirical validation of the integrated model

**CHANGE_INTENT_AND_CHANGE_CLASS.** A generated patch must answer an authorised maintenance objective. Policy, data and model changes can alter behaviour without conventional source changes.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify repository/task baseline, tool/model version, prompts/configuration relevant to evaluation, tests and data/model/policy artefacts. Record benchmark version and excluded cases.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Preserve actual consumer obligations, not merely benchmark assertions or similarity to a gold patch. Learned behaviour may require statistical rather than deterministic comparisons.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Assess repository-scale and cross-artefact dependencies; generated local diffs can omit tests, configuration or downstream effects.

**COMPREHENSION_ASSUMPTIONS.** Automation can shift comprehension into prompting, verification and repair. Task success does not establish general system understanding.

**ORACLE_AND_REGRESSION_LIMITS.** Distinguish plausible patches, independently assessed correctness and accepted deployment. Contamination and shared datasets limit apparent replication.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Generated migration or API changes inherit ordinary coexistence and mapping obligations; an AI label does not relax them.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Delegated release needs explicit bounds and state/effect recovery evidence. An agent’s successful command is not proof of a recovered real system.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Generators propose, evaluators observe and authorised maintainers/operators act. Human approval is not automatically effective; patch quality can change review performance.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

[ESME-S024; ESME-S025; ESME-S026; ESME-S027; ESME-S028; ESME-S033; ESME-S034; ESME-S042; ESME-S052; ESME-S055; ESME-S056; ESME-S057]

### ESME-DM-COMPOSITION — Cross-mechanism continuity and proportionality

**Model.** The composed system links candidate identity, obligations, evidence, authority, operation and outcomes. Three extra obligations arise at their joins: evidence must still apply to the action; joint states need their own constraints; the combined controls must justify their costs.

**Operation.** Use feedback, concurrency and conditional alternatives. A new observation can reopen intent, widen impact, block acceptance or lead to non-change, migration or retirement. Self-revision changes methods only within authorised boundaries.

**Limit and evidence status.** This is the researcher’s reconciled analytical synthesis. Source support for its components is not empirical validation of the total system, a formal global optimiser or a claim of academic consensus. ANALYTICAL_RECONSTRUCTION_OF_INSPECTED_SOURCES; no empirical validation of the integrated model

**CHANGE_INTENT_AND_CHANGE_CLASS.** The composite maintains a useful system under legitimate changing objectives; it does not maximise activity, code cleanliness, automation or documentation.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Bind evidence and decisions to the actual candidate, baseline and relevant state. Joint deployment/migration states may be objects in their own right.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Carry intended and preserved obligations across handoffs; distinguish knowing a criterion, authority/capability to act and realised consequences.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Composition can create interference or temporary dependencies absent from components. Re-evaluate relevant edges when candidate or assumptions change.

**COMPREHENSION_ASSUMPTIONS.** No actor needs complete knowledge of the whole system, but consequential information must reach an appropriate decision consumer.

**ORACLE_AND_REGRESSION_LIMITS.** Independent-looking checks can share stale baselines or wrong oracles. Positive local results cannot alone validate the composed outcome.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Choose local change, bounded automation, coexistence, quiescent migration, non-change or retirement under explicit guards; do not require every technique simultaneously.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Couple release choice to actual data/effect recovery or forward repair. Interrupts can stop exposure and reopen earlier judgements without a forced serial pipeline.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** One competent authorised maintainer may fulfil several roles; external consumers retain their own authority and constraints.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Include coordination and validation costs created by composition. Consolidate or retire controls when a cheaper adequate configuration exists, without silently waiving protected obligations.

[ESME-S002; ESME-S008; ESME-S016; ESME-S018; ESME-S031; ESME-S038; ESME-S040; ESME-S048; ESME-S051; ESME-S053; ESME-S055]


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CEREMONY_STRIPPING_LEDGER

The omission test is functional: what failure is controlled, who consumes the evidence, and what cheaper arrangement still supplies that function? Removing every artefact is not the objective. A local note can be too weak for distributed continuity; a full dashboard can be unnecessary when no decision consumes it. Each candidate has a record, including explicit non-adoption records for rejected, duplicate and unresolved claims. The complete record in the property JSON retains protected failure, consumer and prerequisites; the entries here expose the concrete ritual, alternative, loss and retirement condition.

### ESME-CS001 — Change-request form or approval board

**Candidate and disposition.** `ESME-001`; STRONGLY_RETAINED

**Protected function and failure.** State the requested behavioural difference, surviving obligations and decision authority; challenge ambiguous or conflicting requests before treating tests as acceptance. Failure: A technically valid patch can solve the wrong problem or preserve an obligation that its legitimate owner has withdrawn.

**Consumer.** Request owner and affected obligation holders determine the objective; implementers can question feasibility but cannot silently redefine acceptance.

**Prerequisites.** An identifiable baseline, affected interests and an actor entitled to resolve the objective; emergency delegation must be explicit.

**Minimal adequate alternative.** Use an existing unambiguous authorised request; no new board or document is needed. Decline changes without a supported objective.

**Trigger for fuller form.** New, disputed or externally imposed change objectives, including urgent corrections.

**Cost of simplification.** An informal exchange can leave competing interpretations or missing participants undiscoverable later; retain an explicit decision when that uncertainty matters.

**Omission or retirement.** Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

[ESME-001: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/0)

### ESME-CS002 — Mandatory single-category time coding

**Candidate and disposition.** `ESME-002`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Classify the purposes of a change using stated definitions, permit multiple purposes and explain disagreement where the distinction changes a decision. Failure: Single labels obscure mixed motives, confuse restoring intent with revising it, and distort effort accounts.

**Consumer.** Maintainers and planning consumers agree operational definitions; a classifier has no authority to approve the underlying change.

**Prerequisites.** A common unit of classification and enough request context to distinguish intent, environment and prevention.

**Minimal adequate alternative.** Use ordinary language when no decision depends on a taxonomy; do not force every commit into one exclusive category.

**Trigger for fuller form.** Classification informs planning, funding, reporting or selection of preservation obligations.

**Cost of simplification.** Ordinary language loses aggregate comparability; accept that loss when no credible allocation or planning decision uses the categories.

**Omission or retirement.** Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

[ESME-002: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/1)

### ESME-CS003 — Full environment snapshot or configuration inventory

**Candidate and disposition.** `ESME-003`; STRONGLY_RETAINED

**Protected function and failure.** Bind change and evidence to recoverable versions of the relevant source, configuration, build inputs and data/schema state; distinguish identity from recoverability. Failure: Evidence about one source/configuration state can be misapplied to a different build, schema or deployment.

**Consumer.** Maintainers and release operators establish the baseline; custodians authorise access and retention.

**Prerequisites.** Actual access to required artefacts, dependency versions and restoration permissions; secrets need references or controlled recovery, not public copying.

**Minimal adequate alternative.** Use existing versioned inputs and reproducible commands; do not snapshot irrelevant infrastructure or duplicate authoritative history.

**Trigger for fuller form.** A change or investigation may need reproduction, comparison, release or restoration.

**Cost of simplification.** A lighter baseline may omit a mutable build input, schema or remote state; include any omitted input capable of changing the relevant result.

**Omission or retirement.** Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

[ESME-003: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/2)

### ESME-CS004 — Formal transfer checklist and handover meeting

**Candidate and disposition.** `ESME-004`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Before transferring responsibility, establish the receiving maintainer’s access, runnable artefacts, known obligations and escalation route; revisit after ownership changes. Failure: A delivered system may lack the access, knowledge, build capability or responsibility required for its later changes.

**Consumer.** Delivering and receiving maintainers negotiate support responsibility; a research assessment cannot impose labour or grant access.

**Prerequisites.** A receiving actor, accepted responsibility and feasible resources; possession of documents alone is insufficient.

**Minimal adequate alternative.** An existing competent team with unchanged access can reuse its arrangements; no separate transition ceremony is inherently required.

**Trigger for fuller form.** Initial delivery, outsourcing, major platform change or ownership handoff.

**Cost of simplification.** An informal handover may fail to expose missing credentials, unavailable expertise or unusable artefacts; a small capability check can reveal these failures.

**Omission or retirement.** Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

[ESME-004: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/3)

### ESME-CS005 — Scheduled improvement programme

**Candidate and disposition.** `ESME-005`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Compare a proposed intervention with continued operation under current obligations; permit deliberate non-change with explicit revisit triggers. Failure: Activity metrics and novelty pressure can trigger changes whose risk and effort exceed any supported benefit.

**Consumer.** Service or product decision makers accept residual risk; maintainers report relevant changes without treating every observation as a mandate to modify.

**Prerequisites.** Enough evidence about utility, dependency support and external obligations to distinguish stability from neglected risk.

**Minimal adequate alternative.** Leave the system unchanged and retain only necessary observation or support; do not invent work to sustain activity.

**Trigger for fuller form.** A stable useful system has no material unmet requirement, unsupported dependency exposure or changing obligation requiring action.

**Cost of simplification.** Choosing no change leaves latent risks and future adaptation costs in place; retain revisit signals for actual changing obligations rather than activity targets.

**Omission or retirement.** Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

[ESME-005: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/4)

### ESME-CS006 — Evolution dashboard and regular review meeting

**Candidate and disposition.** `ESME-006`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Observe demand, delivered effects, effort and consequences over time; revise change priorities when those observations challenge the operative model. Failure: Local output counts miss whether changes improve usefulness or increase future change difficulty.

**Consumer.** Maintainers, users and decision makers exchange usage and cost evidence; observation alone neither authorises intervention nor identifies causation.

**Prerequisites.** Consistent measurement boundaries, interpretable observations and authority to change priorities.

**Minimal adequate alternative.** For infrequent bounded changes, a direct outcome review may suffice; do not institute a metric programme without a decision consumer.

**Trigger for fuller form.** Repeated change in a system exposed to evolving use and stakeholder expectations.

**Cost of simplification.** Direct occasional review can miss slow trends and cross-team effects; use time-series observation when those effects change real decisions.

**Omission or retirement.** Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.

[ESME-006: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/5)

### ESME-CS007 — Eight-law compliance scorecard

**Candidate and disposition.** `ESME-007`; ASSUMPTION_SENSITIVE

**Protected function and failure.** Declare system population, time scale, metric and conditional clauses before applying an evolution regularity; compare plausible alternative interpretations. Failure: Population-specific observations can be converted into universal physical laws or operational mandates.

**Consumer.** Analysts state scope; planning authorities decide whether that evidence warrants investment, not whether the word law compels it.

**Prerequisites.** An operational interpretation of the law, compatible observations and a potential disconfirming result.

**Minimal adequate alternative.** Use direct local evidence without invoking a law when the classification or measurement adds no decision value.

**Trigger for fuller form.** A growth, complexity, effort or quality law is used to explain or predict an actual system.

**Cost of simplification.** Direct local evidence gives up broad explanatory comparisons; this is acceptable when population and measurement conditions are not established.

**Omission or retirement.** Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.

[ESME-007: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/6)

### ESME-CS008 — Complexity-reduction campaign

**Candidate and disposition.** `ESME-008`; CONTEXT_DEPENDENT

**Protected function and failure.** Identify a change-relevant source of difficulty and compare targeted restructuring with leaving it, wrapping it or replacing the affected part. Failure: Accumulated interactions can make necessary future modifications slower or more hazardous.

**Consumer.** Maintainers propose structural work; product or service authorities accept its opportunity cost and risk.

**Prerequisites.** A stated future change class, intervention cost and evidence connecting the alleged complexity to that cost.

**Minimal adequate alternative.** Use a local repair or tolerate harmless complexity when no likely change benefits from restructuring.

**Trigger for fuller form.** Recurrent changes or demonstrated failures make a particular structural difficulty consequential.

**Cost of simplification.** A local repair may retain a recurrent structural obstacle; favour it only when avoiding that obstacle does not justify wider relearning and regression cost.

**Omission or retirement.** Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.

[ESME-008: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/7)

### ESME-CS009 — Knowledge map or fixed team-capacity rule

**Candidate and disposition.** `ESME-009`; CONTEXT_DEPENDENT

**Protected function and failure.** Adjust change scope, sequencing, learning and review to demonstrated maintainer capacity; expose concentrated knowledge and provide learning opportunities. Failure: Change volume can outstrip the people able to review, operate and explain consequential behaviour.

**Consumer.** Maintainer teams and managers negotiate workload; repository metrics cannot assign expertise or compel unpaid work.

**Prerequisites.** Access to people and artefacts, an honest account of capacity and authority to defer or narrow change.

**Minimal adequate alternative.** An experienced available maintainer can make a bounded change without a formal knowledge census.

**Trigger for fuller form.** Rapid growth, departure, ownership concentration or repeated review/comprehension failures.

**Cost of simplification.** Informal familiarity judgements may miss concentrated or unavailable expertise; enlarge the assessment when absence would obstruct a consequential change.

**Omission or retirement.** Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.

[ESME-009: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/8)

### ESME-CS010 — Mandatory annual functionality growth target

**Candidate and disposition.** `ESME-010`; REJECTED_OR_DISFAVOURED

**Protected function and failure.** Do not enact this rule; replace it with scoped interpretation and observed consequences. Failure: This inference would justify continual expansion or replacement without examining usefulness or measurement.

**Consumer.** No actor gains authority to impose growth from the laws; decision makers still need a justified objective.

**Prerequisites.** The rejected rule lacks a defensible universal population and invariant measurement.

**Minimal adequate alternative.** Observe the actual system and consider deliberate non-change.

**Trigger for fuller form.** Only triggered for adjudication when someone invokes age or an evolution law as sufficient reason to change.

**Cost of simplification.** Omitting this rejected target has no demonstrated inherent loss; genuinely changing obligations remain reasons to reconsider non-change.

**Omission or retirement.** Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.

[ESME-010: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/9)

### ESME-CS011 — Whole-system comprehension dossier

**Candidate and disposition.** `ESME-011`; STRONGLY_RETAINED

**Protected function and failure.** Identify the questions needed for this change, seek evidence until consequential uncertainties are bounded, and expand inquiry when evidence contradicts the model. Failure: Maintainers may either act without relevant understanding or spend disproportionate effort modelling irrelevant parts.

**Consumer.** The maintainer frames and tests explanations; affected experts can correct them but do not automatically authorise a patch.

**Prerequisites.** A stated change objective and access to representative source, execution or knowledgeable people.

**Minimal adequate alternative.** Reuse reliable knowledge and perform a small confirming check when the question is local and low consequence.

**Trigger for fuller form.** A change depends on unfamiliar behaviour, ownership, dependencies or intent.

**Cost of simplification.** Bounded inquiry can miss a question that would change the intervention; retain an explicit trigger for expanding inquiry when observations disagree.

**Omission or retirement.** Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

[ESME-011: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/10)

### ESME-CS012 — Compulsory multi-tool analysis bundle

**Candidate and disposition.** `ESME-012`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Compare structural dependencies with representative execution, configuration and build evidence; investigate consequential disagreement. Failure: Either source structure or a small execution trace can be mistaken for the full behaviour of a configurable system.

**Consumer.** Maintainers and operators supply complementary evidence; tool outputs are observations rather than approval.

**Prerequisites.** Known analysis scope and representative execution conditions; trace absence must not be read as impossibility.

**Minimal adequate alternative.** Use one adequate analysis for a demonstrably closed local case; combining tools is not mandatory when it adds no discriminating observation.

**Trigger for fuller form.** Dynamic binding, generated code, reflection, configuration or sparse tests make one evidence mode incomplete.

**Cost of simplification.** A single evidence mode can miss its blind spots; the cheap path requires an adequately closed question, not mere agreement with the preferred explanation.

**Omission or retirement.** Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

[ESME-012: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/11)

### ESME-CS013 — Automatically generated slice for every edit

**Candidate and disposition.** `ESME-013`; ASSUMPTION_SENSITIVE

**Protected function and failure.** Compute or inspect a slice relative to a declared criterion and analysis assumptions; treat it as evidence about that criterion, not the complete impact set. Failure: Unrelated code obscures the computations relevant to an observed value or proposed change.

**Consumer.** Analysts choose the criterion; maintainers decide whether its omissions are acceptable for the actual change.

**Prerequisites.** Soundness assumptions for the chosen static/dynamic analysis, aliasing, control flow, termination and environment.

**Minimal adequate alternative.** Direct inspection of a tiny dependency chain may be cheaper; avoid slicing where external effects are outside the model.

**Trigger for fuller form.** A value, statement or behaviour can be represented by a tractable slicing criterion.

**Cost of simplification.** Direct inspection loses systematic reach through complex dependencies; use a sound applicable analysis when manual omission risk becomes consequential.

**Omission or retirement.** Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

[ESME-013: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/12)

### ESME-CS014 — Reverse-engineering taxonomy document

**Candidate and disposition.** `ESME-014`; STRONGLY_RETAINED

**Protected function and failure.** Label whether an activity recovers information, changes representation at the same abstraction, or reconstructs/changes the system; assign evidence and authority accordingly. Failure: Producing an explanation can be misreported as changing the system, or a transformation as merely documenting it.

**Consumer.** Analysts recover evidence; authorised maintainers perform transformations; consumers must not infer one from the other.

**Prerequisites.** Identification of input/output artefacts, abstraction level and whether external behaviour is intended to change.

**Minimal adequate alternative.** Ordinary descriptions suffice for unambiguous local work; a taxonomy table is unnecessary.

**Trigger for fuller form.** A recovery or modernisation activity is proposed, evaluated or handed off.

**Cost of simplification.** Unlabelled activities can blur analysis and mutation; retain an ordinary-language distinction whenever authority or preservation evidence differs.

**Omission or retirement.** Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

[ESME-014: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/13)

### ESME-CS015 — Comprehensive reconstructed documentation set

**Candidate and disposition.** `ESME-015`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Recover consequential rationale from requirements, history, operations and knowledgeable people; link it to decisions and mark uncertain or superseded interpretations. Failure: Code can reveal what happens without revealing why a behaviour is required, tolerated or obsolete.

**Consumer.** Knowledge holders explain history; current obligation owners determine what should survive. Recollection is evidence, not sole authority.

**Prerequisites.** Provenance for recovered claims and access to a consumer able to challenge them.

**Minimal adequate alternative.** Ask the relevant person or retain a short decision note rather than reconstructing a comprehensive document set.

**Trigger for fuller form.** Undocumented behaviour, disputed intent, missing ownership or a knowledge handoff affects a change.

**Cost of simplification.** A short note or conversation may not survive turnover or reach another consumer; preserve consequential rationale in a retrievable form when reuse is likely.

**Omission or retirement.** Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

[ESME-015: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/14)

### ESME-CS016 — Complete system model as universal permission to edit

**Candidate and disposition.** `ESME-016`; REJECTED_OR_DISFAVOURED

**Protected function and failure.** Reject the universal prerequisite; use question-bounded comprehension plus impact expansion when necessary. Failure: Exhaustiveness can postpone useful bounded work indefinitely and disguise untestable claims of complete understanding.

**Consumer.** No process owner should certify total knowledge from a completed model alone.

**Prerequisites.** Complete understanding has no generally operational stopping rule for open, changing systems.

**Minimal adequate alternative.** A local supported explanation and proportionate checks can be sufficient.

**Trigger for fuller form.** Adjudicate when a process demands exhaustive recovery without identifying a consumer or risk.

**Cost of simplification.** Omitting this rejected prerequisite sacrifices no established universal guarantee; high-consequence local proof or wider impact evidence may still be necessary.

**Omission or retirement.** Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

[ESME-016: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/15)

### ESME-CS017 — Whole-repository dependency graph

**Candidate and disposition.** `ESME-017`; STRONGLY_RETAINED

**Protected function and failure.** Propose an impact boundary from relevant dependencies, challenge it with contrary evidence and widen it when an affected obligation crosses the boundary. Failure: A local edit may affect behaviour outside its apparent file or module boundary.

**Consumer.** Maintainers justify the boundary to reviewers and affected consumers; reviewers can require expansion but cannot infer completeness from tool silence.

**Prerequisites.** Baseline identity, change intent and declared dependency evidence with known omissions.

**Minimal adequate alternative.** Accept a local boundary with a concrete reason when interfaces and dependencies make the effect local; no whole-system analysis by default.

**Trigger for fuller form.** A change could propagate beyond the directly edited artefacts.

**Cost of simplification.** A smaller justified boundary may miss an undeclared interaction; include a challenge proportionate to the consequence of that miss.

**Omission or retirement.** Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

[ESME-017: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/16)

### ESME-CS018 — One universal dependency database

**Candidate and disposition.** `ESME-018`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Include the dependency kinds through which the proposed change can affect actual consumers, and distinguish declared, inferred and observed edges. Failure: Unmodelled schema, protocol, build, deployment or responsibility dependencies invalidate code-only change analysis.

**Consumer.** Maintainers and downstream owners communicate constraints; a graph does not grant control over independent consumers.

**Prerequisites.** Evidence for each consequential edge, its direction and the context in which it is active.

**Minimal adequate alternative.** Do not construct every possible graph; inspect only dependency kinds relevant to the change and its obligations.

**Trigger for fuller form.** The changed object participates in shared data, interfaces, builds, learned feedback or cross-team operation.

**Cost of simplification.** Focused inspection can omit configuration, data or organisational edges outside its chosen kinds; expand when the change can act through them.

**Omission or retirement.** Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

[ESME-018: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/17)

### ESME-CS019 — Mandatory co-change recommendation approval

**Candidate and disposition.** `ESME-019`; ASSUMPTION_SENSITIVE

**Protected function and failure.** Use co-change as a defeasible candidate generator; confirm semantic or organisational relevance before requiring another change. Failure: Historical coupling can reveal dependencies missing from explicit structure, but correlations can be mistaken for necessities.

**Consumer.** Tools suggest; maintainers validate relevance and decide action.

**Prerequisites.** Clean enough history, meaningful change units and awareness of bulk edits, conventions and process changes.

**Minimal adequate alternative.** Ignore the predictor for new code, rewritten history or an already understood local dependency.

**Trigger for fuller form.** History is sufficiently representative and structural evidence leaves uncertainty about likely companion changes.

**Cost of simplification.** Ignoring history may lose a useful clue when intent has vanished; history remains a candidate source rather than a required companion-edit generator.

**Omission or retirement.** Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

[ESME-019: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/18)

### ESME-CS020 — Complete stakeholder inventory

**Candidate and disposition.** `ESME-020`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Identify plausible consumers through interfaces, usage, dependency data and consultation; disclose uncertainty and notify those needing action. Failure: A producer can pass its tests while breaking callers, data readers or operators it did not know existed.

**Consumer.** Producers communicate change and uncertainty; independent consumers decide their own migration and acceptance.

**Prerequisites.** A defined support/compatibility surface and channels reaching relevant consumers.

**Minimal adequate alternative.** For a private bounded use with no external consumer, direct coordination with the local caller may suffice.

**Trigger for fuller form.** A public or shared behaviour, data format, dependency or support promise changes.

**Cost of simplification.** Direct contact with known callers cannot establish the absence of other consumers; retain a notice or compatibility interval where undiscovered use is plausible.

**Omission or retirement.** Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

[ESME-020: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/19)

### ESME-CS021 — Independent impact audit for every change

**Candidate and disposition.** `ESME-021`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Seek counterexamples outside the proposed boundary using representative consumers, broader regression or a second evidence mode, scaled to consequence. Failure: A plausible impact boundary can survive only because checks search where the model already expects effects.

**Consumer.** Reviewers and maintainers challenge the analysis; operators or users supply observations beyond development’s model.

**Prerequisites.** A proposed boundary, plausible missed-edge hypotheses and affordable observations.

**Minimal adequate alternative.** For a trivial closed change, a targeted independent check may dominate broad retesting.

**Trigger for fuller form.** High-consequence change, weak dependency evidence, novel configuration or disagreement among analyses.

**Cost of simplification.** A small challenge has limited power against hidden edges; widen it when a missed effect would be costly or the first model has weak support.

**Omission or retirement.** Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

[ESME-021: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/20)

### ESME-CS022 — Semantic-conflict detector on every merge

**Candidate and disposition.** `ESME-022`; ASSUMPTION_SENSITIVE

**Protected function and failure.** Analyse or exercise the merged artefact against combined obligations, using interference candidates to guide investigation rather than declaring every flow a conflict. Failure: Two individually acceptable changes can compose into behaviour neither author intended.

**Consumer.** Change authors and integrators resolve intended interaction; a detector cannot infer stakeholder intent from information flow alone.

**Prerequisites.** A common baseline, both change intents, buildable merged artefact and supported analysis semantics.

**Minimal adequate alternative.** Independent changes with a justified disjoint impact boundary may need only normal combined regression.

**Trigger for fuller form.** Concurrent changes interact through shared state, dataflow, interfaces or assumptions even when textual merge succeeds.

**Cost of simplification.** Textual merging alone misses behaviourally interacting edits; focused tests can substitute only for the relevant reachable interactions.

**Omission or retirement.** Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

[ESME-022: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/21)

### ESME-CS023 — Formal observational-equivalence proof for every refactor

**Candidate and disposition.** `ESME-023`; STRONGLY_RETAINED

**Protected function and failure.** Name the observers, environments and obligations to remain invariant, separately from intended differences; compare the actual transformation against that boundary. Failure: A transformation can preserve outputs in tests while changing timing, exceptions, persistence or reflective behaviour that consumers rely on.

**Consumer.** Obligation holders and maintainers determine the preservation surface; a tool’s narrower model cannot silently replace it.

**Prerequisites.** An explicit contract or adjudicated account of relevant observations and environmental assumptions.

**Minimal adequate alternative.** A narrow observer and a direct comparison suffice where that is the actual contract; do not require equivalence for irrelevant internal states.

**Trigger for fuller form.** Any change claims to preserve behaviour, especially restructuring or compatibility-sensitive repair.

**Cost of simplification.** An informal observer boundary can omit timing, persistence or reflection; specify and check those observations when actual consumers rely on them.

**Omission or retirement.** Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

[ESME-023: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/22)

### ESME-CS024 — Refactoring-tool certification stamp

**Candidate and disposition.** `ESME-024`; ASSUMPTION_SENSITIVE

**Protected function and failure.** Check the transformation’s preconditions in the actual relevant model, and expose unsupported language or environment features before relying on a preservation argument. Failure: A syntactically legal transformation may violate binding, inheritance, visibility or other semantic constraints.

**Consumer.** Tool authors establish model-relative guarantees; maintainers verify applicability and retain responsibility for excluded observers.

**Prerequisites.** A valid mapping from actual language/tool version and artefacts to the proof or rule’s assumptions.

**Minimal adequate alternative.** For a small obvious edit, direct semantic reasoning and testing may be cheaper than a general transformation framework.

**Trigger for fuller form.** An automated or manual transformation relies on a formal or tool-defined refactoring rule.

**Cost of simplification.** Direct checks may not cover all proof preconditions; a formal applicability argument is valuable when the language/environment assumptions can actually be established.

**Omission or retirement.** Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

[ESME-024: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/23)

### ESME-CS025 — Transformation validation report

**Candidate and disposition.** `ESME-025`; STRONGLY_RETAINED

**Protected function and failure.** Check the actual transformed baseline using relevant semantic reasoning, tests or comparison; invalidate earlier evidence when consequential inputs change. Failure: A correct transformation rule can be implemented incorrectly, misapplied or followed by another interacting change.

**Consumer.** Maintainers and reviewers consume validation evidence; the generator cannot self-certify correctness solely through its own success flag.

**Prerequisites.** Candidate identity, obligations and a validation method whose limits are understood.

**Minimal adequate alternative.** A small reviewed diff and a targeted check may be enough; no universal demand for multiple expensive validators.

**Trigger for fuller form.** Any consequential restructuring, generated patch or composed change is proposed for acceptance.

**Cost of simplification.** A small check observes fewer consequences than a broader suite or proof; its adequacy depends on the actual transformation and impact boundary.

**Omission or retirement.** Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

[ESME-025: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/24)

### ESME-CS026 — Separate branch for every preservation and feature change

**Candidate and disposition.** `ESME-026`; STRONGLY_RETAINED

**Protected function and failure.** Declare intentional behavioural differences independently from structural work; revise obsolete tests through an authorised account of intended behaviour. Failure: A repair may be blocked by tests preserving a defect, or a feature change may be disguised as a supposedly preserving refactor.

**Consumer.** Current obligation owners authorise semantic change; maintainers may reorganise code within that boundary.

**Prerequisites.** A baseline, accepted intended difference and evidence for the behaviour that still must remain stable.

**Minimal adequate alternative.** One combined patch is permissible when separating it increases risk, provided the distinct obligations remain assessable.

**Trigger for fuller form.** A patch mixes restructuring with correction, adaptation or changed requirements.

**Cost of simplification.** Combining changes can obscure which differences are intended; preserve independently interpretable acceptance obligations even in one patch.

**Omission or retirement.** Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

[ESME-026: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/25)

### ESME-CS027 — Refactor-before-change rule

**Candidate and disposition.** `ESME-027`; CONTEXT_DEPENDENT

**Protected function and failure.** Name the future change or comprehension task expected to improve, compare intervention cost and evaluate a task-relevant outcome rather than a metric alone. Failure: A cleaner-looking structure can impose immediate risk without helping any likely future task.

**Consumer.** Maintainers propose benefits; those bearing delivery and lifecycle costs decide priority.

**Prerequisites.** A plausible future task population and an explicit account of present disruption and review cost.

**Minimal adequate alternative.** Leave the structure alone, repair locally or improve a small seam when no broader benefit is supported.

**Trigger for fuller form.** Restructuring is justified by maintainability, comprehension or reduced future change cost.

**Cost of simplification.** Local repair can leave repeated future work expensive; accept that cost when expected recurrence does not justify restructuring now.

**Omission or retirement.** Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

[ESME-027: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/26)

### ESME-CS028 — Clean-code or maintainability-metric gate as sufficient proof

**Candidate and disposition.** `ESME-028`; REJECTED_OR_DISFAVOURED

**Protected function and failure.** Reject the guarantee; require a task-specific causal account and proportionate outcome evidence. Failure: The claim would substitute a proxy for actual future effort, reliability or usefulness.

**Consumer.** Metric producers do not determine product value; affected maintainers and users supply task evidence.

**Prerequisites.** No universal mapping from structural score to all relevant outcomes is established.

**Minimal adequate alternative.** Keep a harmless structure or make a bounded repair.

**Trigger for fuller form.** Adjudicate when a structural metric or catalogue label is offered as sufficient benefit evidence.

**Cost of simplification.** Omitting the rejected proxy guarantee loses no demonstrated universal payoff; specific validated indicators may remain useful evidence.

**Omission or retirement.** Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

[ESME-028: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/27)

### ESME-CS029 — Test-oracle sign-off document

**Candidate and disposition.** `ESME-029`; STRONGLY_RETAINED

**Protected function and failure.** Trace acceptance expectations to independent requirements, adjudicated behaviour, domain properties or credible reference evidence; state gaps and conflicts. Failure: Tests can encode obsolete behaviour, mistaken requirements or assumptions shared with the patch generator.

**Consumer.** Domain experts and obligation owners adjudicate expectations; tests and agents produce evidence, not authority.

**Prerequisites.** Known oracle provenance, candidate identity and an actor able to resolve intended behaviour.

**Minimal adequate alternative.** A trusted narrow assertion may suffice for a simple obligation; do not build a specification language merely for appearance.

**Trigger for fuller form.** Test results support a change decision or a test expectation itself changes.

**Cost of simplification.** A short expectation can omit its provenance or stale assumptions; retain enough justification to distinguish accepted behaviour from accidental output.

**Omission or retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

[ESME-029: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/28)

### ESME-CS030 — Permanent golden-master suite

**Candidate and disposition.** `ESME-030`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Observe and record behaviour relevant to the change, treat it as provisional evidence, and adjudicate which observations are contractual rather than automatically preserving all of them. Failure: Unknown legacy behaviour may be unintentionally lost during change.

**Consumer.** Maintainers collect evidence; domain and downstream consumers determine which behaviours deserve continuity.

**Prerequisites.** Representative inputs, environmental context and a way to distinguish intended changes from accidental regression.

**Minimal adequate alternative.** A temporary probe, recorded example or focused test can suffice; retire incidental characterisation tests after their consumer disappears.

**Trigger for fuller form.** Useful or risky behaviour is poorly documented and can be exercised.

**Cost of simplification.** Temporary or selective characterisation leaves some existing behaviour unrecorded; preserve samples that protect real consumers, not every historical accident.

**Omission or retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

[ESME-030: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/29)

### ESME-CS031 — Always-on dual execution

**Candidate and disposition.** `ESME-031`; CONTEXT_DEPENDENT

**Protected function and failure.** Run comparable inputs against the old/new or independent implementations, locate differences and adjudicate them against intended obligations. Failure: Complex semantics can be misimplemented while each implementation appears plausible in isolation.

**Consumer.** Maintainers investigate discrepancies; a reference implementation is evidence, not an unquestionable specification.

**Prerequisites.** Comparable input/environment, known intended differences and awareness of common-mode defects.

**Minimal adequate alternative.** Use direct expected results for simple cases; no duplicate implementation is required where it adds less evidence than it costs.

**Trigger for fuller form.** A credible reference exists and executions can be made comparable.

**Cost of simplification.** Single implementation checks lose the second implementation's discrepancy signal; differential testing is useful only when differences can be adjudicated and cost is justified.

**Omission or retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

[ESME-031: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/30)

### ESME-CS032 — Catalogue of metamorphic relations

**Candidate and disposition.** `ESME-032`; ASSUMPTION_SENSITIVE

**Protected function and failure.** Choose justified input/output relations, execute related cases and investigate violations while preserving the relation’s domain assumptions. Failure: A missing exact-output oracle can prevent useful testing of relations that should still hold.

**Consumer.** Domain specialists justify relations; maintainers implement and interpret tests.

**Prerequisites.** A valid metamorphic relation, appropriate numerical/nondeterministic tolerance and no unaccounted persistent side effects.

**Minimal adequate alternative.** Use ordinary assertions when expected results are cheap; do not invent weak relations to inflate a test count.

**Trigger for fuller form.** Exact expected results are difficult but a relevant mathematical or domain relation is credible.

**Cost of simplification.** A few relations expose only a subset of possible errors; expanding the catalogue helps only when new relations are independently valid for the domain.

**Omission or retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

[ESME-032: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/31)

### ESME-CS033 — Full mutation campaign for every patch

**Candidate and disposition.** `ESME-033`; CONTEXT_DEPENDENT

**Protected function and failure.** Use selected mutation operators to challenge tests, investigate surviving mutants and improve assertions where the mutant represents a relevant fault. Failure: High execution coverage can coexist with weak assertions that miss meaningful faults.

**Consumer.** Test maintainers interpret survivors; a mutation score does not authorise release or define correctness.

**Prerequisites.** Valid operators, interpretable mutants and a correct oracle for deciding whether altered behaviour matters.

**Minimal adequate alternative.** A few manually chosen fault injections may be enough; skip large mutation campaigns when equivalent mutants or cost dominate.

**Trigger for fuller form.** Critical regression claims depend on a test suite whose fault sensitivity is uncertain.

**Cost of simplification.** A smaller challenge can miss oracle weaknesses revealed by additional mutants; larger campaigns require a useful fault model and an affordable consumer action.

**Omission or retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

[ESME-033: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/32)

### ESME-CS034 — Mandatory regression-selection engine

**Candidate and disposition.** `ESME-034`; ASSUMPTION_SENSITIVE

**Protected function and failure.** Select tests using change/dependency evidence and stated safety assumptions; include analysis, selection and validation costs in the comparison. Failure: Running every available test can consume resources without proportional information, but unsafe omission can hide regression.

**Consumer.** Test/release owners choose tolerable omission risk; a safe-selection theorem is relative to the existing tests, not complete correctness.

**Prerequisites.** A recoverable baseline, test-to-behaviour mapping and explicit handling of environment and nondeterminism.

**Minimal adequate alternative.** Run the whole small suite when selection overhead exceeds savings.

**Trigger for fuller form.** Retest-all cost is consequential and change impact can be analysed well enough to support selection.

**Cost of simplification.** Retest-all gives up potential execution savings but avoids selection analysis and omission risk; use it when the full suite is cheap.

**Omission or retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

[ESME-034: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/33)

### ESME-CS035 — Elaborate test-priority ranking

**Candidate and disposition.** `ESME-035`; CONTEXT_DEPENDENT

**Protected function and failure.** Prioritise evidence according to failure consequence and decision timing; record skipped or unfinished checks as such, not as passed. Failure: A slow schedule can delay high-value feedback, while aggressive savings can hide or postpone failures.

**Consumer.** Maintainers and release consumers set decision deadlines; scheduling tools only allocate observation effort.

**Prerequisites.** Interpretable historical evidence, stable enough workload and an explicit delay tolerance.

**Minimal adequate alternative.** Use the ordinary order for a fast suite; do not train a predictor without a meaningful latency problem.

**Trigger for fuller form.** Execution may be interrupted or feedback latency materially affects repair/release decisions.

**Cost of simplification.** A simple order may reveal some failures later; ranking adds value only when earlier detection changes an action and exceeds ranking cost.

**Omission or retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

[ESME-035: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/34)

### ESME-CS036 — Reproducible-build badge

**Candidate and disposition.** `ESME-036`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Identify build inputs and expected outputs; reproduce the relevant artefact or explain environmental variance and validate what is actually shipped. Failure: A patch validated in one environment may produce a different shipped artefact or be impossible to rebuild.

**Consumer.** Build and release maintainers provide provenance; reproducibility does not grant trust in source correctness.

**Prerequisites.** Controlled or recorded toolchain/dependencies, available inputs and a declared comparison boundary.

**Minimal adequate alternative.** For a disposable local script, a versioned command and environment record may suffice; bit-for-bit output is not always the necessary observer.

**Trigger for fuller form.** Release, archival reconstruction or cross-environment validation depends on build identity.

**Cost of simplification.** A merely identified build cannot establish byte-for-byte reproducibility; decide whether independent reproduction is an actual preservation or supply requirement.

**Omission or retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

[ESME-036: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/35)

### ESME-CS037 — Required CI dashboard and green badge

**Candidate and disposition.** `ESME-037`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Run appropriate checks on integrated states, route failures to someone able to act, and make skipped, stale or failing observations visible to release decisions. Failure: Integration failures accumulate when work is combined rarely or results have no responsible consumer.

**Consumer.** The integration service observes; maintainers diagnose and fix; release authority decides whether remaining uncertainty permits delivery.

**Prerequisites.** Identifiable integrated state, useful checks, available execution resources and a responding maintainer.

**Minimal adequate alternative.** For rare changes, a manual reproducible integration check may provide equivalent evidence.

**Trigger for fuller form.** Multiple changes integrate frequently enough that delayed failures have material cost.

**Cost of simplification.** Direct local checking lacks automatically shared timely feedback; use it only when coordination and integration consequences are truly local.

**Omission or retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

[ESME-037: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/36)

### ESME-CS038 — Version-number convention as compatibility proof

**Candidate and disposition.** `ESME-038`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Declare the supported interface/behaviour surface and transition policy, including exceptions, and test changes against the expectations actually communicated. Failure: Version labels or undocumented assumptions can give consumers false expectations about safe upgrades.

**Consumer.** Producers define and honour published support commitments; exceptional breakage requires the appropriate authority and communication.

**Prerequisites.** An identifiable producer, consumers and evidence for the promised compatibility dimensions.

**Minimal adequate alternative.** For a private coordinated consumer, a direct agreement can replace a public versioning policy.

**Trigger for fuller form.** Independent consumers rely on an API, format, behaviour or support promise.

**Cost of simplification.** Direct contract comparison lacks the convention's communication convenience; a label can help consumers but cannot replace evidence about changed behaviour.

**Omission or retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

[ESME-038: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/37)

### ESME-CS039 — Full mixed-version compatibility matrix

**Candidate and disposition.** `ESME-039`; ASSUMPTION_SENSITIVE

**Protected function and failure.** Identify permitted producer/consumer and schema/version combinations; enforce sequencing or adapters where not all combinations are compatible. Failure: Each endpoint can pass isolated tests while mixed-version interactions fail.

**Consumer.** Operators coordinate rollout; independent consumers retain their own upgrade authority and may constrain timing.

**Prerequisites.** Known version combinations, routing/data ownership and a way to prevent unsupported interactions.

**Minimal adequate alternative.** Use a genuinely quiescent coordinated cutover when it is cheaper and acceptable; then the mixed-version matrix may be unnecessary.

**Trigger for fuller form.** A deployment, dependency ecosystem or migration permits mixed versions.

**Cost of simplification.** Constraining deployments to fewer combinations sacrifices rollout flexibility; that can be cheaper and safer than testing unsupported combinations.

**Omission or retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

[ESME-039: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/38)

### ESME-CS040 — Canary release for every change

**Candidate and disposition.** `ESME-040`; CONTEXT_DEPENDENT

**Protected function and failure.** Expose a bounded population or function, observe predeclared consequences and expand, stop or repair according to actionable evidence. Failure: A large untested exposure can make regression expensive to contain; a nominal stage can provide no useful signal.

**Consumer.** Operators control exposure within authorisation; affected users’ obligations remain relevant even in a small stage.

**Prerequisites.** Meaningful observations, a control over exposure and feasible recovery/forward-repair actions.

**Minimal adequate alternative.** Use a direct cutover for a tiny reversible change or when staging introduces more inconsistency than it reduces risk.

**Trigger for fuller form.** Consequences can be observed before full exposure and populations or functions can be separated safely.

**Cost of simplification.** A direct release forgoes early limited-exposure observation; acceptable only when the experiment would be uninformative or proportionate alternatives address its risk.

**Omission or retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

[ESME-040: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/39)

### ESME-CS041 — Rollback checkbox or code-revert button

**Candidate and disposition.** `ESME-041`; STRONGLY_RETAINED

**Protected function and failure.** Classify reversible and irreversible effects; demonstrate restoration/reconciliation where promised, otherwise plan forward repair or explicitly authorised loss. Failure: Reverting code can leave converted data, sent messages or external actions inconsistent or irretrievable.

**Consumer.** Operators perform recovery; data and service obligation owners authorise irreversible actions and residual losses.

**Prerequisites.** Usable backups/logs or compensating capabilities, retention/access rights and an understood recovery point.

**Minimal adequate alternative.** For a pure read-only reversible change, restoring the prior artefact may genuinely be sufficient.

**Trigger for fuller form.** A change writes persistent data, alters schemas or causes external effects whose reversal matters.

**Cost of simplification.** A narrower recovery plan may leave persistent data or external effects unrecoverable; explicitly accept or provide forward repair for those effects rather than imply undo.

**Omission or retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

[ESME-041: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/40)

### ESME-CS042 — Comprehensive modernisation business case

**Candidate and disposition.** `ESME-042`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Compare options against utility, constraints, knowledge, migration risk and full lifecycle cost, including deliberate non-change and retirement. Failure: Replacement can discard undocumented requirements; indefinite patching can sustain excessive cost or unsupported risk.

**Consumer.** Product/service and data owners choose the objective and acceptable risk; maintainers establish feasibility and hidden obligations.

**Prerequisites.** An honest baseline of current value and constraints, credible alternatives and attention to transition as well as end-state cost.

**Minimal adequate alternative.** A bounded repair or continued operation may dominate a programme of replacement.

**Trigger for fuller form.** Current maintenance no longer clearly serves required outcomes or a substantial migration is proposed.

**Cost of simplification.** A bounded comparison may omit distant options or costs; enlarge it when transition irreversibility or support commitments make the omission material.

**Omission or retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

[ESME-042: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/41)

### ESME-CS043 — Mandatory strangler architecture

**Candidate and disposition.** `ESME-043`; CONTEXT_DEPENDENT

**Protected function and failure.** Choose a separable function or consumer boundary, route it deliberately, reconcile shared state and retire the old path after its obligations transfer. Failure: All-at-once replacement concentrates uncertainty and can postpone useful delivery for a long period.

**Consumer.** Migration teams implement boundaries; service/data owners authorise routing and eventual retirement.

**Prerequisites.** Routing control, explicit data authority, compatibility and an exit condition for duplicate operation.

**Minimal adequate alternative.** Prefer a local repair or quiescent cutover when partitions are artificial or gateways cost more than staged benefit.

**Trigger for fuller form.** Work can be partitioned with tolerable coexistence and useful partial delivery.

**Cost of simplification.** A direct cutover loses incremental learning and staged value; it can still dominate when coexistence is infeasible or more expensive.

**Omission or retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

[ESME-043: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/42)

### ESME-CS044 — Big-bang replacement mandate

**Candidate and disposition.** `ESME-044`; DOMAIN_SPECIFIC

**Protected function and failure.** Prepare and validate conversion, establish a quiescent boundary, cut over under explicit recovery/forward-repair conditions and reconcile before reopening use. Failure: Incremental coexistence can be impossible or more hazardous than a controlled outage.

**Consumer.** Operators coordinate cutover with service/data owners and affected consumers; a project team cannot assume all users accept downtime.

**Prerequisites.** Accepted outage, frozen input boundary, tested conversion, sufficient capacity and clear irreversibility decisions.

**Minimal adequate alternative.** Continue maintenance or use incremental displacement where interruption or conversion risk is unacceptable.

**Trigger for fuller form.** A tolerable outage exists, data can be stabilised and the joint operation burden would otherwise dominate.

**Cost of simplification.** Incremental or continued maintenance may prolong dual support but avoid concentrated transition risk; select by actual interruption and partition conditions.

**Omission or retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

[ESME-044: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/43)

### ESME-CS045 — Always-on dual writes and reconciliation dashboard

**Candidate and disposition.** `ESME-045`; ASSUMPTION_SENSITIVE

**Protected function and failure.** Define authority and mappings for each migration phase, compare relevant state and resolve divergence before transferring responsibility. Failure: Dual operation can create conflicting writes, lost records or semantically inconsistent copies.

**Consumer.** Data owners decide meaning and acceptable loss; operators execute and inspect reconciliation.

**Prerequisites.** Explicit identities, mapping semantics, write ordering and access to authoritative observations.

**Minimal adequate alternative.** An immutable read-only export with a simple verified mapping may need only one comparison and no dual-write protocol.

**Trigger for fuller form.** Data or service state is copied, transformed or temporarily maintained in more than one place.

**Cost of simplification.** A single-writer or quiescent design loses some availability or flexibility but can eliminate ambiguity over authority and reduce divergence.

**Omission or retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

[ESME-045: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/44)

### ESME-CS046 — Automatic down-migration script

**Candidate and disposition.** `ESME-046`; ASSUMPTION_SENSITIVE

**Protected function and failure.** State the mapping and its information-loss/invertibility conditions; preserve enough source information or choose forward repair where an inverse does not exist. Failure: A schema change can destroy information or make old queries uninterpretable despite successful conversion.

**Consumer.** Database maintainers establish mappings; data owners authorise losses and changed interpretation.

**Prerequisites.** A model matching actual schema semantics, constraints, data values and supported transformation operators.

**Minimal adequate alternative.** Use a direct checked migration for a simple bijective mapping; a full workbench is unnecessary.

**Trigger for fuller form.** Schema/data representation changes affect persistent meaning or old-version access.

**Cost of simplification.** A forward-only transition forgoes restoration of the old representation; it is acceptable only with explicit preservation, retained information or a supported recovery decision.

**Omission or retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

[ESME-046: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/45)

### ESME-CS047 — Permanent migration gateway

**Candidate and disposition.** `ESME-047`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Assign exit conditions to transitional paths; verify remaining consumers and recovery needs, then remove or deliberately reclassify the retained mechanism. Failure: Temporary gateways, duplicate implementations and double maintenance can become permanent without a consumer.

**Consumer.** Service owners and maintainers authorise retirement after affected consumers have a feasible path.

**Prerequisites.** Evidence of consumer transition, settled data authority and expiry or replacement of recovery obligations.

**Minimal adequate alternative.** Retain an adapter when a real consumer still requires it; do not remove it solely to satisfy a cleanup schedule.

**Trigger for fuller form.** A migration step has transferred its intended obligations and duplicated operation continues.

**Cost of simplification.** Retiring the gateway removes old-path fallback and compatibility; do so only after its consumers and recovery obligations end.

**Omission or retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

[ESME-047: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/46)

### ESME-CS048 — Age threshold or new-language rewrite policy

**Candidate and disposition.** `ESME-048`; REJECTED_OR_DISFAVOURED

**Protected function and failure.** Reject age/novelty as a sufficient criterion; examine viable lifecycle options and transition obligations. Failure: This would conflate technical chronology with actual utility, support risk and maintenance cost.

**Consumer.** No vendor or architectural preference substitutes for service and stakeholder decision authority.

**Prerequisites.** Age has no general causal mapping to unacceptable risk or replacement benefit.

**Minimal adequate alternative.** Continue useful supported operation or make a bounded adaptation.

**Trigger for fuller form.** Adjudicate when a replacement rationale contains no stronger evidence than old or modern.

**Cost of simplification.** Omitting this rejected rule gives up a simple but unsupported decision shortcut; actual support, risk and value still need assessment.

**Omission or retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

[ESME-048: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/47)

### ESME-CS049 — Everything-undesirable-is-debt register

**Candidate and disposition.** `ESME-049`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Identify the design/implementation choice, plausible future burden, affected change class and remediation alternative; distinguish debt from ordinary unmet requirements. Failure: Calling every defect, missing feature or disliked structure debt obscures distinct decisions and future costs.

**Consumer.** Maintainers identify technical mechanisms; stakeholders determine acceptable trade-offs and who bears later costs.

**Prerequisites.** A causal hypothesis connecting the choice to future work and a clear boundary of the obligation.

**Minimal adequate alternative.** Use an ordinary defect or feature request when that is the actual issue; no debt register is needed for an isolated obvious repair.

**Trigger for fuller form.** A present choice is expected to impose avoidable future maintenance cost or constrain options.

**Cost of simplification.** A narrower debt inventory omits ordinary defects, features and obligations from that metaphor; track them through appropriate decisions instead of forcing financial labels.

**Omission or retirement.** Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

[ESME-049: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/48)

### ESME-CS050 — Debt-interest calculator with exact rankings

**Candidate and disposition.** `ESME-050`; ASSUMPTION_SENSITIVE

**Protected function and failure.** Compare remediation cost with contingent future burdens and benefits over a stated horizon, testing sensitivity to change frequency, retirement and uncertainty. Failure: A static cleanup score ignores whether the affected code will change again and which users bear opportunity cost.

**Consumer.** Stakeholders bearing present and future costs choose trade-offs; analysts expose assumptions rather than declare an automatic optimum.

**Prerequisites.** Meaningful cost units, a plausible horizon and honest uncertainty rather than fabricated precision.

**Minimal adequate alternative.** For a cheap urgent defect repair, direct consequence and effort comparison may be enough.

**Trigger for fuller form.** A nontrivial preventive investment competes with current delivery or another maintenance option.

**Cost of simplification.** Qualitative scenarios lose numerical comparability but avoid false precision; use richer estimates when costs, horizon and uncertainty can be defended.

**Omission or retirement.** Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

[ESME-050: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/49)

### ESME-CS051 — Central debt-priority committee

**Candidate and disposition.** `ESME-051`; CONTEXT_DEPENDENT

**Protected function and failure.** Expose who pays and who benefits, compare urgent user needs with preventive work and revisit priorities when evidence or objectives change. Failure: The party benefiting from delivery may not bear the maintenance costs it creates.

**Consumer.** Authorised budget/service owners negotiate priorities; technical labels do not compel others to fund work.

**Prerequisites.** Enough information about affected stakeholders, severity, recurrence and available capacity.

**Minimal adequate alternative.** A maintainer can resolve a small local issue directly when no meaningful trade-off or external cost exists.

**Trigger for fuller form.** Multiple maintenance needs compete for constrained effort, particularly across ownership or funding boundaries.

**Cost of simplification.** Local prioritisation may miss costs imposed on other teams or future maintainers; widen participation when burdens cross the local boundary.

**Omission or retirement.** Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

[ESME-051: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/50)

### ESME-CS052 — Comprehensive cleanup release

**Candidate and disposition.** `ESME-052`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Select a bounded intervention, observe whether the targeted burden changes and stop, revise or retire the effort when benefit is absent or the system nears retirement. Failure: A remediation programme can continue after its original burden disappears or expand into endless cleanup.

**Consumer.** Maintainers report outcomes; decision makers can stop or redirect investment without treating incomplete cleanup as failure.

**Prerequisites.** A measurable task-relevant burden, comparison with baseline and awareness of concurrent changes.

**Minimal adequate alternative.** A small targeted fix or no action may dominate comprehensive re-engineering.

**Trigger for fuller form.** A debt or maintainability intervention has uncertain payoff and can be evaluated incrementally.

**Cost of simplification.** Bounded remediation leaves other problems intact; this is justified when the urgent objective or expected horizon does not support further work.

**Omission or retirement.** Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

[ESME-052: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/51)

### ESME-CS053 — Maintainability-score target

**Candidate and disposition.** `ESME-053`; USEFUL_BUT_EASILY_GAMED

**Protected function and failure.** Use a measure only with a task-relevant interpretation, examine disagreements with observed work and avoid rewards that make proxy improvement the objective. Failure: A readily optimised score can be mistaken for the actual engineering outcome.

**Consumer.** Analysts explain the proxy; maintainers and decision makers judge whether it represents the outcome they need.

**Prerequisites.** Stable definitions, a relevant comparison and evidence about measurement error and confounding.

**Minimal adequate alternative.** Direct task evidence or a short qualitative comparison can dominate an elaborate index.

**Trigger for fuller form.** A metric informs prioritisation, prediction, comparison or acceptance of maintenance work.

**Cost of simplification.** A smaller set of task-relevant observations loses easy portfolio aggregation; aggregation is not valuable when the proxy is unvalidated or gamed.

**Omission or retirement.** Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

[ESME-053: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/52)

### ESME-CS054 — Zero-debt policy

**Candidate and disposition.** `ESME-054`; REJECTED_OR_DISFAVOURED

**Protected function and failure.** Reject zero debt as a universal objective; prioritise justified interventions and permit deliberate deferral. Failure: This ignores opportunity cost, uncertain future changes and planned retirement.

**Consumer.** Decision makers retain authority to accept trade-offs; maintainers cannot infer unlimited cleanup funding from the debt label.

**Prerequisites.** No evidence establishes a universal economic optimum at zero debt.

**Minimal adequate alternative.** Fix the consequential burden, defer harmless issues or leave a stable useful system unchanged.

**Trigger for fuller form.** Adjudicate when cleanup completeness is proposed as an unconditional release or maturity criterion.

**Cost of simplification.** Omitting the rejected universal policy has no established inherent loss; some locally justified debt can still warrant removal.

**Omission or retirement.** Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

[ESME-054: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/53)

### ESME-CS055 — Named-owner registry

**Candidate and disposition.** `ESME-055`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Identify consequential ownership/capacity dependencies, support sustainable workload and arrange a feasible handoff or alternative when continuity is at risk. Failure: Popular or technically functional software can lose the people and resources needed for future obligations.

**Consumer.** Maintainers and sponsors negotiate responsibilities voluntarily; downstream organisations decide how to fund or replace unsupported dependencies.

**Prerequisites.** Actual willingness, competence, access and resources; naming an owner does not create capacity.

**Minimal adequate alternative.** A stable finished component with no active obligations need not recruit maintainers merely to appear alive.

**Trigger for fuller form.** Key-person departure, concentrated knowledge, burnout, funding loss or a critical unmaintained dependency.

**Cost of simplification.** A direct arrangement may not survive absence or be visible to consumers; retain an escalation and support route that reflects willingness and capacity.

**Omission or retirement.** Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

[ESME-055: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/54)

### ESME-CS056 — Handover attendance or documentation-completion certificate

**Candidate and disposition.** `ESME-056`; CONTEXT_DEPENDENT

**Protected function and failure.** Use representative tasks, access checks and dialogue to test the receiving maintainer’s ability; preserve rationale and unresolved questions that the task exposes. Failure: Transferred artefacts may not enable a new maintainer to diagnose or change the system.

**Consumer.** Delivering and receiving maintainers exchange knowledge; managers provide time and authority rather than infer competence from attendance.

**Prerequisites.** A willing receiving maintainer, operational access and time to learn; a quiz alone is not enough.

**Minimal adequate alternative.** Pair on one meaningful change or diagnosis instead of producing a comprehensive handover manual.

**Trigger for fuller form.** Ownership transfer, new maintainer onboarding or impending loss of specialised knowledge.

**Cost of simplification.** A small practical task samples only part of capability; broaden demonstrations when the new responsibility spans materially different operations.

**Omission or retirement.** Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

[ESME-056: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/55)

### ESME-CS057 — Universal fixed deprecation period

**Candidate and disposition.** `ESME-057`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Explain the affected behaviour, support state, replacement or lack of replacement, and timing/exception conditions; retain support as promised during transition. Failure: Consumers may receive a removal notice without a workable path or confuse discouraged use with an immediate break.

**Consumer.** Producers communicate policy; affected consumers choose migration; designated governance can authorise documented exceptions.

**Prerequisites.** Known support commitments, reachable consumers where possible and a feasible transition or explicit residual risk.

**Minimal adequate alternative.** For a private coordinated use, direct communication can suffice; indefinite soft deprecation may be appropriate when removal is not justified.

**Trigger for fuller form.** A supported interface, dependency or behaviour is discouraged, changed or scheduled for removal.

**Cost of simplification.** A tailored transition loses scheduling uniformity; it should still provide actionable notice and respect applicable project policy and consumer constraints.

**Omission or retirement.** Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

[ESME-057: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/56)

### ESME-CS058 — Automatic replace-abandoned-dependency policy

**Candidate and disposition.** `ESME-058`; CONTEXT_DEPENDENT

**Protected function and failure.** Assess actual need and viability, then compare continued use, support contribution, isolation, fork or replacement with their ownership and update costs. Failure: Dependency activity can cease while downstream obligations continue; panic replacement can itself introduce greater risk.

**Consumer.** Downstream maintainers and sponsors choose their response; they cannot compel upstream labour or assume a fork will attract support.

**Prerequisites.** Understanding of actual use, licences/access, transitive dependencies and capacity to maintain an alternative.

**Minimal adequate alternative.** Continue using a stable adequate dependency when no unmet obligation warrants change, while retaining appropriate observation.

**Trigger for fuller form.** A dependency loses maintainers, support, compatibility or timely response needed by the consuming system.

**Cost of simplification.** Waiting or contributing retains upstream uncertainty; replacement or forking also creates new costs and needs actual maintainer capacity.

**Omission or retirement.** Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

[ESME-058: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/57)

### ESME-CS059 — Archive-presence or source-preservation badge

**Candidate and disposition.** `ESME-059`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Retain the artefacts and identity needed by named historical, legal or reconstruction consumers, with limitations on buildability and execution explicit. Failure: Loss of source provenance can prevent later study or reconstruction, while archival possession can be mistaken for an operational guarantee.

**Consumer.** Custodians preserve artefacts; future maintainers decide whether reconstruction is feasible and authorised.

**Prerequisites.** Permission to retain/distribute material, adequate identifiers and a retention purpose; private data and credentials require separate treatment.

**Minimal adequate alternative.** Use an existing trustworthy archive and identifiers rather than maintaining a duplicate live service.

**Trigger for fuller form.** Retirement, handoff, publication or dependency disappearance creates a future need for source or history.

**Cost of simplification.** A smaller archive may not support future reconstruction; record what is preserved and do not promise buildability or operation beyond it.

**Omission or retirement.** Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

[ESME-059: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/58)

### ESME-CS060 — Permanent operation as historical preservation

**Candidate and disposition.** `ESME-060`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Identify remaining consumers and obligations, transfer/export or explicitly end them, stop unnecessary operation and retain only justified historical material. Failure: An obsolete service can remain operational without value, or be shut down while data, users and support obligations remain.

**Consumer.** Service/data owners authorise retirement; operators execute shutdown; affected consumers participate where their obligations require it.

**Prerequisites.** Authority to end service, feasible consumer/data transition and known residual retention/access obligations.

**Minimal adequate alternative.** Keep an adequate low-cost system unchanged when retirement would cause more harm; retain an archive rather than a running service when history is the only need.

**Trigger for fuller form.** Continued operation no longer serves an accepted objective or cannot be sustainably supported.

**Cost of simplification.** Shutting down removes immediate service access; resolve continuing consumer needs and retain justified evidence without equating archival custody with live support.

**Omission or retirement.** Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

[ESME-060: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/59)

### ESME-CS061 — Automated repair leaderboard score as acceptance

**Candidate and disposition.** `ESME-061`; STRONGLY_RETAINED

**Protected function and failure.** Treat generated output as a proposed intervention; check the actual patch against independent intent and preservation obligations before acceptance. Failure: Test-suite overfitting and weak evaluation infrastructure can label wrong or incomplete repairs successful.

**Consumer.** Generators propose; maintainers or explicitly delegated policy accept within scope. Generator confidence does not create authority.

**Prerequisites.** Candidate identity, credible oracles, impact evidence and an authorised acceptance consumer.

**Minimal adequate alternative.** A narrow verified transformation or a simple human fix may be cheaper; automation is optional.

**Trigger for fuller form.** An automatic repair tool or LLM generates a maintenance change.

**Cost of simplification.** A bounded generator may find fewer candidate repairs; independent validation and authorisation remain necessary for the consequences it does propose.

**Omission or retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

[ESME-061: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/60)

### ESME-CS062 — Benchmark-only evaluation report

**Candidate and disposition.** `ESME-062`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Record task origin, training/exposure risks, evaluation version, test/oracle limits, exclusions and shared datasets; compare like outcomes with credible baselines. Failure: Contamination, benchmark selection and weak tests can inflate apparent capability or obscure what was measured.

**Consumer.** Researchers and tool evaluators disclose evidence; downstream adopters test transfer to their own obligations.

**Prerequisites.** Enough disclosed benchmark and tool information to interpret the measure and its denominator.

**Minimal adequate alternative.** Use a small transparent local task evaluation when a leaderboard cannot answer the decision question.

**Trigger for fuller form.** A repair or agent capability claim informs adoption, comparison or a maintenance decision.

**Cost of simplification.** A smaller local evaluation loses broad comparability; it can be more relevant to local work if leakage, selection and held-out obligations are explicit.

**Omission or retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

[ESME-062: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/61)

### ESME-CS063 — Per-token or edit-time productivity dashboard

**Candidate and disposition.** `ESME-063`; CONTEXT_DEPENDENT

**Protected function and failure.** Compare end-to-end outcomes and costs against a credible human/tool/no-change baseline, preserving setting, selection and uncertainty. Failure: Fast generation or more passing tasks may hide comprehension, review, repair, latency, energy and downstream regression costs.

**Consumer.** Maintainers report actual work; decision makers accept costs and risks; survey preference is not causal productivity evidence.

**Prerequisites.** Representative tasks, defined outcomes, appropriate baseline and accounting for review and failed attempts.

**Minimal adequate alternative.** For a cheap reversible task, direct bounded experience may suffice; do not run a research programme for every suggestion.

**Trigger for fuller form.** A maintenance automation is selected, expanded or justified economically.

**Cost of simplification.** A cheap bounded trial leaves some long-term effects unmeasured; widen observation when review, regression or operational costs plausibly outweigh apparent speed.

**Omission or retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

[ESME-063: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/62)

### ESME-CS064 — Mandatory independent human approver for every generated patch

**Candidate and disposition.** `ESME-064`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Identify who may accept and deploy which changes, what evidence they need and when an automatic path must defer or stop. Failure: A generated conclusion can be mistaken for permission to mutate a repository or release a service.

**Consumer.** Authorised maintainers or policy holders accept changes; generators cannot enlarge their own mandate from a successful test.

**Prerequisites.** Legitimate authority, actual action capability and explicit bounds for any delegation.

**Minimal adequate alternative.** A sole authorised maintainer may generate, inspect and accept a small change without separate roles; logical distinctions do not require separate people.

**Trigger for fuller form.** Automated or delegated changes can alter shared artefacts or external behaviour.

**Cost of simplification.** Combining logical roles loses interpersonal challenge; it can be adequate for bounded tasks when independent evidence and explicit authority remain effective.

**Omission or retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

[ESME-064: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/63)

### ESME-CS065 — Generic deterministic regression suite for learned systems

**Candidate and disposition.** `ESME-065`; DOMAIN_SPECIFIC

**Protected function and failure.** Include data/model/configuration versions and relevant feedback relationships in the change and preservation boundary; use task-appropriate statistical evidence. Failure: A code-only baseline can miss behavioural changes caused by data, models, configuration or feedback from deployed use.

**Consumer.** Model/data maintainers and domain owners share responsibility; a model score does not authorise a changed societal or service objective.

**Prerequisites.** Data provenance/access, meaningful outcome measures and an understanding of the observation and deployment environment.

**Minimal adequate alternative.** For deterministic code without learned dependencies, ordinary change evidence applies; no ML-specific machinery is needed.

**Trigger for fuller form.** Maintained behaviour materially depends on learned components or changing data distributions.

**Cost of simplification.** Omitting ML-specific machinery is appropriate without learned dependencies; otherwise it can miss data drift, feedback and distribution-sensitive failures.

**Omission or retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

[ESME-065: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/64)

### ESME-CS066 — Repository-wide policy/documentation inventory

**Candidate and disposition.** `ESME-066`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Include consequential non-code artefacts in identity, impact and validation; determine whether an artefact is actually consumed or enforced before crediting its effect. Failure: A source-only review can miss changed deployment rules, access decisions, build behaviour or documentation consumed by operators.

**Consumer.** Artefact owners and operational consumers establish intended effects; a policy file’s author does not automatically control runtime enforcement.

**Prerequisites.** Knowledge of the interpreter/consumer, version semantics and relevant effect or enforcement point.

**Minimal adequate alternative.** Ignore inert or irrelevant files for this change; a focused consumer check may replace a large repository-wide analysis.

**Trigger for fuller form.** Configuration, policy, schema, build definitions or operational documentation changes actual decisions or execution.

**Cost of simplification.** Focused consumer tracing misses inactive or distant artefacts; expand when changes can alter enforcement, builds or other non-code consumers.

**Omission or retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

[ESME-066: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/65)

### ESME-CS067 — Permanent self-improvement governance meeting

**Candidate and disposition.** `ESME-067`; CONTEXT_DEPENDENT

**Protected function and failure.** Revise tools, thresholds or inquiry methods through an authorised change with a stated failure/benefit hypothesis, preserving prior obligations unless separately changed. Failure: A maintenance method can become obsolete or revise its own acceptance rules merely to declare success.

**Consumer.** Method owners and affected consumers approve changes; the method or agent cannot authorise its own broader powers.

**Prerequisites.** Evidence of the method’s limits, an authorised revision boundary and a comparison not defined solely by the proposed successor.

**Minimal adequate alternative.** Keep a working method unchanged or remove an unused control; do not add reflexive governance without a demonstrated consumer.

**Trigger for fuller form.** Repeated false positives, missed failures, excessive cost or changed technology undermines the current method.

**Cost of simplification.** Keeping the existing method may leave emerging failures unaddressed; revise only when actual evidence or changed obligations supplies a reason.

**Omission or retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

[ESME-067: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/66)

### ESME-CS068 — Human-only maintenance policy

**Candidate and disposition.** `ESME-068`; REJECTED_OR_DISFAVOURED

**Protected function and failure.** Reject the universal comparison; evaluate bounded automation by correct outcomes and complete costs. Failure: This extrapolates local adverse results to all tools, people and tasks.

**Consumer.** Maintainers and decision makers select tools; neither vendor optimism nor a single negative study dictates every setting.

**Prerequisites.** No universal comparison across all maintenance tasks and tools exists in the inspected evidence.

**Minimal adequate alternative.** Use whichever simple human/tool combination is supported for the actual task, including no automation.

**Trigger for fuller form.** Adjudicate when a negative experiment is used to forbid all maintenance automation.

**Cost of simplification.** Omitting the rejected rule allows useful bounded assistance but does not remove the need to assess quality, full cost and acceptance authority.

**Omission or retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

[ESME-068: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/67)

### ESME-CS069 — General unattended maintenance promise

**Candidate and disposition.** `ESME-069`; UNRESOLVED

**Protected function and failure.** Withhold the general capability claim; distinguish bounded demonstrated tasks from open obligations in intent, long-term regression, review, authority and deployment. Failure: Benchmarks and narrow deployments may be treated as proof of durable autonomous understanding, acceptance and operation.

**Consumer.** Tool evaluators establish evidence; service/repository owners decide permissible delegation; the claimed capability does not create authority.

**Prerequisites.** Representative unseen tasks, reliable independent oracles, end-to-end outcomes, long-term follow-up and legitimate operational authority would be needed.

**Minimal adequate alternative.** Use bounded automation with explicit constraints, or an ordinary authorised maintainer when evidence is insufficient.

**Trigger for fuller form.** A general unattended-maintenance claim is used to remove oversight or transfer responsibility.

**Cost of simplification.** Withholding this unresolved promise limits unattended scope; it avoids exporting a guarantee that representative long-term evidence has not established.

**Omission or retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

[ESME-069: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/68)

### ESME-CS070 — Separate golden-master property and control

**Candidate and disposition.** `ESME-070`; DUPLICATE_CANDIDATE

**Protected function and failure.** Link to ESME-030; apply its provisional-oracle and consumer conditions rather than create a second obligation. Failure: Counting the label separately would duplicate the same mechanism and inflate the retained denominator.

**Consumer.** The same maintainers and domain consumers adjudicate snapshot differences.

**Prerequisites.** The claimed mechanism has the same trigger and provisional behaviour evidence as ESME-030.

**Minimal adequate alternative.** Use the existing characterisation mechanism; omit duplicate records and tooling in later integration.

**Trigger for fuller form.** The phrase is used for recording current outputs to detect differences.

**Cost of simplification.** Merging this duplicate into characterisation loses no distinct mechanism; preserve terminology where a genuine consumer uses it.

**Omission or retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

[ESME-070: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/69)

### ESME-CS071 — Formal change board for every edit

**Candidate and disposition.** `ESME-071`; CEREMONY_NOT_GENERAL_PROPERTY

**Protected function and failure.** Strip the mandatory ritual while preserving appropriate authorisation, consultation and evidence; use a fuller forum only when conflicts or obligations require it. Failure: Universal boards can add delay and diffuse accountability without improving intent or impact decisions.

**Consumer.** Existing legitimate decision authority remains; removal of ceremony does not permit unauthorised changes.

**Prerequisites.** A real unresolved cross-party decision or external requirement is needed to justify the fuller form.

**Minimal adequate alternative.** A direct authorised maintainer decision can suffice for a bounded change.

**Trigger for fuller form.** Adjudicate when the presence of a board is treated as the maintenance property itself.

**Cost of simplification.** Removing the universal board loses a shared forum; use one where conflicting authority, coordination or applicable obligations cannot be satisfied more simply.

**Omission or retirement.** Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

[ESME-071: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/70)

### ESME-CS072 — Dedicated evidence registry with automatic invalidation

**Candidate and disposition.** `ESME-072`; RETAINED_IN_EVOLVED_FORM

**Protected function and failure.** Bind evidence and acceptance to the relevant candidate, intent and assumptions; invalidate or re-evaluate affected evidence when a consequential input changes, and deliver it to an actor able to act. Failure: Each local mechanism can be satisfied while stale evidence, changed intent or uncommunicated results disconnect it from the action actually taken.

**Consumer.** Analysts communicate evidence; authorised actors accept and operate; achieved consequences require observation after action.

**Prerequisites.** Identifiable objects and obligations, traceable evidence scope and a consumer with actual authority and capability.

**Minimal adequate alternative.** One maintainer can keep the binding through a single visible diff and check; no new registry or owner is intrinsically required.

**Trigger for fuller form.** Evidence crosses a tool/person boundary, concurrent work changes the candidate, or a method uses results to authorise action.

**Cost of simplification.** A visible local diff and check may not survive distributed handoffs or concurrent edits; enrich binding when stale evidence can reach another actor.

**Omission or retirement.** Include coordination and validation costs created by composition. Consolidate or retire controls when a cheaper adequate configuration exists, without silently waiving protected obligations.

[ESME-072: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/71)

### ESME-CS073 — Exhaustive joint-state model

**Candidate and disposition.** `ESME-073`; ASSUMPTION_SENSITIVE

**Protected function and failure.** Identify reachable joint states, authoritative data and permitted version/change combinations; constrain operation or add evidence for the newly created interactions. Failure: Transition or integration can create new interactions absent from either endpoint’s separate assessment.

**Consumer.** Integrators and operators control only their own transitions; consumer/data owners adjudicate cross-boundary obligations.

**Prerequisites.** A credible account of reachable combinations, sequencing and external actors; abstract state models must match actual operation.

**Minimal adequate alternative.** A truly atomic quiescent transition or justified disjoint changes can eliminate most joint-state obligations.

**Trigger for fuller form.** Coexistence, concurrent integration, data conversion or externally staggered upgrades create intermediate states.

**Cost of simplification.** Constraining reachable combinations loses flexibility and may require interruption; that cost can dominate uncontrolled state-space growth.

**Omission or retirement.** Include coordination and validation costs created by composition. Consolidate or retire controls when a cheaper adequate configuration exists, without silently waiving protected obligations.

[ESME-073: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/72)

### ESME-CS074 — Permanent control-optimisation dashboard

**Candidate and disposition.** `ESME-074`; CONTEXT_DEPENDENT

**Protected function and failure.** Evaluate the combined decision benefit, interaction cost and residual risk of controls; consolidate, simplify or retire them when a cheaper adequate configuration dominates. Failure: Individually sensible checks, documents, adapters and review steps can together exceed their benefit or persist without a consumer.

**Consumer.** Maintainers and decision owners revise controls; external obligations remain binding unless legitimately changed.

**Prerequisites.** Knowledge of protected obligations, actual consumers, combined costs and authority to alter the method without silently waiving required outcomes.

**Minimal adequate alternative.** Retain a small working arrangement unchanged; do not create a permanent meta-process merely to measure every control.

**Trigger for fuller form.** Accumulating controls, repeated false alarms, migration completion, disappearing consumers or changed lifecycle objectives.

**Cost of simplification.** A direct periodic decision can miss slow cost interactions or rare protective value; use richer observation only when it affects justified control selection.

**Omission or retirement.** Include coordination and validation costs created by composition. Consolidate or retire controls when a cheaper adequate configuration exists, without silently waiving protected obligations.

[ESME-074: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/73)


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CRITICISM_LEDGER

Source observations below are separated from this study’s response and present judgement. Adverse evidence changes dispositions: it is not explained away as a failure to practise the “real” tradition. At the same time, an implementation outside a theorem’s assumptions is not a refutation of the theorem.

### ESME-C001 — Maintenance labels may not be reliably applied by the people producing effort records.

**Affected candidates.** `ESME-002`, `ESME-071`

**Source locator.** Study design and inter-rater reliability results

**Evidence.** One field experiment with eight developers found low agreement for both compared schemes; this is classification evidence, not a measure of business value.

**Response.** Permit mixed purposes, define the unit and require classification only when a decision consumes it.

**Later findings.** V3/V4 guidance still organises maintenance; continued standardisation does not remove the reliability objection.

**Present judgement.** Retain a qualified communication mechanism, not an objectively exhaustive partition or compulsory board.

**Residual uncertainty.** Whether improved definitions/training increase actual decision quality remains open.

**Transition.** NARROWED

[ESME-S007] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C002 — Claims of universal expansion or unavoidable deterioration depend on population and measurement.

**Affected candidates.** `ESME-006`, `ESME-007`, `ESME-010`

**Source locator.** Founding scope; Linux growth; law-review synthesis; Linux complexity and glibc phase D

**Evidence.** Founding work allows consolidation. Linux and glibc show different trajectories; total and mean complexity can diverge.

**Response.** Operationalise the law and test alternatives; admit non-change and stage-specific interpretation.

**Later findings.** S060 conditionally supports several laws; S061’s plateau does not itself establish subsequent loss of usefulness.

**Present judgement.** ESME-010 rejected; ESME-007 assumption-sensitive rather than dismissed as wholly useless.

**Residual uncertainty.** Cross-population predictive scope is not established by these cases.

**Transition.** NARROWED

[ESME-S008; ESME-S011; ESME-S029; ESME-S060; ESME-S061] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C003 — Repository history, documents and ownership fields are incomplete proxies for human ability and capacity.

**Affected candidates.** `ESME-004`, `ESME-008`, `ESME-009`, `ESME-015`, `ESME-055`, `ESME-056`

**Source locator.** Knowledge-loss model and maintainer interview findings

**Evidence.** History-based modelling and abandonment interviews illuminate risk but do not measure every form of expertise or create replacement labour.

**Response.** Use task demonstrations, dialogue and actual resource commitments rather than a universal knowledge database.

**Later findings.** Abandonment responses include transferring work downstream through forks or replacement.

**Present judgement.** Retain continuity capability; reject the implication that metadata removes social or economic constraints.

**Residual uncertainty.** Sustainable capacity interventions need target-specific evidence.

**Transition.** REFINED

[ESME-S047; ESME-S043] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C004 — Neither a slice nor a comprehensive-looking model provides universal understanding.

**Affected candidates.** `ESME-011`, `ESME-013`, `ESME-016`

**Source locator.** Slicing criterion and computability; cognitive models; question studies

**Evidence.** Weiser’s guarantee is criterion/model-relative and general minimal slicing is undecidable; comprehension studies report diverse interacting questions.

**Response.** Bound inquiry by consequential questions and expand on contradiction.

**Later findings.** Question-driven empirical work reinforces the need for multiple evidence kinds rather than one mandatory model.

**Present judgement.** ESME-016 rejected; ESME-013 remains assumption-sensitive and ESME-011 retained.

**Residual uncertainty.** Optimal stopping for high-consequence unknown dependencies is unresolved.

**Transition.** REPLACED

[ESME-S013; ESME-S014; ESME-S015] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C005 — Inferred dependencies may miss real effects or demand irrelevant companion work.

**Affected candidates.** `ESME-012`, `ESME-017`, `ESME-018`, `ESME-019`, `ESME-020`, `ESME-021`

**Source locator.** ROSE discussion of actual versus intended dependencies; semantic-analysis comparison

**Evidence.** Historical co-change reflects practice; static and dynamic semantic analyses show precision/recall trade-offs.

**Response.** Use typed evidence, plausible false-negative challenges and local confirmation rather than automatic propagation.

**Later findings.** The semantic-conflict study reuses most scenarios from earlier datasets; this is not broad independent replication.

**Present judgement.** Retain impact analysis but explicitly reject completeness from tool silence.

**Residual uncertainty.** Rare configurations and undeclared consumers remain difficult.

**Transition.** NARROWED

[ESME-S017; ESME-S044] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C006 — Semantic interference is not identical to an unintended semantic conflict.

**Affected candidates.** `ESME-022`, `ESME-073`

**Source locator.** Dataset construction, supported cases and static/dynamic comparison

**Evidence.** Information flow can be benign or intended; buildable Java cases and tool support restrict evaluation.

**Response.** Combine interference candidates with both change intents and validate the integrated artefact.

**Later findings.** No inspected result supplies a universal conflict oracle across code, data and configuration.

**Present judgement.** Assumption-sensitive evidence mechanism, with integration obligations distinct from endpoint success.

**Residual uncertainty.** Intent and rare cross-artefact interactions remain partly human-adjudicated.

**Transition.** REFINED

[ESME-S044] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C007 — Formal refactoring language is routinely used for changes whose actual environment lies outside the proof model.

**Affected candidates.** `ESME-014`, `ESME-023`, `ESME-024`, `ESME-025`, `ESME-026`

**Source locator.** Transformation preconditions; differentiated bug study; observer/oracle definitions

**Evidence.** Opdyke’s rules have preconditions; later empirical work finds actual fault-inducing refactorings alongside confounded associations.

**Response.** Check applicability, preserve declared observers and validate the resulting artefact.

**Later findings.** Differentiated replication narrows simplistic causal blame without establishing fault-free refactoring.

**Present judgement.** Preservation remains strong; formal applicability remains assumption-sensitive.

**Residual uncertainty.** Proof-to-tool and tool-to-environment gaps are not closed by a catalogue.

**Transition.** REFINED

[ESME-S018; ESME-S020; ESME-S051] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C008 — Cleaner structure or catalogue membership does not establish lower future cost or better human comprehension.

**Affected candidates.** `ESME-008`, `ESME-027`, `ESME-028`, `ESME-053`

**Source locator.** Refactoring survey; metric study; differentiated replication

**Evidence.** Industrial self-reports and structural proxies answer different questions; cross-class measures and concurrent edits complicate interpretation.

**Response.** Name the future task and test its payoff; include immediate review and regression costs.

**Later findings.** Conflicting empirical interpretations prevent a universal positive or negative refactoring verdict.

**Present judgement.** ESME-028 rejected; task-specific benefit and defeasible metrics retained conditionally.

**Residual uncertainty.** Durable causal task benefit remains unevenly evidenced.

**Transition.** NARROWED

[ESME-S020; ESME-S021; ESME-S022] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C009 — Passing tests or matching previous output can preserve a defect and omit the intended change.

**Affected candidates.** `ESME-029`, `ESME-030`, `ESME-031`, `ESME-061`, `ESME-070`

**Source locator.** Oracle survey; patch validation; author account of characterisation

**Evidence.** Repair studies expose weak oracles and overfitting; characterisation records actual rather than necessarily desired behaviour.

**Response.** Keep oracle provenance and independently adjudicate intended differences.

**Later findings.** LLM patch studies continue to separate developer-test failure from mere gold-patch difference.

**Present judgement.** Test passage is partial evidence; never an unconditional correctness or authorisation claim.

**Residual uncertainty.** Independent oracles can still disagree or remain incomplete.

**Transition.** REFINED

[ESME-S024; ESME-S026; ESME-S051; ESME-S059] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C010 — Alternative oracles can create false confidence when relations or fault models are wrong.

**Affected candidates.** `ESME-032`, `ESME-033`

**Source locator.** Metamorphic relation definition; mutant/real-fault comparison and validity threats

**Evidence.** Metamorphic methods require domain-valid relations; mutation evidence comes from selected faults and operators.

**Response.** Treat both as partial probes and investigate what a failure or surviving mutant actually means.

**Later findings.** Empirical coupling supports mutation’s usefulness but not complete fault coverage.

**Present judgement.** Preserve optional, assumption-sensitive methods rather than a mandatory test stack.

**Residual uncertainty.** Transfer to probabilistic components and unseen fault classes requires additional evidence.

**Transition.** NARROWED

[ESME-S051; ESME-S062; ESME-S063] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C011 — Test optimisation can cost more than it saves or make failures visible too late.

**Affected candidates.** `ESME-034`, `ESME-035`, `ESME-037`, `ESME-040`, `ESME-074`

**Source locator.** Selection cost discussion; prioritisation efficacy distinction; CI skipping and threats

**Evidence.** Selection has analysis costs; order does not increase a suite’s ultimate efficacy; build-skipping gains come with delayed observations and potential temporal leakage.

**Response.** Compare end-to-end cost and decision latency; label omitted or skipped evidence honestly.

**Later findings.** Current build prediction does not supersede model-relative selection or direct retest-all for small suites.

**Present judgement.** Optimisation is conditional; consumed feedback, not maximum test activity, is retained.

**Residual uncertainty.** Costs of delayed rare severe failures are hard to estimate.

**Transition.** REFINED

[ESME-S023; ESME-S058; ESME-S066] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C012 — Identity, reproducibility, backup presence and recoverability are different properties.

**Affected candidates.** `ESME-003`, `ESME-036`, `ESME-041`, `ESME-059`

**Source locator.** GitLab restore account; reproducible-build definition; archival scope

**Evidence.** The GitLab incident involved unusable expected backup paths and tool-version incompatibility; source archives do not guarantee buildable artefacts.

**Response.** Demonstrate the actual needed recovery and retain identity without overstating operational capability.

**Later findings.** Archival work explicitly separates collection from curation.

**Present judgement.** Retain identity and recovery separately; no green source-revert receipt can stand for restored data.

**Residual uncertainty.** Future environments and external effects can remain unrecoverable.

**Transition.** REFINED

[ESME-S038; ESME-S046; ESME-S054] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C013 — A version label, deprecation notice or private label may not protect real downstream users.

**Affected candidates.** `ESME-020`, `ESME-038`, `ESME-039`, `ESME-057`

**Source locator.** Compatibility policy and abandonment-response interviews

**Evidence.** PEP 387 defines concrete observable compatibility and distinguishes soft deprecation; dependency interviews reveal consumer constraints.

**Response.** Communicate actionable support boundaries and permit exceptions or continued support where justified.

**Later findings.** Policy duration is local to its governance, not a universal engineering constant.

**Present judgement.** Retain consumer interaction, not blanket preservation or a mandatory duration.

**Residual uncertainty.** Unknown consumers and involuntary transitions remain a residual accountability problem.

**Transition.** NARROWED

[ESME-S045; ESME-S043] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C014 — Incremental and big-bang migration can each fail, and modernisation narratives are selectively positive.

**Affected candidates.** `ESME-042`, `ESME-043`, `ESME-044`, `ESME-047`, `ESME-048`

**Source locator.** Migration review alternatives; mobile case; GAO VCF findings

**Evidence.** Gateway/dual-operation complexity is recognised in the review; the mobile case is uncontrolled; GAO documents several interacting management and requirement problems.

**Response.** Keep rival strategies with selection conditions and include transition/retirement costs.

**Later findings.** Later strangler accounts refine an existing migration idea rather than proving universal superiority.

**Present judgement.** Age-only replacement rejected; both migration branches remain contextual.

**Residual uncertainty.** Comparative causal evidence for full lifecycle costs remains weak.

**Transition.** REFINED

[ESME-S031; ESME-S037; ESME-S039] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C015 — Successful conversion does not imply invertibility or consistent coexistence.

**Affected candidates.** `ESME-041`, `ESME-045`, `ESME-046`, `ESME-073`

**Source locator.** Incident recovery; PRISM mappings and information-preserving conditions

**Evidence.** Formal mappings have supported operator assumptions; actual restoration depends on available data and tooling.

**Response.** Identify irreversible information loss and phase-specific data authority; use retained information or forward repair rather than fictitious inverse operations.

**Later findings.** No inspected source supplies a general guarantee for arbitrary deployed databases and external effects.

**Present judgement.** Preserve model-relative mapping plus operative reconciliation and joint-state checks.

**Residual uncertainty.** Exhaustive semantic comparison can be unaffordable.

**Transition.** NARROWED

[ESME-S038; ESME-S053] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C016 — Debt accounting can become a literal financial fiction or justify unlimited cleanup.

**Affected candidates.** `ESME-049`, `ESME-050`, `ESME-051`, `ESME-052`, `ESME-054`

**Source locator.** Original metaphor; debt productivity replication; seminar definition and reframing agenda

**Evidence.** Self-reported waste is not experimentally demonstrated recoverable savings; original and replicated results use different denominators.

**Response.** Use scenario-dependent future burden, bounded remediation and explicit opportunity cost.

**Later findings.** The 2025 agenda reframes value without independently validating a universal economic model.

**Present judgement.** Zero debt rejected; contingent economics remains assumption-sensitive.

**Residual uncertainty.** Future objectives and rare change classes make payoff estimates uncertain.

**Transition.** REFINED

[ESME-S019; ESME-S032; ESME-S048; ESME-S049] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C017 — Inactivity can be finished work, while popularity can coexist with inadequate support.

**Affected candidates.** `ESME-005`, `ESME-055`, `ESME-058`, `ESME-060`

**Source locator.** Reasons for OSS cessation; interviews on abandoned dependencies

**Evidence.** 17 of 104 respondents in the cessation study described finished projects; interviews show varied downstream responses.

**Response.** Distinguish actual unmet obligations from activity signals; allow no-change, support, fork, replacement or retirement.

**Later findings.** No inspected interview establishes one universally superior abandonment response.

**Present judgement.** Retain a legitimate no-change branch and a separate continuity-risk branch.

**Residual uncertainty.** Hidden consumer demand and future support needs are imperfectly observable.

**Transition.** REFINED

[ESME-S040; ESME-S043] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C018 — Repair success defined by available tests may be overfitting, and some historical evaluations had separate infrastructure errors.

**Affected candidates.** `ESME-061`, `ESME-062`, `ESME-069`

**Source locator.** GenProg assumptions; 2015 repair analysis; 2025 original-author retrospective

**Evidence.** S024 separates feature requests, weak test validation and patch correctness; original GenProg explicitly assumes useful tests and reproducibility.

**Response.** Adjudicate tool defects, search limits and oracle limits separately; do not dismiss all adverse results as not really repair.

**Later findings.** The retrospective recognises partial specifications and context-sensitive use cases; different gold patches can still be legitimate.

**Present judgement.** Candidate boundary retained; general unattended capability remains unresolved, not impossible.

**Residual uncertainty.** Long-term correctness and representative evaluation remain unestablished.

**Transition.** REFINED

[ESME-S024; ESME-S065; ESME-S067] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C019 — Automation may increase total work or harm debugging through deceptive suggestions; manual review is not automatically a cure.

**Affected candidates.** `ESME-063`, `ESME-064`, `ESME-068`

**Source locator.** RCT methods; 2026 selection update; survey; repair-user study; deployment account

**Evidence.** The early-2025 RCT reports slowdown in its setting; S052 distinguishes helpful correct and harmful deceptive suggestions; S033 reports new selection problems.

**Response.** Measure task quality and full cost with a credible baseline; allow narrow effective deployment without universalising it.

**Later findings.** S034 is positive subjective evidence, not causal reversal of S025; SapFix is actual bounded deployment, not a universal outcome estimate.

**Present judgement.** Both universal human-only superiority and universal automation benefit rejected.

**Residual uncertainty.** The causal effect of current tools across representative populations is unresolved.

**Transition.** STILL_CONTESTED

[ESME-S025; ESME-S033; ESME-S034; ESME-S052; ESME-S055] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C020 — Leaderboard performance can reflect contamination, selected tasks or plausible rather than correct repairs.

**Affected candidates.** `ESME-062`, `ESME-069`

**Source locator.** Developer-test patch analysis; selected difficult benchmark audit; current APR limitations

**Evidence.** S027’s 59.4% refers to its selected difficult subset, not the whole benchmark; S026’s gold-patch differences do not all imply wrong repairs.

**Response.** Preserve exact denominators, independently test correctness and disclose common datasets and exclusions.

**Later findings.** The July 2026 quantisation preprint still measures test plausibility and acknowledges leakage limitations.

**Present judgement.** General capability claim remains unresolved; benchmark hygiene remains an evidence obligation.

**Residual uncertainty.** Hidden training data and changing benchmarks impede clean comparison.

**Transition.** REFINED

[ESME-S026; ESME-S027; ESME-S057] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C021 — Memory savings or unchanged aggregate pass counts can hide greater energy/time cost or a different set of solved tasks.

**Affected candidates.** `ESME-063`, `ESME-065`

**Source locator.** Experimental hardware, outcomes and limitations

**Evidence.** The current quantisation study compares six models and 13 configurations on one disclosed platform and two benchmarks.

**Response.** Evaluate the actual deployment objective and hardware, including instance-level outcomes and validation costs.

**Later findings.** Future conference presentation is not additional replication; current preprint evidence is preserved with its date.

**Present judgement.** No universal quantisation choice or production productivity gain inferred.

**Residual uncertainty.** Generalisation across hardware and task distributions remains open.

**Transition.** NARROWED

[ESME-S057] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C022 — Source-only maintenance and file-presence checks miss data feedback, configuration and unenforced policy.

**Affected candidates.** `ESME-018`, `ESME-065`, `ESME-066`

**Source locator.** ML debt mechanisms; policy study RQ3 and threats

**Evidence.** S042 documents entanglement and undeclared consumers; S056 finds maintained policy artefacts but commit share is not effort or enforcement.

**Response.** Follow consequential artefacts to actual consumers and observations rather than crediting their existence.

**Later findings.** The 2026 paper’s wide-adoption recommendation outruns its observational cost evidence.

**Present judgement.** Retain non-code effects and domain-specific learned-system boundaries, not universal policy tooling.

**Residual uncertainty.** Runtime enforcement and downstream benefit require target evidence.

**Transition.** REFINED

[ESME-S042; ESME-S056] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C023 — A composed process can be circular, stale, unauthorised or more costly than its protected work.

**Affected candidates.** `ESME-067`, `ESME-072`, `ESME-074`

**Source locator.** Cross-source synthesis of baseline, migration, oracle and cost limits

**Evidence.** This is an analytical objection derived from incompatible local assumptions, not a new published comparative experiment.

**Response.** Bind evidence to actual candidates and authority; re-evaluate affected evidence on change; remove controls whose consumer or payoff disappears.

**Later findings.** No source independently validates the complete Evolved composition.

**Present judgement.** Three composition-induced candidates retained conditionally with explicit new costs; no global optimisation claim.

**Residual uncertainty.** Coordination benefit and revalidation costs need integrated field evaluation.

**Transition.** REFINED

[ESME-S002; ESME-S031; ESME-S038; ESME-S048; ESME-S051; ESME-S058] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.

### ESME-C024 — A technically coherent method can identify a need without having resources, legitimacy or operative power to realise it.

**Affected candidates.** `ESME-001`, `ESME-004`, `ESME-042`, `ESME-060`, `ESME-064`, `ESME-067`, `ESME-069`

**Source locator.** Requirement/management failure; dependency constraints; policy authority; author retrospective

**Evidence.** Primary case and policy sources expose human and organisational boundaries; research recommendations do not grant external authority.

**Response.** Separate distinction, authorised/capable action and observed consequence; preserve unresolved conflicts rather than silently treating them as implementation details.

**Later findings.** New automation changes candidate production but does not erase external ownership or affected consumers.

**Present judgement.** No target adoption or self-authorisation exported; infeasible action can lead to deferral, non-change or retirement.

**Residual uncertainty.** Legitimate resolution of stakeholder disagreement is not fully reducible to a technical procedure.

**Transition.** PRESERVED

[ESME-S039; ESME-S043; ESME-S045; ESME-S067] Source findings and limits are identified in EVIDENCE; the response and disposition are this study’s analytical adjudication unless explicitly described as an author response.


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_EVOLUTION_UNDER_CRITICISM

The following evolution accounts identify the actual narrowing, replacement or residual contestation for every candidate. These are not all historical author responses: where the candidate is a newly tested generalisation or a composition-induced obligation, the transition is explicitly this study’s analytical judgement. The criticism ledger supplies the associated sources and rival explanations.

**ESME-001 — Explicit and authorised change intent.** REFINED: pair approval with revisable intent and explicit preserved-versus-changed obligations, rather than a universal heavyweight change board. **Present disposition:** `STRONGLY_RETAINED`. [ESME-S002; ESME-S005; ESME-S039; ESME-S051]

**ESME-002 — Multi-purpose change classification.** NARROWED: taxonomy is defeasible descriptive support, not an objective universal partition. Swanson’s original body and Chapin’s full taxonomy were inaccessible. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S002; ESME-S004; ESME-S005; ESME-S006; ESME-S007]

**ESME-003 — Recoverable configuration baseline.** GENERALISED within maintenance scope from text revision control to the configuration actually responsible for observed behaviour; no universal byte-level snapshot requirement. **Present disposition:** `STRONGLY_RETAINED`. [ESME-S002; ESME-S030; ESME-S038; ESME-S046]

**ESME-004 — Maintenance readiness across the delivery boundary.** REFINED: readiness is demonstrated capability rather than a post-delivery lifecycle label or document handover. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S001; ESME-S002; ESME-S003; ESME-S005; ESME-S047]

**ESME-005 — Deliberate non-change.** NARROWED: no-change is a positive decision branch, not a universal inference from low activity. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S010; ESME-S031; ESME-S040; ESME-S050; ESME-S061]

**ESME-006 — Evolution feedback with measurable consequences.** REFINED: feedback is a testable decision relationship, not a universal growth equation or dashboard. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S008; ESME-S009; ESME-S010; ESME-S029; ESME-S060; ESME-S061]

**ESME-007 — Population-scoped evolution-law interpretation.** NARROWED: preserve scoped hypotheses and historical explanation; reject unqualified necessity of growth or decay. **Present disposition:** `ASSUMPTION_SENSITIVE`. [ESME-S008; ESME-S009; ESME-S010; ESME-S011; ESME-S029; ESME-S060; ESME-S061]

**ESME-008 — Costed complexity and anti-regressive work.** REFINED: costed anti-regressive investment replaces the slogan that all complexity must continually decrease. **Present disposition:** `CONTEXT_DEPENDENT`. [ESME-S008; ESME-S020; ESME-S022; ESME-S032; ESME-S050; ESME-S060]

**ESME-009 — Familiarity and knowledge-capacity constraints.** REFINED: familiarity becomes a contextual capacity constraint, not a fixed numerical law or universal team-size limit. **Present disposition:** `CONTEXT_DEPENDENT`. [ESME-S008; ESME-S010; ESME-S014; ESME-S043; ESME-S047]

**ESME-010 — Universal mandatory growth or inevitable deterioration.** REJECTED as a universal mandate; ESME-007 preserves the narrower explanatory programme. **Present disposition:** `REJECTED_OR_DISFAVOURED`. [ESME-S008; ESME-S009; ESME-S010; ESME-S011; ESME-S029; ESME-S060; ESME-S061]

**ESME-011 — Question-bounded program comprehension.** REFINED: interleaved inquiry and change replaces a requirement for one complete mental model before acting. **Present disposition:** `STRONGLY_RETAINED`. [ESME-S014; ESME-S015; ESME-S051]

**ESME-012 — Static and dynamic evidence triangulation.** REFINED: triangulation is guarded by information gain and cost, not a fixed bundle of tools. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S012; ESME-S013; ESME-S014; ESME-S015; ESME-S044; ESME-S051]

**ESME-013 — Criterion-relative program slicing.** NARROWED: retain model-relative slicing, reject the inference that a slice proves all omitted code irrelevant to all maintenance questions. **Present disposition:** `ASSUMPTION_SENSITIVE`. [ESME-S013; ESME-S051]

**ESME-014 — Distinguish recovery from transformation.** PRESERVED as a useful distinction, with descriptive rather than policing use of historical terminology. **Present disposition:** `STRONGLY_RETAINED`. [ESME-S012; ESME-S021]

**ESME-015 — Recover intent with rationale and human knowledge.** REFINED: retain rationale through actual consumers and revision, not through document volume or a fiction that expertise is fully codifiable. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S012; ESME-S014; ESME-S015; ESME-S043; ESME-S047]

**ESME-016 — Exhaustive system comprehension before every change.** REPLACED by ESME-011, ESME-017 and ESME-021 rather than by permission to change blindly. **Present disposition:** `REJECTED_OR_DISFAVOURED`. [ESME-S013; ESME-S014; ESME-S015]

**ESME-017 — Justified impact boundary.** REFINED: boundary justification includes how false negatives might be found, rather than treating an automatically produced set as final. **Present disposition:** `STRONGLY_RETAINED`. [ESME-S013; ESME-S016; ESME-S017; ESME-S044]

**ESME-018 — Heterogeneous dependency propagation.** GENERALISED to heterogeneous artefacts while retaining evidence-type distinctions. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S016; ESME-S041; ESME-S042; ESME-S044; ESME-S053]

**ESME-019 — Historical co-change as defeasible evidence.** NARROWED from prediction-as-truth to evidence for investigation. **Present disposition:** `ASSUMPTION_SENSITIVE`. [ESME-S017; ESME-S044]

**ESME-020 — Affected-consumer discovery.** REFINED: discovery and communication are bounded evidence and interaction, not a guarantee of universal consumer enumeration. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S016; ESME-S041; ESME-S042; ESME-S043; ESME-S045]

**ESME-021 — Impact false-negative challenge.** REFINED: retain challenge as a conditional search obligation, not mandatory exhaustive testing. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S016; ESME-S017; ESME-S044; ESME-S051]

**ESME-022 — Semantic interference analysis for merged changes.** REFINED: use semantic analysis as evidence within merge validation, not a complete conflict oracle. **Present disposition:** `ASSUMPTION_SENSITIVE`. [ESME-S044; ESME-S051]

**ESME-023 — Observer-relative preservation obligations.** REFINED: retain observer-relative preservation and explicit exceptions rather than a context-free phrase such as behaviour unchanged. **Present disposition:** `STRONGLY_RETAINED`. [ESME-S012; ESME-S018; ESME-S020; ESME-S022; ESME-S045; ESME-S051]

**ESME-024 — Transformation preconditions and model scope.** NARROWED to an explicit proof-to-implementation obligation, not a universal guarantee from the word refactoring. **Present disposition:** `ASSUMPTION_SENSITIVE`. [ESME-S018; ESME-S020; ESME-S051]

**ESME-025 — Validation of the actual transformed artefact.** REFINED: bind validation to candidate identity and distinguish rule validity from artefact validity. **Present disposition:** `STRONGLY_RETAINED`. [ESME-S018; ESME-S020; ESME-S024; ESME-S051; ESME-S052]

**ESME-026 — Separate preservation from intentional behaviour change.** REFINED: preserve distinct acceptance obligations without mandating a particular patch structure. **Present disposition:** `STRONGLY_RETAINED`. [ESME-S002; ESME-S018; ESME-S023; ESME-S051; ESME-S059]

**ESME-027 — Refactoring benefit tied to a future change class.** NARROWED: retain task-specific benefit hypotheses, not automatic benefit from catalogue membership. **Present disposition:** `CONTEXT_DEPENDENT`. [ESME-S018; ESME-S019; ESME-S020; ESME-S021; ESME-S022]

**ESME-028 — Cleaner structure guarantees engineering benefit.** REJECTED as a guarantee; ESME-027 and ESME-053 retain defeasible uses. **Present disposition:** `REJECTED_OR_DISFAVOURED`. [ESME-S020; ESME-S021; ESME-S022]

**ESME-029 — Oracle provenance and independent obligations.** REFINED: combine partial independent obligations rather than equating more tests with certainty. **Present disposition:** `STRONGLY_RETAINED`. [ESME-S024; ESME-S026; ESME-S051; ESME-S052]

**ESME-030 — Characterisation as provisional behavioural evidence.** REFINED: provisional, consumer-linked characterisation replaces indiscriminate freezing of all existing output. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S024; ESME-S051; ESME-S059]

**ESME-031 — Differential testing with adjudicated differences.** REFINED: differential evidence is coupled to adjudication and bounded configuration coverage. **Present disposition:** `CONTEXT_DEPENDENT`. [ESME-S051; ESME-S064]

**ESME-032 — Metamorphic relations as partial oracles.** GENERALISED in later oracle research but retained as a partial, assumption-sensitive method, not a replacement for all specifications. **Present disposition:** `ASSUMPTION_SENSITIVE`. [ESME-S051; ESME-S063]

**ESME-033 — Mutation analysis as an adequacy probe.** NARROWED: empirical support warrants an adequacy probe, not a guarantee that all real faults will be detected. **Present disposition:** `CONTEXT_DEPENDENT`. [ESME-S051; ESME-S062]

**ESME-034 — Regression selection under explicit safety and cost assumptions.** REFINED: compare total cost and explicit model-relative safety rather than merely counting fewer tests. **Present disposition:** `ASSUMPTION_SENSITIVE`. [ESME-S023; ESME-S051]

**ESME-035 — Test prioritisation under interruption and feedback costs.** REFINED: treat prioritisation and omission as different choices with different evidence obligations. **Present disposition:** `CONTEXT_DEPENDENT`. [ESME-S023; ESME-S051; ESME-S058; ESME-S066]

**ESME-036 — Reproducible and identifiable build evidence.** NARROWED: reproducibility supports identity and diagnosis, not correctness, security or indefinite executability. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S002; ESME-S030; ESME-S038; ESME-S046]

**ESME-037 — Continuous integration with consumed feedback.** REFINED: consumed feedback is the mechanism, not the presence of a CI configuration or an every-commit ritual. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S002; ESME-S040; ESME-S058]

**ESME-038 — Declared compatibility surface and version policy.** REFINED: compatibility is a supported surface and interaction, not universal preservation or a particular version-number syntax. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S043; ESME-S045; ESME-S051]

**ESME-039 — Mixed-version compatibility conditions.** REFINED: coexistence obligations are explicit and temporary where possible, not a universal mandate for backward compatibility. **Present disposition:** `ASSUMPTION_SENSITIVE`. [ESME-S031; ESME-S038; ESME-S043; ESME-S045; ESME-S053]

**ESME-040 — Staged exposure with actionable observations.** NARROWED: staged exposure is a conditional control, not proof of safety or a mandatory release ritual. **Present disposition:** `CONTEXT_DEPENDENT`. [ESME-S035; ESME-S036; ESME-S037; ESME-S038]

**ESME-041 — State-and-effect recovery rather than code reversion alone.** REFINED: recovery is an outcome across code, data and effects, not a command name. **Present disposition:** `STRONGLY_RETAINED`. [ESME-S038; ESME-S053]

**ESME-042 — Compare maintenance, migration, replacement and non-change.** REFINED: replace age-based prescriptions with context-specific option comparison. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S031; ESME-S035; ESME-S036; ESME-S039; ESME-S040]

**ESME-043 — Incremental displacement with bounded coexistence.** REFINED: retain incremental displacement with a coexistence budget and exit criteria, not a fashionable architectural shape. **Present disposition:** `CONTEXT_DEPENDENT`. [ESME-S031; ESME-S035; ESME-S036; ESME-S037; ESME-S053]

**ESME-044 — Quiescent or big-bang cutover as a conditional alternative.** DOMAIN_SPECIFIC alternative preserved rather than treating incremental migration as the only mature form. **Present disposition:** `DOMAIN_SPECIFIC`. [ESME-S031; ESME-S038; ESME-S053]

**ESME-045 — Migration state reconciliation and data authority.** REFINED: reconciliation concerns meaning and authority, not merely successful copying. **Present disposition:** `ASSUMPTION_SENSITIVE`. [ESME-S031; ESME-S038; ESME-S053]

**ESME-046 — Schema mappings and information-loss analysis.** NARROWED to explicit mapping obligations and supported operators, not universal automatic schema migration. **Present disposition:** `ASSUMPTION_SENSITIVE`. [ESME-S038; ESME-S053]

**ESME-047 — Retire migration scaffolding and duplicate operation.** REFINED: retirement follows disappearing obligations, not architectural tidiness. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S031; ESME-S035; ESME-S036; ESME-S037]

**ESME-048 — Technical novelty or age decides replacement.** REJECTED as a decision rule; specific age-associated constraints remain inputs to ESME-042. **Present disposition:** `REJECTED_OR_DISFAVOURED`. [ESME-S031; ESME-S039; ESME-S040; ESME-S050]

**ESME-049 — Bounded technical-debt identification.** REFINED through later scholarly definitions and the 2025 reframing agenda; no claim of uniform academic agreement or validated interest rates. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S019; ESME-S032; ESME-S042; ESME-S048; ESME-S049]

**ESME-050 — Contingent lifecycle economics.** REFINED: scenario-sensitive lifecycle economics replaces a literal universal principal/interest formula. **Present disposition:** `ASSUMPTION_SENSITIVE`. [ESME-S019; ESME-S032; ESME-S048; ESME-S049]

**ESME-051 — Debt prioritisation across affected stakeholders.** REFINED: prioritisation remains an accountable decision, not a universal debt ranking algorithm. **Present disposition:** `CONTEXT_DEPENDENT`. [ESME-S032; ESME-S043; ESME-S048; ESME-S049]

**ESME-052 — Bounded remediation with payoff reassessment.** REFINED: bounded experiments and explicit horizon replace monotonically increasing remediation machinery. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S019; ESME-S020; ESME-S022; ESME-S032; ESME-S048; ESME-S049]

**ESME-053 — Maintainability measures as validated proxies.** NARROWED to validated, revisable proxies; no universal maintainability threshold retained. **Present disposition:** `USEFUL_BUT_EASILY_GAMED`. [ESME-S022; ESME-S032; ESME-S048; ESME-S060]

**ESME-054 — Mandatory comprehensive cleanup or zero debt.** REJECTED; ESME-049 through ESME-052 preserve bounded identification, economics and revision. **Present disposition:** `REJECTED_OR_DISFAVOURED`. [ESME-S019; ESME-S032; ESME-S040; ESME-S048; ESME-S049]

**ESME-055 — Maintainership capacity and continuity.** REFINED: continuity is a social and economic capability, not just documentation or an owner field. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S040; ESME-S043; ESME-S047]

**ESME-056 — Handoff and onboarding through demonstrated capability.** REFINED: demonstrated bounded capability replaces document delivery as the sole handoff criterion. **Present disposition:** `CONTEXT_DEPENDENT`. [ESME-S014; ESME-S015; ESME-S043; ESME-S047]

**ESME-057 — Deprecation communication with actionable transition.** REFINED: preserve actionable transition and exceptions without importing Python’s specific policy duration as a general standard. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S043; ESME-S045]

**ESME-058 — Dependency viability and response alternatives.** REFINED: treat ecosystem continuity as a set of contextual response options. **Present disposition:** `CONTEXT_DEPENDENT`. [ESME-S040; ESME-S041; ESME-S043]

**ESME-059 — Archival identity without a false execution guarantee.** NARROWED: historical custody and runtime continuity are separate obligations. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S030; ESME-S046; ESME-S054]

**ESME-060 — Responsible service retirement and residual obligations.** REFINED analytical composition of source-supported disposal, transition and archival distinctions; not a legal compliance checklist. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S001; ESME-S002; ESME-S040; ESME-S043; ESME-S045; ESME-S054]

**ESME-061 — Generated repairs remain candidate interventions.** REFINED: preserve the candidate/acceptance boundary while permitting evidence-backed bounded automation. **Present disposition:** `STRONGLY_RETAINED`. [ESME-S024; ESME-S026; ESME-S027; ESME-S052; ESME-S055; ESME-S065; ESME-S067]

**ESME-062 — Benchmark and evaluation provenance.** REFINED: evaluation provenance and claim scope are integral to the result, not a confidence percentage. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S024; ESME-S026; ESME-S027; ESME-S057; ESME-S067]

**ESME-063 — End-to-end automation cost and outcome assessment.** REFINED: neither blanket enthusiasm nor blanket rejection survives; select by task, patch quality and complete costs. **Present disposition:** `CONTEXT_DEPENDENT`. [ESME-S025; ESME-S033; ESME-S034; ESME-S052; ESME-S057]

**ESME-064 — Acceptance authority distinct from generation capability.** REFINED: preserve distinct powers and evidence while allowing one person or a bounded automation to perform several functions. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S002; ESME-S024; ESME-S052; ESME-S055; ESME-S067]

**ESME-065 — Learned-system data and feedback evolution.** DOMAIN_SPECIFIC documented import, with explicit statistical and environmental limits. **Present disposition:** `DOMAIN_SPECIFIC`. [ESME-S042; ESME-S051; ESME-S057]

**ESME-066 — Executable-policy and non-code artefact evolution.** GENERALISED within software artefacts, with a stronger distinction between stored rule, operative use and achieved outcome. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S002; ESME-S030; ESME-S042; ESME-S056]

**ESME-067 — Bounded revision of maintenance methods.** REFINED analytical mechanism: revision can narrow or remove machinery as well as expand it. **Present disposition:** `CONTEXT_DEPENDENT`. [ESME-S006; ESME-S025; ESME-S029; ESME-S033; ESME-S049; ESME-S058; ESME-S063]

**ESME-068 — Human-only maintenance is universally superior.** REJECTED in favour of ESME-061 through ESME-064 and conditional configurations. **Present disposition:** `REJECTED_OR_DISFAVOURED`. [ESME-S025; ESME-S033; ESME-S034; ESME-S052; ESME-S055; ESME-S067]

**ESME-069 — Reliable unattended repository-scale maintenance as a general capability.** STILL_CONTESTED/UNRESOLVED: researched uncertainty at the cut-off, not unexamined work and not a claim that future success is impossible. **Present disposition:** `UNRESOLVED`. [ESME-S024; ESME-S025; ESME-S026; ESME-S027; ESME-S033; ESME-S052; ESME-S055; ESME-S057; ESME-S065; ESME-S067]

**ESME-070 — Golden-master preservation as a separate mechanism.** SUPERSEDED for independent counting by the exact linked candidate, without deleting its record. **Present disposition:** `DUPLICATE_CANDIDATE`. [ESME-S051; ESME-S059]

**ESME-071 — A formal change board for every change.** NARROWED to ESME-001’s underlying property with context-triggered coordination. **Present disposition:** `CEREMONY_NOT_GENERAL_PROPERTY`. [ESME-S002; ESME-S005; ESME-S007; ESME-S039]

**ESME-072 — Evidence-to-action binding and invalidation.** GENERALISED analytical relation induced by coupling source-supported mechanisms; richer records only when identity or communication can otherwise be lost. **Present disposition:** `RETAINED_IN_EVOLVED_FORM`. [ESME-S002; ESME-S016; ESME-S018; ESME-S024; ESME-S038; ESME-S051; ESME-S052; ESME-S055]

**ESME-073 — Continuity of obligations across temporary joint states.** REFINED analytical constraint: composition may create new obligations but does not prescribe universal dual operation or full formal verification. **Present disposition:** `ASSUMPTION_SENSITIVE`. [ESME-S031; ESME-S038; ESME-S044; ESME-S045; ESME-S053]

**ESME-074 — Feedback-driven proportionality and retirement of maintenance controls.** REFINED analytical feedback rule, not a proven global optimiser or demand for monotonically simpler structure. **Present disposition:** `CONTEXT_DEPENDENT`. [ESME-S008; ESME-S022; ESME-S031; ESME-S032; ESME-S040; ESME-S048; ESME-S049; ESME-S058]


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_INTERNAL_TENSIONS

Alternatives are selected by discriminating conditions, not by a universal command to combine them. A hybrid can preserve both benefits, create a new obligation, or incur the costs of both with neither benefit.

### ESME-T001 — Continuity versus necessary behavioural change

**Affected candidates.** `ESME-001`, `ESME-023`, `ESME-026`, `ESME-030`, `ESME-038`

**Protected value A.** Preserve relied-on behaviour and downstream trust.

**Cost A.** Preservation retains defects or obsolete constraints and can burden migration.

**Context favouring A.** Supported current consumers rely on the behaviour.

**Protected value B.** Correct defects and obsolete requirements.

**Cost B.** Behavioural change can break legitimate dependencies and trust.

**Context favouring B.** Current legitimate intent requires a different outcome.

**Decision discriminator.** Preserve behaviour with a current supported consumer; change it when legitimate intent is revised and transition consequences are addressed. A failing characterisation test is a question, not automatic veto.

**Supported hybrid.** Separate preservation and changed obligations within one patch when needed.

**Hybrid failure.** A compatibility layer can retain the defect indefinitely while the new path creates incompatible semantics.

**Uncertainty.** Unknown consumers can prevent confident removal.

[ESME-S045; ESME-S051; ESME-S059] SOURCE_GROUNDED_ANALYTICAL_ADJUDICATION

### ESME-T002 — Familiarity versus simplification

**Affected candidates.** `ESME-008`, `ESME-009`, `ESME-011`, `ESME-027`, `ESME-053`

**Protected value A.** Known structure reduces learning and operational uncertainty.

**Cost A.** Familiar structure can retain expensive recurrent work.

**Context favouring A.** Stable use, short remaining life or weak evidence of recurrent difficulty.

**Protected value B.** Better task structure may reduce recurring burden.

**Cost B.** Simplification incurs relearning, review and regression risk.

**Context favouring B.** Credible repeated future tasks benefit enough to offset transition.

**Decision discriminator.** Prefer restructuring when a plausible recurrent task benefit exceeds relearning, review and regression cost; prefer familiarity when the system is stable or retiring.

**Supported hybrid.** Small seam extraction with local learning and task evaluation.

**Hybrid failure.** Partial abstraction adds indirection without retiring old concepts, making both models necessary.

**Uncertainty.** Long-term benefit is confounded by concurrent work.

[ESME-S020; ESME-S021; ESME-S022; ESME-S047] SOURCE_GROUNDED_ANALYTICAL_ADJUDICATION

### ESME-T003 — Local repair versus replacement

**Affected candidates.** `ESME-005`, `ESME-042`, `ESME-043`, `ESME-044`, `ESME-048`

**Protected value A.** Retain embedded domain knowledge and avoid transition risk.

**Cost A.** Repair can perpetuate an unserviceable foundation.

**Context favouring A.** Bounded unmet need and viable support for the existing foundation.

**Protected value B.** Remove constraints that bounded repair cannot economically address.

**Cost B.** Replacement incurs knowledge recovery, conversion and transition risk.

**Context favouring B.** Core obligations cannot be met economically by bounded maintenance.

**Decision discriminator.** Choose by unmet obligations, support feasibility and lifecycle cost including transition; age alone has no deciding role.

**Supported hybrid.** Incremental displacement at a real functional/data boundary.

**Hybrid failure.** A wrapper freezes obsolete constraints while adding a second maintenance burden.

**Uncertainty.** Few unbiased controlled whole-migration comparisons exist.

[ESME-S031; ESME-S037; ESME-S039; ESME-S040] SOURCE_GROUNDED_ANALYTICAL_ADJUDICATION

### ESME-T004 — Automated transformation versus review burden

**Affected candidates.** `ESME-024`, `ESME-025`, `ESME-061`, `ESME-063`, `ESME-064`, `ESME-068`

**Protected value A.** Generate useful candidates and reduce repetitive work.

**Cost A.** Manual inspection has attention and latency costs.

**Context favouring A.** Weak oracles, open-ended intent or unsupported task transfer.

**Protected value B.** Avoid deceptive patches, hidden validation work and unauthorised action.

**Cost B.** Generation and review can increase total work and confidence in wrong patches.

**Context favouring B.** A supported bounded transformation with useful independent checks.

**Decision discriminator.** Evaluate correct outcomes and full cost for the task and tool version. Strong narrow transformations can need less manual review; weak oracles demand more independent evidence.

**Supported hybrid.** Bounded generator plus targeted independent checks and authorised acceptance.

**Hybrid failure.** Reviewer time rises while approval becomes perfunctory, producing neither speed nor reliable correction.

**Uncertainty.** Current population-wide effect remains uncertain.

[ESME-S025; ESME-S033; ESME-S052; ESME-S055; ESME-S067] SOURCE_GROUNDED_ANALYTICAL_ADJUDICATION

### ESME-T005 — Test preservation versus correction of obsolete behaviour

**Affected candidates.** `ESME-029`, `ESME-030`, `ESME-031`, `ESME-032`

**Protected value A.** Existing outputs provide evidence about undocumented use.

**Cost A.** Preserving snapshots can institutionalise a defect.

**Context favouring A.** The observed result has a current justified consumer or contract.

**Protected value B.** New intent can legitimately invalidate old outputs.

**Cost B.** Revising expectations can erase evidence of a relied-on behaviour.

**Context favouring B.** Independent intent or evidence establishes the old result should change.

**Decision discriminator.** Adjudicate the supported observer and oracle provenance. Gold-patch identity alone cannot settle correctness.

**Supported hybrid.** Keep unaffected characterisation while replacing explicitly obsolete assertions with independently justified expectations.

**Hybrid failure.** Updating all golden files automatically makes the patch its own oracle.

**Uncertainty.** Historical intent may be unrecoverable.

[ESME-S024; ESME-S051; ESME-S059; ESME-S064; ESME-S067] SOURCE_GROUNDED_ANALYTICAL_ADJUDICATION

### ESME-T006 — Debt reduction versus current value

**Affected candidates.** `ESME-049`, `ESME-050`, `ESME-051`, `ESME-052`, `ESME-054`

**Protected value A.** Avoid recurring maintenance burden and future loss of options.

**Cost A.** Immediate value work may leave compounding future burdens.

**Context favouring A.** Urgent obligations, short horizon or uncertain interest.

**Protected value B.** Deliver urgent user value and conserve finite capacity.

**Cost B.** Debt work can defer urgent user value and never reach payback.

**Context favouring B.** A plausible repeated burden has a supported horizon and affected consumer.

**Decision discriminator.** Prioritise expected consequential burden within a plausible horizon; stop when retirement or changed demand removes prospective benefit.

**Supported hybrid.** Bounded remediation alongside a necessary change when coupling is genuine.

**Hybrid failure.** Opportunistic cleanup enlarges a critical fix until both value and debt work are delayed.

**Uncertainty.** Future change frequency and shifted costs are uncertain.

[ESME-S019; ESME-S032; ESME-S048; ESME-S049] SOURCE_GROUNDED_ANALYTICAL_ADJUDICATION

### ESME-T007 — Coexistence versus quiescent cutover

**Affected candidates.** `ESME-039`, `ESME-043`, `ESME-044`, `ESME-045`, `ESME-046`, `ESME-073`

**Protected value A.** Avoid a concentrated outage and obtain incremental learning.

**Cost A.** Coexistence creates gateways, data authority and dual-support costs.

**Context favouring A.** Useful partition, tolerable reconciliation and costly interruption.

**Protected value B.** Avoid dual-state, gateway and mixed-version complexity.

**Cost B.** Quiescence concentrates interruption and cutover risk.

**Context favouring B.** An accepted stable write boundary and expensive or infeasible coexistence.

**Decision discriminator.** Use coexistence only when partition and reconciliation costs are tolerable; use quiescence when an accepted stable boundary is credible.

**Supported hybrid.** Read-only or bounded-phase coexistence with explicit data authority.

**Hybrid failure.** Dual writes without authority create divergence while neither system can be retired.

**Uncertainty.** External concurrent writers can defeat the planned boundary.

[ESME-S031; ESME-S038; ESME-S053] SOURCE_GROUNDED_ANALYTICAL_ADJUDICATION

### ESME-T008 — Impact completeness versus investigation cost

**Affected candidates.** `ESME-017`, `ESME-018`, `ESME-019`, `ESME-021`, `ESME-034`

**Protected value A.** Find consequential downstream effects.

**Cost A.** Broad analysis consumes time and produces false positives.

**Context favouring A.** Uncertain edges or high missed-effect consequence.

**Protected value B.** Avoid false-positive work and whole-system paralysis.

**Cost B.** Local inquiry can miss a high-consequence dependency.

**Context favouring B.** A supported small boundary and affordable counterexample challenge.

**Decision discriminator.** Scale challenge effort to plausible missed-edge consequence and evidence quality; accept demonstrably local changes locally.

**Supported hybrid.** Typed impact hypothesis with selective independent challenges.

**Hybrid failure.** Combining several correlated tools produces a huge impact set without improving recall of real hidden effects.

**Uncertainty.** Rare unknown dependencies remain difficult to price.

[ESME-S013; ESME-S016; ESME-S017; ESME-S044] SOURCE_GROUNDED_ANALYTICAL_ADJUDICATION

### ESME-T009 — Early feedback versus evidence breadth

**Affected candidates.** `ESME-034`, `ESME-035`, `ESME-037`, `ESME-040`

**Protected value A.** Expose actionable failures before expensive commitment.

**Cost A.** Broader evidence delays feedback and consumes execution resources.

**Context favouring A.** Critical consequences require broad checks before action.

**Protected value B.** Avoid skipping rare but important checks.

**Cost B.** Selection and priority can miss or delay consequential failures.

**Context favouring B.** Ordering changes a useful action and selection assumptions hold.

**Decision discriminator.** A release decision may wait for critical checks even when routine feedback is prioritised. Small suites favour retest-all.

**Supported hybrid.** Run quick discriminating checks early and retain explicit pending obligations.

**Hybrid failure.** Skipped work is labelled passed, so latency improvement is purchased with false assurance.

**Uncertainty.** Rare delayed failures can dominate otherwise favourable averages.

[ESME-S023; ESME-S058; ESME-S066] SOURCE_GROUNDED_ANALYTICAL_ADJUDICATION

### ESME-T010 — Continuity versus responsible ending

**Affected candidates.** `ESME-055`, `ESME-056`, `ESME-058`, `ESME-059`, `ESME-060`

**Protected value A.** Support users and preserve knowledge.

**Cost A.** Continued support consumes scarce labour and may prolong obsolete risk.

**Context favouring A.** Current obligations and willing capable support remain.

**Protected value B.** End unsustainable labour and unnecessary live operation.

**Cost B.** Ending service can impose transition costs and remove useful access.

**Context favouring B.** Continued operation lacks justified value or feasible support and obligations can be resolved.

**Decision discriminator.** Retain service only for justified obligations with feasible capacity; archives can meet historical needs without a running service.

**Supported hybrid.** Time-bounded transition and retained source/history with clear limits.

**Hybrid failure.** A nominal handoff names an unwilling owner while the old team still supplies unpaid support.

**Uncertainty.** Unknown consumers and unfunded obligations resist tidy closure.

[ESME-S040; ESME-S043; ESME-S045; ESME-S047; ESME-S054] SOURCE_GROUNDED_ANALYTICAL_ADJUDICATION

### ESME-T011 — Learning versus stable acceptance rules

**Affected candidates.** `ESME-067`, `ESME-072`, `ESME-074`

**Protected value A.** Revise failing or overly costly maintenance methods.

**Cost A.** Stable rules may preserve a failing or unnecessarily costly method.

**Context favouring A.** The existing method is effective with no consequential new evidence.

**Protected value B.** Prevent a successor from validating itself by weakening obligations.

**Cost B.** Frequent revision destabilises acceptance and adds meta-work.

**Context favouring B.** Observed failure, changed constraints or demonstrated avoidable cost.

**Decision discriminator.** Changes to method need external authority and evidence tied to a real failure or cost; unchanged methods and control removal remain options.

**Supported hybrid.** Bounded trial evaluated against predecessor obligations or separately authorised new intent.

**Hybrid failure.** A meta-process consumes more attention than it saves and endlessly revises its own success measures.

**Uncertainty.** The integrated revision mechanism has not been empirically validated as a system.

[ESME-S006; ESME-S031; ESME-S048; ESME-S049; ESME-S051; ESME-S058] SOURCE_GROUNDED_ANALYTICAL_ADJUDICATION


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_COMPOSED_SYSTEM

### Purpose, environment, state and agency

**name.** EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_COMPOSED_SYSTEM

**purpose.** Keep existing software useful and intelligible under legitimate changing obligations while preserving what should survive, revising what should not, and permitting non-change or retirement.

**environment.** Open organisational and dependency environments; actors have limited knowledge, resources and authority.

**state.** Versioned artefacts and persistent effects; accepted change/preservation obligations; evidence and assumptions; consumer/support relations; transition authority and lifecycle costs.

**behaviour.** Conditional network with concurrent inquiry and implementation, feedback, rollout interrupts and rival migration paths; no forced serial pipeline.

**epistemic_authority_effect_separation.** A distinction supplies information; an authorised capable actor can act; an observation of the resulting real system establishes a consequence. None entails the next automatically.

**status.** ANALYTICAL_SYNTHESIS, not an established named academic school or empirically validated total methodology.

The system has ten conceptual nodes. These group functions; they are not ten mandated departments, services or owners. A single action can serve several properties, and one person can occupy several roles. Conversely, separate people are necessary when actual authority, expertise or external interests are separate.

**ESME-N01 — Objectives and obligations.** Decision criterion and authority interface. Properties: `ESME-001`, `ESME-002`, `ESME-005`, `ESME-023`, `ESME-026`. ANALYTICAL_GROUPING_OF_SOURCED_PROPERTIES.

**ESME-N02 — Identified artefacts and state.** Objects: source, configuration, build inputs, data/schema, learned models, policy and history. Properties: `ESME-003`, `ESME-004`, `ESME-036`, `ESME-059`. ANALYTICAL_GROUPING_OF_SOURCED_PROPERTIES.

**ESME-N03 — Understanding and impact.** Inquiry, evidence and communication. Properties: `ESME-011`, `ESME-012`, `ESME-013`, `ESME-014`, `ESME-015`, `ESME-017`, `ESME-018`, `ESME-019`, `ESME-020`, `ESME-021`, `ESME-022`. ANALYTICAL_GROUPING_OF_SOURCED_PROPERTIES.

**ESME-N04 — Intervention alternatives.** Actions or candidate-generation methods, not independent authority. Properties: `ESME-008`, `ESME-024`, `ESME-027`, `ESME-042`, `ESME-043`, `ESME-044`, `ESME-049`, `ESME-052`, `ESME-058`, `ESME-061`. ANALYTICAL_GROUPING_OF_SOURCED_PROPERTIES.

**ESME-N05 — Validation and acceptance.** Partial evidence and authorised decision. Properties: `ESME-025`, `ESME-029`, `ESME-030`, `ESME-031`, `ESME-032`, `ESME-033`, `ESME-034`, `ESME-035`, `ESME-037`, `ESME-064`. ANALYTICAL_GROUPING_OF_SOURCED_PROPERTIES.

**ESME-N06 — Release and transition.** Changes to actual deployed relations and persistent state. Properties: `ESME-038`, `ESME-039`, `ESME-040`, `ESME-041`, `ESME-045`, `ESME-046`, `ESME-047`, `ESME-057`, `ESME-060`. ANALYTICAL_GROUPING_OF_SOURCED_PROPERTIES.

**ESME-N07 — People and consumers.** Capacity, knowledge, participation and external obligations. Properties: `ESME-009`, `ESME-055`, `ESME-056`. ANALYTICAL_GROUPING_OF_SOURCED_PROPERTIES.

**ESME-N08 — Outcomes and economics.** Observations and contingent prioritisation. Properties: `ESME-006`, `ESME-007`, `ESME-050`, `ESME-051`, `ESME-053`, `ESME-062`, `ESME-063`. ANALYTICAL_GROUPING_OF_SOURCED_PROPERTIES.

**ESME-N09 — Specialised artefact evolution.** Domain-specific data/feedback and non-code semantics. Properties: `ESME-065`, `ESME-066`. ANALYTICAL_GROUPING_OF_SOURCED_PROPERTIES.

**ESME-N10 — Cross-mechanism coherence.** Analytical constructs for evidence binding, joint-state continuity and proportionate revision. Properties: `ESME-067`, `ESME-072`, `ESME-073`, `ESME-074`. ANALYTICAL_GROUPING_OF_SOURCED_PROPERTIES.

### Communication, operative change and feedback

An originator communicates intended differences and constraints; a maintainer communicates feasibility, uncertainty and affected consumers; validators supply evidence with an identified scope; authorised actors choose and carry out an intervention; operators and users expose its consequences. These are different powers. A diagnosis cannot by itself modify an upstream dependency, a deprecation notice cannot force downstream migration, and a proof about source transformation cannot restore lost data.

The principal loops are inquiry–impact–revised inquiry; intent–acceptance evidence–revised intent; implementation–validation–repair; release observation–interruption–recovery or forward repair; and lifecycle outcome–reprioritisation–maintenance, non-change or retirement. Inquiry and implementation may proceed concurrently, but evidence becomes stale when relevant inputs change. Independent changes may require combined-state validation even when each individually passed. Self-revision is bounded by actual authority and still-binding obligations; no automatic self-authorisation, convergence guarantee or autonomous global optimiser is asserted.

### Three composition-induced properties

**ESME-072 — Evidence-to-action binding and invalidation.** Bind evidence and acceptance to the relevant candidate, intent and assumptions; invalidate or re-evaluate affected evidence when a consequential input changes, and deliver it to an actor able to act. New cost/failure: This relation is a reasoned synthesis, not an empirically validated universal protocol; excessive invalidation can cause rechecking cascades and delay. [ESME-S002; ESME-S016; ESME-S018; ESME-S024; ESME-S038; ESME-S051; ESME-S052; ESME-S055]

**ESME-073 — Continuity of obligations across temporary joint states.** Identify reachable joint states, authoritative data and permitted version/change combinations; constrain operation or add evidence for the newly created interactions. New cost/failure: State-space growth and unknown consumers can make exhaustive validation infeasible; constraints or a different migration strategy may dominate more testing. [ESME-S031; ESME-S038; ESME-S044; ESME-S045; ESME-S053]

**ESME-074 — Feedback-driven proportionality and retirement of maintenance controls.** Evaluate the combined decision benefit, interaction cost and residual risk of controls; consolidate, simplify or retire them when a cheaper adequate configuration dominates. New cost/failure: Underestimating rare-event value can lead to premature control removal; some fixed coordination costs are necessary even when incidents are infrequent. [ESME-S008; ESME-S022; ESME-S031; ESME-S032; ESME-S040; ESME-S048; ESME-S049; ESME-S058]

These three obligations are not merely aliases for input techniques. A test and a change request can each be locally valid yet refer to different candidates (ESME-072). Two individually acceptable versions can create an unacceptable mixed state (ESME-073). Two locally useful controls can interact to produce delay or duplicate burden beyond their combined benefit (ESME-074). These are analytical counterexample arguments; they do not establish a measured general effectiveness of this composition.

### Guarded relation model

The 62 relations below carry explicit guards, shared and incompatible assumptions, mechanism, new cost, source basis and an unresolved applicability obligation. A relation is not an unconditional implementation order. `REQUIRES` denotes an epistemic or operative dependency within its guard; `PROVIDES_EVIDENCE_FOR` does not entail truth; `ENABLES` does not confer authority; and `ALTERNATIVE_TO` does not require simultaneous deployment.

**ESME-R001: `ESME-001` → `ESME-002` — `ENABLES`.**

**Guard.** A change purpose affects planning or acceptance.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Authorised intent makes classification meaningful; the label does not create intent.

**New failure or cost.** Extra coding work and disagreement over mixed purposes.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S002; ESME-S005; ESME-S007] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R002: `ESME-003` → `ESME-011`, `ESME-017`, `ESME-025`, `ESME-036` — `ENABLES`.**

**Guard.** Investigation or validation must refer to a particular state.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Recoverable identity permits comparison and prevents mixing evidence from unrelated versions.

**New failure or cost.** Capturing mutable external inputs can be costly.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S002; ESME-S030; ESME-S046; ESME-S051] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R003: `ESME-004` → `ESME-055`, `ESME-056` — `REQUIRES`.**

**Guard.** Responsibility is being transferred.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Maintenance readiness depends on an actual capable receiving maintainer, not just supplied files.

**New failure or cost.** Handoff work competes with current delivery; nominal ownership can conceal missing capacity.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S002; ESME-S003; ESME-S047; ESME-S043] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R004: `ESME-005` → `ESME-042`, `ESME-060` — `ALTERNATIVE_TO`.**

**Guard.** Current obligations are met without intervention, or retirement is being compared.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Non-change competes with migration and retirement on actual value, risk and capacity.

**New failure or cost.** Neglected hidden obligations can be mistaken for stability.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S031; ESME-S040; ESME-S043] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R005: `ESME-006` → `ESME-001`, `ESME-008`, `ESME-050`, `ESME-051` — `FEEDBACK_TO`.**

**Guard.** Observed utility, demand or burden contradicts current expectations.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Outcome evidence reopens priorities and the proposed objective or structural investment.

**New failure or cost.** Confounding or gamed measures can redirect effort badly.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S008; ESME-S010; ESME-S032; ESME-S060; ESME-S061] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R006: `ESME-007` → `ESME-006`, `ESME-008` — `CONSTRAINS`.**

**Guard.** An evolution regularity is used in planning.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Population and metric limits prevent feedback trends from becoming universal mandates.

**New failure or cost.** Scope disputes may leave a forecast unresolved.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S008; ESME-S009; ESME-S029; ESME-S060; ESME-S061] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R007: `ESME-007`, `ESME-005` → `ESME-010` — `SUPERSEDES`.**

**Guard.** A universal growth/decay rule is proposed.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Scoped hypotheses and legitimate non-change replace the rejected mandate.

**New failure or cost.** No universal forecast remains available.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S008; ESME-S029; ESME-S060; ESME-S061] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R008: `ESME-009` → `ESME-011`, `ESME-025`, `ESME-055` — `CONSTRAINS`.**

**Guard.** Review/comprehension demands exceed demonstrated capacity.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Capacity can narrow or defer change and trigger learning or support.

**New failure or cost.** Deferred work and coordination have real opportunity cost.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S014; ESME-S015; ESME-S043; ESME-S047] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R009: `ESME-011` → `ESME-016` — `SUPERSEDES`.**

**Guard.** Exhaustive understanding is demanded without a bounded consumer.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Question-driven inquiry with escalation replaces the impossible universal prerequisite.

**New failure or cost.** A wrongly bounded question can still miss consequences.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S013; ESME-S014; ESME-S015] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R010: `ESME-012`, `ESME-013`, `ESME-015` → `ESME-011` — `PROVIDES_EVIDENCE_FOR`.**

**Guard.** The technique can answer a consequential comprehension question.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Static/dynamic analysis, slices and recovered rationale support different parts of a provisional explanation.

**New failure or cost.** Correlated blind spots can create false agreement.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S012; ESME-S013; ESME-S014; ESME-S015] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R011: `ESME-014` → `ESME-011`, `ESME-025` — `CONSTRAINS`.**

**Guard.** Analysis output and transformation output are described together.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** The recovery/transformation distinction prevents a model from being mistaken for a modified or validated system.

**New failure or cost.** Extra conceptual distinctions can become terminology policing if no decision uses them.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S012] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R012: `ESME-011` → `ESME-017` — `ENABLES`.**

**Guard.** Impact depends on meaning beyond textual references.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Task-bounded understanding guides which dependency evidence and observers matter.

**New failure or cost.** An incorrect explanation can bias impact search.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S015; ESME-S016] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R013: `ESME-017` → `ESME-018`, `ESME-020`, `ESME-021` — `ACTS_THROUGH`.**

**Guard.** Propagation may cross the direct edit boundary.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Typed dependencies, consumer discovery and counterexample searches make the impact boundary operative.

**New failure or cost.** Broader scope increases false positives and consultation cost.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S016; ESME-S017; ESME-S041; ESME-S044] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R014: `ESME-019` → `ESME-017`, `ESME-018` — `PROVIDES_EVIDENCE_FOR`.**

**Guard.** Representative change history exists.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Co-change suggests candidate relations that require interpretation, not automatic companion edits.

**New failure or cost.** Bulk commits and new architecture can make recommendations stale.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S017] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R015: `ESME-020` → `ESME-038`, `ESME-057`, `ESME-058` — `COMMUNICATES_TO`.**

**Guard.** Independent downstream consumers may need to respond.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Impact findings become actionable compatibility, deprecation or dependency-response information.

**New failure or cost.** Communication can fail to reach unknown or under-resourced consumers.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S041; ESME-S043; ESME-S045] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R016: `ESME-021` → `ESME-011`, `ESME-017`, `ESME-029` — `FEEDBACK_TO`.**

**Guard.** A check finds an effect outside the current explanation or boundary.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** A counterexample reopens understanding, scope and possibly the oracle.

**New failure or cost.** Repeated rework can be expensive; not every unexpected observation is a relevant obligation.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S016; ESME-S044; ESME-S051] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R017: `ESME-022` → `ESME-025`, `ESME-073` — `PROVIDES_EVIDENCE_FOR`.**

**Guard.** Concurrent changes can semantically interact.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Interference analysis directs validation of the merged artefact and newly reachable joint states.

**New failure or cost.** Higher recall can create false-positive review work.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S044] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R018: `ESME-023` → `ESME-024`, `ESME-025`, `ESME-026`, `ESME-038` — `CONSTRAINS`.**

**Guard.** A change claims preservation or compatibility.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Declared observers and environments bound preconditions, actual validation and legitimate intentional differences.

**New failure or cost.** An overly broad observer makes useful change impossible; an overly narrow one misses contracts.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S018; ESME-S045; ESME-S051] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R019: `ESME-025` → `ESME-003`, `ESME-023`, `ESME-024`, `ESME-029` — `REQUIRES`.**

**Guard.** Preservation or correctness of a transformed artefact is asserted.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** The actual candidate needs applicable rules, credible obligations and identity-bound evidence.

**New failure or cost.** Independent validation and revalidation consume time.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S018; ESME-S020; ESME-S051] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R020: `ESME-026` → `ESME-001`, `ESME-029`, `ESME-030` — `REQUIRES`.**

**Guard.** An intentional difference conflicts with existing outputs or tests.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Authorised intent and oracle provenance distinguish correction from regression.

**New failure or cost.** Unrecoverable intent can block a confident decision.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S002; ESME-S051; ESME-S059] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R021: `ESME-027` → `ESME-028` — `SUPERSEDES`.**

**Guard.** Clean structure alone is asserted to guarantee benefit.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Task-specific benefit and cost replace the rejected aesthetic guarantee.

**New failure or cost.** Future benefits can remain uncertain despite improved structure.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S020; ESME-S021; ESME-S022] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R022: `ESME-027` → `ESME-008`, `ESME-050`, `ESME-052`, `ESME-053` — `ACTS_THROUGH`.**

**Guard.** Restructuring is justified by future maintenance value.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Costed burdens, bounded investment and validated proxies connect the structural intervention to a possible payoff.

**New failure or cost.** Measurement and opportunity costs can erase the hypothesised gain.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S019; ESME-S022; ESME-S032; ESME-S048] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R023: `ESME-029` → `ESME-025`, `ESME-030`, `ESME-031`, `ESME-032`, `ESME-033`, `ESME-034`, `ESME-061` — `CONSTRAINS`.**

**Guard.** Tests or analyses are used as acceptance evidence.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Oracle provenance limits what their successful results can establish.

**New failure or cost.** Obtaining independent expectations can dominate testing cost.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S024; ESME-S051; ESME-S062; ESME-S063; ESME-S064; ESME-S065] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R024: `ESME-030` → `ESME-070` — `SUPERSEDES`.**

**Guard.** Golden-master preservation has the same trigger and mechanism as characterisation.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** One characterisation obligation resolves the duplicate label without deleting its candidate ID.

**New failure or cost.** Over-aggressive deduplication could hide a genuinely specified snapshot oracle.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S051; ESME-S059] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R025: `ESME-030`, `ESME-031`, `ESME-032`, `ESME-033` → `ESME-029`, `ESME-025` — `PROVIDES_EVIDENCE_FOR`.**

**Guard.** The chosen partial oracle applies to the actual question.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Characterisation, differential, metamorphic and mutation techniques supply complementary but bounded observations.

**New failure or cost.** More techniques can share misconceptions and increase review burden.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S051; ESME-S059; ESME-S062; ESME-S063; ESME-S064] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R026: `ESME-034` → `ESME-017`, `ESME-029` — `REQUIRES`.**

**Guard.** Test omission is justified through impact analysis.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Selection safety is bounded by dependency assumptions and the existing suite’s expectations.

**New failure or cost.** Analysis overhead can exceed retest-all cost.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S023; ESME-S051] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R027: `ESME-035` → `ESME-037`, `ESME-040` — `ENABLES`.**

**Guard.** Early evidence is useful before full execution completes.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Scheduling accelerates actionable observations while preserving explicit pending obligations.

**New failure or cost.** Rare tests may be delayed or starved; skipped is not passed.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S058; ESME-S066] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R028: `ESME-036` → `ESME-003`, `ESME-025` — `PROVIDES_EVIDENCE_FOR`.**

**Guard.** A built artefact is compared or released.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Build provenance connects the validated object to source and environment.

**New failure or cost.** Reproducibility can be expensive and does not establish correctness.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S046; ESME-S038] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R029: `ESME-037` → `ESME-025`, `ESME-006` — `ACTS_THROUGH`.**

**Guard.** Integrated changes need recurring evidence.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Checks of integrated states and responses to failures make feedback operational.

**New failure or cost.** Flaky or ignored checks can become ceremony.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S002; ESME-S058] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R030: `ESME-038` → `ESME-039`, `ESME-057` — `ENABLES`.**

**Guard.** Consumers upgrade independently or supported behaviour is withdrawn.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** A defined compatibility surface determines coexistence and transition obligations.

**New failure or cost.** Overpromising compatibility can trap the producer in unbounded support.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S045; ESME-S043] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R031: `ESME-039` → `ESME-040`, `ESME-043`, `ESME-073` — `CONSTRAINS`.**

**Guard.** Mixed versions can be exposed during staged change.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Only supported combinations may operate; others require sequencing, isolation or revised strategy.

**New failure or cost.** Combination growth and adapters impose temporary complexity.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S031; ESME-S045; ESME-S053] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R032: `ESME-040` → `ESME-041` — `REQUIRES`.**

**Guard.** A stage promises containment or recovery after adverse observation.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Limited exposure is useful only when observations support a feasible stop, recovery or forward-repair action.

**New failure or cost.** A small stage can still cause irreversible harm.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S037; ESME-S038] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R033: `ESME-041` → `ESME-045`, `ESME-046` — `REQUIRES`.**

**Guard.** Persistent data has been copied or transformed.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Recovery depends on data authority, mappings and information actually retained.

**New failure or cost.** Restore tests and reconciliation cost resources and may expose irreversibility.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S038; ESME-S053] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R034: `ESME-042` → `ESME-043`, `ESME-044`, `ESME-005`, `ESME-060` — `ACTS_THROUGH`.**

**Guard.** A lifecycle decision compares viable interventions.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Choose incremental migration, quiescent replacement, non-change or retirement under their guards.

**New failure or cost.** Option comparison can overfit optimistic estimates.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S031; ESME-S039; ESME-S040] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R035: `ESME-043` → `ESME-044` — `ALTERNATIVE_TO`.**

**Guard.** Migration can use coexistence or a quiescent boundary.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** Uncontrolled live writes are incompatible with an assumed quiescent cutover; unavoidable outage is incompatible with uninterrupted service requirements.

**Mechanism.** Partitionability and tolerance for interruption determine which burden is preferable.

**New failure or cost.** A compromise can retain dual-operation costs while still requiring a major outage.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S031; ESME-S053] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R036: `ESME-043` → `ESME-039`, `ESME-045`, `ESME-047` — `REQUIRES`.**

**Guard.** Incremental displacement creates temporary shared operation.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Compatibility, data reconciliation and exit conditions stop coexistence becoming uncontrolled duplication.

**New failure or cost.** Temporary gateways can become permanent.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S031; ESME-S035; ESME-S036; ESME-S053] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R037: `ESME-044` → `ESME-041`, `ESME-045`, `ESME-046` — `REQUIRES`.**

**Guard.** A cutover relies on a stable conversion boundary.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Quiescence and mapping/recovery evidence replace, rather than magically eliminate, transition obligations.

**New failure or cost.** Concentrated failures and late writes can defeat the planned window.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S031; ESME-S038; ESME-S053] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R038: `ESME-045`, `ESME-046` → `ESME-073` — `PROVIDES_EVIDENCE_FOR`.**

**Guard.** A migration introduces old/new state combinations.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Mappings and authority constraints explain which joint states preserve meaning.

**New failure or cost.** Model-state mismatch can invalidate the inference.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S031; ESME-S053] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R039: `ESME-047` → `ESME-074`, `ESME-060` — `ENABLES`.**

**Guard.** Transferred responsibilities no longer need duplicate operation.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Retiring scaffolding reduces maintenance burden and prepares responsible ending of old service.

**New failure or cost.** Premature retirement can remove a still-needed fallback or consumer path.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S031; ESME-S035; ESME-S036] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R040: `ESME-042` → `ESME-048` — `SUPERSEDES`.**

**Guard.** Technology age or novelty alone is offered as the selection rule.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Lifecycle comparison replaces the unsupported heuristic.

**New failure or cost.** Detailed comparison may still be uncertain.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S031; ESME-S039; ESME-S040] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R041: `ESME-049` → `ESME-050`, `ESME-051` — `ENABLES`.**

**Guard.** A decision claims avoidable future maintenance burden.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** A bounded debt item gives economics and negotiation a concrete causal subject.

**New failure or cost.** Misclassification can hide ordinary obligations or inflate a debt backlog.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S019; ESME-S048; ESME-S049] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R042: `ESME-050` → `ESME-051`, `ESME-052` — `CONSTRAINS`.**

**Guard.** Preventive investment competes with other work.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Horizon, recurrence, uncertainty and shifted costs constrain priority and continuation.

**New failure or cost.** False precision can disguise the assumptions driving an apparent optimum.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S032; ESME-S048; ESME-S049] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R043: `ESME-052` → `ESME-006`, `ESME-027`, `ESME-050` — `FEEDBACK_TO`.**

**Guard.** Observed remediation outcomes challenge the expected payoff.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Actual task outcomes revise the complexity, refactoring and cost hypotheses.

**New failure or cost.** Concurrent changes and delayed benefits complicate attribution.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S020; ESME-S022; ESME-S032] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R044: `ESME-053` → `ESME-050`, `ESME-052` — `PROVIDES_EVIDENCE_FOR`.**

**Guard.** A validated proxy relates to the relevant maintenance task.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Measurements can support—but not replace—cost and outcome evaluation.

**New failure or cost.** Gaming or aggregation changes can reverse interpretation.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S022; ESME-S032; ESME-S060] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R045: `ESME-049`, `ESME-050`, `ESME-052`, `ESME-005` → `ESME-054` — `SUPERSEDES`.**

**Guard.** Complete cleanup or zero debt is proposed as universal maturity.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Bounded burdens, contingent costs and non-change replace the unconditional target.

**New failure or cost.** Some genuinely urgent obligations can be wrongly deferred unless separately identified.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S019; ESME-S032; ESME-S040; ESME-S048; ESME-S049] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R046: `ESME-055`, `ESME-056` → `ESME-004`, `ESME-009`, `ESME-064` — `ENABLES`.**

**Guard.** A change or handoff needs competent authorised action.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Sustainable capacity and demonstrated learning make formal responsibilities executable.

**New failure or cost.** Training and coordination compete with immediate work.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S043; ESME-S047] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R047: `ESME-057` → `ESME-060` — `ENABLES`.**

**Guard.** A supported service or interface is being retired.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Actionable transition information helps transfer or terminate remaining obligations.

**New failure or cost.** Notice without a feasible consumer path can merely document abandonment.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S045; ESME-S043] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R048: `ESME-058` → `ESME-005`, `ESME-042`, `ESME-055` — `ALTERNATIVE_TO`.**

**Guard.** A dependency becomes unsupported.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Response choices include continued use, local support/fork or replacement; a separate owner per dependency is not required.

**New failure or cost.** Forking or vendoring transfers hidden maintenance cost downstream.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S040; ESME-S041; ESME-S043] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R049: `ESME-059` → `ESME-060` — `ENABLES`.**

**Guard.** Historical access remains needed after operation ends.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Archival custody permits knowledge preservation without keeping an obsolete live service.

**New failure or cost.** Archived source may not build; retention itself has access and confidentiality constraints.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S054; ESME-S046] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R050: `ESME-061` → `ESME-025`, `ESME-029`, `ESME-064` — `REQUIRES`.**

**Guard.** An automatically generated patch is proposed for acceptance.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Candidate generation is coupled to independent obligations, actual validation and legitimate acceptance.

**New failure or cost.** Review can be costly and deceptive suggestions can harm it.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S024; ESME-S052; ESME-S055; ESME-S065] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R051: `ESME-062` → `ESME-063`, `ESME-069` — `CONSTRAINS`.**

**Guard.** An automation capability or economic claim is made.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Task provenance, leakage and denominator limits bound transfer from scores to actual maintenance.

**New failure or cost.** High-quality evaluation can lag rapidly changing tools.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S024; ESME-S026; ESME-S027; ESME-S057; ESME-S067] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R052: `ESME-063` → `ESME-061`, `ESME-064`, `ESME-068` — `CONSTRAINS`.**

**Guard.** A tool choice or delegation is justified by productivity.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Complete task costs and patch quality determine whether bounded automation is preferable; no universal human-only conclusion follows.

**New failure or cost.** Outcome measurement can be expensive and selection-biased.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S025; ESME-S033; ESME-S034; ESME-S052; ESME-S055; ESME-S057] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R053: `ESME-065`, `ESME-066` → `ESME-003`, `ESME-018`, `ESME-023`, `ESME-029` — `REFINES`.**

**Guard.** Data, learned models or executable non-code artefacts determine behaviour.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** The relevant baseline, dependencies and oracles expand beyond conventional source edits.

**New failure or cost.** Statistical uncertainty, hidden feedback and unenforced artefacts complicate validation.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S042; ESME-S056] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R054: `ESME-067` → `ESME-001`, `ESME-064`, `ESME-072`, `ESME-074` — `REQUIRES`.**

**Guard.** The maintenance method or its delegated authority is revised.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Method change needs an authorised rationale and preserved obligations; its successor cannot simply redefine success.

**New failure or cost.** Meta-process growth and circular evaluation can consume the capacity being protected.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S006; ESME-S048; ESME-S049; ESME-S051; ESME-S058] ANALYTICAL_SYNTHESIS_FROM_DOCUMENTED_METHOD_REVISION

**ESME-R055: `ESME-001`, `ESME-003`, `ESME-017`, `ESME-025`, `ESME-029`, `ESME-064` → `ESME-072` — `ENABLES`.**

**Guard.** Evidence passes among actors/tools or concurrent work changes its subject.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** The pieces jointly create the need to bind evidence, assumptions and authority to the real action.

**New failure or cost.** Binding/invalidation adds coordination and rechecking cost.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S002; ESME-S016; ESME-S018; ESME-S024; ESME-S038; ESME-S051; ESME-S055] COMPOSITION_INDUCED_ANALYTICAL_RELATION

**ESME-R056: `ESME-072` → `ESME-006`, `ESME-025`, `ESME-037`, `ESME-040`, `ESME-061` — `CONSTRAINS`.**

**Guard.** A previously obtained result is used after relevant state or intent changes.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Affected evidence must be re-evaluated or explicitly qualified before it supports acceptance or exposure.

**New failure or cost.** Over-broad invalidation can cause unnecessary cascades.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S024; ESME-S038; ESME-S051; ESME-S058] COMPOSITION_INDUCED_ANALYTICAL_RELATION

**ESME-R057: `ESME-022`, `ESME-039`, `ESME-043`, `ESME-045`, `ESME-046` → `ESME-073` — `ENABLES`.**

**Guard.** Concurrent changes or transitional versions create joint states.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Endpoint correctness leaves new reachability and interference obligations at the join.

**New failure or cost.** State-space growth can make the chosen composition impractical.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S031; ESME-S044; ESME-S053] COMPOSITION_INDUCED_ANALYTICAL_RELATION

**ESME-R058: `ESME-073` → `ESME-025`, `ESME-039`, `ESME-040`, `ESME-044` — `CONSTRAINS`.**

**Guard.** A reachable mixed state affects a preserved obligation.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Validate or prohibit the combination, or choose another migration/integration configuration.

**New failure or cost.** More constraints may reduce availability or parallelism.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S031; ESME-S038; ESME-S044; ESME-S053] COMPOSITION_INDUCED_ANALYTICAL_RELATION

**ESME-R059: `ESME-006`, `ESME-047`, `ESME-050`, `ESME-052`, `ESME-055` → `ESME-074` — `ENABLES`.**

**Guard.** Several controls compete for finite maintenance capacity.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Outcome and lifecycle evidence makes combined cost and expiry observable.

**New failure or cost.** Rare-event benefits can be undervalued.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S008; ESME-S031; ESME-S032; ESME-S040; ESME-S048; ESME-S058] COMPOSITION_INDUCED_ANALYTICAL_RELATION

**ESME-R060: `ESME-074` → `ESME-011`, `ESME-021`, `ESME-034`, `ESME-035`, `ESME-037`, `ESME-043`, `ESME-056`, `ESME-067` — `FEEDBACK_TO`.**

**Guard.** The combined arrangement has excessive cost, no consumer or an expired obligation.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Simplify, substitute, consolidate or retire methods without silently waiving the protected outcome.

**New failure or cost.** Premature control removal can expose rare severe failures.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S023; ESME-S031; ESME-S048; ESME-S058] COMPOSITION_INDUCED_ANALYTICAL_RELATION

**ESME-R061: `ESME-001` → `ESME-071` — `SUPERSEDES`.**

**Guard.** A formal board is demanded for every change.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Adequate authority and coordination replace an unconditional meeting ritual.

**New failure or cost.** A genuinely required multi-party decision could be lost by over-simplification.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S002; ESME-S005] SOURCE_GROUNDED_ANALYTICAL_COMPOSITION

**ESME-R062: `ESME-013` → `ESME-017` — `SHARES_ANCESTRY_WITH`.**

**Guard.** A dependence-based impact technique is used.

**Shared assumptions.** The relevant candidate, objective and evidence scope are identifiable.

**Incompatible assumptions.** The target evidence must not silently substitute a different baseline, observer or authority.

**Mechanism.** Slicing and impact reasoning share dependence concepts without being identical mechanisms.

**New failure or cost.** Conflating the two can hide different criteria and effects.

**Unresolved obligation.** The later system must supply evidence that the guard and prerequisites actually hold.

[ESME-S013; ESME-S016] DOCUMENTED_CONCEPTUAL_RELATION

### Smallest coherent form and alternative configurations

#### ESME-CFG01 — Smallest coherent local maintenance

**Guard.** A bounded change, a competent authorised maintainer, understood consumers and no complex state transition.

**Operation.** One person may clarify intent, inspect the relevant diff, run an adequate check and release with a feasible recovery/forward-repair condition. A read-only/pure local change can make data-recovery machinery inapplicable.

**Omissions.** No mandatory taxonomy form, board, slicing tool, metric dashboard, mutation campaign or separate actor per function.

**Retirement.** Remove temporary probes and notes with no continuing consumer; retain actual obligations and identity evidence needed later.

**Limit.** Smallest is contextual, not a fixed ten-control implementation.

**Supporting candidates.** `ESME-001`, `ESME-003`, `ESME-011`, `ESME-017`, `ESME-023`, `ESME-025`, `ESME-026`, `ESME-029`, `ESME-041`, `ESME-072`

#### ESME-CFG02 — Continuous shared evolution

**Guard.** Concurrent changes and independent consumers make integration feedback consequential.

**Operation.** Concurrent development with identity-bound checks, impact communication and conditional staged exposure; failures can reopen intent or scope.

**Omissions.** Test selection/prioritisation are optional if retest-all is cheap. Staging is omitted when it cannot yield meaningful early evidence.

**Retirement.** Retire obsolete checks, compatibility paths and unused dependency records after their obligations end.

**Limit.** More tools or shorter cycles do not by themselves improve results.

**Supporting candidates.** `ESME-003`, `ESME-006`, `ESME-009`, `ESME-017`, `ESME-018`, `ESME-020`, `ESME-021`, `ESME-022`, `ESME-025`, `ESME-029`, `ESME-034`, `ESME-035`, `ESME-036`, `ESME-037`, `ESME-038`, `ESME-039`, `ESME-040`, `ESME-041`, `ESME-055`, `ESME-072`, `ESME-073`

#### ESME-CFG03 — Incremental displacement

**Guard.** Useful partition and controllable coexistence are feasible.

**Operation.** Transfer bounded responsibilities with explicit routing/data authority, reconciliation and scaffolding exit conditions.

**Omissions.** No universal dual-write design; read-only or one-authority arrangements may dominate.

**Retirement.** End old paths when consumer, data and recovery obligations permit.

**Limit.** Gateway complexity and extended double maintenance can make another strategy preferable.

**Supporting candidates.** `ESME-015`, `ESME-020`, `ESME-038`, `ESME-039`, `ESME-040`, `ESME-041`, `ESME-042`, `ESME-043`, `ESME-045`, `ESME-046`, `ESME-047`, `ESME-057`, `ESME-072`, `ESME-073`, `ESME-074`

#### ESME-CFG04 — Quiescent cutover

**Guard.** Accepted interruption and a credible stable write boundary exist; prolonged coexistence is disproportionately costly.

**Operation.** Prepare and rehearse conversion, establish quiescence, reconcile and reopen with declared recovery or forward-repair bounds.

**Omissions.** Extended mixed-version operation is not required when it can truly be excluded.

**Retirement.** Remove old live operation only after residual data and support obligations settle.

**Limit.** External writes, unrepresentative rehearsals and irreversible loss can defeat this choice.

**Supporting candidates.** `ESME-001`, `ESME-003`, `ESME-015`, `ESME-020`, `ESME-025`, `ESME-029`, `ESME-041`, `ESME-042`, `ESME-044`, `ESME-045`, `ESME-046`, `ESME-057`, `ESME-072`, `ESME-073`

#### ESME-CFG05 — Bounded automation-assisted maintenance

**Guard.** A supported task class has credible oracles, justified cost and explicit delegation.

**Operation.** Generator proposes, validators establish scoped evidence, authorised acceptance changes the real system and results are observed.

**Omissions.** A separate human approval step is not universally imposed for every narrow transformation; authority and independent evidence cannot be omitted.

**Retirement.** Disable or narrow automation when quality, scope or cost assumptions fail.

**Limit.** No inference to general unattended repository maintenance or self-enlarging authority.

**Supporting candidates.** `ESME-001`, `ESME-003`, `ESME-017`, `ESME-023`, `ESME-025`, `ESME-029`, `ESME-061`, `ESME-062`, `ESME-063`, `ESME-064`, `ESME-072`

#### ESME-CFG06 — Stable service and deliberate non-change

**Guard.** Current obligations and sustainable support are adequate; proposed intervention has no supported net benefit.

**Operation.** Continue useful operation with proportionate observations and revisit triggers.

**Omissions.** No mandatory feature growth, rewrite, zero-debt campaign or commit activity.

**Retirement.** End observations or support arrangements only as obligations disappear; switch to maintenance or retirement when conditions change.

**Limit.** Inactivity alone does not establish the guard.

**Supporting candidates.** `ESME-005`, `ESME-006`, `ESME-007`, `ESME-050`, `ESME-055`, `ESME-058`, `ESME-074`

#### ESME-CFG07 — Responsible retirement with historical custody

**Guard.** Continued operation is no longer justified or sustainable and remaining obligations can be resolved.

**Operation.** Resolve consumer/data transitions, end live service and retain justified identifiable historical artefacts.

**Omissions.** An archive does not require preserving a live obsolete service or promising future executability.

**Retirement.** Retention can end when its legitimate purpose and obligations end.

**Limit.** The study supplies no target-specific legal determination or authority to shut down a service.

**Supporting candidates.** `ESME-001`, `ESME-020`, `ESME-041`, `ESME-055`, `ESME-057`, `ESME-059`, `ESME-060`, `ESME-072`, `ESME-074`

### External interfaces and revision boundaries

**ESME-X01 — Request and obligation owners.** Input: Legitimate intended differences, current constraints and acceptable residual risk. Output: Feasible alternatives, evidence limits and outcome reports. Boundary: No automatic authorisation from research, tests or an agent.

**ESME-X02 — Independent downstream consumers and upstream maintainers.** Input: Actual usage, compatibility needs, support capacity and migration constraints. Output: Actionable impact, deprecation and transition information. Boundary: Notification does not compel a consumer upgrade or upstream labour.

**ESME-X03 — Operators and data custodians.** Input: Actual deployment state, data authority, recoverability and observed consequences. Output: Versioned candidate and explicit rollout/recovery/forward-repair conditions. Boundary: Code identity does not establish persistent-state recovery or access rights.

**ESME-X04 — Later independent tradition synthesis.** Input: Separately researched architecture and product-line evidence, not consulted here. Output: Frozen global property keys, triggers, assumptions, conflicts and evidence. Boundary: No sibling findings inferred; no cross-trifecta synthesis or target adoption performed.

**triggers.** New adverse evidence; Changed environment or objectives; Lost support capacity; Unnecessary cost or disappeared consumer; Tool/model version changes invalidating prior evidence

**actors.** Authorised method/obligation owners with input from affected maintainers and consumers; not self-authorising software.

**allowed_changes.** Narrow, substitute, add, consolidate or retire methods while preserving still-binding obligations; revised objectives require separate legitimate acceptance.

**evaluation.** Use explicit predecessor obligations and independent outcome evidence; do not let the successor’s renamed score validate its own adoption.

**limits.** No claim of an autonomous optimiser, guaranteed convergence or complete self-model.

### Discriminating case tests

The first six cases directly address the required domain challenges. All invented situations are labelled analytical. Published cases contribute their actual reported observations; the proposed response and inferred system obligation remain analytical. No case is counted as a new empirical trial of the composed method.

#### ESME-CASE001 — Important undocumented behaviour

**Kind.** ANALYTICAL

**Setup.** A replacement omits an undocumented rounding convention used by downstream invoices.

**Judgement.** Characterisation reveals the convention, but its existence alone does not establish that it is correct or must remain forever. Current invoice obligations and affected consumers determine preservation or transition.

**Discriminating changed condition.** The consumer establishes that the convention is either contractually required or an old defect with an agreed correction.

**Adequate response.** Protect it when required; otherwise authorise and communicate the intended change with regression checks for unaffected behaviour.

**Failure of the composed system.** Blindly preserve all golden outputs, or dismiss an undocumented behaviour as irrelevant without investigating the consumer.

**Validation status.** Analytical counterexample/consistency test, not empirical validation of the composed system

**Candidates.** `ESME-001`, `ESME-011`, `ESME-015`, `ESME-020`, `ESME-023`, `ESME-026`, `ESME-030`, `ESME-038`, `ESME-042`

[ESME-S035; ESME-S045; ESME-S051; ESME-S059]

#### ESME-CASE002 — Refactor passes tests but changes an external observer

**Kind.** ANALYTICAL

**Setup.** A method rename preserves return values but breaks a reflective caller or changes a supported exception.

**Judgement.** The test result supports its assertions, not the broader preservation claim. The tool’s model may remain internally valid while its applicability to this use fails.

**Discriminating changed condition.** The reflective use is supported public behaviour rather than an excluded private implementation detail.

**Adequate response.** Expand the observer/impact boundary, change the transformation or provide an authorised transition; do not blame the theorem for violating assumptions.

**Failure of the composed system.** Treat the tool’s refactoring label or green tests as proof that the supported caller cannot be affected.

**Validation status.** Analytical counterexample/consistency test, not empirical validation of the composed system

**Candidates.** `ESME-017`, `ESME-018`, `ESME-023`, `ESME-024`, `ESME-025`, `ESME-026`, `ESME-029`, `ESME-038`

[ESME-S018; ESME-S020; ESME-S045; ESME-S051]

#### ESME-CASE003 — Schema rollback after irreversible conversion

**Kind.** ANALYTICAL

**Setup.** A migration rounds monetary values and deletes original precision; reverting source cannot reconstruct the lost digits.

**Judgement.** A non-injective conversion has no complete inverse without retained information. Restoring old code is not restoration of old data meaning.

**Discriminating changed condition.** Original values or an adequate event log were retained and can actually be reconciled, versus their absence.

**Adequate response.** Use a tested restoration/reconciliation path when available; otherwise choose authorised forward repair or explicitly accepted loss before promising recovery.

**Failure of the composed system.** Advertise rollback on the basis of a prior commit despite destroyed information or unknown concurrent writes.

**Validation status.** Analytical counterexample/consistency test, not empirical validation of the composed system

**Candidates.** `ESME-003`, `ESME-039`, `ESME-041`, `ESME-044`, `ESME-045`, `ESME-046`, `ESME-073`

[ESME-S038; ESME-S053]

#### ESME-CASE004 — Popular dependency loses maintainers

**Kind.** ANALYTICAL

**Setup.** A widely used dependency stops responding while a downstream product expects future compatibility fixes.

**Judgement.** Popularity neither creates support capacity nor mandates replacement. Evaluate actual unmet obligations and who would maintain each alternative.

**Discriminating changed condition.** The dependency is complete and adequate with no foreseeable support demand, versus a critical needed change with no willing upstream maintainer.

**Adequate response.** Allow continued use in the former case; compare contribution, paid support, fork or replacement with actual capacity in the latter.

**Failure of the composed system.** Infer safety from stars, demand unpaid work, or create an unowned fork that merely transfers the same problem.

**Validation status.** Analytical counterexample/consistency test, not empirical validation of the composed system

**Candidates.** `ESME-005`, `ESME-020`, `ESME-055`, `ESME-056`, `ESME-057`, `ESME-058`, `ESME-060`

[ESME-S040; ESME-S041; ESME-S043; ESME-S047]

#### ESME-CASE005 — Complexity increases to support needed variation

**Kind.** ANALYTICAL

**Setup.** A product adds required locale/protocol variants; total code and branch counts rise while changes within each variant become simpler.

**Judgement.** Total complexity does not identify local change difficulty or the value of required variation. A metric-only cleanup may remove needed capability.

**Discriminating changed condition.** Variant demand is legitimate and measured local maintenance improves, versus speculative unused variation with growing cost.

**Adequate response.** Judge relevant task costs and preserved obligations; permit justified complexity or remove unjustified variation as evidence dictates.

**Failure of the composed system.** Invoke a law to demand constant size reduction or count a metric increase as automatic architectural failure.

**Validation status.** Analytical counterexample/consistency test, not empirical validation of the composed system

**Candidates.** `ESME-001`, `ESME-006`, `ESME-007`, `ESME-008`, `ESME-027`, `ESME-050`, `ESME-053`, `ESME-065`

[ESME-S008; ESME-S022; ESME-S060; ESME-S064]

#### ESME-CASE006 — Stable useful system with no justified change

**Kind.** ANALYTICAL

**Setup.** An existing system meets its obligations, has adequate support and has no requested enhancement with a supported payoff.

**Judgement.** Deliberate non-change is legitimate. The system does not need a rewrite, debt campaign or artificial commit activity.

**Discriminating changed condition.** An external support or user obligation changes materially.

**Adequate response.** Leave it unchanged with proportionate revisit triggers; reopen the decision when an actual obligation or risk changes.

**Failure of the composed system.** Generate work solely from age, low activity, a zero-debt goal or a universal growth law.

**Validation status.** Analytical counterexample/consistency test, not empirical validation of the composed system

**Candidates.** `ESME-005`, `ESME-007`, `ESME-010`, `ESME-042`, `ESME-048`, `ESME-050`, `ESME-054`, `ESME-060`, `ESME-074`

[ESME-S008; ESME-S031; ESME-S040; ESME-S061]

#### ESME-CASE007 — Favourable bounded automated transformation

**Kind.** ANALYTICAL

**Setup.** A supported language refactoring affects a private function with known callers; the maintainer has authority, a stable baseline and relevant independent checks.

**Judgement.** A single competent actor using a narrow tool and direct checks can satisfy the core; separate boards, agents or exhaustive models are unnecessary.

**Discriminating changed condition.** A new unsupported reflective caller or persistent representation enters the impact boundary.

**Adequate response.** Use the cheap path while assumptions hold; expand analysis or reject the transformation when the new observer invalidates them.

**Failure of the composed system.** Keep the cheap-path conclusion after its supporting assumptions change, or impose maximum machinery despite a closed case.

**Validation status.** Analytical counterexample/consistency test, not empirical validation of the composed system

**Candidates.** `ESME-001`, `ESME-003`, `ESME-017`, `ESME-023`, `ESME-024`, `ESME-025`, `ESME-061`, `ESME-064`, `ESME-072`

[ESME-S018; ESME-S051; ESME-S055]

#### ESME-CASE008 — Individually green changes conflict after merge

**Kind.** ANALYTICAL

**Setup.** Two changes update the same derived data through different paths; isolated tests pass but the merged state applies an operation twice.

**Judgement.** Independent endpoint evidence is not sufficient for the merged candidate. Combined obligations and reachable interactions need checking.

**Discriminating changed condition.** A justified disjoint dependency boundary is demonstrated, versus shared state or assumptions.

**Adequate response.** Validate the actual merged candidate or prohibit the problematic combination; permit truly disjoint work to proceed concurrently.

**Failure of the composed system.** Reuse pre-merge results as if they were evidence about the new integrated state.

**Validation status.** Analytical counterexample/consistency test, not empirical validation of the composed system

**Candidates.** `ESME-003`, `ESME-017`, `ESME-022`, `ESME-025`, `ESME-029`, `ESME-072`, `ESME-073`

[ESME-S044; ESME-S051]

#### ESME-CASE009 — Failed observation and a nominal policy file

**Kind.** ANALYTICAL

**Setup.** A repository contains a passing policy test and a rollout dashboard, but the runtime never loads the policy and no one receives alerts.

**Judgement.** The stored rule and observed test do not establish operative enforcement or response capability. This is a composition failure even when the file is correct.

**Discriminating changed condition.** Runtime consumption and an actor’s response are demonstrated, versus mere artefact presence.

**Adequate response.** Connect or replace the mechanism, or stop claiming its effect. Retire inert artefacts when no protected obligation requires them.

**Failure of the composed system.** Count file presence, green checks or dashboard existence as an achieved maintenance outcome.

**Validation status.** Analytical counterexample/consistency test, not empirical validation of the composed system

**Candidates.** `ESME-037`, `ESME-040`, `ESME-064`, `ESME-066`, `ESME-072`, `ESME-074`

[ESME-S056; ESME-S058]

#### ESME-CASE010 — Published GitLab recovery incident

**Kind.** PUBLISHED

**Setup.** The January 2017 database incident exposed failed expected backup paths, restore-version issues and state recovery complications.

**Judgement.** The case supports separating source identity from real data recovery. It does not measure the failure rate of all migrations or prove a universal recovery design.

**Discriminating changed condition.** A later target’s backups and restore compatibility may differ and must be tested directly.

**Adequate response.** Ask for evidence of the recovery actually promised, not merely a backup schedule.

**Failure of the composed system.** Infer recovery assurance from the existence of an old repository version.

**Validation status.** Published observation with separately labelled analytical implication; no new experiment

**Candidates.** `ESME-003`, `ESME-036`, `ESME-041`, `ESME-045`, `ESME-072`

[ESME-S038]

#### ESME-CASE011 — Published mixed APR assistance effects

**Kind.** PUBLISHED

**Setup.** The 2024 controlled repair-assistance study exposes developers to different patch-quality conditions across real Java bugs.

**Judgement.** Correct and deceptive suggestions affect developers differently. This supports quality-sensitive evaluation rather than assuming that human review always neutralises bad candidates.

**Discriminating changed condition.** The actual production distribution of patch quality may differ from the study’s exposure conditions.

**Adequate response.** Include correctness and review cost in a target evaluation rather than projecting one condition’s effect onto all automation.

**Failure of the composed system.** Count generation or human presence alone as effective maintenance.

**Validation status.** Published observation with separately labelled analytical implication; no new experiment

**Candidates.** `ESME-029`, `ESME-061`, `ESME-063`, `ESME-064`, `ESME-068`

[ESME-S052]

#### ESME-CASE012 — Published software-law counterpressure

**Kind.** PUBLISHED

**Setup.** Linux’s total and per-function complexity trends differ; glibc’s late size plateau complicates a universal growth reading.

**Judgement.** The studies constrain interpretation, not a universal finding that all laws are false or all stable systems will remain useful.

**Discriminating changed condition.** Population, time scale or measured quantity changes.

**Adequate response.** Restate and test the specific hypothesis; do not turn an empirical label into a mandatory intervention.

**Failure of the composed system.** Pool unlike metrics or count a later analysis of Linux as an independent system population.

**Validation status.** Published observation with separately labelled analytical implication; no new experiment

**Candidates.** `ESME-005`, `ESME-006`, `ESME-007`, `ESME-008`, `ESME-010`, `ESME-053`

[ESME-S060; ESME-S061]


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_HYBRIDISATION_AND_EXTERNAL_RELATIONS

Documented imports are kept distinct from native contribution. Software configuration histories become input to mined change recommendations; test-based fitness becomes an input to automated repair; the debt concept is explicitly applied to learned-system entanglement and feedback. Architecture recovery appears inside reverse engineering and migration; product-configuration analysis appears in the KConfigReader experience. These intersections are not findings borrowed from the unread Architecture or Product Line Engineering syntheses. [ESME-S012; ESME-S017; ESME-S031; ESME-S042; ESME-S064; ESME-S065.]

The genetic-programming sense of evolution and the longitudinal Lehman sense are only analogous without further documentary support for influence. Later derivatives can hybridise mechanisms, but common vocabulary is not genealogy. The synthesis interface therefore asks whether architecture constraints and variant-level obligations complement, refine, duplicate or conflict with these maintenance mechanisms; it does not pre-answer those questions. No physical-maintainability law, economic optimisation guarantee or autonomous organisational authority is imported by analogy.


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_STRONGEST_SURVIVING_PROPERTIES

The strongest core consists of criteria and their operative establishment, not a maximal tooling set. “Strong” here includes logically important distinctions whose implementation benefit still depends on context.

**ESME-001 — Explicit and authorised change intent.** State the requested behavioural difference, surviving obligations and decision authority; challenge ambiguous or conflicting requests before treating tests as acceptance. Cheap path: Use an existing unambiguous authorised request; no new board or document is needed. Decline changes without a supported objective. [ESME-S002; ESME-S005; ESME-S039; ESME-S051]

**ESME-003 — Recoverable configuration baseline.** Bind change and evidence to recoverable versions of the relevant source, configuration, build inputs and data/schema state; distinguish identity from recoverability. Cheap path: Use existing versioned inputs and reproducible commands; do not snapshot irrelevant infrastructure or duplicate authoritative history. [ESME-S002; ESME-S030; ESME-S038; ESME-S046]

**ESME-011 — Question-bounded program comprehension.** Identify the questions needed for this change, seek evidence until consequential uncertainties are bounded, and expand inquiry when evidence contradicts the model. Cheap path: Reuse reliable knowledge and perform a small confirming check when the question is local and low consequence. [ESME-S014; ESME-S015; ESME-S051]

**ESME-014 — Distinguish recovery from transformation.** Label whether an activity recovers information, changes representation at the same abstraction, or reconstructs/changes the system; assign evidence and authority accordingly. Cheap path: Ordinary descriptions suffice for unambiguous local work; a taxonomy table is unnecessary. [ESME-S012; ESME-S021]

**ESME-017 — Justified impact boundary.** Propose an impact boundary from relevant dependencies, challenge it with contrary evidence and widen it when an affected obligation crosses the boundary. Cheap path: Accept a local boundary with a concrete reason when interfaces and dependencies make the effect local; no whole-system analysis by default. [ESME-S013; ESME-S016; ESME-S017; ESME-S044]

**ESME-023 — Observer-relative preservation obligations.** Name the observers, environments and obligations to remain invariant, separately from intended differences; compare the actual transformation against that boundary. Cheap path: A narrow observer and a direct comparison suffice where that is the actual contract; do not require equivalence for irrelevant internal states. [ESME-S012; ESME-S018; ESME-S020; ESME-S022; ESME-S045; ESME-S051]

**ESME-025 — Validation of the actual transformed artefact.** Check the actual transformed baseline using relevant semantic reasoning, tests or comparison; invalidate earlier evidence when consequential inputs change. Cheap path: A small reviewed diff and a targeted check may be enough; no universal demand for multiple expensive validators. [ESME-S018; ESME-S020; ESME-S024; ESME-S051; ESME-S052]

**ESME-026 — Separate preservation from intentional behaviour change.** Declare intentional behavioural differences independently from structural work; revise obsolete tests through an authorised account of intended behaviour. Cheap path: One combined patch is permissible when separating it increases risk, provided the distinct obligations remain assessable. [ESME-S002; ESME-S018; ESME-S023; ESME-S051; ESME-S059]

**ESME-029 — Oracle provenance and independent obligations.** Trace acceptance expectations to independent requirements, adjudicated behaviour, domain properties or credible reference evidence; state gaps and conflicts. Cheap path: A trusted narrow assertion may suffice for a simple obligation; do not build a specification language merely for appearance. [ESME-S024; ESME-S026; ESME-S051; ESME-S052]

**ESME-041 — State-and-effect recovery rather than code reversion alone.** Classify reversible and irreversible effects; demonstrate restoration/reconciliation where promised, otherwise plan forward repair or explicitly authorised loss. Cheap path: For a pure read-only reversible change, restoring the prior artefact may genuinely be sufficient. [ESME-S038; ESME-S053]

**ESME-061 — Generated repairs remain candidate interventions.** Treat generated output as a proposed intervention; check the actual patch against independent intent and preservation obligations before acceptance. Cheap path: A narrow verified transformation or a simple human fix may be cheaper; automation is optional. [ESME-S024; ESME-S026; ESME-S027; ESME-S052; ESME-S055; ESME-S065; ESME-S067]

The 25 evolved-form candidates complement this core through bounded feedback, recovery, communication, compatibility, economics and continuity. Neither group claims that a separate control is required for every analytical concern. The source-partitioned property records, not rank alone, determine a later audit question.


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CONTEXT_SPECIFIC_PROPERTIES

### CONTEXT_DEPENDENT (14)

**ESME-008 — Costed complexity and anti-regressive work.** Trigger: Recurrent changes or demonstrated failures make a particular structural difficulty consequential. Preconditions: A stated future change class, intervention cost and evidence connecting the alleged complexity to that cost. Non-trigger/cheaper alternative: Use a local repair or tolerate harmless complexity when no likely change benefits from restructuring. [ESME-S008; ESME-S020; ESME-S022; ESME-S032; ESME-S050; ESME-S060]

**ESME-009 — Familiarity and knowledge-capacity constraints.** Trigger: Rapid growth, departure, ownership concentration or repeated review/comprehension failures. Preconditions: Access to people and artefacts, an honest account of capacity and authority to defer or narrow change. Non-trigger/cheaper alternative: An experienced available maintainer can make a bounded change without a formal knowledge census. [ESME-S008; ESME-S010; ESME-S014; ESME-S043; ESME-S047]

**ESME-027 — Refactoring benefit tied to a future change class.** Trigger: Restructuring is justified by maintainability, comprehension or reduced future change cost. Preconditions: A plausible future task population and an explicit account of present disruption and review cost. Non-trigger/cheaper alternative: Leave the structure alone, repair locally or improve a small seam when no broader benefit is supported. [ESME-S018; ESME-S019; ESME-S020; ESME-S021; ESME-S022]

**ESME-031 — Differential testing with adjudicated differences.** Trigger: A credible reference exists and executions can be made comparable. Preconditions: Comparable input/environment, known intended differences and awareness of common-mode defects. Non-trigger/cheaper alternative: Use direct expected results for simple cases; no duplicate implementation is required where it adds less evidence than it costs. [ESME-S051; ESME-S064]

**ESME-033 — Mutation analysis as an adequacy probe.** Trigger: Critical regression claims depend on a test suite whose fault sensitivity is uncertain. Preconditions: Valid operators, interpretable mutants and a correct oracle for deciding whether altered behaviour matters. Non-trigger/cheaper alternative: A few manually chosen fault injections may be enough; skip large mutation campaigns when equivalent mutants or cost dominate. [ESME-S051; ESME-S062]

**ESME-035 — Test prioritisation under interruption and feedback costs.** Trigger: Execution may be interrupted or feedback latency materially affects repair/release decisions. Preconditions: Interpretable historical evidence, stable enough workload and an explicit delay tolerance. Non-trigger/cheaper alternative: Use the ordinary order for a fast suite; do not train a predictor without a meaningful latency problem. [ESME-S023; ESME-S051; ESME-S058; ESME-S066]

**ESME-040 — Staged exposure with actionable observations.** Trigger: Consequences can be observed before full exposure and populations or functions can be separated safely. Preconditions: Meaningful observations, a control over exposure and feasible recovery/forward-repair actions. Non-trigger/cheaper alternative: Use a direct cutover for a tiny reversible change or when staging introduces more inconsistency than it reduces risk. [ESME-S035; ESME-S036; ESME-S037; ESME-S038]

**ESME-043 — Incremental displacement with bounded coexistence.** Trigger: Work can be partitioned with tolerable coexistence and useful partial delivery. Preconditions: Routing control, explicit data authority, compatibility and an exit condition for duplicate operation. Non-trigger/cheaper alternative: Prefer a local repair or quiescent cutover when partitions are artificial or gateways cost more than staged benefit. [ESME-S031; ESME-S035; ESME-S036; ESME-S037; ESME-S053]

**ESME-051 — Debt prioritisation across affected stakeholders.** Trigger: Multiple maintenance needs compete for constrained effort, particularly across ownership or funding boundaries. Preconditions: Enough information about affected stakeholders, severity, recurrence and available capacity. Non-trigger/cheaper alternative: A maintainer can resolve a small local issue directly when no meaningful trade-off or external cost exists. [ESME-S032; ESME-S043; ESME-S048; ESME-S049]

**ESME-056 — Handoff and onboarding through demonstrated capability.** Trigger: Ownership transfer, new maintainer onboarding or impending loss of specialised knowledge. Preconditions: A willing receiving maintainer, operational access and time to learn; a quiz alone is not enough. Non-trigger/cheaper alternative: Pair on one meaningful change or diagnosis instead of producing a comprehensive handover manual. [ESME-S014; ESME-S015; ESME-S043; ESME-S047]

**ESME-058 — Dependency viability and response alternatives.** Trigger: A dependency loses maintainers, support, compatibility or timely response needed by the consuming system. Preconditions: Understanding of actual use, licences/access, transitive dependencies and capacity to maintain an alternative. Non-trigger/cheaper alternative: Continue using a stable adequate dependency when no unmet obligation warrants change, while retaining appropriate observation. [ESME-S040; ESME-S041; ESME-S043]

**ESME-063 — End-to-end automation cost and outcome assessment.** Trigger: A maintenance automation is selected, expanded or justified economically. Preconditions: Representative tasks, defined outcomes, appropriate baseline and accounting for review and failed attempts. Non-trigger/cheaper alternative: For a cheap reversible task, direct bounded experience may suffice; do not run a research programme for every suggestion. [ESME-S025; ESME-S033; ESME-S034; ESME-S052; ESME-S057]

**ESME-067 — Bounded revision of maintenance methods.** Trigger: Repeated false positives, missed failures, excessive cost or changed technology undermines the current method. Preconditions: Evidence of the method’s limits, an authorised revision boundary and a comparison not defined solely by the proposed successor. Non-trigger/cheaper alternative: Keep a working method unchanged or remove an unused control; do not add reflexive governance without a demonstrated consumer. [ESME-S006; ESME-S025; ESME-S029; ESME-S033; ESME-S049; ESME-S058; ESME-S063]

**ESME-074 — Feedback-driven proportionality and retirement of maintenance controls.** Trigger: Accumulating controls, repeated false alarms, migration completion, disappearing consumers or changed lifecycle objectives. Preconditions: Knowledge of protected obligations, actual consumers, combined costs and authority to alter the method without silently waiving required outcomes. Non-trigger/cheaper alternative: Retain a small working arrangement unchanged; do not create a permanent meta-process merely to measure every control. [ESME-S008; ESME-S022; ESME-S031; ESME-S032; ESME-S040; ESME-S048; ESME-S049; ESME-S058]

### ASSUMPTION_SENSITIVE (12)

**ESME-007 — Population-scoped evolution-law interpretation.** Trigger: A growth, complexity, effort or quality law is used to explain or predict an actual system. Preconditions: An operational interpretation of the law, compatible observations and a potential disconfirming result. Non-trigger/cheaper alternative: Use direct local evidence without invoking a law when the classification or measurement adds no decision value. [ESME-S008; ESME-S009; ESME-S010; ESME-S011; ESME-S029; ESME-S060; ESME-S061]

**ESME-013 — Criterion-relative program slicing.** Trigger: A value, statement or behaviour can be represented by a tractable slicing criterion. Preconditions: Soundness assumptions for the chosen static/dynamic analysis, aliasing, control flow, termination and environment. Non-trigger/cheaper alternative: Direct inspection of a tiny dependency chain may be cheaper; avoid slicing where external effects are outside the model. [ESME-S013; ESME-S051]

**ESME-019 — Historical co-change as defeasible evidence.** Trigger: History is sufficiently representative and structural evidence leaves uncertainty about likely companion changes. Preconditions: Clean enough history, meaningful change units and awareness of bulk edits, conventions and process changes. Non-trigger/cheaper alternative: Ignore the predictor for new code, rewritten history or an already understood local dependency. [ESME-S017; ESME-S044]

**ESME-022 — Semantic interference analysis for merged changes.** Trigger: Concurrent changes interact through shared state, dataflow, interfaces or assumptions even when textual merge succeeds. Preconditions: A common baseline, both change intents, buildable merged artefact and supported analysis semantics. Non-trigger/cheaper alternative: Independent changes with a justified disjoint impact boundary may need only normal combined regression. [ESME-S044; ESME-S051]

**ESME-024 — Transformation preconditions and model scope.** Trigger: An automated or manual transformation relies on a formal or tool-defined refactoring rule. Preconditions: A valid mapping from actual language/tool version and artefacts to the proof or rule’s assumptions. Non-trigger/cheaper alternative: For a small obvious edit, direct semantic reasoning and testing may be cheaper than a general transformation framework. [ESME-S018; ESME-S020; ESME-S051]

**ESME-032 — Metamorphic relations as partial oracles.** Trigger: Exact expected results are difficult but a relevant mathematical or domain relation is credible. Preconditions: A valid metamorphic relation, appropriate numerical/nondeterministic tolerance and no unaccounted persistent side effects. Non-trigger/cheaper alternative: Use ordinary assertions when expected results are cheap; do not invent weak relations to inflate a test count. [ESME-S051; ESME-S063]

**ESME-034 — Regression selection under explicit safety and cost assumptions.** Trigger: Retest-all cost is consequential and change impact can be analysed well enough to support selection. Preconditions: A recoverable baseline, test-to-behaviour mapping and explicit handling of environment and nondeterminism. Non-trigger/cheaper alternative: Run the whole small suite when selection overhead exceeds savings. [ESME-S023; ESME-S051]

**ESME-039 — Mixed-version compatibility conditions.** Trigger: A deployment, dependency ecosystem or migration permits mixed versions. Preconditions: Known version combinations, routing/data ownership and a way to prevent unsupported interactions. Non-trigger/cheaper alternative: Use a genuinely quiescent coordinated cutover when it is cheaper and acceptable; then the mixed-version matrix may be unnecessary. [ESME-S031; ESME-S038; ESME-S043; ESME-S045; ESME-S053]

**ESME-045 — Migration state reconciliation and data authority.** Trigger: Data or service state is copied, transformed or temporarily maintained in more than one place. Preconditions: Explicit identities, mapping semantics, write ordering and access to authoritative observations. Non-trigger/cheaper alternative: An immutable read-only export with a simple verified mapping may need only one comparison and no dual-write protocol. [ESME-S031; ESME-S038; ESME-S053]

**ESME-046 — Schema mappings and information-loss analysis.** Trigger: Schema/data representation changes affect persistent meaning or old-version access. Preconditions: A model matching actual schema semantics, constraints, data values and supported transformation operators. Non-trigger/cheaper alternative: Use a direct checked migration for a simple bijective mapping; a full workbench is unnecessary. [ESME-S038; ESME-S053]

**ESME-050 — Contingent lifecycle economics.** Trigger: A nontrivial preventive investment competes with current delivery or another maintenance option. Preconditions: Meaningful cost units, a plausible horizon and honest uncertainty rather than fabricated precision. Non-trigger/cheaper alternative: For a cheap urgent defect repair, direct consequence and effort comparison may be enough. [ESME-S019; ESME-S032; ESME-S048; ESME-S049]

**ESME-073 — Continuity of obligations across temporary joint states.** Trigger: Coexistence, concurrent integration, data conversion or externally staggered upgrades create intermediate states. Preconditions: A credible account of reachable combinations, sequencing and external actors; abstract state models must match actual operation. Non-trigger/cheaper alternative: A truly atomic quiescent transition or justified disjoint changes can eliminate most joint-state obligations. [ESME-S031; ESME-S038; ESME-S044; ESME-S045; ESME-S053]

### DOMAIN_SPECIFIC (2)

**ESME-044 — Quiescent or big-bang cutover as a conditional alternative.** Trigger: A tolerable outage exists, data can be stabilised and the joint operation burden would otherwise dominate. Preconditions: Accepted outage, frozen input boundary, tested conversion, sufficient capacity and clear irreversibility decisions. Non-trigger/cheaper alternative: Continue maintenance or use incremental displacement where interruption or conversion risk is unacceptable. [ESME-S031; ESME-S038; ESME-S053]

**ESME-065 — Learned-system data and feedback evolution.** Trigger: Maintained behaviour materially depends on learned components or changing data distributions. Preconditions: Data provenance/access, meaningful outcome measures and an understanding of the observation and deployment environment. Non-trigger/cheaper alternative: For deterministic code without learned dependencies, ordinary change evidence applies; no ML-specific machinery is needed. [ESME-S042; ESME-S051; ESME-S057]

### USEFUL_BUT_EASILY_GAMED (1)

**ESME-053 — Maintainability measures as validated proxies.** Trigger: A metric informs prioritisation, prediction, comparison or acceptance of maintenance work. Preconditions: Stable definitions, a relevant comparison and evidence about measurement error and confounding. Non-trigger/cheaper alternative: Direct task evidence or a short qualitative comparison can dominate an elaborate index. [ESME-S022; ESME-S032; ESME-S048; ESME-S060]


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_REJECTED_OR_SUPERSEDED_PRACTICES

**ESME-010 — Universal mandatory growth or inevitable deterioration: `REJECTED_OR_DISFAVOURED`.** REJECTED as a universal mandate; ESME-007 preserves the narrower explanatory programme. Original work itself allows consolidation; later studies show stage and metric dependence. A conditional law does not entail the proposed unconditional mandate. [ESME-S008; ESME-S009; ESME-S010; ESME-S011; ESME-S029; ESME-S060; ESME-S061]

**ESME-016 — Exhaustive system comprehension before every change: `REJECTED_OR_DISFAVOURED`.** REPLACED by ESME-011, ESME-017 and ESME-021 rather than by permission to change blindly. Formal analysis of a bounded model is possible, but it is not exhaustive knowledge of all real environments and future uses. [ESME-S013; ESME-S014; ESME-S015]

**ESME-028 — Cleaner structure guarantees engineering benefit: `REJECTED_OR_DISFAVOURED`.** REJECTED as a guarantee; ESME-027 and ESME-053 retain defeasible uses. Comprehension proxies can miss cross-class effects; refactoring can introduce faults; observational association does not identify net benefit. [ESME-S020; ESME-S021; ESME-S022]

**ESME-048 — Technical novelty or age decides replacement: `REJECTED_OR_DISFAVOURED`.** REJECTED as a decision rule; specific age-associated constraints remain inputs to ESME-042. Older dependencies can create real support constraints, but that is evidence about support, not proof from age itself. [ESME-S031; ESME-S039; ESME-S040; ESME-S050]

**ESME-054 — Mandatory comprehensive cleanup or zero debt: `REJECTED_OR_DISFAVOURED`.** REJECTED; ESME-049 through ESME-052 preserve bounded identification, economics and revision. Some debt carries unacceptable risks, but that supports urgent targeted action rather than a universal total-removal rule. [ESME-S019; ESME-S032; ESME-S040; ESME-S048; ESME-S049]

**ESME-068 — Human-only maintenance is universally superior: `REJECTED_OR_DISFAVOURED`.** REJECTED in favour of ESME-061 through ESME-064 and conditional configurations. Correct suggestions helped in the inspected controlled study; SapFix demonstrates bounded deployment; neither proves universal benefit either. [ESME-S025; ESME-S033; ESME-S034; ESME-S052; ESME-S055; ESME-S067]

**ESME-069 — Reliable unattended repository-scale maintenance as a general capability: `UNRESOLVED`.** STILL_CONTESTED/UNRESOLVED: researched uncertainty at the cut-off, not unexamined work and not a claim that future success is impossible. Leakage, weak oracles, selected populations and narrow deployments leave major transfer gaps. Rapid tool change also prevents treating old adverse evidence as a permanent limit. [ESME-S024; ESME-S025; ESME-S026; ESME-S027; ESME-S033; ESME-S052; ESME-S055; ESME-S057; ESME-S065; ESME-S067]

**ESME-070 — Golden-master preservation as a separate mechanism: `DUPLICATE_CANDIDATE`.** SUPERSEDED for independent counting by the exact linked candidate, without deleting its record. Not every snapshot test is a golden master and some encode explicit specifications; those uses must be classified by mechanism, not brand. [ESME-S051; ESME-S059]

**ESME-071 — A formal change board for every change: `CEREMONY_NOT_GENERAL_PROPERTY`.** NARROWED to ESME-001’s underlying property with context-triggered coordination. The sources support controlled management, not this universal caricature. Some regulated or multi-owner contexts genuinely require formal review. [ESME-S002; ESME-S005; ESME-S007; ESME-S039]

No candidate is assigned the primary status `SUPERSEDED_BY_STRONGER_FORM` in this revision. Some rejected generalisations have explicit `SUPERSEDES` relations to better-scoped alternatives; those relations do not change their primary counted disposition. ESME-070 remains in the denominator as a duplicate of ESME-030. ESME-069 remains unresolved, not rejected or unexamined.


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_CURRENT_STATE_AND_RESEARCH_FRONTIER

The 2022–2026 evidence does not justify a monotonic story in which better automation removes maintenance judgement. Repair quality, oracle adequacy, repository context, developer experience, review costs, task selection, tool vintage and deployment effects change the interpretation of an apparent improvement. Current research also broadens the artefact boundary to learned models, data feedback and executable policy. A result on a benchmark is a claim about its population and evaluation; a deployment report is a claim about an actual setting; neither is a universal capability guarantee. [ESME-S022; ESME-S025–ESME-S028; ESME-S033–ESME-S034; ESME-S042–ESME-S044; ESME-S052; ESME-S056–ESME-S057; ESME-S067.]

Particularly important frontiers are independent obligations for generated transformations; representative long-term evaluation after acceptance; integration of non-code, persistent-state and learned-component change; inference of consequential hidden consumers; lower-cost detection of joint-state conflicts; and maintainership capacity under evolving dependency obligations. These questions remain empirically open without implying that progress is impossible. The packet does not report any future September 2026 conference event as already completed.


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_ADVERSARIAL_SYNTHESIS_VERDICT

**Verdict: retain a conditional core with alternative configurations; do not claim a universally optimal or empirically validated total methodology.** The core preserves distinctions that prevent serious category errors: a request is not automatically beneficial; an identity is not a recovery capability; a representation is not the real system; a passing test is not a complete oracle; a proof is not automatic model applicability; notification is not agreement; and generation is not authority. The best-supported operative interpretation couples each distinction to a relevant consumer and consequence.

The strongest objection to unification is that the parts operate at different abstraction levels and have heterogeneous evidence. A slicing result, a deprecation policy, an interview about abandoned dependencies and a controlled repair-assistance experiment do not identify one shared causal effect. The model therefore preserves alternatives, labels analytical joins, separates evidence partitions and refuses to turn source count into confidence.

The main practical falsifier is net harm: a composed arrangement may increase delay, review burden, rechecking cascades, stale artefacts, state-space complexity or concentrated authority without improving the protected decisions. ESME-074 makes removal and substitution legitimate responses. If a cheap direct check supplies the relevant assurance, additional bureaucracy is not maturity. Conversely, apparent low cost is not enough when a rare but consequential obligation has simply been omitted.

The adversarial cases changed the outcome. Non-change is retained; universal growth, age-based replacement, zero debt and guaranteed refactoring benefit are rejected; migration remains bifurcated; test preservation is provisional; autonomy remains bounded; and three interaction obligations are added. These are not objections appended to an unchanged endorsement.


## EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_OPEN_QUESTIONS_AND_EVIDENCE_LIMITS

### Unresolved composition questions

**ESME-U01 — EXAMINED_UNRESOLVED.** How cheaply can evidence-to-action identity and invalidation be maintained across independently operated tools and teams? `ESME-072`.

**ESME-U02 — EXAMINED_UNRESOLVED.** Which abstraction exposes consequential joint-state failures without unmanageable combination growth? `ESME-073`.

**ESME-U03 — EXAMINED_UNRESOLVED.** What integrated field evidence establishes net benefit and appropriate retirement of combined controls? `ESME-074`.

**ESME-U04 — EXAMINED_UNRESOLVED.** Can reliable, authorised and economical unattended repository maintenance be demonstrated across representative populations over time? `ESME-069`.

### Candidate-level open questions

**ESME-001.** How much stakeholder consultation changes decisions, rather than merely delaying them, is setting-specific.

**ESME-002.** Which classifications improve decisions enough to justify coding and disagreement resolution?

**ESME-003.** How much external state must be captured for a particular observation to remain reproducible?

**ESME-004.** Which low-cost transition exercises predict later maintenance performance?

**ESME-005.** What inexpensive observations distinguish enduring adequacy from unnoticed deterioration?

**ESME-006.** Which feedback mechanisms explain a particular project’s trajectory after organisational confounders are considered?

**ESME-007.** Which formulations retain predictive value across independently selected populations?

**ESME-008.** How can delayed benefits be distinguished from selection effects and concurrent development changes?

**ESME-009.** What task-level demonstrations best reveal knowledge that history-based measures miss?

**ESME-010.** Predictive scope of particular laws remains researchable; rejection does not imply no recurring evolution patterns.

**ESME-011.** How should inquiry stop when low-probability impact is expensive to observe?

**ESME-012.** Which combinations provide enough independent evidence for rare configuration-dependent behaviour?

**ESME-013.** What conservatism is affordable for reflection, foreign calls and configuration-driven execution?

**ESME-014.** How should mixed analysis-and-transformation tools expose their distinct guarantees?

**ESME-015.** Which rationale deserves retention when documentation itself has maintenance cost?

**ESME-016.** High-consequence changes can still demand extensive analysis; the appropriate boundary remains a substantive judgement.

**ESME-017.** How should rare but severe propagation risks affect the cost of boundary verification?

**ESME-018.** How can hidden consumers be discovered without imposing an unmaintainable universal dependency model?

**ESME-019.** How quickly do predictors become stale after architectural or team changes?

**ESME-020.** When does uncertainty about unknown consumers warrant compatibility scaffolding or delayed change?

**ESME-021.** Which challenge strategy gives the best reduction in consequential uncertainty per unit cost?

**ESME-022.** How well do findings transfer beyond buildable Java cases to configuration, schemas and learned components?

**ESME-023.** Which implicit performance or operational expectations should count as supported obligations?

**ESME-024.** What affordable validation detects divergence between language evolution and a refactoring tool’s semantic model?

**ESME-025.** When does independent checking justify its added cost compared with a trustworthy narrow transformation?

**ESME-026.** What evidence adequately justifies changing a characterisation test when original intent is lost?

**ESME-027.** Which refactorings produce durable gains for real maintenance tasks after all costs are counted?

**ESME-028.** Particular task/metric relationships can still be validated locally.

**ESME-029.** How should decisions proceed when the strongest available oracles disagree?

**ESME-030.** Which undocumented behaviours should be promoted to supported contracts?

**ESME-031.** How should references be chosen when no implementation has stronger semantic authority?

**ESME-032.** How can useful relations be validated cheaply for changing learned or probabilistic systems?

**ESME-033.** Which operator set most economically represents a target’s consequential fault classes?

**ESME-034.** How should flaky tests and configuration-dependent dependencies affect selection guarantees?

**ESME-035.** How much delay is acceptable for a rare severe regression compared with routine development feedback?

**ESME-036.** Which environment details are necessary for a future consumer’s reconstruction task?

**ESME-037.** Which cadence and selection policy maximise useful feedback under constrained resources?

**ESME-038.** How should widely relied-on but unintentionally exposed behaviour enter a support policy?

**ESME-039.** What minimum compatibility window is affordable when consumer upgrades are outside producer control?

**ESME-040.** Which observations and exposure limits detect the consequential failure modes soon enough to act?

**ESME-041.** How should a decision value low-probability irreversible losses when no complete recovery is possible?

**ESME-042.** How can undocumented requirements and transition uncertainty be estimated before committing to replacement?

**ESME-043.** Which partition boundaries minimise both transition coupling and permanent duplication?

**ESME-044.** What evidence establishes that an apparently quiescent boundary really excludes concurrent external changes?

**ESME-045.** What sampling or invariants are adequate when full semantic comparison is prohibitively expensive?

**ESME-046.** How should extensions, triggers and external data semantics be incorporated without destroying tractability?

**ESME-047.** When does permanent compatibility support become more economical than forcing the remaining consumers to migrate?

**ESME-048.** Which actual support and knowledge risks are hidden by a superficially modern platform?

**ESME-049.** When is the debt metaphor more informative than direct lifecycle-cost reasoning?

**ESME-050.** How should irreversible option loss and costs shifted to future maintainers be represented without spurious precision?

**ESME-051.** Which mechanisms fairly represent downstream or future maintainers absent from current decisions?

**ESME-052.** What observation period is sufficient for a low-frequency but high-cost change class?

**ESME-053.** Which metrics remain useful after teams adapt their behaviour to being measured?

**ESME-054.** How should genuinely non-deferrable obligations be distinguished from elective maintainability investment?

**ESME-055.** Which funding and workload arrangements sustain capacity without shifting hidden costs to volunteers?

**ESME-056.** How can representative tasks be chosen without overburdening outgoing maintainers?

**ESME-057.** How should a producer proceed when critical unknown consumers cannot be reached?

**ESME-058.** Which signals predict consequential abandonment early enough for a proportionate response?

**ESME-059.** Which environment and dependency evidence should accompany source for a particular future reconstruction task?

**ESME-060.** How can hidden consumers and indefinite support expectations be resolved before final shutdown?

**ESME-061.** What review and validation combination is cost-effective for each repair class?

**ESME-062.** How can current models be evaluated on representative tasks with genuinely unseen obligations and long-term outcomes?

**ESME-063.** What is the causal current-tool effect for representative maintainers and long-lived outcomes?

**ESME-064.** Which narrow change classes justify unattended acceptance under independently established evidence?

**ESME-065.** How can long-term feedback and distribution shifts be evaluated without treating benchmark stability as deployment stability?

**ESME-066.** How can rarely changed but high-consequence policy artefacts be tested economically?

**ESME-067.** What independent evidence is enough when a method changes the way its own effectiveness is measured?

**ESME-068.** Current broad productivity effects remain unresolved rather than replaced with a universal opposite claim.

**ESME-069.** Can independently evaluated unattended systems sustain correct, authorised and economical maintenance across representative repositories over time?

**ESME-070.** A materially different trigger or guarantee would require a new candidate rather than silently overloading this alias.

**ESME-071.** When does a multi-party forum resolve conflicts more effectively than direct accountable decisions?

**ESME-072.** What is the cheapest reliable binding across independently operated tools and teams?

**ESME-073.** Which abstractions preserve the consequential joint-state failures without modelling every combination?

**ESME-074.** How should low-frequency high-consequence controls be valued without allowing either permanent ceremony or unsafe removal?

### Access and transfer limits

**ESME-S001.** Paid normative text not inspected; no clause-level compliance claims.

**ESME-S004.** ACM and institutional PDF attempts failed. No claim of reading original methods or body.

**ESME-S006.** Full body inaccessible; omitted class-level details not inferred.

**Full SWEBOK V4.** V4 scope was checked through an author overview; detailed concepts cited from the inspected V3 guide are explicitly labelled V3, not claimed as inspected V4 clauses.

**Original ICSE 2009 GenProg paper.** Author PDF retrieval failed; the distinct primary 2010 account and 2025 original-author retrospective were inspected and registered separately.

**Rothermel et al. 2001 journal prioritisation paper.** Institutional full-text request returned 403; the original 1999 conference paper was inspected, including methods/table and threats.

**Original 2004 Feathers book.** Whole book not inspected; 2024 author interview supports the characterisation account. No page-level quotation or full-book claim.

**PRISM 2008 paper and SapFix 2019 conference text.** Exact full bodies not retrieved; accessible primary 2009 PRISM demo and 2018 SapFix deployment account used with their narrower evidence roles.

**Software Heritage 2017 original and project whitepaper.** Bot/server access failures; the primary 2023 ecosystem chapter supplied the inspected archival mechanism. No unread historical detail imported.

The standards catalogue cannot support unread normative clauses. Original-body limits for Swanson and Chapin constrain historical detail rather than erase the field. Reviews can organise a branch without substituting for an original empirical study; unavailable originals are not counted as fully inspected. Technical prototypes and formal results retain their model and implementation obligations. Field reports, interviews and self-reports do not identify universal causal effects. Most recent automation outcomes are tool-, task- and date-specific.

### Shared-source and dataset dependence

**ESME-DEP01.** Founding evolution research programme and later reformulation. Do not count each formulation as an independent empirical replication. [ESME-S008; ESME-S009; ESME-S010]

**ESME-DEP02.** Same Linux project, different periods and analyses. Additional longitudinal analysis, not an independent software population. [ESME-S011; ESME-S060]

**ESME-DEP03.** Review organises primary studies; overlapping authorship with glibc work. Review support does not add a new experiment or erase primary disagreements. [ESME-S029; ESME-S060; ESME-S061]

**ESME-DEP04.** Refactoring studies answer different questions; S020 explicitly replicates/differentiates earlier work. Survey perception, metrics and bug association are not interchangeable outcomes. [ESME-S020; ESME-S021; ESME-S022]

**ESME-DEP05.** APR research and deployment accounts; S067 retrospective reuses earlier GenProg and SapFix accounts. Retrospective and deployment article are not independent demonstrations of the same outcome. [ESME-S024; ESME-S055; ESME-S065; ESME-S067]

**ESME-DEP06.** METR programme, returning participants, changed design and separate selected survey. Do not pool causal RCT, biased follow-up and subjective survey as replications or a single effect. [ESME-S025; ESME-S033; ESME-S034]

**ESME-DEP07.** SWE-bench ecosystem and overlapping evaluation artefacts. Repeated critique of common tasks is not independent sampling of all software maintenance. [ESME-S026; ESME-S027]

**ESME-DEP08.** Real-bug benchmark lineage including Defects4J is reused across testing/repair research. Different experimental units and subsets do not establish independent bug populations; exact task overlap is not fully mapped. [ESME-S052; ESME-S057; ESME-S062]

**ESME-DEP09.** Original self-report study and replication/extension within one work. Original wasted-time percentage, fraction of tasks affected and time within affected tasks have different denominators; never pool. [ESME-S032]

**ESME-DEP10.** Original/revised practitioner explanation and a related selected case. Changed edition preserves changed mechanism; repetition is not causal replication. [ESME-S035; ESME-S036; ESME-S037]

**ESME-DEP11.** 96 of 99 units reused from earlier studies. Independent technique comparison does not mean independent case population. [ESME-S044]

**ESME-DEP12.** TravisTorrent and Siemens are reusable benchmark families, respectively. Many reports based on the same family cannot be assumed statistically independent; these two families are not claimed identical. [ESME-S058; ESME-S066]

### Source register and inspected locators

The following register is citation-ready but does not replace the richer machine-readable source table, which includes outcome-specific empirical profiles and source dependence. “Full text” means the relevant inspected sections were accessible, not that every word or every cited underlying work was read.

#### ESME-S001 — Software engineering — Software life cycle processes — Maintenance

**Author or organisation.** ISO/IEC/IEEE

**Date.** 2022-01

**Version or edition.** 14764:2022, edition 3

**URL or DOI.** https://www.iso.org/standard/80710.html

**Source class.** Issuing-body standard catalogue

**Access date and level.** 2026-09-06; OFFICIAL_SCOPE_AND_EDITION_ONLY

**Inspected locators.** Official scope and edition-history panels

**Supported inspection.** Edition 3 includes iterative maintenance and disposal; distinguishes maintenance from operational administration.

**Evidence roles.** STANDARD_OR_GUIDANCE_REQUIREMENT; DEFINITION_OR_TAXONOMY

**Limits.** Paid normative text not inspected; no clause-level compliance claims.

#### ESME-S002 — Guide to the Software Engineering Body of Knowledge, Version 3.0

**Author or organisation.** IEEE Computer Society; Pierre Bourque and Richard E. Fairley (eds.)

**Date.** 2014

**Version or edition.** Version 3.0

**URL or DOI.** https://cs.fit.edu/~kgallagher/Schtick/Serious/SWEBOKv3.pdf

**Source class.** Professional body guide

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Chapter 5 Software Maintenance, including printed p. 5-4 classification (PDF p. 107, visual inspection); Chapter 6 Software Configuration Management

**Supported inspection.** Maintenance and configuration-management scope and process concepts.

**Evidence roles.** STANDARD_OR_GUIDANCE_REQUIREMENT; DEFINITION_OR_TAXONOMY

**Limits.** V3 is not the current edition; not evidence of comparative benefit.

#### ESME-S003 — An Overview of the SWEBOK Guide

**Author or organisation.** Hironori Washizaki / SEBoK

**Date.** 2024

**Version or edition.** Online overview of V4

**URL or DOI.** https://sebokwiki.org/wiki/An_Overview_of_the_SWEBOK_Guide

**Source class.** Guide-author overview

**Access date and level.** 2026-09-06; FULL_WEB_PAGE_TARGETED

**Inspected locators.** Knowledge area 7: Software Maintenance; V4 overview

**Supported inspection.** Maintenance encompasses pre-delivery transition preparation and post-delivery support.

**Evidence roles.** DEFINITION_OR_TAXONOMY

**Limits.** Online overview, not the full V4 guide. Revision date of mutable page must not be confused with original guide publication.

#### ESME-S004 — The dimensions of maintenance

**Author or organisation.** E. Burton Swanson

**Date.** 1976

**Version or edition.** ICSE 1976

**URL or DOI.** https://dl.acm.org/doi/10.5555/800253.807723

**Source class.** Founding conference paper

**Access date and level.** 2026-09-06; BIBLIOGRAPHY_ONLY_ACCESS_FAILED

**Inspected locators.** Bibliographic title, author, ICSE 2, pp. 492–497; original body inaccessible. Historical attribution is corroborated through S005 and S002, not from an unread page.

**Supported inspection.** Historical anchor for corrective/adaptive/perfective classification, corroborated by later inspected sources.

**Evidence roles.** HISTORICAL_PROVENANCE

**Limits.** ACM and institutional PDF attempts failed. No claim of reading original methods or body.

#### ESME-S005 — Guidance on Software Maintenance

**Author or organisation.** Roger J. Martin and Wilma M. Osborne; National Bureau of Standards

**Date.** 1983-12

**Version or edition.** NBS SP 500-106

**URL or DOI.** https://nvlpubs.nist.gov/nistpubs/Legacy/SP/nbsspecialpublication500-106.pdf

**Source class.** Government technical guidance

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Title and abstract; taxonomy and management sections; bibliography SWAN76

**Supported inspection.** Contemporaneous technical and management treatment of maintenance.

**Evidence roles.** HISTORICAL_PROVENANCE; STANDARD_OR_GUIDANCE_REQUIREMENT

**Limits.** Guidance is not a controlled effectiveness evaluation; original date is 1983, not digitisation.

#### ESME-S006 — Types of software evolution and software maintenance

**Author or organisation.** Ned Chapin; Joanne E. Hale; Khaled M. Khan; Juan F. Ramil; Wui-Gee Tan

**Date.** 2001

**Version or edition.** JSME 13:3–30; DOI 10.1002/smr.220

**URL or DOI.** https://onlinelibrary.wiley.com/doi/abs/10.1002/smr.220

**Source class.** Journal taxonomy paper

**Access date and level.** 2026-09-06; ABSTRACT_AND_REFERENCES

**Inspected locators.** Abstract; bibliography

**Supported inspection.** Refines maintenance/evolution classification using evidence and a decision tree.

**Evidence roles.** DEFINITION_OR_TAXONOMY; HISTORICAL_PROVENANCE

**Limits.** Full body inaccessible; omitted class-level details not inferred.

#### ESME-S007 — Assessing the reliability of developers’ classification of change tasks: A field experiment

**Author or organisation.** Hans Christian Benestad

**Date.** 2008

**Version or edition.** Simula technical report 12-2008

**URL or DOI.** https://web-backend.simula.no/sites/default/files/publications/Simula.SE.327.pdf

**Source class.** Empirical technical report

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Study design pp. 2–3; PDF p. 5 reliability table inspected visually; discussion

**Supported inspection.** Motivation labels are subject to inter-rater disagreement.

**Evidence roles.** EMPIRICAL_COMPARISON; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** Eight developers in one setting; comparison of classification reliability, not business value.

#### ESME-S008 — A model of large program development

**Author or organisation.** L. A. Belady and M. M. Lehman

**Date.** 1976

**Version or edition.** IBM Systems Journal 15(3):225–252

**URL or DOI.** https://cseweb.ucsd.edu/~wgg/CSE218/BeladyModel-10.1.1.86.9200.pdf

**Source class.** Founding empirical/modelling paper

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Printed p. 229 scope; growth discussion; resource model and concluding limits

**Supported inspection.** OS/360 observations motivate models of evolving large programmes; consolidation and shrinkage are possible.

**Evidence roles.** HISTORICAL_PROVENANCE; FIELD_OR_DEPLOYMENT_EVIDENCE; FORMAL_OR_THEORETICAL_RESULT

**Limits.** One system/environment over more than twenty releases and twelve years; correlated measures do not establish universal causation.

#### ESME-S009 — Programs, Life Cycles, and Laws of Software Evolution

**Author or organisation.** M. M. Lehman

**Date.** 1980

**Version or edition.** Proceedings IEEE 68(9):1060–1076

**URL or DOI.** https://users.ece.utexas.edu/~perry/education/SE-Intro/lehman.pdf

**Source class.** Founding conceptual paper

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Printed pp. 1061–1063 S/P/E distinctions; laws discussion

**Supported inspection.** E-type software is embedded in changing human activity; S/P/E distinctions delimit arguments.

**Evidence roles.** HISTORICAL_PROVENANCE; DEFINITION_OR_TAXONOMY; FORMAL_OR_THEORETICAL_RESULT

**Limits.** Taxonomy and empirical programme, not an unconditional physical theorem.

#### ESME-S010 — Laws of Software Evolution Revisited

**Author or organisation.** M. M. Lehman

**Date.** 1996

**Version or edition.** EWSPT 1996; author manuscript dated 1997-01-21

**URL or DOI.** https://www.cs.kent.edu/~jmaletic/cs63902/Papers/Lehman96.pdf

**Source class.** Conceptual research paper

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Sections 1–4; eight-law formulations

**Supported inspection.** Extends the evolution programme towards feedback and explicitly discusses the meaning and scope of laws.

**Evidence roles.** HISTORICAL_PROVENANCE; FORMAL_OR_THEORETICAL_RESULT

**Limits.** Inspected manuscript footer 21 January 1997; conference work 1996. Law formulations are not mandatory prescriptions.

#### ESME-S011 — Evolution in Open Source Software: A Case Study

**Author or organisation.** Michael W. Godfrey and Qiang Tu

**Date.** 2000

**Version or edition.** ICSM 2000

**URL or DOI.** https://plg2.cs.uwaterloo.ca/~migod/papers/2000/icsm00.pdf

**Source class.** Empirical conference paper

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Abstract; Linux whole-system/subsystem growth analysis; discussion

**Supported inspection.** Linux exhibits growth patterns that complicate a simple transfer from proprietary-system observations.

**Evidence roles.** EMPIRICAL_COMPARISON; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** Single project; source size, subsystem mix and system boundary matter. Not a random sample of open source.

#### ESME-S012 — Reverse engineering and design recovery: a taxonomy

**Author or organisation.** Elliot J. Chikofsky and James H. Cross II

**Date.** 1990

**Version or edition.** IEEE Software 7(1):13–17; DOI 10.1109/52.43044

**URL or DOI.** https://www.ifi.uzh.ch/dam/jcr:00000000-2f41-7b40-ffff-ffffdc0b3b5e/chikofsky90.pdf

**Source class.** Taxonomy paper

**Access date and level.** 2026-09-06; PAGE_IMAGES_INSPECTED

**Inspected locators.** Printed pp. 14–16; taxonomy definitions and objectives

**Supported inspection.** Reverse engineering analyses without changing the subject; redocumentation, design recovery, restructuring and reengineering have distinct scopes.

**Evidence roles.** HISTORICAL_PROVENANCE; DEFINITION_OR_TAXONOMY

**Limits.** Targeted scanned pages, not a measured benefit study.

#### ESME-S013 — Program Slicing

**Author or organisation.** Mark Weiser

**Date.** 1981

**Version or edition.** ICSE 1981

**URL or DOI.** https://cse.msu.edu/~cse870/Public/Homework/SS2003/HW5/p439-weiser.pdf

**Source class.** Founding formal/empirical conference paper

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Definition and correctness discussion pp. 1–3; flow-analysis construction

**Supported inspection.** Slicing restricts attention to a criterion; practical conservative analysis differs from unattainable minimal general slices.

**Evidence roles.** HISTORICAL_PROVENANCE; FORMAL_OR_THEORETICAL_RESULT

**Limits.** Guarantees depend on the stated language/termination model; not every dependency is modelled.

#### ESME-S014 — Program Comprehension During Software Maintenance and Evolution

**Author or organisation.** Anneliese von Mayrhauser and A. Marie Vans

**Date.** 1995

**Version or edition.** Computer 28(8):44–55

**URL or DOI.** https://www.cs.kent.edu/~jmaletic/cs63902/Papers/ProgramComprehension/von_mayrhauser-1995.pdf

**Source class.** Cognitive-model review and synthesis

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Cognitive-model overview; integrated-model discussion

**Supported inspection.** Comprehension involves interacting top-down and bottom-up processes, not just extracting a static database.

**Evidence roles.** DEFINITION_OR_TAXONOMY; RESEARCHER_INTERPRETATION

**Limits.** Model synthesis is not evidence that one universal workflow dominates.

#### ESME-S015 — Questions Programmers Ask During Software Evolution Tasks

**Author or organisation.** Jonathan Sillito; Gail C. Murphy; Kris De Volder

**Date.** 2006

**Version or edition.** FSE 2006; DOI 10.1145/1181775.1181779

**URL or DOI.** https://www.cs.ubc.ca/~murphy/papers/other/asking-answering-fse06.pdf

**Source class.** Qualitative empirical conference paper

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Two study designs; catalogue of 44 questions; discussion

**Supported inspection.** Maintenance questions range from focal entities to connected subgraphs and consequences of proposed changes.

**Evidence roles.** FIELD_OR_DEPLOYMENT_EVIDENCE

**Limits.** Two qualitative settings; frequency and catalogue are not universal tool requirements.

#### ESME-S016 — The Nature of Impact Analysis, in Software Change Impact Analysis

**Author or organisation.** Shawn A. Bohner and Robert S. Arnold

**Date.** 1996

**Version or edition.** IEEE Computer Society Press, 1996

**URL or DOI.** https://catalogimages.wiley.com/images/db/pdf/0818673842.excerpt.pdf

**Source class.** Edited-volume introductory chapter

**Access date and level.** 2026-09-06; PUBLISHER_EXCERPT_TARGETED

**Inspected locators.** Chapter 1, The Nature of Impact Analysis

**Supported inspection.** Impact analysis relates a contemplated change to affected parts and consequences.

**Evidence roles.** DEFINITION_OR_TAXONOMY

**Limits.** Excerpt also contains reprinted material; only identified introductory chapter attributed here.

#### ESME-S017 — Mining Version Histories to Guide Software Changes

**Author or organisation.** Thomas Zimmermann; Peter Weißgerber; Stephan Diehl; Andreas Zeller

**Date.** 2005

**Version or edition.** IEEE TSE 31(6):429–445

**URL or DOI.** https://thomas-zimmermann.com/publications/files/zimmermann-tse-2005.pdf

**Source class.** Empirical tool paper

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** ROSE mechanism; evaluation; section 11 future work

**Supported inspection.** Historical association rules suggest possible additional changes; actual co-change is not intended dependency.

**Evidence roles.** EMPIRICAL_COMPARISON; IMPLEMENTATION_SEMANTICS

**Limits.** Historical-data selection and future shifts limit prediction; same programme as earlier ROSE work, not independent replication.

#### ESME-S018 — Refactoring Object-Oriented Frameworks

**Author or organisation.** William F. Opdyke

**Date.** 1992

**Version or edition.** University of Illinois at Urbana-Champaign PhD thesis

**URL or DOI.** https://www.laputan.org/pub/papers/opdyke-thesis.pdf

**Source class.** Doctoral thesis

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Abstract; preservation/precondition chapters; Choices case discussion

**Supported inspection.** Refactorings use specified preconditions to support structure change with preservation under a language model.

**Evidence roles.** HISTORICAL_PROVENANCE; FORMAL_OR_THEORETICAL_RESULT; FIELD_OR_DEPLOYMENT_EVIDENCE

**Limits.** Targeted sections of a 206-page thesis; model assumptions do not automatically cover reflection, persistence or external observers.

#### ESME-S019 — The WyCash Portfolio Management System

**Author or organisation.** Ward Cunningham

**Date.** 1992

**Version or edition.** OOPSLA 1992 experience report; author web version

**URL or DOI.** https://c2.com/doc/oopsla92.html

**Source class.** Original experience report

**Access date and level.** 2026-09-06; AUTHOR_FULL_WEB_TEXT

**Inspected locators.** Experience-report discussion of debt and consolidation

**Supported inspection.** Debt metaphor connects expedient delivery with the cost of unconsolidated understanding.

**Evidence roles.** HISTORICAL_PROVENANCE; FIELD_OR_DEPLOYMENT_EVIDENCE

**Limits.** One programme and a metaphor, not a quantified interest model; author page dated 26 March 1992 differs from proceedings date.

#### ESME-S020 — On the Relationship between Refactoring Actions and Bugs: A Differentiated Replication

**Author or organisation.** Massimiliano Di Penta; Gabriele Bavota; Fiorella Zampetti

**Date.** 2020

**Version or edition.** Author preprint 2009.11685

**URL or DOI.** https://arxiv.org/pdf/2009.11685

**Source class.** Empirical differentiated replication

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Study design; results; validity threats

**Supported inspection.** Quantitative associations persist under change-size analysis, but manual examination partly debunks superficial links while finding genuine refactoring-related bugs.

**Evidence roles.** EMPIRICAL_COMPARISON; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** SZZ and refactoring detection can misclassify; observational analysis; relation to original research programme documented.

#### ESME-S021 — A Field Study of Refactoring Challenges and Benefits

**Author or organisation.** Miryung Kim; Thomas Zimmermann; Nachiappan Nagappan

**Date.** 2012

**Version or edition.** FSE 2012

**URL or DOI.** https://web.cs.ucla.edu/~miryung/Publications/fse2012-fieldrefactoring.pdf

**Source class.** Industrial empirical study

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Survey methods and responses; field discussion

**Supported inspection.** Practitioners report wider coordination and comprehension costs than small catalogue refactorings alone capture.

**Evidence roles.** FIELD_OR_DEPLOYMENT_EVIDENCE; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** 328 Microsoft survey respondents; self-report and one employer limit causal/general benefit inference.

#### ESME-S022 — Toward Understanding the Impact of Refactoring on Program Comprehension

**Author or organisation.** Giulia Sellitto; Emanuele Iannone; Zadia Codabux; Valentina Lenarduzzi; Andrea De Lucia; Fabio Palomba; Filomena Ferrucci

**Date.** 2022

**Version or edition.** SANER 2022

**URL or DOI.** https://giuliasellitto7.github.io/pdf/Sellitto-SANER2022-Toward-Understanding-the-Impact-of-Refactoring-on-Program-Comprehension.pdf

**Source class.** Empirical proxy-measure study

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Study design; metric outcomes; validity threats

**Supported inspection.** Refactoring effects need operation-specific interpretation; readability proxies are not measured future maintenance savings.

**Evidence roles.** EMPIRICAL_COMPARISON; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** 156 projects and eight metrics; no direct human-comprehension experiment inferred from metric changes.

#### ESME-S023 — An Empirical Study of Regression Test Selection Techniques

**Author or organisation.** Todd L. Graves; Mary Jean Harrold; Jung-Min Kim; Adam Porter; Gregg Rothermel

**Date.** 2001

**Version or edition.** ACM TOSEM 10(2)

**URL or DOI.** https://www.cs.umd.edu/users/aporter/Docs/p184-graves.pdf

**Source class.** Comparative empirical paper

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Cost model; subjects and experimental design; DejaVu safety discussion

**Supported inspection.** Selection benefit includes analysis, execution and validation cost; safety is relative to an existing suite and model assumptions.

**Evidence roles.** EMPIRICAL_COMPARISON; FORMAL_OR_THEORETICAL_RESULT

**Limits.** Small experimental programmes and fault models limit transfer; safe selection does not repair a weak oracle.

#### ESME-S024 — An Analysis of Patch Plausibility and Correctness for Generate-and-Validate Patch Generation Systems

**Author or organisation.** Zichao Qi; Fan Long; Sara Achour; Martin Rinard

**Date.** 2015

**Version or edition.** ISSTA 2015; DOI 10.1145/2771783.2771791

**URL or DOI.** https://people.csail.mit.edu/rinard/paper/issta15.pdf

**Source class.** Adversarial empirical repair analysis

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Abstract; experimental design; patch analysis and threats

**Supported inspection.** Some reported repairs fail supplied tests; many plausible patches are semantically wrong. Deletion baseline challenges apparent sophistication.

**Evidence roles.** EMPIRICAL_COMPARISON; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** Specific systems, benchmark and availability; plausible versus correct adjudication involves human interpretation.

#### ESME-S025 — Measuring the Impact of Early-2025 AI on Experienced Open-Source Developer Productivity

**Author or organisation.** Joel Becker; Nate Rush; Beth Barnes; David Rein

**Date.** 2025-07-10

**Version or edition.** arXiv 2507.09089

**URL or DOI.** https://arxiv.org/pdf/2507.09089

**Source class.** Randomised field study

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Abstract; randomisation/design; primary outcome; limitations

**Supported inspection.** AI access increased completion time in the evaluated experienced-maintainer setting, despite perceived acceleration.

**Evidence roles.** EMPIRICAL_COMPARISON; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** Early-2025 tools, selected experienced developers, mature familiar repositories; no automatic inference to other people or 2026 tools.

#### ESME-S026 — Are “Solved Issues” in SWE-bench Really Solved Correctly? An Empirical Study

**Author or organisation.** You Wang; Michael Pradel; Zhongxin Liu

**Date.** 2025-09-09

**Version or edition.** arXiv 2503.15223v2; v1 dated 2025-03-19

**URL or DOI.** https://arxiv.org/html/2503.15223v2

**Source class.** Benchmark-validity empirical study

**Access date and level.** 2026-09-06; FULL_HTML_TARGETED

**Inspected locators.** PatchDiff design; evaluation; adjudication and limitations

**Supported inspection.** Reported benchmark success can disagree with developer tests or reference-patch behaviour.

**Evidence roles.** EMPIRICAL_COMPARISON; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** Behavioural difference from reference is not by itself incorrectness; common SWE-bench data do not create independent deployment evidence.

#### ESME-S027 — Why SWE-bench Verified no longer measures frontier coding capabilities

**Author or organisation.** OpenAI

**Date.** 2026-02-23

**Version or edition.** Dated evaluator report

**URL or DOI.** https://openai.com/index/why-we-no-longer-evaluate-swe-bench-verified/

**Source class.** Primary evaluator investigation

**Access date and level.** 2026-09-06; FULL_WEB_TEXT_TARGETED

**Inspected locators.** Audit sampling; overly narrow tests; contamination examples

**Supported inspection.** Audit found flawed tests in a selected difficult subset and contamination evidence.

**Evidence roles.** CRITICISM_OR_NEGATIVE_EVIDENCE; FIELD_OR_DEPLOYMENT_EVIDENCE

**Limits.** 59.4% pertains to audited subset (27.6% of dataset), not all tasks; interested vendor source, not independent superiority evidence for another benchmark.

#### ESME-S028 — ICSME 2026 Research Track

**Author or organisation.** ICSME 2026 programme organisers

**Date.** 2026

**Version or edition.** 2026 conference programme

**URL or DOI.** https://conf.researchr.org/track/icsme-2026/icsme-2026-papers

**Source class.** Official research-community programme

**Access date and level.** 2026-09-06; FULL_WEB_PAGE_TARGETED

**Inspected locators.** Call scope; programme/date information

**Supported inspection.** Contemporary scope includes human, non-code, AI-enabled-system and LLM-assisted maintenance.

**Evidence roles.** DEFINITION_OR_TAXONOMY

**Limits.** Conference is forthcoming relative to 6 September cutoff; programme membership is not effectiveness evidence.

#### ESME-S029 — The evolution of the laws of software evolution: A discussion based on a systematic literature review

**Author or organisation.** Israel Herraiz; Daniel Rodriguez; Gregorio Robles; Jesus M. Gonzalez-Barahona

**Date.** 2013

**Version or edition.** ACM Computing Surveys 46(2); DOI 10.1145/2543581.2543595

**URL or DOI.** https://oa.upm.es/20813/1/herraiz_csur.pdf

**Source class.** Systematic literature review

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Review methods; discussion and conclusions, especially manuscript pp. 20–22

**Supported inspection.** Reports heterogeneous findings and the importance of population and measurement choices.

**Evidence roles.** HISTORICAL_PROVENANCE; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** Review is an evidence map, not another independent replication of the cases it surveys.

#### ESME-S030 — RCS — A System for Version Control

**Author or organisation.** Walter F. Tichy

**Date.** After 1985; exact archive revision date unspecified

**Version or edition.** Archived revision; earlier SPE 15(7):637–654, DOI 10.1002/spe.4380150703

**URL or DOI.** https://docs-archive.freebsd.org/44doc/psd/13.rcs/paper.pdf

**Source class.** Author system description in documentation archive

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Opening definition and earlier-publication footnote; revision/configuration selection sections

**Supported inspection.** Revision ancestry and configuration selection address coherent versions of evolving artefacts.

**Evidence roles.** HISTORICAL_PROVENANCE; IMPLEMENTATION_SEMANTICS

**Limits.** Archive explicitly identifies an earlier July 1985 SPE version; this is not silently treated as identical to it. No current RCS recommendation.

#### ESME-S031 — Legacy Information System Migration: A Brief Review of Problems, Solutions and Research Issues

**Author or organisation.** Jesus Bisbal; Deirdre Lawless; Bing Wu; Jane Grimson

**Date.** 1999

**Version or edition.** TCD-CS-1999-38

**URL or DOI.** https://publications.scss.tcd.ie/tech-reports/reports.99/TCD-CS-1999-38.pdf

**Source class.** Research review with authors’ migration approach

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Sections 2.1–2.3; Chicken Little and Butterfly comparisons

**Supported inspection.** Migration alternatives differ in coexistence, gateway, cutover and data-conversion assumptions.

**Evidence roles.** DEFINITION_OR_TAXONOMY; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** Review descriptions do not establish comparative causal success; original Brodie/Stonebraker monograph not inspected.

#### ESME-S032 — Software Developer Productivity Loss Due to Technical Debt — A replication and extension study examining developers’ development work

**Author or organisation.** Terese Besker; Antonio Martini; Jan Bosch

**Date.** 2019

**Version or edition.** Identified author or publisher version

**URL or DOI.** https://research.chalmers.se/publication/511450/file/511450_Fulltext.pdf

**Source class.** Empirical replication and extension

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Study design; results; section 5.7.2; validity threats section 7

**Supported inspection.** Reported debt-related wasted work depends on task category, setting and denominator.

**Evidence roles.** EMPIRICAL_COMPARISON; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** Original self-reported time fraction and extension affected-task fraction cannot be pooled. No causal benefit estimate for repayment.

#### ESME-S033 — We are Changing our Developer Productivity Experiment Design

**Author or organisation.** METR

**Date.** 2026-02-24

**Version or edition.** Dated primary report

**URL or DOI.** https://metr.org/blog/2026-02-24-uplift-update/

**Source class.** Primary experimental follow-up and limitations report

**Access date and level.** 2026-09-06; FULL_WEB_TEXT_TARGETED

**Inspected locators.** Follow-up design; selection issues; estimates and interpretation

**Supported inspection.** Later study recruitment and task selection compromise confident current-tool effect estimation.

**Evidence roles.** EMPIRICAL_COMPARISON; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** Same research programme as ESME-S025; not an independent replication and not proof that all 2026 tools help or harm.

#### ESME-S034 — Measuring the Self-Reported Impact of Early-2026 AI on Technical Worker Productivity

**Author or organisation.** METR

**Date.** 2026-05-11

**Version or edition.** Dated primary report

**URL or DOI.** https://metr.org/blog/2026-05-11-ai-usage-survey/

**Source class.** Primary worker survey

**Access date and level.** 2026-09-06; FULL_WEB_TEXT_TARGETED

**Inspected locators.** Sample and survey design; speed versus value; limitations

**Supported inspection.** Reported speed and delivered value are different quantities.

**Evidence roles.** FIELD_OR_DEPLOYMENT_EVIDENCE; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** 349 technical workers; selected self-reports are not objective causal measurements; same evaluator organisation as S025/S033.

#### ESME-S035 — Original Strangler Fig Application

**Author or organisation.** Martin Fowler

**Date.** 2004-06-29; later editorial annotations identified

**Version or edition.** Original article with explicitly later annotations

**URL or DOI.** https://martinfowler.com/bliki/OriginalStranglerFigApplication.html

**Source class.** Original practitioner conceptual account

**Access date and level.** 2026-09-06; FULL_WEB_TEXT_TARGETED

**Inspected locators.** Main 2004 text; 2019 naming annotation; 2024 editorial link

**Supported inspection.** Incremental displacement can expose and preserve otherwise undocumented interactions.

**Evidence roles.** HISTORICAL_PROVENANCE; FIELD_OR_DEPLOYMENT_EVIDENCE

**Limits.** Practitioner metaphor and case discussion, not invention of every incremental migration method. Later annotations are not 2004 evidence.

#### ESME-S036 — Strangler Fig Application

**Author or organisation.** Martin Fowler

**Date.** 2024-08-22

**Version or edition.** Revised 2024 article

**URL or DOI.** https://martinfowler.com/bliki/StranglerFigApplication.html

**Source class.** Revised practitioner conceptual account

**Access date and level.** 2026-09-06; FULL_WEB_TEXT_TARGETED

**Inspected locators.** Revised definition; relationship to original article

**Supported inspection.** Current articulation of incremental displacement and its boundaries.

**Evidence roles.** DEFINITION_OR_TAXONOMY

**Limits.** Distinct revision, same author and programme as S035; not independent field evidence.

#### ESME-S037 — Strangler Fig for Mobile Apps

**Author or organisation.** Matthew Foster; John Mikel Amiel Regida

**Date.** 2024-11-05

**Version or edition.** Rendered publication date 5 November 2024

**URL or DOI.** https://martinfowler.com/articles/strangler-fig-mobile-apps.html

**Source class.** Practitioner deployment case

**Access date and level.** 2026-09-06; FULL_WEB_TEXT_TARGETED

**Inspected locators.** Microapp/native bridge design; integration and results discussion

**Supported inspection.** A bounded mobile coexistence design illustrates both migration utility and bridge costs.

**Evidence roles.** FIELD_OR_DEPLOYMENT_EVIDENCE

**Limits.** One consultancy account with concurrent organisational changes; no controlled comparison and no general cycle-time effect inferred.

#### ESME-S038 — Postmortem of database outage of January 31

**Author or organisation.** GitLab engineering

**Date.** 2017-02-10

**Version or edition.** Dated postmortem

**URL or DOI.** https://about.gitlab.com/blog/postmortem-of-database-outage-of-january-31/

**Source class.** Primary incident postmortem

**Access date and level.** 2026-09-06; FULL_WEB_TEXT_TARGETED

**Inspected locators.** Backup failure; recovery timeline; data reconciliation and ID sequence handling

**Supported inspection.** Recovering repository code did not restore all database state; backup compatibility and recovery procedures mattered.

**Evidence roles.** INCIDENT_OR_FAILURE_EVIDENCE

**Limits.** Incident occurred 31 January 2017. This is not a migration experiment or a general incident-frequency estimate.

#### ESME-S039 — Information Technology: FBI Is Building Management Capabilities Essential to Successful System Deployments, but Challenges Remain

**Author or organisation.** United States Government Accountability Office

**Date.** 2005-09-14

**Version or edition.** GAO-05-1014T

**URL or DOI.** https://www.gao.gov/assets/a112158.html

**Source class.** Independent government project assessment

**Access date and level.** 2026-09-06; FULL_HTML_TARGETED

**Inspected locators.** Summary; Virtual Case File lessons; requirements, management and organisational capabilities

**Supported inspection.** Replacement difficulty cannot be reduced to the age or language of the legacy system.

**Evidence roles.** INCIDENT_OR_FAILURE_EVIDENCE; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** Historical VCF assessment, not a current FBI-system evaluation; several organisational causes coexist.

#### ESME-S040 — Why Modern Open Source Projects Fail

**Author or organisation.** Jailton Coelho; Marco Tulio Valente

**Date.** 2017

**Version or edition.** arXiv 1707.02327; FSE 2017

**URL or DOI.** https://arxiv.org/pdf/1707.02327

**Source class.** Qualitative empirical study

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Methods; section 3, especially finished projects; threats

**Supported inspection.** Some apparently inactive projects were considered finished by maintainers rather than failed.

**Evidence roles.** FIELD_OR_DEPLOYMENT_EVIDENCE; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** 104 responding project maintainers; 17 described finished projects. Selection and self-report limit population inference; inactivity is not itself failure.

#### ESME-S041 — An Empirical Comparison of Dependency Network Evolution in Seven Software Packaging Ecosystems

**Author or organisation.** Alexandre Decan; Tom Mens; Philippe Grosjean

**Date.** 2017 preprint; 2019 journal volume

**Version or edition.** Author preprint; EMSE 24, DOI 10.1007/s10664-017-9589-y

**URL or DOI.** https://arxiv.org/pdf/1710.04936

**Source class.** Comparative ecosystem mining study

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Data selection; network metrics; results and validity threats

**Supported inspection.** Dependency concentration and transitive structure affect potential change reach.

**Evidence roles.** EMPIRICAL_COMPARISON

**Limits.** Declared package dependency is not observed runtime use or realised failure; ecosystems and observation windows differ.

#### ESME-S042 — Hidden Technical Debt in Machine Learning Systems

**Author or organisation.** D. Sculley; Gary Holt; Daniel Golovin; Eugene Davydov; Todd Phillips; Dietmar Ebner; Vinay Chaudhary; Michael Young; Jean-François Crespo; Dan Dennison

**Date.** 2015

**Version or edition.** NeurIPS 2015

**URL or DOI.** https://papers.neurips.cc/paper/5656-hidden-technical-debt-in-machine-learning-systems.pdf

**Source class.** Primary industrial conceptual/experience paper

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Sections on entanglement, data dependencies, feedback, configuration and external change

**Supported inspection.** Extends the debt lens to learned systems and their wider data/feedback dependencies.

**Evidence roles.** FIELD_OR_DEPLOYMENT_EVIDENCE; HISTORICAL_PROVENANCE

**Limits.** Documented import into ML; experience-grounded mechanisms, not a controlled universal debt-cost estimate.

#### ESME-S043 — “We Feel Like We’re Winging It”: A Study on Navigating Open-Source Dependency Abandonment

**Author or organisation.** Courtney E. Miller; Christian Kästner; Bogdan Vasilescu

**Date.** 2023

**Version or edition.** FSE 2023 author preprint; DOI 10.1145/3611643.3616293

**URL or DOI.** https://courtney-e-miller.github.io/static/media/WeFeelLikeWereWingingIt.dc3c76d3b3c2d12f4fee.pdf

**Source class.** Qualitative empirical study

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Interview methods; sections 4–7; alternatives and maintainer burden

**Supported inspection.** Abandonment need not immediately break software; responses have differing capability and workload demands.

**Evidence roles.** FIELD_OR_DEPLOYMENT_EVIDENCE; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** 33 interviews; qualitative explanations, not estimates of abandonment prevalence or best-response success rates.

#### ESME-S044 — Detecting Semantic Conflicts using Static Analysis

**Author or organisation.** Galileu Santos de Jesus; Paulo Borba; Rodrigo Bonifácio; Matheus Barbosa de Oliveira

**Date.** 2023-10-06

**Version or edition.** arXiv 2310.04269v1

**URL or DOI.** https://arxiv.org/html/2310.04269v1

**Source class.** Primary tool/evaluation preprint

**Access date and level.** 2026-09-06; FULL_HTML_TARGETED

**Inspected locators.** Sections 3–5; 4.1 scenario selection; 5.3 threats

**Supported inspection.** Static interference detection trades recall, precision and analysis cost; interference need not contradict intended joint behaviour.

**Evidence roles.** EMPIRICAL_COMPARISON; IMPLEMENTATION_SEMANTICS; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** 99 units from 54 merge scenarios in 39 Java projects; 96 units reused from earlier work. Excludes unsupported and unbuildable cases. Header contains publication placeholders, so treated as dated preprint.

#### ESME-S045 — PEP 387 — Backwards Compatibility Policy

**Author or organisation.** Python project / PEP 387 authors and maintainers

**Date.** Mutable policy, accessed 2026-09-06

**Version or edition.** Online policy as accessed

**URL or DOI.** https://peps.python.org/pep-0387/

**Source class.** Project policy specification

**Access date and level.** 2026-09-06; FULL_WEB_TEXT_TARGETED

**Inspected locators.** Basic policy; public API scope; making incompatible changes; soft deprecation

**Supported inspection.** Compatibility and deprecation expectations depend on declared public behaviour and authorised exceptions.

**Evidence roles.** STANDARD_OR_GUIDANCE_REQUIREMENT; IMPLEMENTATION_SEMANTICS

**Limits.** Python-specific policy, not proof every implementation obeys it or every ecosystem should adopt its time periods.

#### ESME-S046 — Definition of reproducible builds

**Author or organisation.** Reproducible Builds project

**Date.** Undated mutable definition

**Version or edition.** Online definition as accessed

**URL or DOI.** https://reproducible-builds.org/docs/definition/

**Source class.** Project technical definition

**Access date and level.** 2026-09-06; FULL_WEB_TEXT_TARGETED

**Inspected locators.** Definition; build environment; artefacts and verification

**Supported inspection.** Reproduction is equality of specified artefacts under specified source, environment and instructions.

**Evidence roles.** DEFINITION_OR_TAXONOMY; IMPLEMENTATION_SEMANTICS

**Limits.** Artifact reproducibility does not establish correct requirements or safe behaviour.

#### ESME-S047 — Quantifying and mitigating turnover-induced knowledge loss: Case studies of Chrome and a project at Avaya

**Author or organisation.** Peter C. Rigby; Yue Cai Zhu; Samuel M. Donadelli; Audris Mockus

**Date.** 2016

**Version or edition.** ICSE 2016; DOI 10.1145/2884781.2884851

**URL or DOI.** https://users.encs.concordia.ca/~pcr/paper/Rigby2016ICSE.pdf

**Source class.** Empirical modelling and case study

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Knowledge-loss model; case designs; mitigation and limitations

**Supported inspection.** Knowledge concentration and turnover create continuity risks that file-history models can partially estimate.

**Evidence roles.** EMPIRICAL_COMPARISON; FIELD_OR_DEPLOYMENT_EVIDENCE

**Limits.** Contribution history is a proxy for knowledge; two cases do not show documentation can replace expertise.

#### ESME-S048 — Managing Technical Debt in Software Engineering (Dagstuhl Seminar 16162)

**Author or organisation.** Paris Avgeriou; Philippe Kruchten; Ipek Ozkaya; Carolyn Seaman (eds.)

**Date.** 2016

**Version or edition.** Dagstuhl Reports 6(4):110–138; DOI 10.4230/DagRep.6.4.110; event 17–22 April 2016

**URL or DOI.** https://d-nb.info/1365181391/34

**Source class.** Research seminar report

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Definition and working-group discussions; costs and prioritisation

**Supported inspection.** Debt models distinguish obligations and contingent future costs; opportunity costs complicate simple accounting.

**Evidence roles.** DEFINITION_OR_TAXONOMY; RESEARCHER_INTERPRETATION

**Limits.** Seminar consensus and research proposals, not field-wide consensus or validated financial formulas.

#### ESME-S049 — Manifesto from Dagstuhl Perspectives Workshop 24452 — Reframing Technical Debt

**Author or organisation.** Participants in Dagstuhl Perspectives Workshop 24452

**Date.** 2025-05-19

**Version or edition.** arXiv 2505.13009

**URL or DOI.** https://arxiv.org/pdf/2505.13009

**Source class.** Research perspectives manifesto

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Definition retained from 2016; value and prioritisation discussion; research agenda

**Supported inspection.** Recent work reframes debt assessment around value and investment rather than universal elimination.

**Evidence roles.** RESEARCHER_INTERPRETATION; DEFINITION_OR_TAXONOMY

**Limits.** Workshop held in 2024, manuscript published 2025; proposals are not newly replicated economic outcomes.

#### ESME-S050 — Software Aging

**Author or organisation.** David L. Parnas

**Date.** 1994

**Version or edition.** ICSE 1994

**URL or DOI.** https://www.ifi.uzh.ch/dam/jcr:00000000-2f41-7b40-0000-000042ae93a8/Parnas96-sw-aging.pdf

**Source class.** Conceptual and experience paper

**Access date and level.** 2026-09-06; PAGE_IMAGES_INSPECTED

**Inspected locators.** Printed pp. 279–280, introduction and two causes; section 3 scope distinction

**Supported inspection.** Distinguishes loss of environmental fit from damaging changes made without understanding.

**Evidence roles.** HISTORICAL_PROVENANCE; RESEARCHER_INTERPRETATION

**Limits.** Scanned pages inspected. Filename suggests 1996 but printed copyright/publication is 1994. Explicitly not the runtime resource-leak sense of ageing.

#### ESME-S051 — The Oracle Problem in Software Testing: A Survey

**Author or organisation.** Earl T. Barr; Mark Harman; Phil McMinn; Muzammil Shahbaz; Shin Yoo

**Date.** 2015; online 2014-11-19

**Version or edition.** IEEE TSE 41(5):507–525; DOI 10.1109/TSE.2014.2372785

**URL or DOI.** https://discovery.ucl.ac.uk/id/eprint/1471263/1/06963470.pdf

**Source class.** Scholarly survey with formal definitions

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Sections 2 and 4–7: specified, derived, implicit and human oracles

**Supported inspection.** A response is not an adequacy judgement without an oracle; partial and derived oracles have distinct limits.

**Evidence roles.** DEFINITION_OR_TAXONOMY; FORMAL_OR_THEORETICAL_RESULT; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** Survey organises underlying research, not an independent comparison of all techniques. Environmental and nonfunctional observations explicitly included.

#### ESME-S052 — Automated Program Repair, What Is It Good For? Not Absolutely Nothing!

**Author or organisation.** Hadeel Eladawy; Claire Le Goues; Yuriy Brun

**Date.** 2024

**Version or edition.** ICSE 2024; DOI 10.1145/3597503.3639095

**URL or DOI.** https://people.cs.umass.edu/brun/pubs/pubs/Eladawy24icse.pdf

**Source class.** Controlled developer study

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Abstract; experimental design; results; validity threats

**Supported inspection.** Correct suggestions helped debugging while deceptive plausible suggestions reduced success in the study.

**Evidence roles.** EMPIRICAL_COMPARISON; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** 40 developers, 160 sessions, nine real Java defects. Conditioned suggestion exposure is not a production distribution of patch correctness.

#### ESME-S053 — The PRISM Workwench: Database Schema Evolution Without Tears

**Author or organisation.** Carlo A. Curino; Hyun J. Moon; MyungWon Ham; Carlo Zaniolo

**Date.** 2009

**Version or edition.** ICDE 2009 demonstration author manuscript

**URL or DOI.** https://www.cs.ucla.edu/~zaniolo/papers/ccurino-prismworkbench-demo.pdf

**Source class.** Prototype demonstration paper

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Introduction; section III theoretical background; demonstration and conclusions

**Supported inspection.** Schema modification operators support information-loss analysis and query rewriting within a mapping model.

**Evidence roles.** IMPLEMENTATION_SEMANTICS; FORMAL_OR_THEORETICAL_RESULT

**Limits.** Demo manuscript proposes a later usability study; no general operational adoption or arbitrary rollback guarantee. Printed title spells Workwench.

#### ESME-S054 — The Software Heritage Open Science Ecosystem

**Author or organisation.** Roberto Di Cosmo; Stefano Zacchiroli

**Date.** 2023

**Version or edition.** Chapter 2, Software Ecosystems; DOI 10.1007/978-3-031-36060-2_2

**URL or DOI.** https://www.dicosmo.org/Articles/2023-SoftwareEcosystems-Book.pdf

**Source class.** Project-authored scholarly chapter

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** §2.1 and §2.1.2; opening discussion of archival scope and curation

**Supported inspection.** Archives source and history with persistent identity; preservation is distinct from curated quality and buildability.

**Evidence roles.** IMPLEMENTATION_SEMANTICS; FIELD_OR_DEPLOYMENT_EVIDENCE

**Limits.** Project account, not independent proof of reproducibility; no current corpus-size claim.

#### ESME-S055 — Finding and fixing software bugs automatically with SapFix and Sapienz

**Author or organisation.** Facebook Engineering

**Date.** 2018-09-13

**Version or edition.** Original deployment account

**URL or DOI.** https://engineering.fb.com/2018/09/13/developer-tools/finding-and-fixing-software-bugs-automatically-with-sapfix-and-sapienz/

**Source class.** Primary industrial deployment account

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Main article: patch generation, validation, and human review before landing

**Supported inspection.** Generates candidate reverts or template fixes, tests candidates, then requires human review and approval before landing. Rejection can terminate an attempted repair.

**Evidence roles.** FIELD_OR_DEPLOYMENT_EVIDENCE; IMPLEMENTATION_SEMANTICS

**Limits.** No independent comparison or complete success-rate denominator; the 2019 conference paper was not inspected.

#### ESME-S056 — An Empirical Study of Policy as Code: Adoption, Purpose, and Maintenance

**Author or organisation.** Ruben Opdebeeck; Mahmoud Alfadel; Akond Rahman; Yutaro Kashiwa; João F. Ferreira; Raula Gaikovina Kula; Coen De Roover

**Date.** 2026

**Version or edition.** MSR 2026; DOI 10.1145/3793302.3793355

**URL or DOI.** https://akondrahman.github.io/files/papers/msr26.pdf

**Source class.** Empirical conference paper

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** §3 sampling and coding; §4.3 RQ3; §5.1 implications and §5.2 threats; PDF p. 9 inspected visually

**Supported inspection.** Policy artefacts receive maintenance changes including refactoring and behavioural restrictions; artefact presence does not establish enforcement or cheapness.

**Evidence roles.** FIELD_OR_DEPLOYMENT_EVIDENCE; DEFINITION_OR_TAXONOMY

**Limits.** Selection removes many small/example projects; commit fractions are not labour or security-benefit measures. The recommendation to adopt widely is not causally established by this design.

#### ESME-S057 — Smaller Models, Unexpected Costs: Trade-offs in LLM Quantization for Automated Program Repair

**Author or organisation.** Fernando Vallecillos-Ruiz; Giordano d’Aloisio; Max Hort; Luca Traini; Antinisca Di Marco; Leon Moonen

**Date.** 2026-07-03

**Version or edition.** arXiv:2606.27205v2; original submission 2026-06-25; ICSME 2026 forthcoming at cut-off

**URL or DOI.** https://arxiv.org/html/2606.27205v2

**Source class.** Contemporary empirical preprint

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** §III experimental setup and hardware; results; §VI limitations

**Supported inspection.** Memory savings from quantisation can coexist with greater time or energy cost; aggregate pass counts can hide changed solved-instance sets.

**Evidence roles.** EMPIRICAL_COMPARISON; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** Platform-specific results; passing-test patches remain plausible rather than proved correct; leakage and run-to-run uncertainty remain. Conference event is after the cut-off.

#### ESME-S058 — A Cost-efficient Approach to Building in Continuous Integration

**Author or organisation.** Xianhao Jin; Francisco Servant

**Date.** 2020

**Version or edition.** ICSE 2020; DOI 10.1145/3377811.3380437

**URL or DOI.** https://fservant.github.io/papers/Jin_Servant_ICSE20.pdf

**Source class.** Empirical conference paper

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** §4 dataset; results; §9 skipped versus passed; §10 validity threats

**Supported inspection.** Build skipping trades resource savings for delayed failures; a skipped build must not be presented as passed.

**Evidence roles.** EMPIRICAL_COMPARISON; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** Historical build prediction is not correctness assurance; cross-validation can expose future information; builds saved are not full end-to-end cost.

#### ESME-S059 — Working Effectively with Legacy Code and AI Coding Assistant

**Author or organisation.** Michael Feathers, interviewed by Henry Suryawirawan

**Date.** 2024-10-14

**Version or edition.** Tech Lead Journal episode 195, transcript

**URL or DOI.** https://techleadjournal.dev/episodes/195/

**Source class.** Primary author interview

**Access date and level.** 2026-09-06; FULL_TRANSCRIPT_TARGETED

**Inspected locators.** Transcript: characterisation testing, legacy-code definition, temporary tests and AI discussion

**Supported inspection.** Characterisation records existing behaviour, not necessarily intended behaviour; some tests are temporary aids to understanding.

**Evidence roles.** HISTORICAL_PROVENANCE; DEFINITION_OR_TAXONOMY

**Limits.** Retrospective author testimony, not inspection of the complete 2004 book or a causal study of AI benefits. The book’s operational legacy definition is not imposed on the entire field.

#### ESME-S060 — The Linux kernel as a case study in software evolution

**Author or organisation.** Ayelet Israeli; Dror G. Feitelson

**Date.** 2010-03

**Version or edition.** Journal of Systems and Software 83(3):485–501; author version copyright 2009

**URL or DOI.** https://www.cs.huji.ac.il/w~feit/papers/LinuxEvol10JSS.pdf

**Source class.** Longitudinal empirical journal paper

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Methods and data; complexity results PDF p. 12 inspected visually; §4 discussion and conclusions

**Supported inspection.** Total complexity and average per-function complexity can move in opposite directions; different law formulations receive different support. Feedback causality is not established merely by time series.

**Evidence roles.** EMPIRICAL_COMPARISON; FIELD_OR_DEPLOYMENT_EVIDENCE; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** One evolving project; overlaps the Linux population of S011; measures are operationalisations, not uniquely determined by the laws.

#### ESME-S061 — Studying the laws of software evolution in a long-lived FLOSS project

**Author or organisation.** Jesús M. González-Barahona; Gregorio Robles; Israel Herraiz; Francisco Ortega

**Date.** 2014

**Version or edition.** Journal of Software: Evolution and Process 26:589–612; DOI 10.1002/smr.1615; online 2013

**URL or DOI.** https://www.researchgate.net/publication/259542861_Studying_the_laws_of_software_evolution_in_a_long-lived_FLOSS_project

**Source class.** Longitudinal empirical journal paper

**Access date and level.** 2026-09-06; AUTHOR_UPLOADED_FULL_TEXT_TARGETED

**Inspected locators.** Author-uploaded full article: growth phases; phase D; §9 threats and conclusions; excluding appended related-paper material

**Supported inspection.** glibc exhibits a late size plateau; growth-law interpretation depends on metric, stage and classification. A later fitness decline is hypothesised, not observed merely from that plateau.

**Evidence roles.** EMPIRICAL_COMPARISON; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** Author-uploaded text inspected; repository conversion and contributor visibility limit measurements. E-type classification is itself discussed.

#### ESME-S062 — Are Mutants a Valid Substitute for Real Faults in Software Testing?

**Author or organisation.** René Just; Darioush Jalali; Laura Inozemtseva; Michael D. Ernst; Reid Holmes; Gordon Fraser

**Date.** 2014

**Version or edition.** FSE 2014:654–665; DOI 10.1145/2635868.2635929

**URL or DOI.** https://homes.cs.washington.edu/~mernst/pubs/mutation-effectiveness-fse2014.pdf

**Source class.** Empirical conference paper

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** Study setup; real-fault and mutant comparison; §3.3 validity threats; conclusions

**Supported inspection.** Mutation detection relates to real-fault detection beyond simple coverage in the studied setting, but not every real fault is represented by the mutation operators.

**Evidence roles.** EMPIRICAL_COMPARISON; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** Automatable reproducible bugs and operator choices limit external validity; benchmark ancestry overlaps later Defects4J repair evaluations.

#### ESME-S063 — Metamorphic Testing: A New Approach for Generating Next Test Cases

**Author or organisation.** T. Y. Chen; S. C. Cheung; S. M. Yiu

**Date.** 1998

**Version or edition.** HKUST-CS98-01; digitised as arXiv:2002.12543 in 2020

**URL or DOI.** https://arxiv.org/pdf/2002.12543

**Source class.** Founding technical report

**Access date and level.** 2026-09-06; SCANNED_TEXT_TARGETED_VISUAL_INSPECTION

**Inspected locators.** PDF pp. 1 and 3 inspected visually: original date, abstract, definition and domain-knowledge relation

**Supported inspection.** Derives related executions from domain properties to address missing individual-output oracles; complements other test-selection methods.

**Evidence roles.** HISTORICAL_PROVENANCE; FORMAL_OR_THEORETICAL_RESULT

**Limits.** Illustrative theoretical method, not a universal correctness guarantee or broad comparative-effectiveness study; 2020 is digitisation, not origin.

#### ESME-S064 — Differential Testing for Variational Analyses: Experience from Developing KConfigReader

**Author or organisation.** Christian Kästner

**Date.** 2017

**Version or edition.** Author paper recounting development beginning in 2014

**URL or DOI.** https://www.cs.cmu.edu/~ckaestne/pdf/difftesting17.pdf

**Source class.** Primary tool-development experience report

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** §§1–4; conclusion and appendix: reference implementation, generated configurations, and prior influence

**Supported inspection.** Uses an existing implementation as differential reference for variational analysis; finds subtle semantics and tool defects. Per-configuration comparison is powerful but can be expensive.

**Evidence roles.** FIELD_OR_DEPLOYMENT_EVIDENCE; HISTORICAL_PROVENANCE

**Limits.** Reference agreement is not independent specification correctness; author experience is not independent replication. Large configuration spaces prevent unrestricted enumeration.

#### ESME-S065 — Automatic program repair with evolutionary computation

**Author or organisation.** Westley Weimer; Stephanie Forrest; Claire Le Goues; ThanhVu Nguyen

**Date.** 2010-05

**Version or edition.** Communications of the ACM 53(5):109–116; account of the 2009 GenProg work

**URL or DOI.** https://squareslab.github.io/papers-repo/pdfs/p109-weimer.pdf

**Source class.** Primary research paper

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** §2 representation, fitness and patch minimisation; §6 basic limitations and repair quality

**Supported inspection.** GenProg searches statement-level variants against positive/negative tests; assumes reproducible defects, useful localisation and tests encoding relevant requirements.

**Evidence roles.** HISTORICAL_PROVENANCE; IMPLEMENTATION_SEMANTICS; FORMAL_OR_THEORETICAL_RESULT

**Limits.** The original ICSE 2009 PDF fetch failed; this distinct primary 2010 account was inspected. Selected examples demonstrate feasibility, not representative general correctness or cost.

#### ESME-S066 — Test Case Prioritization: An Empirical Study

**Author or organisation.** Gregg Rothermel; Roland H. Untch; Chengyun Chu; Mary Jean Harrold

**Date.** 1999-09

**Version or edition.** ICSM 1999; not the distinct 2001 journal article

**URL or DOI.** https://courses.cs.umbc.edu/undergraduate/345/spring12/mitchell/readings/testCasePrioritization-AnEmpiricalStudy.pdf

**Source class.** Primary research paper

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** §2 prioritisation versus efficacy; §3.3–3.5 study and results; §4 threats; PDF p. 6 table/methods visually inspected

**Supported inspection.** Ordering tests can change detection speed without changing a suite’s ultimate fault-detection capability; prioritisation may not pay for a small fast suite.

**Evidence roles.** HISTORICAL_PROVENANCE; EMPIRICAL_COMPARISON; CRITICISM_OR_NEGATIVE_EVIDENCE

**Limits.** Seven small C programs with seeded faults; variation across programs and metric limits restrict transfer. Original 2001 journal retrieval failed; no claim of having read it.

#### ESME-S067 — The Evolution of Automated Software Repair

**Author or organisation.** Claire Le Goues; ThanhVu Nguyen; Stephanie Forrest; Westley Weimer

**Date.** 2025

**Version or edition.** Accepted author version; DOI 10.1109/TSE.2025.3533309; manuscript received January 2025

**URL or DOI.** https://roars.dev/pubs/le2025evolution.pdf

**Source class.** Original-researcher retrospective

**Access date and level.** 2026-09-06; FULL_TEXT_TARGETED_SECTIONS

**Inspected locators.** §I GenProg publication lineage; §II repair quality; §III use cases; §IV–V interpretations and future questions; PDF p. 2 visually inspected

**Supported inspection.** Original researchers describe GenProg’s existence-proof role, later evaluations and alternatives in human involvement. Gold-patch identity and correctness need not coincide; test-based quality remains partial.

**Evidence roles.** HISTORICAL_PROVENANCE; CRITICISM_OR_NEGATIVE_EVIDENCE; RESEARCHER_INTERPRETATION

**Limits.** Retrospective is not independent replication. Broader Darwinian analogy and speculative current adoption claims are author interpretation, not accepted historical causality or general capability evidence.

### Freeze boundary

All 74 candidates and all ten mandatory families are examined. The single unresolved primary candidate and four composition questions are researched uncertainty, not uncompleted mandatory tasks. The eight payloads are frozen as revision `ESME-2026-09-06-r1`. The manifest identifies exact bytes and checks; it inventories payloads, not itself or the enclosing ZIP. The separately reported ZIP hash is the final custody identifier. No downstream synthesis or adoption is established.
