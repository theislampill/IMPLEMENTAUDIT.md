# EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PUBLIC_DOCUMENTATION_INTAKE

Revision `ESME-2026-09-06-r1`; research cut-off **6 September 2026**. This intake supports public explanation of a research corpus. It does not certify that any host system implements the findings.

## Introduction to the established tradition

Software Maintenance and Evolution studies how existing software continues to meet useful obligations as requirements, environments, dependencies and ownership change. It includes correction, adaptation, improvement, comprehension, preservation, migration and eventual retirement—not only fixing defects after release. Its history is plural. Maintenance classifications and management guidance, Lehman and Belady’s longitudinal evolution research, comprehension and slicing, reverse engineering, configuration control, refactoring and testing address related but different problems. [ESME-S002, Chapter 5; ESME-S005, taxonomy and management; ESME-S008–ESME-S018.]

“Evolved Software Maintenance and Evolution” is the name of this report’s criticism-tested analytical composition, not an established historical school. The corpus examines **74 candidates** and preserves unfavourable and unresolved results. It links source-grounded distinctions to operating mechanisms while keeping alternatives, authority limits and evidence uncertainty visible. No other tradition’s findings are assumed by the name or grouping.

## Evolution under criticism

The field did not mature simply by adding techniques. Evolution-law studies revealed dependence on populations, phases and metrics. Refactoring research separated formal preservation, industrial terminology and uncertain practical benefit. Oracle and repair research distinguished test passage from semantic correctness. Migration work exposed gateway, reconciliation and knowledge-recovery costs. Dependency-abandonment work showed that technical need does not automatically create willing maintainers. Recent automation studies further separate plausible patches, accepted interventions and total work. [ESME-S029; ESME-S060–ESME-S061; ESME-S020–ESME-S024; ESME-S031; ESME-S043; ESME-S052.]

The synthesis therefore rejects universal growth or decay, exhaustive comprehension before every edit, guaranteed benefit from cleaner structure, age-based replacement, universal zero debt and universal human-only superiority. It treats a universal change board as ceremony rather than a general property, links golden-master preservation to the existing characterisation mechanism, and leaves general reliable unattended repository maintenance unresolved. These are analytical judgements with sources and counterarguments in the complete ledger; they are not claims that every scholar advocated the rejected caricatures.

## How the surviving parts compose

The core connects a legitimate intended difference and surviving obligations to an identifiable baseline, sufficient understanding, justified impact, appropriate evidence, authorised action and observation of consequences. A request does not prove benefit; a proof does not establish its environmental assumptions; tests do not supply a complete oracle; notification does not confer consent; generation does not confer authority; and a source revert does not restore lost data.

This is not a mandatory serial pipeline. Inquiry can revise intent; implementation can expose new dependencies; concurrent changes can invalidate prior evidence; release observations can interrupt rollout; and support or cost feedback can favour continued maintenance, migration, deliberate non-change or retirement. Richer methods are warranted by actual complexity and consequence. One capable authorised maintainer and a meaningful local check can be the smallest adequate arrangement.

Three analytical properties arise from composition: evidence must remain tied to the candidate and assumptions acted upon; temporarily coexisting versions and data states can create new obligations; and combined controls need cost and retirement judgements. These are reasoned obligations, not an empirically demonstrated universal architecture. Seven alternative configurations and twelve case tests expose their guards and failure modes in the report.

## Strong properties and their anti-ceremony boundaries

Explicit change intent is stronger than a completed form. A recoverable baseline is stronger than a commit label alone. Bounded comprehension is stronger than a polished but untested story. Observer-relative preservation is stronger than calling a change a refactor. Independently justified regression obligations are stronger than green tests that share the patch’s mistake. State/effect recovery is stronger than a rollback button. Actual maintenance capacity is stronger than a named owner. Historical custody is different from indefinitely operating a service.

None of these contrasts forbids documents, meetings or tools. An artefact is useful when a real consumer can use it to establish a relevant distinction, coordinate a legitimate action or observe a consequence. A fuller form is justified when the cheaper one omits a material function. It should be simplified or retired when its consumer, risk or dependency disappears.

## Citation-ready factual claims

The claims below are deliberately narrower than a whole-method endorsement. Exact source metadata and access limits are supplied in the source table.

### Claim 01

Maintenance guidance is broader than post-release bug fixing: the inspected V3 maintenance chapter and V4 overview cover broader purposes and preparation/transition.

**ESME-S002 locator:** Chapter 5 Software Maintenance, including printed p. 5-4 classification (PDF p. 107, visual inspection); Chapter 6 Software Configuration Management

**ESME-S003 locator:** Knowledge area 7: Software Maintenance; V4 overview

### Claim 02

The official catalogue identifies ISO/IEC/IEEE 14764:2022 as a maintenance standard; this study inspected scope and edition information, not paid normative clauses.

**ESME-S001 locator:** Official scope and edition-history panels

### Claim 03

Swanson’s 1976 paper is a historical classification anchor, but its original body was not available to this study; attribution is corroborated by inspected later guidance.

**ESME-S004 locator:** Bibliographic title, author, ICSE 2, pp. 492–497; original body inaccessible. Historical attribution is corroborated through S005 and S002, not from an unread page.

**ESME-S005 locator:** Title and abstract; taxonomy and management sections; bibliography SWAN76

### Claim 04

Lehman’s S/P/E distinctions qualify the population to which evolution arguments are applied.

**ESME-S009 locator:** Printed pp. 1061–1063 S/P/E distinctions; laws discussion

### Claim 05

Longitudinal Linux and glibc studies show why growth and complexity claims need declared metrics, boundaries and phases. They do not establish a universal duty to expand.

**ESME-S060 locator:** Methods and data; complexity results PDF p. 12 inspected visually; §4 discussion and conclusions

**ESME-S061 locator:** Author-uploaded full article: growth phases; phase D; §9 threats and conclusions; excluding appended related-paper material

### Claim 06

Chikofsky and Cross distinguish reverse-engineering activities from transformation categories, including redocumentation, design recovery, restructuring and re-engineering.

**ESME-S012 locator:** Printed pp. 14–16; taxonomy definitions and objectives

### Claim 07

Opdyke’s 1992 thesis develops object-oriented refactoring with preservation and precondition arguments. The guarantee is model-relative.

**ESME-S018 locator:** Abstract; preservation/precondition chapters; Choices case discussion

### Claim 08

The maintenance value of refactoring is not established merely by metric changes: the inspected comprehension study uses proxies, while the differentiated replication examines confounding and bug relationships.

**ESME-S020 locator:** Study design; results; validity threats

**ESME-S022 locator:** Study design; metric outcomes; validity threats

### Claim 09

Test-oracle research distinguishes different sources of expected behaviour; available tests can be incomplete or wrong for an intended change.

**ESME-S051 locator:** Sections 2 and 4–7: specified, derived, implicit and human oracles

### Claim 10

Regression prioritisation concerns earlier revelation under an order; it does not automatically increase the eventual fault-revealing ability of an unchanged suite.

**ESME-S066 locator:** §2 prioritisation versus efficacy; §3.3–3.5 study and results; §4 threats; PDF p. 6 table/methods visually inspected

### Claim 11

Historical automated-repair criticism separates patch plausibility, semantic correctness and validation-infrastructure problems.

**ESME-S024 locator:** Abstract; experimental design; patch analysis and threats

### Claim 12

The PRISM demo reasons about schema mappings and information preservation in a particular formal/prototype setting; it does not demonstrate arbitrary migration reversibility.

**ESME-S053 locator:** Introduction; section III theoretical background; demonstration and conclusions

### Claim 13

The inspected dependency-abandonment interviews describe several responses rather than a universally superior replacement strategy.

**ESME-S043 locator:** Interview methods; sections 4–7; alternatives and maintainer burden

### Claim 14

Some respondents in the inspected open-source cessation study described their projects as finished; inactivity alone does not identify failure.

**ESME-S040 locator:** Methods; section 3, especially finished projects; threats

### Claim 15

The documented SapFix workflow includes validation and human review before landing, establishing a bounded deployment rather than general unattended maintenance.

**ESME-S055 locator:** Main article: patch generation, validation, and human review before landing

### Claim 16

Repair assistance can help or harm depending on suggestion quality in the inspected controlled study.

**ESME-S052 locator:** Abstract; experimental design; results; validity threats

### Claim 17

METR’s early-2025 randomised result and its 2026 follow-up concern different designs and limitations; the follow-up identifies selection problems that constrain current causal interpretation.

**ESME-S025 locator:** Abstract; randomisation/design; primary outcome; limitations

**ESME-S033 locator:** Follow-up design; selection issues; estimates and interpretation

### Claim 18

The recent policy-as-code study measures repository and commit properties; low commit share does not directly measure low maintenance labour, and file presence is not enforcement.

**ESME-S056 locator:** §3 sampling and coding; §4.3 RQ3; §5.1 implications and §5.2 threats; PDF p. 9 inspected visually

### Claim 19

The 2026 quantisation study reports trade-offs under particular task, model and hardware conditions; memory reduction is not a universal time or energy improvement.

**ESME-S057 locator:** §III experimental setup and hardware; results; §VI limitations

## Evidence limits to retain in public text

A source citation is not proof of universal effectiveness. Formal results need their model and applicability conditions; interviews and incidents establish observations in their actual settings; self-reported productivity is not a randomised causal effect; reused datasets are not independent replications; standards scope is not demonstrated adoption; and an author retrospective is not a new controlled trial. The source register makes inaccessible originals and abstract-only inspection explicit.

Current automation claims must retain tool vintage and population. Selected-subset benchmark percentages must not be extrapolated to the whole benchmark. Gold-patch disagreement is not automatically semantic incorrectness. The upcoming September 2026 ICSME event was not complete at the cut-off; accessible papers retain their actual publication/preprint status. The composed system has analytical consistency tests but no claimed integrated field-effect estimate.

## Suggested public page outline

1. Define existing-software obligations and explain the plural historical branches.
2. Explain purpose, comprehension, impact, preservation and evidence with one bounded change example.
3. Present migration, continued maintenance, non-change and retirement as alternatives.
4. Show how criticism narrows refactoring, debt, metrics and automation claims.
5. Explain the composed feedback network and its three new interaction obligations.
6. Link the full 74-candidate ledger, evidence partitions, access limits and revision identifier.

## Claims not to make

Do not say that an established academic school named “Evolved Software Maintenance and Evolution” existed before this synthesis. Do not imply scholarly consensus on the full composition, a universal optimal maintenance process, or unconditional benefits from isolated cases. Do not say software must grow, that every old system decays, that every cleaner design pays off, or that newer technology is necessarily the mature answer.

Do not equate a proof with implementation applicability, a passing suite with complete correctness, a compatibility label with preserved consumers, a backup with recoverability, an archive with executable custody, or a named maintainer with capacity. Do not convert popularity into maturity, benchmark performance into general autonomy, a selected subgroup’s percentage into a population rate, or an historical slowdown into a permanent verdict on future tools.

Do not claim that any host system adopts, satisfies or benefits from these findings without a separate examination of that system. The public introduction supplements rather than replaces the complete denominator and criticism ledger.

## Citation and revision practice

Cite the exact work and inspected locator behind a factual claim. Describe the relational Evolved account as analytical synthesis and the invented cases as analytical tests. Identify this packet as revision `ESME-2026-09-06-r1`, cut-off `2026-09-06`, and preserve the distinction between 74 examined candidates and 65 conditional crosswalk-worthy questions. Use the manifest for byte-level custody and the source table for provenance; neither is evidence of downstream adoption.
