# EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_AUDIT_INTAKE

Revision `ESME-2026-09-06-r1`; research cut-off **2026-09-06**. This intake is for a later, separate audit of an unspecified real system. It contains no target findings, presumed gaps or authority to modify anything.

## Population and interpretation

**74/74 candidates examined; 55 examined and 19 examined with evidence limits; 10/10 mandatory families examined; 0 uncompleted families.** There are **65 crosswalk-worthy questions**, not 65 mandatory controls. The other nine candidates are six rejected generalisations, one duplicate, one ritual-only form and one unresolved general capability claim.

| Primary disposition | Candidates |
|---|---:|
| `ASSUMPTION_SENSITIVE` | 12 |
| `CEREMONY_NOT_GENERAL_PROPERTY` | 1 |
| `CONTEXT_DEPENDENT` | 14 |
| `DOMAIN_SPECIFIC` | 2 |
| `DUPLICATE_CANDIDATE` | 1 |
| `REJECTED_OR_DISFAVOURED` | 6 |
| `RETAINED_IN_EVOLVED_FORM` | 25 |
| `STRONGLY_RETAINED` | 11 |
| `UNRESOLVED` | 1 |
| `USEFUL_BUT_EASILY_GAMED` | 1 |
| **Total** | **74** |

**Complete IDs:** `ESME-001`, `ESME-002`, `ESME-003`, `ESME-004`, `ESME-005`, `ESME-006`, `ESME-007`, `ESME-008`, `ESME-009`, `ESME-010`, `ESME-011`, `ESME-012`, `ESME-013`, `ESME-014`, `ESME-015`, `ESME-016`, `ESME-017`, `ESME-018`, `ESME-019`, `ESME-020`, `ESME-021`, `ESME-022`, `ESME-023`, `ESME-024`, `ESME-025`, `ESME-026`, `ESME-027`, `ESME-028`, `ESME-029`, `ESME-030`, `ESME-031`, `ESME-032`, `ESME-033`, `ESME-034`, `ESME-035`, `ESME-036`, `ESME-037`, `ESME-038`, `ESME-039`, `ESME-040`, `ESME-041`, `ESME-042`, `ESME-043`, `ESME-044`, `ESME-045`, `ESME-046`, `ESME-047`, `ESME-048`, `ESME-049`, `ESME-050`, `ESME-051`, `ESME-052`, `ESME-053`, `ESME-054`, `ESME-055`, `ESME-056`, `ESME-057`, `ESME-058`, `ESME-059`, `ESME-060`, `ESME-061`, `ESME-062`, `ESME-063`, `ESME-064`, `ESME-065`, `ESME-066`, `ESME-067`, `ESME-068`, `ESME-069`, `ESME-070`, `ESME-071`, `ESME-072`, `ESME-073`, `ESME-074`.

## Evidence and scope

The 67-source corpus covers classification, evolution feedback, comprehension, impact, preservation, regression and releases, migration, technical debt, human/ecosystem continuity, retirement and current automation/non-code evolution. Sources distinguish original works and exact editions from reviews, standards scope, field observations, formal results and researcher interpretation. Original-body access limits, shared datasets and population-specific outcomes remain explicit in the source table. The attached report is an analytical within-tradition composition, not a standard or a target-independent causal guarantee.

**Strong theory with limited deployment transfer:** ESME-013, ESME-024, ESME-034 and ESME-046 require evidence that the actual analysis, transformation, selection or mapping model applies. **Field-supported but uncertain generality:** ESME-043, ESME-055, ESME-058 and ESME-063 draw on case, interview or task-specific evidence; they do not identify universal savings. **Analytical interaction obligations:** ESME-072–ESME-074 need target evidence of candidate identity, reachable joint states and combined control costs. **Unresolved frontier:** ESME-069 must not become an assumed capability.

## Permitted audit outcomes and evidence discipline

For each question permit **already addressed**, **inapplicable**, **simpler mechanism sufficient**, **evidence insufficient**, or **a supported candidate improvement requiring separate authorisation**. A missing named tool, document or owner is not itself a gap. One existing mechanism can satisfy several concerns, and role distinctions do not require separate people. Test passage, a policy file, an approval and an archive are evidence only of the properties their actual consumption and effects establish.

A later system should supply its actual objective and authority, relevant baseline, consumers, dependency evidence, expected observations, validation limits, reachable deployment/data states, support capacity and costs. These facts are not supplied by this external research. Do not infer that a source-supported property applies merely because its name resembles a local component.

## Crosswalk-worthy candidates

### ESME-001 — Explicit and authorised change intent

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-001`

**Disposition and kind.** STRONGLY_RETAINED; DECISION_CRITERION_AND_AUTHORISATION_MECHANISM

**Mature form.** State the requested behavioural difference, surviving obligations and decision authority; challenge ambiguous or conflicting requests before treating tests as acceptance.

**Controlled failure.** A technically valid patch can solve the wrong problem or preserve an obligation that its legitimate owner has withdrawn.

**Trigger.** New, disputed or externally imposed change objectives, including urgent corrections.

**Non-trigger and cheap path.** Use an existing unambiguous authorised request; no new board or document is needed. Decline changes without a supported objective.

**Prerequisites.** An identifiable baseline, affected interests and an actor entitled to resolve the objective; emergency delegation must be explicit.

**Consumer and authority.** Request owner and affected obligation holders determine the objective; implementers can question feasibility but cannot silently redefine acceptance.

**Observable consequence.** The accepted difference and preservation boundary can be checked against the actual candidate, with unresolved conflicts visible.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The accepted difference and preservation boundary can be checked against the actual candidate, with unresolved conflicts visible. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Approval can institutionalise an obsolete requirement, exclude affected users or become a bottleneck; procedural approval is not evidence that the goal is beneficial. How much stakeholder consultation changes decisions, rather than merely delaying them, is setting-specific.

**Anti-ceremony boundary.** Change-request form or approval board is optional as a named form. Use an existing unambiguous authorised request; no new board or document is needed. Decline changes without a supported objective.

**Loss from the cheaper form.** An informal exchange can leave competing interpretations or missing participants undiscoverable later; retain an explicit decision when that uncertainty matters.

**Omission/retirement.** Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

**Conflicts and selection conditions.** ESME-T001: Continuity versus necessary behavioural change. Preserve behaviour with a current supported consumer; change it when legitimate intent is revised and transition consequences are addressed. A failing characterisation test is a question, not automatic veto.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** New, disputed or externally imposed change objectives, including urgent corrections. Corrective restores accepted intent; adaptive responds to environment; perfective changes capability or useful qualities; preventive reduces prospective problems. A single intervention can serve several purposes.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify the system/configuration being changed and any non-code artefact needed to interpret the request. A source commit alone may omit deployed data and obligations.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The accepted difference and preservation boundary can be checked against the actual candidate, with unresolved conflicts visible. Separate the observations that must differ from those that must survive. Current obligation holders, including downstream users where relevant, determine what is accepted rather than copying old tests unquestioningly.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Begin with affected purposes and consumers; expand when interfaces, data or ownership cross the proposed local boundary. A request label is not dependency evidence.

**COMPREHENSION_ASSUMPTIONS.** An identifiable baseline, affected interests and an actor entitled to resolve the objective; emergency delegation must be explicit. The maintainer needs enough understanding to interpret the change and recognise disputed assumptions; complete historical reconstruction is not a universal prerequisite.

**ORACLE_AND_REGRESSION_LIMITS.** Approval can institutionalise an obsolete requirement, exclude affected users or become a bottleneck; procedural approval is not evidence that the goal is beneficial. Tests need expectations justified by intent or independently adjudicated behaviour. Passing the old suite may preserve the wrong objective.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Compatibility and migration are applicable when other consumers or persistent representations are affected; for a purely local inquiry with no intervention they are not yet operative obligations.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** An approval does not establish deployability or reversibility. Consequential release requires separately justified state/effect recovery or forward repair.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Request owner and affected obligation holders determine the objective; implementers can question feasibility but cannot silently redefine acceptance.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Use an existing unambiguous authorised request; no new board or document is needed. Decline changes without a supported objective. Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How much stakeholder consultation changes decisions, rather than merely delaying them, is setting-specific. The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S002; ESME-S005; ESME-S039; ESME-S051] [ESME-001: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/0)

### ESME-002 — Multi-purpose change classification

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-002`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; TAXONOMY_AND_COMMUNICATION

**Mature form.** Classify the purposes of a change using stated definitions, permit multiple purposes and explain disagreement where the distinction changes a decision.

**Controlled failure.** Single labels obscure mixed motives, confuse restoring intent with revising it, and distort effort accounts.

**Trigger.** Classification informs planning, funding, reporting or selection of preservation obligations.

**Non-trigger and cheap path.** Use ordinary language when no decision depends on a taxonomy; do not force every commit into one exclusive category.

**Prerequisites.** A common unit of classification and enough request context to distinguish intent, environment and prevention.

**Consumer and authority.** Maintainers and planning consumers agree operational definitions; a classifier has no authority to approve the underlying change.

**Observable consequence.** A reader can tell which purposes the change serves and whether disputed labels affect a decision.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: A reader can tell which purposes the change serves and whether disputed labels affect a decision. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Benestad finds low inter-rater reliability in a small field setting. Taxonomy precision on paper does not guarantee reproducible classification. Which classifications improve decisions enough to justify coding and disagreement resolution?

**Anti-ceremony boundary.** Mandatory single-category time coding is optional as a named form. Use ordinary language when no decision depends on a taxonomy; do not force every commit into one exclusive category.

**Loss from the cheaper form.** Ordinary language loses aggregate comparability; accept that loss when no credible allocation or planning decision uses the categories.

**Omission/retirement.** Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

**Conflicts and selection conditions.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Classification informs planning, funding, reporting or selection of preservation obligations. Corrective restores accepted intent; adaptive responds to environment; perfective changes capability or useful qualities; preventive reduces prospective problems. A single intervention can serve several purposes.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify the system/configuration being changed and any non-code artefact needed to interpret the request. A source commit alone may omit deployed data and obligations.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** A reader can tell which purposes the change serves and whether disputed labels affect a decision. Separate the observations that must differ from those that must survive. Current obligation holders, including downstream users where relevant, determine what is accepted rather than copying old tests unquestioningly.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Begin with affected purposes and consumers; expand when interfaces, data or ownership cross the proposed local boundary. A request label is not dependency evidence.

**COMPREHENSION_ASSUMPTIONS.** A common unit of classification and enough request context to distinguish intent, environment and prevention. The maintainer needs enough understanding to interpret the change and recognise disputed assumptions; complete historical reconstruction is not a universal prerequisite.

**ORACLE_AND_REGRESSION_LIMITS.** Benestad finds low inter-rater reliability in a small field setting. Taxonomy precision on paper does not guarantee reproducible classification. Tests need expectations justified by intent or independently adjudicated behaviour. Passing the old suite may preserve the wrong objective.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Compatibility and migration are applicable when other consumers or persistent representations are affected; for a purely local inquiry with no intervention they are not yet operative obligations.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** An approval does not establish deployability or reversibility. Consequential release requires separately justified state/effect recovery or forward repair.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainers and planning consumers agree operational definitions; a classifier has no authority to approve the underlying change.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Use ordinary language when no decision depends on a taxonomy; do not force every commit into one exclusive category. Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which classifications improve decisions enough to justify coding and disagreement resolution? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: limited; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S002; ESME-S004; ESME-S005; ESME-S006; ESME-S007] [ESME-002: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/1)

### ESME-003 — Recoverable configuration baseline

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-003`

**Disposition and kind.** STRONGLY_RETAINED; IDENTITY_AND_CONTROL_MECHANISM

**Mature form.** Bind change and evidence to recoverable versions of the relevant source, configuration, build inputs and data/schema state; distinguish identity from recoverability.

**Controlled failure.** Evidence about one source/configuration state can be misapplied to a different build, schema or deployment.

**Trigger.** A change or investigation may need reproduction, comparison, release or restoration.

**Non-trigger and cheap path.** Use existing versioned inputs and reproducible commands; do not snapshot irrelevant infrastructure or duplicate authoritative history.

**Prerequisites.** Actual access to required artefacts, dependency versions and restoration permissions; secrets need references or controlled recovery, not public copying.

**Consumer and authority.** Maintainers and release operators establish the baseline; custodians authorise access and retention.

**Observable consequence.** The candidate and its predecessor can be identified; a claimed recovery path has been exercised to the degree needed by the decision.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The candidate and its predecessor can be identified; a claimed recovery path has been exercised to the degree needed by the decision. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** A commit identifier does not identify database contents or remote effects. Archiving an artefact does not show that it builds or can be safely restored. How much external state must be captured for a particular observation to remain reproducible?

**Anti-ceremony boundary.** Full environment snapshot or configuration inventory is optional as a named form. Use existing versioned inputs and reproducible commands; do not snapshot irrelevant infrastructure or duplicate authoritative history.

**Loss from the cheaper form.** A lighter baseline may omit a mutable build input, schema or remote state; include any omitted input capable of changing the relevant result.

**Omission/retirement.** Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

**Conflicts and selection conditions.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A change or investigation may need reproduction, comparison, release or restoration. Corrective restores accepted intent; adaptive responds to environment; perfective changes capability or useful qualities; preventive reduces prospective problems. A single intervention can serve several purposes.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify the system/configuration being changed and any non-code artefact needed to interpret the request. A source commit alone may omit deployed data and obligations.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The candidate and its predecessor can be identified; a claimed recovery path has been exercised to the degree needed by the decision. Separate the observations that must differ from those that must survive. Current obligation holders, including downstream users where relevant, determine what is accepted rather than copying old tests unquestioningly.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Begin with affected purposes and consumers; expand when interfaces, data or ownership cross the proposed local boundary. A request label is not dependency evidence.

**COMPREHENSION_ASSUMPTIONS.** Actual access to required artefacts, dependency versions and restoration permissions; secrets need references or controlled recovery, not public copying. The maintainer needs enough understanding to interpret the change and recognise disputed assumptions; complete historical reconstruction is not a universal prerequisite.

**ORACLE_AND_REGRESSION_LIMITS.** A commit identifier does not identify database contents or remote effects. Archiving an artefact does not show that it builds or can be safely restored. Tests need expectations justified by intent or independently adjudicated behaviour. Passing the old suite may preserve the wrong objective.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Compatibility and migration are applicable when other consumers or persistent representations are affected; for a purely local inquiry with no intervention they are not yet operative obligations.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** An approval does not establish deployability or reversibility. Consequential release requires separately justified state/effect recovery or forward repair.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainers and release operators establish the baseline; custodians authorise access and retention.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Use existing versioned inputs and reproducible commands; do not snapshot irrelevant infrastructure or duplicate authoritative history. Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How much external state must be captured for a particular observation to remain reproducible? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S002; ESME-S030; ESME-S038; ESME-S046] [ESME-003: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/2)

### ESME-004 — Maintenance readiness across the delivery boundary

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-004`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; CAPABILITY_PREPARATION

**Mature form.** Before transferring responsibility, establish the receiving maintainer’s access, runnable artefacts, known obligations and escalation route; revisit after ownership changes.

**Controlled failure.** A delivered system may lack the access, knowledge, build capability or responsibility required for its later changes.

**Trigger.** Initial delivery, outsourcing, major platform change or ownership handoff.

**Non-trigger and cheap path.** An existing competent team with unchanged access can reuse its arrangements; no separate transition ceremony is inherently required.

**Prerequisites.** A receiving actor, accepted responsibility and feasible resources; possession of documents alone is insufficient.

**Consumer and authority.** Delivering and receiving maintainers negotiate support responsibility; a research assessment cannot impose labour or grant access.

**Observable consequence.** The receiving maintainer can perform a representative bounded change or diagnosis with the supplied means.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The receiving maintainer can perform a representative bounded change or diagnosis with the supplied means. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Guide scope establishes a planning responsibility, not a measured universal benefit of every transition artefact. Knowledge-loss proxies do not measure all expertise. Which low-cost transition exercises predict later maintenance performance?

**Anti-ceremony boundary.** Formal transfer checklist and handover meeting is optional as a named form. An existing competent team with unchanged access can reuse its arrangements; no separate transition ceremony is inherently required.

**Loss from the cheaper form.** An informal handover may fail to expose missing credentials, unavailable expertise or unusable artefacts; a small capability check can reveal these failures.

**Omission/retirement.** Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

**Conflicts and selection conditions.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Initial delivery, outsourcing, major platform change or ownership handoff. Corrective restores accepted intent; adaptive responds to environment; perfective changes capability or useful qualities; preventive reduces prospective problems. A single intervention can serve several purposes.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify the system/configuration being changed and any non-code artefact needed to interpret the request. A source commit alone may omit deployed data and obligations.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The receiving maintainer can perform a representative bounded change or diagnosis with the supplied means. Separate the observations that must differ from those that must survive. Current obligation holders, including downstream users where relevant, determine what is accepted rather than copying old tests unquestioningly.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Begin with affected purposes and consumers; expand when interfaces, data or ownership cross the proposed local boundary. A request label is not dependency evidence.

**COMPREHENSION_ASSUMPTIONS.** A receiving actor, accepted responsibility and feasible resources; possession of documents alone is insufficient. The maintainer needs enough understanding to interpret the change and recognise disputed assumptions; complete historical reconstruction is not a universal prerequisite.

**ORACLE_AND_REGRESSION_LIMITS.** Guide scope establishes a planning responsibility, not a measured universal benefit of every transition artefact. Knowledge-loss proxies do not measure all expertise. Tests need expectations justified by intent or independently adjudicated behaviour. Passing the old suite may preserve the wrong objective.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Compatibility and migration are applicable when other consumers or persistent representations are affected; for a purely local inquiry with no intervention they are not yet operative obligations.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** An approval does not establish deployability or reversibility. Consequential release requires separately justified state/effect recovery or forward repair.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Delivering and receiving maintainers negotiate support responsibility; a research assessment cannot impose labour or grant access.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** An existing competent team with unchanged access can reuse its arrangements; no separate transition ceremony is inherently required. Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which low-cost transition exercises predict later maintenance performance? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S001; ESME-S002; ESME-S003; ESME-S005; ESME-S047] [ESME-004: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/3)

### ESME-005 — Deliberate non-change

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-005`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; DECISION_ALTERNATIVE

**Mature form.** Compare a proposed intervention with continued operation under current obligations; permit deliberate non-change with explicit revisit triggers.

**Controlled failure.** Activity metrics and novelty pressure can trigger changes whose risk and effort exceed any supported benefit.

**Trigger.** A stable useful system has no material unmet requirement, unsupported dependency exposure or changing obligation requiring action.

**Non-trigger and cheap path.** Leave the system unchanged and retain only necessary observation or support; do not invent work to sustain activity.

**Prerequisites.** Enough evidence about utility, dependency support and external obligations to distinguish stability from neglected risk.

**Consumer and authority.** Service or product decision makers accept residual risk; maintainers report relevant changes without treating every observation as a mandate to modify.

**Observable consequence.** The decision records why no intervention is justified and what changed condition would reopen it.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The decision records why no intervention is justified and what changed condition would reopen it. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** A project labelled finished may still have dependent users or changing security obligations. Absence of commits is not proof of either health or abandonment. What inexpensive observations distinguish enduring adequacy from unnoticed deterioration?

**Anti-ceremony boundary.** Scheduled improvement programme is optional as a named form. Leave the system unchanged and retain only necessary observation or support; do not invent work to sustain activity.

**Loss from the cheaper form.** Choosing no change leaves latent risks and future adaptation costs in place; retain revisit signals for actual changing obligations rather than activity targets.

**Omission/retirement.** Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

**Conflicts and selection conditions.** ESME-T003: Local repair versus replacement. Choose by unmet obligations, support feasibility and lifecycle cost including transition; age alone has no deciding role.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A stable useful system has no material unmet requirement, unsupported dependency exposure or changing obligation requiring action. Corrective restores accepted intent; adaptive responds to environment; perfective changes capability or useful qualities; preventive reduces prospective problems. A single intervention can serve several purposes.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify the system/configuration being changed and any non-code artefact needed to interpret the request. A source commit alone may omit deployed data and obligations.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The decision records why no intervention is justified and what changed condition would reopen it. Separate the observations that must differ from those that must survive. Current obligation holders, including downstream users where relevant, determine what is accepted rather than copying old tests unquestioningly.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Begin with affected purposes and consumers; expand when interfaces, data or ownership cross the proposed local boundary. A request label is not dependency evidence.

**COMPREHENSION_ASSUMPTIONS.** Enough evidence about utility, dependency support and external obligations to distinguish stability from neglected risk. The maintainer needs enough understanding to interpret the change and recognise disputed assumptions; complete historical reconstruction is not a universal prerequisite.

**ORACLE_AND_REGRESSION_LIMITS.** A project labelled finished may still have dependent users or changing security obligations. Absence of commits is not proof of either health or abandonment. Tests need expectations justified by intent or independently adjudicated behaviour. Passing the old suite may preserve the wrong objective.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Compatibility and migration are applicable when other consumers or persistent representations are affected; for a purely local inquiry with no intervention they are not yet operative obligations.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** An approval does not establish deployability or reversibility. Consequential release requires separately justified state/effect recovery or forward repair.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Service or product decision makers accept residual risk; maintainers report relevant changes without treating every observation as a mandate to modify.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Leave the system unchanged and retain only necessary observation or support; do not invent work to sustain activity. Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** What inexpensive observations distinguish enduring adequacy from unnoticed deterioration? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: differentiated/limited; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S010; ESME-S031; ESME-S040; ESME-S050; ESME-S061] [ESME-005: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/4)

### ESME-006 — Evolution feedback with measurable consequences

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-006`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; FEEDBACK_MECHANISM

**Mature form.** Observe demand, delivered effects, effort and consequences over time; revise change priorities when those observations challenge the operative model.

**Controlled failure.** Local output counts miss whether changes improve usefulness or increase future change difficulty.

**Trigger.** Repeated change in a system exposed to evolving use and stakeholder expectations.

**Non-trigger and cheap path.** For infrequent bounded changes, a direct outcome review may suffice; do not institute a metric programme without a decision consumer.

**Prerequisites.** Consistent measurement boundaries, interpretable observations and authority to change priorities.

**Consumer and authority.** Maintainers, users and decision makers exchange usage and cost evidence; observation alone neither authorises intervention nor identifies causation.

**Observable consequence.** A consequential observation can be traced to a changed decision, an explicit decision not to change, or an unresolved uncertainty.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: A consequential observation can be traced to a changed decision, an explicit decision not to change, or an unresolved uncertainty. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Time-series association and fitted curves do not identify causal feedback. Measures can be gamed and external shocks confound trends. Which feedback mechanisms explain a particular project’s trajectory after organisational confounders are considered?

**Anti-ceremony boundary.** Evolution dashboard and regular review meeting is optional as a named form. For infrequent bounded changes, a direct outcome review may suffice; do not institute a metric programme without a decision consumer.

**Loss from the cheaper form.** Direct occasional review can miss slow trends and cross-team effects; use time-series observation when those effects change real decisions.

**Omission/retirement.** Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.

**Conflicts and selection conditions.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Repeated change in a system exposed to evolving use and stakeholder expectations. Changes may respond to external expectations, defects, opportunities or internal difficulty. Growth itself is not an authorised objective or necessary change class.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Use comparable system/version boundaries over time; separate source size, feature count, local complexity and organisational work rather than calling them one growth variable.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** A consequential observation can be traced to a changed decision, an explicit decision not to change, or an unresolved uncertainty. The observer includes users’ usefulness and maintainers’ ability to change, not just line counts. Preserve required service while allowing deliberate simplification or changed requirements.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Explanations may involve organisation, ecosystem and usage as well as code. Time-series correlation does not establish an impact edge.

**COMPREHENSION_ASSUMPTIONS.** Consistent measurement boundaries, interpretable observations and authority to change priorities. People’s familiarity and limits must be observed through actual tasks or credible evidence; a repository ownership proxy is incomplete.

**ORACLE_AND_REGRESSION_LIMITS.** Time-series association and fitted curves do not identify causal feedback. Measures can be gamed and external shocks confound trends. Trends are not test oracles. A local regression suite cannot establish the causal validity of an evolution law or long-term continued usefulness.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Migration is one possible response to feedback, not an inevitable mature phase. Compare coexistence and replacement burdens before selecting it.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Feedback can stop or defer rollout, but state restoration needs independent feasibility evidence; a favourable trend is not a release guarantee.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainers, users and decision makers exchange usage and cost evidence; observation alone neither authorises intervention nor identifies causation.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** For infrequent bounded changes, a direct outcome review may suffice; do not institute a metric programme without a decision consumer. Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which feedback mechanisms explain a particular project’s trajectory after organisational confounders are considered? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: differentiated/limited; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S008; ESME-S009; ESME-S010; ESME-S029; ESME-S060; ESME-S061] [ESME-006: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/5)

### ESME-007 — Population-scoped evolution-law interpretation

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-007`

**Disposition and kind.** ASSUMPTION_SENSITIVE; EMPIRICAL_MODEL_INTERPRETATION

**Mature form.** Declare system population, time scale, metric and conditional clauses before applying an evolution regularity; compare plausible alternative interpretations.

**Controlled failure.** Population-specific observations can be converted into universal physical laws or operational mandates.

**Trigger.** A growth, complexity, effort or quality law is used to explain or predict an actual system.

**Non-trigger and cheap path.** Use direct local evidence without invoking a law when the classification or measurement adds no decision value.

**Prerequisites.** An operational interpretation of the law, compatible observations and a potential disconfirming result.

**Consumer and authority.** Analysts state scope; planning authorities decide whether that evidence warrants investment, not whether the word law compels it.

**Observable consequence.** The claim specifies what would count against it and avoids converting a conditional regularity into a requirement.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The claim specifies what would count against it and avoids converting a conditional regularity into a requirement. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Linux and glibc findings depend on aggregation, stage and metrics. Conditional prevention clauses can make some formulations difficult to falsify. Which formulations retain predictive value across independently selected populations?

**Anti-ceremony boundary.** Eight-law compliance scorecard is optional as a named form. Use direct local evidence without invoking a law when the classification or measurement adds no decision value.

**Loss from the cheaper form.** Direct local evidence gives up broad explanatory comparisons; this is acceptable when population and measurement conditions are not established.

**Omission/retirement.** Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.

**Conflicts and selection conditions.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A growth, complexity, effort or quality law is used to explain or predict an actual system. Changes may respond to external expectations, defects, opportunities or internal difficulty. Growth itself is not an authorised objective or necessary change class.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Use comparable system/version boundaries over time; separate source size, feature count, local complexity and organisational work rather than calling them one growth variable.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The claim specifies what would count against it and avoids converting a conditional regularity into a requirement. The observer includes users’ usefulness and maintainers’ ability to change, not just line counts. Preserve required service while allowing deliberate simplification or changed requirements.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Explanations may involve organisation, ecosystem and usage as well as code. Time-series correlation does not establish an impact edge.

**COMPREHENSION_ASSUMPTIONS.** An operational interpretation of the law, compatible observations and a potential disconfirming result. People’s familiarity and limits must be observed through actual tasks or credible evidence; a repository ownership proxy is incomplete.

**ORACLE_AND_REGRESSION_LIMITS.** Linux and glibc findings depend on aggregation, stage and metrics. Conditional prevention clauses can make some formulations difficult to falsify. Trends are not test oracles. A local regression suite cannot establish the causal validity of an evolution law or long-term continued usefulness.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Migration is one possible response to feedback, not an inevitable mature phase. Compare coexistence and replacement burdens before selecting it.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Feedback can stop or defer rollout, but state restoration needs independent feasibility evidence; a favourable trend is not a release guarantee.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Analysts state scope; planning authorities decide whether that evidence warrants investment, not whether the word law compels it.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Use direct local evidence without invoking a law when the classification or measurement adds no decision value. Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which formulations retain predictive value across independently selected populations? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: differentiated/limited; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S008; ESME-S009; ESME-S010; ESME-S011; ESME-S029; ESME-S060; ESME-S061] [ESME-007: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/6)

### ESME-008 — Costed complexity and anti-regressive work

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-008`

**Disposition and kind.** CONTEXT_DEPENDENT; INVESTMENT_MECHANISM

**Mature form.** Identify a change-relevant source of difficulty and compare targeted restructuring with leaving it, wrapping it or replacing the affected part.

**Controlled failure.** Accumulated interactions can make necessary future modifications slower or more hazardous.

**Trigger.** Recurrent changes or demonstrated failures make a particular structural difficulty consequential.

**Non-trigger and cheap path.** Use a local repair or tolerate harmless complexity when no likely change benefits from restructuring.

**Prerequisites.** A stated future change class, intervention cost and evidence connecting the alleged complexity to that cost.

**Consumer and authority.** Maintainers propose structural work; product or service authorities accept its opportunity cost and risk.

**Observable consequence.** The targeted task becomes easier or safer under stated measures, or the proposed benefit is withdrawn.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The targeted task becomes easier or safer under stated measures, or the proposed benefit is withdrawn. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Total complexity can rise while local complexity falls; added variation may be necessary. Metric improvement does not establish useful simplification. How can delayed benefits be distinguished from selection effects and concurrent development changes?

**Anti-ceremony boundary.** Complexity-reduction campaign is optional as a named form. Use a local repair or tolerate harmless complexity when no likely change benefits from restructuring.

**Loss from the cheaper form.** A local repair may retain a recurrent structural obstacle; favour it only when avoiding that obstacle does not justify wider relearning and regression cost.

**Omission/retirement.** Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.

**Conflicts and selection conditions.** ESME-T002: Familiarity versus simplification. Prefer restructuring when a plausible recurrent task benefit exceeds relearning, review and regression cost; prefer familiarity when the system is stable or retiring.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Recurrent changes or demonstrated failures make a particular structural difficulty consequential. Changes may respond to external expectations, defects, opportunities or internal difficulty. Growth itself is not an authorised objective or necessary change class.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Use comparable system/version boundaries over time; separate source size, feature count, local complexity and organisational work rather than calling them one growth variable.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The targeted task becomes easier or safer under stated measures, or the proposed benefit is withdrawn. The observer includes users’ usefulness and maintainers’ ability to change, not just line counts. Preserve required service while allowing deliberate simplification or changed requirements.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Explanations may involve organisation, ecosystem and usage as well as code. Time-series correlation does not establish an impact edge.

**COMPREHENSION_ASSUMPTIONS.** A stated future change class, intervention cost and evidence connecting the alleged complexity to that cost. People’s familiarity and limits must be observed through actual tasks or credible evidence; a repository ownership proxy is incomplete.

**ORACLE_AND_REGRESSION_LIMITS.** Total complexity can rise while local complexity falls; added variation may be necessary. Metric improvement does not establish useful simplification. Trends are not test oracles. A local regression suite cannot establish the causal validity of an evolution law or long-term continued usefulness.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Migration is one possible response to feedback, not an inevitable mature phase. Compare coexistence and replacement burdens before selecting it.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Feedback can stop or defer rollout, but state restoration needs independent feasibility evidence; a favourable trend is not a release guarantee.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainers propose structural work; product or service authorities accept its opportunity cost and risk.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Use a local repair or tolerate harmless complexity when no likely change benefits from restructuring. Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How can delayed benefits be distinguished from selection effects and concurrent development changes? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: differentiated/limited; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S008; ESME-S020; ESME-S022; ESME-S032; ESME-S050; ESME-S060] [ESME-008: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/7)

### ESME-009 — Familiarity and knowledge-capacity constraints

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-009`

**Disposition and kind.** CONTEXT_DEPENDENT; HUMAN_CAPACITY_CONSTRAINT

**Mature form.** Adjust change scope, sequencing, learning and review to demonstrated maintainer capacity; expose concentrated knowledge and provide learning opportunities.

**Controlled failure.** Change volume can outstrip the people able to review, operate and explain consequential behaviour.

**Trigger.** Rapid growth, departure, ownership concentration or repeated review/comprehension failures.

**Non-trigger and cheap path.** An experienced available maintainer can make a bounded change without a formal knowledge census.

**Prerequisites.** Access to people and artefacts, an honest account of capacity and authority to defer or narrow change.

**Consumer and authority.** Maintainer teams and managers negotiate workload; repository metrics cannot assign expertise or compel unpaid work.

**Observable consequence.** Affected changes have competent review and support, or a visible capacity constraint changes the plan.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Affected changes have competent review and support, or a visible capacity constraint changes the plan. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Commit ownership is an incomplete proxy for knowledge; spreading ownership can also increase coordination cost and reduce deep expertise. What task-level demonstrations best reveal knowledge that history-based measures miss?

**Anti-ceremony boundary.** Knowledge map or fixed team-capacity rule is optional as a named form. An experienced available maintainer can make a bounded change without a formal knowledge census.

**Loss from the cheaper form.** Informal familiarity judgements may miss concentrated or unavailable expertise; enlarge the assessment when absence would obstruct a consequential change.

**Omission/retirement.** Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.

**Conflicts and selection conditions.** ESME-T002: Familiarity versus simplification. Prefer restructuring when a plausible recurrent task benefit exceeds relearning, review and regression cost; prefer familiarity when the system is stable or retiring.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Rapid growth, departure, ownership concentration or repeated review/comprehension failures. Changes may respond to external expectations, defects, opportunities or internal difficulty. Growth itself is not an authorised objective or necessary change class.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Use comparable system/version boundaries over time; separate source size, feature count, local complexity and organisational work rather than calling them one growth variable.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Affected changes have competent review and support, or a visible capacity constraint changes the plan. The observer includes users’ usefulness and maintainers’ ability to change, not just line counts. Preserve required service while allowing deliberate simplification or changed requirements.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Explanations may involve organisation, ecosystem and usage as well as code. Time-series correlation does not establish an impact edge.

**COMPREHENSION_ASSUMPTIONS.** Access to people and artefacts, an honest account of capacity and authority to defer or narrow change. People’s familiarity and limits must be observed through actual tasks or credible evidence; a repository ownership proxy is incomplete.

**ORACLE_AND_REGRESSION_LIMITS.** Commit ownership is an incomplete proxy for knowledge; spreading ownership can also increase coordination cost and reduce deep expertise. Trends are not test oracles. A local regression suite cannot establish the causal validity of an evolution law or long-term continued usefulness.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Migration is one possible response to feedback, not an inevitable mature phase. Compare coexistence and replacement burdens before selecting it.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Feedback can stop or defer rollout, but state restoration needs independent feasibility evidence; a favourable trend is not a release guarantee.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainer teams and managers negotiate workload; repository metrics cannot assign expertise or compel unpaid work.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** An experienced available maintainer can make a bounded change without a formal knowledge census. Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** What task-level demonstrations best reveal knowledge that history-based measures miss? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S008; ESME-S010; ESME-S014; ESME-S043; ESME-S047] [ESME-009: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/8)

### ESME-011 — Question-bounded program comprehension

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-011`

**Disposition and kind.** STRONGLY_RETAINED; INQUIRY_MECHANISM

**Mature form.** Identify the questions needed for this change, seek evidence until consequential uncertainties are bounded, and expand inquiry when evidence contradicts the model.

**Controlled failure.** Maintainers may either act without relevant understanding or spend disproportionate effort modelling irrelevant parts.

**Trigger.** A change depends on unfamiliar behaviour, ownership, dependencies or intent.

**Non-trigger and cheap path.** Reuse reliable knowledge and perform a small confirming check when the question is local and low consequence.

**Prerequisites.** A stated change objective and access to representative source, execution or knowledgeable people.

**Consumer and authority.** The maintainer frames and tests explanations; affected experts can correct them but do not automatically authorise a patch.

**Observable consequence.** The maintainer can explain the relevant predicted effects and identify remaining uncertainty that matters for the decision.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The maintainer can explain the relevant predicted effects and identify remaining uncertainty that matters for the decision. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** A bounded question can be wrongly framed and hide a dependency; confidence or a polished explanation is not operational validation. How should inquiry stop when low-probability impact is expensive to observe?

**Anti-ceremony boundary.** Whole-system comprehension dossier is optional as a named form. Reuse reliable knowledge and perform a small confirming check when the question is local and low consequence.

**Loss from the cheaper form.** Bounded inquiry can miss a question that would change the intervention; retain an explicit trigger for expanding inquiry when observations disagree.

**Omission/retirement.** Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

**Conflicts and selection conditions.** ESME-T002: Familiarity versus simplification. Prefer restructuring when a plausible recurrent task benefit exceeds relearning, review and regression cost; prefer familiarity when the system is stable or retiring.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A change depends on unfamiliar behaviour, ownership, dependencies or intent. Comprehension is directed by the intended repair, adaptation, restructuring or migration question; inquiry alone need not change behaviour.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Use source, generated artefacts, build/configuration state, execution traces, relevant history and rationale where each is needed to answer Q.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The maintainer can explain the relevant predicted effects and identify remaining uncertainty that matters for the decision. Name the value, behaviour, feature or consumer being explained. Recovering what happens does not determine whether it should continue.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Slices and feature-location results are starting boundaries; reflection, environment and tacit operational dependencies can require expansion.

**COMPREHENSION_ASSUMPTIONS.** A stated change objective and access to representative source, execution or knowledgeable people. Understanding is provisional and task-bounded. Static and dynamic evidence have complementary omissions; access to tacit expertise may be essential.

**ORACLE_AND_REGRESSION_LIMITS.** A bounded question can be wrongly framed and hide a dependency; confidence or a polished explanation is not operational validation. A plausible explanation is not an oracle. Characterisation can support prediction but may capture a defect; unknown behaviour remains explicitly unknown.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** For analysis-only work, compatibility checks are not an executed migration obligation. A later transformation must use the recovered model without assuming it is complete.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Recovery of a model does not establish a recoverable deployment. An operative change requires separate release/effect evidence.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** The maintainer frames and tests explanations; affected experts can correct them but do not automatically authorise a patch.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Reuse reliable knowledge and perform a small confirming check when the question is local and low consequence. Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How should inquiry stop when low-probability impact is expensive to observe? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S014; ESME-S015; ESME-S051] [ESME-011: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/10)

### ESME-012 — Static and dynamic evidence triangulation

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-012`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; EVIDENCE_COMBINATION

**Mature form.** Compare structural dependencies with representative execution, configuration and build evidence; investigate consequential disagreement.

**Controlled failure.** Either source structure or a small execution trace can be mistaken for the full behaviour of a configurable system.

**Trigger.** Dynamic binding, generated code, reflection, configuration or sparse tests make one evidence mode incomplete.

**Non-trigger and cheap path.** Use one adequate analysis for a demonstrably closed local case; combining tools is not mandatory when it adds no discriminating observation.

**Prerequisites.** Known analysis scope and representative execution conditions; trace absence must not be read as impossibility.

**Consumer and authority.** Maintainers and operators supply complementary evidence; tool outputs are observations rather than approval.

**Observable consequence.** Conclusions state what each mode observes and preserve unknown or contradictory edges.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Conclusions state what each mode observes and preserve unknown or contradictory edges. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Static analysis may over-approximate; dynamic analysis misses unexecuted paths. Shared assumptions can make apparent agreement misleading. Which combinations provide enough independent evidence for rare configuration-dependent behaviour?

**Anti-ceremony boundary.** Compulsory multi-tool analysis bundle is optional as a named form. Use one adequate analysis for a demonstrably closed local case; combining tools is not mandatory when it adds no discriminating observation.

**Loss from the cheaper form.** A single evidence mode can miss its blind spots; the cheap path requires an adequately closed question, not mere agreement with the preferred explanation.

**Omission/retirement.** Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

**Conflicts and selection conditions.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Dynamic binding, generated code, reflection, configuration or sparse tests make one evidence mode incomplete. Comprehension is directed by the intended repair, adaptation, restructuring or migration question; inquiry alone need not change behaviour.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Use source, generated artefacts, build/configuration state, execution traces, relevant history and rationale where each is needed to answer Q.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Conclusions state what each mode observes and preserve unknown or contradictory edges. Name the value, behaviour, feature or consumer being explained. Recovering what happens does not determine whether it should continue.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Slices and feature-location results are starting boundaries; reflection, environment and tacit operational dependencies can require expansion.

**COMPREHENSION_ASSUMPTIONS.** Known analysis scope and representative execution conditions; trace absence must not be read as impossibility. Understanding is provisional and task-bounded. Static and dynamic evidence have complementary omissions; access to tacit expertise may be essential.

**ORACLE_AND_REGRESSION_LIMITS.** Static analysis may over-approximate; dynamic analysis misses unexecuted paths. Shared assumptions can make apparent agreement misleading. A plausible explanation is not an oracle. Characterisation can support prediction but may capture a defect; unknown behaviour remains explicitly unknown.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** For analysis-only work, compatibility checks are not an executed migration obligation. A later transformation must use the recovered model without assuming it is complete.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Recovery of a model does not establish a recoverable deployment. An operative change requires separate release/effect evidence.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainers and operators supply complementary evidence; tool outputs are observations rather than approval.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Use one adequate analysis for a demonstrably closed local case; combining tools is not mandatory when it adds no discriminating observation. Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which combinations provide enough independent evidence for rare configuration-dependent behaviour? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S012; ESME-S013; ESME-S014; ESME-S015; ESME-S044; ESME-S051] [ESME-012: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/11)

### ESME-013 — Criterion-relative program slicing

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-013`

**Disposition and kind.** ASSUMPTION_SENSITIVE; FORMAL_ANALYSIS_TECHNIQUE

**Mature form.** Compute or inspect a slice relative to a declared criterion and analysis assumptions; treat it as evidence about that criterion, not the complete impact set.

**Controlled failure.** Unrelated code obscures the computations relevant to an observed value or proposed change.

**Trigger.** A value, statement or behaviour can be represented by a tractable slicing criterion.

**Non-trigger and cheap path.** Direct inspection of a tiny dependency chain may be cheaper; avoid slicing where external effects are outside the model.

**Prerequisites.** Soundness assumptions for the chosen static/dynamic analysis, aliasing, control flow, termination and environment.

**Consumer and authority.** Analysts choose the criterion; maintainers decide whether its omissions are acceptable for the actual change.

**Observable consequence.** The slice and its criterion are explicit, with effects outside the model excluded from the guarantee.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The slice and its criterion are explicit, with effects outside the model excluded from the guarantee. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** General minimal slicing is undecidable; computable slices need not be minimal and the guarantee need not cover termination or arbitrary observers. What conservatism is affordable for reflection, foreign calls and configuration-driven execution?

**Anti-ceremony boundary.** Automatically generated slice for every edit is optional as a named form. Direct inspection of a tiny dependency chain may be cheaper; avoid slicing where external effects are outside the model.

**Loss from the cheaper form.** Direct inspection loses systematic reach through complex dependencies; use a sound applicable analysis when manual omission risk becomes consequential.

**Omission/retirement.** Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

**Conflicts and selection conditions.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A value, statement or behaviour can be represented by a tractable slicing criterion. Comprehension is directed by the intended repair, adaptation, restructuring or migration question; inquiry alone need not change behaviour.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Use source, generated artefacts, build/configuration state, execution traces, relevant history and rationale where each is needed to answer Q.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The slice and its criterion are explicit, with effects outside the model excluded from the guarantee. Name the value, behaviour, feature or consumer being explained. Recovering what happens does not determine whether it should continue.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Slices and feature-location results are starting boundaries; reflection, environment and tacit operational dependencies can require expansion.

**COMPREHENSION_ASSUMPTIONS.** Soundness assumptions for the chosen static/dynamic analysis, aliasing, control flow, termination and environment. Understanding is provisional and task-bounded. Static and dynamic evidence have complementary omissions; access to tacit expertise may be essential.

**ORACLE_AND_REGRESSION_LIMITS.** General minimal slicing is undecidable; computable slices need not be minimal and the guarantee need not cover termination or arbitrary observers. A plausible explanation is not an oracle. Characterisation can support prediction but may capture a defect; unknown behaviour remains explicitly unknown.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** For analysis-only work, compatibility checks are not an executed migration obligation. A later transformation must use the recovered model without assuming it is complete.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Recovery of a model does not establish a recoverable deployment. An operative change requires separate release/effect evidence.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Analysts choose the criterion; maintainers decide whether its omissions are acceptable for the actual change.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Direct inspection of a tiny dependency chain may be cheaper; avoid slicing where external effects are outside the model. Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** What conservatism is affordable for reflection, foreign calls and configuration-driven execution? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: model-bounded formal support; implementation applicability remains unproved; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S013; ESME-S051] [ESME-013: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/12)

### ESME-014 — Distinguish recovery from transformation

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-014`

**Disposition and kind.** STRONGLY_RETAINED; CONCEPTUAL_BOUNDARY

**Mature form.** Label whether an activity recovers information, changes representation at the same abstraction, or reconstructs/changes the system; assign evidence and authority accordingly.

**Controlled failure.** Producing an explanation can be misreported as changing the system, or a transformation as merely documenting it.

**Trigger.** A recovery or modernisation activity is proposed, evaluated or handed off.

**Non-trigger and cheap path.** Ordinary descriptions suffice for unambiguous local work; a taxonomy table is unnecessary.

**Prerequisites.** Identification of input/output artefacts, abstraction level and whether external behaviour is intended to change.

**Consumer and authority.** Analysts recover evidence; authorised maintainers perform transformations; consumers must not infer one from the other.

**Observable consequence.** The activity’s deliverable and actual effect are distinguishable and testable.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The activity’s deliverable and actual effect are distinguishable and testable. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Industrial terminology is broader and inconsistent; labels alone cannot resolve actual semantics or prove preservation. How should mixed analysis-and-transformation tools expose their distinct guarantees?

**Anti-ceremony boundary.** Reverse-engineering taxonomy document is optional as a named form. Ordinary descriptions suffice for unambiguous local work; a taxonomy table is unnecessary.

**Loss from the cheaper form.** Unlabelled activities can blur analysis and mutation; retain an ordinary-language distinction whenever authority or preservation evidence differs.

**Omission/retirement.** Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

**Conflicts and selection conditions.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A recovery or modernisation activity is proposed, evaluated or handed off. Comprehension is directed by the intended repair, adaptation, restructuring or migration question; inquiry alone need not change behaviour.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Use source, generated artefacts, build/configuration state, execution traces, relevant history and rationale where each is needed to answer Q.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The activity’s deliverable and actual effect are distinguishable and testable. Name the value, behaviour, feature or consumer being explained. Recovering what happens does not determine whether it should continue.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Slices and feature-location results are starting boundaries; reflection, environment and tacit operational dependencies can require expansion.

**COMPREHENSION_ASSUMPTIONS.** Identification of input/output artefacts, abstraction level and whether external behaviour is intended to change. Understanding is provisional and task-bounded. Static and dynamic evidence have complementary omissions; access to tacit expertise may be essential.

**ORACLE_AND_REGRESSION_LIMITS.** Industrial terminology is broader and inconsistent; labels alone cannot resolve actual semantics or prove preservation. A plausible explanation is not an oracle. Characterisation can support prediction but may capture a defect; unknown behaviour remains explicitly unknown.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** For analysis-only work, compatibility checks are not an executed migration obligation. A later transformation must use the recovered model without assuming it is complete.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Recovery of a model does not establish a recoverable deployment. An operative change requires separate release/effect evidence.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Analysts recover evidence; authorised maintainers perform transformations; consumers must not infer one from the other.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Ordinary descriptions suffice for unambiguous local work; a taxonomy table is unnecessary. Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How should mixed analysis-and-transformation tools expose their distinct guarantees? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S012; ESME-S021] [ESME-014: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/13)

### ESME-015 — Recover intent with rationale and human knowledge

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-015`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; KNOWLEDGE_RECOVERY_AND_COMMUNICATION

**Mature form.** Recover consequential rationale from requirements, history, operations and knowledgeable people; link it to decisions and mark uncertain or superseded interpretations.

**Controlled failure.** Code can reveal what happens without revealing why a behaviour is required, tolerated or obsolete.

**Trigger.** Undocumented behaviour, disputed intent, missing ownership or a knowledge handoff affects a change.

**Non-trigger and cheap path.** Ask the relevant person or retain a short decision note rather than reconstructing a comprehensive document set.

**Prerequisites.** Provenance for recovered claims and access to a consumer able to challenge them.

**Consumer and authority.** Knowledge holders explain history; current obligation owners determine what should survive. Recollection is evidence, not sole authority.

**Observable consequence.** A maintainer can identify both the rationale and its current acceptance or uncertainty.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: A maintainer can identify both the rationale and its current acceptance or uncertainty. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Memory and documentation can be wrong or stale; history does not make a past choice permanently binding. Which rationale deserves retention when documentation itself has maintenance cost?

**Anti-ceremony boundary.** Comprehensive reconstructed documentation set is optional as a named form. Ask the relevant person or retain a short decision note rather than reconstructing a comprehensive document set.

**Loss from the cheaper form.** A short note or conversation may not survive turnover or reach another consumer; preserve consequential rationale in a retrievable form when reuse is likely.

**Omission/retirement.** Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

**Conflicts and selection conditions.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Undocumented behaviour, disputed intent, missing ownership or a knowledge handoff affects a change. Comprehension is directed by the intended repair, adaptation, restructuring or migration question; inquiry alone need not change behaviour.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Use source, generated artefacts, build/configuration state, execution traces, relevant history and rationale where each is needed to answer Q.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** A maintainer can identify both the rationale and its current acceptance or uncertainty. Name the value, behaviour, feature or consumer being explained. Recovering what happens does not determine whether it should continue.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Slices and feature-location results are starting boundaries; reflection, environment and tacit operational dependencies can require expansion.

**COMPREHENSION_ASSUMPTIONS.** Provenance for recovered claims and access to a consumer able to challenge them. Understanding is provisional and task-bounded. Static and dynamic evidence have complementary omissions; access to tacit expertise may be essential.

**ORACLE_AND_REGRESSION_LIMITS.** Memory and documentation can be wrong or stale; history does not make a past choice permanently binding. A plausible explanation is not an oracle. Characterisation can support prediction but may capture a defect; unknown behaviour remains explicitly unknown.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** For analysis-only work, compatibility checks are not an executed migration obligation. A later transformation must use the recovered model without assuming it is complete.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Recovery of a model does not establish a recoverable deployment. An operative change requires separate release/effect evidence.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Knowledge holders explain history; current obligation owners determine what should survive. Recollection is evidence, not sole authority.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Ask the relevant person or retain a short decision note rather than reconstructing a comprehensive document set. Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which rationale deserves retention when documentation itself has maintenance cost? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S012; ESME-S014; ESME-S015; ESME-S043; ESME-S047] [ESME-015: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/14)

### ESME-017 — Justified impact boundary

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-017`

**Disposition and kind.** STRONGLY_RETAINED; IMPACT_DECISION_MECHANISM

**Mature form.** Propose an impact boundary from relevant dependencies, challenge it with contrary evidence and widen it when an affected obligation crosses the boundary.

**Controlled failure.** A local edit may affect behaviour outside its apparent file or module boundary.

**Trigger.** A change could propagate beyond the directly edited artefacts.

**Non-trigger and cheap path.** Accept a local boundary with a concrete reason when interfaces and dependencies make the effect local; no whole-system analysis by default.

**Prerequisites.** Baseline identity, change intent and declared dependency evidence with known omissions.

**Consumer and authority.** Maintainers justify the boundary to reviewers and affected consumers; reviewers can require expansion but cannot infer completeness from tool silence.

**Observable consequence.** Affected obligations and excluded areas have an explicit rationale linked to evidence.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Affected obligations and excluded areas have an explicit rationale linked to evidence. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Impact sets are estimates; a tool’s recall in a benchmark does not prove absence of missed effects in a target. How should rare but severe propagation risks affect the cost of boundary verification?

**Anti-ceremony boundary.** Whole-repository dependency graph is optional as a named form. Accept a local boundary with a concrete reason when interfaces and dependencies make the effect local; no whole-system analysis by default.

**Loss from the cheaper form.** A smaller justified boundary may miss an undeclared interaction; include a challenge proportionate to the consequence of that miss.

**Omission/retirement.** Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

**Conflicts and selection conditions.** ESME-T008: Impact completeness versus investigation cost. Scale challenge effort to plausible missed-edge consequence and evidence quality; accept demonstrably local changes locally.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A change could propagate beyond the directly edited artefacts. The intended difference determines which dependency paths matter; a documentation-only update and a schema rewrite need different propagation inquiries.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Include code, API, schema, protocol, configuration, build, policy and relevant ownership/deployment state rather than a universal source-file-only graph.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Affected obligations and excluded areas have an explicit rationale linked to evidence. Impacted observers include direct callers, data readers, operators and combined changes. Preserve their accepted obligations, not every correlation in history.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Label each edge as declared, structurally inferred, dynamically observed or historically correlated and state its guard. Challenge missed paths proportional to consequence.

**COMPREHENSION_ASSUMPTIONS.** Baseline identity, change intent and declared dependency evidence with known omissions. The maintainer must understand enough semantics to interpret a candidate edge; a high-confidence predictor cannot replace that interpretation.

**ORACLE_AND_REGRESSION_LIMITS.** Impact sets are estimates; a tool’s recall in a benchmark does not prove absence of missed effects in a target. Test selected impact hypotheses and plausible omissions. Tool recall on reused benchmark cases does not guarantee target recall.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Identify supported version/schema combinations when dependencies cross deployment or ecosystem boundaries; consumers may upgrade independently.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** A broader impact boundary can require staged release, forward repair or coordinated recovery. A local source revert may not reverse propagated effects.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainers justify the boundary to reviewers and affected consumers; reviewers can require expansion but cannot infer completeness from tool silence.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Accept a local boundary with a concrete reason when interfaces and dependencies make the effect local; no whole-system analysis by default. Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How should rare but severe propagation risks affect the cost of boundary verification? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S013; ESME-S016; ESME-S017; ESME-S044] [ESME-017: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/16)

### ESME-018 — Heterogeneous dependency propagation

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-018`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; DEPENDENCY_MODEL

**Mature form.** Include the dependency kinds through which the proposed change can affect actual consumers, and distinguish declared, inferred and observed edges.

**Controlled failure.** Unmodelled schema, protocol, build, deployment or responsibility dependencies invalidate code-only change analysis.

**Trigger.** The changed object participates in shared data, interfaces, builds, learned feedback or cross-team operation.

**Non-trigger and cheap path.** Do not construct every possible graph; inspect only dependency kinds relevant to the change and its obligations.

**Prerequisites.** Evidence for each consequential edge, its direction and the context in which it is active.

**Consumer and authority.** Maintainers and downstream owners communicate constraints; a graph does not grant control over independent consumers.

**Observable consequence.** The impact account includes relevant non-code and cross-boundary consequences with uncertain edges marked.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The impact account includes relevant non-code and cross-boundary consequences with uncertain edges marked. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Declared package edges are not identical to runtime behaviour; organisational relations cannot be inferred solely from source imports. How can hidden consumers be discovered without imposing an unmaintainable universal dependency model?

**Anti-ceremony boundary.** One universal dependency database is optional as a named form. Do not construct every possible graph; inspect only dependency kinds relevant to the change and its obligations.

**Loss from the cheaper form.** Focused inspection can omit configuration, data or organisational edges outside its chosen kinds; expand when the change can act through them.

**Omission/retirement.** Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

**Conflicts and selection conditions.** ESME-T008: Impact completeness versus investigation cost. Scale challenge effort to plausible missed-edge consequence and evidence quality; accept demonstrably local changes locally.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** The changed object participates in shared data, interfaces, builds, learned feedback or cross-team operation. The intended difference determines which dependency paths matter; a documentation-only update and a schema rewrite need different propagation inquiries.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Include code, API, schema, protocol, configuration, build, policy and relevant ownership/deployment state rather than a universal source-file-only graph.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The impact account includes relevant non-code and cross-boundary consequences with uncertain edges marked. Impacted observers include direct callers, data readers, operators and combined changes. Preserve their accepted obligations, not every correlation in history.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Label each edge as declared, structurally inferred, dynamically observed or historically correlated and state its guard. Challenge missed paths proportional to consequence.

**COMPREHENSION_ASSUMPTIONS.** Evidence for each consequential edge, its direction and the context in which it is active. The maintainer must understand enough semantics to interpret a candidate edge; a high-confidence predictor cannot replace that interpretation.

**ORACLE_AND_REGRESSION_LIMITS.** Declared package edges are not identical to runtime behaviour; organisational relations cannot be inferred solely from source imports. Test selected impact hypotheses and plausible omissions. Tool recall on reused benchmark cases does not guarantee target recall.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Identify supported version/schema combinations when dependencies cross deployment or ecosystem boundaries; consumers may upgrade independently.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** A broader impact boundary can require staged release, forward repair or coordinated recovery. A local source revert may not reverse propagated effects.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainers and downstream owners communicate constraints; a graph does not grant control over independent consumers.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Do not construct every possible graph; inspect only dependency kinds relevant to the change and its obligations. Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How can hidden consumers be discovered without imposing an unmaintainable universal dependency model? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S016; ESME-S041; ESME-S042; ESME-S044; ESME-S053] [ESME-018: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/17)

### ESME-019 — Historical co-change as defeasible evidence

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-019`

**Disposition and kind.** ASSUMPTION_SENSITIVE; PREDICTIVE_EVIDENCE

**Mature form.** Use co-change as a defeasible candidate generator; confirm semantic or organisational relevance before requiring another change.

**Controlled failure.** Historical coupling can reveal dependencies missing from explicit structure, but correlations can be mistaken for necessities.

**Trigger.** History is sufficiently representative and structural evidence leaves uncertainty about likely companion changes.

**Non-trigger and cheap path.** Ignore the predictor for new code, rewritten history or an already understood local dependency.

**Prerequisites.** Clean enough history, meaningful change units and awareness of bulk edits, conventions and process changes.

**Consumer and authority.** Tools suggest; maintainers validate relevance and decide action.

**Observable consequence.** Recommended impacts are either supported, rejected with reason or retained as uncertainty; absence is not certified independence.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Recommended impacts are either supported, rejected with reason or retained as uncertainty; absence is not certified independence. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** S017 explicitly distinguishes historical practice from intended dependencies. Co-change may reflect habit, generated files or a single broad commit. How quickly do predictors become stale after architectural or team changes?

**Anti-ceremony boundary.** Mandatory co-change recommendation approval is optional as a named form. Ignore the predictor for new code, rewritten history or an already understood local dependency.

**Loss from the cheaper form.** Ignoring history may lose a useful clue when intent has vanished; history remains a candidate source rather than a required companion-edit generator.

**Omission/retirement.** Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

**Conflicts and selection conditions.** ESME-T008: Impact completeness versus investigation cost. Scale challenge effort to plausible missed-edge consequence and evidence quality; accept demonstrably local changes locally.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** History is sufficiently representative and structural evidence leaves uncertainty about likely companion changes. The intended difference determines which dependency paths matter; a documentation-only update and a schema rewrite need different propagation inquiries.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Include code, API, schema, protocol, configuration, build, policy and relevant ownership/deployment state rather than a universal source-file-only graph.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Recommended impacts are either supported, rejected with reason or retained as uncertainty; absence is not certified independence. Impacted observers include direct callers, data readers, operators and combined changes. Preserve their accepted obligations, not every correlation in history.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Label each edge as declared, structurally inferred, dynamically observed or historically correlated and state its guard. Challenge missed paths proportional to consequence.

**COMPREHENSION_ASSUMPTIONS.** Clean enough history, meaningful change units and awareness of bulk edits, conventions and process changes. The maintainer must understand enough semantics to interpret a candidate edge; a high-confidence predictor cannot replace that interpretation.

**ORACLE_AND_REGRESSION_LIMITS.** S017 explicitly distinguishes historical practice from intended dependencies. Co-change may reflect habit, generated files or a single broad commit. Test selected impact hypotheses and plausible omissions. Tool recall on reused benchmark cases does not guarantee target recall.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Identify supported version/schema combinations when dependencies cross deployment or ecosystem boundaries; consumers may upgrade independently.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** A broader impact boundary can require staged release, forward repair or coordinated recovery. A local source revert may not reverse propagated effects.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Tools suggest; maintainers validate relevance and decide action.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Ignore the predictor for new code, rewritten history or an already understood local dependency. Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How quickly do predictors become stale after architectural or team changes? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S017; ESME-S044] [ESME-019: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/18)

### ESME-020 — Affected-consumer discovery

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-020`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; CONSUMER_DISCOVERY_AND_COMMUNICATION

**Mature form.** Identify plausible consumers through interfaces, usage, dependency data and consultation; disclose uncertainty and notify those needing action.

**Controlled failure.** A producer can pass its tests while breaking callers, data readers or operators it did not know existed.

**Trigger.** A public or shared behaviour, data format, dependency or support promise changes.

**Non-trigger and cheap path.** For a private bounded use with no external consumer, direct coordination with the local caller may suffice.

**Prerequisites.** A defined support/compatibility surface and channels reaching relevant consumers.

**Consumer and authority.** Producers communicate change and uncertainty; independent consumers decide their own migration and acceptance.

**Observable consequence.** Known affected consumers receive actionable information or an inability to reach them constrains release.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Known affected consumers receive actionable information or an inability to reach them constrains release. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Undeclared consumers may remain undiscoverable; notification does not prove receipt, ability to migrate or consent. When does uncertainty about unknown consumers warrant compatibility scaffolding or delayed change?

**Anti-ceremony boundary.** Complete stakeholder inventory is optional as a named form. For a private bounded use with no external consumer, direct coordination with the local caller may suffice.

**Loss from the cheaper form.** Direct contact with known callers cannot establish the absence of other consumers; retain a notice or compatibility interval where undiscovered use is plausible.

**Omission/retirement.** Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

**Conflicts and selection conditions.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A public or shared behaviour, data format, dependency or support promise changes. The intended difference determines which dependency paths matter; a documentation-only update and a schema rewrite need different propagation inquiries.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Include code, API, schema, protocol, configuration, build, policy and relevant ownership/deployment state rather than a universal source-file-only graph.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Known affected consumers receive actionable information or an inability to reach them constrains release. Impacted observers include direct callers, data readers, operators and combined changes. Preserve their accepted obligations, not every correlation in history.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Label each edge as declared, structurally inferred, dynamically observed or historically correlated and state its guard. Challenge missed paths proportional to consequence.

**COMPREHENSION_ASSUMPTIONS.** A defined support/compatibility surface and channels reaching relevant consumers. The maintainer must understand enough semantics to interpret a candidate edge; a high-confidence predictor cannot replace that interpretation.

**ORACLE_AND_REGRESSION_LIMITS.** Undeclared consumers may remain undiscoverable; notification does not prove receipt, ability to migrate or consent. Test selected impact hypotheses and plausible omissions. Tool recall on reused benchmark cases does not guarantee target recall.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Identify supported version/schema combinations when dependencies cross deployment or ecosystem boundaries; consumers may upgrade independently.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** A broader impact boundary can require staged release, forward repair or coordinated recovery. A local source revert may not reverse propagated effects.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Producers communicate change and uncertainty; independent consumers decide their own migration and acceptance.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** For a private bounded use with no external consumer, direct coordination with the local caller may suffice. Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** When does uncertainty about unknown consumers warrant compatibility scaffolding or delayed change? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S016; ESME-S041; ESME-S042; ESME-S043; ESME-S045] [ESME-020: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/19)

### ESME-021 — Impact false-negative challenge

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-021`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; ADVERSARIAL_EVIDENCE_MECHANISM

**Mature form.** Seek counterexamples outside the proposed boundary using representative consumers, broader regression or a second evidence mode, scaled to consequence.

**Controlled failure.** A plausible impact boundary can survive only because checks search where the model already expects effects.

**Trigger.** High-consequence change, weak dependency evidence, novel configuration or disagreement among analyses.

**Non-trigger and cheap path.** For a trivial closed change, a targeted independent check may dominate broad retesting.

**Prerequisites.** A proposed boundary, plausible missed-edge hypotheses and affordable observations.

**Consumer and authority.** Reviewers and maintainers challenge the analysis; operators or users supply observations beyond development’s model.

**Observable consequence.** A missed effect expands the boundary or changes the decision; negative checks retain stated limits.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: A missed effect expands the boundary or changes the decision; negative checks retain stated limits. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** No finite challenge proves absence of all unknown effects; independent-looking tools may share the same incomplete model. Which challenge strategy gives the best reduction in consequential uncertainty per unit cost?

**Anti-ceremony boundary.** Independent impact audit for every change is optional as a named form. For a trivial closed change, a targeted independent check may dominate broad retesting.

**Loss from the cheaper form.** A small challenge has limited power against hidden edges; widen it when a missed effect would be costly or the first model has weak support.

**Omission/retirement.** Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

**Conflicts and selection conditions.** ESME-T008: Impact completeness versus investigation cost. Scale challenge effort to plausible missed-edge consequence and evidence quality; accept demonstrably local changes locally.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** High-consequence change, weak dependency evidence, novel configuration or disagreement among analyses. The intended difference determines which dependency paths matter; a documentation-only update and a schema rewrite need different propagation inquiries.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Include code, API, schema, protocol, configuration, build, policy and relevant ownership/deployment state rather than a universal source-file-only graph.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** A missed effect expands the boundary or changes the decision; negative checks retain stated limits. Impacted observers include direct callers, data readers, operators and combined changes. Preserve their accepted obligations, not every correlation in history.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Label each edge as declared, structurally inferred, dynamically observed or historically correlated and state its guard. Challenge missed paths proportional to consequence.

**COMPREHENSION_ASSUMPTIONS.** A proposed boundary, plausible missed-edge hypotheses and affordable observations. The maintainer must understand enough semantics to interpret a candidate edge; a high-confidence predictor cannot replace that interpretation.

**ORACLE_AND_REGRESSION_LIMITS.** No finite challenge proves absence of all unknown effects; independent-looking tools may share the same incomplete model. Test selected impact hypotheses and plausible omissions. Tool recall on reused benchmark cases does not guarantee target recall.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Identify supported version/schema combinations when dependencies cross deployment or ecosystem boundaries; consumers may upgrade independently.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** A broader impact boundary can require staged release, forward repair or coordinated recovery. A local source revert may not reverse propagated effects.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Reviewers and maintainers challenge the analysis; operators or users supply observations beyond development’s model.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** For a trivial closed change, a targeted independent check may dominate broad retesting. Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which challenge strategy gives the best reduction in consequential uncertainty per unit cost? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S016; ESME-S017; ESME-S044; ESME-S051] [ESME-021: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/20)

### ESME-022 — Semantic interference analysis for merged changes

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-022`

**Disposition and kind.** ASSUMPTION_SENSITIVE; SEMANTIC_CONFLICT_ANALYSIS

**Mature form.** Analyse or exercise the merged artefact against combined obligations, using interference candidates to guide investigation rather than declaring every flow a conflict.

**Controlled failure.** Two individually acceptable changes can compose into behaviour neither author intended.

**Trigger.** Concurrent changes interact through shared state, dataflow, interfaces or assumptions even when textual merge succeeds.

**Non-trigger and cheap path.** Independent changes with a justified disjoint impact boundary may need only normal combined regression.

**Prerequisites.** A common baseline, both change intents, buildable merged artefact and supported analysis semantics.

**Consumer and authority.** Change authors and integrators resolve intended interaction; a detector cannot infer stakeholder intent from information flow alone.

**Observable consequence.** Consequential interactions are accepted, corrected or kept unresolved before the combined release decision.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Consequential interactions are accepted, corrected or kept unresolved before the combined release decision. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** The inspected study trades greater static recall for lower precision; many cases reuse earlier datasets and unsupported cases limit generality. How well do findings transfer beyond buildable Java cases to configuration, schemas and learned components?

**Anti-ceremony boundary.** Semantic-conflict detector on every merge is optional as a named form. Independent changes with a justified disjoint impact boundary may need only normal combined regression.

**Loss from the cheaper form.** Textual merging alone misses behaviourally interacting edits; focused tests can substitute only for the relevant reachable interactions.

**Omission/retirement.** Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

**Conflicts and selection conditions.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Concurrent changes interact through shared state, dataflow, interfaces or assumptions even when textual merge succeeds. The intended difference determines which dependency paths matter; a documentation-only update and a schema rewrite need different propagation inquiries.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Include code, API, schema, protocol, configuration, build, policy and relevant ownership/deployment state rather than a universal source-file-only graph.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Consequential interactions are accepted, corrected or kept unresolved before the combined release decision. Impacted observers include direct callers, data readers, operators and combined changes. Preserve their accepted obligations, not every correlation in history.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Label each edge as declared, structurally inferred, dynamically observed or historically correlated and state its guard. Challenge missed paths proportional to consequence.

**COMPREHENSION_ASSUMPTIONS.** A common baseline, both change intents, buildable merged artefact and supported analysis semantics. The maintainer must understand enough semantics to interpret a candidate edge; a high-confidence predictor cannot replace that interpretation.

**ORACLE_AND_REGRESSION_LIMITS.** The inspected study trades greater static recall for lower precision; many cases reuse earlier datasets and unsupported cases limit generality. Test selected impact hypotheses and plausible omissions. Tool recall on reused benchmark cases does not guarantee target recall.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Identify supported version/schema combinations when dependencies cross deployment or ecosystem boundaries; consumers may upgrade independently.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** A broader impact boundary can require staged release, forward repair or coordinated recovery. A local source revert may not reverse propagated effects.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Change authors and integrators resolve intended interaction; a detector cannot infer stakeholder intent from information flow alone.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Independent changes with a justified disjoint impact boundary may need only normal combined regression. Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How well do findings transfer beyond buildable Java cases to configuration, schemas and learned components? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S044; ESME-S051] [ESME-022: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/21)

### ESME-023 — Observer-relative preservation obligations

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-023`

**Disposition and kind.** STRONGLY_RETAINED; PRESERVATION_CRITERION

**Mature form.** Name the observers, environments and obligations to remain invariant, separately from intended differences; compare the actual transformation against that boundary.

**Controlled failure.** A transformation can preserve outputs in tests while changing timing, exceptions, persistence or reflective behaviour that consumers rely on.

**Trigger.** Any change claims to preserve behaviour, especially restructuring or compatibility-sensitive repair.

**Non-trigger and cheap path.** A narrow observer and a direct comparison suffice where that is the actual contract; do not require equivalence for irrelevant internal states.

**Prerequisites.** An explicit contract or adjudicated account of relevant observations and environmental assumptions.

**Consumer and authority.** Obligation holders and maintainers determine the preservation surface; a tool’s narrower model cannot silently replace it.

**Observable consequence.** The preservation claim states its observer and exclusions; observed violations are not excused merely because tests pass.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The preservation claim states its observer and exclusions; observed violations are not excused merely because tests pass. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Complete equivalence is often undecidable or intractable; broadening observers may make a previously valid proof inapplicable. Which implicit performance or operational expectations should count as supported obligations?

**Anti-ceremony boundary.** Formal observational-equivalence proof for every refactor is optional as a named form. A narrow observer and a direct comparison suffice where that is the actual contract; do not require equivalence for irrelevant internal states.

**Loss from the cheaper form.** An informal observer boundary can omit timing, persistence or reflection; specify and check those observations when actual consumers rely on them.

**Omission/retirement.** Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

**Conflicts and selection conditions.** ESME-T001: Continuity versus necessary behavioural change. Preserve behaviour with a current supported consumer; change it when legitimate intent is revised and transition consequences are addressed. A failing characterisation test is a question, not automatic veto.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Any change claims to preserve behaviour, especially restructuring or compatibility-sensitive repair. Refactoring preserves the declared external behaviour; repair and feature change intentionally alter some obligations. Mixed changes require an explicit distinction, not always separate commits.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Bind before/after source, language/tool version, configuration and persistent representations to the actual applied transformation.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The preservation claim states its observer and exclusions; observed violations are not excused merely because tests pass. Declare relevant O and E, including exceptions, side effects and performance when part of the supported contract; do not assume all internal differences are observable obligations.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use semantic dependency evidence to determine which consumers could observe the transformation, including reflective and external uses.

**COMPREHENSION_ASSUMPTIONS.** An explicit contract or adjudicated account of relevant observations and environmental assumptions. Applicability requires understanding of the transformation’s preconditions and exclusions. A formal rule does not prove that the implementation satisfies them.

**ORACLE_AND_REGRESSION_LIMITS.** Complete equivalence is often undecidable or intractable; broadening observers may make a previously valid proof inapplicable. Test passage provides partial evidence. Independent preservation obligations and tests of the actual transformed candidate can expose tool or integration defects.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Renaming or restructuring exposed entities may require adapters or a migration; purely internal supported transformations may not require any compatibility machinery.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Reverting a structure change is simple only when no incompatible data/effects escaped. Assess actual release state separately from source-level invertibility.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Obligation holders and maintainers determine the preservation surface; a tool’s narrower model cannot silently replace it.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** A narrow observer and a direct comparison suffice where that is the actual contract; do not require equivalence for irrelevant internal states. Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which implicit performance or operational expectations should count as supported obligations? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: differentiated/limited; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S012; ESME-S018; ESME-S020; ESME-S022; ESME-S045; ESME-S051] [ESME-023: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/22)

### ESME-024 — Transformation preconditions and model scope

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-024`

**Disposition and kind.** ASSUMPTION_SENSITIVE; FORMAL_TRANSFORMATION_CONDITION

**Mature form.** Check the transformation’s preconditions in the actual relevant model, and expose unsupported language or environment features before relying on a preservation argument.

**Controlled failure.** A syntactically legal transformation may violate binding, inheritance, visibility or other semantic constraints.

**Trigger.** An automated or manual transformation relies on a formal or tool-defined refactoring rule.

**Non-trigger and cheap path.** For a small obvious edit, direct semantic reasoning and testing may be cheaper than a general transformation framework.

**Prerequisites.** A valid mapping from actual language/tool version and artefacts to the proof or rule’s assumptions.

**Consumer and authority.** Tool authors establish model-relative guarantees; maintainers verify applicability and retain responsibility for excluded observers.

**Observable consequence.** The applied rule, satisfied assumptions and out-of-model features are identifiable.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The applied rule, satisfied assumptions and out-of-model features are identifiable. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** A proof about a model does not validate its implementation or environmental assumptions; reflection and external persistence may invalidate naive transfer. What affordable validation detects divergence between language evolution and a refactoring tool’s semantic model?

**Anti-ceremony boundary.** Refactoring-tool certification stamp is optional as a named form. For a small obvious edit, direct semantic reasoning and testing may be cheaper than a general transformation framework.

**Loss from the cheaper form.** Direct checks may not cover all proof preconditions; a formal applicability argument is valuable when the language/environment assumptions can actually be established.

**Omission/retirement.** Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

**Conflicts and selection conditions.** ESME-T004: Automated transformation versus review burden. Evaluate correct outcomes and full cost for the task and tool version. Strong narrow transformations can need less manual review; weak oracles demand more independent evidence.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** An automated or manual transformation relies on a formal or tool-defined refactoring rule. Refactoring preserves the declared external behaviour; repair and feature change intentionally alter some obligations. Mixed changes require an explicit distinction, not always separate commits.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Bind before/after source, language/tool version, configuration and persistent representations to the actual applied transformation.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The applied rule, satisfied assumptions and out-of-model features are identifiable. Declare relevant O and E, including exceptions, side effects and performance when part of the supported contract; do not assume all internal differences are observable obligations.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use semantic dependency evidence to determine which consumers could observe the transformation, including reflective and external uses.

**COMPREHENSION_ASSUMPTIONS.** A valid mapping from actual language/tool version and artefacts to the proof or rule’s assumptions. Applicability requires understanding of the transformation’s preconditions and exclusions. A formal rule does not prove that the implementation satisfies them.

**ORACLE_AND_REGRESSION_LIMITS.** A proof about a model does not validate its implementation or environmental assumptions; reflection and external persistence may invalidate naive transfer. Test passage provides partial evidence. Independent preservation obligations and tests of the actual transformed candidate can expose tool or integration defects.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Renaming or restructuring exposed entities may require adapters or a migration; purely internal supported transformations may not require any compatibility machinery.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Reverting a structure change is simple only when no incompatible data/effects escaped. Assess actual release state separately from source-level invertibility.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Tool authors establish model-relative guarantees; maintainers verify applicability and retain responsibility for excluded observers.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** For a small obvious edit, direct semantic reasoning and testing may be cheaper than a general transformation framework. Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** What affordable validation detects divergence between language evolution and a refactoring tool’s semantic model? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: model-bounded formal support; implementation applicability remains unproved; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: differentiated/limited; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S018; ESME-S020; ESME-S051] [ESME-024: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/23)

### ESME-025 — Validation of the actual transformed artefact

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-025`

**Disposition and kind.** STRONGLY_RETAINED; TRANSFORMATION_VALIDATION

**Mature form.** Check the actual transformed baseline using relevant semantic reasoning, tests or comparison; invalidate earlier evidence when consequential inputs change.

**Controlled failure.** A correct transformation rule can be implemented incorrectly, misapplied or followed by another interacting change.

**Trigger.** Any consequential restructuring, generated patch or composed change is proposed for acceptance.

**Non-trigger and cheap path.** A small reviewed diff and a targeted check may be enough; no universal demand for multiple expensive validators.

**Prerequisites.** Candidate identity, obligations and a validation method whose limits are understood.

**Consumer and authority.** Maintainers and reviewers consume validation evidence; the generator cannot self-certify correctness solely through its own success flag.

**Observable consequence.** The exact candidate has evidence for its intended and preserved obligations, with unresolved failures visible.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The exact candidate has evidence for its intended and preserved obligations, with unresolved failures visible. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Validation can share the generator’s assumptions or miss rare environments. More tests are not necessarily more independent evidence. When does independent checking justify its added cost compared with a trustworthy narrow transformation?

**Anti-ceremony boundary.** Transformation validation report is optional as a named form. A small reviewed diff and a targeted check may be enough; no universal demand for multiple expensive validators.

**Loss from the cheaper form.** A small check observes fewer consequences than a broader suite or proof; its adequacy depends on the actual transformation and impact boundary.

**Omission/retirement.** Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

**Conflicts and selection conditions.** ESME-T004: Automated transformation versus review burden. Evaluate correct outcomes and full cost for the task and tool version. Strong narrow transformations can need less manual review; weak oracles demand more independent evidence.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Any consequential restructuring, generated patch or composed change is proposed for acceptance. Refactoring preserves the declared external behaviour; repair and feature change intentionally alter some obligations. Mixed changes require an explicit distinction, not always separate commits.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Bind before/after source, language/tool version, configuration and persistent representations to the actual applied transformation.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The exact candidate has evidence for its intended and preserved obligations, with unresolved failures visible. Declare relevant O and E, including exceptions, side effects and performance when part of the supported contract; do not assume all internal differences are observable obligations.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use semantic dependency evidence to determine which consumers could observe the transformation, including reflective and external uses.

**COMPREHENSION_ASSUMPTIONS.** Candidate identity, obligations and a validation method whose limits are understood. Applicability requires understanding of the transformation’s preconditions and exclusions. A formal rule does not prove that the implementation satisfies them.

**ORACLE_AND_REGRESSION_LIMITS.** Validation can share the generator’s assumptions or miss rare environments. More tests are not necessarily more independent evidence. Test passage provides partial evidence. Independent preservation obligations and tests of the actual transformed candidate can expose tool or integration defects.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Renaming or restructuring exposed entities may require adapters or a migration; purely internal supported transformations may not require any compatibility machinery.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Reverting a structure change is simple only when no incompatible data/effects escaped. Assess actual release state separately from source-level invertibility.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainers and reviewers consume validation evidence; the generator cannot self-certify correctness solely through its own success flag.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** A small reviewed diff and a targeted check may be enough; no universal demand for multiple expensive validators. Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** When does independent checking justify its added cost compared with a trustworthy narrow transformation? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: differentiated/limited; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S018; ESME-S020; ESME-S024; ESME-S051; ESME-S052] [ESME-025: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/24)

### ESME-026 — Separate preservation from intentional behaviour change

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-026`

**Disposition and kind.** STRONGLY_RETAINED; CHANGE_SEMANTICS_BOUNDARY

**Mature form.** Declare intentional behavioural differences independently from structural work; revise obsolete tests through an authorised account of intended behaviour.

**Controlled failure.** A repair may be blocked by tests preserving a defect, or a feature change may be disguised as a supposedly preserving refactor.

**Trigger.** A patch mixes restructuring with correction, adaptation or changed requirements.

**Non-trigger and cheap path.** One combined patch is permissible when separating it increases risk, provided the distinct obligations remain assessable.

**Prerequisites.** A baseline, accepted intended difference and evidence for the behaviour that still must remain stable.

**Consumer and authority.** Current obligation owners authorise semantic change; maintainers may reorganise code within that boundary.

**Observable consequence.** Reviewers can distinguish intended differences from regressions and know why changed tests are justified.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Reviewers can distinguish intended differences from regressions and know why changed tests are justified. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Artificially splitting tightly coupled changes can add churn and temporary inconsistency; separation is conceptual, not always separate commits. What evidence adequately justifies changing a characterisation test when original intent is lost?

**Anti-ceremony boundary.** Separate branch for every preservation and feature change is optional as a named form. One combined patch is permissible when separating it increases risk, provided the distinct obligations remain assessable.

**Loss from the cheaper form.** Combining changes can obscure which differences are intended; preserve independently interpretable acceptance obligations even in one patch.

**Omission/retirement.** Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

**Conflicts and selection conditions.** ESME-T001: Continuity versus necessary behavioural change. Preserve behaviour with a current supported consumer; change it when legitimate intent is revised and transition consequences are addressed. A failing characterisation test is a question, not automatic veto.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A patch mixes restructuring with correction, adaptation or changed requirements. Refactoring preserves the declared external behaviour; repair and feature change intentionally alter some obligations. Mixed changes require an explicit distinction, not always separate commits.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Bind before/after source, language/tool version, configuration and persistent representations to the actual applied transformation.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Reviewers can distinguish intended differences from regressions and know why changed tests are justified. Declare relevant O and E, including exceptions, side effects and performance when part of the supported contract; do not assume all internal differences are observable obligations.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use semantic dependency evidence to determine which consumers could observe the transformation, including reflective and external uses.

**COMPREHENSION_ASSUMPTIONS.** A baseline, accepted intended difference and evidence for the behaviour that still must remain stable. Applicability requires understanding of the transformation’s preconditions and exclusions. A formal rule does not prove that the implementation satisfies them.

**ORACLE_AND_REGRESSION_LIMITS.** Artificially splitting tightly coupled changes can add churn and temporary inconsistency; separation is conceptual, not always separate commits. Test passage provides partial evidence. Independent preservation obligations and tests of the actual transformed candidate can expose tool or integration defects.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Renaming or restructuring exposed entities may require adapters or a migration; purely internal supported transformations may not require any compatibility machinery.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Reverting a structure change is simple only when no incompatible data/effects escaped. Assess actual release state separately from source-level invertibility.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Current obligation owners authorise semantic change; maintainers may reorganise code within that boundary.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** One combined patch is permissible when separating it increases risk, provided the distinct obligations remain assessable. Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** What evidence adequately justifies changing a characterisation test when original intent is lost? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S002; ESME-S018; ESME-S023; ESME-S051; ESME-S059] [ESME-026: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/25)

### ESME-027 — Refactoring benefit tied to a future change class

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-027`

**Disposition and kind.** CONTEXT_DEPENDENT; BENEFIT_EVALUATION

**Mature form.** Name the future change or comprehension task expected to improve, compare intervention cost and evaluate a task-relevant outcome rather than a metric alone.

**Controlled failure.** A cleaner-looking structure can impose immediate risk without helping any likely future task.

**Trigger.** Restructuring is justified by maintainability, comprehension or reduced future change cost.

**Non-trigger and cheap path.** Leave the structure alone, repair locally or improve a small seam when no broader benefit is supported.

**Prerequisites.** A plausible future task population and an explicit account of present disruption and review cost.

**Consumer and authority.** Maintainers propose benefits; those bearing delivery and lifecycle costs decide priority.

**Observable consequence.** The claimed task benefit has evidence or is explicitly withdrawn as uncertain after evaluation.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The claimed task benefit has evidence or is explicitly withdrawn as uncertain after evaluation. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Surveys are self-report; metric studies are not human-task trials; bug-inducing associations are confounded by concurrent edits and change size. Which refactorings produce durable gains for real maintenance tasks after all costs are counted?

**Anti-ceremony boundary.** Refactor-before-change rule is optional as a named form. Leave the structure alone, repair locally or improve a small seam when no broader benefit is supported.

**Loss from the cheaper form.** Local repair can leave repeated future work expensive; accept that cost when expected recurrence does not justify restructuring now.

**Omission/retirement.** Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

**Conflicts and selection conditions.** ESME-T002: Familiarity versus simplification. Prefer restructuring when a plausible recurrent task benefit exceeds relearning, review and regression cost; prefer familiarity when the system is stable or retiring.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Restructuring is justified by maintainability, comprehension or reduced future change cost. Refactoring preserves the declared external behaviour; repair and feature change intentionally alter some obligations. Mixed changes require an explicit distinction, not always separate commits.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Bind before/after source, language/tool version, configuration and persistent representations to the actual applied transformation.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The claimed task benefit has evidence or is explicitly withdrawn as uncertain after evaluation. Declare relevant O and E, including exceptions, side effects and performance when part of the supported contract; do not assume all internal differences are observable obligations.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use semantic dependency evidence to determine which consumers could observe the transformation, including reflective and external uses.

**COMPREHENSION_ASSUMPTIONS.** A plausible future task population and an explicit account of present disruption and review cost. Applicability requires understanding of the transformation’s preconditions and exclusions. A formal rule does not prove that the implementation satisfies them.

**ORACLE_AND_REGRESSION_LIMITS.** Surveys are self-report; metric studies are not human-task trials; bug-inducing associations are confounded by concurrent edits and change size. Test passage provides partial evidence. Independent preservation obligations and tests of the actual transformed candidate can expose tool or integration defects.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Renaming or restructuring exposed entities may require adapters or a migration; purely internal supported transformations may not require any compatibility machinery.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Reverting a structure change is simple only when no incompatible data/effects escaped. Assess actual release state separately from source-level invertibility.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainers propose benefits; those bearing delivery and lifecycle costs decide priority.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Leave the structure alone, repair locally or improve a small seam when no broader benefit is supported. Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which refactorings produce durable gains for real maintenance tasks after all costs are counted? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: differentiated/limited; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S018; ESME-S019; ESME-S020; ESME-S021; ESME-S022] [ESME-027: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/26)

### ESME-029 — Oracle provenance and independent obligations

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-029`

**Disposition and kind.** STRONGLY_RETAINED; ORACLE_ESTABLISHMENT

**Mature form.** Trace acceptance expectations to independent requirements, adjudicated behaviour, domain properties or credible reference evidence; state gaps and conflicts.

**Controlled failure.** Tests can encode obsolete behaviour, mistaken requirements or assumptions shared with the patch generator.

**Trigger.** Test results support a change decision or a test expectation itself changes.

**Non-trigger and cheap path.** A trusted narrow assertion may suffice for a simple obligation; do not build a specification language merely for appearance.

**Prerequisites.** Known oracle provenance, candidate identity and an actor able to resolve intended behaviour.

**Consumer and authority.** Domain experts and obligation owners adjudicate expectations; tests and agents produce evidence, not authority.

**Observable consequence.** The acceptance claim distinguishes observed passage from the supported intended and preserved obligations.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The acceptance claim distinguishes observed passage from the supported intended and preserved obligations. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** No single oracle source is universally reliable; reference systems and humans can be wrong, and complete specifications are costly. How should decisions proceed when the strongest available oracles disagree?

**Anti-ceremony boundary.** Test-oracle sign-off document is optional as a named form. A trusted narrow assertion may suffice for a simple obligation; do not build a specification language merely for appearance.

**Loss from the cheaper form.** A short expectation can omit its provenance or stale assumptions; retain enough justification to distinguish accepted behaviour from accidental output.

**Omission/retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and selection conditions.** ESME-T005: Test preservation versus correction of obsolete behaviour. Adjudicate the supported observer and oracle provenance. Gold-patch identity alone cannot settle correctness.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Test results support a change decision or a test expectation itself changes. Test obligations distinguish intended change, characterisation, preserved contracts and invalid/obsolete expectations. A changed oracle requires its own rationale.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify candidate, baseline, test version, build inputs, configuration and relevant persistent state. Skipped or stale checks are not passed checks.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The acceptance claim distinguishes observed passage from the supported intended and preserved obligations. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use change-impact evidence for selection but challenge omitted areas when its assumptions are weak. Existing tests bound any safe-selection guarantee.

**COMPREHENSION_ASSUMPTIONS.** Known oracle provenance, candidate identity and an actor able to resolve intended behaviour. Understand which expectations are independently justified, inherited, reference-derived or relational. A test producer may share the patch’s misconception.

**ORACLE_AND_REGRESSION_LIMITS.** No single oracle source is universally reliable; reference systems and humans can be wrong, and complete specifications are costly. Characterisation can preserve defects; differential agreement can share bugs; metamorphic relations can be wrong; mutation probes have operator limits. None is a complete general oracle.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Check the actual supported version/schema combinations during staged change. A version number or green isolated build does not establish coexistence safety.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Distinguish code reversion, restoration of compatible data, compensation and forward repair. Irreversible effects require explicit decisions and cannot be promised away.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Domain experts and obligation owners adjudicate expectations; tests and agents produce evidence, not authority.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** A trusted narrow assertion may suffice for a simple obligation; do not build a specification language merely for appearance. Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How should decisions proceed when the strongest available oracles disagree? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S024; ESME-S026; ESME-S051; ESME-S052] [ESME-029: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/28)

### ESME-030 — Characterisation as provisional behavioural evidence

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-030`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; BEHAVIOUR_RECOVERY_TESTING

**Mature form.** Observe and record behaviour relevant to the change, treat it as provisional evidence, and adjudicate which observations are contractual rather than automatically preserving all of them.

**Controlled failure.** Unknown legacy behaviour may be unintentionally lost during change.

**Trigger.** Useful or risky behaviour is poorly documented and can be exercised.

**Non-trigger and cheap path.** A temporary probe, recorded example or focused test can suffice; retire incidental characterisation tests after their consumer disappears.

**Prerequisites.** Representative inputs, environmental context and a way to distinguish intended changes from accidental regression.

**Consumer and authority.** Maintainers collect evidence; domain and downstream consumers determine which behaviours deserve continuity.

**Observable consequence.** Important observed behaviour is either protected, intentionally revised or explicitly unresolved.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Important observed behaviour is either protected, intentionally revised or explicitly unresolved. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Golden outputs may preserve defects or incidental formatting; nondeterminism can make brittle tests and obscure actual obligations. Which undocumented behaviours should be promoted to supported contracts?

**Anti-ceremony boundary.** Permanent golden-master suite is optional as a named form. A temporary probe, recorded example or focused test can suffice; retire incidental characterisation tests after their consumer disappears.

**Loss from the cheaper form.** Temporary or selective characterisation leaves some existing behaviour unrecorded; preserve samples that protect real consumers, not every historical accident.

**Omission/retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and selection conditions.** ESME-T001: Continuity versus necessary behavioural change. Preserve behaviour with a current supported consumer; change it when legitimate intent is revised and transition consequences are addressed. A failing characterisation test is a question, not automatic veto. ESME-T005: Test preservation versus correction of obsolete behaviour. Adjudicate the supported observer and oracle provenance. Gold-patch identity alone cannot settle correctness.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Useful or risky behaviour is poorly documented and can be exercised. Test obligations distinguish intended change, characterisation, preserved contracts and invalid/obsolete expectations. A changed oracle requires its own rationale.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify candidate, baseline, test version, build inputs, configuration and relevant persistent state. Skipped or stale checks are not passed checks.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Important observed behaviour is either protected, intentionally revised or explicitly unresolved. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use change-impact evidence for selection but challenge omitted areas when its assumptions are weak. Existing tests bound any safe-selection guarantee.

**COMPREHENSION_ASSUMPTIONS.** Representative inputs, environmental context and a way to distinguish intended changes from accidental regression. Understand which expectations are independently justified, inherited, reference-derived or relational. A test producer may share the patch’s misconception.

**ORACLE_AND_REGRESSION_LIMITS.** Golden outputs may preserve defects or incidental formatting; nondeterminism can make brittle tests and obscure actual obligations. Characterisation can preserve defects; differential agreement can share bugs; metamorphic relations can be wrong; mutation probes have operator limits. None is a complete general oracle.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Check the actual supported version/schema combinations during staged change. A version number or green isolated build does not establish coexistence safety.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Distinguish code reversion, restoration of compatible data, compensation and forward repair. Irreversible effects require explicit decisions and cannot be promised away.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainers collect evidence; domain and downstream consumers determine which behaviours deserve continuity.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** A temporary probe, recorded example or focused test can suffice; retire incidental characterisation tests after their consumer disappears. Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which undocumented behaviours should be promoted to supported contracts? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S024; ESME-S051; ESME-S059] [ESME-030: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/29)

### ESME-031 — Differential testing with adjudicated differences

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-031`

**Disposition and kind.** CONTEXT_DEPENDENT; COMPARATIVE_TESTING

**Mature form.** Run comparable inputs against the old/new or independent implementations, locate differences and adjudicate them against intended obligations.

**Controlled failure.** Complex semantics can be misimplemented while each implementation appears plausible in isolation.

**Trigger.** A credible reference exists and executions can be made comparable.

**Non-trigger and cheap path.** Use direct expected results for simple cases; no duplicate implementation is required where it adds less evidence than it costs.

**Prerequisites.** Comparable input/environment, known intended differences and awareness of common-mode defects.

**Consumer and authority.** Maintainers investigate discrepancies; a reference implementation is evidence, not an unquestionable specification.

**Observable consequence.** Observed differences are classified as intended, erroneous or unresolved rather than automatically counted as bugs.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Observed differences are classified as intended, erroneous or unresolved rather than automatically counted as bugs. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Agreement can preserve a shared defect; configuration enumeration can be intractable; original behaviour may be obsolete. How should references be chosen when no implementation has stronger semantic authority?

**Anti-ceremony boundary.** Always-on dual execution is optional as a named form. Use direct expected results for simple cases; no duplicate implementation is required where it adds less evidence than it costs.

**Loss from the cheaper form.** Single implementation checks lose the second implementation's discrepancy signal; differential testing is useful only when differences can be adjudicated and cost is justified.

**Omission/retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and selection conditions.** ESME-T005: Test preservation versus correction of obsolete behaviour. Adjudicate the supported observer and oracle provenance. Gold-patch identity alone cannot settle correctness.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A credible reference exists and executions can be made comparable. Test obligations distinguish intended change, characterisation, preserved contracts and invalid/obsolete expectations. A changed oracle requires its own rationale.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify candidate, baseline, test version, build inputs, configuration and relevant persistent state. Skipped or stale checks are not passed checks.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Observed differences are classified as intended, erroneous or unresolved rather than automatically counted as bugs. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use change-impact evidence for selection but challenge omitted areas when its assumptions are weak. Existing tests bound any safe-selection guarantee.

**COMPREHENSION_ASSUMPTIONS.** Comparable input/environment, known intended differences and awareness of common-mode defects. Understand which expectations are independently justified, inherited, reference-derived or relational. A test producer may share the patch’s misconception.

**ORACLE_AND_REGRESSION_LIMITS.** Agreement can preserve a shared defect; configuration enumeration can be intractable; original behaviour may be obsolete. Characterisation can preserve defects; differential agreement can share bugs; metamorphic relations can be wrong; mutation probes have operator limits. None is a complete general oracle.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Check the actual supported version/schema combinations during staged change. A version number or green isolated build does not establish coexistence safety.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Distinguish code reversion, restoration of compatible data, compensation and forward repair. Irreversible effects require explicit decisions and cannot be promised away.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainers investigate discrepancies; a reference implementation is evidence, not an unquestionable specification.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Use direct expected results for simple cases; no duplicate implementation is required where it adds less evidence than it costs. Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How should references be chosen when no implementation has stronger semantic authority? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S051; ESME-S064] [ESME-031: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/30)

### ESME-032 — Metamorphic relations as partial oracles

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-032`

**Disposition and kind.** ASSUMPTION_SENSITIVE; PARTIAL_ORACLE_TECHNIQUE

**Mature form.** Choose justified input/output relations, execute related cases and investigate violations while preserving the relation’s domain assumptions.

**Controlled failure.** A missing exact-output oracle can prevent useful testing of relations that should still hold.

**Trigger.** Exact expected results are difficult but a relevant mathematical or domain relation is credible.

**Non-trigger and cheap path.** Use ordinary assertions when expected results are cheap; do not invent weak relations to inflate a test count.

**Prerequisites.** A valid metamorphic relation, appropriate numerical/nondeterministic tolerance and no unaccounted persistent side effects.

**Consumer and authority.** Domain specialists justify relations; maintainers implement and interpret tests.

**Observable consequence.** The relation is checked for stated cases, with no claim that satisfaction proves arbitrary output correctness.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The relation is checked for stated cases, with no claim that satisfaction proves arbitrary output correctness. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** A wrong relation rejects correct behaviour; a weak relation accepts many wrong outputs; mined invariants can reproduce existing defects. How can useful relations be validated cheaply for changing learned or probabilistic systems?

**Anti-ceremony boundary.** Catalogue of metamorphic relations is optional as a named form. Use ordinary assertions when expected results are cheap; do not invent weak relations to inflate a test count.

**Loss from the cheaper form.** A few relations expose only a subset of possible errors; expanding the catalogue helps only when new relations are independently valid for the domain.

**Omission/retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and selection conditions.** ESME-T005: Test preservation versus correction of obsolete behaviour. Adjudicate the supported observer and oracle provenance. Gold-patch identity alone cannot settle correctness.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Exact expected results are difficult but a relevant mathematical or domain relation is credible. Test obligations distinguish intended change, characterisation, preserved contracts and invalid/obsolete expectations. A changed oracle requires its own rationale.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify candidate, baseline, test version, build inputs, configuration and relevant persistent state. Skipped or stale checks are not passed checks.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The relation is checked for stated cases, with no claim that satisfaction proves arbitrary output correctness. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use change-impact evidence for selection but challenge omitted areas when its assumptions are weak. Existing tests bound any safe-selection guarantee.

**COMPREHENSION_ASSUMPTIONS.** A valid metamorphic relation, appropriate numerical/nondeterministic tolerance and no unaccounted persistent side effects. Understand which expectations are independently justified, inherited, reference-derived or relational. A test producer may share the patch’s misconception.

**ORACLE_AND_REGRESSION_LIMITS.** A wrong relation rejects correct behaviour; a weak relation accepts many wrong outputs; mined invariants can reproduce existing defects. Characterisation can preserve defects; differential agreement can share bugs; metamorphic relations can be wrong; mutation probes have operator limits. None is a complete general oracle.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Check the actual supported version/schema combinations during staged change. A version number or green isolated build does not establish coexistence safety.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Distinguish code reversion, restoration of compatible data, compensation and forward repair. Irreversible effects require explicit decisions and cannot be promised away.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Domain specialists justify relations; maintainers implement and interpret tests.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Use ordinary assertions when expected results are cheap; do not invent weak relations to inflate a test count. Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How can useful relations be validated cheaply for changing learned or probabilistic systems? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: model-bounded formal support; implementation applicability remains unproved; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S051; ESME-S063] [ESME-032: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/31)

### ESME-033 — Mutation analysis as an adequacy probe

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-033`

**Disposition and kind.** CONTEXT_DEPENDENT; TEST_ADEQUACY_PROBE

**Mature form.** Use selected mutation operators to challenge tests, investigate surviving mutants and improve assertions where the mutant represents a relevant fault.

**Controlled failure.** High execution coverage can coexist with weak assertions that miss meaningful faults.

**Trigger.** Critical regression claims depend on a test suite whose fault sensitivity is uncertain.

**Non-trigger and cheap path.** A few manually chosen fault injections may be enough; skip large mutation campaigns when equivalent mutants or cost dominate.

**Prerequisites.** Valid operators, interpretable mutants and a correct oracle for deciding whether altered behaviour matters.

**Consumer and authority.** Test maintainers interpret survivors; a mutation score does not authorise release or define correctness.

**Observable consequence.** Relevant surviving mutants lead to improved tests or an explicit explanation of irrelevance.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Relevant surviving mutants lead to improved tests or an explicit explanation of irrelevance. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** The real-fault relationship is sample- and operator-dependent; equivalent mutants and selected reproducible bugs limit interpretation. Which operator set most economically represents a target’s consequential fault classes?

**Anti-ceremony boundary.** Full mutation campaign for every patch is optional as a named form. A few manually chosen fault injections may be enough; skip large mutation campaigns when equivalent mutants or cost dominate.

**Loss from the cheaper form.** A smaller challenge can miss oracle weaknesses revealed by additional mutants; larger campaigns require a useful fault model and an affordable consumer action.

**Omission/retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and selection conditions.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Critical regression claims depend on a test suite whose fault sensitivity is uncertain. Test obligations distinguish intended change, characterisation, preserved contracts and invalid/obsolete expectations. A changed oracle requires its own rationale.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify candidate, baseline, test version, build inputs, configuration and relevant persistent state. Skipped or stale checks are not passed checks.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Relevant surviving mutants lead to improved tests or an explicit explanation of irrelevance. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use change-impact evidence for selection but challenge omitted areas when its assumptions are weak. Existing tests bound any safe-selection guarantee.

**COMPREHENSION_ASSUMPTIONS.** Valid operators, interpretable mutants and a correct oracle for deciding whether altered behaviour matters. Understand which expectations are independently justified, inherited, reference-derived or relational. A test producer may share the patch’s misconception.

**ORACLE_AND_REGRESSION_LIMITS.** The real-fault relationship is sample- and operator-dependent; equivalent mutants and selected reproducible bugs limit interpretation. Characterisation can preserve defects; differential agreement can share bugs; metamorphic relations can be wrong; mutation probes have operator limits. None is a complete general oracle.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Check the actual supported version/schema combinations during staged change. A version number or green isolated build does not establish coexistence safety.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Distinguish code reversion, restoration of compatible data, compensation and forward repair. Irreversible effects require explicit decisions and cannot be promised away.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Test maintainers interpret survivors; a mutation score does not authorise release or define correctness.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** A few manually chosen fault injections may be enough; skip large mutation campaigns when equivalent mutants or cost dominate. Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which operator set most economically represents a target’s consequential fault classes? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S051; ESME-S062] [ESME-033: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/32)

### ESME-034 — Regression selection under explicit safety and cost assumptions

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-034`

**Disposition and kind.** ASSUMPTION_SENSITIVE; REGRESSION_SELECTION

**Mature form.** Select tests using change/dependency evidence and stated safety assumptions; include analysis, selection and validation costs in the comparison.

**Controlled failure.** Running every available test can consume resources without proportional information, but unsafe omission can hide regression.

**Trigger.** Retest-all cost is consequential and change impact can be analysed well enough to support selection.

**Non-trigger and cheap path.** Run the whole small suite when selection overhead exceeds savings.

**Prerequisites.** A recoverable baseline, test-to-behaviour mapping and explicit handling of environment and nondeterminism.

**Consumer and authority.** Test/release owners choose tolerable omission risk; a safe-selection theorem is relative to the existing tests, not complete correctness.

**Observable consequence.** The selected set and omitted-test rationale are identifiable; selection failure expands or abandons the optimisation.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The selected set and omitted-test rationale are identifiable; selection failure expands or abandons the optimisation. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Safe selection does not repair inadequate tests or wrong oracles; analysis overhead and implementation defects can erase benefits. How should flaky tests and configuration-dependent dependencies affect selection guarantees?

**Anti-ceremony boundary.** Mandatory regression-selection engine is optional as a named form. Run the whole small suite when selection overhead exceeds savings.

**Loss from the cheaper form.** Retest-all gives up potential execution savings but avoids selection analysis and omission risk; use it when the full suite is cheap.

**Omission/retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and selection conditions.** ESME-T008: Impact completeness versus investigation cost. Scale challenge effort to plausible missed-edge consequence and evidence quality; accept demonstrably local changes locally. ESME-T009: Early feedback versus evidence breadth. A release decision may wait for critical checks even when routine feedback is prioritised. Small suites favour retest-all.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Retest-all cost is consequential and change impact can be analysed well enough to support selection. Test obligations distinguish intended change, characterisation, preserved contracts and invalid/obsolete expectations. A changed oracle requires its own rationale.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify candidate, baseline, test version, build inputs, configuration and relevant persistent state. Skipped or stale checks are not passed checks.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The selected set and omitted-test rationale are identifiable; selection failure expands or abandons the optimisation. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use change-impact evidence for selection but challenge omitted areas when its assumptions are weak. Existing tests bound any safe-selection guarantee.

**COMPREHENSION_ASSUMPTIONS.** A recoverable baseline, test-to-behaviour mapping and explicit handling of environment and nondeterminism. Understand which expectations are independently justified, inherited, reference-derived or relational. A test producer may share the patch’s misconception.

**ORACLE_AND_REGRESSION_LIMITS.** Safe selection does not repair inadequate tests or wrong oracles; analysis overhead and implementation defects can erase benefits. Characterisation can preserve defects; differential agreement can share bugs; metamorphic relations can be wrong; mutation probes have operator limits. None is a complete general oracle.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Check the actual supported version/schema combinations during staged change. A version number or green isolated build does not establish coexistence safety.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Distinguish code reversion, restoration of compatible data, compensation and forward repair. Irreversible effects require explicit decisions and cannot be promised away.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Test/release owners choose tolerable omission risk; a safe-selection theorem is relative to the existing tests, not complete correctness.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Run the whole small suite when selection overhead exceeds savings. Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How should flaky tests and configuration-dependent dependencies affect selection guarantees? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: model-bounded formal support; implementation applicability remains unproved; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S023; ESME-S051] [ESME-034: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/33)

### ESME-035 — Test prioritisation under interruption and feedback costs

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-035`

**Disposition and kind.** CONTEXT_DEPENDENT; FEEDBACK_SCHEDULING

**Mature form.** Prioritise evidence according to failure consequence and decision timing; record skipped or unfinished checks as such, not as passed.

**Controlled failure.** A slow schedule can delay high-value feedback, while aggressive savings can hide or postpone failures.

**Trigger.** Execution may be interrupted or feedback latency materially affects repair/release decisions.

**Non-trigger and cheap path.** Use the ordinary order for a fast suite; do not train a predictor without a meaningful latency problem.

**Prerequisites.** Interpretable historical evidence, stable enough workload and an explicit delay tolerance.

**Consumer and authority.** Maintainers and release consumers set decision deadlines; scheduling tools only allocate observation effort.

**Observable consequence.** The decision knows which obligations were checked, delayed or not examined.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The decision knows which obligations were checked, delayed or not examined. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Prediction may leak future data; build counts are incomplete cost proxies; reordering can starve rare tests and delay discovery. How much delay is acceptable for a rare severe regression compared with routine development feedback?

**Anti-ceremony boundary.** Elaborate test-priority ranking is optional as a named form. Use the ordinary order for a fast suite; do not train a predictor without a meaningful latency problem.

**Loss from the cheaper form.** A simple order may reveal some failures later; ranking adds value only when earlier detection changes an action and exceeds ranking cost.

**Omission/retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and selection conditions.** ESME-T009: Early feedback versus evidence breadth. A release decision may wait for critical checks even when routine feedback is prioritised. Small suites favour retest-all.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Execution may be interrupted or feedback latency materially affects repair/release decisions. Test obligations distinguish intended change, characterisation, preserved contracts and invalid/obsolete expectations. A changed oracle requires its own rationale.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify candidate, baseline, test version, build inputs, configuration and relevant persistent state. Skipped or stale checks are not passed checks.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The decision knows which obligations were checked, delayed or not examined. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use change-impact evidence for selection but challenge omitted areas when its assumptions are weak. Existing tests bound any safe-selection guarantee.

**COMPREHENSION_ASSUMPTIONS.** Interpretable historical evidence, stable enough workload and an explicit delay tolerance. Understand which expectations are independently justified, inherited, reference-derived or relational. A test producer may share the patch’s misconception.

**ORACLE_AND_REGRESSION_LIMITS.** Prediction may leak future data; build counts are incomplete cost proxies; reordering can starve rare tests and delay discovery. Characterisation can preserve defects; differential agreement can share bugs; metamorphic relations can be wrong; mutation probes have operator limits. None is a complete general oracle.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Check the actual supported version/schema combinations during staged change. A version number or green isolated build does not establish coexistence safety.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Distinguish code reversion, restoration of compatible data, compensation and forward repair. Irreversible effects require explicit decisions and cannot be promised away.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainers and release consumers set decision deadlines; scheduling tools only allocate observation effort.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Use the ordinary order for a fast suite; do not train a predictor without a meaningful latency problem. Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How much delay is acceptable for a rare severe regression compared with routine development feedback? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S023; ESME-S051; ESME-S058; ESME-S066] [ESME-035: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/34)

### ESME-036 — Reproducible and identifiable build evidence

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-036`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; BUILD_IDENTITY_AND_REPRODUCTION

**Mature form.** Identify build inputs and expected outputs; reproduce the relevant artefact or explain environmental variance and validate what is actually shipped.

**Controlled failure.** A patch validated in one environment may produce a different shipped artefact or be impossible to rebuild.

**Trigger.** Release, archival reconstruction or cross-environment validation depends on build identity.

**Non-trigger and cheap path.** For a disposable local script, a versioned command and environment record may suffice; bit-for-bit output is not always the necessary observer.

**Prerequisites.** Controlled or recorded toolchain/dependencies, available inputs and a declared comparison boundary.

**Consumer and authority.** Build and release maintainers provide provenance; reproducibility does not grant trust in source correctness.

**Observable consequence.** The artefact under review is tied to its inputs, and claimed reproducibility is demonstrated within the stated boundary.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The artefact under review is tied to its inputs, and claimed reproducibility is demonstrated within the stated boundary. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Identical output can identically reproduce a defect; remote mutable inputs and proprietary dependencies can block reconstruction. Which environment details are necessary for a future consumer’s reconstruction task?

**Anti-ceremony boundary.** Reproducible-build badge is optional as a named form. For a disposable local script, a versioned command and environment record may suffice; bit-for-bit output is not always the necessary observer.

**Loss from the cheaper form.** A merely identified build cannot establish byte-for-byte reproducibility; decide whether independent reproduction is an actual preservation or supply requirement.

**Omission/retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and selection conditions.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Release, archival reconstruction or cross-environment validation depends on build identity. Test obligations distinguish intended change, characterisation, preserved contracts and invalid/obsolete expectations. A changed oracle requires its own rationale.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify candidate, baseline, test version, build inputs, configuration and relevant persistent state. Skipped or stale checks are not passed checks.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The artefact under review is tied to its inputs, and claimed reproducibility is demonstrated within the stated boundary. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use change-impact evidence for selection but challenge omitted areas when its assumptions are weak. Existing tests bound any safe-selection guarantee.

**COMPREHENSION_ASSUMPTIONS.** Controlled or recorded toolchain/dependencies, available inputs and a declared comparison boundary. Understand which expectations are independently justified, inherited, reference-derived or relational. A test producer may share the patch’s misconception.

**ORACLE_AND_REGRESSION_LIMITS.** Identical output can identically reproduce a defect; remote mutable inputs and proprietary dependencies can block reconstruction. Characterisation can preserve defects; differential agreement can share bugs; metamorphic relations can be wrong; mutation probes have operator limits. None is a complete general oracle.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Check the actual supported version/schema combinations during staged change. A version number or green isolated build does not establish coexistence safety.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Distinguish code reversion, restoration of compatible data, compensation and forward repair. Irreversible effects require explicit decisions and cannot be promised away.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Build and release maintainers provide provenance; reproducibility does not grant trust in source correctness.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** For a disposable local script, a versioned command and environment record may suffice; bit-for-bit output is not always the necessary observer. Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which environment details are necessary for a future consumer’s reconstruction task? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S002; ESME-S030; ESME-S038; ESME-S046] [ESME-036: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/35)

### ESME-037 — Continuous integration with consumed feedback

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-037`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; INTEGRATION_FEEDBACK

**Mature form.** Run appropriate checks on integrated states, route failures to someone able to act, and make skipped, stale or failing observations visible to release decisions.

**Controlled failure.** Integration failures accumulate when work is combined rarely or results have no responsible consumer.

**Trigger.** Multiple changes integrate frequently enough that delayed failures have material cost.

**Non-trigger and cheap path.** For rare changes, a manual reproducible integration check may provide equivalent evidence.

**Prerequisites.** Identifiable integrated state, useful checks, available execution resources and a responding maintainer.

**Consumer and authority.** The integration service observes; maintainers diagnose and fix; release authority decides whether remaining uncertainty permits delivery.

**Observable consequence.** A failed or missing check changes action, or an explicit authorised exception records its implications.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: A failed or missing check changes action, or an explicit authorised exception records its implications. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Adoption associations do not prove causal survival benefits; flaky or ignored checks can become expensive ceremony. Which cadence and selection policy maximise useful feedback under constrained resources?

**Anti-ceremony boundary.** Required CI dashboard and green badge is optional as a named form. For rare changes, a manual reproducible integration check may provide equivalent evidence.

**Loss from the cheaper form.** Direct local checking lacks automatically shared timely feedback; use it only when coordination and integration consequences are truly local.

**Omission/retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and selection conditions.** ESME-T009: Early feedback versus evidence breadth. A release decision may wait for critical checks even when routine feedback is prioritised. Small suites favour retest-all.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Multiple changes integrate frequently enough that delayed failures have material cost. Test obligations distinguish intended change, characterisation, preserved contracts and invalid/obsolete expectations. A changed oracle requires its own rationale.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify candidate, baseline, test version, build inputs, configuration and relevant persistent state. Skipped or stale checks are not passed checks.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** A failed or missing check changes action, or an explicit authorised exception records its implications. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use change-impact evidence for selection but challenge omitted areas when its assumptions are weak. Existing tests bound any safe-selection guarantee.

**COMPREHENSION_ASSUMPTIONS.** Identifiable integrated state, useful checks, available execution resources and a responding maintainer. Understand which expectations are independently justified, inherited, reference-derived or relational. A test producer may share the patch’s misconception.

**ORACLE_AND_REGRESSION_LIMITS.** Adoption associations do not prove causal survival benefits; flaky or ignored checks can become expensive ceremony. Characterisation can preserve defects; differential agreement can share bugs; metamorphic relations can be wrong; mutation probes have operator limits. None is a complete general oracle.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Check the actual supported version/schema combinations during staged change. A version number or green isolated build does not establish coexistence safety.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Distinguish code reversion, restoration of compatible data, compensation and forward repair. Irreversible effects require explicit decisions and cannot be promised away.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** The integration service observes; maintainers diagnose and fix; release authority decides whether remaining uncertainty permits delivery.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** For rare changes, a manual reproducible integration check may provide equivalent evidence. Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which cadence and selection policy maximise useful feedback under constrained resources? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S002; ESME-S040; ESME-S058] [ESME-037: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/36)

### ESME-038 — Declared compatibility surface and version policy

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-038`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; COMPATIBILITY_CONTRACT

**Mature form.** Declare the supported interface/behaviour surface and transition policy, including exceptions, and test changes against the expectations actually communicated.

**Controlled failure.** Version labels or undocumented assumptions can give consumers false expectations about safe upgrades.

**Trigger.** Independent consumers rely on an API, format, behaviour or support promise.

**Non-trigger and cheap path.** For a private coordinated consumer, a direct agreement can replace a public versioning policy.

**Prerequisites.** An identifiable producer, consumers and evidence for the promised compatibility dimensions.

**Consumer and authority.** Producers define and honour published support commitments; exceptional breakage requires the appropriate authority and communication.

**Observable consequence.** Consumers can determine what an upgrade promises and which actions a changed behaviour requires.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Consumers can determine what an upgrade promises and which actions a changed behaviour requires. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Undocumented does not automatically mean private; version numbers alone prove neither compatibility nor consumer readiness. How should widely relied-on but unintentionally exposed behaviour enter a support policy?

**Anti-ceremony boundary.** Version-number convention as compatibility proof is optional as a named form. For a private coordinated consumer, a direct agreement can replace a public versioning policy.

**Loss from the cheaper form.** Direct contract comparison lacks the convention's communication convenience; a label can help consumers but cannot replace evidence about changed behaviour.

**Omission/retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and selection conditions.** ESME-T001: Continuity versus necessary behavioural change. Preserve behaviour with a current supported consumer; change it when legitimate intent is revised and transition consequences are addressed. A failing characterisation test is a question, not automatic veto.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Independent consumers rely on an API, format, behaviour or support promise. Test obligations distinguish intended change, characterisation, preserved contracts and invalid/obsolete expectations. A changed oracle requires its own rationale.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify candidate, baseline, test version, build inputs, configuration and relevant persistent state. Skipped or stale checks are not passed checks.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Consumers can determine what an upgrade promises and which actions a changed behaviour requires. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use change-impact evidence for selection but challenge omitted areas when its assumptions are weak. Existing tests bound any safe-selection guarantee.

**COMPREHENSION_ASSUMPTIONS.** An identifiable producer, consumers and evidence for the promised compatibility dimensions. Understand which expectations are independently justified, inherited, reference-derived or relational. A test producer may share the patch’s misconception.

**ORACLE_AND_REGRESSION_LIMITS.** Undocumented does not automatically mean private; version numbers alone prove neither compatibility nor consumer readiness. Characterisation can preserve defects; differential agreement can share bugs; metamorphic relations can be wrong; mutation probes have operator limits. None is a complete general oracle.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Check the actual supported version/schema combinations during staged change. A version number or green isolated build does not establish coexistence safety.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Distinguish code reversion, restoration of compatible data, compensation and forward repair. Irreversible effects require explicit decisions and cannot be promised away.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Producers define and honour published support commitments; exceptional breakage requires the appropriate authority and communication.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** For a private coordinated consumer, a direct agreement can replace a public versioning policy. Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How should widely relied-on but unintentionally exposed behaviour enter a support policy? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S043; ESME-S045; ESME-S051] [ESME-038: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/37)

### ESME-039 — Mixed-version compatibility conditions

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-039`

**Disposition and kind.** ASSUMPTION_SENSITIVE; COEXISTENCE_CONSTRAINT

**Mature form.** Identify permitted producer/consumer and schema/version combinations; enforce sequencing or adapters where not all combinations are compatible.

**Controlled failure.** Each endpoint can pass isolated tests while mixed-version interactions fail.

**Trigger.** A deployment, dependency ecosystem or migration permits mixed versions.

**Non-trigger and cheap path.** Use a genuinely quiescent coordinated cutover when it is cheaper and acceptable; then the mixed-version matrix may be unnecessary.

**Prerequisites.** Known version combinations, routing/data ownership and a way to prevent unsupported interactions.

**Consumer and authority.** Operators coordinate rollout; independent consumers retain their own upgrade authority and may constrain timing.

**Observable consequence.** Only supported combinations operate, or unsupported combinations are detected and contained.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Only supported combinations operate, or unsupported combinations are detected and contained. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Combinations grow rapidly; wrappers can hide disagreement and remain indefinitely; external consumers may not follow the intended order. What minimum compatibility window is affordable when consumer upgrades are outside producer control?

**Anti-ceremony boundary.** Full mixed-version compatibility matrix is optional as a named form. Use a genuinely quiescent coordinated cutover when it is cheaper and acceptable; then the mixed-version matrix may be unnecessary.

**Loss from the cheaper form.** Constraining deployments to fewer combinations sacrifices rollout flexibility; that can be cheaper and safer than testing unsupported combinations.

**Omission/retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and selection conditions.** ESME-T007: Coexistence versus quiescent cutover. Use coexistence only when partition and reconciliation costs are tolerable; use quiescence when an accepted stable boundary is credible.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A deployment, dependency ecosystem or migration permits mixed versions. Test obligations distinguish intended change, characterisation, preserved contracts and invalid/obsolete expectations. A changed oracle requires its own rationale.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify candidate, baseline, test version, build inputs, configuration and relevant persistent state. Skipped or stale checks are not passed checks.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Only supported combinations operate, or unsupported combinations are detected and contained. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use change-impact evidence for selection but challenge omitted areas when its assumptions are weak. Existing tests bound any safe-selection guarantee.

**COMPREHENSION_ASSUMPTIONS.** Known version combinations, routing/data ownership and a way to prevent unsupported interactions. Understand which expectations are independently justified, inherited, reference-derived or relational. A test producer may share the patch’s misconception.

**ORACLE_AND_REGRESSION_LIMITS.** Combinations grow rapidly; wrappers can hide disagreement and remain indefinitely; external consumers may not follow the intended order. Characterisation can preserve defects; differential agreement can share bugs; metamorphic relations can be wrong; mutation probes have operator limits. None is a complete general oracle.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Check the actual supported version/schema combinations during staged change. A version number or green isolated build does not establish coexistence safety.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Distinguish code reversion, restoration of compatible data, compensation and forward repair. Irreversible effects require explicit decisions and cannot be promised away.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Operators coordinate rollout; independent consumers retain their own upgrade authority and may constrain timing.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Use a genuinely quiescent coordinated cutover when it is cheaper and acceptable; then the mixed-version matrix may be unnecessary. Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** What minimum compatibility window is affordable when consumer upgrades are outside producer control? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S031; ESME-S038; ESME-S043; ESME-S045; ESME-S053] [ESME-039: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/38)

### ESME-040 — Staged exposure with actionable observations

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-040`

**Disposition and kind.** CONTEXT_DEPENDENT; EXPOSURE_CONTROL_AND_OBSERVATION

**Mature form.** Expose a bounded population or function, observe predeclared consequences and expand, stop or repair according to actionable evidence.

**Controlled failure.** A large untested exposure can make regression expensive to contain; a nominal stage can provide no useful signal.

**Trigger.** Consequences can be observed before full exposure and populations or functions can be separated safely.

**Non-trigger and cheap path.** Use a direct cutover for a tiny reversible change or when staging introduces more inconsistency than it reduces risk.

**Prerequisites.** Meaningful observations, a control over exposure and feasible recovery/forward-repair actions.

**Consumer and authority.** Operators control exposure within authorisation; affected users’ obligations remain relevant even in a small stage.

**Observable consequence.** Observed failure changes rollout or repair action, and the released population/state is identifiable.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Observed failure changes rollout or repair action, and the released population/state is identifiable. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** A quiet stage may miss rare or delayed failures; selection can make early users unrepresentative; dual operation adds complexity. Which observations and exposure limits detect the consequential failure modes soon enough to act?

**Anti-ceremony boundary.** Canary release for every change is optional as a named form. Use a direct cutover for a tiny reversible change or when staging introduces more inconsistency than it reduces risk.

**Loss from the cheaper form.** A direct release forgoes early limited-exposure observation; acceptable only when the experiment would be uninformative or proportionate alternatives address its risk.

**Omission/retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and selection conditions.** ESME-T009: Early feedback versus evidence breadth. A release decision may wait for critical checks even when routine feedback is prioritised. Small suites favour retest-all.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Consequences can be observed before full exposure and populations or functions can be separated safely. Test obligations distinguish intended change, characterisation, preserved contracts and invalid/obsolete expectations. A changed oracle requires its own rationale.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify candidate, baseline, test version, build inputs, configuration and relevant persistent state. Skipped or stale checks are not passed checks.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Observed failure changes rollout or repair action, and the released population/state is identifiable. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use change-impact evidence for selection but challenge omitted areas when its assumptions are weak. Existing tests bound any safe-selection guarantee.

**COMPREHENSION_ASSUMPTIONS.** Meaningful observations, a control over exposure and feasible recovery/forward-repair actions. Understand which expectations are independently justified, inherited, reference-derived or relational. A test producer may share the patch’s misconception.

**ORACLE_AND_REGRESSION_LIMITS.** A quiet stage may miss rare or delayed failures; selection can make early users unrepresentative; dual operation adds complexity. Characterisation can preserve defects; differential agreement can share bugs; metamorphic relations can be wrong; mutation probes have operator limits. None is a complete general oracle.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Check the actual supported version/schema combinations during staged change. A version number or green isolated build does not establish coexistence safety.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Distinguish code reversion, restoration of compatible data, compensation and forward repair. Irreversible effects require explicit decisions and cannot be promised away.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Operators control exposure within authorisation; affected users’ obligations remain relevant even in a small stage.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Use a direct cutover for a tiny reversible change or when staging introduces more inconsistency than it reduces risk. Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which observations and exposure limits detect the consequential failure modes soon enough to act? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S035; ESME-S036; ESME-S037; ESME-S038] [ESME-040: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/39)

### ESME-041 — State-and-effect recovery rather than code reversion alone

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-041`

**Disposition and kind.** STRONGLY_RETAINED; RECOVERY_AND_EFFECT_CONTROL

**Mature form.** Classify reversible and irreversible effects; demonstrate restoration/reconciliation where promised, otherwise plan forward repair or explicitly authorised loss.

**Controlled failure.** Reverting code can leave converted data, sent messages or external actions inconsistent or irretrievable.

**Trigger.** A change writes persistent data, alters schemas or causes external effects whose reversal matters.

**Non-trigger and cheap path.** For a pure read-only reversible change, restoring the prior artefact may genuinely be sufficient.

**Prerequisites.** Usable backups/logs or compensating capabilities, retention/access rights and an understood recovery point.

**Consumer and authority.** Operators perform recovery; data and service obligation owners authorise irreversible actions and residual losses.

**Observable consequence.** The recovered or repaired state satisfies stated obligations, with unrecoverable effects disclosed.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The recovered or repaired state satisfies stated obligations, with unrecoverable effects disclosed. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** GitLab’s incident shows that backup existence and restore compatibility can fail; compensation is not necessarily a true inverse. How should a decision value low-probability irreversible losses when no complete recovery is possible?

**Anti-ceremony boundary.** Rollback checkbox or code-revert button is optional as a named form. For a pure read-only reversible change, restoring the prior artefact may genuinely be sufficient.

**Loss from the cheaper form.** A narrower recovery plan may leave persistent data or external effects unrecoverable; explicitly accept or provide forward repair for those effects rather than imply undo.

**Omission/retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and selection conditions.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A change writes persistent data, alters schemas or causes external effects whose reversal matters. Test obligations distinguish intended change, characterisation, preserved contracts and invalid/obsolete expectations. A changed oracle requires its own rationale.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify candidate, baseline, test version, build inputs, configuration and relevant persistent state. Skipped or stale checks are not passed checks.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The recovered or repaired state satisfies stated obligations, with unrecoverable effects disclosed. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Use change-impact evidence for selection but challenge omitted areas when its assumptions are weak. Existing tests bound any safe-selection guarantee.

**COMPREHENSION_ASSUMPTIONS.** Usable backups/logs or compensating capabilities, retention/access rights and an understood recovery point. Understand which expectations are independently justified, inherited, reference-derived or relational. A test producer may share the patch’s misconception.

**ORACLE_AND_REGRESSION_LIMITS.** GitLab’s incident shows that backup existence and restore compatibility can fail; compensation is not necessarily a true inverse. Characterisation can preserve defects; differential agreement can share bugs; metamorphic relations can be wrong; mutation probes have operator limits. None is a complete general oracle.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Check the actual supported version/schema combinations during staged change. A version number or green isolated build does not establish coexistence safety.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Distinguish code reversion, restoration of compatible data, compensation and forward repair. Irreversible effects require explicit decisions and cannot be promised away.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Operators perform recovery; data and service obligation owners authorise irreversible actions and residual losses.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** For a pure read-only reversible change, restoring the prior artefact may genuinely be sufficient. Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How should a decision value low-probability irreversible losses when no complete recovery is possible? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S038; ESME-S053] [ESME-041: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/40)

### ESME-042 — Compare maintenance, migration, replacement and non-change

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-042`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; LIFECYCLE_OPTION_SELECTION

**Mature form.** Compare options against utility, constraints, knowledge, migration risk and full lifecycle cost, including deliberate non-change and retirement.

**Controlled failure.** Replacement can discard undocumented requirements; indefinite patching can sustain excessive cost or unsupported risk.

**Trigger.** Current maintenance no longer clearly serves required outcomes or a substantial migration is proposed.

**Non-trigger and cheap path.** A bounded repair or continued operation may dominate a programme of replacement.

**Prerequisites.** An honest baseline of current value and constraints, credible alternatives and attention to transition as well as end-state cost.

**Consumer and authority.** Product/service and data owners choose the objective and acceptable risk; maintainers establish feasibility and hidden obligations.

**Observable consequence.** The selected option has a reasoned advantage under stated assumptions and explicit triggers for reconsideration.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The selected option has a reasoned advantage under stated assumptions and explicit triggers for reconsideration. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Success stories are selected; failed projects have multiple causes; evidence rarely supports universal superiority of incremental or big-bang approaches. How can undocumented requirements and transition uncertainty be estimated before committing to replacement?

**Anti-ceremony boundary.** Comprehensive modernisation business case is optional as a named form. A bounded repair or continued operation may dominate a programme of replacement.

**Loss from the cheaper form.** A bounded comparison may omit distant options or costs; enlarge it when transition irreversibility or support commitments make the omission material.

**Omission/retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

**Conflicts and selection conditions.** ESME-T003: Local repair versus replacement. Choose by unmet obligations, support feasibility and lifecycle cost including transition; age alone has no deciding role.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Current maintenance no longer clearly serves required outcomes or a substantial migration is proposed. State the required modernisation outcome, not merely a newer technology. Compare adaptation, restructuring, replacement and deliberate non-change.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify both implementations, mappings, data versions, routing, write ownership, temporary adapters and relevant consumer versions.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The selected option has a reasoned advantage under stated assumptions and explicit triggers for reconsideration. Preserve accepted domain meaning and service obligations while deliberately changing implementation or supported behaviour; legacy bugs can be relied-on observations that require adjudication.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Assess shared-data, API, consumer and operational dependencies that cross the migration partition. Artificial partitions can make incremental migration worse.

**COMPREHENSION_ASSUMPTIONS.** An honest baseline of current value and constraints, credible alternatives and attention to transition as well as end-state cost. Recover enough undocumented behaviour and data meaning to choose mappings and boundaries; replacement cannot assume the old system’s code is its complete specification.

**ORACLE_AND_REGRESSION_LIMITS.** Success stories are selected; failed projects have multiple causes; evidence rarely supports universal superiority of incremental or big-bang approaches. Endpoint tests and row counts do not establish semantic reconciliation. Compare meaningful invariants, actual query interpretation and reachable intermediate states.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Incremental operation needs controlled coexistence and authority; quiescent cutover needs a credible no-write boundary and accepted interruption. Neither is universally preferable.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Identify irreversible conversion, external effects and validated backups/logs. Choose feasible rollback, compensation or forward repair; never infer data recovery from source reversion.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Product/service and data owners choose the objective and acceptable risk; maintainers establish feasibility and hidden obligations.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** A bounded repair or continued operation may dominate a programme of replacement. Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How can undocumented requirements and transition uncertainty be estimated before committing to replacement? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S031; ESME-S035; ESME-S036; ESME-S039; ESME-S040] [ESME-042: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/41)

### ESME-043 — Incremental displacement with bounded coexistence

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-043`

**Disposition and kind.** CONTEXT_DEPENDENT; INCREMENTAL_MIGRATION

**Mature form.** Choose a separable function or consumer boundary, route it deliberately, reconcile shared state and retire the old path after its obligations transfer.

**Controlled failure.** All-at-once replacement concentrates uncertainty and can postpone useful delivery for a long period.

**Trigger.** Work can be partitioned with tolerable coexistence and useful partial delivery.

**Non-trigger and cheap path.** Prefer a local repair or quiescent cutover when partitions are artificial or gateways cost more than staged benefit.

**Prerequisites.** Routing control, explicit data authority, compatibility and an exit condition for duplicate operation.

**Consumer and authority.** Migration teams implement boundaries; service/data owners authorise routing and eventual retirement.

**Observable consequence.** A bounded function moves with reconciled obligations, and the old path is removed or explicitly retained for a named consumer.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: A bounded function moves with reconciled obligations, and the old path is removed or explicitly retained for a named consumer. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Gateways, dual data and duplicated knowledge can create the worst of both systems; selected industrial accounts do not establish general cost superiority. Which partition boundaries minimise both transition coupling and permanent duplication?

**Anti-ceremony boundary.** Mandatory strangler architecture is optional as a named form. Prefer a local repair or quiescent cutover when partitions are artificial or gateways cost more than staged benefit.

**Loss from the cheaper form.** A direct cutover loses incremental learning and staged value; it can still dominate when coexistence is infeasible or more expensive.

**Omission/retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

**Conflicts and selection conditions.** ESME-T003: Local repair versus replacement. Choose by unmet obligations, support feasibility and lifecycle cost including transition; age alone has no deciding role. ESME-T007: Coexistence versus quiescent cutover. Use coexistence only when partition and reconciliation costs are tolerable; use quiescence when an accepted stable boundary is credible.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Work can be partitioned with tolerable coexistence and useful partial delivery. State the required modernisation outcome, not merely a newer technology. Compare adaptation, restructuring, replacement and deliberate non-change.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify both implementations, mappings, data versions, routing, write ownership, temporary adapters and relevant consumer versions.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** A bounded function moves with reconciled obligations, and the old path is removed or explicitly retained for a named consumer. Preserve accepted domain meaning and service obligations while deliberately changing implementation or supported behaviour; legacy bugs can be relied-on observations that require adjudication.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Assess shared-data, API, consumer and operational dependencies that cross the migration partition. Artificial partitions can make incremental migration worse.

**COMPREHENSION_ASSUMPTIONS.** Routing control, explicit data authority, compatibility and an exit condition for duplicate operation. Recover enough undocumented behaviour and data meaning to choose mappings and boundaries; replacement cannot assume the old system’s code is its complete specification.

**ORACLE_AND_REGRESSION_LIMITS.** Gateways, dual data and duplicated knowledge can create the worst of both systems; selected industrial accounts do not establish general cost superiority. Endpoint tests and row counts do not establish semantic reconciliation. Compare meaningful invariants, actual query interpretation and reachable intermediate states.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Incremental operation needs controlled coexistence and authority; quiescent cutover needs a credible no-write boundary and accepted interruption. Neither is universally preferable.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Identify irreversible conversion, external effects and validated backups/logs. Choose feasible rollback, compensation or forward repair; never infer data recovery from source reversion.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Migration teams implement boundaries; service/data owners authorise routing and eventual retirement.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Prefer a local repair or quiescent cutover when partitions are artificial or gateways cost more than staged benefit. Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which partition boundaries minimise both transition coupling and permanent duplication? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S031; ESME-S035; ESME-S036; ESME-S037; ESME-S053] [ESME-043: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/42)

### ESME-044 — Quiescent or big-bang cutover as a conditional alternative

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-044`

**Disposition and kind.** DOMAIN_SPECIFIC; MIGRATION_ALTERNATIVE

**Mature form.** Prepare and validate conversion, establish a quiescent boundary, cut over under explicit recovery/forward-repair conditions and reconcile before reopening use.

**Controlled failure.** Incremental coexistence can be impossible or more hazardous than a controlled outage.

**Trigger.** A tolerable outage exists, data can be stabilised and the joint operation burden would otherwise dominate.

**Non-trigger and cheap path.** Continue maintenance or use incremental displacement where interruption or conversion risk is unacceptable.

**Prerequisites.** Accepted outage, frozen input boundary, tested conversion, sufficient capacity and clear irreversibility decisions.

**Consumer and authority.** Operators coordinate cutover with service/data owners and affected consumers; a project team cannot assume all users accept downtime.

**Observable consequence.** The new system starts from a reconciled state and old writes cannot silently diverge.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The new system starts from a reconciled state and old writes cannot silently diverge. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Concentrated conversion failure can be catastrophic; rehearsals may omit production scale or late data; the review literature is not a controlled comparison. What evidence establishes that an apparently quiescent boundary really excludes concurrent external changes?

**Anti-ceremony boundary.** Big-bang replacement mandate is optional as a named form. Continue maintenance or use incremental displacement where interruption or conversion risk is unacceptable.

**Loss from the cheaper form.** Incremental or continued maintenance may prolong dual support but avoid concentrated transition risk; select by actual interruption and partition conditions.

**Omission/retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

**Conflicts and selection conditions.** ESME-T003: Local repair versus replacement. Choose by unmet obligations, support feasibility and lifecycle cost including transition; age alone has no deciding role. ESME-T007: Coexistence versus quiescent cutover. Use coexistence only when partition and reconciliation costs are tolerable; use quiescence when an accepted stable boundary is credible.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A tolerable outage exists, data can be stabilised and the joint operation burden would otherwise dominate. State the required modernisation outcome, not merely a newer technology. Compare adaptation, restructuring, replacement and deliberate non-change.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify both implementations, mappings, data versions, routing, write ownership, temporary adapters and relevant consumer versions.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The new system starts from a reconciled state and old writes cannot silently diverge. Preserve accepted domain meaning and service obligations while deliberately changing implementation or supported behaviour; legacy bugs can be relied-on observations that require adjudication.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Assess shared-data, API, consumer and operational dependencies that cross the migration partition. Artificial partitions can make incremental migration worse.

**COMPREHENSION_ASSUMPTIONS.** Accepted outage, frozen input boundary, tested conversion, sufficient capacity and clear irreversibility decisions. Recover enough undocumented behaviour and data meaning to choose mappings and boundaries; replacement cannot assume the old system’s code is its complete specification.

**ORACLE_AND_REGRESSION_LIMITS.** Concentrated conversion failure can be catastrophic; rehearsals may omit production scale or late data; the review literature is not a controlled comparison. Endpoint tests and row counts do not establish semantic reconciliation. Compare meaningful invariants, actual query interpretation and reachable intermediate states.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Incremental operation needs controlled coexistence and authority; quiescent cutover needs a credible no-write boundary and accepted interruption. Neither is universally preferable.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Identify irreversible conversion, external effects and validated backups/logs. Choose feasible rollback, compensation or forward repair; never infer data recovery from source reversion.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Operators coordinate cutover with service/data owners and affected consumers; a project team cannot assume all users accept downtime.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Continue maintenance or use incremental displacement where interruption or conversion risk is unacceptable. Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** What evidence establishes that an apparently quiescent boundary really excludes concurrent external changes? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S031; ESME-S038; ESME-S053] [ESME-044: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/43)

### ESME-045 — Migration state reconciliation and data authority

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-045`

**Disposition and kind.** ASSUMPTION_SENSITIVE; MIGRATION_RECONCILIATION

**Mature form.** Define authority and mappings for each migration phase, compare relevant state and resolve divergence before transferring responsibility.

**Controlled failure.** Dual operation can create conflicting writes, lost records or semantically inconsistent copies.

**Trigger.** Data or service state is copied, transformed or temporarily maintained in more than one place.

**Non-trigger and cheap path.** An immutable read-only export with a simple verified mapping may need only one comparison and no dual-write protocol.

**Prerequisites.** Explicit identities, mapping semantics, write ordering and access to authoritative observations.

**Consumer and authority.** Data owners decide meaning and acceptable loss; operators execute and inspect reconciliation.

**Observable consequence.** Differences are explained and resolved or explicitly accepted; no competing writer remains accidentally authoritative.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Differences are explained and resolved or explicitly accepted; no competing writer remains accidentally authoritative. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Counts or checksums do not prove semantic equivalence; concurrent updates and external effects can make exact reconciliation difficult. What sampling or invariants are adequate when full semantic comparison is prohibitively expensive?

**Anti-ceremony boundary.** Always-on dual writes and reconciliation dashboard is optional as a named form. An immutable read-only export with a simple verified mapping may need only one comparison and no dual-write protocol.

**Loss from the cheaper form.** A single-writer or quiescent design loses some availability or flexibility but can eliminate ambiguity over authority and reduce divergence.

**Omission/retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

**Conflicts and selection conditions.** ESME-T007: Coexistence versus quiescent cutover. Use coexistence only when partition and reconciliation costs are tolerable; use quiescence when an accepted stable boundary is credible.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Data or service state is copied, transformed or temporarily maintained in more than one place. State the required modernisation outcome, not merely a newer technology. Compare adaptation, restructuring, replacement and deliberate non-change.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify both implementations, mappings, data versions, routing, write ownership, temporary adapters and relevant consumer versions.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Differences are explained and resolved or explicitly accepted; no competing writer remains accidentally authoritative. Preserve accepted domain meaning and service obligations while deliberately changing implementation or supported behaviour; legacy bugs can be relied-on observations that require adjudication.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Assess shared-data, API, consumer and operational dependencies that cross the migration partition. Artificial partitions can make incremental migration worse.

**COMPREHENSION_ASSUMPTIONS.** Explicit identities, mapping semantics, write ordering and access to authoritative observations. Recover enough undocumented behaviour and data meaning to choose mappings and boundaries; replacement cannot assume the old system’s code is its complete specification.

**ORACLE_AND_REGRESSION_LIMITS.** Counts or checksums do not prove semantic equivalence; concurrent updates and external effects can make exact reconciliation difficult. Endpoint tests and row counts do not establish semantic reconciliation. Compare meaningful invariants, actual query interpretation and reachable intermediate states.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Incremental operation needs controlled coexistence and authority; quiescent cutover needs a credible no-write boundary and accepted interruption. Neither is universally preferable.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Identify irreversible conversion, external effects and validated backups/logs. Choose feasible rollback, compensation or forward repair; never infer data recovery from source reversion.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Data owners decide meaning and acceptable loss; operators execute and inspect reconciliation.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** An immutable read-only export with a simple verified mapping may need only one comparison and no dual-write protocol. Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** What sampling or invariants are adequate when full semantic comparison is prohibitively expensive? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S031; ESME-S038; ESME-S053] [ESME-045: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/44)

### ESME-046 — Schema mappings and information-loss analysis

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-046`

**Disposition and kind.** ASSUMPTION_SENSITIVE; SCHEMA_TRANSFORMATION_MODEL

**Mature form.** State the mapping and its information-loss/invertibility conditions; preserve enough source information or choose forward repair where an inverse does not exist.

**Controlled failure.** A schema change can destroy information or make old queries uninterpretable despite successful conversion.

**Trigger.** Schema/data representation changes affect persistent meaning or old-version access.

**Non-trigger and cheap path.** Use a direct checked migration for a simple bijective mapping; a full workbench is unnecessary.

**Prerequisites.** A model matching actual schema semantics, constraints, data values and supported transformation operators.

**Consumer and authority.** Database maintainers establish mappings; data owners authorise losses and changed interpretation.

**Observable consequence.** Queries and converted states meet the declared mapping, or losses and unsupported rewrites block the preservation claim.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Queries and converted states meet the declared mapping, or losses and unsupported rewrites block the preservation claim. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** The inspected PRISM work is a prototype/demo; model-relative guarantees do not establish arbitrary deployed database correctness or economic benefit. How should extensions, triggers and external data semantics be incorporated without destroying tractability?

**Anti-ceremony boundary.** Automatic down-migration script is optional as a named form. Use a direct checked migration for a simple bijective mapping; a full workbench is unnecessary.

**Loss from the cheaper form.** A forward-only transition forgoes restoration of the old representation; it is acceptable only with explicit preservation, retained information or a supported recovery decision.

**Omission/retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

**Conflicts and selection conditions.** ESME-T007: Coexistence versus quiescent cutover. Use coexistence only when partition and reconciliation costs are tolerable; use quiescence when an accepted stable boundary is credible.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Schema/data representation changes affect persistent meaning or old-version access. State the required modernisation outcome, not merely a newer technology. Compare adaptation, restructuring, replacement and deliberate non-change.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify both implementations, mappings, data versions, routing, write ownership, temporary adapters and relevant consumer versions.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Queries and converted states meet the declared mapping, or losses and unsupported rewrites block the preservation claim. Preserve accepted domain meaning and service obligations while deliberately changing implementation or supported behaviour; legacy bugs can be relied-on observations that require adjudication.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Assess shared-data, API, consumer and operational dependencies that cross the migration partition. Artificial partitions can make incremental migration worse.

**COMPREHENSION_ASSUMPTIONS.** A model matching actual schema semantics, constraints, data values and supported transformation operators. Recover enough undocumented behaviour and data meaning to choose mappings and boundaries; replacement cannot assume the old system’s code is its complete specification.

**ORACLE_AND_REGRESSION_LIMITS.** The inspected PRISM work is a prototype/demo; model-relative guarantees do not establish arbitrary deployed database correctness or economic benefit. Endpoint tests and row counts do not establish semantic reconciliation. Compare meaningful invariants, actual query interpretation and reachable intermediate states.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Incremental operation needs controlled coexistence and authority; quiescent cutover needs a credible no-write boundary and accepted interruption. Neither is universally preferable.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Identify irreversible conversion, external effects and validated backups/logs. Choose feasible rollback, compensation or forward repair; never infer data recovery from source reversion.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Database maintainers establish mappings; data owners authorise losses and changed interpretation.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Use a direct checked migration for a simple bijective mapping; a full workbench is unnecessary. Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How should extensions, triggers and external data semantics be incorporated without destroying tractability? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: model-bounded formal support; implementation applicability remains unproved; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S038; ESME-S053] [ESME-046: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/45)

### ESME-047 — Retire migration scaffolding and duplicate operation

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-047`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; MIGRATION_CONTROL_RETIREMENT

**Mature form.** Assign exit conditions to transitional paths; verify remaining consumers and recovery needs, then remove or deliberately reclassify the retained mechanism.

**Controlled failure.** Temporary gateways, duplicate implementations and double maintenance can become permanent without a consumer.

**Trigger.** A migration step has transferred its intended obligations and duplicated operation continues.

**Non-trigger and cheap path.** Retain an adapter when a real consumer still requires it; do not remove it solely to satisfy a cleanup schedule.

**Prerequisites.** Evidence of consumer transition, settled data authority and expiry or replacement of recovery obligations.

**Consumer and authority.** Service owners and maintainers authorise retirement after affected consumers have a feasible path.

**Observable consequence.** No redundant operational path remains without an explicit purpose and cost owner.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: No redundant operational path remains without an explicit purpose and cost owner. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Premature removal can strand consumers or eliminate recovery; zero duplication is not a universal objective. When does permanent compatibility support become more economical than forcing the remaining consumers to migrate?

**Anti-ceremony boundary.** Permanent migration gateway is optional as a named form. Retain an adapter when a real consumer still requires it; do not remove it solely to satisfy a cleanup schedule.

**Loss from the cheaper form.** Retiring the gateway removes old-path fallback and compatibility; do so only after its consumers and recovery obligations end.

**Omission/retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

**Conflicts and selection conditions.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A migration step has transferred its intended obligations and duplicated operation continues. State the required modernisation outcome, not merely a newer technology. Compare adaptation, restructuring, replacement and deliberate non-change.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify both implementations, mappings, data versions, routing, write ownership, temporary adapters and relevant consumer versions.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** No redundant operational path remains without an explicit purpose and cost owner. Preserve accepted domain meaning and service obligations while deliberately changing implementation or supported behaviour; legacy bugs can be relied-on observations that require adjudication.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Assess shared-data, API, consumer and operational dependencies that cross the migration partition. Artificial partitions can make incremental migration worse.

**COMPREHENSION_ASSUMPTIONS.** Evidence of consumer transition, settled data authority and expiry or replacement of recovery obligations. Recover enough undocumented behaviour and data meaning to choose mappings and boundaries; replacement cannot assume the old system’s code is its complete specification.

**ORACLE_AND_REGRESSION_LIMITS.** Premature removal can strand consumers or eliminate recovery; zero duplication is not a universal objective. Endpoint tests and row counts do not establish semantic reconciliation. Compare meaningful invariants, actual query interpretation and reachable intermediate states.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Incremental operation needs controlled coexistence and authority; quiescent cutover needs a credible no-write boundary and accepted interruption. Neither is universally preferable.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Identify irreversible conversion, external effects and validated backups/logs. Choose feasible rollback, compensation or forward repair; never infer data recovery from source reversion.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Service owners and maintainers authorise retirement after affected consumers have a feasible path.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Retain an adapter when a real consumer still requires it; do not remove it solely to satisfy a cleanup schedule. Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** When does permanent compatibility support become more economical than forcing the remaining consumers to migrate? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S031; ESME-S035; ESME-S036; ESME-S037] [ESME-047: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/46)

### ESME-049 — Bounded technical-debt identification

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-049`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; DEBT_IDENTIFICATION

**Mature form.** Identify the design/implementation choice, plausible future burden, affected change class and remediation alternative; distinguish debt from ordinary unmet requirements.

**Controlled failure.** Calling every defect, missing feature or disliked structure debt obscures distinct decisions and future costs.

**Trigger.** A present choice is expected to impose avoidable future maintenance cost or constrain options.

**Non-trigger and cheap path.** Use an ordinary defect or feature request when that is the actual issue; no debt register is needed for an isolated obvious repair.

**Prerequisites.** A causal hypothesis connecting the choice to future work and a clear boundary of the obligation.

**Consumer and authority.** Maintainers identify technical mechanisms; stakeholders determine acceptable trade-offs and who bears later costs.

**Observable consequence.** The debt item identifies what is owed metaphorically, why it matters and under which future conditions.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The debt item identifies what is owed metaphorically, why it matters and under which future conditions. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Debt definitions differ; economic terms may lack observable units; the original experience is not a validated financial model. When is the debt metaphor more informative than direct lifecycle-cost reasoning?

**Anti-ceremony boundary.** Everything-undesirable-is-debt register is optional as a named form. Use an ordinary defect or feature request when that is the actual issue; no debt register is needed for an isolated obvious repair.

**Loss from the cheaper form.** A narrower debt inventory omits ordinary defects, features and obligations from that metaphor; track them through appropriate decisions instead of forcing financial labels.

**Omission/retirement.** Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

**Conflicts and selection conditions.** ESME-T006: Debt reduction versus current value. Prioritise expected consequential burden within a plausible horizon; stop when retirement or changed demand removes prospective benefit.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A present choice is expected to impose avoidable future maintenance cost or constrain options. Debt repayment is preventive/perfective only insofar as a specific future burden is addressed; urgent defects and missing capabilities may need separate priority logic.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify the choice, artefacts, affected task class and baseline cost observations. A smell count alone does not identify an economic liability.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The debt item identifies what is owed metaphorically, why it matters and under which future conditions. Preserve current useful behaviour while improving future work unless an intentional change is separately accepted; include costs borne by downstream maintainers.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Trace the proposed causal mechanism from structure or decision to recurring work rather than relying on a generic metric association.

**COMPREHENSION_ASSUMPTIONS.** A causal hypothesis connecting the choice to future work and a clear boundary of the obligation. Maintainers must understand why the burden occurs and whether a local repair, wrapper, learning intervention or replacement could address it.

**ORACLE_AND_REGRESSION_LIMITS.** Debt definitions differ; economic terms may lack observable units; the original experience is not a validated financial model. Regression checks protect current obligations; they do not establish future productivity benefit. Benefit evaluation needs task outcomes and confounding awareness.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Remediation crossing interfaces or schemas inherits migration/compatibility requirements; internal cleanup does not justify a public break automatically.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Preventive work still needs release/recovery evidence. Economic attractiveness is not permission to impose irreversible risk on other consumers.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainers identify technical mechanisms; stakeholders determine acceptable trade-offs and who bears later costs.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Use an ordinary defect or feature request when that is the actual issue; no debt register is needed for an isolated obvious repair. Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** When is the debt metaphor more informative than direct lifecycle-cost reasoning? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: differentiated/limited; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S019; ESME-S032; ESME-S042; ESME-S048; ESME-S049] [ESME-049: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/48)

### ESME-050 — Contingent lifecycle economics

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-050`

**Disposition and kind.** ASSUMPTION_SENSITIVE; LIFECYCLE_ECONOMIC_MODEL

**Mature form.** Compare remediation cost with contingent future burdens and benefits over a stated horizon, testing sensitivity to change frequency, retirement and uncertainty.

**Controlled failure.** A static cleanup score ignores whether the affected code will change again and which users bear opportunity cost.

**Trigger.** A nontrivial preventive investment competes with current delivery or another maintenance option.

**Non-trigger and cheap path.** For a cheap urgent defect repair, direct consequence and effort comparison may be enough.

**Prerequisites.** Meaningful cost units, a plausible horizon and honest uncertainty rather than fabricated precision.

**Consumer and authority.** Stakeholders bearing present and future costs choose trade-offs; analysts expose assumptions rather than declare an automatic optimum.

**Observable consequence.** The preferred option remains justified under stated scenarios or is marked undecided when rankings reverse.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The preferred option remains justified under stated scenarios or is marked undecided when rankings reverse. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Self-reported wasted time does not prove that a particular repayment would recover that time; future objectives can change. How should irreversible option loss and costs shifted to future maintainers be represented without spurious precision?

**Anti-ceremony boundary.** Debt-interest calculator with exact rankings is optional as a named form. For a cheap urgent defect repair, direct consequence and effort comparison may be enough.

**Loss from the cheaper form.** Qualitative scenarios lose numerical comparability but avoid false precision; use richer estimates when costs, horizon and uncertainty can be defended.

**Omission/retirement.** Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

**Conflicts and selection conditions.** ESME-T006: Debt reduction versus current value. Prioritise expected consequential burden within a plausible horizon; stop when retirement or changed demand removes prospective benefit.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A nontrivial preventive investment competes with current delivery or another maintenance option. Debt repayment is preventive/perfective only insofar as a specific future burden is addressed; urgent defects and missing capabilities may need separate priority logic.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify the choice, artefacts, affected task class and baseline cost observations. A smell count alone does not identify an economic liability.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The preferred option remains justified under stated scenarios or is marked undecided when rankings reverse. Preserve current useful behaviour while improving future work unless an intentional change is separately accepted; include costs borne by downstream maintainers.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Trace the proposed causal mechanism from structure or decision to recurring work rather than relying on a generic metric association.

**COMPREHENSION_ASSUMPTIONS.** Meaningful cost units, a plausible horizon and honest uncertainty rather than fabricated precision. Maintainers must understand why the burden occurs and whether a local repair, wrapper, learning intervention or replacement could address it.

**ORACLE_AND_REGRESSION_LIMITS.** Self-reported wasted time does not prove that a particular repayment would recover that time; future objectives can change. Regression checks protect current obligations; they do not establish future productivity benefit. Benefit evaluation needs task outcomes and confounding awareness.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Remediation crossing interfaces or schemas inherits migration/compatibility requirements; internal cleanup does not justify a public break automatically.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Preventive work still needs release/recovery evidence. Economic attractiveness is not permission to impose irreversible risk on other consumers.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Stakeholders bearing present and future costs choose trade-offs; analysts expose assumptions rather than declare an automatic optimum.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** For a cheap urgent defect repair, direct consequence and effort comparison may be enough. Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How should irreversible option loss and costs shifted to future maintainers be represented without spurious precision? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: differentiated/limited; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S019; ESME-S032; ESME-S048; ESME-S049] [ESME-050: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/49)

### ESME-051 — Debt prioritisation across affected stakeholders

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-051`

**Disposition and kind.** CONTEXT_DEPENDENT; PRIORITISATION_AND_NEGOTIATION

**Mature form.** Expose who pays and who benefits, compare urgent user needs with preventive work and revisit priorities when evidence or objectives change.

**Controlled failure.** The party benefiting from delivery may not bear the maintenance costs it creates.

**Trigger.** Multiple maintenance needs compete for constrained effort, particularly across ownership or funding boundaries.

**Non-trigger and cheap path.** A maintainer can resolve a small local issue directly when no meaningful trade-off or external cost exists.

**Prerequisites.** Enough information about affected stakeholders, severity, recurrence and available capacity.

**Consumer and authority.** Authorised budget/service owners negotiate priorities; technical labels do not compel others to fund work.

**Observable consequence.** The selected work and deferred obligations have reasons understandable to those bearing their consequences.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The selected work and deferred obligations have reasons understandable to those bearing their consequences. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Negotiation can privilege visible or powerful stakeholders; numeric scoring can disguise unsupported weights and gaming. Which mechanisms fairly represent downstream or future maintainers absent from current decisions?

**Anti-ceremony boundary.** Central debt-priority committee is optional as a named form. A maintainer can resolve a small local issue directly when no meaningful trade-off or external cost exists.

**Loss from the cheaper form.** Local prioritisation may miss costs imposed on other teams or future maintainers; widen participation when burdens cross the local boundary.

**Omission/retirement.** Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

**Conflicts and selection conditions.** ESME-T006: Debt reduction versus current value. Prioritise expected consequential burden within a plausible horizon; stop when retirement or changed demand removes prospective benefit.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Multiple maintenance needs compete for constrained effort, particularly across ownership or funding boundaries. Debt repayment is preventive/perfective only insofar as a specific future burden is addressed; urgent defects and missing capabilities may need separate priority logic.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify the choice, artefacts, affected task class and baseline cost observations. A smell count alone does not identify an economic liability.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The selected work and deferred obligations have reasons understandable to those bearing their consequences. Preserve current useful behaviour while improving future work unless an intentional change is separately accepted; include costs borne by downstream maintainers.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Trace the proposed causal mechanism from structure or decision to recurring work rather than relying on a generic metric association.

**COMPREHENSION_ASSUMPTIONS.** Enough information about affected stakeholders, severity, recurrence and available capacity. Maintainers must understand why the burden occurs and whether a local repair, wrapper, learning intervention or replacement could address it.

**ORACLE_AND_REGRESSION_LIMITS.** Negotiation can privilege visible or powerful stakeholders; numeric scoring can disguise unsupported weights and gaming. Regression checks protect current obligations; they do not establish future productivity benefit. Benefit evaluation needs task outcomes and confounding awareness.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Remediation crossing interfaces or schemas inherits migration/compatibility requirements; internal cleanup does not justify a public break automatically.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Preventive work still needs release/recovery evidence. Economic attractiveness is not permission to impose irreversible risk on other consumers.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Authorised budget/service owners negotiate priorities; technical labels do not compel others to fund work.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** A maintainer can resolve a small local issue directly when no meaningful trade-off or external cost exists. Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which mechanisms fairly represent downstream or future maintainers absent from current decisions? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: differentiated/limited; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S032; ESME-S043; ESME-S048; ESME-S049] [ESME-051: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/50)

### ESME-052 — Bounded remediation with payoff reassessment

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-052`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; BOUNDED_REMEDIATION_AND_FEEDBACK

**Mature form.** Select a bounded intervention, observe whether the targeted burden changes and stop, revise or retire the effort when benefit is absent or the system nears retirement.

**Controlled failure.** A remediation programme can continue after its original burden disappears or expand into endless cleanup.

**Trigger.** A debt or maintainability intervention has uncertain payoff and can be evaluated incrementally.

**Non-trigger and cheap path.** A small targeted fix or no action may dominate comprehensive re-engineering.

**Prerequisites.** A measurable task-relevant burden, comparison with baseline and awareness of concurrent changes.

**Consumer and authority.** Maintainers report outcomes; decision makers can stop or redirect investment without treating incomplete cleanup as failure.

**Observable consequence.** Continuation depends on observed or still-credible benefit, not on clearing an arbitrary register.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Continuation depends on observed or still-credible benefit, not on clearing an arbitrary register. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Delayed benefits and confounding can make early evaluation misleading; stopping too early may prevent necessary foundational work. What observation period is sufficient for a low-frequency but high-cost change class?

**Anti-ceremony boundary.** Comprehensive cleanup release is optional as a named form. A small targeted fix or no action may dominate comprehensive re-engineering.

**Loss from the cheaper form.** Bounded remediation leaves other problems intact; this is justified when the urgent objective or expected horizon does not support further work.

**Omission/retirement.** Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

**Conflicts and selection conditions.** ESME-T006: Debt reduction versus current value. Prioritise expected consequential burden within a plausible horizon; stop when retirement or changed demand removes prospective benefit.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A debt or maintainability intervention has uncertain payoff and can be evaluated incrementally. Debt repayment is preventive/perfective only insofar as a specific future burden is addressed; urgent defects and missing capabilities may need separate priority logic.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify the choice, artefacts, affected task class and baseline cost observations. A smell count alone does not identify an economic liability.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Continuation depends on observed or still-credible benefit, not on clearing an arbitrary register. Preserve current useful behaviour while improving future work unless an intentional change is separately accepted; include costs borne by downstream maintainers.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Trace the proposed causal mechanism from structure or decision to recurring work rather than relying on a generic metric association.

**COMPREHENSION_ASSUMPTIONS.** A measurable task-relevant burden, comparison with baseline and awareness of concurrent changes. Maintainers must understand why the burden occurs and whether a local repair, wrapper, learning intervention or replacement could address it.

**ORACLE_AND_REGRESSION_LIMITS.** Delayed benefits and confounding can make early evaluation misleading; stopping too early may prevent necessary foundational work. Regression checks protect current obligations; they do not establish future productivity benefit. Benefit evaluation needs task outcomes and confounding awareness.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Remediation crossing interfaces or schemas inherits migration/compatibility requirements; internal cleanup does not justify a public break automatically.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Preventive work still needs release/recovery evidence. Economic attractiveness is not permission to impose irreversible risk on other consumers.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainers report outcomes; decision makers can stop or redirect investment without treating incomplete cleanup as failure.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** A small targeted fix or no action may dominate comprehensive re-engineering. Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** What observation period is sufficient for a low-frequency but high-cost change class? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: differentiated/limited; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S019; ESME-S020; ESME-S022; ESME-S032; ESME-S048; ESME-S049] [ESME-052: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/51)

### ESME-053 — Maintainability measures as validated proxies

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-053`

**Disposition and kind.** USEFUL_BUT_EASILY_GAMED; MEASUREMENT_PROXY

**Mature form.** Use a measure only with a task-relevant interpretation, examine disagreements with observed work and avoid rewards that make proxy improvement the objective.

**Controlled failure.** A readily optimised score can be mistaken for the actual engineering outcome.

**Trigger.** A metric informs prioritisation, prediction, comparison or acceptance of maintenance work.

**Non-trigger and cheap path.** Direct task evidence or a short qualitative comparison can dominate an elaborate index.

**Prerequisites.** Stable definitions, a relevant comparison and evidence about measurement error and confounding.

**Consumer and authority.** Analysts explain the proxy; maintainers and decision makers judge whether it represents the outcome they need.

**Observable consequence.** Metric movement is interpreted alongside actual task outcomes and contradictory evidence.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Metric movement is interpreted alongside actual task outcomes and contradictory evidence. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Total and average complexity can diverge; code metrics are not human comprehension; self-reported debt time is not automatically recoverable savings. Which metrics remain useful after teams adapt their behaviour to being measured?

**Anti-ceremony boundary.** Maintainability-score target is optional as a named form. Direct task evidence or a short qualitative comparison can dominate an elaborate index.

**Loss from the cheaper form.** A smaller set of task-relevant observations loses easy portfolio aggregation; aggregation is not valuable when the proxy is unvalidated or gamed.

**Omission/retirement.** Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

**Conflicts and selection conditions.** ESME-T002: Familiarity versus simplification. Prefer restructuring when a plausible recurrent task benefit exceeds relearning, review and regression cost; prefer familiarity when the system is stable or retiring.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A metric informs prioritisation, prediction, comparison or acceptance of maintenance work. Debt repayment is preventive/perfective only insofar as a specific future burden is addressed; urgent defects and missing capabilities may need separate priority logic.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify the choice, artefacts, affected task class and baseline cost observations. A smell count alone does not identify an economic liability.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Metric movement is interpreted alongside actual task outcomes and contradictory evidence. Preserve current useful behaviour while improving future work unless an intentional change is separately accepted; include costs borne by downstream maintainers.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Trace the proposed causal mechanism from structure or decision to recurring work rather than relying on a generic metric association.

**COMPREHENSION_ASSUMPTIONS.** Stable definitions, a relevant comparison and evidence about measurement error and confounding. Maintainers must understand why the burden occurs and whether a local repair, wrapper, learning intervention or replacement could address it.

**ORACLE_AND_REGRESSION_LIMITS.** Total and average complexity can diverge; code metrics are not human comprehension; self-reported debt time is not automatically recoverable savings. Regression checks protect current obligations; they do not establish future productivity benefit. Benefit evaluation needs task outcomes and confounding awareness.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Remediation crossing interfaces or schemas inherits migration/compatibility requirements; internal cleanup does not justify a public break automatically.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Preventive work still needs release/recovery evidence. Economic attractiveness is not permission to impose irreversible risk on other consumers.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Analysts explain the proxy; maintainers and decision makers judge whether it represents the outcome they need.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Direct task evidence or a short qualitative comparison can dominate an elaborate index. Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which metrics remain useful after teams adapt their behaviour to being measured? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: differentiated/limited; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S022; ESME-S032; ESME-S048; ESME-S060] [ESME-053: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/52)

### ESME-055 — Maintainership capacity and continuity

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-055`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; HUMAN_CONTINUITY_MECHANISM

**Mature form.** Identify consequential ownership/capacity dependencies, support sustainable workload and arrange a feasible handoff or alternative when continuity is at risk.

**Controlled failure.** Popular or technically functional software can lose the people and resources needed for future obligations.

**Trigger.** Key-person departure, concentrated knowledge, burnout, funding loss or a critical unmaintained dependency.

**Non-trigger and cheap path.** A stable finished component with no active obligations need not recruit maintainers merely to appear alive.

**Prerequisites.** Actual willingness, competence, access and resources; naming an owner does not create capacity.

**Consumer and authority.** Maintainers and sponsors negotiate responsibilities voluntarily; downstream organisations decide how to fund or replace unsupported dependencies.

**Observable consequence.** Required maintenance responsibilities have capable willing actors or an explicit alternative/retirement decision.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Required maintenance responsibilities have capable willing actors or an explicit alternative/retirement decision. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Commit counts and popularity poorly represent capacity; forced redundancy can overload volunteers and dilute expertise. Which funding and workload arrangements sustain capacity without shifting hidden costs to volunteers?

**Anti-ceremony boundary.** Named-owner registry is optional as a named form. A stable finished component with no active obligations need not recruit maintainers merely to appear alive.

**Loss from the cheaper form.** A direct arrangement may not survive absence or be visible to consumers; retain an escalation and support route that reflects willingness and capacity.

**Omission/retirement.** Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

**Conflicts and selection conditions.** ESME-T010: Continuity versus responsible ending. Retain service only for justified obligations with feasible capacity; archives can meet historical needs without a running service.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Key-person departure, concentrated knowledge, burnout, funding loss or a critical unmaintained dependency. Change may concern code, ownership, support, dependency substitution or ending operation. No-change is legitimate when obligations remain met.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Include artefacts, access, build/dependency identity, human knowledge, support promises and consumer relationships relevant to continuity.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Required maintenance responsibilities have capable willing actors or an explicit alternative/retirement decision. Preserve accepted service/data/support obligations during handoff or retirement, not indefinite operation or every historical implementation detail.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Declared dependency networks identify possible exposure; actual use, transitive obligations and human responsibility require additional evidence.

**COMPREHENSION_ASSUMPTIONS.** Actual willingness, competence, access and resources; naming an owner does not create capacity. Demonstrate bounded maintenance ability through tasks and dialogue. Commit history, popularity and documents remain incomplete expertise proxies.

**ORACLE_AND_REGRESSION_LIMITS.** Commit counts and popularity poorly represent capacity; forced redundancy can overload volunteers and dilute expertise. A successful onboarding task or archived build is partial evidence, not proof of readiness for every failure. Inactivity needs interpretation rather than automatic failure classification.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Deprecation needs a feasible transition or explicit exception; forks and replacements transfer maintenance obligations rather than eliminating them.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Shutdown, dependency replacement and ownership transfer need contingency conditions appropriate to actual data/service effects; archival retention alone cannot restore a service.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainers and sponsors negotiate responsibilities voluntarily; downstream organisations decide how to fund or replace unsupported dependencies.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** A stable finished component with no active obligations need not recruit maintainers merely to appear alive. Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which funding and workload arrangements sustain capacity without shifting hidden costs to volunteers? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S040; ESME-S043; ESME-S047] [ESME-055: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/54)

### ESME-056 — Handoff and onboarding through demonstrated capability

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-056`

**Disposition and kind.** CONTEXT_DEPENDENT; KNOWLEDGE_TRANSFER_AND_CAPABILITY_TEST

**Mature form.** Use representative tasks, access checks and dialogue to test the receiving maintainer’s ability; preserve rationale and unresolved questions that the task exposes.

**Controlled failure.** Transferred artefacts may not enable a new maintainer to diagnose or change the system.

**Trigger.** Ownership transfer, new maintainer onboarding or impending loss of specialised knowledge.

**Non-trigger and cheap path.** Pair on one meaningful change or diagnosis instead of producing a comprehensive handover manual.

**Prerequisites.** A willing receiving maintainer, operational access and time to learn; a quiz alone is not enough.

**Consumer and authority.** Delivering and receiving maintainers exchange knowledge; managers provide time and authority rather than infer competence from attendance.

**Observable consequence.** The receiver can complete a representative task or the handoff plan changes to address demonstrated gaps.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The receiver can complete a representative task or the handoff plan changes to address demonstrated gaps. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** A successful rehearsal does not prove broad competence; task selection can conceal rare but important failure modes. How can representative tasks be chosen without overburdening outgoing maintainers?

**Anti-ceremony boundary.** Handover attendance or documentation-completion certificate is optional as a named form. Pair on one meaningful change or diagnosis instead of producing a comprehensive handover manual.

**Loss from the cheaper form.** A small practical task samples only part of capability; broaden demonstrations when the new responsibility spans materially different operations.

**Omission/retirement.** Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

**Conflicts and selection conditions.** ESME-T010: Continuity versus responsible ending. Retain service only for justified obligations with feasible capacity; archives can meet historical needs without a running service.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Ownership transfer, new maintainer onboarding or impending loss of specialised knowledge. Change may concern code, ownership, support, dependency substitution or ending operation. No-change is legitimate when obligations remain met.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Include artefacts, access, build/dependency identity, human knowledge, support promises and consumer relationships relevant to continuity.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The receiver can complete a representative task or the handoff plan changes to address demonstrated gaps. Preserve accepted service/data/support obligations during handoff or retirement, not indefinite operation or every historical implementation detail.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Declared dependency networks identify possible exposure; actual use, transitive obligations and human responsibility require additional evidence.

**COMPREHENSION_ASSUMPTIONS.** A willing receiving maintainer, operational access and time to learn; a quiz alone is not enough. Demonstrate bounded maintenance ability through tasks and dialogue. Commit history, popularity and documents remain incomplete expertise proxies.

**ORACLE_AND_REGRESSION_LIMITS.** A successful rehearsal does not prove broad competence; task selection can conceal rare but important failure modes. A successful onboarding task or archived build is partial evidence, not proof of readiness for every failure. Inactivity needs interpretation rather than automatic failure classification.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Deprecation needs a feasible transition or explicit exception; forks and replacements transfer maintenance obligations rather than eliminating them.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Shutdown, dependency replacement and ownership transfer need contingency conditions appropriate to actual data/service effects; archival retention alone cannot restore a service.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Delivering and receiving maintainers exchange knowledge; managers provide time and authority rather than infer competence from attendance.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Pair on one meaningful change or diagnosis instead of producing a comprehensive handover manual. Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How can representative tasks be chosen without overburdening outgoing maintainers? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S014; ESME-S015; ESME-S043; ESME-S047] [ESME-056: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/55)

### ESME-057 — Deprecation communication with actionable transition

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-057`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; DEPRECATION_INTERACTION

**Mature form.** Explain the affected behaviour, support state, replacement or lack of replacement, and timing/exception conditions; retain support as promised during transition.

**Controlled failure.** Consumers may receive a removal notice without a workable path or confuse discouraged use with an immediate break.

**Trigger.** A supported interface, dependency or behaviour is discouraged, changed or scheduled for removal.

**Non-trigger and cheap path.** For a private coordinated use, direct communication can suffice; indefinite soft deprecation may be appropriate when removal is not justified.

**Prerequisites.** Known support commitments, reachable consumers where possible and a feasible transition or explicit residual risk.

**Consumer and authority.** Producers communicate policy; affected consumers choose migration; designated governance can authorise documented exceptions.

**Observable consequence.** Consumers have actionable information, and removal conditions match the stated commitment rather than a silent version change.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Consumers have actionable information, and removal conditions match the stated commitment rather than a silent version change. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** A policy is not proof of adoption or successful migration; fixed universal time windows ignore differing risk and consumer constraints. How should a producer proceed when critical unknown consumers cannot be reached?

**Anti-ceremony boundary.** Universal fixed deprecation period is optional as a named form. For a private coordinated use, direct communication can suffice; indefinite soft deprecation may be appropriate when removal is not justified.

**Loss from the cheaper form.** A tailored transition loses scheduling uniformity; it should still provide actionable notice and respect applicable project policy and consumer constraints.

**Omission/retirement.** Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

**Conflicts and selection conditions.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A supported interface, dependency or behaviour is discouraged, changed or scheduled for removal. Change may concern code, ownership, support, dependency substitution or ending operation. No-change is legitimate when obligations remain met.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Include artefacts, access, build/dependency identity, human knowledge, support promises and consumer relationships relevant to continuity.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Consumers have actionable information, and removal conditions match the stated commitment rather than a silent version change. Preserve accepted service/data/support obligations during handoff or retirement, not indefinite operation or every historical implementation detail.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Declared dependency networks identify possible exposure; actual use, transitive obligations and human responsibility require additional evidence.

**COMPREHENSION_ASSUMPTIONS.** Known support commitments, reachable consumers where possible and a feasible transition or explicit residual risk. Demonstrate bounded maintenance ability through tasks and dialogue. Commit history, popularity and documents remain incomplete expertise proxies.

**ORACLE_AND_REGRESSION_LIMITS.** A policy is not proof of adoption or successful migration; fixed universal time windows ignore differing risk and consumer constraints. A successful onboarding task or archived build is partial evidence, not proof of readiness for every failure. Inactivity needs interpretation rather than automatic failure classification.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Deprecation needs a feasible transition or explicit exception; forks and replacements transfer maintenance obligations rather than eliminating them.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Shutdown, dependency replacement and ownership transfer need contingency conditions appropriate to actual data/service effects; archival retention alone cannot restore a service.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Producers communicate policy; affected consumers choose migration; designated governance can authorise documented exceptions.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** For a private coordinated use, direct communication can suffice; indefinite soft deprecation may be appropriate when removal is not justified. Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How should a producer proceed when critical unknown consumers cannot be reached? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S043; ESME-S045] [ESME-057: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/56)

### ESME-058 — Dependency viability and response alternatives

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-058`

**Disposition and kind.** CONTEXT_DEPENDENT; ECOSYSTEM_RESPONSE_SELECTION

**Mature form.** Assess actual need and viability, then compare continued use, support contribution, isolation, fork or replacement with their ownership and update costs.

**Controlled failure.** Dependency activity can cease while downstream obligations continue; panic replacement can itself introduce greater risk.

**Trigger.** A dependency loses maintainers, support, compatibility or timely response needed by the consuming system.

**Non-trigger and cheap path.** Continue using a stable adequate dependency when no unmet obligation warrants change, while retaining appropriate observation.

**Prerequisites.** Understanding of actual use, licences/access, transitive dependencies and capacity to maintain an alternative.

**Consumer and authority.** Downstream maintainers and sponsors choose their response; they cannot compel upstream labour or assume a fork will attract support.

**Observable consequence.** The selected response has a capable owner and evidence that it addresses the relevant continuity risk.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The selected response has a capable owner and evidence that it addresses the relevant continuity risk. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Dependency graphs overstate some runtime exposure; interviews are not comparative success rates; a fork transfers rather than eliminates maintenance work. Which signals predict consequential abandonment early enough for a proportionate response?

**Anti-ceremony boundary.** Automatic replace-abandoned-dependency policy is optional as a named form. Continue using a stable adequate dependency when no unmet obligation warrants change, while retaining appropriate observation.

**Loss from the cheaper form.** Waiting or contributing retains upstream uncertainty; replacement or forking also creates new costs and needs actual maintainer capacity.

**Omission/retirement.** Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

**Conflicts and selection conditions.** ESME-T010: Continuity versus responsible ending. Retain service only for justified obligations with feasible capacity; archives can meet historical needs without a running service.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A dependency loses maintainers, support, compatibility or timely response needed by the consuming system. Change may concern code, ownership, support, dependency substitution or ending operation. No-change is legitimate when obligations remain met.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Include artefacts, access, build/dependency identity, human knowledge, support promises and consumer relationships relevant to continuity.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The selected response has a capable owner and evidence that it addresses the relevant continuity risk. Preserve accepted service/data/support obligations during handoff or retirement, not indefinite operation or every historical implementation detail.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Declared dependency networks identify possible exposure; actual use, transitive obligations and human responsibility require additional evidence.

**COMPREHENSION_ASSUMPTIONS.** Understanding of actual use, licences/access, transitive dependencies and capacity to maintain an alternative. Demonstrate bounded maintenance ability through tasks and dialogue. Commit history, popularity and documents remain incomplete expertise proxies.

**ORACLE_AND_REGRESSION_LIMITS.** Dependency graphs overstate some runtime exposure; interviews are not comparative success rates; a fork transfers rather than eliminates maintenance work. A successful onboarding task or archived build is partial evidence, not proof of readiness for every failure. Inactivity needs interpretation rather than automatic failure classification.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Deprecation needs a feasible transition or explicit exception; forks and replacements transfer maintenance obligations rather than eliminating them.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Shutdown, dependency replacement and ownership transfer need contingency conditions appropriate to actual data/service effects; archival retention alone cannot restore a service.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Downstream maintainers and sponsors choose their response; they cannot compel upstream labour or assume a fork will attract support.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Continue using a stable adequate dependency when no unmet obligation warrants change, while retaining appropriate observation. Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which signals predict consequential abandonment early enough for a proportionate response? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S040; ESME-S041; ESME-S043] [ESME-058: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/57)

### ESME-059 — Archival identity without a false execution guarantee

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-059`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; ARCHIVAL_PRESERVATION

**Mature form.** Retain the artefacts and identity needed by named historical, legal or reconstruction consumers, with limitations on buildability and execution explicit.

**Controlled failure.** Loss of source provenance can prevent later study or reconstruction, while archival possession can be mistaken for an operational guarantee.

**Trigger.** Retirement, handoff, publication or dependency disappearance creates a future need for source or history.

**Non-trigger and cheap path.** Use an existing trustworthy archive and identifiers rather than maintaining a duplicate live service.

**Prerequisites.** Permission to retain/distribute material, adequate identifiers and a retention purpose; private data and credentials require separate treatment.

**Consumer and authority.** Custodians preserve artefacts; future maintainers decide whether reconstruction is feasible and authorised.

**Observable consequence.** The archived version is identifiable and accessible within the stated retention conditions, without pretending it necessarily runs.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The archived version is identifiable and accessible within the stated retention conditions, without pretending it necessarily runs. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Software Heritage explicitly separates a comprehensive corpus from curation and buildability; environments and external services may still disappear. Which environment and dependency evidence should accompany source for a particular future reconstruction task?

**Anti-ceremony boundary.** Archive-presence or source-preservation badge is optional as a named form. Use an existing trustworthy archive and identifiers rather than maintaining a duplicate live service.

**Loss from the cheaper form.** A smaller archive may not support future reconstruction; record what is preserved and do not promise buildability or operation beyond it.

**Omission/retirement.** Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

**Conflicts and selection conditions.** ESME-T010: Continuity versus responsible ending. Retain service only for justified obligations with feasible capacity; archives can meet historical needs without a running service.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Retirement, handoff, publication or dependency disappearance creates a future need for source or history. Change may concern code, ownership, support, dependency substitution or ending operation. No-change is legitimate when obligations remain met.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Include artefacts, access, build/dependency identity, human knowledge, support promises and consumer relationships relevant to continuity.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The archived version is identifiable and accessible within the stated retention conditions, without pretending it necessarily runs. Preserve accepted service/data/support obligations during handoff or retirement, not indefinite operation or every historical implementation detail.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Declared dependency networks identify possible exposure; actual use, transitive obligations and human responsibility require additional evidence.

**COMPREHENSION_ASSUMPTIONS.** Permission to retain/distribute material, adequate identifiers and a retention purpose; private data and credentials require separate treatment. Demonstrate bounded maintenance ability through tasks and dialogue. Commit history, popularity and documents remain incomplete expertise proxies.

**ORACLE_AND_REGRESSION_LIMITS.** Software Heritage explicitly separates a comprehensive corpus from curation and buildability; environments and external services may still disappear. A successful onboarding task or archived build is partial evidence, not proof of readiness for every failure. Inactivity needs interpretation rather than automatic failure classification.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Deprecation needs a feasible transition or explicit exception; forks and replacements transfer maintenance obligations rather than eliminating them.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Shutdown, dependency replacement and ownership transfer need contingency conditions appropriate to actual data/service effects; archival retention alone cannot restore a service.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Custodians preserve artefacts; future maintainers decide whether reconstruction is feasible and authorised.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Use an existing trustworthy archive and identifiers rather than maintaining a duplicate live service. Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which environment and dependency evidence should accompany source for a particular future reconstruction task? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S030; ESME-S046; ESME-S054] [ESME-059: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/58)

### ESME-060 — Responsible service retirement and residual obligations

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-060`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; RETIREMENT_DECISION_AND_OPERATION

**Mature form.** Identify remaining consumers and obligations, transfer/export or explicitly end them, stop unnecessary operation and retain only justified historical material.

**Controlled failure.** An obsolete service can remain operational without value, or be shut down while data, users and support obligations remain.

**Trigger.** Continued operation no longer serves an accepted objective or cannot be sustainably supported.

**Non-trigger and cheap path.** Keep an adequate low-cost system unchanged when retirement would cause more harm; retain an archive rather than a running service when history is the only need.

**Prerequisites.** Authority to end service, feasible consumer/data transition and known residual retention/access obligations.

**Consumer and authority.** Service/data owners authorise retirement; operators execute shutdown; affected consumers participate where their obligations require it.

**Observable consequence.** No unacknowledged live dependency remains, residual obligations have responsible actors and unnecessary operation has ceased.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: No unacknowledged live dependency remains, residual obligations have responsible actors and unnecessary operation has ceased. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Disposal scope and policy examples do not establish a universal retirement procedure; external obligations require target-specific evidence beyond this study. How can hidden consumers and indefinite support expectations be resolved before final shutdown?

**Anti-ceremony boundary.** Permanent operation as historical preservation is optional as a named form. Keep an adequate low-cost system unchanged when retirement would cause more harm; retain an archive rather than a running service when history is the only need.

**Loss from the cheaper form.** Shutting down removes immediate service access; resolve continuing consumer needs and retain justified evidence without equating archival custody with live support.

**Omission/retirement.** Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

**Conflicts and selection conditions.** ESME-T010: Continuity versus responsible ending. Retain service only for justified obligations with feasible capacity; archives can meet historical needs without a running service.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Continued operation no longer serves an accepted objective or cannot be sustainably supported. Change may concern code, ownership, support, dependency substitution or ending operation. No-change is legitimate when obligations remain met.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Include artefacts, access, build/dependency identity, human knowledge, support promises and consumer relationships relevant to continuity.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** No unacknowledged live dependency remains, residual obligations have responsible actors and unnecessary operation has ceased. Preserve accepted service/data/support obligations during handoff or retirement, not indefinite operation or every historical implementation detail.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Declared dependency networks identify possible exposure; actual use, transitive obligations and human responsibility require additional evidence.

**COMPREHENSION_ASSUMPTIONS.** Authority to end service, feasible consumer/data transition and known residual retention/access obligations. Demonstrate bounded maintenance ability through tasks and dialogue. Commit history, popularity and documents remain incomplete expertise proxies.

**ORACLE_AND_REGRESSION_LIMITS.** Disposal scope and policy examples do not establish a universal retirement procedure; external obligations require target-specific evidence beyond this study. A successful onboarding task or archived build is partial evidence, not proof of readiness for every failure. Inactivity needs interpretation rather than automatic failure classification.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Deprecation needs a feasible transition or explicit exception; forks and replacements transfer maintenance obligations rather than eliminating them.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Shutdown, dependency replacement and ownership transfer need contingency conditions appropriate to actual data/service effects; archival retention alone cannot restore a service.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Service/data owners authorise retirement; operators execute shutdown; affected consumers participate where their obligations require it.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Keep an adequate low-cost system unchanged when retirement would cause more harm; retain an archive rather than a running service when history is the only need. Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How can hidden consumers and indefinite support expectations be resolved before final shutdown? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: conditional on actual trigger, consumer and cost.

[ESME-S001; ESME-S002; ESME-S040; ESME-S043; ESME-S045; ESME-S054] [ESME-060: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/59)

### ESME-061 — Generated repairs remain candidate interventions

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-061`

**Disposition and kind.** STRONGLY_RETAINED; AUTOMATED_REPAIR_ACCEPTANCE_BOUNDARY

**Mature form.** Treat generated output as a proposed intervention; check the actual patch against independent intent and preservation obligations before acceptance.

**Controlled failure.** Test-suite overfitting and weak evaluation infrastructure can label wrong or incomplete repairs successful.

**Trigger.** An automatic repair tool or LLM generates a maintenance change.

**Non-trigger and cheap path.** A narrow verified transformation or a simple human fix may be cheaper; automation is optional.

**Prerequisites.** Candidate identity, credible oracles, impact evidence and an authorised acceptance consumer.

**Consumer and authority.** Generators propose; maintainers or explicitly delegated policy accept within scope. Generator confidence does not create authority.

**Observable consequence.** The accepted patch has evidence beyond its production and a clear disposition for unresolved failures.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The accepted patch has evidence beyond its production and a clear disposition for unresolved failures. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Human review can also fail, especially for deceptive patches; a universal extra manual review is not itself proved optimal for every narrow transformation. What review and validation combination is cost-effective for each repair class?

**Anti-ceremony boundary.** Automated repair leaderboard score as acceptance is optional as a named form. A narrow verified transformation or a simple human fix may be cheaper; automation is optional.

**Loss from the cheaper form.** A bounded generator may find fewer candidate repairs; independent validation and authorisation remain necessary for the consequences it does propose.

**Omission/retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Conflicts and selection conditions.** ESME-T004: Automated transformation versus review burden. Evaluate correct outcomes and full cost for the task and tool version. Strong narrow transformations can need less manual review; weak oracles demand more independent evidence.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** An automatic repair tool or LLM generates a maintenance change. A generated patch must answer an authorised maintenance objective. Policy, data and model changes can alter behaviour without conventional source changes.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify repository/task baseline, tool/model version, prompts/configuration relevant to evaluation, tests and data/model/policy artefacts. Record benchmark version and excluded cases.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The accepted patch has evidence beyond its production and a clear disposition for unresolved failures. Preserve actual consumer obligations, not merely benchmark assertions or similarity to a gold patch. Learned behaviour may require statistical rather than deterministic comparisons.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Assess repository-scale and cross-artefact dependencies; generated local diffs can omit tests, configuration or downstream effects.

**COMPREHENSION_ASSUMPTIONS.** Candidate identity, credible oracles, impact evidence and an authorised acceptance consumer. Automation can shift comprehension into prompting, verification and repair. Task success does not establish general system understanding.

**ORACLE_AND_REGRESSION_LIMITS.** Human review can also fail, especially for deceptive patches; a universal extra manual review is not itself proved optimal for every narrow transformation. Distinguish plausible patches, independently assessed correctness and accepted deployment. Contamination and shared datasets limit apparent replication.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Generated migration or API changes inherit ordinary coexistence and mapping obligations; an AI label does not relax them.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Delegated release needs explicit bounds and state/effect recovery evidence. An agent’s successful command is not proof of a recovered real system.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Generators propose; maintainers or explicitly delegated policy accept within scope. Generator confidence does not create authority.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** A narrow verified transformation or a simple human fix may be cheaper; automation is optional. Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** What review and validation combination is cost-effective for each repair class? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S024; ESME-S026; ESME-S027; ESME-S052; ESME-S055; ESME-S065; ESME-S067] [ESME-061: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/60)

### ESME-062 — Benchmark and evaluation provenance

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-062`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; EVALUATION_PROVENANCE

**Mature form.** Record task origin, training/exposure risks, evaluation version, test/oracle limits, exclusions and shared datasets; compare like outcomes with credible baselines.

**Controlled failure.** Contamination, benchmark selection and weak tests can inflate apparent capability or obscure what was measured.

**Trigger.** A repair or agent capability claim informs adoption, comparison or a maintenance decision.

**Non-trigger and cheap path.** Use a small transparent local task evaluation when a leaderboard cannot answer the decision question.

**Prerequisites.** Enough disclosed benchmark and tool information to interpret the measure and its denominator.

**Consumer and authority.** Researchers and tool evaluators disclose evidence; downstream adopters test transfer to their own obligations.

**Observable consequence.** The capability claim identifies its actual outcome, denominator, uncertainty and non-independent evidence.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The capability claim identifies its actual outcome, denominator, uncertainty and non-independent evidence. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** OpenAI’s selected difficult subset is not the entire benchmark; gold-patch difference is not automatically error; contamination tests themselves have limits. How can current models be evaluated on representative tasks with genuinely unseen obligations and long-term outcomes?

**Anti-ceremony boundary.** Benchmark-only evaluation report is optional as a named form. Use a small transparent local task evaluation when a leaderboard cannot answer the decision question.

**Loss from the cheaper form.** A smaller local evaluation loses broad comparability; it can be more relevant to local work if leakage, selection and held-out obligations are explicit.

**Omission/retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Conflicts and selection conditions.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A repair or agent capability claim informs adoption, comparison or a maintenance decision. A generated patch must answer an authorised maintenance objective. Policy, data and model changes can alter behaviour without conventional source changes.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify repository/task baseline, tool/model version, prompts/configuration relevant to evaluation, tests and data/model/policy artefacts. Record benchmark version and excluded cases.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The capability claim identifies its actual outcome, denominator, uncertainty and non-independent evidence. Preserve actual consumer obligations, not merely benchmark assertions or similarity to a gold patch. Learned behaviour may require statistical rather than deterministic comparisons.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Assess repository-scale and cross-artefact dependencies; generated local diffs can omit tests, configuration or downstream effects.

**COMPREHENSION_ASSUMPTIONS.** Enough disclosed benchmark and tool information to interpret the measure and its denominator. Automation can shift comprehension into prompting, verification and repair. Task success does not establish general system understanding.

**ORACLE_AND_REGRESSION_LIMITS.** OpenAI’s selected difficult subset is not the entire benchmark; gold-patch difference is not automatically error; contamination tests themselves have limits. Distinguish plausible patches, independently assessed correctness and accepted deployment. Contamination and shared datasets limit apparent replication.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Generated migration or API changes inherit ordinary coexistence and mapping obligations; an AI label does not relax them.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Delegated release needs explicit bounds and state/effect recovery evidence. An agent’s successful command is not proof of a recovered real system.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Researchers and tool evaluators disclose evidence; downstream adopters test transfer to their own obligations.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Use a small transparent local task evaluation when a leaderboard cannot answer the decision question. Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How can current models be evaluated on representative tasks with genuinely unseen obligations and long-term outcomes? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S024; ESME-S026; ESME-S027; ESME-S057; ESME-S067] [ESME-062: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/61)

### ESME-063 — End-to-end automation cost and outcome assessment

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-063`

**Disposition and kind.** CONTEXT_DEPENDENT; AUTOMATION_ECONOMIC_EVALUATION

**Mature form.** Compare end-to-end outcomes and costs against a credible human/tool/no-change baseline, preserving setting, selection and uncertainty.

**Controlled failure.** Fast generation or more passing tasks may hide comprehension, review, repair, latency, energy and downstream regression costs.

**Trigger.** A maintenance automation is selected, expanded or justified economically.

**Non-trigger and cheap path.** For a cheap reversible task, direct bounded experience may suffice; do not run a research programme for every suggestion.

**Prerequisites.** Representative tasks, defined outcomes, appropriate baseline and accounting for review and failed attempts.

**Consumer and authority.** Maintainers report actual work; decision makers accept costs and risks; survey preference is not causal productivity evidence.

**Observable consequence.** The chosen automation has a bounded justification, or remains unproven when comparisons are inadequate.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The chosen automation has a bounded justification, or remains unproven when comparisons are inadequate. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** The 2025 METR result is time- and population-specific; 2026 follow-up selection undermines a clean current causal estimate. Quantisation costs are hardware-specific. What is the causal current-tool effect for representative maintainers and long-lived outcomes?

**Anti-ceremony boundary.** Per-token or edit-time productivity dashboard is optional as a named form. For a cheap reversible task, direct bounded experience may suffice; do not run a research programme for every suggestion.

**Loss from the cheaper form.** A cheap bounded trial leaves some long-term effects unmeasured; widen observation when review, regression or operational costs plausibly outweigh apparent speed.

**Omission/retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Conflicts and selection conditions.** ESME-T004: Automated transformation versus review burden. Evaluate correct outcomes and full cost for the task and tool version. Strong narrow transformations can need less manual review; weak oracles demand more independent evidence.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** A maintenance automation is selected, expanded or justified economically. A generated patch must answer an authorised maintenance objective. Policy, data and model changes can alter behaviour without conventional source changes.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify repository/task baseline, tool/model version, prompts/configuration relevant to evaluation, tests and data/model/policy artefacts. Record benchmark version and excluded cases.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The chosen automation has a bounded justification, or remains unproven when comparisons are inadequate. Preserve actual consumer obligations, not merely benchmark assertions or similarity to a gold patch. Learned behaviour may require statistical rather than deterministic comparisons.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Assess repository-scale and cross-artefact dependencies; generated local diffs can omit tests, configuration or downstream effects.

**COMPREHENSION_ASSUMPTIONS.** Representative tasks, defined outcomes, appropriate baseline and accounting for review and failed attempts. Automation can shift comprehension into prompting, verification and repair. Task success does not establish general system understanding.

**ORACLE_AND_REGRESSION_LIMITS.** The 2025 METR result is time- and population-specific; 2026 follow-up selection undermines a clean current causal estimate. Quantisation costs are hardware-specific. Distinguish plausible patches, independently assessed correctness and accepted deployment. Contamination and shared datasets limit apparent replication.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Generated migration or API changes inherit ordinary coexistence and mapping obligations; an AI label does not relax them.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Delegated release needs explicit bounds and state/effect recovery evidence. An agent’s successful command is not proof of a recovered real system.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainers report actual work; decision makers accept costs and risks; survey preference is not causal productivity evidence.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** For a cheap reversible task, direct bounded experience may suffice; do not run a research programme for every suggestion. Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** What is the causal current-tool effect for representative maintainers and long-lived outcomes? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S025; ESME-S033; ESME-S034; ESME-S052; ESME-S057] [ESME-063: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/62)

### ESME-064 — Acceptance authority distinct from generation capability

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-064`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; AUTHORITY_AND_REVIEW_BOUNDARY

**Mature form.** Identify who may accept and deploy which changes, what evidence they need and when an automatic path must defer or stop.

**Controlled failure.** A generated conclusion can be mistaken for permission to mutate a repository or release a service.

**Trigger.** Automated or delegated changes can alter shared artefacts or external behaviour.

**Non-trigger and cheap path.** A sole authorised maintainer may generate, inspect and accept a small change without separate roles; logical distinctions do not require separate people.

**Prerequisites.** Legitimate authority, actual action capability and explicit bounds for any delegation.

**Consumer and authority.** Authorised maintainers or policy holders accept changes; generators cannot enlarge their own mandate from a successful test.

**Observable consequence.** Acceptance and deployment can be traced to an authorised decision within its stated scope.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: Acceptance and deployment can be traced to an authorised decision within its stated scope. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Human approval can be ceremonial or harmed by deceptive plausible patches; role separation alone does not improve correctness. Which narrow change classes justify unattended acceptance under independently established evidence?

**Anti-ceremony boundary.** Mandatory independent human approver for every generated patch is optional as a named form. A sole authorised maintainer may generate, inspect and accept a small change without separate roles; logical distinctions do not require separate people.

**Loss from the cheaper form.** Combining logical roles loses interpersonal challenge; it can be adequate for bounded tasks when independent evidence and explicit authority remain effective.

**Omission/retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Conflicts and selection conditions.** ESME-T004: Automated transformation versus review burden. Evaluate correct outcomes and full cost for the task and tool version. Strong narrow transformations can need less manual review; weak oracles demand more independent evidence.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Automated or delegated changes can alter shared artefacts or external behaviour. A generated patch must answer an authorised maintenance objective. Policy, data and model changes can alter behaviour without conventional source changes.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify repository/task baseline, tool/model version, prompts/configuration relevant to evaluation, tests and data/model/policy artefacts. Record benchmark version and excluded cases.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** Acceptance and deployment can be traced to an authorised decision within its stated scope. Preserve actual consumer obligations, not merely benchmark assertions or similarity to a gold patch. Learned behaviour may require statistical rather than deterministic comparisons.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Assess repository-scale and cross-artefact dependencies; generated local diffs can omit tests, configuration or downstream effects.

**COMPREHENSION_ASSUMPTIONS.** Legitimate authority, actual action capability and explicit bounds for any delegation. Automation can shift comprehension into prompting, verification and repair. Task success does not establish general system understanding.

**ORACLE_AND_REGRESSION_LIMITS.** Human approval can be ceremonial or harmed by deceptive plausible patches; role separation alone does not improve correctness. Distinguish plausible patches, independently assessed correctness and accepted deployment. Contamination and shared datasets limit apparent replication.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Generated migration or API changes inherit ordinary coexistence and mapping obligations; an AI label does not relax them.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Delegated release needs explicit bounds and state/effect recovery evidence. An agent’s successful command is not proof of a recovered real system.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Authorised maintainers or policy holders accept changes; generators cannot enlarge their own mandate from a successful test.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** A sole authorised maintainer may generate, inspect and accept a small change without separate roles; logical distinctions do not require separate people. Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which narrow change classes justify unattended acceptance under independently established evidence? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S002; ESME-S024; ESME-S052; ESME-S055; ESME-S067] [ESME-064: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/63)

### ESME-065 — Learned-system data and feedback evolution

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-065`

**Disposition and kind.** DOMAIN_SPECIFIC; LEARNED_SYSTEM_EVOLUTION

**Mature form.** Include data/model/configuration versions and relevant feedback relationships in the change and preservation boundary; use task-appropriate statistical evidence.

**Controlled failure.** A code-only baseline can miss behavioural changes caused by data, models, configuration or feedback from deployed use.

**Trigger.** Maintained behaviour materially depends on learned components or changing data distributions.

**Non-trigger and cheap path.** For deterministic code without learned dependencies, ordinary change evidence applies; no ML-specific machinery is needed.

**Prerequisites.** Data provenance/access, meaningful outcome measures and an understanding of the observation and deployment environment.

**Consumer and authority.** Model/data maintainers and domain owners share responsibility; a model score does not authorise a changed societal or service objective.

**Observable consequence.** The change account identifies which artefacts and distributions changed and which conclusions remain uncertain.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The change account identifies which artefacts and distributions changed and which conclusions remain uncertain. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** The Sculley paper is a conceptual industrial account, not controlled proof of every recommended mitigation; deterministic equivalence does not transfer automatically. How can long-term feedback and distribution shifts be evaluated without treating benchmark stability as deployment stability?

**Anti-ceremony boundary.** Generic deterministic regression suite for learned systems is optional as a named form. For deterministic code without learned dependencies, ordinary change evidence applies; no ML-specific machinery is needed.

**Loss from the cheaper form.** Omitting ML-specific machinery is appropriate without learned dependencies; otherwise it can miss data drift, feedback and distribution-sensitive failures.

**Omission/retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Conflicts and selection conditions.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Maintained behaviour materially depends on learned components or changing data distributions. A generated patch must answer an authorised maintenance objective. Policy, data and model changes can alter behaviour without conventional source changes.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify repository/task baseline, tool/model version, prompts/configuration relevant to evaluation, tests and data/model/policy artefacts. Record benchmark version and excluded cases.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The change account identifies which artefacts and distributions changed and which conclusions remain uncertain. Preserve actual consumer obligations, not merely benchmark assertions or similarity to a gold patch. Learned behaviour may require statistical rather than deterministic comparisons.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Assess repository-scale and cross-artefact dependencies; generated local diffs can omit tests, configuration or downstream effects.

**COMPREHENSION_ASSUMPTIONS.** Data provenance/access, meaningful outcome measures and an understanding of the observation and deployment environment. Automation can shift comprehension into prompting, verification and repair. Task success does not establish general system understanding.

**ORACLE_AND_REGRESSION_LIMITS.** The Sculley paper is a conceptual industrial account, not controlled proof of every recommended mitigation; deterministic equivalence does not transfer automatically. Distinguish plausible patches, independently assessed correctness and accepted deployment. Contamination and shared datasets limit apparent replication.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Generated migration or API changes inherit ordinary coexistence and mapping obligations; an AI label does not relax them.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Delegated release needs explicit bounds and state/effect recovery evidence. An agent’s successful command is not proof of a recovered real system.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Model/data maintainers and domain owners share responsibility; a model score does not authorise a changed societal or service objective.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** For deterministic code without learned dependencies, ordinary change evidence applies; no ML-specific machinery is needed. Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How can long-term feedback and distribution shifts be evaluated without treating benchmark stability as deployment stability? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S042; ESME-S051; ESME-S057] [ESME-065: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/64)

### ESME-066 — Executable-policy and non-code artefact evolution

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-066`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; NON_CODE_ARTEFACT_MAINTENANCE

**Mature form.** Include consequential non-code artefacts in identity, impact and validation; determine whether an artefact is actually consumed or enforced before crediting its effect.

**Controlled failure.** A source-only review can miss changed deployment rules, access decisions, build behaviour or documentation consumed by operators.

**Trigger.** Configuration, policy, schema, build definitions or operational documentation changes actual decisions or execution.

**Non-trigger and cheap path.** Ignore inert or irrelevant files for this change; a focused consumer check may replace a large repository-wide analysis.

**Prerequisites.** Knowledge of the interpreter/consumer, version semantics and relevant effect or enforcement point.

**Consumer and authority.** Artefact owners and operational consumers establish intended effects; a policy file’s author does not automatically control runtime enforcement.

**Observable consequence.** The changed artefact reaches its consumer and has the intended observable consequence, or remains explicitly unverified.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The changed artefact reaches its consumer and has the intended observable consequence, or remains explicitly unverified. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Low commit share is not low labour cost; repository presence is not enforcement; the 2026 policy study’s selected sample does not justify universal adoption. How can rarely changed but high-consequence policy artefacts be tested economically?

**Anti-ceremony boundary.** Repository-wide policy/documentation inventory is optional as a named form. Ignore inert or irrelevant files for this change; a focused consumer check may replace a large repository-wide analysis.

**Loss from the cheaper form.** Focused consumer tracing misses inactive or distant artefacts; expand when changes can alter enforcement, builds or other non-code consumers.

**Omission/retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Conflicts and selection conditions.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Configuration, policy, schema, build definitions or operational documentation changes actual decisions or execution. A generated patch must answer an authorised maintenance objective. Policy, data and model changes can alter behaviour without conventional source changes.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify repository/task baseline, tool/model version, prompts/configuration relevant to evaluation, tests and data/model/policy artefacts. Record benchmark version and excluded cases.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The changed artefact reaches its consumer and has the intended observable consequence, or remains explicitly unverified. Preserve actual consumer obligations, not merely benchmark assertions or similarity to a gold patch. Learned behaviour may require statistical rather than deterministic comparisons.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Assess repository-scale and cross-artefact dependencies; generated local diffs can omit tests, configuration or downstream effects.

**COMPREHENSION_ASSUMPTIONS.** Knowledge of the interpreter/consumer, version semantics and relevant effect or enforcement point. Automation can shift comprehension into prompting, verification and repair. Task success does not establish general system understanding.

**ORACLE_AND_REGRESSION_LIMITS.** Low commit share is not low labour cost; repository presence is not enforcement; the 2026 policy study’s selected sample does not justify universal adoption. Distinguish plausible patches, independently assessed correctness and accepted deployment. Contamination and shared datasets limit apparent replication.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Generated migration or API changes inherit ordinary coexistence and mapping obligations; an AI label does not relax them.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Delegated release needs explicit bounds and state/effect recovery evidence. An agent’s successful command is not proof of a recovered real system.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Artefact owners and operational consumers establish intended effects; a policy file’s author does not automatically control runtime enforcement.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Ignore inert or irrelevant files for this change; a focused consumer check may replace a large repository-wide analysis. Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How can rarely changed but high-consequence policy artefacts be tested economically? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: strong for identified works, not for an invented unified school; THEORETICAL_OR_CONCEPTUAL_SUPPORT: conceptually supported, not a universal performance guarantee; COMPARATIVE_EMPIRICAL_SUPPORT: not established for the generalised property in the inspected corpus; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S002; ESME-S030; ESME-S042; ESME-S056] [ESME-066: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/65)

### ESME-067 — Bounded revision of maintenance methods

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-067`

**Disposition and kind.** CONTEXT_DEPENDENT; METHOD_REVISION_BOUNDARY

**Mature form.** Revise tools, thresholds or inquiry methods through an authorised change with a stated failure/benefit hypothesis, preserving prior obligations unless separately changed.

**Controlled failure.** A maintenance method can become obsolete or revise its own acceptance rules merely to declare success.

**Trigger.** Repeated false positives, missed failures, excessive cost or changed technology undermines the current method.

**Non-trigger and cheap path.** Keep a working method unchanged or remove an unused control; do not add reflexive governance without a demonstrated consumer.

**Prerequisites.** Evidence of the method’s limits, an authorised revision boundary and a comparison not defined solely by the proposed successor.

**Consumer and authority.** Method owners and affected consumers approve changes; the method or agent cannot authorise its own broader powers.

**Observable consequence.** The revision has a bounded rationale and evidence, and previous obligations are not silently rewritten to make it pass.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The revision has a bounded rationale and evidence, and previous obligations are not silently rewritten to make it pass. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** This is analytical synthesis from documented method evolution, not an established universal self-revising maintenance architecture. What independent evidence is enough when a method changes the way its own effectiveness is measured?

**Anti-ceremony boundary.** Permanent self-improvement governance meeting is optional as a named form. Keep a working method unchanged or remove an unused control; do not add reflexive governance without a demonstrated consumer.

**Loss from the cheaper form.** Keeping the existing method may leave emerging failures unaddressed; revise only when actual evidence or changed obligations supplies a reason.

**Omission/retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Conflicts and selection conditions.** ESME-T011: Learning versus stable acceptance rules. Changes to method need external authority and evidence tied to a real failure or cost; unchanged methods and control removal remain options.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Repeated false positives, missed failures, excessive cost or changed technology undermines the current method. A generated patch must answer an authorised maintenance objective. Policy, data and model changes can alter behaviour without conventional source changes.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Identify repository/task baseline, tool/model version, prompts/configuration relevant to evaluation, tests and data/model/policy artefacts. Record benchmark version and excluded cases.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The revision has a bounded rationale and evidence, and previous obligations are not silently rewritten to make it pass. Preserve actual consumer obligations, not merely benchmark assertions or similarity to a gold patch. Learned behaviour may require statistical rather than deterministic comparisons.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Assess repository-scale and cross-artefact dependencies; generated local diffs can omit tests, configuration or downstream effects.

**COMPREHENSION_ASSUMPTIONS.** Evidence of the method’s limits, an authorised revision boundary and a comparison not defined solely by the proposed successor. Automation can shift comprehension into prompting, verification and repair. Task success does not establish general system understanding.

**ORACLE_AND_REGRESSION_LIMITS.** This is analytical synthesis from documented method evolution, not an established universal self-revising maintenance architecture. Distinguish plausible patches, independently assessed correctness and accepted deployment. Contamination and shared datasets limit apparent replication.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Generated migration or API changes inherit ordinary coexistence and mapping obligations; an AI label does not relax them.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Delegated release needs explicit bounds and state/effect recovery evidence. An agent’s successful command is not proof of a recovered real system.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Method owners and affected consumers approve changes; the method or agent cannot authorise its own broader powers.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Keep a working method unchanged or remove an unused control; do not add reflexive governance without a demonstrated consumer. Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** What independent evidence is enough when a method changes the way its own effectiveness is measured? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: Constituent-source provenance is identified; no historical origin is asserted for this new analytical compound.; THEORETICAL_OR_CONCEPTUAL_SUPPORT: reasoned synthesis, not a proved general theorem; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: not established as a direct deployment comparison for this property; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S006; ESME-S025; ESME-S029; ESME-S033; ESME-S049; ESME-S058; ESME-S063] [ESME-067: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/66)

### ESME-072 — Evidence-to-action binding and invalidation

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-072`

**Disposition and kind.** RETAINED_IN_EVOLVED_FORM; COMPOSITION_INDUCED_MECHANISM

**Mature form.** Bind evidence and acceptance to the relevant candidate, intent and assumptions; invalidate or re-evaluate affected evidence when a consequential input changes, and deliver it to an actor able to act.

**Controlled failure.** Each local mechanism can be satisfied while stale evidence, changed intent or uncommunicated results disconnect it from the action actually taken.

**Trigger.** Evidence crosses a tool/person boundary, concurrent work changes the candidate, or a method uses results to authorise action.

**Non-trigger and cheap path.** One maintainer can keep the binding through a single visible diff and check; no new registry or owner is intrinsically required.

**Prerequisites.** Identifiable objects and obligations, traceable evidence scope and a consumer with actual authority and capability.

**Consumer and authority.** Analysts communicate evidence; authorised actors accept and operate; achieved consequences require observation after action.

**Observable consequence.** The actual accepted/deployed candidate is the one supported by the still-applicable evidence, or gaps are explicitly accepted within authority.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The actual accepted/deployed candidate is the one supported by the still-applicable evidence, or gaps are explicitly accepted within authority. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** This relation is a reasoned synthesis, not an empirically validated universal protocol; excessive invalidation can cause rechecking cascades and delay. What is the cheapest reliable binding across independently operated tools and teams?

**Anti-ceremony boundary.** Dedicated evidence registry with automatic invalidation is optional as a named form. One maintainer can keep the binding through a single visible diff and check; no new registry or owner is intrinsically required.

**Loss from the cheaper form.** A visible local diff and check may not survive distributed handoffs or concurrent edits; enrich binding when stale evidence can reach another actor.

**Omission/retirement.** Include coordination and validation costs created by composition. Consolidate or retire controls when a cheaper adequate configuration exists, without silently waiving protected obligations.

**Conflicts and selection conditions.** ESME-T011: Learning versus stable acceptance rules. Changes to method need external authority and evidence tied to a real failure or cost; unchanged methods and control removal remain options.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Evidence crosses a tool/person boundary, concurrent work changes the candidate, or a method uses results to authorise action. The composite maintains a useful system under legitimate changing objectives; it does not maximise activity, code cleanliness, automation or documentation.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Bind evidence and decisions to the actual candidate, baseline and relevant state. Joint deployment/migration states may be objects in their own right.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The actual accepted/deployed candidate is the one supported by the still-applicable evidence, or gaps are explicitly accepted within authority. Carry intended and preserved obligations across handoffs; distinguish knowing a criterion, authority/capability to act and realised consequences.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Composition can create interference or temporary dependencies absent from components. Re-evaluate relevant edges when candidate or assumptions change.

**COMPREHENSION_ASSUMPTIONS.** Identifiable objects and obligations, traceable evidence scope and a consumer with actual authority and capability. No actor needs complete knowledge of the whole system, but consequential information must reach an appropriate decision consumer.

**ORACLE_AND_REGRESSION_LIMITS.** This relation is a reasoned synthesis, not an empirically validated universal protocol; excessive invalidation can cause rechecking cascades and delay. Independent-looking checks can share stale baselines or wrong oracles. Positive local results cannot alone validate the composed outcome.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Choose local change, bounded automation, coexistence, quiescent migration, non-change or retirement under explicit guards; do not require every technique simultaneously.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Couple release choice to actual data/effect recovery or forward repair. Interrupts can stop exposure and reopen earlier judgements without a forced serial pipeline.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Analysts communicate evidence; authorised actors accept and operate; achieved consequences require observation after action.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** One maintainer can keep the binding through a single visible diff and check; no new registry or owner is intrinsically required. Include coordination and validation costs created by composition. Consolidate or retire controls when a cheaper adequate configuration exists, without silently waiving protected obligations.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** What is the cheapest reliable binding across independently operated tools and teams? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: Constituent-source provenance is identified; no historical origin is asserted for this new analytical compound.; THEORETICAL_OR_CONCEPTUAL_SUPPORT: reasoned synthesis, not a proved general theorem; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S002; ESME-S016; ESME-S018; ESME-S024; ESME-S038; ESME-S051; ESME-S052; ESME-S055] [ESME-072: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/71)

### ESME-073 — Continuity of obligations across temporary joint states

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-073`

**Disposition and kind.** ASSUMPTION_SENSITIVE; COMPOSITION_INDUCED_CONSTRAINT

**Mature form.** Identify reachable joint states, authoritative data and permitted version/change combinations; constrain operation or add evidence for the newly created interactions.

**Controlled failure.** Transition or integration can create new interactions absent from either endpoint’s separate assessment.

**Trigger.** Coexistence, concurrent integration, data conversion or externally staggered upgrades create intermediate states.

**Non-trigger and cheap path.** A truly atomic quiescent transition or justified disjoint changes can eliminate most joint-state obligations.

**Prerequisites.** A credible account of reachable combinations, sequencing and external actors; abstract state models must match actual operation.

**Consumer and authority.** Integrators and operators control only their own transitions; consumer/data owners adjudicate cross-boundary obligations.

**Observable consequence.** No supported transition relies solely on endpoint tests when consequential intermediate interactions remain unexamined.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: No supported transition relies solely on endpoint tests when consequential intermediate interactions remain unexamined. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** State-space growth and unknown consumers can make exhaustive validation infeasible; constraints or a different migration strategy may dominate more testing. Which abstractions preserve the consequential joint-state failures without modelling every combination?

**Anti-ceremony boundary.** Exhaustive joint-state model is optional as a named form. A truly atomic quiescent transition or justified disjoint changes can eliminate most joint-state obligations.

**Loss from the cheaper form.** Constraining reachable combinations loses flexibility and may require interruption; that cost can dominate uncontrolled state-space growth.

**Omission/retirement.** Include coordination and validation costs created by composition. Consolidate or retire controls when a cheaper adequate configuration exists, without silently waiving protected obligations.

**Conflicts and selection conditions.** ESME-T007: Coexistence versus quiescent cutover. Use coexistence only when partition and reconciliation costs are tolerable; use quiescence when an accepted stable boundary is credible.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Coexistence, concurrent integration, data conversion or externally staggered upgrades create intermediate states. The composite maintains a useful system under legitimate changing objectives; it does not maximise activity, code cleanliness, automation or documentation.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Bind evidence and decisions to the actual candidate, baseline and relevant state. Joint deployment/migration states may be objects in their own right.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** No supported transition relies solely on endpoint tests when consequential intermediate interactions remain unexamined. Carry intended and preserved obligations across handoffs; distinguish knowing a criterion, authority/capability to act and realised consequences.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Composition can create interference or temporary dependencies absent from components. Re-evaluate relevant edges when candidate or assumptions change.

**COMPREHENSION_ASSUMPTIONS.** A credible account of reachable combinations, sequencing and external actors; abstract state models must match actual operation. No actor needs complete knowledge of the whole system, but consequential information must reach an appropriate decision consumer.

**ORACLE_AND_REGRESSION_LIMITS.** State-space growth and unknown consumers can make exhaustive validation infeasible; constraints or a different migration strategy may dominate more testing. Independent-looking checks can share stale baselines or wrong oracles. Positive local results cannot alone validate the composed outcome.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Choose local change, bounded automation, coexistence, quiescent migration, non-change or retirement under explicit guards; do not require every technique simultaneously.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Couple release choice to actual data/effect recovery or forward repair. Interrupts can stop exposure and reopen earlier judgements without a forced serial pipeline.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Integrators and operators control only their own transitions; consumer/data owners adjudicate cross-boundary obligations.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** A truly atomic quiescent transition or justified disjoint changes can eliminate most joint-state obligations. Include coordination and validation costs created by composition. Consolidate or retire controls when a cheaper adequate configuration exists, without silently waiving protected obligations.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** Which abstractions preserve the consequential joint-state failures without modelling every combination? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: Constituent-source provenance is identified; no historical origin is asserted for this new analytical compound.; THEORETICAL_OR_CONCEPTUAL_SUPPORT: reasoned synthesis, not a proved general theorem; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: not established as independent replication of this entire property; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S031; ESME-S038; ESME-S044; ESME-S045; ESME-S053] [ESME-073: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/72)

### ESME-074 — Feedback-driven proportionality and retirement of maintenance controls

**Global key.** `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-074`

**Disposition and kind.** CONTEXT_DEPENDENT; COMPOSITION_INDUCED_FEEDBACK_AND_RETIREMENT

**Mature form.** Evaluate the combined decision benefit, interaction cost and residual risk of controls; consolidate, simplify or retire them when a cheaper adequate configuration dominates.

**Controlled failure.** Individually sensible checks, documents, adapters and review steps can together exceed their benefit or persist without a consumer.

**Trigger.** Accumulating controls, repeated false alarms, migration completion, disappearing consumers or changed lifecycle objectives.

**Non-trigger and cheap path.** Retain a small working arrangement unchanged; do not create a permanent meta-process merely to measure every control.

**Prerequisites.** Knowledge of protected obligations, actual consumers, combined costs and authority to alter the method without silently waiving required outcomes.

**Consumer and authority.** Maintainers and decision owners revise controls; external obligations remain binding unless legitimately changed.

**Observable consequence.** The smallest adequate configuration retains necessary evidence and authority while removing unjustified duplicate or expired work.

**Evidence the later system must supply.** Actual evidence that the stated trigger and prerequisites hold; an identified candidate, observer and consumer; a supported account of the following postcondition: The smallest adequate configuration retains necessary evidence and authority while removing unjustified duplicate or expired work. Do not replace this with mere presence of the artefact or an inherited score.

**Criticism and residual uncertainty.** Underestimating rare-event value can lead to premature control removal; some fixed coordination costs are necessary even when incidents are infrequent. How should low-frequency high-consequence controls be valued without allowing either permanent ceremony or unsafe removal?

**Anti-ceremony boundary.** Permanent control-optimisation dashboard is optional as a named form. Retain a small working arrangement unchanged; do not create a permanent meta-process merely to measure every control.

**Loss from the cheaper form.** A direct periodic decision can miss slow cost interactions or rare protective value; use richer observation only when it affects justified control selection.

**Omission/retirement.** Include coordination and validation costs created by composition. Consolidate or retire controls when a cheaper adequate configuration exists, without silently waiving protected obligations.

**Conflicts and selection conditions.** ESME-T011: Learning versus stable acceptance rules. Changes to method need external authority and evidence tied to a real failure or cost; unchanged methods and control removal remain options.

**Domain profile.** These ten fields qualify this candidate rather than prescribing ten new artefacts.

**CHANGE_INTENT_AND_CHANGE_CLASS.** Accumulating controls, repeated false alarms, migration completion, disappearing consumers or changed lifecycle objectives. The composite maintains a useful system under legitimate changing objectives; it does not maximise activity, code cleanliness, automation or documentation.

**BASELINE_AND_AFFECTED_ARTEFACTS.** Bind evidence and decisions to the actual candidate, baseline and relevant state. Joint deployment/migration states may be objects in their own right.

**PRESERVATION_OBLIGATION_AND_OBSERVER.** The smallest adequate configuration retains necessary evidence and authority while removing unjustified duplicate or expired work. Carry intended and preserved obligations across handoffs; distinguish knowing a criterion, authority/capability to act and realised consequences.

**IMPACT_BOUNDARY_AND_DEPENDENCY_EVIDENCE.** Composition can create interference or temporary dependencies absent from components. Re-evaluate relevant edges when candidate or assumptions change.

**COMPREHENSION_ASSUMPTIONS.** Knowledge of protected obligations, actual consumers, combined costs and authority to alter the method without silently waiving required outcomes. No actor needs complete knowledge of the whole system, but consequential information must reach an appropriate decision consumer.

**ORACLE_AND_REGRESSION_LIMITS.** Underestimating rare-event value can lead to premature control removal; some fixed coordination costs are necessary even when incidents are infrequent. Independent-looking checks can share stale baselines or wrong oracles. Positive local results cannot alone validate the composed outcome.

**COMPATIBILITY_AND_MIGRATION_PRECONDITIONS.** Choose local change, bounded automation, coexistence, quiescent migration, non-change or retirement under explicit guards; do not require every technique simultaneously.

**RELEASE_ROLLBACK_OR_FORWARD_REPAIR_CONDITION.** Couple release choice to actual data/effect recovery or forward repair. Interrupts can stop exposure and reopen earlier judgements without a forced serial pipeline.

**MAINTAINER_AND_DOWNSTREAM_CONSUMERS.** Maintainers and decision owners revise controls; external obligations remain binding unless legitimately changed.

**LIFECYCLE_COST_AND_RETIREMENT_CONDITION.** Retain a small working arrangement unchanged; do not create a permanent meta-process merely to measure every control. Include coordination and validation costs created by composition. Consolidate or retire controls when a cheaper adequate configuration exists, without silently waiving protected obligations.

**Neutral audit questions.** Does the stated trigger occur in the actual system, and what evidence establishes or excludes it? What existing arrangement, including a cheaper path, already addresses the controlled failure? Can the responsible consumer establish the stated postcondition for the actual baseline and observer? What would show the arrangement is inadequate, unnecessary or too costly? Do current constraints favour a listed alternative, omission or retirement?

**Property-specific challenge.** How should low-frequency high-consequence controls be valued without allowing either permanent ceremony or unsafe removal? The audit should accept evidence of inapplicability or adequate existing practice rather than assume an improvement is needed.

**Evidence partitions.** HISTORICAL_PROVENANCE: Constituent-source provenance is identified; no historical origin is asserted for this new analytical compound.; THEORETICAL_OR_CONCEPTUAL_SUPPORT: reasoned synthesis, not a proved general theorem; COMPARATIVE_EMPIRICAL_SUPPORT: mixed or setting-limited; FIELD_OR_DEPLOYMENT_SUPPORT: contextual; independent generality uncertain; REPLICATION: differentiated/limited; CONTRARY_EVIDENCE: material limits examined; TRANSFERABILITY: assumption-sensitive.

[ESME-S008; ESME-S022; ESME-S031; ESME-S032; ESME-S040; ESME-S048; ESME-S049; ESME-S058] [ESME-074: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/73)

## Non-retained, duplicate, ceremonial and unresolved candidates

These remain part of the 74-candidate denominator. Their presence is not an unconditional audit obligation.

### ESME-010 — Universal mandatory growth or inevitable deterioration

**Disposition.** REJECTED_OR_DISFAVOURED

**Why it is not an unconditional obligation.** REJECTED as a universal mandate; ESME-007 preserves the narrower explanatory programme. Original work itself allows consolidation; later studies show stage and metric dependence. A conditional law does not entail the proposed unconditional mandate.

**Alternative or unresolved burden.** Observe the actual system and consider deliberate non-change. Predictive scope of particular laws remains researchable; rejection does not imply no recurring evolution patterns.

[ESME-S008; ESME-S009; ESME-S010; ESME-S011; ESME-S029; ESME-S060; ESME-S061] [ESME-010: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/9)

### ESME-016 — Exhaustive system comprehension before every change

**Disposition.** REJECTED_OR_DISFAVOURED

**Why it is not an unconditional obligation.** REPLACED by ESME-011, ESME-017 and ESME-021 rather than by permission to change blindly. Formal analysis of a bounded model is possible, but it is not exhaustive knowledge of all real environments and future uses.

**Alternative or unresolved burden.** A local supported explanation and proportionate checks can be sufficient. High-consequence changes can still demand extensive analysis; the appropriate boundary remains a substantive judgement.

[ESME-S013; ESME-S014; ESME-S015] [ESME-016: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/15)

### ESME-028 — Cleaner structure guarantees engineering benefit

**Disposition.** REJECTED_OR_DISFAVOURED

**Why it is not an unconditional obligation.** REJECTED as a guarantee; ESME-027 and ESME-053 retain defeasible uses. Comprehension proxies can miss cross-class effects; refactoring can introduce faults; observational association does not identify net benefit.

**Alternative or unresolved burden.** Keep a harmless structure or make a bounded repair. Particular task/metric relationships can still be validated locally.

[ESME-S020; ESME-S021; ESME-S022] [ESME-028: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/27)

### ESME-048 — Technical novelty or age decides replacement

**Disposition.** REJECTED_OR_DISFAVOURED

**Why it is not an unconditional obligation.** REJECTED as a decision rule; specific age-associated constraints remain inputs to ESME-042. Older dependencies can create real support constraints, but that is evidence about support, not proof from age itself.

**Alternative or unresolved burden.** Continue useful supported operation or make a bounded adaptation. Which actual support and knowledge risks are hidden by a superficially modern platform?

[ESME-S031; ESME-S039; ESME-S040; ESME-S050] [ESME-048: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/47)

### ESME-054 — Mandatory comprehensive cleanup or zero debt

**Disposition.** REJECTED_OR_DISFAVOURED

**Why it is not an unconditional obligation.** REJECTED; ESME-049 through ESME-052 preserve bounded identification, economics and revision. Some debt carries unacceptable risks, but that supports urgent targeted action rather than a universal total-removal rule.

**Alternative or unresolved burden.** Fix the consequential burden, defer harmless issues or leave a stable useful system unchanged. How should genuinely non-deferrable obligations be distinguished from elective maintainability investment?

[ESME-S019; ESME-S032; ESME-S040; ESME-S048; ESME-S049] [ESME-054: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/53)

### ESME-068 — Human-only maintenance is universally superior

**Disposition.** REJECTED_OR_DISFAVOURED

**Why it is not an unconditional obligation.** REJECTED in favour of ESME-061 through ESME-064 and conditional configurations. Correct suggestions helped in the inspected controlled study; SapFix demonstrates bounded deployment; neither proves universal benefit either.

**Alternative or unresolved burden.** Use whichever simple human/tool combination is supported for the actual task, including no automation. Current broad productivity effects remain unresolved rather than replaced with a universal opposite claim.

[ESME-S025; ESME-S033; ESME-S034; ESME-S052; ESME-S055; ESME-S067] [ESME-068: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/67)

### ESME-069 — Reliable unattended repository-scale maintenance as a general capability

**Disposition.** UNRESOLVED

**Why it is not an unconditional obligation.** STILL_CONTESTED/UNRESOLVED: researched uncertainty at the cut-off, not unexamined work and not a claim that future success is impossible. Leakage, weak oracles, selected populations and narrow deployments leave major transfer gaps. Rapid tool change also prevents treating old adverse evidence as a permanent limit.

**Alternative or unresolved burden.** Use bounded automation with explicit constraints, or an ordinary authorised maintainer when evidence is insufficient. Can independently evaluated unattended systems sustain correct, authorised and economical maintenance across representative repositories over time?

[ESME-S024; ESME-S025; ESME-S026; ESME-S027; ESME-S033; ESME-S052; ESME-S055; ESME-S057; ESME-S065; ESME-S067] [ESME-069: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/68)

### ESME-070 — Golden-master preservation as a separate mechanism

**Disposition.** DUPLICATE_CANDIDATE

**Why it is not an unconditional obligation.** SUPERSEDED for independent counting by the exact linked candidate, without deleting its record. Not every snapshot test is a golden master and some encode explicit specifications; those uses must be classified by mechanism, not brand.

**Alternative or unresolved burden.** Use the existing characterisation mechanism; omit duplicate records and tooling in later integration. A materially different trigger or guarantee would require a new candidate rather than silently overloading this alias.

[ESME-S051; ESME-S059] [ESME-070: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/69)

### ESME-071 — A formal change board for every change

**Disposition.** CEREMONY_NOT_GENERAL_PROPERTY

**Why it is not an unconditional obligation.** NARROWED to ESME-001’s underlying property with context-triggered coordination. The sources support controlled management, not this universal caricature. Some regulated or multi-owner contexts genuinely require formal review.

**Alternative or unresolved burden.** A direct authorised maintainer decision can suffice for a bounded change. When does a multi-party forum resolve conflicts more effectively than direct accountable decisions?

[ESME-S002; ESME-S005; ESME-S007; ESME-S039] [ESME-071: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/70)

## Integrated audit questions

Does acceptance evidence still refer to the candidate, purpose and assumptions actually acted upon? Which concurrent or mixed-version states become reachable, and who controls their authority and reconciliation? Do controls create duplication, delay, incentives or hidden review work that undermines their combined benefit? What arrangement is the smallest one that meets the actual obligations? A later audit may find that a direct existing practice is adequate, that a control should be removed, or that evidence is insufficient. None of those outcomes changes the frozen source denominator.

**Boundary:** `SIBLING_CORPORA_NOT_CONSULTED`; `CROSS_TRIFECTA_SYNTHESIS_NOT_PERFORMED`. External analysis does not authorise target mutation.
