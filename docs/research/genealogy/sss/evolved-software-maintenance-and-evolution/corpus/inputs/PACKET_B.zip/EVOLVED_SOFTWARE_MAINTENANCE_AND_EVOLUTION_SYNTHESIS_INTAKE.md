# EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_SYNTHESIS_INTAKE

## Identity and authority boundary

Independent lane **5.2**, within the provisional grouping **SSS — Software Architecture / Software Maintenance and Evolution / Software Product Line Engineering**. Revision `ESME-2026-09-06-r1`; cut-off **2026-09-06**; **74/74 candidates examined**, including 19 with explicit evidence limits. The Evolved name denotes analytical synthesis, not an established named school.

`SIBLING_CORPORA_NOT_CONSULTED`  
`CROSS_TRIFECTA_SYNTHESIS_NOT_PERFORMED`

No source property authorises adoption or mutation of a target. Preserve all 74 stable keys and primary dispositions during reconciliation, including the duplicate and unfavourable candidates. There is no requirement to create one mechanism, control or owner per source property.

## Within-tradition result

The smallest coherent account connects an authorised intended difference and surviving obligations to an identifiable baseline, enough comprehension for the question, justified impact, applicable validation, legitimate action and observation of actual consequences. Migration, continued maintenance, deliberate non-change and retirement remain alternative outcomes. Inquiry, implementation and feedback can be concurrent; new evidence can reopen intent, impact or acceptance. Release observations can interrupt rollout. Code reversal is not presumed to reverse persistent state or external effects.

The three composition-induced candidates add evidence-to-action binding and invalidation (ESME-072), continuity over reachable joint states (ESME-073), and feedback on combined control cost and retirement (ESME-074). These are analytical joins of source-supported parts, not empirical validation of the total architecture. Seven guarded configurations preserve different operating choices; their exact dependencies and 62 relations are in the composition JSON.

## Native distinctions and imports to preserve

Native or shared concepts include multi-purpose corrective/adaptive/perfective/preventive change, scoped evolution regularities, recovery versus transformation, criterion-relative slicing, question-bounded comprehension, impact propagation, observer-relative preservation, provisional and independent oracles, regression selection versus prioritisation, migration reconciliation, debt horizons, maintainer capability and retirement. The field is plural: these are not all descendants of one founding method.

Documented intersections include revision histories as mined-change evidence; test oracles as repair-search fitness; architecture/design recovery in reverse engineering and migration; variability and reference semantics in KConfigReader; and explicit transfer of technical debt into learned-system data/feedback concerns. Similar uses of “evolution” do not establish ancestry. [ESME-S012; ESME-S017; ESME-S031; ESME-S042; ESME-S064; ESME-S065; ESME-S067.]

## Evidence partitions and dependency model

Formal results retain model, observer and implementation preconditions. Standards and project policies define their scopes, not universal economic superiority. Cases and interviews expose feasible operation and failure but do not establish prevalence. Comparative findings retain actual populations, measures and tool vintages. The source-dependence register records reused projects, benchmarks, programmes and editions; source count is not independent replication count.

A criterion specifies what matters; an inquiry or test establishes evidence about it; an actor with actual authority and capacity can intervene; an observation concerns the resulting system. These are coupled but not interchangeable. `REQUIRES`, `ENABLES`, `CONSTRAINS`, `PROVIDES_EVIDENCE_FOR`, `COMMUNICATES_TO`, `ACTS_THROUGH`, `FEEDBACK_TO`, `ALTERNATIVE_TO`, `CONFLICTS_WITH`, `REFINES`, `SUPERSEDES` and `SHARES_ANCESTRY_WITH` carry guarded meanings, not universal sequencing instructions.

| Primary disposition | Candidates |
|---|---:|
| `ASSUMPTION_SENSITIVE` | 12 |
| `CEREMONY_NOT_GENERAL_PROPERTY` | 1 |
| `CONTEXT_DEPENDENT` | 14 |
| `DOMAIN_SPECIFIC` | 2 |
| `DUPLICATE_CANDIDATE` | 1 |
| `REJECTED_OR_DISFAVOURED` | 6 |
| `RETAINED_IN_EVOLVED_FORM` | 25 |
| `STRONGLY_RETAINED` | 11 |
| `UNRESOLVED` | 1 |
| `USEFUL_BUT_EASILY_GAMED` | 1 |
| **Total** | **74** |

## Exported candidate interfaces

Every key is exported, including non-retained candidates, so later reconciliation cannot silently reduce the denominator. “Crosswalk-worthy” means eligible for a contextual question, not prescribed implementation. The source JSON records precise locators and evidence limits for the source IDs below.

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-001` — Explicit and authorised change intent

**Disposition, kind and eligibility.** STRONGLY_RETAINED; DECISION_CRITERION_AND_AUTHORISATION_MECHANISM; crosswalk-worthy: YES

**Mechanism.** State the requested behavioural difference, surviving obligations and decision authority; challenge ambiguous or conflicting requests before treating tests as acceptance.

**Trigger.** New, disputed or externally imposed change objectives, including urgent corrections.

**Required inputs and preconditions.** An identifiable baseline, affected interests and an actor entitled to resolve the objective; emergency delegation must be explicit.

**Produced evidence or constraint.** The accepted difference and preservation boundary can be checked against the actual candidate, with unresolved conflicts visible.

**Decision consumer and operative authority.** Request owner and affected obligation holders determine the objective; implementers can question feasibility but cannot silently redefine acceptance.

**Preservation/observer constraint.** The accepted difference and preservation boundary can be checked against the actual candidate, with unresolved conflicts visible. Separate the observations that must differ from those that must survive. Current obligation holders, including downstream users where relevant, determine what is accepted rather than copying old tests unquestioningly.

**Costs and assumption failures.** Approval can institutionalise an obsolete requirement, exclude affected users or become a bottleneck; procedural approval is not evidence that the goal is beneficial. An informal exchange can leave competing interpretations or missing participants undiscoverable later; retain an explicit decision when that uncertainty matters.

**Selection, substitution and omission.** Use an existing unambiguous authorised request; no new board or document is needed. Decline changes without a supported objective.

**Retirement.** Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

**Conflicts and alternatives.** ESME-T001: Continuity versus necessary behavioural change. Preserve behaviour with a current supported consumer; change it when legitimate intent is revised and transition consequences are addressed. A failing characterisation test is a question, not automatic veto.

**Linked composition relations.** `ESME-R001`, `ESME-R005`, `ESME-R020`, `ESME-R054`, `ESME-R055`, `ESME-R061`

**Source IDs.** [ESME-S002; ESME-S005; ESME-S039; ESME-S051]

[ESME-001: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/0)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-002` — Multi-purpose change classification

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; TAXONOMY_AND_COMMUNICATION; crosswalk-worthy: YES

**Mechanism.** Classify the purposes of a change using stated definitions, permit multiple purposes and explain disagreement where the distinction changes a decision.

**Trigger.** Classification informs planning, funding, reporting or selection of preservation obligations.

**Required inputs and preconditions.** A common unit of classification and enough request context to distinguish intent, environment and prevention.

**Produced evidence or constraint.** A reader can tell which purposes the change serves and whether disputed labels affect a decision.

**Decision consumer and operative authority.** Maintainers and planning consumers agree operational definitions; a classifier has no authority to approve the underlying change.

**Preservation/observer constraint.** A reader can tell which purposes the change serves and whether disputed labels affect a decision. Separate the observations that must differ from those that must survive. Current obligation holders, including downstream users where relevant, determine what is accepted rather than copying old tests unquestioningly.

**Costs and assumption failures.** Benestad finds low inter-rater reliability in a small field setting. Taxonomy precision on paper does not guarantee reproducible classification. Ordinary language loses aggregate comparability; accept that loss when no credible allocation or planning decision uses the categories.

**Selection, substitution and omission.** Use ordinary language when no decision depends on a taxonomy; do not force every commit into one exclusive category.

**Retirement.** Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R001`

**Source IDs.** [ESME-S002; ESME-S004; ESME-S005; ESME-S006; ESME-S007]

[ESME-002: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/1)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-003` — Recoverable configuration baseline

**Disposition, kind and eligibility.** STRONGLY_RETAINED; IDENTITY_AND_CONTROL_MECHANISM; crosswalk-worthy: YES

**Mechanism.** Bind change and evidence to recoverable versions of the relevant source, configuration, build inputs and data/schema state; distinguish identity from recoverability.

**Trigger.** A change or investigation may need reproduction, comparison, release or restoration.

**Required inputs and preconditions.** Actual access to required artefacts, dependency versions and restoration permissions; secrets need references or controlled recovery, not public copying.

**Produced evidence or constraint.** The candidate and its predecessor can be identified; a claimed recovery path has been exercised to the degree needed by the decision.

**Decision consumer and operative authority.** Maintainers and release operators establish the baseline; custodians authorise access and retention.

**Preservation/observer constraint.** The candidate and its predecessor can be identified; a claimed recovery path has been exercised to the degree needed by the decision. Separate the observations that must differ from those that must survive. Current obligation holders, including downstream users where relevant, determine what is accepted rather than copying old tests unquestioningly.

**Costs and assumption failures.** A commit identifier does not identify database contents or remote effects. Archiving an artefact does not show that it builds or can be safely restored. A lighter baseline may omit a mutable build input, schema or remote state; include any omitted input capable of changing the relevant result.

**Selection, substitution and omission.** Use existing versioned inputs and reproducible commands; do not snapshot irrelevant infrastructure or duplicate authoritative history.

**Retirement.** Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R002`, `ESME-R019`, `ESME-R028`, `ESME-R053`, `ESME-R055`

**Source IDs.** [ESME-S002; ESME-S030; ESME-S038; ESME-S046]

[ESME-003: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/2)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-004` — Maintenance readiness across the delivery boundary

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; CAPABILITY_PREPARATION; crosswalk-worthy: YES

**Mechanism.** Before transferring responsibility, establish the receiving maintainer’s access, runnable artefacts, known obligations and escalation route; revisit after ownership changes.

**Trigger.** Initial delivery, outsourcing, major platform change or ownership handoff.

**Required inputs and preconditions.** A receiving actor, accepted responsibility and feasible resources; possession of documents alone is insufficient.

**Produced evidence or constraint.** The receiving maintainer can perform a representative bounded change or diagnosis with the supplied means.

**Decision consumer and operative authority.** Delivering and receiving maintainers negotiate support responsibility; a research assessment cannot impose labour or grant access.

**Preservation/observer constraint.** The receiving maintainer can perform a representative bounded change or diagnosis with the supplied means. Separate the observations that must differ from those that must survive. Current obligation holders, including downstream users where relevant, determine what is accepted rather than copying old tests unquestioningly.

**Costs and assumption failures.** Guide scope establishes a planning responsibility, not a measured universal benefit of every transition artefact. Knowledge-loss proxies do not measure all expertise. An informal handover may fail to expose missing credentials, unavailable expertise or unusable artefacts; a small capability check can reveal these failures.

**Selection, substitution and omission.** An existing competent team with unchanged access can reuse its arrangements; no separate transition ceremony is inherently required.

**Retirement.** Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R003`, `ESME-R046`

**Source IDs.** [ESME-S001; ESME-S002; ESME-S003; ESME-S005; ESME-S047]

[ESME-004: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/3)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-005` — Deliberate non-change

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; DECISION_ALTERNATIVE; crosswalk-worthy: YES

**Mechanism.** Compare a proposed intervention with continued operation under current obligations; permit deliberate non-change with explicit revisit triggers.

**Trigger.** A stable useful system has no material unmet requirement, unsupported dependency exposure or changing obligation requiring action.

**Required inputs and preconditions.** Enough evidence about utility, dependency support and external obligations to distinguish stability from neglected risk.

**Produced evidence or constraint.** The decision records why no intervention is justified and what changed condition would reopen it.

**Decision consumer and operative authority.** Service or product decision makers accept residual risk; maintainers report relevant changes without treating every observation as a mandate to modify.

**Preservation/observer constraint.** The decision records why no intervention is justified and what changed condition would reopen it. Separate the observations that must differ from those that must survive. Current obligation holders, including downstream users where relevant, determine what is accepted rather than copying old tests unquestioningly.

**Costs and assumption failures.** A project labelled finished may still have dependent users or changing security obligations. Absence of commits is not proof of either health or abandonment. Choosing no change leaves latent risks and future adaptation costs in place; retain revisit signals for actual changing obligations rather than activity targets.

**Selection, substitution and omission.** Leave the system unchanged and retain only necessary observation or support; do not invent work to sustain activity.

**Retirement.** Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

**Conflicts and alternatives.** ESME-T003: Local repair versus replacement. Choose by unmet obligations, support feasibility and lifecycle cost including transition; age alone has no deciding role.

**Linked composition relations.** `ESME-R004`, `ESME-R007`, `ESME-R034`, `ESME-R045`, `ESME-R048`

**Source IDs.** [ESME-S010; ESME-S031; ESME-S040; ESME-S050; ESME-S061]

[ESME-005: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/4)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-006` — Evolution feedback with measurable consequences

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; FEEDBACK_MECHANISM; crosswalk-worthy: YES

**Mechanism.** Observe demand, delivered effects, effort and consequences over time; revise change priorities when those observations challenge the operative model.

**Trigger.** Repeated change in a system exposed to evolving use and stakeholder expectations.

**Required inputs and preconditions.** Consistent measurement boundaries, interpretable observations and authority to change priorities.

**Produced evidence or constraint.** A consequential observation can be traced to a changed decision, an explicit decision not to change, or an unresolved uncertainty.

**Decision consumer and operative authority.** Maintainers, users and decision makers exchange usage and cost evidence; observation alone neither authorises intervention nor identifies causation.

**Preservation/observer constraint.** A consequential observation can be traced to a changed decision, an explicit decision not to change, or an unresolved uncertainty. The observer includes users’ usefulness and maintainers’ ability to change, not just line counts. Preserve required service while allowing deliberate simplification or changed requirements.

**Costs and assumption failures.** Time-series association and fitted curves do not identify causal feedback. Measures can be gamed and external shocks confound trends. Direct occasional review can miss slow trends and cross-team effects; use time-series observation when those effects change real decisions.

**Selection, substitution and omission.** For infrequent bounded changes, a direct outcome review may suffice; do not institute a metric programme without a decision consumer.

**Retirement.** Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R005`, `ESME-R006`, `ESME-R029`, `ESME-R043`, `ESME-R056`, `ESME-R059`

**Source IDs.** [ESME-S008; ESME-S009; ESME-S010; ESME-S029; ESME-S060; ESME-S061]

[ESME-006: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/5)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-007` — Population-scoped evolution-law interpretation

**Disposition, kind and eligibility.** ASSUMPTION_SENSITIVE; EMPIRICAL_MODEL_INTERPRETATION; crosswalk-worthy: YES

**Mechanism.** Declare system population, time scale, metric and conditional clauses before applying an evolution regularity; compare plausible alternative interpretations.

**Trigger.** A growth, complexity, effort or quality law is used to explain or predict an actual system.

**Required inputs and preconditions.** An operational interpretation of the law, compatible observations and a potential disconfirming result.

**Produced evidence or constraint.** The claim specifies what would count against it and avoids converting a conditional regularity into a requirement.

**Decision consumer and operative authority.** Analysts state scope; planning authorities decide whether that evidence warrants investment, not whether the word law compels it.

**Preservation/observer constraint.** The claim specifies what would count against it and avoids converting a conditional regularity into a requirement. The observer includes users’ usefulness and maintainers’ ability to change, not just line counts. Preserve required service while allowing deliberate simplification or changed requirements.

**Costs and assumption failures.** Linux and glibc findings depend on aggregation, stage and metrics. Conditional prevention clauses can make some formulations difficult to falsify. Direct local evidence gives up broad explanatory comparisons; this is acceptable when population and measurement conditions are not established.

**Selection, substitution and omission.** Use direct local evidence without invoking a law when the classification or measurement adds no decision value.

**Retirement.** Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R006`, `ESME-R007`

**Source IDs.** [ESME-S008; ESME-S009; ESME-S010; ESME-S011; ESME-S029; ESME-S060; ESME-S061]

[ESME-007: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/6)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-008` — Costed complexity and anti-regressive work

**Disposition, kind and eligibility.** CONTEXT_DEPENDENT; INVESTMENT_MECHANISM; crosswalk-worthy: YES

**Mechanism.** Identify a change-relevant source of difficulty and compare targeted restructuring with leaving it, wrapping it or replacing the affected part.

**Trigger.** Recurrent changes or demonstrated failures make a particular structural difficulty consequential.

**Required inputs and preconditions.** A stated future change class, intervention cost and evidence connecting the alleged complexity to that cost.

**Produced evidence or constraint.** The targeted task becomes easier or safer under stated measures, or the proposed benefit is withdrawn.

**Decision consumer and operative authority.** Maintainers propose structural work; product or service authorities accept its opportunity cost and risk.

**Preservation/observer constraint.** The targeted task becomes easier or safer under stated measures, or the proposed benefit is withdrawn. The observer includes users’ usefulness and maintainers’ ability to change, not just line counts. Preserve required service while allowing deliberate simplification or changed requirements.

**Costs and assumption failures.** Total complexity can rise while local complexity falls; added variation may be necessary. Metric improvement does not establish useful simplification. A local repair may retain a recurrent structural obstacle; favour it only when avoiding that obstacle does not justify wider relearning and regression cost.

**Selection, substitution and omission.** Use a local repair or tolerate harmless complexity when no likely change benefits from restructuring.

**Retirement.** Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.

**Conflicts and alternatives.** ESME-T002: Familiarity versus simplification. Prefer restructuring when a plausible recurrent task benefit exceeds relearning, review and regression cost; prefer familiarity when the system is stable or retiring.

**Linked composition relations.** `ESME-R005`, `ESME-R006`, `ESME-R022`

**Source IDs.** [ESME-S008; ESME-S020; ESME-S022; ESME-S032; ESME-S050; ESME-S060]

[ESME-008: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/7)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-009` — Familiarity and knowledge-capacity constraints

**Disposition, kind and eligibility.** CONTEXT_DEPENDENT; HUMAN_CAPACITY_CONSTRAINT; crosswalk-worthy: YES

**Mechanism.** Adjust change scope, sequencing, learning and review to demonstrated maintainer capacity; expose concentrated knowledge and provide learning opportunities.

**Trigger.** Rapid growth, departure, ownership concentration or repeated review/comprehension failures.

**Required inputs and preconditions.** Access to people and artefacts, an honest account of capacity and authority to defer or narrow change.

**Produced evidence or constraint.** Affected changes have competent review and support, or a visible capacity constraint changes the plan.

**Decision consumer and operative authority.** Maintainer teams and managers negotiate workload; repository metrics cannot assign expertise or compel unpaid work.

**Preservation/observer constraint.** Affected changes have competent review and support, or a visible capacity constraint changes the plan. The observer includes users’ usefulness and maintainers’ ability to change, not just line counts. Preserve required service while allowing deliberate simplification or changed requirements.

**Costs and assumption failures.** Commit ownership is an incomplete proxy for knowledge; spreading ownership can also increase coordination cost and reduce deep expertise. Informal familiarity judgements may miss concentrated or unavailable expertise; enlarge the assessment when absence would obstruct a consequential change.

**Selection, substitution and omission.** An experienced available maintainer can make a bounded change without a formal knowledge census.

**Retirement.** Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.

**Conflicts and alternatives.** ESME-T002: Familiarity versus simplification. Prefer restructuring when a plausible recurrent task benefit exceeds relearning, review and regression cost; prefer familiarity when the system is stable or retiring.

**Linked composition relations.** `ESME-R008`, `ESME-R046`

**Source IDs.** [ESME-S008; ESME-S010; ESME-S014; ESME-S043; ESME-S047]

[ESME-009: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/8)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-010` — Universal mandatory growth or inevitable deterioration

**Disposition, kind and eligibility.** REJECTED_OR_DISFAVOURED; OVERGENERALISED_EMPIRICAL_CLAIM; crosswalk-worthy: NO

**Mechanism.** Do not enact this rule; replace it with scoped interpretation and observed consequences.

**Trigger.** Only triggered for adjudication when someone invokes age or an evolution law as sufficient reason to change.

**Required inputs and preconditions.** The rejected rule lacks a defensible universal population and invariant measurement.

**Produced evidence or constraint.** The universal premise is absent from an accepted change rationale.

**Decision consumer and operative authority.** No actor gains authority to impose growth from the laws; decision makers still need a justified objective.

**Preservation/observer constraint.** The universal premise is absent from an accepted change rationale. The observer includes users’ usefulness and maintainers’ ability to change, not just line counts. Preserve required service while allowing deliberate simplification or changed requirements.

**Costs and assumption failures.** Original work itself allows consolidation; later studies show stage and metric dependence. A conditional law does not entail the proposed unconditional mandate. Omitting this rejected target has no demonstrated inherent loss; genuinely changing obligations remain reasons to reconsider non-change.

**Selection, substitution and omission.** Observe the actual system and consider deliberate non-change.

**Retirement.** Observe at a scale where results can change decisions; retire unused dashboards or metrics. Include measurement cost and the option of a stable useful system.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R007`

**Source IDs.** [ESME-S008; ESME-S009; ESME-S010; ESME-S011; ESME-S029; ESME-S060; ESME-S061]

[ESME-010: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/9)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-011` — Question-bounded program comprehension

**Disposition, kind and eligibility.** STRONGLY_RETAINED; INQUIRY_MECHANISM; crosswalk-worthy: YES

**Mechanism.** Identify the questions needed for this change, seek evidence until consequential uncertainties are bounded, and expand inquiry when evidence contradicts the model.

**Trigger.** A change depends on unfamiliar behaviour, ownership, dependencies or intent.

**Required inputs and preconditions.** A stated change objective and access to representative source, execution or knowledgeable people.

**Produced evidence or constraint.** The maintainer can explain the relevant predicted effects and identify remaining uncertainty that matters for the decision.

**Decision consumer and operative authority.** The maintainer frames and tests explanations; affected experts can correct them but do not automatically authorise a patch.

**Preservation/observer constraint.** The maintainer can explain the relevant predicted effects and identify remaining uncertainty that matters for the decision. Name the value, behaviour, feature or consumer being explained. Recovering what happens does not determine whether it should continue.

**Costs and assumption failures.** A bounded question can be wrongly framed and hide a dependency; confidence or a polished explanation is not operational validation. Bounded inquiry can miss a question that would change the intervention; retain an explicit trigger for expanding inquiry when observations disagree.

**Selection, substitution and omission.** Reuse reliable knowledge and perform a small confirming check when the question is local and low consequence.

**Retirement.** Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

**Conflicts and alternatives.** ESME-T002: Familiarity versus simplification. Prefer restructuring when a plausible recurrent task benefit exceeds relearning, review and regression cost; prefer familiarity when the system is stable or retiring.

**Linked composition relations.** `ESME-R002`, `ESME-R008`, `ESME-R009`, `ESME-R010`, `ESME-R011`, `ESME-R012`, `ESME-R016`, `ESME-R060`

**Source IDs.** [ESME-S014; ESME-S015; ESME-S051]

[ESME-011: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/10)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-012` — Static and dynamic evidence triangulation

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; EVIDENCE_COMBINATION; crosswalk-worthy: YES

**Mechanism.** Compare structural dependencies with representative execution, configuration and build evidence; investigate consequential disagreement.

**Trigger.** Dynamic binding, generated code, reflection, configuration or sparse tests make one evidence mode incomplete.

**Required inputs and preconditions.** Known analysis scope and representative execution conditions; trace absence must not be read as impossibility.

**Produced evidence or constraint.** Conclusions state what each mode observes and preserve unknown or contradictory edges.

**Decision consumer and operative authority.** Maintainers and operators supply complementary evidence; tool outputs are observations rather than approval.

**Preservation/observer constraint.** Conclusions state what each mode observes and preserve unknown or contradictory edges. Name the value, behaviour, feature or consumer being explained. Recovering what happens does not determine whether it should continue.

**Costs and assumption failures.** Static analysis may over-approximate; dynamic analysis misses unexecuted paths. Shared assumptions can make apparent agreement misleading. A single evidence mode can miss its blind spots; the cheap path requires an adequately closed question, not mere agreement with the preferred explanation.

**Selection, substitution and omission.** Use one adequate analysis for a demonstrably closed local case; combining tools is not mandatory when it adds no discriminating observation.

**Retirement.** Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R010`

**Source IDs.** [ESME-S012; ESME-S013; ESME-S014; ESME-S015; ESME-S044; ESME-S051]

[ESME-012: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/11)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-013` — Criterion-relative program slicing

**Disposition, kind and eligibility.** ASSUMPTION_SENSITIVE; FORMAL_ANALYSIS_TECHNIQUE; crosswalk-worthy: YES

**Mechanism.** Compute or inspect a slice relative to a declared criterion and analysis assumptions; treat it as evidence about that criterion, not the complete impact set.

**Trigger.** A value, statement or behaviour can be represented by a tractable slicing criterion.

**Required inputs and preconditions.** Soundness assumptions for the chosen static/dynamic analysis, aliasing, control flow, termination and environment.

**Produced evidence or constraint.** The slice and its criterion are explicit, with effects outside the model excluded from the guarantee.

**Decision consumer and operative authority.** Analysts choose the criterion; maintainers decide whether its omissions are acceptable for the actual change.

**Preservation/observer constraint.** The slice and its criterion are explicit, with effects outside the model excluded from the guarantee. Name the value, behaviour, feature or consumer being explained. Recovering what happens does not determine whether it should continue.

**Costs and assumption failures.** General minimal slicing is undecidable; computable slices need not be minimal and the guarantee need not cover termination or arbitrary observers. Direct inspection loses systematic reach through complex dependencies; use a sound applicable analysis when manual omission risk becomes consequential.

**Selection, substitution and omission.** Direct inspection of a tiny dependency chain may be cheaper; avoid slicing where external effects are outside the model.

**Retirement.** Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R010`, `ESME-R062`

**Source IDs.** [ESME-S013; ESME-S051]

[ESME-013: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/12)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-014` — Distinguish recovery from transformation

**Disposition, kind and eligibility.** STRONGLY_RETAINED; CONCEPTUAL_BOUNDARY; crosswalk-worthy: YES

**Mechanism.** Label whether an activity recovers information, changes representation at the same abstraction, or reconstructs/changes the system; assign evidence and authority accordingly.

**Trigger.** A recovery or modernisation activity is proposed, evaluated or handed off.

**Required inputs and preconditions.** Identification of input/output artefacts, abstraction level and whether external behaviour is intended to change.

**Produced evidence or constraint.** The activity’s deliverable and actual effect are distinguishable and testable.

**Decision consumer and operative authority.** Analysts recover evidence; authorised maintainers perform transformations; consumers must not infer one from the other.

**Preservation/observer constraint.** The activity’s deliverable and actual effect are distinguishable and testable. Name the value, behaviour, feature or consumer being explained. Recovering what happens does not determine whether it should continue.

**Costs and assumption failures.** Industrial terminology is broader and inconsistent; labels alone cannot resolve actual semantics or prove preservation. Unlabelled activities can blur analysis and mutation; retain an ordinary-language distinction whenever authority or preservation evidence differs.

**Selection, substitution and omission.** Ordinary descriptions suffice for unambiguous local work; a taxonomy table is unnecessary.

**Retirement.** Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R011`

**Source IDs.** [ESME-S012; ESME-S021]

[ESME-014: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/13)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-015` — Recover intent with rationale and human knowledge

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; KNOWLEDGE_RECOVERY_AND_COMMUNICATION; crosswalk-worthy: YES

**Mechanism.** Recover consequential rationale from requirements, history, operations and knowledgeable people; link it to decisions and mark uncertain or superseded interpretations.

**Trigger.** Undocumented behaviour, disputed intent, missing ownership or a knowledge handoff affects a change.

**Required inputs and preconditions.** Provenance for recovered claims and access to a consumer able to challenge them.

**Produced evidence or constraint.** A maintainer can identify both the rationale and its current acceptance or uncertainty.

**Decision consumer and operative authority.** Knowledge holders explain history; current obligation owners determine what should survive. Recollection is evidence, not sole authority.

**Preservation/observer constraint.** A maintainer can identify both the rationale and its current acceptance or uncertainty. Name the value, behaviour, feature or consumer being explained. Recovering what happens does not determine whether it should continue.

**Costs and assumption failures.** Memory and documentation can be wrong or stale; history does not make a past choice permanently binding. A short note or conversation may not survive turnover or reach another consumer; preserve consequential rationale in a retrievable form when reuse is likely.

**Selection, substitution and omission.** Ask the relevant person or retain a short decision note rather than reconstructing a comprehensive document set.

**Retirement.** Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R010`

**Source IDs.** [ESME-S012; ESME-S014; ESME-S015; ESME-S043; ESME-S047]

[ESME-015: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/14)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-016` — Exhaustive system comprehension before every change

**Disposition, kind and eligibility.** REJECTED_OR_DISFAVOURED; OVERGENERALISED_PROCESS_REQUIREMENT; crosswalk-worthy: NO

**Mechanism.** Reject the universal prerequisite; use question-bounded comprehension plus impact expansion when necessary.

**Trigger.** Adjudicate when a process demands exhaustive recovery without identifying a consumer or risk.

**Required inputs and preconditions.** Complete understanding has no generally operational stopping rule for open, changing systems.

**Produced evidence or constraint.** The accepted inquiry boundary is justified by the change rather than by impossible completeness.

**Decision consumer and operative authority.** No process owner should certify total knowledge from a completed model alone.

**Preservation/observer constraint.** The accepted inquiry boundary is justified by the change rather than by impossible completeness. Name the value, behaviour, feature or consumer being explained. Recovering what happens does not determine whether it should continue.

**Costs and assumption failures.** Formal analysis of a bounded model is possible, but it is not exhaustive knowledge of all real environments and future uses. Omitting this rejected prerequisite sacrifices no established universal guarantee; high-consequence local proof or wider impact evidence may still be necessary.

**Selection, substitution and omission.** A local supported explanation and proportionate checks can be sufficient.

**Retirement.** Stop inquiry when the consequential question is adequately supported at acceptable risk; expand on contrary evidence. Retain only explanations with plausible future consumers.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R009`

**Source IDs.** [ESME-S013; ESME-S014; ESME-S015]

[ESME-016: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/15)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-017` — Justified impact boundary

**Disposition, kind and eligibility.** STRONGLY_RETAINED; IMPACT_DECISION_MECHANISM; crosswalk-worthy: YES

**Mechanism.** Propose an impact boundary from relevant dependencies, challenge it with contrary evidence and widen it when an affected obligation crosses the boundary.

**Trigger.** A change could propagate beyond the directly edited artefacts.

**Required inputs and preconditions.** Baseline identity, change intent and declared dependency evidence with known omissions.

**Produced evidence or constraint.** Affected obligations and excluded areas have an explicit rationale linked to evidence.

**Decision consumer and operative authority.** Maintainers justify the boundary to reviewers and affected consumers; reviewers can require expansion but cannot infer completeness from tool silence.

**Preservation/observer constraint.** Affected obligations and excluded areas have an explicit rationale linked to evidence. Impacted observers include direct callers, data readers, operators and combined changes. Preserve their accepted obligations, not every correlation in history.

**Costs and assumption failures.** Impact sets are estimates; a tool’s recall in a benchmark does not prove absence of missed effects in a target. A smaller justified boundary may miss an undeclared interaction; include a challenge proportionate to the consequence of that miss.

**Selection, substitution and omission.** Accept a local boundary with a concrete reason when interfaces and dependencies make the effect local; no whole-system analysis by default.

**Retirement.** Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

**Conflicts and alternatives.** ESME-T008: Impact completeness versus investigation cost. Scale challenge effort to plausible missed-edge consequence and evidence quality; accept demonstrably local changes locally.

**Linked composition relations.** `ESME-R002`, `ESME-R012`, `ESME-R013`, `ESME-R014`, `ESME-R016`, `ESME-R026`, `ESME-R055`, `ESME-R062`

**Source IDs.** [ESME-S013; ESME-S016; ESME-S017; ESME-S044]

[ESME-017: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/16)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-018` — Heterogeneous dependency propagation

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; DEPENDENCY_MODEL; crosswalk-worthy: YES

**Mechanism.** Include the dependency kinds through which the proposed change can affect actual consumers, and distinguish declared, inferred and observed edges.

**Trigger.** The changed object participates in shared data, interfaces, builds, learned feedback or cross-team operation.

**Required inputs and preconditions.** Evidence for each consequential edge, its direction and the context in which it is active.

**Produced evidence or constraint.** The impact account includes relevant non-code and cross-boundary consequences with uncertain edges marked.

**Decision consumer and operative authority.** Maintainers and downstream owners communicate constraints; a graph does not grant control over independent consumers.

**Preservation/observer constraint.** The impact account includes relevant non-code and cross-boundary consequences with uncertain edges marked. Impacted observers include direct callers, data readers, operators and combined changes. Preserve their accepted obligations, not every correlation in history.

**Costs and assumption failures.** Declared package edges are not identical to runtime behaviour; organisational relations cannot be inferred solely from source imports. Focused inspection can omit configuration, data or organisational edges outside its chosen kinds; expand when the change can act through them.

**Selection, substitution and omission.** Do not construct every possible graph; inspect only dependency kinds relevant to the change and its obligations.

**Retirement.** Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

**Conflicts and alternatives.** ESME-T008: Impact completeness versus investigation cost. Scale challenge effort to plausible missed-edge consequence and evidence quality; accept demonstrably local changes locally.

**Linked composition relations.** `ESME-R013`, `ESME-R014`, `ESME-R053`

**Source IDs.** [ESME-S016; ESME-S041; ESME-S042; ESME-S044; ESME-S053]

[ESME-018: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/17)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-019` — Historical co-change as defeasible evidence

**Disposition, kind and eligibility.** ASSUMPTION_SENSITIVE; PREDICTIVE_EVIDENCE; crosswalk-worthy: YES

**Mechanism.** Use co-change as a defeasible candidate generator; confirm semantic or organisational relevance before requiring another change.

**Trigger.** History is sufficiently representative and structural evidence leaves uncertainty about likely companion changes.

**Required inputs and preconditions.** Clean enough history, meaningful change units and awareness of bulk edits, conventions and process changes.

**Produced evidence or constraint.** Recommended impacts are either supported, rejected with reason or retained as uncertainty; absence is not certified independence.

**Decision consumer and operative authority.** Tools suggest; maintainers validate relevance and decide action.

**Preservation/observer constraint.** Recommended impacts are either supported, rejected with reason or retained as uncertainty; absence is not certified independence. Impacted observers include direct callers, data readers, operators and combined changes. Preserve their accepted obligations, not every correlation in history.

**Costs and assumption failures.** S017 explicitly distinguishes historical practice from intended dependencies. Co-change may reflect habit, generated files or a single broad commit. Ignoring history may lose a useful clue when intent has vanished; history remains a candidate source rather than a required companion-edit generator.

**Selection, substitution and omission.** Ignore the predictor for new code, rewritten history or an already understood local dependency.

**Retirement.** Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

**Conflicts and alternatives.** ESME-T008: Impact completeness versus investigation cost. Scale challenge effort to plausible missed-edge consequence and evidence quality; accept demonstrably local changes locally.

**Linked composition relations.** `ESME-R014`

**Source IDs.** [ESME-S017; ESME-S044]

[ESME-019: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/18)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-020` — Affected-consumer discovery

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; CONSUMER_DISCOVERY_AND_COMMUNICATION; crosswalk-worthy: YES

**Mechanism.** Identify plausible consumers through interfaces, usage, dependency data and consultation; disclose uncertainty and notify those needing action.

**Trigger.** A public or shared behaviour, data format, dependency or support promise changes.

**Required inputs and preconditions.** A defined support/compatibility surface and channels reaching relevant consumers.

**Produced evidence or constraint.** Known affected consumers receive actionable information or an inability to reach them constrains release.

**Decision consumer and operative authority.** Producers communicate change and uncertainty; independent consumers decide their own migration and acceptance.

**Preservation/observer constraint.** Known affected consumers receive actionable information or an inability to reach them constrains release. Impacted observers include direct callers, data readers, operators and combined changes. Preserve their accepted obligations, not every correlation in history.

**Costs and assumption failures.** Undeclared consumers may remain undiscoverable; notification does not prove receipt, ability to migrate or consent. Direct contact with known callers cannot establish the absence of other consumers; retain a notice or compatibility interval where undiscovered use is plausible.

**Selection, substitution and omission.** For a private bounded use with no external consumer, direct coordination with the local caller may suffice.

**Retirement.** Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R013`, `ESME-R015`

**Source IDs.** [ESME-S016; ESME-S041; ESME-S042; ESME-S043; ESME-S045]

[ESME-020: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/19)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-021` — Impact false-negative challenge

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; ADVERSARIAL_EVIDENCE_MECHANISM; crosswalk-worthy: YES

**Mechanism.** Seek counterexamples outside the proposed boundary using representative consumers, broader regression or a second evidence mode, scaled to consequence.

**Trigger.** High-consequence change, weak dependency evidence, novel configuration or disagreement among analyses.

**Required inputs and preconditions.** A proposed boundary, plausible missed-edge hypotheses and affordable observations.

**Produced evidence or constraint.** A missed effect expands the boundary or changes the decision; negative checks retain stated limits.

**Decision consumer and operative authority.** Reviewers and maintainers challenge the analysis; operators or users supply observations beyond development’s model.

**Preservation/observer constraint.** A missed effect expands the boundary or changes the decision; negative checks retain stated limits. Impacted observers include direct callers, data readers, operators and combined changes. Preserve their accepted obligations, not every correlation in history.

**Costs and assumption failures.** No finite challenge proves absence of all unknown effects; independent-looking tools may share the same incomplete model. A small challenge has limited power against hidden edges; widen it when a missed effect would be costly or the first model has weak support.

**Selection, substitution and omission.** For a trivial closed change, a targeted independent check may dominate broad retesting.

**Retirement.** Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

**Conflicts and alternatives.** ESME-T008: Impact completeness versus investigation cost. Scale challenge effort to plausible missed-edge consequence and evidence quality; accept demonstrably local changes locally.

**Linked composition relations.** `ESME-R013`, `ESME-R016`, `ESME-R060`

**Source IDs.** [ESME-S016; ESME-S017; ESME-S044; ESME-S051]

[ESME-021: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/20)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-022` — Semantic interference analysis for merged changes

**Disposition, kind and eligibility.** ASSUMPTION_SENSITIVE; SEMANTIC_CONFLICT_ANALYSIS; crosswalk-worthy: YES

**Mechanism.** Analyse or exercise the merged artefact against combined obligations, using interference candidates to guide investigation rather than declaring every flow a conflict.

**Trigger.** Concurrent changes interact through shared state, dataflow, interfaces or assumptions even when textual merge succeeds.

**Required inputs and preconditions.** A common baseline, both change intents, buildable merged artefact and supported analysis semantics.

**Produced evidence or constraint.** Consequential interactions are accepted, corrected or kept unresolved before the combined release decision.

**Decision consumer and operative authority.** Change authors and integrators resolve intended interaction; a detector cannot infer stakeholder intent from information flow alone.

**Preservation/observer constraint.** Consequential interactions are accepted, corrected or kept unresolved before the combined release decision. Impacted observers include direct callers, data readers, operators and combined changes. Preserve their accepted obligations, not every correlation in history.

**Costs and assumption failures.** The inspected study trades greater static recall for lower precision; many cases reuse earlier datasets and unsupported cases limit generality. Textual merging alone misses behaviourally interacting edits; focused tests can substitute only for the relevant reachable interactions.

**Selection, substitution and omission.** Independent changes with a justified disjoint impact boundary may need only normal combined regression.

**Retirement.** Balance broader investigation against false-positive work. Stop maintaining dependency representations when no decision consumes them, not while hidden critical dependencies remain.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R017`, `ESME-R057`

**Source IDs.** [ESME-S044; ESME-S051]

[ESME-022: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/21)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-023` — Observer-relative preservation obligations

**Disposition, kind and eligibility.** STRONGLY_RETAINED; PRESERVATION_CRITERION; crosswalk-worthy: YES

**Mechanism.** Name the observers, environments and obligations to remain invariant, separately from intended differences; compare the actual transformation against that boundary.

**Trigger.** Any change claims to preserve behaviour, especially restructuring or compatibility-sensitive repair.

**Required inputs and preconditions.** An explicit contract or adjudicated account of relevant observations and environmental assumptions.

**Produced evidence or constraint.** The preservation claim states its observer and exclusions; observed violations are not excused merely because tests pass.

**Decision consumer and operative authority.** Obligation holders and maintainers determine the preservation surface; a tool’s narrower model cannot silently replace it.

**Preservation/observer constraint.** The preservation claim states its observer and exclusions; observed violations are not excused merely because tests pass. Declare relevant O and E, including exceptions, side effects and performance when part of the supported contract; do not assume all internal differences are observable obligations.

**Costs and assumption failures.** Complete equivalence is often undecidable or intractable; broadening observers may make a previously valid proof inapplicable. An informal observer boundary can omit timing, persistence or reflection; specify and check those observations when actual consumers rely on them.

**Selection, substitution and omission.** A narrow observer and a direct comparison suffice where that is the actual contract; do not require equivalence for irrelevant internal states.

**Retirement.** Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

**Conflicts and alternatives.** ESME-T001: Continuity versus necessary behavioural change. Preserve behaviour with a current supported consumer; change it when legitimate intent is revised and transition consequences are addressed. A failing characterisation test is a question, not automatic veto.

**Linked composition relations.** `ESME-R018`, `ESME-R019`, `ESME-R053`

**Source IDs.** [ESME-S012; ESME-S018; ESME-S020; ESME-S022; ESME-S045; ESME-S051]

[ESME-023: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/22)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-024` — Transformation preconditions and model scope

**Disposition, kind and eligibility.** ASSUMPTION_SENSITIVE; FORMAL_TRANSFORMATION_CONDITION; crosswalk-worthy: YES

**Mechanism.** Check the transformation’s preconditions in the actual relevant model, and expose unsupported language or environment features before relying on a preservation argument.

**Trigger.** An automated or manual transformation relies on a formal or tool-defined refactoring rule.

**Required inputs and preconditions.** A valid mapping from actual language/tool version and artefacts to the proof or rule’s assumptions.

**Produced evidence or constraint.** The applied rule, satisfied assumptions and out-of-model features are identifiable.

**Decision consumer and operative authority.** Tool authors establish model-relative guarantees; maintainers verify applicability and retain responsibility for excluded observers.

**Preservation/observer constraint.** The applied rule, satisfied assumptions and out-of-model features are identifiable. Declare relevant O and E, including exceptions, side effects and performance when part of the supported contract; do not assume all internal differences are observable obligations.

**Costs and assumption failures.** A proof about a model does not validate its implementation or environmental assumptions; reflection and external persistence may invalidate naive transfer. Direct checks may not cover all proof preconditions; a formal applicability argument is valuable when the language/environment assumptions can actually be established.

**Selection, substitution and omission.** For a small obvious edit, direct semantic reasoning and testing may be cheaper than a general transformation framework.

**Retirement.** Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

**Conflicts and alternatives.** ESME-T004: Automated transformation versus review burden. Evaluate correct outcomes and full cost for the task and tool version. Strong narrow transformations can need less manual review; weak oracles demand more independent evidence.

**Linked composition relations.** `ESME-R018`, `ESME-R019`

**Source IDs.** [ESME-S018; ESME-S020; ESME-S051]

[ESME-024: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/23)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-025` — Validation of the actual transformed artefact

**Disposition, kind and eligibility.** STRONGLY_RETAINED; TRANSFORMATION_VALIDATION; crosswalk-worthy: YES

**Mechanism.** Check the actual transformed baseline using relevant semantic reasoning, tests or comparison; invalidate earlier evidence when consequential inputs change.

**Trigger.** Any consequential restructuring, generated patch or composed change is proposed for acceptance.

**Required inputs and preconditions.** Candidate identity, obligations and a validation method whose limits are understood.

**Produced evidence or constraint.** The exact candidate has evidence for its intended and preserved obligations, with unresolved failures visible.

**Decision consumer and operative authority.** Maintainers and reviewers consume validation evidence; the generator cannot self-certify correctness solely through its own success flag.

**Preservation/observer constraint.** The exact candidate has evidence for its intended and preserved obligations, with unresolved failures visible. Declare relevant O and E, including exceptions, side effects and performance when part of the supported contract; do not assume all internal differences are observable obligations.

**Costs and assumption failures.** Validation can share the generator’s assumptions or miss rare environments. More tests are not necessarily more independent evidence. A small check observes fewer consequences than a broader suite or proof; its adequacy depends on the actual transformation and impact boundary.

**Selection, substitution and omission.** A small reviewed diff and a targeted check may be enough; no universal demand for multiple expensive validators.

**Retirement.** Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

**Conflicts and alternatives.** ESME-T004: Automated transformation versus review burden. Evaluate correct outcomes and full cost for the task and tool version. Strong narrow transformations can need less manual review; weak oracles demand more independent evidence.

**Linked composition relations.** `ESME-R002`, `ESME-R008`, `ESME-R011`, `ESME-R017`, `ESME-R018`, `ESME-R019`, `ESME-R023`, `ESME-R025`, `ESME-R028`, `ESME-R029`, `ESME-R050`, `ESME-R055`, `ESME-R056`, `ESME-R058`

**Source IDs.** [ESME-S018; ESME-S020; ESME-S024; ESME-S051; ESME-S052]

[ESME-025: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/24)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-026` — Separate preservation from intentional behaviour change

**Disposition, kind and eligibility.** STRONGLY_RETAINED; CHANGE_SEMANTICS_BOUNDARY; crosswalk-worthy: YES

**Mechanism.** Declare intentional behavioural differences independently from structural work; revise obsolete tests through an authorised account of intended behaviour.

**Trigger.** A patch mixes restructuring with correction, adaptation or changed requirements.

**Required inputs and preconditions.** A baseline, accepted intended difference and evidence for the behaviour that still must remain stable.

**Produced evidence or constraint.** Reviewers can distinguish intended differences from regressions and know why changed tests are justified.

**Decision consumer and operative authority.** Current obligation owners authorise semantic change; maintainers may reorganise code within that boundary.

**Preservation/observer constraint.** Reviewers can distinguish intended differences from regressions and know why changed tests are justified. Declare relevant O and E, including exceptions, side effects and performance when part of the supported contract; do not assume all internal differences are observable obligations.

**Costs and assumption failures.** Artificially splitting tightly coupled changes can add churn and temporary inconsistency; separation is conceptual, not always separate commits. Combining changes can obscure which differences are intended; preserve independently interpretable acceptance obligations even in one patch.

**Selection, substitution and omission.** One combined patch is permissible when separating it increases risk, provided the distinct obligations remain assessable.

**Retirement.** Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

**Conflicts and alternatives.** ESME-T001: Continuity versus necessary behavioural change. Preserve behaviour with a current supported consumer; change it when legitimate intent is revised and transition consequences are addressed. A failing characterisation test is a question, not automatic veto.

**Linked composition relations.** `ESME-R018`, `ESME-R020`

**Source IDs.** [ESME-S002; ESME-S018; ESME-S023; ESME-S051; ESME-S059]

[ESME-026: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/25)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-027` — Refactoring benefit tied to a future change class

**Disposition, kind and eligibility.** CONTEXT_DEPENDENT; BENEFIT_EVALUATION; crosswalk-worthy: YES

**Mechanism.** Name the future change or comprehension task expected to improve, compare intervention cost and evaluate a task-relevant outcome rather than a metric alone.

**Trigger.** Restructuring is justified by maintainability, comprehension or reduced future change cost.

**Required inputs and preconditions.** A plausible future task population and an explicit account of present disruption and review cost.

**Produced evidence or constraint.** The claimed task benefit has evidence or is explicitly withdrawn as uncertain after evaluation.

**Decision consumer and operative authority.** Maintainers propose benefits; those bearing delivery and lifecycle costs decide priority.

**Preservation/observer constraint.** The claimed task benefit has evidence or is explicitly withdrawn as uncertain after evaluation. Declare relevant O and E, including exceptions, side effects and performance when part of the supported contract; do not assume all internal differences are observable obligations.

**Costs and assumption failures.** Surveys are self-report; metric studies are not human-task trials; bug-inducing associations are confounded by concurrent edits and change size. Local repair can leave repeated future work expensive; accept that cost when expected recurrence does not justify restructuring now.

**Selection, substitution and omission.** Leave the structure alone, repair locally or improve a small seam when no broader benefit is supported.

**Retirement.** Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

**Conflicts and alternatives.** ESME-T002: Familiarity versus simplification. Prefer restructuring when a plausible recurrent task benefit exceeds relearning, review and regression cost; prefer familiarity when the system is stable or retiring.

**Linked composition relations.** `ESME-R021`, `ESME-R022`, `ESME-R043`

**Source IDs.** [ESME-S018; ESME-S019; ESME-S020; ESME-S021; ESME-S022]

[ESME-027: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/26)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-028` — Cleaner structure guarantees engineering benefit

**Disposition, kind and eligibility.** REJECTED_OR_DISFAVOURED; UNSUPPORTED_BENEFIT_GUARANTEE; crosswalk-worthy: NO

**Mechanism.** Reject the guarantee; require a task-specific causal account and proportionate outcome evidence.

**Trigger.** Adjudicate when a structural metric or catalogue label is offered as sufficient benefit evidence.

**Required inputs and preconditions.** No universal mapping from structural score to all relevant outcomes is established.

**Produced evidence or constraint.** No unconditional payoff is inferred from a cleaner representation alone.

**Decision consumer and operative authority.** Metric producers do not determine product value; affected maintainers and users supply task evidence.

**Preservation/observer constraint.** No unconditional payoff is inferred from a cleaner representation alone. Declare relevant O and E, including exceptions, side effects and performance when part of the supported contract; do not assume all internal differences are observable obligations.

**Costs and assumption failures.** Comprehension proxies can miss cross-class effects; refactoring can introduce faults; observational association does not identify net benefit. Omitting the rejected proxy guarantee loses no demonstrated universal payoff; specific validated indicators may remain useful evidence.

**Selection, substitution and omission.** Keep a harmless structure or make a bounded repair.

**Retirement.** Justify restructuring by a plausible future task and total cost, not aesthetic improvement. Decline or stop work when the targeted burden is absent or retiring.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R021`

**Source IDs.** [ESME-S020; ESME-S021; ESME-S022]

[ESME-028: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/27)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-029` — Oracle provenance and independent obligations

**Disposition, kind and eligibility.** STRONGLY_RETAINED; ORACLE_ESTABLISHMENT; crosswalk-worthy: YES

**Mechanism.** Trace acceptance expectations to independent requirements, adjudicated behaviour, domain properties or credible reference evidence; state gaps and conflicts.

**Trigger.** Test results support a change decision or a test expectation itself changes.

**Required inputs and preconditions.** Known oracle provenance, candidate identity and an actor able to resolve intended behaviour.

**Produced evidence or constraint.** The acceptance claim distinguishes observed passage from the supported intended and preserved obligations.

**Decision consumer and operative authority.** Domain experts and obligation owners adjudicate expectations; tests and agents produce evidence, not authority.

**Preservation/observer constraint.** The acceptance claim distinguishes observed passage from the supported intended and preserved obligations. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**Costs and assumption failures.** No single oracle source is universally reliable; reference systems and humans can be wrong, and complete specifications are costly. A short expectation can omit its provenance or stale assumptions; retain enough justification to distinguish accepted behaviour from accidental output.

**Selection, substitution and omission.** A trusted narrow assertion may suffice for a simple obligation; do not build a specification language merely for appearance.

**Retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and alternatives.** ESME-T005: Test preservation versus correction of obsolete behaviour. Adjudicate the supported observer and oracle provenance. Gold-patch identity alone cannot settle correctness.

**Linked composition relations.** `ESME-R016`, `ESME-R019`, `ESME-R020`, `ESME-R023`, `ESME-R025`, `ESME-R026`, `ESME-R050`, `ESME-R053`, `ESME-R055`

**Source IDs.** [ESME-S024; ESME-S026; ESME-S051; ESME-S052]

[ESME-029: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/28)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-030` — Characterisation as provisional behavioural evidence

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; BEHAVIOUR_RECOVERY_TESTING; crosswalk-worthy: YES

**Mechanism.** Observe and record behaviour relevant to the change, treat it as provisional evidence, and adjudicate which observations are contractual rather than automatically preserving all of them.

**Trigger.** Useful or risky behaviour is poorly documented and can be exercised.

**Required inputs and preconditions.** Representative inputs, environmental context and a way to distinguish intended changes from accidental regression.

**Produced evidence or constraint.** Important observed behaviour is either protected, intentionally revised or explicitly unresolved.

**Decision consumer and operative authority.** Maintainers collect evidence; domain and downstream consumers determine which behaviours deserve continuity.

**Preservation/observer constraint.** Important observed behaviour is either protected, intentionally revised or explicitly unresolved. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**Costs and assumption failures.** Golden outputs may preserve defects or incidental formatting; nondeterminism can make brittle tests and obscure actual obligations. Temporary or selective characterisation leaves some existing behaviour unrecorded; preserve samples that protect real consumers, not every historical accident.

**Selection, substitution and omission.** A temporary probe, recorded example or focused test can suffice; retire incidental characterisation tests after their consumer disappears.

**Retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and alternatives.** ESME-T001: Continuity versus necessary behavioural change. Preserve behaviour with a current supported consumer; change it when legitimate intent is revised and transition consequences are addressed. A failing characterisation test is a question, not automatic veto. ESME-T005: Test preservation versus correction of obsolete behaviour. Adjudicate the supported observer and oracle provenance. Gold-patch identity alone cannot settle correctness.

**Linked composition relations.** `ESME-R020`, `ESME-R023`, `ESME-R024`, `ESME-R025`

**Source IDs.** [ESME-S024; ESME-S051; ESME-S059]

[ESME-030: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/29)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-031` — Differential testing with adjudicated differences

**Disposition, kind and eligibility.** CONTEXT_DEPENDENT; COMPARATIVE_TESTING; crosswalk-worthy: YES

**Mechanism.** Run comparable inputs against the old/new or independent implementations, locate differences and adjudicate them against intended obligations.

**Trigger.** A credible reference exists and executions can be made comparable.

**Required inputs and preconditions.** Comparable input/environment, known intended differences and awareness of common-mode defects.

**Produced evidence or constraint.** Observed differences are classified as intended, erroneous or unresolved rather than automatically counted as bugs.

**Decision consumer and operative authority.** Maintainers investigate discrepancies; a reference implementation is evidence, not an unquestionable specification.

**Preservation/observer constraint.** Observed differences are classified as intended, erroneous or unresolved rather than automatically counted as bugs. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**Costs and assumption failures.** Agreement can preserve a shared defect; configuration enumeration can be intractable; original behaviour may be obsolete. Single implementation checks lose the second implementation's discrepancy signal; differential testing is useful only when differences can be adjudicated and cost is justified.

**Selection, substitution and omission.** Use direct expected results for simple cases; no duplicate implementation is required where it adds less evidence than it costs.

**Retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and alternatives.** ESME-T005: Test preservation versus correction of obsolete behaviour. Adjudicate the supported observer and oracle provenance. Gold-patch identity alone cannot settle correctness.

**Linked composition relations.** `ESME-R023`, `ESME-R025`

**Source IDs.** [ESME-S051; ESME-S064]

[ESME-031: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/30)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-032` — Metamorphic relations as partial oracles

**Disposition, kind and eligibility.** ASSUMPTION_SENSITIVE; PARTIAL_ORACLE_TECHNIQUE; crosswalk-worthy: YES

**Mechanism.** Choose justified input/output relations, execute related cases and investigate violations while preserving the relation’s domain assumptions.

**Trigger.** Exact expected results are difficult but a relevant mathematical or domain relation is credible.

**Required inputs and preconditions.** A valid metamorphic relation, appropriate numerical/nondeterministic tolerance and no unaccounted persistent side effects.

**Produced evidence or constraint.** The relation is checked for stated cases, with no claim that satisfaction proves arbitrary output correctness.

**Decision consumer and operative authority.** Domain specialists justify relations; maintainers implement and interpret tests.

**Preservation/observer constraint.** The relation is checked for stated cases, with no claim that satisfaction proves arbitrary output correctness. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**Costs and assumption failures.** A wrong relation rejects correct behaviour; a weak relation accepts many wrong outputs; mined invariants can reproduce existing defects. A few relations expose only a subset of possible errors; expanding the catalogue helps only when new relations are independently valid for the domain.

**Selection, substitution and omission.** Use ordinary assertions when expected results are cheap; do not invent weak relations to inflate a test count.

**Retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and alternatives.** ESME-T005: Test preservation versus correction of obsolete behaviour. Adjudicate the supported observer and oracle provenance. Gold-patch identity alone cannot settle correctness.

**Linked composition relations.** `ESME-R023`, `ESME-R025`

**Source IDs.** [ESME-S051; ESME-S063]

[ESME-032: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/31)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-033` — Mutation analysis as an adequacy probe

**Disposition, kind and eligibility.** CONTEXT_DEPENDENT; TEST_ADEQUACY_PROBE; crosswalk-worthy: YES

**Mechanism.** Use selected mutation operators to challenge tests, investigate surviving mutants and improve assertions where the mutant represents a relevant fault.

**Trigger.** Critical regression claims depend on a test suite whose fault sensitivity is uncertain.

**Required inputs and preconditions.** Valid operators, interpretable mutants and a correct oracle for deciding whether altered behaviour matters.

**Produced evidence or constraint.** Relevant surviving mutants lead to improved tests or an explicit explanation of irrelevance.

**Decision consumer and operative authority.** Test maintainers interpret survivors; a mutation score does not authorise release or define correctness.

**Preservation/observer constraint.** Relevant surviving mutants lead to improved tests or an explicit explanation of irrelevance. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**Costs and assumption failures.** The real-fault relationship is sample- and operator-dependent; equivalent mutants and selected reproducible bugs limit interpretation. A smaller challenge can miss oracle weaknesses revealed by additional mutants; larger campaigns require a useful fault model and an affordable consumer action.

**Selection, substitution and omission.** A few manually chosen fault injections may be enough; skip large mutation campaigns when equivalent mutants or cost dominate.

**Retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R023`, `ESME-R025`

**Source IDs.** [ESME-S051; ESME-S062]

[ESME-033: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/32)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-034` — Regression selection under explicit safety and cost assumptions

**Disposition, kind and eligibility.** ASSUMPTION_SENSITIVE; REGRESSION_SELECTION; crosswalk-worthy: YES

**Mechanism.** Select tests using change/dependency evidence and stated safety assumptions; include analysis, selection and validation costs in the comparison.

**Trigger.** Retest-all cost is consequential and change impact can be analysed well enough to support selection.

**Required inputs and preconditions.** A recoverable baseline, test-to-behaviour mapping and explicit handling of environment and nondeterminism.

**Produced evidence or constraint.** The selected set and omitted-test rationale are identifiable; selection failure expands or abandons the optimisation.

**Decision consumer and operative authority.** Test/release owners choose tolerable omission risk; a safe-selection theorem is relative to the existing tests, not complete correctness.

**Preservation/observer constraint.** The selected set and omitted-test rationale are identifiable; selection failure expands or abandons the optimisation. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**Costs and assumption failures.** Safe selection does not repair inadequate tests or wrong oracles; analysis overhead and implementation defects can erase benefits. Retest-all gives up potential execution savings but avoids selection analysis and omission risk; use it when the full suite is cheap.

**Selection, substitution and omission.** Run the whole small suite when selection overhead exceeds savings.

**Retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and alternatives.** ESME-T008: Impact completeness versus investigation cost. Scale challenge effort to plausible missed-edge consequence and evidence quality; accept demonstrably local changes locally. ESME-T009: Early feedback versus evidence breadth. A release decision may wait for critical checks even when routine feedback is prioritised. Small suites favour retest-all.

**Linked composition relations.** `ESME-R023`, `ESME-R026`, `ESME-R060`

**Source IDs.** [ESME-S023; ESME-S051]

[ESME-034: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/33)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-035` — Test prioritisation under interruption and feedback costs

**Disposition, kind and eligibility.** CONTEXT_DEPENDENT; FEEDBACK_SCHEDULING; crosswalk-worthy: YES

**Mechanism.** Prioritise evidence according to failure consequence and decision timing; record skipped or unfinished checks as such, not as passed.

**Trigger.** Execution may be interrupted or feedback latency materially affects repair/release decisions.

**Required inputs and preconditions.** Interpretable historical evidence, stable enough workload and an explicit delay tolerance.

**Produced evidence or constraint.** The decision knows which obligations were checked, delayed or not examined.

**Decision consumer and operative authority.** Maintainers and release consumers set decision deadlines; scheduling tools only allocate observation effort.

**Preservation/observer constraint.** The decision knows which obligations were checked, delayed or not examined. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**Costs and assumption failures.** Prediction may leak future data; build counts are incomplete cost proxies; reordering can starve rare tests and delay discovery. A simple order may reveal some failures later; ranking adds value only when earlier detection changes an action and exceeds ranking cost.

**Selection, substitution and omission.** Use the ordinary order for a fast suite; do not train a predictor without a meaningful latency problem.

**Retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and alternatives.** ESME-T009: Early feedback versus evidence breadth. A release decision may wait for critical checks even when routine feedback is prioritised. Small suites favour retest-all.

**Linked composition relations.** `ESME-R027`, `ESME-R060`

**Source IDs.** [ESME-S023; ESME-S051; ESME-S058; ESME-S066]

[ESME-035: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/34)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-036` — Reproducible and identifiable build evidence

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; BUILD_IDENTITY_AND_REPRODUCTION; crosswalk-worthy: YES

**Mechanism.** Identify build inputs and expected outputs; reproduce the relevant artefact or explain environmental variance and validate what is actually shipped.

**Trigger.** Release, archival reconstruction or cross-environment validation depends on build identity.

**Required inputs and preconditions.** Controlled or recorded toolchain/dependencies, available inputs and a declared comparison boundary.

**Produced evidence or constraint.** The artefact under review is tied to its inputs, and claimed reproducibility is demonstrated within the stated boundary.

**Decision consumer and operative authority.** Build and release maintainers provide provenance; reproducibility does not grant trust in source correctness.

**Preservation/observer constraint.** The artefact under review is tied to its inputs, and claimed reproducibility is demonstrated within the stated boundary. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**Costs and assumption failures.** Identical output can identically reproduce a defect; remote mutable inputs and proprietary dependencies can block reconstruction. A merely identified build cannot establish byte-for-byte reproducibility; decide whether independent reproduction is an actual preservation or supply requirement.

**Selection, substitution and omission.** For a disposable local script, a versioned command and environment record may suffice; bit-for-bit output is not always the necessary observer.

**Retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R002`, `ESME-R028`

**Source IDs.** [ESME-S002; ESME-S030; ESME-S038; ESME-S046]

[ESME-036: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/35)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-037` — Continuous integration with consumed feedback

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; INTEGRATION_FEEDBACK; crosswalk-worthy: YES

**Mechanism.** Run appropriate checks on integrated states, route failures to someone able to act, and make skipped, stale or failing observations visible to release decisions.

**Trigger.** Multiple changes integrate frequently enough that delayed failures have material cost.

**Required inputs and preconditions.** Identifiable integrated state, useful checks, available execution resources and a responding maintainer.

**Produced evidence or constraint.** A failed or missing check changes action, or an explicit authorised exception records its implications.

**Decision consumer and operative authority.** The integration service observes; maintainers diagnose and fix; release authority decides whether remaining uncertainty permits delivery.

**Preservation/observer constraint.** A failed or missing check changes action, or an explicit authorised exception records its implications. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**Costs and assumption failures.** Adoption associations do not prove causal survival benefits; flaky or ignored checks can become expensive ceremony. Direct local checking lacks automatically shared timely feedback; use it only when coordination and integration consequences are truly local.

**Selection, substitution and omission.** For rare changes, a manual reproducible integration check may provide equivalent evidence.

**Retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and alternatives.** ESME-T009: Early feedback versus evidence breadth. A release decision may wait for critical checks even when routine feedback is prioritised. Small suites favour retest-all.

**Linked composition relations.** `ESME-R027`, `ESME-R029`, `ESME-R056`, `ESME-R060`

**Source IDs.** [ESME-S002; ESME-S040; ESME-S058]

[ESME-037: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/36)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-038` — Declared compatibility surface and version policy

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; COMPATIBILITY_CONTRACT; crosswalk-worthy: YES

**Mechanism.** Declare the supported interface/behaviour surface and transition policy, including exceptions, and test changes against the expectations actually communicated.

**Trigger.** Independent consumers rely on an API, format, behaviour or support promise.

**Required inputs and preconditions.** An identifiable producer, consumers and evidence for the promised compatibility dimensions.

**Produced evidence or constraint.** Consumers can determine what an upgrade promises and which actions a changed behaviour requires.

**Decision consumer and operative authority.** Producers define and honour published support commitments; exceptional breakage requires the appropriate authority and communication.

**Preservation/observer constraint.** Consumers can determine what an upgrade promises and which actions a changed behaviour requires. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**Costs and assumption failures.** Undocumented does not automatically mean private; version numbers alone prove neither compatibility nor consumer readiness. Direct contract comparison lacks the convention's communication convenience; a label can help consumers but cannot replace evidence about changed behaviour.

**Selection, substitution and omission.** For a private coordinated consumer, a direct agreement can replace a public versioning policy.

**Retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and alternatives.** ESME-T001: Continuity versus necessary behavioural change. Preserve behaviour with a current supported consumer; change it when legitimate intent is revised and transition consequences are addressed. A failing characterisation test is a question, not automatic veto.

**Linked composition relations.** `ESME-R015`, `ESME-R018`, `ESME-R030`

**Source IDs.** [ESME-S043; ESME-S045; ESME-S051]

[ESME-038: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/37)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-039` — Mixed-version compatibility conditions

**Disposition, kind and eligibility.** ASSUMPTION_SENSITIVE; COEXISTENCE_CONSTRAINT; crosswalk-worthy: YES

**Mechanism.** Identify permitted producer/consumer and schema/version combinations; enforce sequencing or adapters where not all combinations are compatible.

**Trigger.** A deployment, dependency ecosystem or migration permits mixed versions.

**Required inputs and preconditions.** Known version combinations, routing/data ownership and a way to prevent unsupported interactions.

**Produced evidence or constraint.** Only supported combinations operate, or unsupported combinations are detected and contained.

**Decision consumer and operative authority.** Operators coordinate rollout; independent consumers retain their own upgrade authority and may constrain timing.

**Preservation/observer constraint.** Only supported combinations operate, or unsupported combinations are detected and contained. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**Costs and assumption failures.** Combinations grow rapidly; wrappers can hide disagreement and remain indefinitely; external consumers may not follow the intended order. Constraining deployments to fewer combinations sacrifices rollout flexibility; that can be cheaper and safer than testing unsupported combinations.

**Selection, substitution and omission.** Use a genuinely quiescent coordinated cutover when it is cheaper and acceptable; then the mixed-version matrix may be unnecessary.

**Retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and alternatives.** ESME-T007: Coexistence versus quiescent cutover. Use coexistence only when partition and reconciliation costs are tolerable; use quiescence when an accepted stable boundary is credible.

**Linked composition relations.** `ESME-R030`, `ESME-R031`, `ESME-R036`, `ESME-R057`, `ESME-R058`

**Source IDs.** [ESME-S031; ESME-S038; ESME-S043; ESME-S045; ESME-S053]

[ESME-039: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/38)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-040` — Staged exposure with actionable observations

**Disposition, kind and eligibility.** CONTEXT_DEPENDENT; EXPOSURE_CONTROL_AND_OBSERVATION; crosswalk-worthy: YES

**Mechanism.** Expose a bounded population or function, observe predeclared consequences and expand, stop or repair according to actionable evidence.

**Trigger.** Consequences can be observed before full exposure and populations or functions can be separated safely.

**Required inputs and preconditions.** Meaningful observations, a control over exposure and feasible recovery/forward-repair actions.

**Produced evidence or constraint.** Observed failure changes rollout or repair action, and the released population/state is identifiable.

**Decision consumer and operative authority.** Operators control exposure within authorisation; affected users’ obligations remain relevant even in a small stage.

**Preservation/observer constraint.** Observed failure changes rollout or repair action, and the released population/state is identifiable. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**Costs and assumption failures.** A quiet stage may miss rare or delayed failures; selection can make early users unrepresentative; dual operation adds complexity. A direct release forgoes early limited-exposure observation; acceptable only when the experiment would be uninformative or proportionate alternatives address its risk.

**Selection, substitution and omission.** Use a direct cutover for a tiny reversible change or when staging introduces more inconsistency than it reduces risk.

**Retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and alternatives.** ESME-T009: Early feedback versus evidence breadth. A release decision may wait for critical checks even when routine feedback is prioritised. Small suites favour retest-all.

**Linked composition relations.** `ESME-R027`, `ESME-R031`, `ESME-R032`, `ESME-R056`, `ESME-R058`

**Source IDs.** [ESME-S035; ESME-S036; ESME-S037; ESME-S038]

[ESME-040: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/39)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-041` — State-and-effect recovery rather than code reversion alone

**Disposition, kind and eligibility.** STRONGLY_RETAINED; RECOVERY_AND_EFFECT_CONTROL; crosswalk-worthy: YES

**Mechanism.** Classify reversible and irreversible effects; demonstrate restoration/reconciliation where promised, otherwise plan forward repair or explicitly authorised loss.

**Trigger.** A change writes persistent data, alters schemas or causes external effects whose reversal matters.

**Required inputs and preconditions.** Usable backups/logs or compensating capabilities, retention/access rights and an understood recovery point.

**Produced evidence or constraint.** The recovered or repaired state satisfies stated obligations, with unrecoverable effects disclosed.

**Decision consumer and operative authority.** Operators perform recovery; data and service obligation owners authorise irreversible actions and residual losses.

**Preservation/observer constraint.** The recovered or repaired state satisfies stated obligations, with unrecoverable effects disclosed. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**Costs and assumption failures.** GitLab’s incident shows that backup existence and restore compatibility can fail; compensation is not necessarily a true inverse. A narrower recovery plan may leave persistent data or external effects unrecoverable; explicitly accept or provide forward repair for those effects rather than imply undo.

**Selection, substitution and omission.** For a pure read-only reversible change, restoring the prior artefact may genuinely be sufficient.

**Retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R032`, `ESME-R033`, `ESME-R037`

**Source IDs.** [ESME-S038; ESME-S053]

[ESME-041: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/40)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-042` — Compare maintenance, migration, replacement and non-change

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; LIFECYCLE_OPTION_SELECTION; crosswalk-worthy: YES

**Mechanism.** Compare options against utility, constraints, knowledge, migration risk and full lifecycle cost, including deliberate non-change and retirement.

**Trigger.** Current maintenance no longer clearly serves required outcomes or a substantial migration is proposed.

**Required inputs and preconditions.** An honest baseline of current value and constraints, credible alternatives and attention to transition as well as end-state cost.

**Produced evidence or constraint.** The selected option has a reasoned advantage under stated assumptions and explicit triggers for reconsideration.

**Decision consumer and operative authority.** Product/service and data owners choose the objective and acceptable risk; maintainers establish feasibility and hidden obligations.

**Preservation/observer constraint.** The selected option has a reasoned advantage under stated assumptions and explicit triggers for reconsideration. Preserve accepted domain meaning and service obligations while deliberately changing implementation or supported behaviour; legacy bugs can be relied-on observations that require adjudication.

**Costs and assumption failures.** Success stories are selected; failed projects have multiple causes; evidence rarely supports universal superiority of incremental or big-bang approaches. A bounded comparison may omit distant options or costs; enlarge it when transition irreversibility or support commitments make the omission material.

**Selection, substitution and omission.** A bounded repair or continued operation may dominate a programme of replacement.

**Retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

**Conflicts and alternatives.** ESME-T003: Local repair versus replacement. Choose by unmet obligations, support feasibility and lifecycle cost including transition; age alone has no deciding role.

**Linked composition relations.** `ESME-R004`, `ESME-R034`, `ESME-R040`, `ESME-R048`

**Source IDs.** [ESME-S031; ESME-S035; ESME-S036; ESME-S039; ESME-S040]

[ESME-042: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/41)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-043` — Incremental displacement with bounded coexistence

**Disposition, kind and eligibility.** CONTEXT_DEPENDENT; INCREMENTAL_MIGRATION; crosswalk-worthy: YES

**Mechanism.** Choose a separable function or consumer boundary, route it deliberately, reconcile shared state and retire the old path after its obligations transfer.

**Trigger.** Work can be partitioned with tolerable coexistence and useful partial delivery.

**Required inputs and preconditions.** Routing control, explicit data authority, compatibility and an exit condition for duplicate operation.

**Produced evidence or constraint.** A bounded function moves with reconciled obligations, and the old path is removed or explicitly retained for a named consumer.

**Decision consumer and operative authority.** Migration teams implement boundaries; service/data owners authorise routing and eventual retirement.

**Preservation/observer constraint.** A bounded function moves with reconciled obligations, and the old path is removed or explicitly retained for a named consumer. Preserve accepted domain meaning and service obligations while deliberately changing implementation or supported behaviour; legacy bugs can be relied-on observations that require adjudication.

**Costs and assumption failures.** Gateways, dual data and duplicated knowledge can create the worst of both systems; selected industrial accounts do not establish general cost superiority. A direct cutover loses incremental learning and staged value; it can still dominate when coexistence is infeasible or more expensive.

**Selection, substitution and omission.** Prefer a local repair or quiescent cutover when partitions are artificial or gateways cost more than staged benefit.

**Retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

**Conflicts and alternatives.** ESME-T003: Local repair versus replacement. Choose by unmet obligations, support feasibility and lifecycle cost including transition; age alone has no deciding role. ESME-T007: Coexistence versus quiescent cutover. Use coexistence only when partition and reconciliation costs are tolerable; use quiescence when an accepted stable boundary is credible.

**Linked composition relations.** `ESME-R031`, `ESME-R034`, `ESME-R035`, `ESME-R036`, `ESME-R057`, `ESME-R060`

**Source IDs.** [ESME-S031; ESME-S035; ESME-S036; ESME-S037; ESME-S053]

[ESME-043: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/42)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-044` — Quiescent or big-bang cutover as a conditional alternative

**Disposition, kind and eligibility.** DOMAIN_SPECIFIC; MIGRATION_ALTERNATIVE; crosswalk-worthy: YES

**Mechanism.** Prepare and validate conversion, establish a quiescent boundary, cut over under explicit recovery/forward-repair conditions and reconcile before reopening use.

**Trigger.** A tolerable outage exists, data can be stabilised and the joint operation burden would otherwise dominate.

**Required inputs and preconditions.** Accepted outage, frozen input boundary, tested conversion, sufficient capacity and clear irreversibility decisions.

**Produced evidence or constraint.** The new system starts from a reconciled state and old writes cannot silently diverge.

**Decision consumer and operative authority.** Operators coordinate cutover with service/data owners and affected consumers; a project team cannot assume all users accept downtime.

**Preservation/observer constraint.** The new system starts from a reconciled state and old writes cannot silently diverge. Preserve accepted domain meaning and service obligations while deliberately changing implementation or supported behaviour; legacy bugs can be relied-on observations that require adjudication.

**Costs and assumption failures.** Concentrated conversion failure can be catastrophic; rehearsals may omit production scale or late data; the review literature is not a controlled comparison. Incremental or continued maintenance may prolong dual support but avoid concentrated transition risk; select by actual interruption and partition conditions.

**Selection, substitution and omission.** Continue maintenance or use incremental displacement where interruption or conversion risk is unacceptable.

**Retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

**Conflicts and alternatives.** ESME-T003: Local repair versus replacement. Choose by unmet obligations, support feasibility and lifecycle cost including transition; age alone has no deciding role. ESME-T007: Coexistence versus quiescent cutover. Use coexistence only when partition and reconciliation costs are tolerable; use quiescence when an accepted stable boundary is credible.

**Linked composition relations.** `ESME-R034`, `ESME-R035`, `ESME-R037`, `ESME-R058`

**Source IDs.** [ESME-S031; ESME-S038; ESME-S053]

[ESME-044: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/43)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-045` — Migration state reconciliation and data authority

**Disposition, kind and eligibility.** ASSUMPTION_SENSITIVE; MIGRATION_RECONCILIATION; crosswalk-worthy: YES

**Mechanism.** Define authority and mappings for each migration phase, compare relevant state and resolve divergence before transferring responsibility.

**Trigger.** Data or service state is copied, transformed or temporarily maintained in more than one place.

**Required inputs and preconditions.** Explicit identities, mapping semantics, write ordering and access to authoritative observations.

**Produced evidence or constraint.** Differences are explained and resolved or explicitly accepted; no competing writer remains accidentally authoritative.

**Decision consumer and operative authority.** Data owners decide meaning and acceptable loss; operators execute and inspect reconciliation.

**Preservation/observer constraint.** Differences are explained and resolved or explicitly accepted; no competing writer remains accidentally authoritative. Preserve accepted domain meaning and service obligations while deliberately changing implementation or supported behaviour; legacy bugs can be relied-on observations that require adjudication.

**Costs and assumption failures.** Counts or checksums do not prove semantic equivalence; concurrent updates and external effects can make exact reconciliation difficult. A single-writer or quiescent design loses some availability or flexibility but can eliminate ambiguity over authority and reduce divergence.

**Selection, substitution and omission.** An immutable read-only export with a simple verified mapping may need only one comparison and no dual-write protocol.

**Retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

**Conflicts and alternatives.** ESME-T007: Coexistence versus quiescent cutover. Use coexistence only when partition and reconciliation costs are tolerable; use quiescence when an accepted stable boundary is credible.

**Linked composition relations.** `ESME-R033`, `ESME-R036`, `ESME-R037`, `ESME-R038`, `ESME-R057`

**Source IDs.** [ESME-S031; ESME-S038; ESME-S053]

[ESME-045: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/44)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-046` — Schema mappings and information-loss analysis

**Disposition, kind and eligibility.** ASSUMPTION_SENSITIVE; SCHEMA_TRANSFORMATION_MODEL; crosswalk-worthy: YES

**Mechanism.** State the mapping and its information-loss/invertibility conditions; preserve enough source information or choose forward repair where an inverse does not exist.

**Trigger.** Schema/data representation changes affect persistent meaning or old-version access.

**Required inputs and preconditions.** A model matching actual schema semantics, constraints, data values and supported transformation operators.

**Produced evidence or constraint.** Queries and converted states meet the declared mapping, or losses and unsupported rewrites block the preservation claim.

**Decision consumer and operative authority.** Database maintainers establish mappings; data owners authorise losses and changed interpretation.

**Preservation/observer constraint.** Queries and converted states meet the declared mapping, or losses and unsupported rewrites block the preservation claim. Preserve accepted domain meaning and service obligations while deliberately changing implementation or supported behaviour; legacy bugs can be relied-on observations that require adjudication.

**Costs and assumption failures.** The inspected PRISM work is a prototype/demo; model-relative guarantees do not establish arbitrary deployed database correctness or economic benefit. A forward-only transition forgoes restoration of the old representation; it is acceptable only with explicit preservation, retained information or a supported recovery decision.

**Selection, substitution and omission.** Use a direct checked migration for a simple bijective mapping; a full workbench is unnecessary.

**Retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

**Conflicts and alternatives.** ESME-T007: Coexistence versus quiescent cutover. Use coexistence only when partition and reconciliation costs are tolerable; use quiescence when an accepted stable boundary is credible.

**Linked composition relations.** `ESME-R033`, `ESME-R037`, `ESME-R038`, `ESME-R057`

**Source IDs.** [ESME-S038; ESME-S053]

[ESME-046: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/45)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-047` — Retire migration scaffolding and duplicate operation

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; MIGRATION_CONTROL_RETIREMENT; crosswalk-worthy: YES

**Mechanism.** Assign exit conditions to transitional paths; verify remaining consumers and recovery needs, then remove or deliberately reclassify the retained mechanism.

**Trigger.** A migration step has transferred its intended obligations and duplicated operation continues.

**Required inputs and preconditions.** Evidence of consumer transition, settled data authority and expiry or replacement of recovery obligations.

**Produced evidence or constraint.** No redundant operational path remains without an explicit purpose and cost owner.

**Decision consumer and operative authority.** Service owners and maintainers authorise retirement after affected consumers have a feasible path.

**Preservation/observer constraint.** No redundant operational path remains without an explicit purpose and cost owner. Preserve accepted domain meaning and service obligations while deliberately changing implementation or supported behaviour; legacy bugs can be relied-on observations that require adjudication.

**Costs and assumption failures.** Premature removal can strand consumers or eliminate recovery; zero duplication is not a universal objective. Retiring the gateway removes old-path fallback and compatibility; do so only after its consumers and recovery obligations end.

**Selection, substitution and omission.** Retain an adapter when a real consumer still requires it; do not remove it solely to satisfy a cleanup schedule.

**Retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R036`, `ESME-R039`, `ESME-R059`

**Source IDs.** [ESME-S031; ESME-S035; ESME-S036; ESME-S037]

[ESME-047: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/46)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-048` — Technical novelty or age decides replacement

**Disposition, kind and eligibility.** REJECTED_OR_DISFAVOURED; AGE_OR_NOVELTY_HEURISTIC; crosswalk-worthy: NO

**Mechanism.** Reject age/novelty as a sufficient criterion; examine viable lifecycle options and transition obligations.

**Trigger.** Adjudicate when a replacement rationale contains no stronger evidence than old or modern.

**Required inputs and preconditions.** Age has no general causal mapping to unacceptable risk or replacement benefit.

**Produced evidence or constraint.** The selected option is justified by actual obligations and costs rather than its technology’s age.

**Decision consumer and operative authority.** No vendor or architectural preference substitutes for service and stakeholder decision authority.

**Preservation/observer constraint.** The selected option is justified by actual obligations and costs rather than its technology’s age. Preserve accepted domain meaning and service obligations while deliberately changing implementation or supported behaviour; legacy bugs can be relied-on observations that require adjudication.

**Costs and assumption failures.** Older dependencies can create real support constraints, but that is evidence about support, not proof from age itself. Omitting this rejected rule gives up a simple but unsupported decision shortcut; actual support, risk and value still need assessment.

**Selection, substitution and omission.** Continue useful supported operation or make a bounded adaptation.

**Retirement.** Include temporary double operation, gateway maintenance, knowledge loss and final retirement in option cost. Remove scaffolding only when its remaining obligations end.

**Conflicts and alternatives.** ESME-T003: Local repair versus replacement. Choose by unmet obligations, support feasibility and lifecycle cost including transition; age alone has no deciding role.

**Linked composition relations.** `ESME-R040`

**Source IDs.** [ESME-S031; ESME-S039; ESME-S040; ESME-S050]

[ESME-048: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/47)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-049` — Bounded technical-debt identification

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; DEBT_IDENTIFICATION; crosswalk-worthy: YES

**Mechanism.** Identify the design/implementation choice, plausible future burden, affected change class and remediation alternative; distinguish debt from ordinary unmet requirements.

**Trigger.** A present choice is expected to impose avoidable future maintenance cost or constrain options.

**Required inputs and preconditions.** A causal hypothesis connecting the choice to future work and a clear boundary of the obligation.

**Produced evidence or constraint.** The debt item identifies what is owed metaphorically, why it matters and under which future conditions.

**Decision consumer and operative authority.** Maintainers identify technical mechanisms; stakeholders determine acceptable trade-offs and who bears later costs.

**Preservation/observer constraint.** The debt item identifies what is owed metaphorically, why it matters and under which future conditions. Preserve current useful behaviour while improving future work unless an intentional change is separately accepted; include costs borne by downstream maintainers.

**Costs and assumption failures.** Debt definitions differ; economic terms may lack observable units; the original experience is not a validated financial model. A narrower debt inventory omits ordinary defects, features and obligations from that metaphor; track them through appropriate decisions instead of forcing financial labels.

**Selection, substitution and omission.** Use an ordinary defect or feature request when that is the actual issue; no debt register is needed for an isolated obvious repair.

**Retirement.** Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

**Conflicts and alternatives.** ESME-T006: Debt reduction versus current value. Prioritise expected consequential burden within a plausible horizon; stop when retirement or changed demand removes prospective benefit.

**Linked composition relations.** `ESME-R041`, `ESME-R045`

**Source IDs.** [ESME-S019; ESME-S032; ESME-S042; ESME-S048; ESME-S049]

[ESME-049: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/48)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-050` — Contingent lifecycle economics

**Disposition, kind and eligibility.** ASSUMPTION_SENSITIVE; LIFECYCLE_ECONOMIC_MODEL; crosswalk-worthy: YES

**Mechanism.** Compare remediation cost with contingent future burdens and benefits over a stated horizon, testing sensitivity to change frequency, retirement and uncertainty.

**Trigger.** A nontrivial preventive investment competes with current delivery or another maintenance option.

**Required inputs and preconditions.** Meaningful cost units, a plausible horizon and honest uncertainty rather than fabricated precision.

**Produced evidence or constraint.** The preferred option remains justified under stated scenarios or is marked undecided when rankings reverse.

**Decision consumer and operative authority.** Stakeholders bearing present and future costs choose trade-offs; analysts expose assumptions rather than declare an automatic optimum.

**Preservation/observer constraint.** The preferred option remains justified under stated scenarios or is marked undecided when rankings reverse. Preserve current useful behaviour while improving future work unless an intentional change is separately accepted; include costs borne by downstream maintainers.

**Costs and assumption failures.** Self-reported wasted time does not prove that a particular repayment would recover that time; future objectives can change. Qualitative scenarios lose numerical comparability but avoid false precision; use richer estimates when costs, horizon and uncertainty can be defended.

**Selection, substitution and omission.** For a cheap urgent defect repair, direct consequence and effort comparison may be enough.

**Retirement.** Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

**Conflicts and alternatives.** ESME-T006: Debt reduction versus current value. Prioritise expected consequential burden within a plausible horizon; stop when retirement or changed demand removes prospective benefit.

**Linked composition relations.** `ESME-R005`, `ESME-R022`, `ESME-R041`, `ESME-R042`, `ESME-R043`, `ESME-R044`, `ESME-R045`, `ESME-R059`

**Source IDs.** [ESME-S019; ESME-S032; ESME-S048; ESME-S049]

[ESME-050: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/49)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-051` — Debt prioritisation across affected stakeholders

**Disposition, kind and eligibility.** CONTEXT_DEPENDENT; PRIORITISATION_AND_NEGOTIATION; crosswalk-worthy: YES

**Mechanism.** Expose who pays and who benefits, compare urgent user needs with preventive work and revisit priorities when evidence or objectives change.

**Trigger.** Multiple maintenance needs compete for constrained effort, particularly across ownership or funding boundaries.

**Required inputs and preconditions.** Enough information about affected stakeholders, severity, recurrence and available capacity.

**Produced evidence or constraint.** The selected work and deferred obligations have reasons understandable to those bearing their consequences.

**Decision consumer and operative authority.** Authorised budget/service owners negotiate priorities; technical labels do not compel others to fund work.

**Preservation/observer constraint.** The selected work and deferred obligations have reasons understandable to those bearing their consequences. Preserve current useful behaviour while improving future work unless an intentional change is separately accepted; include costs borne by downstream maintainers.

**Costs and assumption failures.** Negotiation can privilege visible or powerful stakeholders; numeric scoring can disguise unsupported weights and gaming. Local prioritisation may miss costs imposed on other teams or future maintainers; widen participation when burdens cross the local boundary.

**Selection, substitution and omission.** A maintainer can resolve a small local issue directly when no meaningful trade-off or external cost exists.

**Retirement.** Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

**Conflicts and alternatives.** ESME-T006: Debt reduction versus current value. Prioritise expected consequential burden within a plausible horizon; stop when retirement or changed demand removes prospective benefit.

**Linked composition relations.** `ESME-R005`, `ESME-R041`, `ESME-R042`

**Source IDs.** [ESME-S032; ESME-S043; ESME-S048; ESME-S049]

[ESME-051: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/50)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-052` — Bounded remediation with payoff reassessment

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; BOUNDED_REMEDIATION_AND_FEEDBACK; crosswalk-worthy: YES

**Mechanism.** Select a bounded intervention, observe whether the targeted burden changes and stop, revise or retire the effort when benefit is absent or the system nears retirement.

**Trigger.** A debt or maintainability intervention has uncertain payoff and can be evaluated incrementally.

**Required inputs and preconditions.** A measurable task-relevant burden, comparison with baseline and awareness of concurrent changes.

**Produced evidence or constraint.** Continuation depends on observed or still-credible benefit, not on clearing an arbitrary register.

**Decision consumer and operative authority.** Maintainers report outcomes; decision makers can stop or redirect investment without treating incomplete cleanup as failure.

**Preservation/observer constraint.** Continuation depends on observed or still-credible benefit, not on clearing an arbitrary register. Preserve current useful behaviour while improving future work unless an intentional change is separately accepted; include costs borne by downstream maintainers.

**Costs and assumption failures.** Delayed benefits and confounding can make early evaluation misleading; stopping too early may prevent necessary foundational work. Bounded remediation leaves other problems intact; this is justified when the urgent objective or expected horizon does not support further work.

**Selection, substitution and omission.** A small targeted fix or no action may dominate comprehensive re-engineering.

**Retirement.** Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

**Conflicts and alternatives.** ESME-T006: Debt reduction versus current value. Prioritise expected consequential burden within a plausible horizon; stop when retirement or changed demand removes prospective benefit.

**Linked composition relations.** `ESME-R022`, `ESME-R042`, `ESME-R043`, `ESME-R044`, `ESME-R045`, `ESME-R059`

**Source IDs.** [ESME-S019; ESME-S020; ESME-S022; ESME-S032; ESME-S048; ESME-S049]

[ESME-052: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/51)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-053` — Maintainability measures as validated proxies

**Disposition, kind and eligibility.** USEFUL_BUT_EASILY_GAMED; MEASUREMENT_PROXY; crosswalk-worthy: YES

**Mechanism.** Use a measure only with a task-relevant interpretation, examine disagreements with observed work and avoid rewards that make proxy improvement the objective.

**Trigger.** A metric informs prioritisation, prediction, comparison or acceptance of maintenance work.

**Required inputs and preconditions.** Stable definitions, a relevant comparison and evidence about measurement error and confounding.

**Produced evidence or constraint.** Metric movement is interpreted alongside actual task outcomes and contradictory evidence.

**Decision consumer and operative authority.** Analysts explain the proxy; maintainers and decision makers judge whether it represents the outcome they need.

**Preservation/observer constraint.** Metric movement is interpreted alongside actual task outcomes and contradictory evidence. Preserve current useful behaviour while improving future work unless an intentional change is separately accepted; include costs borne by downstream maintainers.

**Costs and assumption failures.** Total and average complexity can diverge; code metrics are not human comprehension; self-reported debt time is not automatically recoverable savings. A smaller set of task-relevant observations loses easy portfolio aggregation; aggregation is not valuable when the proxy is unvalidated or gamed.

**Selection, substitution and omission.** Direct task evidence or a short qualitative comparison can dominate an elaborate index.

**Retirement.** Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

**Conflicts and alternatives.** ESME-T002: Familiarity versus simplification. Prefer restructuring when a plausible recurrent task benefit exceeds relearning, review and regression cost; prefer familiarity when the system is stable or retiring.

**Linked composition relations.** `ESME-R022`, `ESME-R044`

**Source IDs.** [ESME-S022; ESME-S032; ESME-S048; ESME-S060]

[ESME-053: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/52)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-054` — Mandatory comprehensive cleanup or zero debt

**Disposition, kind and eligibility.** REJECTED_OR_DISFAVOURED; UNIVERSAL_CLEANUP_REQUIREMENT; crosswalk-worthy: NO

**Mechanism.** Reject zero debt as a universal objective; prioritise justified interventions and permit deliberate deferral.

**Trigger.** Adjudicate when cleanup completeness is proposed as an unconditional release or maturity criterion.

**Required inputs and preconditions.** No evidence establishes a universal economic optimum at zero debt.

**Produced evidence or constraint.** Deferred items can have justified dispositions rather than being counted as automatic failure.

**Decision consumer and operative authority.** Decision makers retain authority to accept trade-offs; maintainers cannot infer unlimited cleanup funding from the debt label.

**Preservation/observer constraint.** Deferred items can have justified dispositions rather than being counted as automatic failure. Preserve current useful behaviour while improving future work unless an intentional change is separately accepted; include costs borne by downstream maintainers.

**Costs and assumption failures.** Some debt carries unacceptable risks, but that supports urgent targeted action rather than a universal total-removal rule. Omitting the rejected universal policy has no established inherent loss; some locally justified debt can still warrant removal.

**Selection, substitution and omission.** Fix the consequential burden, defer harmless issues or leave a stable useful system unchanged.

**Retirement.** Consider probability of future changes, remaining life, opportunity cost and uncertain payoff. A zero-debt state is not a universal objective; retirement can end prospective interest.

**Conflicts and alternatives.** ESME-T006: Debt reduction versus current value. Prioritise expected consequential burden within a plausible horizon; stop when retirement or changed demand removes prospective benefit.

**Linked composition relations.** `ESME-R045`

**Source IDs.** [ESME-S019; ESME-S032; ESME-S040; ESME-S048; ESME-S049]

[ESME-054: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/53)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-055` — Maintainership capacity and continuity

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; HUMAN_CONTINUITY_MECHANISM; crosswalk-worthy: YES

**Mechanism.** Identify consequential ownership/capacity dependencies, support sustainable workload and arrange a feasible handoff or alternative when continuity is at risk.

**Trigger.** Key-person departure, concentrated knowledge, burnout, funding loss or a critical unmaintained dependency.

**Required inputs and preconditions.** Actual willingness, competence, access and resources; naming an owner does not create capacity.

**Produced evidence or constraint.** Required maintenance responsibilities have capable willing actors or an explicit alternative/retirement decision.

**Decision consumer and operative authority.** Maintainers and sponsors negotiate responsibilities voluntarily; downstream organisations decide how to fund or replace unsupported dependencies.

**Preservation/observer constraint.** Required maintenance responsibilities have capable willing actors or an explicit alternative/retirement decision. Preserve accepted service/data/support obligations during handoff or retirement, not indefinite operation or every historical implementation detail.

**Costs and assumption failures.** Commit counts and popularity poorly represent capacity; forced redundancy can overload volunteers and dilute expertise. A direct arrangement may not survive absence or be visible to consumers; retain an escalation and support route that reflects willingness and capacity.

**Selection, substitution and omission.** A stable finished component with no active obligations need not recruit maintainers merely to appear alive.

**Retirement.** Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

**Conflicts and alternatives.** ESME-T010: Continuity versus responsible ending. Retain service only for justified obligations with feasible capacity; archives can meet historical needs without a running service.

**Linked composition relations.** `ESME-R003`, `ESME-R008`, `ESME-R046`, `ESME-R048`, `ESME-R059`

**Source IDs.** [ESME-S040; ESME-S043; ESME-S047]

[ESME-055: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/54)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-056` — Handoff and onboarding through demonstrated capability

**Disposition, kind and eligibility.** CONTEXT_DEPENDENT; KNOWLEDGE_TRANSFER_AND_CAPABILITY_TEST; crosswalk-worthy: YES

**Mechanism.** Use representative tasks, access checks and dialogue to test the receiving maintainer’s ability; preserve rationale and unresolved questions that the task exposes.

**Trigger.** Ownership transfer, new maintainer onboarding or impending loss of specialised knowledge.

**Required inputs and preconditions.** A willing receiving maintainer, operational access and time to learn; a quiz alone is not enough.

**Produced evidence or constraint.** The receiver can complete a representative task or the handoff plan changes to address demonstrated gaps.

**Decision consumer and operative authority.** Delivering and receiving maintainers exchange knowledge; managers provide time and authority rather than infer competence from attendance.

**Preservation/observer constraint.** The receiver can complete a representative task or the handoff plan changes to address demonstrated gaps. Preserve accepted service/data/support obligations during handoff or retirement, not indefinite operation or every historical implementation detail.

**Costs and assumption failures.** A successful rehearsal does not prove broad competence; task selection can conceal rare but important failure modes. A small practical task samples only part of capability; broaden demonstrations when the new responsibility spans materially different operations.

**Selection, substitution and omission.** Pair on one meaningful change or diagnosis instead of producing a comprehensive handover manual.

**Retirement.** Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

**Conflicts and alternatives.** ESME-T010: Continuity versus responsible ending. Retain service only for justified obligations with feasible capacity; archives can meet historical needs without a running service.

**Linked composition relations.** `ESME-R003`, `ESME-R046`, `ESME-R060`

**Source IDs.** [ESME-S014; ESME-S015; ESME-S043; ESME-S047]

[ESME-056: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/55)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-057` — Deprecation communication with actionable transition

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; DEPRECATION_INTERACTION; crosswalk-worthy: YES

**Mechanism.** Explain the affected behaviour, support state, replacement or lack of replacement, and timing/exception conditions; retain support as promised during transition.

**Trigger.** A supported interface, dependency or behaviour is discouraged, changed or scheduled for removal.

**Required inputs and preconditions.** Known support commitments, reachable consumers where possible and a feasible transition or explicit residual risk.

**Produced evidence or constraint.** Consumers have actionable information, and removal conditions match the stated commitment rather than a silent version change.

**Decision consumer and operative authority.** Producers communicate policy; affected consumers choose migration; designated governance can authorise documented exceptions.

**Preservation/observer constraint.** Consumers have actionable information, and removal conditions match the stated commitment rather than a silent version change. Preserve accepted service/data/support obligations during handoff or retirement, not indefinite operation or every historical implementation detail.

**Costs and assumption failures.** A policy is not proof of adoption or successful migration; fixed universal time windows ignore differing risk and consumer constraints. A tailored transition loses scheduling uniformity; it should still provide actionable notice and respect applicable project policy and consumer constraints.

**Selection, substitution and omission.** For a private coordinated use, direct communication can suffice; indefinite soft deprecation may be appropriate when removal is not justified.

**Retirement.** Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R015`, `ESME-R030`, `ESME-R047`

**Source IDs.** [ESME-S043; ESME-S045]

[ESME-057: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/56)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-058` — Dependency viability and response alternatives

**Disposition, kind and eligibility.** CONTEXT_DEPENDENT; ECOSYSTEM_RESPONSE_SELECTION; crosswalk-worthy: YES

**Mechanism.** Assess actual need and viability, then compare continued use, support contribution, isolation, fork or replacement with their ownership and update costs.

**Trigger.** A dependency loses maintainers, support, compatibility or timely response needed by the consuming system.

**Required inputs and preconditions.** Understanding of actual use, licences/access, transitive dependencies and capacity to maintain an alternative.

**Produced evidence or constraint.** The selected response has a capable owner and evidence that it addresses the relevant continuity risk.

**Decision consumer and operative authority.** Downstream maintainers and sponsors choose their response; they cannot compel upstream labour or assume a fork will attract support.

**Preservation/observer constraint.** The selected response has a capable owner and evidence that it addresses the relevant continuity risk. Preserve accepted service/data/support obligations during handoff or retirement, not indefinite operation or every historical implementation detail.

**Costs and assumption failures.** Dependency graphs overstate some runtime exposure; interviews are not comparative success rates; a fork transfers rather than eliminates maintenance work. Waiting or contributing retains upstream uncertainty; replacement or forking also creates new costs and needs actual maintainer capacity.

**Selection, substitution and omission.** Continue using a stable adequate dependency when no unmet obligation warrants change, while retaining appropriate observation.

**Retirement.** Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

**Conflicts and alternatives.** ESME-T010: Continuity versus responsible ending. Retain service only for justified obligations with feasible capacity; archives can meet historical needs without a running service.

**Linked composition relations.** `ESME-R015`, `ESME-R048`

**Source IDs.** [ESME-S040; ESME-S041; ESME-S043]

[ESME-058: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/57)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-059` — Archival identity without a false execution guarantee

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; ARCHIVAL_PRESERVATION; crosswalk-worthy: YES

**Mechanism.** Retain the artefacts and identity needed by named historical, legal or reconstruction consumers, with limitations on buildability and execution explicit.

**Trigger.** Retirement, handoff, publication or dependency disappearance creates a future need for source or history.

**Required inputs and preconditions.** Permission to retain/distribute material, adequate identifiers and a retention purpose; private data and credentials require separate treatment.

**Produced evidence or constraint.** The archived version is identifiable and accessible within the stated retention conditions, without pretending it necessarily runs.

**Decision consumer and operative authority.** Custodians preserve artefacts; future maintainers decide whether reconstruction is feasible and authorised.

**Preservation/observer constraint.** The archived version is identifiable and accessible within the stated retention conditions, without pretending it necessarily runs. Preserve accepted service/data/support obligations during handoff or retirement, not indefinite operation or every historical implementation detail.

**Costs and assumption failures.** Software Heritage explicitly separates a comprehensive corpus from curation and buildability; environments and external services may still disappear. A smaller archive may not support future reconstruction; record what is preserved and do not promise buildability or operation beyond it.

**Selection, substitution and omission.** Use an existing trustworthy archive and identifiers rather than maintaining a duplicate live service.

**Retirement.** Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

**Conflicts and alternatives.** ESME-T010: Continuity versus responsible ending. Retain service only for justified obligations with feasible capacity; archives can meet historical needs without a running service.

**Linked composition relations.** `ESME-R049`

**Source IDs.** [ESME-S030; ESME-S046; ESME-S054]

[ESME-059: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/58)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-060` — Responsible service retirement and residual obligations

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; RETIREMENT_DECISION_AND_OPERATION; crosswalk-worthy: YES

**Mechanism.** Identify remaining consumers and obligations, transfer/export or explicitly end them, stop unnecessary operation and retain only justified historical material.

**Trigger.** Continued operation no longer serves an accepted objective or cannot be sustainably supported.

**Required inputs and preconditions.** Authority to end service, feasible consumer/data transition and known residual retention/access obligations.

**Produced evidence or constraint.** No unacknowledged live dependency remains, residual obligations have responsible actors and unnecessary operation has ceased.

**Decision consumer and operative authority.** Service/data owners authorise retirement; operators execute shutdown; affected consumers participate where their obligations require it.

**Preservation/observer constraint.** No unacknowledged live dependency remains, residual obligations have responsible actors and unnecessary operation has ceased. Preserve accepted service/data/support obligations during handoff or retirement, not indefinite operation or every historical implementation detail.

**Costs and assumption failures.** Disposal scope and policy examples do not establish a universal retirement procedure; external obligations require target-specific evidence beyond this study. Shutting down removes immediate service access; resolve continuing consumer needs and retain justified evidence without equating archival custody with live support.

**Selection, substitution and omission.** Keep an adequate low-cost system unchanged when retirement would cause more harm; retain an archive rather than a running service when history is the only need.

**Retirement.** Fund sustainable capacity or choose a feasible alternative. Retire operational systems and artefacts when their justified consumers/obligations end, preserving only required historical custody.

**Conflicts and alternatives.** ESME-T010: Continuity versus responsible ending. Retain service only for justified obligations with feasible capacity; archives can meet historical needs without a running service.

**Linked composition relations.** `ESME-R004`, `ESME-R034`, `ESME-R039`, `ESME-R047`, `ESME-R049`

**Source IDs.** [ESME-S001; ESME-S002; ESME-S040; ESME-S043; ESME-S045; ESME-S054]

[ESME-060: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/59)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-061` — Generated repairs remain candidate interventions

**Disposition, kind and eligibility.** STRONGLY_RETAINED; AUTOMATED_REPAIR_ACCEPTANCE_BOUNDARY; crosswalk-worthy: YES

**Mechanism.** Treat generated output as a proposed intervention; check the actual patch against independent intent and preservation obligations before acceptance.

**Trigger.** An automatic repair tool or LLM generates a maintenance change.

**Required inputs and preconditions.** Candidate identity, credible oracles, impact evidence and an authorised acceptance consumer.

**Produced evidence or constraint.** The accepted patch has evidence beyond its production and a clear disposition for unresolved failures.

**Decision consumer and operative authority.** Generators propose; maintainers or explicitly delegated policy accept within scope. Generator confidence does not create authority.

**Preservation/observer constraint.** The accepted patch has evidence beyond its production and a clear disposition for unresolved failures. Preserve actual consumer obligations, not merely benchmark assertions or similarity to a gold patch. Learned behaviour may require statistical rather than deterministic comparisons.

**Costs and assumption failures.** Human review can also fail, especially for deceptive patches; a universal extra manual review is not itself proved optimal for every narrow transformation. A bounded generator may find fewer candidate repairs; independent validation and authorisation remain necessary for the consequences it does propose.

**Selection, substitution and omission.** A narrow verified transformation or a simple human fix may be cheaper; automation is optional.

**Retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Conflicts and alternatives.** ESME-T004: Automated transformation versus review burden. Evaluate correct outcomes and full cost for the task and tool version. Strong narrow transformations can need less manual review; weak oracles demand more independent evidence.

**Linked composition relations.** `ESME-R023`, `ESME-R050`, `ESME-R052`, `ESME-R056`

**Source IDs.** [ESME-S024; ESME-S026; ESME-S027; ESME-S052; ESME-S055; ESME-S065; ESME-S067]

[ESME-061: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/60)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-062` — Benchmark and evaluation provenance

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; EVALUATION_PROVENANCE; crosswalk-worthy: YES

**Mechanism.** Record task origin, training/exposure risks, evaluation version, test/oracle limits, exclusions and shared datasets; compare like outcomes with credible baselines.

**Trigger.** A repair or agent capability claim informs adoption, comparison or a maintenance decision.

**Required inputs and preconditions.** Enough disclosed benchmark and tool information to interpret the measure and its denominator.

**Produced evidence or constraint.** The capability claim identifies its actual outcome, denominator, uncertainty and non-independent evidence.

**Decision consumer and operative authority.** Researchers and tool evaluators disclose evidence; downstream adopters test transfer to their own obligations.

**Preservation/observer constraint.** The capability claim identifies its actual outcome, denominator, uncertainty and non-independent evidence. Preserve actual consumer obligations, not merely benchmark assertions or similarity to a gold patch. Learned behaviour may require statistical rather than deterministic comparisons.

**Costs and assumption failures.** OpenAI’s selected difficult subset is not the entire benchmark; gold-patch difference is not automatically error; contamination tests themselves have limits. A smaller local evaluation loses broad comparability; it can be more relevant to local work if leakage, selection and held-out obligations are explicit.

**Selection, substitution and omission.** Use a small transparent local task evaluation when a leaderboard cannot answer the decision question.

**Retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R051`

**Source IDs.** [ESME-S024; ESME-S026; ESME-S027; ESME-S057; ESME-S067]

[ESME-062: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/61)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-063` — End-to-end automation cost and outcome assessment

**Disposition, kind and eligibility.** CONTEXT_DEPENDENT; AUTOMATION_ECONOMIC_EVALUATION; crosswalk-worthy: YES

**Mechanism.** Compare end-to-end outcomes and costs against a credible human/tool/no-change baseline, preserving setting, selection and uncertainty.

**Trigger.** A maintenance automation is selected, expanded or justified economically.

**Required inputs and preconditions.** Representative tasks, defined outcomes, appropriate baseline and accounting for review and failed attempts.

**Produced evidence or constraint.** The chosen automation has a bounded justification, or remains unproven when comparisons are inadequate.

**Decision consumer and operative authority.** Maintainers report actual work; decision makers accept costs and risks; survey preference is not causal productivity evidence.

**Preservation/observer constraint.** The chosen automation has a bounded justification, or remains unproven when comparisons are inadequate. Preserve actual consumer obligations, not merely benchmark assertions or similarity to a gold patch. Learned behaviour may require statistical rather than deterministic comparisons.

**Costs and assumption failures.** The 2025 METR result is time- and population-specific; 2026 follow-up selection undermines a clean current causal estimate. Quantisation costs are hardware-specific. A cheap bounded trial leaves some long-term effects unmeasured; widen observation when review, regression or operational costs plausibly outweigh apparent speed.

**Selection, substitution and omission.** For a cheap reversible task, direct bounded experience may suffice; do not run a research programme for every suggestion.

**Retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Conflicts and alternatives.** ESME-T004: Automated transformation versus review burden. Evaluate correct outcomes and full cost for the task and tool version. Strong narrow transformations can need less manual review; weak oracles demand more independent evidence.

**Linked composition relations.** `ESME-R051`, `ESME-R052`

**Source IDs.** [ESME-S025; ESME-S033; ESME-S034; ESME-S052; ESME-S057]

[ESME-063: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/62)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-064` — Acceptance authority distinct from generation capability

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; AUTHORITY_AND_REVIEW_BOUNDARY; crosswalk-worthy: YES

**Mechanism.** Identify who may accept and deploy which changes, what evidence they need and when an automatic path must defer or stop.

**Trigger.** Automated or delegated changes can alter shared artefacts or external behaviour.

**Required inputs and preconditions.** Legitimate authority, actual action capability and explicit bounds for any delegation.

**Produced evidence or constraint.** Acceptance and deployment can be traced to an authorised decision within its stated scope.

**Decision consumer and operative authority.** Authorised maintainers or policy holders accept changes; generators cannot enlarge their own mandate from a successful test.

**Preservation/observer constraint.** Acceptance and deployment can be traced to an authorised decision within its stated scope. Preserve actual consumer obligations, not merely benchmark assertions or similarity to a gold patch. Learned behaviour may require statistical rather than deterministic comparisons.

**Costs and assumption failures.** Human approval can be ceremonial or harmed by deceptive plausible patches; role separation alone does not improve correctness. Combining logical roles loses interpersonal challenge; it can be adequate for bounded tasks when independent evidence and explicit authority remain effective.

**Selection, substitution and omission.** A sole authorised maintainer may generate, inspect and accept a small change without separate roles; logical distinctions do not require separate people.

**Retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Conflicts and alternatives.** ESME-T004: Automated transformation versus review burden. Evaluate correct outcomes and full cost for the task and tool version. Strong narrow transformations can need less manual review; weak oracles demand more independent evidence.

**Linked composition relations.** `ESME-R046`, `ESME-R050`, `ESME-R052`, `ESME-R054`, `ESME-R055`

**Source IDs.** [ESME-S002; ESME-S024; ESME-S052; ESME-S055; ESME-S067]

[ESME-064: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/63)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-065` — Learned-system data and feedback evolution

**Disposition, kind and eligibility.** DOMAIN_SPECIFIC; LEARNED_SYSTEM_EVOLUTION; crosswalk-worthy: YES

**Mechanism.** Include data/model/configuration versions and relevant feedback relationships in the change and preservation boundary; use task-appropriate statistical evidence.

**Trigger.** Maintained behaviour materially depends on learned components or changing data distributions.

**Required inputs and preconditions.** Data provenance/access, meaningful outcome measures and an understanding of the observation and deployment environment.

**Produced evidence or constraint.** The change account identifies which artefacts and distributions changed and which conclusions remain uncertain.

**Decision consumer and operative authority.** Model/data maintainers and domain owners share responsibility; a model score does not authorise a changed societal or service objective.

**Preservation/observer constraint.** The change account identifies which artefacts and distributions changed and which conclusions remain uncertain. Preserve actual consumer obligations, not merely benchmark assertions or similarity to a gold patch. Learned behaviour may require statistical rather than deterministic comparisons.

**Costs and assumption failures.** The Sculley paper is a conceptual industrial account, not controlled proof of every recommended mitigation; deterministic equivalence does not transfer automatically. Omitting ML-specific machinery is appropriate without learned dependencies; otherwise it can miss data drift, feedback and distribution-sensitive failures.

**Selection, substitution and omission.** For deterministic code without learned dependencies, ordinary change evidence applies; no ML-specific machinery is needed.

**Retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R053`

**Source IDs.** [ESME-S042; ESME-S051; ESME-S057]

[ESME-065: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/64)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-066` — Executable-policy and non-code artefact evolution

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; NON_CODE_ARTEFACT_MAINTENANCE; crosswalk-worthy: YES

**Mechanism.** Include consequential non-code artefacts in identity, impact and validation; determine whether an artefact is actually consumed or enforced before crediting its effect.

**Trigger.** Configuration, policy, schema, build definitions or operational documentation changes actual decisions or execution.

**Required inputs and preconditions.** Knowledge of the interpreter/consumer, version semantics and relevant effect or enforcement point.

**Produced evidence or constraint.** The changed artefact reaches its consumer and has the intended observable consequence, or remains explicitly unverified.

**Decision consumer and operative authority.** Artefact owners and operational consumers establish intended effects; a policy file’s author does not automatically control runtime enforcement.

**Preservation/observer constraint.** The changed artefact reaches its consumer and has the intended observable consequence, or remains explicitly unverified. Preserve actual consumer obligations, not merely benchmark assertions or similarity to a gold patch. Learned behaviour may require statistical rather than deterministic comparisons.

**Costs and assumption failures.** Low commit share is not low labour cost; repository presence is not enforcement; the 2026 policy study’s selected sample does not justify universal adoption. Focused consumer tracing misses inactive or distant artefacts; expand when changes can alter enforcement, builds or other non-code consumers.

**Selection, substitution and omission.** Ignore inert or irrelevant files for this change; a focused consumer check may replace a large repository-wide analysis.

**Retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R053`

**Source IDs.** [ESME-S002; ESME-S030; ESME-S042; ESME-S056]

[ESME-066: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/65)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-067` — Bounded revision of maintenance methods

**Disposition, kind and eligibility.** CONTEXT_DEPENDENT; METHOD_REVISION_BOUNDARY; crosswalk-worthy: YES

**Mechanism.** Revise tools, thresholds or inquiry methods through an authorised change with a stated failure/benefit hypothesis, preserving prior obligations unless separately changed.

**Trigger.** Repeated false positives, missed failures, excessive cost or changed technology undermines the current method.

**Required inputs and preconditions.** Evidence of the method’s limits, an authorised revision boundary and a comparison not defined solely by the proposed successor.

**Produced evidence or constraint.** The revision has a bounded rationale and evidence, and previous obligations are not silently rewritten to make it pass.

**Decision consumer and operative authority.** Method owners and affected consumers approve changes; the method or agent cannot authorise its own broader powers.

**Preservation/observer constraint.** The revision has a bounded rationale and evidence, and previous obligations are not silently rewritten to make it pass. Preserve actual consumer obligations, not merely benchmark assertions or similarity to a gold patch. Learned behaviour may require statistical rather than deterministic comparisons.

**Costs and assumption failures.** This is analytical synthesis from documented method evolution, not an established universal self-revising maintenance architecture. Keeping the existing method may leave emerging failures unaddressed; revise only when actual evidence or changed obligations supplies a reason.

**Selection, substitution and omission.** Keep a working method unchanged or remove an unused control; do not add reflexive governance without a demonstrated consumer.

**Retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Conflicts and alternatives.** ESME-T011: Learning versus stable acceptance rules. Changes to method need external authority and evidence tied to a real failure or cost; unchanged methods and control removal remain options.

**Linked composition relations.** `ESME-R054`, `ESME-R060`

**Source IDs.** [ESME-S006; ESME-S025; ESME-S029; ESME-S033; ESME-S049; ESME-S058; ESME-S063]

[ESME-067: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/66)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-068` — Human-only maintenance is universally superior

**Disposition, kind and eligibility.** REJECTED_OR_DISFAVOURED; UNIVERSAL_AUTOMATION_COMPARISON; crosswalk-worthy: NO

**Mechanism.** Reject the universal comparison; evaluate bounded automation by correct outcomes and complete costs.

**Trigger.** Adjudicate when a negative experiment is used to forbid all maintenance automation.

**Required inputs and preconditions.** No universal comparison across all maintenance tasks and tools exists in the inspected evidence.

**Produced evidence or constraint.** The conclusion preserves both observed harms and supported benefits within their populations.

**Decision consumer and operative authority.** Maintainers and decision makers select tools; neither vendor optimism nor a single negative study dictates every setting.

**Preservation/observer constraint.** The conclusion preserves both observed harms and supported benefits within their populations. Preserve actual consumer obligations, not merely benchmark assertions or similarity to a gold patch. Learned behaviour may require statistical rather than deterministic comparisons.

**Costs and assumption failures.** Correct suggestions helped in the inspected controlled study; SapFix demonstrates bounded deployment; neither proves universal benefit either. Omitting the rejected rule allows useful bounded assistance but does not remove the need to assess quality, full cost and acceptance authority.

**Selection, substitution and omission.** Use whichever simple human/tool combination is supported for the actual task, including no automation.

**Retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Conflicts and alternatives.** ESME-T004: Automated transformation versus review burden. Evaluate correct outcomes and full cost for the task and tool version. Strong narrow transformations can need less manual review; weak oracles demand more independent evidence.

**Linked composition relations.** `ESME-R052`

**Source IDs.** [ESME-S025; ESME-S033; ESME-S034; ESME-S052; ESME-S055; ESME-S067]

[ESME-068: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/67)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-069` — Reliable unattended repository-scale maintenance as a general capability

**Disposition, kind and eligibility.** UNRESOLVED; GENERAL_CAPABILITY_CLAIM; crosswalk-worthy: NO

**Mechanism.** Withhold the general capability claim; distinguish bounded demonstrated tasks from open obligations in intent, long-term regression, review, authority and deployment.

**Trigger.** A general unattended-maintenance claim is used to remove oversight or transfer responsibility.

**Required inputs and preconditions.** Representative unseen tasks, reliable independent oracles, end-to-end outcomes, long-term follow-up and legitimate operational authority would be needed.

**Produced evidence or constraint.** The packet exports an unresolved claim, not an unconditional audit obligation or a declaration of impossibility.

**Decision consumer and operative authority.** Tool evaluators establish evidence; service/repository owners decide permissible delegation; the claimed capability does not create authority.

**Preservation/observer constraint.** The packet exports an unresolved claim, not an unconditional audit obligation or a declaration of impossibility. Preserve actual consumer obligations, not merely benchmark assertions or similarity to a gold patch. Learned behaviour may require statistical rather than deterministic comparisons.

**Costs and assumption failures.** Leakage, weak oracles, selected populations and narrow deployments leave major transfer gaps. Rapid tool change also prevents treating old adverse evidence as a permanent limit. Withholding this unresolved promise limits unattended scope; it avoids exporting a guarantee that representative long-term evidence has not established.

**Selection, substitution and omission.** Use bounded automation with explicit constraints, or an ordinary authorised maintainer when evidence is insufficient.

**Retirement.** Count review, failed attempts, comprehension, energy and delayed regression costs. Select or discontinue automation by supported task-specific outcomes, not generation speed or popularity.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R051`

**Source IDs.** [ESME-S024; ESME-S025; ESME-S026; ESME-S027; ESME-S033; ESME-S052; ESME-S055; ESME-S057; ESME-S065; ESME-S067]

[ESME-069: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/68)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-070` — Golden-master preservation as a separate mechanism

**Disposition, kind and eligibility.** DUPLICATE_CANDIDATE; ALIAS_OF_CHARACTERISATION; crosswalk-worthy: NO

**Mechanism.** Link to ESME-030; apply its provisional-oracle and consumer conditions rather than create a second obligation.

**Trigger.** The phrase is used for recording current outputs to detect differences.

**Required inputs and preconditions.** The claimed mechanism has the same trigger and provisional behaviour evidence as ESME-030.

**Produced evidence or constraint.** One mechanism has both labels and one set of obligations; the historical candidate ID remains visible.

**Decision consumer and operative authority.** The same maintainers and domain consumers adjudicate snapshot differences.

**Preservation/observer constraint.** One mechanism has both labels and one set of obligations; the historical candidate ID remains visible. Observers include functional outputs, exceptions, side effects, performance and downstream mixed-version interactions where supported.

**Costs and assumption failures.** Not every snapshot test is a golden master and some encode explicit specifications; those uses must be classified by mechanism, not brand. Merging this duplicate into characterisation loses no distinct mechanism; preserve terminology where a genuine consumer uses it.

**Selection, substitution and omission.** Use the existing characterisation mechanism; omit duplicate records and tooling in later integration.

**Retirement.** Compare analysis, execution, diagnosis, validation and delayed-feedback costs. Remove stale checks only after examining the obligation they protected; retest-all is often cheapest for small suites.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R024`

**Source IDs.** [ESME-S051; ESME-S059]

[ESME-070: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/69)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-071` — A formal change board for every change

**Disposition, kind and eligibility.** CEREMONY_NOT_GENERAL_PROPERTY; UNIVERSALISED_GOVERNANCE_RITUAL; crosswalk-worthy: NO

**Mechanism.** Strip the mandatory ritual while preserving appropriate authorisation, consultation and evidence; use a fuller forum only when conflicts or obligations require it.

**Trigger.** Adjudicate when the presence of a board is treated as the maintenance property itself.

**Required inputs and preconditions.** A real unresolved cross-party decision or external requirement is needed to justify the fuller form.

**Produced evidence or constraint.** The decision is adequately authorised and informed whether or not a meeting occurs.

**Decision consumer and operative authority.** Existing legitimate decision authority remains; removal of ceremony does not permit unauthorised changes.

**Preservation/observer constraint.** The decision is adequately authorised and informed whether or not a meeting occurs. Separate the observations that must differ from those that must survive. Current obligation holders, including downstream users where relevant, determine what is accepted rather than copying old tests unquestioningly.

**Costs and assumption failures.** The sources support controlled management, not this universal caricature. Some regulated or multi-owner contexts genuinely require formal review. Removing the universal board loses a shared forum; use one where conflicting authority, coordination or applicable obligations cannot be satisfied more simply.

**Selection, substitution and omission.** A direct authorised maintainer decision can suffice for a bounded change.

**Retirement.** Compare change with continued useful operation and retirement. End a classification or approval artefact when no consumer uses its distinction, while preserving any actual authorisation requirement.

**Conflicts and alternatives.** No direct tension entry is asserted for this candidate. Its stated trigger, cheaper alternative and applicability limits still constrain its use.

**Linked composition relations.** `ESME-R061`

**Source IDs.** [ESME-S002; ESME-S005; ESME-S007; ESME-S039]

[ESME-071: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/70)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-072` — Evidence-to-action binding and invalidation

**Disposition, kind and eligibility.** RETAINED_IN_EVOLVED_FORM; COMPOSITION_INDUCED_MECHANISM; crosswalk-worthy: YES

**Mechanism.** Bind evidence and acceptance to the relevant candidate, intent and assumptions; invalidate or re-evaluate affected evidence when a consequential input changes, and deliver it to an actor able to act.

**Trigger.** Evidence crosses a tool/person boundary, concurrent work changes the candidate, or a method uses results to authorise action.

**Required inputs and preconditions.** Identifiable objects and obligations, traceable evidence scope and a consumer with actual authority and capability.

**Produced evidence or constraint.** The actual accepted/deployed candidate is the one supported by the still-applicable evidence, or gaps are explicitly accepted within authority.

**Decision consumer and operative authority.** Analysts communicate evidence; authorised actors accept and operate; achieved consequences require observation after action.

**Preservation/observer constraint.** The actual accepted/deployed candidate is the one supported by the still-applicable evidence, or gaps are explicitly accepted within authority. Carry intended and preserved obligations across handoffs; distinguish knowing a criterion, authority/capability to act and realised consequences.

**Costs and assumption failures.** This relation is a reasoned synthesis, not an empirically validated universal protocol; excessive invalidation can cause rechecking cascades and delay. A visible local diff and check may not survive distributed handoffs or concurrent edits; enrich binding when stale evidence can reach another actor.

**Selection, substitution and omission.** One maintainer can keep the binding through a single visible diff and check; no new registry or owner is intrinsically required.

**Retirement.** Include coordination and validation costs created by composition. Consolidate or retire controls when a cheaper adequate configuration exists, without silently waiving protected obligations.

**Conflicts and alternatives.** ESME-T011: Learning versus stable acceptance rules. Changes to method need external authority and evidence tied to a real failure or cost; unchanged methods and control removal remain options.

**Linked composition relations.** `ESME-R054`, `ESME-R055`, `ESME-R056`

**Source IDs.** [ESME-S002; ESME-S016; ESME-S018; ESME-S024; ESME-S038; ESME-S051; ESME-S052; ESME-S055]

[ESME-072: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/71)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-073` — Continuity of obligations across temporary joint states

**Disposition, kind and eligibility.** ASSUMPTION_SENSITIVE; COMPOSITION_INDUCED_CONSTRAINT; crosswalk-worthy: YES

**Mechanism.** Identify reachable joint states, authoritative data and permitted version/change combinations; constrain operation or add evidence for the newly created interactions.

**Trigger.** Coexistence, concurrent integration, data conversion or externally staggered upgrades create intermediate states.

**Required inputs and preconditions.** A credible account of reachable combinations, sequencing and external actors; abstract state models must match actual operation.

**Produced evidence or constraint.** No supported transition relies solely on endpoint tests when consequential intermediate interactions remain unexamined.

**Decision consumer and operative authority.** Integrators and operators control only their own transitions; consumer/data owners adjudicate cross-boundary obligations.

**Preservation/observer constraint.** No supported transition relies solely on endpoint tests when consequential intermediate interactions remain unexamined. Carry intended and preserved obligations across handoffs; distinguish knowing a criterion, authority/capability to act and realised consequences.

**Costs and assumption failures.** State-space growth and unknown consumers can make exhaustive validation infeasible; constraints or a different migration strategy may dominate more testing. Constraining reachable combinations loses flexibility and may require interruption; that cost can dominate uncontrolled state-space growth.

**Selection, substitution and omission.** A truly atomic quiescent transition or justified disjoint changes can eliminate most joint-state obligations.

**Retirement.** Include coordination and validation costs created by composition. Consolidate or retire controls when a cheaper adequate configuration exists, without silently waiving protected obligations.

**Conflicts and alternatives.** ESME-T007: Coexistence versus quiescent cutover. Use coexistence only when partition and reconciliation costs are tolerable; use quiescence when an accepted stable boundary is credible.

**Linked composition relations.** `ESME-R017`, `ESME-R031`, `ESME-R038`, `ESME-R057`, `ESME-R058`

**Source IDs.** [ESME-S031; ESME-S038; ESME-S044; ESME-S045; ESME-S053]

[ESME-073: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/72)

### `EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION::ESME-074` — Feedback-driven proportionality and retirement of maintenance controls

**Disposition, kind and eligibility.** CONTEXT_DEPENDENT; COMPOSITION_INDUCED_FEEDBACK_AND_RETIREMENT; crosswalk-worthy: YES

**Mechanism.** Evaluate the combined decision benefit, interaction cost and residual risk of controls; consolidate, simplify or retire them when a cheaper adequate configuration dominates.

**Trigger.** Accumulating controls, repeated false alarms, migration completion, disappearing consumers or changed lifecycle objectives.

**Required inputs and preconditions.** Knowledge of protected obligations, actual consumers, combined costs and authority to alter the method without silently waiving required outcomes.

**Produced evidence or constraint.** The smallest adequate configuration retains necessary evidence and authority while removing unjustified duplicate or expired work.

**Decision consumer and operative authority.** Maintainers and decision owners revise controls; external obligations remain binding unless legitimately changed.

**Preservation/observer constraint.** The smallest adequate configuration retains necessary evidence and authority while removing unjustified duplicate or expired work. Carry intended and preserved obligations across handoffs; distinguish knowing a criterion, authority/capability to act and realised consequences.

**Costs and assumption failures.** Underestimating rare-event value can lead to premature control removal; some fixed coordination costs are necessary even when incidents are infrequent. A direct periodic decision can miss slow cost interactions or rare protective value; use richer observation only when it affects justified control selection.

**Selection, substitution and omission.** Retain a small working arrangement unchanged; do not create a permanent meta-process merely to measure every control.

**Retirement.** Include coordination and validation costs created by composition. Consolidate or retire controls when a cheaper adequate configuration exists, without silently waiving protected obligations.

**Conflicts and alternatives.** ESME-T011: Learning versus stable acceptance rules. Changes to method need external authority and evidence tied to a real failure or cost; unchanged methods and control removal remain options.

**Linked composition relations.** `ESME-R039`, `ESME-R054`, `ESME-R059`, `ESME-R060`

**Source IDs.** [ESME-S008; ESME-S022; ESME-S031; ESME-S032; ESME-S040; ESME-S048; ESME-S049; ESME-S058]

[ESME-074: complete record](EVOLVED_SOFTWARE_MAINTENANCE_AND_EVOLUTION_PROPERTY_LEDGER.json#/properties/73)

## Reconciliation questions for Software Architecture

How does the independently studied architecture corpus distinguish recovered structure, intended constraints and actual deployed relations? Which maintenance impact boundaries can use architectural evidence, and which data, configuration or human dependencies escape it? When does an architectural change invalidate preservation or release evidence? Does a proposed architectural simplification improve the plausible future change class after relearning and migration costs? Which temporary coexistence decisions create architectural obligations of their own? These are questions grounded in reverse engineering, impact, refactoring and migration, not claims about the unread corpus. [ESME-S012; ESME-S016; ESME-S018; ESME-S020; ESME-S031.]

## Reconciliation questions for Software Product Line Engineering

At what level are preservation and impact claims made: one configuration, a family, a generator, a shared asset or a platform? Which configurations and environment combinations must remain supported, and when is sampling or a variational proof applicable? Can differential reference checks expose disagreements without treating one implementation as infallible? How do deprecation, migration and support costs propagate across variants and independently deployed versions? Which shared mechanism could meet several obligations without hiding their distinct source histories? The KConfigReader experience is a documented intersection, not an answer on behalf of the unread product-line corpus. [ESME-S064; ESME-S045; ESME-S053.]

## Required later reconciliation tests

Test semantic equivalence using trigger, observer, postcondition and assumptions, not similar wording. Test complementarity by identifying actual produced and consumed evidence. Test redundancy without erasing genealogy or criticism. Compare abstraction levels before treating a criterion and a procedure as duplicates. Identify incompatible assumptions, including deterministic versus learned behaviour, local versus ecosystem boundaries, quiescent versus mixed-state transitions, and history-derived versus necessary dependencies. Seek new composition obligations where individually adequate mechanisms interact; keep their analytical status explicit.

A later system may substitute an already adequate mechanism, omit an inapplicable property, retire a cost-ineffective control or retain unresolved uncertainty. It must not recast six rejected generalisations, the golden-master duplicate, the universal change-board ritual or the unresolved autonomy claim as unqualified requirements. Preserve the original 74-candidate denominator in any mapping and place downstream adoption judgements in a new, separate crosswalk.

## Unresolved integration burdens

**ESME-U01.** How cheaply can evidence-to-action identity and invalidation be maintained across independently operated tools and teams? Status: `EXAMINED_UNRESOLVED`.

**ESME-U02.** Which abstraction exposes consequential joint-state failures without unmanageable combination growth? Status: `EXAMINED_UNRESOLVED`.

**ESME-U03.** What integrated field evidence establishes net benefit and appropriate retirement of combined controls? Status: `EXAMINED_UNRESOLVED`.

**ESME-U04.** Can reliable, authorised and economical unattended repository maintenance be demonstrated across representative populations over time? Status: `EXAMINED_UNRESOLVED`.

These are researched uncertainties, not incomplete lane research. Source access limits and the absence of an integrated field trial remain binding on later claims.
