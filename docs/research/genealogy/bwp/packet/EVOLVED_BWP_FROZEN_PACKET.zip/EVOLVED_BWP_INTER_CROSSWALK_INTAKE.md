# Evolved-BWP — later inter-crosswalk intake

**Revision:** `BWP-R1-2026-09-06`. **Inherited research cut-off:** 2026-09-06.

## Admission contract

This is an intake for a later, separately authorised property-by-property comparison. It does not perform that comparison, select a target owner, endorse adoption, or authorise mutation. All 234 inherited rows are exported unchanged in identity and disposition. There are zero new BWP-E rows. The later population is therefore **234 + 0 = 234**.

The complete machine-readable export is [EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json). Each record carries origin, disposition, examination status, bearer, criterion, trigger, non-trigger, mechanism, assumptions, authority, interaction, evidence ceilings, costs/failures, criticism, retirement, relations, clusters, tensions, sources and later questions. This Markdown projection gives a navigable entry for every record; it does not replace the richer JSON or the unchanged original constituent dossier.

Do not merge identities because they share a cluster. Do not drop rejected, ceremonial, duplicate, superseded, domain-bound, contested or unresolved candidates. A relation to a retained property cannot resurrect a rejected universal claim. The seven properties induced within their original lineages remain inherited rows, not new BWP-E properties.

`composition_induced` and `BWP_composition_induced` denote induction at this BWP layer and are false for all rows. `composition_induced_any_level` and `is_inherited_within_lineage_induced` preserve the seven constituent-layer inductions. All source and relation keys are fully qualified or resolve in the named BWP ledgers.

## Reading relations and uncertainty

Use the complete pair matrix and directional ledger together. Pair status is not an adoption disposition. A no-material cell means no direct specific coupling identified under the declared bounded screen, not incompatibility, a proven absence of all possible relations or permission to ignore either row. An unresolved relation may retain known narrower relations. Shared-source ancestry is an epistemic dependence, not operational equivalence or an extra replication.

The later consumer should separately test relevance, actual bearer, trigger, authority, prerequisites, cheaper substitution, evidence access, source independence, cost and retirement. A positive architectural or organisational judgement requires its own evidence. Do not infer a compulsory engine, mining programme, governance office, dashboard or BWP mode.

## Complete population

## EBPM — 73 inherited rows

<a id="ebpm-ebpm-001"></a>
### EBPM:EBPM-001 — End-to-end purposes and beneficiaries

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process purposes, beneficiaries and strategic outcome commitments

**Criterion.** A proposed change can be judged against an explicit outcome and identified recipients, rather than only a department’s activity count.

**Trigger.** A process is being selected, assessed or changed and local success may differ from the received outcome.

**Non-trigger / cheaper path.** For a small, already understood service, a short agreed purpose and completion statement plus sample cases is sufficient; no portfolio exercise is required.

**Mechanism.** Identify the intended result, its recipients and the end-to-end work that produces it. Make competing outcome claims visible before choosing measures or redesigning tasks; a purchaser’s preference is not automatically every affected person’s interest.

**Authority.** Responsible managers can commit resources; beneficiaries and affected workers contribute outcome evidence. Analysts cannot decide whose interests prevail merely by drawing the boundary.

**Interaction.** Recipients, performers and sponsors compare what they regard as successful completion and record unresolved differences.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Changed beneficiary needs, complaints, displaced harm or new strategic commitments.

**Source keys:** `EBPM:S001`, `EBPM:S002`, `EBPM:S005`, `EBPM:S030`. **BWP relations:** 38, individually enumerated in the JSON record. **Clusters:** BWP-K001, BWP-K019, BWP-K034, BWP-K035. **Tensions:** BWP-T009.

**Rich record.** Select `key == EBPM:EBPM-001` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-002"></a>
### EBPM:EBPM-002 — Boundary accountability and displaced burdens

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Outcome/improvement claims over an affected-party consequence boundary

**Criterion.** An apparent local gain is accepted, qualified or rejected with its downstream and affected-person consequences visible.

**Trigger.** A local measure improves, work is outsourced, or a redesigned interface changes another actor’s burden.

**Non-trigger / cheaper path.** Inspect a few complete cases and ask receiving participants what changed. A full network model is unnecessary when interfaces and effects are simple.

**Mechanism.** Trace consequential work, waiting and risk beyond the unit receiving the improvement credit. Compare the whole affected path and require an explicit account of costs displaced onto partners, customers or unlogged workers.

**Authority.** A local owner may change its own work but cannot bind a partner unilaterally. Cross-boundary obligations require agreement with the actors bearing them.

**Interaction.** Exchange completion meanings, demand, delays and burden evidence across interfaces; preserve disagreements rather than collapsing them into a local average.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: A partner backlog, complaint, unexplained abandonment or changed interface.

**Source keys:** `EBPM:S002`, `EBPM:S028`, `EBPM:S030`, `EBPM:S031`, `EBPM:S041`. **BWP relations:** 16, individually enumerated in the JSON record. **Clusters:** BWP-K002. **Tensions:** BWP-T010.

**Rich record.** Select `key == EBPM:EBPM-002` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-003"></a>
### EBPM:EBPM-003 — Identifiable cases, triggers and completion

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process cases, triggering needs and continuing/completion responsibilities

**Criterion.** Cases used in measures or routing have a stated identity rule, with ambiguous or continuing cases identified.

**Trigger.** Measurement, discovery or enactment depends on assigning work to cases and deciding whether work is finished.

**Non-trigger / cheaper path.** Use a lightweight episode or work-object account; where no stable repeated structure exists, coordinate goals and obligations without heavy process standardisation.

**Mechanism.** State what initiates the work, what object or case is being advanced and what counts as completion, cancellation or continuing responsibility. Do not force a single stable case identifier or a terminal event onto open-ended knowledge work without justification.

**Authority.** Operational owners and recipients define business completion; a system administrator defines only the system’s representational boundary.

**Interaction.** Participants reconcile initiating events, shared objects and completion/cancellation meanings.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Unassignable events, shared objects, reopening or work outside the original start/end boundary.

**Source keys:** `EBPM:S002`, `EBPM:S011`, `EBPM:S014`, `EBPM:S041`. **BWP relations:** 99, individually enumerated in the JSON record. **Clusters:** BWP-K003, BWP-K017, BWP-K019. **Tensions:** BWP-T005.

**Rich record.** Select `key == EBPM:EBPM-003` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-004"></a>
### EBPM:EBPM-004 — Selective process portfolio intervention

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Intervention portfolio and chosen scale of change

**Criterion.** Chosen and omitted interventions have intelligible reasons tied to expected consequences and capacity.

**Trigger.** Several process problems compete for limited analytical or change resources.

**Non-trigger / cheaper path.** A direct, well-evidenced local repair can proceed without constructing an organisation-wide portfolio.

**Mechanism.** Select interventions according to outcome importance, observed problems, dependencies and feasible change, not the convenience of what is already modelled. Include no intervention and deferred investigation as legitimate portfolio decisions.

**Authority.** Sponsors allocate scarce effort; affected process owners challenge feasibility and displacement assumptions.

**Interaction.** Make selection reasons, dependencies and deferred concerns available to those whose work is prioritised or postponed.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: New material harm, changed dependencies or evidence invalidating priority assumptions.

**Source keys:** `EBPM:S002`, `EBPM:S005`, `EBPM:S008`, `EBPM:S023`. **BWP relations:** 35, individually enumerated in the JSON record. **Clusters:** BWP-K001, BWP-K026. **Tensions:** BWP-T016.

**Rich record.** Select `key == EBPM:EBPM-004` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-005"></a>
### EBPM:EBPM-005 — Process architecture with preserved dependencies

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process architecture and cross-process dependencies

**Criterion.** An analyst can locate the affected process and its consequential relationships without equating reporting lines with work flow.

**Trigger.** Several processes share resources, objects or interfaces and local changes can conflict.

**Non-trigger / cheaper path.** For a small scope, an interface list with responsible participants can replace a full architecture hierarchy.

**Mechanism.** Represent process families, decomposition and interfaces at the abstraction needed for coordination. Preserve cross-cutting dependencies when decomposing and adapt reference architectures to actual work rather than treating a borrowed map as an empirical description.

**Authority.** Enterprise/process coordinators maintain the map with local expertise; the architecture does not override functional or contractual authority.

**Interaction.** Local owners reconcile shared terms, boundaries and dependencies before treating components as independent.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: New shared resources, duplicated work, boundary disputes or changed interdependencies.

**Source keys:** `EBPM:S002`, `EBPM:S005`, `EBPM:S008`. **BWP relations:** 52, individually enumerated in the JSON record. **Clusters:** BWP-K010, BWP-K020, BWP-K033. **Tensions:** BWP-T012.

**Rich record.** Select `key == EBPM:EBPM-005` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-006"></a>
### EBPM:EBPM-006 — Triangulated discovery of performed work

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Accounts of performed work, variants and observations outside current models

**Criterion.** The as-is account identifies its sources, covered variants and consequential uncertainties.

**Trigger.** A decision depends on what actually happens and available accounts may be incomplete, selective or incentive-distorted.

**Non-trigger / cheaper path.** For a transparent low-risk process, a few representative walkthroughs with performers and recipients may suffice; all evidence channels are not compulsory.

**Mechanism.** Compare interviews, documents, walkthroughs, direct observation and event evidence where they reveal different aspects of work. Record provenance and disagreement; neither a remembered account, a prescription nor an event log is intrinsically the whole truth.

**Authority.** Analysts synthesise evidence; performers and recipients can correct it. Sponsorship does not entitle an analyst to dismiss inconvenient observations.

**Interaction.** Bring discrepant accounts back to the people involved and distinguish uncertainty from disagreement about the desired process.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: A consequential contradiction, missing participant, unexplained outcome or previously hidden workaround.

**Source keys:** `EBPM:S002`, `EBPM:S025`, `EBPM:S035`, `EBPM:S041`, `EBPM:S048`. **BWP relations:** 75, individually enumerated in the JSON record. **Clusters:** BWP-K005, BWP-K016. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-006` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-007"></a>
### EBPM:EBPM-007 — Participant validation and explicit disagreement

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Participant validation, learning and consequential participation arrangements

**Criterion.** Users can apply the representation to the relevant case distinction, or a specific unresolved disagreement is recorded.

**Trigger.** A process model or redesign will be used across roles with different knowledge or incentives.

**Non-trigger / cheaper path.** A brief case walkthrough or annotated narrative may establish the needed understanding without a workshop series.

**Mechanism.** Test a representation with people who perform, receive and coordinate the work using concrete cases and exceptions. Preserve disagreement about facts, goals and authority separately; endorsement of a picture is not evidence of shared decision meaning.

**Authority.** Participants validate their knowledge, not necessarily the whole process; sponsors resolve authorised choices without erasing dissent.

**Interaction.** Ask participants to explain what happens in discriminating cases and identify omissions or conflicting interpretations.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Conflicting case interpretations, excluded stakeholders or changed roles.

**Source keys:** `EBPM:S005`, `EBPM:S025`, `EBPM:S030`, `EBPM:S041`, `EBPM:S048`. **BWP relations:** 12, individually enumerated in the JSON record. **Clusters:** BWP-K006. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-007` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-008"></a>
### EBPM:EBPM-008 — Variant and exception coverage in discovery

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Accounts of performed work, variants and observations outside current models

**Criterion.** A redesign claim states the case classes it covers and the exceptions that could defeat it.

**Trigger.** Case mix, exceptions or hidden handoffs could change analysis or redesign conclusions.

**Non-trigger / cheaper path.** Use a few deliberately contrasting cases when the variant space is small; exhaustive enumeration is unnecessary.

**Mechanism.** Sample materially different case types, failure paths and informal coordination. State which variants are covered and which remain uncertain; do not infer that rare or unlogged work is irrelevant simply because it is absent from a convenient sample.

**Authority.** Process investigators select cases with performers and recipients; owners accept the resulting uncertainty or commission further inquiry.

**Interaction.** Communicate normal-path coverage separately from exception and missing-case coverage.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: New case mix, abandonment, recurring exception or an adverse outlier.

**Source keys:** `EBPM:S014`, `EBPM:S025`, `EBPM:S041`, `EBPM:S048`. **BWP relations:** 47, individually enumerated in the JSON record. **Clusters:** BWP-K005, BWP-K015. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-008` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-009"></a>
### EBPM:EBPM-009 — Event-data provenance and observability limits

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Event/shared-data interpretation and its relationship to actual work

**Criterion.** Claims derived from logs specify what was recorded, transformed and excluded, including consequential blind spots.

**Trigger.** Event data will justify an as-is claim, comparison, forecast or intervention.

**Non-trigger / cheaper path.** A small manually checked sample and extraction description may be sufficient; a mining platform is not required.

**Mechanism.** Establish event meaning, case/object attribution, timestamp semantics, extraction scope and known omissions before using event evidence. Keep data-processing transformations traceable and expose activities that the instrumentation cannot observe.

**Authority.** Data custodians explain instrumentation; analysts own inference limits; process owners decide whether evidence is adequate for action.

**Interaction.** Exchange data definitions, missingness and case-attribution assumptions with performers and consumers of the analysis.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Schema changes, inconsistent timestamps, missing cases or discrepancies with human accounts.

**Source keys:** `EBPM:S018`, `EBPM:S025`, `EBPM:S035`, `EBPM:S041`. **BWP relations:** 134, individually enumerated in the JSON record. **Clusters:** BWP-K003, BWP-K005, BWP-K028, BWP-K032. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-009` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-010"></a>
### EBPM:EBPM-010 — Purpose-fit representation and abstraction

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process representations and the distinctions/quality claims supported by them

**Criterion.** The consumer can make the intended distinction, and prohibited or unsupported uses are visible.

**Trigger.** A representation is being selected, simplified, shared or reused for a new purpose.

**Non-trigger / cheaper path.** Use the lightest already-understood representation that preserves the needed distinction; no diagram is required where a short narrative is enough.

**Mechanism.** Choose the representation and abstraction by the decision it must support and the people who must use it. Preserve the distinctions needed for that task; a narrative, table, decision model, process graph or case representation can be adequate without being interchangeable.

**Authority.** The intended users help judge fitness; a notation specialist cannot infer business authority from technical sophistication.

**Interaction.** Explain what the representation omits and which uses it does not support.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: A new consumer, new task, misunderstanding or omitted consequential distinction.

**Source keys:** `EBPM:S005`, `EBPM:S009`, `EBPM:S010`, `EBPM:S011`, `EBPM:S014`, `EBPM:S041`. **BWP relations:** 96, individually enumerated in the JSON record. **Clusters:** BWP-K004, BWP-K031. **Tensions:** BWP-T004.

**Rich record.** Select `key == EBPM:EBPM-010` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-011"></a>
### EBPM:EBPM-011 — Separate syntactic, semantic and pragmatic quality

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process representations and the distinctions/quality claims supported by them

**Criterion.** A model’s validation statement says which quality dimensions were tested and what remains unestablished.

**Trigger.** A model will justify a decision, communicate consequential instructions or support execution.

**Non-trigger / cheaper path.** A short review against examples may suffice for a simple narrative; formal syntax checks apply only to notations that have such rules.

**Mechanism.** Check notation well-formedness separately from fidelity to the intended domain and understandability for the intended user. Use the corresponding test for each claim; one kind of validity cannot stand in for the others.

**Authority.** Tool validators assess encoded rules; domain experts assess meaning; users demonstrate comprehension. None alone certifies the other dimensions.

**Interaction.** Report quality findings by dimension and resolve disagreements with the relevant expertise.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: A model correction, changed domain rule, execution mismatch or user misunderstanding.

**Source keys:** `EBPM:S007`, `EBPM:S009`, `EBPM:S010`, `EBPM:S011`, `EBPM:S048`. **BWP relations:** 145, individually enumerated in the JSON record. **Clusters:** BWP-K004, BWP-K007, BWP-K011, BWP-K028, BWP-K030. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-011` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-012"></a>
### EBPM:EBPM-012 — Behaviour-preserving complexity management

**Disposition:** `USEFUL_BUT_EASILY_BUREAUCRATISED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process representations and the distinctions/quality claims supported by them

**Criterion.** Users handle the relevant cases at least adequately without loss of critical constraints or relationships.

**Trigger.** Users cannot reliably interpret a model, or model changes introduce structural errors.

**Non-trigger / cheaper path.** Remove an ambiguity or improve a label before imposing a new modelling standard or decomposition programme.

**Mechanism.** Reduce unnecessary representational complexity while preserving decision-relevant behaviour and relationships. Test the simplified form with its users; use modularisation or multiple coordinated views when a single small diagram would conceal essential interactions.

**Authority.** Modellers propose changes; users and domain experts check that useful meaning has not been lost.

**Interaction.** Communicate the relation between simplified and detailed views and the exceptions intentionally retained.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Observed comprehension failures, growing model maintenance cost or changed user tasks.

**Source keys:** `EBPM:S009`, `EBPM:S010`, `EBPM:S044`. **BWP relations:** 63, individually enumerated in the JSON record. **Clusters:** BWP-K004, BWP-K031. **Tensions:** BWP-T004.

**Rich record.** Select `key == EBPM:EBPM-012` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-013"></a>
### EBPM:EBPM-013 — Interpretable activity labels and domain terms

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process representations and the distinctions/quality claims supported by them

**Criterion.** Critical labels support the intended action/object distinction across the relevant users.

**Trigger.** Users disagree about an activity, decision or completion label, or labels are reused across roles.

**Non-trigger / cheaper path.** A brief glossary or example can be enough; a mandatory naming convention is unnecessary when existing terms work.

**Mechanism.** Use terms that distinguish what action or decision occurs and what object is affected, in the intended users’ language. Resolve ambiguous domain terms before standardising a label grammar; test important labels through concrete cases.

**Authority.** Domain participants determine meaning; model maintainers ensure consistent use without overriding legitimate local terminology.

**Interaction.** Ask users what a label authorises or predicts and reconcile materially different readings.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Ambiguous use, a new audience or a term whose meaning changes with the process.

**Source keys:** `EBPM:S009`, `EBPM:S010`, `EBPM:S044`. **BWP relations:** 18, individually enumerated in the JSON record. **Clusters:** BWP-K004. **Tensions:** BWP-T012.

**Rich record.** Select `key == EBPM:EBPM-013` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-014"></a>
### EBPM:EBPM-014 — Explicit modelling-versus-execution contract

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** The modelling-versus-execution contract between a process representation, enactment and actual work

**Criterion.** The model’s claimed scope matches tested implementation behaviour and does not silently certify organisational consequences.

**Trigger.** A model is handed to implementers, imported into a tool or presented as evidence that a process operates correctly.

**Non-trigger / cheaper path.** For a descriptive model, simply state that it is not executable; do not build an execution contract unnecessarily.

**Mechanism.** Declare whether a model communicates, analyses or drives execution, and identify the additional implementation semantics and organisational arrangements needed to move between those uses. Keep engine events and real completion separate until their correspondence is demonstrated.

**Authority.** Implementers control deployed semantics within their authority; process owners and recipients establish real obligations and completion criteria.

**Interaction.** Modellers, implementers and operators reconcile what a task or event means in each representation.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Engine migration, changed task semantics, ignored model elements or completion mismatch.

**Source keys:** `EBPM:S011`, `EBPM:S012`, `EBPM:S027`, `EBPM:S041`. **BWP relations:** 145, individually enumerated in the JSON record. **Clusters:** BWP-K007, BWP-K011, BWP-K032. **Tensions:** BWP-T001, BWP-T017.

**Rich record.** Select `key == EBPM:EBPM-014` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-015"></a>
### EBPM:EBPM-015 — Separable decision logic and decision authority

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Decision rules, their consumers and separately authorised decision-makers

**Criterion.** A decision can be explained and changed without silently changing who may make it or what outcome follows.

**Trigger.** Business decisions are obscured in flow diagrams, reused across processes or changed independently of task order.

**Non-trigger / cheaper path.** A decision table or explicit rationale can be sufficient; DMN is an option rather than an obligation.

**Mechanism.** Where decision rules vary independently of routing, distinguish the information/rules used to decide from the actor authorised to decide and from the consequences of that decision. Keep a traceable connection between a decision model and the process consuming its result.

**Authority.** A rule author or prediction service is not automatically the legitimate decision maker; accountable actors retain domain-specific authority.

**Interaction.** Communicate the rule/version, available inputs, discretion and meaning of the result to the consuming process.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Policy change, unexplained decisions, missing input or mismatch between modelled and actual authority.

**Source keys:** `EBPM:S011`, `EBPM:S013`, `EBPM:S030`, `EBPM:S033`. **BWP relations:** 73, individually enumerated in the JSON record. **Clusters:** BWP-K008, BWP-K014. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-015` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-016"></a>
### EBPM:EBPM-016 — Knowledge-work and declarative alternatives

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Knowledge-work support, discretion, variants and binding constraints

**Criterion.** Participants can adapt the work while preserving essential obligations and keeping others informed.

**Trigger.** Cases require changing knowledge, professional judgement or runtime planning that an exhaustive flow would distort.

**Non-trigger / cheaper path.** A shared case note, goal list and essential constraints can be enough without a case-management engine.

**Mechanism.** Select support according to what can be known in advance: goals and information needs, mandatory constraints, planned tasks or a stable flow. Allow structured sub-processes inside knowledge work and avoid making flexibility equivalent to the absence of guidance.

**Authority.** Case workers plan within professional and organisational authority; system flexibility does not grant new powers.

**Interaction.** Exchange case knowledge, decisions and changes in responsibility rather than only next-task messages.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: An unforeseen case, changed knowledge, persistent workarounds or a constraint that blocks legitimate action.

**Source keys:** `EBPM:S012`, `EBPM:S014`, `EBPM:S041`, `EBPM:S042`. **BWP relations:** 108, individually enumerated in the JSON record. **Clusters:** BWP-K010, BWP-K015, BWP-K031. **Tensions:** BWP-T003.

**Rich record.** Select `key == EBPM:EBPM-016` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-017"></a>
### EBPM:EBPM-017 — Outcome-valid, plural performance measures

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Outcome/improvement claims over an affected-party consequence boundary

**Criterion.** An improvement claim states which outcomes changed, which worsened and whose experience is represented.

**Trigger.** Measures will guide resource allocation, redesign acceptance or individual/process appraisal.

**Non-trigger / cheaper path.** A small set of outcome and harm checks can be sufficient; a comprehensive balanced dashboard is not mandatory.

**Mechanism.** Use measures that represent the intended received outcome and material costs, with case mix and affected groups visible. Keep time, effort, quality, flexibility, resilience and fairness distinct where they can move in opposing directions; select justified constraints and priorities rather than pretending all are maximised.

**Authority.** Accountable decision makers choose priorities with affected-party input; analysts expose measurement limitations rather than choosing values by convenience.

**Interaction.** Communicate the unit, denominator, case mix, uncertainty and parties bearing benefits/costs.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Metric gaming, case-mix change, adverse consequences or conflict between indicators.

**Source keys:** `EBPM:S002`, `EBPM:S016`, `EBPM:S026`, `EBPM:S030`, `EBPM:S031`, `EBPM:S040`. **BWP relations:** 104, individually enumerated in the JSON record. **Clusters:** BWP-K002, BWP-K025, BWP-K027, BWP-K030. **Tensions:** BWP-T010.

**Rich record.** Select `key == EBPM:EBPM-017` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-018"></a>
### EBPM:EBPM-018 — Elapsed time distinguished from work effort

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Elapsed process time, effort and resource occupancy claims

**Criterion.** A delay claim no longer conflates a worker’s effort with the case’s elapsed duration.

**Trigger.** A time-based performance claim or delay intervention is being made.

**Non-trigger / cheaper path.** A manually reconstructed case timeline can be adequate; detailed time logging is unnecessary when the causal bottleneck is already clear.

**Mechanism.** Separate elapsed time experienced by the case or recipient from active work effort and resource occupancy. Locate waiting, transfer and rework contributions before attributing delay to an actor or deciding which activity to accelerate.

**Authority.** Analysts interpret time evidence with performers; owners can change allocation or handoff arrangements within their authority.

**Interaction.** Show the timeline and distinguish work, queueing, handoff and interruption interpretations.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Timestamp changes, new concurrency, unexplained delay or a shift from work to waiting.

**Source keys:** `EBPM:S002`, `EBPM:S016`, `EBPM:S017`, `EBPM:S027`. **BWP relations:** 53, individually enumerated in the JSON record. **Clusters:** BWP-K012, BWP-K013. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-018` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-019"></a>
### EBPM:EBPM-019 — Capacity, variability and bottleneck diagnosis

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Capacity/queueing/simulation model and conditional intervention predictions

**Criterion.** The selected intervention targets a supported constraint and includes evidence about the resulting queue and displaced load.

**Trigger.** Persistent queues, fluctuating demand or shared-resource contention dominate outcomes.

**Non-trigger / cheaper path.** A workload/timeline comparison and a bounded allocation trial may dominate building a detailed stochastic model.

**Mechanism.** Examine demand, service variation, shared capacity and allocation rules together before adding resources or seeking maximum utilisation. Use a queueing model or simulation only when its assumptions represent the relevant work; recheck the end-to-end constraint after a local change.

**Authority.** Resource managers can change capacity and assignment; analysts supply conditional predictions, not authority to alter staffing or worker obligations.

**Interaction.** Make demand, capacity and behavioural assumptions explicit to those who allocate resources and bear workload.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Demand drift, moved bottleneck, overload, altered prioritisation or degraded recovery capacity.

**Source keys:** `EBPM:S004`, `EBPM:S017`, `EBPM:S018`, `EBPM:S027`. **BWP relations:** 64, individually enumerated in the JSON record. **Clusters:** BWP-K012, BWP-K023. **Tensions:** BWP-T010.

**Rich record.** Select `key == EBPM:EBPM-019` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-020"></a>
### EBPM:EBPM-020 — Handoff and rework mechanism diagnosis

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Handoff and rework mechanisms, including necessary repair/checking

**Criterion.** A claimed rework reduction is tied to a changed causal mechanism and retained necessary controls.

**Trigger.** Cases bounce between actors, repeatedly request information or suffer unexplained rejection/delay.

**Non-trigger / cheaper path.** Walk a few failed cases and repair a single information or responsibility defect before redesigning the entire process.

**Mechanism.** Trace how a handoff, missing information or rejected output generates delay and repeated work. Distinguish avoidable rework from necessary checking, learning or repair before changing task boundaries or removing feedback.

**Authority.** Sending and receiving actors jointly identify the mechanism; an owner needs authority or agreement to change both sides.

**Interaction.** Exchange concrete rejected outputs, acceptance conditions and reasons for return, rather than blaming the next department.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Repeated rejection, new error propagation or apparent rework reduction with rising external complaints.

**Source keys:** `EBPM:S001`, `EBPM:S002`, `EBPM:S016`, `EBPM:S025`, `EBPM:S041`. **BWP relations:** 62, individually enumerated in the JSON record. **Clusters:** BWP-K010, BWP-K013, BWP-K018. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-020` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-021"></a>
### EBPM:EBPM-021 — Calibrated simulation with uncertainty

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Capacity/queueing/simulation model and conditional intervention predictions

**Criterion.** A simulation-supported choice includes an empirical calibration check and conditions under which the prediction is not relied upon.

**Trigger.** Alternatives are costly or disruptive to test directly, or queues/current cases make short-term effects non-obvious.

**Non-trigger / cheaper path.** Use arithmetic, a case timeline or a limited real-world trial when these answer the decision adequately.

**Mechanism.** Calibrate the model to the relevant case mix, resource behaviour and current work state; validate predictions against observations and report uncertainty and sensitivity. Treat scenarios as conditional forecasts, not observed consequences of an intervention.

**Authority.** Analysts own model assumptions; operational decision makers decide whether the conditional evidence justifies action.

**Interaction.** Communicate the baseline, predicted range, uncertain assumptions and alternatives to those making the intervention decision.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Calibration failure, current-state mismatch, changed resources or outcome drift.

**Source keys:** `EBPM:S017`, `EBPM:S018`, `EBPM:S027`. **BWP relations:** 49, individually enumerated in the JSON record. **Clusters:** BWP-K023. **Tensions:** BWP-T011.

**Rich record.** Select `key == EBPM:EBPM-021` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-022"></a>
### EBPM:EBPM-022 — Causal restraint in intervention selection

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Intervention hypotheses, comparisons and analytical claim roles

**Criterion.** The decision states whether evidence is descriptive, predictive or causally identifying, with material alternative explanations visible.

**Trigger.** A variant, actor or activity is blamed for an outcome, or a predicted association is used to choose a change.

**Non-trigger / cheaper path.** A modest reversible trial with explicit observations can be more informative than a complex causal model based on weak assumptions.

**Mechanism.** Distinguish description, prediction and causal intervention claims. State the proposed mechanism, plausible confounding and comparison; use stronger designs or bounded trials when an observational association could recommend the wrong intervention.

**Authority.** Analysts can identify evidence limits; authorised owners decide on precaution, experimentation or non-intervention.

**Interaction.** Explain why the proposed comparison distinguishes the causal story from plausible rivals.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: An alternative explanation, changed case mix or outcome inconsistent with the proposed mechanism.

**Source keys:** `EBPM:S002`, `EBPM:S018`, `EBPM:S019`, `EBPM:S027`, `EBPM:S031`, `EBPM:S040`. **BWP relations:** 77, individually enumerated in the JSON record. **Clusters:** BWP-K023, BWP-K025. **Tensions:** BWP-T011.

**Rich record.** Select `key == EBPM:EBPM-022` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-023"></a>
### EBPM:EBPM-023 — Hypothesis-led comparison of redesign alternatives

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Intervention hypotheses, comparisons and analytical claim roles

**Criterion.** A selected redesign has an explicit mechanism, comparison and evaluable consequences rather than a technology-first justification.

**Trigger.** A process intervention is proposed and multiple mechanisms could address the problem.

**Non-trigger / cheaper path.** A small reversible change with a simple comparison may be enough; no full redesign workshop or simulation is necessary.

**Mechanism.** Form a specific change hypothesis and compare it with plausible organisational, informational and technical alternatives, including doing nothing. Define what would count as improvement, what may not worsen and how the choice will be evaluated after enactment.

**Authority.** Owners/sponsors authorise changes within their remit; performers and recipients contribute feasibility and harm evidence.

**Interaction.** Communicate the rationale, alternatives rejected, expected effects and conditions for stopping or revising the change.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Unexpected harm, failure of the mechanism, new evidence or an alternative becoming cheaper.

**Source keys:** `EBPM:S002`, `EBPM:S015`, `EBPM:S016`, `EBPM:S027`, `EBPM:S030`. **BWP relations:** 76, individually enumerated in the JSON record. **Clusters:** BWP-K023, BWP-K025. **Tensions:** BWP-T011.

**Rich record.** Select `key == EBPM:EBPM-023` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-024"></a>
### EBPM:EBPM-024 — Control-aware task elimination

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Tasks/controls proposed for removal and their protected functions

**Criterion.** The removed task’s necessary functions are either explicitly retired with reasons or demonstrably covered elsewhere.

**Trigger.** A step is labelled waste, redundant approval or avoidable checking.

**Non-trigger / cheaper path.** Retain a cheap effective check when redesign cost or uncertain risk exceeds its burden; combine duplicate checks only after their distinct functions are understood.

**Mechanism.** Before deleting a task, identify both its productive and protective functions, their consumers, and whether another mechanism preserves necessary assurance. Compare avoided effort with the error or accountability exposure created by removal.

**Authority.** The owner can propose deletion; the party accountable for the controlled consequence must be involved in accepting the changed exposure.

**Interaction.** Performers explain exceptions and hidden checking work to the redesign decision-maker.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: New failure, previously hidden consumer or changed risk after removal.

**Source keys:** `EBPM:S015`, `EBPM:S016`, `EBPM:S030`. **BWP relations:** 22, individually enumerated in the JSON record. **Clusters:** BWP-K026. **Tensions:** BWP-T016.

**Rich record.** Select `key == EBPM:EBPM-024` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-025"></a>
### EBPM:EBPM-025 — Dependency-aware resequencing

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Task order and information/resource/commitment dependencies

**Criterion.** The revised order avoids targeted delay or unnecessary work without invalidating required inputs or controls.

**Trigger.** Cases commonly fail late or an ordering constraint appears unnecessary.

**Non-trigger / cheaper path.** Keep the current order when dependencies are tight or savings are negligible; try a small reversible ordering change first.

**Mechanism.** Move an activity only after checking information, resource, commitment and protective dependencies. Early screening can avoid downstream effort, while premature action can create irrecoverable commitments.

**Authority.** Operational owners coordinate changes across the functions whose inputs or commitments move.

**Interaction.** Participants agree when inputs are reliable enough and when a case becomes committed.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Changed input reliability, case mix or downstream rejection pattern.

**Source keys:** `EBPM:S015`, `EBPM:S016`. **BWP relations:** 43, individually enumerated in the JSON record. **Clusters:** BWP-K008, BWP-K009. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-025` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-026"></a>
### EBPM:EBPM-026 — Synchronisation-aware parallelisation

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Concurrent activities, joins and resulting partial effects

**Criterion.** Elapsed time improves without unaccounted duplicate work, incompatible outputs or stranded partial completion.

**Trigger.** Serial waiting dominates and dependencies permit overlapping work.

**Non-trigger / cheaper path.** Keep serial execution when coordination or rework dominates; overlap only the independent portion.

**Mechanism.** Execute genuinely independent activities concurrently while specifying how their outputs are joined, what happens on disagreement or partial failure, and whether resources can sustain the overlap.

**Authority.** The owner arranges cross-team commitments; each performer retains authority over its own result.

**Interaction.** Exchange readiness, completion, failure and conflicting-output information, not merely task-start notifications.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Join failures, overload, demand changes or rising speculative rework.

**Source keys:** `EBPM:S015`, `EBPM:S016`, `EBPM:S017`, `EBPM:S027`. **BWP relations:** 65, individually enumerated in the JSON record. **Clusters:** BWP-K009, BWP-K010. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-026` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-027"></a>
### EBPM:EBPM-027 — Case coordination and task composition

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Case coordination, allocation, pooling and segmentation arrangements

**Criterion.** Case continuity improves while required specialist/control functions remain effective.

**Trigger.** Cases repeatedly lose context or stall between fragmented responsibilities.

**Non-trigger / cheaper path.** A shared case note and named coordinator can be enough; do not require one person to perform every specialist task.

**Mechanism.** Assign sufficient continuity of knowledge and responsibility to a case while retaining necessary specialist review and segregation of duties. Compare fewer handoffs with the competence and concentration-of-authority costs of task combination.

**Authority.** A coordinator may organise contributions without acquiring every professional or financial approval power.

**Interaction.** Specialists and coordinators communicate decisions, unresolved issues and recipient needs.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Coordinator overload, skill gaps or recurrent specialist reversals.

**Source keys:** `EBPM:S001`, `EBPM:S015`, `EBPM:S016`, `EBPM:S026`. **BWP relations:** 27, individually enumerated in the JSON record. **Clusters:** BWP-K014, BWP-K033. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-027` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-028"></a>
### EBPM:EBPM-028 — Conditional pooling and centralisation

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Case coordination, allocation, pooling and segmentation arrangements

**Criterion.** Pooling produces a defensible overall result, including access and delay for small or exceptional groups.

**Trigger.** Duplicated capabilities or uneven demand suggest a pooling opportunity.

**Non-trigger / cheaper path.** Retain local provision when responsiveness, contextual expertise or failure isolation dominates.

**Mechanism.** Compare shared capacity and consistency benefits with queueing, local-knowledge loss, authority distance and a larger failure domain. Select central, local or federated arrangements according to the actual dependency and demand structure.

**Authority.** Shared-service governance must have authority to allocate capacity and a route for local concerns.

**Interaction.** Local units expose demand and exceptional needs; the pooled service exposes capacity and priority decisions.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Persistent local bypass, inequitable queues or correlated failure.

**Source keys:** `EBPM:S015`, `EBPM:S016`, `EBPM:S021`. **BWP relations:** 16, individually enumerated in the JSON record. **Clusters:** BWP-K012. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-028` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-029"></a>
### EBPM:EBPM-029 — Case segmentation and skill allocation

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Case coordination, allocation, pooling and segmentation arrangements

**Criterion.** Case groups receive fit-for-purpose handling with visible misclassification and unequal-service effects.

**Trigger.** A common route performs poorly for distinct needs, risks or required expertise.

**Non-trigger / cheaper path.** Keep one route with an exception option when classification adds more error or delay than it removes.

**Mechanism.** Separate materially different cases where this improves fit, but validate classification quality and the burdens imposed on difficult or disadvantaged cases. Reassess class boundaries when demand changes.

**Authority.** Classification and resource-allocation decisions require accountable authority; analysts do not define acceptable exclusion alone.

**Interaction.** Recipients and performers can challenge classifications and reveal unmet needs.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Misclassification, distributional harm or shifting case mix.

**Source keys:** `EBPM:S015`, `EBPM:S016`, `EBPM:S030`. **BWP relations:** 77, individually enumerated in the JSON record. **Clusters:** BWP-K012, BWP-K015, BWP-K027. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-029` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-030"></a>
### EBPM:EBPM-030 — Proportionate radical or incremental change

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Intervention portfolio and chosen scale of change

**Criterion.** The chosen change scale matches the problem and includes credible continuity and evaluation arrangements.

**Trigger.** The current process is being reconsidered or incremental changes repeatedly fail to address a structural problem.

**Non-trigger / cheaper path.** Retain or repair a functioning process when disruption has no warranted payoff.

**Mechanism.** Choose the scale and pace of change by the inadequacy of the current mechanism, uncertainty, transition risk and continuity needs. Consider radical replacement, incremental repair, mixed migration and no change as genuine alternatives.

**Authority.** Sponsors authorise strategic disruption; performers and affected recipients contribute transition and continuity evidence.

**Interaction.** Make reasons for change, protected services and unresolved risks understandable to affected actors.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Failed milestones, service harm or evidence invalidating the redesign rationale.

**Source keys:** `EBPM:S001`, `EBPM:S002`, `EBPM:S005`, `EBPM:S027`, `EBPM:S038`. **BWP relations:** 77, individually enumerated in the JSON record. **Clusters:** BWP-K021, BWP-K026. **Tensions:** BWP-T002.

**Rich record.** Select `key == EBPM:EBPM-030` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-031"></a>
### EBPM:EBPM-031 — Process ownership with effective authority

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process governance arrangements and exercised authority

**Criterion.** A consequential cross-functional decision can actually be made and implemented by identified actors.

**Trigger.** An end-to-end problem crosses functional authority or an owner is assigned responsibility.

**Non-trigger / cheaper path.** In a small team, existing management and a clear escalation agreement may suffice; no extra role is required.

**Mechanism.** Connect responsibility for the process outcome with sufficient influence, knowledge, resources and an escalation route across participating functions. Separate an owner title from the powers actually exercised.

**Authority.** The process owner acts within delegated powers; functional and professional authorities retain powers not transferred. Conflicts require negotiation or escalation, not fictitious unilateral control.

**Interaction.** Owners, functional managers, performers and sponsors exchange priorities, constraints, evidence and unresolved decisions.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Repeated unresolved conflicts, changed scope or accountability without control.

**Source keys:** `EBPM:S020`, `EBPM:S021`, `EBPM:S027`, `EBPM:S043`. **BWP relations:** 65, individually enumerated in the JSON record. **Clusters:** BWP-K014, BWP-K024, BWP-K034. **Tensions:** BWP-T008.

**Rich record.** Select `key == EBPM:EBPM-031` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-032"></a>
### EBPM:EBPM-032 — Strategy-to-process translation

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process purposes, beneficiaries and strategic outcome commitments

**Criterion.** Investment and redesign choices have a traceable substantive reason and can be challenged when consequences contradict it.

**Trigger.** Processes compete for investment or strategic objectives change.

**Non-trigger / cheaper path.** A small service can use a few agreed outcome priorities without a formal strategy cascade.

**Mechanism.** Translate strategic commitments into explicit process outcomes, selection priorities and constraints. Examine conflicts between the sponsor’s strategy, affected-party interests and actual operational capacity rather than assuming alignment is inherently beneficial.

**Authority.** Strategy sponsors decide commitments; owners and performers test feasibility; affected parties inform consequences.

**Interaction.** Explain which process outcomes support which commitments and where trade-offs remain.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Changed strategy, infeasible commitments or adverse consequences of target pursuit.

**Source keys:** `EBPM:S005`, `EBPM:S030`, `EBPM:S040`, `EBPM:S043`. **BWP relations:** 13, individually enumerated in the JSON record. **Clusters:** BWP-K001. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-032` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-033"></a>
### EBPM:EBPM-033 — Context-fit BPM governance configuration

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process governance arrangements and exercised authority

**Criterion.** The chosen arrangement resolves identified coordination needs without unexplained duplication or authority gaps.

**Trigger.** Multiple units need coordination, common methods or shared process investment.

**Non-trigger / cheaper path.** Use existing management and a few explicit coordination agreements when they resolve the actual decisions.

**Mechanism.** Select centralised, decentralised or federated governance according to process interdependence, organisational context and available capabilities. Specify the decisions each arrangement enables rather than treating a BPM office as a universal requirement.

**Authority.** A BPM office may advise, enable or govern only within its mandate; process and functional managers retain explicitly allocated decisions.

**Interaction.** Exchange local evidence with shared standards or investment decisions, including a route to contest misfit.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Unresolved ownership, duplicated work, local bypass or changed organisational dependencies.

**Source keys:** `EBPM:S021`, `EBPM:S023`, `EBPM:S043`. **BWP relations:** 22, individually enumerated in the JSON record. **Clusters:** BWP-K026. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-033` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-034"></a>
### EBPM:EBPM-034 — Capability assessment as fallible diagnosis

**Disposition:** `USEFUL_BUT_EASILY_GAMED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Capability/maturity assessments and claims made from their artefacts or ratings

**Criterion.** Assessment produces testable development priorities or an explicit decision that no further machinery is warranted.

**Trigger.** An organisation needs to diagnose capability gaps or choose improvement support.

**Non-trigger / cheaper path.** Investigate the actual failed decisions or processes directly when a broad assessment would not change action.

**Mechanism.** Use a capability assessment as a fallible diagnostic hypothesis about specific competencies, not as a proxy for process success or an obligatory stage ladder. Check evidence behind ratings and whether the proposed development addresses a real outcome problem.

**Authority.** Assessors describe evidence and limits; sponsors decide whether an identified capability warrants investment.

**Interaction.** Participants can challenge ratings and distinguish missing paperwork from missing capability.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: High ratings with poor results, inconsistent raters or irrelevant prescriptions.

**Source keys:** `EBPM:S022`, `EBPM:S023`, `EBPM:S040`, `EBPM:S043`. **BWP relations:** 50, individually enumerated in the JSON record. **Clusters:** BWP-K026, BWP-K030. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-034` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-035"></a>
### EBPM:EBPM-035 — Participation, learning and incentive alignment

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Participant validation, learning and consequential participation arrangements

**Criterion.** Relevant knowledge changes the design or is explicitly adjudicated, and actors can perform the new work.

**Trigger.** A change depends on new behaviour, tacit knowledge or acceptance by affected actors.

**Non-trigger / cheaper path.** Direct discussion and guided practice may suffice for a small change; a formal change programme is not always needed.

**Mechanism.** Involve those performing and receiving work in discovery, redesign and evaluation; provide skills and incentives that permit the intended behaviour. Treat participation as consequential influence and learning, not attendance or consultation without effect.

**Authority.** Sponsors resource participation; performers contribute operational knowledge; consultation does not erase formal accountability.

**Interaction.** Explain proposed changes and respond visibly to objections, uncertainty and practical constraints.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Adoption failure, repeated confusion, staff turnover or adverse incentives.

**Source keys:** `EBPM:S005`, `EBPM:S024`, `EBPM:S026`, `EBPM:S041`, `EBPM:S043`. **BWP relations:** 45, individually enumerated in the JSON record. **Clusters:** BWP-K006, BWP-K027. **Tensions:** BWP-T007, BWP-T014.

**Rich record.** Select `key == EBPM:EBPM-035` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-036"></a>
### EBPM:EBPM-036 — Bounded human discretion and exceptions

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Knowledge-work support, discretion, variants and binding constraints

**Criterion.** The case can proceed or stop for defensible reasons without losing necessary accountability.

**Trigger.** Case facts invalidate the normal route or expertise is needed beyond a fixed activity sequence.

**Non-trigger / cheaper path.** For low-risk, simple work, a clear goal and accessible expert may suffice without a case-management platform.

**Mechanism.** Distinguish legitimate discretion from uncontrolled deviation. Define the goals and constraints that remain binding, who can depart from the ordinary route, and how the decision and its consequences are communicated and reviewed.

**Authority.** A case worker’s discretion is bounded by professional and organisational authority; a model’s optional task does not confer legal or ethical permission.

**Interaction.** Communicate exceptional facts, chosen departure and unresolved obligations to those affected or responsible.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Recurring exceptions, harmful variation or changed professional knowledge.

**Source keys:** `EBPM:S012`, `EBPM:S014`, `EBPM:S026`, `EBPM:S030`, `EBPM:S042`. **BWP relations:** 66, individually enumerated in the JSON record. **Clusters:** BWP-K015, BWP-K016, BWP-K037. **Tensions:** BWP-T001, BWP-T003, BWP-T006.

**Rich record.** Select `key == EBPM:EBPM-036` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-037"></a>
### EBPM:EBPM-037 — Workaround-driven misalignment inquiry

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** A workaround and its cause, purpose, risks and authorised disposition

**Criterion.** The workaround receives an evidence-based disposition and material unresolved consequences are visible.

**Trigger.** Actors repeatedly bypass a prescribed procedure or information system.

**Non-trigger / cheaper path.** Resolve an isolated, understood mismatch locally when no wider change is justified.

**Mechanism.** Investigate a workaround’s cause, protected purpose, risks and affected parties before either suppressing it or institutionalising it. Distinguish useful repair, constraint evasion and temporary accommodation, then decide whether to change the system, the work or neither.

**Authority.** Performers can explain the workaround; authorised owners and relevant control holders decide its acceptance or replacement.

**Interaction.** Connect the reason for the bypass with the people responsible for the underlying misfit and those bearing the risk.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Repeated recurrence, harm, change in the bypassed risk or discovery of a cheaper legitimate route.

**Source keys:** `EBPM:S025`, `EBPM:S026`, `EBPM:S041`. **BWP relations:** 54, individually enumerated in the JSON record. **Clusters:** BWP-K016, BWP-K022, BWP-K037. **Tensions:** BWP-T001, BWP-T006.

**Rich record.** Select `key == EBPM:EBPM-037` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-038"></a>
### EBPM:EBPM-038 — Responsible visibility and affected-person protection

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process visibility, appraisal, incentives and affected-person protection

**Criterion.** The evidence used for decisions has a defensible purpose and access boundary, with harms and disputes visible.

**Trigger.** Monitoring, employee-level data, sensitive case information or consequential algorithmic decisions are introduced.

**Non-trigger / cheaper path.** Use aggregate, sampled or less identifying evidence when it answers the decision adequately; omit monitoring with no legitimate consumer.

**Mechanism.** Limit process visibility and automated judgements to a declared purpose with appropriate access, participation and challenge. Examine privacy, surveillance, fairness and worker/recipient burdens as design consequences, not external afterthoughts.

**Authority.** Managers do not acquire unlimited surveillance authority through technical availability; applicable professional, organisational and legal constraints require separate determination.

**Interaction.** Affected people understand consequential uses of data and can raise errors and adverse effects.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: New data use, harmful inference, access expansion or affected-party challenge.

**Source keys:** `EBPM:S026`, `EBPM:S030`, `EBPM:S035`, `EBPM:S041`. **BWP relations:** 88, individually enumerated in the JSON record. **Clusters:** BWP-K006, BWP-K027, BWP-K041. **Tensions:** BWP-T014.

**Rich record.** Select `key == EBPM:EBPM-038` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-039"></a>
### EBPM:EBPM-039 — Incentive-aware appraisal and metric interpretation

**Disposition:** `USEFUL_BUT_EASILY_GAMED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process visibility, appraisal, incentives and affected-person protection

**Criterion.** An appraisal or improvement decision accounts for known distortions and does not equate target attainment with the entire outcome.

**Trigger.** A measure affects pay, ranking, sanctions, targets or resource access.

**Non-trigger / cheaper path.** Use qualitative review or aggregate learning measures where precise individual attribution is not warranted.

**Mechanism.** Interpret indicators in light of the behaviour they reward, omitted work and differences in case difficulty. Use multiple relevant observations and inquiry into gaming rather than assuming the measured quantity remains a neutral description once tied to appraisal.

**Authority.** Appraisal decision-makers are accountable for the use of measures; analysts must expose limitations rather than authorising sanctions.

**Interaction.** Workers and recipients can explain discrepant indicators and hidden burden without the discrepancy alone proving misconduct.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Target attainment without outcome gain, unusual case selection or reporting anomalies.

**Source keys:** `EBPM:S005`, `EBPM:S024`, `EBPM:S026`, `EBPM:S030`, `EBPM:S041`. **BWP relations:** 60, individually enumerated in the JSON record. **Clusters:** BWP-K027, BWP-K030. **Tensions:** BWP-T014.

**Rich record.** Select `key == EBPM:EBPM-039` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-040"></a>
### EBPM:EBPM-040 — Socio-technical enactment and adoption

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Socio-technical enactment, automation or low-code delivery and actual received consequences

**Criterion.** Real cases are completed under the new arrangement with responsibilities and observed consequences understood.

**Trigger.** A to-be design is introduced or a new system is claimed to improve a process.

**Non-trigger / cheaper path.** An organisational agreement, training or information change may suffice without new software.

**Mechanism.** Treat enactment as the joint establishment of working technology, roles, skills, resources, coordination and actual adoption. Verify that actors can perform the intended work and that the organisation receives the outcome; deployment is only one observation.

**Authority.** Sponsors resource change; owners coordinate adoption; technical teams control only technical deployment within their mandate.

**Interaction.** Performers, support staff, partners and recipients exchange readiness, problems and unresolved work during transition.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Non-use, unresolved cases, workaround growth, adverse outcomes or withdrawal of needed support.

**Source keys:** `EBPM:S002`, `EBPM:S005`, `EBPM:S027`, `EBPM:S041`, `EBPM:S043`. **BWP relations:** 95, individually enumerated in the JSON record. **Clusters:** BWP-K024, BWP-K025, BWP-K029. **Tensions:** BWP-T007.

**Rich record.** Select `key == EBPM:EBPM-040` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-041"></a>
### EBPM:EBPM-041 — Selective automation and interface suitability

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Socio-technical enactment, automation or low-code delivery and actual received consequences

**Criterion.** The selected mechanism performs its bounded function under stated conditions, with business consequences evaluated separately.

**Trigger.** Repetitive digital work or coordination overhead suggests a technical intervention.

**Non-trigger / cheaper path.** Retain manual work or improve information/organisation when exception cost or integration fragility outweighs automation benefit.

**Mechanism.** Select automation according to process stability, interface characteristics, data quality, exception load and the value of human judgement. Compare interface-level RPA, deeper integration and non-automation; test the actual changed work rather than relying on a tool category.

**Authority.** Automation executes delegated operations; it does not establish the legitimacy of the underlying business decision.

**Interaction.** Users, technical operators and owners communicate interface changes, exceptions and consequences.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Interface change, exception growth, drift in inputs or absent net outcome benefit.

**Source keys:** `EBPM:S027`, `EBPM:S029`, `EBPM:S041`, `EBPM:S045`. **BWP relations:** 87, individually enumerated in the JSON record. **Clusters:** BWP-K029, BWP-K031. **Tensions:** BWP-T007.

**Rich record.** Select `key == EBPM:EBPM-041` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-042"></a>
### EBPM:EBPM-042 — External-effect and completion reconciliation

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Business/external obligation completion and receiving-side evidence

**Criterion.** Declared completion corresponds to the agreed business outcome, or remaining uncertainty and responsibility are explicit.

**Trigger.** A process sends messages, transfers goods or money, changes external records or closes an obligation.

**Non-trigger / cheaper path.** A direct recipient confirmation or simple reconciliation may suffice; do not require a new distributed protocol for every process.

**Mechanism.** Distinguish a local task or engine completion from completion of the obligation to a recipient or partner. Identify the external effects that matter and obtain appropriate receiving-side or operational evidence before declaring the business case complete.

**Authority.** Each actor controls its own commitments; a local owner cannot declare another party’s obligations fulfilled by fiat.

**Interaction.** Communicate acceptance, rejection, missing effects and outstanding responsibility across interfaces.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Unconfirmed receipt, disputed completion, duplicate effect or outstanding obligation.

**Source keys:** `EBPM:S002`, `EBPM:S011`, `EBPM:S027`, `EBPM:S028`, `EBPM:S041`. **BWP relations:** 139, individually enumerated in the JSON record. **Clusters:** BWP-K017, BWP-K018, BWP-K019, BWP-K035, BWP-K039. **Tensions:** BWP-T009.

**Rich record.** Select `key == EBPM:EBPM-042` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-043"></a>
### EBPM:EBPM-043 — Recovery and controlled interruption

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Interrupted work, outstanding obligations and authorised continuation/recovery

**Criterion.** An interrupted case is not silently treated as completed, and an accountable decision governs continuation or resolution.

**Trigger.** Work can fail after consequential action or unsafe continuation is plausible.

**Non-trigger / cheaper path.** For a reversible low-impact task, manual stop-and-check with a responsible person may be sufficient.

**Mechanism.** Where failed or interrupted work can leave consequential partial effects, ensure actors know how to pause, assess outstanding obligations and select an authorised continuation or recovery. The BPM-level requirement does not prescribe engine-specific retry, rollback or compensation algorithms.

**Authority.** Operators may stop within delegated authority; reversal or compensation of another actor’s commitment requires the relevant authority.

**Interaction.** Communicate what happened, what remains uncertain and who owns unfinished obligations.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Failed observation, partial completion, unsafe continuation or exhausted recovery options.

**Source keys:** `EBPM:S011`, `EBPM:S012`, `EBPM:S027`, `EBPM:S041`. **BWP relations:** 155, individually enumerated in the JSON record. **Clusters:** BWP-K017, BWP-K018, BWP-K021. **Tensions:** BWP-T013.

**Rich record.** Select `key == EBPM:EBPM-043` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-044"></a>
### EBPM:EBPM-044 — Decision-linked monitoring

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Monitoring outputs linked, or not linked, to a capable decision consumer

**Criterion.** A relevant observation results in a documented decision, inquiry or reasoned non-action rather than passive reporting.

**Trigger.** Process measures or monitoring are introduced or reviewed.

**Non-trigger / cheaper path.** Periodic case review or a simple threshold with a known responder may suffice; retire indicators with no current decision use.

**Mechanism.** Connect each consequential indicator to a decision, a responsible consumer and a feasible action or inquiry. A dashboard can inform action but its production is not itself adaptation or improvement.

**Authority.** Monitoring analysts provide evidence; authorised owners or professionals decide interventions.

**Interaction.** Transmit deviations, uncertainty and context to a consumer who can question the signal and act.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: A threshold breach, complaint, unexplained divergence or an indicator losing its consumer.

**Source keys:** `EBPM:S004`, `EBPM:S005`, `EBPM:S027`, `EBPM:S036`, `EBPM:S041`. **BWP relations:** 64, individually enumerated in the JSON record. **Clusters:** BWP-K001, BWP-K024, BWP-K034. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-044` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-045"></a>
### EBPM:EBPM-045 — Drift-sensitive reassessment

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Changed demand, models, practice and assumptions requiring reassessment

**Criterion.** The change is classified and consequential assumptions or controls are reviewed with reasons.

**Trigger.** Observed patterns differ materially from the baseline or the operating environment changes.

**Non-trigger / cheaper path.** A focused review of changed cases may suffice; continuous automated drift detection is unnecessary for infrequent stable work.

**Mechanism.** Reassess models, assumptions and measures when demand, case mix, resources, interfaces or actual practices change. Distinguish benign variation from a changed mechanism and avoid updating the model merely to normalise a harmful deviation.

**Authority.** Analysts identify changed evidence; owners and affected actors decide whether models, operations or objectives need revision.

**Interaction.** Communicate changed assumptions, affected cases and uncertainty rather than only a drift score.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Demand/resource change, new workaround pattern, interface revision or outcome drift.

**Source keys:** `EBPM:S004`, `EBPM:S018`, `EBPM:S025`, `EBPM:S035`. **BWP relations:** 99, individually enumerated in the JSON record. **Clusters:** BWP-K021, BWP-K022. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-045` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-046"></a>
### EBPM:EBPM-046 — Outcome evaluation and control retirement

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Post-enactment outcome evaluation and control continuation/retirement decision

**Criterion.** The change receives a reasoned retain, revise, withdraw or evidence-insufficient decision.

**Trigger.** A change has been enacted, an evaluation point arrives, or a control’s continued value is questioned.

**Non-trigger / cheaper path.** A small before/after case review may support a reversible local decision, with causal limits stated; no new intervention is an acceptable result.

**Mechanism.** Separate model change, implementation, adoption and measured outcome change. Review the proposed mechanism against observed consequences and retire, simplify or replace a control when its risk, consumer or payoff no longer warrants its cost.

**Authority.** Owners and sponsors decide continuation within their powers; affected actors provide evidence of benefits and burdens.

**Interaction.** Report unfavourable and null outcomes alongside benefits, including who bears transition and ongoing costs.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Evaluation point, adverse evidence, changed risk or loss of the control’s consumer.

**Source keys:** `EBPM:S002`, `EBPM:S005`, `EBPM:S023`, `EBPM:S027`. **BWP relations:** 109, individually enumerated in the JSON record. **Clusters:** BWP-K022, BWP-K025, BWP-K026, BWP-K040. **Tensions:** BWP-T016.

**Rich record.** Select `key == EBPM:EBPM-046` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-047"></a>
### EBPM:EBPM-047 — Feedback that can expose omitted work

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Accounts of performed work, variants and observations outside current models

**Criterion.** A material discrepancy can lead to changed inquiry or explicit adjudication rather than exclusion as out of scope by definition.

**Trigger.** A process is evaluated primarily through records generated by its existing model or system.

**Non-trigger / cheaper path.** Occasional independent case walkthroughs and accessible complaint routes may suffice; exhaustive surveillance is not required.

**Mechanism.** Keep a route by which observations outside the current model—complaints, practitioner accounts, recipient experience and unlogged work—can challenge both the representation and the success measure. Do not let the model define all admissible evidence about its own adequacy.

**Authority.** Evidence contributors may challenge a model; revision remains an authorised decision rather than automatic acceptance of every complaint.

**Interaction.** Bring external or omitted observations to the people controlling the model, measures and process.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Credible contradiction, unexplained outcome or evidence of systematic omission.

**Source keys:** `EBPM:S006`, `EBPM:S025`, `EBPM:S026`, `EBPM:S035`, `EBPM:S041`. **BWP relations:** 74, individually enumerated in the JSON record. **Clusters:** BWP-K005, BWP-K016. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-047` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-048"></a>
### EBPM:EBPM-048 — Negotiated inter-organisational governance

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Negotiated cross-organisational obligations and dispute/decision rights

**Criterion.** A cross-organisational issue has an agreed decision route and responsibilities visible to participating parties.

**Trigger.** A received outcome depends on independent organisations with their own commitments.

**Non-trigger / cheaper path.** A clear bilateral interface and escalation agreement may suffice for a simple relationship.

**Mechanism.** Negotiate shared outcomes, interfaces, responsibilities and dispute handling among autonomous organisations. Make differences in incentives, information and decision rights explicit; no single process diagram grants one participant authority over the network.

**Authority.** Each organisation can commit only within its mandate; joint decisions require agreed governance rather than assumed central control.

**Interaction.** Exchange interface expectations, capacity issues, rejected handoffs and unresolved cross-party obligations.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Partner change, disputed completion, shifted burden or failure of agreed escalation.

**Source keys:** `EBPM:S002`, `EBPM:S028`, `EBPM:S030`. **BWP relations:** 24, individually enumerated in the JSON record. **Clusters:** BWP-K020. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-048` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-049"></a>
### EBPM:EBPM-049 — Shared-data meaning and disclosure boundaries

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Event/shared-data interpretation and its relationship to actual work

**Criterion.** A receiving actor can interpret the shared evidence for the intended decision, with missing or incompatible meaning explicit.

**Trigger.** Data or messages cross organisational/system boundaries or are joined for analysis.

**Non-trigger / cheaper path.** Agree a small set of shared terms and examples when broad semantic standardisation would add no value.

**Mechanism.** Reconcile the meanings of cases, events, messages and completion across interfaces while limiting disclosure to a justified purpose. Technical schema compatibility is not enough when organisations interpret the same field differently.

**Authority.** Data custodians control authorised disclosure; process parties jointly resolve business meaning within their commitments.

**Interaction.** Communicate definitions, provenance, uncertainty and changes that affect receiving interpretations.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Schema/meaning change, joining error, disclosure concern or incompatible completion claims.

**Source keys:** `EBPM:S011`, `EBPM:S028`, `EBPM:S030`, `EBPM:S035`. **BWP relations:** 208, individually enumerated in the JSON record. **Clusters:** BWP-K003, BWP-K020, BWP-K027, BWP-K028, BWP-K032. **Tensions:** BWP-T005, BWP-T012, BWP-T015, BWP-T017.

**Rich record.** Select `key == EBPM:EBPM-049` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-050"></a>
### EBPM:EBPM-050 — Environmental and societal outcome constraints

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Outcome/improvement claims over an affected-party consequence boundary

**Criterion.** A sustainability claim states what changed, for whom, over which boundary and with what evidence limits.

**Trigger.** A process has material resource, environmental or social consequences or a sponsor claims sustainable improvement.

**Non-trigger / cheaper path.** A focused material-impact assessment may suffice; do not add an ESG dashboard unrelated to a consequential decision.

**Mechanism.** Include material environmental and societal consequences in process purpose, boundaries and redesign comparisons. Identify who or what bears these effects and distinguish measured outcomes from reporting capability, commitments or maturity ratings.

**Authority.** Sponsors and owners decide within legitimate constraints; affected parties and domain experts contribute consequences that internal metrics may omit.

**Interaction.** Explain impact assumptions, displaced burdens and conflicts rather than announcing all objectives simultaneously improved.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: New impact evidence, displaced burden, changed objectives or unsupported sustainability claims.

**Source keys:** `EBPM:S030`, `EBPM:S031`, `EBPM:S032`, `EBPM:S040`. **BWP relations:** 49, individually enumerated in the JSON record. **Clusters:** BWP-K002, BWP-K027. **Tensions:** BWP-T010.

**Rich record.** Select `key == EBPM:EBPM-050` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-051"></a>
### EBPM:EBPM-051 — Process intelligence joined to accountable intervention

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Intervention hypotheses, comparisons and analytical claim roles

**Criterion.** An analytical result is accepted only for a stated evidential role and its action/outcome claims are separately evaluated.

**Trigger.** Analytics is proposed to diagnose or recommend process changes.

**Non-trigger / cheaper path.** A simple case review or direct measure may answer the decision without mining, prediction or simulation.

**Mechanism.** Use analytical outputs as evidence for accountable inquiry and intervention, preserving data, causal and organisational limits. Distinguish descriptive pattern, predictive performance, feasible intervention and achieved outcome.

**Authority.** Analysts and tools generate evidence or recommendations; process actors retain responsibility for actions and consequences.

**Interaction.** Communicate uncertainty, omitted work, comparison conditions and the proposed decision use.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Contradictory field evidence, model drift, causal-assumption failure or lack of an actionable consumer.

**Source keys:** `EBPM:S004`, `EBPM:S018`, `EBPM:S019`, `EBPM:S035`, `EBPM:S036`. **BWP relations:** 86, individually enumerated in the JSON record. **Clusters:** BWP-K023, BWP-K024. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-051` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-052"></a>
### EBPM:EBPM-052 — Independently checked AI-assisted modelling

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** AI-generated process artefacts and their independent acceptance checks

**Criterion.** Accepted content is checked against the task’s evidence and intended semantics; uncertainty and unsupported additions remain identifiable.

**Trigger.** A generative model is used to elicit, draft, explain or revise a process representation.

**Non-trigger / cheaper path.** Human modelling, a short narrative or a decision table may be cheaper and more reliable for small or sensitive tasks.

**Mechanism.** Use generated process artefacts as drafts that require independent checking of syntax, domain meaning, omitted work and purpose. Separate benchmark task success from truthful reconstruction of an organisation and from authority to execute the generated design.

**Authority.** The model has no independent business authority; authorised people remain responsible for accepting representations and interventions.

**Interaction.** Reviewers receive the input basis, generated claims and unresolved ambiguities, not just a polished diagram.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Unsupported claim, changed model/version, new use purpose or failed field validation.

**Source keys:** `EBPM:S010`, `EBPM:S033`, `EBPM:S034`. **BWP relations:** 21, individually enumerated in the JSON record. **Clusters:** BWP-K029. **Tensions:** BWP-T007.

**Rich record.** Select `key == EBPM:EBPM-052` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-053"></a>
### EBPM:EBPM-053 — Autonomous agentic process self-revision

**Disposition:** `UNRESOLVED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Unresolved autonomous organisational process self-revision capability

**Criterion.** No general operational postcondition is certified. A later bounded system would need demonstrable constraint-respecting action and verified consequences.

**Trigger.** An agent is proposed to choose and execute consequential process changes without case-by-case human approval.

**Non-trigger / cheaper path.** Use bounded assistance, recommendations or explicitly delegated reversible operations while retaining authorised review of consequential redesign.

**Mechanism.** Candidate proposition: agents could revise and enact organisational processes under goals and constraints. The inspected 2026 manifesto formulates research requirements; this study does not establish that autonomous cross-context self-revision is safe, effective or adequately governed.

**Authority.** A goal prompt does not grant unlimited organisational authority. Any permissible autonomy must be separately delegated and justified.

**Interaction.** The research problem includes how agents expose reasons, uncertainty, interventions and failures to accountable actors.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Any proposed expansion of autonomy requires new evidence and explicit authorisation.

**Source keys:** `EBPM:S030`, `EBPM:S034`. **BWP relations:** 24, individually enumerated in the JSON record. **Clusters:** BWP-K029. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-053` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-054"></a>
### EBPM:EBPM-054 — Universal prescriptive standardisation

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Knowledge-work support, discretion, variants and binding constraints

**Criterion.** A later assessment does not penalise justified discretion merely for departing from the nominal path.

**Trigger.** This proposition is used to justify a process design or evaluate success without checking the guarded alternative.

**Non-trigger / cheaper path.** Do not impose the proposition. Use EBPM-036 only when its stated trigger and prerequisites hold; otherwise retain the existing arrangement or omit the machinery.

**Mechanism.** No unconditional operating mechanism is retained. Knowledge-intensive and exceptional cases can require bounded judgement; a fixed route is not universally appropriate.

**Authority.** A case worker’s discretion is bounded by professional and organisational authority; a model’s optional task does not confer legal or ethical permission.

**Interaction.** Communicate exceptional facts, chosen departure and unresolved obligations to those affected or responsible.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Recurring exceptions, harmful variation or changed professional knowledge.

**Source keys:** `EBPM:S012`, `EBPM:S014`, `EBPM:S026`, `EBPM:S030`, `EBPM:S042`. **BWP relations:** 30, individually enumerated in the JSON record. **Clusters:** BWP-K015. **Tensions:** BWP-T003.

**Rich record.** Select `key == EBPM:EBPM-054` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-055"></a>
### EBPM:EBPM-055 — Radical re-engineering as default

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Intervention portfolio and chosen scale of change

**Criterion.** Change scale is justified by mechanism and continuity evidence rather than the radicalism of the proposal.

**Trigger.** This proposition is used to justify a process design or evaluate success without checking the guarded alternative.

**Non-trigger / cheaper path.** Do not impose the proposition. Use EBPM-030 only when its stated trigger and prerequisites hold; otherwise retain the existing arrangement or omit the machinery.

**Mechanism.** No unconditional operating mechanism is retained. Disruption and transition costs can dominate, while incremental repair or no change may address the actual problem.

**Authority.** Sponsors authorise strategic disruption; performers and affected recipients contribute transition and continuity evidence.

**Interaction.** Make reasons for change, protected services and unresolved risks understandable to affected actors.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Failed milestones, service harm or evidence invalidating the redesign rationale.

**Source keys:** `EBPM:S001`, `EBPM:S002`, `EBPM:S005`, `EBPM:S027`, `EBPM:S038`. **BWP relations:** 42, individually enumerated in the JSON record. **Clusters:** BWP-K026. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-055` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-056"></a>
### EBPM:EBPM-056 — Documentation or maturity score as success

**Disposition:** `CEREMONY_NOT_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Capability/maturity assessments and claims made from their artefacts or ratings

**Criterion.** Ratings remain diagnostic evidence rather than a substitute for operational results.

**Trigger.** This proposition is used to justify a process design or evaluate success without checking the guarded alternative.

**Non-trigger / cheaper path.** Do not impose the proposition. Use EBPM-034 only when its stated trigger and prerequisites hold; otherwise retain the existing arrangement or omit the machinery.

**Mechanism.** No unconditional operating mechanism is retained. Artefacts and self-assessed stages do not establish exercised capability or received outcomes.

**Authority.** Assessors describe evidence and limits; sponsors decide whether an identified capability warrants investment.

**Interaction.** Participants can challenge ratings and distinguish missing paperwork from missing capability.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: High ratings with poor results, inconsistent raters or irrelevant prescriptions.

**Source keys:** `EBPM:S022`, `EBPM:S023`, `EBPM:S040`, `EBPM:S043`. **BWP relations:** 41, individually enumerated in the JSON record. **Clusters:** BWP-K026, BWP-K030. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-056` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-057"></a>
### EBPM:EBPM-057 — Notation conformance as organisational truth

**Disposition:** `NO_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process representations and the distinctions/quality claims supported by them

**Criterion.** Model validity is restricted to the checked interpretation and purpose.

**Trigger.** This proposition is used to justify a process design or evaluate success without checking the guarded alternative.

**Non-trigger / cheaper path.** Do not impose the proposition. Use EBPM-014 only when its stated trigger and prerequisites hold; otherwise retain the existing arrangement or omit the machinery.

**Mechanism.** No unconditional operating mechanism is retained. Syntax, execution semantics, domain accuracy, authority and actual enactment are distinct.

**Authority.** Implementers control deployed semantics within their authority; process owners and recipients establish real obligations and completion criteria.

**Interaction.** Modellers, implementers and operators reconcile what a task or event means in each representation.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Engine migration, changed task semantics, ignored model elements or completion mismatch.

**Source keys:** `EBPM:S011`, `EBPM:S012`, `EBPM:S027`, `EBPM:S041`. **BWP relations:** 104, individually enumerated in the JSON record. **Clusters:** BWP-K007, BWP-K028. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-057` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-058"></a>
### EBPM:EBPM-058 — Automation as a sufficient improvement

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Socio-technical enactment, automation or low-code delivery and actual received consequences

**Criterion.** A technical intervention must pass an outcome comparison rather than an automation-count test.

**Trigger.** This proposition is used to justify a process design or evaluate success without checking the guarded alternative.

**Non-trigger / cheaper path.** Do not impose the proposition. Use EBPM-041 only when its stated trigger and prerequisites hold; otherwise retain the existing arrangement or omit the machinery.

**Mechanism.** No unconditional operating mechanism is retained. Automation can amplify a flawed decision, shift manual repair or fail to be adopted.

**Authority.** Automation executes delegated operations; it does not establish the legitimacy of the underlying business decision.

**Interaction.** Users, technical operators and owners communicate interface changes, exceptions and consequences.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Interface change, exception growth, drift in inputs or absent net outcome benefit.

**Source keys:** `EBPM:S027`, `EBPM:S029`, `EBPM:S041`, `EBPM:S045`. **BWP relations:** 49, individually enumerated in the JSON record. **Clusters:** BWP-K024, BWP-K029. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-058` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-059"></a>
### EBPM:EBPM-059 — Maximum utilisation as a universal goal

**Disposition:** `NO_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Capacity/queueing/simulation model and conditional intervention predictions

**Criterion.** Capacity decisions consider demand variability and elapsed outcomes rather than pursuing full utilisation by definition.

**Trigger.** This proposition is used to justify a process design or evaluate success without checking the guarded alternative.

**Non-trigger / cheaper path.** Do not impose the proposition. Use EBPM-019 only when its stated trigger and prerequisites hold; otherwise retain the existing arrangement or omit the machinery.

**Mechanism.** No unconditional operating mechanism is retained. Variability, bottlenecks and queues make utilisation alone an inadequate end-to-end objective; the relevant model assumptions must be checked.

**Authority.** Resource managers can change capacity and assignment; analysts supply conditional predictions, not authority to alter staffing or worker obligations.

**Interaction.** Make demand, capacity and behavioural assumptions explicit to those who allocate resources and bear workload.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Demand drift, moved bottleneck, overload, altered prioritisation or degraded recovery capacity.

**Source keys:** `EBPM:S004`, `EBPM:S017`, `EBPM:S018`, `EBPM:S027`. **BWP relations:** 30, individually enumerated in the JSON record. **Clusters:** BWP-K012. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-059` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-060"></a>
### EBPM:EBPM-060 — Nominal owner assignment as adequate governance

**Disposition:** `CEREMONY_NOT_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process governance arrangements and exercised authority

**Criterion.** Assessment looks for exercised decision capacity rather than the existence of the title.

**Trigger.** This proposition is used to justify a process design or evaluate success without checking the guarded alternative.

**Non-trigger / cheaper path.** Do not impose the proposition. Use EBPM-031 only when its stated trigger and prerequisites hold; otherwise retain the existing arrangement or omit the machinery.

**Mechanism.** No unconditional operating mechanism is retained. A title can coexist with absent authority, resources, knowledge or escalation ability.

**Authority.** The process owner acts within delegated powers; functional and professional authorities retain powers not transferred. Conflicts require negotiation or escalation, not fictitious unilateral control.

**Interaction.** Owners, functional managers, performers and sponsors exchange priorities, constraints, evidence and unresolved decisions.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Repeated unresolved conflicts, changed scope or accountability without control.

**Source keys:** `EBPM:S020`, `EBPM:S021`, `EBPM:S027`, `EBPM:S043`. **BWP relations:** 33, individually enumerated in the JSON record. **Clusters:** BWP-K014. **Tensions:** BWP-T008.

**Rich record.** Select `key == EBPM:EBPM-060` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-061"></a>
### EBPM:EBPM-061 — Dashboard publication as demonstrated improvement

**Disposition:** `CEREMONY_NOT_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Monitoring outputs linked, or not linked, to a capable decision consumer

**Criterion.** An indicator is tied to a decision or retired; publication is not counted as improvement.

**Trigger.** This proposition is used to justify a process design or evaluate success without checking the guarded alternative.

**Non-trigger / cheaper path.** Do not impose the proposition. Use EBPM-044 only when its stated trigger and prerequisites hold; otherwise retain the existing arrangement or omit the machinery.

**Mechanism.** No unconditional operating mechanism is retained. A report with no capable consumer or consequential decision is not a functioning feedback mechanism.

**Authority.** Monitoring analysts provide evidence; authorised owners or professionals decide interventions.

**Interaction.** Transmit deviations, uncertainty and context to a consumer who can question the signal and act.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: A threshold breach, complaint, unexplained divergence or an indicator losing its consumer.

**Source keys:** `EBPM:S004`, `EBPM:S005`, `EBPM:S027`, `EBPM:S036`, `EBPM:S041`. **BWP relations:** 45, individually enumerated in the JSON record. **Clusters:** BWP-K001, BWP-K024. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-061` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-062"></a>
### EBPM:EBPM-062 — Mined process model as unqualified ground truth

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Event/shared-data interpretation and its relationship to actual work

**Criterion.** A mined result is interpreted within its data-generation and observation boundary.

**Trigger.** This proposition is used to justify a process design or evaluate success without checking the guarded alternative.

**Non-trigger / cheaper path.** Do not impose the proposition. Use EBPM-009 only when its stated trigger and prerequisites hold; otherwise retain the existing arrangement or omit the machinery.

**Mechanism.** No unconditional operating mechanism is retained. Event recording is selective, case identity can misfit work and off-system coordination may be essential.

**Authority.** Data custodians explain instrumentation; analysts own inference limits; process owners decide whether evidence is adequate for action.

**Interaction.** Exchange data definitions, missingness and case-attribution assumptions with performers and consumers of the analysis.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Schema changes, inconsistent timestamps, missing cases or discrepancies with human accounts.

**Source keys:** `EBPM:S018`, `EBPM:S025`, `EBPM:S035`, `EBPM:S041`. **BWP relations:** 66, individually enumerated in the JSON record. **Clusters:** BWP-K005, BWP-K028. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-062` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-063"></a>
### EBPM:EBPM-063 — Universal fifty-element decomposition threshold

**Disposition:** `SUPERSEDED_BY_STRONGER_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process representations and the distinctions/quality claims supported by them

**Criterion.** Complexity treatment is selected through purpose and comprehension evidence, not a universal element-count pass/fail.

**Trigger.** This proposition is used to justify a process design or evaluate success without checking the guarded alternative.

**Non-trigger / cheaper path.** Do not impose the proposition. Use EBPM-012 only when its stated trigger and prerequisites hold; otherwise retain the existing arrangement or omit the machinery.

**Mechanism.** No unconditional operating mechanism is retained. The 7PMG recommendation is not a universal discontinuity in comprehension or correctness; user, task, semantics and decomposition costs matter.

**Authority.** Modellers propose changes; users and domain experts check that useful meaning has not been lost.

**Interaction.** Communicate the relation between simplified and detailed views and the exceptions intentionally retained.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Observed comprehension failures, growing model maintenance cost or changed user tasks.

**Source keys:** `EBPM:S009`, `EBPM:S010`, `EBPM:S044`. **BWP relations:** 12, individually enumerated in the JSON record. **Clusters:** BWP-K004. **Tensions:** BWP-T004.

**Rich record.** Select `key == EBPM:EBPM-063` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-064"></a>
### EBPM:EBPM-064 — One standard variant for every case

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Knowledge-work support, discretion, variants and binding constraints

**Criterion.** A common route or variant set is justified by case needs and consequences.

**Trigger.** This proposition is used to justify a process design or evaluate success without checking the guarded alternative.

**Non-trigger / cheaper path.** Do not impose the proposition. Use EBPM-029 only when its stated trigger and prerequisites hold; otherwise retain the existing arrangement or omit the machinery.

**Mechanism.** No unconditional operating mechanism is retained. Meaningful differences in needs, expertise and risk can justify variants; eliminating variation can harm difficult cases.

**Authority.** Classification and resource-allocation decisions require accountable authority; analysts do not define acceptable exclusion alone.

**Interaction.** Recipients and performers can challenge classifications and reveal unmet needs.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Misclassification, distributional harm or shifting case mix.

**Source keys:** `EBPM:S015`, `EBPM:S016`, `EBPM:S030`. **BWP relations:** 14, individually enumerated in the JSON record. **Clusters:** BWP-K015. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-064` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-065"></a>
### EBPM:EBPM-065 — Blanket elimination of controls and human involvement

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Tasks/controls proposed for removal and their protected functions

**Criterion.** Necessary protective functions remain covered or their retirement is explicitly justified.

**Trigger.** This proposition is used to justify a process design or evaluate success without checking the guarded alternative.

**Non-trigger / cheaper path.** Do not impose the proposition. Use EBPM-024 only when its stated trigger and prerequisites hold; otherwise retain the existing arrangement or omit the machinery.

**Mechanism.** No unconditional operating mechanism is retained. Some steps protect against consequential error or preserve legitimate judgement; their functions cannot be erased by relabelling them overhead.

**Authority.** The owner can propose deletion; the party accountable for the controlled consequence must be involved in accepting the changed exposure.

**Interaction.** Performers explain exceptions and hidden checking work to the redesign decision-maker.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: New failure, previously hidden consumer or changed risk after removal.

**Source keys:** `EBPM:S015`, `EBPM:S016`, `EBPM:S030`. **BWP relations:** 20, individually enumerated in the JSON record. **Clusters:** BWP-K026. **Tensions:** BWP-T016.

**Rich record.** Select `key == EBPM:EBPM-065` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-066"></a>
### EBPM:EBPM-066 — Single-metric optimisation as end-to-end value

**Disposition:** `NO_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Outcome/improvement claims over an affected-party consequence boundary

**Criterion.** Outcome claims are scoped and competing protected consequences are examined.

**Trigger.** This proposition is used to justify a process design or evaluate success without checking the guarded alternative.

**Non-trigger / cheaper path.** Do not impose the proposition. Use EBPM-017 only when its stated trigger and prerequisites hold; otherwise retain the existing arrangement or omit the machinery.

**Mechanism.** No unconditional operating mechanism is retained. A single local metric can conceal burden displacement, unfairness, reduced resilience or worse received outcomes.

**Authority.** Accountable decision makers choose priorities with affected-party input; analysts expose measurement limitations rather than choosing values by convenience.

**Interaction.** Communicate the unit, denominator, case mix, uncertainty and parties bearing benefits/costs.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Metric gaming, case-mix change, adverse consequences or conflict between indicators.

**Source keys:** `EBPM:S002`, `EBPM:S016`, `EBPM:S026`, `EBPM:S030`, `EBPM:S031`, `EBPM:S040`. **BWP relations:** 32, individually enumerated in the JSON record. **Clusters:** BWP-K002, BWP-K030. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-066` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-067"></a>
### EBPM:EBPM-067 — Organisation chart as process architecture

**Disposition:** `NO_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process architecture and cross-process dependencies

**Criterion.** Process boundaries and dependencies have evidence distinct from functional reporting lines.

**Trigger.** This proposition is used to justify a process design or evaluate success without checking the guarded alternative.

**Non-trigger / cheaper path.** Do not impose the proposition. Use EBPM-005 only when its stated trigger and prerequisites hold; otherwise retain the existing arrangement or omit the machinery.

**Mechanism.** No unconditional operating mechanism is retained. Reporting relationships do not identify end-to-end work, cases, dependencies or received outcomes.

**Authority.** Enterprise/process coordinators maintain the map with local expertise; the architecture does not override functional or contractual authority.

**Interaction.** Local owners reconcile shared terms, boundaries and dependencies before treating components as independent.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: New shared resources, duplicated work, boundary disputes or changed interdependencies.

**Source keys:** `EBPM:S002`, `EBPM:S005`, `EBPM:S008`. **BWP relations:** 5, individually enumerated in the JSON record. **Clusters:** BWP-K033. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-067` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-068"></a>
### EBPM:EBPM-068 — Coupling warranted distinctions to authorised effects

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** yes.

**Bearer.** Evidence-to-authorised-action-to-observed-consequence relations for managed work

**Criterion.** A claim of improvement can be traced through warranted observation, an actual authorised intervention and its observed result, with missing links explicit.

**Trigger.** A model, analytic result or recommendation is proposed as sufficient justification for operational change or success.

**Non-trigger / cheaper path.** A small team can establish the links through a short case discussion, an existing decision-maker and direct outcome confirmation.

**Mechanism.** Keep three linked but non-equivalent claims explicit: evidence supports a distinction about work; an identified actor is authorised and able to intervene; observed consequences support an outcome judgement. Require the missing link to be established before promoting one claim into another.

**Authority.** Evidence producers do not acquire execution powers by analysis; authorised actors do not acquire factual correctness by holding office.

**Interaction.** Transfer the evidence, uncertainty and proposed action to the responsible actor, then return consequence evidence to the original judgement.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: A broken evidence/action/consequence link, contradiction or changed authority.

**Source keys:** `EBPM:S002`, `EBPM:S005`, `EBPM:S020`, `EBPM:S027`, `EBPM:S036`, `EBPM:S041`. **BWP relations:** 140, individually enumerated in the JSON record. **Clusters:** BWP-K001, BWP-K014, BWP-K019, BWP-K024, BWP-K032, BWP-K038. **Tensions:** BWP-T008.

**Rich record.** Select `key == EBPM:EBPM-068` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-069"></a>
### EBPM:EBPM-069 — Boundary-sensitive improvement acceptance

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** yes.

**Bearer.** Outcome/improvement claims over an affected-party consequence boundary

**Criterion.** The benefit claim is accepted, rejected or bounded to what the evidence supports, including unknown external effects.

**Trigger.** A redesign appears beneficial on one unit’s measures or changes who bears work and risk.

**Non-trigger / cheaper path.** For a simple isolated process, recipient confirmation and a small burden check may suffice.

**Mechanism.** Accept an improvement claim only over its declared consequence boundary and protected outcomes. A local gain remains qualified when material receiving-side burdens are unknown; do not aggregate away a harmed group or silently change the boundary to rescue the claim.

**Authority.** The party claiming benefit cannot unilaterally accept another party’s material burden as harmless.

**Interaction.** Exchange local gains and displaced costs with affected actors; preserve unresolved disagreements.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Displaced burden, scope change, new affected party or contradictory outcome evidence.

**Source keys:** `EBPM:S002`, `EBPM:S017`, `EBPM:S027`, `EBPM:S028`, `EBPM:S030`, `EBPM:S031`, `EBPM:S041`. **BWP relations:** 68, individually enumerated in the JSON record. **Clusters:** BWP-K002, BWP-K025, BWP-K038, BWP-K040. **Tensions:** BWP-T010.

**Rich record.** Select `key == EBPM:EBPM-069` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-070"></a>
### EBPM:EBPM-070 — Minimal sufficient portfolio of BPM machinery

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** yes.

**Bearer.** The jointly sufficient portfolio of BPM mechanisms, dependencies and costs

**Criterion.** The chosen configuration is coherent and justified, with omitted functions or unresolved dependencies explicit.

**Trigger.** A BPM method, model, role, assessment or platform is proposed, expanded or retained.

**Non-trigger / cheaper path.** Use existing coordination and a narrative/case review when adequate; no new BPM-branded artefact is required.

**Mechanism.** Select the smallest set of BPM mechanisms that jointly covers the actual purpose, evidence, authority and feedback needs. Evaluate shared functions and dependencies before adding artefacts, roles or tools; omit or retire machinery whose function is already adequately supplied or no longer needed.

**Authority.** The accountable consumer and affected actors judge adequacy; method specialists do not mandate tools merely because they are standard practice.

**Interaction.** Explain which failure each selected mechanism controls and which existing mechanism can substitute for it.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Lost consumer, changed risk, duplicate coverage, excessive burden or inadequate observed performance.

**Source keys:** `EBPM:S005`, `EBPM:S010`, `EBPM:S014`, `EBPM:S021`, `EBPM:S023`, `EBPM:S041`. **BWP relations:** 26, individually enumerated in the JSON record. **Clusters:** BWP-K026, BWP-K041. **Tensions:** BWP-T015, BWP-T016.

**Rich record.** Select `key == EBPM:EBPM-070` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-071"></a>
### EBPM:EBPM-071 — Coupled revision of representations and work

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** yes.

**Bearer.** Coupled but distinct revisions of representations, actual work, measures and hypotheses

**Criterion.** The revision’s type and operational consequences are explicit, with critical outstanding obligations preserved.

**Trigger.** Consequences or exceptions challenge the current process account or a revision is proposed.

**Non-trigger / cheaper path.** A local correction to a note may suffice when work and authority are unchanged; avoid reopening the entire portfolio for a representational typo.

**Mechanism.** Allow feedback to change a representation, the real work, the measure or the intervention hypothesis, but distinguish these acts. Review their consistency and continuity: updating a diagram does not change work, and changed work may require a revised account without implying improvement.

**Authority.** Modellers may revise descriptions within their remit; changing operational commitments or evaluation criteria requires the responsible authority.

**Interaction.** Tell performers and consumers what changed in work, representation, objectives or evidence and what remains unchanged.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Credible mismatch, recurring exception, changed objective or failed outcome hypothesis.

**Source keys:** `EBPM:S004`, `EBPM:S005`, `EBPM:S025`, `EBPM:S027`, `EBPM:S041`. **BWP relations:** 151, individually enumerated in the JSON record. **Clusters:** BWP-K021, BWP-K022, BWP-K025, BWP-K032, BWP-K036. **Tensions:** BWP-T002, BWP-T013.

**Rich record.** Select `key == EBPM:EBPM-071` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-072"></a>
### EBPM:EBPM-072 — Governed low-code participation and delivery

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Socio-technical enactment, automation or low-code delivery and actual received consequences

**Criterion.** A delivered application has demonstrated task fit and an identified support/authority arrangement for its real consequences.

**Trigger.** Non-specialists or decentralised teams build applications that affect process operation.

**Non-trigger / cheaper path.** Use a supported template or existing application; professional development may dominate where risk or integration complexity exceeds local capability.

**Mechanism.** Match low-code users’ skills, support, permitted scope and release authority to the consequences of the applications they build. Distinguish a simpler modelling interface from validated competence to change shared processes or sensitive data use.

**Authority.** A citizen developer may create within delegated scope; platform access does not confer authority over another function’s commitments or protected data.

**Interaction.** Developers, users, support/IT and process owners communicate requirements, limits, dependencies and operational problems.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Changed application scope, unsupported dependency, user mismatch or recurring operational defect.

**Source keys:** `EBPM:S044`, `EBPM:S045`, `EBPM:S046`, `EBPM:S047`. **BWP relations:** 65, individually enumerated in the JSON record. **Clusters:** BWP-K029, BWP-K031. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-072` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ebpm-ebpm-073"></a>
### EBPM:EBPM-073 — Consistent declarative constraints and history-compatible change

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Formal declarative constraints and history-compatible instance specifications

**Criterion.** Within the checked formal model, the stated consistency/history-compatibility result holds; no claim about unencoded harm or real-world correctness follows.

**Trigger.** A declarative process has interacting constraints or is changed while cases are in progress.

**Non-trigger / cheaper path.** For a few transparent constraints, competent manual checking may suffice; procedural or case-based alternatives may be easier for the actual users.

**Mechanism.** Where the chosen formalism supports it, check that the combined constraints admit appropriate executions and that a changed instance specification remains compatible with its recorded history. Separate formal satisfiability and dead-activity checks from the truth, completeness and legitimacy of the encoded constraints.

**Authority.** Analysts check encoded behaviour; accountable domain actors decide which constraints should apply and whether a departure is authorised.

**Interaction.** Explain conflicting constraints, blocked activities and history incompatibilities in terms domain actors can adjudicate.

**Retirement / omission.** Omit when the stated trigger is absent, an existing/cheaper mechanism supplies the required function, or its risk/consumer/dependency has disappeared. Reconsider on: Added/changed constraint, conflicting obligation, instance migration or unreliable history.

**Source keys:** `EBPM:S014`, `EBPM:S042`. **BWP relations:** 118, individually enumerated in the JSON record. **Clusters:** BWP-K008, BWP-K011, BWP-K021, BWP-K031. **Tensions:** none.

**Rich record.** Select `key == EBPM:EBPM-073` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

## EWM — 77 inherited rows

<a id="ewm-ewm-001"></a>
### EWM:EWM-001 — Identity separation: definition, instance, work item and external object

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Bindings among definition versions, instances, work items, messages and external business objects

**Criterion.** A sample event and an in-flight action can be traced to the intended instance and definition without ambiguous aliasing.

**Trigger.** Concurrent cases, retries, reused business keys, subtasks or definition changes can otherwise be confused.

**Non-trigger / cheaper path.** A single stable task may use a named record rather than an identifier service; omit separate identifiers when their lifecycles genuinely coincide.

**Mechanism.** Bind each transition to its definition version, case, work item and, where relevant, message attempt and external business object; do not substitute one identifier for all of them.

**Authority.** Identity locates an object; it grants no person or service permission to act on it.

**Interaction.** Exchange the case/work-item/version references needed by the recipient, without exposing unrelated personal data.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A single stable task may use a named record rather than an identifier service; omit separate identifiers when their lifecycles genuinely coincide.

**Source keys:** `EWM:EWM-S001`, `EWM:EWM-S002`, `EWM:EWM-S018`, `EWM:EWM-S026`, `EWM:EWM-S045`. **BWP relations:** 68, individually enumerated in the JSON record. **Clusters:** BWP-K003, BWP-K021, BWP-K032. **Tensions:** BWP-T005.

**Rich record.** Select `key == EWM:EWM-001` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-002"></a>
### EWM:EWM-002 — Explicit executable enabling and transition semantics

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Task enabling/transition predicates together with data, resource and action meaning

**Criterion.** The same tested state/event yields the specified enabled set and transition effect for the declared version.

**Trigger.** More than one next action is possible or correctness depends on order, conditionality or concurrency.

**Non-trigger / cheaper path.** For stable one-person work, a short conditional procedure with known next/completion conditions may suffice.

**Mechanism.** Define the state and event predicates that enable work and the transitions that consume or produce state; distinguish intended notation from the engine implementation.

**Authority.** Model-enabled does not mean authorised, feasible or beneficial.

**Interaction.** Publish the relevant preconditions and resulting state changes to actors who enact or review the transition.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. For stable one-person work, a short conditional procedure with known next/completion conditions may suffice.

**Source keys:** `EWM:EWM-S002`, `EWM:EWM-S004`, `EWM:EWM-S017`, `EWM:EWM-S027`, `EWM:EWM-S033`. **BWP relations:** 49, individually enumerated in the JSON record. **Clusters:** BWP-K007, BWP-K008. **Tensions:** BWP-T008.

**Rich record.** Select `key == EWM:EWM-002` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-003"></a>
### EWM:EWM-003 — Completion conditions and residual-work accounting

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Instance closure/termination and dispositions of residual work and external obligations

**Criterion.** No unaccounted active work remains under the chosen scope; the result claim states what was and was not established.

**Trigger.** Parallel work, exceptions, optional/discretionary items or external actions make completion ambiguous.

**Non-trigger / cheaper path.** A directly inspected result and an agreed completion criterion may replace a formal end-state model.

**Mechanism.** Declare what instance completion establishes, what work may remain and whether residual effects are closed, transferred or explicitly accepted; do not equate terminal status with success.

**Authority.** A permitted engine completion is not authority to dismiss somebody else’s unresolved obligation.

**Interaction.** Communicate the completion claim and its exclusions, including any approved transfer of remaining work.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A directly inspected result and an agreed completion criterion may replace a formal end-state model.

**Source keys:** `EWM:EWM-S004`, `EWM:EWM-S016`, `EWM:EWM-S017`, `EWM:EWM-S019`, `EWM:EWM-S041`, `EWM:EWM-S051`. **BWP relations:** 63, individually enumerated in the JSON record. **Clusters:** BWP-K017, BWP-K019. **Tensions:** BWP-T009.

**Rich record.** Select `key == EWM:EWM-003` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-004"></a>
### EWM:EWM-004 — Proportional choice of enactment infrastructure

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Selected workflow representation/enactment infrastructure and total fitness/cost

**Criterion.** The selected mechanism has an identified consumer and a stated omission/retirement condition.

**Trigger.** Choosing whether to introduce, expand or retire workflow machinery.

**Non-trigger / cheaper path.** No engine, a shared record, direct agreement or a short procedure can be adequate where concurrency, duration and recovery risk are small.

**Mechanism.** Select the least costly representation and enactment mechanism adequate to the actual coordination risk and its consumer; revisit it when risk or demand changes.

**Authority.** Technical elegance or a licence purchase does not authorise redesign of other people’s responsibilities.

**Interaction.** Explain which failure the mechanism controls, to whom, and why a cheaper alternative is insufficient.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. No engine, a shared record, direct agreement or a short procedure can be adequate where concurrency, duration and recovery risk are small.

**Source keys:** `EWM:EWM-S002`, `EWM:EWM-S009`, `EWM:EWM-S023`, `EWM:EWM-S025`, `EWM:EWM-S034`. **BWP relations:** 97, individually enumerated in the JSON record. **Clusters:** BWP-K001, BWP-K026. **Tensions:** BWP-T016.

**Rich record.** Select `key == EWM:EWM-004` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-005"></a>
### EWM:EWM-005 — Joint control, data, resource and action interpretation

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Task enabling/transition predicates together with data, resource and action meaning

**Criterion.** A consequential task’s required input, state, resource and effect assumptions can be examined together.

**Trigger.** A model is being used to justify real coordination rather than only illustrate a route.

**Non-trigger / cheaper path.** Keep perspectives in one concise task contract when separate models would duplicate information.

**Mechanism.** Interpret an enabled task jointly with its information inputs, eligible/available actor, interaction obligations and external effect boundary.

**Authority.** Eligibility, capability and authority are separate checks; the workflow cannot invent any of them.

**Interaction.** Provide the work item with the data, responsible party and unresolved dependencies needed to act.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Keep perspectives in one concise task contract when separate models would duplicate information.

**Source keys:** `EWM:EWM-S006`, `EWM:EWM-S007`, `EWM:EWM-S014`, `EWM:EWM-S015`, `EWM:EWM-S016`, `EWM:EWM-S034`. **BWP relations:** 54, individually enumerated in the JSON record. **Clusters:** BWP-K008, BWP-K014, BWP-K032. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-005` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-006"></a>
### EWM:EWM-006 — Decision guards with defined ambiguity and absence behaviour

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Task enabling/transition predicates together with data, resource and action meaning

**Criterion.** Tests cover true, false, multiple-match and missing-input cases with defined outcomes.

**Trigger.** Conditional routing, including human-entered or external data.

**Non-trigger / cheaper path.** A human resolves an infrequent ambiguous choice explicitly rather than maintaining a general rules engine.

**Mechanism.** Specify whether guards are mutually exclusive, priority-ordered or multi-selecting, and what unknown, missing, stale or conflicting values do.

**Authority.** An expression result permits only the modelled route, not a new permission to take the external action.

**Interaction.** Expose unresolved conditions rather than hiding them behind an arbitrary default.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A human resolves an infrequent ambiguous choice explicitly rather than maintaining a general rules engine.

**Source keys:** `EWM:EWM-S006`, `EWM:EWM-S014`, `EWM:EWM-S017`, `EWM:EWM-S051`. **BWP relations:** 32, individually enumerated in the JSON record. **Clusters:** BWP-K008. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-006` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-007"></a>
### EWM:EWM-007 — Activation-aware synchronisation and merge semantics

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Workflow control-flow, activation scopes, concurrency, repeated work and arbitration

**Criterion.** Adversarial traces with absent, late, duplicate and re-entered branches yield the specified convergence behaviour.

**Trigger.** Parallel or inclusive branching followed by convergence.

**Non-trigger / cheaper path.** A structured split/join pair or explicit list of launched tasks avoids a general non-local join when the work permits it.

**Mechanism.** Choose join semantics for the actual activation and re-entry model, specifying which branch arrivals are required, which remain possible and when the join resets.

**Authority.** Join firing establishes a coordination condition, not success of each outside action.

**Interaction.** Communicate branch activation/completion/cancellation information at the level required by the selected join.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A structured split/join pair or explicit list of launched tasks avoids a general non-local join when the work permits it.

**Source keys:** `EWM:EWM-S006`, `EWM:EWM-S013`, `EWM:EWM-S017`, `EWM:EWM-S024`, `EWM:EWM-S032`, `EWM:EWM-S051`. **BWP relations:** 54, individually enumerated in the JSON record. **Clusters:** BWP-K009, BWP-K010. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-007` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-008"></a>
### EWM:EWM-008 — Multiple-instance creation and completion accounting

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Workflow control-flow, activation scopes, concurrency, repeated work and arbitration

**Criterion.** The parent advances exactly under its declared threshold, with every remaining child accounted for.

**Trigger.** Fan-out work or repeated concurrent performance by a varying population.

**Non-trigger / cheaper path.** An ordinary bounded loop or fixed explicit set of tasks is cheaper when dynamic multiplicity is unnecessary.

**Mechanism.** Track distinct child instances, permitted dynamic creation, completion threshold and the disposition of remaining children after the threshold is reached.

**Authority.** Reaching a threshold does not authorise cancelling independently owned work or erasing its effects.

**Interaction.** Report child creation and completion with their parent activation and relevant status.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. An ordinary bounded loop or fixed explicit set of tasks is cheaper when dynamic multiplicity is unnecessary.

**Source keys:** `EWM:EWM-S006`, `EWM:EWM-S016`, `EWM:EWM-S017`, `EWM:EWM-S051`. **BWP relations:** 32, individually enumerated in the JSON record. **Clusters:** BWP-K009. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-008` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-009"></a>
### EWM:EWM-009 — Deferred choice and event-race arbitration

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Workflow control-flow, activation scopes, concurrency, repeated work and arbitration

**Criterion.** Near-simultaneous arrivals select behaviour consistent with the declared arbitration rule.

**Trigger.** Competing response, timeout, human choice or external signal.

**Non-trigger / cheaper path.** An explicit actor decision suffices when races are infrequent and responses can be safely held.

**Mechanism.** Define which events compete, how a winner is committed and how late losing events are ignored, rejected or routed to another valid state.

**Authority.** Winning an internal race does not retract a request already accepted elsewhere.

**Interaction.** Communicate winner, cancellation requests and unresolved late replies to their responsible parties.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. An explicit actor decision suffices when races are infrequent and responses can be safely held.

**Source keys:** `EWM:EWM-S006`, `EWM:EWM-S017`, `EWM:EWM-S026`, `EWM:EWM-S051`. **BWP relations:** 33, individually enumerated in the JSON record. **Clusters:** BWP-K009. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-009` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-010"></a>
### EWM:EWM-010 — Interleaving and mutual-exclusion requirements

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Workflow control-flow, activation scopes, concurrency, repeated work and arbitration

**Criterion.** Conflicting actions cannot overlap under the declared cross-case and external scope.

**Trigger.** Actions interfere through shared data, equipment or a required non-overlap rule.

**Non-trigger / cheaper path.** Serialise the small conflicting region or allocate independent resources rather than locking the entire process.

**Mechanism.** Identify the actual shared resource or invariant and exclude conflicting overlap at that scope while allowing irrelevant concurrency.

**Authority.** A per-case critical section does not automatically exclude other cases or independent applications.

**Interaction.** Expose who owns the protected scope and how release or recovery is established.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Serialise the small conflicting region or allocate independent resources rather than locking the entire process.

**Source keys:** `EWM:EWM-S006`, `EWM:EWM-S015`, `EWM:EWM-S018`, `EWM:EWM-S051`. **BWP relations:** 14, individually enumerated in the JSON record. **Clusters:** BWP-K009. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-010` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-011"></a>
### EWM:EWM-011 — Iteration, re-entry and recursive scope identity

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Workflow control-flow, activation scopes, concurrency, repeated work and arbitration

**Criterion.** Repetition and exit traces have defined state effects; a claimed termination guarantee has a stronger argument than one reachable exit.

**Trigger.** Rework, periodic interaction, recursive decomposition or repeated external inquiry.

**Non-trigger / cheaper path.** A bounded explicit repetition suffices when the number of iterations is known and small.

**Mechanism.** Distinguish repeated activations and recursive parent-child scopes, define exit conditions and separate the existence of an exit path from inevitable termination.

**Authority.** Re-entry does not renew expired external authority automatically.

**Interaction.** Carry iteration/parent identity and exit or interruption reason into dependent work.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A bounded explicit repetition suffices when the number of iterations is known and small.

**Source keys:** `EWM:EWM-S006`, `EWM:EWM-S007`, `EWM:EWM-S042`, `EWM:EWM-S051`. **BWP relations:** 35, individually enumerated in the JSON record. **Clusters:** BWP-K009, BWP-K010. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-011` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-012"></a>
### EWM:EWM-012 — Structured and unstructured model selection

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Workflow control-flow, activation scopes, concurrency, repeated work and arbitration

**Criterion.** The selected form represents the required cases without unexamined semantic translation.

**Trigger.** Choosing a representation for complex joins, cycles or nested cancellation.

**Non-trigger / cheaper path.** Use structured blocks where they express the task clearly; keep unstructured behaviour when forced restructuring would obscure or alter it.

**Mechanism.** Select a modelling form that preserves the needed behaviours and supports an affordable verification/explanation method.

**Authority.** Notation choice creates no operational authority.

**Interaction.** Explain preserved and excluded behaviours when changing representation.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Use structured blocks where they express the task clearly; keep unstructured behaviour when forced restructuring would obscure or alter it.

**Source keys:** `EWM:EWM-S006`, `EWM:EWM-S008`, `EWM:EWM-S013`, `EWM:EWM-S024`, `EWM:EWM-S032`, `EWM:EWM-S051`. **BWP relations:** 79, individually enumerated in the JSON record. **Clusters:** BWP-K004, BWP-K010, BWP-K031. **Tensions:** BWP-T004.

**Rich record.** Select `key == EWM:EWM-012` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-013"></a>
### EWM:EWM-013 — Cancellation-aware convergence of parallel work

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Workflow control-flow, activation scopes, concurrency, repeated work and arbitration

**Criterion.** The cancelled-branch test neither waits for an impossible arrival nor asserts an unachieved result.

**Trigger.** An interrupted branch can feed a later convergence point.

**Non-trigger / cheaper path.** Cancel the enclosing unit and restart or adjudicate it as a whole when selective continuation is unnecessary.

**Mechanism.** When a branch is cancelled, update join obligations according to the declared scope and activation rather than pretending that cancellation produced a success token.

**Authority.** Only the actor entitled to change the coordination obligation may dispense with a required branch.

**Interaction.** Signal whether the branch ceased, may still run, or left an unresolved outside effect.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Cancel the enclosing unit and restart or adjudicate it as a whole when selective continuation is unnecessary.

**Source keys:** `EWM:EWM-S008`, `EWM:EWM-S016`, `EWM:EWM-S017`, `EWM:EWM-S026`, `EWM:EWM-S051`. **BWP relations:** 46, individually enumerated in the JSON record. **Clusters:** BWP-K009, BWP-K017. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-013` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-014"></a>
### EWM:EWM-014 — Termination scopes and orphan-work disposition

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Instance closure/termination and dispositions of residual work and external obligations

**Criterion.** No active descendant or late reply is silently assigned an impossible parent lifecycle.

**Trigger.** Explicit terminate, case close, parent cancellation or disappearance of future enabled work.

**Non-trigger / cheaper path.** For a genuinely single task, an explicit final response can replace an elaborate termination protocol.

**Mechanism.** Specify the scope ended by termination and account for live children, subscriptions, pending work items and transferred external obligations.

**Authority.** An enclosing model can terminate only work within its effective control; external parties may need separate requests.

**Interaction.** Communicate termination scope and any accepted continuation/transfer.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. For a genuinely single task, an explicit final response can replace an elaborate termination protocol.

**Source keys:** `EWM:EWM-S017`, `EWM:EWM-S019`, `EWM:EWM-S026`, `EWM:EWM-S045`, `EWM:EWM-S051`. **BWP relations:** 62, individually enumerated in the JSON record. **Clusters:** BWP-K017, BWP-K019. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-014` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-015"></a>
### EWM:EWM-015 — Model-bounded classical workflow-net soundness

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Workflow-model verification, soundness quantifiers and proof/reduction assumptions

**Criterion.** A reproducible analysis or proof establishes precisely the selected structural guarantee.

**Trigger.** An ordinary WF-net abstraction is being used for structural assurance.

**Non-trigger / cheaper path.** For a trivial model, direct reachability reasoning or exhaustive small-state examination may suffice.

**Mechanism.** Check the exact WF-net definition: every reachable marking has some path to the final marking, final completion leaves no residual tokens, and every transition can occur in some execution.

**Authority.** A soundness verdict neither authorises tasks nor supplies resources, deadlines or successful external action.

**Interaction.** Report the checked net, marking, soundness definition and excluded environmental assumptions.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. For a trivial model, direct reachability reasoning or exhaustive small-state examination may suffice.

**Source keys:** `EWM:EWM-S004`, `EWM:EWM-S007`, `EWM:EWM-S008`. **BWP relations:** 48, individually enumerated in the JSON record. **Clusters:** BWP-K011, BWP-K030. **Tensions:** BWP-T009.

**Rich record.** Select `key == EWM:EWM-015` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-016"></a>
### EWM:EWM-016 — Soundness variant and progress-assumption selection

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Workflow-model verification, soundness quantifiers and proof/reduction assumptions

**Criterion.** Counterexamples distinguish “can finish”, “all chosen runs finish” and any multi-case guarantee.

**Trigger.** A claim extends from one case to many, from possible completion to inevitable progress, or to richer cancellation constructs.

**Non-trigger / cheaper path.** Use classical one-case soundness when it answers the actual question; do not demand stronger variants by prestige.

**Mechanism.** Select the initial population and quantifiers explicitly; add fairness, resource, time or ranking assumptions only when the required guarantee actually needs them.

**Authority.** Fairness assumptions concern execution policy/environment; a proof cannot compel a human to perform work.

**Interaction.** State the guarantee in quantifiers or equivalent precise language, not just “sound”.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Use classical one-case soundness when it answers the actual question; do not demand stronger variants by prestige.

**Source keys:** `EWM:EWM-S007`, `EWM:EWM-S008`, `EWM:EWM-S051`. **BWP relations:** 45, individually enumerated in the JSON record. **Clusters:** BWP-K011, BWP-K030. **Tensions:** BWP-T009.

**Rich record.** Select `key == EWM:EWM-016` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-017"></a>
### EWM:EWM-017 — Verification by state analysis, reduction and justified composition

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Workflow-model verification, soundness quantifiers and proof/reduction assumptions

**Criterion.** The verdict can be reproduced and its link to the enacted version explained.

**Trigger.** State interaction is too complex for reliable unaided inspection or consequences justify formal assurance.

**Non-trigger / cheaper path.** A reviewed small model or direct test may dominate heavyweight verification for low-risk bounded work.

**Mechanism.** Choose an analysis method that preserves the target property and record abstraction, reduction and compositional assumptions; complement it with implementation tests where needed.

**Authority.** Verification approves a stated model claim, not uncontrolled operational changes.

**Interaction.** Deliver the analysed artefact, property, method and limits alongside the verdict.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A reviewed small model or direct test may dominate heavyweight verification for low-risk bounded work.

**Source keys:** `EWM:EWM-S004`, `EWM:EWM-S005`, `EWM:EWM-S007`, `EWM:EWM-S008`, `EWM:EWM-S013`, `EWM:EWM-S033`. **BWP relations:** 58, individually enumerated in the JSON record. **Clusters:** BWP-K011, BWP-K031. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-017` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-018"></a>
### EWM:EWM-018 — Model-to-engine semantic correspondence

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Correspondence among model, interchange, engine and supported semantic level

**Criterion.** Used behaviours match their declared semantics under relevant fault, race and upgrade probes.

**Trigger.** A formal/specification claim is used to justify execution, interchange or upgrade.

**Non-trigger / cheaper path.** A small conformance test set for the used subset is often enough; exhaustive language support is unnecessary.

**Mechanism.** Check the employed constructs and combinations against actual engine/version behaviour, including regressions, extensions and replay constraints.

**Authority.** Product branding is not an authority to assert untested semantics.

**Interaction.** Expose the tested subset, deviations and version-specific exceptions to consumers of the model.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A small conformance test set for the used subset is often enough; exhaustive language support is unnecessary.

**Source keys:** `EWM:EWM-S017`, `EWM:EWM-S024`, `EWM:EWM-S027`, `EWM:EWM-S032`, `EWM:EWM-S033`. **BWP relations:** 99, individually enumerated in the JSON record. **Clusters:** BWP-K004, BWP-K007, BWP-K029, BWP-K032. **Tensions:** BWP-T012, BWP-T017.

**Rich record.** Select `key == EWM:EWM-018` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-019"></a>
### EWM:EWM-019 — Resource and time feasibility beyond control-flow soundness

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Resource/time feasibility and allocation/escalation for enabled work

**Criterion.** An unavailable-resource scenario produces a truthful wait/escalation/adaptation outcome rather than a false completion guarantee.

**Trigger.** Human/service capacity, calendars or deadlines determine whether work can progress.

**Non-trigger / cheaper path.** An explicit availability check or manual rescheduling may suffice for a small workload.

**Mechanism.** Assess whether eligible resources and time assumptions can support the enabled work, and specify what happens when they cannot.

**Authority.** Availability cannot be conjured by assigning a role; escalating does not grant competence or permission.

**Interaction.** Communicate waiting reason, expected availability and the decision needed to change it.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. An explicit availability check or manual rescheduling may suffice for a small workload.

**Source keys:** `EWM:EWM-S007`, `EWM:EWM-S015`, `EWM:EWM-S025`, `EWM:EWM-S034`, `EWM:EWM-S040`, `EWM:EWM-S049`. **BWP relations:** 154, individually enumerated in the JSON record. **Clusters:** BWP-K011, BWP-K012, BWP-K014, BWP-K023, BWP-K024, BWP-K038. **Tensions:** BWP-T008.

**Rich record.** Select `key == EWM:EWM-019` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-020"></a>
### EWM:EWM-020 — Data-flow defect detection and control-data consistency

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Task data flow, binding, ownership, freshness and concurrent-update semantics

**Criterion.** Tests or analysis cover each consequential input on normal, skipped and migrated paths.

**Trigger.** Data-dependent routing or action can proceed on a path lacking required information.

**Non-trigger / cheaper path.** A small typed form or explicit input checklist suffices when data flow is simple.

**Mechanism.** Check that every needed input is defined, appropriately scoped and usable when its consumer is enabled, including paths introduced by exceptions or change.

**Authority.** Readability of data does not grant permission to use it for an unrelated action.

**Interaction.** Expose input provenance and missing-input status to the consumer, not only a generic task-ready flag.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A small typed form or explicit input checklist suffices when data flow is simple.

**Source keys:** `EWM:EWM-S007`, `EWM:EWM-S014`, `EWM:EWM-S017`, `EWM:EWM-S021`, `EWM:EWM-S046`. **BWP relations:** 33, individually enumerated in the JSON record. **Clusters:** BWP-K008. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-020` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-021"></a>
### EWM:EWM-021 — Data scope, bindings, ownership and access

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Task data flow, binding, ownership, freshness and concurrent-update semantics

**Criterion.** The value read at a task boundary has a known scope, owner and binding time.

**Trigger.** Multiple activities or actors share data or pass it through subprocess/service boundaries.

**Non-trigger / cheaper path.** A single immutable task input/output document can replace general shared-variable infrastructure.

**Mechanism.** Define who reads/writes each relevant value, when binding occurs and whether values are copied, shared or referenced across scopes.

**Authority.** Workflow scope is not legal or organisational authority; access policy needs its own basis.

**Interaction.** Pass only the information needed for the action, with binding and freshness context.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A single immutable task input/output document can replace general shared-variable infrastructure.

**Source keys:** `EWM:EWM-S014`, `EWM:EWM-S018`, `EWM:EWM-S019`, `EWM:EWM-S039`. **BWP relations:** 79, individually enumerated in the JSON record. **Clusters:** BWP-K008, BWP-K020, BWP-K027, BWP-K041. **Tensions:** BWP-T014.

**Rich record.** Select `key == EWM:EWM-021` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-022"></a>
### EWM:EWM-022 — Case, message and business-object correlation

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Bindings among definition versions, instances, work items, messages and external business objects

**Criterion.** Late, duplicated, unmatched and ambiguous messages are associated or held according to declared rules.

**Trigger.** Asynchronous replies, overlapping cases, reused business keys or interorganisational messages.

**Non-trigger / cheaper path.** A verified human lookup is sufficient at low volume when ambiguity is explicitly resolved.

**Mechanism.** Validate correlation keys and their scopes before accepting a message or callback as a transition for a case; distinguish deduplication from correct association.

**Authority.** Correct routing neither authenticates the sender nor establishes its authority to request a change.

**Interaction.** Exchange the minimal contractually required correlation and sender/context evidence.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A verified human lookup is sufficient at low volume when ambiguity is explicitly resolved.

**Source keys:** `EWM:EWM-S018`, `EWM:EWM-S026`, `EWM:EWM-S038`, `EWM:EWM-S039`, `EWM:EWM-S045`. **BWP relations:** 35, individually enumerated in the JSON record. **Clusters:** BWP-K003, BWP-K020. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-022` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-023"></a>
### EWM:EWM-023 — Data-centric and interacting-object lifecycle coordination

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Interacting business-object states and data-centric lifecycle coordination

**Criterion.** A change in one object enables/constrains related work without losing its own identity or lifecycle obligations.

**Trigger.** Multiple related objects evolve asynchronously or work is naturally case/data-driven.

**Non-trigger / cheaper path.** An activity-centred process with explicit data bindings is preferable when it already represents the relationships clearly.

**Mechanism.** Use available case data or interacting business-object states to determine permissible work when a single activity route would hide essential relationships.

**Authority.** Object existence does not imply authority to modify its state.

**Interaction.** Communicate relevant object/state changes to affected task and case consumers.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. An activity-centred process with explicit data bindings is preferable when it already represents the relationships clearly.

**Source keys:** `EWM:EWM-S007`, `EWM:EWM-S022`, `EWM:EWM-S034`, `EWM:EWM-S039`. **BWP relations:** 18, individually enumerated in the JSON record. **Clusters:** BWP-K003. **Tensions:** BWP-T005.

**Rich record.** Select `key == EWM:EWM-023` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-024"></a>
### EWM:EWM-024 — Freshness and concurrent update control for routing data

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Task data flow, binding, ownership, freshness and concurrent-update semantics

**Criterion.** Races either preserve the declared consistency rule or become visible for retry/adjudication.

**Trigger.** Data may change between enablement, claim and external action, or concurrent children update shared values.

**Non-trigger / cheaper path.** Read-and-confirm immediately before a low-volume action or use immutable inputs instead of broad transactional machinery.

**Mechanism.** Choose binding/snapshot, conflict-detection or synchronisation rules sufficient for decisions that depend on mutable data; record when freshness cannot be established.

**Authority.** An engine cannot declare an external database current merely because its own copy is durable.

**Interaction.** Provide the version or freshness uncertainty on which the decision relies.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Read-and-confirm immediately before a low-volume action or use immutable inputs instead of broad transactional machinery.

**Source keys:** `EWM:EWM-S017`, `EWM:EWM-S018`, `EWM:EWM-S030`, `EWM:EWM-S039`. **BWP relations:** 32, individually enumerated in the JSON record. **Clusters:** BWP-K008. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-024` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-025"></a>
### EWM:EWM-025 — Role eligibility separated from operative authority

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Actor eligibility/authority/competence, work-item ownership and assignment constraints

**Criterion.** An assigned performer can explain and evidence the relevant eligibility and authority boundary.

**Trigger.** Work is assigned to roles, substitutes or automated principals.

**Non-trigger / cheaper path.** A known qualified individual with an explicit agreement may need no organisational directory integration.

**Mechanism.** Separate role eligibility, current authorisation, competence and availability; obtain each needed condition from an appropriate authority rather than from a worklist label.

**Authority.** Workflow assignment records do not create external legal, professional or organisational authority.

**Interaction.** Tell the performer what is offered, under whose delegation and with which constraints.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A known qualified individual with an explicit agreement may need no organisational directory integration.

**Source keys:** `EWM:EWM-S015`, `EWM:EWM-S019`, `EWM:EWM-S034`, `EWM:EWM-S040`. **BWP relations:** 88, individually enumerated in the JSON record. **Clusters:** BWP-K014, BWP-K024, BWP-K027, BWP-K038. **Tensions:** BWP-T008.

**Rich record.** Select `key == EWM:EWM-025` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-026"></a>
### EWM:EWM-026 — Work-item lifecycle and accountable ownership

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Actor eligibility/authority/competence, work-item ownership and assignment constraints

**Criterion.** The current responsible party and permitted next lifecycle transition are knowable for each consequential open item.

**Trigger.** Multiple potential performers, asynchronous human work, failure or reassignment.

**Non-trigger / cheaper path.** One accountable performer and a clear ready/done exchange can suffice when no claiming or handover race exists.

**Mechanism.** Use only the lifecycle states needed to establish current responsibility, exclusivity or permissible reassignment, and transition them consistently with the work being performed.

**Authority.** Owning a work item establishes coordination responsibility only within the assignment’s authority.

**Interaction.** Communicate claim, handover, suspension and completion in the terms required by other actors.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. One accountable performer and a clear ready/done exchange can suffice when no claiming or handover race exists.

**Source keys:** `EWM:EWM-S015`, `EWM:EWM-S016`, `EWM:EWM-S026`, `EWM:EWM-S045`. **BWP relations:** 39, individually enumerated in the JSON record. **Clusters:** BWP-K013, BWP-K014, BWP-K033. **Tensions:** BWP-T014.

**Rich record.** Select `key == EWM:EWM-026` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-027"></a>
### EWM:EWM-027 — Delegation and substitution without silently losing constraints

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Actor eligibility/authority/competence, work-item ownership and assignment constraints

**Criterion.** The delegate can continue or restart under an explicit valid state and assignment.

**Trigger.** Absence, workload balancing, specialist substitution or handover.

**Non-trigger / cheaper path.** Wait for the original performer when delay is cheaper and safer than transfer.

**Mechanism.** Check that reassignment preserves required duty constraints, state, information access and accountability, or explicitly define a safe restart.

**Authority.** Delegation may transfer coordination responsibility but cannot enlarge the delegator’s powers.

**Interaction.** Send what was done, what remains, applicable constraints and unresolved external effects.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Wait for the original performer when delay is cheaper and safer than transfer.

**Source keys:** `EWM:EWM-S015`, `EWM:EWM-S019`, `EWM:EWM-S040`. **BWP relations:** 28, individually enumerated in the JSON record. **Clusters:** BWP-K014. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-027` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-028"></a>
### EWM:EWM-028 — Capacity, calendars, priorities and escalation

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Resource/time feasibility and allocation/escalation for enabled work

**Criterion.** Long waits and overload lead to an accountable decision or an explicitly accepted service limitation.

**Trigger.** Competing cases or time-sensitive work contend for limited people or services.

**Non-trigger / cheaper path.** A visible queue and periodic human review suffice where load is modest and priorities stable.

**Mechanism.** Relate queue policy and escalation to actual capacity, calendars and service needs; surface starvation and overload rather than optimising only local throughput.

**Authority.** Escalation requests a decision; it does not authorise bypassing duty or competence requirements.

**Interaction.** Share queue condition and the reason for priority changes with affected performers.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A visible queue and periodic human review suffice where load is modest and priorities stable.

**Source keys:** `EWM:EWM-S015`, `EWM:EWM-S025`, `EWM:EWM-S034`, `EWM:EWM-S040`, `EWM:EWM-S049`. **BWP relations:** 96, individually enumerated in the JSON record. **Clusters:** BWP-K012, BWP-K023. **Tensions:** BWP-T010.

**Rich record.** Select `key == EWM:EWM-028` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-029"></a>
### EWM:EWM-029 — Duty constraints and assignment satisfiability

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Actor eligibility/authority/competence, work-item ownership and assignment constraints

**Criterion.** A proposed assignment satisfies the declared rules, or infeasibility is surfaced.

**Trigger.** Rules relate multiple task performers or sharply constrain who may act.

**Non-trigger / cheaper path.** Direct examination of a small assignment can replace a solver.

**Mechanism.** Check assignment satisfiability under the stated constraint language; recheck when users, roles or prior assignments change.

**Authority.** A satisfying assignment is permission-consistent in the model, not proof of current availability or real-world authority.

**Interaction.** Explain unsatisfied constraints rather than silently weakening them to make an assignment.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Direct examination of a small assignment can replace a solver.

**Source keys:** `EWM:EWM-S007`, `EWM:EWM-S015`, `EWM:EWM-S040`. **BWP relations:** 51, individually enumerated in the JSON record. **Clusters:** BWP-K014, BWP-K027. **Tensions:** BWP-T003.

**Rich record.** Select `key == EWM:EWM-029` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-030"></a>
### EWM:EWM-030 — Human task completion distinguished from achieved effect

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Performer declarations, commitments, recipient acceptance and established effects

**Criterion.** The completion evidence supports the exact claim being made, with unresolved uncertainty visible.

**Trigger.** A person can mark an item complete without the intended result occurring.

**Non-trigger / cheaper path.** For low-consequence trusted work, a declaration may be adequate evidence; do not mandate independent witnessing of everything.

**Mechanism.** Define what evidence is sufficient for the claimed result and distinguish performer declaration, recipient acceptance and independently established effect.

**Authority.** Acceptance is an authorised judgement within a stated scope, not a metaphysical guarantee or substitute for consent.

**Interaction.** State whether the item records a claim of performance, an acknowledgement or a verified outcome.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. For low-consequence trusted work, a declaration may be adequate evidence; do not mandate independent witnessing of everything.

**Source keys:** `EWM:EWM-S009`, `EWM:EWM-S019`, `EWM:EWM-S034`, `EWM:EWM-S041`, `EWM:EWM-S050`. **BWP relations:** 85, individually enumerated in the JSON record. **Clusters:** BWP-K002, BWP-K013, BWP-K019, BWP-K024, BWP-K035, BWP-K038. **Tensions:** BWP-T009.

**Rich record.** Select `key == EWM:EWM-030` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-031"></a>
### EWM:EWM-031 — Participatory discretion and coordination work outside the engine

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Participatory/flexible/declarative/case-based support with accountable discretion

**Criterion.** A legitimate unanticipated situation has an explicit route for judgement and feedback rather than only noncompliance labels.

**Trigger.** Knowledge-intensive work or observed workarounds reveal an inadequate representation.

**Non-trigger / cheaper path.** Direct coordination without an engine can be preferable for small, changing cooperative tasks.

**Mechanism.** Include participants in defining and revising workflow support, and provide a way to handle legitimate work outside the prescription without pretending it never happened.

**Authority.** Discretion has boundaries; recognising situated work does not authorise every deviation.

**Interaction.** Exchange reasons for exceptions, practical constraints and consequences with those affected.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Direct coordination without an engine can be preferable for small, changing cooperative tasks.

**Source keys:** `EWM:EWM-S009`, `EWM:EWM-S010`, `EWM:EWM-S011`, `EWM:EWM-S025`, `EWM:EWM-S034`, `EWM:EWM-S050`. **BWP relations:** 159, individually enumerated in the JSON record. **Clusters:** BWP-K005, BWP-K006, BWP-K015, BWP-K016, BWP-K027. **Tensions:** BWP-T001, BWP-T003, BWP-T007.

**Rich record.** Select `key == EWM:EWM-031` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-032"></a>
### EWM:EWM-032 — Anticipated exceptions with defined handlers

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Exception handlers, bounded repairs and interruption/cancellation scope

**Criterion.** The handler leaves a defined state from which permitted continuation or closure is clear.

**Trigger.** A foreseeable failure, deadline, escalation or interrupt can alter normal coordination.

**Non-trigger / cheaper path.** A documented operator response suffices when automated handling adds little benefit.

**Mechanism.** Specify detected exception classes, handler scope, allowed continuation and the resulting state of both current and dependent work.

**Authority.** The handler can only perform actions within its supplied authority and external capabilities.

**Interaction.** Convey exception type, affected scope and what recovery has or has not established.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A documented operator response suffices when automated handling adds little benefit.

**Source keys:** `EWM:EWM-S016`, `EWM:EWM-S017`, `EWM:EWM-S018`, `EWM:EWM-S026`. **BWP relations:** 54, individually enumerated in the JSON record. **Clusters:** BWP-K015, BWP-K017. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-032` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-033"></a>
### EWM:EWM-033 — Unanticipated deviation and repair with bounded authority

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Exception handlers, bounded repairs and interruption/cancellation scope

**Criterion.** Resumption or closure is tied to an intelligible accepted state, not merely a successful administrative edit.

**Trigger.** An exception is outside known handlers or a valid next step is not representable.

**Non-trigger / cheaper path.** Stop the affected activity and make a direct case-specific decision rather than installing a general adaptation subsystem.

**Mechanism.** Route unmodelled situations to an actor who can examine current state, authorise a bounded repair and record its consequences before resuming or revising the definition.

**Authority.** The ability to edit state is not permission to change business obligations or other people’s work.

**Interaction.** Record the deviation’s reason, authorisation and resulting state sufficiently for later actors to continue safely.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Stop the affected activity and make a direct case-specific decision rather than installing a general adaptation subsystem.

**Source keys:** `EWM:EWM-S009`, `EWM:EWM-S016`, `EWM:EWM-S021`, `EWM:EWM-S034`, `EWM:EWM-S036`, `EWM:EWM-S037`. **BWP relations:** 57, individually enumerated in the JSON record. **Clusters:** BWP-K006, BWP-K015, BWP-K016, BWP-K037. **Tensions:** BWP-T006, BWP-T013.

**Rich record.** Select `key == EWM:EWM-033` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-034"></a>
### EWM:EWM-034 — Interrupt versus non-interrupt semantics and cancellation scope

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Exception handlers, bounded repairs and interruption/cancellation scope

**Criterion.** The post-interrupt enabled work and unresolved running actions match the declared scope.

**Trigger.** Boundary events, cancellation requests, timeout escalation or user intervention.

**Non-trigger / cheaper path.** A direct stop/continue agreement may suffice for an immediately observable human task.

**Mechanism.** Specify whether the original work continues, what is cancelled or suspended, and how partial acknowledgement or inability to stop is represented.

**Authority.** A cancellation request is not control over an independent participant or an irreversible effect.

**Interaction.** Distinguish requested, acknowledged and observed interruption states where the distinction changes decisions.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A direct stop/continue agreement may suffice for an immediately observable human task.

**Source keys:** `EWM:EWM-S008`, `EWM:EWM-S016`, `EWM:EWM-S017`, `EWM:EWM-S026`, `EWM:EWM-S051`. **BWP relations:** 32, individually enumerated in the JSON record. **Clusters:** BWP-K017. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-034` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-035"></a>
### EWM:EWM-035 — Timeout interpreted as uncertainty rather than external failure

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Uncertain external effects, retries, compensation, reconciliation and residual obligations

**Criterion.** The committed-before-timeout case cannot silently produce an unjustified duplicate effect.

**Trigger.** A response is missing after an action may have been accepted or committed.

**Non-trigger / cheaper path.** Wait or query the authoritative service rather than immediately retrying when delay is safer than duplication.

**Mechanism.** Treat a timed-out action’s effect as unknown until the relevant protocol, idempotency boundary or reconciliation establishes what happened.

**Authority.** Timeout does not authorise a conflicting second action or unilateral reversal.

**Interaction.** Communicate “response absent/effect unknown” rather than “did not happen” when that is all the evidence supports.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Wait or query the authoritative service rather than immediately retrying when delay is safer than duplication.

**Source keys:** `EWM:EWM-S020`, `EWM:EWM-S026`, `EWM:EWM-S029`, `EWM:EWM-S044`. **BWP relations:** 32, individually enumerated in the JSON record. **Clusters:** BWP-K017, BWP-K018, BWP-K039. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-035` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-036"></a>
### EWM:EWM-036 — Compensation distinguished from rollback

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Uncertain external effects, retries, compensation, reconciliation and residual obligations

**Criterion.** The remedy’s achieved effect is distinguished from the original transaction’s state and from complete restoration.

**Trigger.** An earlier committed effect must be addressed after later failure or cancellation.

**Non-trigger / cheaper path.** Use a real atomic transaction inside a suitable boundary, or a case-specific remedial action, when those are cheaper and more faithful.

**Mechanism.** Describe compensation as another action with its own preconditions and result, and identify which effects it can offset rather than claim universal world restoration.

**Authority.** The original actor’s permission need not include permission to compensate; new approval may be required.

**Interaction.** Communicate original effect, proposed remedy and any residual differences.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Use a real atomic transaction inside a suitable boundary, or a case-specific remedial action, when those are cheaper and more faithful.

**Source keys:** `EWM:EWM-S016`, `EWM:EWM-S018`, `EWM:EWM-S020`, `EWM:EWM-S026`. **BWP relations:** 19, individually enumerated in the JSON record. **Clusters:** BWP-K018, BWP-K039. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-036` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-037"></a>
### EWM:EWM-037 — Compensation failure and irreversible residual obligations

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Uncertain external effects, retries, compensation, reconciliation and residual obligations

**Criterion.** Every claimed completed remedy has evidence; every other material residue has a visible accepted disposition.

**Trigger.** A compensator fails, an effect is irreversible, or a repair cannot finish before case closure.

**Non-trigger / cheaper path.** A named unresolved-obligation record and human decision can replace an automated compensation tree.

**Mechanism.** Track outstanding remedies and their uncertainty separately from the stopped process, with a permitted retry, alternative remedy, transfer or accepted residual outcome.

**Authority.** An engine cannot waive external commitments by deleting failed compensation state.

**Interaction.** Deliver the unresolved consequence and evidence to the actor able to decide its next disposition.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A named unresolved-obligation record and human decision can replace an automated compensation tree.

**Source keys:** `EWM:EWM-S016`, `EWM:EWM-S020`, `EWM:EWM-S029`, `EWM:EWM-S044`. **BWP relations:** 32, individually enumerated in the JSON record. **Clusters:** BWP-K017, BWP-K018. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-037` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-038"></a>
### EWM:EWM-038 — Orchestration and choreography with participant boundaries

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Participant workflows, message contracts and global interaction compatibility

**Criterion.** Every external action is attributed to the participant that can actually perform and answer for it.

**Trigger.** Work crosses independently controlled applications or organisations.

**Non-trigger / cheaper path.** A bilateral agreement and two simple local procedures may suffice without a global orchestration engine.

**Mechanism.** Declare which participant controls each action and what the global interaction view omits; keep local execution and shared communication contracts distinct.

**Authority.** No choreography picture creates a central authority; orchestration only controls its own effective scope.

**Interaction.** Exchange commitments, requests and acknowledgements at the agreed boundary rather than exposing unnecessary internal detail.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A bilateral agreement and two simple local procedures may suffice without a global orchestration engine.

**Source keys:** `EWM:EWM-S003`, `EWM:EWM-S018`, `EWM:EWM-S038`, `EWM:EWM-S050`. **BWP relations:** 27, individually enumerated in the JSON record. **Clusters:** BWP-K020, BWP-K033. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-038` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-039"></a>
### EWM:EWM-039 — Message contracts, delivery states and interaction compatibility

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Participant workflows, message contracts and global interaction compatibility

**Criterion.** Lost, duplicate, reordered or rejected messages have declared consequences for the local and shared states.

**Trigger.** An interaction’s success depends on more than local send completion.

**Non-trigger / cheaper path.** Acknowledged human exchange is adequate when volume and ambiguity do not warrant protocol machinery.

**Mechanism.** Define message types, correlation, ordering, error responses and the evidence needed for received, accepted, performed or satisfied states.

**Authority.** Receipt is not consent; acceptance must be made by an appropriate participant under the relevant rules.

**Interaction.** Exchange the distinctions the downstream decision consumes; avoid acknowledgements with unclear meaning.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Acknowledged human exchange is adequate when volume and ambiguity do not warrant protocol machinery.

**Source keys:** `EWM:EWM-S018`, `EWM:EWM-S026`, `EWM:EWM-S038`, `EWM:EWM-S045`, `EWM:EWM-S050`. **BWP relations:** 61, individually enumerated in the JSON record. **Clusters:** BWP-K019, BWP-K020, BWP-K032, BWP-K035. **Tensions:** BWP-T012.

**Rich record.** Select `key == EWM:EWM-039` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-040"></a>
### EWM:EWM-040 — Global compatibility beyond locally correct workflows

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Participant workflows, message contracts and global interaction compatibility

**Criterion.** A published-model-style locally-correct/global-deadlock counterexample is excluded or explicitly tolerated by the chosen protocol.

**Trigger.** Independent participants wait on or trigger one another.

**Non-trigger / cheaper path.** For a small bilateral exchange, enumerate the possible message orders and failure responses rather than use a general choreography tool.

**Mechanism.** Analyse the shared protocol and local behaviours together under explicit message ordering, delivery and partner assumptions; check global deadlocks and incompatible expectations.

**Authority.** Compatibility does not make an unwilling or unavailable participant cooperate.

**Interaction.** Agree the public sequence/partial-order constraints and how non-response or rejection is handled.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. For a small bilateral exchange, enumerate the possible message orders and failure responses rather than use a general choreography tool.

**Source keys:** `EWM:EWM-S004`, `EWM:EWM-S007`, `EWM:EWM-S038`. **BWP relations:** 44, individually enumerated in the JSON record. **Clusters:** BWP-K020, BWP-K032. **Tensions:** BWP-T017.

**Rich record.** Select `key == EWM:EWM-040` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-041"></a>
### EWM:EWM-041 — Interchange and portability at a declared semantic level

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Correspondence among model, interchange, engine and supported semantic level

**Criterion.** Representative used behaviour survives the intended interchange or its loss is accepted before reliance.

**Trigger.** Engine replacement, cross-tool exchange, outsourcing or avoiding lock-in.

**Non-trigger / cheaper path.** A maintained mapping or documented manual transition may be cheaper than requiring complete round-trip portability.

**Mechanism.** Declare the portability layer—diagram, interchange syntax, executable subset, data bindings or runtime interaction—and test the layer actually relied upon.

**Authority.** A standard name is not evidence of conformance at every layer or permission to move data.

**Interaction.** Communicate unsupported constructs, transformations and lost information explicitly.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A maintained mapping or documented manual transition may be cheaper than requiring complete round-trip portability.

**Source keys:** `EWM:EWM-S002`, `EWM:EWM-S003`, `EWM:EWM-S017`, `EWM:EWM-S018`, `EWM:EWM-S023`, `EWM:EWM-S033`. **BWP relations:** 110, individually enumerated in the JSON record. **Clusters:** BWP-K004, BWP-K007, BWP-K020, BWP-K031. **Tensions:** BWP-T012.

**Rich record.** Select `key == EWM:EWM-041` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-042"></a>
### EWM:EWM-042 — Durable instance state and crash-recovery continuity

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Durable/replay/migration continuity of an instance, governing version and external references

**Criterion.** Crash tests resume or safely adjudicate the declared instance without silently discarding established state.

**Trigger.** Execution outlives a process, machine or short database transaction.

**Non-trigger / cheaper path.** A single atomic transaction or restartable manual record suffices when the coordination has no consequential in-flight state.

**Mechanism.** Persist enough committed coordination state to resume the same instance claim after failure, with a declared boundary between durable orchestration and separately executed work.

**Authority.** Durability of an engine record does not establish the current state of an outside service.

**Interaction.** Preserve and expose the last established coordination state and any uncertain in-flight actions.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A single atomic transaction or restartable manual record suffices when the coordination has no consequential in-flight state.

**Source keys:** `EWM:EWM-S002`, `EWM:EWM-S020`, `EWM:EWM-S026`, `EWM:EWM-S027`, `EWM:EWM-S044`. **BWP relations:** 42, individually enumerated in the JSON record. **Clusters:** BWP-K018, BWP-K021. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-042` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-043"></a>
### EWM:EWM-043 — Retries and duplicate external-effect control

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Uncertain external effects, retries, compensation, reconciliation and residual obligations

**Criterion.** Repeated delivery or execution produces the declared business effect count, or ambiguity is surfaced rather than hidden.

**Trigger.** Lost responses, crashes, worker replacement or at-least-once delivery can repeat an action.

**Non-trigger / cheaper path.** Disable automatic retry and adjudicate the uncommon ambiguous case when the action has no safe repeat protocol.

**Mechanism.** Control repeated effects through a suitable combination of idempotency, deduplication with durable keys, atomic participation, rollback support or explicit reconciliation.

**Authority.** An orchestrator cannot impose idempotency on an uncooperative external service.

**Interaction.** Carry operation keys and distinguish retry attempts from new intended business operations.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Disable automatic retry and adjudicate the uncommon ambiguous case when the action has no safe repeat protocol.

**Source keys:** `EWM:EWM-S020`, `EWM:EWM-S026`, `EWM:EWM-S029`, `EWM:EWM-S044`. **BWP relations:** 19, individually enumerated in the JSON record. **Clusters:** BWP-K018, BWP-K039. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-043` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-044"></a>
### EWM:EWM-044 — Recovery reconciled with external applications

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Uncertain external effects, retries, compensation, reconciliation and residual obligations

**Criterion.** The next recovery step states which external facts are established and which remain uncertain.

**Trigger.** An action may have committed outside the persisted workflow transition or a human acted outside the system.

**Non-trigger / cheaper path.** An authoritative query or human confirmation may be more appropriate than a distributed transaction.

**Mechanism.** Reconcile intent, recorded acknowledgement and authoritative external outcome before a recovery decision that would otherwise assume the world matches engine history.

**Authority.** The reconciler may observe without being authorised to mutate; discrepancies require the right decision-maker.

**Interaction.** Exchange evidence of actual outcome, not merely duplicate copies of the original request.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. An authoritative query or human confirmation may be more appropriate than a distributed transaction.

**Source keys:** `EWM:EWM-S020`, `EWM:EWM-S026`, `EWM:EWM-S029`, `EWM:EWM-S041`, `EWM:EWM-S044`. **BWP relations:** 19, individually enumerated in the JSON record. **Clusters:** BWP-K018, BWP-K039. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-044` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-045"></a>
### EWM:EWM-045 — Deterministic replay boundary for nondeterministic work

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Durable/replay/migration continuity of an instance, governing version and external references

**Criterion.** Replaying a supported history under compatible code preserves the required command sequence.

**Trigger.** The selected runtime rebuilds orchestration by replay.

**Non-trigger / cheaper path.** A state-machine snapshot engine, explicit persisted state or a short transaction may not require this particular programming discipline.

**Mechanism.** Keep replay-sensitive decisions within the deterministic contract and isolate or record nondeterministic inputs and effects through the supported interfaces.

**Authority.** Replay consistency is not permission to repeat an external action or proof that its returned value was correct.

**Interaction.** Expose which values were recorded and which computations are re-executed.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A state-machine snapshot engine, explicit persisted state or a short transaction may not require this particular programming discipline.

**Source keys:** `EWM:EWM-S027`, `EWM:EWM-S028`, `EWM:EWM-S030`, `EWM:EWM-S044`. **BWP relations:** 64, individually enumerated in the JSON record. **Clusters:** BWP-K021, BWP-K031. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-045` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-046"></a>
### EWM:EWM-046 — Sufficient recovery history and bounded retention

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Durable/replay/migration continuity of an instance, governing version and external references

**Criterion.** The retained material supports the declared claims and no discarded material is silently assumed to exist.

**Trigger.** History growth, archival cost, long duration or retention-sensitive data.

**Non-trigger / cheaper path.** A compact snapshot plus necessary operation references may replace full event retention when its sufficiency is established.

**Mechanism.** Determine the minimum retained state, history and external references required for specified recovery, review and continuity claims; retire records only after those consumers and obligations are addressed.

**Authority.** This is not legal retention advice; applicable obligations must be supplied by the relevant authority.

**Interaction.** Communicate which reconstruction and verification claims survive compaction or retirement.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A compact snapshot plus necessary operation references may replace full event retention when its sufficiency is established.

**Source keys:** `EWM:EWM-S027`, `EWM:EWM-S030`, `EWM:EWM-S044`, `EWM:EWM-S045`. **BWP relations:** 119, individually enumerated in the JSON record. **Clusters:** BWP-K021, BWP-K026, BWP-K027, BWP-K028, BWP-K041. **Tensions:** BWP-T015, BWP-T016.

**Rich record.** Select `key == EWM:EWM-046` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-047"></a>
### EWM:EWM-047 — Running code-version and replay compatibility

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Durable/replay/migration continuity of an instance, governing version and external references

**Criterion.** Existing cases either continue under compatible semantics or undergo an explicit approved transition.

**Trigger.** Engine, code, dependency or workflow-definition changes while instances remain active.

**Non-trigger / cheaper path.** Pin old instances to the old version until they finish when that is safer and affordable.

**Mechanism.** Bind in-flight work to a compatible implementation/definition version and test upgrade or routing strategies against real persisted states before replacing them.

**Authority.** Deployment access does not authorise changing the meaning of commitments already made.

**Interaction.** Communicate version selection and exceptions to operators and dependent services.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Pin old instances to the old version until they finish when that is safer and affordable.

**Source keys:** `EWM:EWM-S027`, `EWM:EWM-S028`, `EWM:EWM-S030`, `EWM:EWM-S033`, `EWM:EWM-S044`. **BWP relations:** 25, individually enumerated in the JSON record. **Clusters:** BWP-K021. **Tensions:** BWP-T002.

**Rich record.** Select `key == EWM:EWM-047` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-048"></a>
### EWM:EWM-048 — State-sensitive running-instance migration

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Durable/replay/migration continuity of an instance, governing version and external references

**Criterion.** The migrated case has a valid current state and a permissible future under the new definition, with past external effects preserved as facts.

**Trigger.** An existing case is moved to a changed process rather than merely starting new cases differently.

**Non-trigger / cheaper path.** Leave the old case on its original definition or explicitly close/restart it with consequence accounting when migration adds no value.

**Mechanism.** Check the actual marking, data, completed work, pending interactions and relevant constraints when migrating an instance; a sound new definition alone is insufficient.

**Authority.** Migration permission must cover changed obligations, not just permission to edit a diagram.

**Interaction.** Explain what completed actions remain valid, what new work is required and how outstanding responses will be interpreted.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Leave the old case on its original definition or explicitly close/restart it with consequence accounting when migration adds no value.

**Source keys:** `EWM:EWM-S016`, `EWM:EWM-S021`, `EWM:EWM-S035`, `EWM:EWM-S036`. **BWP relations:** 86, individually enumerated in the JSON record. **Clusters:** BWP-K021, BWP-K022, BWP-K025, BWP-K036, BWP-K040. **Tensions:** BWP-T002, BWP-T013.

**Rich record.** Select `key == EWM:EWM-048` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-049"></a>
### EWM:EWM-049 — Definition coexistence and deployment selection

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Durable/replay/migration continuity of an instance, governing version and external references

**Criterion.** Every active instance has an explicit governing version and a valid update/retirement path.

**Trigger.** A definition changes but immediate migration of all cases is unnecessary or unsafe.

**Non-trigger / cheaper path.** Drain a short-lived workload before replacement when coexistence would cost more than a brief pause.

**Mechanism.** Declare deployment selection and permit coexistence where appropriate, with clear routing of new work, events and operators to the right version.

**Authority.** Coexistence must not silently violate externally required rule changes; those obligations need separate judgement.

**Interaction.** Publish which population follows which definition and when each version can retire.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Drain a short-lived workload before replacement when coexistence would cost more than a brief pause.

**Source keys:** `EWM:EWM-S021`, `EWM:EWM-S028`, `EWM:EWM-S030`, `EWM:EWM-S036`. **BWP relations:** 51, individually enumerated in the JSON record. **Clusters:** BWP-K021, BWP-K022, BWP-K036. **Tensions:** BWP-T002.

**Rich record.** Select `key == EWM:EWM-049` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-050"></a>
### EWM:EWM-050 — Flexibility by design, deviation, underspecification and change

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Participatory/flexible/declarative/case-based support with accountable discretion

**Criterion.** The selected strategy states what is variable, who decides and what evidence justifies the choice.

**Trigger.** Observed variation cannot be handled adequately by a single fixed route.

**Non-trigger / cheaper path.** Explicitly enumerate a few stable alternatives when that is clearer than a general adaptive mechanism.

**Mechanism.** Select the flexibility mechanism according to whether variation is anticipated, temporarily tolerated, deliberately left open or requires a changed definition/state.

**Authority.** Freedom to choose a next step does not authorise changing the constraints that make it acceptable.

**Interaction.** Distinguish case-specific deviation from a new general definition.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Explicitly enumerate a few stable alternatives when that is clearer than a general adaptive mechanism.

**Source keys:** `EWM:EWM-S009`, `EWM:EWM-S021`, `EWM:EWM-S025`, `EWM:EWM-S035`, `EWM:EWM-S036`. **BWP relations:** 96, individually enumerated in the JSON record. **Clusters:** BWP-K015, BWP-K022. **Tensions:** BWP-T013.

**Rich record.** Select `key == EWM:EWM-050` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-051"></a>
### EWM:EWM-051 — Declarative constraints with consistency and progress analysis

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Participatory/flexible/declarative/case-based support with accountable discretion

**Criterion.** The rule set admits the intended cases and rejects specified violations, including terminal response obligations.

**Trigger.** Many valid sequences share a small set of important constraints.

**Non-trigger / cheaper path.** Use an imperative route for stable routine sections or a short set of human-understood rules when a declarative engine adds no value.

**Mechanism.** Express necessary temporal/data constraints, analyse their consistency and progress implications, and explain which obligations remain pending before completion.

**Authority.** An allowed trace is not automatically authorised or wise; external powers remain separately supplied.

**Interaction.** Expose why an action is allowed/blocked and which obligations remain to be fulfilled.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Use an imperative route for stable routine sections or a short set of human-understood rules when a declarative engine adds no value.

**Source keys:** `EWM:EWM-S024`, `EWM:EWM-S032`, `EWM:EWM-S035`, `EWM:EWM-S036`. **BWP relations:** 63, individually enumerated in the JSON record. **Clusters:** BWP-K015, BWP-K031. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-051` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-052"></a>
### EWM:EWM-052 — Case handling based on available data and accountable discretion

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Participatory/flexible/declarative/case-based support with accountable discretion

**Criterion.** A non-predetermined but legitimate next step can be selected with an intelligible rationale and observable result.

**Trigger.** Knowledge-intensive cases whose next valid action depends on evolving context.

**Non-trigger / cheaper path.** An informal case record and an experienced worker may be adequate at low scale; stable work can remain prescribed.

**Mechanism.** Expose relevant case data and permissible operations so an accountable actor can select the next justified action without inventing a full predetermined sequence.

**Authority.** Discretion is exercised within the actor’s actual authority; broad data access is not automatically justified.

**Interaction.** Explain the chosen next action and relevant case changes sufficiently for collaboration and review.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. An informal case record and an experienced worker may be adequate at low scale; stable work can remain prescribed.

**Source keys:** `EWM:EWM-S022`, `EWM:EWM-S025`, `EWM:EWM-S034`, `EWM:EWM-S039`. **BWP relations:** 70, individually enumerated in the JSON record. **Clusters:** BWP-K015. **Tensions:** BWP-T003.

**Rich record.** Select `key == EWM:EWM-052` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-053"></a>
### EWM:EWM-053 — Discretionary case planning and explicit completion criteria

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Participatory/flexible/declarative/case-based support with accountable discretion

**Criterion.** A closed case states its actual outcome and selected-work disposition, not merely its engine lifecycle label.

**Trigger.** Case workers add or activate work during a case.

**Non-trigger / cheaper path.** A small case plan with explicit decisions can replace a full case-management notation.

**Mechanism.** Separate the available plan from selected work, declare who may add/activate items, and define completion without equating every terminal item state with success.

**Authority.** Planning tables express permitted roles in a model; they do not establish external authority.

**Interaction.** Communicate what was available, chosen, declined, completed or otherwise terminated.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A small case plan with explicit decisions can replace a full case-management notation.

**Source keys:** `EWM:EWM-S016`, `EWM:EWM-S019`, `EWM:EWM-S022`. **BWP relations:** 52, individually enumerated in the JSON record. **Clusters:** BWP-K015, BWP-K019. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-053` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-054"></a>
### EWM:EWM-054 — Late-bound worklets and contextual exception reuse

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Participatory/flexible/declarative/case-based support with accountable discretion

**Criterion.** The selected/replaced worklet is appropriate to the current context and leaves a usable parent state.

**Trigger.** Repeated contextual variation is better handled by reusable subworkflows than by one expanding monolithic route.

**Non-trigger / cheaper path.** A human-selected procedure or a small explicit variant list may be easier to maintain.

**Mechanism.** Select a bounded subworkflow for the current case context and preserve the selection rationale and exception precedence when extending the rule base.

**Authority.** The ability to add a worklet does not authorise changing parent commitments or external privileges.

**Interaction.** Explain the rule path and communicate input/output and exception expectations to the selected worklet.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A human-selected procedure or a small explicit variant list may be easier to maintain.

**Source keys:** `EWM:EWM-S034`, `EWM:EWM-S036`, `EWM:EWM-S037`. **BWP relations:** 22, individually enumerated in the JSON record. **Clusters:** BWP-K015. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-054` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-055"></a>
### EWM:EWM-055 — Execution histories with defined event semantics

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Execution histories, conformance/monitoring observations and event-to-world claims

**Criterion.** A reviewer can distinguish request, start, acknowledgement, completion and externally established effect where those distinctions matter.

**Trigger.** Later actors rely on an execution history rather than direct memory of the work.

**Non-trigger / cheaper path.** A concise result/decision record may suffice when detailed event reconstruction has no consumer.

**Mechanism.** Define event meaning, identity, ordering and observation scope so histories can support the particular recovery, monitoring or review question.

**Authority.** Logging access is not authority to observe every human activity or retain all personal data.

**Interaction.** Provide event definitions and known omissions along with the history.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A concise result/decision record may suffice when detailed event reconstruction has no consumer.

**Source keys:** `EWM:EWM-S027`, `EWM:EWM-S041`, `EWM:EWM-S043`, `EWM:EWM-S045`, `EWM:EWM-S049`. **BWP relations:** 150, individually enumerated in the JSON record. **Clusters:** BWP-K003, BWP-K005, BWP-K013, BWP-K025, BWP-K028, BWP-K032, BWP-K034, BWP-K040. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-055` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-056"></a>
### EWM:EWM-056 — Conformance observations as bounded evidence

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Execution histories, conformance/monitoring observations and event-to-world claims

**Criterion.** Conformance claims state what was observed and distinguish model, logging and real-work deviations.

**Trigger.** A workflow is being monitored or assessed against an expected model.

**Non-trigger / cheaper path.** Directly review a small set of consequential traces instead of imposing a general mining pipeline.

**Mechanism.** Check log-to-case/activity/order assumptions and the model’s intended scope before interpreting deviations or conformance as evidence about enactment.

**Authority.** A detected mismatch is a question for adjudication, not automatic authority to sanction or repair.

**Interaction.** Present the observed trace, alignment assumptions and plausible recording/model explanations.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Directly review a small set of consequential traces instead of imposing a general mining pipeline.

**Source keys:** `EWM:EWM-S009`, `EWM:EWM-S031`, `EWM:EWM-S043`, `EWM:EWM-S045`. **BWP relations:** 65, individually enumerated in the JSON record. **Clusters:** BWP-K016, BWP-K022, BWP-K037. **Tensions:** BWP-T001, BWP-T006.

**Rich record.** Select `key == EWM:EWM-056` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-057"></a>
### EWM:EWM-057 — Operational monitoring with a decision consumer

**Disposition:** `USEFUL_BUT_EASILY_GAMED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Execution histories, conformance/monitoring observations and event-to-world claims

**Criterion.** A material signal results in an appropriate decision, including justified non-intervention.

**Trigger.** Waiting, failures or resource use can be acted on before or after outcomes deteriorate.

**Non-trigger / cheaper path.** A visible queue and periodic review can replace dashboards and continuous instrumentation.

**Mechanism.** Connect each monitored quantity to a decision-maker and a possible action, while preserving scope, uncertainty and incentives.

**Authority.** Monitoring does not authorise intervention beyond the responsible actor’s powers.

**Interaction.** Communicate the actionable condition and competing explanations rather than only a red/green indicator.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A visible queue and periodic review can replace dashboards and continuous instrumentation.

**Source keys:** `EWM:EWM-S025`, `EWM:EWM-S031`, `EWM:EWM-S034`, `EWM:EWM-S045`, `EWM:EWM-S049`. **BWP relations:** 116, individually enumerated in the JSON record. **Clusters:** BWP-K001, BWP-K024, BWP-K030. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-057` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-058"></a>
### EWM:EWM-058 — Observation completeness and event-to-world correspondence

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Execution histories, conformance/monitoring observations and event-to-world claims

**Criterion.** The claim’s evidence boundary is visible and no external success is asserted solely from an inadequate internal event.

**Trigger.** Completion, conformance, recovery or effectiveness is inferred from internal history.

**Non-trigger / cheaper path.** A trustworthy participant report is sufficient when the consequence and risk justify it; independent sensing is not universal.

**Mechanism.** Identify the observation boundary and connect consequential claims to an appropriate external or participant source; preserve uncertainty when correspondence cannot be checked.

**Authority.** An observer need not have authority to act, and a model’s certainty cannot replace a participant’s legitimate judgement.

**Interaction.** State whether evidence concerns a recorded event, a communicated commitment or an observed consequence.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A trustworthy participant report is sufficient when the consequence and risk justify it; independent sensing is not universal.

**Source keys:** `EWM:EWM-S009`, `EWM:EWM-S031`, `EWM:EWM-S041`, `EWM:EWM-S045`, `EWM:EWM-S049`, `EWM:EWM-S050`. **BWP relations:** 141, individually enumerated in the JSON record. **Clusters:** BWP-K005, BWP-K025, BWP-K027, BWP-K028, BWP-K032, BWP-K034. **Tensions:** BWP-T014.

**Rich record.** Select `key == EWM:EWM-058` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-059"></a>
### EWM:EWM-059 — Scientific workflow provenance and reproducibility boundary

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Scientific workflow provenance, environments, execution and reproduction claims

**Criterion.** The claimed reproducibility level is supported by retained artefacts and a suitable result check, not just exit status.

**Trigger.** A scientific computation is shared, rerun or interpreted as evidence.

**Non-trigger / cheaper path.** A small script with pinned inputs and a clear method record may be adequate; a workflow suite is not compulsory.

**Mechanism.** Preserve the workflow, relevant input/dependency/environment identity and provenance needed for a declared rerun or result-comparison claim; choose an appropriate output oracle.

**Authority.** Workflow execution is not scientific authority and metadata completeness does not validate an inference.

**Interaction.** Share provenance and conditions of reuse, including known inaccessible or changing services.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A small script with pinned inputs and a clear method record may be adequate; a workflow suite is not compulsory.

**Source keys:** `EWM:EWM-S041`, `EWM:EWM-S042`, `EWM:EWM-S047`, `EWM:EWM-S048`. **BWP relations:** 69, individually enumerated in the JSON record. **Clusters:** BWP-K028, BWP-K031. **Tensions:** BWP-T015.

**Rich record.** Select `key == EWM:EWM-059` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-060"></a>
### EWM:EWM-060 — Scientific workflow execution under data and environment constraints

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Scientific workflow provenance, environments, execution and reproduction claims

**Criterion.** The execution claim includes resource/data assumptions and identifies unresolved external failures.

**Trigger.** Distributed data movement or heterogeneous resources dominate execution feasibility and cost.

**Non-trigger / cheaper path.** Local execution or a simple scheduler may dominate when data and resources are already co-located.

**Mechanism.** Model the data availability, placement, execution capability and failure/recovery boundary relevant to the scientific task, without equating a scheduler graph with the whole scientific process.

**Authority.** Scheduling authority is limited to allocated resources and permitted data movement.

**Interaction.** Expose execution-site, data-transfer and reported-error provenance to diagnosis and recovery consumers.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Local execution or a simple scheduler may dominate when data and resources are already co-located.

**Source keys:** `EWM:EWM-S041`, `EWM:EWM-S042`, `EWM:EWM-S044`, `EWM:EWM-S047`, `EWM:EWM-S049`. **BWP relations:** 41, individually enumerated in the JSON record. **Clusters:** BWP-K031. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-060` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-061"></a>
### EWM:EWM-061 — Low-code abstraction and portability limits

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Low-code/agent-produced workflow artefacts and their execution/semantic-environment boundaries

**Criterion.** Used behaviours and replacement costs are understood beyond the canvas appearance.

**Trigger.** A low-code/visual system is used for consequential automation or replacement is contemplated.

**Non-trigger / cheaper path.** A simple script or manual procedure may be clearer; visual tooling may also be the cheaper adequate option.

**Mechanism.** Inspect the used abstraction’s execution, data, extension and exit boundaries before relying on visual simplicity or claimed portability.

**Authority.** An accessible editor does not authorise the user to automate every connected action.

**Interaction.** Document the hidden boundaries and provide meaningful explanations to the people responsible for results.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A simple script or manual procedure may be clearer; visual tooling may also be the cheaper adequate option.

**Source keys:** `EWM:EWM-S017`, `EWM:EWM-S023`, `EWM:EWM-S025`, `EWM:EWM-S031`, `EWM:EWM-S033`. **BWP relations:** 146, individually enumerated in the JSON record. **Clusters:** BWP-K004, BWP-K029, BWP-K031. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-061` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-062"></a>
### EWM:EWM-062 — Agent-generated coordination under separately enforced constraints

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Low-code/agent-produced workflow artefacts and their execution/semantic-environment boundaries

**Criterion.** Invalid or unsubstantiated proposed actions can be rejected without relying on the same model’s assertion of safety.

**Trigger.** A learned component may change task selection, data interpretation or external action.

**Non-trigger / cheaper path.** Use a fixed route or a human decision where learned flexibility has no demonstrated value.

**Mechanism.** Treat generated routes or decisions as proposals under separately established semantic, authority, effect and observation constraints; distinguish configuration links from actual execution paths.

**Authority.** An agent’s generated instruction is not self-authorising; external permissions and approval remain separate.

**Interaction.** Expose the decision basis, selected action and unresolved uncertainty to the appropriate consumer.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Use a fixed route or a human decision where learned flexibility has no demonstrated value.

**Source keys:** `EWM:EWM-S030`, `EWM:EWM-S031`, `EWM:EWM-S033`, `EWM:EWM-S041`. **BWP relations:** 47, individually enumerated in the JSON record. **Clusters:** BWP-K024, BWP-K029. **Tensions:** BWP-T007.

**Rich record.** Select `key == EWM:EWM-062` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-063"></a>
### EWM:EWM-063 — Contextual economic and organisational effectiveness

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Contextual or generalised economic/organisational claims about workflow support

**Criterion.** The benefit claim fits its study design and setting and includes adverse or null outcomes.

**Trigger.** A business or organisational benefit claim justifies adoption or expansion.

**Non-trigger / cheaper path.** A bounded trial, credible baseline and participant review may be enough; do not require a large experiment for every small decision.

**Mechanism.** Evaluate the actual setting, comparison, implementation attrition and distribution of costs before claiming improvement attributable to workflow support.

**Authority.** A measured efficiency gain does not authorise shifting unacceptable burdens to others.

**Interaction.** Report who improved, who paid, what failed and what the comparison cannot establish.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A bounded trial, credible baseline and participant review may be enough; do not require a large experiment for every small decision.

**Source keys:** `EWM:EWM-S009`, `EWM:EWM-S025`, `EWM:EWM-S033`, `EWM:EWM-S034`. **BWP relations:** 222, individually enumerated in the JSON record. **Clusters:** BWP-K001, BWP-K002, BWP-K012, BWP-K023, BWP-K025, BWP-K026, BWP-K030. **Tensions:** BWP-T010, BWP-T011.

**Rich record.** Select `key == EWM:EWM-063` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-064"></a>
### EWM:EWM-064 — Workflow restricted universally to a serial pipeline or DAG

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Workflow control-flow, activation scopes, concurrency, repeated work and arbitration

**Criterion.** The representation no longer makes a universal acyclicity claim.

**Trigger.** The claim is tested when loops, concurrent races, cancellation or recurring operation are present.

**Non-trigger / cheaper path.** Use a DAG freely for an acyclic computation; do not add loops solely to demonstrate expressiveness.

**Mechanism.** No general mechanism survives this restriction; select a DAG only for a scope whose behaviour is genuinely acyclic, or label it a finite expansion of a richer process.

**Authority.** A tidy representation cannot redefine the real authority or responsibilities of participants.

**Interaction.** Disclose excluded behaviours and the relationship between an expansion and the governing model.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Use a DAG freely for an acyclic computation; do not add loops solely to demonstrate expressiveness.

**Source keys:** `EWM:EWM-S006`, `EWM:EWM-S013`, `EWM:EWM-S017`, `EWM:EWM-S035`, `EWM:EWM-S042`, `EWM:EWM-S051`. **BWP relations:** 31, individually enumerated in the JSON record. **Clusters:** BWP-K010. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-064` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-065"></a>
### EWM:EWM-065 — Unqualified exactly-once effects outside the declared cooperative boundary

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Uncertain external effects, retries, compensation, reconciliation and residual obligations

**Criterion.** The scope and assumptions are explicit; no blanket external exactly-once promise remains.

**Trigger.** An exactly-once label is offered as sufficient assurance for external actions.

**Non-trigger / cheaper path.** Use honest at-least-once or uncertain-outcome semantics plus reconciliation when stronger cooperation is unavailable.

**Mechanism.** Replace the unqualified claim with an explicit effect boundary and validated idempotency, rollback, persistence or participation assumptions.

**Authority.** No engine controls an arbitrary uncooperative external world.

**Interaction.** State which executions, outputs or effects the guarantee actually covers.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Use honest at-least-once or uncertain-outcome semantics plus reconciliation when stronger cooperation is unavailable.

**Source keys:** `EWM:EWM-S020`, `EWM:EWM-S026`, `EWM:EWM-S029`, `EWM:EWM-S044`. **BWP relations:** 9, individually enumerated in the JSON record. **Clusters:** BWP-K018. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-065` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-066"></a>
### EWM:EWM-066 — Diagram or conformance brand as sufficient correctness

**Disposition:** `CEREMONY_NOT_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Correspondence among model, interchange, engine and supported semantic level

**Criterion.** Presence of the artefact is no longer counted as evidence of untested correctness.

**Trigger.** A notation or product label substitutes for testing the behaviour being relied upon.

**Non-trigger / cheaper path.** An unbranded but precise procedure or tested subset can be adequate.

**Mechanism.** No independent correctness mechanism is supplied by the artefact’s presence; retain only the communication or executable-semantic function it demonstrably serves.

**Authority.** A badge or drawing confers no permission or verified outcome.

**Interaction.** Communicate actual supported semantics and limits instead of relying on branding.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. An unbranded but precise procedure or tested subset can be adequate.

**Source keys:** `EWM:EWM-S017`, `EWM:EWM-S023`, `EWM:EWM-S024`, `EWM:EWM-S033`. **BWP relations:** 63, individually enumerated in the JSON record. **Clusters:** BWP-K004, BWP-K007, BWP-K030. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-066` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-067"></a>
### EWM:EWM-067 — Sound target definition as sufficient safe migration

**Disposition:** `SUPERSEDED_BY_STRONGER_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Durable/replay/migration continuity of an instance, governing version and external references

**Criterion.** Definition-only soundness is no longer treated as the full migration criterion.

**Trigger.** Live migration is proposed for a partly completed case.

**Non-trigger / cheaper path.** Keep the old definition or perform a consciously adjudicated restart rather than assume target soundness is enough.

**Mechanism.** Supersede definition-only approval with EWM-048’s current-state, data and outstanding-interaction migration check.

**Authority.** An approved new model does not authorise rewriting facts about already performed work.

**Interaction.** Communicate the state transformation and its justification.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Keep the old definition or perform a consciously adjudicated restart rather than assume target soundness is enough.

**Source keys:** `EWM:EWM-S021`, `EWM:EWM-S035`, `EWM:EWM-S036`. **BWP relations:** 12, individually enumerated in the JSON record. **Clusters:** BWP-K021. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-067` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-068"></a>
### EWM:EWM-068 — Complete engine history as complete external truth

**Disposition:** `NO_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Execution histories, conformance/monitoring observations and event-to-world claims

**Criterion.** Claims are limited to the history’s actual coverage and evidence role.

**Trigger.** Log completeness is used to infer unobserved manual or downstream consequences.

**Non-trigger / cheaper path.** A scoped statement of what was recorded is sufficient where no stronger claim is needed.

**Mechanism.** No such general property exists; scope the history to observed events and couple stronger claims to appropriate external evidence.

**Authority.** An internal record cannot overrule facts or testimony it never observed merely by being durable.

**Interaction.** Communicate omissions and provenance rather than the word “complete” alone.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A scoped statement of what was recorded is sufficient where no stronger claim is needed.

**Source keys:** `EWM:EWM-S009`, `EWM:EWM-S031`, `EWM:EWM-S041`, `EWM:EWM-S045`, `EWM:EWM-S050`. **BWP relations:** 30, individually enumerated in the JSON record. **Clusters:** BWP-K005, BWP-K028. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-068` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-069"></a>
### EWM:EWM-069 — Compensation as universal restoration of the original world

**Disposition:** `NO_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Uncertain external effects, retries, compensation, reconciliation and residual obligations

**Criterion.** No unproved equivalence between compensated and original world states is asserted.

**Trigger.** Rollback language is applied to committed long-lived, human or irreversible effects.

**Non-trigger / cheaper path.** A real atomic rollback inside a suitable technical boundary is valid; outside it, use an explicit remedy or accepted residual outcome.

**Mechanism.** No universal inverse exists; record the compensator’s own effect and residual differences.

**Authority.** Permission to act once does not necessarily include permission to reverse or remedy.

**Interaction.** State what the remedy can and cannot restore.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A real atomic rollback inside a suitable technical boundary is valid; outside it, use an explicit remedy or accepted residual outcome.

**Source keys:** `EWM:EWM-S016`, `EWM:EWM-S020`, `EWM:EWM-S044`. **BWP relations:** 9, individually enumerated in the JSON record. **Clusters:** BWP-K018. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-069` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-070"></a>
### EWM:EWM-070 — Full pattern coverage as universal product-selection optimum

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Selected workflow representation/enactment infrastructure and total fitness/cost

**Criterion.** No choice is justified solely by the largest count or popularity.

**Trigger.** Pattern coverage is used for tool selection or maturity ranking.

**Non-trigger / cheaper path.** A small tested subset can be optimal when it meets the actual needs.

**Mechanism.** Replace feature-count maximisation with fit to required behaviours, semantic fidelity and total operating cost.

**Authority.** Feature counts do not authorise adoption or prove organisational benefit.

**Interaction.** Explain which needed cases each feature supports and the limitations of the support rating.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. A small tested subset can be optimal when it meets the actual needs.

**Source keys:** `EWM:EWM-S023`, `EWM:EWM-S024`, `EWM:EWM-S033`, `EWM:EWM-S051`. **BWP relations:** 46, individually enumerated in the JSON record. **Clusters:** BWP-K026, BWP-K030. **Tensions:** BWP-T016.

**Rich record.** Select `key == EWM:EWM-070` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-071"></a>
### EWM:EWM-071 — Automation as universal economic improvement

**Disposition:** `NO_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Contextual or generalised economic/organisational claims about workflow support

**Criterion.** Benefit claims are qualified to evidence and population rather than attributed universally to automation.

**Trigger.** Automation itself is presented as the cause or guarantee of improvement.

**Non-trigger / cheaper path.** No intervention or a simpler coordination change remains a valid comparator.

**Mechanism.** No universal improvement guarantee is established; use EWM-063’s contextual evaluation, retain measured gains and include failed implementations without treating organisational cancellation as proof of engine malfunction.

**Authority.** Efficiency rhetoric does not settle whose costs count or legitimise every organisational change.

**Interaction.** Report setting, comparison, attrition and adverse outcomes.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. No intervention or a simpler coordination change remains a valid comparator.

**Source keys:** `EWM:EWM-S009`, `EWM:EWM-S025`, `EWM:EWM-S033`, `EWM:EWM-S034`. **BWP relations:** 118, individually enumerated in the JSON record. **Clusters:** BWP-K002, BWP-K024, BWP-K025, BWP-K026. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-071` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-072"></a>
### EWM:EWM-072 — Indefinite retention of all execution events as universal obligation

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** History-retention policy and continuing recovery/evidence consumers

**Criterion.** Retention has a reasoned scope and retirement condition rather than an infinite default.

**Trigger.** History preservation is treated as an unconditional requirement independent of consumers and obligations.

**Non-trigger / cheaper path.** Keep only the necessary record, snapshot or operation references when their sufficiency is justified.

**Mechanism.** Replace unlimited retention with claim-relative sufficient state and a justified retirement rule.

**Authority.** This packet determines no legal retention period or permission to erase required records.

**Interaction.** State what remains verifiable after retention changes.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Keep only the necessary record, snapshot or operation references when their sufficiency is justified.

**Source keys:** `EWM:EWM-S027`, `EWM:EWM-S030`, `EWM:EWM-S045`. **BWP relations:** 59, individually enumerated in the JSON record. **Clusters:** BWP-K026, BWP-K027, BWP-K028. **Tensions:** BWP-T015.

**Rich record.** Select `key == EWM:EWM-072` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-073"></a>
### EWM:EWM-073 — Semantic-environment binding for durable AI execution

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Low-code/agent-produced workflow artefacts and their execution/semantic-environment boundaries

**Criterion.** Continuation states which environment it depends on and which compatibility claims remain assumptions.

**Trigger.** A long-lived learned workflow spans model, prompt, tool or retrieval changes that can alter meaning without changing control code.

**Non-trigger / cheaper path.** For a closed dependency set, pin the relevant environment or require explicit review at a change boundary. The inspected prototype also prevents its closed-world anomalies with static pinning; online extension is justified only by genuinely late-discovered dependencies and a valid compatibility contract.

**Mechanism.** Bind and disclose the environment needed to interpret a decision or continuation, and evaluate declared compatibility before combining outputs from changed environments.

**Authority.** A compatibility declaration is not proof of correctness and cannot authorise its own acceptance.

**Interaction.** Communicate relevant environment/version changes and the basis for accepting continued work.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. For a closed dependency set, pin the relevant environment or require explicit review at a change boundary. The inspected prototype also prevents its closed-world anomalies with static pinning; online extension is justified only by genuinely late-discovered dependencies and a valid compatibility contract.

**Source keys:** `EWM:EWM-S027`, `EWM:EWM-S028`, `EWM:EWM-S030`, `EWM:EWM-S031`. **BWP relations:** 96, individually enumerated in the JSON record. **Clusters:** BWP-K021, BWP-K022, BWP-K029, BWP-K032. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-073` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-074"></a>
### EWM:EWM-074 — Autonomous workflow optimisation with generally safe semantic preservation

**Disposition:** `UNRESOLVED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Unresolved general autonomous workflow optimisation capability

**Criterion.** Any accepted change has independent-of-proposal justification appropriate to its consequences; general safety remains unestablished.

**Trigger.** A learned optimiser changes definitions, tools, assignments or policies without case-by-case human authorship.

**Non-trigger / cheaper path.** Keep a fixed definition or human-reviewed bounded revision when general autonomy has not earned its cost.

**Mechanism.** Treat proposed optimisation as an unvalidated change requiring an external objective, semantic constraints, authority, evaluation and continuity checks; no general guarantee is supplied.

**Authority.** The optimiser cannot confer on itself the authority or criteria for accepting its own change.

**Interaction.** Expose proposed changes, preserved assumptions, measured consequences and unresolved risks.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Keep a fixed definition or human-reviewed bounded revision when general autonomy has not earned its cost.

**Source keys:** `EWM:EWM-S025`, `EWM:EWM-S030`, `EWM:EWM-S031`, `EWM:EWM-S033`, `EWM:EWM-S041`. **BWP relations:** 123, individually enumerated in the JSON record. **Clusters:** BWP-K023, BWP-K024, BWP-K029. **Tensions:** BWP-T007.

**Rich record.** Select `key == EWM:EWM-074` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-075"></a>
### EWM:EWM-075 — Closure accounting across work and external obligations

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** yes.

**Bearer.** Instance closure/termination and dispositions of residual work and external obligations

**Criterion.** The case may close without every action succeeding, but no material residue is silently recast as fulfilled.

**Trigger.** Local cancellation/completion can coexist with still-running work or unremedied effects.

**Non-trigger / cheaper path.** An explicit handover or acknowledged residual-obligation note can be sufficient; do not require one engine to own the whole world.

**Mechanism.** Before asserting closure, reconcile the local terminal state with the disposition of work and material external obligations: fulfilled, legitimately waived, transferred or explicitly unresolved under an accepted closure policy.

**Authority.** Local terminal status is not unilateral permission to waive another participant’s commitment.

**Interaction.** Communicate closure’s meaning and obtain the relevant acknowledgement for transferred obligations.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. An explicit handover or acknowledged residual-obligation note can be sufficient; do not require one engine to own the whole world.

**Source keys:** `EWM:EWM-S003`, `EWM:EWM-S016`, `EWM:EWM-S019`, `EWM:EWM-S020`, `EWM:EWM-S026`, `EWM:EWM-S041`, `EWM:EWM-S050`. **BWP relations:** 69, individually enumerated in the JSON record. **Clusters:** BWP-K002, BWP-K018, BWP-K019, BWP-K035. **Tensions:** BWP-T009.

**Rich record.** Select `key == EWM:EWM-075` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-076"></a>
### EWM:EWM-076 — Recovery continuity across version, instance and external references

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** yes.

**Bearer.** Durable/replay/migration continuity of an instance, governing version and external references

**Criterion.** The resumed case’s next action is justified by a coherent state/effect/version account or is explicitly held for adjudication.

**Trigger.** A crash or migration crosses a definition/code or external-interaction boundary.

**Non-trigger / cheaper path.** Continue the old version or perform a bounded manual reconciliation when a general automated migration/replay bridge is unnecessary.

**Mechanism.** Recover or revise an instance only with a coherent account of its governing version, current state, pending work, message/effect identities and known external outcomes.

**Authority.** Continuity does not grant authority to modify prior commitments or fabricate missing evidence.

**Interaction.** Transmit preserved identity and unresolved state across version, worker and organisation boundaries.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Continue the old version or perform a bounded manual reconciliation when a general automated migration/replay bridge is unnecessary.

**Source keys:** `EWM:EWM-S018`, `EWM:EWM-S021`, `EWM:EWM-S027`, `EWM:EWM-S028`, `EWM:EWM-S030`, `EWM:EWM-S044`, `EWM:EWM-S045`. **BWP relations:** 80, individually enumerated in the JSON record. **Clusters:** BWP-K021, BWP-K022, BWP-K032, BWP-K036, BWP-K039. **Tensions:** BWP-T013.

**Rich record.** Select `key == EWM:EWM-076` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="ewm-ewm-077"></a>
### EWM:EWM-077 — Explicit request, commitment, declaration and acceptance transitions

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Performer declarations, commitments, recipient acceptance and established effects

**Criterion.** Participants can distinguish what was requested, accepted, declared performed and accepted as satisfactory.

**Trigger.** Cooperative work depends on negotiated responsibilities rather than transport acknowledgement alone.

**Non-trigger / cheaper path.** Ordinary conversation and a clear confirmation can suffice; do not impose a four-form ritual on every exchange.

**Mechanism.** Use explicit request, commitment, declaration and acceptance distinctions when different participants need to agree what work is owed and whether it has been satisfied.

**Authority.** A recorded acceptance does not prove uncoerced consent, objective correctness or authority outside the relationship.

**Interaction.** Exchange the commitment and satisfaction conditions, including changed expectations and disagreement.

**Retirement / omission.** Retire or omit the extra machinery when the trigger, consumer or relevant dependency disappears, after settling/transferring the outstanding work or evidence that still relies on it. Ordinary conversation and a clear confirmation can suffice; do not impose a four-form ritual on every exchange.

**Source keys:** `EWM:EWM-S009`, `EWM:EWM-S018`, `EWM:EWM-S034`, `EWM:EWM-S050`. **BWP relations:** 30, individually enumerated in the JSON record. **Clusters:** BWP-K006, BWP-K019. **Tensions:** none.

**Rich record.** Select `key == EWM:EWM-077` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

## EPM — 84 inherited rows

<a id="epm-epm-001"></a>
### EPM:EPM-001 — Meaningful event identity

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Event records, source/extraction/lifecycle/order semantics and collection/format policies

**Criterion.** A sampled event can be traced to an intelligible recorded occurrence; ambiguous classes are excluded, bounded or clearly labelled in results.

**Trigger.** Any claim that interprets event labels or counts as activities, transitions or work.

**Non-trigger / cheaper path.** Reuse a tested event dictionary when the recording mechanism has not changed. For a question about recorded transactions only, explicitly narrow the claim instead of reconstructing an entire process.

**Mechanism.** For each event class, establish what happened or was recorded, by whom or what, at which lifecycle phase, and with what relation to an actual work episode. Test a small number of material examples against source-system behaviour and domain testimony; preserve unresolved alternatives rather than inventing execution semantics.

**Authority.** Analyst and domain participant decide whether an event class supports the proposed question; data custodians explain recording but do not determine organisational obligations. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange event definitions, source examples, extraction rules and unresolved recording ambiguities between the analyst and source/domain custodians. Specific receiving decision: Analyst and domain participant decide whether an event class supports the proposed question; data custodians explain recording but do not determine organisational obligations.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S001`, `EPM:EPM-S014`, `EPM:EPM-S016`, `EPM:EPM-S039`, `EPM:EPM-S045`. **BWP relations:** 100, individually enumerated in the JSON record. **Clusters:** BWP-K003, BWP-K005, BWP-K018, BWP-K032, BWP-K034, BWP-K039. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-001` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-002"></a>
### EPM:EPM-002 — Source provenance and trace-back

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Event records, source/extraction/lifecycle/order semantics and collection/format policies

**Criterion.** A reviewer can select a material finding and recover its contributing records and transformations, or see the exact provenance break.

**Trigger.** A result may be challenged, repeated, corrected or used for consequential action.

**Non-trigger / cheaper path.** A query identifier, immutable extract and short mapping may suffice for a one-off local analysis; a full enterprise provenance platform is not required.

**Mechanism.** Retain a feasible trace-back from a consequential output through selected events, source identifiers and extraction versions. Use protected pseudonymous keys where direct identifiers are unnecessary. Record which lineage edges cannot be reconstructed.

**Authority.** Analyst, data custodian and reviewer exchange the minimal trace evidence required to diagnose a result. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange event definitions, source examples, extraction rules and unresolved recording ambiguities between the analyst and source/domain custodians. Specific receiving decision: Analyst, data custodian and reviewer exchange the minimal trace evidence required to diagnose a result.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S001`, `EPM:EPM-S014`, `EPM:EPM-S016`, `EPM:EPM-S036`, `EPM:EPM-S045`. **BWP relations:** 90, individually enumerated in the JSON record. **Clusters:** BWP-K021, BWP-K027, BWP-K028. **Tensions:** BWP-T015.

**Rich record.** Select `key == EPM:EPM-002` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-003"></a>
### EPM:EPM-003 — Semantically justified extraction

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Event records, source/extraction/lifecycle/order semantics and collection/format policies

**Criterion.** The same declared source snapshot and extraction rule reproduce the analysis population and explain material count differences.

**Trigger.** Events are assembled from databases, APIs, status tables or multiple systems rather than directly supplied as a tested event log.

**Non-trigger / cheaper path.** A simple, documented query is adequate where one source already contains the required event semantics. Do not build a generic integration layer merely to perform one bounded query.

**Mechanism.** State extraction predicates, join cardinalities, event-to-source mappings and inclusion/exclusion rules. Check material counts and sample reconciliations against the operational sources; preserve a route back to excluded or unresolved records.

**Authority.** Data engineer and analyst agree on transformation meaning with the domain consumer; technical ownership of SQL does not authorise redefining the work. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange event definitions, source examples, extraction rules and unresolved recording ambiguities between the analyst and source/domain custodians. Specific receiving decision: Data engineer and analyst agree on transformation meaning with the domain consumer; technical ownership of SQL does not authorise redefining the work.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S014`, `EPM:EPM-S016`, `EPM:EPM-S024`, `EPM:EPM-S045`. **BWP relations:** 49, individually enumerated in the JSON record. **Clusters:** BWP-K003, BWP-K005, BWP-K028. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-003` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-004"></a>
### EPM:EPM-004 — Activity abstraction with retained mappings

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Activity abstraction and analytical representation suited to a consumer

**Criterion.** A material finding states its abstraction level and has a traceable mapping and sensitivity result.

**Trigger.** Raw logs are too fine, labels combine distinct tasks, or analysis must cross systems with different granularity.

**Non-trigger / cheaper path.** Use the native activity labels when they already answer the question. A small manually checked mapping can dominate an automated abstraction model.

**Mechanism.** Choose an activity vocabulary at the level of the decision, retain the mapping from raw observations to abstract events, and test whether material conclusions survive a plausible finer or coarser alternative. Treat an abstract event as a derived object, not a newly observed fact.

**Authority.** Analyst proposes abstraction; domain participants test whether the resulting distinctions are sufficient for the decision. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange event definitions, source examples, extraction rules and unresolved recording ambiguities between the analyst and source/domain custodians. Specific receiving decision: Analyst proposes abstraction; domain participants test whether the resulting distinctions are sufficient for the decision.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S001`, `EPM:EPM-S013`, `EPM:EPM-S014`, `EPM:EPM-S016`, `EPM:EPM-S039`, `EPM:EPM-S045`. **BWP relations:** 35, individually enumerated in the JSON record. **Clusters:** BWP-K004. **Tensions:** BWP-T004.

**Rich record.** Select `key == EPM:EPM-004` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-005"></a>
### EPM:EPM-005 — Lifecycle-aware event interpretation

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Event records, source/extraction/lifecycle/order semantics and collection/format policies

**Criterion.** Each reported interval identifies the events and lifecycle interpretation that establish its endpoints.

**Trigger.** Timing, utilisation, waiting, overlapping work or activity counts depend on lifecycle interpretation.

**Non-trigger / cheaper path.** Report elapsed time between recorded milestones when service-time evidence is absent; do not impute a work interval merely to fill a dashboard.

**Mechanism.** Identify lifecycle phases and pairing rules; separate enabled, started, suspended, resumed and completed states where actually observed. Compute service or waiting intervals only from phases whose meaning supports them, and label unobserved intervals as unknown.

**Authority.** Performance analyst and operational staff distinguish recorded elapsed time from effort before staffing or redesign decisions. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange event definitions, source examples, extraction rules and unresolved recording ambiguities between the analyst and source/domain custodians. Specific receiving decision: Performance analyst and operational staff distinguish recorded elapsed time from effort before staffing or redesign decisions.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S001`, `EPM:EPM-S039`, `EPM:EPM-S045`, `EPM:EPM-S048`, `EPM:EPM-S050`. **BWP relations:** 114, individually enumerated in the JSON record. **Clusters:** BWP-K008, BWP-K013, BWP-K017, BWP-K018, BWP-K019, BWP-K035, BWP-K039. **Tensions:** BWP-T009.

**Rich record.** Select `key == EPM:EPM-005` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-006"></a>
### EPM:EPM-006 — Ordering proportional to temporal evidence

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Event records, source/extraction/lifecycle/order semantics and collection/format policies

**Criterion.** A conclusion is either invariant across plausible orders or qualified by the orders on which it depends.

**Trigger.** Timestamp ties, mixed granularity, asynchronous systems, uncertain timestamps or consequential order-sensitive findings.

**Non-trigger / cheaper path.** Ignore order for an order-insensitive question, or flag the few ambiguous pairs instead of enumerating every possible trace.

**Mechanism.** Use the strongest ordering supported by the evidence: a total order where justified, an explicit partial order or bounded alternatives otherwise. Keep tie-breaking separate from observed chronology and test sensitivity when an algorithm requires a sequence.

**Authority.** Analyst exposes ordering alternatives to the consumer; system timestamps alone do not settle the real chronology. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange event definitions, source examples, extraction rules and unresolved recording ambiguities between the analyst and source/domain custodians. Specific receiving decision: Analyst exposes ordering alternatives to the consumer; system timestamps alone do not settle the real chronology.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S025`, `EPM:EPM-S039`, `EPM:EPM-S045`. **BWP relations:** 38, individually enumerated in the JSON record. **Clusters:** BWP-K009, BWP-K017. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-006` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-007"></a>
### EPM:EPM-007 — Quality repair without erasing uncertainty

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Event records, source/extraction/lifecycle/order semantics and collection/format policies

**Criterion.** Material repairs have reasons and consequences; users can identify which conclusions require the repair to be correct.

**Trigger.** Detected defects materially threaten the stated question, not merely because a quality metric is nonzero.

**Non-trigger / cheaper path.** Annotate an isolated uncertain record, narrow a claim, or tolerate a known harmless defect rather than rebuild the whole log.

**Mechanism.** Classify suspected defects, keep the original or a recoverable trace, justify each material repair, and compare important results with unrepaired or alternative treatments. Where correction is unsupported, carry uncertainty or decline the affected inference.

**Authority.** Analyst and data custodian review repair rules; domain participants distinguish atypical work from recording error. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange event definitions, source examples, extraction rules and unresolved recording ambiguities between the analyst and source/domain custodians. Specific receiving decision: Analyst and data custodian review repair rules; domain participants distinguish atypical work from recording error.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S016`, `EPM:EPM-S025`, `EPM:EPM-S039`, `EPM:EPM-S045`. **BWP relations:** 18, individually enumerated in the JSON record. **Clusters:** BWP-K028. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-007` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-008"></a>
### EPM:EPM-008 — Question-relative population adequacy

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Analytical target population, unit and observation/censoring process

**Criterion.** Reported denominators correspond to the declared unit, and material exclusions and generalisation limits are explicit.

**Trigger.** Generalisation, prevalence, compliance rates, resource comparison or prediction beyond the observed records.

**Non-trigger / cheaper path.** Restrict the claim to the observed extract when that is enough; a census of all organisational activity is not necessary for every local question.

**Mechanism.** Declare the target population and observation window; distinguish cases, events, objects and decision occasions; examine inclusion, censoring, unlogged work and changes in capture. Match the strength of a conclusion to the actual observation process.

**Authority.** The consumer accepts or rejects the bounded population claim; the analyst cannot expand it by reporting more decimal places. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange event definitions, source examples, extraction rules and unresolved recording ambiguities between the analyst and source/domain custodians. Specific receiving decision: The consumer accepts or rejects the bounded population claim; the analyst cannot expand it by reporting more decimal places.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S001`, `EPM:EPM-S016`, `EPM:EPM-S019`, `EPM:EPM-S020`, `EPM:EPM-S022`, `EPM:EPM-S045`, `EPM:EPM-S053`, `EPM:EPM-S056`. **BWP relations:** 103, individually enumerated in the JSON record. **Clusters:** BWP-K005, BWP-K018, BWP-K019, BWP-K025, BWP-K034, BWP-K035, BWP-K040. **Tensions:** BWP-T009.

**Rich record.** Select `key == EPM:EPM-008` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-009"></a>
### EPM:EPM-009 — Proportionate logging and collection

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Event records, source/extraction/lifecycle/order semantics and collection/format policies

**Criterion.** New collection has a stated use, bounded scope and retirement condition; unavailable detail remains an evidence limit.

**Trigger.** Proposed new instrumentation, richer identity attributes, prolonged retention or cross-organisational linkage.

**Non-trigger / cheaper path.** Use an existing coarse extract, a small sample, aggregates or no mining if they sufficiently answer the question.

**Mechanism.** Specify what uncertainty additional logging would reduce, compare it with burden and exposure, and collect only the granularity and retention needed for that purpose. Reassess the need when the consumer or risk changes.

**Authority.** Operational and data-governance decision makers authorise collection; analysts advise on informational value, not unilateral monitoring rights. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange event definitions, source examples, extraction rules and unresolved recording ambiguities between the analyst and source/domain custodians. Specific receiving decision: Operational and data-governance decision makers authorise collection; analysts advise on informational value, not unilateral monitoring rights.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S001`, `EPM:EPM-S016`, `EPM:EPM-S017`, `EPM:EPM-S040`. **BWP relations:** 72, individually enumerated in the JSON record. **Clusters:** BWP-K026, BWP-K027, BWP-K041. **Tensions:** BWP-T015, BWP-T016.

**Rich record.** Select `key == EPM:EPM-009` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-010"></a>
### EPM:EPM-010 — Syntactic validity as sufficient process truth

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Event records, source/extraction/lifecycle/order semantics and collection/format policies

**Criterion.** No assurance claim uses format conformity as sufficient evidence of the process or organisational reality.

**Trigger.** An analyst or consumer infers process truth from successful import, schema compliance or checksum agreement.

**Non-trigger / cheaper path.** Keep lightweight syntax checks as prerequisites and state their limited result; no replacement bureaucracy is needed.

**Mechanism.** Reject the sufficiency implication. Structural validity can be checked separately, but event meaning, extraction and representativeness still need their own evidence.

**Authority.** Data consumer must not accept technical parsing as semantic validation. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange event definitions, source examples, extraction rules and unresolved recording ambiguities between the analyst and source/domain custodians. Specific receiving decision: Data consumer must not accept technical parsing as semantic validation.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S014`, `EPM:EPM-S015`, `EPM:EPM-S024`, `EPM:EPM-S039`, `EPM:EPM-S045`. **BWP relations:** 24, individually enumerated in the JSON record. **Clusters:** BWP-K007, BWP-K028. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-010` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-011"></a>
### EPM:EPM-011 — Versioned event-data interoperability

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Event records, source/extraction/lifecycle/order semantics and collection/format policies

**Criterion.** Interchange retains the fields and relations required for the intended analysis, with any loss exposed.

**Trigger.** An analysis crosses tool, organisation, version or serialization boundaries.

**Non-trigger / cheaper path.** A simple documented table is adequate within a bounded analysis where no interchange requires a larger standard.

**Mechanism.** Record the exact data format, version, required extensions and interpretation conventions; test representative round trips or imports. Preserve semantic mappings when converting between case-centric and object-centric formats.

**Authority.** Data producer and tool consumer agree on accepted meanings and reject silent coercions. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange event definitions, source examples, extraction rules and unresolved recording ambiguities between the analyst and source/domain custodians. Specific receiving decision: Data producer and tool consumer agree on accepted meanings and reject silent coercions.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S014`, `EPM:EPM-S015`, `EPM:EPM-S016`, `EPM:EPM-S024`, `EPM:EPM-S036`. **BWP relations:** 65, individually enumerated in the JSON record. **Clusters:** BWP-K020, BWP-K021, BWP-K028. **Tensions:** BWP-T012.

**Rich record.** Select `key == EPM:EPM-011` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-012"></a>
### EPM:EPM-012 — Question-dependent case notion

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Analytical case/object identities, relations and projection multiplicities

**Criterion.** The chosen case notion is explicit and conclusions that change under alternatives are identified.

**Trigger.** Several plausible identifiers, hierarchical cases, or interactions between orders, items, deliveries and other objects.

**Non-trigger / cheaper path.** Use one established case identifier when it captures the required relation and produces no material flattening distortion.

**Mechanism.** Select a case notion according to the question and unit of responsibility; test relevant alternative correlations. When one case cannot retain required object interactions, keep a relational/object-centric representation instead of forcing a convenient identifier.

**Authority.** Analyst and domain consumer choose the unit; the database’s primary key is not an automatic answer to the business question. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange the chosen unit, object/identity relations, projection losses and model semantics with the consumer of the relation. Specific receiving decision: Analyst and domain consumer choose the unit; the database’s primary key is not an automatic answer to the business question.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S014`, `EPM:EPM-S026`, `EPM:EPM-S035`, `EPM:EPM-S050`. **BWP relations:** 63, individually enumerated in the JSON record. **Clusters:** BWP-K003, BWP-K020, BWP-K032. **Tensions:** BWP-T005.

**Rich record.** Select `key == EPM:EPM-012` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-013"></a>
### EPM:EPM-013 — Explicit typed object interactions

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Analytical case/object identities, relations and projection multiplicities

**Criterion.** A shared event can be counted once while its participating objects and their types remain recoverable.

**Trigger.** Interaction itself is needed to answer the question, including synchronisation, multi-object waiting or cross-case dependencies.

**Non-trigger / cheaper path.** A relational join or explicit shared-event table may be enough; an executable object-centric net is not mandatory.

**Mechanism.** Represent stable object identities and types, event–object participation and needed object–object relations; record qualifiers and temporal attribute changes when relevant. Preserve multiplicity instead of copying a shared event into fictional independent occurrences.

**Authority.** Data custodians establish identity conventions; analysts communicate relation meaning to the process consumer. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange the chosen unit, object/identity relations, projection losses and model semantics with the consumer of the relation. Specific receiving decision: Data custodians establish identity conventions; analysts communicate relation meaning to the process consumer.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S024`, `EPM:EPM-S026`, `EPM:EPM-S035`, `EPM:EPM-S043`, `EPM:EPM-S044`, `EPM:EPM-S050`. **BWP relations:** 75, individually enumerated in the JSON record. **Clusters:** BWP-K003, BWP-K009, BWP-K020, BWP-K027. **Tensions:** BWP-T005.

**Rich record.** Select `key == EPM:EPM-013` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-014"></a>
### EPM:EPM-014 — Flattening distortion checks

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Analytical case/object identities, relations and projection multiplicities

**Criterion.** Reported rework or duration claims identify whether projection duplicates events or changes the relation being measured.

**Trigger.** One-to-many, many-to-many or shared-object relations are projected into a single trace identifier.

**Non-trigger / cheaper path.** A small cardinality and trace sample check may establish that a chosen projection is harmless for this question.

**Mechanism.** Inspect shared-event multiplicities, object-to-case cardinalities and artificial directly-follows edges before interpreting a flattened log. Compare the relevant counts or timing in the original relation structure and the flattened view.

**Authority.** Analyst explains distortion to the consumer before a repeated record is interpreted as repeated work. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange the chosen unit, object/identity relations, projection losses and model semantics with the consumer of the relation. Specific receiving decision: Analyst explains distortion to the consumer before a repeated record is interpreted as repeated work.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S014`, `EPM:EPM-S026`, `EPM:EPM-S035`, `EPM:EPM-S050`. **BWP relations:** 32, individually enumerated in the JSON record. **Clusters:** BWP-K003, BWP-K009. **Tensions:** BWP-T005.

**Rich record.** Select `key == EPM:EPM-014` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-015"></a>
### EPM:EPM-015 — Object-centric discovery with model obligations

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Discovery procedure/model, language/bias, observational support and fragment/global claims

**Criterion.** The model’s formalism, supported constructs and scoped guarantee are stated without transfer to incompatible object models.

**Trigger.** The consumer needs executable or formally analysable object interactions rather than a descriptive relation map.

**Non-trigger / cheaper path.** Use an object-centric directly-follows view or a relational diagnostic when sound executable behaviour is not required.

**Mechanism.** Choose the exact object-centric formalism and required guarantee; distinguish type-level tokens from identifier-aware semantics and prove or test only the obligations that formalism states. Treat discovery, soundness and correspondence to real interactions as different claims.

**Authority.** Model analyst establishes formal properties; domain participants check identity interpretations; neither formal result grants intervention authority. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange the chosen unit, object/identity relations, projection losses and model semantics with the consumer of the relation. Specific receiving decision: Model analyst establishes formal properties; domain participants check identity interpretations; neither formal result grants intervention authority.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S026`, `EPM:EPM-S035`, `EPM:EPM-S043`, `EPM:EPM-S044`, `EPM:EPM-S050`. **BWP relations:** 42, individually enumerated in the JSON record. **Clusters:** BWP-K011, BWP-K031. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-015` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-016"></a>
### EPM:EPM-016 — Representation complexity as a selection cost

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Activity abstraction and analytical representation suited to a consumer

**Criterion.** The selected representation has a stated advantage over a cheaper adequate alternative and a known loss boundary.

**Trigger.** Choice between case-centric, object-centric, declarative, local, high-level or executable representations.

**Non-trigger / cheaper path.** Retain a tested existing view when added expressiveness would not change a decision.

**Mechanism.** Compare candidate representations against the actual distinction required, data availability, interpretation burden and computational cost. Prefer the least costly representation that preserves the consequential relation, not necessarily the fewest nodes.

**Authority.** Analyst and consumer jointly select a representation; maximal expressiveness is not a delegated objective. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange the chosen unit, object/identity relations, projection losses and model semantics with the consumer of the relation. Specific receiving decision: Analyst and consumer jointly select a representation; maximal expressiveness is not a delegated objective.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S013`, `EPM:EPM-S016`, `EPM:EPM-S026`, `EPM:EPM-S035`. **BWP relations:** 45, individually enumerated in the JSON record. **Clusters:** BWP-K004, BWP-K026. **Tensions:** BWP-T004.

**Rich record.** Select `key == EPM:EPM-016` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-017"></a>
### EPM:EPM-017 — Activity-level refinement as a separate obligation

**Disposition:** `DUPLICATE_CANDIDATE`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Activity abstraction and analytical representation suited to a consumer

**Criterion.** EPM-017 remains visible and links to EPM-004; only the latter exports the mechanism as a retained candidate.

**Trigger.** Later synthesis encounters activity refinement under a second label.

**Non-trigger / cheaper path.** Reuse EPM-004 and keep the additional contextual link.

**Mechanism.** Resolve this candidate to EPM-004. Its activity-level trigger and protected failure are identical; preserve the PM2 provenance and avoid creating another mechanism or audit obligation.

**Authority.** Corpus reviewer maintains the denominator while avoiding double counting. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange the chosen unit, object/identity relations, projection losses and model semantics with the consumer of the relation. Specific receiving decision: Corpus reviewer maintains the denominator while avoiding double counting.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S001`, `EPM:EPM-S013`, `EPM:EPM-S016`. **BWP relations:** 28, individually enumerated in the JSON record. **Clusters:** BWP-K004. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-017` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-018"></a>
### EPM:EPM-018 — Universal superiority of object-centricity

**Disposition:** `NO_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Analytical case/object identities, relations and projection multiplicities

**Criterion.** No universal migration requirement is exported from this candidate.

**Trigger.** A proposal asserts that every mining analysis should be object-centric.

**Non-trigger / cheaper path.** Use EPM-012 and EPM-016 to select the representation without an obligatory migration.

**Mechanism.** Reject unconditional superiority. Select object-centric methods where retaining relationships changes the inquiry; otherwise preserve simpler case or relational views.

**Authority.** Consumer decides whether added relations are worth their acquisition and interpretation burden. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange the chosen unit, object/identity relations, projection losses and model semantics with the consumer of the relation. Specific receiving decision: Consumer decides whether added relations are worth their acquisition and interpretation burden.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S016`, `EPM:EPM-S024`, `EPM:EPM-S026`, `EPM:EPM-S035`, `EPM:EPM-S043`, `EPM:EPM-S044`. **BWP relations:** 14, individually enumerated in the JSON record. **Clusters:** BWP-K031. **Tensions:** BWP-T005.

**Rich record.** Select `key == EPM:EPM-018` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-019"></a>
### EPM:EPM-019 — Explicit discovery and representation bias

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Discovery procedure/model, language/bias, observational support and fragment/global claims

**Criterion.** Each model is accompanied by a scoped claim: what it represents, what its construction guarantees and what remains hypothetical.

**Trigger.** Any automatically or semi-automatically discovered process model.

**Non-trigger / cheaper path.** For a directly-follows summary, state that it is a relation summary and do not claim executable semantics or complete process recovery.

**Mechanism.** State the model language, search space, objective, noise handling and assumptions before interpreting discovered structure. Separate properties guaranteed by construction from properties inferred from the sample and from domain claims requiring external evidence.

**Authority.** Model producer communicates inductive bias to the analyst and decision consumer. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate the representation, discovery bias, filtering and guarantee scope; keep domain-supplied knowledge distinguishable from mined evidence. Specific receiving decision: Model producer communicates inductive bias to the analyst and decision consumer.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S002`, `EPM:EPM-S005`, `EPM:EPM-S007`, `EPM:EPM-S008`, `EPM:EPM-S011`, `EPM:EPM-S019`, `EPM:EPM-S038`, `EPM:EPM-S053`, `EPM:EPM-S056`. **BWP relations:** 61, individually enumerated in the JSON record. **Clusters:** BWP-K007, BWP-K010, BWP-K011, BWP-K030. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-019` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-020"></a>
### EPM:EPM-020 — Alpha as the default general-purpose miner

**Disposition:** `SUPERSEDED_BY_STRONGER_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Discovery procedure/model, language/bias, observational support and fragment/global claims

**Criterion.** Use of alpha is justified by scope or a baseline purpose rather than universal recovery claims.

**Trigger.** Choice of a default miner for heterogeneous real event data.

**Non-trigger / cheaper path.** Alpha can remain adequate for a small didactic or controlled log within its assumptions; replacement is not mandatory merely because a method is old.

**Mechanism.** Do not use original alpha as the universal default. Retain it as an explanatory baseline or for inputs satisfying its scoped conditions; select extensions or alternative miners according to the actual noise, loops and construct requirements.

**Authority.** Analyst selects the method; foundational status is not evidence that it is the best operational choice. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate the representation, discovery bias, filtering and guarantee scope; keep domain-supplied knowledge distinguishable from mined evidence. Specific receiving decision: Analyst selects the method; foundational status is not evidence that it is the best operational choice.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S005`, `EPM:EPM-S006`, `EPM:EPM-S007`, `EPM:EPM-S019`, `EPM:EPM-S031`. **BWP relations:** 23, individually enumerated in the JSON record. **Clusters:** BWP-K010, BWP-K031. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-020` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-021"></a>
### EPM:EPM-021 — Heuristic discovery with threshold sensitivity

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Discovery procedure/model, language/bias, observational support and fragment/global claims

**Criterion.** The resulting model identifies its filtering settings and important conclusions are checked against plausible alternatives.

**Trigger.** Noisy event logs where frequent behaviour is the object of analysis and approximate discovery is acceptable.

**Non-trigger / cheaper path.** A transparent frequency table or unfiltered directly-follows graph may be enough for a descriptive question.

**Mechanism.** Use frequency-sensitive dependency estimates and thresholds to obtain a useful model; disclose threshold choices and inspect the behaviour removed or changed. Re-evaluate material low-frequency paths rather than classifying all of them as noise.

**Authority.** Analyst proposes thresholds; domain consumer decides whether suppressed behaviour is important. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate the representation, discovery bias, filtering and guarantee scope; keep domain-supplied knowledge distinguishable from mined evidence. Specific receiving decision: Analyst proposes thresholds; domain consumer decides whether suppressed behaviour is important.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S006`, `EPM:EPM-S019`, `EPM:EPM-S053`. **BWP relations:** 54, individually enumerated in the JSON record. **Clusters:** BWP-K015, BWP-K031. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-021` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-022"></a>
### EPM:EPM-022 — Sound-by-construction inductive discovery

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Discovery procedure/model, language/bias, observational support and fragment/global claims

**Criterion.** The reported guarantee names the model class and does not equate soundness with truth, precision or normative correctness.

**Trigger.** A sound executable model is needed and a block-structured model is an acceptable abstraction.

**Non-trigger / cheaper path.** Use a relation map or selected constraints when executable semantics add no useful distinction.

**Mechanism.** Use a sound-by-construction structured representation where its expressiveness is adequate; distinguish the construction’s soundness guarantee from conditions for rediscovery and from correspondence to actual work. Record fall-through or noise-handling choices that affect the result.

**Authority.** Algorithm establishes its scoped construction property; analyst and domain consumer judge whether the representation fits the question. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate the representation, discovery bias, filtering and guarantee scope; keep domain-supplied knowledge distinguishable from mined evidence. Specific receiving decision: Algorithm establishes its scoped construction property; analyst and domain consumer judge whether the representation fits the question.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S007`, `EPM:EPM-S019`, `EPM:EPM-S053`, `EPM:EPM-S056`. **BWP relations:** 58, individually enumerated in the JSON record. **Clusters:** BWP-K010, BWP-K011, BWP-K031. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-022` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-023"></a>
### EPM:EPM-023 — Region and ILP discovery

**Disposition:** `DOMAIN_SPECIFIC`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Discovery procedure/model, language/bias, observational support and fragment/global claims

**Criterion.** The result identifies the constraint problem solved and the assumptions needed to interpret its solution.

**Trigger.** The process question benefits from a Petri-net representation and the available computational budget permits region/ILP search.

**Non-trigger / cheaper path.** A simpler structured or heuristic miner is adequate when it preserves the relevant behaviour at lower cost.

**Mechanism.** Formulate candidate regions and place constraints as an optimisation/synthesis problem; choose objective, admissible regions and noise treatment explicitly, then inspect the behavioural implications of the resulting net.

**Authority.** Model analyst chooses the formal objective; a solver’s optimum is not an organisational objective by default. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate the representation, discovery bias, filtering and guarantee scope; keep domain-supplied knowledge distinguishable from mined evidence. Specific receiving decision: Model analyst chooses the formal objective; a solver’s optimum is not an organisational objective by default.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S008`, `EPM:EPM-S019`, `EPM:EPM-S053`. **BWP relations:** 57, individually enumerated in the JSON record. **Clusters:** BWP-K010, BWP-K011, BWP-K031. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-023` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-024"></a>
### EPM:EPM-024 — Declarative discovery with activation and consistency checks

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Discovery procedure/model, language/bias, observational support and fragment/global claims

**Criterion.** A reported constraint includes its activation basis, scope and interpretation, not just a high support number.

**Trigger.** Flexible or knowledge-intensive processes where a small set of behavioural restrictions is more informative than a procedural model.

**Non-trigger / cheaper path.** A few manually specified, authorised constraints can be sufficient; mining a complete template universe is unnecessary.

**Mechanism.** Mine supported finite-trace constraints with explicit activation semantics, distinguish satisfaction from meaningful activation, and check redundancy and consistency before interpretation. Treat a discovered constraint as a descriptive hypothesis unless independently authorised.

**Authority.** Analyst explains rule semantics; domain participants evaluate meaningful activation; rule authority is a separate decision. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate the representation, discovery bias, filtering and guarantee scope; keep domain-supplied knowledge distinguishable from mined evidence. Specific receiving decision: Analyst explains rule semantics; domain participants evaluate meaningful activation; rule authority is a separate decision.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S011`, `EPM:EPM-S041`, `EPM:EPM-S042`, `EPM:EPM-S056`. **BWP relations:** 101, individually enumerated in the JSON record. **Clusters:** BWP-K008, BWP-K010, BWP-K011, BWP-K015, BWP-K031. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-024` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-025"></a>
### EPM:EPM-025 — Global evolutionary discovery

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Discovery procedure/model, language/bias, observational support and fragment/global claims

**Criterion.** Results report objective, budget and stochastic variability alongside the selected model.

**Trigger.** The search objective captures the needed behaviour and additional computation can plausibly improve a consequential model.

**Non-trigger / cheaper path.** A deterministic structured or heuristic method may dominate when it already supplies an adequate result.

**Mechanism.** Search candidate models using explicit fitness objectives, mutation/crossover choices, resource limits and stochastic seeds; retain multiple runs and compare with simpler baselines. Do not interpret the returned best candidate as a proven global optimum.

**Authority.** Analyst chooses the search objective and stopping condition; the optimiser cannot supply the missing definition of a useful process. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate the representation, discovery bias, filtering and guarantee scope; keep domain-supplied knowledge distinguishable from mined evidence. Specific receiving decision: Analyst chooses the search objective and stopping condition; the optimiser cannot supply the missing definition of a useful process.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S019`, `EPM:EPM-S038`, `EPM:EPM-S053`. **BWP relations:** 54, individually enumerated in the JSON record. **Clusters:** BWP-K026, BWP-K031. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-025` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-026"></a>
### EPM:EPM-026 — Purposeful process-map simplification

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Activity abstraction and analytical representation suited to a consumer

**Criterion.** The consumer can identify the represented scope and retrieve material suppressed behaviour.

**Trigger.** The full view is too dense for a specified diagnostic or communication task.

**Non-trigger / cheaper path.** Filter a small relevant segment, annotate a few events or use a table rather than adopting a large map-building ritual.

**Mechanism.** Simplify a process view according to its communicative purpose, retain access to suppressed detail, and label the result as an abstraction rather than a complete executable specification. Test whether the consumer can answer the intended question.

**Authority.** Analyst constructs the view; participants judge its adequacy for the discussion, not merely its visual attractiveness. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate the representation, discovery bias, filtering and guarantee scope; keep domain-supplied knowledge distinguishable from mined evidence. Specific receiving decision: Analyst constructs the view; participants judge its adequacy for the discussion, not merely its visual attractiveness.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S013`, `EPM:EPM-S016`, `EPM:EPM-S019`. **BWP relations:** 58, individually enumerated in the JSON record. **Clusters:** BWP-K004, BWP-K007, BWP-K031. **Tensions:** BWP-T004.

**Rich record.** Select `key == EPM:EPM-026` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-027"></a>
### EPM:EPM-027 — Protection of material infrequent behaviour

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Discovery procedure/model, language/bias, observational support and fragment/global claims

**Criterion.** Important infrequent behaviour remains visible in the evidence or its deliberate exclusion is justified.

**Trigger.** Filtering, thresholding, abstraction or sampling can remove behaviour whose consequence is disproportionate to frequency.

**Non-trigger / cheaper path.** A small exception list linked to the main analysis may be sufficient; no additional model is needed for harmless isolated artefacts.

**Mechanism.** Classify low-frequency behaviour by relevance to the question before suppressing it; retain or separately analyse material exceptions and expose the effect of filtering on the conclusion. Do not require keeping every rare record in every main view.

**Authority.** Domain participants explain consequence and authorisation; the miner supplies frequency, not importance. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate the representation, discovery bias, filtering and guarantee scope; keep domain-supplied knowledge distinguishable from mined evidence. Specific receiving decision: Domain participants explain consequence and authorisation; the miner supplies frequency, not importance.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S001`, `EPM:EPM-S006`, `EPM:EPM-S013`, `EPM:EPM-S016`, `EPM:EPM-S039`, `EPM:EPM-S045`. **BWP relations:** 58, individually enumerated in the JSON record. **Clusters:** BWP-K005, BWP-K015. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-027` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-028"></a>
### EPM:EPM-028 — Non-identifiability-aware inference

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Discovery procedure/model, language/bias, observational support and fragment/global claims

**Criterion.** Claims distinguish observed support, model permission and warranted process necessity.

**Trigger.** A discovered relation is interpreted as necessity, impossibility, causal structure or the only true process.

**Non-trigger / cheaper path.** Report the observed directly-follows relation or a descriptive model without making an identification claim.

**Mechanism.** State observational equivalence and the limits of the sampled behaviour. Where competing models make different consequential predictions, seek discriminating data or domain evidence; otherwise retain alternatives or a weaker conclusion rather than asserting unique recovery.

**Authority.** Analyst communicates what is and is not identified; domain evidence can discriminate but must not be silently smuggled into the log. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate the representation, discovery bias, filtering and guarantee scope; keep domain-supplied knowledge distinguishable from mined evidence. Specific receiving decision: Analyst communicates what is and is not identified; domain evidence can discriminate but must not be silently smuggled into the log.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S002`, `EPM:EPM-S005`, `EPM:EPM-S018`, `EPM:EPM-S019`, `EPM:EPM-S020`, `EPM:EPM-S053`, `EPM:EPM-S056`. **BWP relations:** 78, individually enumerated in the JSON record. **Clusters:** BWP-K009, BWP-K010, BWP-K023, BWP-K032. **Tensions:** BWP-T017.

**Rich record.** Select `key == EPM:EPM-028` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-029"></a>
### EPM:EPM-029 — Domain-guided discovery with explicit input authority

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Discovery procedure/model, language/bias, observational support and fragment/global claims

**Criterion.** A consumer can tell which parts of the model were mined, interpreted or supplied as intended behaviour.

**Trigger.** Multiple plausible interpretations, incomprehensible models, unlogged activities or known policies materially affect the inquiry.

**Non-trigger / cheaper path.** A focused conversation about one ambiguous event class may suffice; a standing modelling committee is unnecessary.

**Mechanism.** Use domain knowledge to propose constraints, abstractions or candidate interpretations, label its origin and test its consequences against event evidence. Keep observed, inferred and prescribed statements separate when adjusting a model.

**Authority.** Domain experts supply contextual knowledge; the relevant institutional actor—not the analyst—authorises prescriptive rules. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate the representation, discovery bias, filtering and guarantee scope; keep domain-supplied knowledge distinguishable from mined evidence. Specific receiving decision: Domain experts supply contextual knowledge; the relevant institutional actor—not the analyst—authorises prescriptive rules.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S001`, `EPM:EPM-S016`, `EPM:EPM-S032`, `EPM:EPM-S056`. **BWP relations:** 54, individually enumerated in the JSON record. **Clusters:** BWP-K006, BWP-K015. **Tensions:** BWP-T012.

**Rich record.** Select `key == EPM:EPM-029` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-030"></a>
### EPM:EPM-030 — Local or decomposed discovery with boundary obligations

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Discovery procedure/model, language/bias, observational support and fragment/global claims

**Criterion.** Each fragment’s scope and unresolved composition obligations are explicit.

**Trigger.** A local pattern or sub-process answers the question more economically than a full end-to-end model.

**Non-trigger / cheaper path.** Analyse the relevant event subset or a single constraint without promising whole-process reconstruction.

**Mechanism.** Discover or analyse bounded fragments with explicit event selection and boundary semantics; identify shared events and interactions omitted by the decomposition. Recompose only when compatibility and the consumer’s global question are actually addressed.

**Authority.** Analyst communicates what a local result does not say; the consumer decides whether a global conclusion is needed. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate the representation, discovery bias, filtering and guarantee scope; keep domain-supplied knowledge distinguishable from mined evidence. Specific receiving decision: Analyst communicates what a local result does not say; the consumer decides whether a global conclusion is needed.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S019`, `EPM:EPM-S026`, `EPM:EPM-S049`. **BWP relations:** 91, individually enumerated in the JSON record. **Clusters:** BWP-K010, BWP-K020, BWP-K031, BWP-K032. **Tensions:** BWP-T017.

**Rich record.** Select `key == EPM:EPM-030` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-031"></a>
### EPM:EPM-031 — Defensible reference origin and authority

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Conformance reference, mapping, diagnosis and authorised interpretation/repair

**Criterion.** Every material deviation states what it deviates from and the authority, if any, behind that reference.

**Trigger.** Any use of conformance to evaluate people, compliance, policy adherence, implementation or process correctness.

**Non-trigger / cheaper path.** For a purely descriptive comparison, say that the log differs from a model and make no normative allegation.

**Mechanism.** Record whether the reference is descriptive, intended, contractual, technical or otherwise externally authorised; identify its version, scope and approving actor. Limit conformance conclusions to the actual reference semantics and route normative judgements to the actor entitled to make them.

**Authority.** Analyst computes correspondence; externally entitled actors interpret or amend obligations. No legal ruling or institutional power is inferred from mining.

**Interaction.** Communicate the reference origin, comparison semantics and rival explanations of mismatch to participants and actors entitled to choose a remedy. Specific receiving decision: The reference owner and relevant institutional authority determine obligations. The mining analyst establishes a comparison, not legality or fairness.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S001`, `EPM:EPM-S009`, `EPM:EPM-S010`, `EPM:EPM-S017`, `EPM:EPM-S032`, `EPM:EPM-S047`. **BWP relations:** 71, individually enumerated in the JSON record. **Clusters:** BWP-K007, BWP-K016, BWP-K019, BWP-K037. **Tensions:** BWP-T001, BWP-T006.

**Rich record.** Select `key == EPM:EPM-031` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-032"></a>
### EPM:EPM-032 — Token replay as bounded diagnosis

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Conformance reference, mapping, diagnosis and authorised interpretation/repair

**Criterion.** The consumer can identify which replay assumptions and token discrepancies produced the result.

**Trigger.** A Petri-net-style reference and log permit useful low-cost replay diagnostics.

**Non-trigger / cheaper path.** For a simple precedence rule, a direct trace check may be clearer and cheaper than a replay engine.

**Mechanism.** Replay a trace under stated net and mapping semantics, expose missing/remaining-token diagnostics and identify artificial token insertion or other replay choices. Use the result as a bounded explanation of mismatch, not as a unique cause of failure.

**Authority.** Analyst presents replay diagnostics to model and process experts; they evaluate possible explanations. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate the reference origin, comparison semantics and rival explanations of mismatch to participants and actors entitled to choose a remedy. Specific receiving decision: Analyst presents replay diagnostics to model and process experts; they evaluate possible explanations.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S009`, `EPM:EPM-S010`, `EPM:EPM-S032`, `EPM:EPM-S046`. **BWP relations:** 18, individually enumerated in the JSON record. **Clusters:** BWP-K016. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-032` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-033"></a>
### EPM:EPM-033 — Alignment cost and approximation transparency

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Conformance reference, mapping, diagnosis and authorised interpretation/repair

**Criterion.** A reported alignment states its cost model, search status and the semantics of each deviation category.

**Trigger.** The mismatch needs a principled comparison against executable model behaviour and the computational cost is justified.

**Non-trigger / cheaper path.** Use a simple constraint check or replay when it answers the question with acceptable ambiguity.

**Mechanism.** Specify synchronous moves, log moves, model moves, admissible paths and their costs; distinguish an exact optimum from a heuristic bound or timed-out search. Present alternative low-cost explanations where they change interpretation.

**Authority.** Analyst chooses and discloses costs; domain experts assess whether those costs reflect diagnostic importance; optimisation grants no authority. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate the reference origin, comparison semantics and rival explanations of mismatch to participants and actors entitled to choose a remedy. Specific receiving decision: Analyst chooses and discloses costs; domain experts assess whether those costs reflect diagnostic importance; optimisation grants no authority.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S010`, `EPM:EPM-S018`, `EPM:EPM-S046`. **BWP relations:** 14, individually enumerated in the JSON record. **Clusters:** BWP-K016. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-033` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-034"></a>
### EPM:EPM-034 — Multi-perspective conformance

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Conformance reference, mapping, diagnosis and authorised interpretation/repair

**Criterion.** The diagnosis identifies the perspectives and assumptions needed to support it.

**Trigger.** A consequential rule depends on more than activity sequence, such as a data guard or resource condition.

**Non-trigger / cheaper path.** Use a single-perspective check for a genuinely single-perspective question; do not add attributes merely because they are available.

**Mechanism.** Compare control-flow and relevant data/resource/time constraints jointly where the formalism supports them, with explicit cross-perspective costs. Diagnose which interpretation changes when a missing or inconsistent attribute is considered.

**Authority.** Analyst establishes joint comparison; domain or rule authority interprets the guard and its consequence. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate the reference origin, comparison semantics and rival explanations of mismatch to participants and actors entitled to choose a remedy. Specific receiving decision: Analyst establishes joint comparison; domain or rule authority interprets the guard and its consequence.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S017`, `EPM:EPM-S046`. **BWP relations:** 48, individually enumerated in the JSON record. **Clusters:** BWP-K008, BWP-K009, BWP-K016. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-034` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-035"></a>
### EPM:EPM-035 — Uncertain-event conformance bounds

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Conformance reference, mapping, diagnosis and authorised interpretation/repair

**Criterion.** A result distinguishes robust mismatch from mismatch that depends on an unresolved event interpretation.

**Trigger.** Material uncertainty is bounded well enough to express meaningful alternatives and conformance remains decision-relevant.

**Non-trigger / cheaper path.** Flag a local ambiguity or withhold the affected judgement when full realisation analysis would not change a decision.

**Mechanism.** Represent the admitted event uncertainties and compute or approximate lower and upper conformance costs across supported realisations. Report what holds for all, some or none of those realisations without assigning unsupported probabilities.

**Authority.** Analyst explains bound semantics; the consumer decides whether the interval is informative enough to act on. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate the reference origin, comparison semantics and rival explanations of mismatch to participants and actors entitled to choose a remedy. Specific receiving decision: Analyst explains bound semantics; the consumer decides whether the interval is informative enough to act on.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S025`, `EPM:EPM-S043`. **BWP relations:** 42, individually enumerated in the JSON record. **Clusters:** BWP-K011, BWP-K031. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-035` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-036"></a>
### EPM:EPM-036 — Plural explanations of deviation

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Conformance reference, mapping, diagnosis and authorised interpretation/repair

**Criterion.** The decision record identifies the evidence that distinguishes the adopted explanation from material alternatives.

**Trigger.** A deviation may lead to blame, redesign, software correction, model change or sanction.

**Non-trigger / cheaper path.** For an inconsequential exploratory discrepancy, record uncertainty without opening a full investigation.

**Mechanism.** For a consequential deviation, keep plausible data, reference, execution and exception explanations separate; gather discriminating evidence and state which alternatives remain. Match the remedy to the supported cause rather than automatically correcting the process.

**Authority.** Analyst frames competing explanations; data custodians, process participants and authorised decision makers establish causes and appropriate action. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate the reference origin, comparison semantics and rival explanations of mismatch to participants and actors entitled to choose a remedy. Specific receiving decision: Analyst frames competing explanations; data custodians, process participants and authorised decision makers establish causes and appropriate action.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S009`, `EPM:EPM-S016`, `EPM:EPM-S017`, `EPM:EPM-S032`, `EPM:EPM-S045`, `EPM:EPM-S047`. **BWP relations:** 91, individually enumerated in the JSON record. **Clusters:** BWP-K015, BWP-K016, BWP-K017, BWP-K018, BWP-K037. **Tensions:** BWP-T001, BWP-T006.

**Rich record.** Select `key == EPM:EPM-036` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-037"></a>
### EPM:EPM-037 — Conformance as sufficient legality or fairness

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Conformance reference, mapping, diagnosis and authorised interpretation/repair

**Criterion.** No unconditional legal, ethical or organisational endorsement is inferred from a fitness or alignment score.

**Trigger.** A dashboard or audit conclusion treats model conformance as an all-purpose compliance certificate.

**Non-trigger / cheaper path.** Retain the narrow, useful comparison and state that further normative assessment is outside it.

**Mechanism.** Reject the implication. Conformance establishes only the relation defined by the model, mapping and comparison; external normative predicates require separate standards, interpretation and authority.

**Authority.** Competent external authorities or accountable decision makers, not the mining algorithm, determine the additional predicates. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate the reference origin, comparison semantics and rival explanations of mismatch to participants and actors entitled to choose a remedy. Specific receiving decision: Competent external authorities or accountable decision makers, not the mining algorithm, determine the additional predicates.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S009`, `EPM:EPM-S010`, `EPM:EPM-S017`. **BWP relations:** 11, individually enumerated in the JSON record. **Clusters:** BWP-K016. **Tensions:** BWP-T006.

**Rich record.** Select `key == EPM:EPM-037` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-038"></a>
### EPM:EPM-038 — Authorised model repair versus process correction

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Conformance reference, mapping, diagnosis and authorised interpretation/repair

**Criterion.** The chosen correction has a supported cause, a stated change boundary and a checked effect on previously meaningful behaviour.

**Trigger.** Confirmed mismatch reveals an inadequate descriptive model or a legitimately approved change in intended behaviour.

**Non-trigger / cheaper path.** Correct one extraction rule or annotate one justified exception when this closes the issue; rediscovery is not obligatory.

**Mechanism.** Decide whether evidence supports correcting data, repairing a descriptive model, changing execution or formally revising an authorised rule. For model repair, preserve unaffected intent and re-evaluate changed behaviour; maintain the prior reference when continuity matters.

**Authority.** Model maintainer can repair a descriptive model within mandate; changing an obligation requires its own authorised actor and process. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate the reference origin, comparison semantics and rival explanations of mismatch to participants and actors entitled to choose a remedy. Specific receiving decision: Model maintainer can repair a descriptive model within mandate; changing an obligation requires its own authorised actor and process.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S001`, `EPM:EPM-S017`, `EPM:EPM-S032`, `EPM:EPM-S047`. **BWP relations:** 79, individually enumerated in the JSON record. **Clusters:** BWP-K015, BWP-K016, BWP-K022, BWP-K037. **Tensions:** BWP-T001, BWP-T006.

**Rich record.** Select `key == EPM:EPM-038` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-039"></a>
### EPM:EPM-039 — Separate model-quality dimensions

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process-model quality metrics, generalisation targets and comparative evaluation claims

**Criterion.** A selection rationale states which trade-off was accepted and does not imply that a good score on one dimension establishes the others.

**Trigger.** Comparison, selection or validation of discovered or repaired process models.

**Non-trigger / cheaper path.** Evaluate only the dimensions material to a tightly bounded question, explaining exclusions instead of manufacturing a four-score dashboard.

**Mechanism.** Evaluate fitness, precision, generalisation and simplicity as distinct questions, naming each operational measure and its assumptions. Report trade-offs and missing measurements rather than compressing them into an unexplained total.

**Authority.** Analyst explains the measures; the consumer supplies the decision priorities rather than allowing a metric package to choose them. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate experimental units, actual metric definitions, missing results and task-specific trade-offs rather than only an aggregate score. Specific receiving decision: Analyst explains the measures; the consumer supplies the decision priorities rather than allowing a metric package to choose them.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S001`, `EPM:EPM-S009`, `EPM:EPM-S018`, `EPM:EPM-S019`, `EPM:EPM-S020`, `EPM:EPM-S053`, `EPM:EPM-S056`. **BWP relations:** 40, individually enumerated in the JSON record. **Clusters:** BWP-K030. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-039` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-040"></a>
### EPM:EPM-040 — Measure-specific precision interpretation

**Disposition:** `USEFUL_BUT_EASILY_GAMED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process-model quality metrics, generalisation targets and comparative evaluation claims

**Criterion.** The reported precision result names what it measures and the important limitations that can change the ranking.

**Trigger.** Precision influences model choice, claimed superiority or the rejection of a permissive model.

**Non-trigger / cheaper path.** For an obvious flower model or simple local question, an explicit behavioural counterexample may be clearer than a fragile aggregate metric.

**Mechanism.** State the precision definition, behavioural equivalence and evaluated representation; check known axiomatic or computational limitations before using the value for ranking. Compare alternatives only where their operationalisations are compatible.

**Authority.** Analyst interprets the measure; decision consumers must not equate the score with an externally validated false-behaviour rate. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate experimental units, actual metric definitions, missing results and task-specific trade-offs rather than only an aggregate score. Specific receiving decision: Analyst interprets the measure; decision consumers must not equate the score with an externally validated false-behaviour rate.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S009`, `EPM:EPM-S018`, `EPM:EPM-S019`, `EPM:EPM-S056`. **BWP relations:** 24, individually enumerated in the JSON record. **Clusters:** BWP-K030. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-040` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-041"></a>
### EPM:EPM-041 — Representativeness-aware generalisation

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process-model quality metrics, generalisation targets and comparative evaluation claims

**Criterion.** Generalisation claims identify the tested setting and uncertainty rather than treating a metric as direct access to the true process.

**Trigger.** A model will be used beyond the observed cases or is claimed to recover a generating process.

**Non-trigger / cheaper path.** Restrict the model to descriptive use when unseen-behaviour inference is not needed; use a simple estimate if a richer estimator has no demonstrated advantage.

**Mechanism.** State the unseen-behaviour target and sample-generation assumptions; use held-out, simulation-ground-truth or resampling evidence only for the claim it supports. Compare simple baselines and examine sensitivity to representativeness and sample size.

**Authority.** Analyst communicates population assumptions; domain consumer decides whether external validity is adequate for the planned use. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate experimental units, actual metric definitions, missing results and task-specific trade-offs rather than only an aggregate score. Specific receiving decision: Analyst communicates population assumptions; domain consumer decides whether external validity is adequate for the planned use.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S019`, `EPM:EPM-S020`, `EPM:EPM-S053`, `EPM:EPM-S056`. **BWP relations:** 20, individually enumerated in the JSON record. **Clusters:** BWP-K030. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-041` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-042"></a>
### EPM:EPM-042 — Consumer-relative simplicity

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Activity abstraction and analytical representation suited to a consumer

**Criterion.** The chosen representation allows the needed decision without hiding consequential alternatives.

**Trigger.** A model must support human reasoning, communication, maintenance or an operational decision.

**Non-trigger / cheaper path.** A short trace, constraint or table may communicate the result better than any general process model.

**Mechanism.** Evaluate simplicity relative to the consumer’s task and notation knowledge; inspect whether required distinctions and important exceptions remain accessible. Consider interpretive and maintenance burden, not only structural size.

**Authority.** The actual consumer supplies evidence of usability; analysts should not substitute aesthetic preference for task performance. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate experimental units, actual metric definitions, missing results and task-specific trade-offs rather than only an aggregate score. Specific receiving decision: The actual consumer supplies evidence of usability; analysts should not substitute aesthetic preference for task performance.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S001`, `EPM:EPM-S013`, `EPM:EPM-S016`, `EPM:EPM-S019`, `EPM:EPM-S056`. **BWP relations:** 60, individually enumerated in the JSON record. **Clusters:** BWP-K004, BWP-K026. **Tensions:** BWP-T004.

**Rich record.** Select `key == EPM:EPM-042` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-043"></a>
### EPM:EPM-043 — Evaluation units and splits matched to the claim

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process-model quality metrics, generalisation targets and comparative evaluation claims

**Criterion.** Results state the denominator and split unit, retain adverse/missing results and avoid converting repeated runs into independent replications.

**Trigger.** Any empirical comparison or model-performance claim beyond a worked example.

**Non-trigger / cheaper path.** A small controlled example can establish possibility or a counterexample if labelled as such; it need not imitate a deployment study.

**Mechanism.** Match the experimental unit, split and comparison to the intended inference; isolate test information from tuning, preserve appropriate temporal availability, include meaningful baselines and account for failures/timeouts. State exactly what the dataset collection can and cannot represent.

**Authority.** Researcher designs the comparison; reviewer checks whether the conclusion follows from its units and assumptions. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate experimental units, actual metric definitions, missing results and task-specific trade-offs rather than only an aggregate score. Specific receiving decision: Researcher designs the comparison; reviewer checks whether the conclusion follows from its units and assumptions.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S019`, `EPM:EPM-S020`, `EPM:EPM-S022`, `EPM:EPM-S023`, `EPM:EPM-S053`, `EPM:EPM-S056`. **BWP relations:** 61, individually enumerated in the JSON record. **Clusters:** BWP-K023, BWP-K025, BWP-K030. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-043` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-044"></a>
### EPM:EPM-044 — Universal aggregate model-quality ranking

**Disposition:** `NO_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process-model quality metrics, generalisation targets and comparative evaluation claims

**Criterion.** No unconditional model-quality ranking is exported; any local scalar is labelled as a chosen decision rule.

**Trigger.** A score is claimed to identify the best process model independently of purpose, model class or consumer.

**Non-trigger / cheaper path.** Use a transparent trade-off account or dominance comparison rather than forced aggregation.

**Mechanism.** Reject a context-free aggregate ranking. A decision-specific utility function may be used only with explicit weights, commensurability assumptions, exclusions and sensitivity to alternative priorities.

**Authority.** The consumer specifies priorities; a metric designer cannot supply universal organisational preferences. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate experimental units, actual metric definitions, missing results and task-specific trade-offs rather than only an aggregate score. Specific receiving decision: The consumer specifies priorities; a metric designer cannot supply universal organisational preferences.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S001`, `EPM:EPM-S018`, `EPM:EPM-S019`, `EPM:EPM-S020`, `EPM:EPM-S056`. **BWP relations:** 32, individually enumerated in the JSON record. **Clusters:** BWP-K030. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-044` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-045"></a>
### EPM:EPM-045 — Perfect fitness as sufficient validity

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Process-model quality metrics, generalisation targets and comparative evaluation claims

**Criterion.** A perfect-fit result is not allowed to erase semantic, precision, generalisation or authority limitations.

**Trigger.** Perfect replay or alignment fitness is used as a certificate of process correctness or complete analysis.

**Non-trigger / cheaper path.** One counterexample showing indiscriminate permitted behaviour may be enough to defeat the sufficiency claim.

**Mechanism.** Reject perfect fitness as sufficient validity. Test what additional behaviour the model admits and whether the event semantics, population and intended use are supported.

**Authority.** Analyst reports the narrow fitness result; consumer requires other evidence for stronger conclusions. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate experimental units, actual metric definitions, missing results and task-specific trade-offs rather than only an aggregate score. Specific receiving decision: Analyst reports the narrow fitness result; consumer requires other evidence for stronger conclusions.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S009`, `EPM:EPM-S018`, `EPM:EPM-S019`, `EPM:EPM-S050`, `EPM:EPM-S056`. **BWP relations:** 30, individually enumerated in the JSON record. **Clusters:** BWP-K007, BWP-K030. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-045` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-046"></a>
### EPM:EPM-046 — Elapsed time distinguished from effort

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Observed/inferred time, queues and candidate bottleneck explanations

**Criterion.** A duration claim can be traced to its endpoints and does not silently equate elapsed time with labour.

**Trigger.** Any timing result used to diagnose delay, compare resources or change staffing.

**Non-trigger / cheaper path.** Report a milestone-to-milestone elapsed interval without claiming a service-time decomposition when start or enablement events are unavailable.

**Mechanism.** Define each duration by its observed endpoints and lifecycle semantics; distinguish throughput, waiting, service and unobserved time. Attribute elapsed intervals only where the data and model support the attribution, and retain missing intervals as missing.

**Authority.** Performance analyst and operational staff agree what the time measure denotes before it is used as evidence of effort or blame. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange traceable intervals and interaction patterns with operational participants; distinguish observed facts, proposed causes, agreed actions and consequences. Specific receiving decision: Performance analyst and operational staff agree what the time measure denotes before it is used as evidence of effort or blame.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S039`, `EPM:EPM-S045`, `EPM:EPM-S048`, `EPM:EPM-S050`. **BWP relations:** 48, individually enumerated in the JSON record. **Clusters:** BWP-K012, BWP-K013, BWP-K018. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-046` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-047"></a>
### EPM:EPM-047 — Bottleneck explanations checked against omitted prerequisites

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Observed/inferred time, queues and candidate bottleneck explanations

**Criterion.** A proposed bottleneck remedy states the evidence linking the recorded delay to the alleged mechanism.

**Trigger.** A timing pattern could lead to process redesign, escalation or attribution of responsibility.

**Non-trigger / cheaper path.** A targeted examination of a few delayed cases may answer the question; a complete simulation or staffing model is unnecessary if the prerequisite is directly verifiable.

**Mechanism.** Use the process trace to generate candidate bottleneck explanations, then check omitted prerequisites, calendars, case mix and recording practices. Distinguish the location of an observed delay from a supported causal explanation and from an effective remedy.

**Authority.** Analyst reports the pattern; operational participants provide contextual evidence; authorised managers decide on interventions. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange traceable intervals and interaction patterns with operational participants; distinguish observed facts, proposed causes, agreed actions and consequences. Specific receiving decision: Analyst reports the pattern; operational participants provide contextual evidence; authorised managers decide on interventions.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S016`, `EPM:EPM-S032`, `EPM:EPM-S045`, `EPM:EPM-S048`, `EPM:EPM-S050`. **BWP relations:** 25, individually enumerated in the JSON record. **Clusters:** BWP-K012, BWP-K013. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-047` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-048"></a>
### EPM:EPM-048 — Inter-case resource and queueing context

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Observed/inferred time, queues and candidate bottleneck explanations

**Criterion.** A comparison identifies the contextual variables whose omission would change the interpretation.

**Trigger.** Observed delay depends on shared resources, priority rules, batches or multiple interacting objects.

**Non-trigger / cheaper path.** A small load or queue stratification may suffice; a full queueing or object-centric executable model is not always needed.

**Mechanism.** Include inter-case or inter-object context when it materially affects the interpretation of queues and delays; stratify or annotate by relevant load, batching and relation states. Keep inferred context distinct from directly observed resource states.

**Authority.** Analyst and operational consumer decide which context explains the decision-relevant variation. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange traceable intervals and interaction patterns with operational participants; distinguish observed facts, proposed causes, agreed actions and consequences. Specific receiving decision: Analyst and operational consumer decide which context explains the decision-relevant variation.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S048`, `EPM:EPM-S050`. **BWP relations:** 16, individually enumerated in the JSON record. **Clusters:** BWP-K012. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-048` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-049"></a>
### EPM:EPM-049 — Verified resource identity semantics

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Resource/people identifiers, social inferences and subgroup/case-mix comparisons

**Criterion.** The unit of a resource claim matches the verified meaning of the identifier.

**Trigger.** Resource utilisation, handoff, social-network, workload or individual-performance analysis.

**Non-trigger / cheaper path.** Analyse roles, teams or technical accounts at the level actually supported; omit personal attribution if it is unnecessary.

**Mechanism.** Establish what each resource identifier denotes and when the mapping changes; distinguish people, roles, teams, systems and accounts. Do not make individual-level claims from a coarser or ambiguous identifier.

**Authority.** Data custodian explains account semantics; affected participants can challenge attribution; analysts do not infer personal identity by convenience. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange traceable intervals and interaction patterns with operational participants; distinguish observed facts, proposed causes, agreed actions and consequences. Specific receiving decision: Data custodian explains account semantics; affected participants can challenge attribution; analysts do not infer personal identity by convenience.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S012`, `EPM:EPM-S017`, `EPM:EPM-S045`. **BWP relations:** 68, individually enumerated in the JSON record. **Clusters:** BWP-K013, BWP-K014, BWP-K027, BWP-K033. **Tensions:** BWP-T014.

**Rich record.** Select `key == EPM:EPM-049` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-050"></a>
### EPM:EPM-050 — Social-network interpretation restraint

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Resource/people identifiers, social inferences and subgroup/case-mix comparisons

**Criterion.** The network is labelled by its operational construction rather than by an unsupported social meaning.

**Trigger.** The inquiry genuinely concerns organisational coordination and the log can support a relevant relation.

**Non-trigger / cheaper path.** A process-level handoff count may be enough; do not construct a personal social network for an unrelated performance question.

**Mechanism.** Define the exact event-derived relation and its unit; validate what the metric means with organisational participants and separate technical handoff from social relationship. Prefer aggregates where individual identification is not needed.

**Authority.** Analyst describes the operational relation; participants contest interpretation; organisational decisions remain externally accountable. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange traceable intervals and interaction patterns with operational participants; distinguish observed facts, proposed causes, agreed actions and consequences. Specific receiving decision: Analyst describes the operational relation; participants contest interpretation; organisational decisions remain externally accountable.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S012`, `EPM:EPM-S017`. **BWP relations:** 37, individually enumerated in the JSON record. **Clusters:** BWP-K027, BWP-K033. **Tensions:** BWP-T014.

**Rich record.** Select `key == EPM:EPM-050` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-051"></a>
### EPM:EPM-051 — Case-mix and subgroup comparability

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Resource/people identifiers, social inferences and subgroup/case-mix comparisons

**Criterion.** A comparison names its unit, material adjustment assumptions and groups for which evidence is insufficient.

**Trigger.** Performance comparisons across people, units, time periods, demographic groups or process variants.

**Non-trigger / cheaper path.** Report separate descriptive distributions or refrain from ranking rather than fit an unjustified adjustment model.

**Mechanism.** Compare like with like where possible, disclose subgroup and case-mix differences, and examine how selection, censoring and task allocation affect the result. When comparability fails, narrow the claim instead of normalising away inconvenient differences.

**Authority.** Analyst identifies comparability limits; affected participants and accountable decision makers assess the meaning and acceptable use. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange traceable intervals and interaction patterns with operational participants; distinguish observed facts, proposed causes, agreed actions and consequences. Specific receiving decision: Analyst identifies comparability limits; affected participants and accountable decision makers assess the meaning and acceptable use.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S017`, `EPM:EPM-S022`, `EPM:EPM-S048`. **BWP relations:** 102, individually enumerated in the JSON record. **Clusters:** BWP-K002, BWP-K012, BWP-K025, BWP-K027, BWP-K030, BWP-K040. **Tensions:** BWP-T010.

**Rich record.** Select `key == EPM:EPM-051` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-052"></a>
### EPM:EPM-052 — Simulation as conditional scenario analysis

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Conditional simulation scenarios and counterfactual interpretation

**Criterion.** A scenario result states which assumptions generate the advantage and what prospective evidence would be needed before wider use.

**Trigger.** The decision concerns a counterfactual change that cannot yet be tested directly and a model can represent its relevant mechanism.

**Non-trigger / cheaper path.** A transparent analytical bound or small controlled pilot can dominate an elaborate simulator; no simulation is necessary for an already observable factual question.

**Mechanism.** Use simulation to explore consequences under stated process, resource, arrival and intervention assumptions; compare baseline reproduction and sensitivity before drawing a conditional scenario conclusion. Keep calibration evidence separate from intervention validation.

**Authority.** Analyst constructs scenarios; authorised decision makers choose whether and how to test them in reality. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange traceable intervals and interaction patterns with operational participants; distinguish observed facts, proposed causes, agreed actions and consequences. Specific receiving decision: Analyst constructs scenarios; authorised decision makers choose whether and how to test them in reality.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S001`, `EPM:EPM-S027`. **BWP relations:** 62, individually enumerated in the JSON record. **Clusters:** BWP-K023, BWP-K031. **Tensions:** BWP-T011.

**Rich record.** Select `key == EPM:EPM-052` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-053"></a>
### EPM:EPM-053 — Consequential consumer and measured outcome

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Analytical results, decision consumers and continuation/return/non-use claims

**Criterion.** The result has a known consumer, disposition and consequence test, including a legitimate no-action outcome.

**Trigger.** Mining is proposed as decision support or as an improvement programme rather than purely methodological research.

**Non-trigger / cheaper path.** A bounded explanation or confirmation that no change is needed can be a valid result; another dashboard is not obligatory.

**Mechanism.** Identify who needs the result, what decision it can change and what observation would establish the consequence. Separate analytical delivery, organisational agreement, implemented action and measured outcome; stop or retire an analysis without an adequate consumer.

**Authority.** Analyst communicates evidence and uncertainty; operational actors act within their mandate; outcome measurement must not be replaced by analyst self-report. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange traceable intervals and interaction patterns with operational participants; distinguish observed facts, proposed causes, agreed actions and consequences. Specific receiving decision: Analyst communicates evidence and uncertainty; operational actors act within their mandate; outcome measurement must not be replaced by analyst self-report.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S001`, `EPM:EPM-S016`, `EPM:EPM-S017`, `EPM:EPM-S032`. **BWP relations:** 97, individually enumerated in the JSON record. **Clusters:** BWP-K001, BWP-K002, BWP-K019, BWP-K024, BWP-K034. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-053` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-054"></a>
### EPM:EPM-054 — Temporal identity of logs models and expectations

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Time-regime-bound logs/models/references, drift and streaming/adaptation claims

**Criterion.** A result or decision can be matched to its data, model and reference regime.

**Trigger.** Long-running analysis, changing instrumentation, retraining, repair or evaluation across periods.

**Non-trigger / cheaper path.** One dated snapshot and model version may suffice for a one-off historical question.

**Mechanism.** Keep observation windows, event-schema versions, model versions and reference expectations distinguishable; tie a result to the regime in which its assumptions were assessed. Preserve enough prior identity to compare changes or reconstruct a past decision.

**Authority.** Data and model custodians communicate changes; consumers know which temporal claim a result supports. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate alarms, source/model version changes, retained history and alternative change explanations to actors able to investigate and revise. Specific receiving decision: Data and model custodians communicate changes; consumers know which temporal claim a result supports.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S021`, `EPM:EPM-S022`, `EPM:EPM-S034`, `EPM:EPM-S037`. **BWP relations:** 103, individually enumerated in the JSON record. **Clusters:** BWP-K021, BWP-K022, BWP-K025, BWP-K032, BWP-K036. **Tensions:** BWP-T002, BWP-T013.

**Rich record.** Select `key == EPM:EPM-054` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-055"></a>
### EPM:EPM-055 — Drift detection with latency and false-alarm costs

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Time-regime-bound logs/models/references, drift and streaming/adaptation claims

**Criterion.** An alert carries its feature basis and uncertainty, and the response distinguishes detection from diagnosis.

**Trigger.** The process may change in a way that invalidates a model or decision and timely detection would matter.

**Non-trigger / cheaper path.** A scheduled comparison of a few interpretable indicators can suffice for slow or low-consequence change.

**Mechanism.** Choose observable features and a detector matched to the relevant kind of change; evaluate sensitivity, false alarms, detection delay and resource costs under plausible stable and changed conditions. Treat an alarm as evidence for investigation, not proof of a particular cause.

**Authority.** Analyst defines and evaluates detection; operational/model authorities decide what a confirmed change means. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate alarms, source/model version changes, retained history and alternative change explanations to actors able to investigate and revise. Specific receiving decision: Analyst defines and evaluates detection; operational/model authorities decide what a confirmed change means.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S021`, `EPM:EPM-S037`. **BWP relations:** 20, individually enumerated in the JSON record. **Clusters:** BWP-K022. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-055` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-056"></a>
### EPM:EPM-056 — Instrumentation change distinguished from process change

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Time-regime-bound logs/models/references, drift and streaming/adaptation claims

**Criterion.** A drift disposition states whether evidence supports process change, observation change, both or an unresolved mixture.

**Trigger.** A detected shift coincides with possible source-system, extraction, label or sampling changes.

**Non-trigger / cheaper path.** Checking a deployment note and a few paired records may resolve the issue without retraining or process redesign.

**Mechanism.** On an apparent drift, compare instrumentation, extraction, population and process explanations; inspect the change history and selected raw examples. Revise the process hypothesis only after distinguishing or explicitly retaining these alternatives.

**Authority.** Data custodian explains instrumentation; analyst evaluates the observed shift; process authority decides on operational consequences. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate alarms, source/model version changes, retained history and alternative change explanations to actors able to investigate and revise. Specific receiving decision: Data custodian explains instrumentation; analyst evaluates the observed shift; process authority decides on operational consequences.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S021`, `EPM:EPM-S039`, `EPM:EPM-S045`. **BWP relations:** 75, individually enumerated in the JSON record. **Clusters:** BWP-K021, BWP-K022, BWP-K025, BWP-K036, BWP-K040. **Tensions:** BWP-T013.

**Rich record.** Select `key == EPM:EPM-056` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-057"></a>
### EPM:EPM-057 — Streaming with explicit forgetting and incomplete-case semantics

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Time-regime-bound logs/models/references, drift and streaming/adaptation claims

**Criterion.** An online result states what history it represents and how partial/late observations affect it.

**Trigger.** Data volume or required latency makes bounded online processing preferable to complete batch analysis.

**Non-trigger / cheaper path.** Periodic batch analysis with explicit windows is adequate when near-real-time decisions are unnecessary.

**Mechanism.** Specify window/forgetting policy, event arrival order, late-data handling and prefix semantics; expose the trade-off between latency, memory and historical coverage. Assess partial-case conformance as partial rather than pretending the case has ended.

**Authority.** Stream analyst or service operator discloses retention and delay to the decision consumer. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate alarms, source/model version changes, retained history and alternative change explanations to actors able to investigate and revise. Specific receiving decision: Stream analyst or service operator discloses retention and delay to the decision consumer.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S021`, `EPM:EPM-S034`, `EPM:EPM-S052`. **BWP relations:** 62, individually enumerated in the JSON record. **Clusters:** BWP-K017, BWP-K019, BWP-K022. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-057` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-058"></a>
### EPM:EPM-058 — Adaptive description separated from stable obligations

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Time-regime-bound logs/models/references, drift and streaming/adaptation claims

**Criterion.** Observed drift cannot erase a prior obligation merely by changing the learned model.

**Trigger.** A model is retrained or repaired while also being used to judge compliance or intended behaviour.

**Non-trigger / cheaper path.** A dated descriptive snapshot plus an unchanged reference may suffice; separate software services or new organisational owners are not required.

**Mechanism.** Maintain a distinction between the model describing recent behaviour and any stable or separately authorised reference. Compare them, diagnose change and obtain the relevant decision before amending obligations; adaptation of description is not self-authorising revision.

**Authority.** Analyst may update a descriptive estimate within scope; rule owners or other entitled actors decide whether the intended process changes. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate alarms, source/model version changes, retained history and alternative change explanations to actors able to investigate and revise. Specific receiving decision: Analyst may update a descriptive estimate within scope; rule owners or other entitled actors decide whether the intended process changes.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S017`, `EPM:EPM-S021`, `EPM:EPM-S037`, `EPM:EPM-S047`. **BWP relations:** 50, individually enumerated in the JSON record. **Clusters:** BWP-K021, BWP-K022. **Tensions:** BWP-T002, BWP-T003.

**Rich record.** Select `key == EPM:EPM-058` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-059"></a>
### EPM:EPM-059 — Automatic normative normalisation of detected drift

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Time-regime-bound logs/models/references, drift and streaming/adaptation claims

**Criterion.** No reference obligation changes solely because the observed behaviour changed.

**Trigger.** An adaptive analysis is proposed as an automatic update to compliance expectations.

**Non-trigger / cheaper path.** Keep the existing reference and record a change hypothesis while the appropriate actor investigates.

**Mechanism.** Reject automatic normative normalisation. Drift may warrant a new descriptive model, process correction, instrumentation repair or an authorised rule review; detection alone selects none of these.

**Authority.** Only the relevant authorised actor can revise an obligation; a detector has no such authority. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate alarms, source/model version changes, retained history and alternative change explanations to actors able to investigate and revise. Specific receiving decision: Only the relevant authorised actor can revise an obligation; a detector has no such authority.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S017`, `EPM:EPM-S021`, `EPM:EPM-S037`, `EPM:EPM-S047`. **BWP relations:** 10, individually enumerated in the JSON record. **Clusters:** BWP-K022. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-059` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-060"></a>
### EPM:EPM-060 — Prediction-time information availability

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Prediction occasions, available features, calibration and predictive evaluation/utility

**Criterion.** Every predictive input can be justified as available at the declared decision time.

**Trigger.** Any claim of prospective outcome, next-event or remaining-time prediction.

**Non-trigger / cheaper path.** A historical description may use complete traces if it is labelled retrospective and makes no prospective-performance claim.

**Mechanism.** Define the prediction occasion and information available at that moment, including attribute update histories and cross-case state. Construct features and labels accordingly; keep post-outcome or future-derived information outside the predictor and its tuning.

**Authority.** Predictive analyst establishes temporal eligibility; operational consumer confirms when information and action opportunities actually exist. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange decision-time inputs, uncertainty, feasible actions, causal assumptions and observed actions/outcomes with the actual operational recipient. Specific receiving decision: Predictive analyst establishes temporal eligibility; operational consumer confirms when information and action opportunities actually exist.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S022`, `EPM:EPM-S023`. **BWP relations:** 36, individually enumerated in the JSON record. **Clusters:** BWP-K008, BWP-K023. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-060` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-061"></a>
### EPM:EPM-061 — Leakage- and censoring-aware predictive evaluation

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Prediction occasions, available features, calibration and predictive evaluation/utility

**Criterion.** The evaluation can be reconstructed and does not treat future outcomes or dependent prefixes as independent unseen evidence.

**Trigger.** A retrospective benchmark is used to estimate future predictive performance.

**Non-trigger / cheaper path.** For an explicitly exchangeable retrospective question, a grouped random split can be acceptable; temporal splitting is not a ritual for unrelated claims.

**Mechanism.** Split at the unit and time boundary appropriate to the deployment claim; ensure training outcomes were available then, keep dependent prefixes together where required, and disclose censoring, length restrictions and exclusions. Report performance by meaningful decision horizon and compare an adequate simple baseline.

**Authority.** Researcher states the claim and split design; reviewer examines what excluded cases and dependence do to the result. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange decision-time inputs, uncertainty, feasible actions, causal assumptions and observed actions/outcomes with the actual operational recipient. Specific receiving decision: Researcher states the claim and split design; reviewer examines what excluded cases and dependence do to the result.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S022`, `EPM:EPM-S023`, `EPM:EPM-S056`. **BWP relations:** 41, individually enumerated in the JSON record. **Clusters:** BWP-K023, BWP-K025. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-061` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-062"></a>
### EPM:EPM-062 — Calibrated uncertainty and abstention

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Prediction occasions, available features, calibration and predictive evaluation/utility

**Criterion.** Outputs distinguish probability calibration, marginal set coverage and individual uncertainty; unreliable regimes trigger qualified output or review.

**Trigger.** Prediction uncertainty materially affects the cost or safety of a decision and a consumer can use an uncertainty-aware output.

**Non-trigger / cheaper path.** A conservative rule, broad interval or human review may be preferable to a complex calibration layer whose assumptions cannot be justified.

**Mechanism.** Choose uncertainty measures appropriate to the decision, evaluate calibration/coverage and set usefulness separately, and provide a human-review or abstention path where uncertainty defeats actionability. State assumptions such as exchangeability, valid calibration separation and limits under drift.

**Authority.** Analyst explains uncertainty semantics; accountable operators decide how uncertain cases are handled rather than reading a singleton set as certainty. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange decision-time inputs, uncertainty, feasible actions, causal assumptions and observed actions/outcomes with the actual operational recipient. Specific receiving decision: Analyst explains uncertainty semantics; accountable operators decide how uncertain cases are handled rather than reading a singleton set as certainty.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S022`, `EPM:EPM-S057`, `EPM:EPM-S058`. **BWP relations:** 18, individually enumerated in the JSON record. **Clusters:** BWP-K023. **Tensions:** BWP-T011.

**Rich record.** Select `key == EPM:EPM-062` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-063"></a>
### EPM:EPM-063 — Timely resource-aware decision utility

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Prediction occasions, available features, calibration and predictive evaluation/utility

**Criterion.** A claimed useful prediction has an available response and an evaluation matched to its timing and resource constraints.

**Trigger.** Predictions are intended to allocate attention, resources or interventions to running cases.

**Non-trigger / cheaper path.** A simple prioritisation rule may be adequate, or no prediction is warranted if no timely action is possible.

**Mechanism.** Evaluate predictive utility at actual decision times, accounting for lead time, false alarms, intervention capacity and opportunity cost. Choose thresholds or policies against an explicit decision objective rather than accuracy alone.

**Authority.** Operational authority specifies available actions and resource limits; the analyst evaluates decision support within those bounds. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange decision-time inputs, uncertainty, feasible actions, causal assumptions and observed actions/outcomes with the actual operational recipient. Specific receiving decision: Operational authority specifies available actions and resource limits; the analyst evaluates decision support within those bounds.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S023`, `EPM:EPM-S027`, `EPM:EPM-S030`. **BWP relations:** 97, individually enumerated in the JSON record. **Clusters:** BWP-K001, BWP-K012, BWP-K014, BWP-K023, BWP-K024. **Tensions:** BWP-T010.

**Rich record.** Select `key == EPM:EPM-063` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-064"></a>
### EPM:EPM-064 — Causal identification before interventional claims

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Intervention identification, recommendation feasibility and post-intervention/deployment claims

**Criterion.** An interventional claim states why the observational or experimental evidence identifies the proposed effect, and where it does not.

**Trigger.** A result claims that changing an activity, priority, resource or decision will improve an outcome.

**Non-trigger / cheaper path.** Use prediction for preparation or communicate a descriptive association without claiming a causal redesign benefit.

**Mechanism.** Define the intervention, outcome and comparison; state the identification assumptions and assess confounding, treatment availability, temporal order and support. Use experimental or suitably justified causal evidence for interventional claims, and otherwise present recommendations as hypotheses requiring evaluation.

**Authority.** Analyst establishes the causal claim’s conditions; authorised decision makers decide whether a test or intervention is acceptable. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange decision-time inputs, uncertainty, feasible actions, causal assumptions and observed actions/outcomes with the actual operational recipient. Specific receiving decision: Analyst establishes the causal claim’s conditions; authorised decision makers decide whether a test or intervention is acceptable.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S027`, `EPM:EPM-S030`. **BWP relations:** 71, individually enumerated in the JSON record. **Clusters:** BWP-K023, BWP-K024, BWP-K025, BWP-K038, BWP-K040. **Tensions:** BWP-T011.

**Rich record.** Select `key == EPM:EPM-064` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-065"></a>
### EPM:EPM-065 — Feasible and authorised recommendations

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Intervention identification, recommendation feasibility and post-intervention/deployment claims

**Criterion.** Advice states its recipient, feasibility conditions and evaluation basis; acceptance and actual execution are distinguishable.

**Trigger.** A system offers case-level or process-level advice intended to change behaviour.

**Non-trigger / cheaper path.** Present a small set of options or a human-reviewed hypothesis rather than automatic execution.

**Mechanism.** Restrict recommendations to actions that the recipient can perform within actual authority, timing and resource constraints; expose uncertainty and alternatives, allow rejection, and observe the action actually taken rather than equating advice with execution.

**Authority.** Operational actors retain the authority specified by the setting; analysts or models cannot grant themselves new powers through recommendations. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange decision-time inputs, uncertainty, feasible actions, causal assumptions and observed actions/outcomes with the actual operational recipient. Specific receiving decision: Operational actors retain the authority specified by the setting; analysts or models cannot grant themselves new powers through recommendations.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S017`, `EPM:EPM-S027`, `EPM:EPM-S030`. **BWP relations:** 87, individually enumerated in the JSON record. **Clusters:** BWP-K002, BWP-K014, BWP-K024, BWP-K029, BWP-K038. **Tensions:** BWP-T007, BWP-T008, BWP-T010.

**Rich record.** Select `key == EPM:EPM-065` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-066"></a>
### EPM:EPM-066 — Evaluation renewal after intervention feedback

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Intervention identification, recommendation feasibility and post-intervention/deployment claims

**Criterion.** Post-intervention claims cite evidence from the relevant regime and do not recycle an invalidated pre-intervention evaluation.

**Trigger.** Advice is acted upon, a policy is deployed, or user adaptation materially changes the process that produced training data.

**Non-trigger / cheaper path.** For unused exploratory predictions, no intervention-driven re-evaluation is needed beyond ordinary temporal checks.

**Mechanism.** Record when recommendations or interventions alter exposure, action selection or outcomes; reassess predictive, calibration and causal claims against the new regime. Preserve the prior evaluation as historical evidence and explicitly test the revised policy or narrow its use.

**Authority.** Analyst identifies changed validity conditions; operational authority decides continued use, revision or retirement based on new evidence. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange decision-time inputs, uncertainty, feasible actions, causal assumptions and observed actions/outcomes with the actual operational recipient. Specific receiving decision: Analyst identifies changed validity conditions; operational authority decides continued use, revision or retirement based on new evidence.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S022`, `EPM:EPM-S027`, `EPM:EPM-S030`, `EPM:EPM-S037`. **BWP relations:** 46, individually enumerated in the JSON record. **Clusters:** BWP-K022, BWP-K025, BWP-K038, BWP-K040. **Tensions:** BWP-T011.

**Rich record.** Select `key == EPM:EPM-066` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-067"></a>
### EPM:EPM-067 — Universal superiority of deep predictive models

**Disposition:** `NO_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Prediction occasions, available features, calibration and predictive evaluation/utility

**Criterion.** No unconditional deep-model preference is exported.

**Trigger.** Model architecture or novelty is used as sufficient justification for selection.

**Non-trigger / cheaper path.** Use a simple rule or conventional model when it meets the decision need with less cost and uncertainty.

**Mechanism.** Reject the universal claim; compare appropriate baselines on valid task-specific splits, including inference cost, data needs, interpretability and timing.

**Authority.** Analyst supplies evidence; consumer judges cost and decision relevance rather than accepting architectural prestige. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange decision-time inputs, uncertainty, feasible actions, causal assumptions and observed actions/outcomes with the actual operational recipient. Specific receiving decision: Analyst supplies evidence; consumer judges cost and decision relevance rather than accepting architectural prestige.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S022`, `EPM:EPM-S023`, `EPM:EPM-S028`, `EPM:EPM-S056`. **BWP relations:** 38, individually enumerated in the JSON record. **Clusters:** BWP-K026, BWP-K030. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-067` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-068"></a>
### EPM:EPM-068 — General deployed causal benefit of prescription

**Disposition:** `UNRESOLVED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Intervention identification, recommendation feasibility and post-intervention/deployment claims

**Criterion.** The packet exports an evidence obligation, not a presumed benefit or an unconditional control.

**Trigger.** A proposal relies on general realised benefit of automated prescription rather than on a bounded local test.

**Non-trigger / cheaper path.** A carefully scoped pilot, human decision support or no intervention may be sufficient while external validity is unknown.

**Mechanism.** Keep broad deployed benefit unresolved. Retain the narrower formal, simulation and retrospective findings and specify the prospective, multi-setting intervention evidence needed for stronger transfer.

**Authority.** Researcher and operational evaluator must establish realised effects; a developer’s simulation is not a deployment verdict. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Exchange decision-time inputs, uncertainty, feasible actions, causal assumptions and observed actions/outcomes with the actual operational recipient. Specific receiving decision: Researcher and operational evaluator must establish realised effects; a developer’s simulation is not a deployment verdict.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S027`, `EPM:EPM-S030`. **BWP relations:** 65, individually enumerated in the JSON record. **Clusters:** BWP-K023, BWP-K024, BWP-K029. **Tensions:** BWP-T011.

**Rich record.** Select `key == EPM:EPM-068` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-069"></a>
### EPM:EPM-069 — Reproducible executable analysis

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Analytical recipes, alternatives, evidence dependencies and validity-preserving handoffs

**Criterion.** A competent reviewer can reproduce the declared computation or locate the exact blocked dependency.

**Trigger.** A result must be reviewed, reproduced, maintained or used beyond an ephemeral exploration.

**Non-trigger / cheaper path.** A short script, query and immutable extract can suffice; a large reproducibility platform is not an intrinsic requirement.

**Mechanism.** Preserve the executable transformation/analysis recipe, relevant data identity, parameters, tool and dependency versions, random seeds and excluded or failed runs. Where raw data cannot be shared, expose the limitation and provide lawful substitutes that support only their stated claims.

**Authority.** Analyst produces reproducible evidence; data custodians enforce access boundaries; reviewers distinguish executable replication from data access. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Provide reviewers and participants with a usable, lawful analytical chain, relevant sensitivity results, data dependence and unresolved assumptions. Specific receiving decision: Analyst produces reproducible evidence; data custodians enforce access boundaries; reviewers distinguish executable replication from data access.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S016`, `EPM:EPM-S019`, `EPM:EPM-S022`, `EPM:EPM-S036`, `EPM:EPM-S056`. **BWP relations:** 48, individually enumerated in the JSON record. **Clusters:** BWP-K021, BWP-K028. **Tensions:** BWP-T015.

**Rich record.** Select `key == EPM:EPM-069` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-070"></a>
### EPM:EPM-070 — Robustness to plausible analytical alternatives

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Analytical recipes, alternatives, evidence dependencies and validity-preserving handoffs

**Criterion.** The finding states which reasonable changes preserve it and which would reverse or weaken it.

**Trigger.** Reasonable alternative extraction, representation, filtering, ordering, threshold or metric choices could change the decision.

**Non-trigger / cheaper path.** Test a small set of material alternatives, not an exhaustive Cartesian product of every parameter.

**Mechanism.** Vary plausible consequential analytical choices and identify which findings survive; treat changed conclusions as evidence about assumption sensitivity rather than selecting the preferred run. Include simple baselines and report computational failures.

**Authority.** Analyst defines and reports sensitivity; reviewer challenges whether excluded alternatives were genuinely implausible. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Provide reviewers and participants with a usable, lawful analytical chain, relevant sensitivity results, data dependence and unresolved assumptions. Specific receiving decision: Analyst defines and reports sensitivity; reviewer challenges whether excluded alternatives were genuinely implausible.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S018`, `EPM:EPM-S019`, `EPM:EPM-S020`, `EPM:EPM-S053`, `EPM:EPM-S056`. **BWP relations:** 18, individually enumerated in the JSON record. **Clusters:** BWP-K028. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-070` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-071"></a>
### EPM:EPM-071 — Domain challenge and participant validation

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Participant challenge, privacy/fairness, federated computation and output-disclosure boundaries

**Criterion.** Material contextual challenges are incorporated or remain explicitly unresolved.

**Trigger.** Interpretation depends on unlogged context, event meaning, intended practice or consequences for participants.

**Non-trigger / cheaper path.** One well-chosen knowledgeable participant or a small targeted check can be adequate for a narrow question; broad meetings are not mandatory.

**Mechanism.** Present traceable findings and competing explanations to relevant domain participants, including affected parties where people-related claims matter; record corrections, disagreement and evidence requested. Use focused challenge rather than treating agreement as truth.

**Authority.** Participants contribute situated evidence; authority to decide or revise policy remains distinct from expertise or seniority. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Provide reviewers and participants with a usable, lawful analytical chain, relevant sensitivity results, data dependence and unresolved assumptions. Specific receiving decision: Participants contribute situated evidence; authority to decide or revise policy remains distinct from expertise or seniority.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S016`, `EPM:EPM-S017`, `EPM:EPM-S032`, `EPM:EPM-S045`. **BWP relations:** 55, individually enumerated in the JSON record. **Clusters:** BWP-K005, BWP-K006, BWP-K027. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-071` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-072"></a>
### EPM:EPM-072 — Dependence-aware evidence accounting

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Analytical recipes, alternatives, evidence dependencies and validity-preserving handoffs

**Criterion.** The evidence account identifies reused data and does not convert repeated experiments into replicated benefit.

**Trigger.** A synthesis infers evidential breadth, maturity or transferability from multiple publications or benchmark results.

**Non-trigger / cheaper path.** A compact dependence note is sufficient where only a few sources share one public log.

**Mechanism.** Record shared datasets, sites, experimental generators, author programmes and repeated cases; distinguish sample size within one study from independent replication. Preserve materially different versions without counting them as new field settings.

**Authority.** Evidence synthesiser reports dependence; consumers judge generality using actual independent settings rather than citation volume. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Provide reviewers and participants with a usable, lawful analytical chain, relevant sensitivity results, data dependence and unresolved assumptions. Specific receiving decision: Evidence synthesiser reports dependence; consumers judge generality using actual independent settings rather than citation volume.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S016`, `EPM:EPM-S019`, `EPM:EPM-S021`, `EPM:EPM-S022`, `EPM:EPM-S023`, `EPM:EPM-S056`. **BWP relations:** 18, individually enumerated in the JSON record. **Clusters:** BWP-K028. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-072` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-073"></a>
### EPM:EPM-073 — Dashboard possession as evidence of analytical quality

**Disposition:** `CEREMONY_NOT_GENERAL_PROPERTY`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Analytical results, decision consumers and continuation/return/non-use claims

**Criterion.** Success is expressed in evidence and decision terms, not artefact presence.

**Trigger.** A software purchase, licence, certification or dashboard is proposed as the success criterion.

**Non-trigger / cheaper path.** A query, table, script or focused conversation can satisfy the real analytical function.

**Mechanism.** Do not export dashboard possession as an obligation. Evaluate whether a representation supports the actual traceable inference and consumer interaction; keep the tool only if it earns that role.

**Authority.** Consumer evaluates function; vendor or project branding does not establish analytical authority. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Provide reviewers and participants with a usable, lawful analytical chain, relevant sensitivity results, data dependence and unresolved assumptions. Specific receiving decision: Consumer evaluates function; vendor or project branding does not establish analytical authority.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S001`, `EPM:EPM-S016`, `EPM:EPM-S036`, `EPM:EPM-S056`. **BWP relations:** 48, individually enumerated in the JSON record. **Clusters:** BWP-K001, BWP-K026. **Tensions:** BWP-T016.

**Rich record.** Select `key == EPM:EPM-073` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-074"></a>
### EPM:EPM-074 — Auditability distinguished from correctness

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Analytical recipes, alternatives, evidence dependencies and validity-preserving handoffs

**Criterion.** A result’s audit trail and its unresolved validity limits are both visible.

**Trigger.** A highly documented or reproducible analysis is claimed to be correct by virtue of its evidence trail.

**Non-trigger / cheaper path.** One explicit limitation statement tied to the result can defeat an overclaim; no duplicate review layer is required.

**Mechanism.** Separate traceability and computational reproducibility from semantic, population, model and causal validity. Use auditability to expose assumptions and reproduce a challenge, not as a replacement for evidence about them.

**Authority.** Analyst and reviewer use custody evidence to examine claims; no actor receives extra substantive authority merely by maintaining a log. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Provide reviewers and participants with a usable, lawful analytical chain, relevant sensitivity results, data dependence and unresolved assumptions. Specific receiving decision: Analyst and reviewer use custody evidence to examine claims; no actor receives extra substantive authority merely by maintaining a log.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S014`, `EPM:EPM-S016`, `EPM:EPM-S022`, `EPM:EPM-S045`, `EPM:EPM-S056`. **BWP relations:** 94, individually enumerated in the JSON record. **Clusters:** BWP-K005, BWP-K007, BWP-K028, BWP-K030, BWP-K032. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-074` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-075"></a>
### EPM:EPM-075 — Non-use and retirement when mining has no adequate purpose

**Disposition:** `STRONGLY_RETAINED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Analytical results, decision consumers and continuation/return/non-use claims

**Criterion.** An analysis can conclude inapplicable, already adequate, simpler method sufficient or evidence insufficient without being counted as failure to mine.

**Trigger.** Initial scoping, failed validation, disappearing consumers, obsolete monitoring or sustained evidence insufficiency.

**Non-trigger / cheaper path.** Use ordinary transaction queries, interviews, process modelling, direct observation or no intervention where those methods answer the question more adequately.

**Mechanism.** Permit non-use, narrowed use and retirement when the data cannot support the question, the result cannot affect a legitimate decision, or the harm/cost exceeds its plausible value. State what evidence or changed condition would justify reconsideration.

**Authority.** The accountable consumer and data authority decide whether to proceed; analysts must be able to report an evidence gap without manufacturing a model. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate legitimate purpose, threat/disclosure boundaries, generated-content uncertainty and contestable people-related conclusions to accountable consumers. Specific receiving decision: The accountable consumer and data authority decide whether to proceed; analysts must be able to report an evidence gap without manufacturing a model.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S001`, `EPM:EPM-S016`, `EPM:EPM-S017`. **BWP relations:** 60, individually enumerated in the JSON record. **Clusters:** BWP-K001, BWP-K026. **Tensions:** BWP-T016.

**Rich record.** Select `key == EPM:EPM-075` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-076"></a>
### EPM:EPM-076 — Privacy protection matched to an explicit attacker

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Participant challenge, privacy/fairness, federated computation and output-disclosure boundaries

**Criterion.** Privacy claims name the adversary and protected boundary, and do not equate pseudonyms or encryption with universal anonymity.

**Trigger.** Personal, commercially sensitive or linkable event data are collected, shared or analysed across trust boundaries.

**Non-trigger / cheaper path.** Use access restriction, aggregation, a smaller lawful extract or no release when these meet the purpose more safely than elaborate transformation.

**Mechanism.** Define the protected information, adversary’s plausible background knowledge and release/processing boundary; select and evaluate privacy transformations against that model and measure analytical utility loss. Treat output disclosure separately from secure computation.

**Authority.** Data governance determines acceptable exposure; privacy specialists and analysts assess the mechanism and its loss of useful distinctions. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate legitimate purpose, threat/disclosure boundaries, generated-content uncertainty and contestable people-related conclusions to accountable consumers. Specific receiving decision: Data governance determines acceptable exposure; privacy specialists and analysts assess the mechanism and its loss of useful distinctions.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S017`, `EPM:EPM-S040`. **BWP relations:** 30, individually enumerated in the JSON record. **Clusters:** BWP-K027, BWP-K041. **Tensions:** BWP-T014, BWP-T015.

**Rich record.** Select `key == EPM:EPM-076` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-077"></a>
### EPM:EPM-077 — Fairness and contestable people-related inference

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Participant challenge, privacy/fairness, federated computation and output-disclosure boundaries

**Criterion.** People-related conclusions are contestable, scoped and connected to evidence rather than presented as total objective assessment.

**Trigger.** Analysis affects individuals or groups through evaluation, resource allocation, monitoring or recommendations.

**Non-trigger / cheaper path.** Use non-identifying process-level evidence or refrain from personal ranking when individual attribution is unnecessary.

**Mechanism.** Limit people-related inference to supported units and legitimate purposes; expose data/metric limitations, assess differential representation and consequences, and provide a meaningful route to challenge or correct material attributions. Treat fairness as a separately specified concern, not a property inferred from conformance.

**Authority.** Affected participants can supply corrections and objections; institutional decision makers remain accountable for use and consequences. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate legitimate purpose, threat/disclosure boundaries, generated-content uncertainty and contestable people-related conclusions to accountable consumers. Specific receiving decision: Affected participants can supply corrections and objections; institutional decision makers remain accountable for use and consequences.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S012`, `EPM:EPM-S017`, `EPM:EPM-S045`. **BWP relations:** 56, individually enumerated in the JSON record. **Clusters:** BWP-K002, BWP-K006, BWP-K027, BWP-K041. **Tensions:** BWP-T014.

**Rich record.** Select `key == EPM:EPM-077` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-078"></a>
### EPM:EPM-078 — Federated mining within security and output boundaries

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Participant challenge, privacy/fairness, federated computation and output-disclosure boundaries

**Criterion.** The result states which identifiers, lengths, frequencies or relations remain observable and the associated performance cost.

**Trigger.** A legitimate cross-organisational analysis cannot lawfully or acceptably centralise the required raw data.

**Non-trigger / cheaper path.** Separate local analyses or a negotiated aggregate may suffice; federation is not a default for a single trusted dataset.

**Mechanism.** Choose a federated protocol with explicit participant, identifier, activity-mapping and adversary assumptions; distinguish what is hidden during computation from what the protocol and released result reveal. Compare privacy, communication and computation costs with simpler aggregate exchange.

**Authority.** Participating organisations jointly authorise the computation and release; analysts cannot promise secrecy beyond the protocol’s boundary. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate legitimate purpose, threat/disclosure boundaries, generated-content uncertainty and contestable people-related conclusions to accountable consumers. Specific receiving decision: Participating organisations jointly authorise the computation and release; analysts cannot promise secrecy beyond the protocol’s boundary.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S017`, `EPM:EPM-S033`. **BWP relations:** 75, individually enumerated in the JSON record. **Clusters:** BWP-K020, BWP-K027, BWP-K031, BWP-K041. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-078` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-079"></a>
### EPM:EPM-079 — Checked LLM assistance rather than asserted competence

**Disposition:** `CONTEXT_DEPENDENT`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** AI-assisted/extracted evidence and unresolved or rejected transfers to broad capability/authority

**Criterion.** Consequential generated outputs have been checked against source evidence or execution semantics, with uncertainty and rejected outputs retained.

**Trigger.** Language assistance can reduce a demonstrated interpretation or construction burden and checking is feasible.

**Non-trigger / cheaper path.** A deterministic query, template or manual review may be cheaper and more reliable for a small stable task.

**Mechanism.** Use LLM assistance for bounded tasks with explicit input, output semantics and independent checking of consequential claims or executable artefacts. Preserve source spans for extracted facts, tool/model versions and failed outputs; do not infer autonomous competence from a benchmark score.

**Authority.** Analyst retains responsibility for claims and tool execution; an LLM receives no operative authority from producing a plausible answer. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate legitimate purpose, threat/disclosure boundaries, generated-content uncertainty and contestable people-related conclusions to accountable consumers. Specific receiving decision: Analyst retains responsibility for claims and tool execution; an LLM receives no operative authority from producing a plausible answer.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S029`, `EPM:EPM-S055`, `EPM:EPM-S056`. **BWP relations:** 49, individually enumerated in the JSON record. **Clusters:** BWP-K029, BWP-K031. **Tensions:** BWP-T007.

**Rich record.** Select `key == EPM:EPM-079` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-080"></a>
### EPM:EPM-080 — Autonomous operative authority inferred from event logs

**Disposition:** `REJECTED_OR_DISFAVOURED`. **Examination:** `EXAMINED`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** AI-assisted/extracted evidence and unresolved or rejected transfers to broad capability/authority

**Criterion.** The composed system cannot promote an evidence output into a self-authorised intervention.

**Trigger.** Discovery, prediction or an LLM result is used as sufficient warrant for autonomous organisational action.

**Non-trigger / cheaper path.** Deliver a bounded analysis or reviewed recommendation without automatic mutation of work or rules.

**Mechanism.** Reject the inference from observation or model competence to operative authority. Require a separately established actor, mandate, feasible action and consequence evaluation for any real change.

**Authority.** External accountable actors retain their actual authority; no authority is created by the analytical system. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate legitimate purpose, threat/disclosure boundaries, generated-content uncertainty and contestable people-related conclusions to accountable consumers. Specific receiving decision: External accountable actors retain their actual authority; no authority is created by the analytical system.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S017`, `EPM:EPM-S027`, `EPM:EPM-S029`, `EPM:EPM-S055`. **BWP relations:** 43, individually enumerated in the JSON record. **Clusters:** BWP-K014, BWP-K024, BWP-K029. **Tensions:** BWP-T007, BWP-T008.

**Rich record.** Select `key == EPM:EPM-080` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-081"></a>
### EPM:EPM-081 — Text-derived event semantics retained as hypotheses

**Disposition:** `ASSUMPTION_SENSITIVE`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** AI-assisted/extracted evidence and unresolved or rejected transfers to broad capability/authority

**Criterion.** A consumer can trace a consequential derived event or relation to its text and see whether it was explicit or inferred.

**Trigger.** Relevant process evidence exists in text and a structured event log is unavailable or incomplete.

**Non-trigger / cheaper path.** Manual annotation of a small corpus or a simple deterministic extraction can be adequate; full generative extraction is not mandatory.

**Mechanism.** Treat text-derived events, identities, order and object relations as extracted hypotheses with source-span provenance and validation appropriate to their intended use. Separate explicit statements, inferred links and absent information; evaluate downstream sensitivity to extraction alternatives.

**Authority.** Extractor proposes records; analyst/domain reviewer establishes admissibility for the intended claim; narrative authorship does not guarantee factual correctness. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate legitimate purpose, threat/disclosure boundaries, generated-content uncertainty and contestable people-related conclusions to accountable consumers. Specific receiving decision: Extractor proposes records; analyst/domain reviewer establishes admissibility for the intended claim; narrative authorship does not guarantee factual correctness.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S054`, `EPM:EPM-S055`. **BWP relations:** 49, individually enumerated in the JSON record. **Clusters:** BWP-K029, BWP-K031. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-081` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-082"></a>
### EPM:EPM-082 — Broad external validity of uncertain object-centric analysis

**Disposition:** `UNRESOLVED`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** AI-assisted/extracted evidence and unresolved or rejected transfers to broad capability/authority

**Criterion.** The packet exports a compatibility/evidence question instead of presuming a general mature solution.

**Trigger.** A later synthesis relies on broad external validity of uncertain, dynamically interacting object analysis.

**Non-trigger / cheaper path.** Use a narrow validated object relation or uncertainty bound for a specific question rather than adopting an unvalidated general combination.

**Mechanism.** Keep the broad transfer claim unresolved; preserve each exact representation, uncertainty model and scoped guarantee, and identify which combinations have actually been evaluated.

**Authority.** Researchers establish formal compatibility; domain evaluators establish practical interpretation and usefulness. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate legitimate purpose, threat/disclosure boundaries, generated-content uncertainty and contestable people-related conclusions to accountable consumers. Specific receiving decision: Researchers establish formal compatibility; domain evaluators establish practical interpretation and usefulness.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S025`, `EPM:EPM-S026`, `EPM:EPM-S043`, `EPM:EPM-S044`, `EPM:EPM-S050`. **BWP relations:** 24, individually enumerated in the JSON record. **Clusters:** BWP-K029. **Tensions:** none.

**Rich record.** Select `key == EPM:EPM-082` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-083"></a>
### EPM:EPM-083 — Universal positive economic return on mining

**Disposition:** `NO_GENERAL_PROPERTY`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** no.

**Bearer.** Analytical results, decision consumers and continuation/return/non-use claims

**Criterion.** No guaranteed-benefit claim is exported; local value remains a separately testable proposition.

**Trigger.** A purchase, programme or method adoption is justified by generic return-on-investment claims.

**Non-trigger / cheaper path.** A low-cost bounded inquiry or an alternative method may dominate; do not require a business case model when a small safe exploratory cost is already justified.

**Mechanism.** Reject universal return. Assess benefits, acquisition and cleaning effort, interpretation, tooling, privacy, organisational response and opportunity cost for the actual purpose; retain negative, null and no-action outcomes.

**Authority.** The accountable sponsor evaluates value; a vendor case or analyst report cannot establish universal economic authority. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Communicate legitimate purpose, threat/disclosure boundaries, generated-content uncertainty and contestable people-related conclusions to accountable consumers. Specific receiving decision: The accountable sponsor evaluates value; a vendor case or analyst report cannot establish universal economic authority.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S016`, `EPM:EPM-S017`, `EPM:EPM-S032`. **BWP relations:** 46, individually enumerated in the JSON record. **Clusters:** BWP-K002, BWP-K025, BWP-K026. **Tensions:** BWP-T016.

**Rich record.** Select `key == EPM:EPM-083` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.

<a id="epm-epm-084"></a>
### EPM:EPM-084 — Validity-preserving analytical handoffs

**Disposition:** `RETAINED_IN_EVOLVED_FORM`. **Examination:** `EXAMINED_WITH_EVIDENCE_LIMIT`. **BWP-induced:** no. **Induced within the constituent lineage:** yes.

**Bearer.** Analytical recipes, alternatives, evidence dependencies and validity-preserving handoffs

**Criterion.** No downstream conclusion silently converts model fit into semantic truth, uncertain order into certain violation, description into authority or prediction into achieved causal benefit.

**Trigger.** A finding or model crosses method, representation, actor or time-regime boundaries and the receiving claim depends on its meaning.

**Non-trigger / cheaper path.** A short explicit qualification in the existing result or conversation may suffice. No dedicated new protocol, service, committee or form is required for every property.

**Mechanism.** At a consequential analytical handoff, carry the output’s unit, event interpretation, population/time scope, model/reference semantics, uncertainty and supported use. The receiving method checks compatibility with its own assumptions; a material mismatch causes reinterpretation, additional evidence, a narrower claim or non-use. Invalidate affected downstream conclusions when an upstream assumption materially changes.

**Authority.** The producer communicates the bounded claim; the receiver checks semantic compatibility; externally authorised actors still decide and act. Analytical competence does not itself supply additional organisational authority.

**Interaction.** Provide reviewers and participants with a usable, lawful analytical chain, relevant sensitivity results, data dependence and unresolved assumptions. Specific receiving decision: The producer communicates the bounded claim; the receiver checks semantic compatibility; externally authorised actors still decide and act.

**Retirement / omission.** Omit or retire this mechanism when its trigger no longer holds, a cheaper adequate path meets the stated postcondition, or the intended consumer disappears; preserve evidence needed for existing consequential decisions. For a non-retained candidate, retirement means dropping the overclaim, not its valid supporting techniques.

**Source keys:** `EPM:EPM-S014`, `EPM:EPM-S016`, `EPM:EPM-S017`, `EPM:EPM-S022`, `EPM:EPM-S026`, `EPM:EPM-S046`, `EPM:EPM-S050`, `EPM:EPM-S056`. **BWP relations:** 165, individually enumerated in the JSON record. **Clusters:** BWP-K018, BWP-K020, BWP-K021, BWP-K022, BWP-K025, BWP-K028, BWP-K032, BWP-K036, BWP-K039. **Tensions:** BWP-T012, BWP-T013, BWP-T017.

**Rich record.** Select `key == EPM:EPM-084` in the [full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [constituent register](EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json). The latter preserves the entire original record, original file and JSON pointer, original-record hash, all evidence-strength partitions, exact criticisms, assumptions and open questions. Evidence access is not upgraded by this projection.
