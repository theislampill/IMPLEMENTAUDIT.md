#!/usr/bin/env python3
"""Readback-only verifier. No imports from the synthesis builder or semantic specification.
Usage: python independent_verify.py PACKET_ROOT [--require-docs] [--output REPORT_JSON]
Verifies integrity, coverage, identity and reverse consistency; not scholarly truth.
"""
import sys,json,pathlib,hashlib,zipfile,itertools,collections
ROOT=pathlib.Path(sys.argv[1]); REQUIRE_DOCS='--require-docs' in sys.argv
REPORT_PATH=pathlib.Path(sys.argv[sys.argv.index('--output')+1]) if '--output' in sys.argv else ROOT/'EVOLVED_BWP_AUTOMATED_READBACK_REVIEW.json'
counts=collections.Counter(); failures=[]
def check(group,condition,detail=''):
 counts[group]+=1
 if not condition:failures.append({'group':group,'detail':str(detail)})
def unique_object(pairs):
 d={}
 for k,v in pairs:
  if k in d:raise ValueError('duplicate JSON key '+k)
  d[k]=v
 return d
def read(name):return json.loads((ROOT/name).read_text(encoding='utf-8'),object_pairs_hook=unique_object,parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
def sha(b):return hashlib.sha256(b).hexdigest()
for path in sorted(ROOT.rglob('*.json')):
 if path.name.endswith('FROZEN_MANIFEST.json') and path.parent==ROOT:continue
 try:json.loads(path.read_text(encoding='utf-8'),object_pairs_hook=unique_object,parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)));check('strict_json',True)
 except Exception as e:check('strict_json',False,str(path)+':'+str(e))
expected={'EBPM':('BUSINESS_PROCESS_MANAGEMENT',73,48,67,'94f96cf38e32d373d5962f23f86e33513cc865dcaa899716797771cc76d3df49'),'EWM':('WORKFLOW_MANAGEMENT',77,51,63,'e477651fe3629f33e98ddc04f51d33c4907c8fd659a7d518ba11e0544239e818'),'EPM':('PROCESS_MINING',84,58,70,'94e2d898e5ea6f15bcd913b8c13c7b83e3dc477879e3f20375520a50cbcf9858')}
raw={};rawsrc={};within={}
for lin,(stem,np,ns,nr,hash_) in expected.items():
 paths=list((ROOT/'input_archives').glob('*'+stem+'_FROZEN_PACKET*.zip'));check('input_archives',len(paths)==1,lin)
 path=paths[0];check('input_archives',sha(path.read_bytes())==hash_,lin)
 with zipfile.ZipFile(path) as z:
  check('input_archives',z.testzip() is None,lin+' CRC')
  mn=next(n for n in z.namelist() if n.endswith('FROZEN_MANIFEST.json'));m=json.loads(z.read(mn))
  check('input_archives',m['revision']==lin+'-R1-2026-09-06',lin+' revision')
  inventory=m['payload_inventory'];expnames={x.get('relative_filename',x.get('filename')) for x in inventory}|{mn}
  check('input_archives',set(z.namelist())==expnames,lin+' inventory')
  for f in inventory:
   n=f.get('relative_filename',f.get('filename'));b=z.read(n)
   check('input_payloads',len(b)==f['bytes'] and sha(b)==f['sha256'],lin+':'+n)
  for n in z.namelist():check('input_payloads',(ROOT/'inputs'/lin/n).read_bytes()==z.read(n),n)
 pp=read(f'inputs/{lin}/EVOLVED_{stem}_PROPERTY_LEDGER.json')['properties'];ss=read(f'inputs/{lin}/EVOLVED_{stem}_SOURCE_TABLE.json')['sources'];ww=read(f'inputs/{lin}/EVOLVED_{stem}_COMPOSITION_MODEL.json')['relations']
 check('input_counts',len(pp)==np and len(ss)==ns and len(ww)==nr,lin)
 for p in pp:raw[lin+':'+p['PROPERTY_ID']]=p
 for s in ss:rawsrc[lin+':'+s['SOURCE_ID']]=s
 # Source models use different field schemas; identify actual relation IDs without rewriting them.
 within[lin]={r.get('RELATION_ID',r.get('ID',r.get('id'))) for r in ww}
reg=read('EVOLVED_BWP_CONSTITUENT_PROPERTY_REGISTER.json');P={p['key']:p for p in reg['properties']}
check('properties',len(P)==len(reg['properties'])==234 and set(P)==set(raw),'234 unique exact keys')
critical_fields={'name':'PROPERTY_NAME','disposition':'CURRENT_STATUS','examination_status':'EXAMINATION_STATUS','criterion':'OBSERVABLE_POSTCONDITION','mechanism':'MECHANISM','trigger':'TRIGGER_OR_CONTEXT','non_trigger_cheap_path':'NON_TRIGGER_OR_CHEAP_PATH','authority':'ACTOR_AND_AUTHORITY_BOUNDARY','communication_interaction':'COMMUNICATION_OR_INTERACTION_REQUIREMENT','evidence_limit':'EVIDENCE_STRENGTH_PARTITIONS','criticism':'IMPORTANT_CRITICISMS','unresolved_questions':'OPEN_QUESTIONS'}
for key,p in P.items():
 check('property_identity',p['original_record']==raw[key],key)
 check('property_identity',sha(json.dumps(raw[key],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==p['canonical_original_sha256'],key+' canonical')
 for field,orig in critical_fields.items():check('property_fields',p[field]==raw[key][orig],key+' '+field)
 for rid in p['within_lineage_relation_ids']:check('within_lineage_refs',rid.split(':',1)[1] in within[p['lineage']],rid)
 check('properties',bool(p['bearer']) and bool(p['retirement_omission_condition']),key)
S=read('EVOLVED_BWP_SOURCE_REGISTER.json');sources={s['key']:s for s in S['sources']}
check('sources',len(sources)==len(S['sources'])==157 and set(sources)==set(rawsrc))
for key,s in sources.items():
 check('source_identity',s['original_record']==rawsrc[key],key)
 uses=sorted(p['key'] for p in P.values() if key in p['source_ids']);check('source_reverse',sorted(s['BWP_property_claim_uses'])==uses,key)
for p in P.values():
 for sid in p['source_ids']:check('source_refs',sid in sources,p['key']+':'+sid)
rl=read('EVOLVED_BWP_DIRECTIONAL_RELATION_LEDGER.json');R={r['id']:r for r in rl['relations']}
check('relations',len(R)==len(rl['relations'])==rl['count'])
reverse=collections.defaultdict(set);pairrels=collections.defaultdict(set)
sigs={(r['source_property'],r['target_property'],r['type'],r['origin_rule']) for r in R.values()}
for rid,r in R.items():
 a,b=r['source_property'],r['target_property'];check('relation_refs',a in P and b in P and P[a]['lineage']!=P[b]['lineage'],rid)
 reverse[a].add(rid);reverse[b].add(rid);pairrels[frozenset((a,b))].add(rid)
 check('relation_semantics',bool(r['semantic_basis']) and bool(r['evidence_boundary']) and bool(r['authority_comparison']),rid)
 check('relation_semantics',r['type'] in rl['allowed_relation_vocabulary'],rid)
 if r['directionality']=='SYMMETRIC_WITH_EXPLICIT_REVERSE':check('symmetry',(b,a,r['type'],r['origin_rule']) in sigs,rid)
 for dim,refpair in r['comparison_dimensions'].items():
  for ref in refpair.values():
   obj,field=ref.split('#/',1);check('comparison_refs',obj in P and field in P[obj],rid+' '+ref)
for key,p in P.items():check('property_relation_reverse',set(p['BWP_relation_ids'])==reverse[key] and len(p['BWP_relation_ids'])==len(set(p['BWP_relation_ids'])),key)
matrix=read('EVOLVED_BWP_INTRA_CROSSWALK_MATRIX.json');M=matrix['pairs'];actual={};sub=collections.defaultdict(collections.Counter)
for pair in M:
 a,b=pair['left_key'],pair['right_key'];unit=frozenset((a,b));check('pair_unique',unit not in actual,(a,b));actual[unit]=pair
 check('pair_refs',a in P and b in P and P[a]['lineage']!=P[b]['lineage'],(a,b))
 ids=set(pair['directional_relation_ids']);check('pair_relation_reverse',ids==pairrels.get(unit,set()),(a,b))
 unr=any(R[r]['type']=='UNRESOLVED' for r in ids);expected_status='UNRESOLVED_RELATION' if unr else ('MATERIAL_RELATION' if ids else 'NO_MATERIAL_RELATION')
 check('pair_status',pair['status']==expected_status and pair['unresolved_flag']==unr,(a,b))
 check('pair_status',bool(pair['adjudication_basis']) and pair['left_profile_ref']==a and pair['right_profile_ref']==b,(a,b))
 sub[P[a]['lineage']+'_'+P[b]['lineage']][pair['status']]+=1
universe=set()
for la,lb,num in [('EBPM','EWM',5621),('EBPM','EPM',6132),('EWM','EPM',6468)]:
 this={frozenset((a,b)) for a in P for b in P if P[a]['lineage']==la and P[b]['lineage']==lb}
 check('pair_denominator',len(this)==num and sum(sub[la+'_'+lb].values())==num,la+'x'+lb);universe.update(this)
check('pair_denominator',set(actual)==universe and len(M)==18221 and matrix['count']==18221,'all 18221')
counts_status=dict(collections.Counter(p['status'] for p in M));check('pair_denominator',counts_status==matrix['status_counts'])
clusters=read('EVOLVED_BWP_CONVERGENCE_AND_COMPOSITION_CLUSTERS.json')['clusters'];K={c['id']:c for c in clusters}
for cid,c in K.items():
 check('cluster_refs',all(m in P for m in c['members']) and sorted({P[m]['lineage'] for m in c['members']})==c['lineages'],cid)
 expected_r={r['id'] for r in R.values() if r['source_property'] in c['members'] and r['target_property'] in c['members']}
 check('cluster_reverse',set(c['relation_ids'])==expected_r,cid)
 for rid in c['relation_ids']:check('cluster_reverse',cid in R[rid]['cluster_ids'],cid+':'+rid)
 if c['composition_class']=='ONE_TO_MANY':check('composition_refs',c['originating_property'] in c['members'] and all(m in c['members'] for m in c['required_constituent_mechanisms']),cid)
for key,p in P.items():check('cluster_reverse',set(p['cluster_ids'])=={c['id'] for c in K.values() if key in c['members']},key)
tensions=read('EVOLVED_BWP_TENSION_LEDGER.json')['tensions'];T={t['id']:t for t in tensions}
for tid,t in T.items():
 check('tension_refs',all(m in P for m in t['constituent_properties']) and t['lineages']==sorted({P[m]['lineage'] for m in t['constituent_properties']}),tid)
 check('tension_semantics',all(t.get(f) for f in ['justified_scope_A','justified_scope_B','failure_when_A_dominates','failure_when_B_dominates','bounded_synthesis','unresolved_remainder','evidence_boundary']),tid)
 expected_r={r['id'] for r in R.values() if tid in r['tension_ids']};check('tension_reverse',set(t['relation_ids'])==expected_r and bool(expected_r),tid)
for key,p in P.items():check('tension_reverse',set(p['tension_ids'])=={t['id'] for t in T.values() if key in t['constituent_properties']},key)
for r in R.values():
 for cid in r['cluster_ids']:check('relation_backrefs',cid in K and r['id'] in K[cid]['relation_ids'],r['id'])
 for tid in r['tension_ids']:check('relation_backrefs',tid in T and r['id'] in T[tid]['relation_ids'],r['id'])
E=read('EVOLVED_BWP_COMPOSITION_INDUCED_PROPERTY_LEDGER.json');rejected=E['rejected_candidates']
check('emergence',len(E['properties'])==E['surviving_count']==E['pairwise_count']==E['genuinely_three_way_count']==0)
check('emergence',len(rejected)==E['candidate_count']==16 and all(c['decision']=='REJECTED_AS_NEW_BWP_PROPERTY' for c in rejected))
CE=read('EVOLVED_BWP_ANALYTICAL_COUNTEREXAMPLES.json');ceids={c['id'] for c in CE['counterexamples']}
for c in rejected:
 check('candidate_refs',all(m in P for m in c['proposed_parents']+c['sufficient_inherited_properties']) and all(r in R for r in c['required_relation_ids']) and c['failure_witness'] in ceids,c['candidate_id'])
 check('candidate_ablation',{x['removed_parent'] for x in c['minimality_tests']['parent_removal']}==set(c['proposed_parents']),c['candidate_id'])
 check('candidate_ablation',{x['removed_lineage'] for x in c['minimality_tests']['lineage_removal']}==set(c['lineages']),c['candidate_id'])
for c in CE['counterexamples']:
 check('counterexample_refs',all(m in P for m in c['inherited_properties_rejecting_global_claim']) and all(x['property'] in P for x in c['locally_satisfied_properties_or_restricted_checks']),c['id'])
 check('counterexample_semantics',bool(c['scope_caution']) and bool(c['emergence_adjudication']),c['id'])
Q=read('EVOLVED_BWP_REQUIRED_QUESTIONS_ADJUDICATION.json')['questions'];check('questions',{q['id'] for q in Q}=={'Q'+str(i) for i in range(1,15)})
for q in Q:check('question_refs',all(p in P for p in q['supporting_properties']) and all(c in ceids for c in q['counterexample_ids']) and all(r in R for r in q['relation_ids']),q['id'])
I=read('EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json');intake={r['key']:r for r in I['rows']}
check('intake',len(intake)==len(I['rows'])==I['total_population']==234 and set(intake)==set(P))
check('intake',I['total_population']==I['inherited_population']+I['BWP_induced_population'])
for key,row in intake.items():
 for field in ['disposition','examination_status','bearer','criterion','mechanism','trigger','authority','evidence_limit','BWP_relation_ids','cluster_ids','tension_ids','source_ids']:
  check('intake_reverse',row[field]==P[key][field],key+' '+field)
 check('intake_reverse',row['composition_induced_any_level']==P[key]['is_inherited_within_lineage_induced'] and not row['BWP_composition_induced'],key)
model=read('EVOLVED_BWP_COMPOSITION_MODEL.json');nodes={n['id'] for n in model['nodes']}
for e in model['edges']:
 check('model_refs',e['source_node'] in nodes and e['target_node'] in nodes and all(p in P for p in e['parent_properties']) and bool(e['relation_ids']) and all(r in R for r in e['relation_ids']),e['id'])
 check('model_semantics',not e['mandatory_global_sequence'] and bool(e['guard']),e['id'])
check('model_semantics',model['model_kind']=='GUARDED_MULTIGRAPH_NOT_SERIAL_PIPELINE' and not any(model['boundaries'].values()))
CF=read('EVOLVED_BWP_ALTERNATIVE_CONFIGURATIONS.json');check('configurations',len(CF['configurations'])==CF['count']==12)
for c in CF['configurations']:check('configuration_refs',all(p in P for p in c['required_property_mechanisms']),c['id'])
SS=read('EVOLVED_BWP_SHARED_SOURCE_IDENTITY_LEDGER.json');check('source_independence',SS['source_rows']==157 and SS['exact_shared_cross_lineage_work_groups']==len(SS['shared_work_identities'])==5 and not SS['external_research_used'])
for s in SS['shared_work_identities']:
 check('source_independence',all(k in sources for k in s['members']) and len({sources[k]['lineage'] for k in s['members']})>=2 and bool(s['independence_effect']),s['id'])
# Recompute fixtures without trusting their recorded PASS flags.
F=read('EVOLVED_BWP_EXECUTED_ANALYTICAL_FIXTURES.json')
eq={(0,0),(1,1)};neq={(0,1),(1,0)};tuples=list(itertools.product(range(2),repeat=3));join=[x for x in tuples if x[:2] in eq and x[1:] in eq and (x[0],x[2]) in neq]
check('executed_fixtures',not join and F['TRIANGLE_JOIN']['global_join']==join and all(len({v[i] for v in r})==2 for r in [eq,eq,neq] for i in [0,1]),'triangle')
# Finite net reachability, terminal marking and transition coverage.
edges={'start':['prepared'],'prepared':['end'],'end':[]}
def reaches(a,b):
 seen=set();todo=[a]
 while todo:
  n=todo.pop()
  if n==b:return True
  if n in seen:continue
  seen.add(n);todo+=edges[n]
 return False
check('executed_fixtures',all(reaches(n,'end') for n in edges) and edges['end']==[] and all(reaches('start',n) for n in edges),'sound finite net')
check('executed_fixtures',sum([2]*50+[10]*50)/100==F['CASE_MIX_REVERSAL']['before_mean'] and sum([3]*90+[11]*10)/100==F['CASE_MIX_REVERSAL']['after_mean'],'case mix')
check('executed_fixtures',len(set(['d','d']))==1 and len([('d','o1'),('d','o2')])==2,'multiplicity')
SCOUNTS=read('EVOLVED_BWP_COUNTS.json')
for key,value in [('inherited',len(P)),('sources',len(sources)),('pairs',len(M)),('directional_relations',len(R)),('clusters',len(K)),('tensions',len(T)),('counterexamples',len(ceids)),('alternative_configurations',len(CF['configurations'])),('later_population',len(intake)),('rejected_emergent_candidates',len(rejected))]:check('count_agreement',SCOUNTS[key]==value,key)
check('count_agreement',SCOUNTS['pair_status_counts']==counts_status)
neg={'REJECTED_OR_DISFAVOURED','CEREMONY_NOT_GENERAL_PROPERTY','NO_GENERAL_PROPERTY','SUPERSEDED_BY_STRONGER_FORM','DUPLICATE_CANDIDATE'}
check('negative_preservation',sum(p['disposition'] in neg for p in P.values())==35)
check('negative_preservation',{p['key'] for p in P.values() if p['disposition']=='UNRESOLVED'}=={'EBPM:EBPM-053','EWM:EWM-074','EPM:EPM-068','EPM:EPM-082'})
check('negative_preservation',sum(p['is_inherited_within_lineage_induced'] for p in P.values())==7)
if REQUIRE_DOCS:
 for n in ['EVOLVED_BWP_FROZEN_REPORT.md','EVOLVED_BWP_COMPLETENESS_AND_REVERSE_CONSISTENCY_REVIEW.md','EVOLVED_BWP_INTER_CROSSWALK_INTAKE.md','EVOLVED_BWP_PUBLIC_DOCUMENTATION_INTAKE.md']:
  check('required_docs',(ROOT/n).is_file() and (ROOT/n).stat().st_size>100,n)
report={'verifier':'Separately implemented readback verifier; no builder/spec imports','verification_scope':'Integrity, input identity, schema, complete pair enumeration, all references/reverse links, flags, intakes, count agreement and selected logical fixtures. This is not independent scholarly validation of every semantic judgement.','independent_scholarly_reviewer_used':False,'status':'PASS' if not failures else 'FAIL','assertions_executed':sum(counts.values()),'assertion_groups':dict(counts),'failure_count':len(failures),'failures':failures,'recomputed':{'properties':len(P),'sources':len(sources),'pairs':len(M),'pair_status_counts':counts_status,'relations':len(R),'clusters':len(K),'tensions':len(T),'BWP_E':len(E['properties']),'rejected_candidates':len(rejected),'counterexamples':len(ceids),'configurations':len(CF['configurations']),'intake':len(intake)}}
REPORT_PATH.parent.mkdir(parents=True,exist_ok=True)
REPORT_PATH.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
sys.exit(bool(failures))
