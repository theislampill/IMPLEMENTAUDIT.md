# Evolved-BWP frozen packet — start here

Revision: `BWP-R1-2026-09-06`. Research cut-off: 2026-09-06.

Start with [the report](EVOLVED_BWP_FROZEN_REPORT.md). For later property-by-property work, use [the full intake JSON](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.json) and [navigable intake](EVOLVED_BWP_INTER_CROSSWALK_INTAKE.md). The [manifest](EVOLVED_BWP_FROZEN_MANIFEST.json) lists exact members and hashes; the [verification receipt](EVOLVED_BWP_VERIFICATION_RECEIPT.json) states the internal verification scope.

There are 234 inherited properties, zero new BWP-E properties, 157 local source rows and 18,221 explicitly classified cross-lineage pairs. The composition adds relations, tensions, alternatives and counterexamples without deleting any constituent identity. All three original ZIPs and every original payload are bundled unchanged.

The source of every inherited claim is its original frozen dossier. New bearer annotations, crosswalk relations and candidate decisions are analytical additions. `analysis/` contains the authored semantic specification for inspection; it is not an external research corpus or an independent source. `verification/independent_verify.py` is a portable readback verifier.

Read [the completeness review](EVOLVED_BWP_COMPLETENESS_AND_REVERSE_CONSISTENCY_REVIEW.md) for the independence boundary: separate mechanical verification and same-executor semantic review, not a second scholarly reviewer. Read [the public intake](EVOLVED_BWP_PUBLIC_DOCUMENTATION_INTAKE.md) before reusing claims about effectiveness, novelty or adoption.

No outside-trifecta or target-system crosswalk occurred. No target owner, adoption or mutation is authorised. The final enclosing ZIP hash is supplied in an external archive receipt, not embedded recursively into the ZIP it would have to hash.
